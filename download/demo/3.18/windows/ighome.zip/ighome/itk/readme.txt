
This directory contains the ITK system based on Tcl/Tk. The tcltk subdirectory
contains the initialization scripts for Tcl and Tk.

ITK was created by Igor Gresovnik in 2003. This is a pure Tcl code that
implements a small set of practical extensions to Tcl/Tk. ITK is free for
any kind of use (see license.txt for terms of use).

Please do not remove or change this file.

$A Igor apr05;

