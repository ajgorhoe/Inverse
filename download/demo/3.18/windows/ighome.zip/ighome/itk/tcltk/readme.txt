
This directory contains the initialization scripts for Tcl and Tk. Tcl/Tk
is copyrighted by the Regents of the University of California, Sun Microsystems,
Inc., Scriptics Corporation, and other parties. User should refer to the file
license.txt for terms of use of Tcl/Tk. These terms apply for all files
contained in the sub-directories of the directory in which this file resides.

Tcl (the Tool Command Language) and Tk (the Toolkit) were created by John K.
Ousterhout. Hereby the system is used as a basis of ITK, which is used in some
programs that developed by Igor Gresovnik. Igor G. gratefully acknowleges the
development effort of Tcl/Tk and all those who enabled its public use. 

Please do not remove or change this file.

As the user of Tcl/Tk you are also requested not to remove or change the file
license.txt from the directory that contains this file.

$A Igor apr04;

