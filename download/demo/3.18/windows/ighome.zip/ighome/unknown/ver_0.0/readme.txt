
This file and the directory containing it were created by
program unknown ((null)) 0.0, session 0
at Sunday, March 09 2003, 22:44:39

