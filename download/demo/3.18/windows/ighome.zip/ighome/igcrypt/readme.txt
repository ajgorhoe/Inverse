
This file and the directory containing it were created by
program igcrypt (IGCrypt) 0.01, session 0
at Monday, January 06 2003, 22:52:25

