
This is the root of the software home directory. This directory is used by programs
designed by Igor Gresovnik or by programs that use some of Igor's general utilities
as a basic source directory.

Please do not remove or change this file.

$A Igor jan02;

