
This file and the directory containing it were created by
program inverse (Inverse) 3.18, session 0
at Tuesday, January 29 2008, 00:51:22

