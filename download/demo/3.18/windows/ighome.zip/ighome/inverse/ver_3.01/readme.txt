
This file and the directory containing it were created by
program inverse (Inverse) 3.01, session 0
at Monday, February 19 2007, 11:45:17

