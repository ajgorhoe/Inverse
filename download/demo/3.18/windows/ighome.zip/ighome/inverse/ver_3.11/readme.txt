
This file and the directory containing it were created by
program inverse (Inverse) 3.11, session 0
at Sunday, September 25 2005, 11:39:27

