
This file and the directory containing it were created by
program inverse (Inverse) 3.09, session 0
at Tuesday, January 29 2002, 13:38:24

