
This file and the directory containing it were created by
program inverse (Inverse) 3.12, session 0
at Monday, February 20 2006, 23:27:31

