
This file and the directory containing it were created by
program inverse (Inverse) 3.15, session 0
at Tuesday, February 20 2007, 10:46:56

