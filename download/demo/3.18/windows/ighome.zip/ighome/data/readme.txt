
This is the data directory. It includes the data that are constituent part of
programs and libraries that use the IGHOME directory as their root directory.
The program data can either reside in the software root directory (usually
defined by the environment variable IGHOME), the program (or library) directory
or in the version directory.

Data is searched for in the opposite orter (i.e. first in the version
directory). This means that different versions of the program can share common
data (e.g. icons), which are stored in the program directory, and even
different programs can share the data which are stored in the software root
directory. On the other hand, newer versions of the program can use modified
data by putting the files to the version instead of program directory.

Please do not remove this file.

$A Igor apr04;

