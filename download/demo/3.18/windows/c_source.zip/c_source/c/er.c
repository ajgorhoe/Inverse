#include <sysint.h>

#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <rf.h>

#include <mtypes.h>
#include <strop.h>
#include <fop.h>
#include <mtime.h>
#include <itk.h>


#include <er.h>


#undef errfunc0  /* macros in sysint.h for correction */
#undef errfunc1
#undef warnfunc1
#define MINBUF 2500  /* Minimum available space in the string error buffers */



FILE *errfl=NULL;
int errmode;

void marker(char *s,char c)
     /* Oznaci napako tako, da naredi datoteko, katere prvi znak imena je
     '%', nadaljevanje pa niz s. Ce se program prekine, preden je klicana
     funkcija deler z istim argumentom, datoteka s tem imenom ostane na disku.
     funkcija hkrati zapise znak c na konec datoteke, da se omogoci npr. stetje,
     kolikokrat je bil dolocen del programa izveden, preden je prislo do 
     prekinitve.
     $A Igor <==; */
{
FILE *fp;
char *t;
t=stringcat("%",s);
fp=fopen(t,"a+");
putc(c,fp);
fclose(fp);
}



void deler(char *s)
     /* Zbrise datoteko, ki jo je naredila funkcija marker z enakim nizom kot
     argumentom. 
     $A Igor <==; */
{
char *t;
t=stringcat("%",s);
remove(t);
}




/*    THE THREE STAGE ERROR REPORTING SYSTEM

- a set of utilities that enables making an error report in a standard way.
Error reporting is done in three stages: Error message (or report)
initialisation stage, message writing stage, and error report finalisation
stage.
  In the first stage the error report initialisation function is called (e.g.
err0 or err1, errfunc0 or errfunc1). This initialises the file and string
buffers to which the error reporter can write his own messages, prepends a
standard head for an error message (possibly with some useful information for
easier location of the place where error was generated) and does other tiny
necessary things that prepare the system for error reporting.
  In the second stage the error reporter writes the error report to a string
or file buffer. For accessing the string or error buffer there are functions
erf() and ers(). The message is simply printed e.g. by fprintf(erf(),"....",...)
of sprintf(erf(),"...",...). Several successive prints can be made, and the
messages printed may not contain the null characters (i.e. '\0'). In this
stage, the error reporter typically adds to the error message any information
he thinks would be useful for the receiver of the message (usually programme
user). There is an agreement that the printed messages should consist of one
or more full gramatically correct sentences, capitalised and ended by a period.
  In the last stage the error report finalisation function is called (e.g.
err2 or errfunc2). The finalisation function typically outputs the whole
error report to the standard error and the error output file (returned by
the function errorfile()), clears the buffers and possibly does some additional
stuff (such as prints posts a dialog box with an error report).

  All functions from this modula can be replaced by other functions in such a
way that the name of the specific function remains the same, but the
functionality changes. This enables even error reporting in low-level modules
to be adjusted in accordance with a specific application with its own error
reporting and messaging rules. This feature is implemented in such a way that
for each function, there is a function pointer which this function actually
calls, and the value of this function pointer can be modified to refer another
functon. The default function is also availavle, so that a newly defined
function can include a call to the default function. The function that sets
the function pointer returns its old value so it can be referred to or
restored if necessary.
  The default functions from this module have the following behaviour:
The first stage functions (err0, err1, errfunc0, errfunc1) first check if the
error message buffers are empty; If not, this is reported (this situation can
appear if something was printed to error message buffers somewhere else but
between a the calls to the first and the second stage function). Then the
error message buffers are prepared with head of the error messag written to
them. In the second stage, functions that give access to error message buffers
are called and specific information is written to that buffers. The functon
erf() at this stage always returns a file pointer to an open file; any writing
operation can be performed on this file pointer, but the file position should
not be modified (by writing operations, the position is automatically set to
the end of the current contents). The function ers() returns a pointer to the
first character after the end of the current contents of the memory buffer,
so that functions for writing to strings can directly be applied. Any call to
ers() first ensures that at least the specified minimum buffer size is left
in the allocated space; This size is by default 1000 bytes, but can be
increased to any number greater than 1000 bytes by the function minerbuf().
In the third stage (call to one of th efunctions err2 or errfunc2), the status
of buffers is checked and buffer contents are output to the standard error and
the error output file as it is returned by the function errorfile() (writing
to this file is skipped if the returned file pointer is NULL). An message tail
is appended to the buffers before the contents are output. Finally, the buffers
are emptied. Actually, the string buffer is not deallocated and the file
buffer is not closed, onlt the positions are reset to the beginning.

  An application can either replace one or more error reporting functions in
this module, or can use its own functions for error reporting; usually a
combination of both is used, so that error reporting in low level modules
is also affected and at the same time higher level features are used for
reportnig errors at higher levels (e.g. in file interpreter functions where
additional information about interpretation status is highly appreciated in
error messages). It is recommended that the second stage functions from this
module are always used, because the sufficient access to message buffers is
given by the module. Then it is recommended that the first stage functions
first call the appropriate original first stage functions and then do the
additional job (e.g. append additional information to the gead of the message
or store some addional information elsewhere; here the erorr message buffers
will typically be accessed). In the third stage functions, additional
information should be appended to error buffers first, then additional methods
of output should be used (e.g. by a dialog window) and additional storing
should be made if necessary, and finally the original third stage functions
should be called. 
  Use of the original first and second stage functions should be avoided if
what these functios do is not satisfactory for a specific application. This
usually includes two steps, the replacement of the original function itself
and possible derivation of other higher level fuctions. Sometimes the first
step would be enough, but sometimes we want to have some additional diversity
in the first and third stage functions (e.g. have different error reporting if
the error occured directly in an file interpreter function or not). Building
proper functions for replacement of the first and the second stage error
reporting functions is easy because there are functions that empty error
message buffers (typically this will be done within third stage functions, and
second stage functions will check if the buffers are empty and report if they
are not).
*/

 

/*      FILE AND STRING BUFFERS FOR WRITING DOWN ERROR MESSAGES 

  erf() returns the file and ers() returns the string into which the whole or
a part of the error message can be printed directly. If both are used, the
information in the string buffer is output first. For output, the message in
the string buffer can be accessed by ersbuf() as a standard C string ('\0'
terminated char *). The message in the file buffer is the whole contents
of the file from its beginning to the current position (therefore, if you
use this yourself, take care that you set appropriately the position after
usage). It is recommended to use only the string buffer. Function ermes()
appends the file buffer to the string buffer, clears the contents of the file
buffer and returns the contents of the string buffer, therefore it returns the
current contents of the whole error message.
  The function clearerbuf() clears the contents of both buffers, but does
not close the file or deallocate the string buffer. Function deleteerbuf()
deallocates the string buffer and closes (removes) the file buffer.
Function call minerbuf(minbuf) sets the minimum space in the string
buffer, so that whenever ers() is called, in the returned string buffer
there is enough space for at least minbuf characters. If enough characters
are printed to the buffer that there is less than for minbuf characters
free space left, the next call to the ers() extends the buffer in such a
way that the current content of the message is unchanged.
An open file (file pointer)is returned by erf(), into which we can write the
error message between the calls to error message initialisation and
finalisation functions. The file position is set after the end of the current
message.
  WARNING: Anything you print to ers() must be NULL terminated!
*/


/* THREAD LOCK FOR THREAD SAFE OPERATION: */
int erlock=0;

void lockersys(void)
    /* Locks error reporting system so that only the current thread can
    access them, and other threads must queue until the lock is released.
    $A Igor feb05; */
{
m_threadlock(erlock);
}

void unlockersys(void)
    /* Releases the error reporting system lock.
    $A Igor feb05; */
{
m_threadunlock(erlock);
}

/* FILE BUFFER: */

static FILE *fperf=NULL;

FILE *erfdefault(void)
    /* The default version of erf(). Made globally avaliable such that it can
    be upgraded. The position is at the end of the current contents of the
    error message buffer. 
    $A Igor jul99, nov02; */
{
if (fperf==NULL)
  fperf=tmpfile();
return fperf;
}


static FILE * (*erfptr) (void) = erfdefault;

void * seterf(FILE * (*func) (void))
    /* Sets the funcion erf(), which returns a file buffer for writing error
    messages, to func. Returns the previous function assigned to this task.
    $A Igor jul99, nov02; */
{
void *ret=erfptr;
erfptr=func;
return ret;
}


FILE *erf(void)
    /* Returns a file buffer for writing error messages. An error message can
    be written to that file between the two successive calls to the functions
    that initialise and finalise error reporting. The finalising function
    (i.e. err2 or errfunc2) will take care that the message written to the
    buffer will be output to the proper output streams and files. The
    message is contained in the file from the beginning to the current
    position.
    $A Igor jul99, nov02; */
{
if (erfptr!=NULL)
  return erfptr();
else
  return NULL;
}


/*  STRING BUFFER: */

static char *erbuf=NULL;
static int meslength=0,buflength=0,minbuflength=MINBUF;

char *ersdefault(void)
    /* Default version of the ers() function.
    Returns the string buffer on which one can print (e.g. by sprintf())
    a part of the error message. It is guaranteed that at least a certain
    minimum amount of space is allocated for the returned pointer, which can
    be set by minerbufdefault() (the function minerbuf() is initially
    set to that function).
    $A Igor nov02; */
{
if (erbuf==NULL)
{
  /* Allocate the buffer if necesary: */
  buflength=2*minbuflength+1;  meslength=0;
  erbuf=calloc(1,buflength);
  erbuf[0]='\0';  /* Obligatory NULL termination */
  meslength=0;
} else
{
  /* meslength+=strlen(erbuf+meslength); */
  meslength=strlen(erbuf);
}
if (1+meslength+minbuflength<buflength)
{
  /* Reallocate the buffer if free space is too small: */
  buflength=1+meslength+2*minbuflength;
  erbuf=realloc(erbuf,buflength);
}
/* address of the end of the current message, from which printing can be
continued: */
return (erbuf+meslength);
}

char *ersbufdefault(void)
    /* Default version of ersbuf().
    Returns the current contents of the string error message buffer,
    intended for output of the error report.
      WARNING: The function can return NULL if there was no need to allocate
    the buffer.
    $A Igor nov02; */
{
return erbuf;
}

static char filebufwarning='\0'; /* Records output of the recommendation that
            using file error buffers should be avoided. */

char *ermesdefault(void)
    /* Default version of ermes.
    Returns the complete contents of the error reporting buffers. If file
    buffer is not empty, its contents is appended to the string buffer and
    then the pointer to the beginning of the string buffer is returned.
    $A Igor nov02; */
{
FILE *erfp;
int pos=0,length;
char *sbuf=NULL;
/* Check if contents of file error buffer is not empty : */
erfp=erf();
if (erfp!=NULL)
 pos=ftell(erfp);
if (pos>0)
{
  /* Move contents of the file buffer to the string buffer: */
  sbuf=ers();
  length=fileread(sbuf,1,pos,erfp,1);
  sbuf[length]='\0';
  fseek(erfp,0,SEEK_SET);  /* Empty file buffer */
  if (filebufwarning=='\0')
  {
    sprintf(ers(),"\n\n\nRECOMMENDATION: Using file error buffer should be avoided.\n\n");
    filebufwarning='\1';
  }
}
return ersbuf(); /* return complete string error message */
}

static char * (*ersptr) (void) = ersdefault;
static char * (*ersbufptr) (void) = ersbufdefault;
static char * (*ermesptr) (void) = ermesdefault;


char *ers(void)
    /* Returns the string buffer on which one can print (e.g. by sprintf())
    a part of the error message. It is guaranteed that at least a certain
    minimum amount of space is alocated for the returned pointer, which can
    be set by minerbuf().
    $A Igor nov02; */
{
return ersptr();
}

char *ersbuf(void)
    /* Returns the current contents of the string error message buffer,
    intended for output of the error report.
      WARNING: The function can return NULL if there was no need to allocate
    the buffer.
    $A Igor nov02; */
{
return ersbufptr();
}

char *ermes(void)
    /* Returns the complete contents of the error message buffers, intended
    for output of the error report. If the file error buffer is not empty, it
    appends its contents to the end of the string error message buffer first.
    It actually returns the contents of the string error message buffer.
      The function can not return NULL.
    $A Igor nov02; */
{
return ermesptr();
}

void *seters(char * (*func) (void))
    /* Sets the function ers() to func and returns the address of the current
    function used as ers() as void *.
      WARNING:
      When the ers() is re-defined, the functions ersbuf(), minerbuf(),
    deleteerbuf(), clearerbuf() and aldso erf() should be redefined
    consistently! As an example of how to define these functions, see the
    definitions of their default versions in this module.
    $A Igor nov02; */
{
void *ret=ersptr;
ersptr=func;
return ret;
}

void *setersbuf(char * (*func) (void))
    /* Sets the function ersbuf() to func and returns the address of the
    current function used as ersbuf() as void *.
      WARNING:
      When the ersbuf() is re-defined, the functions ers(), minerbuf(),
    deleteerbuf(), clearerbuf() and aldso erf() should be redefined
    consistently! As an example of how to define these functions, see the
    definitions of their default versions in this module.
    $A Igor nov02; */
{
void *ret=ersbufptr;
ersbufptr=func;
return ret;
}

void *setermes(char * (*func) (void))
    /* Sets the function ermes() to func and returns the address of the
    current function used as ermes() as void *.
      WARNING:
      When the ermes() is re-defined, the functions ers(), minerbuf(),
    deleteerbuf(), clearerbuf() and aldso erf() should be redefined
    consistently! As an example of how to define these functions, see the
    definitions of their default versions in this module.
    $A Igor nov02; */
{
void *ret=ermesptr;
ermesptr=func;
return ret;
}


/* INITIALISATION AND SETTINGS FOR ERROR BUFFERS: */

int minerbufdefault(int size)
    /* Default version of minerbuf(). Sets the minimum number of bytes that
    will always be available in the error buffer, and returns the previous
    value. If size<0, then it only returns the current value of the minimum
    size, but does not change it. If min is smaller than the MINBUF (a macro
    defined in er.c), then the minimum buffer size is set to MINBUF.
    $A Igor nov02; */
{
int ret=minbuflength;
minbuflength=size;
if (minbuflength<MINBUF /* && minbuflength>=0 */ )
  minbuflength=MINBUF;
return ret;
}

int checkminerbufdefault(int size)
    /* Checks if minimum number of bytes that is always available in the error
    buffer is at least size. If not, it is increased to size, otherwise it is
    left unchanged. Returns previous minimum size of error buffer.
    $A Igor jul03; */
{
int ret;
ret=minbuflength;
if (minbuflength<size)
  minbuflength=size;
return ret;
}

void clearerbufdefault(void)
    /* Default version of clearerbufdefault().
    Resets error reporting buffers so that their content is empty. It does
    not deallocate temporary memory space or close the temporary file.
    $A Igor nov02; */
{
if (fperf!=NULL)
  fseek(fperf,0,SEEK_SET);
if (erbuf!=NULL)
{
  erbuf[0]='\0';
  meslength=0;
}
}

void deleteerbufdefault(void)
    /* Defauld version of deleteerbuf().
    Closes the error reporting system buffer file and deallocates the string
    buffer. Before that, it checks if any messages are still buffered and
    outputs these messages to the standard output.
    $A Igor nov02; */
{
char *message=ermesdefault();

if (message!=NULL)
{
  if (erbuf[0]!='\0')
  {
    fprintf(stderr,"\n==== REMAINING ERROR BUFFER! ====");
    fprintf(stderr,"%s\n====\n\n\n",message);
  }
  free(erbuf);
  meslength=0;
  buflength=0;
}
}

static int (*minerbufptr) (int) = minerbufdefault;
static int (*checkminerbufptr) (int) = checkminerbufdefault;
static void (*clearerbufptr) (void) = clearerbufdefault;
static void (*deleteerbufptr) (void) = deleteerbufdefault;

void *setminerbuf(int (*func) (int))
    /* Sets minerbuf() to func() and returns the address of the current
    function used as minerbuf() as void *.
      WARNING:
      When the minerbuf() is re-defined, other functions concerning the
    error reporting buffers such as ersbuf(), minerbuf(), deleteerbuf(),
    clearerbuf() and erf() should be redefined consistently! As an example of
    how to define these functions, see the definitions of their default
    versions in this module.
    $A Igor nov02; */
{
void *ret=minerbufptr;
minerbufptr=func;
return ret;
}

void *setcheckminerbuf(int (*func) (int))
    /* Sets checkminerbuf() to func() and returns the address of the current
    function used as minerbuf() as void *.
      WARNING:
      When the checkminerbuf() is re-defined, other functions concerning the
    error reporting buffers such as ersbuf(), minerbuf(), deleteerbuf(),
    clearerbuf() and erf() should be redefined consistently! As an example of
    how to define these functions, see the definitions of their default
    versions in this module.
    $A Igor jul03; */
{
void *ret=checkminerbufptr;
checkminerbufptr=func;
return ret;
}

void *setclearerbuf(void (*func) (void))
    /* Sets clearerbuf() to func() and returns the address of the current
    function used as clearerbuf() as void *.
      WARNING:
      When the clearerbuf() is re-defined, other functions concerning the
    error reporting buffers such as ersbuf(), minerbuf(), deleteerbuf(),
    clearerbuf() and erf() should be redefined consistently! As an example of
    how to define these functions, see the definitions of their default
    versions in this module.
    $A Igor nov02; */
{
void *ret=clearerbufptr;
clearerbufptr=func;
return ret;
}

void *setdeleteerbuf(void (*func) (void))
    /* Sets deleteerbuf() to func() and returns the address of the current
    function used as deleteerbuf() as void *.
      WARNING:
      When the deleteerbuf() is re-defined, other functions concerning the
    error reporting buffers such as ersbuf(), minerbuf(), deleteerbuf(),
    clearerbuf() and erf() should be redefined consistently! As an example of
    how to define these functions, see the definitions of their default
    versions in this module.
    $A Igor nov02; */
{
void *ret=deleteerbufptr;
deleteerbufptr=func;
return ret;
}


int minerbuf(int min)
    /* Sets the minimum number of available bytes in the string error reporting
    buffer to min and returns the previous minimum vlue.
    $A Igor nov01; */
{
return minerbufptr(min);
}

int checkminerbuf(int min)
    /* Checks if minimum number of bytes that is always available in the error
    buffer is at least size. If not, it is increased to size, otherwise it is
    left unchanged. Returns previous minimum size of error buffer.
    $A Igor jul03; */
{
return checkminerbufptr(min);
}

void clearerbuf(void)
    /* Clears the contents of error reporting buffers. This function must be
    called after the error messages residing in these buffers are output, so
    the buffer contents are not needed any more and buffers should be ready
    for filling with new messages.
    $A Igor nov02; */
{
clearerbufptr();
}

void deleteerbuf(void)
    /* Releases resources occupied by the error reporting buffers, e.g. closes
    the error buffer file and deallocates the string buffer. Before a call to
    this function, the contents of the buffers should be cleared by the
    clearerbuf().
      In principle this function is rarely used. Typical use is when for some
    special error message a lot of space is needed, so we needed to increase
    the buffer size in order to create the message, and after usage we want
    to release the unnecessary space. Typically we would call minerbuf(0)
    together with this function.
    $A Igor nov02; */
{
deleteerbufptr();
}




/* OUTPUT FILE FOR WRITING ERROR MESSAGES:
Defines a (possibly open) file into which program writes error reports
beside the standard error. Error message initialising and finalising
functions must be written in such a way that this file can be NULL! */


FILE *errorfiledefault(void)
    /* The default function, which returns the programme file for writing
    error reports - simply returns NULL, which means that eroror reports
    will not be written to a file by the error message finalising functions.
    $A Igor nov02; */
{
return NULL;
}

static FILE * (*errorfileptr) (void) = errorfiledefault;

void *seterrorfile(FILE * (*func) (void))
    /* Sets the function errorfile, which returns the file (either open or NULL)
    into which the function finalising the error report should also write the
    error message. The argument can be NULL, in that case the function errorfile
    will return NULL in any case. Function returns the previous version of
    errorfile() as void *.
      Typically, in applications this function will return an open output file
    or a special file for collecting error reports.
    $A Igor nov02; */
{
void *ret=errorfileptr;
errorfileptr=func;
return ret;
}


FILE *errorfile(void)
    /* Returns the file (either a file pointer to an open file or null) into
    which error messages should be also written beside the standard locations.
    $A Igor nov02; */
{
if (errorfileptr!=NULL)
  return errorfileptr();
else
  return NULL;
}




/* FUNCTION PAIRS FOR INITIALISING AND FINALISING ERROR REPORTS: */


void errfunc0default(char *funcname)
    /* Default version of errfunc0(). 
    Check if error buffers are empty and outputs a head of the error report
    on the standard error and the appropriate file if specified, where
    funcname must be the name of theC function in which the error appeared.
    $A Igor jul99 nov02; */
{
errfunc1default(-1,funcname);
}

static void (*errfunc0prt) (char *funcname) = errfunc0default;

void *seterrfunc0(void (*func) (char * funcname))
    /* Sets the function errfunc0 to func() and returns the previous version
    of errfunc0.
    $A Igor jul99 nov02; */
{
void *ret=errfunc0prt;
errfunc0prt=func;
return ret;
}

void errfunc0(char *funcname)
    /* Initialises the error report, in which the name funcname of the
    function in which error occurred is also noted.
    $A Igor jul99 nov02; */
{
errfunc0prt(funcname);
}


void errfunc1default(int code,char *funcname)
    /* Default version of errfunc1(). Prints a head of the error report
    containing the name of the function where error occured funcname and
    the error code code, to the standard error and the appropriate file if
    specified.
    $A Igor jul99 nov02; */
{
FILE *erout;
char *mes;
int function=0;
if (funcname!=NULL)
  if (strlen(funcname)>0)
     function=1;
erout=errorfile();  /* file for printing error reports */
/* Check if anything remained in error reporting buffers. It sould have not,
but if it has, this is reported; Such situation occurs for example if
something is printed to error buffers after finalisation of the last error
report: */
mes=erbuf;
if (mes!=NULL) if (strlen(mes)>0)
{
  fprintf(stderr,
    "\n\n==== Remaining contents of the the ERROR buffer:  ==\n%s\n\n\n",
    mes);
  if (erout!=NULL)
  {
    fprintf(erout,
    "\n\n==== Remaining contents of the the ERROR buffer:  ==\n%s\n\n\n",
    mes);
  }
  clearerbuf();  /* empty the contents of the buffer */
}
/* Print the head of the error message to the standard error and the
appropriate file, if specified by the function errorfile(): */
if (function)
{
  if (code>=0)
  {
    fprintf(stderr,"\n\n==== ERROR %i in %s  ==\n",code,funcname);
    if (erout!=NULL)
      fprintf(erout,"\n\n==== ERROR %i in %s  ==\n",code,funcname);
  } else
  {
    fprintf(stderr,"\n\n==== ERROR in %s  ==\n",funcname);
    if (erout!=NULL)
      fprintf(erout,"\n\n==== ERROR in %s  ==\n",funcname);
  }
} else
{
  if (code>=0)
  {
    fprintf(stderr,"\n\n==== ERROR %i  ==\n",code);
    if (erout!=NULL)
      fprintf(erout,"\n\n==== ERROR %i  ==\n",code);
  } else
  {
    fprintf(stderr,"\n\n==== ERROR  ==\n");
    if (erout!=NULL)
      fprintf(erout,"\n\n==== ERROR  ==\n");
  }
}
}

static void (*errfunc1ptr) (int code,char *funcname) = errfunc1default;

void *seterrfunc1(void (*func) (int code,char *funcname))
    /* Sets the function errfunc1 to func() and returns the previous version
    of errfunc1.
    $A Igor jul99 nov02; */
{
void *ret=errfunc1ptr;
errfunc1ptr=func;
return ret;
}

void errfunc1(int code,char *funcname)
    /* Initialises the error report, in which the name funcname of the
    function in which error occurred and the error code code are also noted.
    $A Igor jul99 nov02; */
{
errfunc1ptr(code,funcname);
}




void errfunc2default(void)
    /* Default version of errfunc2(). Copies error message from the error
    string of file buffer to the standart erorr and the appropriate file as
    specified by errorfile(), resets (empties) the error reporting buffers.
    $A Igor jul99 nov02; */
{
FILE *erout;
char *mes;
erout=errorfile();  /* file for printing error reports */
mes=ermes();  /* complete contents of the error buffer */
/* Copy contents of the error buffer to the standard error: */
if (mes!=NULL)
  if (mes[0]!='\0')
    fprintf(stderr,"%s",mes);
/* Finalise error message on the standard error: */
fprintf(stderr,"======\n\n\n");
if (erout!=NULL)
{
  /* Print the error report to the appropriate file if specified, in the
  same way as to the standard error: */
  if (mes!=NULL)
    if (mes[0]!='\0')
      fprintf(erout,"%s",mes);
  /* Finalise error message on the standard error: */
  fprintf(erout,"======\n\n\n");
}
clearerbuf();  /* Empty error buffers */
}


static void (*errfunc2ptr) (void) = errfunc2default;

void *seterrfunc2(void (*func) (void))
    /* Sets the function errfunc2 to func() and returns the previous version
    of errfunc2.
    $A Igor jul99 nov02; */
{
void *ret=errfunc2ptr;
errfunc2ptr=func;
return ret;
}


void errfunc2(void)
    /* Finalises the error report in which the name of the function in which\
    error occurred is also noted. In error reporting, this function is
    combined with either the error report initialisation function errfunc0()
    or errfunc1(); between the two calls arbitrary messages can be written to
    the error reporting file buffer (obtained by the function erf()) or the
    error reporting string buffer (obtained by the function ers()).
    $A Igor jul99 nov02; */
{
errfunc2ptr();
}




void err0default(void)
    /* Default version of err0().
    Check if error buffers are empty and outputs a head of the error report
    on the standard error and the appropriate file if specified.
    $A Igor jul99 nov01; */
{
errfunc1default(-1,NULL);
}

static void (*err0ptr) (void) = err0default;

void *seterr0(void (*func) (void))
    /* sets err0() to func(), returns previous version of err0.
    $A Igor jul99; */
{
void *ret=err0ptr;
err0ptr=func;
return ret;
}

void err0(void)
    /* Performs initialisation of the error report.
    $A Igor jul99; */
{
err0ptr();
}




void err1default(int code)
    /* Default version of err1().
    Check if error buffers are empty and outputs a head of the error report
    on the standard error and the appropriate file if specified, including
    the error code code.
    $A Igor jul99 nov02; */
{
errfunc1default(-1,NULL);
}

void (*err1ptr) (int code) = err1default;

void *seterr1( void (*func) (int code) )
    /* sets err1() to func() and returns the previous version of err1 as
    void *.
    $A Igor jul99 nov01; */
{
void *ret=err1ptr;
err1ptr=func;
return ret;
}

void err1(int code)
    /* Performs initialisation of the error report, also notes the error code.
    $A Igor jul99 nov01; */
{
err1ptr(code);
}



void err2default(void)
    /* default err2(). Completes the error report.
    $A Igor jul99 nov01; */
{
errfunc2default();
}

void (*err2ptr) (void) = err2default;

void *seterr2( void (*func) (void) )
    /* Sets err2() to func() and returns the previous version of err2 as
    void *.
    $A Igor jul99 nov01; */
{
void *ret=err2ptr;
err2ptr=func;
return ret;
}

void err2(void)
    /* Finalises the error report. It can be used in combination of either
    err0() or err1(0).
    $A Igor jul99 nov01; */
{
err2ptr();
}



void errorreport00(char *funcname,char *errorstring)
    /* Launches an error report. funcname is the name of the function where
    error occured and erorr string is a string containing the report. Either of
    these can be omitted.
      This function is conglomeration of the errfunc0(), printing on error
    buffer and errfunc2(), and its use is more comfortable than using individual
    parts when the error string is not composed of different parts.
      WARNING:
      The report generated by this function will not include correct information
    on the location where the error occured. To correct this, use the macro
    m_errorreport0.
      REMARK:
      This function was called errorreport0 before and was a global definition.
    Now it is replaced by a macro defined in er.h. This is necessary because
    the macro must extract position in the file (file name and line number).
    $A Igor feb05; */
{
errfunc0(funcname);
if (errorstring!=NULL)
  sprintf(ers(),"%s",errorstring);
else
  sprintf(ers(),"Unknown error.\n");
errfunc2();
}


/* WARNINGS: */


static int warnlevel=0,  /* Level of the current warning */
           warnoutput=10000;  /* Warning output level; warnings with levels
           lesser or equal to this are shoen. */

int warnoutleveldefault(int level)
    /* Default version of warnoutlevel().
    Sets the level of warning output to level, which should be 0 1, 2 or 3.
    Only those warnings which have the level lesser or equal to the level set
    by this function will be reported from the function call on. 0 will switch
    off warnings completely. Function returns the previous value of the
    warning output level.
    $A Igor nov02; */
{
int ret=warnoutput;
warnoutput=ret;
return ret;
}

void warnfunc1default(int level,char *funcname)
    /* Default version of warnfunc1().
    Initialises an warning message. level determines whether the warning
    is actually reported or not and should have a value 1, 2 or 3. The smaller
    the value is, the more important the warning is considered and greater the
    chance is that the warning will be output. Function warnoutdefault() can
    be used to specify which level warnings are printed out. funcname can
    specify the function in which the warning is produced. If it is NULL or an
    empty string, function name is considered irrelevant and is not stated inthe output.
    $A nov02; */
{
FILE *erout;
char *mes;
int function=0;
if (funcname!=NULL)
  if (strlen(funcname)>0)
     function=1;
warnlevel=level;
if (level<1) warnlevel=1;
erout=errorfile();  /* file for printing error reports */
/* Check if anything remained in error reporting buffers. It sould have not,
but if it has, this is reported; Such situation occurs for example if
something is printed to error buffers after finalisation of the last error
report: */
mes=erbuf;
if (mes!=NULL) if (strlen(mes)>0)
{
  fprintf(stderr,
    "\n\n==== Remaining contents of the the ERROR buffer:  ==\n%s\n\n\n",
    mes);
  if (erout!=NULL)
  {
    fprintf(erout,
    "\n\n==== Remaining contents of the the ERROR buffer:  ==\n%s\n\n\n",
    mes);
  }
  clearerbuf();  /* empty the contents of the buffer */
}
/* Print the head of the error message to the standard error and the
appropriate file, if specified by the function errorfile(): */
if (warnoutput>=warnlevel)
{
  if (function)
  {
    fprintf(stderr,"\n\n==== WARNING in  \"%s\"  ==\n",funcname);
    if (erout!=NULL)
      fprintf(erout,"\n\n==== WARNING in  \"%s\"  ==\n",funcname);
  } else
  {
    fprintf(stderr,"\n\n==== WARNING ==\n",funcname);
    if (erout!=NULL)
      fprintf(erout,"\n\n==== WARNING ==\n",funcname);
  }
}
}

void warnfunc2default(void)
    /* Default version of warnfunc2(). Finalises the warning message.
    $A Igor nov02; */
{
FILE *erout;
char *mes;
erout=errorfile();  /* file for printing error reports */
mes=ermes();  /* complete contents of the error buffer */
/* Copy contents of the error buffer to the standard error: */
if (mes!=NULL)
  if (mes[0]!='\0')
    fprintf(stderr,"%s",mes);
/* Finalise error message on the standard error: */
if (warnoutput>=warnlevel)
{
  fprintf(stderr,"======\n\n\n");
  if (erout!=NULL)
  {
    /* Print the error report to the appropriate file if specified, in the
    same way as to the standard error: */
    if (mes!=NULL)
      if (mes[0]!='\0')
        fprintf(erout,"%s",mes);
    /* Finalise error message on the standard error: */
    fprintf(erout,"======\n\n\n");
  }
}
clearerbuf();  /* Empty error buffers */
}


static int (*warnoutlevelptr) (int) = warnoutleveldefault;
static void (*warnfunc1ptr) (int, char *) = warnfunc1default;
static void (*warnfunc2ptr) (void) = warnfunc2default;

void *setwarnoutlevel(int (*func)(int))
    /* Sets the function warnoutlevel to func and returns previous version of
    this function so that it can be restored later or called within the new
    version (if this one is meant only as an supplemented version of the old
    function).
    $A Igor nov02; */
{
void *ret=warnoutlevelptr;
warnoutlevelptr=func;
return ret;
}

void *setwarnfunc1 (void (*func)(int, char *))
    /* Sets the function warnfunc1 to func and returns the previous version of
    this function so that it can be restored later or called within the new
    version (if this one is meant only as an supplemented version of the old
    function).
    $A Igor nov02; */
{
void *ret=warnfunc1ptr;
warnfunc1ptr=func;
return ret;
}

void *setwarnfunc2(void (*func)(void))
    /* Sets the function warnfunc1 to func and returns the previous version of
    this function so that it can be restored later or called within the new
    version (if this one is meant only as an supplemented version of the old
    function).
    $A Igor nov02; */
{
void *ret=warnfunc2ptr;
warnfunc2ptr=func;
return ret;
}

int warnoutlevel(int level)
    /* Sets the level of warning output to level, which should be 0 1, 2 or 3.
    Only those warnings which have the level lesser or equal to the level set
    by this function will be reported from the function call on. 0 will switch
    off warnings completely. Function returns the previous value of the
    warning output level.
    $A Igor nov02; */
{
return warnoutlevelptr(level);
}



void warnfunc1(int level,char *funcname)
    /* Initialises an warning message. level determines whether the warning
    is actually reported or not and should have a value 1, 2 or 3. The smaller
    the value is, the more important the warning is considered and greater the
    chance is that the warning will be output. Function warnoutdefault() can
    be used to specify which level warnings are printed out. funcname can
    specify the function in which the warning is produced. If it is NULL or an
    empty string, function name is considered irrelevant and is not stated inthe output.
    $A nov02; */
{
warnfunc1ptr(level,funcname);
}


void warnfunc2(void)
    /* Finalises the warning message.
    $A Igor nov02; */
{
warnfunc2ptr();
}


void warningreport1(int level,char *funcname,char *errorstring)
    /* Launches an error report. funcname is the name of the function where
    error occured and erorr string is a string containing the report. Either of
    these can be omitted.
      This function is conglomeration of the errfunc0(), printing on error
    buffer and errfunc2(), and its use is more comfortable than using individual
    parts when the error string is not composed of different parts.
    $A Igor feb05; */
{
warnfunc1(level,funcname);
if (errorstring!=NULL)
  sprintf(ers(),"%s",errorstring);
else
  sprintf(ers(),"Unknown warning.\n");
warnfunc2();
}



void instersys(FILE * (*erffunc) (void),
               void (*errfunc0func) (char * funcname),
               void (*errfunc1func) (int code,char *funcname),
               void (*errfunc2func) (void),
               void (*err0func) (void),
               void (*err1func) (int code),
               void (*err2func) (void)    )
    /* Sets the most important user defined functions of the error reporting
    system. This does not include the error buffer functions since these can
    usually be taken from this module.
    Names of the arguments unambiguously indicate, which functions are in
    question.
    $A Igor jul99 avg01 nov01; */
{
seterf(erffunc); /* seterrorfile(errorfilefunc); */
/* seterf(erffunc); */
seterrfunc0(errfunc0func);
seterrfunc1(errfunc1func);
seterrfunc2(errfunc2func);
seterr0(err0func);
seterr1(err1func);
seterr2(err2func);
}




static char *locationstring=NULL;
static int locationlock=0;

void errfunc0cor(char *function,char *file,int line,char *date)
    /* Corrected function for error reporting called by macro errfunc0 (to
    override the original function) - adds more accurate data about the
    error, i.e. the source file, line number and date of compilation.
      DON'T CALL this function DIRECTLY, it should be called only as errfunc0!
    $A Igor dec03; */
{
char *p,buf[20];
sprintf(buf,"%i",line);
/* Make file to point after the last file separator in the original file
(or to remain as is if there are none): */
p=file;
if (file!=NULL)
{
  p+=strlen(file);
  while (p>file)
  {
    if (*(p-1)=='/' || *(p-1)=='\\')
      file=p;
    else
      --p;
  }
}
disppointer((void **) &locationstring);
stringappend(&locationstring,"\"");
stringappend(&locationstring,function);
stringappend(&locationstring,"\"");
stringappend(&locationstring," (");
stringappend(&locationstring,file);
stringappend(&locationstring,", ");  /* ", line " */
stringappend(&locationstring,buf);
stringappend(&locationstring,", ");  /* ", comp. " */
stringappend(&locationstring,date);
stringappend(&locationstring,")");
errfunc0(locationstring);
}


void errfunc1cor(int code,char *function,char *file,int line,char *date)
    /* Corrected function for error reporting called by macro errfunc1 (to
    override the original function) - adds more accurate data about the
    error, i.e. the source file, line number and date of compilation.
      DON'T CALL this function DIRECTLY, it should be called only as errfunc1!
    $A Igor dec03; */
{
char *p,buf[20];
sprintf(buf,"%i",line);
/* Make file to point after the last file separator in the original file
(or to remain as is if there are none): */
p=file;
if (file!=NULL)
{
  p+=strlen(file);
  while (p>file)
  {
    if (*(p-1)=='/' || *(p-1)=='\\')
      file=p;
    else
      --p;
  }
}
disppointer((void **) &locationstring);
stringappend(&locationstring,function);
stringappend(&locationstring," (");
stringappend(&locationstring,file);
stringappend(&locationstring,", ");  /* ", line " */
stringappend(&locationstring,buf);
stringappend(&locationstring,", ");  /* ", comp. " */
stringappend(&locationstring,date);
stringappend(&locationstring,")");
errfunc1(code,locationstring);
}



void warnfunc1cor(int level,char *function,char *file,int line,char *date)
    /* Corrected function for warnings called by macro watnfunc1 (to override
    the original function) - adds more accurate data about the error, i.e.
    source file, line number and date of compilation.
      DON'T CALL this function DIRECTLY, it should be called only as warnfunc1!
    $A Igor dec03; */
{
char *p,buf[20];
sprintf(buf,"%i",line);
/* Make file to point after the last file separator in the original file
(or to remain as is if there are none): */
p=file;
if (file!=NULL)
{
  p+=strlen(file);
  while (p>file)
  {
    if (*(p-1)=='/' || *(p-1)=='\\')
      file=p;
    else
      --p;
  }
}
disppointer((void **) &locationstring);
stringappend(&locationstring,function);
stringappend(&locationstring," (");
stringappend(&locationstring,file);
stringappend(&locationstring,", ");  /* ", line " */
stringappend(&locationstring,buf);
stringappend(&locationstring,", ");  /* ", comp. " */
stringappend(&locationstring,date);
stringappend(&locationstring,")");
warnfunc1(level,locationstring);
}







              /***************************/
              /*                         */
              /*  CALLING STACK TRACING  */
              /*                         */
              /***************************/

/* Functions and variables used in calling stack tracing mechanisms are defined
below. Macros and comments on this are in the header file er.h. */

typedef struct _callinfo {  /* Calling stack data for a thread */
  int
    thread;     /* thread ID */
  stack
    callstack,  /* calling stack */
    callseq;    /* calling sequence */
} *callinfo;


/* Maximum of calls registered in calling sequence: */
static int maxcallseq=10000,excallseq=1000;

/* Stack of calling data for individual threads: */
static stack calldata=NULL;

/* Flags: */
static int regcallstack=1,    /* register calling stack */
           regcallseq=0;      /* register calling sequence */

static callinfo getcallinfo(void)
    /* Returns the calling information structure for the current thread. If
    such a structure does not yet exists for the current execution thread, it
    is first created and initialized.
    $A Igor apr04; */
{
int threadid,i;
callinfo cur;
if (calldata==NULL)
  calldata=newstack(10);
threadid=getthreadid();
for (i=1;i<=calldata->n;++i)
{
  /* Get the next calling data and check if its thread number matches the
  current thread: */
  cur=calldata->s[i];
  if (cur->thread==threadid)
    return cur;
}
/* The calling data for the current thread was not found, the data structure
must be created anew: */
cur=calloc(1,sizeof(*cur));
cur->thread=threadid;
cur->callstack=newstack(100);
cur->callseq=newstack(m_maxval(100,excallseq));
return cur;
}


void tr_regfuncname(char *name)
    /* Registers function name on the calling stack and calling sequence info
    structures for the current execution thread.
    $A Igor apr04; */
{
callinfo info;
info=getcallinfo();
if (regcallstack)
  pushstack(info->callstack,name);
if (regcallseq)
{
  pushstack(info->callseq,name);
  if (info->callseq->n>maxcallseq+excallseq)
    while (info->callseq->n>maxcallseq)
      delstack(info->callseq,1);
}
}


void tr_unregfuncname(char *name)
    /* Unregisters function name on the calling stack and calling sequence info
    structures for the current execution thread.
    $A Igor apr04; */
{
callinfo info;
stack st;
if (regcallstack)
{
  info=getcallinfo();
  if (stringlength(name)>0)
  {
    /* We don't need to check for matching function name, just pop the last
    name on the stack: */
    if (info->callstack->n>0)
      popstack(info->callstack);
  } else
  {
    /* We must find the name on the stack that actually matches name. Therefore
    we also check if any function names above the name on the calling stack
    has not been removed form the stack yet, and launch warning in this case: */
    int match=0,which,i,nchar;
    st=info->callstack;
    which=st->n;
    while(which>0 && cmpstrings(name,st->s[which]))
      --which;
    if (which==0 || which<st->n)
    {
      warnfunc1(1,"tr_unregfuncname");
      sprintf(ers(),"Function name to unregister (\"%s\") does not match the last\n");
      sprintf(ers(),"name on the calling stack");
      if (st->n>0)
      {
        sprintf(ers()," (%s).\n",st->s[st->n]);
        sprintf(ers(),"Thread %i, calling stack length %i, first matched %i.\nUnmatched names:\n",
          info->thread,st->n,which);
        nchar=0;
        for (i=st->n;i>which;--i)
        {
          nchar+=sprintf(ers(),"%s",st->s[i]);
          if (i>which+1)
            nchar+=sprintf(ers()," <- ");
          if (nchar>60)
          {
            sprintf(ers(),"\n");
            nchar=0;
          }
        }
        sprintf(ers(),"\n");
      } else
        sprintf(ers()," (no names on this stack).\n");
      warnfunc2();
    }
  }
}
}





          /*************************************/
          /*                                   */
          /*  TRACING UTILITIES FOR DEBUGGING  */
          /*                                   */
          /*************************************/


/* Functions and variables used in execution tracing mechanisms are defined
below. Macros and comments on this are in the header file er.h. */



typedef struct _trace {  /* nested trace data for pair TRIN/TROUT */
  int 
    group,     /* user defined group ID */
    id,        /* user defined ID */
    traceid,   /* internal trace ID */
    level,     /* trace level */
    thread,    /* thread ID */
    threadid;  /* internal thread ID */
  double 
    time;      /* time of executin of corresponding TRIN */
} *trace;

typedef struct _thread {  /* thread data */
  int
    thread,      /* ID of the thread corresponding to the structure */
    threadid,    /* internal thread ID */
    tracelevel;  /* trace level within the current thread */
  double
    prevtime;    /* time of the last executed TROUT or TRPT */
  stack
    traces;      /* stack of nestet trace structures */
} *thread;

/* Settings: */
static FILE *tracefile=NULL;
static char *tracefilename="0tracefile.txt";  /* name of the trace file */
static int 
         marktime=1,     /* flag for time marks */
         traceindent=2;  /* indentation for nested levels in the file */

static int 
         tracelock=0,       /* for safety in multi-thread environment */
         traceopenerror=0,  /* file can't be open */
         tracelastid=0,     /* counter of assigned IDs */
         mainthread=0;      /* The main thread ID */
static double
         curtime=0,            /* Current time */
         inittime=0;        /* CPU time when initialized */

static stack 
         traces=NULL,   /* auxiliary stack pointer, not allocated */
         used=NULL,     /* trace structures for recycling */
         threads=NULL;  /* thread data */
static thread thr=NULL; /* data for the current thread */



static indtab  idtab=NULL;


static void opentracefile(char *sourcefile)
    /* If not yet open, it opent she trace file and does some initialization
    for tracing.
    $A Igor feb03; */
{
static int curthread;
if (tracefile==NULL && !traceopenerror)
{
  /* Initialization - write down some information first */
  used=newstack(10);
  threads=newstack(5);
  mainthread=getmainthreadid();
  curthread=getthreadid();
  curtime=inittime=cputime(); 
  tracefile=fopen(tracefilename,"a");
  if (tracefile==NULL)
  {
    /* Could not open the file */
    errfunc0("opentracefile");
    sprintf(ers(),"Could not open the execution trace file \"%s\" for appending\n.");
    sprintf(ers(),"There will be no further attempts to open the file, therefore\n");
    sprintf(ers(),"trace logging will not be performed in this session.\n");
    errfunc2();
    traceopenerror=1;
  }
  else
  {
    /* Print the head of the new session */
    fprintf(tracefile,"\n\n\n");
    fprintf(tracefile,"\nNew trace session open from the source file %s\n\n",
      sourcefile);
    fprintf(tracefile,"Input Traces are written in the form\n\n");
    fprintf(tracefile,"  < gr,id (globid:lev)  {line  file (func)}  // comment // t=tot/dif\n");
    fprintf(tracefile,"gr: user specified group, id: user specified id, lev: tracelevel,\n");
    fprintf(tracefile,"globid: global ID of the trace (internally assigned),\n");
    fprintf(tracefile,"line: line in the source code, file: source file, func: function\n");
    fprintf(tracefile,"comment: user defined comment, tot: total CPU time\n");
    fprintf(tracefile,"dif: difference in CPU time with respect to the previous trace\n");
    fprintf(tracefile,"  Heads: < - input to a block, > - exit from a block,");
    fprintf(tracefile,"| - point trace\n");
    fprintf(tracefile,"  In the multithread case, heads are followed by internal thread ID\n");
    fprintf(tracefile,"(except in the main thread), e.g. <2 3: 2.1 (5) ..., |1 ...\n");
    fprintf(tracefile,"\n\n");
    fflush(tracefile);
  }
} else if (tracefile!=NULL)
{
  /* Launc low level warning on redundant call: */
  warnfunc1(3,"opentracefile");
  sprintf(ers(),"Trace file has already been open.\n");
  warnfunc2();
}
}


static void getthreaddata(void)
    /* Retreives and sets the thread data for the current threasd, sets the
    stack of traces to the corresponding stack for that thread, etc.
    $A Igor feb03; */
{
int i,curthread,threadid;
if (threads==NULL)
  threads=newstack(4);
curthread=getthreadid();
/* Find the thread data structure corresponding to the current thread: */
threadid=0;
for (i=1; i<=threads->n && threadid==0; ++i)
{
  thr=threads->s[i];
  if (thr->thread==curthread)
    threadid=i;
}
if (threadid==0)  /* thread data not found, create a new one: */
{
  thr=calloc(1,sizeof(*thr));
  pushstack(threads,thr);
  thr->thread=curthread;
  thr->threadid=threadid=threads->n;
  thr->tracelevel=0;
  thr->prevtime=cputime();
  thr->traces=newstack(5);
  /* Notification of new thread in the tracefile: */
  if (tracefile!=NULL)
  {
    fprintf(tracefile,"!T Thread ID %i corresponds to the thread %i",
      threadid,curthread);
    if (curthread==mainthread)
      fprintf(tracefile," (main thread).\n");
    else
      fprintf(tracefile,".\n");
  }
}
traces=thr->traces;
}



FILE *trf(void)
    /* Returns the trace file. It opens it if it is not yet open, so one can
    always directly write to the returned file without any checks.
    $A Igor feb03; */
{
if (tracefile==NULL)
{
  opentracefile("<<Open by trf()>>");
  if (tracefile==NULL)
  {
    errfunc0("trf");
    sprintf(ers(),"Dangerous:\nThe trace file can not be open for writing.\n");
    sprintf(ers(),"This may cause a crash of the program.\n");
    errfunc2();
  } else
    fflush(tracefile);
}
return tracefile;
}


int tracelockstate(void)
    /* Returns the state of tracelock; Needed in tr_mark_mem() in sysint.h to
    prevent infinite recursion.
    $A Igor feb04; */
{
return tracelock;
}


int extraceinfunc(int group,int id,char *funcname,char *comment,
                   char *filename,int line)
    /* Marks the beginning of the nested block whose execution we are tracing.
    This function should be always called through the macro TRIN in combination
    with TROUT. In such a way one can easily switch whether the function is
    actually compiled (macro EXTRACE) or executed (macro TRCOND) in a given
    portion of code, and it makes absolutely no effect on the compiled code
    when the compilation is switched off.
      Used for tracing which portions of code are executed and in which order
    and which code were executed before program crash.
    $A Igor feb04; */
{
trace tr=NULL;
int i,lockstate;
char *shortfilename=NULL;
lockstate=tracelock;
m_threadlock(tracelock);
if (tracefile==NULL)
  opentracefile(filename);
getthreaddata();
++tracelastid;
if (marktime)
  curtime=cputime();
if (used->n>1)
  pushstack(traces,(tr=popstack(used)));
else
  pushstack(traces,(tr=calloc(1,sizeof(*tr))) );
tr->group=group;
tr->id=id;
tr->level=thr->tracelevel;
tr->threadid=0;
tr->thread=0;
tr->traceid=tracelastid;
tr->thread=thr->thread;
tr->threadid=thr->threadid;
tr->time=curtime;
if (tracefile!=NULL)
{
  shortfilename=fileminusdir(filename);
  /* First print errors, warnings and other messages: */
  if (lockstate)
  {
    for (i=1;i<=(2+thr->tracelevel)*traceindent;++i)
      fprintf(tracefile," ");
    fprintf(tracefile,"!L Lock state was %i\n",lockstate);
  }
  for (i=1;i<=thr->tracelevel*traceindent;++i)
    fprintf(tracefile," ");
  if (thr->thread==mainthread)
    fprintf(tracefile,"< ");
  else
    fprintf(tracefile,"<%i ",thr->threadid);
  fprintf(tracefile,"%i,%i (%i;%i)",group,id,tr->traceid,thr->tracelevel);
  fprintf(tracefile,"  {%i  %s (%s)}",line,shortfilename,funcname);
  if (stringlength(comment)>0)
  fprintf(tracefile,"  // %s //",comment);
  if (marktime)
    fprintf(tracefile," t=%g/(%g)",curtime,curtime-thr->prevtime);
  fprintf(tracefile,"\n");
  fflush(tracefile);
  disppointer((void **) &shortfilename);
}
++thr->tracelevel;
m_threadunlock(tracelock)
return 0;
}



int extraceoutfunc(int group,int id,char *funcname,char *comment,
                    char *filename,int line)
    /* Marks the end of the nested block whose execution we are tracing.
    This function should be always called through the macro TROUT in 
    combination with (preceeding) TRIN. In such a way one can easily switch
    whether the function is actually compiled (macro EXTRACE) or executed
    (macro TRCOND) in a given portion of code, and it makes absolutely no
    effect on the compiled code when the compilation is switched off.
      Used for tracing which portions of code are executed and in which order
    and which code were executed before program crash.
    $A Igor feb04; */
{
trace tr=NULL;
struct _trace traux={0};
int i,lockstate;
char *shortfilename=NULL;
lockstate=tracelock;
m_threadlock(tracelock)
if (tracefile==NULL)
  opentracefile(filename);
getthreaddata();
--thr->tracelevel;
if (tracefile==NULL)
  opentracefile(filename);
/*
if (traces==NULL)
  traces=newstack(30);
*/
if (traces->n==0)
{
  for (i=1;i<=thr->tracelevel*traceindent;++i)
    fprintf(tracefile,"%s"," ");
  fprintf(tracefile,"    !! No matching entrance trace for exit trace below:\n");
}
/*
if (used==NULL)
  used=newstack(30);
*/
if (traces->n>1)
  pushstack(used,(tr=popstack(traces)));
if (tr==NULL)
  tr=&traux;
if (marktime)
  curtime=cputime();

if (tracefile!=NULL && tr!=NULL)
{
 shortfilename=fileminusdir(filename);
 /* First print errors, warnings and other messages: */
  if (lockstate)
  {
    for (i=1;i<=(2+thr->tracelevel)*traceindent;++i)
      fprintf(tracefile," ");
    fprintf(tracefile,"!L Lock state was %i\n",lockstate);
  }
  if (thr->tracelevel!=tr->level)
  {
    for (i=1;i<=(2+thr->tracelevel)*traceindent;++i)
      fprintf(tracefile," ");
    fprintf(tracefile,"!E Trace level (%i) different than that of entrance trace (%i)!\n",
            thr->tracelevel,tr->level);
  }
  for (i=1;i<=thr->tracelevel*traceindent;++i)
    fprintf(tracefile," ");
  if (thr->thread==mainthread)
    fprintf(tracefile,"> ");
  else
    fprintf(tracefile,">%i ",thr->threadid);
  fprintf(tracefile,"%i,%i (%i;%i)",group,id,tr->traceid,thr->tracelevel);
  fprintf(tracefile,"  {%i  %s (%s)}",line,shortfilename,funcname);
  fprintf(tracefile,"  // %s //",comment);
  if (marktime)
    fprintf(tracefile," t=%g/%g",curtime,curtime-tr->time);
  fprintf(tracefile,"\n");
  fflush(tracefile);
  disppointer((void **) &shortfilename);
}
popindtab(idtab);
thr->prevtime=curtime;
m_threadunlock(tracelock)
return 0;
}



int extraceptfunc(int group,int id,char *funcname,char *comment,
                     char *filename,int line)
    /* Marks the position in a block of code whose execution we are tracing.
    This function should be always called through the macro TRPT. In such a 
    way one can easily switch whether the function is actually compiled (macro
    EXTRACE) or executed (macro TRCOND) in a given portion of code, and it
    makes absolutely no effect on the compiled code when the compilation is
    switched off.
      Used for tracing which portions of code are executed and in which order
    and which code were executed before program crash.
    $A Igor feb04; */
{
int i,lockstate;
char *shortfilename=NULL;
lockstate=tracelock;
m_threadlock(tracelock)
if (tracefile==NULL)
  opentracefile(filename);
getthreaddata();
++tracelastid;
if (marktime)
  curtime=cputime();
if (tracefile!=NULL)
{
 shortfilename=fileminusdir(filename);
 /* First print errors, warnings and other messages: */
  if (lockstate)
  {
    for (i=1;i<=(2+thr->tracelevel)*traceindent;++i)
      fprintf(tracefile," ");
    fprintf(tracefile,"!L Lock state was %i\n",lockstate);
  }
  for (i=1;i<=thr->tracelevel*traceindent;++i)
    fprintf(tracefile," ");
  if (thr->thread==mainthread)
    fprintf(tracefile,"| ");
  else
    fprintf(tracefile,"|%i ",thr->threadid);
  fprintf(tracefile,"%i,%i (%i;%i)",group,id,tracelastid,thr->tracelevel);
  fprintf(tracefile,"  {%i  %s (%s)}",line,shortfilename,funcname);
  fprintf(tracefile,"  // %s //",comment);
  if (marktime)
    fprintf(tracefile," t=%g/%g",curtime,curtime-thr->prevtime);
  fprintf(tracefile,"\n");
  fflush(tracefile);
  disppointer((void **) &shortfilename);
}
thr->prevtime=curtime;
m_threadunlock(tracelock)
return 0;
}




int extracecomfunc(char *comment,char *filename,int line)
    /* Writes a comment to the trace file. If comment=NULL then only the
    comment head is printed and no newline character is appended, which makes
    possible for the user to print something to the trace file (and add the
    newline character himself).
    $A Igor feb03; */
{
int i,lockstate;
char *shortfilename=NULL;
lockstate=tracelock;
m_threadlock(tracelock)
if (tracefile==NULL)
  opentracefile(filename);
getthreaddata();
if (tracefile!=NULL)
{
 shortfilename=fileminusdir(filename);
 /* First print errors, warnings and other messages: */
  if (lockstate)
  {
    for (i=1;i<=(2+thr->tracelevel)*traceindent;++i)
      fprintf(tracefile," ");
    fprintf(tracefile,"!L Lock state was %i\n",lockstate);
  }
  for (i=1;i<=(2+thr->tracelevel)*traceindent;++i)
    fprintf(tracefile," ");
  if (thr->thread==mainthread)
    fprintf(tracefile,"// ");
  else
    fprintf(tracefile,"//%i ",thr->threadid);
  /*
  fprintf(tracefile,"%i: ",thr->tracelevel);
  */
  if (comment!=NULL)
  {
    fprintf(tracefile," \"%s\"",comment);
    fprintf(tracefile,"      {%i  %s}",line,shortfilename);
    fprintf(tracefile,"\n");
  }
  fflush(tracefile);
  disppointer((void **) &shortfilename);
}
m_threadunlock(tracelock)
return 0;
}









