/*
    KONSTRUKCIJA 3D GRAFOV
*/



#include <sysint.h>

#include <stdlib.h>
#include <stddef.h>
#include <math.h>
#include <mtypes.h>
#include <strop.h>
#include <gro.h>
#include <st.h>
#include <vec.h>

#include <sg_graph.h>




   /***************************************************/
   /*        FUNKCIJE ZA KONSTRUKCIJO 2D GRAFOV       */
   /***************************************************/

#include "sg_gr2d.h"




         /***********************/
         /*                     */
         /*      3D GRAPHS      */
         /*                     */
         /***********************/



void calccontourcolor(double z,double min,double max,truecolor color)
    /* Izracuna barvo konture, ki lezi na z, pri cemer je spodnja meja obmocja
    min, zgornja pa max. Proti nizjim vrednostim gredo barve proti modri, proti
    visjim pa proti rdeci. Izracunana barva se zapise v spremenljivko *color,
    za katero mora biti prostor ze alociran. */
{
double halfint,quartint,midp,qp,kcol,val,halfcol;
double mingrey=0.0,plusmingrey=0.0,power=0.3;
double val1,power1;
power1=1;

if (z<min) z=min;
if (z>max) z=max;
halfcol=mingrey+(1-mingrey)/2;
halfint=(max-min)/2;
quartint=halfint/2;
midp=min+halfint;
kcol=(1-mingrey)/0.5;
if (z<midp)
{
  qp=min+quartint;
  /* mingrey=plusmingrey*(1-fabs(z-qp)/quartint); */
  if (z<qp)
    val=0.5*pow(fabs((z-min)/quartint),power);
  else
    val=1-0.5*pow(fabs((z-midp)/quartint),power);

  if (z<qp)
    val1=0.5*pow(fabs((z-min)/quartint),power1);
  else
    val1=1-0.5*pow(fabs((z-midp)/quartint),power1);
  /* val=0.5*(val+val1); */

  color->green=(float) mingrey+(float) val*(1-(float) mingrey);
  color->blue=1-color->green+(float) mingrey;
  color->red=(float) mingrey;
} else
{
  qp=max-quartint;
  /* mingrey=plusmingrey*(1-fabs(z-qp)/quartint); */
  if (z<qp)
    val=0.5*pow(fabs((z-midp)/quartint),power);
  else
    val=1-0.5*pow(fabs((z-max)/quartint),power);

  if (z<qp)
    val1=0.5*pow(fabs((z-midp)/quartint),power1);
  else
    val1=1-0.5*pow(fabs((z-max)/quartint),power1);
  color->red=(float) mingrey+(float) val*(1-(float) mingrey);
  color->green=1-color->red+(float) mingrey;
  color->blue=(float) mingrey;
}
}





gogroup gomakeframe3dsimple(frame3d frame)
    /* Sestavi graficni objekt - tridimenzionalni okvir iz crt. frame doloca
    koordinate okvirja. */
{
_coord3d p1,p2;
gogroup ret=NULL,ret1=NULL;
ret=newgogroupst(1,5,0);
ret->name=stringcopy("frame3d");
/*
ret->primitives=newstack(5);
ret->groups=newstack(1);
*/
/* Nastavitve za risanje crt: */
ret->ls1=malloc(sizeof(*ret->ls1));
ret->ls1->color.red=1; ret->ls1->color.blue=1; ret->ls1->color.green=1;
ret->ls1->linewidth=1;
ret->ls1->linetype=1;
ret->ls1->extra=NULL;
/* Sestava okvirja: */
/* Spodnji pravokotnik: */
p1.x=frame->max.x; p1.y=frame->min.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->max.y; p2.z=frame->min.z;
goaddline(&p1,&p2,ret->primitives,ret);
p1.x=frame->max.x; p1.y=frame->max.y; p1.z=frame->min.z;
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->min.z;
goaddline(&p1,&p2,ret->primitives,ret);
/* Zgornji pravokotnik: */
p1.x=frame->min.x; p1.y=frame->min.y; p1.z=frame->max.z;
p2.x=frame->max.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddline(&p1,&p2,ret->primitives,ret);
p1.x=frame->max.x; p1.y=frame->min.y; p1.z=frame->max.z;
p2.x=frame->max.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddline(&p1,&p2,ret->primitives,ret);
p1.x=frame->max.x; p1.y=frame->max.y; p1.z=frame->max.z;
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddline(&p1,&p2,ret->primitives,ret);
p1.x=frame->min.x; p1.y=frame->max.y; p1.z=frame->max.z;
p2.x=frame->min.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddline(&p1,&p2,ret->primitives,ret);
/* Precke, ki povezujejo spodnji in zgornji stirikotnik: */
p1.x=frame->max.x; p1.y=frame->min.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddline(&p1,&p2,ret->primitives,ret);
p1.x=frame->max.x; p1.y=frame->max.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddline(&p1,&p2,ret->primitives,ret);
p1.x=frame->min.x; p1.y=frame->max.y; p1.z=frame->min.z;
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddline(&p1,&p2,ret->primitives,ret);
/* Koordinatne osi: */
ret1=newgogroupst(0,1,0);
ret1->name=stringcopy("axes");
/*
ret1->primitives=newstack(1);
*/
/* Nastavitve za risanje crt: */
ret1->ls1=malloc(sizeof(*ret1->ls1));
ret1->ls1->color.red=1; ret1->ls1->color.blue=0; ret1->ls1->color.green=0;
ret1->ls1->linewidth=1;
ret1->ls1->linetype=1;
ret1->ls1->extra=NULL;
ret1->ts1=malloc(sizeof(*ret1->ts1));
ret1->ts1->color.red=1; ret1->ts1->color.green=1; ret1->ts1->color.blue=0;
ret1->ts1->font=1;
ret1->ts1->height=0.03;
ret1->ts1->spacing=0;
ret1->ts1->expansion=1;
ret1->ts1->xalignment=0;
ret1->ts1->yalignment=0;
pushstack(ret->groups,ret1);
/* Os x */
p1.x=frame->min.x; p1.y=frame->min.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->min.y; p2.z=frame->min.z;
goaddline(&p1,&p2,ret1->primitives,ret1);
goaddtext("Os X",&p2,ret1->primitives,ret1);
/* Os y */
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->min.z;
goaddline(&p1,&p2,ret1->primitives,ret1);
goaddtext("Os Y",&p2,ret1->primitives,ret1);
/* Os z */
p2.x=frame->min.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddline(&p1,&p2,ret1->primitives,ret1);
goaddtext("Os Z",&p2,ret1->primitives,ret1);
return ret;
}








static gogroup gomakeframe3dold(frame3d frame,int numx,int numy,int numz)
    /* Sestavi graficni objekt - tridimenzionalni okvir iz crt. frame doloca
    koordinate okvirja. numx, numy in numz povedo, na koliko delov naj bodo
    razdeljene ctte, vzporedne z osmi x, y in z. */
{
_coord3d p1,p2,p3;
gogroup ret=NULL,ret1=NULL;
double tf=0.1;
ret=newgogroupst(1,5,0);
ret->name=stringcopy("frame3d");
/*
ret->primitives=newstack(5);
ret->groups=newstack(1);
*/
/* Nastavitve za risanje crt: */
ret->ls1=malloc(sizeof(*ret->ls1));
ret->ls1->color.red=1; ret->ls1->color.blue=1; ret->ls1->color.green=1;
ret->ls1->linewidth=1;
ret->ls1->linetype=1;
ret->ls1->extra=NULL;
/* Sestava okvirja: */
/* Spodnji pravokotnik: */
p1.x=frame->max.x; p1.y=frame->min.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->max.y; p2.z=frame->min.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numy);
p1.x=frame->max.x; p1.y=frame->max.y; p1.z=frame->min.z;
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->min.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numx);
/* Zgornji pravokotnik: */
p1.x=frame->min.x; p1.y=frame->min.y; p1.z=frame->max.z;
p2.x=frame->max.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numx);
p1.x=frame->max.x; p1.y=frame->min.y; p1.z=frame->max.z;
p2.x=frame->max.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numy);
p1.x=frame->max.x; p1.y=frame->max.y; p1.z=frame->max.z;
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numx);
p1.x=frame->min.x; p1.y=frame->max.y; p1.z=frame->max.z;
p2.x=frame->min.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numy);
/* Precke, ki povezujejo spodnji in zgornji stirikotnik: */
p1.x=frame->max.x; p1.y=frame->min.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numz);
p1.x=frame->max.x; p1.y=frame->max.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numz);
p1.x=frame->min.x; p1.y=frame->max.y; p1.z=frame->min.z;
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numz);
/* Koordinatne osi: */
ret1=newgogroupst(0,1,0);
ret1->name=stringcopy("axes");
/*
ret1->primitives=newstack(1);
*/
/* Nastavitve za risanje crt: */
ret1->ls1=malloc(sizeof(*ret1->ls1));
ret1->ls1->color.red=1; ret1->ls1->color.blue=0; ret1->ls1->color.green=0;
ret1->ls1->linewidth=1;
ret1->ls1->linetype=1;
ret1->ls1->extra=NULL;
ret1->ts1=malloc(sizeof(*ret1->ts1));
ret1->ts1->color.red=1; ret1->ts1->color.green=1; ret1->ts1->color.blue=0;
ret1->ts1->font=1;
ret1->ts1->height=0.03;
ret1->ts1->spacing=0;
ret1->ts1->expansion=1;
ret1->ts1->xalignment=0;
ret1->ts1->yalignment=0;
pushstack(ret->groups,ret1);
/* Os x */
p1.x=frame->min.x; p1.y=frame->min.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->min.y; p2.z=frame->min.z;
goaddlinediv(&p1,&p2,ret1->primitives,ret1,numx);
p3.x=p2.x+tf*(p2.x-p1.x); p3.y=p2.y+tf*(p2.y-p1.y); p3.z=p2.z+tf*(p2.z-p1.z);
goaddtext("Os X",&p3,ret1->primitives,ret1);
/* Os y */
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->min.z;
goaddlinediv(&p1,&p2,ret1->primitives,ret1,numy);
p3.x=p2.x+tf*(p2.x-p1.x); p3.y=p2.y+tf*(p2.y-p1.y); p3.z=p2.z+tf*(p2.z-p1.z);
goaddtext("Os Y",&p3,ret1->primitives,ret1);
/* Os z */
p2.x=frame->min.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret1->primitives,ret1,numz);
p3.x=p2.x+tf*(p2.x-p1.x); p3.y=p2.y+tf*(p2.y-p1.y); p3.z=p2.z+tf*(p2.z-p1.z);
goaddtext("Os Z",&p3,ret1->primitives,ret1);
return ret;
}






gogroup gomakeframe3d(frame3d frame,golinesettings ls,golinesettings lsbas,
    int numx,int numy,int numz)
    /* Sestavi graficni objekt - tridimenzionalni okvir iz crt. frame doloca
    koordinate okvirja. numx, numy in numz povedo, na koliko delov naj bodo
    razdeljene ctte, vzporedne z osmi x, y in z. ls doloca lastnosti crt, ki
    sestavljajo okvir, lsbas pa lastnosti crt, ki tvorijo osnovni kot. */
{
_coord3d p1,p2;
gogroup ret=NULL,ret1=NULL;
double tf=0.1;
ret=newgogroupst(1,5,0);
ret->name=stringcopy("3D-frame");
/* Nastavitve za risanje crt: */
ret->ls1=malloc(sizeof(*ret->ls1));
*(ret->ls1)=*ls;
/* Sestava okvirja: */
/* Spodnji pravokotnik: */
p1.x=frame->max.x; p1.y=frame->min.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->max.y; p2.z=frame->min.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numy);
p1.x=frame->max.x; p1.y=frame->max.y; p1.z=frame->min.z;
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->min.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numx);
/* Zgornji pravokotnik: */
p1.x=frame->min.x; p1.y=frame->min.y; p1.z=frame->max.z;
p2.x=frame->max.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numx);
p1.x=frame->max.x; p1.y=frame->min.y; p1.z=frame->max.z;
p2.x=frame->max.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numy);
p1.x=frame->max.x; p1.y=frame->max.y; p1.z=frame->max.z;
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numx);
p1.x=frame->min.x; p1.y=frame->max.y; p1.z=frame->max.z;
p2.x=frame->min.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numy);
/* Precke, ki povezujejo spodnji in zgornji stirikotnik: */
p1.x=frame->max.x; p1.y=frame->min.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numz);
p1.x=frame->max.x; p1.y=frame->max.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numz);
p1.x=frame->min.x; p1.y=frame->max.y; p1.z=frame->min.z;
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret->primitives,ret,numz);
/* Koordinatne osi: */
ret1=newgogroupst(0,1,0);
ret1->name=stringcopy("axes");
/* Nastavitve za risanje crt: */
ret1->ls1=malloc(sizeof(*ret1->ls1));
*(ret1->ls1)=*lsbas;
pushstack(ret->groups,ret1);
/* Os x */
p1.x=frame->min.x; p1.y=frame->min.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->min.y; p2.z=frame->min.z;
goaddlinediv(&p1,&p2,ret1->primitives,ret1,numx);
/* Os y */
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->min.z;
goaddlinediv(&p1,&p2,ret1->primitives,ret1,numy);
/* Os z */
p2.x=frame->min.x; p2.y=frame->min.y; p2.z=frame->max.z;
goaddlinediv(&p1,&p2,ret1->primitives,ret1,numz);
return ret;
}




gogroup gomakeendaxeslabels3d0(frame3d frame,char *strx,char *stry,char *strz,
            gotextsettings tsx, gotextsettings tsy,gotextsettings tsz,
            double factx,double facty,double factz)
    /* Sestavi graficni objekt - tekst na koncu crt, ki tvorijo osnovni kot
    okvirja v 3 dimenzijah. frame doloca koordinate okvirja. tsx, tsy in tsz
    dolocajo lastnosti teksta na koncu crt v smeri osi x, y in z, strx, stry
    in strz so nizi, ki se izpisejo, factx, facty in factz pa predstavljajo
    deleze intervalov (iz parametra frame), za katere je tekst pomaknjen izven
    grafa od konca ustreznih crt. */
{
_coord3d p1,p2,p3;
gogroup ret=NULL,retx=NULL,rety=NULL,retz=NULL;
double tf=0.1;
ret=newgogroupst(1,5,0);
ret->name=stringcopy("endaxeslabels");
/*
ret->primitives=newstack(5);
ret->groups=newstack(1);
*/
retx=newgogroupst(0,1,0);
retx->name=stringcopy("x");
/*
retx->primitives=newstack(1);
*/
retx->ts1=malloc(sizeof(*retx->ts1));
*(retx->ts1)=*tsx;
rety=newgogroupst(0,1,0);
rety->name=stringcopy("y");
/*
rety->primitives=newstack(1);
*/
rety->ts1=malloc(sizeof(*rety->ts1));
*(rety->ts1)=*tsy;
retz=newgogroupst(0,1,0);
retz->name=stringcopy("z");
/*
retz->primitives=newstack(1);
*/
retz->ts1=malloc(sizeof(*retz->ts1));
*(retz->ts1)=*tsz;
pushstack(ret->groups,retx);
pushstack(ret->groups,rety);
pushstack(ret->groups,retz);
/* Os x */
p1.x=frame->min.x; p1.y=frame->min.y; p1.z=frame->min.z;
p2.x=frame->max.x; p2.y=frame->min.y; p2.z=frame->min.z;
p3.x=p2.x+tf*(p2.x-p1.x); p3.y=p2.y+tf*(p2.y-p1.y); p3.z=p2.z+tf*(p2.z-p1.z);
goaddtext(strx,&p3,retx->primitives,retx);
/* Os y */
p2.x=frame->min.x; p2.y=frame->max.y; p2.z=frame->min.z;
p3.x=p2.x+tf*(p2.x-p1.x); p3.y=p2.y+tf*(p2.y-p1.y); p3.z=p2.z+tf*(p2.z-p1.z);
goaddtext(stry,&p3,rety->primitives,rety);
/* Os z */
p2.x=frame->min.x; p2.y=frame->min.y; p2.z=frame->max.z;
p3.x=p2.x+tf*(p2.x-p1.x); p3.y=p2.y+tf*(p2.y-p1.y); p3.z=p2.z+tf*(p2.z-p1.z);
goaddtext(strz,&p3,retz->primitives,retz);
return ret;
}


gogroup gomakeendaxeslabels3d(frame3d frame,char *strx,char *stry,char *strz,
            gotextsettings ts,double fact)
    /* Podobno kot gomakeendaxeslabels3d0(), le da ima tekst za vse osi enake
    lastnosti (ts) in tudi delezi pomika teksta izven okvirja (fact) so enaki. */
{
return gomakeendaxeslabels3d0(frame,strx,stry,strz,ts,ts,ts,fact,fact,fact);
}





int gridbascalc(double min,double max,double *first,double *step)
    /* Izracuna zacetno tocko, korak in stevilo tock osnovne mreze, ki jo damo
    lahko na interval z mejama min in max. Korak osnovne mreze mora biti cela
    potenca stevila 10. */
{
double e;
char *str=NULL,*str1=NULL;
e= (floor(log10(max-min))); /* desetiski eksponent koraka med razdelki mreze */
/* Izogniti se je treba napaki zaradi zaokrozevanja, zato izracunamo *step na-
mesto *step=pow(10,e); tako: */
str=makestring(10);
sscanf(str,"%i",(int) e);
str1=stringcat("1.0E",str);
*step=atof(str1);
if (str!=NULL)
  free(str);
if (str1!=NULL)
  free(str1);
*first=*step*ceil(min/(*step));
return 1+(int) floor((max-*first)/(*step));
}



/*
static int gridcalcnum(double min,double max,double step)
{
return (int) floor((max-*first)/(*step));
}
*/






void gridcalc(double min,double max,int nummin,stack st,stack st1,
              stack st2)
     /* Dolooci vse razdeleke mreze za interval med min in max. Na sklad s0
     nalozi razdelke najfinejse delitve, na sklad s1 razdelke bolj grobe, na
     sklad s2 pa razdelke najbolj grobe delitve. nummin je najmanjse dopustno
     stevilo razdelkov v najbolj grobi delitvi. Skladi morajo biti ob klicu
     funkcije inicializirani (prostor alociran, brez elementov). Mnozice
     razdelkov, ki se nalozijo na sklad, so disjunktne. */
{
double factor=1,factor1,first,first1,step,step1,step2,x,*pd=NULL;
int num,num1,n1,n2;
div_t sdiv;
num1=num=gridbascalc(min,max,&first,&step);
step1=step;
/* Izracunajo se najvecji desetiski razdelki, ki jih je ze vec ali enako nummin */
while (num1<nummin)
{
  step1=step1*0.1;
  first1=step1*ceil(min/step1);
  num1= 1+(int) floor((max-first1)/(step1));
  if (num1>nummin)
    step=step1;
}
/* Nato se doloci najvecji dopustni korak se med nedesetiskimi razdelki: */
factor=1;
if (num1>nummin)
{
  factor1=2;
  step1=step*factor1;
  first1=step1*ceil(min/step1);
  num1= 1+(int) floor((max-first1)/(step1));
  if (num1>=nummin)
  {
    factor=2;
    factor1=2.5;
    step1=step*factor1;
    first1=step1*ceil(min/step1);
    num1= 1+(int) floor((max-first1)/(step1));
    if (num1>=nummin)
    {
      factor=2.5;
      factor1=5;
      step1=step*factor1;
      first1=step1*ceil(min/step1);
      num1= 1+(int) floor((max-first1)/(step1));
      if (num1>=nummin)
      {
        factor=5;
      }

    }
  }
}
step*=factor;
/* Glede na vrednost nedesetiskega faktorja se dolocijo dolzine bolj grobih
razdelkov: */
if (factor==1)
{
  n1=5; n2=10; /* stevilo najbolj finih razdelkov v enem grobem */
} else if (factor==2)
{
  n1=5; n2=25;
} else if (factor==2.5)
{
  n1=2; n2=4;
} else if (factor==5)
{
  n1=2; n2=10;
}
step1=step* (double) n1; step2=step* (double) n2;
/* Zacnemo pri zadnjem najbolj grobem razdelku pred min in se pomikamo po en
najbolj fini razdelek naprej: */
x=step2*floor((min/step2));
num=0;
while (x<=max)
{
  if (x>=min)
  {
    /* Zaradi zaokrozitvene napake je treba rocno postaviti male vrednosti x na
    0: */
    if (fabs(x/step)<1.0e-5)
      x=0;
    pd=malloc(sizeof(*pd));
    *pd=x;
    sdiv=div(num,n2);
    if (sdiv.rem==0)
      pushstack(st2,pd); /* x lahko predstavlja najbolj grobi razdelek */
    else
    {
      sdiv=div(num,n1);
      if (sdiv.rem==0)
        pushstack(st1,pd); /* x lahko predstavlja srednje fini razdelek */
      else pushstack (st,pd); /* x lahko predstavlja le najbolj fini razdelek */
    }
  }
  ++num; x+=step;
}
}





gogroup go3dgridbas(frame3d frame,
          golinesettings xls0,golinesettings xls1,golinesettings xls2,
            int xnum,double xposy,double xposz,double xrely0,double xrely1,
            double xrely2,double xrelz0,double xrelz1,double xrelz2,
          golinesettings yls0,golinesettings yls1,golinesettings yls2,
            int ynum,double yposx,double yposz,double yrelx0,double yrelx1,
            double yrelx2,double yrelz0,double yrelz1,double yrelz2,
          golinesettings zls0,golinesettings zls1,golinesettings zls2,
            int znum,double zposx,double zposy,double zrelx0,double zrelx1,
            double zrelx2,double zrely0,double zrely1,double zrely2,
          char putx,char puty,char putz)
    /* Postavi ravnila na robove tridimenzionalnega grafa. Ta funkcija je
    nadomestilo za gomakerulers3d0(), od katere nudi precej vec moznosti, je
    pa zato klic funkcije malo bolj kompliciran. Glede hitrosti je funkcija
    zanemarljivo pocasnejsa od gomakerulers3d0(). Misljeno je, da bi se v
    prihodnje ta funkcija uporabljala kot osnova za vse vrste ravnil v dvo ali
    trodimenzionalnih grafih, vse bolj specificne funkcije naj bi bile torej
    izpeljane iz te.
      frame3d je okvir grafa, nato pa sledijo tri serije argumentov za osi x,
    y in z. Zadnji trije argumenti putx, puty in putz povedo, ali naj se naredi
    ravnilo za os x, y oziroma z (0 pomeni ne, ostale vrednosti pa da).
      Pomen argumentov za os x (za ostale osi so argumenti ekvivalentni):
    xls0, xls1 in xls2 dolocajo lastnosti crt za fine, srednje in grobe
    razdelke za ravnilo v smeri osi x. xnum je najmanjse stevilo vseh razdelkov
    skupaj za os x. xposy in xposz dolocata pozicijo ravnila v smeri osi x
    glede na koordinati y in z Pozicija je podana relativno glede na okvir
    frame. Tako je koordinata y ravnila dolocena kot miny+xposy*(maxy-miny),
    ce sta miny in maxy meji okvirja frame v smeri osi y. xrely0, xrely1 in
    xrely2 dolocajo dolzino crtic za fine, srednje in grobe razdelke v smeri
    osi y, spet relativno glede na okvir grafa (xrelz0, xrelz1 in xrelz2 imajo
    podoben pomen, le da gre za dolzino v smeri osi z). Tako pozicija ravnila,
    ki je podana z xposy in xposz, doloca 1. tocko vsake crtice, odmik, ki je
    podan z xrely... in xrelz..., pa doloza 2. tocko vsake zrtice. y koordinati
    crtice za fini razdelek sta na primer miny+xposy*(maxy-miny) in
    miny+xposy*(maxy-miny) + xrely0*(maxy-miny).
      Funkcija vrne skupino graficnih objektov, na kateri so podskupine za osi
    x, y in z (glede na vrednosti putx, puty in putz se lahko zgodi, da  katera
    od teh podskupin ne obstaja), na vsaki od teh pa so podskupine, ki
    vsebujejo crtice za fine, srednje fine in grobe razdelke.
      OPOMBE:
     Po navadi so lastnosti crt, ki prikazujejo razdelke, enake za vse osi za
    doloceno finost. V tem primeru je ob klicu funkcije xls0=ylsy=zls0,
    xls1=yls1=zls1 in xls2=yls2=zls2.
     Po navadi so crtice, ki predstavljajo razdelke, vzporedne s katero od
    koordinatnih osi. V tem primeru je za ravnilo v smeri vsake osi en set
    argumentov ...rel... enak 0. Ce na primer hocemo, da bodo crtice na ravnilu
    za os x vzporedne osi z, bodo xrely0, xrely1 in xrely2 enaki 0.
     Po navadi lezijo crtice ravnila na eni izmed ravnin okvira frame. V tem
    primeru je eden izmed obeh argumentov ...pos... za ravnilo na doloceni osi
    enak ali 0 ali 1. Ce na primer ravnilo za os x lezi na ravnini
    y=frame->max.y, je xposy=1. Poleg tega po navadi ravnila lezijo na robovih
    teh ravnin, zaradi cesar sta oba izmed doticnih argumentov ...pos... za
    dano ravnilo enaka ali 0 ali 1. Ce na primer hocemo, da ravnilo za os x
    lezi na spodnjem robu ravnine y=frame->max.y, je xposy=1 in xposz=0.
    $A Igor feb97; */
{
int i;
_coord3d p1,p2;
stack st0=NULL,st1=NULL,st2=NULL;
gogroup ret=NULL,retx=NULL,rety=NULL,retz=NULL,ret0=NULL,ret1=NULL,ret2=NULL;
ret=newgogroupst(3,0,0);
ret->name=stringcopy("grid3d");
st0=newstack(10); st1=newstack(8); st2=newstack(5);
if (putx)
{
  /* Podskupina za os x: */
  dispstackval(st0); dispstackval(st1); dispstackval(st2);
  popstackall(st0); popstackall(st1); popstackall(st2);
  retx=newgogroupst(3,0,0);
  retx->name=stringcopy("X");
  pushstack(ret->groups,retx);
  p1.y=frame->min.y+(frame->max.y-frame->min.y)*xposy;
  p1.z=frame->min.z+(frame->max.z-frame->min.z)*xposz;

  gridcalc(frame->min.x,frame->max.x,xnum,st0,st1,st2);
  if (st2!=NULL)
    if (st2->n>0)
    {
      /* Podskupina za grobo delitev: */
      ret2=newgogroupst(0,10,0);
      ret2->name=stringcopy("rough");
      if (xls2!=NULL)
      {
        ret2->ls1=malloc(sizeof(*(ret2->ls1)));
        *(ret2->ls1)=*xls2;
      }
      pushstack(retx->groups,ret2);
      /* Koordinate 2. krajisca crtic: */
      p2.y=p1.y+(frame->max.y-frame->min.y)*xrely2;
      p2.z=p1.z+(frame->max.z-frame->min.z)*xrelz2;
      for (i=1;i<=st2->n;++i)
      {
        p1.x=p2.x=*((double *) st2->s[i]);
        goaddline(&p1,&p2,ret2->primitives,ret2);
      }
    }
  if (st1!=NULL)
    if (st1->n>0)
    {
      /* Podskupina za grobo delitev: */
      ret1=newgogroupst(0,10,0);
      ret1->name=stringcopy("medium");
      if (xls1!=NULL)
      {
        ret1->ls1=malloc(sizeof(*(ret1->ls1)));
        *(ret1->ls1)=*xls1;
      }
      pushstack(retx->groups,ret1);
      /* Koordinate 2. krajisca crtic: */
      p2.y=p1.y+(frame->max.y-frame->min.y)*xrely1;
      p2.z=p1.z+(frame->max.z-frame->min.z)*xrelz1;
      for (i=1;i<=st1->n;++i)
      {
        p1.x=p2.x=*((double *) st1->s[i]);
        goaddline(&p1,&p2,ret1->primitives,ret1);
      }
    }
  if (st0!=NULL)
    if (st0->n>0)
    {
      /* Podskupina za grobo delitev: */
      ret0=newgogroupst(0,10,0);
      ret0->name=stringcopy("fine");
      if (xls2!=NULL)
      {
        ret0->ls1=malloc(sizeof(*(ret0->ls1)));
        *(ret0->ls1)=*xls0;
      }
      pushstack(retx->groups,ret0);
      /* Koordinate 2. krajisca crtic: */
      p2.y=p1.y+(frame->max.y-frame->min.y)*xrely0;
      p2.z=p1.z+(frame->max.z-frame->min.z)*xrelz0;
      for (i=1;i<=st0->n;++i)
      {
        p1.x=p2.x=*((double *) st0->s[i]);
        goaddline(&p1,&p2,ret0->primitives,ret0);
      }
    }
}
if (puty)
{
  /* Podskupina za os y: */
  dispstackval(st0); dispstackval(st1); dispstackval(st2);
  popstackall(st0); popstackall(st1); popstackall(st2);
  rety=newgogroupst(3,0,0);
  rety->name=stringcopy("Y");
  pushstack(ret->groups,rety);
  p1.x=frame->min.x+(frame->max.x-frame->min.x)*yposx;
  p1.z=frame->min.z+(frame->max.z-frame->min.z)*yposz;

  gridcalc(frame->min.y,frame->max.y,ynum,st0,st1,st2);
  if (st2!=NULL)
    if (st2->n>0)
    {
      /* Podskupina za grobo delitev: */
      ret2=newgogroupst(0,10,0);
      ret2->name=stringcopy("rough");
      if (yls2!=NULL)
      {
        ret2->ls1=malloc(sizeof(*(ret2->ls1)));
        *(ret2->ls1)=*yls2;
      }
      pushstack(rety->groups,ret2);
      /* Koordinate 2. krajisca crtic: */
      p2.x=p1.x+(frame->max.x-frame->min.x)*yrelx2;
      p2.z=p1.z+(frame->max.z-frame->min.z)*yrelz2;
      for (i=1;i<=st2->n;++i)
      {
        p1.y=p2.y=*((double *) st2->s[i]);
        goaddline(&p1,&p2,ret2->primitives,ret2);
      }
    }
  if (st1!=NULL)
    if (st1->n>0)
    {
      /* Podskupina za grobo delitev: */
      ret1=newgogroupst(0,10,0);
      ret1->name=stringcopy("medium");
      if (yls1!=NULL)
      {
        ret1->ls1=malloc(sizeof(*(ret1->ls1)));
        *(ret1->ls1)=*yls1;
      }
      pushstack(rety->groups,ret1);
      /* Koordinate 2. krajisca crtic: */
      p2.x=p1.x+(frame->max.x-frame->min.x)*yrelx1;
      p2.z=p1.z+(frame->max.z-frame->min.z)*yrelz1;
      for (i=1;i<=st1->n;++i)
      {
        p1.y=p2.y=*((double *) st1->s[i]);
        goaddline(&p1,&p2,ret1->primitives,ret1);
      }
    }
  if (st0!=NULL)
    if (st0->n>0)
    {
      /* Podskupina za grobo delitev: */
      ret0=newgogroupst(0,10,0);
      ret0->name=stringcopy("fine");
      if (yls2!=NULL)
      {
        ret0->ls1=malloc(sizeof(*(ret0->ls1)));
        *(ret0->ls1)=*yls0;
      }
      pushstack(rety->groups,ret0);
      /* Koordinate 2. krajisca crtic: */
      p2.x=p1.x+(frame->max.x-frame->min.x)*yrelx0;
      p2.z=p1.z+(frame->max.z-frame->min.z)*yrelz0;
      for (i=1;i<=st0->n;++i)
      {
        p1.y=p2.y=*((double *) st0->s[i]);
        goaddline(&p1,&p2,ret0->primitives,ret0);
      }
    }
}
if (putz)
{
  /* Podskupina za os z: */
  dispstackval(st0); dispstackval(st1); dispstackval(st2);
  popstackall(st0); popstackall(st1); popstackall(st2);
  retz=newgogroupst(3,0,0);
  retz->name=stringcopy("Z");
  pushstack(ret->groups,retz);
  p1.x=frame->min.x+(frame->max.x-frame->min.x)*zposx;
  p1.y=frame->min.y+(frame->max.y-frame->min.y)*zposy;

  gridcalc(frame->min.z,frame->max.z,znum,st0,st1,st2);
  if (st2!=NULL)
    if (st2->n>0)
    {
      /* Podskupina za grobo delitev: */
      ret2=newgogroupst(0,10,0);
      ret2->name=stringcopy("rough");
      if (zls2!=NULL)
      {
        ret2->ls1=malloc(sizeof(*(ret2->ls1)));
        *(ret2->ls1)=*zls2;
      }
      pushstack(retz->groups,ret2);
      /* Koordinate 2. krajisca crtic: */
      p2.x=p1.x+(frame->max.x-frame->min.x)*zrelx2;
      p2.y=p1.y+(frame->max.y-frame->min.y)*zrely2;
      for (i=1;i<=st2->n;++i)
      {
        p1.z=p2.z=*((double *) st2->s[i]);
        goaddline(&p1,&p2,ret2->primitives,ret2);
      }
    }
  if (st1!=NULL)
    if (st1->n>0)
    {
      /* Podskupina za grobo delitev: */
      ret1=newgogroupst(0,10,0);
      ret1->name=stringcopy("medium");
      if (zls1!=NULL)
      {
        ret1->ls1=malloc(sizeof(*(ret1->ls1)));
        *(ret1->ls1)=*zls1;
      }
      pushstack(retz->groups,ret1);
      /* Koordinate 2. krajisca crtic: */
      p2.x=p1.x+(frame->max.x-frame->min.x)*zrelx1;
      p2.y=p1.y+(frame->max.y-frame->min.y)*zrely1;
      for (i=1;i<=st1->n;++i)
      {
        p1.z=p2.z=*((double *) st1->s[i]);
        goaddline(&p1,&p2,ret1->primitives,ret1);
      }
    }
  if (st0!=NULL)
    if (st0->n>0)
    {
      /* Podskupina za grobo delitev: */
      ret0=newgogroupst(0,10,0);
      ret0->name=stringcopy("fine");
      if (zls2!=NULL)
      {
        ret0->ls1=malloc(sizeof(*(ret0->ls1)));
        *(ret0->ls1)=*zls0;
      }
      pushstack(retz->groups,ret0);
      /* Koordinate 2. krajisca crtic: */
      p2.x=p1.x+(frame->max.x-frame->min.x)*zrelx0;
      p2.y=p1.y+(frame->max.y-frame->min.y)*zrely0;
      for (i=1;i<=st0->n;++i)
      {
        p1.z=p2.z=*((double *) st0->s[i]);
        goaddline(&p1,&p2,ret0->primitives,ret0);
      }
    }
}
return ret;
}




gogroup gomakerulers3d0(frame3d frame,golinesettings ls,golinesettings ls1,
            golinesettings ls2,
            int numx,double relx,double relx1,double relx2,double xy,double xz,
            int numy,double rely,double rely1,double rely2,double yx,double yz,
            int numz,double relz,double relz1,double relz2,double zx,double zy)
    /*
    POZOR!  Funkcija je zastarela, kor osnova za postavljanje ravnil na grafe
    naj se v prihodnje uporablja funkcija go3dgridbas()!
     Postavi ravnila na robove tridimenzionalnega grafa. frame so meje grafa,
    ls,ls1 in ls2 dolocajo lastnosti crt finih, srednjefinih in grobih razdelkov,
    num... dolocajo najmanjse stevilo razdelkov (vseh skupaj), rel... dolocajo
    relativno dolzino razdelkov (v primerjavi s celotnimi intervali iz
    spremenljivke frame - posebej za fino, srednje fino in grobo delitev),
    ostale spremenljivke pa dolocajo lege ravnil (npr. xy=1, xz=0 pomeni, da
    lezi ravnilo za os x na zgornji meji grafa v smeri osi y in na spodnji meji
    grafa v smeri osi z).
    $A Igor <== feb97; */
{
int i;
double k;
_coord3d p1,p2;
stack st=NULL,st1=NULL,st2=NULL;
gogroup ret=NULL,retx=NULL,rety=NULL,retz=NULL,ret0=NULL,ret1=NULL,ret2=NULL;
ret=newgogroupst(3,0,0);
ret->name=stringcopy("rulers3d");
st=newstack(10); st1=newstack(8); st2=newstack(5);
/* Os x: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
retx=newgogroupst(3,0,0);
retx->name=stringcopy("X");
pushstack(ret->groups,retx);
/* Skupine za fino,srednjo in grobo delitev: */
ret0=newgogroupst(0,10,0);
ret0->name=stringcopy("fine");
ret0->ls1=malloc(sizeof(*(ret0->ls1)));
*(ret0->ls1)=*ls;
ret1=newgogroupst(0,10,0);
ret1->name=stringcopy("medium");
ret1->ls1=malloc(sizeof(*(ret1->ls1)));
*(ret1->ls1)=*ls1;
ret2=newgogroupst(0,10,0);
ret2->name=stringcopy("rough");
ret2->ls1=malloc(sizeof(*(ret2->ls1)));
*(ret2->ls1)=*ls2;
pushstack(retx->groups,ret0);
pushstack(retx->groups,ret1);
pushstack(retx->groups,ret2);
gridcalc(frame->min.x,frame->max.x,numx,st,st1,st2);
if (xz==0)
{
  p1.z=p2.z=frame->min.z;
} else
{
  p1.z=p2.z=frame->max.z;
}
if (xy==0)
{
  p1.y=frame->min.y;
  k=1;
}
else
{
  p1.y=frame->max.y;
  k=-1;
}
if (st2!=NULL)
  if (st2->n>0)
  {
    p2.y=p1.y+k*relx2*(frame->max.y-frame->min.y);
    for (i=1;i<=st2->n;++i)
    {
      p1.x=p2.x=*((double *) st2->s[i]);
      goaddline(&p1,&p2,ret2->primitives,ret2);
    }
  }
if (st1!=NULL)
  if (st1->n>0)
  {
    p2.y=p1.y+k*relx1*(frame->max.y-frame->min.y);
    for (i=1;i<=st1->n;++i)
    {
      p1.x=p2.x=*((double *) st1->s[i]);
      goaddline(&p1,&p2,ret1->primitives,ret1);
    }
  }
if (st!=NULL)
  if (st->n>0)
  {
    p2.y=p1.y+k*relx*(frame->max.y-frame->min.y);
    for (i=1;i<=st->n;++i)
    {
      p1.x=p2.x=*((double *) st->s[i]);
      goaddline(&p1,&p2,ret0->primitives,ret0);
    }
  }
/* Os y: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
rety=newgogroupst(3,0,0);
rety->name=stringcopy("Y");
pushstack(ret->groups,rety);
/* Skupine za fino,srednjo in grobo delitev: */
ret0=newgogroupst(0,10,0);
ret0->name=stringcopy("fine");
ret0->ls1=malloc(sizeof(*(ret0->ls1)));
*(ret0->ls1)=*ls;
ret1=newgogroupst(0,10,0);
ret1->name=stringcopy("medium");
ret1->ls1=malloc(sizeof(*(ret1->ls1)));
*(ret1->ls1)=*ls1;
ret2=newgogroupst(0,10,0);
ret2->name=stringcopy("rough");
ret2->ls1=malloc(sizeof(*(ret2->ls1)));
*(ret2->ls1)=*ls2;
pushstack(rety->groups,ret0);
pushstack(rety->groups,ret1);
pushstack(rety->groups,ret2);
gridcalc(frame->min.y,frame->max.y,numy,st,st1,st2);
if (yz==0)
{
  p1.z=p2.z=frame->min.z;
} else
{
  p1.z=p2.z=frame->max.z;
}
if (yx==0)
{
  p1.x=frame->min.x;
  k=1;
}
else
{
  p1.x=frame->max.x;
  k=-1;
}
if (st2!=NULL)
  if (st2->n>0)
  {
    p2.x=p1.x+k*rely2*(frame->max.x-frame->min.x);
    for (i=1;i<=st2->n;++i)
    {
      p1.y=p2.y=*((double *) st2->s[i]);
      goaddline(&p1,&p2,ret2->primitives,ret2);
    }
  }
if (st1!=NULL)
  if (st1->n>0)
  {
    p2.x=p1.x+k*rely1*(frame->max.x-frame->min.x);
    for (i=1;i<=st1->n;++i)
    {
      p1.y=p2.y=*((double *) st1->s[i]);
      goaddline(&p1,&p2,ret1->primitives,ret1);
    }
  }
if (st!=NULL)
  if (st->n>0)
  {
    p2.x=p1.x+k*rely*(frame->max.x-frame->min.x);
    for (i=1;i<=st->n;++i)
    {
      p1.y=p2.y=*((double *) st->s[i]);
      goaddline(&p1,&p2,ret0->primitives,ret0);
    }
  }
/* Os z: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
retz=newgogroupst(3,0,0);
retz->name=stringcopy("Z");
pushstack(ret->groups,retz);
/* Skupine za fino,srednjo in grobo delitev: */
ret0=newgogroupst(0,10,0);
ret0->name=stringcopy("fine");
ret0->ls1=malloc(sizeof(*(ret0->ls1)));
*(ret0->ls1)=*ls;
ret1=newgogroupst(0,10,0);
ret1->name=stringcopy("medium");
ret1->ls1=malloc(sizeof(*(ret1->ls1)));
*(ret1->ls1)=*ls1;
ret2=newgogroupst(0,10,0);
ret2->name=stringcopy("rough");
ret2->ls1=malloc(sizeof(*(ret2->ls1)));
*(ret2->ls1)=*ls2;
pushstack(retz->groups,ret0);
pushstack(retz->groups,ret1);
pushstack(retz->groups,ret2);
gridcalc(frame->min.z,frame->max.z,numz,st,st1,st2);
if (zy==0)
{
  p1.y=p2.y=frame->min.y;
} else
{
  p1.y=p2.y=frame->max.y;
}
if (zx==0)
{
  p1.x=frame->min.x;
  k=1;
}
else
{
  p1.x=frame->max.x;
  k=-1;
}
if (st2!=NULL)
  if (st2->n>0)
  {
    p2.x=p1.x+k*relz2*(frame->max.x-frame->min.x);
    for (i=1;i<=st2->n;++i)
    {
      p1.z=p2.z=*((double *) st2->s[i]);
      goaddline(&p1,&p2,ret2->primitives,ret2);
    }
  }
if (st1!=NULL)
  if (st1->n>0)
  {
    p2.x=p1.x+k*relz1*(frame->max.x-frame->min.x);
    for (i=1;i<=st1->n;++i)
    {
      p1.z=p2.z=*((double *) st1->s[i]);
      goaddline(&p1,&p2,ret1->primitives,ret1);
    }
  }
if (st!=NULL)
  if (st->n>0)
  {
    p2.x=p1.x+k*relz*(frame->max.x-frame->min.x);
    for (i=1;i<=st->n;++i)
    {
      p1.z=p2.z=*((double *) st->s[i]);
      goaddline(&p1,&p2,ret0->primitives,ret0);
    }
  }
if (st!=NULL)
{
  dispstackval(st); dispstack(&st);
}
if (st1!=NULL)
{
  dispstackval(st1); dispstack(&st1);
}
if (st2!=NULL)
{
  dispstackval(st2); dispstack(&st2);
}
return ret;
}


static gogroup gomakerulers3dold(frame3d frame,golinesettings ls,golinesettings ls1,
            golinesettings ls2,int num,double rel,double rel1,double rel2)
    /* Podobno kot gomakerulers3d0(), le da so nekatere lastnosti skupne za vse
    osi (najmanjse stevilo razdelkov num in relativne dolzine rel...), lege so
    vnaprej dolocene (niso parametri).
    POZOR: To je stara verzija gomakerulers3d in ni vec v uporabi. Cez cas se
    lahko brise. */
{
return gomakerulers3d0(frame,ls,ls1,ls2,
               num,rel,rel1,rel2,1,0,
               num,rel,rel1,rel2,1,0,
               num,rel,rel1,rel2,1,0);
}


gogroup gomakerulers3d(frame3d frame,golinesettings ls,golinesettings ls1,
            golinesettings ls2,int num,double rel,double rel1,double rel2)
    /* Postavi ravnila na robove tridimenzionalnega grafa. S frame je dolocen
    okvir grafa, v ls, ls1 in ls2 pa so nastavitve za risanje crt pri fini,
    srednji in grobi razdelitvi. num je najmanjse stevilo vseh razdelkov za
    katerokoli os,rel, rel1 in rel2 pa so ustrezne relativne dolzine razdelkov
    glede na dimenzije okvirja.
    $A Igor <== feb97; */
{
return go3dgridbas(frame,
           ls,ls1,ls2,num, 1,0, -rel,-rel1,-rel2, 0,0,0,
           ls,ls1,ls2,num, 1,0, -rel,-rel1,-rel2, 0,0,0,
           ls,ls1,ls2,num, 1,0, -rel,-rel1,-rel2, 0,0,0,
           1,1,1);
}







gogroup go3dgridtextbas(frame3d frame,
  gotextsettings xts,int xdig,int xnum,int xnumtext,double xposy,double xposz,
  gotextsettings yts,int ydig,int ynum,int ynumtext,double yposx,double yposz,
  gotextsettings zts,int zdig,int znum,int znumtext,double zposx,double zposy,
  char putx,char puty,char putz)
    /* Postavi stevilcne oznake (v obliki teksta) k ravnilom grafa v treh
    dimenzijah. Funkcija je predvidena za uporabo skupaj s funkcijo
    go3dgridbas() kot osnova za stevilcne oznake ravnil osi pri dvo- ali
    trodimenzionalnih grafih (vse bolj specificne funkcije za taksne naloge naj
    bi bile izpeljane iz te).
      frame3d je okvir grafa, nato sledijo tri serije argumentov za osi x, y in
    z. Zadnji trije argumenti putx, puty in putz povedo, ali naj se naredijo
    oznakete za os x, y oziroma z (0 pomeni ne, ostale vrednosti pa da).
      Pomen argumentov za os x (za ostale osi so argumenti ekvivalentni):
    xts doloca lastnosti teksta za os x. xnum je najmanjse stevilo vseh
    razdelkov na osi x, kot je bilo doloceno pri klicu funkcije go3dgridbas(),
    xnumtext pa je najmanjse stevilo oznak za os x in mora biti manjse ali
    enako xnum. Ce je manjse, dopustimo, da se stevilcne oznake ne izpisejo na
    pri vseh (tudi najbolj finih) razdelkih, ampak lahko samo pri grobih, ce
    taksnih razdelkov pride pri klicu funkcije gridcalc() ze vec ali enako kot
    xnumtext.
      xposy in xposz dolocata polozaj oznak v smeri y in z, in sicer relativno
    glede na meje okvirja frame. Tako je na primer koordinata y oznak enaka
    ymin+(ymax-ymin)*xposy, kjer je ymin spodnja meja grafa  v smeri y
    (frame->min.y), ymax pa zgornja (frame->max.y).
    $A Igor feb97; */
{
int i;
char *str=NULL;
_coord3d p1;
stack st0=NULL,st1=NULL,st2=NULL;
gogroup ret=NULL,retx=NULL,rety=NULL,retz=NULL;
str=malloc(30);
ret=newgogroupst(3,0,0);
ret->name=stringcopy("gridtext3d");
st0=newstack(10); st1=newstack(8); st2=newstack(5);
if (putx)
{
  /* Podskupina za os x: */
  dispstackval(st0); dispstackval(st1); dispstackval(st2);
  popstackall(st0); popstackall(st1); popstackall(st2);
  retx=newgogroupst(0,8,0);
  retx->name=stringcopy("X");
  if (xts!=NULL)
  {
    retx->ts1=malloc(sizeof(*(retx->ts1)));
    *(retx->ts1)=*xts;
  }
  pushstack(ret->groups,retx);
  p1.y=frame->min.y+(frame->max.y-frame->min.y)*xposy;
  p1.z=frame->min.z+(frame->max.z-frame->min.z)*xposz;
  gridcalc(frame->min.x,frame->max.x,xnum,st0,st1,st2);
  /* Na sklad st2 se prepisejo tudi razdelbe s st1 in po moznosti se s st0, ce
  je razdelb na st2 manj kot ynumtext: */
  if (st2->n<xnumtext)
    while(st1->n>0)
        pushstack(st2,popstack(st1));
  if (st2->n<xnumtext)
    while(st0->n>0)
        pushstack(st2,popstack(st0));
  if (st2!=NULL)
    if (st2->n!=0)
    {
      for (i=1;i<=st2->n;++i)
      {
        p1.x=*((double *) st2->s[i]);
        sprintf(str,"%.*g",xdig,p1.x);
        goaddtext(str,&p1,retx->primitives,retx);
      }
    }
}
if (puty)
{
  /* Podskupina za os y: */
  dispstackval(st0); dispstackval(st1); dispstackval(st2);
  popstackall(st0); popstackall(st1); popstackall(st2);
  rety=newgogroupst(0,8,0);
  rety->name=stringcopy("Y");
  if (yts!=NULL)
  {
    rety->ts1=malloc(sizeof(*(rety->ts1)));
    *(rety->ts1)=*yts;
  }
  pushstack(ret->groups,rety);
  p1.x=frame->min.x+(frame->max.x-frame->min.x)*yposx;
  p1.z=frame->min.z+(frame->max.z-frame->min.z)*yposz;
  gridcalc(frame->min.y,frame->max.y,ynum,st0,st1,st2);
  /* Na sklad st2 se prepisejo tudi razdelbe s st1 in po moznosti se s st0, ce
  je razdelb na st2 manj kot ynumtext: */
  if (st2->n<ynumtext)
    while(st1->n>0)
        pushstack(st2,popstack(st1));
  if (st2->n<ynumtext)
    while(st0->n>0)
        pushstack(st2,popstack(st0));
  if (st2!=NULL)
    if (st2->n!=0)
    {
      for (i=1;i<=st2->n;++i)
      {
        p1.y=*((double *) st2->s[i]);
        sprintf(str,"%.*g",ydig,p1.y);
        goaddtext(str,&p1,rety->primitives,rety);
      }
    }
}
if (putz)
{
  /* Podskupina za os z: */
  dispstackval(st0); dispstackval(st1); dispstackval(st2);
  popstackall(st0); popstackall(st1); popstackall(st2);
  retz=newgogroupst(0,8,0);
  retz->name=stringcopy("Z");
  if (zts!=NULL)
  {
    retz->ts1=malloc(sizeof(*(retz->ts1)));
    *(retz->ts1)=*zts;
  }
  pushstack(ret->groups,retz);
  p1.x=frame->min.x+(frame->max.x-frame->min.x)*zposx;
  p1.y=frame->min.y+(frame->max.y-frame->min.y)*zposy;
  gridcalc(frame->min.z,frame->max.z,znum,st0,st1,st2);
  /* Na sklad st2 se prepisejo tudi razdelbe s st1 in po moznosti se s st0, ce
  je razdelb na st2 manj kot znumtext: */
  if (st2->n<znumtext)
    while(st1->n>0)
        pushstack(st2,popstack(st1));
  if (st2->n<znumtext)
    while(st0->n>0)
        pushstack(st2,popstack(st0));
  if (st2!=NULL)
    if (st2->n!=0)
    {
      for (i=1;i<=st2->n;++i)
      {
        p1.z=*((double *) st2->s[i]);
        sprintf(str,"%.*g",zdig,p1.z);
        goaddtext(str,&p1,retz->primitives,retz);
      }
    }
}
if (str!=NULL)
  free(str);
if (st0!=NULL)
{
  dispstackval(st0); dispstack(&st0);
}
if (st1!=NULL)
{
  dispstackval(st1); dispstack(&st1);
}
if (st2!=NULL)
{
  dispstackval(st2); dispstack(&st2);
}
return ret;
}




gogroup gomakerulertext3d0(frame3d frame,gotextsettings tsx,gotextsettings tsy,
            gotextsettings tsz,
            int xdig,int numx,double numxtext,double relx,double xy,double xz,
            int ydig,int numy,double numytext,double rely,double yx,double yz,
            int zdig,int numz,double numztext,double relz,double zx,double zy)
    /* POZOR! To je zastarela funkcija, ki naj se ne bi vec uporabljala.
    namesto nje naj se uporablja funkcija go3dgridtextbas().
      Napise tekst ob ravnilih na robovih tridimenzionalnega grafa. Ta funkcija
    je narejena za uporabo v kombinaciji s funkcijo gomakerulers3d0(), tudi
    pomen nekaterih argumentov je ekvivalenten. xdig, ydig in zdig so stevila
    decimalnih mest pri izpisu stevilk ob ustreznih ravnilih. num...text so
    najmanjsa stevila stevil, izpisanih ob ustreznih ravnilih. */
{
int i;
double k;
char *str=NULL;
_coord3d p1,p2;
stack st=NULL,st1=NULL,st2=NULL;
gogroup ret=NULL,retx=NULL,rety=NULL,retz=NULL;
str=malloc(30);
ret=newgogroupst(3,0,0);
ret->name=stringcopy("rulertext3d");
retx=newgogroupst(0,10,0);
retx->name=stringcopy("x");
retx->ts1=malloc(sizeof(*(retx->ts1)));
*(retx->ts1)=*tsx;
rety=newgogroupst(0,10,0);
rety->name=stringcopy("y");
rety->ts1=malloc(sizeof(*(rety->ts1)));
*(rety->ts1)=*tsy;
retz=newgogroupst(0,10,0);
retz->name=stringcopy("z");
retz->ts1=malloc(sizeof(*(retz->ts1)));
*(retz->ts1)=*tsz;
pushstack(ret->groups,retx);
pushstack(ret->groups,rety);
pushstack(ret->groups,retz);
st=newstack(10); st1=newstack(8); st2=newstack(5);

/* Os x: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
gridcalc(frame->min.x,frame->max.x,numx,st,st1,st2);
/* Na sklad st2 se prepisejo tudi razdelbe s st1 in po moznosti se s st, ce je
razdelb na st2 manj kot numxtext: */
if (st2->n<numxtext)
  while(st1->n>0)
      pushstack(st2,popstack(st1));
if (st2->n<numxtext)
  while(st->n>0)
      pushstack(st2,popstack(st));
if (xz==0)
{
  p1.z=p2.z=frame->min.z;
} else
{
  p1.z=p2.z=frame->max.z;
}
if (xy==0)
{
  p1.y=frame->min.y;
  k=-1;
}
else
{
  p1.y=frame->max.y;
  k=1;
}
if (st2!=NULL)
  if (st2->n>0)
  {
    p2.y=p1.y+k*relx*(frame->max.y-frame->min.y);
    for (i=1;i<=st2->n;++i)
    {
      p1.x=p2.x=*((double *) st2->s[i]);
      sprintf(str,"%.*g",xdig,p2.x);
      goaddtext(str,&p2,retx->primitives,retx);
    }
  }

/* Os y: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
gridcalc(frame->min.y,frame->max.y,numy,st,st1,st2);
/* Na sklad st2 se prepisejo tudi razdelbe s st1 in po moznosti se s st, ce je
razdelb na st2 manj kot numytext: */
if (st2->n<numytext)
  while(st1->n>0)
      pushstack(st2,popstack(st1));
if (st2->n<numytext)
  while(st->n>0)
      pushstack(st2,popstack(st));
if (yz==0)
{
  p1.z=p2.z=frame->min.z;
} else
{
  p1.z=p2.z=frame->max.z;
}
if (yx==0)
{
  p1.x=frame->min.x;
  k=-1;
}
else
{
  p1.x=frame->max.x;
  k=1;
}
if (st2!=NULL)
  if (st2->n>0)
  {
    p2.x=p1.x+k*rely*(frame->max.x-frame->min.x);
    for (i=1;i<=st2->n;++i)
    {
      p1.y=p2.y=*((double *) st2->s[i]);
      sprintf(str,"%.*g",ydig,p2.y);
      goaddtext(str,&p2,rety->primitives,rety);
    }
  }

/* Os z: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
gridcalc(frame->min.z,frame->max.z,numz,st,st1,st2);
/* Na sklad st2 se prepisejo tudi razdelbe s st1 in po moznosti se s st, ce je
razdelb na st2 manj kot numztext: */
if (st2->n<numztext)
  while(st1->n>0)
      pushstack(st2,popstack(st1));
if (st2->n<numztext)
  while(st->n>0)
      pushstack(st2,popstack(st));
if (zx==0)
{
  p1.x=p2.x=frame->min.x;
} else
{
  p1.x=p2.x=frame->max.x;
}
if (zy==0)
{
  p1.y=frame->min.y;
  k=-1;
}
else
{
  p1.y=frame->max.y;
  k=1;
}
if (st2!=NULL)
  if (st2->n>0)
  {
    p2.y=p1.y+k*relz*(frame->max.y-frame->min.y);
    for (i=1;i<=st2->n;++i)
    {
      p1.z=p2.z=*((double *) st2->s[i]);
      sprintf(str,"%.*g",zdig,p2.z);
      goaddtext(str,&p2,retz->primitives,retz);
    }
  }

if (str!=NULL)
  free(str);
if (st!=NULL)
{
  dispstackval(st); dispstack(&st);
}
if (st1!=NULL)
{
  dispstackval(st1); dispstack(&st1);
}
if (st2!=NULL)
{
  dispstackval(st2); dispstack(&st2);
}
return ret;
}



static gogroup gomakerulertext3dold(frame3d frame,gotextsettings ts,
            int digits,int num,int numtext,double rel)
    /* Podobno kot gomakerulers3d0(), le da so nekatere lastnosti skupne za vse
    osi (stevilo decimalk digits, najmanjse stevilo stevilk numtext in relativne
    dolzine rel...), lege so vnaprej dolocene (niso argumenti funkcije).
    POZOR: To je stara verzija gomakerulertext3d in ni vec v uporabi. Cez cas se
    lahko brise. */
{
return gomakerulertext3d0(frame,ts,ts,ts,
         digits,num,numtext,rel,1,0,
         digits,num,numtext,rel,1,0,
         digits,num,numtext,rel,1,0);
}



gogroup gomakerulertext3d(frame3d frame,gotextsettings ts,
            int digits,int num,int numtext,double pos)
    /* Postavi stevilcne oznake v obliki teksta za ravnila trodimenzionalnega
    grafa. V frame so meje okvirja grafa, v ts pa nastavitve za tekst. digits
    je stevilo decimalk, ki se izpisejo v oznakah. num je najmanjse stevilo
    vseh razdelkov ravnil, numtext pa je najmanjse stevilo oznak. pos je
    relstivna pozicija oznak glede na dimenzije okvirja. Funkcija je misljena
    za uporabo skupaj s funkcijo gomakerulers3d(). V tem primeru mora biti
    argument num enak kot pri klicu te funkicje.
    $A Igor feb97 */
{
return go3dgridtextbas(frame,
             ts,digits,num,numtext,1+pos,0,
             ts,digits,num,numtext,1+pos,0,
             ts,digits,num,numtext,1+pos,0,
             1,1,1);
}






gogroup gomakegridbascorner3d0(frame3d frame,golinesettings ls,
            golinesettings ls1,golinesettings ls2,
            int numx,int numy,int numz,
            double xpos,double ypos,double zpos)
    /* Postavi mrezice na tri ravnine okvirja tridimenzionalnega grafa frame.
    ls, ls1 in ls2 dolocajo lastnosti finih, srednje finih in grobih razdelkov
    grafa, numx, numy in numz so najmanjsa stevila finih razdelkov v smereh x,
    y in z, numx, numy in numz pa dolocajo, na katerih ravninah se izrisejo
    mrezice (0 pomeni spodnjo mejo ustreznega intervala v frame, 1 pa
    zgornjo). */
{
int i;
_coord3d p1,p2,p3,p4;
stack st=NULL,st1=NULL,st2=NULL;
gogroup ret=NULL,ret0=NULL,ret1=NULL,ret2=NULL;
ret=newgogroupst(3,0,0);
ret->name=stringcopy("cornergrid3d");
/*
ret->groups=newstack(3);
*/
ret0=newgogroupst(0,10,0);
ret0->name=stringcopy("fine");
/*
ret0->primitives=newstack(10);
*/
ret0->ls1=malloc(sizeof(*(ret0->ls1)));
*(ret0->ls1)=*ls;
ret1=newgogroupst(0,10,0);
ret1->name=stringcopy("medium");
/*
ret1->primitives=newstack(10);
*/
ret1->ls1=malloc(sizeof(*(ret1->ls1)));
*(ret1->ls1)=*ls1;
ret2=newgogroupst(0,10,0);
ret2->name=stringcopy("rough");
/*
ret2->primitives=newstack(10);
*/
ret2->ls1=malloc(sizeof(*(ret2->ls1)));
*(ret2->ls1)=*ls2;
pushstack(ret->groups,ret0);
pushstack(ret->groups,ret1);
pushstack(ret->groups,ret2);
st=newstack(10); st1=newstack(8); st2=newstack(5);

/* Delitev po x: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
gridcalc(frame->min.x,frame->max.x,numx,st,st1,st2);
if (zpos==0)
  p1.z=p2.z=frame->min.z;
else
  p1.z=p2.z=frame->max.z;
p1.y=frame->min.y;
p2.y=frame->max.y;
if (ypos==0)
  p3.y=p4.y=frame->min.y;
else
  p3.y=p4.y=frame->max.y;
p3.z=frame->min.z;
p4.z=frame->max.z;
if (st2!=NULL)
  if (st2->n>0)
  {
    for (i=1;i<=st2->n;++i)
    {
      p1.x=p2.x=p3.x=p4.x=*((double *) st2->s[i]);
      goaddline(&p1,&p2,ret2->primitives,ret2);
      goaddline(&p3,&p4,ret2->primitives,ret2);
    }
  }
if (st1!=NULL)
  if (st1->n>0)
  {
    for (i=1;i<=st1->n;++i)
    {
      p1.x=p2.x=p3.x=p4.x=*((double *) st1->s[i]);
      goaddline(&p1,&p2,ret1->primitives,ret1);
      goaddline(&p3,&p4,ret1->primitives,ret1);
    }
  }
if (st!=NULL)
  if (st->n>0)
  {
    for (i=1;i<=st->n;++i)
    {
      p1.x=p2.x=p3.x=p4.x=*((double *) st->s[i]);
      goaddline(&p1,&p2,ret0->primitives,ret0);
      goaddline(&p3,&p4,ret0->primitives,ret0);
    }
  }

/* Delitev po y: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
gridcalc(frame->min.y,frame->max.y,numy,st,st1,st2);
if (xpos==0)
  p1.x=p2.x=frame->min.x;
else
  p1.x=p2.x=frame->max.x;
p1.z=frame->min.z;
p2.z=frame->max.z;
if (zpos==0)
  p3.z=p4.z=frame->min.z;
else
  p3.z=p4.z=frame->max.z;
p3.x=frame->min.x;
p4.x=frame->max.x;
if (st2!=NULL)
  if (st2->n>0)
  {
    for (i=1;i<=st2->n;++i)
    {
      p1.y=p2.y=p3.y=p4.y=*((double *) st2->s[i]);
      goaddline(&p1,&p2,ret2->primitives,ret2);
      goaddline(&p3,&p4,ret2->primitives,ret2);
    }
  }
if (st1!=NULL)
  if (st1->n>0)
  {
    for (i=1;i<=st1->n;++i)
    {
      p1.y=p2.y=p3.y=p4.y=*((double *) st1->s[i]);
      goaddline(&p1,&p2,ret1->primitives,ret1);
      goaddline(&p3,&p4,ret1->primitives,ret1);
    }
  }
if (st!=NULL)
  if (st->n>0)
  {
    for (i=1;i<=st->n;++i)
    {
      p1.y=p2.y=p3.y=p4.y=*((double *) st->s[i]);
      goaddline(&p1,&p2,ret0->primitives,ret0);
      goaddline(&p3,&p4,ret0->primitives,ret0);
    }
  }

/* Delitev po z: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
gridcalc(frame->min.z,frame->max.z,numz,st,st1,st2);
if (xpos==0)
  p1.x=p2.x=frame->min.x;
else
  p1.x=p2.x=frame->max.x;
p1.y=frame->min.y;
p2.y=frame->max.y;
if (ypos==0)
  p3.y=p4.y=frame->min.y;
else
  p3.y=p4.y=frame->max.y;
p3.x=frame->min.x;
p4.x=frame->max.x;
if (st2!=NULL)
  if (st2->n>0)
  {
    for (i=1;i<=st2->n;++i)
    {
      p1.z=p2.z=p3.z=p4.z=*((double *) st2->s[i]);
      goaddline(&p1,&p2,ret2->primitives,ret2);
      goaddline(&p3,&p4,ret2->primitives,ret2);
    }
  }
if (st1!=NULL)
  if (st1->n>0)
  {
    for (i=1;i<=st1->n;++i)
    {
      p1.z=p2.z=p3.z=p4.z=*((double *) st1->s[i]);
      goaddline(&p1,&p2,ret1->primitives,ret1);
      goaddline(&p3,&p4,ret1->primitives,ret1);
    }
  }
if (st!=NULL)
  if (st->n>0)
  {
    for (i=1;i<=st->n;++i)
    {
      p1.z=p2.z=p3.z=p4.z=*((double *) st->s[i]);
      goaddline(&p1,&p2,ret0->primitives,ret0);
      goaddline(&p3,&p4,ret0->primitives,ret0);
    }
  }

if (st!=NULL)
{
  dispstackval(st); dispstack(&st);
}
if (st1!=NULL)
{
  dispstackval(st1); dispstack(&st1);
}
if (st2!=NULL)
{
  dispstackval(st2); dispstack(&st2);
}
return ret;
}


gogroup gomakegridbascorner3d(frame3d frame,golinesettings ls,
            golinesettings ls1,golinesettings ls2,int num)
    /* Podobno kot gomakegridbascorner3d0(), le da so najmanjsa stevila
    razdelkov enaka za vse tri smeri (num) ter so ravnine vnaprej dolocene
    (in sicer ravnine osnovnega kota okvirja frame). */
{
return gomakegridbascorner3d0(frame,ls,ls1,ls2,num,num,num,0,0,0);
}





static char contourintersection(double z,coord3d p1,coord3d p2,coord3d intsec)
       /* Preveri, ce plastnica pri z sece daljico med p1 in p2. Ce je ne, vrne
       0, drugace pa vrne 1 in zapise koordinate secisca v *intsec. */
{
char ret=0;
double k;
if ( (z>=p1->z && z<p2->z) || (z<=p1->z && z>p2->z) )
  ret=1;
if (ret)
{
  if (p1->z==p2->z)
    k=0;
  else
    k=(z-p1->z)/(p2->z-p1->z);
  intsec->x=p1->x+k*(p2->x-p1->x);
  intsec->y=p1->y+k*(p2->y-p1->y);
  intsec->z=p1->z+k*(p2->z-p1->z);
}
return ret;
}

gogroup gocontourplotsimp0(double ff(double x,double y),stack stz,int numx,
            int numy,frame3d lim,stack stcol,golinesettings ls,int type,
            double z0)
{
int i,j,k;
double x0,y0,hx,hy,z;
char is1,is2,is3,is4,*str=NULL;
_coord3d p1,p2,p3,p4,s1,s2,s3,s4,*l1,*l2;
truecolor col;
stack stgroups=NULL;
gogroup gg=NULL,ret=NULL;
if (stz!=NULL)
  if (stz->n>0)
  {
    ret=newgogroupst(stz->n,0,0);
    ret->name=stringcopy("contourplot");
    /*
    ret->groups=newstack(stz->n);
    */
    stgroups=ret->groups;
    /* Tvorjenje skupin graf. primitivov za vsako konturo posebej: */
    str=makestring(5);
    for (i=1;i<=stz->n;++i)
    {
      gg=newgogroupst(0,10,0);
      /*
      gg->primitives=newstack(10);
      */
      sprintf(str,"%i",i);
      gg->name=stringcat("contour ",str);
      gg->ls1=malloc(sizeof(*(gg->ls1)));
      *(gg->ls1)=*ls;
      col=NULL;
      if (stcol!=NULL)
        if (stcol->n>=i)
          col=(truecolor) stcol->s[i];
      if (col!=NULL)
        gg->ls1->color=*col;
      pushstack(stgroups,gg);
    }
    if (str!=NULL)
      free(str);
    str=NULL;
    if (numx<1) numx=1;     if (numy<1) numy=1;
    hx=(lim->max.x-lim->min.x)/(double)numx;
    hy=(lim->max.y-lim->min.y)/(double)numy;
    y0=lim->min.y;
    for (i=1;i<=numy;++i)
    {
      x0=lim->min.x;
      for (j=1;j<=numx;++j)
      {
        p1.x=p4.x=x0;  p2.x=p3.x=x0+hx;
        p1.y=p2.y=y0;  p3.y=p4.y=y0+hy;
        p1.z=ff(p1.x,p1.y); p2.z=ff(p2.x,p2.y);
        p3.z=ff(p3.x,p3.y); p4.z=ff(p4.x,p4.y);
        for (k=1;k<=stz->n;++k)
        {
          z=*((double *) stz->s[k]);
          is1=contourintersection(z,&p1,&p2,&s1);
          is2=contourintersection(z,&p2,&p3,&s2);
          is3=contourintersection(z,&p3,&p4,&s3);
          is4=contourintersection(z,&p4,&p1,&s4);
          if (is1)
            l1=&s1;
          else if (is2)
            l1=&s2;
          else if (is3)
            l1=&s3;
          else if (is4)
            l1=&s4;
          if (is4)
            l2=&s4;
          else if (is3)
            l2=&s3;
          else if (is2)
            l2=&s2;
          else if (is1)
            l2=&s1;
          if (is1 || is2 || is3 || is4)
          {
            if (type==0)
            {
              l1->z=l2->z=z0;
            }
            /* Doda se graficni obljekt */
            gg=(gogroup) stgroups->s[k];
            goaddline(l1,l2,gg->primitives,gg);
          }
        }
        x0+=hx;
      }
      y0+=hy;
    }
  }
return ret;
}


gogroup gocontourplotsimp(double ff(double x,double y),double min,double max,
            int num,int numx,int numy,frame3d lim,golinesettings ls,int type,
            double z0)
{
stack stz=NULL,stcol=NULL;
double step,z,*pz=NULL;
truecolor col=NULL;
gogroup ret=NULL;
int i;
if (num<1) num=1;
stz=newstack(num+1); stcol=newstack(num+1);
z=min;
step=(max-min)/(double) num;
for (i=0;i<=num;++i)
{
  pz=malloc(sizeof(*pz));
  col=malloc(sizeof(*col));
  *pz=z;
  calccontourcolor(z,min,max,col);
  pushstack(stz,pz);
  pushstack(stcol,col);
  z+=step;
}
/* Meje v smeri z se zamenjajo z argumentoma min in max: */
z=min; min=lim->min.z; lim->min.z=z;
z=max; max=lim->max.z; lim->max.z=z;
/* Tvorjenje konturne risbe: */
ret=gocontourplotsimp0(ff,stz,numx,numy,lim,stcol,ls,type,z0);
/* Nazaj se vzpostavijo prvotne meje na *lim. */
lim->min.z=min; lim->max.z=max;
if (stz!=NULL)
{
  dispstackval(stz); dispstack(&stz);
}
if (stcol!=NULL)
{
  dispstackval(stcol); dispstack(&stcol);
}
return ret;
}







static double linintz4p(double z1,double z2,double z3,double z4,
                         double kx,double ky)
    /* Izracuna vmesne vrednosti funkcije na pravokotniku, ce so podane 4
    ogliscne vrednosti. z1, z2 , z3 in z4 so vrednosti funkcije na ogliscih,
    kx je normirana oddaljenost od 1. tocke v smeri osi x, ky pa normirana
    oddaljenost od 2. tocke v smeri osi y. */
{
return z1*(1-kx-ky+kx*ky)+
       z2*(kx-kx*ky)+
       z3*(kx*ky)+
       z4*(ky-kx*ky);
}

static double linintz4l(vector v1,vector v2,vector v3,vector v4,int ix,int iy)
       /* Izracuna vmesne vrednosti funkcije znotraj stirikotnika, ce so podane
       diskretne vrednosti na stranicah. V vektorjih val1, val2, val3 in val4
       so vrednosti na 1., 2., 3. in 4. stranici pravokotnika. Indeksa ix in iy
       pa podajata diskretni notranji koordinati koordinati tocke. ix in iy
       ustrezata indeksom pri val1 ... val4. */
{
double kx,ky;
double z00,z10,z11,z01,zi0,z1j,zi1,z0j;
kx=((double) (ix-1))/((double) (v1->d-1));
ky=((double) (iy-1))/((double) (v2->d-1));
z00=v1->v[1];
z10=v1->v[v1->d];
z11=v3->v[v3->d];
z01=v3->v[1];
zi0=v1->v[ix];
z1j=v2->v[iy];
zi1=v3->v[ix];
z0j=v4->v[iy];
return
z00*(-1+kx+ky-kx*ky)+
z10*(-kx+kx*ky)+
z11*(-kx*ky)+
z01*(-ky+kx*ky)+
zi0*(1-ky)+
z1j*(kx)+
zi1*(ky)+
z0j*(1-kx);

}

gogroup gosurfaceplotprim(double (*ff) (double,double),int numx,int divx,
                  int numy,int divy,frame3d lim,gofillsettings fs,
                  golinesettings ls,int type,int method)
    /* Sestavi graficni objekt - graf slike funkcije dveh spremenljivk ff().
    Graf je v smeri osi x razdeljen na numx osnovnih delov, od katerih je vsak
    se dodatno razdeljen na divx delov, podobno je z delitvijo v smeri osi y.
    lim doloca meje grafa v obeh smereh.
    fs doloca nacin izrisa ploskev, ls pa nacin izrisa crt.t
    ype doloca tip grafa, method pa aproksimacijsko metodo, ki se uporabli za
    izracun vmesnih vrednosti med osnovnimi delitvami.
    Graf je glede na vrednost argumenta type sestavljen iz:
    (type:)
      0: stirikotnikov iz crt po fini delitvi.
      1: obrobljenih polnih stirikotnikov po fini delitvi.
      2: polnih stirikotnikov po fini delitvi.
      3: polnih stirikotnikov po fini in linij po grobi delitvi.
      4: delno obrobljenih zapolnjenih stirikotnilov po fini delitvi, robovi so
         po grobi delitvi.
      6: zapolnih stirikotnikov na robovih grobe delitve in linij po grobi del.
      7: zapolnjenih stirikotnikov po robovih grobe delitve.
      8: zapolnjenih delno obrobljenih stirikotnikov po robovih grobe delitve.
      10: podobno kot 0, le da se vsak stirikotnik razdeli na stiri trikotnike.
      11: podobno kot 1, le da se vsak stirikotnik razdeli na stiri trikotnike.
      12: podobno kot 2, le da se vsak stirikotnik razdeli na stiri trikotnike.
      13: podobno kot 3, le da se vsak stirikotnik razdeli na stiri trikotnike.
      14: podobno kot 4, le da se vsak stirikotnik razdeli na stiri trikotnike.
      16: podobno kot 6, le da se vsak stirikotnik razdeli na stiri trikotnike.
      17: podobno kot 7, le da se vsak stirikotnik razdeli na stiri trikotnike.
      18: podobno kot 8, le da se vsak stirikotnik razdeli na stiri trikotnike.
      20: podobno kot 0, le da se vsak stirikotnik razdeli na dva trikotnika.
      21: podobno kot 1, le da se vsak stirikotnik razdeli na dva trikotnika.
      22: podobno kot 2, le da se vsak stirikotnik razdeli na dva trikotnika.
      23: podobno kot 3, le da se vsak stirikotnik razdeli na dva trikotnika.
      24: podobno kot 4, le da se vsak stirikotnik razdeli na dva trikotnika.
      26: podobno kot 6, le da se vsak stirikotnik razdeli na dva trikotnika.
      27: podobno kot 7, le da se vsak stirikotnik razdeli na dva trikotnika.
      28: podobno kot 8, le da se vsak stirikotnik razdeli na dva trikotnika.
    Glede na vrednost argumenta metgod se uporabi naslednja metoda za izracun
    vmesnih vrednosti funkcije ff() znotraj grobe delitve:
    (method:)
      0: vse vmesne vrednosti se izracunajo s funkcijo ff().
      1: le ogliscne vrednosti grobe delitve se izracunajo s funkcijo ff(), (
         ostale pa z interpolacijo s funkcijo linintz4p().
      2: Vrednosti na robovih grobe delitve se izracunajo iz funkcije ff(),
         notranje vrednosti pa z interpolacijo s funkcijo linintz4l.
    */
{
_coord3d p1,p2,p3,p4,p5;
vector val1=NULL,val2=NULL,val3=NULL,val4=NULL,v;
gogroup ret=NULL;
goprimitive gp;
int ix,iy,jx,jy,i;
double hx,hy,dx,dy,x0,y0,x,y,x1,y1,x2,y2,x3,y3,x4,y4,kx,ky;
char b1,b2,b3,b4;
if (numx<1) numx=1;  if (divx<1) divx=1;
if (numy<1) numy=1;  if (divy<1) divy=1;
val1=getvector(divx+1); val2=getvector(divy+1);
val3=getvector(divx+1); val4=getvector(divy+1);
hx=(lim->max.x-lim->min.x)/((double)numx); hy=(lim->max.y-lim->min.y)/((double)numy);
dx=hx/((double)divx); dy=hy/((double)divy);
ret=newgogroupst(0,40,40);
ret->name=stringcopy("surfaceplot");
/*
ret->primitives=newstack(40);
ret->extraprimitives=newstack(40);
*/
if (fs!=NULL)
{
  ret->fs1=malloc(sizeof(*(ret->fs1)));
  *(ret->fs1)=*fs;
}
if (ls!=NULL)
{
  ret->ls1=malloc(sizeof(*(ret->ls1)));
  *(ret->ls1)=*ls;
}
y0=lim->min.y;
for (iy=0;iy<numy;++iy)
{
  x0=lim->min.x;
  for (ix=0;ix<numx;++ix)
  {
    if (ix!=0)
    {
      v=val4; val4=val2; val2=v;  /* Vrednosti na val4 se prepisejo s prejsnjega val2 */
    } else
    {
      val4->v[divy+1]=ff(x0,y0+hy);
      val4->v[1]=ff(x0,y0);
    }
    val1->v[1]=val4->v[1];
    val1->v[divx+1]=ff(x0+hx,y0);
    val2->v[1]=val1->v[divx+1];
    val2->v[divy+1]=ff(x0+hx,y0+hy);
    val3->v[divx+1]=val2->v[divy+1];
    val3->v[1]=val4->v[divy+1];
    if (method==0 || method==2)
    {
      if (ix==0)  /* vrednosti v val4 se morajo na novo izracunati */
      {
        x=x0; y=y0+dy;
        for (i=2;i<=divy;++i)
        {
          val4->v[i]=ff(x,y);
          y+=dy;
        }
      }
      /* Izracun vrednosti v val1: */
      x=x0+dx; y=y0;
      for (i=2;i<=divx;++i)
      {
        val1->v[i]=ff(x,y);
        x+=dx;
      }
      /* Izracun vrednosti v val2: */
      x=x0+hx; y=y0+dy;
       for (i=2;i<=divy;++i)
      {
        val2->v[i]=ff(x,y);
        y+=dy;
      }
      /* Izracun vrednosti v val3: */
      x=x0+dx; y=y0+hy;
      for (i=2;i<=divx;++i)
      {
        val3->v[i]=ff(x,y);
        x+=dx;
      }
    } else if (method==1)
    {
      /* Vmesne vrednosti na val1 ... val4 se tu ne racunajo. */
    } else
    {
      if (ix==0)  /* vrednosti v val4 se morajo na novo izracunati */
      {
        x=x0; y=y0+dy;
        for (i=2;i<=divy;++i)
        {
          val4->v[i]=ff(x,y);
          y+=dy;
        }
      }
      /* Izracun vrednosti v val1: */
      x=x0+dx; y=y0;
      for (i=2;i<=divx;++i)
      {
        val1->v[i]=ff(x,y);
        x+=dx;
      }
      /* Izracun vrednosti v val2: */
      x=x0+hy; y=y0+dy;
       for (i=2;i<=divy;++i)
      {
        val2->v[i]=ff(x,y);
        y+=dy;
      }
      /* Izracun vrednosti v val3: */
      x=x0+dx; y=y0+hy;
      for (i=2;i<=divx;++i)
      {
        val3->v[i]=ff(x,y);
        x+=dx;
      }
    }
    /* Ogliscne vrednosti velikega pravokotnika so izracunane; sledi izracun
    ogliscnih vrednosti v manjsih pravokotnikih: */
    y1=y0; y2=y0; y3=y0+dy; y4=y0+dy;

    for (jy=1;jy<=divy;++jy)
    {
      x1=x0; x2=x0+dx; x3=x0+dx; x4=x0;
      p1.y=y1; p2.y=y2; p3.y=y3; p4.y=y4;
      for (jx=1;jx<=divx;++jx)
      {
        p1.x=x1; p2.x=x2; p3.x=x3; p4.x=x4;
        if (method==0)
        {
          if (jx==1)
          {
            p1.z=val4->v[jy];
            p4.z=val4->v[jy+1];
          } else
          {
            p1.z=p2.z;
            p4.z=p3.z;
          }
           if (jy==1)
            p2.z=val1->v[jx+1];
          else if (jx==divx)
            p2.z=val2->v[jy];
          else
            p2.z=ff(x2,y2);
          if (jx==divx)
            p3.z=val2->v[jy+1];
          else if (jy==divy)
            p3.z=val3->v[jx+1];
          else
            p3.z=ff(x3,y3);
          /*
          if (jx==1)
          {
          p1.z=ff(x1,y1);
          p4.z=ff(x4,y4);
          }
          */
          /*
          p2.z=ff(x2,y2);
          p3.z=ff(x3,y3);
          */

        } else if (method==1)
        {
          kx=((double) (jx-1))/((double)(divx));
          ky=((double) (jy-1))/((double)(divy));
          p1.z=linintz4p(val1->v[1],val1->v[divx+1],val3->v[divx+1],val3->v[1],
           kx,ky);
          kx=((double) (jx))/((double)(divx));
          p2.z=linintz4p(val1->v[1],val1->v[divx+1],val3->v[divx+1],val3->v[1],
           kx,ky);
          ky=((double) (jy))/((double)(divy));
          p3.z=linintz4p(val1->v[1],val1->v[divx+1],val3->v[divx+1],val3->v[1],
           kx,ky);
          kx=((double) (jx-1))/((double)(divx));
          p4.z=linintz4p(val1->v[1],val1->v[divx+1],val3->v[divx+1],val3->v[1],
           kx,ky);
        } else if (method==2)
        {
          p1.z=linintz4l(val1,val2,val3,val4,jx,jy);
          p2.z=linintz4l(val1,val2,val3,val4,jx+1,jy);
          p3.z=linintz4l(val1,val2,val3,val4,jx+1,jy+1);
          p4.z=linintz4l(val1,val2,val3,val4,jx,jy+1);
        } else
        {
          if (jx==1)
          {
            p1.z=val4->v[jy];
            /*
            p4.z=val3->v[1];
            */
            p4.z=val4->v[jy+1];
          } else
          {
            p1.z=p2.z;
            p4.z=p3.z;
          }
          /* POPRAVI !!! */
          p2.z=ff(x2,y2);
          p3.z=ff(x3,y3);
        }

        /* Dodajanje graficnih primitivov: */
        if (type==0)
          goaddfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
        else if (type==1)
          goaddbordfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
        else if (type==2)
          goaddfillfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
        else if (type==3)
        {
          gp=goaddfillfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            if (jx==1)
              pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
            if (jx==divx)
              pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
            if (jy==1)
              pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
            if (jy==divy)
              pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
          }
        } else if (type==4)
        {
          b1=b2=b3=b4=0;
          if (jx==1)
            b4=1;
          if (jx==divx)
            b2=1;
          if (jy==1)
            b1=1;
          if (jy==divy)
            b3=1;
          gp=goaddpartbordfourangle(&p1,&p2,&p3,&p4,b1,b2,b3,b4,
           ret->primitives,ret);
        } else if (type==6)
        {
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            gp=goaddfillfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
            if (gp->after==NULL)
              gp->after=newstack(1);
            if (jx==1)
              pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
            if (jx==divx)
              pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
            if (jy==1)
              pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
            if (jy==divy)
              pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
          }
        } else if (type==7)
        {
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            gp=goaddfillfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
          }
        } else if (type==8)
        {
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            b1=b2=b3=b4=0;
            if (jx==1)
              b4=1;
            if (jx==divx)
              b2=1;
            if (jy==1)
              b1=1;
            if (jy==divy)
              b3=1;
            gp=goaddpartbordfourangle(&p1,&p2,&p3,&p4,b1,b2,b3,b4,
             ret->primitives,ret);
          }
        } else if (type==10)
        {
          /* Podobno kot pri type=0, le da stirikotnik razdeli na 4 trikot. */
          p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
          p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
          p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
          goaddtriangle(&p1,&p2,&p5,ret->primitives,ret);
          goaddtriangle(&p2,&p3,&p5,ret->primitives,ret);
          goaddtriangle(&p3,&p4,&p5,ret->primitives,ret);
          goaddtriangle(&p4,&p1,&p5,ret->primitives,ret);
        } else if (type==11)
        {
          /* Podobno kot pri type=1, le da stirikotnik razdeli na 4 trikot. */
          p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
          p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
          p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
          goaddbordtriangle(&p1,&p2,&p5,ret->primitives,ret);
          goaddbordtriangle(&p2,&p3,&p5,ret->primitives,ret);
          goaddbordtriangle(&p3,&p4,&p5,ret->primitives,ret);
          goaddbordtriangle(&p4,&p1,&p5,ret->primitives,ret);
        } else if (type==12)
        {
          /* Podobno kot pri type=2, le da stirikotnik razdeli na 4 trikot. */
          p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
          p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
          p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
          goaddfilltriangle(&p1,&p2,&p5,ret->primitives,ret);
          goaddfilltriangle(&p2,&p3,&p5,ret->primitives,ret);
          goaddfilltriangle(&p3,&p4,&p5,ret->primitives,ret);
          goaddfilltriangle(&p4,&p1,&p5,ret->primitives,ret);
        } else if (type==13)
        {
          /* Podobno kot pri type=3, le da stirikotnik razdeli na 4 trikot. */
          p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
          p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
          p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
          gp=goaddfilltriangle(&p1,&p2,&p5,ret->primitives,ret);
          if (jy==1)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
          }
          gp=goaddfilltriangle(&p2,&p3,&p5,ret->primitives,ret);
          if (jx==divx)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
          }
          gp=goaddfilltriangle(&p3,&p4,&p5,ret->primitives,ret);
          if (jy==divy)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
          }
          gp=goaddfilltriangle(&p4,&p1,&p5,ret->primitives,ret);
          if (jx==1)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
          }
        } else if (type==14)
        {
          /* Podobno kot pri type=3, le da stirikotnik razdeli na 4 trikot. */
          p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
          p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
          p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
          /* Trikotnik: 1. stranica stirikotnika in sredisce. */
          if (jy==1)
            b1=1;
          else b1=0;
          gp=goaddpartbordtriangle(&p1,&p2,&p5,b1,0,0,ret->primitives,ret);
          /* Trikotnik: 2. stranica stirikotnika in sredisce. */
          if (jx==divx)
            b1=1;
          else b1=0;
          gp=goaddpartbordtriangle(&p2,&p3,&p5,b1,0,0,ret->primitives,ret);
          /* Trikotnik: 3. stranica stirikotnika in sredisce. */
          if (jy==divy)
            b1=1;
          else b1=0;
          gp=goaddpartbordtriangle(&p3,&p4,&p5,b1,0,0,ret->primitives,ret);
          /* Trikotnik: 4. stranica stirikotnika in sredisce. */
          if (jx==1)
            b1=1;
          else b1=0;
          gp=goaddpartbordtriangle(&p4,&p1,&p5,b1,0,0,ret->primitives,ret);
        } else if (type==16)
        {
          /* Podobno kot pri type=6, le da stirikotnik razdeli na 4 trikot. */
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
            p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
            p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
            gp=goaddfilltriangle(&p1,&p2,&p5,ret->primitives,ret);
            if (jy==1)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
            }
            gp=goaddfilltriangle(&p2,&p3,&p5,ret->primitives,ret);
            if (jx==divx)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
            }
            gp=goaddfilltriangle(&p3,&p4,&p5,ret->primitives,ret);
            if (jy==divy)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
            }
            gp=goaddfilltriangle(&p4,&p1,&p5,ret->primitives,ret);
            if (jx==1)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
            }
          }
        } else if (type==17)
        {
          /* Podobno kot pri type==7, le da stirikotnik razdeli na 4 trikot. */
          if  (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
            p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
            p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
            goaddfilltriangle(&p1,&p2,&p5,ret->primitives,ret);
            goaddfilltriangle(&p2,&p3,&p5,ret->primitives,ret);
            goaddfilltriangle(&p3,&p4,&p5,ret->primitives,ret);
            goaddfilltriangle(&p4,&p1,&p5,ret->primitives,ret);
          }
        }  else if (type==18)
        {
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            /* Podobno kot pri type=3, le da stirikotnik razdeli na 4 trikot. */
            p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
            p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
            p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
            /* Trikotnik: 1. stranica stirikotnika in sredisce. */
            if (jy==1)
              b1=1;
            else b1=0;
            gp=goaddpartbordtriangle(&p1,&p2,&p5,b1,0,0,ret->primitives,ret);
            /* Trikotnik: 2. stranica stirikotnika in sredisce. */
            if (jx==divx)
              b1=1;
            else b1=0;
            gp=goaddpartbordtriangle(&p2,&p3,&p5,b1,0,0,ret->primitives,ret);
            /* Trikotnik: 3. stranica stirikotnika in sredisce. */
            if (jy==divy)
              b1=1;
            else b1=0;
            gp=goaddpartbordtriangle(&p3,&p4,&p5,b1,0,0,ret->primitives,ret);
            /* Trikotnik: 4. stranica stirikotnika in sredisce. */
            if (jx==1)
              b1=1;
            else b1=0;
            gp=goaddpartbordtriangle(&p4,&p1,&p5,b1,0,0,ret->primitives,ret);
          }
        } else if (type==20)
        {
          /* podobno kot pri type=0, le da se stirikotnik razdeli na 2 trikot. */
          goaddtriangle(&p1,&p2,&p3,ret->primitives,ret);
          goaddtriangle(&p3,&p4,&p1,ret->primitives,ret);
        } else if (type==21)
        {
          /* podobno kot pri type=1, le da se stirikotnik razdeli na 2 trikot. */
          goaddbordtriangle(&p1,&p2,&p3,ret->primitives,ret);
          goaddbordtriangle(&p3,&p4,&p1,ret->primitives,ret);
        } else if (type==22)
        {
          /* podobno kot pri type=2, le da se stirikotnik razdeli na 2 trikot. */
          goaddfilltriangle(&p1,&p2,&p3,ret->primitives,ret);
          goaddfilltriangle(&p3,&p4,&p1,ret->primitives,ret);
        } else if (type==23)
        {
          gp=goaddfilltriangle(&p1,&p2,&p3,ret->primitives,ret);
          if (jy==1 || jx==divx)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            if (jy==1)
              pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
            if (jx==divx)
              pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
          }
          gp=goaddfilltriangle(&p3,&p4,&p1,ret->primitives,ret);
          if (jy==divy || jx==1)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            if (jy==divy)
              pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
            if (jx==1)
              pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
          }
        } else if (type==24)
        {
          b1=b2=b3=b4=0;
          if (jx==1)
            b4=1;
          if (jx==divx)
            b2=1;
          if (jy==1)
            b1=1;
          if (jy==divy)
            b3=1;
          gp=goaddpartbordtriangle(&p1,&p2,&p3,b1,b2,0,ret->primitives,ret);
          gp=goaddpartbordtriangle(&p3,&p4,&p1,b3,b4,0,ret->primitives,ret);
        } else if (type==26)
        {
          /* Podobno kot 6, le da je vsak stirikotnik iz dveh trikotnikov */
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            gp=goaddfilltriangle(&p1,&p2,&p3,ret->primitives,ret);
            if (jy==1 || jx==divx)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              if (jy==1)
                pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
              if (jx==divx)
                pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
            }
            gp=goaddfilltriangle(&p3,&p4,&p1,ret->primitives,ret);
            if (jy==divy || jx==1)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              if (jy==divy)
                pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
              if (jx==1)
                pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
            }
          }
        } else if (type==27)
        {
          /* podobno kot pri type=7, le da se stirikotnik razdeli na 2 trikot. */
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            goaddfilltriangle(&p1,&p2,&p3,ret->primitives,ret);
            goaddfilltriangle(&p3,&p4,&p1,ret->primitives,ret);
          }
        } else if (type==28)
        {
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            b1=b2=b3=b4=0;
            if (jx==1)
              b4=1;
            if (jx==divx)
              b2=1;
            if (jy==1)
              b1=1;
            if (jy==divy)
              b3=1;
            gp=goaddpartbordtriangle(&p1,&p2,&p3,b1,b2,0,ret->primitives,ret);
            gp=goaddpartbordtriangle(&p3,&p4,&p1,b3,b4,0,ret->primitives,ret);
          }
        } else
        {
          goaddfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
        }
        x1+=dx; x2+=dx; x3+=dx; x4+=dx;
      }
      y1+=dy; y2+=dy; y3+=dy; y4+=dy;
    }
    x0+=hx;
  }
  y0+=hy;
}
if (val1!=NULL)
  dispvector(&val1);
if (val2!=NULL)
  dispvector(&val2);
if (val3!=NULL)
  dispvector(&val3);
if (val4!=NULL)
  dispvector(&val4);
return ret;
}




static gogroup gosurfaceplotpar0(double (*ffx) (double,double),
                  double (*ffy) (double,double),
                  double (*ffz) (double,double),
                  int numx,int divx,int numy,int divy,frame3d lim,
                  gofillsettings fs,golinesettings ls,int type,int method)
    /* Sestavi graficni objekt - graf parametricno podane ploskve.
    Graf je po 1. parametru razdeljen na numx osnovnih delov, od katerih je vsak
    se dodatno razdeljen na divx delov, podobno je z delitvijo po drugem.
    lim doloca meje, v katerih teceta parametra (lim->x za 1. in lim->y za 2.
    parameter).
    fs doloca nacin izrisa ploskev, ls pa nacin izrisa crt.type doloca tip
    grafa, method pa aproksimacijsko metodo, ki se uporabli za izracun vmesnih
    vrednosti med osnovnimi delitvami.
    Graf je glede na vrednost argumenta type sestavljen iz:
    (type:)
      0: stirikotnikov iz crt po fini delitvi.
      1: obrobljenih polnih stirikotnikov po fini delitvi.
      2: polnih stirikotnikov po fini delitvi.
      3: polnih stirikotnikov po fini in linij po grobi delitvi.
      4: delno obrobljenih zapolnjenih stirikotnilov po fini delitvi, robovi so
         po grobi delitvi.
      6: zapolnih stirikotnikov na robovih grobe delitve in linij po grobi del.
      7: zapolnjenih stirikotnikov po robovih grobe delitve.
      8: zapolnjenih delno obrobljenih stirikotnikov po robovih grobe delitve.
      10: podobno kot 0, le da se vsak stirikotnik razdeli na stiri trikotnike.
      11: podobno kot 1, le da se vsak stirikotnik razdeli na stiri trikotnike.
      12: podobno kot 2, le da se vsak stirikotnik razdeli na stiri trikotnike.
      13: podobno kot 3, le da se vsak stirikotnik razdeli na stiri trikotnike.
      14: podobno kot 4, le da se vsak stirikotnik razdeli na stiri trikotnike.
      16: podobno kot 6, le da se vsak stirikotnik razdeli na stiri trikotnike.
      17: podobno kot 7, le da se vsak stirikotnik razdeli na stiri trikotnike.
      18: podobno kot 8, le da se vsak stirikotnik razdeli na stiri trikotnike.
      20: podobno kot 0, le da se vsak stirikotnik razdeli na dva trikotnika.
      21: podobno kot 1, le da se vsak stirikotnik razdeli na dva trikotnika.
      22: podobno kot 2, le da se vsak stirikotnik razdeli na dva trikotnika.
      23: podobno kot 3, le da se vsak stirikotnik razdeli na dva trikotnika.
      24: podobno kot 4, le da se vsak stirikotnik razdeli na dva trikotnika.
      26: podobno kot 6, le da se vsak stirikotnik razdeli na dva trikotnika.
      27: podobno kot 7, le da se vsak stirikotnik razdeli na dva trikotnika.
      28: podobno kot 8, le da se vsak stirikotnik razdeli na dva trikotnika.
    Glede na vrednost argumenta metgod se uporabi naslednja metoda za izracun
    vmesnih vrednosti funkcije ff() znotraj grobe delitve:
    (method:)
      0: vse vmesne vrednosti se izracunajo s funkcijo ff().
      1: le ogliscne vrednosti grobe delitve se izracunajo s funkcijo ff(), (
         ostale pa z interpolacijo s funkcijo linintz4p().
      2: Vrednosti na robovih grobe delitve se izracunajo iz funkcije ff(),
         notranje vrednosti pa z interpolacijo s funkcijo linintz4l.
    $A Igor <== feb97; */
{
_coord3d p1,p2,p3,p4,p5;
vector valx1=NULL,valx2=NULL,valx3=NULL,valx4=NULL,v;
vector valy1=NULL,valy2=NULL,valy3=NULL,valy4=NULL;
vector valz1=NULL,valz2=NULL,valz3=NULL,valz4=NULL;
gogroup ret=NULL;
goprimitive gp;
int ix,iy,jx,jy,i;
double hx,hy,dx,dy,x0,y0,x,y,x1,y1,x2,y2,x3,y3,x4,y4,kx,ky;
char b1,b2,b3,b4;
if (numx<1) numx=1;  if (divx<1) divx=1;
if (numy<1) numy=1;  if (divy<1) divy=1;
valx1=getvector(divx+1); valx2=getvector(divy+1);
valx3=getvector(divx+1); valx4=getvector(divy+1);
valy1=getvector(divx+1); valy2=getvector(divy+1);
valy3=getvector(divx+1); valy4=getvector(divy+1);
valz1=getvector(divx+1); valz2=getvector(divy+1);
valz3=getvector(divx+1); valz4=getvector(divy+1);
hx=(lim->max.x-lim->min.x)/((double)numx); hy=(lim->max.y-lim->min.y)/((double)numy);
dx=hx/((double)divx); dy=hy/((double)divy);
ret=newgogroupst(0,40,40);
/*
ret->name=stringcopy("surfaceplot");
*/
/*
ret->primitives=newstack(40);
ret->extraprimitives=newstack(40);
*/
if (fs!=NULL)
{
  ret->fs1=malloc(sizeof(*(ret->fs1)));
  *(ret->fs1)=*fs;
}
if (ls!=NULL)
{
  ret->ls1=malloc(sizeof(*(ret->ls1)));
  *(ret->ls1)=*ls;
}
y0=lim->min.y;
for (iy=0;iy<numy;++iy)
{
  x0=lim->min.x;
  for (ix=0;ix<numx;++ix)
  {
    if (ix!=0)
    {
      v=valx4; valx4=valx2; valx2=v;  /* Vrednosti na valx4 se prepisejo s prejsnjega valx2 */
      v=valy4; valy4=valy2; valy2=v;  /* Vrednosti na valy4 se prepisejo s prejsnjega valy2 */
      v=valz4; valz4=valz2; valz2=v;  /* Vrednosti na valz4 se prepisejo s prejsnjega valz2 */
    } else
    {
      valx4->v[divy+1]=ffx(x0,y0+hy);
      valx4->v[1]=ffx(x0,y0);
      valy4->v[divy+1]=ffy(x0,y0+hy);
      valy4->v[1]=ffy(x0,y0);
      valz4->v[divy+1]=ffz(x0,y0+hy);
      valz4->v[1]=ffz(x0,y0);
    }
    valx1->v[1]=valx4->v[1];
    valx1->v[divx+1]=ffx(x0+hx,y0);
    valx2->v[1]=valx1->v[divx+1];
    valx2->v[divy+1]=ffx(x0+hx,y0+hy);
    valx3->v[divx+1]=valx2->v[divy+1];
    valx3->v[1]=valx4->v[divy+1];

    valy1->v[1]=valy4->v[1];
    valy1->v[divx+1]=ffy(x0+hx,y0);
    valy2->v[1]=valy1->v[divx+1];
    valy2->v[divy+1]=ffy(x0+hx,y0+hy);
    valy3->v[divx+1]=valy2->v[divy+1];
    valy3->v[1]=valy4->v[divy+1];

    valz1->v[1]=valz4->v[1];
    valz1->v[divx+1]=ffz(x0+hx,y0);
    valz2->v[1]=valz1->v[divx+1];
    valz2->v[divy+1]=ffz(x0+hx,y0+hy);
    valz3->v[divx+1]=valz2->v[divy+1];
    valz3->v[1]=valz4->v[divy+1];
    if (method==0 || method==2)
    {
      if (ix==0)  /* vrednosti v val4 se morajo na novo izracunati */
      {
        x=x0; y=y0+dy;
        for (i=2;i<=divy;++i)
        {
          valx4->v[i]=ffx(x,y);
          valy4->v[i]=ffy(x,y);
          valz4->v[i]=ffz(x,y);
          y+=dy;
        }
      }
      /* Izracun vrednosti v val1: */
      x=x0+dx; y=y0;
      for (i=2;i<=divx;++i)
      {
        valx1->v[i]=ffx(x,y);
        valy1->v[i]=ffy(x,y);
        valz1->v[i]=ffz(x,y);
        x+=dx;
      }
      /* Izracun vrednosti v val2: */
      x=x0+hx; y=y0+dy;
       for (i=2;i<=divy;++i)
      {
        valx2->v[i]=ffx(x,y);
        valy2->v[i]=ffy(x,y);
        valz2->v[i]=ffz(x,y);
        y+=dy;
      }
      /* Izracun vrednosti v val3: */
      x=x0+dx; y=y0+hy;
      for (i=2;i<=divx;++i)
      {
        valx3->v[i]=ffx(x,y);
        valy3->v[i]=ffy(x,y);
        valz3->v[i]=ffz(x,y);
        x+=dx;
      }
    } else if (method==1)
    {
      /* Vmesne vrednosti na val1 ... val4 se tu ne racunajo. */
    } else /* Enako kot pri method=0 */
    {
      if (ix==0)  /* vrednosti v val4 se morajo na novo izracunati */
      {
        x=x0; y=y0+dy;
        for (i=2;i<=divy;++i)
        {
          valx4->v[i]=ffx(x,y);
          valy4->v[i]=ffy(x,y);
          valz4->v[i]=ffz(x,y);
          y+=dy;
        }
      }
      /* Izracun vrednosti v val1: */
      x=x0+dx; y=y0;
      for (i=2;i<=divx;++i)
      {
        valx1->v[i]=ffx(x,y);
        valy1->v[i]=ffy(x,y);
        valz1->v[i]=ffz(x,y);
        x+=dx;
      }
      /* Izracun vrednosti v val2: */
      x=x0+hx; y=y0+dy;
       for (i=2;i<=divy;++i)
      {
        valx2->v[i]=ffx(x,y);
        valy2->v[i]=ffy(x,y);
        valz2->v[i]=ffz(x,y);
        y+=dy;
      }
      /* Izracun vrednosti v val3: */
      x=x0+dx; y=y0+hy;
      for (i=2;i<=divx;++i)
      {
        valx3->v[i]=ffx(x,y);
        valy3->v[i]=ffy(x,y);
        valz3->v[i]=ffz(x,y);
        x+=dx;
      }
    }
    /* Ogliscne vrednosti velikega pravokotnika so izracunane; sledi izracun
    ogliscnih vrednosti v manjsih pravokotnikih: */
    y1=y0; y2=y0; y3=y0+dy; y4=y0+dy;

    for (jy=1;jy<=divy;++jy)
    {
      x1=x0; x2=x0+dx; x3=x0+dx; x4=x0;
      /* p1.y=y1; p2.y=y2; p3.y=y3; p4.y=y4; */
      for (jx=1;jx<=divx;++jx)
      {
        /* p1.x=x1; p2.x=x2; p3.x=x3; p4.x=x4; */
        if (method==0)
        {
          if (jx==1)
          {
            p1.x=valx4->v[jy];
            p4.x=valx4->v[jy+1];

            p1.y=valy4->v[jy];
            p4.y=valy4->v[jy+1];

            p1.z=valz4->v[jy];
            p4.z=valz4->v[jy+1];

          } else
          {
            p1.x=p2.x;
            p4.x=p3.x;

            p1.y=p2.y;
            p4.y=p3.y;

            p1.z=p2.z;
            p4.z=p3.z;

          }
          if (jy==1)
          {
            p2.x=valx1->v[jx+1];
            p2.y=valy1->v[jx+1];
            p2.z=valz1->v[jx+1];

          }
          else if (jx==divx)
          {
            p2.x=valx2->v[jy];
            p2.y=valy2->v[jy];
            p2.z=valz2->v[jy];

          }
          else
          {
            p2.x=ffx(x2,y2);
            p2.y=ffy(x2,y2);
            p2.z=ffz(x2,y2);

          }
          if (jx==divx)
          {
            p3.x=valx2->v[jy+1];
            p3.y=valy2->v[jy+1];
            p3.z=valz2->v[jy+1];

          }
          else if (jy==divy)
          {
            p3.x=valx3->v[jx+1];
            p3.y=valy3->v[jx+1];
            p3.z=valz3->v[jx+1];

          }
          else
          {
            p3.x=ffx(x3,y3);
            p3.y=ffy(x3,y3);
            p3.z=ffz(x3,y3);

          }
          /*
          if (jx==1)
          {
            p1.z=ffz(x1,y1);
            p4.z=ffz(x4,y4);

          }
          */
          /*
          p2.z=ffz(x2,y2);
          p3.z=ffz(x3,y3);
          */

        } else if (method==1)
        {
          kx=((double) (jx-1))/((double)(divx));
          ky=((double) (jy-1))/((double)(divy));
          p1.x=linintz4p(valx1->v[1],valx1->v[divx+1],valx3->v[divx+1],valx3->v[1],
           kx,ky);
          p1.y=linintz4p(valy1->v[1],valy1->v[divx+1],valy3->v[divx+1],valy3->v[1],
           kx,ky);
          p1.z=linintz4p(valz1->v[1],valz1->v[divx+1],valz3->v[divx+1],valz3->v[1],
           kx,ky);
          kx=((double) (jx))/((double)(divx));
          p2.x=linintz4p(valx1->v[1],valx1->v[divx+1],valx3->v[divx+1],valx3->v[1],
           kx,ky);
          p2.y=linintz4p(valy1->v[1],valy1->v[divx+1],valy3->v[divx+1],valy3->v[1],
           kx,ky);
          p2.z=linintz4p(valz1->v[1],valz1->v[divx+1],valz3->v[divx+1],valz3->v[1],
           kx,ky);
          ky=((double) (jy))/((double)(divy));
          p3.x=linintz4p(valx1->v[1],valx1->v[divx+1],valx3->v[divx+1],valx3->v[1],
           kx,ky);
          p3.y=linintz4p(valy1->v[1],valy1->v[divx+1],valy3->v[divx+1],valy3->v[1],
           kx,ky);
          p3.z=linintz4p(valz1->v[1],valz1->v[divx+1],valz3->v[divx+1],valz3->v[1],
           kx,ky);
          kx=((double) (jx-1))/((double)(divx));
          p4.x=linintz4p(valx1->v[1],valx1->v[divx+1],valx3->v[divx+1],valx3->v[1],
           kx,ky);
          p4.y=linintz4p(valy1->v[1],valy1->v[divx+1],valy3->v[divx+1],valy3->v[1],
           kx,ky);
          p4.z=linintz4p(valz1->v[1],valz1->v[divx+1],valz3->v[divx+1],valz3->v[1],
           kx,ky);
        } else if (method==2)
        {
          p1.x=linintz4l(valx1,valx2,valx3,valx4,jx,jy);
          p2.x=linintz4l(valx1,valx2,valx3,valx4,jx+1,jy);
          p3.x=linintz4l(valx1,valx2,valx3,valx4,jx+1,jy+1);
          p4.x=linintz4l(valx1,valx2,valx3,valx4,jx,jy+1);

          p1.y=linintz4l(valy1,valy2,valy3,valy4,jx,jy);
          p2.y=linintz4l(valy1,valy2,valy3,valy4,jx+1,jy);
          p3.y=linintz4l(valy1,valy2,valy3,valy4,jx+1,jy+1);
          p4.y=linintz4l(valy1,valy2,valy3,valy4,jx,jy+1);

          p1.z=linintz4l(valz1,valz2,valz3,valz4,jx,jy);
          p2.z=linintz4l(valz1,valz2,valz3,valz4,jx+1,jy);
          p3.z=linintz4l(valz1,valz2,valz3,valz4,jx+1,jy+1);
          p4.z=linintz4l(valz1,valz2,valz3,valz4,jx,jy+1);

        } else /* enako kot pri method=0. */
        {

          if (jx==1)
          {
            p1.x=valx4->v[jy];
            p4.x=valx4->v[jy+1];

            p1.y=valy4->v[jy];
            p4.y=valy4->v[jy+1];

            p1.z=valz4->v[jy];
            p4.z=valz4->v[jy+1];

          } else
          {
            p1.x=p2.x;
            p4.x=p3.x;

            p1.y=p2.y;
            p4.y=p3.y;

            p1.z=p2.z;
            p4.z=p3.z;

          }
          if (jy==1)
          {
            p2.x=valx1->v[jx+1];
            p2.y=valy1->v[jx+1];
            p2.z=valz1->v[jx+1];

          }
          else if (jx==divx)
          {
            p2.x=valx2->v[jy];
            p2.y=valy2->v[jy];
            p2.z=valz2->v[jy];

          }
          else
          {
            p2.x=ffx(x2,y2);
            p2.y=ffy(x2,y2);
            p2.z=ffz(x2,y2);

          }
          if (jx==divx)
          {
            p3.x=valx2->v[jy+1];
            p3.y=valy2->v[jy+1];
            p3.z=valz2->v[jy+1];

          }
          else if (jy==divy)
          {
            p3.x=valx3->v[jx+1];
            p3.y=valy3->v[jx+1];
            p3.z=valz3->v[jx+1];

          }
          else
          {
            p3.x=ffx(x3,y3);
            p3.y=ffy(x3,y3);
            p3.z=ffz(x3,y3);

          }
          /*
          if (jx==1)
          {
            p1.z=ffz(x1,y1);
            p4.z=ffz(x4,y4);

          }
          */
          /*
          p2.z=ffz(x2,y2);
          p3.z=ffz(x3,y3);
          */



        }

        /* Dodajanje graficnih primitivov: */
        if (type==0)
          goaddfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
        else if (type==1)
          goaddbordfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
        else if (type==2)
          goaddfillfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
        else if (type==3)
        {
          gp=goaddfillfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            if (jx==1)
              pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
            if (jx==divx)
              pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
            if (jy==1)
              pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
            if (jy==divy)
              pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
          }
        } else if (type==4)
        {
          b1=b2=b3=b4=0;
          if (jx==1)
            b4=1;
          if (jx==divx)
            b2=1;
          if (jy==1)
            b1=1;
          if (jy==divy)
            b3=1;
          gp=goaddpartbordfourangle(&p1,&p2,&p3,&p4,b1,b2,b3,b4,
           ret->primitives,ret);
        } else if (type==6)
        {
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            gp=goaddfillfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
            if (gp->after==NULL)
              gp->after=newstack(1);
            if (jx==1)
              pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
            if (jx==divx)
              pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
            if (jy==1)
              pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
            if (jy==divy)
              pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
          }
        } else if (type==7)
        {
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            gp=goaddfillfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
          }
        } else if (type==8)
        {
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            b1=b2=b3=b4=0;
            if (jx==1)
              b4=1;
            if (jx==divx)
              b2=1;
            if (jy==1)
              b1=1;
            if (jy==divy)
              b3=1;
            gp=goaddpartbordfourangle(&p1,&p2,&p3,&p4,b1,b2,b3,b4,
             ret->primitives,ret);
          }
        } else if (type==10)
        {
          /* Podobno kot pri type=0, le da stirikotnik razdeli na 4 trikot. */
          p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
          p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
          p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
          goaddtriangle(&p1,&p2,&p5,ret->primitives,ret);
          goaddtriangle(&p2,&p3,&p5,ret->primitives,ret);
          goaddtriangle(&p3,&p4,&p5,ret->primitives,ret);
          goaddtriangle(&p4,&p1,&p5,ret->primitives,ret);
        } else if (type==11)
        {
          /* Podobno kot pri type=1, le da stirikotnik razdeli na 4 trikot. */
          p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
          p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
          p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
          goaddbordtriangle(&p1,&p2,&p5,ret->primitives,ret);
          goaddbordtriangle(&p2,&p3,&p5,ret->primitives,ret);
          goaddbordtriangle(&p3,&p4,&p5,ret->primitives,ret);
          goaddbordtriangle(&p4,&p1,&p5,ret->primitives,ret);
        } else if (type==12)
        {
          /* Podobno kot pri type=2, le da stirikotnik razdeli na 4 trikot. */
          p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
          p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
          p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
          goaddfilltriangle(&p1,&p2,&p5,ret->primitives,ret);
          goaddfilltriangle(&p2,&p3,&p5,ret->primitives,ret);
          goaddfilltriangle(&p3,&p4,&p5,ret->primitives,ret);
          goaddfilltriangle(&p4,&p1,&p5,ret->primitives,ret);
        } else if (type==13)
        {
          /* Podobno kot pri type=3, le da stirikotnik razdeli na 4 trikot. */
          p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
          p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
          p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
          gp=goaddfilltriangle(&p1,&p2,&p5,ret->primitives,ret);
          if (jy==1)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
          }
          gp=goaddfilltriangle(&p2,&p3,&p5,ret->primitives,ret);
          if (jx==divx)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
          }
          gp=goaddfilltriangle(&p3,&p4,&p5,ret->primitives,ret);
          if (jy==divy)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
          }
          gp=goaddfilltriangle(&p4,&p1,&p5,ret->primitives,ret);
          if (jx==1)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
          }
        } else if (type==14)
        {
          /* Podobno kot pri type=3, le da stirikotnik razdeli na 4 trikot. */
          p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
          p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
          p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
          /* Trikotnik: 1. stranica stirikotnika in sredisce. */
          if (jy==1)
            b1=1;
          else b1=0;
          gp=goaddpartbordtriangle(&p1,&p2,&p5,b1,0,0,ret->primitives,ret);
          /* Trikotnik: 2. stranica stirikotnika in sredisce. */
          if (jx==divx)
            b1=1;
          else b1=0;
          gp=goaddpartbordtriangle(&p2,&p3,&p5,b1,0,0,ret->primitives,ret);
          /* Trikotnik: 3. stranica stirikotnika in sredisce. */
          if (jy==divy)
            b1=1;
          else b1=0;
          gp=goaddpartbordtriangle(&p3,&p4,&p5,b1,0,0,ret->primitives,ret);
          /* Trikotnik: 4. stranica stirikotnika in sredisce. */
          if (jx==1)
            b1=1;
          else b1=0;
          gp=goaddpartbordtriangle(&p4,&p1,&p5,b1,0,0,ret->primitives,ret);
        } else if (type==16)
        {
          /* Podobno kot pri type=6, le da stirikotnik razdeli na 4 trikot. */
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
            p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
            p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
            gp=goaddfilltriangle(&p1,&p2,&p5,ret->primitives,ret);
            if (jy==1)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
            }
            gp=goaddfilltriangle(&p2,&p3,&p5,ret->primitives,ret);
            if (jx==divx)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
            }
            gp=goaddfilltriangle(&p3,&p4,&p5,ret->primitives,ret);
            if (jy==divy)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
            }
            gp=goaddfilltriangle(&p4,&p1,&p5,ret->primitives,ret);
            if (jx==1)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
            }
          }
        } else if (type==17)
        {
          /* Podobno kot pri type==7, le da stirikotnik razdeli na 4 trikot. */
          if  (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
            p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
            p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
            goaddfilltriangle(&p1,&p2,&p5,ret->primitives,ret);
            goaddfilltriangle(&p2,&p3,&p5,ret->primitives,ret);
            goaddfilltriangle(&p3,&p4,&p5,ret->primitives,ret);
            goaddfilltriangle(&p4,&p1,&p5,ret->primitives,ret);
          }
        }  else if (type==18)
        {
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            /* Podobno kot pri type=3, le da stirikotnik razdeli na 4 trikot. */
            p5.x=(p1.x+p2.x+p3.x+p4.x)/4;
            p5.y=(p1.y+p2.y+p3.y+p4.y)/4;
            p5.z=(p1.z+p2.z+p3.z+p4.z)/4;
            /* Trikotnik: 1. stranica stirikotnika in sredisce. */
            if (jy==1)
              b1=1;
            else b1=0;
            gp=goaddpartbordtriangle(&p1,&p2,&p5,b1,0,0,ret->primitives,ret);
            /* Trikotnik: 2. stranica stirikotnika in sredisce. */
            if (jx==divx)
              b1=1;
            else b1=0;
            gp=goaddpartbordtriangle(&p2,&p3,&p5,b1,0,0,ret->primitives,ret);
            /* Trikotnik: 3. stranica stirikotnika in sredisce. */
            if (jy==divy)
              b1=1;
            else b1=0;
            gp=goaddpartbordtriangle(&p3,&p4,&p5,b1,0,0,ret->primitives,ret);
            /* Trikotnik: 4. stranica stirikotnika in sredisce. */
            if (jx==1)
              b1=1;
            else b1=0;
            gp=goaddpartbordtriangle(&p4,&p1,&p5,b1,0,0,ret->primitives,ret);
          }
        } else if (type==20)
        {
          /* podobno kot pri type=0, le da se stirikotnik razdeli na 2 trikot. */
          goaddtriangle(&p1,&p2,&p3,ret->primitives,ret);
          goaddtriangle(&p3,&p4,&p1,ret->primitives,ret);
        } else if (type==21)
        {
          /* podobno kot pri type=1, le da se stirikotnik razdeli na 2 trikot. */
          goaddbordtriangle(&p1,&p2,&p3,ret->primitives,ret);
          goaddbordtriangle(&p3,&p4,&p1,ret->primitives,ret);
        } else if (type==22)
        {
          /* podobno kot pri type=2, le da se stirikotnik razdeli na 2 trikot. */
          goaddfilltriangle(&p1,&p2,&p3,ret->primitives,ret);
          goaddfilltriangle(&p3,&p4,&p1,ret->primitives,ret);
        } else if (type==23)
        {
          gp=goaddfilltriangle(&p1,&p2,&p3,ret->primitives,ret);
          if (jy==1 || jx==divx)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            if (jy==1)
              pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
            if (jx==divx)
              pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
          }
          gp=goaddfilltriangle(&p3,&p4,&p1,ret->primitives,ret);
          if (jy==divy || jx==1)
          {
            if (gp->after==NULL)
              gp->after=newstack(1);
            if (jy==divy)
              pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
            if (jx==1)
              pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
          }
        } else if (type==24)
        {
          b1=b2=b3=b4=0;
          if (jx==1)
            b4=1;
          if (jx==divx)
            b2=1;
          if (jy==1)
            b1=1;
          if (jy==divy)
            b3=1;
          gp=goaddpartbordtriangle(&p1,&p2,&p3,b1,b2,0,ret->primitives,ret);
          gp=goaddpartbordtriangle(&p3,&p4,&p1,b3,b4,0,ret->primitives,ret);
        } else if (type==26)
        {
          /* Podobno kot 6, le da je vsak stirikotnik iz dveh trikotnikov */
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            gp=goaddfilltriangle(&p1,&p2,&p3,ret->primitives,ret);
            if (jy==1 || jx==divx)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              if (jy==1)
                pushstack(gp->after,goaddline(&p1,&p2,ret->extraprimitives,ret));
              if (jx==divx)
                pushstack(gp->after,goaddline(&p2,&p3,ret->extraprimitives,ret));
            }
            gp=goaddfilltriangle(&p3,&p4,&p1,ret->primitives,ret);
            if (jy==divy || jx==1)
            {
              if (gp->after==NULL)
                gp->after=newstack(1);
              if (jy==divy)
                pushstack(gp->after,goaddline(&p3,&p4,ret->extraprimitives,ret));
              if (jx==1)
                pushstack(gp->after,goaddline(&p4,&p1,ret->extraprimitives,ret));
            }
          }
        } else if (type==27)
        {
          /* podobno kot pri type=7, le da se stirikotnik razdeli na 2 trikot. */
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            goaddfilltriangle(&p1,&p2,&p3,ret->primitives,ret);
            goaddfilltriangle(&p3,&p4,&p1,ret->primitives,ret);
          }
        } else if (type==28)
        {
          if (jx==1 || jx==divx || jy==1 || jy==divy)
          {
            b1=b2=b3=b4=0;
            if (jx==1)
              b4=1;
            if (jx==divx)
              b2=1;
            if (jy==1)
              b1=1;
            if (jy==divy)
              b3=1;
            gp=goaddpartbordtriangle(&p1,&p2,&p3,b1,b2,0,ret->primitives,ret);
            gp=goaddpartbordtriangle(&p3,&p4,&p1,b3,b4,0,ret->primitives,ret);
          }
        } else
        {
          goaddfourangle(&p1,&p2,&p3,&p4,ret->primitives,ret);
        }
        x1+=dx; x2+=dx; x3+=dx; x4+=dx;
      }
      y1+=dy; y2+=dy; y3+=dy; y4+=dy;
    }
    x0+=hx;
  }
  y0+=hy;
}
if (valx1!=NULL) dispvector(&valx1);     if (valx2!=NULL) dispvector(&valx2);
if (valx3!=NULL) dispvector(&valx3);     if (valx4!=NULL) dispvector(&valx4);
if (valy1!=NULL) dispvector(&valy1);     if (valy2!=NULL) dispvector(&valy2);
if (valy3!=NULL) dispvector(&valy3);     if (valy4!=NULL) dispvector(&valy4);
if (valz1!=NULL) dispvector(&valz1);     if (valz2!=NULL) dispvector(&valz2);
if (valz3!=NULL) dispvector(&valz3);     if (valz4!=NULL) dispvector(&valz4);
return ret;
}



gogroup gosurfaceplotpar(double (*ffx) (double,double),
                  double (*ffy) (double,double),
                  double (*ffz) (double,double),
                  int numx,int divx,int numy,int divy,frame3d lim,
                  gofillsettings fs,golinesettings ls,int type,int method)
    /* Sestavi graficni objekt - graf parametricno podane ploskve. Funkcija je
    identicna gosurfaceplotpar0(), le da postavi tudi ime skupine, ki jo vrne.
    $A Igor feb97; */
{
gogroup ret;
ret=gosurfaceplotpar0(ffx,ffy,ffz,numx,divx,numy,divy,lim,fs,ls,type,method);
if (ret!=NULL)
  ret->name=stringcopy("surfaceplotpar");
return ret;
}


/* POMOZNE FUNKCIJE za izpeljavo gosurfaceplot iz gosurfaceplotpar: */

static double retfirstoftwo(double u,double v)
    /* Vrne 1. izmed dveh argumentov. */
{
return u;
}

static double retsecondoftwo(double u,double v)
    /* Vrne 2. izmed dveh argumentov. */
{
return v;
}

gogroup gosurfaceplot(double (*ff) (double,double),int numx,int divx,
                  int numy,int divy,frame3d lim,gofillsettings fs,
                  golinesettings ls,int type,int method)
    /* Sestavi graficni objekt - graf slike funkcije dveh spremenljivk ff().
    funkcija uporablja za sestavo grafa funkcijo gosurfaceplotpar0(), zato so
    tudi argumenti identicni argumentom te funkcije, razen funkcijskih argumen-
    tov. ff je funkcija, katere graf rsemo.
    $A Igor <== feb97; */
{
gogroup ret;
ret=gosurfaceplotpar0(retfirstoftwo,retsecondoftwo,ff,numx,divx,numy,divy,
    lim,fs,ls,type,method);
if (ret!=NULL)
  ret->name=stringcopy("surfaceplot");
return ret;
}




/* POMOZNE FUNKCIJE za izpeljavo gosurfaceplotspher iz gosurfaceplotpar: */

static double (*rspher) (double,double);

static double xspher(double fi,double theta)
    /* Izracuna koordinato x iz sfericnih koordinat fi, theta in
    rspher(fi, theta). */
{
  return rspher(fi,theta)*sin(theta)*cos(fi);
}

static double yspher(double fi,double theta)
    /* Izracuna koordinato y iz sfericnih koordinat fi, theta in
    rspher(fi, theta). */
{
  return rspher(fi,theta)*sin(theta)*sin(fi);
}

static double zspher(double fi,double theta)
    /* Izracuna koordinato z iz sfericnih koordinat fi, theta in
    rspher(fi, theta). */
{
  return rspher(fi,theta)*cos(theta);
}

gogroup gosurfaceplotspher(double (*ff) (double,double),int numx,int divx,
                  int numy,int divy,frame3d lim,gofillsettings fs,
                  golinesettings ls,int type,int method)
    /* Sestavi graficni objekt - graf ploskve v sfericnih koordinatah.
    Funkcija uporablja za sestavo grafa funkcijo gosurfaceplotpar(), zato so
    tudi argumenti identicni argumentom te funkcije, razen funkcijskih argumen-
    tov. ff je funkcija, katere graf rsemo, in podaja odvisnost razdalje tocke
    od koordinatnega izhodisca od azimuta in polarnega kota. */
{
rspher=ff;
return gosurfaceplotpar(xspher,yspher,zspher,numx,divx,numy,divy,
    lim,fs,ls,type,method);
}




/* POMOZNE FUNKCIJE za izpeljavo gosurfaceplotcyl iz gosurfaceplotpar: */

static double xcyl(double r,double fi)
    /* Izracuna koordinato x iz sfericnih koordinat fi, theta in
    zcyl(fi, theta). */
{
  return r*cos(fi);
}

static double ycyl(double r,double fi)
    /* Izracuna koordinato y iz sfericnih koordinat fi, theta in
    zcyl(fi, theta). */
{
  return r*sin(fi);
}

gogroup gosurfaceplotcyl(double (*ff) (double,double),int numx,int divx,
                  int numy,int divy,frame3d lim,gofillsettings fs,
                  golinesettings ls,int type,int method)
    /* Sestavi graficni objekt - graf ploskve v cilindricnih koordinatah.
    Funkcija uporablja za sestavo grafa funkcijo gosurfaceplotpar(), zato so
    tudi argumenti identicni argumentom te funkcije, razen funkcijskih argumen-
    tov. ff je funkcija, katere graf risemo in podaja odvisnost koordinate z
    tocke od koordinat r in fi v cilindricnih koordinatah. */
{
return gosurfaceplotpar(xcyl,ycyl,ff,numx,divx,numy,divy,
    lim,fs,ls,type,method);
}





/* POMOZNE FUNKCIJE za izpeljavo gosurfaceplotbottle iz gosurfaceplotpar: */

static double (*rbottle) (double z,double fi);

static double xbottle(double z,double fi)
    /* Izracuna koordinato x iz cilindricnih koordinat fi in r(z,fi). */
{
return rbottle(z,fi)*cos(fi);
}

static double ybottle(double z,double fi)
    /* Izracuna koordinato y iz cilindricnih koordinat fi in r(z,fi). */
{
return rbottle(z,fi)*sin(fi);
}

static double zbottle(double z,double fi)
       /* Vrne 1. izmed koordinat z in fi. */
{
return z;
}


gogroup gosurfaceplotbottle(double (*ff) (double,double),int numx,int divx,
                  int numy,int divy,frame3d lim,gofillsettings fs,
                  golinesettings ls,int type,int method)
    /* Sestavi graficni objekt - graf steklenicne ploskve v cilind. koordinatah.
    Funkcija uporablja za sestavo grafa funkcijo gosurfaceplotpar(), zato so
    tudi argumenti identicni argumentom te funkcije, razen funkcijskih argumen-
    tov. ff je funkcija, katere graf risemo in podaja odvisnost koordinate r
    tocke od koordinat z in fi v cilindricnem koordinat. sistemu. */
{
rbottle=ff;
return gosurfaceplotpar(xbottle,ybottle,zbottle,numx,divx,numy,divy,
    lim,fs,ls,type,method);
}





gogroup gocurveplot3dpar(double fx(double),double fy(double),double fz(double),
          int num,int div,double from,double to,golinesettings ls)
    /* Sestavi graficni objekt - graf parametricno podane krivulje v 3
    dimenzijah. fx, fy in fz so funkcijske odvisnosti koordinat od parametra, ki
    tece od from do to. Krivulja je razdeljena na num ravnih delov, od katerih
    je vsak razdeljen na div krajsih crt. V ls so lastnosti crt, ki sestavljajo
    krivuljo. */
{
double step;
_coord3d p1,p2;
gogroup ret=NULL;
int i;
step=(to-from)/((double) num);
ret=newgogroupst(0,100,0);
ret->name=stringcopy("curveplot3dpar");
/* Nastavitve za risanje crt: */
ret->ls1=malloc(sizeof(*ret->ls1));
*(ret->ls1)=*ls;
/* Sestava grafa: */
p2.x=fx(from);  p2.y=fy(from);  p2.z=fz(from);
for (i=1;i<=num;++i)
{
  p1=p2;
  p2.x=fx(from+((double)i)*step);
  p2.y=fy(from+((double)i)*step);
  p2.z=fz(from+((double)i)*step);
  goaddlinediv(&p1,&p2,ret->primitives,ret,div);
}
return ret;
}





