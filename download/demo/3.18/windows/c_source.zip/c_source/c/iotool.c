

#define EXTRACE   /* Switch on tracing */

#ifdef EXTRACE
  #undef EXTRACE    /* Switch off tracing */
#endif

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include <mtypes.h>
#include <er.h>
#include <rf.h>
#include <mat.h>
#include <vec.h>
#include <st.h>
#include <strop.h>
#include <fop.h>
#include <simb.h>
#include <varop.h>
#include <fld.h>






            /******************************************/
            /*                                        */
            /*            POMOZNA  ORODJA             */
            /*           BRANJE IN PISANJE            */
            /*                                        */
            /******************************************/






void fileargto(FILE *fp,long from,long to,int buflength,
            int *kind,long *pos1,long *pos2,char **str)
    /* Funkcija poisce 1. argument v datoteki fp med from in to (buflength je
    dolzina vmesnega pomnilnika pri iskanju). Argument je lahko stevilo, ime
    spremenljivke ali izraz, ki ga lahko izracunamo s simbolnim kalkulatorjem.
    Funkcija vrne v *kind vrsto argumenta (-1, ce argumenta ne najde, 0, ce je
    argument stevilo, 1, ce je argument ime spremenljivke, in 2, ce je arguent
    izraz),    v *pos1 vrne mesto, kjer se argument zacne (pri imenih
    spremenljivk in izrazov je to mesto, kjer stoji znak '$'), v *pos2 pa
    mesto, kjer se argument konca (za eno vec kot mesto, do koder traja niz,
    ki predstavlja argument).
      Ime spremenljivke mora stati za znakom '$', vmes je lahko presledek ali
    znak '\n' ali '\r' ali '"' ali ',', za imenom pa mora biti presledek ali
    znak '\n' ali '\r' ali '"' ali ','. Ce se ime ne zakluci z enim od teh
    znakov, se vzame, da traja kar do konca obmocja iskanja. Primeri za ime
    spremenljivke: $x $ x $ "x"  $x, $"x",
      Tudi izraz mora stati za znakom '\n' ali '\r' ali '"' ali ','. Biti mora
    v zavitih oklepajih. Primeri: ${x+y} $ {3*(a-2)}  $ { a + z }
    $A Igor jun97; */
{
char bracexp1='{',bracexp2='}';
long start1,start2,pos,open,close;
int length;
double x;
char ch;
*kind=-1;
*pos1=-1;
*pos2=-1;
*str=NULL;
x=filenumto(fp,from,to,buflength,&start1,&length);
start2=filecharto(fp,"$",1,from,to,buflength);
if (start1>0 && (start2<=0 || start2>start1) )
{
  /* Ce je 1. stevilo, ki smo ga nasli, pred 1. znakom '$', ki smo ga nasli
  (ali ce znaka '$' sploh nismo nasli), potem je iskani atgument to stevilo: */
  *kind=0;
  *pos1=start1;
  *pos2=start1+length;
  *str=malloc(length+1);
  fileread(*str,1,length,fp,start1);
  (*str)[length]='\0';
} else if (start2>0 && (start1<=0 || start1>start2) && start2+1<=to)
{
  /* Ce je 1. znak '$', ki smo ga nasli, pred 1. stevilom, ki smo ga nasli
  (ali ce stevila sploh nismo nasli), potem je iskani atgument tisto, na kar
  se nanasa ta znak '$': */
  pos=filenotcharto(fp," \"\n\r\t\0",6,start2+1,to,buflength);
  if (pos>0)
  {
    fileread(&ch,sizeof(char),1,fp,pos);
    if (ch==bracexp1)
    {
      /* Gre za izraz, ki je v oklepaju: */
      filebracto(fp,bracexp1,bracexp2,pos,to,buflength,&open,&close);
      if (open>0 && close>0)
      {
        /* Branje niza: */
        *kind=2;
        *pos1=start2;
        *pos2=close+1;
        length=close-open-1;
        *str=malloc(length+1);
        fileread(*str,1,length,fp,open+1);
        (*str)[length]='\0';
      }
    } else
    {
      /* Gre za ime spremenljivke: */
      /* Dolzina imena spremenljivke: */
      close=filecharto(fp," ;':,\n\r\"\t\0",10,pos,to,buflength);
      /* Ce ni zakljucnega locila, traja ime spremenljivke do konca obmocja: */
      if (close<=0)
        close=to+1;
      if (pos>0 && close>0)
        length=close-pos;
      else
        length=0;
      if (length>0)
      {
        /* Prebere se ime spremenljivke: */
        *str=malloc(length+1); /* En byte je za zakljucni znak '\0'. */
        fileread(*str,sizeof(char),length,fp,pos);
        (*str)[length]='\0'; /* Ker se steje od 0 */
        *kind=1;
        *pos1=start2;
        *pos2=close;
        if (*pos2>to+1)
          *pos2=to+1;
      }
    }
  }
} else
{
  /* Ce nicesar nismo nasli: */
  *kind=-1;
  *pos1=-1;
  *pos2=-1;
  *str=NULL;
}
}




long fileargvaltoold(FILE *fp,long from,long to,int max,ssyst syst,
       int buflength,stack st)
    /* Na sklad st potisne vse vrednosti argumentov (tipa double), ki jih
    najde v datoteki fp med from in to s funkcijo fileargto. max je najvecje
    stevilo vrednosti, ki jih lahko potisne na sklad (ce je max manj od 1,
    je to stevilo neomejeno). syst je sistem za simbolno racunanje, v katerem
    se ovrednotijo izrazi ali spremenljivke. buflength je dolzina vmesnega
    pomnilnika pri iskanju po datoteki.
    Funkcija vrne stevilo, ki je za ena vecje, kot mesto, do katerega je v
    datoteki zapisan zadnji najdeni argument (ce ne najde nobenega
    argumenta, vrne -1).
      OPOMBA: Prostor za sklad st mora biti ze rezerviran. 
    $A Igor jun97; */
{
char end=0,*str=NULL;
int kind,count;
long pos1,pos2,ret=-1;
double *argval=NULL;
pos2=from;
count=1;
if (st==NULL)
  end=1;
while (!end)
{
  fileargto(fp,pos2,to,buflength,&kind,&pos1,&pos2,&str);
  if (kind>-1)
  {
    ret=pos2;
    argval=malloc(sizeof(*argval));
    if (kind==0) /* Stevilo */
    {
      sscanf(str,"%lg",argval);
    } else if (kind==1) /* Spremenljivka */
    {
      *argval=(double) evaluateexp(syst,str);
    } else if (kind==2) /* Izraz */
    {
      *argval=(double) evaluateexp(syst,str);
    }
    pushstack(st,argval);
    argval=NULL;
    if (str!=NULL)
      free(str);
    if (count==max)
      end=1;
  } else
    end=1;
  ++count;
}
return ret;
}




double file1argvaltoold(FILE *fp,long from,long to,ssyst syst,int buflength,
              long *pos1,long *pos2)
    /* Vrne vrednost 1. argumenta, ki ga najde v datoteki fp med from in to
    s funkcijo fileargto. syst je sistem za simbolno racunanje, v katerem se
    izracuna izraz, ce je to argument. buflength je dolzina vmesnega
    pomnilnika pri iskanju po datoteki. V *pos1 in *pos2 se zapiseta
    mesto v datoteki, kjer se argument zacne ter za ena vec kot je mesto,
    kjer se argument konca.
    $A Igor jun97; */
{
char *str=NULL;
int kind;
double ret=0;
fileargto(fp,from,to,buflength,&kind,pos1,pos2,&str);
if (kind>-1)
{
  if (kind==0) /* Stevilo */
  {
    sscanf(str,"%lg",&ret);
  } else if (kind==1) /* Spremenljivka */
  {
    ret=(double) evaluateexp(syst,str);
  } else if (kind==2) /* Izraz */
  {
    ret=(double) evaluateexp(syst,str);
  }
  if (str!=NULL)
    free(str);
}
return ret;
}


int freadnumarg(FILE *fp,double *val,long from,long to,ssyst syst,
                long *start,long *next)
    /* Prebere stevilski argument iz datoteke fp med mestoma from in to ter ga
    zapise v *val. V *start zapise zacetek argumenta, v *next pa mesto, kjer
    se zacnejo nadaljnji podatki za prebranim argumentom. Stevilski argument je
    lahko podan neposredno kot stevilo, kot spremenljivka kalkulatorja syst
    (znak $, ki mu sledi ime spremenljivke) ali kot matematicni izrazi, ki se
    ovrednotijo v sistemu syst (znak $, ki mu sledi izraz v zavitih oklepajih).
     Funkcija vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj
    narobe. 
    $A Igor jul99; */
{
long start1=-1,next1=-1;
char *str=NULL;
int kind,ret=0,buflength=20;
fileargto(fp,from,to,buflength,&kind,&start1,&next1,&str);
if (kind>-1)
{
  if (kind==0) /* Stevilo */
  {
    sscanf(str,"%lg",val);
  } else if (kind==1) /* Spremenljivka */
  {
    *val=(double) evaluateexp(syst,str);
  } else if (kind==2) /* Izraz */
  {
    *val=(double) evaluateexp(syst,str);
  }
  if (str!=NULL)
    free(str);
} else
  ret=-1;
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return ret;
}



int freadnumargs(FILE *fp,long from,long to,int maxnum,ssyst syst,
                stack *st,long *start,long *next)
    /* Iz datoteke fp prebere stevila med mestoma from in to in jih polozi na
    sklad st kot kazalce na double. Prebere najvec maxnum stevil s funkcijo
    freadnumarg() in vrne stevilo dejansko prebranih stevil. Ce lahko prebere
    kako stevilo, zapise v *start zacetek prvega stevila, v *next pa mesto,
    kjer se zacnejo nadaljnji podatki za zadnjim prebranim stevilom. Stevila so
    lahko podana z vrednostmi, kot spremenljivke kalkulatorja syst (znak $, ki
    mu sledi ime spremenljivke) ali kot matematicni izrazi, ki se ovrednotijo
    v sistemu syst (znak $, ki mu sledi izraz v zavitih oklepajih).
      Ce funkciija ne more prebrati nobenega stevila, se v *start in *next
    zapise -1.
    Argumenta start in next sta lahko tudi NULL.
    $A Igor jul99; */
{
long start1=-1,next1=-1,pos,pos1,pos2;
char end=0;
int count=0;
stack retst=NULL;
double val,*pval;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
if (st==NULL)
  end=1;
else
{
  if (*st==NULL)
    *st=newstack(5);
  else
    dispstackval(*st);
  retst=*st;
}
if (from>0 && to>=from)
{
  pos=from;
  while (!end)
  {
    freadnumarg(fp,&val,pos,to,syst,&pos1,&pos2);
    if (pos1>0 && pos2>0)
    {
      ++ count;
      if (count==maxnum && maxnum>0)
        end=1;
      pval=malloc(sizeof(*pval));
      *pval=val;
      pushstack(retst,pval);
      pos=pos2;
      if (pos>to)
        end=1;
      if (start1<1)
        start1=pos1;
      next1=pos2;
    } else
      end=1;
    if (count==maxnum)
      end=1;
  }
}
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return count;
}


double file1argvalto(FILE *fp,long from,long to,ssyst syst,int buflength,
              long *pos1,long *pos2)
    /* Vrne vrednost 1. argumenta, ki ga najde v datoteki fp med from in to
    s funkcijo fileargto. syst je sistem za simbolno racunanje, v katerem se
    izracuna izraz, ce je to argument. buflength je dolzina vmesnega
    pomnilnika pri iskanju po datoteki. V *pos1 in *pos2 se zapiseta
    mesto v datoteki, kjer se argument zacne ter za ena vec kot je mesto,
    kjer se argument konca.
      POZOR!
      Ta funkcija naj se ne uporablja vec, namesto nje je treba uporabljati
    funkcijo freadnumarg().
    $A Igor jul99; */
{
double ret;
freadnumarg(fp,&ret,from,to,syst,pos1,pos2);
return ret;
}


long fileargvalto(FILE *fp,long from,long to,int max,ssyst syst,
       int buflength,stack st)
    /* Na sklad st potisne vse vrednosti argumentov (tipa double), ki jih
    najde v datoteki fp med from in to s funkcijo fileargto. max je najvecje
    stevilo vrednosti, ki jih lahko potisne na sklad (ce je max manj od 1,
    je to stevilo neomejeno). syst je sistem za simbolno racunanje, v katerem
    se ovrednotijo izrazi ali spremenljivke. buflength je dolzina vmesnega
    pomnilnika pri iskanju po datoteki.
    Funkcija vrne stevilo, ki je za ena vecje, kot mesto, do katerega je v
    datoteki zapisan zadnji najdeni argument (ce ne najde nobenega
    argumenta, vrne -1).
      OPOMBA: Prostor za sklad st mora biti ze rezerviran. 
      POZOR!
      Ta funkcija naj se ne uporablja vec, namesto nje je treba uporabljati
    funkcijo freadnumargs().
    $A Igor jul99; */
{
long start,next;
if (st!=NULL)
  freadnumargs(fp,from,to,max,syst,&st,&start,&next);
else
  next=-1;
return next;
}



stack freadstringsold(FILE *fp,char *left,int nleft,char *right,int nright,
                   char *pre,int npre,char *post,int npost,long from,long to,
                   int maxnum,int buflength,long *begin,long *next)
    /* Funkcija prebere najvec maxnum nizov, ki so v datoteki fp med from in
    to, in jih nalozi na sklad, ki ga vrne. Ce je maxnum<1, je lahko stevilo 
    nizov poljubno.
      Nizi se morajo zaceti z znakom, ki ni vsebovan v nizu left dolzine nleft.
    Konec niza oznacuje znak, ki je vsebovan v nizu right dolzine nright. V
    pre in post so znaki, ki lahko oklepajo niz na levi oz. desni strani. Ce
    so ti znaki specifirani in se najde znak iz pre, ki se pojavi prej ali
    istocasno kot prvi znak, ki ni vsebovan v nizu left, je konec niza dolocen
    kot en znak pred 1. pojavom znaka iz niza post od zacetka niza naprej.
    npre  in npost oznacujeta stevilo znakov v nizih pre in post.
      Ce se najde znak, ki lahko zacne niz, ne pa znak, ki ga lahko
    konca, niz traja vse do mesta to (vkljucno!). funkcija vrne NULL, ce je
    kaj narobe z vhodnimi parametri, in prazen sklad, ce ni nasla nobenega
    niza.
      V *begin se zapise pozicija 1. znaka 1. najdenega niza, v *next pa
    pozicija takoj za zadnjim znakom zadnjega najdenega niza.
    $A Igor jun97 jun98; */
{
stack ret=NULL;
long pos1,pos2,pospre;
int count=0,length;
char end=0,enclose,*str;
*begin=0;  *next=0;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
if (from>0 && to>=from)
{
  ret=newstack(5);
  pos2=from-1;
  while (!end)
  {
    ++ count;
    /* Najprej najdemo zacetek naslednjega niza, ce je to mozno, in preverimo,
    ce niz oklepajo znaki, ki oznacujejo zacetek in konec niza in so vsebovani
    v pre in post (v tem primeru postavimo enclose na 1): */
    pos1=pospre=0;
    if (left!=NULL && nleft>0)
      pos1=filenotcharto(fp,left,nleft,pos2+1,to,buflength);
    /* Ce je pos1>0, potem niz ni omejen z znaki, ki so v pre in post, razen,
    ce najdemo kak znak iz niza pre se pred pos1, ki drugace oznacuje 1. znak
    niza: */
    if (pre!=NULL && npre>0)
      pospre=filecharto(fp,pre,npre,pos2+1,to,buflength);
    if (pospre>0 && pospre<=pos1)
    {
      enclose=1;
      /* Ce je niz vsebovan med znakoma iz pre in post, je zacetek niza takoj
      za pozicijo 1. znaka iz pre: */
      pos1=pospre+1;
    } else
      enclose=0;
    if (pos1<1)
      end=1;
    else
    {
      pos2=0;
      /* Ko je znan zacetek niza, poiscemo se njegov konec: */
      if (enclose)
        pos2=filecharto(fp,post,npost,pos1,to,buflength);
      else
        pos2=filecharto(fp,right,nright,pos1,to,buflength);
      if (pos2<1)
      {
        /* Ce smo nasli znak, s katerim se niz lahko zacne, ne pa znaka, ki
        lahko niz konca, potem traja niz kar do konca obmocja: */
        end=1;
        pos2=to+1;
      }
      /* Ce smo nasli zacetek in konec niza, ga preberemo in nalozimo na sklad: */
      length=pos2-pos1;
      if (length>=0)
      {
        if (*begin==0)
          *begin=pos1;
        /* *next=pos2-1; */
        *next=pos2;
        str=makestring(length);
        fileread(str,1,length,fp,pos1);
        str[length]='\0';
        pushstack(ret,str);   str=NULL;
      }
    }
    if (count==maxnum)
      end=1;
  }
}
return ret;
}


static string freadstring(FILE *fp,char *left,int nleft,char *right,int nright,
                   char *pre,int npre,char *post,int npost,long from,long to,
                   int buflength,long *begin,long *next)
    /* Funkcija prebere prvi niz, ki je v datoteki fp med from in to, in ga
    vrne.
      Nizi se mora zaceti z znakom, ki ni vsebovan v nizu left dolzine nleft.
    Konec niza oznacuje znak, ki je vsebovan v nizu right dolzine nright. V
    pre in post so znaki, ki lahko oklepajo niz na levi oz. desni strani. Ce
    so ti znaki specifirani in se najde znak iz pre, ki se pojavi prej ali
    istocasno kot prvi znak, ki ni vsebovan v nizu left, je konec niza dolocen
    kot en znak pred 1. pojavom znaka iz niza post od zacetka niza naprej.
    npre  in npost oznacujeta stevilo znakov v nizih pre in post.
      Ce se najde znak, ki lahko zacne niz, ne pa znak, ki ga lahko
    konca, niz traja vse do mesta to (vkljucno!). funkcija vrne NULL, ce je
    kaj narobe z vhodnimi parametri, in prazen sklad, ce ni nasla nobenega
    niza.
      V *begin se zapise pozicija 1. znaka prebranega niza, v *next pa
    pozicija takoj za zadnjim znakom tega niza. Ce ne najde niza, zapise v
    *begin in *next -1.
    $A Igor jul99; */
{
long pos1,pos2,pospre,begin1=0,next1=0;
int length;
char enclose,*ret=NULL;
begin1=0;  next1=0;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
if (from>0 && to>=from)
{
  pos2=from-1;
  /* Najprej najdemo zacetek naslednjega niza, ce je to mozno, in preverimo,
  ce niz oklepajo znaki, ki oznacujejo zacetek in konec niza in so vsebovani
  v pre in post (v tem primeru postavimo enclose na 1): */
  pos1=pospre=0;
  if (left!=NULL && nleft>0)
    pos1=filenotcharto(fp,left,nleft,pos2+1,to,buflength);
  /* Ce je pos1>0, potem niz ni omejen z znaki, ki so v pre in post, razen,
  ce najdemo kak znak iz niza pre se pred pos1, ki drugace oznacuje 1. znak
  niza: */
  if (pre!=NULL && npre>0)
    pospre=filecharto(fp,pre,npre,pos2+1,to,buflength);
  if (pospre>0 && pospre<=pos1)
  {
    enclose=1;
    /* Ce je niz vsebovan med znakoma iz pre in post, je zacetek niza takoj
    za pozicijo 1. znaka iz pre: */
    pos1=pospre+1;
  } else
    enclose=0;
  if (pos1>=1)
  {
    pos2=0;
    /* Ko je znan zacetek niza, poiscemo se njegov konec: */
    if (enclose)
      pos2=filecharto(fp,post,npost,pos1,to,buflength);
    else
      pos2=filecharto(fp,right,nright,pos1,to,buflength);
    if (pos2<1)
    {
      /* Ce smo nasli znak, s katerim se niz lahko zacne, ne pa znaka, ki
      lahko niz konca, potem traja niz kar do konca obmocja: */
      pos2=to+1;
    }
    /* Ce smo nasli zacetek in konec niza, ga preberemo in nalozimo na sklad: */
    length=pos2-pos1;
    if (length>=0)
    {
      begin1=pos1;
      /* next1=pos2-1; */
      next1=pos2;
      if (enclose)
        if (next1>0)
          ++next1;
      ret=makestring(length);
      fileread(ret,1,length,fp,pos1);
      ret[length]='\0';
    }
  }
}
if (begin!=NULL)
  *begin=begin1;
if (next!=NULL)
  *next=next1;
return ret;
}





stack freadstrings(FILE *fp,char *left,int nleft,char *right,int nright,
                   char *pre,int npre,char *post,int npost,long from,long to,
                   int maxnum,int buflength,long *begin,long *next)
    /* Funkcija prebere najvec maxnum nizov, ki so v datoteki fp med from in
    to, in jih nalozi na sklad, ki ga vrne. Ce je maxnum<1, je lahko stevilo 
    nizov poljubno.
      Nizi se morajo zaceti z znakom, ki ni vsebovan v nizu left dolzine nleft.
    Konec niza oznacuje znak, ki je vsebovan v nizu right dolzine nright. V
    pre in post so znaki, ki lahko oklepajo niz na levi oz. desni strani. Ce
    so ti znaki specifirani in se najde znak iz pre, ki se pojavi prej ali
    istocasno kot prvi znak, ki ni vsebovan v nizu left, je konec niza dolocen
    kot en znak pred 1. pojavom znaka iz niza post od zacetka niza naprej.
    npre  in npost oznacujeta stevilo znakov v nizih pre in post.
      Ce se najde znak, ki lahko zacne niz, ne pa znak, ki ga lahko
    konca, niz traja vse do mesta to (vkljucno!). funkcija vrne NULL, ce je
    kaj narobe z vhodnimi parametri, in prazen sklad, ce ni nasla nobenega
    niza.
      V *begin se zapise pozicija 1. znaka 1. najdenega niza, v *next pa
    pozicija takoj za zadnjim znakom zadnjega najdenega niza. Ce ne najde
    nobenega niza, zapise v *begin in *next -1.
    $A Igor jun97 jun98 jul99; */
{
long pos,pos1,pos2,begin1=-1,next1=-1;
int count=0;
char end=0,*str=NULL;
stack retst=NULL;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
retst=newstack(5);
if (from>0 && to>=from)
{
  pos=from;
  while (!end)
  {
    str=freadstring(fp,left,nleft,right,nright,pre,npre,post,npost,from,to,
                buflength,&pos1,&pos2);
    if (pos1>0 && pos2>0)
    {
      ++ count;
      if (count==maxnum && maxnum>0)
        end=1;
      pushstack(retst,str);
      str=NULL;
      pos=pos2;
      if (pos>to)
        end=1;
      if (begin1<1)
        begin1=pos1;
      next1=pos2;
    } else
      end=1;
    if (count==maxnum)
      end=1;
  }
}
if (begin!=NULL)
  *begin=begin1;
if (next!=NULL)
  *next=next1;
return retst;
}



stack freadstringsold0(FILE *fp,char *left,int nleft,char *right,int nright,
                   long from,long to,int maxnum,int buflength,long *first,
                   long *last)
    /* Podobno kot freadstrings, le da niso specifirani znaki, ki lahko
    omejujejo niz (kot npr. dvojni narekoveji) in da *last postane pozicija
    zadnjega znaka zadnjega niza. 
    
    $A Igor jun98; */
{
stack ret;
ret=freadstrings(fp,left,nleft,right,nright,NULL,0,NULL,0,from,to,maxnum,
                 buflength,first,last);
if (*last>0)
  --(*last);
return ret;
}

static string freadstringinv(FILE *fp,char *left,int nleft,char *right,
               int nright,long from,long to,int buflength,
               long *begin,long *next)
    /* Podobno kot freadstring, le da je znak, ki lahko omejuje niz na levi in
    desni, avtomatsko dvojni narekovaj. 
    $A Igor jul99; */
{
return freadstring(fp,left,nleft,right,nright,"\"",1,"\"",1,from,to,
                    buflength,begin,next);
}

stack freadstringsinv(FILE *fp,char *left,int nleft,char *right,int nright,
                   long from,long to,int maxnum,int buflength,
                   long *begin,long *next)
    /* Podobno kot freadstrings, le da je znak, ki lahko omejuje niz na levi in
    desni, avtomatsko dvojni narekovaj. 
    $A Igor jun98; */
{
return freadstrings(fp,left,nleft,right,nright,"\"",1,"\"",1,from,to,maxnum,
                    buflength,begin,next);
}


int freadvarspec(FILE *fp,long from, long to,ssyst syst,
                        char **name,stack *ind,long *start,long *newdata);


int freadstrarg(FILE *fp,string *str,long from,long to,stack strst,
      ssyst syst,long *start,long *next)
    /* Iz datoteke fp prebere niz med mestoma from in to in ga zapise v
    *str. Ce lahko prebere niz, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebranim nizom. Niz je
    lahko podan na 2 nacina. Lahko so podane njegove vrednosti, v tem primeru
    se prebere s funkcijo freadstringsinv().
      Niz je lahko podan tudi s specifikacijo elementa nizovne
    spremenljivke na skladu strst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *str (ce se ustrezni element ne najde, se v *str skopira niz NULL).
    Na strst morajo biti nalozeni objekti tipa varholder. Specifikacija se
    prebere s funkcijo freadvarspec(), ki tudi postavi *next.
      Ce niz ni pravilno podan, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe.
    Argumenta start in next sta lahko tudi NULL.
    $A Igor jun99; */
{
char chr,*name=NULL;
varholder var=NULL;
string v;
stack indst=NULL;
long pos1,start1=-1,next1=-1;
int ret=0,place,buflength=30;
start1=next1=-1;
/* Najprej se poisce neprazni znak, ki je zacetek nizovnega argumenta (izpusti
se tudi do ena vejica): */
/*
start1=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
*/
start1=filenotchartoret(fp,"\n\r\t \0",5 /*vkljucno \0 */,from,to,15,&chr);
if (start1>0 && chr==',')
{
  start1=filenotcharto(fp,"\n\r\t \0",5 /*vkljucno \0 */,start1+1,to,15);
}
if (start1>0)
{
  chr=filereadchar(fp,start1);
  if (chr=='#')
  {
    freadvarspec(fp,start1+1,to,syst,&name,&indst,&pos1,&next1);
    if (start1>0 && name!=NULL)
    {
      place=findsortstackvar(strst,name,0,0);
      if (place>0)
        var=strst->s[place];
      if (var!=NULL)
      {
        v=varelst(var,indst);
        if (str==NULL)
        {
          start1=next1=-1; ret=-1;
        } else
        {
          *str=stringcopy(v);
        }
      } else ret=-1;
    } else
    {
      start1=next1=-1; ret=-1;
    }
  } else
  {
    if (str==NULL)
    {
      ret=-1;
    } else
    {
      stack st=NULL;
      disppointer((void **) str);
      /* $$$ Removed comma from the first string */
      *str=freadstringinv(fp,"\n\r\t \0",5,"\n\r\t, \0",6,
                       start1,to,buflength,&start1,&next1);
      if (start1<1 || next1<start1)
        ret=-1;
    }
  }
} else
{
  next1=-1;
  ret=-1;
}
if (ret<0)
  disppointer((void **) str);
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return ret;
}


int freadstrargs(FILE *fp,long from,long to,int maxnum,stack strst,
                    ssyst syst,stack *st,long *start,long *next)
    /* Iz datoteke fp prebere nize med mestoma from in to in jih polozi na
    sklad st. Prebere najvec maxnum nizov s funkcijo freadstrarg() in vrne
    stevilo dejansko prebranih nizov. Ce lahko prebere kak niz, zapise v *start
    zacetek prvega niza, v *next pa mesto, kjer se zacnejo nadaljnji podatki za
    zadnjim prebranim nizom. Nizi so lahko podani na 2 nacina. Lahko so podane 
    njihove vsebine,  lahko pa so podani tudi s specifikacijo elementa nizovne
    spremenljivke na skladu strst, ki sledi znaku '#' (vmes so lahko  
    presledki). V tem primeru se vzame za prebrani niz kopija elementa,
    katerega specifikacija je podana (ce se ustrezni element ne najde, se v
    *str skopira niz NULL). Na strst morajo biti nalozeni objekti tipa
    varholder. Specifikacija se prebere s funkcijo freadvarspec(), ki tudi
    postavi *next.
      Ce funkciija ne more prebrati nobenega niza, se v *start in *next zapise
    -1.
    Argumenta start in next sta lahko tudi NULL.
    $A Igor jul99; */
{
long pos,pos1,pos2,start1=-1,next1=-1;
int count=0;
char end=0,*str=NULL;
stack retst=NULL;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
if (st==NULL)
  end=1;
else
{
  if (*st==NULL)
    *st=newstack(5);
  retst=*st;
}
if (from>0 && to>=from)
{
  pos=from;
  while (!end)
  {
    freadstrarg(fp,&str,pos,to,strst,syst,&pos1,&pos2);
    if (pos1>0 && pos2>0)
    {
      ++ count;
      if (count==maxnum && maxnum>0)
        end=1;
      pushstack(retst,str);
      str=NULL;
      pos=pos2;
      if (pos>to)
        end=1;
      if (start1<1)
        start1=pos1;
      next1=pos2;
    } else
      end=1;
    if (count==maxnum)
      end=1;
  }
}
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return count;
}



long filebractoselect(FILE *fp,char brac1,char brac2,long from,
                      long to, int buflength,long *pos1,long *pos2)
    /* Nadomestek za filebracto(). Namesto lege 1. oklepaja v datoteki fp med
    from in to vrne lego 1. oklepaja, ki ne takoj sledi znaku '$'.
    $A Igor jul97; */
{
long ret=-1;
char end=0,prechar;
while (!end)
{
  /* Poiscemo oklepaj: */
  ret=filebracto(fp,brac1,brac2,from,to,buflength,pos1,pos2);
  if (*pos1<1 || *pos2<1)
    end=1;    /* Oklepaja nismo nasli, zato koncamo iskanje: */
  else
  {
    /* Nasli smo oklepaj, preverimo, ce je ustrezen (ce tik pred njim ne stoji
    znak '$'): */
    if (*pos1>1)
    {
      prechar=filereadchar(fp,*pos1-1);
      if (prechar=='$')
        from=*pos2+1;    /* oklepaj ni dober, iscemo naprej */
      else end=1; /* Oklepaj je dober, koncamo iskanje. */
    } else end=1;
  }
}
return ret;
}





int freadvarind(FILE *fp,long from, long to,ssyst syst,stack *ind,
    long *start,long *newdata)
    /* Prebere indekse (ce so podani) spremenljivke iz datoteke fp med
    mestoma from in to. Indekse nalozi na sklad *ind. syst je sistem za
    ovrednotenje izrazov, v katerem se ovrednotijo indeksi, ce so podani kot
    izrazi. Funkcija vrne 0, ce ne najde indeksov, drugace vrne 1. Ce niso
    podani indeksi, tudi postavi sklad *ind na NULL.
    V *start se zapise mesto v datoteki, kjer se indeksi zacnejo, v *newdata
    pa za eno vec kot je mesto zadnjega znaka, ki pripada indeksom.
    $A Igor maj98; */
{
int ret=1,*ip,index;
long pos,pos1,pos2;
int buflength=20;
char ch,indeces=0;
*start=*newdata=0;
if (ind==NULL)
{
  ret=0;
  errfunc0("freadvarind");
  fprintf(erf(),"Storage for variable dimensions not given.\n");
  errfunc2();
} else
{
  dispstackval(*ind);
}
if (ret)
{
  pos1=filenotcharto(fp,"\n\r\t \0",5 /*vkljucno \0 */,from,to,15);
  if (pos1>0)
  {
    *start=pos1;
    ch=filereadchar(fp,pos1);
    if (ch!='[')
      ret=0;
    else
    {
      /* Indeksi so podani in jih preberemo: */
      filebracto(fp,'[',']',pos1,to,buflength,&pos1,&pos2);
      if (pos1<1 || pos2<=pos1)
      {
        errfunc0("freadvarind");
        fprintf(erf(),"Index table not specified correctly.\n");
        errfunc2();
      }
      if (pos1>0 && pos2>pos1)
      {
        /* Navedeni so tudi indeksi: */
        pos=pos2-1; /* Poz. zaklepaja - 1 */
        *newdata=pos2+1;
        if (*ind==NULL)
          *ind=newstack(5);
        while (pos1>0)
        {
          index=(int) file1argvalto(fp,pos1+1,pos,syst,buflength,&pos1,&pos2);
          if (pos1>0 && pos2>0)
          {
            pos1=pos2;
            ip=malloc(sizeof(*ip));
            *ip=index;
            pushstack(*ind,ip);
            indeces=1;
          }
        }
      }
    }
  } else ret=0;
}
if (!indeces)
  dispstack(ind);
if (!ret)
{
  *start=*newdata=0;
}
return ret;
}

long freadvarindsimp(FILE *fp,long from, long to,ssyst syst,stack *ind)
    /* Prebere indekse spremenljivke (ce so podani) iz datoteke fp med
    mestoma from in to s funkcijo freadvarind(). Razlika je v tem, da ta
    funkcija vrne 0, ce ne najde imena spremenljivke, drugace pa vrne mesto
    v datoteki takoj za mestom, kjer se koncajo indeksi.
    $A Igor maj98; */
{
long start,newdata;
long ret=0;
if (freadvarind(fp,from,to,syst,ind,&start,&newdata))
  ret=newdata;
else
  ret=0;
return ret;
}




int freadvarspec(FILE *fp,long from, long to,ssyst syst,
                        char **name,stack *ind,long *start,long *newdata)
    /* Prebere ime spremenljivke in indekse (ce so podani) iz datoteke fp med
    mestoma from in to. Ime vrne v *name, indekse pa nalozi na sklad *ind.
    syst je sistem za ovrednotenje izrazov, v katerem se ovrednotijo indeksi,
    ce so podani kot izrazi. Funkcija vrne 0, ce ne najde imena spremenljivke,
    drugace vrne 1. Ce niso podani indeksi, postavi sklad *ind na NULL.
    V *start se zapise mesto v datoteki, kjer se specifikacija spremenljivke
    zacne, v *newdata pa za eno vec kot je mesto zadnjega znaka, ki pripada
    specifikaciji.
    $A Igor feb98; */
{
int ret=1,*ip,index;
long pos,pos1,pos2;
int length,buflength=20;
char ch,indeces=0;
*start=*newdata=0;
if (name==NULL)
{
  ret=0;
  errfunc0("freadvarspec");
  fprintf(erf(),"Storage for variable name not given.\n");
  errfunc2();
} else
{
  if (*name!=NULL)
  {
    free(*name);
    *name=NULL;
  }
}
if (ind==NULL)
{
  ret=0;
  errfunc0("freadvarspec");
  fprintf(erf(),"Storage for variable dimensions not given.\n");
  errfunc2();
} else
{
  dispstackval(*ind);
}
if (ret)
{
  /* $$$ added comma! */
  /*
  pos1=filenotcharto(fp,"\n\r\t ,",6 / vkljucno \0 /,from,to,15);
  */
  pos1=filenotchartoret(fp,"\n\r\t ",5 /*vkljucno \0 */,from,to,15,&ch);
  if (pos1>0 && ch==',')
  {
    pos1=filenotcharto(fp,"\n\r\t ",5 /*vkljucno \0 */,pos1+1,to,15);
  }
  if (pos1>0)
  {
    *start=pos1;
    ch=filereadchar(fp,pos1);
    if (ch=='\"')
    {
      /* Ime je podano v narekovajih: */
      ++pos1;
      pos2=filecharto(fp,"\"",1,pos1,to,buflength);
      if (pos2<pos1+1) /* Ime mora imeti koncno dolzino! */
        ret=0;
      else
      {
        *newdata=pos2+1;
        length=pos2-pos1;
        *name=malloc(length+1);
        fileread(*name,1,length,fp,pos1);
        (*name)[length]='\0';
        pos1=pos2+1;
      }
    } else
    {
      /* Ime ni podano v narekovajih: */
      /* $$ add comma: */
      pos2=filecharto(fp,"\n\r\t [{(,",8 /* '\0' vsebovan */,pos1+1,to,buflength);
      if (pos2<1)
        pos2=to+1;
      if (pos2>0)
      {
        *newdata=pos2;
        length=pos2-pos1;
        *name=malloc(length+1);
        fileread(*name,1,length,fp,pos1);
        (*name)[length]='\0';
        pos1=pos2;
      } else ret=0;
    }
    if (ret)
    {
      /* Dobili smo ime spremenljivke, preverimo se, ce so podani indeksi: */
      pos1=filenotcharto(fp,"\n\r\t ",5,pos1,to,buflength);
      if (pos1>0)
      {
        ch=filereadchar(fp,pos1);
        if (ch=='[')
        {
          filebracto(fp,'[',']',pos1,to,buflength,&pos1,&pos2);
          if (pos1<1 || pos2<=pos1)
          {
            errfunc0("freadvarspec");
            fprintf(erf(),"Index table not specified correctly.\n");
            errfunc2();
          } else
          {
            /* Navedeni so tudi indeksi: */
            pos=pos2-1; /* Poz. zaklepaja - 1 */
            *newdata=pos2+1;
            if (*ind==NULL)
              *ind=newstack(5);
            while (pos1>0)
            {
              index=(int) file1argvalto(fp,pos1+1,pos,syst,buflength,&pos1,&pos2);
              if (pos1>0 && pos2>0)
              {
                pos1=pos2;
                ip=malloc(sizeof(*ip));
                *ip=index;
                pushstack(*ind,ip);
                indeces=1;
              }
            }
          }
        }
      }
    }
  } else ret=0;
}
if (!indeces)
  dispstack(ind);
if (!ret)
{
  *start=*newdata=0;
}
/*  KONTROLNI IZPIS:
if (1)
{
  stack st=NULL;
  int i,*ip;
  printf("\n\nIndex stack for variable %s: ",*name);
  if (ind!=NULL)
    st=*ind;
  if (st!=NULL)
    if (st->n>0)
      for (i=1;i<=st->n;++i)
      {
        ip=st->s[i];
        if (ip!=NULL)
          printf("%i ",*ip);
      }
   printf("\n\n");
}
*/
return ret;
}



long freadvarspecsimp(FILE *fp,long from, long to,ssyst syst,
                        char **name,stack *ind)
    /* Prebere ime spremenljivke in indekse (ce so podani) iz datoteke fp med
    mestoma from in to s funkcijo freadvarspec(). Razlika je v tem, da ta
    funkcija vrne 0, ce ne najde imena spremenljivke, drugace pa vrne mesto
    v datoteki takoj za mestom, kjer se konca specifikacija spremenljivke.
    $A Igor feb98; */
{
long start,newdata;
long ret=0;
if (freadvarspec(fp,from,to,syst,name,ind,&start,&newdata))
  ret=newdata;
else
  ret=0;
return ret;
}




int freadvarspecarg(FILE *fp,long from, long to,stack strst,ssyst syst,
                        char **name,stack *ind,long *start,long *newdata)
    /* Prebere ime spremenljivke in indekse (ce so podani) iz datoteke fp med
    mestoma from in to. Ime vrne v *name, indekse pa nalozi na sklad *ind.
    syst je sistem za ovrednotenje izrazov, v katerem se ovrednotijo indeksi,
    ce so podani kot izrazi. Funkcija vrne 0, ce ne najde imena spremenljivke,
    drugace vrne 1. Ce niso podani indeksi, postavi sklad *ind na NULL.
    V *start se zapise mesto v datoteki, kjer se specifikacija spremenljivke
    zacne, v *newdata pa za eno vec kot je mesto zadnjega znaka, ki pripada
    specifikaciji.
     Ime spremenljivke se prebere kot nizovni argument, kar pomeni, da se lahko
    namesto eksplicitne navedbe imena sklicujemo na niz iz sistema nizovnih
    spremenljivk, ki so na skladu strst nalozene kot objekti tipa varholder. V
    tem primeru mora specifikacija nizovnega elementa slediti znaku '#' in mora
    OBVEZNO vsebovati indeksno specifikacijo v oglatih oklepajih, ceprav je ta
    prazna.
    $A Igor jul99; */
{
int ret=1,*ip,index;
long pos,pos1,pos2,start1=-1,newdata1=-1;
int length,buflength=20;
char ch,indeces=0;
if (name==NULL)
{
  ret=0;
  errfunc0("freadvarspecarg");
  fprintf(erf(),"Sorage for variable name not given.\n");
  errfunc2();
} else
{
  disppointer((void **) name);
}
if (ind==NULL)
{
  ret=0;
  errfunc0("freadvarspecarg");
  fprintf(erf(),"Storage for variable dimensions not given.\n");
  errfunc2();
} else
{
  dispstackval(*ind);
}
if (ret)
{
  pos1=filenotcharto(fp,"\n\r\t ",5 /* vkljucno \0 */ ,from,to,15);
  if (pos1>0)
  {
    start1=pos1;
    ch=filereadchar(fp,pos1);
    if (ch=='#')
    {
      freadstrarg(fp,name,pos1,to,strst,syst,&pos1,&pos2);
      if (pos1>0 && pos2>0)
      {
        start1=pos1;
        newdata1=pos2;
        pos1=pos2;
      } else
        ret=0;
    } else if (ch=='\"')
    {
      /* Ime je podano v narekovajih: */
      ++pos1;
      pos2=filecharto(fp,"\"",1,pos1,to,buflength);
      if (pos2<pos1+1) /* Ime mora imeti koncno dolzino! */
        ret=0;
      else
      {
        newdata1=pos2+1;
        length=pos2-pos1;
        *name=malloc(length+1);
        fileread(*name,1,length,fp,pos1);
        (*name)[length]='\0';
        pos1=pos2+1;
      }
    } else
    {
      /* Ime ni podano v narekovajih: */
      /* $$ Add comma: */
      pos2=filecharto(fp,"\n\r\t [{(,",8 /* '\0' vsebovan */,pos1+1,to,buflength);
      if (pos2<1)
        pos2=to+1;
      if (pos2>0)
      {
        newdata1=pos2;
        length=pos2-pos1;
        *name=malloc(length+1);
        fileread(*name,1,length,fp,pos1);
        (*name)[length]='\0';
        pos1=pos2;
      } else ret=0;
    }
    if (ret)
    {
      /* Dobili smo ime spremenljivke, preverimo se, ce so podani indeksi: */
      pos1=filenotcharto(fp,"\n\r\t ",5,pos1,to,buflength);
      if (pos1>0)
      {
        ch=filereadchar(fp,pos1);
        if (ch=='[')
        {
          filebracto(fp,'[',']',pos1,to,buflength,&pos1,&pos2);
          if (pos1<1 || pos2<=pos1)
          {
            errfunc0("freadvarspecarg");
            fprintf(erf(),"Index table not specified correctly.\n");
            errfunc2();
          } else
          {
            /* Navedeni so tudi indeksi: */
            pos=pos2-1; /* Poz. zaklepaja - 1 */
            newdata1=pos2+1;
            if (*ind==NULL)
              *ind=newstack(5);
            while (pos1>0)
            {
              index=(int) file1argvalto(fp,pos1+1,pos,syst,buflength,&pos1,&pos2);
              if (pos1>0 && pos2>0)
              {
                pos1=pos2;
                ip=malloc(sizeof(*ip));
                *ip=index;
                pushstack(*ind,ip);
                indeces=1;
              }
            }
          }
        }
      }
    }
  } else ret=0;
}
if (!indeces)
  dispstack(ind);
if (!ret)
{
  start1=newdata1=0;
}
/*  KONTROLNI IZPIS:
if (1)
{
  stack st=NULL;
  int i,*ip;
  printf("\n\nIndex stack for variable %s: ",*name);
  if (ind!=NULL)
    st=*ind;
  if (st!=NULL)
    if (st->n>0)
      for (i=1;i<=st->n;++i)
      {
        ip=st->s[i];
        if (ip!=NULL)
          printf("%i ",*ip);
      }
   printf("\n\n");
}
*/
if (start!=NULL)
  *start=start1;
if (newdata!=NULL)
  *newdata=newdata1;
return ret;
}


long freadvarspecargsimp(FILE *fp,long from, long to,stack strst,ssyst syst,
                        char **name,stack *ind)
    /* Prebere ime spremenljivke in indekse (ce so podani) iz datoteke fp med
    mestoma from in to s funkcijo freadvarspecarg(). Razlika je v tem, da ta
    funkcija vrne 0, ce ne najde imena spremenljivke, drugace pa vrne mesto
    v datoteki takoj za mestom, kjer se konca specifikacija spremenljivke.
    $A Igor jul99; */
{
long start,newdata;
long ret=0;

TRIN(121,1,"freadvarspecargsimp","Beginning of freadvarspecargsimp")


if (freadvarspecarg(fp,from,to,strst,syst,name,ind,&start,&newdata))
  ret=newdata;
else
  ret=0;

TROUT(121,1,"freadvarspecargsimp","End of freadvarspecargsimp")

return ret;
}




void freadvectorinvold(FILE *fp,vector *vec,char brac1,char brac2,long from,
       long to,ssyst syst)
    /* Prebere vektor vec v datoteki fp. Podatki o vektorju so v datoteki
    med mestoma from in to. Komponente so nastete v oklepajih brac1-brac2 in
    sicer na dva mozna nacina:
      1. Znotraj zunanjega oklepaja so notranji, v katerih sta po dve
    stevilki, 1. pove, za katero komponento gre, 2. pa je vrednost te
    komponente (stevili sta lahko med sabo loceni s katerimkoli znakom, ki ne
    more pripadati stevilu).
      2. Znotraj zunanjega oklepaja so po vrsti nastete komponente.
      Dimenzija vektorja je lahko podana pred 1. znakom brac1 med from in to.
    Lahko je podana tudi samo dimenzija brez komponent.
      Primeri:
    3 { {1 3.12} {2 5.3} {3 0.9999} }
    3 { 3.12 5.3 0.9999 }
    Ce ni podana dimenzija, se predpostavi trenutna
    dimenzija vektorja. Ce je dimenzija podana in se ne ujema s trenutno
    dimenzijo, se zbrise vsebina vektorja, le-ta pa se tvori na novo. Ce
    je podana kaksna komponenta z zaporedno stevilko vecjo od dimenzije,
    se ignorira. Ce je dimenzija 0, se le *vec zbrise in postavi na NULL.
    Pri branju so lahko vse stevilcne vrednosti nadomescene z matematicnimi
    izrazi oblike ${exp} (brez presledka med '$' in '{') ali imeni spremenljivk
    oblike $ var (z enim presledkom med '$' in imenom). V tem primeru se
    izrazi in spremenljivke ovrednotijo v sistemu syst.
    $A Igor <== jul97; */
{
long pos1,pos2,open,close,to1,start,l1;
int dim,buflength=20,buflength1=50,count,i;
double x;
char dimension=0,components=0,end=0;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
if (from>0 && to>from && vec!=NULL)
  {
  /* Poisce se 1. oklepaj. Ce se ne najde, to pomeni, da ne bomo brali komponent
  vektorja. */
  if (filebractoselect(fp,brac1,brac2,from,to,buflength1,&pos1,&pos2) >-1 && pos1>0
   && pos2>0)
    components=1;
  /* Poisce se dimenzija. Ce so navedene tudi komponente, mora biti dimenzija
  napisana pred njimi. Ce dimenzija ni podana, ostane dimenzija vektorja ista. */
  if (components)
    to1=pos1-1;
  else
    to1=to;
  /*
  x=filenumto(fp,from,to1,buflength,&start,&length);
  */
  x=file1argvalto(fp,from,to1,syst,buflength,&start,&l1);

  if (start>0 && l1>0)
  {
    dimension=1;
    dim= (int) round(x);
  }
  /* Ce je podana dimenzija in se ne ujema s trenutno dimenzijo, se tvori vektor
  na novo: */
  if (dimension)
  {
    if (*vec!=NULL)
      if ((*vec)->d!=dim)
        dispvector(vec);
    if (*vec==NULL && dim>0)
      *vec=getvector(dim);
  }

  /* Branje komponent: */
  if ( components && *vec!=NULL && (dim=(*vec)->d)>0 )
  {
    end=0;
    open=close=pos1;
    count=1;
    while (!end)
    {
      filebractoselect(fp,brac1,brac2,close+1,pos2-1,buflength,&open,&close);
      if (open<=0 || close<=open)
      {
        end=1;
        if (count==1)
        {
          /* Ce je to 1. izvrsitev zanke in znotraj oklepaja na pos1 in pos2 ne
          najdemo notranjih oklepajev niti dvopicja, potem beremo po vrsti
          komponente znotraj oklepaja na pos1 in pos2; Ce znotraj oklepaja na
          pos1 in pos2 najdemo dvopicje, preberemo ustrezno komponento
          in iscemo se druge komponente v oklepajih: */
          start=filecharto(fp,":",1,pos1+1,pos2-1,buflength);
          if (start>0)
          {
            /* Znotraj 1. oklepaja ni drugih oklepajev, je pa dvopicje. To pomeni,
            da imamo nastete posamezne komponente vektorja v zavitih
            oklepajih, ki jih ne obdaja se en oklepaj, zato je treba nanovo nas-
            taviti spremenljivke za izvajanje zanke while: */
            end=0;
            open=pos1; close=pos2;
            pos2=to+1;
          }  else
          {
            start=pos1;
            l1=start+1;
            i=1;
            while (i<=(*vec)->d && start>0 && l1>0 /* length>0 */ )
            {
              /*
              x=filenumto(fp,start+length,pos2-1,buflength,&start,&length);
              */
              x=file1argvalto(fp,l1,pos2-1,syst,buflength,&start,&l1);
              if (start>=0 && l1>=0 && i>0 && i<=(*vec)->d /* && length>0 */ )
              {
                (*vec)->v[i]=x;
              }
              ++i;
            }
          }
        }
      }
      if (!end)
      {
        /* Prebere se komponenta v oklepaju: */
        /*
        x=filenumto(fp,open+1,close-1,buflength,&start,&length);
        */
        x=file1argvalto(fp,open+1,close-1,syst,buflength,&start,&l1);
        if (start>0 && l1>0 /* length>0*/ )
        {
          i= (int) round(x);  /* Komponenta vektorja */
          /*
          x=filenumto(fp,l1,close-1,buflength,&start,&length);
          */
          x=file1argvalto(fp,l1,close-1,syst,buflength,&start,&l1);
          if (start>0 && l1>0 && i>0 && i<=(*vec)->d)
            (*vec)->v[i]=x; /* Vrednost komponente */
        }
      }
      ++ count;
    }
  }
}
}






void freadvectorinv(FILE *fp,vector *vec,char brac1,char brac2,long from,
       long to,ssyst syst,long *first,long *next)
    /* Prebere vektor vec v datoteki fp. Podatki o vektorju so v datoteki
    med mestoma from in to. Komponente so nastete v oklepajih brac1-brac2 in
    sicer na dva mozna nacina:
      1. Znotraj zunanjega oklepaja so notranji, v katerih sta po dve
    stevilki, 1. pove, za katero komponento gre, 2. pa je vrednost te
    komponente (stevili sta lahko med sabo loceni s katerimkoli znakom, ki ne
    more pripadati stevilu).
      2. Znotraj zunanjega oklepaja so po vrsti nastete komponente.
      Dimenzija vektorja je lahko podana pred 1. znakom brac1 med from in to.
    Lahko je podana tudi samo dimenzija brez komponent.
      Primeri:
    3 { {1 3.12} {2 5.3} {3 0.9999} }
    3 { 3.12 5.3 0.9999 }
    Ce ni podana dimenzija, se predpostavi trenutna dimenzija vektorja. Ce je
    dimenzija podana in se ne ujema s trenutno dimenzijo, se zbrise vsebina
    vektorja, le-ta pa se tvori na novo. Ce je podana kaksna komponenta z
    zaporedno stevilko vecjo od dimenzije, se ignorira. Ce je dimenzija 0, se
    le *vec zbrise in postavi na NULL. Pri branju so lahko vse stevilcne
    vrednosti nadomescene z matematicnimi izrazi oblike ${exp} (brez presledka
    med '$' in '{') ali imeni spremenljivk oblike $ var (z enim presledkom med
    '$' in imenom). V tem primeru se izrazi in spremenljivke ovrednotijo v
    sistemu syst.
      Funkcija v *first zapise pozicijo prvega znaka zapisa vektorja, v *next
    pa pozicijo 1. znaka po koncu zapisa vektorja. First in next sta lahko
    enaka NULL, v tem primeru se ne zapise pozicija zacetka in konca zapisa.
    $A Igor <== jul97 mar99; */
{
long pos1,pos2,open,close,start,l1,first1=-1,next1=-1;
int dim,buflength=20,buflength1=50,count,i;
double x;
char dimension=0,components=0,end=0,ch;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
if (from>0 && to>=from && vec!=NULL)
{
  /* Poisce se 1. neprazen znak: */
  first1=filenotcharto(fp," \n\r\t\0",5,from,to,8);
  if (first1<=0)
    end=1;
  else
  {
    /* Ta znak se prebere in preveri se, za kateri znak gre: */
    ch=filereadchar(fp,first1);
    if (ch==brac1)
    {
      /* Dimenzija ni podana, podane pa so komponente; poiscejo se pozicije
      oklepaja, v katerem so podane komponente: */
      if (filebracto(fp,brac1,brac2,first1,to,buflength1,&pos1,&pos2) >-1
       && pos1>0 && pos2>0)
      {
        components=1;
        next1=pos2+1;
      } else
      {
        end=1;
        next1=-1;
        first1=-1;
      }
    } else
    {
      /* Podana je dimenzija, ker 1. neprazni znak ni enak oklepaju brac1: */
      x=file1argvalto(fp,first1,to,syst,buflength,&start,&next1);
      if (start==first1)
      {
        dimension=1;
        dim= (int) round(x);
        /* Po branju dimenzije poiscemo oklepaje s komponentami: */
        pos1=filenotcharto(fp," \n\r\t\0",5,next1,to,8);
        if (pos1<0)
        {
          end=1;
        } else if (filebracto(fp,brac1,brac2,next1,to,buflength1,&pos1,&pos2) >
         -1 && pos1>0 && pos2>0)
        {
          components=1;
          next1=pos2+1;
        } else
          end=1;
      } else
      {
        /* Napaka: Morala bi biti podana dimenzija, vendar temu ni tako (recimo
        format ni ustrezen) */
        end=1;
        first1=next1=-1;
      }
    }
  }
  /* Ce je podana dimenzija in se ne ujema s trenutno dimenzijo, se tvori vektor
  na novo: */
  if (dimension)
  {
    if (*vec!=NULL)
      if ((*vec)->d!=dim)
        dispvector(vec);
    if (*vec==NULL && dim>0)
      *vec=getvector(dim);
  }
  /* Branje komponent: */
  if ( components && *vec!=NULL && (dim=(*vec)->d)>0 )
  {
    end=0;
    open=close=pos1;
    count=1;
    while (!end)
    {
      /* Poskusimo najti oklepaj, katerega 1. znak je tudi 1. neprazni znak
      od close+1 naprej: */
      filebractoselect(fp,brac1,brac2,close+1,pos2-1,buflength,&open,&close);
      /*
      posch=filenotcharto(fp," \n\r\t\0",5,close+1,pos2-1,buflength);
      if (posch!=open)
        open=close=-1;
      */
      if (close+1>next1)
        next1=close+1;
      if (open<=0 || close<=open)
      {
        end=1;
        if (count==1)
        {
          /* Ce je to 1. izvrsitev zanke in znotraj oklepaja na pos1 in pos2 ne
          najdemo notranjih oklepajev niti dvopicja, potem beremo po vrsti
          komponente znotraj oklepaja na pos1 in pos2; Ce znotraj oklepaja na
          pos1 in pos2 najdemo dvopicje, preberemo ustrezno komponento
          in iscemo se druge komponente v oklepajih: */
          start=filecharto(fp,":",1,pos1+1,pos2-1,buflength);
          if (start>0)
          {
            /* Znotraj 1. oklepaja ni drugih oklepajev, je pa dvopicje. To pomeni,
            da imamo nastete posamezne komponente vektorja v zavitih
            oklepajih, ki jih ne obdaja se en oklepaj, zato je treba nanovo nas-
            taviti spremenljivke za izvajanje zanke while: */
            end=0;
            open=pos1; close=pos2;
            pos2=to+1;
          }  else
          {
            start=pos1;
            l1=start+1;
            i=1;
            while (i<=(*vec)->d && start>0 && l1>0 /* length>0 */ )
            {
              x=file1argvalto(fp,l1,pos2-1,syst,buflength,&start,&l1);
              if (start>=0 && l1>=0 && i>0 && i<=(*vec)->d /* && length>0 */ )
              {
                (*vec)->v[i]=x;
              } else if (i>(*vec)->d)
              {
                errfunc0("freadvectorinv");
                sprintf(ers(),"Component %i exceeds vector dimension (%i).\n",
                  i,(*vec)->d);
                errfunc2();
              }
              ++i;
            }
          }
        }
      }
      if (!end)
      {
        /* Prebere se komponenta v oklepaju: */
        x=file1argvalto(fp,open+1,close-1,syst,buflength,&start,&l1);
        if (start>0 && l1>0 /* length>0*/ )
        {
          i= (int) round(x);  /* Komponenta vektorja */
          x=file1argvalto(fp,l1,close-1,syst,buflength,&start,&l1);
          if (start>0 && l1>0 && i>0 && i<=(*vec)->d)
            (*vec)->v[i]=x; /* Vrednost komponente */
          else  if (i>(*vec)->d)
          {
            errfunc0("freadvectorinv");
            sprintf(ers(),"Component %i exceeds vector dimension (%i).\n",
              i,(*vec)->d);
            errfunc2();
          }
        }
      }
      ++ count;
    }
  } else if (*vec==NULL || dim<1)
  {
    errfunc0("freadvectorinv");
    sprintf(ers(),"Can not read vector components, vector is not allocated.\n");
    errfunc2();

  }
}
if (first!=NULL)
  *first=first1;
if (next!=NULL)
  *next=next1;
}






void freadmatrixinvold(FILE *fp,matrix *mat,char brac1,char brac2,
       char separator,long from, long to,ssyst syst)
    /*     Iz datoteke fp se prebere matrika *mat med mestoma from in to v tej
    datoteki. Komponente matrike so podane med oklepajema brac1 in brac2
    in sicer na tri mozne nacine:
      1. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da sta
    1. dve stevilki v vsakem oklepaju stevilki vrstice in stolpca, tema sledi
    dvopicje, tretja stevilka pa je vrednost ustrezne komponente.
      2. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da je 1.
    stevilka v vsakem oklepaju stevilka vrstice, tej sledi dvopicje, nato pa
    so po vrsti nastete vse komponente matrike v tej vrstici.
      3. Lahko so podane po vrsti (po vrsticah) v osnovnem oklepaju
    brac1-brac2. V tem primeru znotraj osnovnega oklepaja ni potreben se
    notranji oklepaj.
    Dimenziji matrike sta podani pred osnovnim oklepajem brac1-brac2. Lahko
    sta podani samo dimenziji ali samo komponente. Ce je podana samo ena
    dimenzija, se privzame, da je druga enaka tej.
      Primeri:
    2 2 { {1 1: 1.1} {1 2: 1.3} {2 1: 0.5} {2 2: 0.6} }
    2 2 { {1: 1.1 1.3} {2: 0.5 0.6} }
    2 2 { 1.1  1.3  0.5  0.6 }
    Ce ni podana dimenzija, se predpostavi trenutna dimenzija matrike. Ce je
    dimenzija podana in se ne ujema s trenutno dimenzijo, se zbrise vsebina
    matrike, le-ta pa se tvori na novo. Ce je podana kaksna komponenta z
    zaporedno stevilko vecjo od dimenzije, se ignorira. Ce je dimenzija 0,
    se *mat zbrise in postavi na NULL.
    Pri branju so lahko vse stevilcne vrednosti nadomescene z matematicnimi
    izrazi oblike ${exp} (brez presledka med '$' in '{') ali imeni spremenljivk
    oblike $ var (z enim presledkom med '$' in imenom). V tem primeru se
    izrazi in spremenljivke ovrednotijo v sistemu syst.
    $A Igor jul97; */
{
long pos,pos1,pos2,to1,start,endarg,open,close;
int dim1,dim2,length,buflength=30,buflength1=100,line,col,i,j,count;
double x;
char dimension=0,components=0,end=0;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
if (from>0 && to>from && mat!=NULL)
  {
  /* Poisce se 1. oklepaj. Ce se ne najde, to pomeni, da ne bomo brali komponent
  matrike. */
  if (filebractoselect(fp,brac1,brac2,from,to,buflength1,&pos1,&pos2) >-1 && pos1>0
   && pos2>0)
    components=1;
  /* Poiscejo se dimenzije. Ce so navedene tudi komponente, morajo biti
  dimenzije napisane pred njimi. Ce dimenzije niso podane, ostanejo dimenzije
  matrike iste. Ce je podana le ena dimenzija, je druga dimenzija enaka tej. */
  if (components)
    to1=pos1-1;
  else
    to1=to;
  /* x=filenumto(fp,from,to1,buflength,&start,&length); */
  x=file1argvalto(fp,from,to1,syst,buflength,&start,&endarg);
  length=endarg-start;
  if (start>0 && length>0)
  {
    dimension=1;
    dim1= (int) round(x);
    start+=length;
    /* x=filenumto(fp,start,to1,buflength,&start,&length); */
    x=file1argvalto(fp,start,to1,syst,buflength,&start,&endarg);
    length=endarg-start;
    if (start>0 && length>0)
      dim2=(int) round(x);
    else
      dim2=dim1;
  }
  /* Ce je podana dimenzija in se ne ujema s trenutno dimenzijo, se tvori vektor
  na novo: */
  if (dimension)
  {
    if ( ! ( *mat!=NULL && (*mat)->d1==dim1 && (*mat)->d2==dim2 ) )
    {
      dispmatrix(mat);
      if (dim1>0 && dim2>0)
        *mat=getmatrix(dim1,dim2);
    }
  }
  /* Branje komponent: */
  if ( components && *mat!=NULL && (dim1=(*mat)->d1)>0 && (dim2=(*mat)->d2)>0 )
  {
    end=0;
    open=close=pos1;
    count=1;
    while (!end)
    {
      filebractoselect(fp,brac1,brac2,close+1,pos2-1,buflength,&open,&close);
      if (open<=0 || close<=open)
      {
        end=1;
        if (count==1)
        {
          /* Ce ni notranjega oklepaja, se preberejo komponente kar po vrsti, razen, ce
          oklepaj med pos1 in pos2 vsebuje tudi znak separator, kar pomeni, da so
          vseeno v oklepajih nastete posamezne komponente ali vrstice, le da okrog
          teh oklepajev ni zunanjega oklepaja: */
          start=filecharto(fp,":",1,pos1+1,pos2-1,buflength);
          if (start>0)
          {
            /* Znotraj 1. oklepaja ni drugih oklepajev, je pa dvopicje. To pomeni,
            da imamo nastete posamezne komponente ali vrstice matrike v zavitih
            oklepajih, ki jih ne obdaja se en oklepaj, zato je treba nanovo nas-
            taviti spremenljivke za izvajanje zanke while: */
            end=0;
            open=pos1; close=pos2;
            pos2=to+1;
          }  else
          {
            start=pos1;
            length=1;
            i=1; j=1;
            while (start>0 && length>0 && i<=(*mat)->d1 && j<=(*mat)->d2)
            {
              /* x=filenumto(fp,start+length,pos2-1,buflength,&start,&length); */
              x=file1argvalto(fp,start+length,pos2-1,syst,buflength,&start,&endarg);
              length=endarg-start;
              if (start>0 && length>0)
                (*mat)->m[i][j]=x;
              ++j;
              if (j>(*mat)->d2)
              {
                ++i;
                j=1;
              }
            }

          }
        }
      }
      if (!end)
      {
        /* str=":";
        str[0]=separator; */
        pos=filecharto(fp,/*str*/ &separator,1,open+1,close-1,buflength);
        if (pos>0)
        {
          /* Prebere se stevilka vrstice: */
          /* x=filenumto(fp,open+1,pos-1,buflength,&start,&length); */
          x=file1argvalto(fp,open+1,pos-1,syst,buflength,&start,&endarg);
          length=endarg-start;
          if (start>0 && length>0)
          {
            line=(int) x;
            /* Prebere se vrstica stolpca: */
            /* x=filenumto(fp,start+length,pos-1,buflength,&start,&length); */
            x=file1argvalto(fp,start+length,pos-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0)
              col=(int) x;
            else
              col=0;
          } else line=0;
        } else
        {
          line=col=0;
          pos=open+1;
        }
        if (line>0)
        {
          if (col>0)
          {
            /* Ce je podana tudi stevilka stolpca, preberemo komponento, ki je
            zapisana za znakom separator: */
            /* x=filenumto(fp,pos+1,close-1,buflength,&start,&length); */
            x=file1argvalto(fp,pos+1,close-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0 && line>0 && col>0 && line<=(*mat)->d1
            && col<=(*mat)->d2)
              (*mat)->m[line][col]=x;
          } else
          {
            /* Ce ni podana stevilka stolpca, beremo po vrsti elemente vrstice: */
            start=pos;
            length=1;
            j=1;
            while (start>0 && j<=(*mat)->d2)
            {
              /* x=filenumto(fp,start+length,close-1,buflength,&start,&length); */
              x=file1argvalto(fp,start+length,close-1,syst,buflength,&start,&endarg);
              length=endarg-start;
              if (start>0 && length>0 && line>0 && line<=(*mat)->d1)
                (*mat)->m[line][j]=x;
              ++j;
            }
          }
        } else
        {
          /* Ce tudi stevilka vrstice ni podana, kar beremo komponente po
          vrsti: */
          start=pos;
          length=1;
          i=1; j=1;
          while (start>0 && i<=(*mat)->d1 && j<=(*mat)->d2)
          {
            /* x=filenumto(fp,start+length,close-1,buflength,&start,&length); */
            x=file1argvalto(fp,start+length,close-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0)
              (*mat)->m[i][j]=x;
            ++j;
            if (j>(*mat)->d2)
            {
              ++i;
              j=1;
            }
          }
        }
      }
      ++ count;
    }
  }
}
}




void freadmatrixinv(FILE *fp,matrix *mat,char brac1,char brac2,
       char separator,long from, long to,ssyst syst,long *first,long *next)
    /*     Iz datoteke fp se prebere matrika *mat med mestoma from in to v tej
    datoteki. Komponente matrike so podane med oklepajema brac1 in brac2
    in sicer na tri mozne nacine:
      1. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da sta
    1. dve stevilki v vsakem oklepaju stevilki vrstice in stolpca, tema sledi
    dvopicje, tretja stevilka pa je vrednost ustrezne komponente.
      2. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da je 1.
    stevilka v vsakem oklepaju stevilka vrstice, tej sledi dvopicje, nato pa
    so po vrsti nastete vse komponente matrike v tej vrstici.
      3. Lahko so podane po vrsti (po vrsticah) v osnovnem oklepaju
    brac1-brac2. V tem primeru znotraj osnovnega oklepaja ni potreben se
    notranji oklepaj.
    Dimenziji matrike sta podani pred osnovnim oklepajem brac1-brac2. Lahko
    sta podani samo dimenziji ali samo komponente. Ce je podana samo ena
    dimenzija, se privzame, da je druga enaka tej.
      Primeri:
    2 2 { {1 1: 1.1} {1 2: 1.3} {2 1: 0.5} {2 2: 0.6} }
    2 2 { {1: 1.1 1.3} {2: 0.5 0.6} }
    2 2 { 1.1  1.3  0.5  0.6 }
    Ce ni podana dimenzija, se predpostavi trenutna dimenzija matrike. Ce je
    dimenzija podana in se ne ujema s trenutno dimenzijo, se zbrise vsebina
    matrike, le-ta pa se tvori na novo. Ce je podana kaksna komponenta z
    zaporedno stevilko vecjo od dimenzije, se ignorira. Ce je dimenzija 0,
    se *mat zbrise in postavi na NULL.
    Pri branju so lahko vse stevilcne vrednosti nadomescene z matematicnimi
    izrazi oblike ${exp} (brez presledka med '$' in '{') ali imeni spremenljivk
    oblike $ var (z enim presledkom med '$' in imenom). V tem primeru se
    izrazi in spremenljivke ovrednotijo v sistemu syst.
      Funkcija v *first zapise pozicijo prvega znaka zapisa matrike, v *next
    pa pozicijo 1. znaka po koncu zapisa matrike. First in next sta lahko
    enaka NULL, v tem primeru se ne zapise pozicija zacetka in konca zapisa.
    $A Igor jul97 mar99; */
{
long pos,pos1,pos2,start,endarg,open,close,first1=-1,next1=-1;
int dim1,dim2,length,buflength=30,buflength1=100,line,col,i,j,count;
double x;
char dimension=0,components=0,end=0,ch;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
if (from>0 && to>=from && mat!=NULL)
{
  /* Poisce se 1. neprazen znak: */
  first1=filenotcharto(fp," \n\r\t\0",5,from,to,8);
  if (first1<=0)
    end=1;
  else
  {
    /* Ta znak se prebere in preveri se, za kateri znak gre: */
    ch=filereadchar(fp,first1);
    if (ch==brac1)
    {
      /* Dimenzije niso podane, podane pa so komponente; poiscejo se pozicije
      oklepaja, v katerem so podane komponente: */
      if (filebracto(fp,brac1,brac2,first1,to,buflength1,&pos1,&pos2) >-1
       && pos1>0 && pos2>0)
      {
        components=1;
        next1=pos2+1;
      } else
      {
        end=1;
        next1=-1;
        first1=-1;
      }
    } else
    {
      /* Podane so dimenzije, ker 1. neprazni znak ni enak oklepaju brac1: */
      x=file1argvalto(fp,first1,to,syst,buflength,&start,&next1);
      if (start==first1)
      {
        dimension=1;
        dim1= (int) round(x);
        /* Preberemo se drugo dimenzijo, ce obstaja: */
        pos1=filenotcharto(fp," \n\r\t\0",5,next1,to,8);
        x=file1argvalto(fp,pos1,to,syst,buflength,&start,&pos2);
        if (pos1>0 && start==pos1)
        {
            /* Podana je tudi druga dimenzija: */
            next1=pos2;
            dim2= (int) round(x);
            pos1=filenotcharto(fp," \n\r\t\0",5,pos2,to,8);
        }        /* Po branju dimenzije poiscemo oklepaje s komponentami: */
        if (pos1<0)
        {
          end=1;
        } else if (filebracto(fp,brac1,brac2,next1,to,buflength1,&pos1,&pos2) >
         -1 && pos1>0 && pos2>0)
        {
          components=1;
          next1=pos2+1;
        } else
          end=1;
      } else
      {
        /* Napaka: Morale bi biti podane dimenzije, vendar temu ni tako (morda
        format ni ustrezen) */
        end=1;
        first1=next1=-1;
      }
    }
  }
  /* Ce je podana dimenzija in se ne ujema s trenutno dimenzijo, se tvori matrika
  na novo: */
  if (dimension)
  {
    if ( ! ( *mat!=NULL && (*mat)->d1==dim1 && (*mat)->d2==dim2 ) )
    {
      dispmatrix(mat);
      if (dim1>0 && dim2>0)
        *mat=getmatrix(dim1,dim2);
    }
  }
  /* Branje komponent: */
  if ( components && *mat!=NULL && (dim1=(*mat)->d1)>0 && (dim2=(*mat)->d2)>0 )
  {
    end=0;
    open=close=pos1;
    count=1;
    while (!end)
    {
      /* Poskusimo najti oklepaj, katerega 1. znak je tudi 1. neprazni znak
      od close+1 naprej: */
      filebractoselect(fp,brac1,brac2,close+1,pos2-1,buflength,&open,&close);
      /*
      posch=filenotcharto(fp," \n\r\t\0",5,close+1,pos2-1,buflength);
      if (posch!=open)
        open=close=-1;
      */
      if (close+1>next1)
        next1=close+1;
      if (open<=0 || close<=open)
      {
        end=1;
        if (count==1)
        {
          /* Ce ni notranjega oklepaja, se preberejo komponente kar po vrsti, razen, ce
          oklepaj med pos1 in pos2 vsebuje tudi znak separator, kar pomeni, da so
          vseeno v oklepajih nastete posamezne komponente ali vrstice, le da okrog
          teh oklepajev ni zunanjega oklepaja: */
          start=filecharto(fp,":",1,pos1+1,pos2-1,buflength);
          if (start>0)
          {
            /* Znotraj 1. oklepaja ni drugih oklepajev, je pa dvopicje. To pomeni,
            da imamo nastete posamezne komponente ali vrstice matrike v zavitih
            oklepajih, ki jih ne obdaja se en oklepaj, zato je treba nanovo nas-
            taviti spremenljivke za izvajanje zanke while: */
            end=0;
            open=pos1; close=pos2;
            pos2=to+1;
          }  else
          {
            start=pos1;
            length=1;
            i=1; j=1;
            while (start>0 && length>0 && i<=(*mat)->d1 && j<=(*mat)->d2)
            {
              /* x=filenumto(fp,start+length,pos2-1,buflength,&start,&length); */
              x=file1argvalto(fp,start+length,pos2-1,syst,buflength,&start,&endarg);
              length=endarg-start;
              if (start>0 && length>0)
                (*mat)->m[i][j]=x;
              ++j;
              if (j>(*mat)->d2)
              {
                ++i;
                j=1;
              }
            }

          }
        }
      }
      if (!end)
      {
        /* str=":";
        str[0]=separator; */
        pos=filecharto(fp,/*str*/ &separator,1,open+1,close-1,buflength);
        if (pos>0)
        {
          /* Prebere se stevilka vrstice: */
          /* x=filenumto(fp,open+1,pos-1,buflength,&start,&length); */
          x=file1argvalto(fp,open+1,pos-1,syst,buflength,&start,&endarg);
          length=endarg-start;
          if (start>0 && length>0)
          {
            line=(int) x;
            /* Prebere se vrstica stolpca: */
            /* x=filenumto(fp,start+length,pos-1,buflength,&start,&length); */
            x=file1argvalto(fp,start+length,pos-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0)
              col=(int) x;
            else
              col=0;
          } else line=0;
        } else
        {
          line=col=0;
          pos=open+1;
        }
        if (line>0)
        {
          if (col>0)
          {
            /* Ce je podana tudi stevilka stolpca, preberemo komponento, ki je
            zapisana za znakom separator: */
            /* x=filenumto(fp,pos+1,close-1,buflength,&start,&length); */
            x=file1argvalto(fp,pos+1,close-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0 && line>0 && col>0 && line<=(*mat)->d1
            && col<=(*mat)->d2)
              (*mat)->m[line][col]=x;
            else if (line>=(*mat)->d1 || col>=(*mat)->d2)
            {
              errfunc0("freadmatrixinv");
              sprintf(ers(),"Components (%i,%i) exceed matrix dimensions (%i,%i).\n",
              line,col,(*mat)->d1,(*mat)->d2);
              errfunc2();
            }
          } else
          {
            /* Ce ni podana stevilka stolpca, beremo po vrsti elemente vrstice: */
            start=pos;
            length=1;
            j=1;
            while (start>0 && j<=(*mat)->d2)
            {
              /* x=filenumto(fp,start+length,close-1,buflength,&start,&length); */
              x=file1argvalto(fp,start+length,close-1,syst,buflength,&start,&endarg);
              length=endarg-start;
              if (start>0 && length>0 && line>0 && line<=(*mat)->d1)
                (*mat)->m[line][j]=x;
              else if (line>=(*mat)->d1)
              {
                errfunc0("freadmatrixinv");
                sprintf(ers(),"Components (%i,%i) exceed matrix dimensions (%i,%i).\n",
                line,j,(*mat)->d1,(*mat)->d2);
                errfunc2();
              }
              ++j;
            }
          }
        } else
        {
          /* Ce tudi stevilka vrstice ni podana, kar beremo komponente po
          vrsti: */
          start=pos;
          length=1;
          i=1; j=1;
          while (start>0 && i<=(*mat)->d1 && j<=(*mat)->d2)
          {
            /* x=filenumto(fp,start+length,close-1,buflength,&start,&length); */
            x=file1argvalto(fp,start+length,close-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0)
              (*mat)->m[i][j]=x;
            ++j;
            if (j>(*mat)->d2)
            {
              ++i;
              j=1;
            }
          }
        }
      }
      ++ count;
    }
  } else if (*mat==NULL || dim1<1 || dim2<1)
  {
    errfunc0("freadmatrixinv");
    sprintf(ers(),"Can not read matrix components, matrix is not allocated.\n");
    errfunc2();
  }
}
if (first!=NULL)
  *first=first1;
if (next!=NULL)
  *next=next1;
}





void freadfieldinvold(FILE *fp,field *fld,char brac1,char brac2,
       char separator,long from, long to,ssyst syst)
    /*     Iz datoteke fp se prebere polje *fld med mestoma from in to v tej
    datoteki. Komponente polja so podane med oklepajema brac1 in brac2
    in sicer na tri mozne nacine:
      1. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da sta
    1. dve stevilki v vsakem oklepaju stevilki vrstice in stolpca, tema sledi
    dvopicje, tretja stevilka pa je vrednost ustrezne komponente.
      2. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da je 1.
    stevilka v vsakem oklepaju stevilka vrstice, tej sledi dvopicje, nato pa
    so po vrsti nastete vse komponente matrike v tej vrstici.
      3. Lahko so podane po vrsti (po vrsticah) v osnovnem oklepaju
    brac1-brac2. V tem primeru znotraj osnovnega oklepaja ni potreben se
    notranji oklepaj.
    Dimenziji polja sta podani pred osnovnim oklepajem brac1-brac2. Lahko
    sta podani samo dimenziji ali samo komponente. Ce je podana samo ena
    dimenzija, se privzame, da je druga enaka tej.
      Primeri:
    2 2 { {1 1: 1.1} {1 2: 1.3} {2 1: 0.5} {2 2: 0.6} }
    2 2 { {1: 1.1 1.3} {2: 0.5 0.6} }
    2 2 { 1.1  1.3  0.5  0.6 }
    Ce ni podana dimenzija, se predpostavi trenutna dimenzija polja. Ce je
    dimenzija podana in se ne ujema s trenutno dimenzijo, se zbrise vsebina
    polja, le-ta pa se tvori na novo. Ce je podana kaksna komponenta z
    zaporedno stevilko vecjo od dimenzije, se ignorira. Ce je dimenzija 0,
    se *fld zbrise in postavi na NULL.
    Pri branju so lahko vse stevilcne vrednosti nadomescene z matematicnimi
    izrazi oblike ${exp} (brez presledka med '$' in '{') ali imeni spremenljivk
    oblike $ var (z enim presledkom med '$' in imenom). V tem primeru se
    izrazi in spremenljivke ovrednotijo v sistemu syst.
    $A Igor jul97; Damjan jul98*/
{
long pos,pos1,pos2,to1,start,endarg,open,close;
int dim1,dim2,length,buflength=30,buflength1=100,line,col,i,j,count;
double x;
char dimension=0,components=0,end=0;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
if (from>0 && to>from && fld!=NULL)
  {
  /* Poisce se 1. oklepaj. Ce se ne najde, to pomeni, da ne bomo brali komponent
  polja. */
  if (filebractoselect(fp,brac1,brac2,from,to,buflength1,&pos1,&pos2) >-1 && pos1>0
   && pos2>0)
    components=1;
  /* Poiscejo se dimenzije. Ce so navedene tudi komponente, morajo biti
  dimenzije napisane pred njimi. Ce dimenzije niso podane, ostanejo dimenzije
  polja iste. Ce je podana le ena dimenzija, je druga dimenzija enaka tej. */
  if (components)
    to1=pos1-1;
  else
    to1=to;
  /* x=filenumto(fp,from,to1,buflength,&start,&length); */
  x=file1argvalto(fp,from,to1,syst,buflength,&start,&endarg);
  length=endarg-start;
  if (start>0 && length>0)
  {
    dimension=1;
    dim1= (int) round(x);
    start+=length;
    /* x=filenumto(fp,start,to1,buflength,&start,&length); */
    x=file1argvalto(fp,start,to1,syst,buflength,&start,&endarg);
    length=endarg-start;
    if (start>0 && length>0)
      dim2=(int) round(x);
    else
      dim2=dim1;
  }
  /* Ce je podana dimenzija in se ne ujema s trenutno dimenzijo, se tvori polje
  na novo: */
  if (dimension)
  {
    if ( ! ( *fld!=NULL && (*fld)->lin==dim1 && (*fld)->col==dim2 ) )
    {
      dispfield(fld);
      if (dim1>0 && dim2>0)
        *fld=getfield(dim1,dim2);
    }
  }
  /* Branje komponent: */
  if ( components && *fld!=NULL && (dim1=(*fld)->lin)>0 && (dim2=(*fld)->col)>0 )
  {
    end=0;
    open=close=pos1;
    count=1;
    while (!end)
    {
      filebractoselect(fp,brac1,brac2,close+1,pos2-1,buflength,&open,&close);
      if (open<=0 || close<=open)
      {
        end=1;
        if (count==1)
        {
          /* Ce ni notranjega oklepaja, se preberejo komponente kar po vrsti, razen, ce
          oklepaj med pos1 in pos2 vsebuje tudi znak separator, kar pomeni, da so
          vseeno v oklepajih nastete posamezne komponente ali vrstice, le da okrog
          teh oklepajev ni zunanjega oklepaja: */
          start=filecharto(fp,":",1,pos1+1,pos2-1,buflength);
          if (start>0)
          {
            /* Znotraj 1. oklepaja ni drugih oklepajev, je pa dvopicje. To pomeni,
            da imamo nastete posamezne komponente ali vrstice matrike v zavitih
            oklepajih, ki jih ne obdaja se en oklepaj, zato je treba nanovo nas-
            taviti spremenljivke za izvajanje zanke while: */
            end=0;
            open=pos1; close=pos2;
            pos2=to+1;
          }  else
          {
            start=pos1;
            length=1;
            i=1; j=1;
            while (start>0 && length>0 && i<=(*fld)->lin && j<=(*fld)->col)
            {
              /* x=filenumto(fp,start+length,pos2-1,buflength,&start,&length); */
              x=file1argvalto(fp,start+length,pos2-1,syst,buflength,&start,&endarg);
              length=endarg-start;
              if (start>0 && length>0)
                ((vector)((*fld)->st->s[i]))->v[j]=x;
              ++j;
              if (j>(*fld)->col)
              {
                ++i;
                j=1;
              }
            }

          }
        }
      }
      if (!end)
      {
        /* str=":";
        str[0]=separator; */
        pos=filecharto(fp,/*str*/ &separator,1,open+1,close-1,buflength);
        if (pos>0)
        {
          /* Prebere se stevilka vrstice: */
          /* x=filenumto(fp,open+1,pos-1,buflength,&start,&length); */
          x=file1argvalto(fp,open+1,pos-1,syst,buflength,&start,&endarg);
          length=endarg-start;
          if (start>0 && length>0)
          {
            line=(int) x;
            /* Prebere se vrstica stolpca: */
            /* x=filenumto(fp,start+length,pos-1,buflength,&start,&length); */
            x=file1argvalto(fp,start+length,pos-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0)
              col=(int) x;
            else
              col=0;
          } else line=0;
        } else
        {
          line=col=0;
          pos=open+1;
        }
        if (line>0)
        {
          if (col>0)
          {
            /* Ce je podana tudi stevilka stolpca, preberemo komponento, ki je
            zapisana za znakom separator: */
            /* x=filenumto(fp,pos+1,close-1,buflength,&start,&length); */
            x=file1argvalto(fp,pos+1,close-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0 && line>0 && col>0 && line<=(*fld)->lin
            && col<=(*fld)->col)
              ((vector)((*fld)->st->s[line]) )->v[col]=x;
          } else
          {
            /* Ce ni podana stevilka stolpca, beremo po vrsti elemente vrstice: */
            start=pos;
            length=1;
            j=1;
            while (start>0 && j<=(*fld)->col)
            {
              /* x=filenumto(fp,start+length,close-1,buflength,&start,&length); */
              x=file1argvalto(fp,start+length,close-1,syst,buflength,&start,&endarg);
              length=endarg-start;
              if (start>0 && length>0 && line>0 && line<=(*fld)->lin)
                ( (vector) ( (*fld)->st->s[line]) )->v[j]=x;
              ++j;
            }
          }
        } else
        {
          /* Ce tudi stevilka vrstice ni podana, kar beremo komponente po
          vrsti: */
          start=pos;
          length=1;
          i=1; j=1;
          while (start>0 && i<=(*fld)->lin && j<=(*fld)->col)
          {
            /* x=filenumto(fp,start+length,close-1,buflength,&start,&length); */
            x=file1argvalto(fp,start+length,close-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0)
              ((vector)((*fld)->st->s[i]))->v[j]=x;
            ++j;
            if (j>(*fld)->col)
            {
              ++i;
              j=1;
            }
          }
        }
      }
      ++ count;
    }
  }
}
}




void freadfieldinv(FILE *fp,field *fld,char brac1,char brac2,
       char separator,long from, long to,ssyst syst,long *first,long *next)
    /*     Iz datoteke fp se prebere polje *fld med mestoma from in to v tej
    datoteki. Komponente polja so podane med oklepajema brac1 in brac2
    in sicer na tri mozne nacine:
      1. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da sta
    1. dve stevilki v vsakem oklepaju stevilki vrstice in stolpca, tema sledi
    dvopicje, tretja stevilka pa je vrednost ustrezne komponente.
      2. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da je 1.
    stevilka v vsakem oklepaju stevilka vrstice, tej sledi dvopicje, nato pa
    so po vrsti nastete vse komponente matrike v tej vrstici.
      3. Lahko so podane po vrsti (po vrsticah) v osnovnem oklepaju
    brac1-brac2. V tem primeru znotraj osnovnega oklepaja ni potreben se
    notranji oklepaj.
    Dimenziji polja sta podani pred osnovnim oklepajem brac1-brac2. Lahko
    sta podani samo dimenziji ali samo komponente. Ce je podana samo ena
    dimenzija, se privzame, da je druga enaka tej.
      Primeri:
    2 2 { {1 1: 1.1} {1 2: 1.3} {2 1: 0.5} {2 2: 0.6} }
    2 2 { {1: 1.1 1.3} {2: 0.5 0.6} }
    2 2 { 1.1  1.3  0.5  0.6 }
    Ce ni podana dimenzija, se predpostavi trenutna dimenzija polja. Ce je
    dimenzija podana in se ne ujema s trenutno dimenzijo, se zbrise vsebina
    polja, le-ta pa se tvori na novo. Ce je podana kaksna komponenta z
    zaporedno stevilko vecjo od dimenzije, se ignorira. Ce je dimenzija 0,
    se *fld zbrise in postavi na NULL.
    Pri branju so lahko vse stevilcne vrednosti nadomescene z matematicnimi
    izrazi oblike ${exp} (brez presledka med '$' in '{') ali imeni spremenljivk
    oblike $ var (z enim presledkom med '$' in imenom). V tem primeru se
    izrazi in spremenljivke ovrednotijo v sistemu syst.
      Funkcija v *first zapise pozicijo prvega znaka zapisa polja, v *next
    pa pozicijo 1. znaka po koncu zapisa polja. First in next sta lahko
    enaka NULL, v tem primeru se ne zapise pozicija zacetka in konca zapisa.
    $A Igor jul97 mar99; Damjan jul98*/
{
long pos,pos1,pos2,start,endarg,open,close,first1=-1,next1=-1;
int dim1,dim2,length,buflength=30,buflength1=100,line,col,i,j,count;
double x;
char dimension=0,components=0,end=0,ch;
if (from==0)
  from=1;
if (to==0)
  to=flength(fp);
if (from>0 && to>=from && fld!=NULL)
{
  /* Poisce se 1. neprazen znak: */
  first1=filenotcharto(fp," \n\r\t\0",5,from,to,8);
  if (first1<=0)
    end=1;
  else
  {
    /* Ta znak se prebere in preveri se, za kateri znak gre: */
    ch=filereadchar(fp,first1);
    if (ch==brac1)
    {
      /* Dimenzije niso podane, podane pa so komponente; poiscejo se pozicije
      oklepaja, v katerem so podane komponente: */
      if (filebracto(fp,brac1,brac2,first1,to,buflength1,&pos1,&pos2) >-1
       && pos1>0 && pos2>0)
      {
        components=1;
        next1=pos2+1;
      } else
      {
        end=1;
        next1=-1;
        first1=-1;
      }
    } else
    {
      /* Podane so dimenzije, ker 1. neprazni znak ni enak oklepaju brac1: */
      x=file1argvalto(fp,first1,to,syst,buflength,&start,&next1);
      if (start==first1)
      {
        dimension=1;
        dim1= (int) round(x);
        /* Preberemo se drugo dimenzijo, ce obstaja: */
        pos1=filenotcharto(fp," \n\r\t\0",5,next1,to,8);
        x=file1argvalto(fp,pos1,to,syst,buflength,&start,&pos2);
        if (pos1>0 && start==pos1)
        {
            /* Podana je tudi druga dimenzija: */
            next1=pos2;
            dim2= (int) round(x);
            pos1=filenotcharto(fp," \n\r\t\0",5,pos2,to,8);
        }        /* Po branju dimenzije poiscemo oklepaje s komponentami: */
        if (pos1<0)
        {
          end=1;
        } else if (filebracto(fp,brac1,brac2,next1,to,buflength1,&pos1,&pos2) >
         -1 && pos1>0 && pos2>0)
        {
          components=1;
          next1=pos2+1;
        } else
          end=1;
      } else
      {
        /* Napaka: Morale bi biti podane dimenzije, vendar temu ni tako (morda
        format ni ustrezen) */
        end=1;
        first1=next1=-1;
      }
    }
  }
  /* Ce je podana dimenzija in se ne ujema s trenutno dimenzijo, se tvori polje
  na novo: */
  if (dimension)
  {
    if ( ! ( *fld!=NULL && (*fld)->lin==dim1 && (*fld)->col==dim2 ) )
    {
      dispfield(fld);
      if (dim1>0 && dim2>0)
        *fld=getfield(dim1,dim2);
    }
  }
  /* Branje komponent: */
  if ( components && *fld!=NULL && (dim1=(*fld)->lin)>0 && (dim2=(*fld)->col)>0 )
  {
    end=0;
    open=close=pos1;
    count=1;
    while (!end)
    {
      /* Poskusimo najti oklepaj, katerega 1. znak je tudi 1. neprazni znak
      od close+1 naprej: */
      filebractoselect(fp,brac1,brac2,close+1,pos2-1,buflength,&open,&close);
      /*
      posch=filenotcharto(fp," \n\r\t\0",5,close+1,pos2-1,buflength);
      if (posch!=open)
        open=close=-1;
      */
      if (close+1>next1)
        next1=close+1;
      if (open<=0 || close<=open)
      {
        end=1;
        if (count==1)
        {
          /* Ce ni notranjega oklepaja, se preberejo komponente kar po vrsti, razen, ce
          oklepaj med pos1 in pos2 vsebuje tudi znak separator, kar pomeni, da so
          vseeno v oklepajih nastete posamezne komponente ali vrstice, le da okrog
          teh oklepajev ni zunanjega oklepaja: */
          start=filecharto(fp,":",1,pos1+1,pos2-1,buflength);
          if (start>0)
          {
            /* Znotraj 1. oklepaja ni drugih oklepajev, je pa dvopicje. To pomeni,
            da imamo nastete posamezne komponente ali vrstice matrike v zavitih
            oklepajih, ki jih ne obdaja se en oklepaj, zato je treba nanovo nas-
            taviti spremenljivke za izvajanje zanke while: */
            end=0;
            open=pos1; close=pos2;
            pos2=to+1;
          }  else
          {
            start=pos1;
            length=1;
            i=1; j=1;
            while (start>0 && length>0 && i<=(*fld)->lin && j<=(*fld)->col)
            {
              /* x=filenumto(fp,start+length,pos2-1,buflength,&start,&length); */
              x=file1argvalto(fp,start+length,pos2-1,syst,buflength,&start,&endarg);
              length=endarg-start;
              if (start>0 && length>0)
                ((vector)((*fld)->st->s[i]))->v[j]=x;
              ++j;
              if (j>(*fld)->col)
              {
                ++i;
                j=1;
              }
            }

          }
        }
      }
      if (!end)
      {
        /* str=":";
        str[0]=separator; */
        pos=filecharto(fp,/*str*/ &separator,1,open+1,close-1,buflength);
        if (pos>0)
        {
          /* Prebere se stevilka vrstice: */
          /* x=filenumto(fp,open+1,pos-1,buflength,&start,&length); */
          x=file1argvalto(fp,open+1,pos-1,syst,buflength,&start,&endarg);
          length=endarg-start;
          if (start>0 && length>0)
          {
            line=(int) x;
            /* Prebere se vrstica stolpca: */
            /* x=filenumto(fp,start+length,pos-1,buflength,&start,&length); */
            x=file1argvalto(fp,start+length,pos-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0)
              col=(int) x;
            else
              col=0;
          } else line=0;
        } else
        {
          line=col=0;
          pos=open+1;
        }
        if (line>0)
        {
          if (col>0)
          {
            /* Ce je podana tudi stevilka stolpca, preberemo komponento, ki je
            zapisana za znakom separator: */
            /* x=filenumto(fp,pos+1,close-1,buflength,&start,&length); */
            x=file1argvalto(fp,pos+1,close-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0 && line>0 && col>0 && line<=(*fld)->lin
            && col<=(*fld)->col)
              ((vector)((*fld)->st->s[line]) )->v[col]=x;
          } else
          {
            /* Ce ni podana stevilka stolpca, beremo po vrsti elemente vrstice: */
            start=pos;
            length=1;
            j=1;
            while (start>0 && j<=(*fld)->col)
            {
              /* x=filenumto(fp,start+length,close-1,buflength,&start,&length); */
              x=file1argvalto(fp,start+length,close-1,syst,buflength,&start,&endarg);
              length=endarg-start;
              if (start>0 && length>0 && line>0 && line<=(*fld)->lin)
                ( (vector) ( (*fld)->st->s[line]) )->v[j]=x;
              ++j;
            }
          }
        } else
        {
          /* Ce tudi stevilka vrstice ni podana, kar beremo komponente po
          vrsti: */
          start=pos;
          length=1;
          i=1; j=1;
          while (start>0 && i<=(*fld)->lin && j<=(*fld)->col)
          {
            /* x=filenumto(fp,start+length,close-1,buflength,&start,&length); */
            x=file1argvalto(fp,start+length,close-1,syst,buflength,&start,&endarg);
            length=endarg-start;
            if (start>0 && length>0)
              ((vector)((*fld)->st->s[i]))->v[j]=x;
            ++j;
            if (j>(*fld)->col)
            {
              ++i;
              j=1;
            }
          }
        }
      }
      ++ count;
    }
  }
}
if (first!=NULL)
  *first=first1;
if (next!=NULL)
  *next=next1;
}




int freadvecargold(FILE *fp,vector *vec,char brac1,char brac2,long from,
       long to,stack vecst,ssyst syst,long *start,long *next)
    /* Iz datoteke fp prebere vektor med mestoma from in to in ga zapise v
    *vec. Ce lahko prebere vektor, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebranim vektorjem. Vektor je
    lahko podan na 2 nacina. Lahko so podane njegove vrednosti v zavitih
    oklepajih, v tem primeru se prebere s funkcijo freadvectorinv(), v *start
    se zapise pozicija zavitega oklepaja, v *next pa ena vec kot je pozicija
    zavitega zaklepaja. Kalkulator syst se v tem primeru uporabi za
    ovrednotenje matematicnih izrazov, ki lahko nastopajo namesto stevil (glej
    specifikacijo funkcije freadvectorinv()). brac1 in brac2 sta oklepaj in
    zaklepaj, ki se uporabljata pri navajanju komponent. Ce zaklepaj takoj
    sledi oklepaju brez vmesnega prostora, vrne funkcija negativno vrednost.
      Vektor je lahko podan tudi s specifikacijo elementa vektorske
    spremenljivke na skladu vecst, ki sledi znaku '$' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *vec (ce se ustrezni element ne najde, se v *vec skopira vektor NULL).
    Na vecst morajo biti nalozeni objekti tipa varholder. Specifikacija se
    prebere s funkcijo freadvarspec(), ki tudi postavi *next.
      Ce vektor ni pravilno podan, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je format ustrezen, a se vektorju *vec priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce je vektor podan z zavitiim
    oklepajem, kjer zaklepaj takoj sledi oklepaju, ali ce se na skladu vecst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul98; */
{
char chr,*name=NULL;
varholder var=NULL;
vector v;
stack indst=NULL;
long pos1,pos2;
int ret=0,place;
*next=-1;
/* Najprej se poisce neprazni znak, ki je zacetek vektorskega argumenta: */
*start=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
if (*start>0)
{
  chr=filereadchar(fp,*start);
  if (chr=='{')
  {
    filebracto(fp,'{','}',*start,to,100,&pos1,&pos2);
    if (pos1<0)
    {
      *next=*start=-1;
      ret=-1;
    } else if (pos2-pos1<2)
    {
      /* Ce zaklepaj takoj sledi oklepaju brez vmesnega praznega prostora,
      vrne funkcija -1: */
      *next=pos2+1;
      ret=-1;
    } else
    {
      /* Ce smo nasli oklepaja in je med njima kaj prostora, preberemo vektor
      s funkcijo freadvectorinv(): */
      *next=pos2+1;
      freadvectorinv(fp,vec,brac1,brac2,pos1+1,pos2-1,syst,NULL,NULL);
    }
  } else if (chr=='$')
  {
    freadvarspec(fp,*start+1,to,syst,&name,&indst,&pos1,next);
    if (pos1>0 && name!=NULL)
    {
      place=findsortstackvar(vecst,name,0,0);
      if (place>0)
        var=vecst->s[place];
      if (var!=NULL)
      {
        v=varelst(var,indst);
        copyvector0(v,vec);
      } else ret=-1;
    } else
    {
      *start=*next=-1; ret=-1;
    }
  } else
  {
    *start=*next=-1; ret=-1;
  }
} else
{
  *next=-1;
  ret=-1;
}
return ret;
}


int freadmatargold(FILE *fp,matrix *mat,char brac1,char brac2,char separator,
       long from,long to,stack matst,ssyst syst,long *start,long *next)
    /* Iz datoteke fp prebere matriko med mestoma from in to in jo zapise v
    *mat. Ce lahko prebere matriko, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebrano matriko. Matrika je
    lahko podana na 2 nacina. Lahko so podane njene vrednosti v zavitih
    oklepajih, v tem primeru se prebere s funkcijo freadmatrixinv(), v *start
    se zapise pozicija zavitega oklepaja, v *next pa ena vec kot je pozicija
    zavitega zaklepaja. Kalkulator syst se v tem primeru uporabi za
    ovrednotenje matematicnih izrazov, ki lahko nastopajo namesto stevil (glej
    specifikacijo funkcije freadmatrixinv()). brac1 in brac2 sta oklepaj in
    zaklepaj, ki se uporabljata pri navajanju komponent. Ce zaklepaj takoj
    sledi oklepaju brez vmesnega prostora, vrne funkcija negativno vrednost.
      Matrika je lahko podana tudi s specifikacijo elementa matricne
    spremenljivke na skladu matst, ki sledi znaku '$' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *mat (ce se ustrezni element ne najde, se v *mat skopira mtrika NULL).
    Na matst morajo biti nalozeni objekti tipa varholder. Specifikacija se
    prebere s funkcijo freadvarspec(), ki tudi postavi *next.
      Ce matrika ni pravilno podana, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je format ustrezen, a se matriki *mat priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce je matrika podana z zavitiim
    oklepajem, kjer zaklepaj takoj sledi oklepaju, ali ce se na skladu matst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul98; */
{
char chr,*name=NULL;
varholder var=NULL;
matrix v;
stack indst=NULL;
long pos1,pos2;
int ret=0,place;
*next=-1;
/* Najprej se poisce neprazni znak, ki je zacetek matricnega argumenta: */
*start=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
if (*start>0)
{
  chr=filereadchar(fp,*start);
  if (chr=='{')
  {
    filebracto(fp,'{','}',*start,to,100,&pos1,&pos2);
    if (pos1<0)
    {
      *next=*start=-1;
      ret=-1;
    } else if (pos2-pos1<2)
    {
      /* Ce zaklepaj takoj sledi oklepaju brez vmesnega praznega prostora,
      vrne funkcija -1: */
      *next=pos2+1;
      ret=-1;
    } else
    {
      /* Ce smo nasli oklepaja in je med njima kaj prostora, preberemo matriko
      s funkcijo freadmatrixinv(): */
      *next=pos2+1;
      freadmatrixinv(fp,mat,brac1,brac2,separator,pos1+1,pos2-1,syst,NULL,NULL);
    }
  } else if (chr=='$')
  {
    freadvarspec(fp,*start+1,to,syst,&name,&indst,&pos1,next);
    if (pos1>0 && name!=NULL)
    {
      place=findsortstackvar(matst,name,0,0);
      if (place>0)
        var=matst->s[place];
      if (var!=NULL)
      {
        v=varelst(var,indst);
        copymatrix0(v,mat);
      } else ret=-1;
    } else
    {
      *start=*next=-1; ret=-1;
    }
  } else
  {
    *start=*next=-1; ret=-1;
  }
} else
{
  *next=-1;
  ret=-1;
}
return ret;
}



void freadcounterinv(FILE *fp,counter *count,long from,long to,
            ssyst syst,long *start,long *next)
    /* Iz datoteke fp prebere vrednost stevca med mestoma from in to ter jo
    zapise v **count. Vrednost je lahko podana tudi z izrazom ali spremenljivko
    v sistemu za ovrednotenje izrazov syst. V *start se zapise pozicija zacetka
    stevca, v next pa pozicija takoj za koncem.
    $A Igor nov98 jul99; */
{
double x;
long start1,next1;
if (fp==NULL)
{
  errfunc0("freadcounterinv");
  fprintf(erf(),"Input file not open.\n");
  errfunc2();
} else if (count==NULL)
{
  errfunc0("freadcounterinv");
  fprintf(erf(),"Counter address not specified.\n");
  errfunc2();
} else
{
  x=file1argvalto(fp,from,to,syst,20,&start1,&next1);
  if (start1<=0 && next1<=0)
  {
    errfunc0("freadcounterinv");
    fprintf(erf(),"Value not specified properly.\n");
    errfunc2();
  } else
  {
    if (*count==NULL)
      *count=malloc(sizeof(**count));
    x=round(x);
    **count= (long) x;
  }
}
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
}


int freadcountarg(FILE *fp,counter *count,long from, long to,stack countst,
                 stack strst,ssyst syst,long *start,long *next)
    /* Iz datoteke fp prebere stevec med mestoma from in to in ga zapise v
    *count. Ce lahko prebere stevec, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebranim stevcem. Stevec je
    lahko podan na 2 nacina. Lahko je podana njegova vrednost, v tem primeru
    se prebere s funkcijo freadcounterinv(). Kalkulator syst se v tem primeru
    uporabi za ovrednotenje matematicnih izrazov, ki lahko nastopajo namesto
    stevil (glej specifikacijo funkcije freadcounterinv()).
      Stevec je lahko podan tudi s specifikacijo elementa stevcne
    spremenljivke na skladu countst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *count (ce se ustrezni element ne najde, se v *count skopira stevec NULL).
    Ime stevcne spremenljivke je lahko nadalje podano kot element nizovne
    spremenljivke, katerega specifikacija sledi znaku '#'. strst je sklad, na
    katerem morajo biti nalozene nizovne spremenljivke kot objekti tipa
    varholder. Na countst morajo biti nalozene stevcne spremenljivke kot
    objekti tipa varholder. Specifikacija se prebere s funkcijo
    freadvarspecrg(), ki tudi postavi *next.	
      Ce stevec ni pravilno podan, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je format ustrezen, a se stevcu *count priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce se na skladu countst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul99; */
{
char chr,*name=NULL;
varholder var=NULL;
counter v;
stack indst=NULL;
long pos1,start1=-1,next1=-1;
int ret=0,place;
start1=next1=-1;
/* Najprej se poisce neprazni znak, ki je zacetek stevcnega argumenta: */
start1=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
if (start1>0)
{
  chr=filereadchar(fp,start1);
  if (chr=='#')
  {
    freadvarspecarg(fp,start1+1,to,strst,syst,&name,&indst,&pos1,&next1);
    if (pos1>0 && name!=NULL)
    {
      place=findsortstackvar(countst,name,0,0);
      if (place>0)
        var=countst->s[place];
      if (var!=NULL)
      {
        v=varelst(var,indst);
        copycounter0(v,count);
      } else ret=-1;
    } else
    {
      start1=next1=-1; ret=-1;
    }
  } else
  {
    freadcounterinv(fp,count,start1,to,syst,&start1,&next1);
    if (start1<1 || next1<start1)
      ret=-1;
  }
} else
{
  next1=-1;
  ret=-1;
}
if (ret<0)
  disppointer((void **) count);
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return ret;
}




void freadscalarinv(FILE *fp,scalar *scal,long from,long to,ssyst syst,
    long *start,long *next)
    /* Iz datoteke fp prebere vrednost skalarja med mestoma from in to ter jo
    zapise v **scal. Vrednost je lahko podana tudi z izrazom ali spremenljivko
    v sistemu za ovrednotenje izrazov syst.
    $A Igor maj98; */
{
long start1,next1;
double x;
if (fp==NULL)
{
  errfunc0("freadscalarinv");
  fprintf(erf(),"Input file not open.\n");
  errfunc2();
} else if (scal==NULL)
{
  errfunc0("freadscalarinv");
  fprintf(erf(),"Scalar address not specified.\n");
  errfunc2();
} else
{
  x=file1argvalto(fp,from,to,syst,20,&start1,&next1);
  if (start1<=0 && next1<=0)
  {
    errfunc0("freadscalarinv");
    fprintf(erf(),"Value not specified properly.\n");
    errfunc2();
  } else
  {
    if (*scal==NULL)
      *scal=malloc(sizeof(**scal));
    **scal=x;
  }
}
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
}



int freadscalarg(FILE *fp,scalar *scal,long from, long to,stack scalst,
                 stack strst,ssyst syst,long *start,long *next)
    /* Iz datoteke fp prebere skalar med mestoma from in to in ga zapise v
    *scal. Ce lahko prebere skalar, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebranim skalarjem. Skalar je
    lahko podan na 2 nacina. Lahko je podana njegova vrednost, v tem primeru
    se prebere s funkcijo freadscalarinv(). Kalkulator syst se v tem primeru
    uporabi za ovrednotenje matematicnih izrazov, ki lahko nastopajo namesto
    stevil (glej specifikacijo funkcije freadscalarinv()).
      Skalar je lahko podan tudi s specifikacijo elementa skalarne
    spremenljivke na skladu scalst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *scal (ce se ustrezni element ne najde, se v *scal skopira skalar NULL).
    Ime skalarne spremenljivke je lahko nadalje podano kot element nizovne
    spremenljivke, katerega specifikacija sledi znaku '#'. strst je sklad, na
    katerem morajo biti nalozene nizovne spremenljivke kot objekti tipa
    varholder. Na scalst morajo biti nalozene skalarne spremenljivke kot
    objekti tipa varholder. Specifikacija se prebere s funkcijo
    freadvarspecrg(), ki tudi postavi *next.	
      Ce skalar ni pravilno podan, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je format ustrezen, a se skalarju *scal priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce se na skladu scalst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul99; */
{
char chr,*name=NULL;
varholder var=NULL;
scalar v;
stack indst=NULL;
long pos1,start1=-1,next1=-1;
int ret=0,place;
start1=next1=-1;
/* Najprej se poisce neprazni znak, ki je zacetek skalarnega argumenta: */
start1=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
if (start1>0)
{
  chr=filereadchar(fp,start1);
  if (chr=='#')
  {
    freadvarspecarg(fp,start1+1,to,strst,syst,&name,&indst,&pos1,&next1);
    if (pos1>0 && name!=NULL)
    {
      place=findsortstackvar(scalst,name,0,0);
      if (place>0)
        var=scalst->s[place];
      if (var!=NULL)
      {
        v=varelst(var,indst);
        copyscalar0(v,scal);
      } else ret=-1;
    } else
    {
      start1=next1=-1; ret=-1;
    }
  } else
  {
    freadscalarinv(fp,scal,start1,to,syst,&start1,&next1);
    if (start1<1 || next1<start1)
      ret=-1;
  }
} else
{
  next1=-1;
  ret=-1;
}
if (ret<0)
  disppointer((void **) scal);
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return ret;
}



int freadvecarg(FILE *fp,vector *vec,char brac1,char brac2,long from,
       long to,stack vecst,stack strst,ssyst syst,long *start,long *next)
    /* Iz datoteke fp prebere vektor med mestoma from in to in ga zapise v
    *vec. Ce lahko prebere vektor, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebranim vektorjem. Vektor je
    lahko podan na 2 nacina. Lahko so podane njegove vrednosti, v tem primeru
    se prebere s funkcijo freadvectorinv(). Kalkulator syst se v tem primeru
    uporabi za ovrednotenje matematicnih izrazov, ki lahko nastopajo namesto
    stevil (glej specifikacijo funkcije freadvectorinv()). brac1 in brac2 sta
    oklepaj in zaklepaj, ki se uporabljata pri navajanju komponent.
      Vektor je lahko podan tudi s specifikacijo elementa vektorske
    spremenljivke na skladu vecst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *vec (ce se ustrezni element ne najde, se v *vec skopira vektor NULL).
    Ime vektorske spremenljivke je lahko nadalje podano kot element nizovne
    spremenljivke, katerega specifikacija sledi znaku '#'. strst je sklad, na
    katerem morajo biti nalozene nizovne spremenljivke kot objekti tipa
    varholder. Na vecst morajo biti nalozene vektorske spremenljivke kot
    objekti tipa varholder. Specifikacija se prebere s funkcijo
    freadvarspecrg(), ki tudi postavi *next.	
      Ce vektor ni pravilno podan, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je format ustrezen, a se vektorju *vec priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce je vektor podan z zavitiim
    oklepajem, kjer zaklepaj takoj sledi oklepaju, ali ce se na skladu vecst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul98 mar99 jul99; */
{
char chr,*name=NULL;
varholder var=NULL;
vector v;
stack indst=NULL;
long pos1,start1=-1,next1=-1;
int ret=0,place;
start1=next1=-1;
/* Najprej se poisce neprazni znak, ki je zacetek vektorskega argumenta: */
start1=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
if (start1>0)
{
  chr=filereadchar(fp,start1);
  if (chr=='#')
  {
    freadvarspecarg(fp,start1+1,to,strst,syst,&name,&indst,&pos1,&next1);
    if (pos1>0 && name!=NULL)
    {
      place=findsortstackvar(vecst,name,0,0);
      if (place>0)
        var=vecst->s[place];
      if (var!=NULL)
      {
        v=varelst(var,indst);
        copyvector0(v,vec);
      } else ret=-1;
    } else
    {
      start1=next1=-1; ret=-1;
    }
  } else
  {
    freadvectorinv(fp,vec,brac1,brac2,start1,to,syst,&start1,&next1);
    if (start1<1 || next1<start1)
      ret=-1;
  }
} else
{
  next1=-1;
  ret=-1;
}
if (ret<0)
  dispvector(vec);
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return ret;
}


int freadvecargbrac(FILE *fp,vector *vec,char brac1,char brac2,long from,
       long to,stack vecst,stack strst,ssyst syst,long *start,long *next)
    /* Naredi isto kot freadvecarg, s to razliko, da mora biti vektor podan v
    zavitih oklepajih.
    $A Igor mar99 jul99; */
{
int ret=0;
long pos1,pos2,start1=-1,next1=-1;
char chr;
/* Najprej se poisce neprazni znak, ki mora biti zaviti oklepaj: */
start1=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
if (start1>0)
{
  chr=filereadchar(fp,start1);
  if (chr=='{')
  {
    filebracto(fp,'{','}',start1,to,100,&pos1,&pos2);
    if (pos1<0)
    {
      next1=start1=-1;
      ret=-1;
    } else if (pos2-pos1<2)
    {
      /* Ce zaklepaj takoj sledi oklepaju brez vmesnega praznega prostora,
      vrne funkcija -1: */
      start1=pos1; next1=pos2+1;
      ret=-1;
    } else
    {
      /* Ce smo nasli oklepaja in je med njima kaj prostora, preberemo vektor
      s funkcijo freadvecarg(): */
      start1=pos1; next1=pos2+1;
      freadvecarg(fp,vec,brac1,brac2,pos1+1,pos2-1,vecst,strst,syst,
       &pos1,&pos2);
      if (pos1<1 || pos1<start1)
        ret=-1;
    }
  } else 
  {
    /* start1=next1=-1; ret=-1; */
    freadvecarg(fp,vec,brac1,brac2,start1,to,vecst,strst,syst,
       &start1,&next1);
    if (start1<1 || next1<1)
      ret=-1;
  }
} else
{
  start1=next1=-1;
  ret=-1;
}
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return ret;
}


int freadmatarg(FILE *fp,matrix *mat,char brac1,char brac2,char separator,
       long from,long to,stack matst,stack strst,ssyst syst,long *start,long *next)
    /* Iz datoteke fp prebere matriko med mestoma from in to in jo zapise v
    *mat. Ce lahko prebere matriko, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebrano matriko. Matrika je
    lahko podana na 2 nacina. Lahko so podane njene vrednosti, v tem primeru
    se prebere s funkcijo freadmatrixinv(). Kalkulator syst se v tem primeru
    uporabi za ovrednotenje matematicnih izrazov, ki lahko nastopajo namesto
    stevil (glej specifikacijo funkcije freadmatrixinv()). brac1 in brac2 sta
    oklepaj in zaklepaj, ki se uporabljata pri navajanju komponent.
      Matrika je lahko podana tudi s specifikacijo elementa matricne
    spremenljivke na skladu matst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *mat (ce se ustrezni element ne najde, se v *mat skopira matriko NULL).
    Ime matricne spremenljivke je lahko nadalje podano kot element nizovne
    spremenljivke, katerega specifikacija sledi znaku '#'. strst je sklad, na
    katerem morajo biti nalozene nizovne spremenljivke kot objekti tipa
    varholder. Na matst morajo biti nalozene matricne spremenljivke kot objekti
    tipa varholder. Specifikacija se prebere s funkcijo freadvarspecrg(), ki
    tudi postavi *next.	
      Ce matrika ni pravilno podana, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je format ustrezen, a se matriki *mat priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce je matrika podana z zavitiim
    oklepajem, kjer zaklepaj takoj sledi oklepaju, ali ce se na skladu matst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul98 mar99; */
{
char chr,*name=NULL;
varholder var=NULL;
matrix v;
stack indst=NULL;
long pos1,start1=-1,next1=-1;
int ret=0,place;
start1=next1=-1;
/* Najprej se poisce neprazni znak, ki je zacetek matricnega argumenta: */
start1=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
if (start1>0)
{
  chr=filereadchar(fp,start1);
  if (chr=='#')
  {
    freadvarspecarg(fp,start1+1,to,strst,syst,&name,&indst,&pos1,&next1);
    if (pos1>0 && name!=NULL)
    {
      place=findsortstackvar(matst,name,0,0);
      if (place>0)
        var=matst->s[place];
      if (var!=NULL)
      {
        v=varelst(var,indst);
        copymatrix0(v,mat);
      } else ret=-1;
    } else
    {
      start1=next1=-1; ret=-1;
    }
  } else
  {
    freadmatrixinv(fp,mat,brac1,brac2,separator,start1,to,syst,&start1,&next1);
    if (start1<1 || next1<start1)
      ret=-1;
  }
} else
{
  next1=-1;
  ret=-1;
}
/*
if (ret<0)
  dispmatrix(mat);
*/
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return ret;
}



int freadmatargbrac(FILE *fp,matrix *mat,char brac1,char brac2,char separator,
       long from,long to,stack matst,stack strst,ssyst syst,long *start,long *next)
    /* Naredi isto kot freadmatarg, s to razliko, da mora biti matrika podana v
    zavitih oklepajih.
    $A Igor mar99; */
{
int ret=0;
long pos1,pos2,start1=-1,next1=-1;
char chr;
/* Najprej se poisce neprazni znak, ki mora biti zaviti oklepaj: */
start1=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
if (start1>0)
{
  chr=filereadchar(fp,start1);
  if (chr=='{')
  {
    filebracto(fp,'{','}',start1,to,100,&pos1,&pos2);
    if (pos1<0)
    {
      next1=start1=-1;
      ret=-1;
    } else if (pos2-pos1<2)
    {
      /* Ce zaklepaj takoj sledi oklepaju brez vmesnega praznega prostora,
      vrne funkcija -1: */
      start1=pos1; next1=pos2+1;
      ret=-1;
    } else
    {
      /* Ce smo nasli oklepaja in je med njima kaj prostora, preberemo matriko
      s funkcijo freadmatarg(): */
      start1=pos1; next1=pos2+1;
      freadmatarg(fp,mat,brac1,brac2,separator,pos1+1,pos2-1,matst,strst,syst,&pos1,&pos2);
      if (pos1<1 || pos1<start1)
        ret=-1;
    }
  } else 
  {
    /* start1=next1=-1; ret=-1; */
    freadmatarg(fp,mat,brac1,brac2,separator,start1,to,matst,strst,syst,
       &start1,&next1);
    if (start1<1 || next1<1)
      ret=-1;
  }
} else
{
  start1=next1=-1;
  ret=-1;
}
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return ret;
}



int freadfldarg(FILE *fp,field *fld,char brac1,char brac2,char separator,
       long from,long to,stack fldst,stack strst,ssyst syst,long *start,
       long *next)
    /* Iz datoteke fp prebere polje med mestoma from in to in ga zapise v
    *fld. Ce lahko prebere polje, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebrano polje. Polje je
    lahko podano na 2 nacina. Lahko so podane njegove vrednosti, v tem primeru
    se prebere s funkcijo freadfieldinv(). Kalkulator syst se v tem primeru
    uporabi za ovrednotenje fldefldicnih izrazov, ki lahko nastopajo namesto stevil (glej
    specifikacijo funkcije freadfieldinv()). brac1 in brac2 sta oklepaj in
    zaklepaj, ki se uporabljata pri navajanju komponent.
      Polje je lahko podan tudi s specifikacijo elementa poljske
    spremenljivke na skladu fldst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *fld (ce se ustrezni element ne najde, se v *fld skopira polje NULL).
    Ime poljske spremenljivke je lahko nadalje podano kot element nizovne
    spremenljivke, katerega specifikacija sledi znaku '#'. strst je sklad, na
    katerem morajo biti nalozene nizovne spremenljivke kot objekti tipa
    varholder. Na fldst morajo biti nalozene poljske spremenljivke kot objekti
    tipa varholder. Specifikacija se prebere s funkcijo freadvarspecrg(), ki
    tudi postavi *next.	
      Ce polje ni pravilno podana, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je forfld ustrezen, a se polju *fld priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce je polje podano z zavitiim
    oklepajem, kjer zaklepaj takoj sledi oklepaju, ali ce se na skladu fldst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul98 mar99; */
{
char chr,*name=NULL;
varholder var=NULL;
field v;
stack indst=NULL;
long pos1,start1=-1,next1=-1;
int ret=0,place;
start1=next1=-1;
/* Najprej se poisce neprazni znak, ki je zacetek poljskega argumenta: */
start1=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
if (start1>0)
{
  chr=filereadchar(fp,start1);
  if (chr=='#')
  {
    freadvarspecarg(fp,start1+1,to,strst,syst,&name,&indst,&pos1,&next1);
    if (pos1>0 && name!=NULL)
    {
      place=findsortstackvar(fldst,name,0,0);
      if (place>0)
        var=fldst->s[place];
      if (var!=NULL)
      {
        v=varelst(var,indst);
        copyfield(v,fld);
      } else ret=-1;
    } else
    {
      start1=next1=-1; ret=-1;
    }
  } else
  {
    freadfieldinv(fp,fld,brac1,brac2,separator,start1,to,syst,&start1,&next1);
    if (start1<1 || next1<start1)
      ret=-1;
  }
} else
{
  next1=-1;
  ret=-1;
}
/*
if (ret<0)
  dispfield(fld);
*/
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return ret;
}



int freadfldargbrac(FILE *fp,field *fld,char brac1,char brac2,char separator,
       long from,long to,stack fldst,stack strst,ssyst syst,long *start,
       long *next)
    /* Naredi isto kot freadfldarg, s to razliko, da mora biti polje podano v
    zavitih oklepajih.
    $A Igor mar99; */
{
int ret=0;
long pos1,pos2,start1=-1,next1=-1;
char chr;
/* Najprej se poisce neprazni znak, ki mora biti zaviti oklepaj: */
start1=filenotcharto(fp,", \n\r\t\0",6,from,to,5);
if (start1>0)
{
  chr=filereadchar(fp,start1);
  if (chr=='{')
  {
    filebracto(fp,'{','}',start1,to,100,&pos1,&pos2);
    if (pos1<0)
    {
      next1=start1=-1;
      ret=-1;
    } else if (pos2-pos1<2)
    {
      /* Ce zaklepaj takoj sledi oklepaju brez vmesnega praznega prostora,
      vrne funkcija -1: */
      start1=pos1; next1=pos2+1;
      ret=-1;
    } else
    {
      /* Ce smo nasli oklepaja in je med njima kaj prostora, preberemo polje
      s funkcijo freadfldarg(): */
      start1=pos1; next1=pos2+1;
      freadfldarg(fp,fld,brac1,brac2,separator,pos1+1,pos2-1,fldst,strst,syst,
       &pos1,&pos2);
      if (pos1<1 || pos1<start1)
        ret=-1;
    }
  } else 
  {
    /* start1=next1=-1; ret=-1; */
    freadfldarg(fp,fld,brac1,brac2,separator,start1,to,fldst,strst,syst,
       &start1,&next1);
    if (start1<1 || next1<1)
      ret=-1;
  }
} else
{
  start1=next1=-1;
  ret=-1;
}
if (start!=NULL)
  *start=start1;
if (next!=NULL)
  *next=next1;
return ret;
}





