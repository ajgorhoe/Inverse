
#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>


#include <mtypes.h>
#include <st.h>
#include <rand.h>
#include <vec.h>
#include <mat.h>
#include <spmat.h>


/* OPOMBE:
  Razprsene matrike in vektorji imajo dva rezima delovanja. Prvi je sinhroni
rezim, kjer so vse operacije nad indeksno tabelo in tabelo elementov hkratne,
v tem nacinu je stevilo alociranih mest za tabelo elementov vsaj taksno, kot
je polje r v indeksni tabeli, ki ustreza minimumu alociranega prostora za
tabelo indeksov). Drugi nacin dela je asinhroni nacin, v tem nacinu se
operacije nad indeksno tabelo izvajajo neodvisno od operacij nad tabelo
vrednosti (tipicen primer je zajemanje strukture togostne matrike pred
asembliranjem), temu pa obicajno sledi faza sinhronizacije, kjer se alocira
prostor za vrednosti, ki ustreza alociranemu prostoru v indeksni tabeli (ta
faza mora biti izvedena pred prirejanjem elementov). Pri razprsenih matrikah se 
lahko tabela info uporabi za shranjevanje informacije o tem, koliko mest je
rezervirano pri posameznih vrsticah matrike za vrednosti elementov, kar omogoca
hitrejso sinhronizacijo.
  V splosnem je tam, kjer se vsakic sproti ugotavlja struktura matrike (t.j.
struktura matrike se spreminja ali pa matriko med ponovnimi sestavljanji
brisemo, da prihranimo cas), bolj ugodno uporabiti asinhroni rezim pri
ugotavljanju strukture, pri nadaljnjih operacijah pa sinhronega.
  Funkcije za asinhroni rezim delovanja imajo navadno v imenu besedico tab.
Pri vseh sinhronih operacijah se pricakuje, da so elementi razprsenih
vektorjev sortirani po narascajocem vrstnem redu indeksov (t.j. mest v polnem
vektorju).
*/


            /******************************************/
            /*                                        */
            /*   OPERACIJE NAD RAZPRSENIMI VEKTORJI   */
            /*                                        */
            /******************************************/



spvec getspvec(int excess,int r)
    /* Naredi razprsen vektor, pripravljen za polnjenje indeksne tabele in
    elementov. excess je parameter, ki se zapise v polje ex indeksne tabele
    (t.j. presezek mest pri realokaciji), r pa je stevilo mest v indeksni
    tabeli in v tabeli vrednosti, ki se alocirajo ob klicu funkcije.
    $A Igor avg00; */
{
spvec ret;
if (excess<0)
  excess=1;
ret=malloc(sizeof(*ret));
ret->it=newindtab(excess,r);
if (r<1)
  ret->v=NULL;
else
{
  ret->v=malloc(sizeof(*(ret->v))*r);
  --ret->v;
}
return ret;
}


spvec getspvectab(int excess,int r)
    /* Naredi razprsen vektor, pripravljen za polnjenje indeksne tabele, t.j.
    brez alociranega prostora za vrednosti elementov, in vrne njegov kazalec.
    excess je parameter, ki se zapise v polje ex indeksne tabele (t.j. presezek
    mest pri realokaciji), r pa je stevilo mest v indeksni tabeli, ki se
    alocirajo ob klicu funkcije.
    $A Igor avg00; */
{
spvec ret;
if (excess<0)
  excess=1;
ret=malloc(sizeof(*ret));
ret->it=newindtab(excess,r);
ret->v=NULL;
return ret;
}


void syncspvectab(spvec vec)
    /* Po potrebi realocira tabelo vrednosti vec->v, tako da je za tabelo
    vrednosti alociranih enako stevilo mest kot za tabelo indeksov (torej
    vec->it->r). SLABOST uporabe te funkcije je v tem, da se lahko vec->v
    realocira po nepotrebnem, saj funkcija ne more vedeti, ce ni morda za
    tabelo ze alociranih dovolj mest.
    $A Igor avg00; */
{
if (vec!=NULL)
  if (vec->it!=NULL)
  {
    if (vec->it->r>0)
    {
      if (vec->v!=NULL)
        ++vec->v;
      vec->v=realloc(vec->v,vec->it->r*sizeof(*(vec->v)));
      --vec->v;
    } else if (vec->v!=NULL)
    {
      free(++(vec->v));
      vec->v=NULL;
    }
  }
}


void dispspvec(spvec *vec)
    /* Zbrise razprseni vektor *vec in ga postavi na NULL.
    $A Igor avg00; */
{
spvec v;
if (vec!=NULL)
  if ((v=*vec)!=NULL)
  {
    dispindtab(&(v->it));
    if (v->v!=NULL)
      free(v->v+1);
    free(v);
    *vec=NULL;
  }
}


void resizespvec(spvec *pvec,int ex,int r,int n)
    /* Po potrebi popravi velikost alociranega prostora v razprsenem vektorju
    *pvec. Ce je r vecji od 0, se poskrbi, da je alociranega prostora natancno
    za r elementov. Ce je v tem primeru n vecji od r, se najprej r postavi na
    n. Ce je n vecji od 0, se stevilo elementov (*pvec)->it->n postavi na n, po
    potrebi se poveca stevilo alociranih mest (ce jih je manj kot n), se pa to
    ne zmanjsa. Ce je n enak 0, se stevilo elementov spremeni (zmanjsa) le, ce
    postane stevilo alociranih mest manjse od stavila elementov - v tem primeru
    se stevilo elementov postavi na stevilo alociranih mest. Ce je ex vecji od
    0, se (*pvec)->it->ex postavi na ex.
      Razlicne moznosti so:
    n>0, r=0: Stevilo elementov se postavi na n, stevilo alociranih mest se
      poveca, ce je to potrebno (ce je trenutno manj kot n), v nobenem primeru
      pa se ne zmanjsa.
    n>0, r>0: Stevilo elementov se postavi na n, stevilo alociranih mest pa na
      r (torej se po potrebi spremeni). Ce bi bil r<n, se r najprej postavi na
      n.
    n=0, r>0: Stevilo alociranih mest se postavi na r. Stevilo elementov se po
      potrebi zmanjsa (ce je vecje od r, se postavi na r).
    n=0,r=0: Stevilo elementov postane 0, v nobenem primeru se ne spremeni
      stevilo alociranih mest.
    $A Igor avg00; */
{
indtab it;
spvec vec=NULL;
if (pvec!=NULL)
{
  if (*pvec==NULL)
  {
    /* pvec kaze na nealociran vektor, alocirati je treba ta vektor in to je
    vse: */
    if (n<0)
      n=0;
    if (r<n)
      r=n;
    *pvec=getspvec(ex,r);
    (*pvec)->it->n=n;
  } else
    vec=*pvec;
}
if (vec!=NULL)
{
  if (n<0)
    n=0;
  if (vec->it==NULL)
    vec->it=newindtab(ex,0);
  it=vec->it;
  if (ex>0)
    it->ex=ex;
  if (n>0)
    it->n=n;
  if (r>0) /* dolocena je velikost alociranega prostora */
  {
    if (r<n)
      r=n;
    if (it->r!=r)
    {
      /* Treba je realocirati spomin: */
      it->r=r;
      /* Moznost zmanjsanja st. aloc. mest pod it->n pri realokaciji: */
      if (it->n>it->r)
        it->n=it->r;
      if (it->t!=NULL)
        ++it->t;
      it->t=realloc(it->t,it->r*sizeof(*(it->t)));
      --it->t;
      if (vec->v!=NULL)
        ++vec->v;
      vec->v=realloc(vec->v,it->r*sizeof(*(vec->v)));
      --vec->v;
    }
  } else if (n>0)
  {
    if (it->r<n)
    {
      /* Stevilo alociranih mest je manjse od n, potrebna je realokacija: */
      it->r=n;
      if (it->t!=NULL)
        ++it->t;
      it->t=realloc(it->t,it->r*sizeof(*(it->t)));
      --it->t;
      if (vec->v!=NULL)
        ++vec->v;
      vec->v=realloc(vec->v,it->r*sizeof(*(vec->v)));
      --vec->v;
    }
  } else
    vec->it->n=0;
}
}


void redspvecsize(spvec vec)
    /* Zmanjsa stevilo alociranih mest na stevilo elementov, ce je le-to
    vec kot za vec->it->ex vecje od stevila elementov vec->it->n (redukcija
    aloc. prostora).
    $A Igor avg00; */
{
indtab it;
if (vec!=NULL)
  if ((it=vec->it)!=NULL)
    if (it->r-it->n>it->ex)
    {
      /* Stevilo alociranih mest je preveliko, izvede se realokacija: */
      it->r=it->n;
      if (it->t!=NULL)
        ++it->t;
      it->t=realloc(it->t,it->r*sizeof(*(it->t)));
      if (it->t!=NULL)
        --it->t;
      if (vec->v!=NULL)
        ++vec->v;
      vec->v=realloc(vec->v,it->r*sizeof(*(vec->v)));
      if (vec->v!=NULL)
        --vec->v;
    }
}


void minspvecsize(spvec vec)
    /* Zmanjsa stevilo alociranih mest na stevilo elementov, ce je le-to
    vecje od stevila elementov vec->it->n (minimizacija aloc. prostora).
    $A Igor avg00; */
{
indtab it;
if (vec!=NULL)
  if ((it=vec->it)!=NULL)
    if (it->r-it->n>it->ex)
    {
      /* Stevilo alociranih mest je preveliko, izvede se realokacija: */
      it->r=it->n;
      if (it->t!=NULL)
        ++it->t;
      it->t=realloc(it->t,it->r*sizeof(*(it->t)));
      if (it->t!=NULL)
        --it->t;
      if (vec->v!=NULL)
        ++vec->v;
      vec->v=realloc(vec->v,it->r*sizeof(*(vec->v)));
      if (vec->v!=NULL)
        --vec->v;
    }
}


spvec copyspvec(spvec v1,spvec *v2)
    /* Vrne kopijo razprsenega vektorja v1. Ce je v2 razlicen od NULL,
    skopira vektor v1 v vektor *v2 in vrne *v2.
      OPOMBA:
    Ce *v2 ze obstaja, potem ima kopija v1 za najvec ex presezka alociranih
    mest, ceprav bi bil presezek vecji, ce ne bi bilo realokacije (funkcija
    torej izvede avtomatsko ciscenje odvecnih mest nad kopijo).
    $A Igor avg00; */
{
int i;
if (v2!=NULL)
{
  /* Ce je *v2!=NULL, se v1 skopira v *v2: */
  if (v1==NULL)
    dispspvec(v2);
  else if (v1->it==NULL)
    resizespvec(v2,0,0,0);
  else 
  {
    /* Po potrebi realociramo prostor( prostor se ne zmanjsa!): */
    resizespvec(v2,v1->it->ex,0,v1->it->n);
    redspvecsize(*v2);
    /* Kopiranje vrednosti: */
    for (i=1;i<=v1->it->n;++i)
    {
      (*v2)->it->t[i]=v1->it->t[i];
      (*v2)->v[i]=v1->v[i];
    }
  }
  return *v2; /* Ker je bil v2!=NULL, se vrne *v2. */
} else
{
  spvec v=NULL;
  /* v2==NULL, naredi se nov vektor, ki je kopija v1, vrne se njegov kazalec: */
  if (v1==NULL)
    return NULL;
  else if (v1->it==NULL)
    v=getspvec(0,0);
  else
  {
    v=getspvec(v1->it->ex,v1->it->n);
    v->it->n=v1->it->n;
    for (i=1;i<=v1->it->n;++i)
    {
      v->it->t[i]=v1->it->t[i];
      v->v[i]=v1->v[i];
    }
  }
  return v;
}
}


void printspvec(spvec vec)
    /* Izpise podatke o razprsenem vektorju vec. Elemente izpise v stolpcu.
    $A Igor avg00; */
{
int i;
if (vec==NULL)
  printf("NULL.\n");
else
{
  if (vec->it==NULL)
    printf("NULL index table.\n");
  else
  {
    printf("n=%i, r=%i, ex=%i",vec->it->n,vec->it->r,vec->it->ex);
    if (vec->v==NULL)
      printf(", value table is NULL.");
    printf("\n");
    if (vec->it->n>0)
      for (i=1;i<=vec->it->n;++i)
      {
        if (vec->v!=NULL)
          printf("%i: %g\n",vec->it->t[i],vec->v[i]);
        else
          printf("%i\n");
      }
  }
}
}


void printspvecline(spvec vec)
    /* Izpise podatke o razprsenem vektorju vec. Elemente izpise v vrstici.
    $A Igor avg00; */
{
int i;
if (vec==NULL)
  printf("NULL.\n");
else
{
  if (vec->it==NULL)
    printf("NULL index table.\n");
  else
  {
    printf("n=%i, r=%i, ex=%i",vec->it->n,vec->it->r,vec->it->ex);
    if (vec->v==NULL)
      printf(", value table is NULL.");
    printf("\n");
    if (vec->it->n>0)
    {
      for (i=1;i<=vec->it->n;++i)
      {
        if (vec->v!=NULL)
          printf("%i: %g; ",vec->it->t[i],vec->v[i]);
        else
          printf("%i ",vec->it->t[i]);
      }
      printf("\n");
    }
  }
}
}


void printspvectab(spvec vec)
    /* Izpise podatke o razprsenem vektorju vec, s tem da se izpise samo
    indekse indeksne tabele, ne pa vrednosti elementov. Funkcija se uporablja
    v primeru, ko je mozno, da tabela elementov ni alocirana. Elemente izpise v
    stolpcu.
    $A Igor avg00; */
{
int i;
if (vec==NULL)
  printf("NULL.\n");
else
{
  if (vec->it==NULL)
    printf("NULL index table.\n");
  else
  {
    printf("n=%i, r=%i, ex=%i",vec->it->n,vec->it->r,vec->it->ex);
    if (vec->v==NULL)
      printf(", value table is NULL.");
    printf("\n");
    if (vec->it->n>0)
    {
      for (i=1;i<=vec->it->n;++i)
        printf("%i: %i\n",i,vec->it->t[i]);
      printf("\n");
    }
  }
}
}


void printspvectabline(spvec vec)
    /* Izpise podatke o razprsenem vektorju vec, s tem da se izpise samo
    indekse indeksne tabele, ne pa vrednosti elementov (funkcija se uporablja
    v asinhronem rezimu dela). Elemente izpise v vrstici.
    $A Igor avg00; */
{
int i;
if (vec==NULL)
  printf("NULL.\n");
else
{
  if (vec->it==NULL)
    printf("NULL index table.\n");
  else
  {
    printf("n=%i, r=%i, ex=%i",vec->it->n,vec->it->r,vec->it->ex);
    if (vec->v==NULL)
      printf(", value table is NULL.");
    printf("\n");
    if (vec->it->n>0)
    {
      for (i=1;i<=vec->it->n;++i)
        printf("%i: %i; ",i,vec->it->t[i]);
      printf("\n");
    }
  }
}
}


void printspvectablinesimp(spvec vec)
    /* Izpise podatke o razprsenem vektorju vec, s tem da se izpise samo
    indekse indeksne tabele, ne pa vrednosti elementov (funkcija se uporablja
    v asinhronem rezimu dela). Indekse izpise v vrstici in brez zaporednih
    stevilk.
    $A Igor avg00; */
{
int i;
if (vec==NULL)
  printf("NULL.\n");
else
{
  if (vec->it==NULL)
    printf("NULL index table.\n");
  else
  {
    printf("n=%i, r=%i, ex=%i",vec->it->n,vec->it->r,vec->it->ex);
    if (vec->v==NULL)
      printf(", value table is NULL.");
    printf("\n");
    if (vec->it->n>0)
    {
      for (i=1;i<=vec->it->n;++i)
        printf("%i ",vec->it->t[i]);
      printf("\n");
    }
  }
}
}



void insspvec(spvec vec,int el,double val,int place)
    /* V razprsenem vektorju vec vrine element z indeksom el in vrednostjo val
    na mesto place. Ce je place vecji od vec->it->n+1, se element vrine na
    zadnje mesto. Funkcija deluje v sinhronem rezimu in pricakuje, da je za
    vec->v vsaj toliko alociranih mest, kot je vec->it->r.
    $A Igor avg00; */
{
int i;
indtab it;
if (vec!=NULL)
  if ((it=vec->it)!=NULL && place>0)
  {
    /* Ce je place vecji od 1+st. el., se place postavi na to vrednost: */
    if (place>it->n+1)
      place=it->n+1;
    ++it->n;
    if (it->n>it->r)
    {
      /* treba je povecati alociran prostor */
      it->r=it->n+it->ex;
      if (it->t!=NULL)
        ++it->t;
      it->t=realloc(it->t,it->r*sizeof(*(it->t)));
      --it->t;
      if (vec->v!=NULL)
        ++vec->v;
      vec->v=realloc(vec->v,it->r*sizeof(*(vec->v)));
      --vec->v;
    }
    /* Elementi tabele od mesta place naprej se pomaknejo za eno mesto navzgor: */
    for (i=it->n;i>place;--i)
    {
      it->t[i]=it->t[i-1];
      vec->v[i]=vec->v[i-1];
    }
    it->t[place]=el;
    vec->v[place]=val;
  }
}


int delspvec(spvec vec,int place)
    /* Z razprsenega vektorja vec zbrise element (z ustreznim indeksom vred),
    ki je na mestu place. Vrzel se zapolni tako, da se indeksi in ustrezni
    elementi za zbrisanim elementom pomaknejo za eno mesto naprej. Ce tako
    nastane presezek alociranega spomina za vec kot 2*vec->it->ex, se spomin
    realocira tako, da ostane presezek samo vec->it->ex. Funkcija vrne indeks
    elementa, ki je bil zbrisan.
    $A Igor avg00; */
{
int ret=0,i;
indtab it;
if (vec!=NULL)
  if ((it=vec->it)!=NULL)
    if (place>0 && place<=it->n)
    {
      ret=it->t[place];
      /* Pomik indeksov za place za eno mesto naprej: */
      for (i=place;i<it->n;++i)
      {
        it->t[i]=it->t[i+1];
        vec->v[i]=vec->v[i+1];
      }
      --it->n;
      /* Realokacija (zmanjsanje) spomina po potrebi: */
      if (it->r - it->n > 2*it->ex)
      {
        it->r=it->n+it->ex;
        if (it->r>0)
        {
          if (it->t!=NULL)
            ++it->t;
          it->t=realloc(it->t,it->r*sizeof(*(it->t)));
          --it->t;
          if (vec->v!=NULL)
            ++vec->v;
          vec->v=realloc(vec->v,it->r*sizeof(*(vec->v)));
          --vec->v;
        } else
        {
          if (it->t!=NULL)
          {
            free(++it->t);
            it->t=NULL;
          }
          if (vec->v!=NULL)
          {
            free(++vec->v);
            vec->v=NULL;
          }
        }
      }
    }
return ret;
}


int delspvecsimp(spvec vec,int place)
    /* Z razprsenega vektorja vec zbrise element (z ustreznim indeksom vred),
    ki je na mestu place. Vrzel se zapolni tako, da se indeksi in ustrezni
    elementi za zbrisanim elementom pomaknejo za eno mesto naprej. Funkcija
    NE RAALOCIRA SPOMINA, ce je novo stevilo elementov ustrezno majhno!
    Funkcija vrne indeks elementa, ki je bil zbrisan.
    $A Igor avg00; */
{
int ret=0,i;
indtab it;
if (vec!=NULL)
  if ((it=vec->it)!=NULL)
    if (place>0 && place<=it->n)
    {
      ret=it->t[place];
      /* Pomik indeksov za place za eno mesto naprej: */
      for (i=place;i<it->n;++i)
      {
        it->t[i]=it->t[i+1];
        vec->v[i]=vec->v[i+1];
      }
      --it->n;
    }
return ret;
}


double getspvecel(spvec vec,int el)
    /* Vrne element razprsenega vektorja vec z indeksom el. Ce v vektorju ni
    tega elementa, vrne 0.
    $A Igor avg00; */
{
int place;
if (vec!=NULL)
  if ( ( place=findsortindtab(vec->it,el,0,0) ) )
    return vec->v[place];
return 0;
}


double *getspvecaddr(spvec vec,int el)
    /* Vrne naslov elementa razprsenega vektorja vec z indeksom el. Ce v
    vektorju ni tega elementa, vrne NULL.
    $A Igor avg00; */
{
int place;
if (vec!=NULL)
  if ( ( place=findsortindtab(vec->it,el,0,0) ) )
    return &(vec->v[place]);
return NULL;
}

double *getspvecaddrins(spvec vec,int el)
    /* Vrne naslov elementa razprsenega vektorja vec z indeksom el, pri cemer
    se element vrine, ce se ne obstaja v vektorju (v tem primeru se vrednost
    elementa postavi na 0).
    $A Igor avg00; */
{
int place;
if (vec!=NULL)
  if ( ( place=placesortindtab(vec->it,el,0,0) ) > 0 )
  {
    insspvec(vec,el,0,place);
    return &(vec->v[place]);
  } else if (place<0)
    return &(vec->v[-place]);
return NULL;
}

int setspvecel(spvec vec,int el,double val)
    /* V razprsenem vektorju vec postavi element z indeksom el na vrednost val.
    Ce element z indeksom el ze obstaja, se samo ta element postavi na val,
    drugace pa se element vrine na novo. Funkcija vrne mesto, na katerem je
    postavljen element.
    $A Igor avg00; */
{
int place;
if (vec!=NULL)
  if ( ( place=placesortindtab(vec->it,el,0,0) ) > 0 )
  {
    insspvec(vec,el,val,place);
    return place;
  } else if (place<0)
  {
    place=-place;
    vec->v[place]=val;
    return place;
  }
return 0;
}

int delsspvecel(spvec vec,int el)
    /* Iz razprsenega vektorja vec odstrani element z indeksom el in vrne mesto
    tega elementa. Ce elementa ni v vektorju, vrne 0.
    $A Igor avg00; */
{
int place;
if (vec!=NULL)
  if ( ( place=findsortindtab(vec->it,el,0,0) ) > 0 )
  {
    delspvec(vec,place);
    return place;
  }
return 0;
}

int delspvecelsimp(spvec vec,int el)
    /* Iz razprsenega vektorja vec odstrani element z indeksom el in vrne mesto
    tega elementa. Ce elementa ni v vektorju, vrne 0. Funkcija v nobenem
    primeru NE IZVRSI REALOKACIJE spomina.
    $A Igor avg00; */
{
int place;
if (vec!=NULL)
  if ( ( place=findsortindtab(vec->it,el,0,0) ) > 0 )
  {
    delspvecsimp(vec,place);
    return place;
  }
return 0;
}



           /*******************************************/
           /*                                         */
           /*   OPERACIJE NAD RAZPRSENIMI MATRIKAMI   */
           /*                                         */
           /*******************************************/




matrix randmatsp0(int d1,int d2,int which,int num,double par1,double par2,
       matrix *m)
    /* Naredi in vrne matriko z nakljucnimi elementi, ki ima na veliko mestih
    nicelne elementa. d1 in d2 sta dimenziji matrike, par1 in par2 sta
    parametra verjet. porazdelitve (npr. pri Gaussovi), which doloca, kaksne
    vrste je matrika (npr. simetricna/nesimetricna) in po kaksni porazdelitvi
    so porazdeljeni elementi, num pa doloca zapolnjenost matrike (navadno kar
    stevilo nenicelnih elementov v vsaki vrstici). Ce je d2 0, postane d2 enak
    d1 (kvadratna matrika), ce pa sta d2 in d1 enaka 0, postaneta dimenziji
    matrike *m, ce je ta razlicna od NULL. Zaenkrat so implementirane naslednje
    moznosti glede na vrednosti argumenta which:
    OBVEZNO NENICELNI ELEMENTI NA DIAGONALI, NESIM. MATRIKA:
     0,1: enakomer. porazdelitev med 0 in 1
     2:   enakomer. porazdelitev med par1 in par2
     3:   enakomer. porazdelitev med -par1 in par1
    OBVEZNO NENICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI IZ
    NESIMETRICNE (zaradi enakomerno nepolne strukture zadnjih vrstic):
     10,11: enakomer. porazdelitev med 0 in 1
     12:   enakomer. porazdelitev med par1 in par2
     13:   enakomer. porazdelitev med -par1 in par1
    OBVEZNO NENICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI
    DIREKTNO (zaradi cesar so zadnje vrstice in stolpci bolj polni) - POZOR:
    tu se elementi priblizno podvajajo, kar je potrebno upostevati pri
    parametru num:
     20,21: enakomer. porazdelitev med 0 in 1
     22:   enakomer. porazdelitev med par1 in par2
     23:   enakomer. porazdelitev med -par1 in par1
    DOVOLJENI NICELNI ELEMENTI NA DIAGONALI, NESIM. MATRIKA:
     50,51: enakomer. porazdelitev med 0 in 1
     52:   enakomer. porazdelitev med par1 in par2
     53:   enakomer. porazdelitev med -par1 in par1
    DOVOLJENI NICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI IZ
    NESIMETRICNE (zaradi nepolne strukture zadnjih vrstic):
     60,61: enakomer. porazdelitev med 0 in 1
     62:   enakomer. porazdelitev med par1 in par2
     63:   enakomer. porazdelitev med -par1 in par1
    DOVOLJENI NICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI
    DIREKTNO (zaradi cesar so zadnje vrstice in stolpci bolj polni) - POZOR:
    tu se elementi priblizno podvajajo, kar je potrebno upostevati pri
    parametru num:
     70,71: enakomer. porazdelitev med 0 in 1
     72:   enakomer. porazdelitev med par1 in par2
     73:   enakomer. porazdelitev med -par1 in par1
    $A Igor avg00 */
{
matrix ret=NULL;
indtab it=NULL;
int i,j,k,l;
if (d2==0)
  d2=d1;
if (d2==0 && m!=NULL) /* Torej d2 in d1 enaka 0, privzamejo se dimenzije *m */
  if (*m!=NULL)
  {
    d1=(*m)->d1;
    d2=(*m)->d2;
  }
if (d1>0 && d2>0)
{
  if (m!=NULL)
  {
    if (*m==NULL)
      *m=getmatrix(d1,d2);
    else if ((*m)->d1!=d1 || (*m)->d2!=d2)
    {
      dispmatrix(m);
      *m=getmatrix(d1,d2);
    }
    ret=*m;
  } else
    ret=getmatrix(d1,d2);
  it=newindtab(50,0);
  
  if (which<10)
  {
    /*  OBVEZNO NENICELNI ELEMENTI NA DIAGONALI, NESIMET. MATRIKA: */
    /* Diagonalni elementi: */
    for (i=1;i<=d1 && i<=d2; ++i)
    {
      if (which==2)
        ret->m[i][i]=par1+random1()*(par2-par1);
      else if (which==3)
        ret->m[i][i]=-par1+random1()*2*par1;
      else  /* which=1 */
        ret->m[i][i]=random1();
      if (ret->m[i][i]==0) /* varnostni ventil za nenicelne diag. elemente */
      {
        if (which==2)
          ret->m[i][i]+=par1+1.0e-10*(par2-par1);
        else if (which==3)
          ret->m[i][j]+=1.0e-10*par1;
        else  /* which=1 */
          ret->m[i][i]+=1.0e-10;
      }
    }
    for (i=1;i<=d1;++i)
    {
      randindtabsortun(it,1,d2,num,1);
      /* k naj kaze na 1. element indeksne tabele, ki se ni izkoriscen, l pa
      naj bo vrednost tega elementa: */
      if (it->n>0)
      {
        k=1;
        l=it->t[1];
      } else
        k=0;
      for (j=1;j<=d2;++j)
      {
        if (k)
        {
          /* Nismo se izcrpali vseh indeksov na nakljucno generirani indeksni
          tabeli nenicelnih elementov vrstice, preverimo, ce je indeks j v
          tabeli in glede na to priredimo element matrike: */
          if (j==l)
          {
            /* Indeks je v tabeli */
            if (j!=i) /* nediagonal. element */
            {
              if (which==2)
                ret->m[i][j]=par1+random1()*(par2-par1);
              else if (which==3)
                ret->m[i][j]=-par1+random1()*2*par1;
              else  /* which=1 */
                ret->m[i][j]=random1();
            }
            ++k;
            if (k>it->n)
              k=0;
            else
              l=it->t[k];
          } else if (j!=i)
            ret->m[i][j]=0;
        } else if (j!=i)
          ret->m[i][j]=0;
      }
    }
  }
   
  else if (which<20 && d1==d2)
  {
    /* OBVEZNO NENICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI
    IZ NESIMETRICNE (zaradi nepolne strukture zadnjih vrstic): */
    /* Diagonalni elementi: */
    for (i=1;i<=d1 && i<=d2; ++i)
    {
      if (which==12)
        ret->m[i][i]=par1+random1()*(par2-par1);
      else if (which==13)
        ret->m[i][i]=-par1+random1()*2*par1;
      else  /* which=11 */
        ret->m[i][i]=random1();
      if (ret->m[i][i]==0) /* varnostni ventil za nenicelne diag. elemente */
      {
        if (which==12)
          ret->m[i][i]+=par1+1.0e-10*(par2-par1);
        else if (which==13)
          ret->m[i][j]+=1.0e-10*par1;
        else  /* which=11 */
          ret->m[i][i]+=1.0e-10;
      }
    }
    for (i=1;i<=d1;++i)
    {
      randindtabsortun(it,1,d2,num,1);
      /* k naj kaze na 1. element indeksne tabele, ki se ni izkoriscen, l pa
      naj bo vrednost tega elementa: */
      if (it->n>0)
      {
        k=1;
        l=it->t[1];
      } else
        k=0;
      for (j=1;j<=d2;++j)
      {
        if (k)
        {
          /* Nismo se izcrpali vseh indeksov na nakljucno generirani indeksni
          tabeli nenicelnih elementov vrstice, preverimo, ce je indeks j v
          tabeli in glede na to priredimo element matrike: */
          if (j==l)
          {
            /* Indeks je v tabeli */
            if (j!=i) /* nediagonal. element */
            {
              if (which==12)
                ret->m[i][j]=ret->m[j][i]=par1+random1()*(par2-par1);
              else if (which==13)
                ret->m[i][j]=ret->m[j][i]=-par1+random1()*2*par1;
              else  /* which=11 */
                ret->m[i][j]=ret->m[j][i]=random1();
            }
            ++k;
            if (k>it->n)
              k=0;
            else
              l=it->t[k];
          } else if (j!=i)
            ret->m[i][j]=ret->m[j][i]=0;
        } else if (j!=i)
          ret->m[i][j]=ret->m[j][i]=0;
      }
    }
  }
   
  else if (which<30 && d1==d2)
  {
    /* OBVEZNO NENICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI
    DIREKTNO (zaradi cesar so zadnje vrstice in stolpci bolj polni) - POZOR:
    tu se elementi priblizno podvajajo, kar je potrebno upostevati pri
    parametru num: */
    /* Diagonalni elementi: */
    for (i=1;i<=d1 && i<=d2; ++i)
    {
      if (which==22)
        ret->m[i][i]=par1+random1()*(par2-par1);
      else if (which==23)
        ret->m[i][i]=-par1+random1()*2*par1;
      else  /* which=21 */
        ret->m[i][i]=random1();
      if (ret->m[i][i]==0) /* varnostni ventil za nenicelne diag. elemente */
      {
        if (which==22)
          ret->m[i][i]+=par1+1.0e-10*(par2-par1);
        else if (which==23)
          ret->m[i][j]+=1.0e-10*par1;
        else  /* which=21 */
          ret->m[i][i]+=1.0e-10;
      }
    }
    for (i=1;i<=d1 && i<d2;++i)
    {
      randindtabsortun(it,i+1,d2,num,1);
      /* k naj kaze na 1. element indeksne tabele, ki se ni izkoriscen, l pa
      naj bo vrednost tega elementa: */
      if (it->n>0)
      {
        k=1;
        l=it->t[1];
      } else
        k=0;
      for (j=i+1;j<=d2;++j)
      {
        if (k)
        {
          /* Nismo se izcrpali vseh indeksov na nakljucno generirani indeksni
          tabeli nenicelnih elementov vrstice, preverimo, ce je indeks j v
          tabeli in glede na to priredimo element matrike: */
          if (j==l)
          {
            /* Indeks je v tabeli */
            if (j!=i) /* nediagonal. element */
            {
              if (which==22)
                ret->m[i][j]=ret->m[j][i]=par1+random1()*(par2-par1);
              else if (which==23)
                ret->m[i][j]=ret->m[j][i]=-par1+random1()*2*par1;
              else  /* which=21 */
                ret->m[i][j]=ret->m[j][i]=random1();
            }
            ++k;
            if (k>it->n)
              k=0;
            else
              l=it->t[k];
          } else if (j!=i)
            ret->m[i][j]=ret->m[j][i]=0;
        } else if (j!=i)
          ret->m[i][j]=ret->m[j][i]=0;
      }
    }
  }
  
  else if (which<60)
  {
    /* DOVOLJENI NICELNI ELEMENTI NA DIAGONALI, NESIM. MATRIKA: */
    for (i=1;i<=d1;++i)
    {
      randindtabsortun(it,1,d2,num,1);
      /* k naj kaze na 1. element indeksne tabele, ki se ni izkoriscen, l pa
      naj bo vrednost tega elementa: */
      if (it->n>0)
      {
        k=1;
        l=it->t[1];
      } else
        k=0;
      for (j=1;j<=d2;++j)
      {
        if (k)
        {
          /* Nismo se izcrpali vseh indeksov na nakljucno generirani indeksni
          tabeli nenicelnih elementov vrstice, preverimo, ce je indeks j v
          tabeli in glede na to priredimo element matrike: */
          if (j==l)
          {
            /* Indeks je v tabeli */
            if (1) /* nediagonal. element */
            {
              if (which==52)
                ret->m[i][j]=par1+random1()*(par2-par1);
              else if (which==53)
                ret->m[i][j]=-par1+random1()*2*par1;
              else  /* which=51 */
                ret->m[i][j]=random1();
            }
            ++k;
            if (k>it->n)
              k=0;
            else
              l=it->t[k];
          } else
            ret->m[i][j]=0;
        } else
          ret->m[i][j]=0;
      }
    }
  }
  
  else if (which<70 && d1==d2)
  {
    /* DOVOLJENI NICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI
    IZ NESIMETRICNE (zaradi nepolne strukture zadnjih vrstic): */
    for (i=1;i<=d1;++i)
    {
      randindtabsortun(it,1,d2,num,1);
      /* k naj kaze na 1. element indeksne tabele, ki se ni izkoriscen, l pa
      naj bo vrednost tega elementa: */
      if (it->n>0)
      {
        k=1;
        l=it->t[1];
      } else
        k=0;
      for (j=1;j<=d2;++j)
      {
        if (k)
        {
          /* Nismo se izcrpali vseh indeksov na nakljucno generirani indeksni
          tabeli nenicelnih elementov vrstice, preverimo, ce je indeks j v
          tabeli in glede na to priredimo element matrike: */
          if (j==l)
          {
            /* Indeks je v tabeli */
            if (1) /* nediagonal. element */
            {
              if (which==62)
                ret->m[i][j]=ret->m[j][i]=par1+random1()*(par2-par1);
              else if (which==63)
                ret->m[i][j]=ret->m[j][i]=-par1+random1()*2*par1;
              else  /* which=61 */
                ret->m[i][j]=ret->m[j][i]=random1();
            }
            ++k;
            if (k>it->n)
              k=0;
            else
              l=it->t[k];
          } else
            ret->m[i][j]=ret->m[j][i]=0;
        } else
          ret->m[i][j]=ret->m[j][i]=0;
      }
    }
  }
   
  else if (which<80 && d1==d2)
  {
    /* DOVOLJENI NICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI
    DIREKTNO (zaradi cesar so zadnje vrstice in stolpci bolj polni) - POZOR:
    tu se elementi priblizno podvajajo, kar je potrebno upostevati pri
    parametru num: */
    for (i=1;i<=d1 && i<d2;++i)
    {
      randindtabsortun(it,i+1,d2,num,1);
      /* k naj kaze na 1. element indeksne tabele, ki se ni izkoriscen, l pa
      naj bo vrednost tega elementa: */
      if (it->n>0)
      {
        k=1;
        l=it->t[1];
      } else
        k=0;
      for (j=i+1;j<=d2;++j)
      {
        if (k)
        {
          /* Nismo se izcrpali vseh indeksov na nakljucno generirani indeksni
          tabeli nenicelnih elementov vrstice, preverimo, ce je indeks j v
          tabeli in glede na to priredimo element matrike: */
          if (j==l)
          {
            /* Indeks je v tabeli */
            if (1) /* nediagonal. element */
            {
              if (which==72)
                ret->m[i][j]=ret->m[j][i]=par1+random1()*(par2-par1);
              else if (which==73)
                ret->m[i][j]=ret->m[j][i]=-par1+random1()*2*par1;
              else  /* which=71 */
                ret->m[i][j]=ret->m[j][i]=random1();
            }
            ++k;
            if (k>it->n)
              k=0;
            else
              l=it->t[k];
          } else
            ret->m[i][j]=ret->m[j][i]=0;
        } else
          ret->m[i][j]=ret->m[j][i]=0;
      }
    }
  }
} else
  dispmatrix(m);
dispindtab(&it);
return ret;
}



void printmatrixsplinesimp(matrix m)
    /* Ipzise matriko m v zgosceni obliki, primerni za razprsene matrike.
    Po vrsticah izpise indekse nenicelnih elementov in njihove vrednosti.
    Funkcija se uporablja pretezno za testiranje operacij nad razprsenimi
    matrikami.
    $A Igor avg00; */
{
int numel=0,numline,i,j;
char sym=1,nonzerodiag=1;
if (m==NULL)
  printf("NULL matrix.\n");
else
{
  printf("d1 = %i, d2 = %i.\n",m->d1,m->d2);
  if (m->d1>0 && m->d2>0)
    for (i=1;i<=m->d1;++i)
    {
      printf("LINE %i ",i);
      if (i<=m->d2)
        if (m->m[i][i]==0)
          nonzerodiag=0;
      /* Stetje elementov v vrstici: */
      numline=0;
      for (j=1;j<=m->d2;++j)
      {
        if (m->m[i][j]!=0)
          ++numline;
        if (i<=m->d2 && j<=m->d1)
          if (m->m[i][j]!=m->m[j][i])
            sym=0;
      }
      printf("(%i el.):\n",numline);
      numel+=numline;
      if (numline)
      {
        for (j=1;j<=m->d2;++j)
        {
          if (m->m[i][j]!=0)
            printf("%i:%g  ",j,m->m[i][j]);
          if (i==j)
            printf("  ");
        }
        printf("\n");
      }
    }
  printf("Num. el.: %i (ratio %g). ",numel,(double)numel/(double)(m->d1*m->d2));
  if (sym)
    printf("Symmetric. ");
  else
    printf("Not symmetric. ");
  if (nonzerodiag)
    printf("Nonzero diagonal.\n");
  else
    printf("\n");
}
}



void printmatrixsptablinesimp(matrix m)
    /* Ipzise zasedenost matrike m v zgosceni obliki, primerni za razprsene
    matrike. Po vrsticah izpise indekse nenicelnih elementov.
    Funkcija se uporablja pretezno za testiranje operacij nad razprsenimi
    matrikami.
    $A Igor avg00; */
{
int numel=0,numline,i,j;
char sym=1,nonzerodiag=1;
if (m==NULL)
  printf("NULL matrix.\n");
else
{
  printf("d1 = %i, d2 = %i.\n",m->d1,m->d2);
  if (m->d1>0 && m->d2>0)
  {
    for (i=1;i<=m->d1;++i)
    {
      printf("LINE %i ",i);
      if (i<=m->d2)
        if (m->m[i][i]==0)
          nonzerodiag=0;
      /* Stetje elementov v vrstici: */
      numline=0;
      for (j=1;j<=m->d2;++j)
      {
        if (m->m[i][j]!=0)
          ++numline;
        if (i<=m->d2 && j<=m->d1)
          if (m->m[i][j]!=m->m[j][i])
            sym=0;
      }
      printf("(%i el.):\n",numline);
      numel+=numline;
      if (numline)
      {
        for (j=1;j<=m->d2;++j)
        {
          if (m->m[i][j]!=0)
            printf("%i ",j);
          if (i==j)
            printf("  ");
        }
        printf("\n");
      }
    }
    /* Zvezdna risba: */
    if (m->d2<40)
    {
      for (i=1;i<=m->d1;++i)
      {
        for (j=1;j<=m->d2;++j)
          if (m->m[i][j]!=0)
          {
            if (i==j)
              printf("{}");
            else
              printf("[]");
          }
          else
          {
            if (i==j)
              printf(".'");
            else
              printf("  ");
          }
        printf("\n");
      }
    } else if (m->d2<=80)
      for (i=1;i<=m->d1;++i)
      {
        for (j=1;j<=m->d2;++j)
          if (m->m[i][j]!=0)
          {
            if (i==j)
              printf("$");
            else
              printf("*");
          } else
          {
            if (i==j)
              printf(".");
            else
              printf(" ");
          }
        printf("\n");
      }
  }
  printf("Num. el.: %i (ratio %g). ",numel,(double)numel/(double)(m->d1*m->d2));
  if (sym)
    printf("Symmetric. ");
  else
    printf("Not symmetric. ");
  if (nonzerodiag)
    printf("Nonzero diagonal.\n");
  else
    printf("\n");
}
}



spmat getspmat(int d1,int d2,int ex,int r)
    /* Kreira in vrne razprseno matriko z dimenzijama d1 in d2, pri cemer
    alocira za vsako vrstico r mest in postavi na ex polje ex pri vrsticah (to
    polje pove, za koliko vec mest se alocira prostor ob realokaciji, ko
    zmanjka mest na razprsenih vektorjih, ki predstavljajo vrstice.
    $A Igor avg00; */
{
spmat ret=NULL;
int i;
if (d1>0 && d2>0)
{
  ret=malloc(sizeof(*ret));
  ret->d1=d1; ret->d2=d2;
  ret->m=malloc(d1*sizeof(*(ret->m)));
  --ret->m;
  for (i=1;i<=d1;++i)
    ret->m[i]=getspvec(ex,r);
}
return ret;
}


void dispspmat(spmat *pmat)
    /* Zbrise razprseno matriko *pmat in *pmat postavi na NULL.
    $A Igor avg00; */
{
int i;
spmat mat=NULL;
if (pmat!=NULL)
{
  if ((mat=*pmat)!=NULL)
  {
    if (mat->d1>0)
    {
      for (i=1;i<=mat->d1;++i)
        dispspvec(&(mat->m[i]));
      free(++mat->m);
    }
    free(mat);
  }
  *pmat=NULL;
}
}


void printspmat(spmat mat)
    /* Izpise razprseno matriko mat v dolgi obliki, elemente vrstic izpise v
    stolpcih.
    $A Igor avg00; */
{
int i;
if (mat==NULL)
  printf("NULL sparse matrix.\n");
else
{
  printf("Dimension: %i*%i\n",mat->d1,mat->d2);
  if (mat->d1>0 && mat->d2>0)
    if (mat->m==NULL)
      printf("NULL value table.\n");
    else for (i=1;i<=mat->d1;++i)
    {
      printf("LINE %i:      ",i);
      printspvec(mat->m[i]);
      printf("\n");
    }
}
}

void printspmatline(spmat mat)
    /* Izpise razprseno matriko mat, elemente vrstic izpise v vrsticah.
    $A Igor avg00; */
{
int i;
if (mat==NULL)
  printf("NULL sparse matrix.\n");
else
{
  printf("Dimension: %i*%i\n",mat->d1,mat->d2);
  if (mat->d1>0 && mat->d2>0)
    if (mat->m==NULL)
      printf("NULL value table.\n");
    else for (i=1;i<=mat->d1;++i)
    {
      printf("LINE %i:      ",i);
      printspvecline(mat->m[i]);
    }
}
}


void printspmatfull(spmat mat)
    /* Izpise razprseno matriko mat, kot da bi bila to polna matrika Elemente
    vrstic izpise v stolpcih. Pri elementih, ki niso zasedeni, se za vrednostjo
    0 izpise pomisljaj, da jih lahko locimo od zasedenih elementov, ki imajo 
    vrednost 0.
    $A Igor avg00; */
{
int i,j,k;
spvec vec;
if (mat==NULL)
  printf("NULL sparse matrix.\n");
else
{
  printf("Dimension: %i*%i (sparse)\n",mat->d1,mat->d2);
  if (mat->d1>0 && mat->d2>0)
    if (mat->m==NULL)
      printf("NULL value table.\n");
    else for (i=1;i<=mat->d1;++i)
    {
      /*
      printf("LINE %i:      ",i);
      printspvec(mat->m[i]);
      */
      if ((vec=mat->m[i])==NULL)
      {
        printf("NULL LINE!\n");
        for (j=1;j<=mat->d2;++j)
          printf("m[%i,%i]= 0 -\n",i,j);
      } else
      {
        /* k bo indeks 1. zasedenega elementa v vrstici, ki se se ni izpisal: */
        if (vec->it->n>0)
          k=1;
        else
          k=0;
        for (j=1;j<=mat->d2;++j)
        {
          if (k)
          {
            if (vec->it->t[k]==j)
            {
              printf("m[%i,%i]= %g\n",i,j,vec->v[k]);
              ++k;
              if (k>vec->it->n)
                k=0;
            } else
              printf("m[%i,%i]= 0 -\n",i,j);
          } else
            printf("m[%i,%i]= 0 -\n",i,j);
        }
        if (k)
          printf("Warning: there are row elements whose index exceeds the second dimension.\n");
      }
      printf("\n");
    }
}
}


void printspmattab(spmat mat)
    /* Izpise zasedenost razprsene matrike mat v dolgi obliki, indekse
    elementov vrstic izpise v stolpcih.
    $A Igor avg00; */
{
int i;
if (mat==NULL)
  printf("NULL sparse matrix.\n");
else
{
  printf("Dimension: %i*%i\n",mat->d1,mat->d2);
  if (mat->d1>0 && mat->d2>0)
    if (mat->m==NULL)
      printf("NULL value table.\n");
    else for (i=1;i<=mat->d1;++i)
    {
      printf("LINE %i:      ",i);
      printspvectab(mat->m[i]);
      printf("\n");
    }
}
}


void printspmattabline(spmat mat)
    /* Izpise zasedenost razprsene matrike mat v krajsi obliki, indekse
    elementov vrstic izpise v vrsticah.
    $A Igor avg00; */
{
int i;
if (mat==NULL)
  printf("NULL sparse matrix.\n");
else
{
  printf("Dimension: %i*%i\n",mat->d1,mat->d2);
  if (mat->d1>0 && mat->d2>0)
    if (mat->m==NULL)
      printf("NULL value table.\n");
    else for (i=1;i<=mat->d1;++i)
    {
      printf("LINE %i:      ",i);
      printspvectabline(mat->m[i]);
    }
}
}

void printspmattablinesimp(spmat mat)
    /* Izpise zasedenost razprsene matrike mat v najkrajsi obliki, indekse
    elementov vrstic izpise v v vrsticah in brez zaporednih stevilk.
    $A Igor avg00; */
{
int i;
if (mat==NULL)
  printf("NULL sparse matrix.\n");
else
{
  printf("Dimension: %i*%i\n",mat->d1,mat->d2);
  if (mat->d1>0 && mat->d2>0)
    if (mat->m==NULL)
      printf("NULL value table.\n");
    else for (i=1;i<=mat->d1;++i)
    {
      printf("LINE %i:      ",i);
      printspvectablinesimp(mat->m[i]);
    }
}
}


spmat copyspmat(spmat m1,spmat *m2)
    /* Vrne kopijo razprsene matrike m1. Ce je m2 razlicen od NULL, skopira
    m1 v *m2 in vrne *m2.
      OPOMBA:
    Ce *m2 ze obstaja, potem ima kopija m1 za najvec ex presezka alociranih
    mest za katerokoli vrstico, ceprav bi bil presezek vecji, ce ne bi bilo
    realokacije (funkcija torej izvede avtomatsko ciscenje prevec odvecnih mest
    nad kopijo).
    $A Igor avg00; */
{
spmat m;
int i;
if (m2!=NULL)
{
  /* Ce je *m2!=NULL, se m1 skopira v *m2: */
  if (m1==NULL)
  {
    dispspmat(m2);
  } else
  {
    /* Preverimo dimenziji *m2, ce nista ustrezni, zbrisemo *m2: */
    if (*m2!=NULL)
      if ((*m2)->d1!=m1->d1 || (*m2)->d2!=m1->d2)
        dispspmat(m2);
    /* Ce je *m2==NULL, tvorimo *m2 z dimenzijama m1: */
    if (*m2==NULL)
        *m2=getspmat(m1->d1,m1->d2,0,0);
    m=*m2;
    /* Kopiranje vrstic: */
    if (m1->d1>0 && m1->d2>0)
      for (i=1;i<=m1->d1;++i)
        copyspvec(m1->m[i],&(m->m[i]));
  }
  return *m2; /* Ker je bil m2!=NULL, se vrne *m2. */
} else
{
  /* m2==NULL, naredi se nova matrika, ki je kopija m1, vrne se njen kazalec: */
  if (m1==NULL)
    return NULL;
  else
  {
    m=getspmat(m1->d1,m1->d2,0,0);
    /* Kopiranje vrstic: */
    if (m1->d1>0 && m1->d2>0)
      for (i=1;i<=m1->d1;++i)
        copyspvec(m1->m[i],&(m->m[i]));
    return m;
  }
}
}


matrix copyspmattomatrix(spmat m1,matrix *m2)
    /* Razprseno matriko m1 skopira v polno matriko in jo vrne. Ce je m2
    razlicen od NULL, se m1 skopira v *m2 in se vrne *m2.
    $A Igor avg00; */
{
matrix m;
int i,j;
if (m2!=NULL)
{
  /* Ce je *m2!=NULL, se m1 skopira v *m2: */
  if (m1==NULL)
  {
    dispmatrix(m2);
  } else
  {
    /* Preverimo dimenziji *m2, ce nista ustrezni, zbrisemo *m2: */
    if (*m2!=NULL)
      if ((*m2)->d1!=m1->d1 || (*m2)->d2!=m1->d2)
        dispmatrix(m2);
    /* Ce je *m2==NULL, tvorimo *m2 z dimenzijama m1: */
    if (*m2==NULL)
        *m2=getmatrix(m1->d1,m1->d2);
    m=*m2;
    /* Kopiranje elementov: */
    if (m1->d1>0 && m1->d2>0)
      for (i=1;i<=m1->d1;++i)
      {
        for (j=1;j<=m->d2;++j)  /* najprej se v celo vrstico zapisejo nicle */
          m->m[i][j]=0;
        if (m1->m[i]!=NULL)  /* nato se zapisejo nenicelni elementi */
          if ((m1->m[i])->it!=NULL)
            for (j=1;j<=(m1->m[i])->it->n;++j)
              m->m[i][(m1->m[i])->it->t[j]]=(m1->m[i])->v[j];
      }
  }
  return *m2; /* Ker je bil m2!=NULL, se vrne *m2. */
} else
{
  /* m2==NULL, naredi se nova matrika, ki je kopija m1, vrne se njen kazalec: */
  if (m1==NULL)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    /* Kopiranje elementov: */
    if (m1->d1>0 && m1->d2>0)
      for (i=1;i<=m1->d1;++i)
      {
        for (j=1;j<=m->d2;++j)  /* najprej se v celo vrstico zapisejo nicle */
          m->m[i][j]=0;
        if (m1->m[i]!=NULL)  /* nato se zapisejo nenicelni elementi */
          if ((m1->m[i])->it!=NULL)
            for (j=1;j<=(m1->m[i])->it->n;++j)
              m->m[i][(m1->m[i])->it->t[j]]=(m1->m[i])->v[j];
      }
    return m;
  }
}
}


spmat copymatrixtospmat(matrix m1,spmat *m2,int ex)
    /* Polno matriko m1 skopira v razprseno matriko in jo vrne. Ce je m2
    razlicen od NULL, se m1 skopira v *m2 in se vrne *m2.
    $A Igor avg00; */
{
spmat m;
int i,j,n;
if (m2!=NULL)
{
  /* Ce je *m2!=NULL, se m1 skopira v *m2: */
  if (m1==NULL)
  {
    dispspmat(m2);
  } else
  {
    /* Preverimo dimenziji *m2, ce nista ustrezni, zbrisemo *m2: */
    if (*m2!=NULL)
      if ((*m2)->d1!=m1->d1 || (*m2)->d2!=m1->d2)
        dispspmat(m2);
    /* Ce je *m2==NULL, tvorimo *m2 z dimenzijama m1: */
    if (*m2==NULL)
        *m2=getspmat(m1->d1,m1->d2,0,0);
    m=*m2;
    /* Kopiranje vrstic: */
    if (m1->d1>0 && m1->d2>0)
      for (i=1;i<=m1->d1;++i)
      {
        /* Ugotavljanje stevila nenicelnih elmentov v vrstici: */
        n=0;
        for (j=1;j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
            ++n;
        /* Najprej zagotovimo zadostno stevilo alociranih mest: */
        resizespvec(&(m->m[i]),ex,0,n);  redspvecsize(m->m[i]);
        /* Kopiranje nenicelnih elementov: */
        n=0;
        for (j=1;j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
          {
            ++n;
            (m->m[i])->it->t[n]=j;
            (m->m[i])->v[n]=m1->m[i][j];
          }
      }
  }
  return *m2; /* Ker je bil m2!=NULL, se vrne *m2. */
} else
{
  /* m2==NULL, naredi se nova matrika, ki je kopija m1, vrne se njen kazalec: */
  if (m1==NULL)
    return NULL;
  else
  {
    m=getspmat(m1->d1,m1->d2,0,0);
    /* Kopiranje vrstic: */
    if (m1->d1>0 && m1->d2>0)
      for (i=1;i<=m1->d1;++i)
      {
        /* Ugotavljanje stevila nenicelnih elmentov v vrstici: */
        n=0;
        for (j=1;j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
            ++n;
        /* Najprej zagotovimo zadostno stevilo alociranih mest: */
        resizespvec(&(m->m[i]),ex,0,n);  redspvecsize(m->m[i]);
        /* Kopiranje nenicelnih elementov: */
        n=0;
        for (j=1;j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
          {
            ++n;
            (m->m[i])->it->t[n]=j;
            (m->m[i])->v[n]=m1->m[i][j];
          }
      }
    return m;
  }
}
}


spmat copymatrixlowtospmat(matrix m1,spmat *m2,int ex)
    /* Spodnji trikotnik in diagonalo polne matrike m1 skopira v razprseno
    matriko in jo vrne. Ce je m2 razlicen od NULL, se spodnji del m1 skopira v
    *m2 in se vrne *m2. Parameter ex doloca stevilo preseznih mest pri
    realokaciji  razprsenih vektorjev ciljne matrike.
    $A Igor sep00; */
{
spmat m;
int i,j,n;
if (m2!=NULL)
{
  /* Ce je *m2!=NULL, se m1 skopira v *m2: */
  if (m1==NULL)
  {
    dispspmat(m2);
  } else
  {
    /* Preverimo dimenziji *m2, ce nista ustrezni, zbrisemo *m2: */
    if (*m2!=NULL)
      if ((*m2)->d1!=m1->d1 || (*m2)->d2!=m1->d2)
        dispspmat(m2);
    /* Ce je *m2==NULL, tvorimo *m2 z dimenzijama m1: */
    if (*m2==NULL)
        *m2=getspmat(m1->d1,m1->d2,0,0);
    m=*m2;
    /* Kopiranje vrstic: */
    if (m1->d1>0 && m1->d2>0)
      for (i=1;i<=m1->d1;++i)
      {
        /* Ugotavljanje stevila nenicelnih elmentov v vrstici: */
        n=0;
        for (j=1;j<=i && j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
            ++n;
        /* Najprej zagotovimo zadostno stevilo alociranih mest: */
        resizespvec(&(m->m[i]),ex,0,n);  redspvecsize(m->m[i]);
        /* Kopiranje nenicelnih elementov: */
        n=0;
        for (j=1;j<=i && j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
          {
            ++n;
            (m->m[i])->it->t[n]=j;
            (m->m[i])->v[n]=m1->m[i][j];
          }
      }
  }
  return *m2; /* Ker je bil m2!=NULL, se vrne *m2. */
} else
{
  /* m2==NULL, naredi se nova matrika, ki je kopija m1, vrne se njen kazalec: */
  if (m1==NULL)
    return NULL;
  else
  {
    m=getspmat(m1->d1,m1->d2,0,0);
    /* Kopiranje vrstic: */
    if (m1->d1>0 && m1->d2>0)
      for (i=1;i<=m1->d1;++i)
      {
        /* Ugotavljanje stevila nenicelnih elmentov v vrstici: */
        n=0;
        for (j=1;j<=i && j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
            ++n;
        /* Najprej zagotovimo zadostno stevilo alociranih mest: */
        resizespvec(&(m->m[i]),ex,0,n);  redspvecsize(m->m[i]);
        /* Kopiranje nenicelnih elementov: */
        n=0;
        for (j=1;j<=i && j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
          {
            ++n;
            (m->m[i])->it->t[n]=j;
            (m->m[i])->v[n]=m1->m[i][j];
          }
      }
    return m;
  }
}
}


spmat copymatrixuptospmat(matrix m1,spmat *m2,int ex)
    /* Zgornji trikotnik in diagonalo polne matrike m1 skopira v razprseno
    matriko in jo vrne. Ce je m2 razlicen od NULL, se zgornji del m1 skopira v
    *m2 in se vrne *m2. Parameter ex doloca stevilo preseznih mest pri
    realokaciji  razprsenih vektorjev ciljne matrike.
    $A Igor sep00; */
{
spmat m;
int i,j,n;
if (m2!=NULL)
{
  /* Ce je *m2!=NULL, se m1 skopira v *m2: */
  if (m1==NULL)
  {
    dispspmat(m2);
  } else
  {
    /* Preverimo dimenziji *m2, ce nista ustrezni, zbrisemo *m2: */
    if (*m2!=NULL)
      if ((*m2)->d1!=m1->d1 || (*m2)->d2!=m1->d2)
        dispspmat(m2);
    /* Ce je *m2==NULL, tvorimo *m2 z dimenzijama m1: */
    if (*m2==NULL)
        *m2=getspmat(m1->d1,m1->d2,0,0);
    m=*m2;
    /* Kopiranje vrstic: */
    if (m1->d1>0 && m1->d2>0)
      for (i=1;i<=m1->d1;++i)
      {
        /* Ugotavljanje stevila nenicelnih elmentov v vrstici: */
        n=0;
        for (j=i;j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
            ++n;
        /* Najprej zagotovimo zadostno stevilo alociranih mest: */
        resizespvec(&(m->m[i]),ex,0,n);  redspvecsize(m->m[i]);
        /* Kopiranje nenicelnih elementov: */
        n=0;
        for (j=i;j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
          {
            ++n;
            (m->m[i])->it->t[n]=j;
            (m->m[i])->v[n]=m1->m[i][j];
          }
      }
  }
  return *m2; /* Ker je bil m2!=NULL, se vrne *m2. */
} else
{
  /* m2==NULL, naredi se nova matrika, ki je kopija m1, vrne se njen kazalec: */
  if (m1==NULL)
    return NULL;
  else
  {
    m=getspmat(m1->d1,m1->d2,0,0);
    /* Kopiranje vrstic: */
    if (m1->d1>0 && m1->d2>0)
      for (i=1;i<=m1->d1;++i)
      {
        /* Ugotavljanje stevila nenicelnih elmentov v vrstici: */
        n=0;
        for (j=i;j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
            ++n;
        /* Najprej zagotovimo zadostno stevilo alociranih mest: */
        resizespvec(&(m->m[i]),ex,0,n);  redspvecsize(m->m[i]);
        /* Kopiranje nenicelnih elementov: */
        n=0;
        for (j=i;j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
          {
            ++n;
            (m->m[i])->it->t[n]=j;
            (m->m[i])->v[n]=m1->m[i][j];
          }
      }
    return m;
  }
}
}


void spmatprodvecplain(spmat m1,vector v2,vector res)
    /* V vektor res zapise produkt razprsene matrike m1 in vektorja v2.
    Funkcija ne kontrolira niti dimenzij niti tega, ce je prostor alociran.
    Vektor res ne sme biti isti kot v2.
    $A Igor avg00; */
{
int i,k,n,*ind;
double s,*el;
indtab it;
spvec row;
for (i=1;i<=m1->d1;++i)
{
  s=0;
  if ((n=(it=(row=m1->m[i])->it)->n)>0)
  {
    el=row->v;
    ind=it->t;
    for (k=1;k<=n;++k)
    s+=el[k]*v2->v[ind[k]];
  }
  res->v[i]=s;
}
}


vector spmatprodvec(spmat m1,vector v2,vector *v3)
    /* Vrne produkt razprsene matrike m1 in vektorja v2. Ce je v3 razlicen od
    NULL, zapise rezultat v *v3 in vrne *v3. v3 je lahko tudi naslov v2,
    funkcija v tem primeru poskrbi za to, da se najprej izracuna rezultat
    operacije in sele nato prepise operand.
     OPOMBA:
     Ce je v3 razlicen od NULL, se po navadi vektor, ki ga funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze v3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */
{
vector v=NULL,*save=NULL;
if (v3!=NULL)
{
  if (*v3==v2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce v3 kaze na
    v2: */
    save=v3;
    v3=&v;
  }
  /* Ce je v3!=NULL, se rezultat shrane v *v3: */
  /* Najprej preverimo, ce sta m1 in v2 kompatibilna z operacijo: */
  if (m1==NULL || v2==NULL)
    dispvector(v3);
  else if (m1->d2!=v2->d || m1->d1<1 || m1->d2<1)
    dispvector(v3);
  else
  {
    /* Preverimo dimenzijo *v3, ce ni ustrezna, zbrisemo *v3: */
    if (*v3!=NULL)
      if ((*v3)->d!=m1->d1)
        dispvector(v3);
    /* Ce je *v3==NULL, tvorimo *v3 s 1. dimenzijo m1: */
    if (*v3==NULL)
      *v3=getvector(m1->d1);
    /* Izvedba operacije: */
    spmatprodvecplain(m1,v2,*v3);
  }
  if (save!=NULL)
  {
    dispvector(save);
    *save=*v3;
  }
  return *v3; /* Ker je bil v3!=NULL, se vrne *v3. */
} else
{
  /* v3==NULL, naredi se nov vektor, v katerega se zapise rezultat operacije,
  vrne se njegov kazalec: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni za operacijo: */
  if (m1==NULL || v2==NULL)
    return NULL;
  else if (m1->d2!=v2->d || m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    v=getvector(m1->d1);
    /* Izvedba operacije: */
    spmatprodvecplain(m1,v2,v);
    return v;
  }
}
}



void spmattranspplain(spmat m,spmat res,indtab aux)
    /* Elementi razprsene matrike res postanejo elementi transponirane
    razprsene matrike m. Funkcija ne preverja dimenzij in obstoja matrik, zato
    morajo biti dimenzije kompatibilne. Ce je m kvadratna matrika, je lahko
    res ista matrika kot m. aux je pomozna indeksna tabela, ki mora imeti
    toliko alociranih mest, kot je 1. dimenzija m (t.j. m->d1).
    $A Igor jan00; */
{
int i,irow,elrow,irow1,elrow1,icol;
double val;
spvec row,row1;
indtab indrow;
if (res==m)
{
  /* Algoritem za primer, ko sta res in m isti matriki, v postev pride le za
  kvadratne matrike: */
  /* Najprej se v aux zapisejo zap. st. elementov v posameznih vrsticah, ki so
  naslednji na vrsti za obdelavo (po dogovoru 0, ko zmanjka taksnih vrstic), to
  so na zacetku kar indeksi prvega elementa, ce je poddiagonalen: */
  for (i=1;i<=m->d1;++i)
  {
    aux->t[i]=0;
    if ( (indrow=m->m[i]->it)->n )
      aux->t[i]=1;
    else
      aux->t[i]=0;
    /*
      if ( (j=indrow->t[1]) <i) / biti mora poddiagonalni element /
        aux->t[i]=j;
    */
  }
  for (i=1;i<=m->d1;++i)
  {
    /* Iteracija po stolpcih m: */
    icol=i+1; /* Stevilka vrstice, ki je trenutno v obdelavi */
    /* i. vrstica in njena indeksna tabela: */
    row=m->m[i];
    indrow=row->it;
    if (irow=aux->t[i])
    {
      elrow=indrow->t[irow];
      if (elrow==i)
      {
        ++irow;
        if (irow>indrow->n)
          irow=elrow=0;
        else elrow=indrow->t[irow];
      }
    } else
      elrow=0;
    while (icol<=m->d1)
    {
      row1=m->m[icol]; /* Vrstica, ki je trenutno v obdelavi */
      if ((irow1=aux->t[icol]))
        elrow1=row1->it->t[irow1];
      else
        elrow1=0;
      if (elrow1==i)
      {
        /* Ce je element i v vrstici icol zaseden: */
        if (icol==elrow)
        {
          /* Tudi element icol v vrstici i (t.j. zrcalni element) je zaseden,
          zamenjata se samo vrednosti in inkrementirajo ustrezni stevci: */
          val=row1->v[irow1];
          row1->v[irow1]=row->v[irow];
          row->v[irow]=val;
          /* Inkrementacija zaporednega elementa vrstice icol, ki bo naslednji 
          v obdelavi: */
          if ( (++aux->t[icol]) > row1->it->n)
            aux->t[icol]=0;
          if ((++irow) > indrow->n)
            irow=elrow=0;
          else
            elrow=indrow->t[irow];
        } else if (icol<elrow || elrow==0)
        {
          /* Zrcalni element ni zaseden, zato se vrine na novo, element v
          vrstici icol pa se zbrise: */
          val=row1->v[irow1]; /* zapolnimo si vrednost */
          /* Brisanje elementa z indeksom i (zap. st. irow1) v vrstici row1: */
          delspvecsimp(row1,irow1);
          if (irow1>row1->it->n)
            aux->t[icol]=0;
          /* Vrivanje elementa v i. vrstico: */
          if (irow)
          {
            insspvec(row,icol,val,irow);
            ++irow;
          } else
            insspvec(row,icol,val,row->it->n+1);
        }
      } else if (icol==elrow)
      {
        /* Element i v vrstici icol ni zaseden, je pa zaseden element icol v
        vrstici i: */
        val=row->v[irow];
        /* Brisanje elementa icol v vrstici i: */
        delspvecsimp(row,irow);
        if (irow>row->it->n)
          irow=elrow=0;
        else
          elrow=row->it->t[irow];
        /* Vrivanje vrednosti v vrstico icol: */
        if (irow1)
        {
          insspvec(row1,i,val,irow1);
          if ( (++aux->t[icol]) > row1->it->n)
            aux->t[icol]=0;
        }
        else
          insspvec(row1,i,val,row1->it->n+1);
      }
      ++icol;
    }
  }
} else
{
  for (i=1;i<=res->d1;++i)
    res->m[i]->it->n=0;
  for (i=1;i<=m->d1;++i)
  {
    row=m->m[i];
    for (irow=1;irow<=row->it->n;++irow)
    {
      elrow=row->it->t[irow];
      val=row->v[irow];
      row1=res->m[elrow];
      insspvec(row1,i,val,row1->it->n+1);
    }
  }
}
}


spmat spmattransp(spmat m1,spmat *res,indtab *pit1)
    /* Vrne transponirano razprsene matrike m1. Ce je res razlicen od NULL,
    zapise rezultat v *res in vrne *res. res je lahko tudi naslov m1, funkcija
    v tem primeru poskrbi za to, da se najprej izracuna rezultat operacije in
    sele nato prepise operand.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
spmat m=NULL,*save=NULL;
indtab it1=NULL;
if (res!=NULL)
{
  
  if (*res==m1 && m1!=NULL)
    if (m1->d1!=m1->d2)
    {
      /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce res kaze na
      m1 in m1 ni kvadratna matrika: */
      save=res;
      res=&m;
    }
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispspmat(res);
  else if (m1->d1<1 || m1->d2<1)
    dispspmat(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d1!=m1->d2 || (*res)->d2!=m1->d1)
        dispspmat(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getspmat(m1->d2,m1->d1,(m1->m[1])->it->ex,0);
    /* Alokacija pomozne indeksne tabele po potrebi: */
    if (pit1!=NULL)
      resizeindtab(pit1,0,0,m1->d1);
    else
    {
      resizeindtab(&it1,0,0,m1->d1);
      pit1=&it1;
    }
    /* Izvedba operacije: */
    spmattranspplain(m1,*res,*pit1);
    /* Ce je bil pit1 NULL, je treba sprostiti prostor za indeksno tabelo, ki
    je bila alocirana znotraj funkcije: */
    dispindtab(&it1);
  }
  if (save!=NULL)
  {
    dispspmat(save);
    *save=*res;
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    m=getspmat(m1->d2,m1->d1,(m1->m[1])->it->ex,0);
    /* Alokacija pomozne indeksne tabele po potrebi: */
    if (pit1!=NULL)
      resizeindtab(pit1,0,0,m1->d1);
    else
    {
      resizeindtab(&it1,0,0,m1->d1);
      pit1=&it1;
    }
    /* Izvedba operacije: */
    spmattranspplain(m1,m,*pit1);
    /* Ce je bil pit1 NULL, je treba sprostiti prostor za indeksno tabelo, ki
    je bila alocirana znotraj funkcije: */
    dispindtab(&it1);
    return m;
  }
}
}



            /***************************************/
            /*                                     */
            /*   DEKOMPOZICIJE RAZPRSENIH MATRIK   */
            /*                                     */
            /***************************************/



int spLDLTdecomplowrow(spmat m)
    /* Izvede LDLT dekompozicijo simetricne razprsene matrike m, v kateri je
    shranjen samo spodnji trikotnik. Elementi L in D se zapisejo v m, tako da
    se originalna matrika unici.
    $A Igor sep00; */
{
int i,j,irow,elrow,irow1,elrow1,ibas,elbas,dim,ret=0;
double val;
spvec row,row1;
indtab indrow,indrow1;
if (m==NULL)
  ret=-1;
else if ((dim=m->d1)!=m->d2 || m->d1<1)
  ret=-1;
else
{
  for (i=1;i<=dim;++i)
  {
    
    if (i%50==0)
    {
      printf(".");
      fflush(stdout);
    }
    
    /* Priprava podatkov o i. vrstici, katere elementi se trenutno racunajo: */
    row=m->m[i];
    indrow=row->it;
    ibas=1;
    if (indrow->n>0)
      elbas=indrow->t[1];
    else
      elbas=i+1;
    for (j=elbas;j<i;++j)
    {
      /* Racunanje j. elementa; najprej se dobi vredost tega elementa v
      originalni matriki: */
      if (elbas==j)
        val=row->v[ibas];
      else
        val=0;
      /* Od vrednosti elementa odstejemo clene vsote do j-1-tega clena: */
      indrow1=(row1=m->m[j])->it;
      if (indrow1->n)
      {
        irow1=1;
        elrow1=indrow1->t[1];
      } else
      {
        irow1=0;
        elrow1=j; /* vec, kor je obseg indeksa pri vsoti */
      }
      if (indrow->n)
      {
        irow=1;
        elrow=indrow->t[1];
      } else
      {
        irow=0;
        elrow=j; /* vec, kor je obseg indeksa pri vsoti */
      }
      while (elrow<j && elrow1<j)
      {
        if (elrow<elrow1)
        {
          if ((++irow)<=indrow->n)
            elrow=indrow->t[irow];
          else
            elrow=j; /* indeks postavimo izven obsega indeksov pri vsoti */
        } else if (elrow1<elrow)
        {
          if ((++irow1)<=indrow1->n)
            elrow1=indrow1->t[irow1];
          else
            elrow1=j; /* indeks postavimo izven obsega indeksov pri vsoti */
        } else /* elrow==elrow1 */
        {
          val-=row->v[irow]*row1->v[irow1]*(m->m[elrow])->v[(m->m[elrow])->it->n];
          /* zadnji clen produkta je elrow. diagonal. element, torej zadnji 
          element vrstice elrow, ker je shranjen le spodnji trikotnik matrike */
          if ((++irow)<=indrow->n)
            elrow=indrow->t[irow];
          else
            elrow=j; /* indeks postavimo izven obsega indeksov pri vsoti */
          if ((++irow1)<=indrow1->n)
            elrow1=indrow1->t[irow1];
          else
            elrow1=j; /* indeks postavimo izven obsega indeksov pri vsoti */
        }
      }
      if (val)
      {
        /* Na koncu se vsota se deli z j. diagonalnim elementom: */
        val/=row1->v[indrow1->n];
        /* Potem se ustrez. element razcepa postavi na izracunano vrednost: */
        if (j<elbas)
        {
          insspvec(row,j,val,ibas);
          ++ibas;
        } else /* elbas==j */
        {
          row->v[ibas]=val;
          if ((++ibas)<=indrow->n)
            elbas=indrow->t[ibas];
          else
            elbas=i+1;
        }
      }
    }
    /* Racunanje i. diagonalnega elementa, najprej se vzame ustrez. el. originalne
    matrike: */
    if (elbas==i)
      val=row->v[ibas];
    else
      val=0;
    /* Sledi racunanje in hkratno odstevanje vsote: */
    if (indrow->n)
    {
      irow=1;
      elrow=indrow->t[1];
    } else
    {
      irow=0;
      elrow=i; /* vec, kor je obseg indeksa pri vsoti */
    }
    while (elrow<i)
    {
      val-=row->v[irow]*row->v[irow]*(m->m[elrow])->v[(m->m[elrow])->it->n];
      /* zadnji clen produkta je elrow. diagonal. element, torej zadnji 
      element vrstice elrow, ker je shranjen le spodnji trikotnik matrike */
      if ((++irow)<=indrow->n)
        elrow=indrow->t[irow];
      else
        elrow=i; /* indeks postavimo izven obsega indeksov pri vsoti */
    }
    if (val)
    {
      /* Diagonal. element razcepa postavimo na izracunano vrednost: */
      if (i!=elbas)
        insspvec(row,j,val,ibas);
      else /* elbas==j */
        row->v[ibas]=val;
    } else
    {
      return -1;
      printf("\nSingular matrix!\n\n");
    }
  }
}
return ret;
}


/*

typedef struct{
    indtab it;
    double *v;
} _spvec;

typedef _spvec *spvec;


typedef struct{
  int d1,d2;
  spvec *m;
} _spmat;

typedef _spmat *spmat;

*/


