#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <mtypes.h>
#include <fop.h>


main(int numargs, char *argv[])
{
char ch,ch1='\r',ch2='\0',end=0;
FILE *fp,*fp1;
long from,pos;
if (numargs==3)
{
  fp=fopen(argv[1],"rb");
  fp1=fopen(argv[2],"wb");
  if (fp==NULL || fp1==NULL)
    printf("Can't open files.\n");
  else
  {
    end=0;
    /*
    from=1;
    */
    while (!end)
    {
      if (!feof(fp))
      {
        fscanf(fp,"%c",&ch);
        if (ch==ch1)
          ch=ch2;
        if (ch!='\0')
          fprintf(fp1,"%c",ch);
      } else end=1;
      
      /*
      pos=filechar(fp,&ch1,1,from,100);
      if (pos>0)
      {
        fflush(fp);
        filewrite(&ch2,1,1,fp,pos);
        from=pos+1;
      }
      else
        end=1;
      */
    }
    fclose(fp);
    fclose(fp1);
  }
}
else
{
  printf("Usage:  %s <source_file> <target_file>\n\n",argv[0]);
  /*
  printf("This program converts all\n");
  printf("This program converts all '%c' characters in the specified file \nto '%c' characters.\n",ch1,ch2);
  */
  printf("This program copies the first file to the second one,\n");
  printf("omiting all '\\r' characters.\n");

}
}
