

/******************* GRAFICNI VMESNIK ZA XLIB *******************/



#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include <mtypes.h>
#include <st.h>
#include <strop.h>
#include <titles.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>


#include <X11/Xresource.h>



#define xcoord(x) x*iwindowwidth
#define ycoord(y) (1.0-y)*iwindowheight



typedef struct
    {
      float red,green,blue;
    } truecolorstruct;


typedef struct
    {
      Window id;      /* Identifikacijska st. v X */
      char   open;    /* Je 0, ce okno ni odprto */
      GC     gc;      /* Graficni kontekst */
      int width, height; /* Sirina in solzina */
    } _winstruct;

typedef _winstruct *winstruct;






/* SPREMENLJIVKE, KI JIH RABIJO FUNKCIJE VMESNIKA ZA SKLADISCENJE PODATKOV: */


static int MAXX=1280,MAXY=1024;

static Display *display=NULL;
static char *displayname=NULL;
static Window window;
static int screen;
static Colormap colormap;
static int mapsize;
static GC gc=NULL;
static unsigned long defaultfgpixel,defaultbgpixel;  /* Barva ospredja in ozadja */
static char *defaultfontname="*times*";
static XFontStruct *defaultfontstruct=NULL;
static int defaultfontid;

static int   activewindow=0;  /* Zaporedna st. aktivnega okna */
static stack windows=NULL;
/* Te spremenljivke morajo vedno biti enake pravim dimenzijam okna: */
static int iwindowxpos=0,iwindowypos=0,iwindowheight=200,iwindowwidth=200;
static float windowxpos=(float) 0.0,windowypos=(float) 0.0,
        windowheight=(float) 0.4,windowwidth=(float) 0.4;
static char *windowtitle=NULL;
static unsigned long fgpixel,bgpixel;  /* Barva ospredja in ozadja */
static XFontStruct *fontstruct=NULL;
static int fontid=0;
static XEvent event;



static XGCValues linegcv,fillgcv,textgcv;
static unsigned long linemask=0,fillmask=0,textmask=0;

static truecolorstruct linecolor,fillcolor,textcolor;

static double linewidth;
static int linetype;

static int curvepoints=16;
static float pointsize;

static int textfont;
static float textheight;
static float textspacing;
static float textexpansion;
static int textxalignment;
static int textyalignment;
static float textprecision;

/* static int fontid=0; */
static unsigned long linepixel=0;
static unsigned long fillpixel=0;
static unsigned long textpixel=0;


static XPoint points[10];  /* Tocke za risanje poligonov */






/*********** FUNKCIJE ZA RAVNANJE S FONTI: ************/


typedef struct
    {
      char *pre,*post;
      char scalable;
      stack sizes;
    } _fontdatastruct;

typedef _fontdatastruct *fontdatastruct;

typedef struct
    {
      int size;
      int fontid;
      XFontStruct *fontstruct;
    } _fontsizestruct;

typedef _fontsizestruct *fontsizestruct;

static stack fonts=NULL;



static void deinstallfont(int num)
    /* S sklada fonts odstrani podatke o fontu z zap. st. num. */
{
int i;
fontdatastruct fd;
fontsizestruct fs;

if (num<1)
  num=1;
if (fonts!=NULL)
  if (fonts->n>=num)
  {
    fd=fonts->s[num];
    if (fd!=NULL)
    {
      if (fd->pre!=NULL)
        free(fd->pre);
      if (fd->post!=NULL)
        free(fd->post);
      if (fd->sizes!=NULL)
      {
        if (fd->sizes->n>0)
        {
          for (i=1;i<=fd->sizes->n;++i)
          {
            fs=fd->sizes->s[i];
            if (fs!=NULL)
            {
              if (fs->fontid!=0)
                XUnloadFont(display,fs->fontid);
              free(fs);
            }
          }
          dispstack(&fd->sizes);
        }
      }
    free(fd);
    fonts->s[num]=NULL;
    }
  }
}


void giinstallfont(int num,char *name1)
    /* Instalira font z imenom name na mesto num. */
{
int i;
fontdatastruct fd;
char *name=NULL,*point,*scalestr="--0-",chr;
name=stringcopy(name1);
if (num<1)
  num=1;
if (name!=NULL)
{
  if (fonts==NULL)
    fonts=newstack(5);
  if (fonts->n<num)
    for (i=fonts->n+1;i<=num;++i)
      pushstack(fonts,NULL);
  if (fonts->s[num]!=NULL)
    deinstallfont(num);
  fd=malloc(sizeof(*fd));
  fd->sizes=newstack(5);
  fd->pre=fd->post=NULL;
  fonts->s[num]=fd;
  /* preveri se, ce name predsstavlja font, ki se da skalirati: */
  point=memfind(name,strlen(name),scalestr,strlen(scalestr));
  if (point!=NULL)
  {
    fd->scalable=1;
    chr=*point;
    point+=2;
    *point='\0';
    fd->pre=stringcopy(name);
    *point=chr;
    ++point;
    fd->post=stringcopy(point);
  } else
  {
    fd->scalable=0;
    fd->pre=stringcopy(name);
    fd->post=NULL;
  }
}
/*
if(fd!=NULL)
  if (fd->pre!=NULL)
    printf("GI: Font %s installed (ID=%i).\n",fd->pre,num);
*/
if (name!=NULL)
  free(name);
}


static void giinstallfontnew(int num,char *name)
    /* Instalira font z imenom name na mesto num. */
{
int i;
int place;
fontdatastruct fd;
char *point,*scalestr="--0-",chr;
if (num<1)
  num=1;
if (name!=NULL)
{
  if (fonts==NULL)
    fonts=newstack(5);
  if (fonts->n<num)
    for (i=fonts->n+1;i<=num;++i)
      pushstack(fonts,NULL);
  if (fonts->s[num]!=NULL)
    deinstallfont(num);
  fd=malloc(sizeof(*fd));
  fd->sizes=newstack(5);
  fd->pre=fd->post=NULL;
  fonts->s[num]=fd;
  /* preveri se, ce name predsstavlja font, ki se da skalirati: */
  point=memfind(name,strlen(name),scalestr,strlen(scalestr));
  if (point!=NULL)
  {
    fd->scalable=1;
    chr=*point;
    /* point+=2; */ point=&(point[2]);
    /* *point='\0'; */
    place=point-name;
    fd->pre=stringncopy(name,place);
    /* *point=chr; */
    ++point;
    fd->post=stringcopy(point);
  } else
  {
    fd->scalable=0;
    fd->pre=stringcopy(name);
  }
}
/*
if(fd!=NULL)
  if (fd->pre!=NULL)
    printf("GI: Font %s installed (ID=%i).\n",fd->pre,num);
*/
}



static char namebuf[200];
char nonscalablefont;  /* spremenljivka, ki je 1, ce ima trenutno nalozen font
                          fiksno velikost. */
                

static void setfont(void)
    /* Postavi aktiven font na vrsto in velikost, kot sta doloceni v lokalnih
    spremenljivkah textfont in textsize. Najprej preveri, ce je bila serverju
    ze poslana zahteva, naj ta font nalozi. Ce ni, se poslje ta zahteva in
    na koncu se v nastavitve za risanje teksta v X nastavi identifikacijska
    stevilka, s katero je font dane vrste in vleikosti znan serverju. */
{
XFontStruct *locfontstruct=NULL;
float scalingfactor=1.25;
char goon=0;
fontdatastruct fd=NULL;
fontsizestruct fs=NULL;
int num,size,i;
nonscalablefont=1;
num=textfont; /* font */
size=(textheight*scalingfactor)*iwindowheight; /* celostevilcna velikost */
fontid=defaultfontid;
fontstruct=defaultfontstruct;
/*
printf("SF{");
*/
if (num<1)
  num=1;
if (size<1)
  size=1;
/* Najprej se pogleda, ce je font z ustrezno zaporedno stevilko instaliran
(ce obstaja font s to zaporedno stevilko na sklatu fonts): */
if (fonts!=NULL)
  if (fonts->n>0)
  {
    /* Ce font z zap. stevilko num ni instaliran, se vzame 1. font s sklada
    fonts: */
    if (num>fonts->n)
      num=1;
    if (fonts->s[num]==NULL)
      num=1;
    fd=fonts->s[num];
    if (fd!=NULL)
    {
      /* Prisli smo do instaliranega fonta. Zdaj poskusamo nastaviti font
      (naloziti ga, ce se ni nalozen, ali pa uporabiti podatke o nalozenem
      fontu). Preveri se sklad, na katerem so podatki o nalozenih fontih
      razlicnih velikosti: */
      if (fd->sizes==NULL)
        fd->sizes=newstack(5);
      /* Poisce se mesto, na katerem mora biti font zelene velikosti: */
      i=1;
      goon=1;
      if (fd->sizes->n>0)
        fs=fd->sizes->s[1];
      else
        fs=NULL;
      /* Ce se font ne da skalirati, ustreza ze 1. struktura na skladu
      fd->sizes. Drugace poiscemo na tem skladu predstavnika fonta ustrezne
      velikosti: */
      if (fd->scalable)
      {
        /* Smo pri 1. strukturi na skladu fd->sizes. Preveri se, ali je treba
        nadaljevati z iskanjem ustrezne velikosti (to je v primeru, ce 1.
        velikost ni prava in hkrati nismo prisli cez konec sklada. */
        if (fs!=NULL)
        {
          if (fs->size<size)
            goon=1;
          else
            goon=0;
          if (i>fd->sizes->n)
            goon=0;
        } else goon=0;
        /* Ce je potrebno, se isce ustrezno velikost naprej: */
        while (goon)
        {
          ++i;
          if (i<=fd->sizes->n)
            fs=fd->sizes->s[i];
          else
            fs=NULL;
          if (fs!=NULL)
          {
            if (fs->size<size)
              goon=1;
            else
              goon=0;
            if (i>fd->sizes->n)
              goon=0;
          } else goon=0;
        }
        /* Konec iskanja; Preveri se, ce je fs ustrezen: */
        if (fs!=NULL)
          if (fs->size!=size)
            fs=NULL;
      }
      if (fs!=NULL)
      {
        /* Nasli smo font prave velikosti, ki je ze nalozen: */
        fontid=fs->fontid;
        fontstruct=fs->fontstruct;
        /*
        printf("Nasli smo ze nalozen font velikosti Ii, fid=%i.\n");
        */
        if (fd->scalable)
          nonscalablefont=0;
        /*
        if (fd->scalable)
          printf("Old scalable. ");
        else printf("Old nonscalable.");
        */
      } else
      {
        /* Treba bo naloziti font zelene velikosti; Najprej se skonstruira niz,
        ki predstavlja ta font: */
        if (fd->scalable)
          sprintf(namebuf,"%s%i%s\0",fd->pre,size,fd->post);
        else
          sprintf(namebuf,"%s\0",fd->pre);
        /* Nalaganje fonta: */
        if ((locfontstruct=XLoadQueryFont(display,namebuf)) != NULL)
        {
          /* Ce se je font uspesno nalozil, se na ustrezno mesto sklada
          fd->sizes nalozijo podatki o velikosti fonta: */
          fontstruct=locfontstruct;
          fs=malloc(sizeof(*fs));
          insstack(fd->sizes,fs,i);
          fs->size=size;
          fs->fontid=fontstruct->fid;
          fs->fontstruct=fontstruct;
          fontid=fontstruct->fid;
          if (fd->scalable)
            nonscalablefont=0;
          /*
          if (fd->scalable)
            printf("New scalable. ");
          else
            printf("Nev non-scalable. ");
          */
        }
      }
    }
  }
/*
printf("}");
*/
}


static void installdefaultfonts(void)
    /* Instalira nekaj fontov. */
{
giinstallfont(1,"-adobe-courier-bold-r-normal--0-0-75-75-m-0-iso8859-1");
giinstallfont(2,"-adobe-helvetica-bold-r-normal--0-0-75-75-p-0-iso8859-1");
giinstallfont(3,"-adobe-new century schoolbook-bold-r-normal--0-0-75-75-p-0-iso8859-1");
giinstallfont(4,"-adobe-times-bold-r-normal--0-0-75-75-p-0-iso8859-1");
giinstallfont(5,"-b&h-lucidabright-demibold-r-normal--0-0-75-75-p-0-iso8859-1");
giinstallfont(6,"-bitstream-charter-bold-r-normal--0-0-75-75-p-0-iso8859-1");
giinstallfont(7,"-dec-terminal-bold-r-normal--0-0-75-75-c-0-iso8859-1");
giinstallfont(8,"-hp-hp system-bold-r-normal--0-0-85-85-p-0-iso8859-9");
giinstallfont(9,"-hp-hp user-medium-r-normal--0-0-85-85-m-0-iso8859-9");
giinstallfont(10,"-sony-fixed-medium-r-normal--0-0-100-100-c-0-jisx0201.1976-0");
}





/*********** FUNKCIJE ZA RAVNANJE Z BARVAMI: ************/

/* Ta del zajema funkcije za inicializacijo (vzpostavitev zelenega nacina
ravnanja z barvami) in funkcije za pretvorbo barv v celice X serverja */

/* SPLOSNE SPREMENLJIVKE: */


/* OSNOVNE KONSTANTE: */

static unsigned int MAXSHADES=65536; /* Strojna meja stevila odtenkov */


/* UPORABNIKOVA NAVODILA ZA DELO Z BARVAMI: */

static char ucoloring=1;
/* uporaba barv (v nasprotnem primeru sivi odtenki) */

static char upreindexall=0;
/* Ce je 1, se pri inicializaciji alocirajo vsi mozni pixli. */

static unsigned short unumshades=64;
/* Stevilo odtenkov barvnih komponent; 256 je dovolj za obcutek zveznega
prelivanja. Ce je 0, so barve zvezne (v tem primeru se tudi ne more uporabiti
indeksiranje). */

static int  uindexsize=1025;
/* Dolzina tabele indeksov Ce je to 0, naj se ne uporablja indeksiranje. */

static unsigned long unumprivatecells=0;
/* Stevilo celic v privatni tabeli. Ce je to 0, se ne alocira privat. tabela. */



/* SPREMENLJIVKE, KI SE UPORABLJAJO PRI PRETVORBI BARVA->PIXEL: */

static char coloring=1;

static char preindexall=0;

static int numshades=256; /* Stevilo odtenkov barvnih komponent */

static int shadefactor=256; /* MAXSHADES/numshades */

static unsigned long numdiscretecolors;
/* Stevilo vseh moznih diskretnih barv; pri sivih odtenkih je to numshades, pri
barvnih pa numshades^3. */

static int indexsize=0; /* Velikost indeksnih tabel */

static int numindeces=0;  /* Stevilo indeksov v tabeli */

static unsigned long *pixeltab=NULL;
/* Tabela pikslov, ki pripadajo ustreznim   indeksom tabele indextab */

static unsigned long *indextab=NULL;
/* Tabela indeksov, ki pripadajo ustreznim pikslom */
static unsigned long numprivatecells;

static int freecells=0;


/* STOPNJE PRI PRETVORBI BARVE V PIXEL: */


static truecolorstruct true;    /*komponente barve */


static unsigned short ired,igreen,iblue; /* diskretni indeksi komponent */

static XColor color;  /* komponente diskretne barve in pixel; S komponentami
                      server alocira barvno celico in vrne pixel */

static unsigned long index; /* Indeks, ki enolicno doloca diskretno barvo */

static char allocated; /* Ce je 1, je bil pixel uspesno alociran. */


/* OSNOVNE FUNKCIJE PRETVORBE: */

static void indextodiscretecolor(void)
{
/*
color.red=ired*shadefactor+ired;
color.green=igreen*shadefactor+igreen;
color.blue=iblue*shadefactor+iblue;
*/
color.red=ired*shadefactor+(ired*shadefactor)/numshades;
color.green=igreen*shadefactor+(igreen*shadefactor)/numshades;
color.blue=iblue*shadefactor+(iblue*shadefactor)/numshades;

}

static void indextodiscretegray(void)
{
color.red=color.green=color.blue=ired*shadefactor+ired;
}

static void truetodiscretecolor(void)
    /* Komponente realne barve pretvori v diskretne komponente, ce se
    uporabljajo barve. */
{
/*
if (
!(
   (true.red>=0&&true.red<=1) &&
   (true.green>=0&&true.green<=1) &&
   (true.blue>=0&&true.blue<=1)
)
)
  printf("NAPACNE BARVE!!!! R=%gG=%gB=%g\n",true.red,true.green,true.blue);
*/
ired=true.red*(numshades-1);
igreen=true.green*(numshades-1);
iblue=true.blue*(numshades-1);
color.red=ired*shadefactor+ired;
color.green=igreen*shadefactor+igreen;
color.blue=iblue*shadefactor+iblue;
}

static float grayintensity;
static void truetodiscretegray(void)
    /* Komponente realne barve pretvori v diskretne komponente, ce se
    uporabljajo sivi odtenki. */
{
grayintensity=(true.red+true.green+true.blue)/3;
ired=igreen=iblue=grayintensity*(numshades-1);
color.red=color.green=color.blue=ired*shadefactor+ired;
}

static void (*truetodiscrete) (void) = truetodiscretecolor;
    /* Funkcija, ki se dejansko klice pri pretvorbi realne barve v diskretne
    komponente; Po inicializaciji mora biti to naslov ene od funkcij
    truetodiscretecolor() ali truetodiscretegray(). */

static void discretetoindexcolor(void)
    /* Diskretne komponente barve enolicno pretvori v indeks (identifikacijsko
    stevilko) barve v primeru, ko se uporabljajo barvni odtenki. Mapiranje treh
    komponent barve v indeks je odvisno od stevila odtenkov numshades. */
{
index=ired+igreen*(numshades)+iblue*(numshades*numshades);
}

static void discretetoindexgray(void)
    /* Diskretne komponente barve enolicno pretvori v indeks (identifikacijsko
    stevilko) barve v primeru, ko se uporabljajo sivi odtenki. Mapiranje je
    odvisno od stevila odtenkov numshades. */
{
index=ired;
}

static void (*discretetoindex) (void) = discretetoindexcolor;
   /* Funkcija, ki se dejansko uporabi pri pretvorbi diskretnih komponent v
   indeks. Po inicializaciji je to naslov ene od funkcij discretetoindexcolor()
   in discretetoindexgray(). */

static void directtopixel(void)
    /* Komponente diskretne barve pretvori v pixel */
{
/*
printf("RGB=(%i,%i,%i)\n",color.red,color.green,color.blue);
*/
allocated=1;
if (XAllocColor(display,colormap,&color)==0)
{
  printf("X: Can not allocate a cell for color (%i,%i,%i).\n",color.red,color.green,color.blue);
  color.pixel=BlackPixel(display,DefaultScreen(display));
  allocated=0;
}
}

static char indexfound;
static unsigned long indexplace;
static unsigned long *pointindex;

static int compareindeces(const void *p1,const void*p2)
    /* Ta funkcija naj bi se uporabila pri iskanju indeksa na skladu indextab
    s pomocjo standardne funkcije qsort, kar iz neznanih razlogov ne deluje,
    tako da se zaenkrat uporablja pocasnejsi nacin iskanja, kjer se po vrsti
    preverjajo indeksi, dokler se ne najde pravi ali pride do konca tabele. */
{
if (*(long*)p1<*(long*)p2)
  return -1;
else if (*(long*)p1==*(long*)p2)
  return 0;
else
  return 1;
}

static void findindex(void)
    /* V tabeli indextab se poisce indeks, ki je enak *pointindex. V primeru
    uspesnega iskanja se njegovo mesto v tabeli zapise v indexplace, indexfound
    pa postane 1. Ce iskanje ni uspesno, postane indexfound 0. */
    
{
if (indextab!=NULL)
{
  if (numindeces==numdiscretecolors) /* Tabela indeksov pokriva vse barve */
  {
    indexplace=index;
    indexfound=1;
  } else
  {
    /*
    pointindex=bsearch(indextab,&index,
                        numindeces,sizeof(*indextab),compareindeces);
    if (pointindex==NULL)
      indexfound=0;
    else
    {
      indexfound=1;
      indexplace=pointindex-indextab;
    }
    */
    indexplace=0;
    while(indextab[indexplace]!=index && indexplace<numindeces)
      ++indexplace;
    if (indexplace<numindeces)
      indexfound=1;
    else
      indexfound=0;
  }
}
}


/*
static void freepixels(void)
{
if (numindeces>0 && pixeltab!=NULL)
{
  if (freecells>numindeces)
    freecells=numindeces/2;
  if (freecells>0)
  {
    XFreeColors(display,colormap,
     &(pixeltab[numindeces-freecells-10]) ,freecells,0);
    printf("FREEEEEEEEEING COLORS.\n");
  }
}
}
*/



static void freepixels(void)
    /* Ta funkcija naj bi se uporabljala za sprostitev nekaj barvnih celic iz
    barvne tabele, da bi bilo mozno alocirati nove celice. Zaenkrat ne dela v
    redu zaradi nevarnosti, da se prekine zveza s serverjem v primeru, da se
    poskusa sprostiti celica, ki jo je alociral ali jo uporablja kak drug
    program. Tezava je v tem, da zaenkrat ni znan nacin, kako ugotoviti,
    katere celice se lahko sprosti in katerih se ne sme. */
{
int numcleared=0;
unsigned long clearedindex=indexsize+1;
int place,i;

unsigned long blackpixel,whitepixel;
blackpixel=BlackPixel(display,DefaultScreen(display));
whitepixel=WhitePixel(display,DefaultScreen(display));

if (numindeces>0 && pixeltab!=NULL)
{
  if (freecells>numindeces)
    freecells=numindeces/2;
  if (freecells>0)
  {
    place=0;
    numcleared=0;
    while (place<numindeces && numcleared<freecells)
    {
      if (pixeltab[place]!=blackpixel && pixeltab[place]!=whitepixel)
      {
        printf("FREING COLOR PIXEL no. %i (index %i):\n",pixeltab[place],indextab[place]);
        XFreeColors(display,colormap,&(pixeltab[place]),1,0);
        ++numcleared;
        indextab[place]=clearedindex;
      }
      ++place;
    }
    /* Treba je se zapolniti luknje v tabeli indeksov in pixlov: */
    place=0;
    for (i=0;i<numindeces;++i)
    {
      if (indextab[i]!=clearedindex)
      {
        indextab[place]=indextab[i];
        pixeltab[place]=pixeltab[i];
        ++place;
      } else
        --numindeces;
    }

  }
}
}




static void markindex(void)
    /* index zadnje alocirane barve (ki je v lokalni spremenljivki index), se
    spravi v tabelo indeksov indextab. Hkrati se na isto mesto v tabeli pixlov
    pixeltab zapise ustrezen pixel (identifikacijska stevilke, ki predstavlja
    ustrezno barvo v serverju) */
{
long i,j;

if (freecells>0 && numindeces>=indexsize)
  freepixels();
if (indexsize>numindeces && indextab!=NULL && pixeltab!=NULL)
/* Ce je v indeksni tabeli se prostor, postavimo indeks na svoje mesto */
{
  i=-1;
  /* Najde se 1. element tabele, ki ni manjsi od index: */
  do
  {
    ++i;
  } while (indextab[i]<index && i<numindeces);
  /* index bo zavzel mesto tega elementa, zato je treba vse elemente od tega
  naprej premakniti za eno mesto v desno. */
  if (i<numindeces)
  {
    for (j=numindeces;j>i;--j)
    {
      indextab[j]=indextab[j-1];
      pixeltab[j]=pixeltab[j-1];
    }
  }
  indextab[i]=index;
  pixeltab[i]=color.pixel;
  ++numindeces;
}
}

/*
static int ind=0;
*/

static void indextopixel(void)
    /* Barvo pretvori v pixel, pri cemer najprej poskusi z iskanjem indeksov po
    tabeli indextab. Ce indeks barve v tej tabeli ne obstaja, najde pixel z
    direktno pretvorbo iz diskretne barve prek alokacije celice s serverjem */
{
/*
if (ind>130)
{
  ind=ind+1;
  --ind;
}
printf(".");
*/
findindex();
/*
if (!indexfound)
{
  ++ind;
  printf(" %i ",ind);
}
*/
if (indexfound)
{
  color.pixel=pixeltab[indexplace];
} else
{
  directtopixel();
  /*
  if (allocated)
  */
  markindex();
}
}



static void calculatepixel(void)
    /* Pixel (identifikacijsko stevilko), ki pripada barvi, zapisani v lokalni
    spremenljivki true, zapise v lokalno spremenljivko pixel. Vrednost pixla
    se dobi prek serverja, ki po potrebi alocira barvno celico. */
{
if (indexsize>0)
{
  truetodiscrete();
  discretetoindex();
  indextopixel();
} else
  directtopixel();
}



static void indexallcolors(void)
    /* Indeksira vse mozne barve (kar pomeni, dazanje tudi alocira celice v
    barvni tabeli). */
{
int i;
if (coloring)
{
  for (ired=0;ired<numshades;++ired)
    for (igreen=0;igreen<numshades;++igreen)
      for (iblue=0;iblue<numshades;++iblue)
      {
        indextodiscretecolor();
        discretetoindexcolor();
        directtopixel();
        if (indexsize>index)
        {
          pixeltab[index]=color.pixel;
          indextab[index]=index;
          ++numindeces;
        }
      }
} else
{
  if (indexsize>=numshades)
    for (i=0;i<numshades;++i)
    {
      ired=igreen=iblue=i;
      indextodiscretegray();
      discretetoindexgray();
      directtopixel();
      pixeltab[index]=color.pixel;
      indextab[index]=index;
      ++numindeces;
    }
}
}


static void initcolorhandling(void)
    /* Inicializira podsistem za ravnanje z barvami. S to funkcijo pridejo
    do veljave tudi nastavitve, ki jih glede ravnanja z barvami nastavi upo-
    rabnik. */
{
coloring=ucoloring;
numshades=unumshades;
if (numshades<0)
  numshades=0;
if (numshades==1)
  numshades=2;
indexsize=uindexsize;
if (indexsize<0)
  indexsize=0;
numprivatecells=unumprivatecells;
if (numprivatecells<0)
  numprivatecells=0;
/* Ce ni mapiranja v diskretne barve, tudi indeksiranja ne more biti: */
if (numshades==0)
  indexsize=0;
shadefactor=MAXSHADES/numshades;
if (coloring && numshades>0)
  numdiscretecolors=numshades*numshades*numshades;
else
  numdiscretecolors=numshades;  /* sivi odtenki */
if (numshades==0)
  numdiscretecolors=0;
numindeces=0;
if (indexsize!=0)
{
  indextab=realloc(indextab,(indexsize+1)*sizeof(*indextab));
  pixeltab=realloc(pixeltab,(indexsize+1)*sizeof(indextab));
}
if (coloring)
{
  truetodiscrete=truetodiscretecolor;
  discretetoindex=discretetoindexcolor;
} else
{
  truetodiscrete=truetodiscretegray;
  discretetoindex=discretetoindexgray;
}
if (upreindexall)
  preindexall=1;
else
  preindexall=0;
/* Vnaprejsnje indeksiranje ni mozno, ce je na razpolago manj indeksov kot je
vseh barv: */
if (indexsize<numdiscretecolors)
  preindexall=0;
if (preindexall)
  indexallcolors();
/*    Alokacija privatnih tabel:
.........


*/

}


static void printcolorhandlingstatus(void)
    /* Izpise nastavitve, ki se ticejo ravnanja z barvami. */
{
printf("IG coloring status:\n");
if (coloring)
  printf("Using RGB colors.\n");
else
  printf("Using gray scale.\n");
if (numshades==0)
  printf("Using continuous colors.\n");
else
{
  printf("Number of shades: %i\n",numshades);
  printf("Number of colors: %i\n",numdiscretecolors);
}
if (indexsize>0)
{
  printf("Size of index table: %i\n",indexsize);
  printf("Number of indeces used: %i\n",numindeces);
  if (numindeces==numdiscretecolors)
    printf("Cells for all possible colors are allocated.\n");;
} else printf ("No indexing.\n");
}








void gicoloring(int yes)
    /* Ce je yes 0, bodo grafi izrisani v sivih odtenhih, drugace pa v barvnih.
    funkcija ima efekt, ce jo klicemo pred giinitdisplay(). */
{
if (yes)
  ucoloring=1;
else
  ucoloring=0;
}

void ginumshades(int num)
    /* Nastavi stevilo barvnih odtenkov vsake komponente barve na num. Funkcija
    ima efekt, ce jo klicemo pred initdisplay(). Ce je num 0, so barve zvezne
    (v tem primeru se tudi ne more uporabiti indeksiranje). */
{
if (num==1 || num<0)
  num=2;
if (num>1024)
  num=1024;
unumshades=num;
}

void gicolortabsize(int size)
    /* Nastavi velikost tabele, v kateri so shranjeni indeksi ze alociranih
    barvnih celic, na size. Ce je size 0, se ne uporablja indeksiranje in se
    pri vsaki uporabi katerekoli barve prenese X serverju ukaz za alokacijo
    ustrezne barvne celice ne glede na to, ali je bila tista barva ze prej
    uporabljena. */
{
if (size<0)
  size=0;
uindexsize=size;
}

void gipreindexcolors(int yes)
    /* Ce je yes 0, se zahteve za alokacijo barvnih celic dajejo serverju
    sproti, ce je 1, pa se predhodno (ob inicializaciji zaslona) rezervirajo
    celice za vse mozne barve (seveda le, ce je tabela indeksov dovolj
    velika). */
{
if (yes)
  upreindexall=1;
else
  upreindexall=0;
}





void gisetwindowtitle(char *title)
     /* Naslov oken, ki se na novo odpirajo, postavi na title. */
{
windowtitle=title;
}

char *gigetwindowtitle(void)
{
return windowtitle;
}

float gisetwindowxpos(float z)
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri x na z. Vrne prej.
    pozicijo. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */
{
float ret;
ret=windowxpos;
if (z>=0 && z<=1)
{
  windowxpos=z;
  iwindowxpos=(int) (z*MAXX);
}
return ret;
}

float gigetwindowxpos(void)
{
return windowxpos;
}


float gisetwindowypos(float z)
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri y na z. Vrne prej.
    pozicijo. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */
{
float ret;
ret=windowypos;
if (z>=0 && z<=1)
{
  windowypos=z;
  iwindowypos=(int) (z*MAXY);
}
return ret;
}

float gigetwindowypos(void)
{
return windowypos;
}


float gisetwindowwidth(float z)
    /* Postavi zaceto sirino oken pri odpiranju v smeri na z. Vrne prej.
    sirino. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */
{
float ret;
ret=windowwidth;
if (z>=0 && z<=1)
{
  windowwidth=z;
  iwindowwidth=(int) (z*MAXX);
}
return ret;
}

float gigetwindowwidth(void)
{
return windowwidth;
}


float gisetwindowheight(float z)
    /* Postavi zaceto visino oken pri odpiranju v smeri na z. Vrne prej.
    visino. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */
{
float ret;
ret=windowheight;
if (z>=0 && z<=1)
{
  windowheight=z;
  iwindowheight=(int) (z*MAXY);
}
return ret;
}

float gigetwindowheight(void)
{
return windowheight;
}



int ginsetwindowxpos(int z)
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri x na z. Vrne prej.
    pozicijo.
    $A Igor maj97; */
{
int ret;
ret=iwindowxpos;
windowxpos=(float) z/MAXX;
iwindowxpos=z;
return ret;
}

int gingetwindowxpos(void)
    /* $A Igor maj97; */
{
return iwindowxpos;
}


int ginsetwindowypos(int z)
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri y na z. Vrne prej.
    pozicijo.
    $A Igor maj97; */
{
int ret;
ret=iwindowypos;
windowypos=(float) z/MAXY;
iwindowypos=z;
return ret;
}

int gingetwindowypos(void)
    /* $A Igor maj97; */
{
return iwindowypos;
}


int ginsetwindowwidth(int z)
    /* Postavi zaceto sirino oken pri odpiranju v smeri na z. Vrne prej.
    sirino.
    $A Igor maj97; */
{
int ret;
ret=iwindowwidth;
windowwidth=(float) z/MAXX;
iwindowwidth=z;
return ret;
}

int gingetwindowwidth(void)
    /* $A Igor maj97; */
{
return iwindowwidth;
}


int ginsetwindowheight(int z)
    /* Postavi zaceto visino oken pri odpiranju v smeri na z. Vrne prej.
    visino.
    $A Igor maj97; */
{
int ret;
ret=iwindowheight;
windowheight=(float) z/MAXY;
iwindowheight=z;
return ret;
}

int gingetwindowheight(void)
    /* $A Igor maj97; */
{
return iwindowheight;
}



float gisetpointsize(float size)
      /* Nastavi velikost tock. Vrne trenutno velokost. */
{
float ret=pointsize;
if (size>0 && size<=1)
  pointsize=size;
else
  pointsize=0.01;
return ret;
}

float gigetpointsize(void)
{
return pointsize;
}


int gisetcurvepoints(int num)
    /* Nastavi stevilo vmesnih tock pri risanju krivuljnih objektov, npr.
    kroznic. Vrne trenutno stevilo tock. */
{
int ret=curvepoints;
if (num>1)
  curvepoints=num;
else
  curvepoints=15;
return ret;
}

int gigetcurvepoints()
{
return curvepoints;
}



static float testcolor(float color)
       /* Ce barvna komponenta ni v dovoljenem obsegu, jo postavi v dovoljen
       obseg in jo vrne, drugace vrne nespremenjno komponento. To funkcijo
       uporabljajo funkcije za nastavitev barv. */
{
if ( !(color>=0.0 && color<=1.0) )
{
  /*
  linemask&=(!GCForeground);
  fillmask&=(!GCForeground);
  textmask&=(!GCForeground);
  fprintf(stderr," CE ");
  */
  /* fprintf(stderr,"TESTCOLOR error;\n"); */
  /* color=0; */
  if (color<0)
    color=0;
  else if (color>1)
    color=1;
  else color=0;
} /* else fprintf(stderr," OK "); */
/*
if (color<0.0)
  return 0.0;
else if (color>1.0)
  return 1.0;
else
  return color;
*/
return color;
}


void gisetlinecolor(float red,float green,float blue)
     /* Nastavi barvo za risanje crt. */
{
linecolor.red=testcolor(red);  linecolor.green=testcolor(green);
linecolor.blue=testcolor(blue);
true.red=linecolor.red;
true.green=linecolor.green;
true.blue=linecolor.blue;
/* Barva se pretvori v vrednost, ki identificira to barvo v barvni mapi. Ta
vrednost je po pretvorbi v color.pixel in se prepise v linegcv.pixel; linegcv
se uporabi pri spreminjanju graficnega konteksta ob izrisu prve stvari, ki
uporablja linecolor (zahtevo po spremembi graficnega konteksta nosi v tem
primeru linemask). */
calculatepixel();
linegcv.foreground=color.pixel;
/* Maski za nastavitve pri risanju crt se doda zahteva po spremembi barve
ospredja. Ta sprememba se izvrsi sele ob izrisu prve stvari, ki je odvisna od
nastavitev za risanje crt, to pa zato, da se hkrati s tem lahko spremenijo se
morebitne druge nastavitve za risanje crt; na ta nacin se zmanjsa stevilo
zahtev za X server, s cemer se pohitri izvajanje: */
linemask|=GCForeground;
}

void gigetlinecolor(float *red,float *green,float *blue)
{
*red=linecolor.red; *green=linecolor.green; *blue=linecolor.blue;
}


void gisetfillcolor(float red,float green,float blue)
     /* Nastavi barvo za risanje zapolnjenih likov */
{
/*
if (! (red>=0&&red<=1&&green>=0&&green<=1&&blue>=0&&blue<=1) )
{
  fprintf(stderr,"Neveljavne vrednosti barv !!!\n");
}
*/
fillcolor.red=testcolor(red);  fillcolor.green=testcolor(green);
fillcolor.blue=testcolor(blue);
true.red=fillcolor.red;
true.green=fillcolor.green;
true.blue=fillcolor.blue;
/* Barva se pretvori v vrednost, ki identificira to barvo v barvni mapi. Ta
vrednost je po pretvorbi v color.pixel in se prepise v fillgcv.pixel; fillgcv
se uporabi pri spreminjanju graficnega konteksta ob izrisu prve stvari, ki
uporablja fillcolor (zahtevo po spremembi graficnega konteksta nosi v tem
primeru fillmask). */
calculatepixel();
fillgcv.foreground=color.pixel;
/* Maski za nastavitve pri risanju likov se doda zahteva po spremembi barve
ospredja. Ta sprememba se izvrsi sele ob izrisu prve stvari, ki je odvisna od
nastavitev za risanje likov, to pa zato, da se hkrati s tem lahko spremenijo se
morebitne druge nastavitve za risanje likov; na ta nacin se zmanjsa stevilo
zahtev za X server, s cemer se pohitri izvajanje: */
fillmask|=GCForeground;
}

void gigetfillcolor(float *red,float *green,float *blue)
{
*red=fillcolor.red; *green=fillcolor.green; *blue=fillcolor.blue;
}


static int lwidth=1;

void gisetlinewidth(double width)
     /* Nastavi sirino crt pri risanju (velja tudi za nezapolnjene like) */
{
if (width<1)
  width=1;
linewidth=width;
lwidth=(int) width;
linegcv.line_width=lwidth;
linemask|=GCLineWidth;
}

double gigetlinewidth(void)
{
return linewidth;
}



void gisetlinetype(int type)
     /* Nastavi tip crt; Ce je tip enak 1, socrte neprekinjene. */
{
if( type<1)
  type=1;
else if (type>3)
  type=3;
linetype=type;
if (linetype==1)
  linegcv.line_style=LineSolid;
else if (linetype==2)
  linegcv.line_style=LineOnOffDash;
else if (linetype==3)
  linegcv.line_style=LineDoubleDash;
linemask|=GCLineStyle;
}

int gigetlinetype(void)
{
return linetype;
}



void gisettextcolor(float red,float green,float blue)
     /* Nastavi barvo teksta. */
{
textcolor.red=testcolor(red);  textcolor.green=testcolor(green);
textcolor.blue=testcolor(blue);
true.red=textcolor.red;
true.green=textcolor.green;
true.blue=textcolor.blue;
/* Barva se pretvori v vrednost, ki identificira to barvo v barvni mapi. Ta
vrednost je po pretvorbi v color.pixel in se prepise v textgcv.pixel; textgcv
se uporabi pri spreminjanju graficnega konteksta ob izrisu prve stvari, ki
uporablja textcolor (zahtevo po spremembi graficnega konteksta nosi v tem
primeru textmask). */
calculatepixel();
textgcv.foreground=color.pixel;
/* Maski za nastavitve pri risanju teksta se doda zahteva po spremembi barve
ospredja. Ta sprememba se izvrsi sele ob izrisu prve stvari, ki je odvisna od
nastavitev za risanje teksta, to pa zato, da se hkrati s tem lahko spremenijo se
morebitne druge nastavitve za risanje teksta; na ta nacin se zmanjsa stevilo
zahtev za X server, s cemer se pohitri izvajanje: */
textmask|=GCForeground;
}

void gigettextcolor(float *red,float *green,float *blue)
{
*red=textcolor.red; *green=textcolor.green; *blue=textcolor.blue;
}


void gisettextprecision(float precision)
     /* Ta funkcija ni izdelana do konca! */
{
textprecision=0;
}

float gigettextprecision()
{
return textprecision;
}


void gisettextfont(int font)
     /* Nastavi pisavo, ki se uporablja pri tekstu. */
{
textfont=font;
if (textfont<1)
  textfont=1;
}

int gigettextfont(void)
{
return textfont;
}



void gisettextheight(float height)
     /* Nastavi velikost (visino) teksta. */
{
textheight=height;
if (textheight<=0.0)
  textheight=0.01;
}

float gigettextheight(void)
{
return textheight;
}


void gisettextspacing(float spacing)
     /* Nastavi velikost presledkov med crkami pri tekstu. */
{
textspacing=spacing;
if (textspacing<0.0)
  textspacing=0.0;
}

float gigettextspacing(void)
{
return textspacing;
}


void gisettextexpansion(float expansion)
     /* Nastavi razsiritev teksta v vodoravni smeri. */
{
textexpansion=expansion;
if (textexpansion<=0.0)
  textexpansion=1.0;
}

float gigettextexpansion(void)
{
return textexpansion;
}


void gisettextxalignment(int alignment)
     /* Nastavi poravnavanje teksta v vodoravni smeri. Ce je alignment -1, je
     poravnavanje levo, ce je 0, je centrirano, ce pa je 1, je desno. */
{
textxalignment=alignment;
}

int gigettextxalignment(void)
{
return textxalignment;
}


void gisettextyalignment(int alignment)
     /* Nastavi poravnavanje teksta v navpicni smeri. Ce je -1, je poravnavanje
     spodnje, ce je 0, je centrirano, ce pa je 1, je zgornje. */
{
textyalignment=alignment;
}

int gigettextyalignment(void)
{
return textyalignment;
}


void gisettextalignment(int xalignment,int yalignment)
     /* Hkrati nastavi poravnavanje teksta v obeh smereh, pri cemer uporablja
     funkciji gisettextxalignment in settextyalignment. */
{
gisettextxalignment(xalignment);
gisettextyalignment(yalignment);
}

void gigettextalignment(int *xalignment,int *yalignment)
{
*xalignment=textxalignment;  *yalignment=textyalignment;
}






int giinitdisplay(void)
    /* Odpre display. */
{
titleigs(10);
/* Open the X connection and initialize PEX on it. */
if ((display=XOpenDisplay(displayname))==NULL)
{
  fprintf(stderr,"GI: Can not open display \"%s\".\n",displayname);
} else
{
  screen=DefaultScreen(display);  /* zaslon */
  MAXX=DisplayWidth(display,screen);
  MAXY=DisplayHeight(display,screen);
  mapsize=DisplayCells(display,screen);  /* st. celic barvne mape */
  colormap=DefaultColormap(display,screen);  /* barvna mapa */
  defaultfontstruct=XLoadQueryFont(display,defaultfontname);
  fontstruct=defaultfontstruct;
  if (defaultfontstruct==NULL)
  {
    fprintf(stderr,"Default font \"%s\" is not available.\n",defaultfontname);
    defaultfontid=0;
  } else
    defaultfontid=defaultfontstruct->fid;
  defaultbgpixel=WhitePixel(display,screen);
  defaultfgpixel=BlackPixel(display,screen);
  bgpixel=defaultbgpixel; fgpixel=defaultfgpixel;
  fontid=defaultfontid;
  windowtitle=stringcopy("IGS_1.0/Xlib");
  initcolorhandling();
  printf("Initializing graphic display.\n");
  printcolorhandlingstatus();
  if (fonts==NULL)
    installdefaultfonts();
}
return 0;
}




int giinitgraph(void)
    /* Zacetne nastavitve za grafiko. To funkcijo se lahko pozene le enkrat ne
    glede na stevilo oken, ki so odprta (nastavitve veljajo za vsa okna). */
{

gisetwindowtitle("IGS_1.0/Xlib");
gisetwindowxpos(0.);
gisetwindowypos(0.);
gisetwindowwidth(0.3);
gisetwindowheight(0.3);

gisetlinecolor(0.8,0.2,0.2);
gisetfillcolor(0.2,0.8,0.2);
gisetlinewidth(1);
gisetlinetype(1);

gisettextcolor(0.8,0.5,0.8);
gisettextprecision(1.0);
gisettextfont(1);
gisettextheight(0.05);
gisettextspacing(0.2);
gisettextexpansion(1.0);
gisettextxalignment(0);
gisettextyalignment(0);

curvepoints=20;
pointsize=0.01;

}



static void checkwindowgeometry(void)
{
Window root;
unsigned int width,height,borderwidth,depth;
if (XGetGeometry(display,window,&root,&iwindowxpos,&iwindowypos,
     &width,&height,&borderwidth,&depth) == 0)
  fprintf(stderr,"GI: Can not determine window geometry.\n");
iwindowwidth=(int)width; iwindowheight=(int)height;
if (1)
{
  /* Garancija, da je obmocje, v katerega risemo, kvadratno in ne pravokotno: */
  iwindowwidth=(iwindowwidth<iwindowheight?iwindowwidth:iwindowheight);
  iwindowheight=iwindowwidth;
}
}


static XWMHints   *wmh=NULL;
static XSizeHints *wsh=NULL;
static XClassHint *wch=NULL;
static int bandwidth=1;
static XTextProperty wname,iname; /* ime okna in ikone */
static XGCValues gcv;
static XSetWindowAttributes winat;

int giopenwindow(void)
    /* Odpre novo okno. Vrne identifikacijsko stevilko tega okna, s to stevilko
    se nato sklicujemo na to okno v programu. Okno, ki ga odpre, postane
    aktivno. */
{
winstruct win=NULL;
if (windows==NULL)        /* Sklad, na katerem so podatki o oknih */
  windows=newstack(5);
if ((wsh=XAllocSizeHints()) == NULL)
  fprintf(stderr,"GI: Error allocating size hints.\n");
else
{
  wsh->flags=(PPosition | PSize | PMinSize);
  wsh->min_width=10;
  wsh->min_height=10;
  wsh->width=iwindowwidth;
  wsh->height=iwindowheight;
  wsh->x=iwindowxpos;
  wsh->y=iwindowypos;
  wsh->flags |= USPosition;
  wsh->flags |= USSize;
}
/* Kreiranje okna: */
window=XCreateSimpleWindow(display,DefaultRootWindow(display),
        wsh->x,wsh->y,wsh->width,wsh->height,bandwidth,fgpixel,bgpixel);
/* Nastavitev lastnosti za window manager (ime okna in ikone) */
if ((wch=XAllocClassHint()) == NULL)
{
  fprintf(stderr,"GI: Error allocating class hint.\n");
} else
{
  wch->res_name="IGS";
  wch->res_class="XApplication";
}
if (XStringListToTextProperty(&windowtitle,1,&wname) == 0 ||
    XStringListToTextProperty(&windowtitle,1,&iname) == 0)
  fprintf(stderr,"GI: Error creating XTextProperty.\n");

if((wmh=XAllocWMHints()) == NULL)
{
  fprintf(stderr, "GI: Error allocating Window Manager hints.\n");
} else
{
  wmh->flags=(InputHint|StateHint);
  wmh->input=False;
  wmh->initial_state=NormalState;
}
XSetWMProperties(display,window,&wname,&iname,NULL,0,wsh,wmh,wch);
/* Kreiranje graficnega konteksta za okno: */
gcv.font=fontid;
gcv.foreground=fgpixel;
gcv.background=bgpixel;
gc=XCreateGC(display, window,(GCFont|GCForeground|GCBackground),&gcv);
/* Nastavitev okenskih lastnosti: */
winat.colormap=colormap;
winat.bit_gravity=CenterGravity;
XChangeWindowAttributes(display, window,(CWColormap | CWBitGravity),&winat);
/* Izbira vhodnih dogodkov: */
XSelectInput(display, window,ExposureMask | ButtonPressMask);
/* Mapiranje okna: */
XMapWindow(display,window);
/* Dobi se 1. event (ki je tipa expose), da se okno v resnici izrise: */
/*
XNextEvent(display,&event);
*/
/* Preveri se trenutna geometrija okna: (nastavijo se iwindowxpos itd.) */
checkwindowgeometry();
/* Osnovni podatki o oknu se shranejo v *win, win se nato potisne na sklad: */
win=malloc(sizeof(*win)); /* Podatki o oknu */
win->id=window;
win->open=1;
win->gc=gc;
win->width=iwindowwidth;
win->height=iwindowheight;
pushstack(windows,win);
return (windows->n);
}




int gisetwindow(int num)
    /* Okno z zaporedno stevilko num naredi za aktivno. */
{
winstruct ws;
char ok=0;
if (windows!=NULL)
  if (num>0 && num<=windows->n)
    if (windows->s[num]!=NULL)
    {
      activewindow=num;
      ws=windows->s[num];
      window=ws->id;
      gc=ws->gc;
      checkwindowgeometry();
      ok=1;
      iwindowwidth=ws->width;
      iwindowheight=ws->height;
    }
if (!ok)
  fprintf(stderr,"GI: Can not make window %i active.\n",num);
}


void giresetwindow(void)
     /* Resetiranje aktivnega okna. Vsebina okna se zbrise. */
{

XClearWindow(display,window);
checkwindowgeometry();
}

void giclosewindow(void)
     /* Zapre aktivno okno. */
{
if (windows!=NULL)
  if (activewindow>0 && activewindow<=windows->n)
    if (windows->s[activewindow]!=NULL)
    {
      XDestroyWindow(display,window);
      free(windows->s[activewindow]);
      windows->s[activewindow]=NULL;
    }
}

void giclearwindow(void)
     /* Zbrise vsebino aktivnega okna. */
{
XClearWindow(display,window);
}

void giflushdisplay(void)
     /* Povzroci izris vsega, kar se se ni izrisalo. */
{
XFlush(display);
}



void giline(float x1,float y1,float x2,float y2)
     /* Narise crto med tockama (x1,y1) in (x2,y2). */
{
if (linemask) /* Ce je treba nastaviti katero od nastavitev za risanje crt: */
{
  if (linemask & GCForeground)
  {
    /* Ce se spremeni barva ospredja, je treba povedati, naj se pri naslednjem
    izrisu teksta ali zapolnjenih likov le-ta ponovno nastavi: */
    fillmask|=GCForeground;
    textmask|=GCForeground;
  }
  /* Nastavitev lastnosti pri risanju crt: */
  XChangeGC(display,gc,linemask,&linegcv);
  linemask=0;
}
XDrawLine(display,window,gc,xcoord(x1),ycoord(y1),xcoord(x2),ycoord(y2));
}

void gitriangle(float x1,float y1,float x2,float y2,float x3,float y3)
     /* Narise trikonik iz crt z oglisci (x1,y1), (x2,y2) in (x3,y3). */
{
if (linemask) /* Ce je treba nastaviti katero od nastavitev za risanje crt: */
{
  if (linemask & GCForeground)
  {
    /* Ce se spremeni barva ospredja, je treba povedati, naj se pri naslednjem
    izrisu teksta ali zapolnjenih likov le-ta ponovno nastavi: */
    fillmask|=GCForeground;
    textmask|=GCForeground;
  }
  /* Nastavitev lastnosti pri risanju crt: */
  XChangeGC(display,gc,linemask,&linegcv);
  linemask=0;
}
points[0].x=xcoord(x1);  points[0].y=ycoord(y1);
points[1].x=xcoord(x2);  points[1].y=ycoord(y2);
points[2].x=xcoord(x3);  points[2].y=ycoord(y3);
points[3].x=xcoord(x1);  points[3].y=ycoord(y1);
XDrawLines(display,window,gc,points,4,CoordModeOrigin);
}


void gifourangle(float x1,float y1,float x2,float y2,float x3,float y3,
               float x4,float y4)
     /* Narise stirikotnik iz crt z oglisci (x1,y1), (x2,y2), (x3,y3) in
     (x4,y4). */
{
if (linemask) /* Ce je treba nastaviti katero od nastavitev za risanje crt: */
{
  if (linemask & GCForeground)
  {
    /* Ce se spremeni barva ospredja, je treba povedati, naj se pri naslednjem
    izrisu teksta ali zapolnjenih likov le-ta ponovno nastavi: */
    fillmask|=GCForeground;
    textmask|=GCForeground;
  }
  /* Nastavitev lastnosti pri risanju crt: */
  XChangeGC(display,gc,linemask,&linegcv);
  linemask=0;
}
points[0].x=xcoord(x1);  points[0].y=ycoord(y1);
points[1].x=xcoord(x2);  points[1].y=ycoord(y2);
points[2].x=xcoord(x3);  points[2].y=ycoord(y3);
points[3].x=xcoord(x4);  points[3].y=ycoord(y4);
points[4].x=xcoord(x1);  points[4].y=ycoord(y1);
XDrawLines(display,window,gc,points,5,CoordModeOrigin);
}


void girectangle(float x1,float y1,float x2,float y2)
     /* Narise pravokotnik iz crt z nasprotileznima ogliscema (x1,y1) in
     (x2,y2). */
{
gifourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}


void gicircle(float x,float y,float r)
     /* Narise krog iz curvepoints crt s srediscem (x,y) in radijem r. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) curvepoints);
x1=x+r;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  giline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gicirclearc(float x,float y,float r,float fi1,float fi2)
     /* Narise krozni lok iz curvepoints crt s srediscem (x,y), radijem r ter
     z zacetnim kotom fi1 in s koncnim kotom fi2. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) curvepoints);
x1=x+r*cos(fi);
y1=y+r*sin(fi);
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  giline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void giellipse(float x,float y,float a,float b)
     /* Narise elipso iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) curvepoints);
x1=x+a;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  giline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void giellipsearc(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise elipsin lok iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri ter z zacetnim kotom fi1 in
     s koncnim kotom fi2. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) curvepoints);
x1=x+a*cos(fi);
y1=y+b*sin(fi);
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  giline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gifilltriangle(float x1,float y1,float x2,float y2,float x3,float y3)
     /* Narise pobarvan trikotnik z oglisci (x1,y1), (x2,y2) in (x3,y3). */
{
if (fillmask) /* Ce je treba nastaviti katero od nastavitev za polne like: */
{
  if (fillmask & GCForeground)
  {
    /* Ce se spremeni barva ospredja, je treba povedati, naj se pri naslednjem
    izrisu linij ali teksta le-ta ponovno nastavi: */
    linemask|=GCForeground;
    textmask|=GCForeground;
  }
  /* Nastavitev lastnosti pri risanju likov: */
  XChangeGC(display,gc,fillmask,&fillgcv);
  fillmask=0;
}
points[0].x=xcoord(x1);  points[0].y=ycoord(y1);
points[1].x=xcoord(x2);  points[1].y=ycoord(y2);
points[2].x=xcoord(x3);  points[2].y=ycoord(y3);
XFillPolygon(display,window,gc,points,3,Convex,CoordModeOrigin);
}


void gifillfourangle(float x1,float y1,float x2,float y2,float x3,float y3,
                   float x4,float y4)
     /* Narise pobarvan stirikotnik z oglisci (x1,y1), (x2,y2), (x3,y3) in
     (x4,y4). */
{
if (fillmask) /* Ce je treba nastaviti katero od nastavitev za polne like: */
{
  if (fillmask & GCForeground)
  {
    /* Ce se spremeni barva ospredja, je treba povedati, naj se pri naslednjem
    izrisu linij ali teksta le-ta ponovno nastavi: */
    linemask|=GCForeground;
    textmask|=GCForeground;
  }
  /* Nastavitev lastnosti pri risanju likov: */
  XChangeGC(display,gc,fillmask,&fillgcv);
  fillmask=0;
}
points[0].x=xcoord(x1);  points[0].y=ycoord(y1);
points[1].x=xcoord(x2);  points[1].y=ycoord(y2);
points[2].x=xcoord(x3);  points[2].y=ycoord(y3);
points[3].x=xcoord(x4);  points[3].y=ycoord(y4);
XFillPolygon(display,window,gc,points,4,Convex,CoordModeOrigin);
}

void gifillrectangle(float x1,float y1,float x2,float y2)
     /* Narise zapolnjen pravokotnik s protileznima ogliscema (x1,y1) in
     (x2,y2). */
{
gifillfourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}

void gipoint(float x,float y)
     /* Narise tocko s koordinatami (x,y). Za barvo se uporalbja barva za
     polnjenje likov. */
{
if (fillmask) /* Ce je treba nastaviti katero od nastavitev za polne like: */
{
  if (fillmask & GCForeground)
  {
    /* Ce se spremeni barva ospredja, je treba povedati, naj se pri naslednjem
    izrisu linij ali teksta le-ta ponovno nastavi: */
    linemask|=GCForeground;
    textmask|=GCForeground;
  }
  /* Nastavitev lastnosti pri risanju likov: */
  XChangeGC(display,gc,fillmask,&fillgcv);
  fillmask=0;
}
XDrawPoint(display,window,gc,xcoord(x),ycoord(y));
/*
gifillrectangle(x-pointsize,y-pointsize,x+pointsize,y+pointsize);
*/
}




void gifillcircle(float x,float y,float r)
     /* Narise zapolnjen krog s srediscem v (x,y) in polmerom r iz curvepoints
     zapolnjenih trikotnikov. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double)  curvepoints);
x1=x+r;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  gifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gifillcirclearc(float x,float y,float r,float fi1,float fi2)
     /* Narise zapolnjen krozni lok s srediscem (x,y), polmerom r ter zacetnim
     kotom fi1 in koncnim kotom fi2 zi curvepoints zapolnjenih trikotnikov. Koti
     so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) curvepoints);
x1=x+r*cos(fi);
y1=y+r*sin(fi);
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  gifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gifillellipse(float x,float y,float a,float b)
     /* Narise zapolnjeno elipso s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b iz curvepoints zapolnjenih trikornikov. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) curvepoints);
x1=x+a;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  gifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gifillellipsearc(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise zapolnjen elipsin lok s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b ter zacetnim kotom fi1 in koncnim fi2 iz curvepoints
     zapolnjenih trikornikov. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) curvepoints);
x1=x+a*cos(fi);
y1=y+b*sin(fi);
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  gifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}






static void boxunscalabletext(char *str,int xpos,int ypos)
{
int size,height,width;
float widthbyheight=0.7;
float linewidth,lred,lgreen,lblue,tred,tgreen,tblue;
int linetype;
/* Shranijo se prejsnje nastavitve za risanje crt: */
linewidth=gigetlinewidth();
linetype=gigetlinetype();
gigetlinecolor(&lred,&lgreen,&lblue);
/* Nastavijo se nastavitve za risanje crt pri okvirju: */
gisetlinewidth(1);
gisetlinetype(2);
/* Barva je taksn kot pri risanju teksta: */
gigettextcolor(&tred,&tgreen,&tblue);
gisetlinecolor(tred,tgreen,tblue);

if (linemask) /* Ce je treba nastaviti katero od nastavitev za risanje crt: */
{
  if (linemask & GCForeground)
  {
    /* Ce se spremeni barva ospredja, je treba povedati, naj se pri naslednjem
    izrisu teksta ali zapolnjenih likov le-ta ponovno nastavi: */
    fillmask|=GCForeground;
    textmask|=GCForeground;
  }
  /* Nastavitev lastnosti pri risanju crt: */
  XChangeGC(display,gc,linemask,&linegcv);
  linemask=0;
}

/* velikost fonta: */
size=textheight*iwindowheight;
/* Puscica za oznacevanje izhodiscne pozicije: */
XDrawLine(display,window,gc,xpos,ypos,xpos-10,ypos-5);
XDrawLine(display,window,gc,xpos,ypos,xpos-10,ypos+5);
height=size;
width=(int)(widthbyheight*(size*strlen(str)));
/* Poravnavanje: */
if (textxalignment!=-1)
{
  if (textxalignment==0)
    xpos-=width/2;
  else if (textxalignment==1)
    xpos-=width;
}
if (textyalignment!=-1)
{
  if (textyalignment==0)
    ypos+=height/2;
  else if (textyalignment==1)
    ypos+=height;
}
/* Okvircek za oznacevanje predvidene lege: */
XDrawRectangle(display,window,gc,xpos,ypos-size,width,size);
/* Nazaj se postavijo prejsnje nastavitve za risanje crt: */
gisetlinecolor(lred,lgreen,lblue);
gisetlinewidth(linewidth);
gisetlinetype(linetype);
}





static void gimarktextpos(char *str,float x,float y,char mark,char box)
    /* Oznaci pozicijo teksta, ki naj bi se izpisal s funkcijo gitext. str je
    niz, ki naj bi se izpisal, x in y pa sta koordinati, pri katerih naj bi
    se niz izpisal. Ce je mark razlicen od 0, se izrise puscica na poziciji
    (x1,y1), ce pa je box 1, se izrise okvir okrog mej, s katerimi naj bi bil
    tekst omejen.
    $A Igor apr97; */
{
float marklength=0.03;
float xratio=/* 1.9332 */ 1.5;
float yratio=1.514;
float x1,y1,x2,y2,height,dx,dy,xalign=0,yalign=0,red,green,blue;

if (mark || box)
{
  gisetlinewidth(1);
  gisetlinetype(2);
  gigettextcolor(&red,&green,&blue);
  gisetlinecolor(1-red,1-green,1-blue);
  if (mark)
  {
    x1=x-marklength;
    y1=y+0.3*marklength;
    x2=x1;
    y2=y-0.3*marklength;
    giline(x,y,x1,y1); 
    giline(x,y,x2,y2);
  }
  if (box)
  {  
    gisetlinecolor(red,green,blue);
    height=gigettextheight();
    xalign=gigettextxalignment();
    yalign=gigettextyalignment();
    /* Nastavitev poravnavanja teksta: */
    dy=height;    /* celotna visina teksta */
    dx=strlen(str)*height/xratio;    /* celotna sirina teksta */
    x1=x; y1=y;   /* (x,y) je spodnja leva tocka boksa. */
    /* poravnavanje v vodoravni smeri: */
    if (xalign==0)
      x1-=dx*0.5;
    else if (xalign==1)
      x1-=dx;
    if (yalign==0)
      y1-=dy*0.5;
    else if (yalign==1)
      y1-=dy;
    x2=x1+dx;
    y2=y1+dy;
    gifourangle(x1,y1,x2,y1,x2,y2,x1,y2);
  }
}
}





void gitext(char *str,float x,float y)
     /* Izpise niz str pri koordinatah (x,u). */
{
int xpos,ypos,width,height;

/* Pomoz. spremenljivka za kontrolo predvidene velikosti fonta:
int size;
size=textheight*iwindowheight;
*/
/* Nastavi se ustrezen font (spremenljivki fontid in fontstruct): */
setfont();
textgcv.font=fontid;
textmask|=GCFont;
if (textmask) /* Ce je treba nastaviti katero od nastavitev za tekste: */
{
  if (textmask & GCForeground)
  {
    /* Ce se spremeni barva ospredja, je treba povedati, naj se pri naslednjem
    izrisu linij ali likov le-ta ponovno nastavi: */
    linemask|=GCForeground;
    fillmask|=GCForeground;
  }
  /* Nastavitev lastnosti pri risanju teksta: */
  XChangeGC(display,gc,textmask,&textgcv);
  textmask=0;
}
xpos=xcoord(x);
ypos=ycoord(y);
if (nonscalablefont)
{
  /* Ce ima font, ki je nalozen, fiksno velikost, se izrise okvircek okoli
  priblizne lege napisa, kakrsna bi morala biti glede na zahtevano velikost
  in poravnavanje: */
  boxunscalabletext(str,xpos,ypos);
}
/* Puscica za oznacevanje izhodiscne pozicije:
XDrawLine(display,window,gc,xpos,ypos,xpos-20,ypos-10);
XDrawLine(display,window,gc,xpos,ypos,xpos-20,ypos+10);
*/
/* Poravnavanje: */
if (textxalignment!=-1)
{
  width=XTextWidth(fontstruct,str,strlen(str));
  if (textxalignment==0)
    xpos-=width/2;
  else if (textxalignment==1)
    xpos-=width;
}
if (textyalignment!=-1)
{
  height=fontstruct->max_bounds.ascent;
  if (textyalignment==0)
    ypos+=height/2;
  else if (textyalignment==1)
    ypos+=height;
}
/* Okvircek za oznacevanje predvidene lege:
width=XTextWidth(fontstruct,str,strlen(str));
height=fontstruct->max_bounds.ascent;
XDrawRectangle(display,window,gc,xpos,ypos-size,width,size);
*/
XDrawString(display,window,gc,xpos,ypos,str,strlen(str));
/* Oznacevanje teksta: */
/* gimarktextpos(str,x,y,1,1); */
}



void gidrawloop(void (*redraw)(void))
     /* Zanka okrog funkcije redraw, ki naj bi bila taksna funkcija, ki nekaj
     narise v aktivno okno. Funkcija na novo izrise aktivno okno vsakic, ko je
     potrebno zaradi odkrivanja okna ali cesa drugega. Ko kliknemo z misko v
     okno, se le-to zapre. */
{
int                 Done = False;   /* done getting X events? */
XEvent              Event;          /* what did user do? */
XSelectInput(display, window, ExposureMask | ButtonPressMask);
while (!Done)
{
  XNextEvent(display, &Event);
  switch (Event.type)
  {
    case Expose:
      while (XCheckTypedWindowEvent(display, window, Expose,&Event))
        ;
      redraw();
      break;
    case ButtonPress:
      Done = True;
      break;
  }
}
}



void gidrawactionloop(void (*redraw)(void),void (*b1)(void),void (*b2)(void),void (*b3)(void))
     /* Zanka okrog funkcije redraw, ki naj bi bila taksna funkcija, ki nekaj
     narise v aktivno okno. Funkcija na novo izrise aktivno okno vsakic, ko je
     potrebno zaradi odkrivanja okna ali cesa drugega. Ko kliknemo z misko v
     okno, se izvede funkcija b1(), ce smo kliknili s 1. gumbom, b2(), ce smo
     kliknili z 2. gumbom, in b3(), ce smo kliknili s 3. gumbom.
     Igor feb97; */
{
int                 Done = False;   /* done getting X events? */
XEvent              Event;          /* what did user do? */
XSelectInput(display, window, ExposureMask | ButtonPressMask);
while (!Done)
{
  XNextEvent(display, &Event);
  switch (Event.type)
  {
    case Expose:
      while (XCheckTypedWindowEvent(display, window, Expose,&Event))
        ;
      redraw();
      break;
    case ButtonPress:
      if (event.xbutton.button==Button1)
      {
        if (b1!=NULL)
          b1;
      }
      else if (event.xbutton.button==Button2)
      {
        if (b2!=NULL)
          b2();
      }
      else if (event.xbutton.button==Button3)
      {
        if (b3!=NULL)
          b3();
      }
      /* Done = True; */
      break;
  }
}
}




int gibuttonpressed(void)
    /* Vrne st. gumba miske, ki je bil pritisnjen v aktivnem oknu. Ce ni bil
    pritisnjen noben gumb, vrne 0. Funkcija caka, dokler ni dejansko pritisnjen
    kak gumb ali se aktivno okno izpostavi. */
{
XEvent event;
XSelectInput(display,window, ExposureMask | ButtonPressMask | PointerMotionMask);
XNextEvent(display,&event);
if (event.type==ButtonPress)
{
  if (event.xbutton.button==Button1)
    return 1;
  else if (event.xbutton.button==Button2)
    return 2;
  else if (event.xbutton.button==Button3)
    return 3;
  else
    return 0;
} else if (event.type==Expose)
  return 0;
else return -1;
}

