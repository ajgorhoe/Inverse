/* MANIPULACIJA Z UPORABNISKO DEFINIRANIMI SPREMENLJIVKAMI */





#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>

#include <mtypes.h>
#include <st.h>
#include <strop.h>
#include <varop.h>



main()
{
varholder v=NULL,v1=NULL,v2=NULL;
int i,*ip,tab[5];
stack st;


st=newstack(10);
ip=malloc(sizeof(*ip));
*ip=2;
pushstack(st,ip);
ip=malloc(sizeof(*ip));
*ip=3;
pushstack(st,ip);
ip=malloc(sizeof(*ip));
*ip=4;
pushstack(st,ip);
ip=malloc(sizeof(*ip));
*ip=2;
pushstack(st,ip);
printvarholder(v);
printf("\n\n");
v=newvarholderst(st);
v->name=stringcopy("sprem_1");
printvarholder(v);

dispwholevar(&v);

}




