/* OPERACIJE NA NIZIH */


#include <sysint.h>
#include <t_sysint.h>

#include <t_strop.h>



#ifdef IGTEST
 #include "../ct/c_strop.c"
#endif








































