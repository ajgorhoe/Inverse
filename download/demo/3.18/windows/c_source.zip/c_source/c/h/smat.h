




            /*******************************************/
            /*                                         */
            /*   OPERACIJE NAD RAZPRSENIMI MATRIKAMI   */
            /*                                         */
            /*******************************************/



smat getsmat(int d1,int d2,int ex,int r);
    /* Kreira in vrne razprseno matriko z dimenzijama d1 in d2, pri cemer
    alocira r mest in postavi na ex polje ex. Dimanziji morata biti vecji od
    0. Alocira se vedno vsaj d1 toliko mest.
    $A Igor okt00; */

smat getsmatindtab(int d1,int d2,int ex,indtab it,int firstgap,int plusgap);
    /* Alocira razprseno matriko, za katero it vsebuje stevilo elementov
    za vsako vrstico, firstgap doloca velikost praznine za 1. vrstico, plusgap
    pa prirastek praznine za vsako naslednjo vrstico (oboje je lahko 0). Tudi
    za zadnjo vrstico se pusti praznina, ce je firstgap ali plusgap vecji od 0.
    $A Igor okt00; */

void dispsmat(smat *am);
    /* Zbrise razprseno matriko *am in jo postavi na NULL.
    $A Igor okt00; */

void printsmatline(smat m);
    /* Izpise razprseno matriko m. Nenicelne elemente vrstice zapise v eni
    vrstici.
    $A Igor okt00; */

void printsmat(smat m);
    /* Izpise razprseno matriko m. Nenicelne elemente izpise vsakega v svoji
    vrstici.
    $A Igor okt00; */

void printsmatfull(smat mat);
    /* Izpise razprseno matriko m, kot da bi bila polna matrika, le da pri
    niclah, za katere tudi ni alociran prostor, izpise se crtico.
    $A Igor okt00; */

smat copymatrixtosmat(matrix m1,smat *m2);
    /* Polno matriko m1 skopira v razprseno matriko in jo vrne. Ce je m2
    razlicen od NULL, se m1 skopira v *m2 in se vrne *m2. Ce je treba razprdeno
    matriko alocirati na novo, se alocira natancno toliko prostora, da se lahko
    vanjo spravi vse elemente.
    $A Igor okt00; */








