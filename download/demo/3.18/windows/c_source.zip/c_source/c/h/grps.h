

          /*************************************************/
          /*   OSNOVNE FUNKCIJE ZA RISANJE V FORMATU PS   */
          /*************************************************/




void pssetshortoperators(void);
    /* V uporabo postavi kratka imena operatorjev: nastavi ustrezne nize, ki
    predstavljajo operatorje v formatu PostScript in postavi shortoperators
    na 1. */

void pssetlongoperators(void);
    /* V uporabo postavi dolga imena operatorjev: nastavi ustrezne nize, ki
    predstavljajo operatorje v formatu PostScript in postavi shortoperators
    na 0. */

static void psinstallfont(int num,char *name);
    /* Doda novo ime fonta, ki se uporablja pri risanju v formatu Postscript.
    num je zaporedna stevilka, pod katero se instalira font, name pa ime fonta.
    Ime fonta se nalozi na sklad psfontnames, ki se uporablja pri prireditvi
    imena fonta zaporedni stevilki pri zapisu v formatu PostScript. Zaporedne
    stevilke za fonte uporabljajo graficni objekti. */

void pssetscaling(char scaling);
    /* Doloci skaliranje koordinat pri zapisu graficnih objektov v formatu DXF.
    ce je scaling==0, postane funkcija pswindowcoord() za skaliranje koordinat
    kar funkcija psnaturalwindowxoord(), ki ohranja naravne koordinate objektov,
    drugace pa to postane funkcija psgpwindowxoord(), ki skalira koordinati x
    in y tako, kot se to naredi pri risanju na zaslon, koordinato z pa poskusa
    skalirati na podoben nacin. */

void psdrawprimitive(FILE *fp,goprimitive gp);
     /* Izrise graficni primitiv gp. */

void psdrawstack(FILE *fp,stack st);
     /* Izrise sklad st, na katerega so nalozeni graficni primitivi, v datoteko
     fp v formatu PostScript. */

void psfiledrawstack(char *name,stack st);
     /* Izrise sklad st, na katerega so nalozeni graficni primitivi, v datoteko
     z imenom name. Ce datoteka ze obstaja, se prepise. */

