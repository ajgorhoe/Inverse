
/* Ensure at most one inclusion: */
#ifndef INCLUDED_approx
#define INCLUDED_approx

                 /***********************/
                 /*                     */
                 /*    APPROXIMATION    */
                 /*                     */
                 /***********************/

#ifndef INCLUDED_vec
 #include <vec.h>
#endif

#ifndef INCLUDED_mat
 #include <mat.h>
#endif


  /* GENERAL REMARKS: 
  Functions for calculating approximatinos with linear and quadratic
  polynomials are optimized for calculating approximation in many point, i.e.
with possibly different data sets of the same dimensions. Therefore, auxiliary
matrices are static variables and it is possible not to deallocate them
between successive computations, which saves the computational time. */


         /****************************************/
         /*                                      */
         /*  LINEAR LEAST SQUARES APPROXIMATION  */
         /*                                      */
         /****************************************/


int approx_forceclean(int doclean);
    /* Sets the parameter that determines whether the auxiliary storage used by
    approximation routines is released each time after use. If doclean is
    non-zero then the storage is released, otherwise (if doclean is 0) some
    auxiliary variables are not deallocated after use, so that the next
    computation can use utilize the same storage and it need not to allocate
    the space again. This can speed up computation especially when a lot of
    approximations of small dimensions are calculated successively. By default
    cleaning is not enforced. If the necessary storage is large then the
    auxiliary storage is deallocated after use in any case (since repeated
    allocation is inexpensive with respect to computation).
      The current value of the parameter before the call is returned.
    $A Igor nov03; */

void approx_cleanauxdata(void);
   /* Releases the space that is eventually occupied by auxiliary variables
   used by the functions of the approximation module.
   $A Igor nov03; */


    /* GENERAL LIN. APPROXIMATION (any type of basis functions): */

int coeflincombapprox(matrix basval,vector val,vector w,vector *coefaddr);
    /* Calculates coefficients of a linear combination of a set of basis
    functions that approximates the best the given data, and stores them
    to *coefaddr. basval must contain values of the basis functions in the
    sampling points (each line corresponds to one sampling point and each
    element of this line corresponds to a value of the corresponding basis
    function in that point). Val must contain values of the approximated
    function in the sampling points and w their QUADRATIC weights. basval,
    val and w must be of consistent dimensions because this is not checked
    by the function. *coefaddr can be NULL or of inconsistend dimensions
    since it is allocated or reallocated if necessary.
    $A Igor nov03; */

int coeflincombapproxgrad(matrix basval,matrix val,matrix w,vector *coefaddr);
    /* Calculates coefficients of a linear combination of a set of basis
    functions that approximates the best the given data, and stores them
    to *coefaddr. basval must contain values and gradients of the basis
    functions in the sampling points where function values and gradients
    were captured (each line must corresponds to one sampling point and 
    must contain by turns the value and the derivatives for each basis
    bunction in that point). Val must contain values and gradients of the
    approximated function in the sampling points and w their QUADRATIC weights
    (one line per a sampling point).
      basval, val and w must be of consistent dimensions because this is not
    checked by the function. Values in each line of basval must be listed by
    basis functions, for each function the value in the corresponding sampling
    points must be stated first followed by the derivatives. 
      *coefaddr can be NULL or of inconsistend dimensions because it is
    allocated or reallocated if necessary.
    $A Igor nov03; */


         /*************************************************/
         /*                                               */
         /*     APPROXIMATION WITH LINEAR POLYNOMIALS     */
         /*                                               */
         /*************************************************/


  /* CONVERSION BETWEEN RAW AND NORMAL FORM OF COEFFICIENTS: */

void coeflinpolraw(vector b,double c,vector *addrraw);
    /* Conversion from regular form of coefficients of a linear polynomial to
    raw form. The lin. pol. is b_T x + c. In raw form, coefficients are
    arranged in a single vector and sorted in the following order: c, b[1],
    b[2], ..., b[dim] where dim is the number of independent variables
    (dimension of the space).
      b must be allocated and of correct dimension since this is not checked. 
      addrraw may not be NULL, but it can point to a NULL vector. The function
    allocates or reallocates the space for *addrraw if necessary.
    $A Igor nov03; */

void coeflinpolreg(vector raw,vector *addrb,double *addrc);
    /* Rearrangement of raw coefficients of a linear polynomial to a regular
    form. Coefficient are arranged in vector *addrb and scalar *addrc. If
    necessary, the vector is allocated or re-allocated.
    See also coeflinpolraw()!
      If necessary, vector *addrb is reallocated or allocated anew.
    $A Igror nov03; */


  /* CALCULATION OF LINEAR POLYNOMIAL AND ITS GRADIENT: */

double linpol(vector x,vector b,double c);
    /* Returns the value of a linear polynomial with coefficients b and
    c at x.
    $A Igor nov03; */

vector gradlinpol(vector x,vector b,vector *addrgrad);
    /* Calculates gradient of a linear polynomial with linear coefficients b,
    and stores it to *addrgrad. x, and b must be allocated and of consistent
    dimensions since this is not checked by the function. If necessary the
    function allocates or reallocates the storage for the gradient.
    $A Igor nov03; */

double derlinpol(vector x,int which,vector b);
    /* Returns the derivative of a linear polynomial whose  linear coefficients
    are in b, with respect to the variable which at the point x.
    $A igor nov03; */

double linpolraw(vector x,vector raw);
    /* Calculates a linear polynomial in x whose raw coefficients are in
    raw. x and raw must be allocated and of consistent dimensions since this
    is not checked by the function.
    $A Igor nov03; */

vector gradlinpolraw(vector x,vector raw,vector *addrgrad);
    /* Calculates gradient of a linear polynomial with coefficients raw
    arranged in raw form, and stores it to *addrgrad. x and raw must be
    allocated and of consistent dimensions since this is not checked in the
    function. If necessary the function allocates or reallocates the storage
    for the gradient.
    $A Igor nov03; */

double derlinpolraw(vector x,int which,vector raw);
    /* Returns the derivative of the linear polynomial with raw coefficients
    in raw at x with respect to the variable which. x and raw must be allocated
    with consistent dimensions and it must be 0<which<=which->d, since this is
    not checked.
      If which==0 then the value of the linear polynomiel is returned.
    $A Igor nov03; */


  /* CALCULATING THE APPROXIMATION: */


int coeflinpolapproxraw_old(matrix points,vector val,vector w,vector *rawaddr);
    /* Calculates coefficients of a linear pol. approximation and stores them
    to *rawaddr. points must be a matrix whose LINES contain co-ordinates
    of sampling points, val must contain values of the sampled function in
    these points, and w must contain the corresponding SQUARE weigth that weigh
    the importance of individual points. points, val and w must be allocated
    and of consistent dimensions since this is not checked by the function.
    If necessary, space for coefficients is allocated anew or re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) with values close to the value
    in the most important point (or just one of them if they are equally
    weighted). The returned value is then a counter of how many times the
    system algorithm has been applied in order to obtain a solution. If all
    attempts to get a solution fail then a negative value is returned (equal
    to minus the number of attempts). In each attempt dim points are added
    where dim is dimension of the space.
      WARNINING:
      w must contain the SQUARED weights!
      REMARK:
      This is an old version of a function. It is a bit quicker than the
    newer one, but uses additional auxiliary storage for values of basic
    functions in all points (which can be considerable for large number of
    dimensions).
    $A Igor nov03; */

int coeflinpolapproxraw1(matrix points,vector val,vector w,vector *rawaddr);
    /* Does the same as coeflinpolapproxraw(), except that it first creates a
    matrix of values of basis functions in sampling points and then calculates
    the approximation by coeflincombapprox(). On contrary, coeflinpolapproxraw()
    assembles the system of equations without this intermediate storage.
      This function is slower than coeflinpolapproxraw() and was primarily
    created  for testing coeflincombapprox().
    $A, Igor nov03; */

int coeflinpolapproxraw(matrix points,vector val,vector w,vector *rawaddr);
    /* Calculates coefficients of a linear pol. approximation and stores them
    to *rawaddr. points must be a matrix whose LINES contain co-ordinates
    of sampling points, val must contain values of the sampled function in
    these points, and w must contain the corresponding SQUARE weigth that
    weigh the importance of individual points. points, val and w must be
    allocated and of consistent dimensions since this is not checked by the
    function. If necessary, space for coefficients is allocated anew or
    re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) by values close to the value
    in the most important point (or just one of them if they are equally
    weighted). The returned value is then a counter of how many times the
    system algorithm has been applied in order to obtain a solution. If all
    attempts to get a solution fail then a negative value is returned (equal
    to minus the number of attempts). In each attempt dim points are added
    where dim is dimension of the space.
      WARNINING:
      w must contain the SQUARED weights!
    $A Igor nov03; */

double linpolapprox(vector x,matrix points,vector val,vector w);
    /* Calculates the value of a linear pol. approximation of data in point x.
    points must contain co-ordinates of data points, val must contain values
    in these points to be fitted, and w must contain the corresponding SQUARED
    weights. A warning is launched if the initial problem is not well posed so
    that it had to be conditioned by adding imaginary points, and an error is
    launched if the repair failed to produce results.
      Remark:
      For many applications it is better to separately perform calculation of
    approximation coefficients by coeflinpolapproxraw() and then call
    linpolraw() to evaluate the approximation, since in this way it can be
    controlled if the approximation problem is well defined and separate
    actions can be performed if it is not.
    $A Igor nov03; */

static int coeflinpolapproxgradraw1(matrix points,matrix val,matrix w,
                                    vector *rawaddr);
    /* Does the same as coeflinpolapproxgradraw(), except that it first
    creates a matrix of values of basis functions in sampling points and then
    calculates the approximation by coeflincombapproxgrad(). On contrary,
    coeflinpolapproxgradraw() assembles the system of equations without this
    intermediate storage.
      This function is much slower than coeflinpolapproxraw() and was primarily
    created  for testing coeflincombapproxgrad().
    $A, Igor nov03; */

int coeflinpolapproxgradraw(matrix points,matrix val,matrix w,vector *rawaddr);
    /* Calculates coefficients of a linear pol. approximation on the basis of
    function values and gradients and stores them to *rawaddr. points must be
    a matrix whose LINES contain co-ordinates of sampling points, val must
    contain values and derivatives with respect to all independent variables
    (co-ordinates) of the sampled function in these points (each row contains
    the value and all derivatives in turns for one point), and w must contain
    the corresponding SQUARE weigth that weigh the importance of values and
    derivatives with respect to each variable (the dimension must therefore be
    the same as that of val). points, val and w must be allocated and of
    consistent dimensions since this is not checked by the function. If
    necessary, space for coefficients is allocated anew or re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) by values close to the value
    in the most important point (i.e. that with the highest weight for the
    value, or just one of them if they are equally weighted). The returned
    value is then a counter of how many times the repair algorithm has been
    applied in order to obtain a solution. If all attempts to get a solution
    fail, then a negative value is returned (equal to minus the number of
    attempts). In each attempt dim points are added where dim is dimension of
    the space.
      WARNINING:
      w must contain the SQUARED weights!
    $A Igor nov03; */

double linpolapproxgrad(vector x,matrix points,matrix val,matrix w);
    /* Calculates the value of a linear pol. approximation of data in point x.
    points must contain co-ordinates of data points, val must contain values
    and gradients in these points to be fitted (each line corresponds to one
    point and contains the value followed by all derivatives), and w must
    contain the corresponding SQUARED weights. A warning is launched if the
    initial problem is not well posed so that it had to be conditioned by
    adding imaginary points, and an error report is launched if the repair
    failed to produce results.
      Remark:
      For many applications it is better to separately perform calculation of
    approximation coefficients by coeflinpolapproxgradraw() and then call
    linpolraw() to evaluate the approximation, since in this way it can be
    controlled if the approximation problem is well defined and separate
    actions can be performed if it is not.
    $A Igor nov03; */


         /*****************************************************/
         /*                                                   */
         /*      APPROXIMATION WITH QUADRATIC POLYNOMIALS     */
         /*                                                   */
         /*****************************************************/


  /* CONVERSION BETWEEN RAW AND NORMAL FORM OF COEFFICIENTS: */

void coefquadpolraw(matrix G,vector b,double c,vector *addrraw);
    /* Conversion from regular form of coefficients of a quadratic function to
    raw form. The quatratic function is 1/2 x_T G x + b_T x + c. In the raw
    form, coefficients are arranged in a single vector and sorted in the
    following order: c, b[1], b[2], ..., b[dim], G[1,1], G[1,2], ..., G[1,dim],
    G[2,2], ..., G[2,dim], G[3,3], ..., G[3,dim] where dim is the number of
    the variables (dimension of the space).
      G, b and c must be allocated and of correct dimensions since this is not
    checked. G must be a symmetric matrix. Only upper triangle is taken into
    account at conversion.
      addrraw may not be NULL, but it can point to a NULL vector. The function
    allocates or reallocates the space for *addrraw if necessary.
    $A Igor nov03; */

void coefquadpolreg(vector raw,matrix *addrG,vector *addrb,double *addrc);
    /* Rearrangement of raw coefficients of a quadratic function to a regular
    form. Coefficient are arranged in matrix *addrG, vector *addrb and scalar
    *addrc. If necessary, the matrix and the vector are allocated or
    re-allocated. Although the matrix is symmetric, all elements are filled.
    See also coefquadpolraw()!
      addrG, addrb and addrc may not be NULL. Wector raw must be allocated and
    of correct dimension (at least 3).
    $A Igror nov03; */

  /* CALCULATION OF QUADRATIC POLYNOMIAL AND ITS GRADIENT: */

double quadpol(vector x,matrix G,vector b,double c);
    /* Returns the value of the quadratic function with coefficients G, b and
    c at x. Only upper triangle of G is used in calculation.
    $A Igor nov03; */

vector gradquadpol(vector x,matrix G,vector b,vector *addrgrad);
    /* Calculates gradient of a quadratic function with quadratic and linear
    coefficients G and b, and stores it to *addrgrad. x, G and b must be
    allocated and of consistent dimensions since this is not checked in the
    function. If necessary the function allocates or reallocates the storage
    for gradient.
      Only the upper triangle of G (which is symmetric) is used in calculation.
    $A Igor nov03; */

double derquadpol(vector x,int which,matrix G,vector b);
    /* Returns the derivative of a quadratic function whose quadratic and
    linear coefficients are G and b, with respect to the variable which at
    the point x.
    $A igor nov03; */

double quadpolraw(vector x,vector raw);
    /* Calculates a quadratic function in x whose raw coefficients are in
    raw. x and raw must be allocated and of consistent dimensions since this
    is not checked in the function.
    $A Igor nov03; */

vector gradquadpolraw(vector x,vector raw,vector *addrgrad);
    /* Calculates gradient of a quadratic function with coefficients raw
    arranged in raw form, and stores it to *addrgrad. x and raw must be
    allocated and of consistent dimensions since this is not checked in the
    function. If necessary the function allocates or reallocates the storage
    for gradient.
    $A Igor nov03; */

double derquadpolraw(vector x,int which,vector raw);
    /* Returns the derivative of the quadratic function with raw coefficients
    in raw at x with respect to the variable which. x and raw must be allocated
    with consistent dimensions and it must be 0<=which<=which->d, since this is
    not checked.
      If which==0 then the value of the quadratic function is returned.
    $A Igor nov03; */


  /* CALCULATING THE APPROXIMATION: */

  /* Remark: Functions for calculating quadratic approximatinos are optimized
for calculating approximation in many point, i.e. with possibly different
data sets of the same dimensions. Therefore, auxiliary matrices are static
variables and it is possible not to deallocate them between successive
computations, which saves the computational time. */


int coefquadpolapproxraw_old(matrix points,vector val,vector w,vector *rawaddr);
    /* Calculates coefficients of a quadratic approximation and stores them
    to *rawaddr. points must be a matrix whose LINES contain co-ordinates
    of sampling points, val must contain values of the sampled function in
    these points, and w must contain the corresponding SQUARE weigth that weigh
    the importance of individual points. points, val and w must be allocated
    and of consistent dimensions since this is not checked by the function.
    If necessary, space for coefficients is allocated anew or re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) by values close to the value
    in the most important point (or just one of them if they are equally
    weighted). The returned value is then a counter of how many times the
    system algorithm has been applied in order to obtain a solution. If all
    attempts to get a solution fail then a negative value is returned (equal
    to minus the number of attempts). In each attempt dim points are added
    where dim is dimension of the space.
      WARNINING:
      w must contain the SQUARED weights!
      REMARK:
      This is an old version of a function. It is approx. 1/3 quicker than the
    newer one, but uses additional auxiliary storage for values of basic
    functions in all points (which can be considerable for large number of
    dimensions since the dimension grows
    $A Igor nov03; */

int coefquadpolapproxraw1(matrix points,vector val,vector w,vector *rawaddr);
    /* Does the same as coefquadpolapproxraw(), except that it first creates a
    matrix of values of basis functions in sampling points and then calculates
    the approximation by coeflincombapprox(). On contrary, coefquadpolapproxraw()
    assembles the system of equations without this intermediate storage.
      This function is slower than coefquadpolapproxraw() and was primarily created 
    for testing coeflincombapprox().
    $A, Igor nov03; */

int coefquadpolapproxraw(matrix points,vector val,vector w,vector *rawaddr);
    /* Calculates coefficients of a quadratic approximation and stores them
    to *rawaddr. points must be a matrix whose LINES contain co-ordinates
    of sampling points, val must contain values of the sampled function in
    these points, and w must contain the corresponding SQUARE weigth that weigh
    the importance of individual points. points, val and w must be allocated
    and of consistent dimensions since this is not checked by the function.
    If necessary, space for coefficients is allocated anew or re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) by values close to the value
    in the most important point (or just one of them if they are equally
    weighted). The returned value is then a counter of how many times the
    system algorithm has been applied in order to obtain a solution. If all
    attempts to get a solution fail then a negative value is returned (equal
    to minus the number of attempts). In each attempt dim points are added
    where dim is dimension of the space.
      WARNINING:
      w must contain the SQUARED weights!
    $A Igor nov03; */

double quadpolapprox(vector x,matrix points,vector val,vector w);
    /* Calculates the value of a quadratic approximation of data in point x.
    points must contain co-ordinates of data points, val must contain values
    in these points to be fitted, and w must contain the corresponding SQUARED
    weights. A warning is launched if the initial problem is not well posed so
    that it had to be conditioned by adding imaginary points, and an error is
    launched if the repair failed to produce results.
      Remark:
      For many applications it is better to separately perform calculation of
    approximation coefficients by coefquadpolapproxraw() and then call
    quadpolraw() to evaluate the approximation, since in this way it can be
    controlled if the approximation problem is well defined and separate
    actions can be performed if it is not.
    $A Igor nov03; */

static int coefquadpolapproxgradraw1(matrix points,matrix val,matrix w,
                                     vector *rawaddr);
    /* Does the same as coefquadpolapproxgradraw(), except that it first creates
    a matrix of values of basis functions in sampling points and then
    calculates the approximation by coeflincombapproxgrad(). On contrary,
    coefquadpolapproxgradraw() assembles the system of equations without this
    intermediate storage.
      This function is much slower than coefquadpolapproxraw() and was primarily
    created  for testing coeflincombapproxgrad().
    $A, Igor nov03; */

int coefquadpolapproxgradraw(matrix points,matrix val,matrix w,vector *rawaddr);
    /* Calculates coefficients of a quadratic approximation on the basis of
    function values and gradients and stores them to *rawaddr. points must be
    a matrix whose LINES contain co-ordinates of sampling points, val must
    contain values and derivatives with respect to all independent variables
    (co-ordinates) of the sampled function in these points (each row contains
    the value and all derivatives in turns for one point), and w must contain
    the corresponding SQUARE weigth that weigh the importance of values and
    each derivative of different (the dimension must therefore be the same
    as that of val). points, val and w must be allocated and of consistent
    dimensions since this is not checked by the function. If necessary, space
    for coefficients is allocated anew or re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) by values close to the value
    in the most important point (i.e. that with the highest weight for the
    value, or just one of them if they are equally weighted). The returned
    value is then a counter of how many times the system algorithm has been
    applied in order to obtain a solution. If all attempts to get a solution
    fail, then a negative value is returned (equal to minus the number of
    attempts). In each attempt dim points are added where dim is dimension of
    the space.
      WARNINING:
      w must contain the SQUARED weights!
    $A Igor nov03; */

double quadpolapproxgrad(vector x,matrix points,matrix val,matrix w);
    /* Calculates the value of a quadratic approximation of data in point x.
    points must contain co-ordinates of data points, val must contain values
    and gradients in these points to be fitted (each line corresponds to one
    point and contains the value followed by all derivatives), and w must
    contain the corresponding SQUARED weights. A warning is launched if the
    initial problem is not well posed so that it had to be conditioned by
    adding imaginary points, and an error report is launched if the repair
    failed to produce results.
      Remark:
      For many applications it is better to separately perform calculation of
    approximation coefficients by coefquadpolapproxgradraw() and then call
    quadpolraw() to evaluate the approximation, since in this way it can be
    controlled if the approximation problem is well defined and separate
    actions can be performed if it is not.
    $A Igor nov03; */




    /* SMOOTHING APPROXIMATIONS: */


int smoothapproxsimp(matrix samp,vector rw,vector x,int whichval,
                      double *valaddr,vector *gradaddr,int dispauxvar);
  /* Calculates the value and gradient of a smooth approximation of function
    whose samples are specified in samp. The approximation is quadratic moving
    least squares approximatio where all the points are taken into account,
    and the dependency of weights on the difference r between pooint of
    evaluation and the sample is exp(-sqrt(r1^2/rw1^2+r2^2/rw2^2+...).
      Lines of samp represent samples, the first rw->dim columns being
    parameter values and the next being values.
      rw is a vector whose dimension equals the number of independent
    variables, and its components rw1, re2, etc. represent the length in each
    co-ordinate direction on which the value of weighting function falls to
    1/exp(1) ~ 0.37 (the value is 1 in the sampling point).
      x is the point in which approximation is evaluated.
      whichval determines which value is approximated (starts with 1).
    valaddr is the address where the value of the approximation calculated in
    x is stored. It must not be NULL.
      gradaddr is address of the vector where gradient of the approximation is
    stored. It can be NULL, in this case gradient is not calculated.
      If dispauxvar is nonzero then auxiliay variables are deleted at the end
    of the function, otherwise they are left allocated so that successive calls
    are quicker.
      Return value:
      The function returns the value returned from coefquadpolapproxraw(), i.e.
    0 if everything is OK.
      Remarks:
      The approximation is a quadratic function whose coefficients vary in the
    space of parameters, however this is not taken into account in calculation 
    of the gradient, which is calculated just by deriving a quadratic function
    with constant coefficients.
    $A Igor aug04; */





    /* TEST FUNCTION OF THIS MODULE: */

void testapprox(void);
    /* A test function for the linear approximation module. Several types of
    functionality are tested, some of which are included in "if (0)" - change
    0 to 1 if you want to run tests for this functionality.
    $A Igor nov03; */









#endif    /* (not defined) INCLUDED_approx */
