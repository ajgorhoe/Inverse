

             /*************************************************/
             /*                                               */
             /*    VISUALIZATION TOOLS FOR FINITE ELEMENTS    */
             /*                                               */
             /*************************************************/


/* ensure only one inclusion: */
#ifndef INCLUDED_fem
#define INCLUDED_fem


#ifndef INCLUDED_vec
 #include <vec.h>
#endif

#ifndef INCLUDED_mat
 #include <mat.h>
#endif

#ifndef INCLUDED_sg_obj
 #include <sg_obj.h>
#endif

#ifndef INCLUDED_geom
 #include <geom.h>
#endif


         /***********************************/
         /*                                 */
         /*      FINITE ELEMENT MESHES      */
         /*                                 */
         /***********************************/


/*  DATA TYPES FOR REPRESENTING THE FINITE ELEMENT MESH (short exp.: fem.c)
  
  Two structures are defined, their pointer being of the type femesh and
elgrp. femesh contains all the mesh data while elgrp wears element data for
a given group of elements (i.e. mesh connectivity and the derived data).
  
    When the finite element mesh is read, the MESH DATA STRUCTURE (pointed to by
the type femesh) MUST CONTAIN at least the following data:
  - (...)->grp contains data about element groups
  - (...)->nodcoord contains node co-ordinates of the mesh; Each line of this
matrix contains co-ordinates of one node.
  - (...)->nodnum contains numbers of nodes whose co-ordinates are contained in
the appropriate lines of (...)->nodcoord, i.e. the element i of this table
is the number of node whose co-ordinates are contained in the line i of
(...)->nodcoord. It CAN BE NULL, in this case numbers of nodes follow
successively without holes and each line of (...)->nodcoord correspond to the
node whose number is the same as the line number.
  - (...)->nodnuminv contains for each node the number of the corresponding
line in (...)->nodcoord. WARNING: if (...)->nodnum is different than NULL then
(...)->nodnuminv must be different than NULL, too! Such arrangement is
necessary because the node co-ordinates are accessed through node numbers
rather than by lines in the (...)->coord.

  The ELEMENT GROUP STRUCTURES whose pointers are loaded on the (...)->elgrp
of the mesh data structure MUST CONTAIN the following data:
  - (...)->elspec - element ID (its string specification) that is used for
finding the element definition.
  - (...)->numelnod is the number of nodes in elements of the group.
  - (...)->surftop contains the surface topology of the element. For each
surface there is an index table on this stack that contains the local (i.e.
element-relative) numbers of element nodes that lie on that surface. These
numbers correspond to the entries of indec tables that are elements of 
(...)->eltop. Nodes that are positioned in the apices of the surface must
be listed first.
  - (...)->surfedg contains the number of edges for each surface on
(...)->surftop.
  - (...)->elnum contains element numbers for entries on (...)->eltop. This
is used e.g. for plotting where element numbers are plotted on the mesh.
  - (...)->eltop contains for each element of the group an index table in
which numbers of nodes that constitute the element are listed. The order of
listing is specified by the element definition, i.e. nodes are listed by their
local (element-relative) numbers, which are also used in (...)->surftop. The
element number corresponding to entry i on this stack is (...)->elnum->t[i].

DERIVED (auxiliary) DATA ON THE MESH STRUCTURE (femesh):
  - (...)->elgrpinv contains for each element (element number corresponds to
the entry in this table) the number of group in which it is contained (this
corresponds to the number of the element of (...)->elgrp).
  - (...)->elnuminv contains for each element the number of the entry for its
data in the fields of the element group structure (such as eltop or outsurf)
of the group in which the element is contained (the number of this group is
obtained from (...)->elgrpinv).
  - (...)->eltipinv contains for each node a list of elements (identified by
element global numbers) that contain this node. The list is an index table
(type indtab) and indices of entries correspond to those of (...)->nodcoord. 

DERIVED (auxiliary) DATA ON THE EL. GROUP STRUCTURE (elgrp):
  - (...)->outsurf contains for each element an index table t which contains
the local (element-relative) indices of all element surfaces that are outer
surfaces of the given element group. If no surfaces of a particular element
are outer surfaces of the group, then the corresponding index table can be
NULL (it is also perimitted that it is allocated but contains 0 elements).
*/



typedef struct {
    stack elgrp;       /* stack of element groups */
    indtab nodnum,     /* node numbers corresponding to lines of nodcoord */
           nodnuminv,  /* inverse of the previous table, i.e. entry numbers of
                       nodes in nodcoord */
           elgrpinv,   /* group numbers for each element */
           elnuminv;   /* serial numbers on the appropriate group structure on
                       elgrp for each element */
           /* vsebujeta skupino in vrstno stevilko vsakega elementa
                          z doloceno stevilko na skladu elgrp */
    matrix nodcoord,   /* node co-ords., each node has one row of coord. */
           origcoord;  /* Original mesh co-ordinates - if exists then nodcoord
                       represent the current (=transformed) co-ordinates. */
    stack eltopinv;    /* entries are lists of elements that contain a given
          node; entry indices for nodes correspond to those in nodcoord */
}  _femesh;

typedef _femesh *femesh;

typedef struct {
  char *name;      /* name of the group */
  char *elspec;    /* name (type) of the group's constituent finite element */
  indtab elnum;    /* numbers of elements that are represented on eltop */
  stack eltop;     /* element topology; elements are index tables (type indtab)
                   that contain lists of nodes for each element */
  int numelnod;    /* number of nodes per element */
  stack surftop;   /* surface topology of the element; for each surface there
      is an index table containing local (element-relative) numbers of nodes
      that constitute the surface. Nodes positioned in the element apices must
      be stated first by the rule! */
  indtab surfedg; /* number of edges for each surface from surftop */
  stack outsurf;   /* for each element on eltop there is an index table that
        contains the list of element's outer surfaces, if thre are any. */
} _elgrp;

typedef _elgrp *elgrp;



    /* ALLOCATION AND DEALLOCATION */


elgrp newelgrp(void);
    /* Makes a new object of type elgrp and returns its pointer. All fields
    of the created objece are initialized to 0.
    $A Igor jul01; */

void dispelgrp(elgrp *e);
    /* Releases the complete object *e of the type elgrp and sets *e to NULL.
    $A Igor jul01; */

elgrp copyelgrp(elgrp gr1,elgrp * gr2);
    /* Returns a copy of element group gr1. If gr2 is different than NULL
    then gr1 is coppied to *gr2 and *gr2 returned.
    Stack of outer surfaces is also copied, but sometimes these should actually
    be re-calculated. In such a case care fo this must be taken separately.
    $A Igor feb04; */

femesh newfemesh(void);
    /* Creates a new object of type femesh and returns its pointer. All its 
    fields are initialized to 0 except the stack (...)->elgrp, which is
    allocated but empty (field ex seto to 1).
    $A Igor jul01; */

void dispfemesh(femesh *m);
    /* Releases the complete object *m and sets *m to NULL.
    $A Igor jul01; */

femesh copyfemesh(femesh m1,femesh * m2);
    /* Returns a copy of finite element mesh m1. If m2 is different than NULL
    then m1 is coppied to *m2 and *m2 returned.
    $A Igor feb04; */




/* COMFORTABLE FUNCTIONS FOR OBTAINING MESH INFORMATION: */


int femnodeind(femesh mesh,int nodenum);
    /* Returns the index (position) of the node numbered by nodenum in the node
    data tables like mesh->coord, or 0 if there is no node numbered nodenum
    in the mesh or the data can not be bounkd.
    $A Igor sep03; */

int femnodenum(femesh mesh,int nodeind);
    /* Returns the number of the mesh node whose position in the node data
    tables like mesh->coord and other nodal data is nodeind.
    $A Igor sep03; */

double femnodcoord(femesh mesh,int nodenum,int whichcoord);
    /* Returns a specific coordinate (whichcoord) of the node nodnum of the
    finite element mesh mesh. Does not check if mesh is different than 0 etc.
    If indices nodnum and whichcoord are out of range then 0 is returned.
    $A Igor sep03; */

int femnodcoords(femesh mesh,int nodenum,coord3d coord);
    /* Writes three co-ordinates of the node numbered nodnum of the FE mesh to
    If there are more than 3 coordinates per node, the first three are written
    to coord, if there are less, zeros are written for the remaining
    co-ordinates. Function does not chech whether mesh or coord are differet
    than NULL. If index nodnum is out of range then zeros are written to coord.
      Returns the position of node data in the matrix mesh->nodcoord or 0 if
    the co-ordinates can not be found.
    $A Igor sep03; */

int femnodcoordsind(femesh mesh,int nodind,coord3d coord);
    /* Writes three co-ordinates of the node numbered nodnum of the FE mesh to
    If there are more than 3 coordinates per node, the first three are written
    to coord, if there are less, zeros are written for the remaining
    co-ordinates. Function does not chech whether mesh or coord are differet
    than NULL. If index nodnum is out of range then zeros are written to coord.
      Returns the position of node data in the matrix mesh->nodcoord or 0 if
    the co-ordinates can not be found.
    $A Igor sep03; */

int femnumgroups(femesh mesh);
    /* Returns the number of element groups in the finite element mesh "mesh".
    $A Igor sep03; */

elgrp femgroup(femesh mesh,int ngroup);
    /* Returns the a pointer to the ngroup-th element group containet in mesh,
    or NULL if ngroup is out of range or the data pointer for this group is
    NULL.
    $A Igor sep03; */

int femnumelements(elgrp grp);
    /* Returns the number of elements of the element group grp.
      grp may be NULL , in this case 0 is returned.
    $A Igor sep03; */

int femnumelnodes(elgrp grp,int el);
    /* Returns the number of nodes of the element el of the element group grp,
    or 0 if thre is no data about that.
    $A Igor spe03.*/

int femelnode(elgrp grp,int el,int which);
    /* Returns the number of the node which of element el on the group grp.
    does not check if grp is NULL. el must be a serial number of the element on
    the stack grp->eltop (which is necessarily the same as element ID), and
    which must be the local serial number of the node within an element. If a
    node that satisfies the parameters can not be identified, 0 is returned.
    $A Igor sep03; */

void femelnodes(elgrp grp,int el,indtab it);
    /* Loads indices of all nodes of element el of element group grp to the
    index tab it (in the appropriate order). Space for it must be allocated.
    The function does not check if grp is different than NULL. If indices are
    out of range or the data can not be obtained, then it will contain 0
    elements after the function call.
    $A Igor sep03; */

int femnumelsurf(elgrp grp,int el);
    /* Returns the number of surfaces of the element el of the element group
    grp, or 0 if thre is no data about that or el is out of range. It does not
    check if grp is NULL.
    $A Igor sep03.*/

int femnumelsurfedges(elgrp grp,int el,int surf);
    /* Returns the number of surface edges of the surface surf of the element
    el of the element group grp, or 0 if the data is not available or if the
    indices are out of range. grp may not be NULL because the function itself
    does not check it.
    $A Igor sep03 */

int femnumelsurfnodes(elgrp grp,int el,int surf);
    /* Returns the number of nodes on the surface surf of the element el of the
    element group grp, or 0 if the data is not available or if the indices are
    out of range. grp may not be NULL because the function itself does not
    check this.
    $A Igor sep03; */

int femelsurfnode(elgrp grp,int el,int surf,int which);
    /* Returns the node number of node which of the surface surf of element
    el on grp, or 0 if the indormation can not be obtained or if indices are
    out of range. It does not check if grp is NULL.
    $A Igor spe03.*/

void femelsurfnodes(elgrp grp,int el,int surf,indtab it);
    /* Loads indices of the surface surf of element el of the group grp on the
    index table it, which must be allocated. If indices are out of range or
    the information could not be obtained, then it will contain 0 indices
    after the call. grp must be different than NULL because the function does
    not check it.
    $A Igor spe03.*/

int femelsurfext(femesh mesh,elgrp grp,int el,int surf);
    /* Returns 1 if teh surface surf of element el of the element group grp is
    a part of the external surface of the element group grp, or 0 if it is not
    or if the information can not be obtained.
      mesh and grp may not be NULL because the function itself does not check
    this. It is necessary to pass mesh as argument because a pointer to the
    whole finite element mesh is necessary for identification of outer surfaces.
    The function automatically identifies the outer element surfaces for the
    all groups of the mesh if this data is not yet available (this refers to
    the element surfaces that are external to groups, which includes those that
    lie on the border of two groups).
    /* $A Igor sep03; */

int femel2d(elgrp grp,int el);
    /* Returns 1 if it can be confirmed that the element el of the group grp is
    two dimensional, otherwise it returns 0. Currently this function relies
    only on the information in gr->surfedg, but which should also be enough.
    $A Igor sep03; */

int femel3d(elgrp grp,int el);
    /* Returns 1 if it can be confirmed that the element el of the group grp is
    three dimensional, otherwise it returns 0. Currently this function relies
    only on the information in gr->surfedg, but which should also be enough.
    $A Igor sep03; */




    /* ROUTINES FOR CALCULATING DERIVED DATA: */

void femcalcelnuminv(femesh mesh);
    /* Calculates the position of element data for all elements and stores this
    information in mesh->elgrpinv and mesh->elnuminv. If these structures
    already exist, they are re-calculated.
    $A igor sep03; */

void femcalceltopinv(femesh mesh);
    /* Calculates and creates mesh->eltopinv, which contains for each node 
    a list of elements that contain this node. Index of an entry that
    represents a given node is the same as the indices of the the node data
    on mesh->coord, and elements are listed by their global numbers.
      If the structure already exists, it is re-calculated.
    $A igor sep03; */

void femcalcoutsurf(femesh mesh,int grpnum);
    /* For the element group grpnum of the mesh, checks which element surfaces
    are the outer surfaces for the group of elements and writes the information
    in the stack (...)->outsurf of a given group. If the stack alreay exists,
    the data is recalculated and rewritten.
      For every element thet has one or more output surfaces, an index table 
    is put on (...)->outsurf at the index of this element within the element
    group. Element of this index table (type indtab) are the element-local
    numbers of surfaces of the element that are outer surfaces of the group.
    $A Igor sep03; */

int femcalcnodnuminv(femesh fm);
    /* Na mrezi koncnih elementov kreira inverzno indeksno tabelo za stevilke
    vozlisc fm->nodnuminv, tako da je i. element zap. st. vozlisca st. i na
    fm->nodnum. Ce so stevilke vozlisc ze po vrsti ali je fm->nodnum enak
    NULL, postane tudi fm->nodnuminv NULL. Ce je inverzna tabela ze narejena,
    funkcija ne naredi nic. Funkcija vrne stevilo vozlisc, ki jih spravi na
    inverzno indeksno tabelo, ali -1, ce pride do napake.
    $A Igor jul01; */

void femcalclimits(femesh mesh,vector *addrmin,vector *addrmax);
    /* Calculates the minimum and maximum values for nodal co-ordinnates of
    the finite element mesh "mesh" and writes them to *addrmin and *addrmax,
    respectively. addrmin and addrmax must be addresses of vectors that are
    either NULL or allocated with any dimension.
      If mesh==NULL or mesh->coord==NULL then vectors *addrmin and *addrmax
    are deleted, but no error is reported.
    $A Igor oct03 feb04; */

void femcalcgrplimits(femesh mesh,int grp,vector *addrmin,vector *addrmax);
    /* Calculates the minimum and maximum values for nodal co-ordinnates of
    the group grp of the finite element mesh "mesh" and writes them to *addrmin
    and *addrmax, respectively. addrmin and addrmax must be addresses of 
    vectors that are either NULL or allocated with any dimension.
      If grp==0 then limits are calculated for the whole mesh, but in this
    case femcalclimits() is much more efficient.
      If there are no nodes belonging to the group grp then *addrmin and 
    *addrmax are deleted, but no error is reported.
    $A Igor oct03 feb04; */



    /* PRINTING MESH DATA: */

void printelsurftop(elgrp grp);
    /* Izpise topologijo povrsin elementov, ki so na skupini elementov grp.
    $A Igor jul01; */

void printelsurftopgrp(femesh fm);
    /* Izpise topologijo povrsin elementov, ki so na skupini elementov grp.
    $A Igor avg01; */

void printelgrp(femesh mesh,elgrp grp);
    /* Izpise vsebino objekta grp.
    $A Igor jul01; */

void printfemesh(femesh mesh);
    /* Izpise vsebino objekta mesh, izpise tudi topologije elementov vseh
    skupin elementov, ki so na mesh.
    $A Igor jul01; */


    /* OLD ROUTINES FOR OUTER SURFACES: */


int identifyfemeshsurfold(femesh fm);
    /* V mrezi koncnih elementov identificira vse tiste povrsine elementov, ki
    so zunanje povrsine za objekte iz koncnih elementov na fm. Funkcija deluje
    podobno kot identifyfemeshsurfgrpold, le da poisce zunanje povrsine celotne
    mreze koncnih elementov na fm in ne za vsako skupino elementov na fm
    posebej.
    Funkcija vrne stevilo vseh odkritih zunanjih povrsin oz. -1, ce pride
    pri izvedbi do napake.
    $A Igor avg01; */

int identifyfemeshsurfgrpold(femesh fm);
    /* V mrezi koncnih elementov identificira vse tiste povrsine elementov, ki
    so zunanje povrsine za skupine koncnih elementov na fm. Funkcija tvori za
    posamezne povrsine podatkovne strukture, na katerih sortirane stevilke
    vozlisc na povrsini (stevilke se vzamejo kar iste kot so na skladu
    (...)->eltop skupine, saj tu ni potrebno vedeti dejanskih stevilk vozlisc,
    ki se v splosnem dobijo preko fm->nodnuminv). Tako lahko funkcija primerja
    povrsine razlicnih elementov in ugotovi, ali gre pri dveh povrsinah
    razlicnega elementa fizicno za isto povrsino. Povrsine, ki so prvic
    identificirane, se nalozijo na sklad, da se lahko pri povrsinah, ki so
    identificirane kasneje, ugotovi, ali dana povrsina obstaja ze pri kaksnem
    drugem elementu. Zunanje povrsine skupine elementov so namrec le tiste, ki
    nastopajo v enem samem elementu.
    Funkcija vrne stevilo vseh odkritih zunanjih povrsin oz. -1, ce pride
    pri izvedbi do napake.
    $A Igor avg01; */


/* The functions that will replace the obsolete identifyfemeshsurfold and
identifyfemeshsurfgrpold: */

int identifyfemeshsurf(femesh fm);
int identifyfemeshsurfgrp(femesh fm);



int identifyfemeshsurfstruct(femesh fm);
    /* V strukturirani (!) mrezi koncnih elementov identificira vse tiste
    povrsine elementov, ki so zunanje povrsine za celotno mrezo koncnih
    elementov fm. Zunanje povrsine se identificirajo glede na to, koliko
    elementom pripadajo vozlisca na posamezni povrsini elementa. Ce vsa
    vozlisca na povrsini pripadajo manj elementom kot je najvecje ugotovljeno
    stevilo v dani skupini elementov za doloceno vozlisce elementa, potem se
    povrsina steje za zunanjo. Zaradi morebitnega napacnega delovanja pri
    primerih, kjer so objekti npr. sestavljeni le iz dveh plasti elementov in
    se lahko zgodi, da za kaksno vozlisce stevilo pojavov v nobenem elementu 
    ni vecje kot ce to vozlisce pripada zunanji povrsini (ker je stevilcenje
    taksno, da je se dolocena povrsina elementa nikoli ne pojavi kot notranja,
    kar je pri taksnih degeneriranih primerih mozno), se preveri, ali je
    funkcija nasla vsaj pricakovano povrsino zunanjih povrsin; Ce ni, se
    kriterij sprosti tako, da se povrsina spozna za zunanjo, ce ima ima vsaj
    polovica vozlisc manj kot maks. st. pojavov. Vseeno v taksnih primerih
    uporaba funkcije ni zanesljiva in je bolje uporabiti funkcije za
    nestrukturirano mrezo, ki so cisto splosne, a zato pocasnejse.
    Ta funkcija obravnava vse skupine elementov skupaj, ne loceno, zato se
    mejne povrsine med posameznimi skupinami elementov ne stejejo za zunanje
    povrsine. Funkcija vrne stevilo vseh odkritih zunanjih povrsin oz. -1, ce
    pride pri izvedbi do napake.
    $A Igor jul01; */





    /*   BRANJE MREZ IZ ELFENOVIH DATOTEK (neutral format):   */


int freadelfmesh(FILE *fp, femesh *pfm);
    /* Iz datoteke fp, ki mora biti odprta za branje in mora biti v Elfenovem
    neutral formatu, prebere podatke o mrezi koncnih elementov in jih zapise
    v *pfm. Funkcija ne izvaja nobene dodatne obdelave podatkov. Vrne 0, ce med
    branjem ni prislo do napak, in -1, ce je.
     Opomba:
    Funkcija najprej sama zbrise podatke, ki po moznosti ze obstajajo na pfm.
    Morda bo kdaj treba narediti funkcijo, ki dodaja k obstojecim podatkom.
    $A Igor jul01; */



    /* BRANJE TOPOLOGIJE POVRSIN ELEMENTOV (standardiziran format) */

long freadelsurftop(FILE *fp,long pos,elgrp grp);
    /* Iz datoteke fp prebere od trenutne pozicije naprej podatke o topologiji
    povrsin elementa in jih zapise na strukturo podatkov o elementu *grp.
    Ce se pri branju ne pojavijo napake, vrne pozicijo 1. znaka za zadnjim
    prebranim podatkom, ce se, pa -1. Podatki v datoteki morajo biti v
    dogovorjeni obliki. Vsi nestevilski podatki se ignorirajo,, stevilski pa
    so organizirani na naslednji nacin: 1. stevilka je stevilo povrsin, sledijo
    stevila robov za vsako povrsino (vedno 1 v dveh dimenzijah, v treh pa
    navadno 3 ali 4), stevilo vozlisc na povrsini za vsako povrsino, nazadnje
    pa so za vsako povrsino nastete stevilke vozlisc, ki so na povrsini.
    Ce je pos manj od 1, se na zacetku postavi na 1.
     Primer datoteke:
      Number of Surfaces:
      4
      Number of borders for individual surfaces (surfedg):
      1 1 1 1
      Number of nodes per each surface:
      2 2 2 2
      Local numbers of nodes that constitute individual surfaces:
      1 2
      2 3
      3 4
      4 1
      End of file.
     OPOZORILO:
    Funkcija zbrise polje grp->surfel, kjer so podatki o zunanjih povrsinah
    posameznih elementov.
    $A Igor jul01; */

long filereadelsurftop(char *filename,long pos,elgrp grp);
    /* Iz datoteke z imenom filename prebere s funkcijo freadelsurftop
    podatke o topologiji povrsin elementa. Bere od pozicije pos naprej,
    vrne pozicijo po zadnjem prebranem podatku oz. -1, ce je prislo do
    napake, in zapise podatke v *grp.
    $A Igor jul01; */

long freadelsurftopgrp(FILE *fp,long pos,femesh fm);
    /* Iz datoteke fp prebere podatke o topologiji povrsin elementov za
    skupine elementov, ki so na fm. Podatke bere od pozicije pos naprej in
    morajo biti v taksni obliki, kot so podatki za funkcijo freadelsurftop,
    poleg tega pa mora biti prvi podatek stevilo skupin, za katere se prebere
    podatke, pri vsaki skupini pa mora biti na zacetku se stevilka skupine.
    Ce je branje uspesno, vrne funkcija pozicijo takoj za zadnjim prebranim
    podatkom, drugace pa -1. Ce je pos manj kot 1, se na zacetku postavi na 1.
     POZOR!
     Podatke of topologiji povrsin elementa se lahko bere sele potem, ko je
    ze alociran prostor za podatke o elementih (objekti tipa elgrp), ni pa
    potrebno, da je alociran prostor za podatke o topologiji povrsin (polji
    surftop in surfedg na objektu tipa elgrp).
    $A Igor jul01; */

long filereadelsurftopgrp(char *filename,long pos,femesh fm);
    /* Iz datoteke z imenom filename prebere s funkcijo freadelsurftopgrp
    podatke o topologiji povrsin elementa. Bere od pozicije pos naprej,
    vrne pozicijo po zadnjem prebranem podatku oz. -1, ce je prislo do
    napake, in zapise podatke v *grp.
    $A Igor jul01; */




/* UPORABA DATOTEK S PODATKI O TOPOLOGIJI POVRSIN ZA POSAMEZNE ELEMENTE: */

int dirreadelsurftopgrp(char *dirname,femesh fm);
    /* Podatke o topologiji povrsin elementov na skupinah elementov mreze fm
    poisce v direktoriju dirname. Podatke isce v datotekah z istim imenom kot
    je ime tipa elementov, ki tvorijo skupino, torej (...)->elspec, plus
    koncnica ".est" (element surface topology). Podatki v datotekah za
    posamezne elemente morajo biti v istem formatu kot za funkcijo
    freadelsurftop(), pred zacetkom podatkov pa mora biti obvezno niz "begin"
    (lahko se zacne z veliko ali je cel zapisan z velikimi crkami). Ce se
    ustrezne datoteke za kak tip elementov ne najde, funkcija vrne -1.
    $A Igor avg01; */

int dirreadelsurftopgrpsafe(char *dirname,femesh fm);
    /* Podatke o topologiji povrsin elementov na skupinah elementov mreze fm
    poisce v direktoriju dirname. Podatke isce v datotekah z istim imenom kot
    je ime tipa elementov, ki tvorijo skupino, torej (...)->elspec, plus
    koncnica ".est" (element surface topology). Podatki v datotekah za
    posamezne elemente morajo biti v istem formatu kot za funkcijo
    freadelsurftop(), pred zacetkom podatkov pa mora biti obvezno niz "begin"
    (lahko se zacne z veliko ali je cel zapisan z velikimi crkami). Ce se
    ustrezne datoteke ne najde, funkcija vprasa za novo ime direktorija.
    $A Igor avg01; */




   /* BRANJE TOPOLOGIJE POVRSIN ELEMENTOV S STAND. VHODA IN VARNO BRANJE: */


int readelsurftop(elgrp grp);
    /* S stand. vhoda prebere podatke o topologiji povrsin elementa in jih
    zapise na strukturo podatkov o elementu *grp. Ce se pri branju ne pojavijo
    napake, vrne 0, ce se, pa -1. Funkcija zahteva od uporabnika, da po vrsti
    vstavlja podatke v stevilski obliki, ki se berejo s funkcijo readint.
    Prostor za podatke na grp se ob branju sproti alocira.
     Opozorilo:
    Funkcija zbrise polje grp->surfel, kjer so podatki o zunanjih povrsinah
    posameznih elementov.
    $A Igor jul01; */

int readelsurftopgrp(femesh fm);
    /* S stand. vhoda prebere podatke o topologiji povrsin elementov za 
    posamezne skupine elementov in jih zapise na strukturo podatkov o emrezi
    koncnih elementov *fm. Ce se pri branju ne pojavijo napake, vrne 0, ce se,
    pa -1. Funkcija zahteva od uporabnika, da po vrsti vstavlja podatke v
    stevilski obliki, ki se berejo s funkcijo readint. Prostor za podatke na
    *fm se ob branju sproti alocira.
     POZOR!
     Podatke of topologiji povrsin elementa se lahko bere sele potem, ko je
    ze alociran prostor za podatke o elementih (objekti tipa elgrp), ni pa
    potrebno, da je alociran prostor za podatke o topologiji povrsin (polji
    surftop in surfedg na objektu tipa elgrp).
    $A Igor jul01; */

long filereadelsurftopgrpsafe(char *filename,femesh fm);
    /* Iz datoteke z imenom fp poskusa prebrati podatke o topologiji povrsin
    elementov za skupine elementov, ki so na *fm. Ce je filename razlicen
    od NULL ali "", najprej poskusi z branjem iz datoteke z imenom filename,
    drugace pa z branjem preko standardnega vhoda (rocno vstavljanje podatkov).
    Po branju preveri, ce so prebrani podatki za vse skupine elementov in javi
    napako, ce niso. Funkcija vrne negativno stevilo, ce branje ni bilo uspesno
    oz. pozitivno ali 0, ce je bilo branje uspesno. Funkcija javi napako tudi,
    ce je fm NULL ali ce ne kaze na strukturo, na kateri so podatki o vsaj eni
    skupini elementov. Funkcija poskusa poskrbeti, da se preberejo topologije
    povrsin za vse skupine elementov na fm, v nasprotnem primeru javi napako.
    $A Igor jul01; */

long readelsurftopgrpsafe(char *dirname,char *filename,femesh fm);
    /* Branje podatkov o topologiji povrsin elementov za skupine elementov, ki
    so na *fm, z varnostnimi mehanizmi in na razlicne nacine.
      Ce je dirname razlicen od NULL ali "", najprej poskusi se z branjem iz
    direktorija z imenom dirname in ce je filename razlicen od NULL ali "",
    poskusi (se) z branjem iz datoteke z imenom filename. Ce ne poskusi niti
    z branjem iz direktorija niti iz datoteke oziroma dokler niso dolocene
    topologije povrsin za vse skupine, poskusa z branjem na tri nacine, ki
    vkljucujejo poleg branja iz direktorija in datoteke se branja s standardnega
    vhoda. Iz direktorija bere s funkcijo dirreadelsurftopgrpsafe, iz datoteke s
    funkcijo filereadelsurftopgrp, s standardnega vhoda pa s funkcijo
    readelsurftopgrp.
    Po branju preveri, ce so prebrani podatki za vse skupine elementov in javi
    napako, ce niso. Funkcija vrne negativno stevilo, ce branje ni bilo uspesno
    oz. pozitivno ali 0, ce je bilo branje uspesno. Funkcija javi napako tudi,
    ce je fm NULL ali ce ne kaze na strukturo, na kateri so podatki o vsaj eni
    skupini elementov. Funkcija poskusa poskrbeti, da se preberejo topologije
    povrsin za vse skupine elementov na fm, v nasprotnem primeru javi napako.
    $A Igor avg01; */


    /* VARIOUS MESH MANIPULATION UTILITIES: */

void transffemeshbas(femesh mesh,int grp,vector param,
                  void (*transform)(vector orig,vector transf,vector param));
    /* Transforms co-ordinates of the nodes of the element group grp of the
    mesh mesh by the function transf. If grp is 0 then nodes of all the groups
    are transformed.
      The transform is performed from mesh->origcoord to mesh->nodcoord. If
    both are NULL (or if mesh is NULL) an error is reported, if mesh->nodcoord
    is NULL then a level 2 warning is launched and mesh->origcoord is copied
    to mesh->nodcoord before performing operation, and if mesh->origcoord is
    NULL then mesh->nodcoord is copied to mesh->origcoord before the operation
    and no warning is launched. Such a regime is adopted because it is not
    normally assumed that the field (...)->origcoord of a finite element mesh
    is allocated.
    $A Igor oct03 fev04; */

void transffemesh(femesh mesh,int grp,int which,vector param,
                  void (*transform)(vector orig,vector transf,vector param));
    /* The same as transffemesh0, except that the caller can specify by which
    how the co-ordinates are transformed.
      which<0 :
      transform is performed on original co-ordinates mesh->origcoord
    without affecting the current co-ordinates. If mesh->origcoord is NULL
    then the current co-ordinates are first copied to the original without
    a warning.
      which==0 (default):
      transform maps from original co-ordinates (mesh->origcoord) to current
    (mesh->nodcoord). If mesh->origcoord==NULL then current co-ordinates
    are first copied to original, and if mesh->nodcoord==NULL then original
    coordinates are first copied to current, without any warning.
      which>0 :
      transform will be performed on current co-ordinates (mesh->nodcoord).
    If mesh->nodcoord==NULL then original co-ordinates are first copied
    to current and a level warning is launched.
    $A Igor oct03; */

int addfemesh(femesh mesh,femesh *maddr,int newgroups,double tolcoord);
    /* Adds elements and nodes of mesh to the finite element mesh whose address
    is maddr. *maddr may be NULL (in this case it is created and the function
    only copies the mesh on it) or may contain no elements.
      If newgroups is not 0 then element groups wirth the same numbers are not
    merged, but a new group is created on *maddr for each group on mesh.
      If tolcoord>=0 then nodes of the two meshes with the same co-ordinates
    are considered identical and only one node number is assigned to such a
    pair (this is always the number used on the original mesh). If tolcoord==0
    then only exact matching is considered. When tolcoord>0, two nodes are
    considered identical when absolute difference is below tolcoord for all
    of their co-ordinates.
      Returns 0 if operation succeeded or a negative number if there is an
    error. A warning is launched if mesh does no contain any nodes or elements
    (-1 is also returned in this case).
      Properties:
      Node and element numbers (if any) on *maddr are preserved. If there are
    holes in node or element numbering these are not filled.
      If there are identical nodes on mesh itself, they are olso joined into
    one node. Therefore you can use this function only for removal of multiple
    nodes (e.g. by adding a mesh to an empty mesh and then deletinf the added
    mesh). Function can even be used to number nodes in such a way that thre
    are no gaps and the fields (...)->nodnum and (...)->nodnuminv are not
    needed any more on the mesh structure.
      Warnings:
      Because of finite precision you should not set tolcoord to 0 except in
    some very exceptional cases where there is strong correlation between 
    generation of the original and added mesh.
      Only the current co-ordinates mesh->nodcoord of the added mesh are copied
    to *maddr while mesh->origcoord are not copied. (*maddr)->origcoord are
    deleted if they are not NULL. If original co-ordinates should be copied
    instead, they can simply be swaped before the operation.
    $A Igor feb04; */

void stretchtransform(vector orig,vector transf,vector param);
    /* Maps orig to transf by stretchig co-ordinates by the corresponding
    components of param. If param has less components than orig then the
    remaining components are not affected, except if param has only
    one component, in which case all components of orig are multiplied by 
    that component.
      Vectors orig and transf must be allocated and of compatible dimensions,
    otherwise error is reported. They can point to the same vector. param must
    also be allocated and of dimension at least 1.
    $A Igor feb04; */

void translationtransform(vector orig,vector transf,vector param);
    /* Maps orig to transf by translation by the corresponding components of
    param. If param has less components than orig then the remaining
    components are not affected (even if there is only one component - this is
    different for example from stretchtransform().
      Vectors orig and transf must be allocated and of compatible dimensions,
    otherwise error is reported. They can point to the same vector. param must
    also be allocated and of dimension at least 1.
    $A Igor feb04; */

int femgrid(femesh cell,femesh *maddr,int newgroups,double tolcoord,
            int numx,int numy,int numz,
            mat3d transmat,vec3d shift);
    /* Takes the finite element mesh cell and creates a grid of equal meshes by
    translating and copying it. The created grid is added to *maddr, which is
    created anew if necessary. If any element groups already exist on *maddr
    they are kept, therefore cara of cleaning the original contents must be 
    taken specially if this is necessary.
      If newgroups==0 then groups numbers of the original cells are preserved,
    (i.e. element groups in all copied cells and eventually the original mesh
    with the same group number are merged into one group). If tolcoord>=0 it
    is used to identify which nodes in the created grid (eventually together
    with the original mesh) have the same (witgin tolerance) co-ordinates.
    Such groups of multiple nodes are then replaced by a single node. tolcoord
    0 should be rarely used (because of numerical errors obteined at
    translation). Two nodes are consitered identical if all co-ordinates differ
    absolutely by something less or equal tol.
      numx, numy and numz specify the number of cells in a grid in three
    directions, transmat specifies the three translation vectors for
    creating the lattice of cells and shift specifies the shift by which the
    entire grid is shifted, both can be NULL.
      If shift is NULL then the grid is not shifted. If transmat is NULL
    then the translation vectors are set in the co-ordinate directions x, y
    and z such that their sizes equal to sizes of sides of the smallest 3D
    frame (sides parallel to co-ordinate axes) that contains the mesh.
    $A Igor feb04; */

    /* FOR the FEAP INTERFACE: */

int fwritefemeshfeap(FILE *fp,femesh mesh);
    /* Writes the finite element mesh in the FEAP format to the file fp 
    starting from the current position in the file. Returns 0 if OK, negative
    value in the case of error.
    $A Igor feb03; */

int filewritemeshfeap(char *filename,femesh mesh);
    /* Writes the finite element mesh in the FEAP format to the file named
    filename. Returns 0 if OK, negative value in the case of error. If the
    file with that name exists its contents are overwritten.
    $A Igor feb03; */






    /* PLOTTING FE MESHES: */




gogroup gofemeshplotbas(femesh mesh,int ngroup,
          char frout,char fillout,char frin,char fillin,
          char pelnum,char pnodnum,char pnodes,
          gofillsettings fs,golinesettings ls,
          gotextsettings tselements,gotextsettings tsnodes,
          golinesettings lsnodes,int markertype,double markersize);
    /* Creates and returns a plot of a finite element mesh mesh or one of its
    element groups. If ngroup is 0 then all element groups are plotted,
    otherwise just the element group whose number is ngroup is plotted.
      If frout is different than 0 then the frame is plotted for outer element
    surfaces of the group, if fillout is different than 0 then a filled frame
    is plotted for outer surfaces, if frin is different than 0 then a frame is
    plotted for internal element surfaces, and if fillin is different than 0
    then the filled frame is also plotted for the inner surfaces.
      pelnum is an orr-ed combination of flags that determine if and how the
    element numbers are plotted with the mesh. If 1 is set then element numbers
    are plotted, if 2 is set then the surface numbers are also plotted where
    appropriate and if 4 is set (3rd bit) then the group number is plotted with
    each element.
      If pnodnum is different than 0 then node numbers are plotted. If pnodes
    is different than 0 then markers are plotted for nodes.
      fs are fill settings for coloring element surfaces, ls are line settings
    for plotting element outlines, and tselements are text settings for
    plotting element numbers and tsnodes are text settings for plotting node
    numbers. lsnodes are line settings for plotting node markers, markertype
    is the type of markers plotted for nodes and markersize is their size.
    $A Igor sep03; */



void plotmeshtofile(femesh fm,char *filename,double fi, double theta,
                 char *str,vector param,int intfc,int winid);
    /* Plots a finite element mesh fm to a file named filename so that it can be
    visualized later. If filename is NULL or "" then the name of the file is
    chosen isn such a way that it is unique for one run of the program, which
    enables that several plots can be produced and kept in the current directory.
    The name begins with  "SGS_meshplot".
      fi and theta define the viewpoint and are set automatically in the case
    that mesh is 2D. 
      If str is different than NULL then this string is plotted on the top of the
    plot, and if vector of parameters param is different than NULL then its
    components are plotted. They are plotted beside the string (if it is not NULL),
    therefore the string must contain a newline in order to plot the components
    in a different line than a string (with some graphic interfaces this might not
    work, however).
      intfc defines the plotting interface to be used, such as SG_PLOT_TCL or 
    SG_PLOT_PS.
       If intfc specifies a screen interface (as opposed to file plotting) then
    winid can be used for a minimal window control. If winid is 0 then a new
    window is open every time this function is called. If it is greater than 0
    (a limit is 1000) then it represents an internal window ID and function
    calls with the same winid will cause plotting to the same window.
    $A Igor feb03; */

void plotmeshtcl(femesh fm,char *filename,double fi, double theta,
                 char *str,vector param);
    /* Plots a finite element mesh fm to a Tcl file named filename, which can
    be later interpreted by the wish shell in order to visualize the mesh.
    If filename is NULL or "" then the name of the file is chosen in such a
    way that it is unique for the current run of the program, which enables that
    several plots can be produced and kept in the current directory (the name in
    this case begins with "SGS_meshplot".
      fi and theta define the viewpoint and are set automatically in the case
    that mesh is 2D. 
      If str is different than NULL then this string is plotted on the top of the
    plot, and if vector of parameters param is different than NULL then its
    components are plotted. They are plotted beside the string (if it is not NULL),
    therefore the string must contain a newline in order to plot the components
    in a different line than a string (with some graphic interfaces this might not
    work, however).
    $A Igor mar04; */

void plotmeshps(femesh fm,char *filename,double fi, double theta,
                 char *str,vector param);
    /* Plots a finite element mesh fm to a Tcl file named filename, which can
    be later interpreted by the wish shell in order to visualize the mesh.
    If filename is NULL or "" then the name of the file is chosen in such a
    way that it is unique for the current run of the program, which enables that
    several plots can be produced and kept in the current directory (the name in
    this case begins with "SGS_meshplot".
      fi and theta define the viewpoint and are set automatically in the case
    that mesh is 2D. 
      If str is different than NULL then this string is plotted on the top of the
    plot, and if vector of parameters param is different than NULL then its
    components are plotted. They are plotted beside the string (if it is not NULL),
    therefore the string must contain a newline in order to plot the components
    in a different line than a string (with some graphic interfaces this might not
    work, however).
    $A Igor mar04; */

void plotmesh(femesh fm,double fi, double theta,char *str,vector param,int winid);
    /* Plots a finite element mesh fm in a new window on the screen.
      fi and theta define the viewpoint and are set automatically in the case
    that mesh is 2D. 
      If str is different than NULL then this string is plotted on the top of the
    plot, and if vector of parameters param is different than NULL then its
    components are plotted. They are plotted beside the string (if it is not NULL),
    therefore the string must contain a newline in order to plot the components
    in a different line than a string (with some graphic interfaces this might not
    work, however).
      If winid is 0 then a new window is open every time this function is called.
    If it is greater than 0 (a limit is 1000) then it represents an internal 
    window ID and function calls with the same winid will cause plotting to the
    same window on the screen (with clearing executed before plotting).
    $A Igor mar04; */











#endif









