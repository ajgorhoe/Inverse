
/* Ensure at most one inclusion: */
#ifndef INCLUDED_sg_graph
#define INCLUDED_sg_graph


         /*********************************************/
         /*                                           */
         /*      COMPOSITION OF 2D AND 3d GRAPHS      */
         /*                                           */
         /*********************************************/


#ifndef INCLUDED_sg_obj
 #include <sg_obj.h>
#endif

#ifndef INCLUDED_sg_ploto
 #include <sg_ploto.h>
#endif


         /***********************/
         /*                     */
         /*      2D GRAPHS      */
         /*                     */
         /***********************/

/* Functions for 2D graphs are defined in ../sg_gr2d.h, which is included in
   ../sg_gr3d.h */
   

gogroup gomakeframe2d(double minx,double miny,double maxx,double maxy,double z,
        golinesettings ls,golinesettings lsbas,int numx,int numy);
    /* Sestavi graficni objekt - dvodimenzionalni okvir iz crt. minx, miny, 
    maxx in maxy so meje okvirja, z pa koordinata z (visina) okvirja. numx in
    numy povesta, na koliko delov naj bodo razdeljene crte, vzporedne z osema.
    ls doloca lastnosti crt, ki sestavljajo okvir, lsbas pa lastnosti crt, ki
    tvorijo osnovni kot. Ce je lsbas enak NULL, se vzame za lastnosti crt, ki
    tvorijo osnovni kot, kar ls.
    $A Igor feb97; */

gogroup gomakerulers2d0(double minx,double miny,double maxx,double maxy,
          double z,golinesettings ls,golinesettings ls1,golinesettings ls2,
          int numx,double relx,double relx1,double relx2,double posx,
          int numy,double rely,double rely1,double rely2,double posy);
    /* POZOR! To je zastarela funkcija, ki naj se ne bi vec uporabljala.
    Namesto nje naj bi se v prihodnje uporabljala go3dgridbas().
     Postavi ravnila na robove (okvir) dvodimenzionalnega grafa. minx,miny,
    maxx in maxy so meje okvirja, z je koordinata z ravnil (visina), ls, ls1
    in ls2 so lastnosti crt pri finih, srednje finih in grobih razdelkih,
    naprej pa so argumenti, ki dolocajo geometrijske lastnosti in sicer:
    numx je  najmanjse stevilo vseh razdelkov osi x skupaj, relx je relativna
    dolzina finih razdelkov na osi x v primerjavi s sirino grafa (maxy-miny),
    relx1 in relx2 sta isti stvari za srednjo in grbo delitev, posx pa je
    relativna pozicija zacetkov razdelkov na osi x glede na sirino grafa. Ce je
    npr. posx=1 in relx=0.1, so fini razdelki na osi x locirani na zgornjem
    robu grafa in strlijo za 0.1 sirine grafa navzven (ker je relx pozitiven;
    ce bi bil negativen, bi strleli navznoter). Ekvivalentni so pomeni
    spremenljivk, ki dolocajo geometrijske lastnosti razdelkov za os y.
    $A Igor feb97; */

gogroup gomakerulers2d(double minx,double miny,double maxx,double maxy,
          double z,golinesettings ls,golinesettings ls1,golinesettings ls2,
          int num,double rel,double rel1,double rel2);
    /* Postavi ravnila na robove dvodimenzionalnega grafa. minx, miny, maxx in
    maxy dolocajo okvir grafa z pa koordinato z (visino) grafa. V ls, ls1 in
    ls2 so nastavitve za risanje crt pri fini, srednji in grobi razdelitvi.
    num je najmanjse stevilo vseh razdelkov za katerokoli os,rel, rel1 in rel2
    pa so ustrezne relativne dolzine razdelkov glede na dimenzije okvirja.
    $A Igor feb97; */

gogroup gomakerulertext2d0(double minx,double miny,double maxx,double maxy,
            double z,gotextsettings tsx,gotextsettings tsy,
            int digx,int numx,double numxtext,double posx,
            int digy,int numy,double numytext,double posy);
    /* POZOR! To je zastarela funkcija, ki naj se ne bi vec uporabljala.
    Namesto nje naj bi se v prihodnje uporabljala go3dgridtextbas().
      Sestavi stevilcne oznake za ravnila dvodimenzionalnega grafa. minx,
    miny,maxx in maxy so meje okvirja grafa, z pa je koordinata z (visina)
    grafa. V tsx in tsy so nastavitve za tekst za os x in za os y.
    digx je stevilo decimalnih mest, ki se izpisuje za os x. numx je najmanjse
    stevilo razdelkov za os x, kot je bilo uporabljeno v funkciji, ki naredi
    ravnilo, numxtext pa je najmanjse stevilo stevilcnih oznak, ki se izpisejo
    tekstovno. Glede na numx in numxtext se funkcija odloci, ali bodo stevilcne
    oznake le na najbolj grobi delitvi, ali pa morda tudi na finejsih. posx je
    relativna oddaljenost stevilcnih oznak za os x od spodnjega roba grafa
    glede na visino grafa (maxy-miny). Ce je na primer posx=0.1, bodo stevilcne
    oznake za os x ob spodnjem robu grafa, pomaknjene za 0.1 visine grafa v
    notranjost, ce pa je posx=1.05, bodo nad zgornjim robom grafa pomaknjene
    za 0.05 visine grafa navzven.
    Pomen argumentov digy, numy, numytext, posy in posy je ekvivalenten, le da
    se nanasajo na os y.
    $A Igor feb97 */

gogroup gomakerulertext2d(double minx,double miny,double maxx,double maxy,
            double z,gotextsettings ts, int dig,int num,double numtext,
            double pos);
    /* Postavi stevilcne oznake v obliki teksta za ravnila dvodimenzionalnega
    grafa. minx, miny, maxx in maxy dolocajo meje okvirja gtrafa, z pa njegovo
    koordinato z (visino). V ts so nastavitve za tekst. digits je stevilo
    decimalk, ki se izpisejo v oznakah. num je najmanjse stevilo vseh razdelkov
    ravnil, numtext pa je najmanjse stevilo oznak. pos je relstivna pozicija
    oznak glede na dimenzije okvirja. Funkcija je misljena za uporabo skupaj s
    funkcijo gomakerulers2d(). V tem primeru mora biti argument num enak kot
    pri klicu te funkicje.
    $A Igor feb97; */

gogroup gocurveplot2dpar(double fx(double),double fy(double),
        int num,int div,double from, double to,double z,golinesettings ls);
    /* Sestavi graficni objekt - graf parametricno podane krivulje v dveh
    dimenzijah. Funkcija je identicna gocurveplot2dpar0(), le da postavi se ime
    skupine, ki jo vrne.
    $A Igor feb97; */

gogroup gocurveplot2d(double ff(double),int num,int div,
        double from, double to,double z,golinesettings ls);
    /* Sestavi graficni objekt - graf funkcije ff, pri cemer x tece od from do
    to. Krivulja je razdeljena na num ravnih delov, od katerih je vsak
    razdeljen na div krajsih crt. V ls so lastnosti crt, ki sestavljajo
    krivuljo. z je koordinata z (visina) grafa.
    $A Igor feb97; */

gogroup gocurveplotpolar(double fr(double),int num,int div,
        double from, double to,double z,golinesettings ls);
    /* Sestavi graficni objekt - polarni graf funkcije fr, pri cemer polarni
    kot tece od from do to. Krivulja je razdeljena na num ravnih delov, od
    katerih je vsak razdeljen na div krajsih crt. V ls so lastnosti crt, ki
    sestavljajo krivuljo. z je koordinata z (visina) grafa.
    $A Igor feb97; */




         /***********************/
         /*                     */
         /*      3D GRAPHS      */
         /*                     */
         /***********************/


   

void calccontourcolor(double z,double min,double max,truecolor color);
    /* Izracuna barvo konture, ki lezi na z, pri cemer je spodnja meja obmocja
    min, zgornja pa max. Proti nizjim vrednostim gredo barve proti modri, proti
    visjim pa proti rdeci. Izracunana barva se zapise v spremenljivko *color,
    za katero mora biti prostor ze alociran. */

gogroup gomakeframe3dsimple(frame3d frame);
    /* Sestavi graficni objekt - tridimenzionalni okvir iz crt. frame doloca
    koordinate okvirja. */

gogroup gomakeframe3d(frame3d frame,golinesettings ls,golinesettings lsbas,
    int numx,int numy,int numz);
    /* Sestavi graficni objekt - tridimenzionalni okvir iz crt. frame doloca
    koordinate okvirja. numx, numy in numz povedo, na koliko delov naj bodo
    razdeljene ctte, vzporedne z osmi x, y in z. ls doloca lastnosti crt, ki
    sestavljajo okvir, lsbas pa lastnosti crt, ki tvorijo osnovni kot. */

gogroup gomakeendaxeslabels3d0(frame3d frame,char *strx,char *stry,char *strz,
            gotextsettings tsx, gotextsettings tsy,gotextsettings tsz,
            double factx,double facty,double factz);
    /* Sestavi graficni objekt - tekst na koncu crt, ki tvorijo osnovni kot
    okvirja v 3 dimenzijah. frame doloca koordinate okvirja. tsx, tsy in tsz
    dolocajo lastnosti teksta na koncu crt v smeri osi x, y in z, strx, stry
    in strz so nizi, ki se izpisejo, factx, facty in factz pa predstavljajo
    deleze intervalov (iz parametra frame), za katere je tekst pomaknjen izven
    grafa od konca ustreznih crt. */

gogroup gomakeendaxeslabels3d(frame3d frame,char *strx,char *stry,char *strz,
            gotextsettings ts,double fact);
    /* Podobno kot gomakeendaxeslabels3d0(), le da ima tekst za vse osi enake
    lastnosti (ts) in tudi delezi pomika teksta izven okvirja (fact) so enaki. */ 

int gridbascalc(double min,double max,double *first,double *step);
    /* Izracuna zacetno tocko, korak in stevilo tock osnovne mreze, ki jo damo
    lahko na interval z mejama min in max. Korak osnovne mreze mora biti cela
    potenca stevila 10. */

void gridcalc(double min,double max,int nummin,stack st,stack st1,
              stack st2);
     /* Dolooci vse razdeleke mreze za interval med min in max. Na sklad s0
     nalozi razdelke najfinejse delitve, na sklad s1 razdelke bolj grobe, na
     sklad s2 pa razdelke najbolj grobe delitve. nummin je najmanjse dopustno
     stevilo razdelkov v najbolj grobi delitvi. Skladi morajo biti ob klicu
     funkcije inicializirani (prostor alociran, brez elementov). Mnozice
     razdelkov, ki se nalozijo na sklad, so disjunktne. */

gogroup go3dgridbas(frame3d frame,
          golinesettings xls0,golinesettings xls1,golinesettings xls2,
            int xnum,double xposy,double xposz,double xrely0,double xrely1,
            double xrely2,double xrelz0,double xrelz1,double xrelz2,
          golinesettings yls0,golinesettings yls1,golinesettings yls2,
            int ynum,double yposx,double yposz,double yrelx0,double yrelx1,
            double yrelx2,double yrelz0,double yrelz1,double yrelz2,
          golinesettings zls0,golinesettings zls1,golinesettings zls2,
            int znum,double zposx,double zposy,double zrelx0,double zrelx1,
            double zrelx2,double zrely0,double zrely1,double zrely2,
          char putx,char puty,char putz);
    /* Postavi ravnila na robove tridimenzionalnega grafa. Ta funkcija je
    nadomestilo za gomakerulers3d0(), od katere nudi precej vec moznosti, je
    pa zato klic funkcije malo bolj kompliciran. Glede hitrosti je funkcija
    zanemarljivo pocasnejsa od gomakerulers3d0(). Misljeno je, da bi se v
    prihodnje ta funkcija uporabljala kot osnova za vse vrste ravnil v dvo ali
    trodimenzionalnih grafih, vse bolj specificne funkcije naj bi bile torej
    izpeljane iz te.
      frame3d je okvir grafa, nato pa sledijo tri serije argumentov za osi x,
    y in z. Zadnji trije argumenti putx, puty in putz povedo, ali naj se naredi
    ravnilo za os x, y oziroma z (0 pomeni ne, ostale vrednosti pa da).
      Pomen argumentov za os x (za ostale osi so argumenti ekvivalentni):
    xls0, xls1 in xls2 dolocajo lastnosti crt za fine, srednje in grobe
    razdelke za ravnilo v smeri osi x. xnum je najmanjse stevilo vseh razdelkov
    skupaj za os x. xposy in xposz dolocata pozicijo ravnila v smeri osi x
    glede na koordinati y in z Pozicija je podana relativno glede na okvir
    frame. Tako je koordinata y ravnila dolocena kot miny+xposy*(maxy-miny),
    ce sta miny in maxy meji okvirja frame v smeri osi y. xrely0, xrely1 in
    xrely2 dolocajo dolzino crtic za fine, srednje in grobe razdelke v smeri
    osi y, spet relativno glede na okvir grafa (xrelz0, xrelz1 in xrelz2 imajo
    podoben pomen, le da gre za dolzino v smeri osi z). Tako pozicija ravnila,
    ki je podana z xposy in xposz, doloca 1. tocko vsake crtice, odmik, ki je
    podan z xrely... in xrelz..., pa doloza 2. tocko vsake zrtice. y koordinati
    crtice za fini razdelek sta na primer miny+xposy*(maxy-miny) in
    miny+xposy*(maxy-miny) + xrely0*(maxy-miny).
      Funkcija vrne skupino graficnih objektov, na kateri so podskupine za osi
    x, y in z (glede na vrednosti putx, puty in putz se lahko zgodi, da  katera
    od teh podskupin ne obstaja), na vsaki od teh pa so podskupine, ki
    vsebujejo crtice za fine, srednje fine in grobe razdelke.
      OPOMBE:
     Po navadi so lastnosti crt, ki prikazujejo razdelke, enake za vse osi za
    doloceno finost. V tem primeru je ob klicu funkcije xls0=ylsy=zls0,
    xls1=yls1=zls1 in xls2=yls2=zls2.
     Po navadi so crtice, ki predstavljajo razdelke, vzporedne s katero od
    koordinatnih osi. V tem primeru je za ravnilo v smeri vsake osi en set
    argumentov ...rel... enak 0. Ce na primer hocemo, da bodo crtice na ravnilu
    za os x vzporedne osi z, bodo xrely0, xrely1 in xrely2 enaki 0.
     Po navadi lezijo crtice ravnila na eni izmed ravnin okvira frame. V tem
    primeru je eden izmed obeh argumentov ...pos... za ravnilo na doloceni osi
    enak ali 0 ali 1. Ce na primer ravnilo za os x lezi na ravnini 
    y=frame->max.y, je xposy=1. Poleg tega po navadi ravnila lezijo na robovih
    teh ravnin, zaradi cesar sta oba izmed doticnih argumentov ...pos... za
    dano ravnilo enaka ali 0 ali 1. Ce na primer hocemo, da ravnilo za os x
    lezi na spodnjem robu ravnine y=frame->max.y, je xposy=1 in xposz=0.
    $A Igor feb97; */

gogroup gomakerulers3d0(frame3d frame,golinesettings ls,golinesettings ls1,
            golinesettings ls2,
            int numx,double relx,double relx1,double relx2,double xy,double xz,
            int numy,double rely,double rely1,double rely2,double yx,double yz,
            int numz,double relz,double relz1,double relz2,double zx,double zy);
    /* Postavi ravnila na robove tridimenzionalnega grafa. frame so meje grafa,
    ls,ls1 in ls2 dolocajo lastnosti crt finih, srednjefinih in grobih razdelkov,
    num... dolocajo najmanjse stevilo razdelkov (vseh skupaj), rel... dolocajo
    relativno dolzino razdelkov (v primerjavi s celotnimi intervali iz
    spremenljivke frame - posebej za fino, srednje fino in grobo delitev),
    ostale spremenljivke pa dolocajo lege ravnil (npr. xy=1, xz=0 pomeni, da
    lezi ravnilo za os x na zgornji meji grafa v smeri osi y in na spodnji meji
    grafa v smeri osi z).
    $A Igor <== feb97; */

gogroup gomakerulers3d(frame3d frame,golinesettings ls,golinesettings ls1,
            golinesettings ls2,int num,double rel,double rel1,double rel2);
    /*
    POZOR!  Funkcija je zastarela, kor osnova za postavljanje ravnil na grafe
    naj se v prihodnje uporablja funkcija go3dgridbas()!
     Postavi ravnila na robove tridimenzionalnega grafa. S frame je dolocen
    okvir grafa, v ls, ls1 in ls2 pa so nastavitve za risanje crt pri fini,
    srednji in grobi razdelitvi. num je najmanjse stevilo vseh razdelkov za
    katerokoli os,rel, rel1 in rel2 pa so ustrezne relativne dolzine razdelkov
    glede na dimenzije okvirja.
    $A Igor ==> feb97; */

gogroup go3dgridtextbas(frame3d frame,
  gotextsettings xts,int xdig,int xnum,int xnumtext,double xposy,double xposz,
  gotextsettings yts,int ydig,int ynum,int ynumtext,double yposx,double yposz,
  gotextsettings zts,int zdig,int znum,int znumtext,double zposx,double zposy,
  char putx,char puty,char putz);
    /* Postavi stevilcne oznake (v obliki teksta) k ravnilom grafa v treh
    dimenzijah. Funkcija je predvidena za uporabo skupaj s funkcijo
    go3dgridbas() kot osnova za stevilcne oznake ravnil osi pri dvo- ali
    trodimenzionalnih grafih (vse bolj specificne funkcije za taksne naloge naj
    bi bile izpeljane iz te).
      frame3d je okvir grafa, nato sledijo tri serije argumentov za osi x, y in
    z. Zadnji trije argumenti putx, puty in putz povedo, ali naj se naredijo
    oznakete za os x, y oziroma z (0 pomeni ne, ostale vrednosti pa da).
      Pomen argumentov za os x (za ostale osi so argumenti ekvivalentni):
    xts doloca lastnosti teksta za os x. xnum je najmanjse stevilo vseh
    razdelkov na osi x, kot je bilo doloceno pri klicu funkcije go3dgridbas(),
    xnumtext pa je najmanjse stevilo oznak za os x in mora biti manjse ali
    enako xnum. Ce je manjse, dopustimo, da se stevilcne oznake ne izpisejo na
    pri vseh (tudi najbolj finih) razdelkih, ampak lahko samo pri grobih, ce
    taksnih razdelkov pride pri klicu funkcije gridcalc() ze vec ali enako kot
    xnumtext.
      xposy in xposz dolocata polozaj oznak v smeri y in z, in sicer relativno
    glede na meje okvirja frame. Tako je na primer koordinata y oznak enaka
    ymin+(ymax-ymin)*xposy, kjer je ymin spodnja meja grafa  v smeri y
    (frame->min.y), ymax pa zgornja (frame->max.y).
    $A Igor feb97; */

gogroup gomakerulertext3d0(frame3d frame,gotextsettings tsx,gotextsettings tsy,
            gotextsettings tsz,
            int xdig,int numx,double numxtext,double relx,double xy,double xz,
            int ydig,int numy,double numytext,double rely,double yx,double yz,
            int zdig,int numz,double numztext,double relz,double zx,double zy);
    /* POZOR! To je zastarela funkcija, ki naj se ne bi vec uporabljala.
    namesto nje naj se uporablja funkcija go3dgridtextbas().
    Napise tekst ob ravnilih na robovih tridimenzionalnega grafa. Ta funkcija
    je narejena za uporabo v kombinaciji s funkcijo gomakerulers3d0(), tudi
    pomen nekaterih argumentov je ekvivalenten. xdig, ydig in zdig so stevila
    decimalnih mest pri izpisu stevilk ob ustreznih ravnilih. num...text so
    najmanjsa stevila stevil, izpisanih ob ustreznih ravnilih. */

gogroup gomakerulertext3d(frame3d frame,gotextsettings ts,
            int digits,int num,int numtext,double rel);
    /* Postavi stevilcne oznake v obliki teksta za ravnila trodimenzionalnega
    grafa. V frame so meje okvirja grafa, v ts pa nastavitve za tekst. digits
    je stevilo decimalk, ki se izpisejo v oznakah. num je najmanjse stevilo
    vseh razdelkov ravnil, numtext pa je najmanjse stevilo oznak. pos je
    relstivna pozicija oznak glede na dimenzije okvirja. Funkcija je misljena
    za uporabo skupaj s funkcijo gomakerulers3d(). V tem primeru mora biti
    argument num enak kot pri klicu te funkicje.
    $A Igor feb97 */

gogroup gomakegridbascorner3d0(frame3d frame,golinesettings ls,
            golinesettings ls1,golinesettings ls2,
            int numx,int numy,int numz,
            double xpos,double ypos,double zpos);
    /* Postavi mrezice na tri ravnine okvirja tridimenzionalnega grafa frame.
    ls, ls1 in ls2 dolocajo lastnosti finih, srednje finih in grobih razdelkov
    grafa, numx, numy in numz so najmanjsa stevila finih razdelkov v smereh x,
    y in z, numx, numy in numz pa dolocajo, na katerih ravninah se izrisejo
    mrezice (0 pomeni spodnjo mejo ustreznega intervala v frame, 1 pa
    zgornjo). */

gogroup gomakegridbascorner3d(frame3d frame,golinesettings ls,
            golinesettings ls1,golinesettings ls2,int num);
    /* Podobno kot gomakegridbascorner3d0(), le da so najmanjsa stevila
    razdelkov enaka za vse tri smeri (num) ter so ravnine vnaprej dolocene
    (in sicer ravnine osnovnega kota okvirja frame). */


gogroup gocontourplotsimp(double ff(double x,double y),double min,double max,
            int num,int numx,int numy,frame3d lim,golinesettings ls,int type,
            double z0);




gogroup gosurfaceplotprim(double (*ff) (double,double),int numx,int divx,
                  int numy,int divy,frame3d lim,gofillsettings fs,
                  golinesettings ls,int type,int method);
    /* Sestavi graficni objekt - graf slike funkcije dveh spremenljivk ff().
    Graf je v smeri osi x razdeljen na numx osnovnih delov, od katerih je vsak
    se dodatno razdeljen na divx delov, podobno je z delitvijo v smeri osi y.
    lim doloca meje grafa v obeh smereh.
    fs doloca nacin izrisa ploskev, ls pa nacin izrisa crt.t
    ype doloca tip grafa, method pa aproksimacijsko metodo, ki se uporabli za
    izracun vmesnih vrednosti med osnovnimi delitvami.
    Graf je glede na vrednost argumenta type sestavljen iz:
    (type:)
      0: stirikotnikov iz crt po fini delitvi.
      1: obrobljenih polnih stirikotnikov po fini delitvi.
      2: polnih stirikotnikov po fini delitvi.
      3: polnih stirikotnikov po fini in linij po grobi delitvi.
      4: delno obrobljenih zapolnjenih stirikotnilov po fini delitvi, robovi so
         po grobi delitvi.
      6: zapolnih stirikotnikov na robovih grobe delitve in linij po grobi del.
      7: zapolnjenih stirikotnikov po robovih grobe delitve.
      8: zapolnjenih delno obrobljenih stirikotnikov po robovih grobe delitve.
      10: podobno kot 0, le da se vsak stirikotnik razdeli na stiri trikotnike.
      11: podobno kot 1, le da se vsak stirikotnik razdeli na stiri trikotnike.
      12: podobno kot 2, le da se vsak stirikotnik razdeli na stiri trikotnike.
      13: podobno kot 3, le da se vsak stirikotnik razdeli na stiri trikotnike.
      14: podobno kot 4, le da se vsak stirikotnik razdeli na stiri trikotnike.
      16: podobno kot 6, le da se vsak stirikotnik razdeli na stiri trikotnike.
      17: podobno kot 7, le da se vsak stirikotnik razdeli na stiri trikotnike.
      18: podobno kot 8, le da se vsak stirikotnik razdeli na stiri trikotnike.
      20: podobno kot 0, le da se vsak stirikotnik razdeli na dva trikotnika.
      21: podobno kot 1, le da se vsak stirikotnik razdeli na dva trikotnika.
      22: podobno kot 2, le da se vsak stirikotnik razdeli na dva trikotnika.
      23: podobno kot 3, le da se vsak stirikotnik razdeli na dva trikotnika.
      24: podobno kot 4, le da se vsak stirikotnik razdeli na dva trikotnika.
      26: podobno kot 6, le da se vsak stirikotnik razdeli na dva trikotnika.
      27: podobno kot 7, le da se vsak stirikotnik razdeli na dva trikotnika.
      28: podobno kot 8, le da se vsak stirikotnik razdeli na dva trikotnika.
    Glede na vrednost argumenta metgod se uporabi naslednja metoda za izracun
    vmesnih vrednosti funkcije ff() znotraj grobe delitve:
    (method:)
      0: vse vmesne vrednosti se izracunajo s funkcijo ff().
      1: le ogliscne vrednosti grobe delitve se izracunajo s funkcijo ff(), (
         ostale pa z interpolacijo s funkcijo linintz4p().
      2: Vrednosti na robovih grobe delitve se izracunajo iz funkcije ff(),
         notranje vrednosti pa z interpolacijo s funkcijo linintz4l.
    */



gogroup gosurfaceplotpar(double (*ffx) (double,double),
                  double (*ffy) (double,double),
                  double (*ffz) (double,double),
                  int numx,int divx,int numy,int divy,frame3d lim,
                  gofillsettings fs,golinesettings ls,int type,int method);
    /* Sestavi graficni objekt - graf parametricno podane ploskve.
    Graf je po 1. parametru razdeljen na numx osnovnih delov, od katerih je vsak
    se dodatno razdeljen na divx delov, podobno je z delitvijo po drugem.
    lim doloca meje, v katerih teceta parametra (lim->x za 1. in lim->y za 2.
    parameter).
    fs doloca nacin izrisa ploskev, ls pa nacin izrisa crt.type doloca tip
    grafa, method pa aproksimacijsko metodo, ki se uporabli za izracun vmesnih
    vrednosti med osnovnimi delitvami.
    Graf je glede na vrednost argumenta type sestavljen iz:
    (type:)
      0: stirikotnikov iz crt po fini delitvi.
      1: obrobljenih polnih stirikotnikov po fini delitvi.
      2: polnih stirikotnikov po fini delitvi.
      3: polnih stirikotnikov po fini in linij po grobi delitvi.
      4: delno obrobljenih zapolnjenih stirikotnilov po fini delitvi, robovi so
         po grobi delitvi.
      6: zapolnih stirikotnikov na robovih grobe delitve in linij po grobi del.
      7: zapolnjenih stirikotnikov po robovih grobe delitve.
      8: zapolnjenih delno obrobljenih stirikotnikov po robovih grobe delitve.
      10: podobno kot 0, le da se vsak stirikotnik razdeli na stiri trikotnike.
      11: podobno kot 1, le da se vsak stirikotnik razdeli na stiri trikotnike.
      12: podobno kot 2, le da se vsak stirikotnik razdeli na stiri trikotnike.
      13: podobno kot 3, le da se vsak stirikotnik razdeli na stiri trikotnike.
      14: podobno kot 4, le da se vsak stirikotnik razdeli na stiri trikotnike.
      16: podobno kot 6, le da se vsak stirikotnik razdeli na stiri trikotnike.
      17: podobno kot 7, le da se vsak stirikotnik razdeli na stiri trikotnike.
      18: podobno kot 8, le da se vsak stirikotnik razdeli na stiri trikotnike.
      20: podobno kot 0, le da se vsak stirikotnik razdeli na dva trikotnika.
      21: podobno kot 1, le da se vsak stirikotnik razdeli na dva trikotnika.
      22: podobno kot 2, le da se vsak stirikotnik razdeli na dva trikotnika.
      23: podobno kot 3, le da se vsak stirikotnik razdeli na dva trikotnika.
      24: podobno kot 4, le da se vsak stirikotnik razdeli na dva trikotnika.
      26: podobno kot 6, le da se vsak stirikotnik razdeli na dva trikotnika.
      27: podobno kot 7, le da se vsak stirikotnik razdeli na dva trikotnika.
      28: podobno kot 8, le da se vsak stirikotnik razdeli na dva trikotnika.
    Glede na vrednost argumenta metgod se uporabi naslednja metoda za izracun
    vmesnih vrednosti funkcije ff() znotraj grobe delitve:
    (method:)
      0: vse vmesne vrednosti se izracunajo s funkcijo ff().
      1: le ogliscne vrednosti grobe delitve se izracunajo s funkcijo ff(), (
         ostale pa z interpolacijo s funkcijo linintz4p().
      2: Vrednosti na robovih grobe delitve se izracunajo iz funkcije ff(),
         notranje vrednosti pa z interpolacijo s funkcijo linintz4l.
    */


gogroup gosurfaceplot(double (*ff) (double,double),int numx,int divx,
                  int numy,int divy,frame3d lim,gofillsettings fs,
                  golinesettings ls,int type,int method);
    /* Sestavi graficni objekt - graf slike funkcije dveh spremenljivk ff().
    funkcija uporablja za sestavo grafa funkcijo gosurfaceplotpar(), zato so
    tudi argumenti identicni argumentom te funkcije, razen funkcijskih argumen-
    tov. ff je funkcija, katere graf rsemo. */

gogroup gosurfaceplotspher(double (*ff) (double,double),int numx,int divx,
                  int numy,int divy,frame3d lim,gofillsettings fs,
                  golinesettings ls,int type,int method);
    /* Sestavi graficni objekt - graf ploskve v sfericnih koordinatah.
    funkcija uporablja za sestavo grafa funkcijo gosurfaceplotpar(), zato so
    tudi argumenti identicni argumentom te funkcije, razen funkcijskih argumen-
    tov. ff je funkcija, katere graf rsemo, in podaja odvisnost razdalje tocke
    od koordinatnega izhodisca od azimuta in polarnega kota. */

gogroup gosurfaceplotcyl(double (*ff) (double,double),int numx,int divx,
                  int numy,int divy,frame3d lim,gofillsettings fs,
                  golinesettings ls,int type,int method);
    /* Sestavi graficni objekt - graf ploskve v cilindricnih koordinatah.
    funkcija uporablja za sestavo grafa funkcijo gosurfaceplotpar(), zato so
    tudi argumenti identicni argumentom te funkcije, razen funkcijskih argumen-
    tov. ff je funkcija, katere graf risemo in podaja odvisnost koordinate z
    tocke od projekcije te tocke na ravnino xy in azimuta. */

gogroup gosurfaceplotbottle(double (*ff) (double,double),int numx,int divx,
                  int numy,int divy,frame3d lim,gofillsettings fs,
                  golinesettings ls,int type,int method);
    /* Sestavi graficni objekt - graf steklenicne ploskve v cilind. koordinatah.
    Funkcija uporablja za sestavo grafa funkcijo gosurfaceplotpar(), zato so
    tudi argumenti identicni argumentom te funkcije, razen funkcijskih argumen-
    tov. ff je funkcija, katere graf risemo in podaja odvisnost koordinate r
    tocke od koordinat z in fi v cilindricnem koordinat. sistemu. */


gogroup gocurveplot3dpar(double fx(double),double fy(double),double fz(double),
          int num,int div,double from,double to,golinesettings ls);
    /* Sestavi graficni objekt - graf parametricno podane krivulje v 3
    dimenzijah. fx, fy in fz so funkcijske odvisnosti koordinat od parametra, ki
    tece od from do to. Krivulja je razdeljena na num ravnih delov, od katerih
    je vsak razdeljen na div krajsih crt. V ls so lastnosti cre, ki sestavljajo
    krivuljo. */









#endif    /* (not defined) INCLUDED_sg_graph */
