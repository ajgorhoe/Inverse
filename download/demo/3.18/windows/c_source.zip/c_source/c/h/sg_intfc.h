

/* Code that ensures at most one inclusion: */
#ifndef INCLUDED_sg_intfc
#define INCLUDED_sg_intfc




          /*******************************/
          /*   SGS PLOTTING INTERFACES   */
          /*******************************/




    /* INSTALLING THE ITK DRAWING INTERFACE FOR SGS */

void sg_itk_interface(void);
    /* Installs the ITK drawing interface for SGS, which draws on screen by
    using the Tk canvas widgets.
    $A Igor sep03; */


void sg_tcl_interface(void);
    /* Installs the Tcl drawing interface for SGS, which draws in Tcl files
    format that can be interpreted (displayed) by any Tcl/Tk interpreter, for
    example by the wish shell.
    $A Igor sep03; */




    /* INSTALLING THE PostScript DRAWING INTERFACE FOR SGS */


void sg_ps_interface(void);
    /* Activates the plotting interface for plotting into PostScript files.
    $A Igor sep03; */



int sg_itk_setdirectitk(int direct,void *interp);
    /* Sets either direct access to the ITK interpreter (if direct==1 and
    interp!=NULL) by the ITK plotting interface or indirect access. Teturns
    the current value of the flag that determines what kind of execution is
    in use. The function should normally be called twice - for the first time
    to set the kind of access and for the second time to restore the previous
    state (with the same argument interp). If direct is 1 then interp must be
    the pointer to the ITK interpreter.
    $A Igor sep03; */
















#endif    /* (not defined) INCLUDED_sg_intfc */

