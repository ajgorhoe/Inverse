

/*         RUTINE ZA ZAPIS IN BRANJE GRAFICNIH OBJEKTOV IZ DATOTEK          */




/***********************************************/
/*                                             */
/*            ZAPIS V DATOTEKE:                */
/*                                             */
/***********************************************/



void gofwritegroup(FILE *fp,gogroup gg,int spaces,int plusspaces);
    /* V datoteko fp zapise skupino graficnih objektov gg. spaces je zacetni
    zamik, plusspaces pa dodatni zamik pri prehodih v nov podnivo. */

void gofilewritegroup(char *name,gogroup gg,int spaces,int plusspaces);
    /* V datoteko z imenom name zapise skupino graficnih elementov gg. Ce
    datoteka s tem imenom ze obstaja, se njena vsebina prepise. spaces je
    zacetni zamik, plusspaces pa dodatni zamik pri prehodu v nov podnivo. */




/***********************************************/
/*                                             */
/*            BRANJE IZ DATOTEK:               */
/*                                             */
/***********************************************/




void freadgofile(FILE *fp,long from,long to,stack *groups);
    /* Iz datoteke fp prebere graficno okolje in objekte med vkljucno from in to.
    groups je kazalec na sklad, kamor naj se nalozijo skupine graficnih objektov.
    Ce je *gogroups enak NULL, se prostor za ta sklad alocira znotraj te
    funkcije. */

void filereadgofile(char *name,stack *groups);
     /* Prebere graficno okolje in objekte iz datoteke z imenom name. groups
     je kazalec na sklad, kamor naj se nalozijo skupine graficnih objektov. */




