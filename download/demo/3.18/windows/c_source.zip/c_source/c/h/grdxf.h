

          /*************************************************/
          /*   OSNOVNE FUNKCIJE ZA RISANJE V FORMATU DXF   */
          /*************************************************/



void dxfsetscaling(char scaling);
    /* Doloci skaliranje koordinat pri zapisu graficnih objektov v formatu DXF.
    ce je scaling==0, postane funkcija dxfwindowcoord() za skaliranje koordinat
    kar funkcija dxfnaturalwindowxoord(), ki ohranja naravne koordinate objektov,
    drugace pa to postane funkcija dxfgpwindowxoord(), ki skalira koordinati x
    in y tako, kot se to naredi pri risanju na zaslon, koordinato z pa poskusa
    skalirati na podoben nacin. */

void dxfdrawprimitive(FILE *fp,goprimitive gp);
     /* Izrise graficni primitiv gp. */

void dxfdrawstack(FILE *fp,stack st);
     /* Izrise sklad, na katerega so nalozeni graficni primetivi. */

void dxffiledrawstack(char *name,stack st);
     /* Izrise sklad, na katerega so nalozeni graficni primetivi. */


