


            /******************************************/
            /*                                        */
            /*            POMOZNA  ORODJA             */
            /*           BRANJE IN PISANJE            */
            /*                                        */
            /******************************************/



/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_st
#include <st.h>
#endif
#ifndef INCLUDED_fld
#include <fld.h>
#endif
#ifndef INCLUDED_vec
#include <vec.h>
#endif
#ifndef INCLUDED_mat
#include <mat.h>
#endif
#ifndef INCLUDED_mtypes
#include <mtypes.h>
#endif




void fileargto(FILE *fp,long from,long to,int buflength,
            int *kind,long *pos1,long *pos2,char **str);
    /* Funkcija poisce 1. argument v datoteki fp med from in to (buflength je
    dolzina vmesnega pomnilnika pri iskanju). Argument je lahko stevilo, ime
    spremenljivke ali izraz, ki ga lahko izracunamo s simbolnim kalkulatorjem.
    Funkcija vrne v *kind vrsto argumenta (-1, ce argumenta ne najde, 0, ce je
    argument stevilo, 1, ce je argument ime spremenljivke, in 2, ce je arguent
    izraz),    v *pos1 vrne mesto, kjer se argument zacne (pri imenih
    spremenljivk in izrazov je to mesto, kjer stoji znak '$'), v *pos2 pa
    mesto, kjer se argument konca (za eno vec kot mesto, do koder traja niz,
    ki predstavlja argument).
      Ime spremenljivke mora stati za znakom '$', vmes je lahko presledek ali
    znak '\n' ali '\r' ali '"' ali ',', za imenom pa mora biti presledek ali
    znak '\n' ali '\r' ali '"' ali ','. Ce se ime ne zakluci z enim od teh
    znakov, se vzame, da traja kar do konca obmocja iskanja. Primeri za ime
    spremenljivke: $x $ x $ "x"  $x, $"x",
      Tudi izraz mora stati za znakom '\n' ali '\r' ali '"' ali ','. Biti mora
    v ogladih oklepajih. Primeri: $[x+y] $ [3*(a-2)]  $ [ a + z ]
    $A Igor jun97; */

int freadnumarg(FILE *fp,double *val,long from,long to,ssyst syst,
                long *start,long *next);
    /* Prebere stevilski argument iz datoteke fp med mestoma from in to ter ga
    zapise v *val. V *start zapise zacetek argumenta, v *next pa mesto, kjer
    se zacnejo nadaljnji podatki za prebranim argumentom. Stevilski argument je
    lahko podan neposredno kot stevilo, kot spremenljivka kalkulatorja syst
    (znak $, ki mu sledi ime spremenljivke) ali kot matematicni izrazi, ki se
    ovrednotijo v sistemu syst (znak $, ki mu sledi izraz v zavitih oklepajih).
     Funkcija vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj
    narobe. 
    $A Igor jul99; */

int freadnumargs(FILE *fp,long from,long to,int maxnum,ssyst syst,
                stack *st,long *start,long *next);
    /* Iz datoteke fp prebere stevila med mestoma from in to in jih polozi na
    sklad st kot kazalce na double. Prebere najvec maxnum stevil s funkcijo
    freadnumarg() in vrne stevilo dejansko prebranih stevil. Ce lahko prebere
    kako stevilo, zapise v *start zacetek prvega stevila, v *next pa mesto,
    kjer se zacnejo nadaljnji podatki za zadnjim prebranim stevilom. Stevila so
    lahko podana z vrednostmi, kot spremenljivke kalkulatorja syst (znak $, ki
    mu sledi ime spremenljivke) ali kot matematicni izrazi, ki se ovrednotijo
    v sistemu syst (znak $, ki mu sledi izraz v zavitih oklepajih).
      Ce funkciija ne more prebrati nobenega stevila, se v *start in *next
    zapise -1.
    Argumenta start in next sta lahko tudi NULL.
    $A Igor jul99; */

double file1argvalto(FILE *fp,long from,long to,ssyst syst,int buflength,
              long *pos1,long *pos2);
    /* Vrne vrednost 1. argumenta, ki ga najde v datoteki fp med from in to
    s funkcijo fileargto. syst je sistem za simbolno racunanje, v katerem se
    izracuna izraz, ce je to argument. buflength je dolzina vmesnega
    pomnilnika pri iskanju po datoteki. V *pos1 in *pos2 se zapiseta
    mesto v datoteki, kjer se argument zacne ter za ena vec kot je mesto,
    kjer se argument konca.
      POZOR!
      Ta funkcija naj se ne uporablja vec, namesto nje je treba uporabljati
    funkcijo freadnumarg().
    $A Igor jul99; */

long fileargvalto(FILE *fp,long from,long to,int max,ssyst syst,
       int buflength,stack st);
    /* Na sklad st potisne vse vrednosti argumentov (tipa double), ki jih
    najde v datoteki fp med from in to s funkcijo fileargto. max je najvecje
    stevilo vrednosti, ki jih lahko potisne na sklad (ce je max manj od 1,
    je to stevilo neomejeno). syst je sistem za simbolno racunanje, v katerem
    se ovrednotijo izrazi ali spremenljivke. buflength je dolzina vmesnega
    pomnilnika pri iskanju po datoteki.
    Funkcija vrne stevilo, ki je za ena vecje, kot mesto, do katerega je v
    datoteki zapisan zadnji najdeni argument (ce ne najde nobenega
    argumenta, vrne -1).
      OPOMBA: Prostor za sklad st mora biti ze rezerviran. 
      POZOR!
      Ta funkcija naj se ne uporablja vec, namesto nje je treba uporabljati
    funkcijo freadnumargs().
    $A Igor jul99; */

string freadstring(FILE *fp,char *left,int nleft,char *right,int nright,
                   char *pre,int npre,char *post,int npost,long from,long to,
                   int buflength,long *begin,long *next);
    /* Funkcija prebere prvi niz, ki je v datoteki fp med from in to, in ga
    vrne.
      Nizi se mora zaceti z znakom, ki ni vsebovan v nizu left dolzine nleft.
    Konec niza oznacuje znak, ki je vsebovan v nizu right dolzine nright. V
    pre in post so znaki, ki lahko oklepajo niz na levi oz. desni strani. Ce
    so ti znaki specifirani in se najde znak iz pre, ki se pojavi prej ali
    istocasno kot prvi znak, ki ni vsebovan v nizu left, je konec niza dolocen
    kot en znak pred 1. pojavom znaka iz niza post od zacetka niza naprej.
    npre  in npost oznacujeta stevilo znakov v nizih pre in post.
      Ce se najde znak, ki lahko zacne niz, ne pa znak, ki ga lahko
    konca, niz traja vse do mesta to (vkljucno!). funkcija vrne NULL, ce je
    kaj narobe z vhodnimi parametri, in prazen sklad, ce ni nasla nobenega
    niza.
      V *begin se zapise pozicija 1. znaka prebranega niza, v *next pa
    pozicija takoj za zadnjim znakom tega niza. Ce ne najde niza, zapise v
    *begin in *next -1.
    $A Igor jul99; */

stack freadstrings(FILE *fp,char *left,int nleft,char *right,int nright,
                   char *pre,int npre,char *post,int npost,long from,long to,
                   int maxnum,int buflength,long *begin,long *next);
    /* Funkcija prebere najvec maxnum nizov, ki so v datoteki fp med from in
    to, in jih nalozi na sklad, ki ga vrne. Ce je maxnum<1, je lahko stevilo 
    nizov poljubno.
      Nizi se morajo zaceti z znakom, ki ni vsebovan v nizu left dolzine nleft.
    Konec niza oznacuje znak, ki je vsebovan v nizu right dolzine nright. V
    pre in post so znaki, ki lahko oklepajo niz na levi oz. desni strani. Ce
    so ti znaki specifirani in se najde znak iz pre, ki se pojavi prej ali
    istocasno kot prvi znak, ki ni vsebovan v nizu left, je konec niza dolocen
    kot en znak pred 1. pojavom znaka iz niza post od zacetka niza naprej.
    npre  in npost oznacujeta stevilo znakov v nizih pre in post.
      Ce se najde znak, ki lahko zacne niz, ne pa znak, ki ga lahko
    konca, niz traja vse do mesta to (vkljucno!). funkcija vrne NULL, ce je
    kaj narobe z vhodnimi parametri, in prazen sklad, ce ni nasla nobenega
    niza.
      V *begin se zapise pozicija 1. znaka 1. najdenega niza, v *next pa
    pozicija takoj za zadnjim znakom zadnjega najdenega niza. Ce ne najde
    nobenega niza, zapise v *begin in *next -1.
    $A Igor jun97 jun98 jul99; */

stack freadstringsold0(FILE *fp,char *left,int nleft,char *right,int nright,
                   long from,long to,int maxnum,int buflength,long *first,
                   long *last);
    /* Podobno kot freadstrings, le da niso specifirani znaki, ki lahko
    omejujejo niz (kot npr. dvojni narekoveji) in da *last postane pozicija
    zadnjega znaka zadnjega niza. 
    $A Igor jun98; */

string freadstringinv(FILE *fp,char *left,int nleft,char *right,
               int nright,long from,long to,int buflength,
               long *begin,long *next);
    /* Podobno kot freadstring, le da je znak, ki lahko omejuje niz na levi in
    desni, avtomatsko dvojni narekovaj. 
    $A Igor jul99; */

stack freadstringsinv(FILE *fp,char *left,int nleft,char *right,int nright,
                   long from,long to,int maxnum,int buflength,
                   long *begin,long *next);
    /* Podobno kot freadstrings, le da je znak, ki lahko omejuje niz na levi in
    desni, avtomatsko dvojni narekovaj. 
    $A Igor jun98; */

int freadstrarg(FILE *fp,string *str,long from,long to,stack strst,
      ssyst syst,long *start,long *next);
    /* Iz datoteke fp prebere niz med mestoma from in to in ga zapise v
    *str. Ce lahko prebere niz, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebranim nizom. Niz je
    lahko podan na 2 nacina. Lahko so podane njegove vrednosti, v tem primeru
    se prebere s funkcijo freadstringsinv().
      Niz je lahko podan tudi s specifikacijo elementa nizovne
    spremenljivke na skladu strst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *str (ce se ustrezni element ne najde, se v *str skopira niz NULL).
    Na strst morajo biti nalozeni objekti tipa varholder. Specifikacija se
    prebere s funkcijo freadvarspec(), ki tudi postavi *next.
      Ce niz ni pravilno podan, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe.
    Argumenta start in next sta lahko tudi NULL.
    $A Igor jun99; */

int freadstrargs(FILE *fp,long from,long to,int maxnum,stack strst,
                    ssyst syst,stack *st,long *start,long *next);
    /* Iz datoteke fp prebere nize med mestoma from in to in jih polozi na
    sklad st. Prebere najvec maxnum nizov s funkcijo freadstrarg() in vrne
    stevilo dejansko prebranih nizov. Ce lahko prebere kak niz, zapise v *start
    zacetek prvega niza, v *next pa mesto, kjer se zacnejo nadaljnji podatki za
    zadnjim prebranim nizom. Nizi so lahko podani na 2 nacina. Lahko so podane 
    njihove vsebine,  lahko pa so podani tudi s specifikacijo elementa nizovne
    spremenljivke na skladu strst, ki sledi znaku '#' (vmes so lahko  
    presledki). V tem primeru se vzame za prebrani niz kopija elementa,
    katerega specifikacija je podana (ce se ustrezni element ne najde, se v
    *str skopira niz NULL). Na strst morajo biti nalozeni objekti tipa
    varholder. Specifikacija se prebere s funkcijo freadvarspec(), ki tudi
    postavi *next.
      Ce funkciija ne more prebrati nobenega niza, se v *start in *next zapise
    -1.
    Argumenta start in next sta lahko tudi NULL.
    $A Igor jul99; */

long filebractoselect(FILE *fp,char brac1,char brac2,long from,
                      long to, int buflength,long *pos1,long *pos2);
    /* Nadomestek za filebracto(). Namesto lege 1. oklepaja v datoteki fp med
    from in to vrne lego 1. oklepaja, ki ne takoj sledi znaku '$'.
    $A Igor jul97; */

int freadvarind(FILE *fp,long from, long to,ssyst syst,stack *ind,
    long *start,long *newdata);
    /* Prebere indekse (ce so podani) spremenljivke iz datoteke fp med
    mestoma from in to. Indekse nalozi na sklad *ind. syst je sistem za
    ovrednotenje izrazov, v katerem se ovrednotijo indeksi, ce so podani kot
    izrazi. Funkcija vrne 0, ce ne najde indeksov, drugace vrne 1. Ce niso
    podani indeksi, tudi postavi sklad *ind na NULL.
    V *start se zapise mesto v datoteki, kjer se indeksi zacnejo, v *newdata
    pa za eno vec kot je mesto zadnjega znaka, ki pripada indeksom.
    $A Igor maj98; */

long freadvarindsimp(FILE *fp,long from, long to,ssyst syst,stack *ind);
    /* Prebere indekse spremenljivke (ce so podani) iz datoteke fp med
    mestoma from in to s funkcijo freadvarind(). Razlika je v tem, da ta
    funkcija vrne 0, ce ne najde imena spremenljivke, drugace pa vrne mesto
    v datoteki takoj za mestom, kjer se koncajo indeksi.
    $A Igor maj98; */

int freadvarspec(FILE *fp,long from, long to,ssyst syst,
                        char **name,stack *ind,long *start,long *newdata);
    /* Prebere ime spremenljivke in indekse (ce so podani) iz datoteke fp med
    mestoma from in to. Ime vrne v *name, indekse pa nalozi na sklad *ind.
    syst je sistem za ovrednotenje izrazov, v katerem se ovrednotijo indeksi,
    ce so podani kot izrazi. Funkcija vrne 0, ce ne najde imena spremenljivke,
    drugace vrne 1. Ce niso podani indeksi, postavi sklad *ind na NULL.
    V *start se zapise mesto v datoteki, kjer se specifikacija spremenljivke
    zacne, v *newdata pa za eno vec kot je mesto zadnjega znaka, ki pripada
    specifikaciji.
    $A Igor feb98; */

long freadvarspecsimp(FILE *fp,long from, long to,ssyst syst,
                        char **name,stack *ind);
    /* Prebere ime spremenljivke in indekse (ce so podani) iz datoteke fp med
    mestoma from in to s funkcijo freadvarspec(). Razlika je v tem, da ta
    funkcija vrne 0, ce ne najde imena spremenljivke, drugace pa vrne mesto
    v datoteki takoj za mestom, kjer se konca specifikacija spremenljivke.
    $A Igor feb98; */

int freadvarspecarg(FILE *fp,long from, long to,stack strst,ssyst syst,
                        char **name,stack *ind,long *start,long *newdata);
    /* Prebere ime spremenljivke in indekse (ce so podani) iz datoteke fp med
    mestoma from in to. Ime vrne v *name, indekse pa nalozi na sklad *ind.
    syst je sistem za ovrednotenje izrazov, v katerem se ovrednotijo indeksi,
    ce so podani kot izrazi. Funkcija vrne 0, ce ne najde imena spremenljivke,
    drugace vrne 1. Ce niso podani indeksi, postavi sklad *ind na NULL.
    V *start se zapise mesto v datoteki, kjer se specifikacija spremenljivke
    zacne, v *newdata pa za eno vec kot je mesto zadnjega znaka, ki pripada
    specifikaciji.
     Ime spremenljivke se prebere kot nizovni argument, kar pomeni, da se lahko
    namesto eksplicitne navedbe imena sklicujemo na niz iz sistema nizovnih
    spremenljivk, ki so na skladu strst nalozene kot objekti tipa varholder. V
    tem primeru mora specifikacija nizovnega elementa slediti znaku '#' in mora
    OBVEZNO vsebovati indeksno specifikacijo v oglatih oklepajih, ceprav je ta
    prazna.
    $A Igor jul99; */

long freadvarspecargsimp(FILE *fp,long from, long to,stack strst,ssyst syst,
                        char **name,stack *ind);
    /* Prebere ime spremenljivke in indekse (ce so podani) iz datoteke fp med
    mestoma from in to s funkcijo freadvarspecarg(). Razlika je v tem, da ta
    funkcija vrne 0, ce ne najde imena spremenljivke, drugace pa vrne mesto
    v datoteki takoj za mestom, kjer se konca specifikacija spremenljivke.
    $A Igor jul99; */

void freadvectorinv(FILE *fp,vector *vec,char brac1,char brac2,long from,
       long to,ssyst syst,long *first,long *next);
    /* Prebere vektor vec v datoteki fp. Podatki o vektorju so v datoteki
    med mestoma from in to. Komponente so nastete v oklepajih brac1-brac2 in
    sicer na dva mozna nacina:
      1. Znotraj zunanjega oklepaja so notranji, v katerih sta po dve
    stevilki, 1. pove, za katero komponento gre, 2. pa je vrednost te
    komponente (stevili sta lahko med sabo loceni s katerimkoli znakom, ki ne
    more pripadati stevilu).
      2. Znotraj zunanjega oklepaja so po vrsti nastete komponente.
      Dimenzija vektorja je lahko podana pred 1. znakom brac1 med from in to.
    Lahko je podana tudi samo dimenzija brez komponent.
      Primeri:
    3 { {1 3.12} {2 5.3} {3 0.9999} }
    3 { 3.12 5.3 0.9999 }
    Ce ni podana dimenzija, se predpostavi trenutna dimenzija vektorja. Ce je
    dimenzija podana in se ne ujema s trenutno dimenzijo, se zbrise vsebina
    vektorja, le-ta pa se tvori na novo. Ce je podana kaksna komponenta z
    zaporedno stevilko vecjo od dimenzije, se ignorira. Ce je dimenzija 0, se
    le *vec zbrise in postavi na NULL. Pri branju so lahko vse stevilcne
    vrednosti nadomescene z matematicnimi izrazi oblike ${exp} (brez presledka
    med '$' in '{') ali imeni spremenljivk oblike $ var (z enim presledkom med
    '$' in imenom). V tem primeru se izrazi in spremenljivke ovrednotijo v
    sistemu syst.
      Funkcija v *first zapise pozicijo prvega znaka zapisa vektorja, v *next
    pa pozicijo 1. znaka po koncu zapisa vektorja. First in next sta lahko
    enaka NULL, v tem primeru se ne zapise pozicija zacetka in konca zapisa.
    $A Igor <== jul97 mar99; */

void freadmatrixinv(FILE *fp,matrix *mat,char brac1,char brac2,
       char separator,long from, long to,ssyst syst,long *first,long *next);
    /*     Iz datoteke fp se prebere matrika *mat med mestoma from in to v tej
    datoteki. Komponente matrike so podane med oklepajema brac1 in brac2
    in sicer na tri mozne nacine:
      1. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da sta
    1. dve stevilki v vsakem oklepaju stevilki vrstice in stolpca, tema sledi
    dvopicje, tretja stevilka pa je vrednost ustrezne komponente.
      2. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da je 1.
    stevilka v vsakem oklepaju stevilka vrstice, tej sledi dvopicje, nato pa
    so po vrsti nastete vse komponente matrike v tej vrstici.
      3. Lahko so podane po vrsti (po vrsticah) v osnovnem oklepaju
    brac1-brac2. V tem primeru znotraj osnovnega oklepaja ni potreben se
    notranji oklepaj.
    Dimenziji matrike sta podani pred osnovnim oklepajem brac1-brac2. Lahko
    sta podani samo dimenziji ali samo komponente. Ce je podana samo ena
    dimenzija, se privzame, da je druga enaka tej.
      Primeri:
    2 2 { {1 1: 1.1} {1 2: 1.3} {2 1: 0.5} {2 2: 0.6} }
    2 2 { {1: 1.1 1.3} {2: 0.5 0.6} }
    2 2 { 1.1  1.3  0.5  0.6 }
    Ce ni podana dimenzija, se predpostavi trenutna dimenzija matrike. Ce je
    dimenzija podana in se ne ujema s trenutno dimenzijo, se zbrise vsebina
    matrike, le-ta pa se tvori na novo. Ce je podana kaksna komponenta z
    zaporedno stevilko vecjo od dimenzije, se ignorira. Ce je dimenzija 0,
    se *mat zbrise in postavi na NULL.
    Pri branju so lahko vse stevilcne vrednosti nadomescene z matematicnimi
    izrazi oblike ${exp} (brez presledka med '$' in '{') ali imeni spremenljivk
    oblike $ var (z enim presledkom med '$' in imenom). V tem primeru se
    izrazi in spremenljivke ovrednotijo v sistemu syst.
      Funkcija v *first zapise pozicijo prvega znaka zapisa vektorja, v *next
    pa pozicijo 1. znaka po koncu zapisa vektorja. First in next sta lahko
    enaka NULL, v tem primeru se ne zapise pozicija zacetka in konca zapisa.
    $A Igor jul97 mar99; */

void freadfieldinv(FILE *fp,field *fld,char brac1,char brac2,
       char separator,long from, long to,ssyst syst,long *first,long *next);
    /*     Iz datoteke fp se prebere polje *fld med mestoma from in to v tej
    datoteki. Komponente polja so podane med oklepajema brac1 in brac2
    in sicer na tri mozne nacine:
      1. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da sta
    1. dve stevilki v vsakem oklepaju stevilki vrstice in stolpca, tema sledi
    dvopicje, tretja stevilka pa je vrednost ustrezne komponente.
      2. Lahko so podane v vec notranjih oklepajih brac1-brac2 tako, da je 1.
    stevilka v vsakem oklepaju stevilka vrstice, tej sledi dvopicje, nato pa
    so po vrsti nastete vse komponente matrike v tej vrstici.
      3. Lahko so podane po vrsti (po vrsticah) v osnovnem oklepaju
    brac1-brac2. V tem primeru znotraj osnovnega oklepaja ni potreben se
    notranji oklepaj.
    Dimenziji polja sta podani pred osnovnim oklepajem brac1-brac2. Lahko
    sta podani samo dimenziji ali samo komponente. Ce je podana samo ena
    dimenzija, se privzame, da je druga enaka tej.
      Primeri:
    2 2 { {1 1: 1.1} {1 2: 1.3} {2 1: 0.5} {2 2: 0.6} }
    2 2 { {1: 1.1 1.3} {2: 0.5 0.6} }
    2 2 { 1.1  1.3  0.5  0.6 }
    Ce ni podana dimenzija, se predpostavi trenutna dimenzija polja. Ce je
    dimenzija podana in se ne ujema s trenutno dimenzijo, se zbrise vsebina
    polja, le-ta pa se tvori na novo. Ce je podana kaksna komponenta z
    zaporedno stevilko vecjo od dimenzije, se ignorira. Ce je dimenzija 0,
    se *fld zbrise in postavi na NULL.
    Pri branju so lahko vse stevilcne vrednosti nadomescene z matematicnimi
    izrazi oblike ${exp} (brez presledka med '$' in '{') ali imeni spremenljivk
    oblike $ var (z enim presledkom med '$' in imenom). V tem primeru se
    izrazi in spremenljivke ovrednotijo v sistemu syst.
      Funkcija v *first zapise pozicijo prvega znaka zapisa polja, v *next
    pa pozicijo 1. znaka po koncu zapisa polja. First in next sta lahko
    enaka NULL, v tem primeru se ne zapise pozicija zacetka in konca zapisa.
    $A Igor jul97 mar99; Damjan jul98*/

void freadcounterinv(FILE *fp,counter *count,long from,long to,
            ssyst syst,long *start,long *next);


int freadcountarg(FILE *fp,counter *count,long from, long to,stack countst,
                 stack strst,ssyst syst,long *start,long *next);
    /* Iz datoteke fp prebere stevec med mestoma from in to in ga zapise v
    *count. Ce lahko prebere stevec, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebranim stevcem. Stevec je
    lahko podan na 2 nacina. Lahko je podana njegova vrednost, v tem primeru
    se prebere s funkcijo freadcounterinv(). Kalkulator syst se v tem primeru
    uporabi za ovrednotenje matematicnih izrazov, ki lahko nastopajo namesto
    stevil (glej specifikacijo funkcije freadcounterinv()).
      Stevec je lahko podan tudi s specifikacijo elementa stevcne
    spremenljivke na skladu countst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *count (ce se ustrezni element ne najde, se v *count skopira stevec NULL).
    Ime stevcne spremenljivke je lahko nadalje podano kot element nizovne
    spremenljivke, katerega specifikacija sledi znaku '#'. strst je sklad, na
    katerem morajo biti nalozene nizovne spremenljivke kot objekti tipa
    varholder. Na countst morajo biti nalozene stevcne spremenljivke kot
    objekti tipa varholder. Specifikacija se prebere s funkcijo
    freadvarspecrg(), ki tudi postavi *next.	
      Ce stevec ni pravilno podan, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je format ustrezen, a se stevcu *count priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce se na skladu countst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul99; */

void freadscalarinv(FILE *fp,scalar *scal,long from,long to,ssyst syst,
      long *start,long *next);


int freadscalarg(FILE *fp,scalar *scal,long from, long to,stack scalst,
                 stack strst,ssyst syst,long *start,long *next);
    /* Iz datoteke fp prebere skalar med mestoma from in to in ga zapise v
    *scal. Ce lahko prebere skalar, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebranim skalarjem. Skalar je
    lahko podan na 2 nacina. Lahko je podana njegova vrednost, v tem primeru
    se prebere s funkcijo freadscalarinv(). Kalkulator syst se v tem primeru
    uporabi za ovrednotenje matematicnih izrazov, ki lahko nastopajo namesto
    stevil (glej specifikacijo funkcije freadscalarinv()).
      Skalar je lahko podan tudi s specifikacijo elementa skalarne
    spremenljivke na skladu scalst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *scal (ce se ustrezni element ne najde, se v *scal skopira skalar NULL).
    Ime skalarne spremenljivke je lahko nadalje podano kot element nizovne
    spremenljivke, katerega specifikacija sledi znaku '#'. strst je sklad, na
    katerem morajo biti nalozene nizovne spremenljivke kot objekti tipa
    varholder. Na scalst morajo biti nalozene skalarne spremenljivke kot
    objekti tipa varholder. Specifikacija se prebere s funkcijo
    freadvarspecrg(), ki tudi postavi *next.	
      Ce skalar ni pravilno podan, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je format ustrezen, a se skalarju *scal priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce se na skladu scalst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul99; */

int freadvecarg(FILE *fp,vector *vec,char brac1,char brac2,long from,
       long to,stack vecst,stack strst,ssyst syst,long *start,long *next);
    /* Iz datoteke fp prebere vektor med mestoma from in to in ga zapise v
    *vec. Ce lahko prebere vektor, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebranim vektorjem. Vektor je
    lahko podan na 2 nacina. Lahko so podane njegove vrednosti, v tem primeru
    se prebere s funkcijo freadvectorinv(). Kalkulator syst se v tem primeru
    uporabi za ovrednotenje matematicnih izrazov, ki lahko nastopajo namesto
    stevil (glej specifikacijo funkcije freadvectorinv()). brac1 in brac2 sta
    oklepaj in zaklepaj, ki se uporabljata pri navajanju komponent.
      Vektor je lahko podan tudi s specifikacijo elementa vektorske
    spremenljivke na skladu vecst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *vec (ce se ustrezni element ne najde, se v *vec skopira vektor NULL).
    Ime vektorske spremenljivke je lahko nadalje podano kot element nizovne
    spremenljivke, katerega specifikacija sledi znaku '#'. strst je sklad, na
    katerem morajo biti nalozene nizovne spremenljivke kot objekti tipa
    varholder. Na vecst morajo biti nalozene vektorske spremenljivke kot
    objekti tipa varholder. Specifikacija se prebere s funkcijo
    freadvarspecrg(), ki tudi postavi *next.	
      Ce vektor ni pravilno podan, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je format ustrezen, a se vektorju *vec priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce je vektor podan z zavitiim
    oklepajem, kjer zaklepaj takoj sledi oklepaju, ali ce se na skladu vecst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul98 mar99 jul99; */

int freadvecargbrac(FILE *fp,vector *vec,char brac1,char brac2,long from,
       long to,stack vecst,stack strst,ssyst syst,long *start,long *next);
    /* Naredi isto kot freadvecarg, s to razliko, da mora biti vektor podan v
    zavitih oklepajih.
    $A Igor mar99 jul99; */

int freadmatarg(FILE *fp,matrix *mat,char brac1,char brac2,char separator,
       long from,long to,stack matst,stack strst,ssyst syst,long *start,long *next);
    /* Iz datoteke fp prebere matriko med mestoma from in to in jo zapise v
    *mat. Ce lahko prebere matriko, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebrano matriko. Matrika je
    lahko podana na 2 nacina. Lahko so podane njene vrednosti, v tem primeru
    se prebere s funkcijo freadmatrixinv(). Kalkulator syst se v tem primeru
    uporabi za ovrednotenje matematicnih izrazov, ki lahko nastopajo namesto
    stevil (glej specifikacijo funkcije freadmatrixinv()). brac1 in brac2 sta
    oklepaj in zaklepaj, ki se uporabljata pri navajanju komponent.
      Matrika je lahko podana tudi s specifikacijo elementa matricne
    spremenljivke na skladu matst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *mat (ce se ustrezni element ne najde, se v *mat skopira matriko NULL).
    Ime matricne spremenljivke je lahko nadalje podano kot element nizovne
    spremenljivke, katerega specifikacija sledi znaku '#'. strst je sklad, na
    katerem morajo biti nalozene nizovne spremenljivke kot objekti tipa
    varholder. Na matst morajo biti nalozene matricne spremenljivke kot objekti
    tipa varholder. Specifikacija se prebere s funkcijo freadvarspecrg(), ki
    tudi postavi *next.	
      Ce matrika ni pravilno podana, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je format ustrezen, a se matriki *mat priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce je matrika podana z zavitiim
    oklepajem, kjer zaklepaj takoj sledi oklepaju, ali ce se na skladu matst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul98 mar99; */

int freadmatargbrac(FILE *fp,matrix *mat,char brac1,char brac2,char separator,
       long from,long to,stack matst,stack strst,ssyst syst,long *start,long *next);
    /* Naredi isto kot freadmatarg, s to razliko, da mora biti matrika podana v
    zavitih oklepajih.
    $A Igor mar99; */

int freadfldarg(FILE *fp,field *fld,char brac1,char brac2,char separator,
       long from,long to,stack fldst,stack strst,ssyst syst,long *start,
       long *next);
    /* Iz datoteke fp prebere polje med mestoma from in to in ga zapise v
    *fld. Ce lahko prebere polje, zapise v *start zacetek zapisa, v *next pa
    mesto, kjer se zacnejo nadaljnji podatki za prebrano polje. Polje je
    lahko podano na 2 nacina. Lahko so podane njegove vrednosti, v tem primeru
    se prebere s funkcijo freadfieldinv(). Kalkulator syst se v tem primeru
    uporabi za ovrednotenje fldefldicnih izrazov, ki lahko nastopajo namesto stevil (glej
    specifikacijo funkcije freadfieldinv()). brac1 in brac2 sta oklepaj in
    zaklepaj, ki se uporabljata pri navajanju komponent.
      Polje je lahko podan tudi s specifikacijo elementa poljske
    spremenljivke na skladu fldst, ki sledi znaku '#' (vmes so lahko
    presledki). V tem primeru se element, ki je podan s specifikacijo, skopira
    v *fld (ce se ustrezni element ne najde, se v *fld skopira polje NULL).
    Ime poljske spremenljivke je lahko nadalje podano kot element nizovne
    spremenljivke, katerega specifikacija sledi znaku '#'. strst je sklad, na
    katerem morajo biti nalozene nizovne spremenljivke kot objekti tipa
    varholder. Na fldst morajo biti nalozene poljske spremenljivke kot objekti
    tipa varholder. Specifikacija se prebere s funkcijo freadvarspecrg(), ki
    tudi postavi *next.	
      Ce polje ni pravilno podana, se v *start in *next zapise -1. Funkcija
    vrne 0, ce je vse v redu, ali negativno vrednost, ce je kaj narobe. Tudi,
    ce je forfld ustrezen, a se polju *fld priredi NULL, vrne funkcija
    negativno vrednost. To je npr. v primeru, ce je polje podano z zavitiim
    oklepajem, kjer zaklepaj takoj sledi oklepaju, ali ce se na skladu fldst
    ne najde element, ki ga doloca specifikacija.
    $A Igor jul98 mar99; */

int freadfldargbrac(FILE *fp,field *fld,char brac1,char brac2,char separator,
       long from,long to,stack fldst,stack strst,ssyst syst,long *start,
       long *next);
    /* Naredi isto kot freadfldarg, s to razliko, da mora biti polje podano v
    zavitih oklepajih.
    $A Igor mar99; */






