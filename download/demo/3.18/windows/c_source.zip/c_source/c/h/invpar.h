


                    /***********************/
                    /*                     */
                    /*  PARALELNI VMESNIK  */
                    /*                     */
                    /***********************/




void invinitpar(int *argc, char** argv[]);

int invmyparid(void);

void invclosepar(void);

void invsendkillall(stack *pointprocst,int *pointnumprocs,FILE *outfile);

void invwaitprocdeaths(stack *pointprocst,int *pointnumprocs,FILE *outfile);

void invslaveloop(void);
    /* Zanka, ki jo izvaja podrejeni program, ko caka na navodila nadrejenega
    programa in jih izpolnjuje
    $A Igor sep97; */

void partab2d(int which1, double from1, double to1, int num1,
           int which2, double from2, double to2, int num2,
           int pchi2, int pmeas);
    /* Naredi dvodimenzionalno tabelo rezultatov direktnih analiz. which1 in
    which2 sta zaporedni stevilki parametrov, ki se spreminjata (ostali
    parametri se vzamejo iz com.parammom). 1. parameter se spreminja od from1
    do to1, pri cemer se tabelira num1 tock (vseh skupaj), drugi paramer pa od
    from2 do to2, tabelira se v num2 tockah.
    pchi2 pove, ali naj se izpisejo vrednosti hi-kvadrat, pmeas pa, ali naj se
    izpisejo simulirane meritve.
      Vektor com.parammom ostane po izvedbi funkcije nespremenjen.
      Analize za izracun tabele se pozenejo vzporedno.
    $A Igor okt97; */

void parlinetabexp(struct _vector from, struct _vector to, int num, double k, int pchi2, int pmeas);
    /* V datoteko inv_outfile() zapise rezultate serije numericnih analiz.
    Tocke vhodnih parametrov analiz lezijo na daljici med
    vektorjema from in to tako, da sta dva zampredna intervala v razmerju k
    (i[n+1]/i[n]=k) .
      from - zacetni vektor parametrov
      to - koncni vektor parametrov
      num - stevilo izvedenih analiz (vkljucno s krajiscema)
      pchi pove, ali naj se izpisejo hi-kvadrat.
      pmeas pove, ali naj se izpisejo simulirane meritve.
    Vhodni podatki morajo biti v skladu z globalnimi spremenljivkami.
    To pomeni, da mora biti dimenzija vektorjev from in to enaka
    com.numparam.
    Tabela se izracuna z vzporednim poganjanjem analiz.
    $A Igor okt97; */






void installparallelinterface(ficom fcom);
    /* Funkcija, ki instalira paralelni vmesnik na datotecni interpreter
    fcom.
    $A Igor sep01; */


