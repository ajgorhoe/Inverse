

          /*************************************************/
          /*   OSNOVNE FUNKCIJE ZA RISANJE V FORMATU Tcl   */
          /*************************************************/





void tclsetwindowsize(int width,int height);
    /* Postavi sirino tcl-ovega okna, v katerem se izrise graf iz tcl-ove
    datoteke, na width, in visino na height. Ce je eden ali drugi 0, se
    ohranita dimenziji, ki sta trenutno nastavljeni.
    $A Igor maj01; */

void tclsetepsoutfile(char *name);
    /* Nastavi ime datoteke, v katero bo lupina wish ob interpretaciji datotek
    generiranih s pomocjo tega modula zapisala slike v formatu eps, na name. Ce
    je name NULL, se v datoteke v formatu Tcl ne bo izpisalo navodilo za izpis
    v formatu eps. Ce je tcloldwish razlicno od 0, bi moral biti name pri klicu
    te funkcije enak NULL. name se skopira s stringcopy() v lokalno
    spremenljivko tclepsoutfile. */

void tclsetoldwish(int oldwish);
  /* Ce je oldwish 0, se datoteke zapisujejo v formatu, ki ga zna prebrati
  wish verzije 8.0 ali poznejse. */

void tclinstallfont(int num,char *font,char bold,char italic);
    /* Instalira font z zaporedno stevilko num v sistem fontov, ki se uporablja
    pri risanju v formatu tcl. font je ime (vrsta) fonta, bold in italic pa
    povesta, ali je font krebko tiskan oz. ali je nagnjen. */

void tclinstallfontstr(int num,char *pre,char *post);
    /* Instalira font z zaporedno stevilko num v sistem fontov, ki se uporablja
    pri risanju v formatu tcl. Od funkcije tclinstallfont se razlikuje po tem,
    da se zadnji del imena fonta poda direktno in ne z dvema celima argumentoma,
    ki povesta, ali je font krepko tiskan oz. nagnjen. funkcija je bolj primerna
    za instaliranje fontov, ce uporabljamo stari wish; v tem primeru je treba
    postaviti lokalno spremenljivko tcloldwish na 1 s klicem tclsetoldwish(1).
    Pri instalaciji fonta mora biti potem pre 1. del imena (kot v X) do nicle,
    ki pomeni, da ima font prilagodljivo velikost, post pa 2. del od te nicle
    naprej. Pri nastavitvi imena fonta se najprej zapise 1. del fonta, nato
    velikost in nato 2. del brez vmesnih presledkov. */

void tclsetscaling(char scaling);
    /* Doloci skaliranje koordinat pri zapisu graficnih objektov v formatu Tcl.
    ce je scaling==0, postane funkcija tclwindowcoord() za skaliranje koordinat
    kar funkcija tclnaturalwindowxoord(), ki ohranja naravne koordinate objektov,
    drugace pa to postane funkcija tclgpwindowxoord(), ki skalira koordinati x
    in y tako, kot se to naredi pri risanju na zaslon, koordinato z pa poskusa
    skalirati na podoben nacin. */

void tcldrawprimitive(FILE *fp,goprimitive gp);
     /* Izrise graficni primitiv gp. */

void tcldrawstack(FILE *fp,stack st);
     /* Izrise sklad, na katerega so nalozeni graficni primetivi. */

void tclfiledrawstack(char *name,stack st);
     /* Izrise sklad, na katerega so nalozeni graficni primetivi. */


