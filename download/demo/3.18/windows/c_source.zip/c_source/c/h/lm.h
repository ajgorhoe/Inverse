/* LEVENBERG - MARQUARDTOVA METODA */


double levmarqder(_vector a,int whichmeas,int whichpar, 
                  void lmfunc(_vector,_vector *));
        /* Funkcija, ki numericno izracuna odvode za Levenberg-Marquardtovo
        metodo. */


double levmarqdconsth(_vector a,int whichmeas,int whichpar, 
                  void lmfunc(_vector,_vector *));
        /* Funkcija, ki numericno izracuna odvode za Levenberg-Marquardtovo
        metodo. */


void levmarqconsth(_vector meas, _vector sigma, _vector * a, 
             _vector *h, _vector * meascalc,
             double * chi2, _matrix *covar,
             void func(_vector, _vector *), 
             double tol,
             int *it, int maxit, int connection(int), FILE *fp);

void levmarq1(_vector meas, _vector sigma, _vector * a, 
             _vector *h, _vector * meascalc,
             double * chi2, _matrix *covar,
             void func(_vector, _vector *), 
             double dfunc(_vector, int, int,void basfunc(_vector,_vector *) ), 
             double tol,
             int *it, int maxit, int connection(int), FILE *fp);
