






                    /*******************************/
                    /*                             */
                    /*  FUNKCIJE ZA ANALIZO IN ZA  */
                    /*  OPTIMIZACIJSKE ALGORITME   */
                    /*                             */
                    /*******************************/

 
void invanalyse(void);
    /* Izvede direktno numericno analizo z vhodnimi parametri com.parammom ter
    zapise rezultate analize v vektor com.measmom, ki mora biti ze alociran in
    mora biti primerne dimenzije. Analiza se izvede z interpretacijo datoteke
    *fp od mesta from do mesta to. Ce je fp==NULL, se interpretira datoteka
    com.fcom->fp.
    $A Igor <== jun97; */


void installoptimisationutilities(ficom fcom);
    /* Funkcija, ki instalira optimizacijske algoritme in ustrezne
    pripomocke na datotecni interpreter fcom.
    $A Igor sep01; */





