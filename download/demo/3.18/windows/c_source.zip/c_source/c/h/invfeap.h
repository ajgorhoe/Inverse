


                /*****************************/
                /*                           */
                /*    INTERFACE WITH FEAP    */
                /*                           */
                /*****************************/



#ifndef INCLUDED_fem
  #include <fem.h>
#endif


#ifdef FEAPINT
extern void feapanalyse_(int *numparam,double *param,
              int *numres,double *res,int *numgradres,double *gradres);
    /* Runs the FEAP analysis. numparam is the number of parameters, param is
    the parameter array, numres is the number of expected results, res is array
    in which results will be stored by FEAP, numgradres is the number of
    gradients of the results and gradres is the array where gradients will be
    stored by FEAP.
      Number corresponding to each array must indicate how much space is
    actually allocated for a given array (FEAP should check this number when
    reading parameters or writing results). Array elements are counted from 0.
    numgradres indicates the amount of allocated space in gradres, it does not
    have anything to do with the dimensions of the field. */

#else
void feapanalyse_(int *numparam,double *param,
              int *numres,double *res,int *numgradres,double *gradres);
    /* Dummy FEAP analysis, intended for reporting an error when called but
    FEAP is not available. */
#endif




        /* UTILITIES FOR THE PROJECT: */


    /* DEFINITION OF TRANSFORMS */

/* Function that define into what the centered circle of the radius cell_rinit
is transformed: */
double (*rpfunc) (double fi,vector param);


void prepcelldata(femesh fmcell,double rinit);
    /* Prepares the data for transforming cell mesh by transformations that
    produce elliptic inclusions or holes or other shapes of inclusions that
    are defived from an initial round shape.
    $A Igor feb04; */

double rpellipse(double fi,vector param);
    /* Rerutns radius of the border of a hole or inclusion at polar angle fi
    and parameters param such that the shape of the border is elliptic.
      The first parameter is angle between the x-axis and the first
    half-axis of the ellipse, the second parameter is the relative size of the
    first half-axis with respect to a half of the cell size, and the third
    parameter is the relative size of the second half-axis of the ellipse.
    $A Igor oct03; */

void transfcellradstrech(vector orig,vector transf,vector param);
    /* Atapts function transform10 for taking separate vector of original and
    transformed co-ordinates. */


    /* INSTALLATION AND INITIALIZATION OF THE INTERFACE: */

void installfeapinterface(void);
    /* Installs the FEAP interface function to interpreter and calculator.
    $A Igor feb03; */


