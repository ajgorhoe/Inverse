
        /* BASIC VECTOR OPERATIONS */



/* Direktive, ki omogocajo v kljucitev lint.h v headerjih (npr. fint.h), ne da
bi bilo treba skrbeti za to, ali ni pri vkljucitvi teh headerjev ze bil
kakorkoli vkljucen lint.h, ker se v lint.h to eksplicitno preverja preko
definicije makra
INCLUDED_lint : */

#ifndef INCLUDED_vec
#define INCLUDED_vec

#ifndef INCLUDED_stdio  /* for definition of type FILE */
  #include <stdio.h>
  #define INCLUDED_stdio
#endif

/* Definition of the vector type:
  IMPORTANT:
  Elements are countes from 1, not from 0 (the pointer to a table is decremented
by 1 when a vector is created)! e.g. if we declared "vector v;" then v->v[1],
v->v[2], ... v->v[v->d] are legal references to vector components.  */

typedef struct _vector {
    int d;      /* dimension (num. of comp.) */
    double * v; /* table of elements, STARTS WITH 1! */
} *vector;


/* Definition of scalar and counter types (used in the system of
variables): */
typedef double _scalar;
typedef _scalar *scalar;

typedef long _counter;
typedef _counter *counter;


/* MACROS FOR CONVERTING OLD NAMES: */

#define copycounter0 copycounter
#define copyscalar0 copyscalar

#define copyvector0 copyvector



  /* COUNTERS: */

counter getcounter(void);
    /* Creates a new counter and returns its pointer.
    $A Igor feb05; */

void dispcounter(counter *addr);
    /* If applicable, deallocates the counter whose address is addr and sets
    *addr to NULL.
    $A Igor feb05; */

void fprintcounter(FILE *fp,counter s);
    /* Prints the counter s to the file fp, with a newline printed after the
    value.
    $A Igor mar05; */

void printcounter(counter s);
    /* The same as fprintcounter, but prints to the standard output rather than
    to a specified file.
    $A Igor mar05; */

void fprintcounterlist(FILE *fp,counter s);
    /* Prints a counter s to the file fp. Only pure value is printed: neither a
    newline nor a space is printed after the value.
    $A Igor mar05; */

void printcounterlist(counter s);
    /* The same as fprintstalarlist, but prints to the standard output rather
    than to a specified file.
    $A Igor mar05; */

void resizecounter(counter *addr);
    /* If counter pointed to by addr is NULL then the counter is allocated.
      Remark: this is actually not resizing, but the name is taken in
    analogy to containter structures.
    $A Igor mar04; */

counter copycounter(counter v1,counter *v2);
    /* Returns a coopy of counter v1. If v2!=NULL then v1 is copied to v2
    and v2 returned.
    $A Igor nov98; */


  /* SCALARS: */

scalar getscalar(void);
    /* Creates a new scalar and returns its pointer.
    $A Igor feb05; */

void dispscalar(scalar *addr);
    /* If applicable, deallocates a scalar whose address is addr and sets *addr
    to NULL.
    $A Igor feb05; */

void fprintscalar(FILE *fp,scalar s);
    /* Prints a scalar s to the file fp, with a newline printed after the
    value.
    $A Igor mar05; */

void printscalar(scalar s);
    /* The same as fprintscalar, but prints to the standard output rather than
    to a specified file.
    $A Igor mar05; */

void fprintscalarlist(FILE *fp,scalar s);
  /* Prints a scalar s to the file fp. Only pure value is printed: neither a
  newline nor a space is printed after the value.
    $A Igor mar05; */

void printscalarlist(scalar s);
    /* The same as fprintstalarlist, but prints to the standard output rather
    than to a specified file.
    $A Igor mar05; */

void resizescalar(scalar *addr);
    /* If scalar pointed to by addr is NULL then the scalar is allocated.
      Remark: this is actually not resizing, but the name is taken in
    analogy to containter structures.
    $A Igor mar04; */

scalar copyscalar(scalar v1,scalar *v2);
    /* Returns a copy of scalar v1. If v2!=NULL then v1 is copied to *v2
    and *v2 returned.
    $A Igor maj98; */



int vecgetoutdig(void);
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu vec.c.
    $A Igor mar99; */

int vecgetoutchar(void);
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu vec.c.
    $A Igor mar99; */

void vecsetoutdig(int num);
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu vec.c.
    $A Igor mar99; */

void vecsetoutchar(int num);
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu vec.c.
    $A Igor mar99; */

void getvec(vector vec, int n);
     /* Naredi vektor dimenzije n. */

void dispvec(vector vec);
     /* Sprosti spomin, na katerega kaze vec.v, postavi
        vec.v in vec.d na 0 */

void initvec(vector  vec);

vector getvector(int dim);
       /* Rezervira spomin za vektor z dim elementi in vrne kazalec na ta
       prostor. */

vector resizevector(vector *addrv,int dim);
    /* Resizes a vector pointed to by addrv so that its new dimension is dim.
    All components of an old vector that fit in the new one are preserved. If
    addrv=NULL then vector is created and returned. If dim=0 then vector is
    set to NULL.
    $A Igor nov03; */

vector vectorcopy(vector v);
    /* Vrne kopijo vektorja v.
    $A Igor okt97; */

void dispvector(vector *vec);
     /* Zbrise vektor *vec z vsebino vred in njegovo vrednost postavi na
     NULL. */

int cmpvecfirstcomp(const vector vec1,const vector vec2);
    /* Compares vectors vec1 and vec2 by the first component that is not equal
    if they are of the same dimension, or by dimension if they are not of the 
    same dimension, or vector which is NULL is consider smaller.
      Returns 0 if vectors are equal, -1 if the first vector is smaller than
    the second one and 1 if the first vector is larger than the second one
    according to this criterium.
      This function can be used for checking whether two vectors are equal or
    for sorting & searcing of vectors or vector parts of structures.
    $A Igor apr05; */

vector copytabletovector(double *x,int dim,vector *vec);
    /* Tabela dim stevil dipa double *x se prepise v vektor *vec. Ce je
    dim enak 0 ali ce je x enak NULL, postane *vec enak NULL. Funkcija
    vektor, ki je nastal s prepisom, tudi vrne.
      Ce je argument vec, ki je naslov ciljnega vektorja, enak NULL, se vektor,
    v katerega se prepise tabela in ki ga funkcija vrne, tvori na novo.
    Dimenzija vektorja, v katerega se prepise tabela, je po operaciji enaka
    dim.
      POZOR:
    x mora kazati na 1. element tabele. To pomeni, da se na 1. element
    sklicujemo z x[0] in ne z x[1].
    $A Igor jul98; */

int copyvectortotable(vector v,double **x,int *dim);
    /* Vektor v se prepise v tabelo stevil tipa double, katere nasov je x.
    Ce je v enak NULL ali je njegova dimenzija (v->d) enaka 0 ali je x enak
    NULL, se ne zgodi nic. Ce je dim razlicen od NULL, je z *dim podana
    resnicna dimenzija tabele oz. alociranega prostora. V tem primeru se
    preveri, ce je alociranega prostora dovolj in ce ga ni, se *x zbrise in
    alocira na novo, v *dim pa se zapise dimenzija vektorja. *x se alocira na
    novo tudi, ce je enak NULL. Funkcija vrne stevilo prepisanih komponent
    (ki je lahko samo 0 ali v->d).
      POZOR:
    *x mora kazati na 1. element tabele, na katerega se torej sklicujemo z
    (*x)[0] in ne z (*x)[1].
    $A Igor jul98; */

void copyvec(vector v1, vector v2);
     /* Vektor v2 prepise na vektor v1. v1 mora biti 
        inicializiran na 0. */

vector copyvector(vector v1,vector *v2);
    /* Returns a copy of the vector v1. If v2 is different than NULL then v1
    is copied to *v2 and *v2 returned.
    $A Igor mar98; */

vector copyvector0(vector v1,vector *v2);
    /* Returns a copy of the vector v1. If v2 is different than NULL then v1
    is copied to *v2 and *v2 returned. This function is identical to
    copyvector, which should be used in the future.
    $A Igor mar98; */

vector vectorsum0(vector v1,vector v2,vector *v3);
    /* Vrne vsoto vektorjev v1 in v2. Ce je v3 razlicen od NULL, zapise rezultat
    v *v3 in vrne *v3.
    $A Igor mar98; */

vector vectordif0(vector v1,vector v2,vector *v3);
    /* Vrne razliko vektorjev v1 in v2. Ce je v3 razlicen od NULL, zapise rezultat
    v *v3 in vrne *v3.
    $A Igor mar99; */

vector movevector0(vector *v1,vector *v2);
    /* Premakne *v1 v *v2 in vrne *v2. Po izvedbi je vedno *v1==NULL. Ce je
    v2==NULL, samo vrne *v1 (ce je v1==NULL, vrne NULL).
    $A Igor mar98; */

void fprintvec(FILE *fp,struct _vector v);
     /* Izpise vsebino vektorja na zaslon */

void printvec(struct _vector v);
     /* Izpise vsebino vektorja na zaslon */

void fprintvector(FILE *fp,vector vec);
     /* Izpise vsebino vektorja vec v datoteko fp. */

void printvector(vector vec);
     /* Izpise vsebino vektorja vec na zaslon. */

void fprintvecname(FILE *fp,struct _vector v, char *name);
     /* Izpise vsebino vektorja na datoteko fp. Ime vektorja je name. */

void printvecname(struct _vector v, char *name);
     /* Izpise vsebino vektorja na zaslon. Ime vektorja je name. */

void fprintvectorname(FILE *fp,vector v,char *name);
     /* Izpise vsebino vektorja na datoteko fp. Ime vektorja je name. */

void printvectorname(vector v,char *name);
     /* Izpise vsebino vektorja na zaslon. Ime vektorja je name. */

void fprintvectorline(FILE *fp,vector vec);
    /* Izpise vektor vec v datoteko fp. Vse komponente izpise v eni vrstici.
    $A Igor sep97; */

void printvectorline(vector vec);
    /* Izpise vektor vec na stand. izhod. Vse komponente izpise v eni vrstici.
    $A Igor sep97; */

void fprintvectorlist(FILE *fp,vector vec);
    /* Prints vector vec to fp in a list form as used by Mathematica.
    $A Igor nov03; */

void printvectorlist(vector vec);
    /* Prints vector vec to stand. output in a list form as used by Mathematica.
    $A Igor nov03; */

void readvec(vector v);
     /* Prebere vektor */

void fwritevec(char *filename, struct _vector v);
     /* Zapise komponente vektorja v datoteko z imenom filename.
        Prvotna datoteka se prepise (ce je obstajala). */

int freadvec(char *filename, vector v);
     /* Prebere vektor v iz datoteke z imenom filename.
        V datoteki morajo biti po vrsti zapisane samo komponente
        vektorja. Vrne dimenzijo vektorja. */

void normvec1(vector vec);
             /* Normira vektor vec */

struct _vector timesvec(struct _vector v, double t);
       /* Vrne produkt vektorja v s stevilom t */

struct _vector sumvec(struct _vector v1, struct _vector v2);
       /* Vrne vsoto vektorjev v1 in v2. */

struct _vector difvec(struct _vector v1, struct _vector v2);
       /* Vrne razliko vektorjev v1 in v2. (v1-v2) */








#endif    /* (not defined) INCLUDED_vec */
