
/* Ensure at most one inclusion: */
#ifndef INCLUDED_mat
#define INCLUDED_mat



            /*****************************/
            /*                           */   
            /*  BASIC MATRIX OPERATIONS  */
            /*                           */   
            /*****************************/



/* Inclusion of crucial headers: */
#ifndef INCLUDED_vec
 #include <vec.h>
#endif

#ifndef INCLUDED_stdio
  #include <stdio.h> /* for the type FILE */
  #define INCLUDED_stdio
#endif



/* Definition of the matrix type:
  IMPORTANT:
  Elements and lines are counted from 1, not from 0 (the pointer to a table of
lines and pointers to tables of elements are decremented by 1 when a matrix is
created)! e.g. if we declared "vector m;" then m->m[1][1], m->m[1],2[], ...,
m->m[1][m->d2], m->m[2][1], ..., m->m[m->d1][1], m->m[m->d1],[2], ...,
m->m[m->d1][m->d2] are legal references to matrix components.  */



typedef struct _matrix {
    int d1,d2;    /* dimensions (num. of rows and num. of columns) */
    double ** m;  /* table of pointers to lines, COUNT FROM 1! */
    double *comp; /* pointer to components, 0 offset; NEVER ACCESS DIRECTLY! */
} *matrix;

/* Remark: In the future all struct _matrix declarations should be replaced by
struct struct _matrix, so that struct _matrix can me omitted. Then the first definition
below can also be omitted and struct should be added to the second. */

/*
typedef struct struct _matrix struct _matrix;
typedef matrix matrix;
*/




/* DEFINICIJE MATRICNIH FUNKCIJ */




int matgetoutdig(void);
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu mat.c.
    $A Igor mar99; */

int matgetoutchar(void);
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu mat.c.
    $A Igor mar99; */

void matsetoutdig(int num);
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu mat.c.
    $A Igor mar99; */

void matsetoutchar(int num);
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu mat.c.
    $A Igor mar99; */

void getmat(matrix mat, int m, int n);
     /* Naredi matrikko dimenzije m*n */

void  dispmat(matrix mat);
      /* Sprosti *mat.m, postavi *mat.m ter *mat.d1 in 
         *mat.d2 na 0 */

void initmat(matrix m);
     /* inicializira matriko */

matrix getmatrix(int m,int n);
       /* Rezervira prostor za matriko z m vrsticami in n stolpci ter vrne
       kazalec na ta prostor. */

matrix resizematrix(matrix *addrm,int dim1,int dim2);
    /* Resizes a matrix pointed to by addrm so that its new dimensions are dim1
    and dim2. All components of an old matrix that fit in the new one are
    preserved. If addrm=NULL then a matrix is created and returned. If dim1=0
    and dim2=0 then the matrix is set to NULL. If only one of dim1 and dim2 is
    0 then the appropriate dimension of the old matrix is kept (if there is no
    old matrix then NULL matrix is returned).
    $A Igor nov03; */

matrix matrixcopy(matrix m);
    /* Vrne kopijo matrike m.
    $A Igor okt97; */

void dispmatrix(matrix *mat);
     /* Zbrise matriko *mat z vsebino vred in njeno vrednost postavi na NULL. */

matrix copytabletomatrix(double *x,int dim1,int dim2,matrix *mat);
    /* Tabela dim1xdim2 stevil dipa double *x se prepise v matriko *mat. Ce je
    dim1 ali dim2 enak 0 ali ce je x enak NULL, postane *mat enak NULL.
    Funkcija matriko, ki je nastala s prepisom, tudi vrne.
      Ce je argument mat, ki je naslov ciljne matrike, enak NULL, se matrika,
    v katereo se prepise tabela in ki jo funkcija vrne, tvori na novo.
    Dimenziji matrike, v katereo se prepise tabela, sta po operaciji enaki
    dim1 in dim2.
      POZOR:
    x mora kazati na 1. element tabele. To pomeni, da se na 1. element
    sklicujemo z x[0] in ne z x[1].
    $A Igor jul98; */

int copymatrixtotable(matrix mat,double **x,int *dim1,int *dim2);
    /* Matrika mat se prepise v tabelo stevil tipa double, katere nasov je x.
    Ce je mat enaka NULL ali je katera od njenih dimenzij (v->d1 oz. v->d2)
    enaka 0 ali je x enak NULL, se ne zgodi nic. Ce sta dim1 in dim2 razlicna
    od NULL, je *dim1x*dim2 resnicna dimenzija tabele oz. alociranega prostora.
    V tem primeru se preveri, ce je alociranega prostora dovolj in ce ga ni, se
    *x zbrise in alocira na novo, v *dim1 in *dim2  pa se zapiseta dimenziji
    matrike mat. *x se alocira na novo tudi, ce je enak NULL. Funkcija vrne
    stevilo prepisanih komponent (ki je lahko samo 0 ali mat->d1xmat->d2).
    Ce je dim1 razlicen od NULL, se v *dim1 zapise mat->d1; ce je dim2 razlicen
    od NULL, se v *dim2 zapise mat->d2 (oboje v primeru, da je mat razlicna od
    NULL in sta njeni dimenziji vecji od 0).
      POZOR:
    *x mora kazati na 1. element tabele, na katerega se torej sklicujemo z
    (*x)[0] in ne z (*x)[1].
    $A Igor jul98; */

void copymat(matrix m1, matrix m2);
     /* Matriko *m2 skopira na matriko *m1 */

matrix copymatrix(matrix m1,matrix *m2);
    /* Returns the copy of matrix m1. If m2 is different than NULL, then m1 is
    coppied to *m2 and *m2 returned.
    $A Igor mar98; */

matrix copymatrix0(matrix m1,matrix *m2);
    /* Vrne kopijo matrike m1. Ce je m2 razlicen od NULL, skopira matriko m1 v
    *m2 in vrne *m2.
    $A Igor mar98; */

matrix matrixsum0(matrix m1,matrix m2,matrix *m3);
    /* Vrne vsoto matrik m1 in m2. Ce je m3 razlicen od NULL, zapise rezultat
    v *m3 in vrne *m3.
    $A Igor mar98; */

matrix matrixdif0(matrix m1,matrix m2,matrix *m3);
    /* Vrne vsoto matrik m1 in m2. Ce je m3 razlicen od NULL, zapise rezultat
    v *m3 in vrne *m3.
    $A Igor mar99; */

matrix movematrix0(matrix *m1,matrix *m2);
    /* Premakne *m1 v *m2 in vrne *m2. Po izvedbi je vedno *m1==NULL. Ce je
    m2==NULL, samo vrne *m1 (ce je m1==NULL, vrne NULL).
    $A Igor mar98; */

void fprintmat(FILE *fp, struct _matrix m);
     /* Izpise matriko m */

void printmat(struct _matrix m);
     /* Izpise matriko m */
     
void fprintmatrix(FILE *fp,matrix mat);
     /* Izpise vsebino matrike mat v datoteko fp. */

void printmatrix(matrix mat);
     /* Izpise vsebino matrike mat na standardni izhod. */     

void fprintmatname(FILE *fp,struct _matrix m, char *name);
     /* Izpise matriko m. Niz name uporabi pri poimenovanju matrike. */

void printmatname(struct _matrix m, char *name);
     /* Izpise matriko m. Niz name uporabi pri poimenovanju matrike. */

void fprintmatrixname(FILE *fp,matrix m,char *name);
     /* Izpise vsebino matrike m v datoteko fp. Ime vektorja je name. */

void printmatrixname(matrix m,char *name);
     /* Izpise vsebino matrike m na na standardni izhod. Ime vektorja je name. */

void fprintmatrixline(FILE *fp,matrix mat);
    /* V datoteko fp zapise matriko mat, pri cemer vrstice izpise v eni vrsti.
    $A Igor sep97; */

void printmatrixline(matrix mat);
    /* Na stand. izhod zapise matriko mat, pri cemer vrstice izpise v eni vrsti.
    $A Igor sep97; */

void fprintmatrixlist(FILE *fp,matrix mat);
    /* Prints matrix mat to the file fp in a list form as used in Mathematica.
    Line breaks are printed between lines.
    $A Igor nov03; */

void printmatrixlist(matrix mat);
    /* Prints matrix mat to the standard output in a list form as used in
    Mathematica. Line breaks are printed between lines.
    $A Igor nov03; */

void fprintmatrixlistline(FILE *fp,matrix mat);
    /* Prints matrix mat to the file fp in a list form as used in Mathematica.
    Only spaces are printed between lines (no line breaks).
    $A Igor apr05; */

void printmatrixlistline(matrix mat);
    /* Prints matrix mat to the standard output in a list form as used in
    Mathematica. Only spaces are printed between lines (no line breaks).
    $A Igor apr05; */

void readmat(matrix m);
     /* Prebere matriko s standardnega vhoda. */

struct _matrix identitymat(int n);
       /* Vrne identicno matriko n*n */

struct _matrix prodmat(struct _matrix m1, struct _matrix m2);
       /* Vrne matricni produkt matrik m1 in m2 */

struct _matrix timesmat(struct _matrix m, double t);
       /* Vrne matriko m, pomnozeno s stevilom t */

struct _matrix summat(struct _matrix m1, struct _matrix m2);
       /* Vrne vsoto matrik m1 in m2. */

struct _matrix difmat(struct _matrix m1, struct _matrix m2);
       /* Vrn razliko matrik (m1-m2) */

struct _matrix transpmat(struct _matrix m);
       /* Vrne transponirano matriko matrike m */

double detmat(struct _matrix mm);
       /* Vrne determinanto kvadratne matrike m. */

struct _matrix invmat(struct _matrix m);
       /* Vrne inverzno matriko kvadratne matrike m */

struct _matrix quotmat(struct _matrix a, struct _matrix b);
       /* Vrne kvocient matrik (a inv(b)) */



/* "Varne matricne funkcije: matrika, ki je rezultat funkcije, se ne tvori na
    novo, ce ustrezna matrika ze obstaja. S tem se izognemo napakam pri delu s
    spominom, ki se lahko pojavijo, ce hocemo znotraj funkcije brisati matriko,
    ki je bila definirana zunaj te funkcije. */


void scopymat(matrix m1, struct _matrix m2);
     /* Varno kopiranje:
        Matriko *m2 skopira na matriko m1. Ce je matrika m1 ze ustrezne
        dimenzije, se le prepise vsebina in se ne tvori na novo. */


void sidentitymat(matrix mat, int n);
       /* Vrne identicno matriko n*n */


void sprodmat(matrix m, struct _matrix m1, struct _matrix m2);
       /* Varni matricni produkt matrik m1 in m2:
          Matrika m postane produkt matrik m1 in m2. Ce je m ze obstojeca 
          matrika ustreznih dimenzij, se ne zbrise in tvori na novo! */


void stimesmat(matrix mm, struct _matrix m, double t);
       /* Vrne matriko m, pomnozeno s stevilom t */


void ssummat(matrix mm, struct _matrix m1, struct _matrix m2);
       /* Vrne vsoto matrik m1 in m2. */


void sdifmat(matrix mm, struct _matrix m1, struct _matrix m2);
       /* Vrne razliko matrik (m1-m2) */



void stranspmat(matrix mm, struct _matrix m);
       /* Vrne transponirano matriko matrike m */


void sinvmat(matrix inv, struct _matrix m,matrix a);
       /* Vrne inverzno matriko kvadratne matrike m v matriki inv. Matrika
          a je pomozna matrika, ki mora biti iste dimenzije kot m. */


void squotmat(matrix q, struct _matrix a, struct _matrix b,matrix buf);
       /* Vrne kvocient matrik (a inv(b)) v matriki q. buf je pomozna 
       matrika. */


void sinvmat1(matrix inv, struct _matrix m);
       /* Vrne inverzno matriko kvadratne matrike m */


void squotmat1(matrix q, struct _matrix a, struct _matrix b);
       /* Vrne kvocient matrik (a inv(b)) v matriki q. */




/* Matricne funkcije za uporabo v matricnih enacbah. So hkrati preproste za
   uporabo (uporabljas jih lahko skoraj tako kot obizajne funkcije) in varne,
   kar se tice napak pri ravnanju s spominom: Ce matrika, v katero naj se zapise
   rezultat, ze obstaja, potem je ni treba brisati pred prireditvijo in se tudi 
   ne brise znotraj funkcije same. edina neprijetnost teh funkcij je v tem, da 
   moramo matrika, ki naj vsebuje rezultat operacije, navesti kot 1. parameter.
     PRIMERI:
   a=b*c zapisemo kot a=cprodmat(&a,b,c) ali kar cprodmat(&a,b,c).
   c=c*c zapisemo kot c=cprodmat(&c,c,c) ali cprodmat(&c,c,c).
   c=c*c*c zapisemo npr. kot cprodmat(&c,cprodmat(&c,c,c),c).
   c=a*(1/b) zapisemo lahko kot c=cprodmat(&c,a,cinvmat(&c,b)).
     POZOR!
   Pri uporabi teh funkcij je treba paziti na naslednje:
   Ce napisemo na primer a=cprodmat(&b,x,y) , si matriki a in b delita 
   komponente (te so na istih spominskih lokacijah). Ce kdaj pozneje zbrisemo
   matriko a, se hkrati zbrise tudi matrika , vendar nepravilno, ker ostanejo
   dimenziji ter kazalec na komponente razlicni od 0.
*/

 
 
 
struct _matrix cidentitymat(matrix mat, int n);
       /* Identicna matrika dimenzije n */


struct _matrix cprodmat(matrix res, struct _matrix m1, struct _matrix m2);
       /* produnkt matrik m1 in m2 */


struct _matrix ctimesmat(matrix res, struct _matrix m, double t);
       /* Produkt matrike m s stevilom t */


struct _matrix csummat(matrix res, struct _matrix m1, struct _matrix m2);
       /* Vsota matrik m1 in m2 */


struct _matrix cdifmat(matrix res, struct _matrix m1, struct _matrix m2);
              /* Razlika matrik m1 in m2 */


struct _matrix ctranspmat(matrix res, struct _matrix m);
       /* Transponirana matrika matrike m */


struct _matrix cinvmat(matrix res, struct _matrix m);
       /* Inverzna matrika matrike m */


struct _matrix cquotmat(matrix res, struct _matrix m1, struct _matrix m2);
       /* Kvocient matrik m1 in m2 (m1/m2) */


struct _matrix cinvmat1(matrix  inverse, struct _matrix m);
       /* Vrne inverzno matriko kvadratne matrike m */


/* ============= LU dodatek ====================== */

void luordermat(vector scale,matrix a,int *order);
    /* funkcija pripravi vse potrebno za potrebe delnega pivotiranja. Vektor
    celih  stevil order se v funkciji le inicializira. V vektor scale pa se 
    shranijo scale faktorji.
      POZOR !!! Funkcijo izvrsimo vedno pred LU dekompozicijo.
    $A Tomsus feb97;  */


void lupivot(vector scale,matrix a,int *order,int row);
    /* funkcija izvaja delno pivotiranje matrike glede na velikosti scale 
    faktorjev, ki jih izracuna funkcija luordermat. Nove pozicije vrstic 
    matrike a se shranijo v vektor celih stevil order.
    Funkcija je pomozna funkcija glavne dekompozicijske funkcije ludecompmat,
    ki po obdelavi posamezne vrstice row znova poisce pivota
    $A Tomsus feb97; */

void ludecompmat(vector scale,matrix a, int *order);
    /* funkcija opravi LU dekompozicijo matrike a z Crautovim algoritmom.
    Funkcija izvaja delno pivotiranje za to potrebuje predhodno izracunani
    vektor scale faktorjev (vektor scale) in pa vektor celih stevil oreder
    v katerm je shranjena trenutna lega posamezne vrstice matrike a.
    Obe novo nastali matriki L in U shrani v matriko a. Matriko L 
    (lower matrix) sestavljajo elementi pod diagonalo.
    POZOR !!! pred klicem funkcije ludecompmat je zaradi potreb pivotiranja
    nujen klic funkcije luordermat.
    (POZOR !!! v originalni varianti ima matrika L vse diagonalne elemente 
    enake 1. Matriko U (upper matrix) pa sestavljajo elementi na 
    diagonali in nad njo )
    Primer dekompozicije matrike a :
      luordermat(scale,a,order);
      ludecompmat(scale,a,order);
    $A Tomsus feb97; */

void lusolvemat(matrix a, vector b,vector x, int *order);
    /* Funkcija za resevanje sistema linearnih enacb s pomocjo LU-dekompozicije.
    Matrika a mora biti ze dekompozirana (Solve obicajno sledi klicu 
    ludecompmat(a) ). b je vektor konstant na desni strani enacbe. Resitev 
    sistema se shrani v vektor x. Zaradi delnega pivotiranja mora biti
    znan tudi trenutni polozaj vrstic v vektorju celih stevil order.
      Postopek za resevanje sistema A x = b
       luordermat(scale,a,order);
       ludecompmat(scale,a,order);
       lusolvemat(stress,b,x,order);   
    $A Tomsus  feb97; */
   
void luinvmat(matrix a,matrix inv,int *order);
    /* funkcija izracuna inverz ze dekompozirane matrike.
    Funkcija vrne inverzno matriko.
    Primer izracuna inverzne matrike inv  matrike a :
      ( inv = a^-1 )
      luordermat(scale,a,order);
      ludecompmat(scale,a,order);
      inv=luinvmat(a,order);
    $A Tomsus feb97; */

double ludetmat(matrix a,int *order);
    /* funkcija vrne vrednost determinante dekompozirane matrike a.
    Primer izracuna determinante matrike a:
      luordermat(scale,a,order);
      ludecompmat(scale,a,order);
      printf("det(A) = %f \n",ludetmat(a,order));
    $A Tomsus feb97; */

void fprintmatrow(FILE *fp,matrix a);
    /* Funkcija izpise matriko v datoteko fp po vrsticah 
    Tomaz feb97; */

void printmatrow(matrix a);
    /* Funkcija izpise matriko na zaslon fp po vrsticah 
    Tomaz feb97; */
   








#endif    /* (not defined) INCLUDED_lint */
