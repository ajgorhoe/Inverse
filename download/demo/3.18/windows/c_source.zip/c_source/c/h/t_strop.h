

        /* TESTNE OPERACIJE Z NIZI */

#include "t_sysint.h"


/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_st
 #include <st.h>
#endif



#ifndef INCLUDED_t_strop
#define  INCLUDED_t_strop

#ifdef IGTEST
 #include "../../ct/h/h_strop.h"
#endif









#endif /* (not defined) INCLUDED_t_strop */


