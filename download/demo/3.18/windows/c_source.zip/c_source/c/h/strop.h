

        /* OPERATIONS ON STRINGS */


/* Code that prevents double inclusion (and thus makes safe inclusion of
this header in other headers):  */
#ifndef INCLUDED_strop
#define INCLUDED_strop


/* Code that insures inclusion of necessary headers: */
#ifndef INCLUDED_st
 #include <st.h>
#endif


/* String type as equivalent to char *: */
typedef char _string;
typedef _string *string;



void disppointer(void **p);
    /* Zbrise kazalec na objekt nesestavljenega tipa *p. Funkcija je napisana
    zato, da se lahko uporabi funkcije, ki imajo med svojimi argumenti tudi
    funkcijo za brisanje objektov, tudi pri enostavnih tipih, za katere taksna
    funkcija ni posebej definirana, saj lahko uporabimo kar free().
    $A Igor apr98; */

int pointerdatanotnull(void *p,int size);
    /* Returns 0 if memory block of size bytes pointed to by p contains 
    only zeros, or the position (counted from 1) of the first byte that
    is  not 0. This function is usually used for checking that 
    everything is deleted on structures.
    $A Igor aug05; */


/* macro m_sizepointer(p,type) :
evaluates to the size of a simple object (i.e. no other allocated pointers
loaded on it) of a specified type. If p is NULL then it evaluates to 0,
otherwise to the size of the object pointed to by type.
$A Igor nov03; */

#define m_sizepointer(p,type) ((p)==NULL?0:sizeof(type *))

/* macro m_copypointer(p1,addr2,ret) :
Used for copying simple pointer objects with known type. p1, *addr2 and ret
must be of the same type. If addr2 is different than NULL then *p1 is copied
to **addr2 and ret is set to *addr2 (*addr2 is allocated if necessary).
Otherwise a new pointer is allocated, *p1 copied to the location pointed to
by this pointer, and ret is set to this pointer.
This function is often used inside functions for copying simple objects.
  Important:
#include <stdlib.h> when using this macro (because of calloc())!
$A Igor nov03; */

#define m_copypointer(p1,addr2,ret)  \
  if ((addr2)!=NULL)  \
  {  \
    /* If addr2!=NULL, then p1 is copied to *addr2: */  \
    if ((p1)==NULL)  \
    {  \
      disppointer((void **) (addr2));  \
    } else  \
    {  \
      if (*(addr2)==NULL)    /* Allocate *c2 if necessary: */  \
        *(addr2)=calloc(1,sizeof(*(p1)));  \
      /* Copying contents: */  \
      **(addr2)=*(p1);  \
    }  \
    (ret)= *(addr2); /* since addr2!=NULL. */  \
  } else  \
  {  \
    /* addr2==NULL, a new copy of p1 created and returned */  \
    if ((p1)==NULL)  \
      (ret)=NULL;  \
    else  \
    {  \
      (ret)=calloc(1,sizeof(*(p1)));  \
      *(ret)=*(p1);  \
    }  \
  }



    /* OPERACIJE Z NIZI BYTOV V SPOMINU */


        /* ISKANJE NIZOV BYTOV V SPOMINU */

int imemchr(void *p,int c,size_t n);
    /* V delu spomina p velikosti n poisce znak c in vrne razliko (v bytih)
    med njegovo pozicijo in p. Ce znaka ne najde, vrne -1.
    $A Igor sep98; */

void *memnchr(char *p1,size_t l1,char *p2,size_t l2);
     /* V delu spomina dolzine l1, na katerega kae p1, najde 1. znak, ki je
     vsebovan v nizu p2 dolzine l2. */

int imemnchr(char *p1,size_t l1,char *p2,size_t l2);
    /* V delu spomina dolzine l1, na katerega kae p1, najde 1. znak, ki je
    vsebovan v nizu p2 dolzine l2. Vrne razliko med pozicijo tega znaka in p1,
    ce pa znaka ne najde, vrne -1.
    $A Igor sep98; */

void *memnotnchr(char *p1,size_t l1,char *p2,size_t l2);
     /* V delu spomina dolzine l1, na katerega kae p1, najde 1. znak, ki ni
     vsebovan v nizu p2 dolzine l2. */

int imemnotnchr(char *p1,size_t l1,char *p2,size_t l2);
     /* V delu spomina dolzine l1, na katerega kae p1, najde 1. znak, ki ni
     vsebovan v nizu p2 dolzine l2 in vrne razliko med pozicijo tega znaka in
     p1. Ce taksnega znaka ne najde, vrne -1.
     $A Igor sep98; */

char *memfind(char *p1, size_t l1, char *p2, size_t l2);
     /* Poisce 1. pojav spominskega niza p2 dolzine l2 v spominskem nizu
     p1 dolzine l1. Vrne kazalec na ta del spomina.
     */

int imemfind(char *p1, size_t l1, char *p2, size_t l2);
    /* Poisce 1. pojav spominskega niza p2 dolzine l2 v spominskem nizu p1
    dolzine l1. Vrne razliko med pozicijo najdenega niza in p1 oziroma -1, ce
    niza ne najde.
    $A Igor sep98; */

char *nmemfind(char *p1, size_t l1,stack strst,stack lengthst,int *which);
     /* Najde 1. pojav kateregakoli od nizov, ki so na skladu strst, v nizu p1
     dolzine l1. Glede znakov, ki jih vsebujejo nizi, ni omejitev. Na skladu
     lengthst morajo biti kazalci na dolzine ustreznih nizov na skladu strst,
     in sicer morajo biti te dolzine tipa int.
     funkcija vrne kazalec na 1. najdeni niz, v *which pa zapise, kateri po
     vrsti je ta niz na skladu strst. Ce funkcija ne najde nobenega od nizov,
     vrne NULL, *which pa postane -1.
     */

int inmemfind(char *p1, size_t l1,stack strst,stack lengthst,int *which);
    /* Najde 1. pojav kateregakoli od nizov, ki so na skladu strst, v nizu p1
    dolzine l1. Glede znakov, ki jih vsebujejo nizi, ni omejitev. Na skladu
    lengthst morajo biti kazalci na dolzine ustreznih nizov na skladu strst,
    in sicer morajo biti te dolzine tipa int.
    Funkcija vrne razliko med pozicijo najdenega niza in p1, v *which pa
    zapise, kateri po vrsti je ta niz na skladu strst. Ce funkcija ne najde
    nobenega od nizov, vrne -1, tudi *which pa postane -1.
    $A Igor sep98; */

int memfindall(char *p1, size_t l1, char *p2, size_t l2, stack st);
     /* Poisce vse pojave spominskega niza p2 dolzine l2 v spominskem nizu
     p1 dolzine l1. Vrnestevilo najdenih pojav, hkrati pa na sklad st zaporedoma
     potisne kazalce na stevila tipa int, ki predstavljajo mesta pojav. mesta
     se stejejo od p1 zacensi z 0.
     */




    /* OPERACIJE S TEKSTOVNIMI NIZI */


int stringlength(char *s);
    /* Safe version of strlen; returns length of string s (i.e. numver of
    characters in *s before the first '\0') of 0 if s is NULL.
    $A Igor jan02; */

char *makestring(int n);
     /* Rezervira prostor za niz dolzine n in vrne kazalec nanj. Taksen niz
     lahko brises z ukazom free! */

int sizestring(char *s);
    /* Returns the size of the memory occupied by *s, in bytes.
    $A Igor nov03; */

char *copystring(char *s1,char **s2);
    /* Returns a copy of s1. If s2 is different than NULL then s1 is
    copied to *s2 and *s2 returned, otherwise a dynamic copy of s1 is made
    and returned.
    $A Igor nov03; */

char *stringcopy(const char *s);
     /* Ta funkcija alocira toliko spomina, da lahko nanj
     skopira niz s z zakljucnim znakom vred, skopira vse
     znake niza s na rezerviran spominski prostor in vrne
     kot rezultat kazalec na ta alociran spomin. */

char *stringncopy(char *s,int n);
     /* Ta funkcija alocira toliko spomina, da lahko nanj
     skopira niz n znakov niza s z zakljucnim znakom vred,
     skopira n znakov niza s na rezerviran spominski prostor in vrne
     kot rezultat kazalec na ta alociran spomin. Ce ima niz s manj kot
     n znakov, se alocira le toliko znakov, kolikor je potrebno za
     prepis niza. */

void stringappend(char **straddr,char *ext);
    /* Appends a zero terminated string pointed to by straddr by the contents
    of a zero terminated string ext. Nothing happens if straddr is NULL.
    $A Igor apr03; */

void stringinsert(char **straddr,char *ext,int place);
    /* Insert into a zero terminated string pointed to by straddr the content
    of the string ext, at location place (counted from zero). If place is a
    negative number or it is greater or equal than the length of *straddr, then
    the string ext is appended at the end of the string pointed to by straddr.
    Nothing happens if straddr is NULL, if ext is NULL or if ext is an empty
    string. Note that *straddr is usually changed.
    $A Igor apr03; */

char *stringcat(char *s1,char*s2);
     /* Alocira toliko spomina, kot ej potrebno za zapis nizov s1 in s1, nato
     na ta prostor zapise zlepljen niz s1+s2 ter vrne kazalec na alociran
     prostor. niz lahko brises z ukazom free!
     */

char *multstringcat(char *first,...);
    /* Zlepi vse argumente kot nize in vrne alociran zlepek zakljucen z '\0'.
    Zadnji argument mora biti NULL, drugace pa je lahko stevilo argumentov
    poljubno. Ce je skupna dolzina nizov enaka 0, vrne funkcija NULL, ceprav je
    kak niz razlicen od NULL (enak ""). NULL je lahko le zadnji argument.
    $A Igor jan02; */

char *multstringcatn(int num,char *first,...);
    /* Zlepi vseh n argumentov, ki sledijo num, kot nize in vrne alociran
    zlepek zakljucen z '\0'. Ce je skupna dolzina nizov enaka 0, vrne funkcija
    NULL, ceprav je kak niz razlicen od NULL (enak ""). Katerikoli niz med
    argumenti je lahko NULL, nizovnih arhumentov za num pa mora biti vsaj
    num. Niz, ki se vrne, je dinamicno alociran in se lahko brise s free().
    $A Igor dec02; */

int cmpstrings(const char *str1,const char *str2);
    /* Podobno kot standardna funkcija strcmp, le da deluje tudi, ce je kateri
    (ali oba) od nizov str1 in str2 enak NULL.
    $A Igor jan99; */

int ncmpstrings(char *str1,char *str2,int n);
    /* Similar to the standard function nstrcmp, except that it functions
    properly if one or both strings are NULL.
    $A Igor jul03; */

int cmpstringtails(char *str1,char *str2,int n);
    /* Compares the last n characters of strings str1 and str2. It returns the
    same result as cmpstrings() would return on strings comosed of the last n
    characters of str1 and str2, provided that NULL is taken in n exceeds the
    number of characters in the corresponding string.
      The function is used for example for checking if the first file name is
    the same as the second except thet it does not contain the complete path.
    $A Igor jan03; */

#define strcmpsafe(str1,str2) ( ((str1)==NULL)? ((str2)==NULL? 0: -1) : ( ((str2)==NULL)? 1 : strcmp((str1),(str2)) ) )

#define strlensafe(str) ( ((str)==NULL)? 0: strlen(str) )

#define strncmpsafe(str1,str2,n) ( ((str1)==NULL)? ((str2)==NULL? 0: -1) : ( ((str2)==NULL)? 1 : strncmp((str1),(str2),(n)) ) )


    /* POSEBNI ZNAKI (nacin za Inverse): */

char specialcharacter(char spec);
    /* Vrne znak, ki ustreza specifikaciji spec. Funkcija je narejena za
    pretvarjanje specifikacij posebnih znakov na tistih mestih, kjer ni mozno
    zapisati teh znakov direktno. Ce spec ni dogovorjena specifikacija za kak
    posebni znak, vrne funkcija '0'.
    $A Igor maj98; */

int updatespecchar(char *str);
    /* V nizu str spremeni vse specifikacije posebnih znakov (te morajo slediti
    znaku '\') v ustrezne posebne znake. Ce se zaradi tega niz skrajsa, se ne
    alocira prostor zanj na novo. niz str mora biti terminiran z '\0'.
    $A Igor maj98; */


    /* BITWISE OPERATIONS */



    /* PRINTING MEMORY CONTENTS: */

int fprintdatahex(FILE *fp,void *p,int size);
    /* Prints a memory chunk of size bytes pointed to by p as a hexadecimal
    number. Returns the number of bytes written.
    $A Igor jul05; */

int printdatahex(void *p,int size);
    /* Prints a memory chunk of size bytes pointed to by p as a hexadecimal
    number. Returns the number of bytes written.
    $A Igor jul05; */

int sprintdatahex(char *str,void *p,int size);
    /* Prints a memory chunk of size bytes pointed to by p as a hexadecimal
    number, to the string str. The output string str must be allocated with
    sufficient length (3 bytes for each byte + terminating 0 byte + 4 bytes).
      Function returns the length of output in bytes.
    $A Igor jul05; */

int fprintdataoct(FILE *fp,void *p,int size);
    /* Prints a memory chunk of size bytes pointed to by p as a octal
    number. Returns the number of bytes written.
    $A Igor jul05; */

int printdataoct(void *p,int size);
    /* Prints a memory chunk of size bytes pointed to by p as a octal
    number. Returns the number of bytes written.
    $A Igor jul05; */

int sprintdataoct(char *str,void *p,int size);
    /* Prints a memory chunk of size bytes pointed to by p as a octal
    number, to the string str. The output string str must be allocated with
    sufficient length (4 bytes for each byte + terminating 0 byte + 4 bytes).
      Function returns the length of output in bytes.
    $A Igor jul05; */

int fprintdatabits(FILE *fp,void *p,int size);
    /* Prints the state of all bits from the memory location pointed to by p
    of size bytes, to the file fp. Bits are printed from in the descending
    order of memory address, i.e. from the most to the least significant ones.
      Function returns the number of bytes written.
    $A Igor feb01 apr03; */

int printdatabits(void *p,int size);
    /* Prints the state fo all bits from the memory location pointed to by p
    of size bytes. Bits are printed from in the descending order of memory
    address, i.e. from the most to the least significant ones.
      Function returns the number of bytes written.
    $A Igor feb01 apr03; */

int sprintdatabits(char *str,void *p,int size);
    /* Prints the state of all bits from the memory location pointed to by p
    of size bytes, to the string str. Bits are printed from in the descending
    order of memory address, i.e. from the most to the least significant ones.
      Function returns the length of output written to str in bytes.
    $A Igor feb01 apr03; */

int fprintintflags(FILE *fp,int flags);
    /* Prints bit image of integer flags to the file fp.
    Returns the number of written bytes.
    $A Igor apr03; */

int printintflags(int flags);
    /* Prints bit image of integer flags to the standard output.
    Returns the number of written bytes.
    $A Igor apr03; */

int sprintintflags(char *str,int flags);
    /* Prints bit image of integer flags to the string str. Str must point to
    enough allocated space, normally this should be at least 2+9*sizeof(int)
    bytes. Returns the number of written bytes.
    $A Igor apr03; */

int fprintlongflags(FILE *fp,long flags);
    /* Prints bit image of long integer flags to the file fp.
    $A Igor apr03; */

int printlongflags(long flags);
    /* Prints bit image of long integer flags to the standard output.
    Returns the number of written bytes.
    $A Igor apr03; */

int sprintlongflags(char *str,long flags);
    /* Prints bit image of long integer flags to the string str. Str must point to
    enough allocated space, normally this should be at least 2+9*sizeof(long)
    bytes. Returns the number of written bytes.
    $A Igor apr03; */

void setallbits(void *p,int size);
    /* Sets all bits in the memory region pointed to by p of size size bytes.
    $A Igor apr03; */


    /* COMFORTABLE READING OF NUMBERS FROM STAND. INPUT */


void setstropevaluateexpression(double (*evalexp) (char *exp) );
    /* Nastavi lokalno funkcijo evaluateexpression(), ki se uporablja pri
    izvrednotenju izrazov v funkcijah za branje stevil.
    $A Igor jul01; */

void setstropsendtocalc(void (*sendtc) (char *exp) );
    /* Nastavi lokalno funkcijo sendtocalc(), ki se uporablja kot kalkulatorska
    lupina v funkcijah za branje stevil.
    $A Igor avg01; */

int readdouble(double *a);
    /* Prebere realno stevilo s standardnega vhoda. Ce uporabnik vstavi niz "?"
    namesto stevila, se izpise trenutna vrednost stevila, branje pa se ponovi.
    Ce vstavi niz "", se ohrani stara vrednost. Ce vstavi $ in izraz ali izraz
    v oklepajih (), se izracuna izraz s funkcijo evaluateespression (ce je
    razlicna od NULL) in se njegova vrednost priredi *a.
    $A Igor  <== jul01; */

int readfloat(float *a);
    /* Prebere float *a s standardnega vhoda. Ce uporabnik vstavi niz "?"
    namesto stevila, se izpise trenutna vrednost stevila, branje pa se ponovi.
    Ce vstavi niz "", se ohrani stara vrednost. Ce vstavi $ in izraz ali izraz
    v oklepajih (), se izracuna izraz s funkcijo evaluateespression (ce je
    razlicna od NULL) in se njegova vrednost priredi *a.
    $A Igor <== feb01 jul01; */

int readlong(long *a);
    /* Prebere stevilo tipa long s standardnega vhoda. Ce uporabnik vstavi niz "?"
    namesto stevila, se izpise trenutna vrednost stevila, branje pa se ponovi.
    Ce vstavi niz "", se ohrani stara vrednost. Ce vstavi $ in izraz ali izraz
    v oklepajih (), se izracuna izraz s funkcijo evaluateespression (ce je
    razlicna od NULL) in se njegova zaokrozena vrednost priredi *a.
    $A Igor <== jul01; */

int readint(int *a);
    /* Prebere celo stevilo s standardnega vhoda. Ce uporabnik vstavi niz "?"
    namesto stevila, se izpise trenutna vrednost stevila, branje pa se ponovi.
    Ce vstavi niz "", se ohrani stara vrednost. Ce vstavi $ in izraz ali izraz
    v oklepajih (), se izracuna izraz s funkcijo evaluateespression (ce je
    razlicna od NULL) in se njegova zaokrozena vrednost priredi *a.
    $A Igor <== feb01 jul01; */

int readlongflags(long *pflags,long mask);
    /* The same as readintflags() (see below), except that flags are of type
    long rather than int. This should always be the case if more than 16 bits
    are needed, since int is 2 bytes long on some systems.
    $A Igor apr0l */

int readintflags(int *pflags,int mask);
    /* Sets flags *pflags according to user input on stdin. mask defines the
    bits which are set or unset. User input is read by readint() where initial
    value is set according to whether all mask defined flags in *pflags are
    set (1), none of them is set (0) or some are set and some are not (-1).
    If user input is 0, all flags in *pflags for which bits in mask are 0 are
    unset, if it is 1, all flags are set, and if it is -1, *oflags  remains
    unchanged. In any case, those bits which are 0 in mask, are not changed.
      Function returns 1 if everything is OK or -1 if not (namely if pglags
    is NULL).
    	If the mask is specified as 0, all bits in *pflags are affected.
      Warning:
      Whenever more than 16 distinct bits are used for flags, these should be
    long int, since int is only 2 bytes long on some operating systems.
    $A Igor apr0l */

void waituserresponse(void);
    /* Prompts user to press <Enter> and stops execution of the program, until
    <Enter> is pressed.
    $A Igor jul03; */


    /* UDOBNO BRANJE NIZOV S STAND. VHODA */

int readstring(char **str);
    /* Prebere niz *str s standardnega vhoda. Ce vstavi niz "", se
    ohrani stara vrednost niza.  Ce je zadnji znak vstavljenega niza '\', pred
    njim pa ni tega znaka, se prebere se en niz, ki se prikljuci k prepranemu
    nizu brez zadnjega znaka '\' (to se lahko poljubno krat ponovi). Pri
    vstavljanju se lahko vstavi posebne sekvence, ki pomenijo navodila tej
    funkciji in se ne stejejo kot del vstavljenega niza.  Ce uporabnik vstavi
    niz "\", se izpise trenutna vrednost niza, branje se ponovi. Ce je
    vstavljen niz enak "a\", se prebrani niz prikljuci stari vsebini niza. Z
    ukazom "c\" odpovemo prikljucevanje staremu nizu. Ce je niz enak "e\",
    postane brani niz prazni niz "", ce pa je niz enak "n\", postane brani niz
    NULL. Ce je vstavljen niz enak "?", "?\" ali "h\", se izpise kratka pomoc
    za vstavljanje nizov.
    Prebrani niz lahko vsebuje posebne znake, ki se vstavijo s sekvenco, ki se
    zacne z znakom '\' (pravila so taksna, kot pri funkciji specialcharacter).
    V tem primeru se po branju zamenjajo sekvence, ki oznacujejo posebne znake,
    s funkcijo updatespecchat().
    Za *str se alocira tocno toliko prostora, kolikor je potrebno. Branje se
    izvede preko vmesnega pomnilnika buf, ki ima alociranih doloceno stevilo
    znakov (konstanda buflength v funkciji). Funkcija vrne dolzino prebranega
    niza ali -1, ce je str enak NULL.
      POZOR: znaka '\' v nizu se ne da vstaviti neposredno, ampak ga je treba
    vstaviti kot sekvenco za poseben znak "\\".
    $A Igor jan01 jan03; */



    /* CEKIRANJE IMEN SPREMENLJIVK: */


char legalvarname(char *name);
    /* Vrne 1, ce je name niz, ki ga lahko uporabimo za ime spremenljivke, in
    0, ce name ni tak niz (to je tudi v primeru, da je NULL).
    $A Igor sep01; */




    
        /*************************/
        /*                       */
        /*  STRINGS AND NUMBERS  */
        /*                       */
        /*************************/



    /* PRINTING NUMBERS WITH 1000 SEPARATORS: */

/* Remark: IMPLEMENT THREAD COMPATIBILITY! */

int fprintdoublesep(FILE *fp,double x,char sep, char *flags,int width,
                     int precision,char *type);
    /* Prints a double x with 1000 separators into fp. sep is separator (none
    if sep=='\0' || sep=='0'), flags are formatting flags like for printf(),
    e.g. "-" for left alignment (can be NULL or ""), width is field width
    (if <=0 then the default width is used), precision is number of signif.
    digits printed (if 0 then the default value is used), and type must be a
    valid format specification like for printf() (e.g. "lg" or "e"), but it can
    be NULL or "", in which case "lg" is used.
    The function prints the number x in the same way as fprintf(), except that
    it inserts signs sep as 1000 separators into the whole part of the number.
      Function returns the number of characters printed or a negative number
    in the case of error.
    $A Igor apr03; */

int printdoublesep(double x,char sep, char *flags,int width,
                     int precision,char *type);
    /* The same as fprintdoublesep(), but prints the number to the standard
    output.
    $A Igor apr03; */

int sprintdoublesep(char *str,double x,char sep, char *flags,int width,
                     int precision,char *type);
    /* The same as fprintdoublesep(), but prints the number with separators
    to the string str and appends the terminating '\0' (which is not counted
    into the returned number of written bytes).
    $A Igor apr03; */

int fprintlongsep(FILE *fp,long x,char sep, char *flags,int width,
                  char *type);
    /* Prints a long int. x with 1000 separators into fp. sep is separator
    (none if sep=='\0' || sep=='0'), flags are formatting flags like for
    printf(), e.g. "-" for left alignment (can be NULL or ""), width is field
    width (if <=0 then the default width is used), and type must be a valid
    format specification like for printf() (e.g. "li" or "i"), but it can
    be NULL or "", in which case "li" is used.
    The function prints the number x in the same way as fprintf(), except that
    it inserts signs sep as 1000 separators into the number.
      Function returns the number of characters printed or a negative number
    in the case of error.
    $A Igor apr03; */

int printlongsep(long x,char sep, char *flags,int width,
                     char *type);
    /* The same as fprintlongsep(), but prints the number to the standard
    output.
    $A Igor apr03; */

int sprintlongsep(char *str,long x,char sep, char *flags,int width,
                  char *type);
    /* The same as fprintlongsep, except that it prints the number with
    added separators to the string str and adds the terminating '\0' character,
    which is not kcounted in the returned number of written characters.
    $A Igor apr03; */



char *stringlong(long a);
     /* Vrne kazalec na niz, ki predstavlja stevilo a tipa long. Ta niz lahko
     brises s free. */

char *stringdouble(double a);
     /* Vrne kazalec na niz, ki predstavlja stevilo a tipa double. Ta niz lahko
     brises s free. */

char decdigit(char d);
     /* Vrne 1, ce znak predstavlja decimalno stevilko, drugace pa 0. */

char sletter(char d);
     /* Vrne 1, ce znak predstavlja malo crko, drugace pa 0. */

char bletter(char d);
     /* Vrne 1, ce znak predstavlja veliko crko, drugace pa 0. */

char letter(char d);
     /* Vrne 1, ce znak predstavlja crko (malo ali veliko), drugace pa 0. */

char alphanum(char d);
     /* Vrne 1, ce znak predstavlja a;fanumericen  znak, drugace pa 0. */

char isnumber(char *s);
     /* Vrne 1, ce zacetek niza *s predstavlja stevilo, drugace pa 0 */

int nstrnum(char *s);
     /* vrne stevilo znakov v nizu, ki predstavljajo stevilo. Ce zacetek
     niza sploh ne predstavlja stevila, vrne 0. */

int nstrnum1(char *s);
     /* vrne stevilo znakov v nizu, ki predstavljajo stevilo. Ce zacetek
     niza sploh ne predstavlja stevila, vrne 0. */

int floatstr(char *s);
     /* Vrne 1, ce niz s gotovo predstavlja necelo stevilo, drugace vrne 0.
     Ce je stevilo zapisano v eksponentni obliki, potem se avtomatsko vzame,
     da je to necelo stevilo. */



    /* PARSING FACILITIES */



void cutstringtowords(char *str,char *separators,stack words);
    /* Finds words in string str and put dynamically allocated words to the
	  stack st. If st already contains some elements, these are not deleted.
    $A Igor apr04; */











                         /**************/
                         /*            */
                         /*   MACROS   */
                         /*            */
                         /**************/



/* macro m_disppointer(void p)
    Frees p and sets it to NULL.
    $A Igor jan03; */
#define m_disppointer(p) if (p!=NULL) free(p);  p=NULL;










#endif    /* (not defined) INCLUDED_strop */
