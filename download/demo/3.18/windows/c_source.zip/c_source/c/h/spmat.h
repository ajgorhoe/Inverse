

/* OPOMBE:
  Razprsene matrike in vektorji imajo dva rezima delovanja. Prvi je sinhroni
rezim, kjer so vse operacije nad indeksno tabelo in tabelo elementov hkratne,
v tem nacinu je stevilo alociranih mest za tabelo elementov vsaj taksno, kot
je polje r v indeksni tabeli, ki ustreza minimumu alociranega prostora za
tabelo indeksov). Drugi nacin dela je asinhroni nacin, v tem nacinu se
operacije nad indeksno tabelo izvajajo neodvisno od operacij nad tabelo
vrednosti (tipicen primer je zajemanje strukture togostne matrike pred
asembliranjem), temu pa obicajno sledi faza sinhronizacije, kjer se alocira
prostor za vrednosti, ki ustreza alociranemu prostoru v indeksni tabeli (ta
faza mora biti izvedena pred prirejanjem elementov). Pri razprsenih matrikah se 
lahko tabela info uporabi za shranjevanje informacije o tem, koliko mest je
rezervirano pri posameznih vrsticah matrike za vrednosti elementov, kar omogoca
hitrejso sinhronizacijo.
  V splosnem je tam, kjer se vsakic sproti ugotavlja struktura matrike (t.j.
struktura matrike se spreminja ali pa matriko med ponovnimi sestavljanji
brisemo, da prihranimo cas), bolj ugodno uporabiti asinhroni rezim pri
ugotavljanju strukture, pri nadaljnjih operacijah pa sinhronega.
  Funkcije za asinhroni rezim delovanja imajo navadno v imenu besedico tab.
Pri vseh sinhronih operacijah se pricakuje, da so elementi razprsenih
vektorjev sortirani po narascajocem vrstnem redu indeksov (t.j. mest v polnem
vektorju).
*/



/* DEFINICIJE TIPOV: */






typedef struct{
    indtab it;
    double *v;
} _spvec;

typedef _spvec *spvec;


typedef struct{
  int d1,d2;
  spvec *m;
  /* indtab info; */
} _spmat;

typedef _spmat *spmat;



typedef struct{
  int d1,d2,  /* matrix dimendions */
  r,          /* number of reserved elements in the buffer */
  ex;         /* excess at reallocation */
  int *l,     /* table of addresses of rows */
      *n,     /* table of numbers of elements in rows */
      *i;     /* table of indices of line elements */
  double *m;  /* table of values */
} _smat;

typedef _smat *smat;





            /******************************************/
            /*                                        */
            /*   OPERACIJE NAD RAZPRSENIMI VEKTORJI   */
            /*                                        */
            /******************************************/



spvec getspvec(int excess,int r);
    /* Naredi razprsen vektor, pripravljen za polnjenje indeksne tabele in
    elementov. excess je parameter, ki se zapise v polje ex indeksne tabele
    (t.j. presezek mest pri realokaciji), r pa je stevilo mest v indeksni
    tabeli in v tabeli vrednosti, ki se alocirajo ob klicu funkcije.
    $A Igor avg00; */

spvec getspvectab(int excess,int r);
    /* Naredi razprsen vektor, pripravljen za polnjenje indeksne tabele, t.j.
    brez alociranega prostora za vrednosti elementov, in vrne njegov kazalec.
    excess je parameter, ki se zapise v polje ex indeksne tabele (t.j. presezek
    mest pri realokaciji), r pa je stevilo mest v indeksni tabeli, ki se
    alocirajo ob klicu funkcije.
    $A Igor avg00; */

void syncspvectab(spvec vec);
    /* Po potrebi realocira tabelo vrednosti vec->v, tako da je za tabelo
    vrednosti alociranih enako stevilo mest kot za tabelo indeksov (torej
    vec->it->r). SLABOST uporabe te funkcije je v tem, da se lahko vec->v
    realocira po nepotrebnem, saj funkcija ne more vedeti, ce ni morda za
    tabelo ze alociranih dovolj mest.
    $A Igor avg00; */

void dispspvec(spvec *vec);
    /* Zbrise razprseni vektor *vec in ga postavi na NULL.
    $A Igor avg00; */

void resizespvec(spvec *pvec,int ex,int r,int n);
    /* Po potrebi popravi velikost alociranega prostora v razprsenem vektorju
    *pvec. Ce je r vecji od 0, se poskrbi, da je alociranega prostora natancno
    za r elementov. Ce je v tem primeru n vecji od r, se najprej r postavi na
    n. Ce je n vecji od 0, se stevilo elementov (*pvec)->it->n postavi na n, po
    potrebi se poveca stevilo alociranih mest (ce jih je manj kot n), se pa to
    ne zmanjsa. Ce je n enak 0, se stevilo elementov spremeni (zmanjsa) le, ce
    postane stevilo alociranih mest manjse od stavila elementov - v tem primeru
    se stevilo elementov postavi na stevilo alociranih mest. Ce je ex vecji od
    0, se (*pvec)->it->ex postavi na ex.
      Razlicne moznosti so:
    n>0, r=0: Stevilo elementov se postavi na n, stevilo alociranih mest se
      poveca, ce je to potrebno (ce je trenutno manj kot n), v nobenem primeru
      pa se ne zmanjsa.
    n>0, r>0: Stevilo elementov se postavi na n, stevilo alociranih mest pa na
      r (torej se po potrebi spremeni). Ce bi bil r<n, se r najprej postavi na
      n.
    n=0, r>0: Stevilo alociranih mest se postavi na r. Stevilo elementov se po
      potrebi zmanjsa (ce je vecje od r, se postavi na r).
    n=0,r=0: Stevilo elementov postane 0, v nobenem primeru se ne spremeni
      stevilo alociranih mest.
    $A Igor avg00; */

void redspvecsize(spvec vec);
    /* Zmanjsa stevilo alociranih mest na stevilo elementov, ce je le-to
    vec kot za vec->it->ex vecje od stevila elementov vec->it->n (redukcija
    aloc. prostora).
    $A Igor avg00; */

void minspvecsize(spvec vec);
    /* Zmanjsa stevilo alociranih mest na stevilo elementov, ce je le-to
    vecje od stevila elementov vec->it->n (minimizacija aloc. prostora).
    $A Igor avg00; */

spvec copyspvec(spvec v1,spvec *v2);
    /* Vrne kopijo razprsenega vektorja v1. Ce je v2 razlicen od NULL,
    skopira vektor v1 v vektor *v2 in vrne *v2.
      OPOMBA:
    Ce *v2 ze obstaja, potem ima kopija v1 za najvec ex presezka alociranih
    mest, ceprav bi bil presezek vecji, ce ne bi bilo realokacije (funkcija
    torej izvede avtomatsko ciscenje odvecnih mest nad kopijo).
    $A Igor avg00; */

void printspvec(spvec vec);
    /* Izpise podatke o razprsenem vektorju vec. Elemente izpise v stolpcu.
    $A Igor avg00; */

void printspvecline(spvec vec);
    /* Izpise podatke o razprsenem vektorju vec. Elemente izpise v vrstici.
    $A Igor avg00; */

void printspvectab(spvec vec);
    /* Izpise podatke o razprsenem vektorju vec, s tem da se izpise samo
    indekse indeksne tabele, ne pa vrednosti elementov. Funkcija se uporablja
    v primeru, ko je mozno, da tabela elementov ni alocirana. Elemente izpise v
    stolpcu.
    $A Igor avg00; */

void printspvectabline(spvec vec);
    /* Izpise podatke o razprsenem vektorju vec, s tem da se izpise samo
    indekse indeksne tabele, ne pa vrednosti elementov (funkcija se uporablja
    v asinhronem rezimu dela). Elemente izpise v vrstici.
    $A Igor avg00; */

void printspvectablinesimp(spvec vec);
    /* Izpise podatke o razprsenem vektorju vec, s tem da se izpise samo
    indekse indeksne tabele, ne pa vrednosti elementov (funkcija se uporablja
    v asinhronem rezimu dela). Indekse izpise v vrstici in brez zaporednih
    stevilk.
    $A Igor avg00; */

void insspvec(spvec vec,int el,double val,int place);
    /* V razprsenem vektorju vec vrine element z indeksom el in vrednostjo val
    na mesto place. Ce je place vecji od vec->it->n+1, se element vrine na
    zadnje mesto. Funkcija deluje v sinhronem rezimu in pricakuje, da je za
    vec->v vsaj toliko alociranih mest, kot je vec->it->r.
    $A Igor avg00; */

int delspvec(spvec vec,int place);
    /* Z razprsenega vektorja vec zbrise element (z ustreznim indeksom vred),
    ki je na mestu place. Vrzel se zapolni tako, da se indeksi in ustrezni
    elementi za zbrisanim elementom pomaknejo za eno mesto naprej. Ce tako
    nastane presezek alociranega spomina za vec kot 2*vec->it->ex, se spomin
    realocira tako, da ostane presezek samo vec->it->ex. Funkcija vrne indeks
    elementa, ki je bil zbrisan.
    $A Igor avg00; */

int delspvecsimp(spvec vec,int place);
    /* Z razprsenega vektorja vec zbrise element (z ustreznim indeksom vred),
    ki je na mestu place. Vrzel se zapolni tako, da se indeksi in ustrezni
    elementi za zbrisanim elementom pomaknejo za eno mesto naprej. Funkcija
    NE RAALOCIRA SPOMINA, ce je novo stevilo elementov ustrezno majhno!
    Funkcija vrne indeks elementa, ki je bil zbrisan.
    $A Igor avg00; */

double getspvecel(spvec vec,int el);
    /* Vrne element razprsenega vektorja vec z indeksom el. Ce v vektorju ni
    tega elementa, vrne 0.
    $A Igor avg00; */

double *getspvecaddr(spvec vec,int el);
    /* Vrne naslov elementa razprsenega vektorja vec z indeksom el. Ce v
    vektorju ni tega elementa, vrne NULL.
    $A Igor avg00; */

double *getspvecaddrins(spvec vec,int el);
    /* Vrne naslov elementa razprsenega vektorja vec z indeksom el, pri cemer
    se element vrine, ce se ne obstaja v vektorju (v tem primeru se vrednost
    elementa postavi na 0).
    $A Igor avg00; */

int setspvecel(spvec vec,int el,double val);
    /* V razprsenem vektorju vec postavi element z indeksom el na vrednost val.
    Ce element z indeksom el ze obstaja, se samo ta element postavi na val,
    drugace pa se element vrine na novo. Funkcija vrne mesto, na katerem je
    postavljen element.
    $A Igor avg00; */

int delsspvecel(spvec vec,int el);
    /* Iz razprsenega vektorja vec odstrani element z indeksom el in vrne mesto
    tega elementa. Ce elementa ni v vektorju, vrne 0.
    $A Igor avg00; */

int delspvecelsimp(spvec vec,int el);
    /* Iz razprsenega vektorja vec odstrani element z indeksom el in vrne mesto
    tega elementa. Ce elementa ni v vektorju, vrne 0. Funkcija v nobenem
    primeru NE IZVRSI REALOKACIJE spomina.
    $A Igor avg00; */






           /*******************************************/
           /*                                         */
           /*   OPERACIJE NAD RAZPRSENIMI MATRIKAMI   */
           /*                                         */
           /*******************************************/


matrix randmatsp0(int d1,int d2,int which,int num,double par1,double par2,
       matrix *m);
    /* Naredi in vrne matriko z nakljucnimi elementi, ki ima na veliko mestih
    nicelne elementa. d1 in d2 sta dimenziji matrike, par1 in par2 sta
    parametra verjet. porazdelitve (npr. pri Gaussovi), which doloca, kaksne
    vrste je matrika (npr. simetricna/nesimetricna) in po kaksni porazdelitvi
    so porazdeljeni elementi, num pa doloca zapolnjenost matrike (navadno kar
    stevilo nenicelnih elementov v vsaki vrstici). Ce je d2 0, postane d2 enak
    d1 (kvadratna matrika), ce pa sta d2 in d1 enaka 0, postaneta dimenziji
    matrike *m, ce je ta razlicna od NULL. Zaenkrat so implementirane naslednje
    moznosti glede na vrednosti argumenta which:
    OBVEZNO NENICELNI ELEMENTI NA DIAGONALI, NESIM. MATRIKA:
     0,1: enakomer. porazdelitev med 0 in 1
     2:   enakomer. porazdelitev med par1 in par2
     3:   enakomer. porazdelitev med -par1 in par1
    OBVEZNO NENICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI IZ
    NESIMETRICNE (zaradi enakomerno nepolne strukture zadnjih vrstic):
     10,11: enakomer. porazdelitev med 0 in 1
     12:   enakomer. porazdelitev med par1 in par2
     13:   enakomer. porazdelitev med -par1 in par1
    OBVEZNO NENICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI
    DIREKTNO (zaradi cesar so zadnje vrstice in stolpci bolj polni) - POZOR:
    tu se elementi priblizno podvajajo, kar je potrebno upostevati pri
    parametru num:
     20,21: enakomer. porazdelitev med 0 in 1
     22:   enakomer. porazdelitev med par1 in par2
     23:   enakomer. porazdelitev med -par1 in par1
    DOVOLJENI NICELNI ELEMENTI NA DIAGONALI, NESIM. MATRIKA:
     50,51: enakomer. porazdelitev med 0 in 1
     52:   enakomer. porazdelitev med par1 in par2
     53:   enakomer. porazdelitev med -par1 in par1
    DOVOLJENI NICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI IZ
    NESIMETRICNE (zaradi nepolne strukture zadnjih vrstic):
     60,61: enakomer. porazdelitev med 0 in 1
     62:   enakomer. porazdelitev med par1 in par2
     63:   enakomer. porazdelitev med -par1 in par1
    DOVOLJENI NICELNI ELEMENTI NA DIAGONALI, SIMETRICNA MATRIKA, KI SE TVORI
    DIREKTNO (zaradi cesar so zadnje vrstice in stolpci bolj polni) - POZOR:
    tu se elementi priblizno podvajajo, kar je potrebno upostevati pri
    parametru num:
     70,71: enakomer. porazdelitev med 0 in 1
     72:   enakomer. porazdelitev med par1 in par2
     73:   enakomer. porazdelitev med -par1 in par1
    $A Igor avg00 */

void printmatrixsplinesimp(matrix m);
    /* Ipzise matriko m v zgosceni obliki, primerni za razprsene matrike.
    Po vrsticah izpise indekse nenicalnih elementov in njihove vrednosti.
    Funkcija se uporablja pretezno za testiranje operacij nad razprsenimi
    matrikami.
    $A Igor avg00; */

void printmatrixsptablinesimp(matrix m);
    /* Ipzise zasedenost matrike m v zgosceni obliki, primerni za razprsene
    matrike. Po vrsticah izpise indekse nenicelnih elementov.
    Funkcija se uporablja pretezno za testiranje operacij nad razprsenimi
    matrikami.
    $A Igor avg00; */

spmat getspmat(int d1,int d2,int ex,int r);
    /* Kreira in vrne razprseno matriko z dimenzijama d1 in d2, pri cemer
    alocira za vsako vrstico r mest in postavi na ex polje ex pri vrsticah (to
    polje pove, za koliko vec mest se alocira prostor ob realokaciji, ko
    zmanjka mest na razprsenih vektorjih, ki predstavljajo vrstice.
    $A Igor avg00; */

void dispspmat(spmat *pmat);
    /* Zbrise razprseno matriko *pmat in *pmat postavi na NULL.
    $A Igor avg00; */

void printspmat(spmat mat);
    /* Izpise razprseno matriko mat v dolgi obliki, elemente vrstic izpise v
    stolpcih.
    $A Igor avg00; */

void printspmatline(spmat mat);
    /* Izpise razprseno matriko mat, elemente vrstic izpise v vrsticah.
    $A Igor avg00; */

void printspmatfull(spmat mat);
    /* Izpise razprseno matriko mat, kot da bi bila to polna matrika Elemente
    vrstic izpise v stolpcih.
    $A Igor avg00; */

void printspmattab(spmat mat);
    /* Izpise zasedenost razprsene matrike mat v dolgi obliki, indekse
    elementov vrstic izpise v stolpcih.
    $A Igor avg00; */

void printspmattabline(spmat mat);
    /* Izpise zasedenost razprsene matrike mat v krajsi obliki, indekse
    elementov vrstic izpise v vrsticah.
    $A Igor avg00; */

void printspmattablinesimp(spmat mat);
    /* Izpise zasedenost razprsene matrike mat v najkrajsi obliki, indekse
    elementov vrstic izpise v v vrsticah in brez zaporednih stevilk.
    $A Igor avg00; */

spmat copyspmat(spmat m1,spmat *m2);
    /* Vrne kopijo razprsene matrike m1. Ce je m2 razlicen od NULL, skopira
    m1 v *m2 in vrne *m2.
      OPOMBA:
    Ce *m2 ze obstaja, potem ima kopija m1 za najvec ex presezka alociranih
    mest za katerokoli vrstico, ceprav bi bil presezek vecji, ce ne bi bilo
    realokacije (funkcija torej izvede avtomatsko ciscenje prevec odvecnih mest
    nad kopijo).
    $A Igor avg00; */

matrix copyspmattomatrix(spmat m1,matrix *m2);
    /* Razprseno matriko m1 skopira v polno matriko in jo vrne. Ce je m2
    razlicen od NULL, se m1 skopira v *m2 in se vrne *m2.
    $A Igor avg00; */

spmat copymatrixtospmat(matrix m1,spmat *m2,int ex);
    /* Polno matriko m1 skopira v razprseno matriko in jo vrne. Ce je m2
    razlicen od NULL, se m1 skopira v *m2 in se vrne *m2.
    $A Igor avg00; */

spmat copymatrixlowtospmat(matrix m1,spmat *m2,int ex);
    /* Spodnji trikotnik in diagonalo polne matrike m1 skopira v razprseno
    matriko in jo vrne. Ce je m2 razlicen od NULL, se spodnji del m1 skopira v
    *m2 in se vrne *m2.
    $A Igor sep00; */

spmat copymatrixuptospmat(matrix m1,spmat *m2,int ex);
    /* Zgornji trikotnik in diagonalo polne matrike m1 skopira v razprseno
    matriko in jo vrne. Ce je m2 razlicen od NULL, se zgornji del m1 skopira v
    *m2 in se vrne *m2.
    $A Igor sep00; */

void spmatprodvecplain(spmat m1,vector v2,vector res);
    /* V vektor res zapise produkt razprsene matrike m1 in vektorja v2.
    Funkcija ne kontrolira niti dimenzij niti tega, ce je prostor alociran.
    Vektor res ne sme biti isti kot v2.
    $A Igor avg00; */

vector spmatprodvec(spmat m1,vector v2,vector *v3);
    /* Vrne produkt razprsene matrike m1 in vektorja v2. Ce je v3 razlicen od
    NULL, zapise rezultat v *v3 in vrne *v3. v3 je lahko tudi naslov v2,
    funkcija v tem primeru poskrbi za to, da se najprej izracuna rezultat
    operacije in sele nato prepise operand.
     OPOMBA:
     Ce je v3 razlicen od NULL, se po navadi vektor, ki ga funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze v3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */

void spmattranspplain(spmat m,spmat res,indtab aux);
    /* Elementi razprsene matrike res postanejo elementi transponirane
    razprsene matrike m. Funkcija ne preverja dimenzij in obstoja matrik, zato
    morajo biti dimenzije kompatibilne. Ce je m kvadratna matrika, je lahko
    res ista matrika kot m. aux je pomozna indeksna tabela, ki mora imeti
    toliko alociranih mest, kot je 1. dimenzija m (t.j. m->d1).
    $A Igor jan00; */

spmat spmattransp(spmat m1,spmat *res,indtab *pit1);
    /* Vrne transponirano razprsene matrike m1. Ce je res razlicen od NULL,
    zapise rezultat v *res in vrne *res. res je lahko tudi naslov m1, funkcija
    v tem primeru poskrbi za to, da se najprej izracuna rezultat operacije in
    sele nato prepise operand.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */



            /***************************************/
            /*                                     */
            /*   DEKOMPOZICIJE RAZPRSENIH MATRIK   */
            /*                                     */
            /***************************************/



int spLDLTdecomplowrow(spmat m);
    /* Izvede LDLT dekompozicijo simetricne razprsene matrike m, v kateri je
    shranjen samo spodnji trikotnik. Elementi L in D se zapisejo v m, tako da
    se originalna matrika unici.
    $A Igor sep00; */

