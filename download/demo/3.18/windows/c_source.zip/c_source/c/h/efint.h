#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>



/* Izris koncnih elementov  */

typedef struct{
        int i;          /* Stevilka vozlisca */
        double x,y,z;   /* Koordinate vozlisca */
        } _nodcoord;

typedef _nodcoord *nodcoord;


typedef struct{
        int i,
        x,y,z;
        } _nodconstr;

typedef _nodconstr *nodconstr;


typedef struct{
   int gn;           /* Stevilka skupine elementov */
   char *eltype;     /* Tip elementov */
   stack elements;   /* Sklad elementov z st. vozlisc */
}_eltopstruct;

typedef _eltopstruct *eltopstruct;


/* DEFINICIJE FUNKCIJ: */

long ffindbol(FILE *fp,long pos);
/*
   Funkcija v odprti datoteki na katero kaze kazalec fp
   najde pozicijo prvega znaka v vrstici, kjer se nahaja
   trenutna pozicija pos, steta od zacetka datoteke.
   $A Damjan apr97;
*/


int comparenodenumbers(void *p1,void *p2);
    /* Primerja vozlisci, ki sta zapisani v podatku tipa nodcoord, po zapored.
    stevilki. Funkcija vrne -1, ce je zap. stevilka vozlisca p1 manjsa od
    zaporedne stevilke vozlisca p2, 0, ce sta koordinati enaki, drugace pa 1.
    */


long copyfilepart(FILE *fp1,long from,long to,FILE *fp2,int bufsize);
    /* Iz datoteke fp1 skopira del od byta from do vkljucno byta to (steti se
    zacne z 1) na datoteko fp2. Zapis na datoteko fp2 se zacne pri trenutni
    poziciji v tej datoteki. Bufsize je velikost pomoznega pomnilnika.
      Funkcija vrne stevilo uspesno prenesenih bytov.
      Ce je to enak 0, postane enak dolzini datoteke. */


stack createimage(stack list,stack reference);
      /* Vrne sklad, na katerega so nalozeni kazalci na vsa tista vozlisca na
      skladu s2, ki so tudi na skladu s1. Ce je kateri od skladov prazen, je
      tudi rezultat funkcije prazen sklad in ce je kateri od skladov enak NULL,
      je taksen tudi rezultat. Na sklad, ki ga vrne fukcija, so nalozeni le
      kazalci na vozlisca na sklasu reference, prostor za zapis vozlisc se torej
      ne rezervira! */


stack createhardimage(stack list,stack reference,int size);
      /* Podobno kot createimage, le, da se ne skopirajo kazalci, ki so na
      skladu, ampak objekti, na katere ti kazalci kazejo. Zato funkcija rabi
      dodaten argument size, ki je velikost taksnega objekta v bytih. */


int ffindnodefield(char *keystr,FILE *fp,long from,long *first,long *last);
     /* V vhodni datoteki za program Elfen fp najde vozliscno polje, doloceno
     z nizom keystr (za vozliscne koordinate je to npr. "NODE COORDINATES", za
     predpisane pomike "PRESCRIBED DISP" itd.). Funkcija vrne zacetek
     polja v begin (1. znak za tistim \n ali \r, ki je v isti vrstici kot
     niz keystr) in konec v end (znak \n ali \r za zadnjim zapisom vozlisca).
     Funkcija vrne stevilo vozlisc, ki so zabelezena v polju.
     */


int fresfindnodefield(char *keystr,FILE *fp,long from,long *first,long *last);
     /* V datoteki rezultatov programa Elfen fp najde vozliscno polje, doloceno
     z nizom keystr (za vozliscne koordinate je to npr. "NODE COORDINATES", za
     predpisane pomike "PRESCRIBED DISP" itd.). Funkcija vrne zacetek
     polja v begin (1. znak za tistim \n ali \r, ki je v isti vrstici kot
     niz keystr) in konec v end (znak \n ali \r za zadnjim zapisom vozlisca).
     Funkcija vrne stevilo vozlisc, ki so zabelezena v polju.
     */


int freadnodefield(char *keystr,FILE *fp,long from,stack nod);
     /* Iz vhodne datoteke za program Elfen fp prebere vozliscno polje, doloceno
     z nizom keystr (za vozliscne koordinate je to npr. "NODE COORDINATES", za
     predpisane pomike "PRESCRIBED DISP" itd.) z njihovimi koordinatami
     in jih nalozi na sklad nod. Podatki o vozliscih so nalozeni v podatke tipa
     nodcoord.
     */


int fresreadnodefield(char *keystr,FILE *fp,long from,stack nod);
     /* Iz datoteke rezultatov za program Elfen fp prebere vozliscno polje, doloceno
     z nizom keystr (za vozliscne koordinate je to npr. "NODE COORDINATES", za
     predpisane pomike "PRESCRIBED DISP" itd. z njihovimi koordinatami
     in jih nalozi na sklad nod. Podatki o vozliscih se nalozijo v podatke tipa
     nodcoord.
     */


int freadnodecoords(FILE *fp,long from,stack nod);


int fresreadnodecoords(FILE *fp,long from,stack nod);


int freadnodeprescdisp(FILE *fp,long from,stack nod);


int fresreadnodeprescdisp(FILE *fp,long from,stack nod);


int fresnreadnodecoords(FILE *fp,int which,stack nod);
    /* Iz datoteke fp, ki je datoteka rezultatov direktne analize, prebere polje
    vozliscnih koordinat z zaporedno stevilko which glede na mesto v datoteki
    (ce je v datoteki vec polj, ki opisujejo predpisane pomike). */


int fnreadnodeprescdisp(FILE *fp,int which,stack nod);
    /* Iz datoteke fp, ki je vhodna datoteka za direktno analizo, prebere polje
    predpisanih pomikov z zaporedno stevilko which glede na mesto v datoteki
    (ce je v datoteki vec polj, ki opisujejo predpisane pomike). */


int fresnreadnodeprescdisp(FILE *fp,int which,stack nod);
    /* Iz datoteke fp, ki je datoteka rezultatov direktne analize, prebere polje
    predpisanih pomikov z zaporedno stevilko which glede na mesto v datoteki
    (ce je v datoteki vec polj, ki opisujejo predpisane pomike). */


void fwritenodecoords(FILE *fp,stack nodes,int dim);
     /* V datoteko fp izpise polje vozliscnih koordinat, nalozenih na sklad 
     nodes. Izpis se zacne pri trenutni poziciji v datoteki. dim je dimenzija
     polja, ki se izpise. */


int freadnodeconstr(FILE *fp,stack nod);
     /* Iz vhodne datoteke za program Elfen fp prebere 1. polje podpor vozlisc v
     datoteki in jih nalozi na sklad nod. Podatki o vozliscih se nalozijo v
     podatke tipa nodcoonstr.
     */


int fnreadnodeconstr(FILE *fp,int which,stack nod);
     /* Iz vhodne datoteke za program Elfen fp prebere polje podpor vozlisc z
     zapovrstno stevilko which; podatke nalozi na sklad nod in so tipa
     nodcoonstr.
     */


void fwritenodeconstr(FILE *fp,stack nodes,int dim);
     /* V datoteko fp zapise polje vozliscnih podpor, ki so nalozene na skladu
     nodes (podatki morajo biti tipa nodconstr). dim je dimenzija polja. */


int freadeltopstruct(FILE *fp,long from,eltopstruct elgroup);
/*
	Funkcija iz vhodne datoteke za analizo v programu ELFEN
	prebere prvo skupino elementov ter njihovih vozlisc, ki jih
	najde za mestom from. Stevilo skupine, njen tip in elemente
	nalozi  na strukturo tipa eltopstruct. Funkcija vrne stevilo
	elementov v skupini.
	$A Damjan apr97;
*/
