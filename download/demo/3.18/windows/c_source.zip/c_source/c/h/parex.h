

/* TIPI, KI SE UPORABLJAJO PRI PARALELNEM PROCESIRANJU: */

typedef struct
    {
      int id;   /* identifikacija v programu */
      int rank;    /* identifikacijska stevilka za sistem */
      char busy;   /* ce je 0, proces caka na ukaze */
      char work;   /* ce je 1, proces racuna po navodilu central. procesa */
      char dead;   /* ce je 1, je proces mrtev */
      char locked; /* ce je 1, je prozes zacasno izkljucen (mu je prepovedano
                      dajati dela) */
      int which;  /* pomozno stevilo za identifikacijo vhod. podatkov */
      void *inpdata;  /* kazalec na vhodne podatke */
      void *resdata;  /* kazalec na rezultate */
      double jobstart;  /* cas zacetka zadnjega dela */
      double lasttest;  /* cas zadnjega casovnega testa */
      stack testtimes;  /* testni casi */
      double lastwork; /* cas koncanja zadnjega posla */
      stack worktimes; /* casi potrebni za zaporedne posle */
    } _procdata;

typedef _procdata *procdata;


typedef struct
{
  int id;
  char flag;
  void *p;
  int proc;
  stack l,d,v,m;
} _jobdata;

typedef _jobdata *jobdata;

