
double funk(double x);

double odvod(double x,double *h,double funk(double));

/*   OBJEMIMIN   */
double objemimin(double *a, double *b, double *c,double funk(double));

/*   OZIM1D   */
void ozim1d(double *a, double *b, double *c, 
              double *fa, double *fb, double *fc,double funk(double));

/*   MIN1D   */
double min1d(double *a, double *b, double *c,
             double tolx, double toly,double funk(double));

/*   BRENT   */
void brent(double *a, double *b, double *c, 
           double *fa, double *fb, double *fc,
           double tol, int * it, int maxit, 
           double funk(double), int connection(int), FILE *fp);

/*   BRENTABS   */
void brentabs(double *a, double *b, double *c, 
           double *fa, double *fb, double *fc,
           double tol, int * it, int maxit, 
           double funk(double), int connection(int), FILE *fp);
/* Izolira minimum funkcije funk in ga vrne v b.
   a, b in c so zacetne abscise, biti mora fun(b)<funk(a),
   funk(b)<funk(c). fb je na izhodu vrednost funkcije v b.
   connection je funkcija, ki znotraj te funkcije
   izvede to, kar zahteva zunanje okolje. izvede se pred iterativno
   zanko s parametrom 0, na koncu vsake iteracije s parametrom
   1 in na koncu funkcije s parametrom 2. fp je datoteka, v katero
   se izpisujejo rezultati, it je stevilo iteracij, maxit pa je 
   najvecje dovoljeno stevilo iteracij.
   POZOR! Biti mora tol>0!
     Ta funkcija je podobna funkciji brent, le konvergencni kriterij je 
     drugacen. Konvergenca je dosezena, ko je najvecja absolutna vrednost
     razliki funkcijskih vrednosti manjsa ali enaka tol.
*/

/*   BRAKMIN   */
void brakmin(double *a, double *b, double *c,
             double *fa, double *fb, double *fc,
             int *it, int maxit,
             double funk(double), int connection(int), FILE *fp);
