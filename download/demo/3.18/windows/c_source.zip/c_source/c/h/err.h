
extern FILE *errf;
extern int errmode;

void marker(char *s,char c);
     /* Oznaci napako tako, da naredi datoteko, katere prvi znak imena je
     '%', nadaljevanje pa niz s. Ce se program prekine, preden je klicana
     funkcija deler z istim argumentom, datoteka s tem imenom ostane na disku.
     funkcija hkrati zapise znak c na konec datoteke, da se omogoci npr. stetje,
     kolikokrat je bil dolocen del programa izveden, preden je prislo do 
     prekinitve. */



void deler(char *s);
     /* Zbrise datoteko, ki jo je naredila funkcija marker z enakim nizom kot
     argumentom. */











































































