
/* The code that ensures at most one inclusion: */
#ifndef INCLUDED_sg_draw
#define INCLUDED_sg_draw

#ifndef INCLUDED_sysint
 #include <sysint.h>
#endif


      /*************************************/
      /*                                   */ 
      /*   SGS:                            */
      /*   BASIS FOR PLOTTING INTERFACES   */
      /*                                   */ 
      /*************************************/


/* Include the necessary headers if not already included: */
#ifndef INCLUSED_sg_obj
 #include <sg_obj.h>
#endif
#ifndef INCLUDED_stdarg
 #include <stdarg.h>
 #define INCLUDED_stdarg
#endif


/* Types of pre-installed graphic interfaces: */
#define SG_PLOT_DEFAULT    1
#define SG_PLOT_X          2
#define SG_PLOT_ITK        3
#define SG_PLOT_PS         4
#define SG_PLOT_TCL        5

#ifdef GRX
 #define SG_PLOT_BASIC SG_PLOT_X
#elif defined(ITK)
 #define SG_PLOT_BASIC SG_PLOT_ITK
#else
 #define SG_PLOT_BASIC SG_PLOT_DEFAULT
#endif

/* Definitions for arrow attributes: */
#define SG_ARROW_NOFILL 1
#define SG_ARROW_LINE 2
#define SG_ARROW_TRIANGLE 4

#define SG_ARROW_ABS 32






typedef struct
{
  int id;         /* ID number for SGS */
  int serial;     /* ID that is unique in a given application (since (...)->id
      can be re-used); usually set by nwwsg_window(). */
  int intfc;      /* ID of the plotting interface that created the window */
  void *intfcdata; /* Interface specific data (types defined in interfaces) */
  /* IS THIS NECESSARY (fields open and visible)? */
  char   open;    /* 0 if the window is not open */
  char   visible; /* 0 if the window is not visible - currently not used */

  int width,
      height;     /* Dimensions in pixels */
  char *title;    /* Window's title */
  
  /*
  char *tkid;
  char *forcewin;
  */
} _sg_window;

typedef _sg_window *sg_window;


typedef struct {
  int id;        /* identification number */
  int serial;     /* ID that is unique in a given application (since (...)->id
      can be re-used) usually set by nwwsg_font(). */
  char *family;  /* name of the font */
  char bold,italic,underline,overstrike;  /* attributes */
  stack intfcst; /* specific data for different interfaces */
} _sg_font;

typedef _sg_font *sg_font;




    /* GENERAL SETTINGS (used across plotting interfaces) */

extern int sg_interfaceid;       /* Active plotting interface ID */
extern char * sg_interfacename;  /* Name of the active interface */


/* Window handling options: */
extern char *sg_windowtitle;
extern int sg_MAXX,sg_MAXY;  /* Screen width and height */
/* Window positioning and size: */
extern float sg_windowxpos,sg_windowypos,
             sg_windowwidth,sg_windowheight;
extern int sg_iwindowxpos,sg_iwindowypos,
             sg_iwindowwidth,sg_iwindowheight;

/* Color handling options: */
extern char sg_coloring; /* Whether color or grayscale plotting is used */
extern int sg_numshades; /* Number of discrete accessible shades for color comp. */
extern int sg_numdiscretecolors;
extern int sg_indexsize; /* Size of color index tables */
extern int sg_numindices;
extern char sg_preindexall; /* If 1, all possible pixel colors are allocated
            at the initialization. */

/* Color settings: */
extern _truecolor sg_linecolor,
                  sg_fillcolor,
                  sg_textcolor;


/* Line, text and oter settings: */
extern int sg_ilinewidth;
extern double sg_linewidth;
extern int sg_linetype;

extern int sg_textxalignment,sg_textyalignment;
extern float sg_textheight;
extern int sg_itextheight;


/* Options for drawing points and curved object such as circle arcs: */
extern float sg_pointsize;
extern int sg_curvepoints,
         sg_markercurvepoints;


/* FONT and WINDOW stacks:
Each window belongs to a particular plotting interface. Fonts are valid for
all plotting interface, so each font has a stack on which for each plotting
interface there is an object (possibly NULL) that contains interface -
specific data (these objects are handled locally by plotting interfaces). */
extern stack sg_fonts,
       sg_windows;

extern int sg_currentfont;   /* Current font used */
extern int sg_currentwindow; /* Current window */




    /* AUXILIARY FUNCTIONS: */


  /* GENERAL AUXILIARY FUNCTIONS: */

int sg_screeninterface(int intfc);
    /* Returns 1 if the interface denoted by intfc is a screen interface and 0
    if not (e.g. it is a file plotting interface).
    $A Igor mar04; */


  /* CALCULATING COLOR SCALES: */

_truecolor sg_colorscalerainbow(double factor);
    /* Scale to color conversion that approximately corresponds to a rainbow.
    $A Igor oct03; */

_truecolor sg_colorscalerainbowlight(double factor);
    /* Light variant of sg_colorscalerainbow(), a combination of a 0.5 white and
    0.5 of what sg_colorscalerainbow() returns.
    $A Igor oct03; */

_truecolor sg_colorscalebas(double factor);
    /* Scale to color conversion that is suitable for contour plots. Factor
    must be in range [0,1], otherwise it is set to 0 or 1, respectively.
      The grey level of the returned color equals 1/3 for all values of
    factor while the maximum possible component is 1. Factor 0 corresponds to
    pure blue - RGB color (1,0,0), factor 0.5 corresponds to pure green (0,1,0)
    and factor 1 corresponds to pure red (1,0,0).
    $A Igor oct03; */

_truecolor sg_colorscalebaslight(double factor);
    /* Light variant of sg_colorscalebas(), a combination of a 0.5 white and
    0.5 of what sg_colorscalebas() returns.
    $A Igor oct03; */

_truecolor sg_colorscalecomp(double factor);
    /* Returns the color that is complementary to those returned by
    sg_colorscalebas, i.e. each color component is obtained as 1 minus the
    corresponding component returned by sg_colorscalebas(). The grey level of
    the produced colors is therefore 2/3 for all values of factor and the
    maximum possible component is 1.
    $A Igor oct03; */

_truecolor sg_colorscalecomplight(double factor);
    /* Light variant of sg_colorscalecomp(), a combination of a 0.4 white and
    0.6 of what sg_colorscalecomp() returns.
    $A Igor oct03; */

_truecolor sg_colorscalemix(double factor);
    /* Returns a color dependent on factor that is a proportional mixture of 
    what is obtained by sg_colorscalebas() and inverse of what is obtained by
    g_colorscalecomp() (i.e. what is obtained by g_colorscalecomp(1-factor)).
    The grey level of the returned colors therefore equals 1/2 and the maximum
    possible component is 1.
    $A Igor oct03; */

_truecolor sg_colorscalemixlight(double factor);
    /* Light variant of sg_colorscalemixinv(), a combination of a 0.5 white and
    0.5 of what sg_colorscalemixinv() returns.
    $A Igor oct03; */


  /* WINDOW AND FONT AUXILIARY FUNCTIONS: */

void sg_register_dispwin(void (*dispwindowdata) (void **));
    /* Installs the function for deletion of the interface specific window
    data on the structures of type sg_window. Argument may be NULL. This
    function should be called in the function for the activation of the
    plotting interface.
    $A Igor sep03; */

void sg_register_dispfont(void (*dispfontdata) (void **));
    /* Installs the function for deletion of the interface specific font
    data on the structures of type sg_font. Argument can be NULL. This
    function should be called in the function for the activation of the
    plotting interface.
    $A Igor sep03; */

sg_window newsg_window(void);
    /* Creates a new window structure and marks the current plotting interface
    (which created the window) on it, so that the function for deleting the
    interface specific data can be located later when the structure is deleted.
    Returns the pointer to the structure.
    $A Igo sep03; */

void dispsg_window(sg_window *addr);
    /* Deallocates all the window data contained in **addr and sets *addr to 
    NULL;
    $A Igor sep03; */

sg_font newsg_font(void);
    /* Creates a new font structure ans returns a pointer to this structure.
    $A igor sep03; */

void dispsg_font(sg_font *addr);
    /* Deallocates all the font data contained in **addr and sets *addr to 
    NULL;
    $A Igor sep03; */

void **sg_fontdataaddr(sg_font font);
    /* Returns the address of the interface specific data for the currently
    active plotting interface
    identified by id on the SGS font structure font. If there is no data for
    the plotting interface identified by id on font, then the data entry is
    created anew and the address of the pointer which will point to the
    interface specific data is returned (the pointer itself is NULL in this
    case).
      Function returns NULL only if font is NULL or if the active plotting
    interface is not defined.
    $A Igor sep03; */





    /* WINDOW (and graphic context) HNADLING: */

int sg_openwindow_default (void);
extern int (*sg_openwindow) (void);


int sg_setwindow_default(int id);
extern int (*sg_setwindow) (int id);

void sg_clearwindow_default(void);
extern void (*sg_clearwindow) (void);

void  sg_resetwindow_default(void);
extern void (*sg_resetwindow) (void);


extern void sg_closewindow_default(void);
extern void (*sg_closewindow) (void);


void sg_raisewindow_default(void);
extern void (*sg_raisewindow) (void);


int sg_installfont_default(char *family,char bold,char italic,char underline,
                           char overstrike);
extern int (*sg_installfont) (char *family,char bold,char italic,char underline,
                           char overstrike);

/* The following function is obsolate: */
void sg_installfontstr_default(int id,char *spec);
extern void (*sg_installfontstr) (int, char *);


void sg_setcoloring_default(int yes);
extern void (*sg_setcoloring) (int yes);


void sg_setnumshades_default(int num);
extern void (*sg_setnumshades) (int num);


void sg_colortabsize_default(int size);
extern void (*sg_colortabsize) (int size);


void sg_preindexcolors_default(int yes);
extern void (*sg_preindexcolors) (int yes);


void sg_setwindowtitle_default(char *title);
extern void (*sg_setwindowtitle) (char *title);


char *sg_getwindowtitle_default(void);
extern char * (*sg_getwindowtitle) (void);


float sg_setwindowxpos_default(float z);
extern float (*sg_setwindowxpos) (float z);


float sg_getwindowxpos_default(void);
extern float (*sg_getwindowxpos) (void);

float sg_setwindowypos_default(float z);
extern float (*sg_setwindowypos) (float z);

float sg_getwindowypos_default(void);
extern float (*sg_getwindowypos) (void);

float sg_setwindowwidth_default(float z);
extern float (*sg_setwindowwidth) (float z);

float sg_getwindowwidth_default(void);
extern float (*sg_getwindowwidth) (void);

float sg_setwindowheight_default(float z);
extern float (*sg_setwindowheight) (float z);

float sg_getwindowheight_default(void);
extern float (*sg_getwindowheight) (void);

int sg_nsetwindowxpos_default(int z);
extern int (*sg_nsetwindowxpos) (int z);

int sg_ngetwindowxpos_default(void);
extern int (*sg_ngetwindowxpos) (void);

int sg_nsetwindowypos_default(int z);
extern int (*sg_nsetwindowypos) (int z);

int sg_ngetwindowypos_default(void);
extern int (*sg_ngetwindowypos) (void);

int sg_nsetwindowwidth_default(int z);
extern int (*sg_nsetwindowwidth) (int z);

int sg_ngetwindowwidth_default(void);
extern int (*sg_ngetwindowwidth) (void);

int sg_nsetwindowheight_default(int z);
extern int (*sg_nsetwindowheight) (int z);

int sg_ngetwindowheight_default(void);
extern int (*sg_ngetwindowheight) (void);

float sg_setpointsize_default(float size);
extern float (*sg_setpointsize) (float size);

float sg_getpointsize_default(void);
extern float (*sg_getpointsize) (void);

int sg_setcurvepoints_default(int num);
extern int (*sg_setcurvepoints) (int num);

int sg_getcurvepoints_default(void);
extern int (*sg_getcurvepoints) (void);


    /* SETTING COLORS: */

void sg_setlinecolor_default(float red,float green,float blue);
extern void (*sg_setlinecolor) (float red,float green,float blue);

void sg_getlinecolor_default(float *red,float *green,float *blue);
extern void (*sg_getlinecolor) (float *red,float *green,float *blue);

void sg_setfillcolor_default(float red,float green,float blue);
extern void (*sg_setfillcolor) (float red,float green,float blue);

void sg_getfillcolor_default(float *red,float *green,float *blue);
extern void (*sg_getfillcolor) (float *red,float *green,float *blue);

void sg_settextcolor_default(float red,float green,float blue);
extern void (*sg_settextcolor) (float red,float green,float blue);

void sg_gettextcolor_default(float *red,float *green,float *blue);
extern void (*sg_gettextcolor) (float *red,float *green,float *blue);


    /* LINE SETTINGS */

void sg_setlinewidth_default(double width);
extern void (*sg_setlinewidth) (double width);

double sg_getlinewidth_default(void);
extern double (*sg_getlinewidth) (void);

void sg_setlinetype_default(int type);
extern void (*sg_setlinetype) (int type);

int sg_getlinetype_default(void);
extern int (*sg_getlinetype) (void);


    /* TEXT SETTINGS: */


void sg_settextfont_default(int font);
extern void (*sg_settextfont) (int font);

int sg_gettextfont_default(void);
extern int (*sg_gettextfont) (void);

void sg_settextheight_default(float height);
extern void (*sg_settextheight) (float height);

float sg_gettextheight_default(void);
extern float (*sg_gettextheight) (void);

void sg_settextxalignment_default(int alignment);
extern void (*sg_settextxalignment) (int alignment);

int sg_gettextxalignment_default(void);
extern int (*sg_gettextxalignment) (void);

void sg_settextyalignment_default(int alignment);
extern void (*sg_settextyalignment) (int alignment);

int sg_gettextyalignment_default(void);
extern int (*sg_gettextyalignment) (void);

void sg_settextalignment_default(int xalignment,int yalignment);
extern void (*sg_settextalignment) (int xalignment,int yalignment);

void sg_gettextalignment_default(int *xalignment,int *yalignment);
extern void (*sg_gettextalignment) (int *xalignment,int *yalignment);





/* BASIC DRAWING FUNCTIONS: */

/* WARNING - For programmers:
Implemented should be also plotting with integer coordinates!
Implement calculation of fp coordinates from window coordinates and vice versa!
*/

void sg_line_default(float x1,float y1,float x2,float y2);
extern void (*sg_line) (float x1,float y1,float x2,float y2);

void sg_triangle_default(float x1,float y1,float x2,float y2,float x3,float y3);
extern void (*sg_triangle) (float x1,float y1,float x2,float y2,
                        float x3,float y3);

void sg_fourangle_default(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4);
extern void (*sg_fourangle) (float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4);

void sg_filltriangle_default(float x1,float y1,float x2,float y2,
                        float x3,float y3);
extern void (*sg_filltriangle) (float x1,float y1,float x2,float y2,
                        float x3,float y3);

void sg_fillfourangle_default(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4);
extern void (*sg_fillfourangle) (float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4);

void sg_text_default(char *str,float x1,float y1);
extern void (*sg_text) (char *str,float x1,float y1);




   /* BASIC GRAPHIC ELEMENTS THAT ARE DRAWN BY OTHER DRAWING FUNCTIONS: */


void sg_rectangle_default(float x1,float y1,float x2,float y2);
extern void (*sg_rectangle) (float x1,float y1,float x2,float y2);

void sg_circle_default(float x,float y,float r);
    /* Draws a circle with the center (x,y) and radius r composed of
    sg_curvepoints lines.
    $A Igor sep03; */


extern void (*sg_circle) (float x,float y,float r);


void sg_circlearc_default(float x,float y,float r,float fi1,float fi2);
    /* Draws a circle arc with the center (x,y), radius r and start and end
    angles fi1 and fi2. It composes the arc of lines in such a way that full
    angle would be composed of sg_curvepoints lines.
    $A Igor sep03; */

extern void (*sg_circlearc)(float x,float y,float r,float fi1,float fi2);


void sg_ellipse_default(float x,float y,float a,float b);
     /* Narise elipso iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri. */

extern void (*sg_ellipse) (float x,float y,float a,float b);



void sg_ellipsearc_default(float x,float y,float a,float b,float fi1,float fi2);
     /* Narise elipsin lok iz sg_curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri ter z zacetnim kotom fi1 in
     s koncnim kotom fi2. Koti so v radianih. */

extern void (*sg_ellipsearc)(float x,float y,float a,float b,float fi1,float fi2);



void sg_fillrectangle_default(float x1,float y1,float x2,float y2);
     /* Narise zapolnjen pravokotnik s protileznima ogliscema (x1,y1) in
     (x2,y2). */

extern void (*sg_fillrectangle)(float x1,float y1,float x2,float y2);


void sg_point_default(float x,float y);
     /* Narise tocko s koordinatami (x,y). Za barvo se uporalbja barva za
     polnjenje likov. */

extern void (*sg_point)(float x,float y);


void sg_fillcircle_default(float x,float y,float r);
     /* Narise zapolnjen krog s srediscem v (x,y) in polmerom r iz sg_curvepoints
     zapolnjenih trikotnikov. */

extern void (*sg_fillcircle)(float x,float y,float r);




void sg_fillcirclearc_default(float x,float y,float r,float fi1,float fi2);
     /* Narise zapolnjen krozni lok s srediscem (x,y), polmerom r ter zacetnim
     kotom fi1 in koncnim kotom fi2 zi sg_curvepoints zapolnjenih trikotnikov. Koti
     so v radianih. */

extern void (*sg_fillcirclearc) (float x,float y,float r,float fi1,float fi2);


void sg_fillellipse_default(float x,float y,float a,float b);
     /* Narise zapolnjeno elipso s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b iz sg_curvepoints zapolnjenih trikornikov. */

extern void (*sg_fillellipse)(float x,float y,float a,float b);


void sg_fillellipsearc_default(float x,float y,float a,float b,float fi1,float fi2);
     /* Narise zapolnjen elipsin lok s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b ter zacetnim kotom fi1 in koncnim fi2 iz sg_curvepoints
     zapolnjenih trikornikov. Koti so v radianih. */

extern void (*sg_fillellipsearc)(float x,float y,float a,float b,float fi1,float fi2);




/* FUNCTIONS FOR DRAWING MARKERS (=points): */


void sg_marker_default(float x,float y,float size,int kind);
    /* Draws a marker at (x,y) of a specified size and kind.
    $A Igor sep03; */

extern void (*sg_marker) (float x,float y,float size,int kind);


int sg_registermarker_default (void (*drawmarker) (float x,float y,float size));
    /* Registers a new function for drawing a marker and returns its ID by
    which it will be accessed (via the kind argument ar rhe call to sg_marker).
    $A Igor sep03; */

extern int (*sg_registermarker) (void (*drawmarker) (float x,float y,float size));


void sg_arrow_default(float x1,float y1,float x2,float y2,float size,
                      float tgangle,int attr);
  /* Draws an arrow from (x1,y2) to (x2,y2) with the size of the head size and
  the tangens of the half angle of the head tgangle. attr determine how the arrow
  head is plotted. It can be a bitwise orred combination of the flags
  SG_ARROW_NOFILL (the head is not filled), SG_ARROW_LINE (the head is outlined),
  SG_ARROW_TRIANGLE (transversal line is also plotted in the outline) and
  SG_ARROW_ABS (the head size is understood absolute, i.e. relative to the window
  size; if this flag is not 1 then the head size is taken relative to the arrow
  length).
  $A Igor sep03; */

extern void (*sg_arrow)(float x1,float y1,float x2,float y2,float size,
                        float tgangle,int attr);
            




    /* DRAWING STACKS (or better lists) OF GRAPHIC PRIMITIVES: */


void sg_godrawstack_default(stack st);
    /* Plots the stack st containing graphic primitives. Primitives are
    plotted in order of appearance.
    $A Igor sep03; */

extern void (*sg_godrawstack) (stack st);


    /* AUXILIARY UTILITIES: */


char *sg_obtainplotfile(char *extension);
    /* Returns a dynamically allocated name for the graphic file in which
    a file graphic interface will plot its output. This function is usually
    called in a function for opening a window. The name is created according
    to instructions posed by sg_setplotfile() of sg_setplotfileroot()
    or autonomously if no recommendations were set.
      The extension specifies which extension should be appended to the file
    name, but has no wffect if the name has been requested by a call to the
    sg_setplotfilename() function. If extension has been dynamically allocated,
    it should be deallocated after the call to this function.
    $A Igor sep03; */

void sg_setplotfile(char *filename);
    /* Sets the name for the graphic file that will be first open for output
    by any graphic interface. The copy of filename is created, therefore the
    caller must eventually deallocate filename after the call to this function.
      filename can be NULL, in this case the previous setting is cancelled.
    $A Igor sep03; */

void sg_setplotfileroot(char *root);
    /* Sets the name root for the graphic file that will be next open for
    output by any graphic interface. The copy of root is created, therefore the
    caller must eventually deallocate the string after the call to this
    function.
      After a call to this function root will be used for forming the name of
    the graphic output file by the function sg_obtainplotfile() whenever
    the complete name will not be explicitly instructed by a preceeding
    call to sg_setplotfile().
      root can be NULL, in this case the previous setting is cancelled.
    $A Igor sep03; */




    /* SWITCHING BETWEEN PLOTTING INTERFACES: */


void sg_initintbas(void);
    /* Performs the basic initialization for drawing interfaces. This function
    must be called at the beginning of each interface activation function.
    $A Igor sep03; */

int sg_interface(int id);
    /* Activates a specific drawing interface for SGS that is identified by
    id. id can be 0 (meaning the default interface) or any of the valid numbers
    that identify an interface. Macros such as SG_PLOT_X, SG_PLOT_ITK,
    SG_PLOT_PS and SG_PLOT_TCL can be used for the argument id.
      Retuns actual interface id (different than id if id is 0) or 0 if there
    is no interface identified by id.
    $A Igor sep03; */



int sg_registerinterface(void (*activate_interface) (void),char *name,int screen);
    /* Registeres a new interface. activate_interface is the function for
    activation and initialization of the interface, name is the name of the
    interface, and screen tells whether the interface draws on screen (1 for
    yes, 0 for no).
      A dynamic copy of name is made for use by SGS, which is available in the
    global variable sg_interfacename when the interface is active (while its
    ID is available in sg_interfaceid and the screen flah in sg_interfaceflag).
      This function RETURNS the interface ID that is assigned to this interface.
    This ID is used in all further references to the interface (e.g. after the
    call to this function, the interface will be activated by sg_interface(ID)).
    $A Igor sep03; */




    /* TESTING INTERFACES: */

void test_sg_intfc(int direct,int num,char *fileroot,int intfc1,...);
    /* Performs the test of SGS drawing interfaces by drawing the same things in a
    random way with all interfaces. The Current window settings are assumed when
    opening windows. fileroot is the first part of the name of the file in which
    graphics will be output in the case that file interfaces are also included in
    the test. intfc1, etc., are the IDs of interfaces that should be tested. There
    can be a variable number of these arguments, the list must be terminated by
    an argument whose value is less or equal 0 (and which may not be omitted). num
    is the number of repetions of the basic loop which plots one primitive of each 
    ind with each interface.
      direct determines whether a direct access of the ITK interpreter is used
    or the interpreter is accessed via the ITK server.
    $A Igor sep03; */


















#endif    /* (not defined) INCLUDED_sg_draw */





