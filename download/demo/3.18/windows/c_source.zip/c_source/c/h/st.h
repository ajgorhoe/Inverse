


             /*********************************/
             /*                               */
             /*    STACKS AND INDEX TABLES    */
             /*                               */
             /*********************************/



/* Koda, ki omogoca v kljucitev lint.h v headerjih (npr. fint.h), ne da bi
bilo treba skrbeti za to, ali ni pri vkljucitvi teh headerjev ze bil kakorkoli
vkljucen lint.h, ker se v lint.h to eksplicitno preverja preko definicije makra
INCLUDED_lint : */

#ifndef INCLUDED_st
#define INCLUDED_st


#ifndef INCLUDED_stdio  /* for definition of type FILE */
  #include <stdio.h>
  #define INCLUDED_stdio
#endif

typedef struct _stack {
    int n,r;   /* number of occupied / allocated places */
    int ex;    /* excess at reallocation */
    void **s;  /* table of pointers, counting STARTS WITH 1 */
} *stack;

/*
struct _stack *stack;
*/


typedef struct _indtab {
    int n,  /* num. of elements */
        r,  /* allocated space */
        ex, /* excess allowed in reallocation */
        *t; /* table of elements, counting STARTS WITH 1 */
} *indtab;

/*
typedef struct _indtab *indtab;
*/

typedef struct _membuf {
    int p,r;
    char *b;
        };

typedef struct _membuf *membuf;



stack newstack(int excess);
      /* alocira prostor za spremenljivko tipa _stack, spremenljivko 
      inicializira z vrednostjo excess in vrne kazalec nanjo. */

stack newstackr(int excess,int r);
    /* Alocira prostor za spremenljivko tipa _stack, pri cemer spremenljivko
    inicializira z vrednostjo excess in rezerviranim prostorom za r kazalcev,
    ki jih postavi na NULL, ter vrne kazalec na alociran prostor. Polje n na
    skladu postavi na 0.
    $A Igor nov00;  */

stack newstackrn(int excess,int r);
    /* Alocira prostor za spremenljivko tipa _stack, pri cemer spremenljivko
    inicializira z vrednostjo excess in rezerviranim prostorom za r kazalcev,
    ki jih postavi na NULL, ter vrne kazalec na alociran prostor. Polje n na
    skladu postavi kar na r.
    $A Igor nov00;  */

void resizestack(stack *addrst,int excess,int n,void (*disp)(void **));
    /* Resizes the stack *addrst so that it contains n elements after operation.
    excess is the value of st->ex; if it is less than 1 then it is set
    automatically according to n. n is the requested number of elements of the
    stack after the operation. disp is the function for deletion of stack
    elements, if it is NULL then simply dispppointer is used.
      Eventual redundant elements on the stack are deleted. If there are too
    few elements on the stack then NULL pointers are added. 
    $A Igor oct04; */

void dispstack(stack *st);
     /* Sprosti spomin za spremenljivko tipa stack*. Ce stack vsebuje tabelo
     kazalcev, sprosti najprej to tabelo.
     */

void dispstackval(stack st);
     /* Sprosti vse spominske lokacije, na katere kazejo elementi sklada st */

void dispstackvalspec(stack st,void (*disp) (void **));
    /* Zbrise vse elemente, na katere kazejo kazalci, nalozeni na sklad st,
    pri cemer se za brisanje posameznih elementov uporabi funkcija disp, ki
    vzame za argument naslov kazalca, ki kaze na element, ki ga je treba
    brisati. Ce je disp enak NULL, se elementi brisejo s funkcijo free().
    $A Igor avg97; */

void dispstackall(stack *st);
    /* Sprosti vse spominske lokacije, na katere kazejo elementi sklada *st,
    in zbrise sam sklad ter postavi *st na NULL. Za brisanje elementov sklada
    uporabi sistemsko funkcijo free().
    $A Igor nov00; */

void dispstackallspec(stack *st,void (*disp) (void **));
    /* Sprosti vse spominske lokacije, na katere kazejo elementi sklada *st,
    in zbrise sam sklad ter postavi *st na NULL. Za brisanje elementov sklada
    uporabi funkcijo disp(). Ce je disp enak NULL, se elementi brisejo s
    sistemsko funkcijo free().
    $A Igor nov00; */

void fprintstack(FILE *fp,stack st,void (*fprintel) (FILE *fp,void *el));
    /* Prints the stack st and its elements to the file fp. fprintel() is 
    called to print each individual element on the stack. If fprintel is NULL
    then elements are not printed, but 0 is printed for each element if it is
    NULL and 1 if it is not NULL.
    $A Igor mar05; */

void printstack(stack st,void (*fprintel) (FILE *fp,void *el));
    /* The same as fprintstack(), but prints to the standard output rather to
    a particular file.
    $A Igor mar05; */

void fprintstacklist(FILE *fp,stack st,void (*fprintel) (FILE *fp,void *el));
    /* Prints elements of stack st to file fp as a list of objects, listed in
    curly brackets { } and dliminated by commas. fprintel() is called to print
    each individual element on the stack.
    A single newline is printed after the last curly bracket.
    $A Igor mar05; */

void printstacklist(stack st,void (*fprintel) (FILE *fp,void *el));
    /* The same as fprintstacklist(), but prints to the standard output rather
    to a specified file.
    $A Igor mar05; */

void fprintstacklistline(FILE *fp,stack st,void (*fprintel) (FILE *fp,void *el));
    /* The same as fprintstacklist(), but it prints stack elements in a single
    line. Therefore, if function fprintel() does not add any newlines, then 
    output does not contain newlines.
    $A Igor mar05; */

void printstacklistline(stack st,void (*fprintel)(FILE *fp,void *el));
    /* The same as fprintstacklistline(), but prints to the standard output
    rather to a specified file.
    $A Igor mar05; */

int sizestack0(stack st);
    /* Returns the size of the memory occupied by st without its elements.
    $A Igor nov03; */

int sizestack(stack st,int sizeel(void *));
    /* Returns the size of the memory occupied by st including its elements.
    sizeel must be a function that calculates and returns a size of an
    individual element.
    $A Igor nov03; */

stack copystack(stack st1,stack *st2);
    /* Copies the stack st1 to *st2 and returns the pointer to the copy. If
    st2==NULL then a copy of st1 is created anew and its pointer returned.
      WARNING!
      The elements of the stack are copied by simply copying their pointers!
    Therefore, this function may not be used if *st2 contains any elements
    and pointers loaded on it are the only handles of these elements.
    $A Igor nov03; */

stack copystackspec(stack st1,stack *st2,void dispel(void **),
                    void *copyel (void *,void **) );
    /* Copies the stack st1 to *st2 and returns the pointer to the copy. If
    st2==NULL then a copy of st1 is created anew and its pointer returned.
      By dispel we must specify a function for deletion of eventual elements
    that existed on *st2, while with copyel we must specify the function for
    copying individual elements from the original stack st1 to the copy.
      WARNING!
      dispel and copyel should normally be different than NULL. If dispel or
    copyel are NULL, then these functions are simply not executed on those
    elements on which they should. Instead of copying elements, elements on
    the resulting stack are set to NULL. This may be useful in some cases
    (e.g. when the resulting stack exists but its elements are also stored
    somewhere else, so they should not be released here, and we don't want
    to copy elements, but just set elements on the resulting stack to NULL).
    $A Igor nov03; */

void pushstack(stack st, void *el);
     /* Doda element el na konec sklada. Ce je potrebno, predhodno razsiri 
     sklad. */

void insstack(stack st,void *el,int place);
     /* V skladu st vrine na mesto place element el. Ostali elementi se 
     pomaknejo za eno mesto navzgor. */

void * setstack(stack st,void *el,int place);
     /* Sets the element at position place on the stack st to el. If the stack
     contains less than place elements, NULL pointers are pushed to stack first
     until it contains  place elements. The function returns the element that
     was on the position place before its execution, so we can for example
     delete it. If the stack is NULL, the function just returns NULL.
     $A Igor sep03; */

void *popstack(stack st);
     /* Vzame zadnji element s stacka, hkrati pa vrne njegovo vrednost.
     Ce s tem postane velikost stacka za vec kot excess vecja od stevila 
     elementov v njem, se velikost skrci na trenutno stevilo elementov. 
     Ce je stack prazen, je vrnjena vrednost NULL. */

void *delstack(stack st,int place);
     /* v skladu st odstrani element place na mestu place. Poznejsi elementi se 
     pomaknejo za eno mesto navzdol. Funkcija vrne element (tipa void*!), ki je
     bil prej na mestu place. Z objektom, na katerega kaze ta element, se ne
     zgodi nic.*/

void npopstack(stack st,int n);
     /* S sklada pobere n elementov. Ne vrne nobene vrednosti. */

void popstackall(stack st);
     /* S sklada pobere vse elemente. Ne vrne nobene vrednosti. */

void *stackel(stack st,int n);
     /* Vrne n-ti zaporedni element na skladu st. Ce ni zahtevanega elementa,
     vrne NULL. Stetje se zacne z 1.
     $A Igor <== avg97; */

void *nstack(stack st, int n);
     /* Vrne n-ti element sklada st od zadaj naprej. Ce ni zahtevanega 
     elementa, vrne NULL. Stetje se zacne z 1.
     $A Igor <== avg97; */

int findstack(stack st,void *ptr,int from, int to,int cmp(void *p1,void *p2));
    /* Na skladu st najde 1. taksen kazalec med from in to, da je objekt, na 
    katerega kaze, enak objektu, na katerega kaze kazalec ptr. Kriterij za
    enakost je funkcija cmp, ki mora vrniti vrednost 0, ce sta objekta, na
    katera kazeta kazalca p1 in p2, enaka, ter katerokoli drugo vrednost, ce
    nista. funkcija vrne mesto, na katerem je ta kazalec. Ce taksnega mesta ne
    najde, vrne 0. 
      Ce je from enako 0, funkcija isce od 1. elementa sklada naprej, ce pa je
    to enoko 0, isce funkcija do zadnjega elementa slada.
    VAZNA OPOMBA: 1. argument, ki se nalozi funkciji cmp, je vedno ptr !!! Zato
    mora biti tudi funkcija cmp narejena tako, da vzame ptr kot 1. argument.
    */

void qsortstack0(stack st,int cmp(const void *p1,const void *p2));
     /* Sorts elements of the stack st in such a way that they are ordered in
     increasing order according to the function cmp. cmp must return -1 if the
     first argument (i.e. the object pointed to by this argument) is smaller 
     than the second, 0 if they are equal and 1 if the first element is larger
     than the second element.
       Function uses the standard function qsort.
     $A Igor jul05; */

void qsortstacklim0(stack st,int from,int to,
                    int cmp(const void *p1,const void *p2));
    /* Similar to qsortstack, except that it sorts only elements between
    from and to inclusively.
    $A Igor jul05; */

void qsortstack(stack st,int cmp(void *p1,void *p2));
     /* Funkcija presortira elemente sklada st tako, da si sledijo v
     narascajocem vrstnem redu. To je misljeno pravzaprav za objekte, na katere
     kazejo kazalci, ki so na tem skladu. Funkcija cmp mora biti taksna, da vrne
     -1, ce je element, na katerega kaze p1, manjsi od elementa, na katerega
     kaze p2, 0, ce sta enaka, drugace pa 1.
       Funkcija uporablja standardno funkcijo qsort, ki pa je namenjena za
     sortiranje tabel, v katerih so ze elementi, ki jih sortiramo, ne pa kazalci
     nanje. Zato funkcija qsortstack uporablja funkcijo comparefunction kot
     vmesnik. */

void qsortstacklim(stack st,int from,int to,int cmp(void *p1,void *p2));
    /* Similar to qsortstack, except that it sorts only elements between
    from and to inclusively.
    $A Igor apr04; */

int findsortstack(stack st,void *ptr,int from, int to,
                  int cmp(void *p1,void *p2));
    /* Na skladu st najde 1. taksen kazalec med from in to, da je objekt, na
    katerega kaze, enak objektu, na katerega kaze kazalec ptr. Kriterij za
    enakost je funkcija cmp, ki mora vrniti vrednost 0, ce sta objekta, na
    katera kazeta kazalca p1 in p2, enaka, negativno vrednost, ce je prvi
    objekt manjsi in pozitivno vrednost, ce je 1. objekt vecji.
    Funkcija vrne mesto, na katerem je ta kazalec. Ce taksnega mesta ne
    najde, vrne 0. Sklad st mora biti sortiran glede na funkcijo cmp v
    narascajocem vrstnem redu.
      Ce je from enako 0, funkcija isce od 1. elementa sklada naprej, ce pa je
    to enoko 0, isce funkcija do zadnjega elementa slada.
    VAZNA OPOMBA: 1. argument, ki se nalozi funkciji cmp, je vedno ptr !!!
    Zato mora biti tudi funkcija cmp narejena tako, da vzame ptr kot 1. arg.
    $A Igor dec97; */

void *ptrfindsortstack(stack st,void *ptr,int from, int to,
                       int cmp(void *p1,void *p2));
    /* Na skladu st najde 1. taksen kazalec med from in to, da je objekt, na
    katerega kaze, enak objektu, na katerega kaze kazalec ptr. Kriterij za
    enakost je funkcija cmp, ki mora vrniti vrednost 0, ce sta objekta, na
    katera kazeta kazalca p1 in p2, enaka, negativno vrednost, ce je prvi
    objekt manjsi in pozitivno vrednost, ce je 1. objekt vecji.
    Funkcija vrne ta kazalec. Ce ga ne najde, vrne NULL. Sklad st mora biti
    sortiran glede na funkcijo cmp v narascajocem vrstnem redu.
      Ce je from enako 0, funkcija isce od 1. elementa sklada naprej, ce pa je
    to enoko 0, isce funkcija do zadnjega elementa slada.
    VAZNA OPOMBA: 1. argument, ki se nalozi funkciji cmp, je vedno ptr !!!
    Zato mora biti tudi funkcija cmp narejena tako, da vzame ptr kot 1. arg.
    $A Igor dec97; */

int findsortstacklim(stack st,void *left,void *right,int from, int to,
                  int cmp(void *p1,void *p2));
    /* Vrne mesto, na katerem najde prvi element, ki je glede na primerjalno
    funkcijo cmp() med elementoma pleft in pright (oziroma je kateremu od teh
    elementov enak). Funkcija cmp mora biti taksna, da vrne stevilo manjse od
    0, ce je 1. argument manjsi, stevilo vecje od 0, ce je prvi argument vecji,
    in 0, ce sta enaka. Funkcija vrne 0, ce na skladu ne najde ustreznega
    argumenta. Obvezno mora biti pleft glede na cmp() manjsi ali enak pright,
    drugace vrne funkcija 0.
    $A Igor apr01; */

void *ptrfindsortstacklim(stack st,void *left,void *right,int from, int to,
                       int cmp(void *p1,void *p2));
    /* Na skladu st najde taksen kazalec med from in to, da je objekt, na
    katerega kaze, glede na funkcijo cmp() med objektoma, na katera kazeta
    primerjalna left in right. Vrne kazalec na najden objekt oz. NULL, ce
    objekta ne najde. Za iskanje uporabi funkcijo findsortstacklim().
    $A Igor apr01;; */

int placesortstackint(stack st,void *ptr,int from, int to,
                      int cmp(void *p1,void *p2));
    /* Na skladu st, ki mora biti urejen v narascajocem vrstnem redu, najde
    mesto, kamor spada po velikosti objekt, na katerega kaza ptr. Pri tem se
    obravnava le odsek sklada med from in to. Funkcija vrne to mesto. Ce je
    ptr manjsi od vseh elementov sklada (glede na funkcijo cmp), vrne funkcija
    vrednost 1, ce pa je vecji od vseh elementov, vrne st->n+1 (za ena vec
    kot je stevilo elementov na skladu). Ce je na skladu vec elementov, ki so
    glede na funkcijo cmp enaki ptr, vrne funkcija mesto prvega med njimi.
     Funkcija cmp mora biti taksna, da vrne 0, ce sta objekta, na kstea kazeta
    p1 in p2, po vlikosti enaka, manj kot 0, ce je 1. objekt manjsi, in vec
    kot kot 0, ce je 1. objekt vecji od drugega. Sklad st mora biti urejen
    po vleikosti glede na funkcijo cmp.
     Ce je from enak 0, je zacetek obmocja, ki se obravnava, 1, ce pa je to
     enak 0, je konec obmocja, ki se obravnava, enak st->n.
    $A Igor dec97; */

int placesortstack(stack st,void *ptr,int cmp(void *p1,void *p2));
    /* Na skladu st, ki mora biti urejen v narascajocem vrstnem redu, najde
    mesto, kamor spada po velikosti objekt, na katerega kaza ptr. Funkcija vrne
    to mesto. Ce je ptr manjsi od vseh elementov sklada (glede na funkcijo
    cmp), vrne funkcija vrednost 1, ce pa je vecji od vseh elementov, vrne
    st->n+1 (za ena vec kot je stevilo elementov na skladu). Ce je na skladu
    vec elementov, ki so glede na funkcijo cmp enaki ptr, vrne funkcija mesto
    prvega med njimi.
     Funkcija cmp mora biti taksna, da vrne 0, ce sta objekta, na kstea kazeta
    p1 in p2, po vlikosti enaka, manj kot 0, ce je 1. objekt manjsi, in vec
    kot kot 0, ce je 1. objekt vecji od drugega. Sklad st mora biti urejen
    po vleikosti glede na funkcijo cmp.
    $A Igor dec97;*/

int inssortstack(stack st,void *ptr,int cmp(void *p1,void *p2));
    /* Na sklad st, katerega elementi morajo biti sortirani v narascajocem
    vrstnem redu glede na funkcijo cmp, vrine element ptr tako, da sklad ostane
    sortiran. Funkcija vrne mesto na skladu, na katerega vrine element.
    $A Igor dec97; */




            /*************************/
            /*                       */
            /*    INDEKSNE TABELE    */
            /*                       */
            /*************************/


indtab newindtab(int excess,int r);
    /* Naredi in vrne indeksno tabelo z r alociranimi mesti in vrednostjo polja
    ex excess. Polje ex pove, koliksen presezek se alocira, ko postane alociran
    prostor premali.
    $A Igor avg00; */

indtab newindtabrn(int excess,int r);
    /* Allocates and returns a new index table with (...)->ex set to excess
    and with r elements, which are not initialized. Both (...)->r and (...)->n
    are set to r.
    $A Igor dec03; */

void dispindtab(indtab *it);
    /* Zbrise indeksno tabelo ind.
    $A Igor avg00; */

int sizeindtab(indtab it);
    /* Returns the total size of the memory, in bytes, occupied by it.
    $A Igor nov03; */

indtab copyindtab(indtab it1,indtab *it2);
    /* Vrne kopijo indeksne tabele it1. Ce je it2 razlicen od NULL, skopira
    indeksno tabelo it1 v *it2 in vrne *it2. Funkcija deluje po podobnem nacelu
    kot copyvector0().
    $A Igor avg01; */

stack copyindtabtostack(indtab it1,stack *st2);
    /* Vrne kopijo indeksne tabele it1 v obliki sklada, na katerem so indeksi
    nalozeni kot kazalci na tip int. Ce je it2 razlicen od NULL, skopira indeksno
    tabelo it1 v *it2 in vrne *it2. Funkcija deluje po podobnem nacelu kot
    copyvector0(). Pri skladu se tudi polje (...)->ex postavi na isto vrednost
    kot pri tabeli.
    $A Igor avg02; */

indtab copystacktoindtab(stack st1,indtab *it2);
    /* Vrne indeksno tabelo, ki je kopija sklada st1, na katerem so indeksi
    nalozeni kot kazalci na tip int. Ce je it2 razlicen od NULL, skopira
    indekse na skladu st1 v *it2 in vrne *it2. Funkcija deluje po podobnem nacelu
    kot copyvector0(). Pri indeksin tabeli se tudi polje (...)->ex postavi na isto
    vrednost kot pri skladu.
    $A Igor avg01; */

indtab resizeindtab(indtab *pit,int ex,int r,int n);
    /* Po potrebi popravi velikost alociranega prostora v indeksni tabeli
    *pit. Ce je r vecji od 0, se poskrbi, da je alociranega prostora natancno
    za r elementov. Ce je v tem primeru n vecji od r, se najprej r postavi na
    n. Ce je n vecji od 0, se stevilo elementov (*pit)->n postavi na n, po
    potrebi se poveca stevilo alociranih mest (ce jih je manj kot n), se pa to
    ne zmanjsa. Ce je n enak 0, se stevilo elementov spremeni (zmanjsa) le, ce
    postane stevilo alociranih mest manjse od stavila elementov - v tem primeru
    se stevilo elementov postavi na stevilo alociranih mest. Ce je ex vecji od
    0, se (*pvec)->it->ex postavi na ex.
      Razlicne moznosti so:
    n>0, r=0: Stevilo elementov se postavi na n, stevilo alociranih mest se
      poveca, ce je to potrebno (ce je trenutno manj kot n), v nobenem primeru
      pa se ne zmanjsa.
    n>0, r>0: Stevilo elementov se postavi na n, stevilo alociranih mest pa na
      r (torej se po potrebi spremeni). Ce bi bil r<n, se r najprej postavi na
      n.
    n=0, r>0: Stevilo alociranih mest se postavi na r. Stevilo elementov se po
      potrebi zmanjsa (ce je vecje od r, se postavi na r).
    n=0,r=0: Stevilo elementov postane 0, v nobenem primeru se ne spremeni
      stevilo alociranih mest.
      Funkcija vrne spremenjeno indeksno tabelo. Ce je pit NULL, potem se
    indeksna tabela naredi na novo in vrne.
    $A Igor avg00 nov03; */

void fprintindtab(FILE *fp,indtab it);
    /* Prints data about indec table it to file fp. Elements are printed 
    in a column.
    $A Igor mar05; */

void printindtab(indtab it);
    /* Prints data about indec table it to the standard output. Elements 
    are printed in a column.
    $A Igor mar05; */

void fprintindtabline(FILE *fp,indtab it);
    /* Prints data about index table it to the file fp. Elements are
    printed in a line.
    $A Igor mar05; */

void printindtabline(indtab it);
    /* Prints data about index table it to the standard output. Elements are
    printed in a line.
    $A Igor mar05; */

void fprintindtablinesimp(FILE *fp,indtab it);
    /* Prints data about index table it to the file fp. Elements are
    printed in a line and without sequential numbers.
    $A Igor mar05; */

void printindtablinesimp(indtab it);
    /* Prints data about index table it to thestandard output. Elements are
    printed in a line and without sequential numbers.
    $A Igor mar05; */

void fprintindtablist(FILE *fp,indtab it);
    /* Prints index table it to the file fp in a list form as used by 
    Mathematica.
    $A Igor mar05; */

void printindtablist(indtab it);
    /* Prints index table it to the standard output in a list form as used by 
    Mathematica.
    $A Igor mar05; */

void pushindtab(indtab it,int el);
    /* Doda indeks el na konec indeksne tabele. Ce je potrebno, predhodno
    poveca alociran prostor.
    $A Igor avg00; */

void insindtab(indtab it,int el,int place);
    /* V indeksni tabeli it vrine na mesto place element el. Ostali elementi se
    pomaknejo za eno mesto navzgor. Ce je place vecji od  it->n+1, se vrzeli
    zapolnijo s kazalci NULL.
    $A Igor avg00; */

int setindtab(indtab it,int val,int place);
     /* Sets the element at position place on the index table it to val. If the
     index table contains less than place elements, then zeros are pushed to the
     index table until it contains  place elements. The function returns the
     element that was on the position place before its execution. If the it is
     NULL, the function just returns 0.
     $A Igor sep03; */

int popindtab(indtab it);
    /* Pobere zadnji element z indeksne tabele it in ga vrne. Ce je alociranega
    spomina vec kot za 2*it->ex vec kot zasedenaga, se spomin realocira tako,
    da ostane it->ex prostih mest.
    $A Igor avg00; */

int delindtab(indtab it,int place);
    /* Z indeksne tabele it zbrise indeks na mestu place in ga vrne. Vrzel se
    zapolni tako, da se indeksi za zbrisanim pomaknejo za eno mesto naprej.
    Ce tako nastane presezek alociranega spomina za vec kot 2*it->ex, se spomin
    realocira tako, da ostane presezek samo it->ex.
    $A Igor avg00; */

int findindtab(indtab it, int ind,int from,int to);
    /* Najde prvi indeks, ki je enak ind, na indeksni tabeli it od masta from
    do mesta to, in vrne njegovo pozicijo. Ce indeksa ne najde, vrne 0. Ce je
    from 0, postane 1; ce je to 0 ali vecje od stevila elemntov tabele, postane
    enak stevilu elementov.
    $A Igor avg00; */

void mergesortindtab(indtab it);
    /* Sortira indekse na indeksni tabeli it po narascajocem vrstnem redu po
    metodi mergesort.
    $A Igor avg00; */

void qsortindtab(indtab it);
    /* Sortira indekse na indeksni tabeli it po narascajocem vrstnem redu po
    metodi quicksort.
    $A Igor avg00; */

void ordsortindtab(indtab it);
    /* Sortira indekse na indeksni tabeli it po narascajocem vrstnem redu.
    Metoda gre po vrsti po elementih tabele tako, da so vsi predhodnji elementi
    elementa v obdelavi ze sortirani. Potem se s primerjanjem elementa s
    prejsnjimi elementi od zadnjega proti prvemu ugotovi, kam ta element spada
    in se ga vrine na to mesto ter preskoci na naslednji element.
    POZOR! Metoda sortiranja ni najbolj efektivna.
    $A Igor avg00; */

void bubsortindtab(indtab it);
    /* Sortira indekse na indeksni tabeli it po narascajocem vrstnem redu z
    metodo bubble sort.
    POZOR! Metoda sortiranja je ZELO POCASNA.
    $A Igor avg00; */

void sortindtab(indtab it);
    /* Sortira indekse na indeksni tabeli it po narascajocem vrstnem redu.
    $A Igor avg00; */

int findsortindtab(indtab it,int index,int from,int to);
    /* Poisce indeks index v sortirani indeksni tabeli it med from in to in
    vrne njegovo pozicijo oz. 0, ce indeksa ne najde. Ce je from 0, postane 1;
    ce je to 0 ali vecje od stevila elemntov tabele, postane enak stevilu
    elementov.
    $A Igor avg00; */

int placesortindtab(indtab it,int index,int from,int to);
    /* V sortirani indeksni tabeli it poisce in vrne mesto med from in to,
    kamor lahko vrine indeks index in vrne njegovo pozicijo oz. 0, ce taksnega
    mesta ne najde (kar je le v primeru, ce je it enak NULL). Ce je from 0,
    postane 1; ce je to 0 ali vecje od stevila elemntov tabele, postane enak
    stevilu elementov.
     POZOR: Ce je indeks index ze v tabeli indeksov med from in t, vrne njegovo
    mesto!!!
    $A Igor avg00; */

int inssortindtab(indtab it,int index,int from,int to);
    /* Vrine indeks index na pravo mesto v sortirani indeksni tabeli it med
    mestoma from in to. Funkcija vrne mesto, kamor se je vrinil indeks.
     POZOR: Pri uporabi te funkcije lahko dobimo vec enakih indeksov v tabeli,
     ker se indeks vrine tudi, ce ze obstaja v tabeli!
    $A avg00; */

int placesortindtabinfo(indtab it,int index,int from,int to);
    /* V sortirani indeksni tabeli it poisce med from in to mesto, kamor lahko
    vrine indeks index in vrne njegovo pozicijo, ce tega indeksa se ni v tem
    odseku tabele, minus pozicijo indeksa, ce indeks ze obstaja, ali 0, ce
    je it enak NULL. Ce je from 0, postane 1; ce je to 0 ali vecje od stevila
    elemntov tabele, postane enak stevilu elementov.
     POZOR: Ce je indeks index ze v tabeli indeksov med from in t, vrne njegovo
    mesto!!!
    $A Igor avg00; */

int inssortindtabun(indtab it,int index,int from,int to);
    /* Vrine indeks index na pravo mesto v sortirani indeksni tabeli it med
    mestoma from in to, ce indeks na tem odseku se NE OBSTAJA. Funkcija vrne
    mesto, kamor se je vrinil indeks, oziroma minus mesto, na katerem je ze
    indeks, oziroma 0, ce je kaj narobe.
      Pri uporabi te funkcije ne dobimo vec enakih indeksov v tabeli.
    $A avg00; */

int addindtabun(indtab it,int index,int from,int to);
    /* Doda indeks index na konec indeksne tabele it, ce ta indeks se ne
    obstaja v tabeli med mestoma from in to.
    $A Igor avg00; */


    /*  NAKLJUCNE INDEKSNE TABELE  */


void randindtabun(indtab it,indtab itsort,int from,int to,int n,char inc);
    /* Na indeksno tabelo it postavi n nakljucno izbranih indeksov z
    vrednostmi med from in to (vkljucno) v nakljucnem vrstnem redu, tako da
    so indeksi enolicni. Ce je med from in to manj kot n celih stevil, postavi
    na tabelo toliko indeksov, kot je mozno. Indeksna tabela indsort je pomozna
    indeksna tabela, s pomocjo katere funkcija zagotavlja enolicnost indeksov.
    Obe indeksni tabeli morata biti alocirani. Ce je inc razlicen od 0 (kar je
    PRIPOROCLJIVO), je dovoljeno poiskati nov indeks z inkrementiranjem ali
    dekrementiranjem od nakljucno izbranega naprej, ce ta ze obstaja v tabeli
    (v tem primeru se nakljucna generacija indeksa izvede le n-krat).
    $A Igor avg00; */

void randindtabsortun(indtab it,int from,int to,int n,char inc);
    /* Na indeksno tabelo it postavi n nakljucno izbranih sortiranih indeksov z
    vrednostmi med from in to (vkljucno) tako, da so indeksi enolicni. Ce je
    med from in to manj kot n celih stevil, postavi na tabelo toliko indeksov,
    kot je mozno. Indeksna tabela it mora biti ze alocirana, ni pa vazno, ali
    je na njej kaj elementov. Ce je inc razlicen od 0 (kar je PRIPOROCLJIVO),
    je dovoljeno poiskati nov indeks z inkrementiranjem ali dekrementiranjem od
    nakljucno izbranega naprej, ce ta ze obstaja v tabeli (v tem primeru se
    nakljucna generacija indeksa izvede le n-krat).
    $A Igor avg00; */




    /*  PODPORA ZA INDEKSIRANJE RAZPRSENIH MATRIK  */


void prepspmatindtab(stack *st,int dim1,int excess,int numalloc);
    /* Pripravi sklad indeksnih tabel, kamor se lahko zapisujejo indeksi
    zapolnjenih mest v razprseni matriki. Na sklad *st vrze indeksne tabele,
    ki so alocirane s poljem ex enakemu excess in imajo numalloc ze alociranih
    mest za indekse. Tiste indeksne tabele na skladu, ki so morebiti ze
    alocirane, pusti taksne kot so, samo polje ex postavi na excess. dim1 je
    stevilo vrstic matrike.
    $A Igor avg00; */ 

int setspmatindtabel(stack st,int line,int col);
    /* Na tabelo zapolnjenih mest razprsene matrike, ki jo predstavlja sklad
    st, vrine indeks novega elementa matrike, katerega vrstica je line in
    stolpec col. Funkcija vrne mesto v vrstici, na katero se je vrinil indeks
    stolpca, kot ga vrne funkcija addindtabun(). Ta funkcija generira
    tabelo, na kateri indeksi NISO SORTIRANI.
     POZOR: Funkcija ne preverja, ce je sklad alociran in ce ima pravilno
    stevilo elementov.
    $A Igor avg00; */

int setspmatindtabelsort(stack st,int line,int col);
    /* Na tabelo zapolnjenih mest razprsene matrike, ki jo predstavlja sklad
    st, vrine indeks novega elementa matrike, katerega vrstica je line in
    stolpec col. Funkcija vrne mesto v vrstici, na katero se je vrinil indeks
    stolpca, kot ga vrne funkcija inssortindtabun(). Ta funkcija generira
    tabelo, na kateri so indeksi SORTIRANI.
     POZOR: Funkcija ne preverja, ce je sklad alociran in ce ima pravilno
    stevilo elementov.
    $A Igor avg00; */

void sortspmatindtab(stack st);
    /* Sortira tabelo zapolnjenih mest razprsene matrike, ki jo predstavlja
    sklad st.
    $A Igor avg00; */

void printspmatindtab(stack st);
    /* Izpise tabelo zapolnjenih mest razprsene matrike, ki jo predstavlja
    sklad st. Funkcija ne preverja dimenzij.
    $A Igor avg00; */

void spmatindtabtoNASA(stack st,int *neq,int *nel,int **ptrs,int **cumptrs,
        int **indxs, double **coefs,double **diag);
    /* Glede na indeksno tabelo zapolnjenih mest razprsene matrike, ki je na
    st, po potrebi alocira in inicializira polja, ki so input za solver
    NASA. Ce so kazalci *ptrs, *cumptrs, *indxs, *coefs in *diag enaki
    NULL, se prostor zanje alocira. Ce je kateri od kazalcev nanje (npr. coefs)
    enak NULL, se ustrezno polje ignorira. V *eq mora biti pri klicu stevilo
    vrstic matrike, v *nel pa stevilo nenicelnih elementov (brez diagonalnih!).
    Ce se ta podatka ne ujemata z dejanskimi podatki, ki jih funkcija dobi s
    sklada st, se vsa polja na novo alocirajo, funkcija pa v *neq in
    *nel vrne prava podatka glede na strukturo na st. neq in nel ne smeta biti
    NULL! Funkcija tudi inicializira elementa polj coefs in diag!
    $A Igor avg00; */






            /****************************/
            /*                          */
            /*    SPOMINSKI BUFFERJI    */
            /*                          */
            /****************************/



membuf newmembuf(int r);
    /* Naredi in vrne spominski buffer, ki mu alocira spomina za r bytov. Ce je
    r manjsi ali enak 0, buffer nima alociranega spomina. polje p postavi na 0.
    $A Igor okt01; */ 

void dispmembuf(membuf *pb);
    /* Zbrise spominski buffer *pb in postavi *pb na NULL.
    $A Igor okt01; */

void resizemembuf(membuf buf,int r);
    /* Kolicino alociranega spomina v spominskem bufferju buf spremeni na r.
    Ce pozicija buf->p pade izven novega stevila alociranih mest, se postavi
    na 0. Vsebina alociranega spomina ostane ista v moznem obsegu.
    $A Igor okt01; */

void increasemembuf(membuf buf,int r);
    /* Ce ima buffer buf manj kot r bytov alociranega spomina, se alociran
    prostor poveca na r bytov, drugace pa se ne spremeni. Vsebina alociranega
    spomina ostane ista v moznem obsegu.
    $A Igor okt01; */

void decreasemembuf(membuf buf,int r);
    /* Ce ima buffer buf vec kot r bytov alociranega spomina, se alociran
    prostor zmanjsa na r bytov, drugace pa se ne spremeni. Vsebina alociranega
    spomina ostane ista v moznem obsegu.
    $A Igor okt01; */

void increasemembufex(membuf buf,int r,int ex);
    /* Ce ima buffer buf manj kot r bytov alociranega spomina, se alociran
    prostor poveca na r+ex bytov, drugace pa se ne spremeni. Vsebina alociranega
    spomina ostane ista v moznem obsegu.
    $A Igor okt01; */

void decreasemembufex(membuf buf,int r,int ex);
    /* Ce ima buffer buf vec kot r+2*ex bytov alociranega spomina, se alociran
    prostor zmanjsa na r bytov, drugace pa se ne spremeni. Vsebina alociranega
    spomina ostane ista v moznem obsegu.
    $A Igor okt01; */


            /*********************************/
            /*                               */
            /*    GLOBALNI POMOZNI BUFFER    */
            /*                               */
            /*********************************/


char *tmpstringbuf(void);
    /* Vrne alociran niz za zacasni spominski buffer z zagotovljeno dolzino
    50 znakov (to je definirano v makroju minglobbuf). Vrnjenega bufferja se ne 
    sme brisati ali realoci rati.
    $A Igor jan02; */

char *tmpstringbufmin(int minlength);
    /* Vrne alociran niz za zacasni spominski buffer in poskrbi, da je dolzina
    bufferja vsaj minlength. Vrnjenega bufferja se ne sme brisati ali realoci-
    rati.
    $A jan02; */

void decreasetmpstringbuf(int size);
    /* Poskrbi, da alocirana dolzina niza, ki se uporablja za zacasni buffer,
    ni vecja kot size.
    $A Igor jan02; */












#endif    /* (not defined) INCLUDED_st */
