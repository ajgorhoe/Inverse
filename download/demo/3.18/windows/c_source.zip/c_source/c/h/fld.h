



/* Koda, ki omogoca v kljucitev te datoteke v headerjih, ne da bi bilo treba
skrbeti za to, ali ni ta header ze bil kakorkoli vkljucen, ker se v to
eksplicitno preverja preko definicije ustreznega makra: */
#ifndef INCLUDED_fld
#define INCLUDED_fld


/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_st
#include <st.h>
#endif



typedef struct{
  int lin,col;
  stack st;
}_field;

typedef _field *field;




/* Definicije funkcij polja */


int fldgetoutdig(void);
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu fld.c.
    $A Igor mar99; */

int fldgetoutchar(void);
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu fld.c.
    $A Igor mar99; */

void fldsetoutdig(int num);
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu fld.c.
    $A Igor mar99; */

void fldsetoutchar(int num);
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu fld.c.
    $A Igor mar99; */

field getfield(int lin,int col);
    /* Rezervira prostor za polje z lin vrsticami in col stolpci ter vrne
    kazalec na ta prostor.Ce sta argumenta ob klicu enaka 0, funkcija ne
    alocira prostora za posamezne vektorje polja. */
    
void dispfield(field *fld);
    /* Zbrise polje *fld s celotno vsebino in njegovo vrednost postavi na NULL. */

field fieldcopy(field f);
    /* Vrne kopijo polja f. */
    
    
field copyfield(field f1,field *f2);
    /* Vrne kopijo polja f1. Ce je f2 razlicen od NULL, skopira polje f1 v
    *f2 in vrne *f2. */
    
    
field movefield(field *f1, field *f2);
    /* Premakne *f1 v *f2 in vrne *f2. Po izvedbi je vedno *f1==NULL. Ce je
    f2==NULL, samo vrne *f1 (ce je f1==NULL, vrne NULL). */    
    
    
void fprintfield(FILE *fp, field f);
     /* Izpise polje f v datoteko fp na standarden nacin. */



void printfield(field fld);
     /* Izpise polje f na standardni izhod. */


 
void fprintfieldline(FILE *fp,field fld);
    /* V datoteko fp zapise polje fld, pri cemer vrstice izpise v eni vrsti. */
    
    
void printfieldline(field fld);
    /* Na standardni izhod zapise polje fld, pri cemer vrstice izpise v eni vrsti. */


    
void fwritefieldcomp(FILE *fp, field f);
     /* Izpise komponente polja f v izhodno outfile datoteko fp. */
          
     
long ffindnthfield(FILE *fp,char *keystr,int n);
    /* Funkcija poisce zacetek polja z imenom keystr, ki je n-to po vrsti
    v datoteki fp. Funkcija vrne pozicijo zacetka imena iskanega polja. 
    Ce polja z imenom keystr ni, vrne -1.  */


long freadfieldheader(FILE *fp,char *fieldname,long from,int *lin,int *col);
    /* V datoteki fp najde polje z imenom fieldname od pozicije from naprej
    in prebere dimenzije polja (lin x col). Ce dimenzije ne najde postavi
    lin in col na 0. Funkcija vrne pozicijo zacetka bloka polja, ce pa polja
    z navedenim imenom ne najde vrne -1.
    $A Damjan maj98; */


long freadfieldcomp(FILE *fp,long pos,field *fld,int lin,int col);
    /* Iz datoteke fp prebere tabelo stevil (lin x col) od mesta
    pos naprej. Vektorje sestavljene iz stevil v vrsticah tabele nalozi
    na sklad st polja fld. Ce hocemo s funkcijo prebrati polje katerega
    stevila vrstic in stolpcev (lin, col) ne poznamo, postavimo argumenta
    lin in col pri klicu na 0. V tem primeru funkcija polje kreira na novo 
    (s funkcijo getfield(0,0)) in nanj nalaga vrstice polja, dokler ne naleti 
    na konec polja. V primeru napake pri branju dobi fld vrednost NULL. 
    Funkcija vrne pozicijo konca polja. V primeru napake vrne -1.
    $A Damjan maj98 jul98; */

     
long freaddatfield(FILE *fp,char *keystr,long pos,field *fld);
    /* Iz datoteke fp prebere prvo polje stevil oznaceno z imenom keystr 
    od pozicije pos naprej. Funkcija uposteva, da so podatki urejeni tako,
    kot v vhodni datoteki tipa *.dat za program ELFEN. Podatke nalozi na 
    strukturo tipa field s funkcijo freadfieldcomp. 
    Funkcija vrne pozicijo konca polja. V primeru napake vrne -1.
    $A Damjan jul98; */
    
        
long freadneufield(FILE *fp,char *keystr,long from,field *fld);
    /* Iz datoteke fp prebere prvo polje stevil od pozicije from naprej,
    ki je oznaceno z imenom keystr. Funkcija uposteva, da so podatki urejeni
    tako, kot v vhodni datoteki tipa *.neu in dimenzije tabele prebere iz 
    standardne definicije polja. Podatke nalozi na strukturo tipa field 
    s funkcijo freadfieldcomp. 
    Funkcija vrne pozicijo konca polja. V primeru napake vrne -1.
    $A Damjan maj98 jul98; */
    

long freadresfield(FILE *fp,char *keystr,long from,field *fld);
    /* Iz datoteke fp prebere prvo polje stevil z imenom keystr od pozicije
    from naprej. Funkcija uposteva da so podatki urejeni tako, kot v izhodni
    datoteki tipa *.res za program ELFEN. Podatke nalozi na strukturo tipa
    field s funkcijo freadfieldcomp. V primeru napake pri branju dobi polje fld
    vrednost NULL. Funkcija vrne pozicijo konca polja. V primeru napake vrne -1.
    $A Damjan maj98; */    


long freplacefield(field fld,FILE *fp,char *keystr,long from);
    /* Funkcija v navedeni datoteki fp najde prvo polje z imenom keystr 
    za pozicijo from in ga zamenja s poljem fld. Funkcija uposteva, da je
    format zapisa enak kot v datotekah tipa *.dat.
    $A Damjan jun98; */


double lagrange(double xx, vector x, vector y);
  /* Funcija izracuna vrednost Lagrangeovega interpolacijskega polinoma skozi
  tocke podanne z vektorjema koordinat x in y (x1,x2,..,xn) v tocki xx.
  $A Damjan sep98 */


int spline_sec_derivs(vector x,vector y, double yp1, double ypn, vector *y2);
  /* Funkcija izracuna vrednosti drugih odvodov zlepka interpolacijskih 
     polinomov 3. stopnje (splines) v interpolacijskih tockah (xi,yi), ki so 
     podane z vektorjema x in y (x1,x2,..,xn). Dodatni podatki so 
     vrednosti 1. odvodov v robnih tockah interpolacijskega intervala yp1 in 
     yp2. Vrednosti izracunanih 2. odvodov se shranijo v vektor y2. 
     Vrednosti 2. odvodov potrebujemo pri izracunu vrednosti inerpolacijske 
     funkcije, njenih 1. odvodov in integrala interpolacijske funkcije na 
     interpolacijskem intervalu.
     $A Damjan sep98
  */ 


double spline(double xx,vector x,vector y,vector y2);
  /*
  Funkcija vrne vrednost interpolacijske funkcije v tocki x, ki mora
  biti znotraj interpolacijskega intervala. Poleg koordinate x so vhodni 
  podatki se vektorja koordinat interpolacijskih tock x in y ter vektor drugih
  odvodov interpolacijske funkcije v tockah xi, ki jih dobimo s funkcijo 
  spline_sec_derivs. V primeru neustreznih vhodnih podatkov funkcija vrne 
  infinity().
  $A Damjan sep98
  */


double spline_integral(double xl,double xh,vector x,vector y,vector y2);
  /*
  Funkcija vrne velikost dolocenega integrala interpolacijske funkcije z 
  mejama x1 in x2, morata biti vsebovani v interpolacijskem intervalu. 
  Vhodni podatki so meji intervalov x1 in x2 ter vektorja koordinat
  interpolacijskih tock x in y ter vektor drugih odvodov interpolacijske
  funkcije, ki jih dobimo s funkcijo spline_sec_derivs.
  $A Damjan sep98 nov98
  */


double spline_deriv(double xx,vector x,vector y,vector y2);
  /*
  Funkcija vrne prvi odvod interpolacijske funkcije v tocki x na 
  interpolacijskem intervalu. Poleg koordinate x so vhodni podatki se 
  vektorja koordinat interpolacijskih tock in vektor drugih odvodov,
  interpolacijske funkcije ki jih dobimo s funkcijo spline_sec_derivs.
  V primeru neustreznih vhodnih podatkov funkcija vrne -infinity().
  $A Damjan sep 98
  */


int file_get_group_nodes_vector(FILE *fp,long from,vector *vec);
  /* Funkcija v vhodni datoteki za analizo fp (tip *.neu) poisce prvo skupino
  elementov z imenom "Element_topology" od pozicije from naprej in vsa vozlisca,
  ki sestavljajo to skupino elementov nalozi na vektorsko spremenljivko *vec.
  Ce je operacija uspesna funkcija vrne stevilo vozlisc, ce pa pride do 
  napake vrne -1, vektor vec pa dobi vrednost NULL. Datotecni kazalec se po 
  uspesnem klicu funkcije postavi na mesto za oklepajem, ki oznacuje konec
  polja elementov, sicer pa se postavi na zacetek datoteke. 
  $A Damjan sep98; */


int file_get_slideline_nodes_vector(FILE *fp,long from,vector *vec);
    /*  Funkcija prebere vozlisca v prvem polju z imenom 
       "Nodal_pointers_for_segments" za pozicijo from in 
        jih nalozi na vektorsko spremenljivko *vec.
        $A Damjan nov98
    */


int transform_coords(vector nodes,field *coords,vector xtransvec,
                       vector ytransvec,vector secder,double ex,int side);
  /* Funkcija transformira koordinate vozlisc, ki so shranjene v polju coords
  in nasteta po vrsti v vektorju nodes. Za pravilno delovanje funkcije mora 
  biti zacetna oblika skupine nastetih vozlisc pravokotnik s stranicami 
  vzporednimi koordinatnim osem. Transformacijsko funcijo dolocajo koordinate 
  transformacijskih tock nastete v vektorjih xtransvec in ytransvec ter 
  korekcijski faktor ex. xi so koeficienti,ki dolocajo x koordinate 
  interpolacijskih tock in imajo lahko vrednost med [0,1]. yi so koeficienti, 
  ki dolocajo vrednost transformiranih koordinat zgornjega roba in imajo lahko 
  vrednost [0,inf], oziroma v praksi so meje zaradi deformacij mreze manjse. 
  Skozi tako predpisane tocke funkcija povlece zlepek polinomov 3. reda 
  (splines). Navesti moramo se  vektor drugih odvodov zlepka. Spremenljivka 
  side doloca smer transformacije. (1:+x, 2:+y, 3:-x, 4:-y) Funkcija vrne 
  stevilo transformiranih koordinat, v primeru neuspesnega klica pa vrne -1.
  $A Damjan sep98 */





#endif    /* (not defined) INCLUDED_fld */

