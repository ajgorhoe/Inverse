
        /* REAL FUNCTIONS */


/* The code below implies that the content of this header is included only once: */
#ifndef INCLUDED_rf
#define INCLUDED_rf


#ifndef INCLUDED_math
 #include <math.h>
#endif
#ifndef INCLUDED_float
 #include <float.h>
#endif
#ifndef INCLUDED_limits
 #include <limits.h>
#endif


/* Printing accuracy and avoiding exponential notation; In code, macros
should be used! */
#define m_avoidexp rf_avoid_print_exp
#define m_outdig rf_printdigits_accuracy_definition
extern int rf_printdigits_accuracy_definition;
int rf_avoid_print_exp;


#define ConstPi  3.14159265358979323846
#define ConstE   2.7182818284590451
#define doubleinfinity (0.9*DBL_MAX)


double pi(void);
    /* Vrne razmerje med obsegom in premerom kroga. */

double infinity(void);
       /* + neskoncno */




    /* NAJMANJSE, NAJVECJE OD VEC (do 6) STEVIL: */

#define m_minval(x,y) ( (x)<=(y) ? (x) : (y) )
    /* manjse od stevil x in y */

#define m_maxval(x,y) ( (x)>=(y) ? (x) : (y) )
    /* vecje od stevil x in y */

#define m_minval3(x,y,z) m_minval(m_minval((x),(y)),(z))
    /* najmanjse od stevil x, y in z */

#define m_maxval3(x,y,z) m_maxval(m_maxval((x),(y)),(z))
    /* najvecje od stevil x, y in z */

#define m_minval4(a,b,c,d) m_minval(m_minval((a),(b)),m_minval((c),(d)))
    /* najmanjse od stevil a, b, c in d */

#define m_maxval4(a,b,c,d) m_maxval(m_maxval((a),(b)),m_maxval((c),(d)))
    /* najvecje od stevil a, b, c in d */

#define m_minval5(a,b,c,d,e) m_minval(m_minval((a),(b)),m_minval3((c),(d),(e)))
    /* najmanjse od stevil a, b, c, d in e */

#define m_maxval5(a,b,c,d,e) m_maxval(m_maxval((a),(b)),m_maxval3((c),(d),(e)))
    /* najvecje od stevil a, b, c, d in e */

#define m_minval6(a,b,c,d,e,f) m_minval(m_minval3((a),(b),(c)),m_minval3((d),(e),(f)))
    /* najmanjse od stevil a, b, c, d, e in f */

#define m_maxval6(a,b,c,d,e,f) m_maxval(m_maxval3((a),(b),(c)),m_maxval3((d),(e),(f)))
    /* najvecje od stevil a, b, c, d, e in f */



    /* PREDZNAK: */

#define m_sign(x) ( (x)<0 ? -1 : ((x)>0 ? 1 : 0) )
    /* -1, ce je x negativen, in 1, ce ni */
    
    


    /* LOGARITMI: */

#define ln(x)   (log(x))
    /* naravni logaritem */

#define lg(x) log10(x)
    /* desetiski algoritem */

#define logn(x,n) (log(x)/log(n))
    /* logaritem z osnovo n */



    /* KVADRAT IN KUB: */

#define m_sqr(x) ((x)*(x))
    /* kvadrat (2. potenca) */

#define m_cube(x) ((x)*(x)*(x))
    /* kub (3. potenca) */

#define m_cub(x) ((x)*(x)*(x))
    /* kub (3. potenca) */



    /* PRETVORBA MED RADIANI IN STOPINJAMI */

#define st(x) ((x)*180/ConstPi)
    /* pretvorba radianov v stopinje */

#define deg(x) ((x)*180/ConstPi)
    /* conversion of radians to degrees */

#define rad(x) ((x)*ConstPi/180)
    /* pretvorba radianov v stopinje */
    

    /* KOTNE FUNKCIJE: */

#define tg(x) tan(x)
    /* tangens */

#define ctg(x) (1/tan(x))
    /* kotangens */



    /* INVERZNE KOTNE (CIKLOMETRICNE) FUNKCIJE: */

#define arcsin(x) asin(x)
    /* arkus sinus */

#define arccos(x) acos(x)
    /* arkus kosinus */

#define arctg(x) atan(x)
    /* arkus tangens */

#define arcctg(x) ( (x)==0 ? 0.5*ConstPi : atan(1/(x))  )
    /* arkus kotangens */



    /* HIPERBOLICNE FUNKCIJE: */

#define ch(x)   cosh(x)
    /* hiperbolicni kosinus */

#define sh(x)   sinh(x)
    /* hiperbolicni kosinus */

#define th(x)   tanh(x)
    /* hiperbolicni tangebs */

#define cth(x)   (1/tanh(x))
    /* hiperbolicni kotangens */



    /* INVERZNE HIPERBOLICNE FUNKCIJE: */

#define arsh(x) ln( (x)+sqrt(m_sqr(x)+1) ) 
    /* inv. hip. sinus */

#define arch(x) ln( (x)+sqrt(m_sqr(x)-1) ) 
    /* inv. hip. kosinus */

#define arth(x) ( 0.5*ln( (1+(x))/(1-(x)) ) )
    /* inv. hip. tangens */

#define arcth(x) ( 0.5*ln( ((x)+1)/((x)-1) ) )
    /* inv. hip. kotangens */





    /* ZAOKROZEVANJE: */


double round(double x);
       /* Vrne x zaokrozen na celo vrednost */

double trunc(double x);
       /* Vrne x, kateremu odreze neceli del */

double frac(double x);
       /* vrne neceli del x */

double intpow(double x,int pow);
    /* Vrne celo potenco pow stevila x.
    $A Igor jul00; */



    /* FACTORIAL, BINOMIAL SYMBOLS, ... */


unsigned long factorialint0(int n);
    /* Returns the factorial of n (n!) calculated exactly.
    On overflow or if argument is less than 0, the function returns 0 but
    does not report an error.
    $A Ifor jul04; */

unsigned long factorialint(int n);
    /* The same as factorialint0, just that it reports an error in the case that
    n is less than 0 or in the case of overflow when the result can not be
    represented by an unsigned long.
    $A Igor jul04; */

unsigned long multifactorialint0(int n,int m);
    /* Returns the multifactorial fac_m(n)=n*(n-m)*(n-2*m)*...*1, or 0 if
    n<0 or k<1 or in the case of overflow.
    $A Igor jul04; */

unsigned long multifactorialint(int n,int m);
    /* The same as multifactorialint0, except that it reports error in the case
    of invalid arguments or overflow.
    $A Igor jul04; */





    /* SESTEVANJE V CIKLICNIH GRUPAH: */

int mapcyclicshift(int length,int shift,long num);
  /* Maps the number num to an element of the cyclic group with number of
  elements length (0 thru length-1) and shifts it by shift.
  $AS Igor dec02; */

int pluscyclicshift(int length,int shift, long n1,long n2);
  /* Returns a sum of n1 and n1 mapped by the function mapcyclicshift to a
  cyclic group length shifted by shift. Operation result would be the same if
  n1 and n2 would be mapped to a shifted cyclic group first and then they would
  added together.
  $A Igor dec02; */


/* Auxiliary macros: */
#define m_mapcyclicminus(length,num) m_mapcyclicplus((length),((num)+(1+abs(num)/(length))*(length)))
#define m_mapcyclicplus(length,num) ((num)<(length)?(num):(num)%(length))
#define m_mapcyclic(length,num) ((num)<0?m_mapcyclicminus((length),(num)):m_mapcyclicplus((length),(num)))
/* Operations on shifted cyclic groups: */
#define m_mapcyclicshift(length,shift,num) ((shift)+m_mapcyclic((length),(num)-(shift)))
#define m_pluscyclicshift(length,shift,n1,n2) m_mapcyclicshift((length),(shift),(n1)+(n2))










#endif   /* ndef INCLUDED_rf  */
