
            /* MATRICNE OPERACIJE */

#ifndef INCLUDED_matrixop  /* prevent multiple inclusions */
#define INCLUDED_matrixop

/* Inclusion of headers with type definitions if not already included: */
#ifndef INCLUDED_vec
 #include <vec.h>
#endif
#ifndef INCLUDED_mat
 #include <mat.h>
#endif
#ifndef INCLUDED_st
 #include <st.h>
#endif




            /**********************/
            /*                    */
            /*    VECTOR NORMS    */
            /*                    */
            /**********************/


double vecnorm1(vector v);
    /* Vrne normo 1 vektorja v (vsoto abs. vred. komponent); Ce je v enak NULL
    ali ima dimenzijo 0, vrne 0.
    $A Igor jan00; */

double vecnorm2(vector v);
    /* Vrne normo 2 vektorja v (koren vsote kvadratov komp.); Ce je v enak NULL
    ali ima dimenzijo 0, vrne 0.
    $A Igor jan00; */

double vecnorminf(vector v);
    /* Vrne normo neskoncno vektorja v (najvec. abs. vred. komp.); Ce je v enak
    NULL ali ima dimenzijo 0, vrne 0.
    $A Igor jan00; */

double vecnormE(vector v);
    /* Vrne evklidsko normo vektorja v (koren vsote kvadratov komp.); Ce je v
    enak NULL ali ima dimenzijo 0, vrne 0.
    $A Igor jan00; */

double vecnorm(vector v);
    /* Vrne evklidsko normo oz. normo 2 vektorja v (koren vsote kvadratov
    komp.); Ce je v enak NULL ali ima dimenzijo 0, vrne 0.
    $A Igor jan00; */

void normvecplain(vector v,vector res);
    /* Vector res postane normiran vektor v (uporabi se norma 2 oz. evklidska
    norma). res mora biti ze alociran z enako dimenzijo (vecjo od 0) kot
    v. res je lahko isti vektor kot v.
    $A Igor jan00; */

vector normvec0(vector v1,vector *res);
    /* Vrne normiran vektor v1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. res je lahko tudi naslov v1.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi vektor, ki ga funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor jan00; */



            /************************/
            /*                      */
            /*     MATRIX NORMS     */
            /*                      */
            /************************/



double matnorm1(matrix m);
    /* Vrne normo 1 matrike m (maksimum po stolpcih vsot absolutnih vrednosti
    komponent v danem stolpcu); Ce je m enaka NULL ali ima kaksno dimenzijo 0,
    vrne funkcija 0.
    $A Igor jan00; */

double matnorminf(matrix m);
    /* Vrne normo neskoncno matrike m (maksimum po vrsticah vsot absolutnih
    vrednosti komponent v dani vrstici). Ce je m enaka NULL ali ima kaksno
    dimenzijo 0, vrne funkcija 0.
    $A Igor jan00; */

double matnormE(matrix m);
    /* Vrne evklidsko normo matrike m (koren iz vsote kvadratov komponent). Ce
    je m enaka NULL ali ima kaksno
    dimenzijo 0, vrne funkcija 0.
    $A Igor jan00; */

double matnorm(matrix m);
    /* Vrne evklidsko normo matrike m (koren iz vsote kvadratov komponent). Ce
    je m enaka NULL ali ima kaksno
    dimenzijo 0, vrne funkcija 0.
    $A Igor jan00; */

void normmatplain(matrix m,matrix res);
    /* Matrika res postane normirana matrika m (uporabi se evklidska norma).
    res mora biti ze alocirana z enakimi dimenzijami (vecjimi od 0) kot
    m. res je lahko ista matrika kot m.
    $A Igor jan00; */

matrix normmat0(matrix m1,matrix *res);
    /* Vrne normirano matriko m1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. res je lahko tudi naslov m1.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */




            /*******************************************************/
            /*                                                     */
            /*  CONVERSION AND COPYING BETWEEN MATRIX AND VECTORS  */
            /*                                                     */
            /*******************************************************/


matrix vectomatrow0(vector v1,matrix res,int nrow);
    /* Copies vector v1 to row nrow of matrix res. It returns res if operation
    was successful and NULL otherwise.
      v1 and res must be allocated and v1->d==res->d2 and 0<nrow<=res->d1.
    $A Igor feb05; */

matrix vectomatcol0(vector v1,matrix res,int ncol);
    /* Copies vector v1 to column ncol of matrix res. It returns res if 
    operation was successful and NULL otherwise. 
      v1 and res must be allocated and v1->d==res->d1 and 0<ncol<=res->d2.
    $A Igor feb05; */

matrix vectomatdiag0(vector v1,matrix res);
    /* Copies vector v1 to the diagonal of matrix res. It returns res if 
    operation was successful and NULL otherwise.
      v1 and res must be allocated and v1->d==res->d1==res->d2 (res a square
    matrix).
    $A Igor feb05; */

matrix vectomat0(vector v1,matrix *res);
    /* Vrne matricno kopijo (stolpec) vektorja v1. Ce je res razlicen od NULL,
    zapise rezultat v *res in vrne *res.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */

matrix vectransptomat0(vector v1,matrix *res);
    /* Vrne matricno kopijo (vrstico) transponiranega vektorja v1. Ce je res
    razlicen od NULL, zapise rezultat v *res in vrne *res.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */

vector mattovec0(matrix m1,vector *res);
    /* Vrne vektorsko kopijo matrike m1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. Matrika m1 se v vektor prepise po vrsticah.
    $A Igor feb00; */

vector mattransptovec0(matrix m1,vector *res);
    /* Vrne vektorsko kopijo (transponirane) matrike m1. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. Matrika m1 se v vektor prepise
    po stolpcih.
    $A Igor feb00; */

matrix matparttomat0(matrix m1,int i1,int j1,int i2,int j2,matrix *res);
    /* Vrne matricno kopijo dela matrike m1 po vrsticah. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. i1, j1, i2 in j2 dolocajo del
    matrike, ki se prepise v rezultat (tj. od vkljucno elementa (i1,j1) do
    vkljucno elementa (i2,j2)).
    $A Igor feb00; */

matrix matparttransptomat0(matrix m1,int i1,int j1,int i2,int j2,matrix *res);
    /* Vrne matricno kopijo dela matrike m1 po stolpcih. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. i1, j1, i2 in j2 dolocajo del
    matrike, ki se prepise v rezultat (tj. od vkljucno elementa (i1,j1) do
    vkljucno elementa (i2,j2)). Del matrike se prepisuje po stolpcih v vrstice.
    $A Igor feb00; */

vector matparttovec0(matrix m1,int i1,int j1,int i2,int j2,vector *res);
    /* Vrne vektorsko kopijo dela matrike m1 po vrsticah. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. i1, j1, i2 in j2 dolocajo del
    matrike, ki se prepise v rezultat (tj. od vkljucno elementa (i1,j1) do
    vkljucno elementa (i2,j2)).
    $A Igor feb00; */

vector matparttransptovec0(matrix m1,int i1,int j1,int i2,int j2,vector *res);
    /* Vrne vektorsko kopijo dela matrike m1 po stolpcih. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. i1, j1, i2 in j2 dolocajo del
    matrike, ki se prepise v rezultat (tj. od vkljucno elementa (i1,j1) do
    vkljucno elementa (i2,j2)).
    $A Igor feb00; */

vector matrowtovec0(matrix m1,int ln,vector *res);
    /* Returns a vector copy of the line ln of matrix m1. If res is not NULL
    then the copy is stored to *res and *res is returned.
    $A Igor feb00; */

vector matcoltovec0(matrix m1,int col,vector *res);
    /* Returns a vector copy of the column col of matrix m1. If res is not NULL
    then the copy is stored to *res and *res is returned.
    $A Igor feb00; */

vector matdiagtovec0(matrix m1,vector *res);
    /* Returns a vector copy of the diagonal of matrix m1, which must be a
    square matrix. If res!=NULL then result is written to *res and *res is
    returned (if necessary, *res is allocated or reallocated according to
    the dimensions of m1).
    $A Igor feb05; */




            /*********************************/
            /*                               */
            /*   INITIALIZATION OF VECTORS   */
            /*                               */
            /*********************************/


/*
macro m_tablevector(vec,expr,first,cond,incr)
    Assigns the value of expression expr to components of vector vec in a loop
    for (first;cond;incr). first, cond and incr must be valid parts of a for
    loop and must contain variables that are defined in the scope where the
    macro is called (take care since the variables will be affected as is usual
    for the for loop), and expr can be any valid expression, usually it will
    contain variables contained in first, cond and incr, and possibly some
    additional ones.
      If vec is NULL or it its dimensions do not match the number of iteratinos
    of the for loop, then vec is allocated or reallocated.
      Examples:
    vector v=NULL; int i;  m_tablevector(v,1/(double) i,i=1,i<=4,++i)
    will initialize v to be of dimension 4 and contain components
    {1, 0.5, 0.3333333333, 0.25}
    $A Igor nov03; */

#define m_tablevector(vec,expr,first,cond,incr)  \
  if (1)  \
  {  \
    int m_tabvector_dim,m_tabvector_i;  \
    double m_tabvector_val;  \
    /* printf("Count number of iterations for getting the dimension:\n"); */  \
    m_tabvector_dim=0;  \
    for(first;cond;incr)  \
    {  \
      ++m_tabvector_dim;  \
      /* printf("dim: %i\n",m_tabvector_dim); */  \
    }  \
    if ((vec)!=NULL)  \
    {  \
      if ((vec)->d!=m_tabvector_dim)  \
      {  \
        dispvector(&(vec));  \
        (vec)=getvector(m_tabvector_dim);  \
      }  \
    } else  \
      (vec)=getvector(m_tabvector_dim);  \
    /* printf("Assigning components: \n"); */  \
    m_tabvector_i=1;  \
    for (first;cond;incr)  \
    {  \
      m_tabvector_val=(double) (expr);  \
      /* printf("Comp. %i assigned to %g (i=%i).\n",m_tabvector_i,m_tabvector_val,i); */  \
      (vec)->v[m_tabvector_i]=m_tabvector_val;  \
      ++m_tabvector_i;  \
    }  \
  }


vector initvec0(vector *v,int d,double comp1,...);
    /* Creates and returns a vector with a given set of components which must
    be listed after v. All components of the vector must be listed (their
    number is specified by d) and must be of type double. This function is
    convenient for initialization of smaller or mid-size vectors with known
    components.
      If v!=NULL then *v is initialized. In any case the pointer of vector
    is returned. If v is NULL then a vector is created anew and returned.
      WARNING:
      The caller must make sure that actual arguments that follow comp1 are
    indeed of type double (e.g. by cast). If components are integers they
    should be followed by ., for example 2., 3., 15.! The most common error is
    listing integers as integers, e.g. 2, 3, 15. In this case conversion is
    not performed implicitly as usually because at the caller's side the type
    of arguments following comp11 is not determined!
    $A Igor nov03; */

vector randvec0(int d,int which,double par1,double par2,vector *v);
    /* Naredi in vrne vektor z nakljucnimi elementi. d je dimenzija vektorja,
    which doloca, po kaksni porazdelitvi so porazdeljeni elementi, par1 in par2
    sta parametra verjet. porazdelitve (npr. pri Gaussovi).
     Ce je d 0, postane d dimenzija vektorja *v, ce je ta razlicen od NULL.
    Vektor se vrne tudi v *v, ce je v razlicen od NULL.
     Zaenkrat so implementirane naslednje moznosti glede na vrednosti argumenta
    which:
     0,1: enakomer. porazdelitev med 0 in 1
     2:   enakomer. porazdelitev med par1 in par2
     3:   enakomer. porazdelitev med -par1 in par1
    $A Igor jul00 */

vector constvec0(int d,double c,vector *v);
    /* Naredi in vrne vektor z elementi enakimi c. d je dimenzija vektorja.
    Ce je d 0, postane d dimenzija vektorja *v, ce je ta razlicen od NULL.
    Vektor se vrne tudi v *v, ce je v razlicen od NULL.
    $A Igor jul00 */

vector zerovec0(int d,vector *v);
    /* Naredi in vrne vektor z elementi enakimi 0. d je dimenzija vektorja.
    Ce je d 0, postane d dimenzija vektorja *v, ce je ta razlicen od NULL.
    Vektor se vrne tudi v *v, ce je v razlicen od NULL.
    $A Igor jul00 */

vector unitvec0(int d,int which,vector *v);
    /* Naredi in vrne which-ti enotski vektor (elementi 0 razen na mestu which,
    kjer je element enak 1). d je dimenzija vektorja.
    Ce je d 0, postane d dimenzija vektorja *v, ce je ta razlicen od NULL.
    Vektor se vrne tudi v *v, ce je v razlicen od NULL.
    $A Igor jul00 */





            /**********************************/
            /*                                */
            /*   INITIALIZATION OF MATRICES   */
            /*                                */
            /**********************************/


/*
macro m_tablematrix(mat,expr,first,cond,incr,first1,cond1,incr1)
    Assigns the value of expression expr to components of matrix mat in a
    nested for loop, namely
    for(first;cond;incr)
    {
      ...
      for (first1;cond1;incr1)
      {
        ...
      }
      ...
    }
      first, cond and incr and first1, cond1 and incr1 must be valid parts of
    a for loop and may contain variables that are defined in the scope where
    the macro is called (take care since the variables will be affected as it
    is usual for the for loop), and expr can be any valid expression, usually
    it will contain variables contained in first, cond, incr, first1, cond1
    and incr1, and possibly some additional ones.
      If mat is NULL or it its dimensions do not match the total number of
    iteratinos of the outer and inner for loop, then ir is allocated anew or
    reallocated.
      Examples:
    matrix m=NULL; int i,j;  m_tablematrix(m,10*i+j,i=0,i<=1,++i,j=0,j<=2,++j)
    will initialize m to be of dimensions 2*3 and contain components
    {{0,1,2},{10,11,12},{20,21,22}}
      WARNING:
      Take care that the number of iterations in the internal loop is always
    the same, otherwise the macro will falsely determine the dimension of the
    matrix or will not initialize all elements!
    $A Igor nov03; */

#define m_tablematrix(mat,expr,first,cond,incr,first1,cond1,incr1)  \
  if (1)  \
  {  \
    int m_tabmatrix_dim1,m_tabmatrix_dim2,m_tabmatrix_i,m_tabmatrix_j;  \
    double m_tabmatrix_val;  \
    /* printf("Count number of iterations for getting the dimension:\n"); */  \
    m_tabmatrix_dim1=0;  \
    for(first;cond;incr)  \
    {  \
      ++m_tabmatrix_dim1;  \
      m_tabmatrix_dim2=0;  \
      for(first1;cond1;incr1)  \
      {  \
        ++m_tabmatrix_dim2;  \
        /* printf("dim: %i, dim1: %i\n",m_tabmatrix_dim1,m_tabmatrix_dim2); */  \
      }  \
    }  \
    if ((mat)!=NULL)  \
    {  \
      if ((mat)->d1!=m_tabmatrix_dim1 || (mat)->d2!=m_tabmatrix_dim2)  \
      {  \
        dispmatrix(&(mat));  \
        (mat)=getmatrix(m_tabmatrix_dim1,m_tabmatrix_dim2);  \
      }  \
    } else  \
      (mat)=getmatrix(m_tabmatrix_dim1,m_tabmatrix_dim2);  \
    /* printf("Assigning components: \n"); */  \
    m_tabmatrix_i=1;  \
    m_tabmatrix_j=1;  \
    for (first;cond;incr)  \
    {  \
      for(first1;cond1;incr1)  \
      {  \
        m_tabmatrix_val=(double) (expr);  \
        /* printf("Comp. (%i,%i) assigned to %g (i=%i, j=%i).\n", */  \
          /* m_tabmatrix_i,m_tabmatrix_j,m_tabmatrix_val,i,j); */  \
        (mat)->m[m_tabmatrix_i][m_tabmatrix_j]=m_tabmatrix_val;  \
        ++m_tabmatrix_j;  \
      }  \
      ++m_tabmatrix_i;  \
      m_tabmatrix_j=1;  \
    }  \
  }


matrix initmat0(matrix *m,int d1,int d2,double comp11,...);
    /* Creates and returns a matrix with a given set of components which must
    be listed after m. All components of the matrix must be listed (their
    number is d1*d2) and must be of type double. This function is convenient
    for initialization of smaller or mid-size matrices with known components.
      If m!=NULL then *m is initialized. In any case the pointer of the matrix
    is returned. If m is NULL then a matrix is created anew and returned. If
    d1 or d2 is 0 then a NULL matrix is created.
      WARNING:
    The caller must make sure that actual arguments that follow comp11 are
    indeed of type double (e.g. by cast). If components are integers they
    should be followed by ., for example 2., 3., 15.! The most common error is
    listing integers as integers, e.g. 2, 3, 15. In this case conversion is
    not performed implicitly as usually because at the caller's side the type
    of arguments following comp11 is not determined!
    $A Igor nov03; */

matrix randmat0(int d1,int d2,int which,double par1,double par2,
       matrix *m);
    /* Naredi in vrne matriko z nakljucnimi elementi. d1 in d2 sta dimenziji
    matrike, par1 in par2 sta parametra verjet. porazdelitve (npr. pri
    Gaussovi), which doloca, po kaksni porazdelitvi so porazdeljeni elementi.
    Ce je d2 0, postane d2 enak d1 (kvadratna matrika), ce pa sta d2 in d1
    enaka 0, postaneta dimenziji matrike *m, ce je ta razlicna od NULL.
    Zaenkrat so implementirane naslednje moznosti glede na vrednosti argumenta
    which:
     0,1: enakomer. porazdelitev med 0 in 1
     2:   enakomer. porazdelitev med par1 in par2
     3:   enakomer. porazdelitev med -par1 in par1
    $A Igor jan00 */

matrix constmat0(int d1,int d2,double c,matrix *m);
    /* Elemente matrike dimenzij d1*d2 postavi na d in vrne matriko. Ce je m
    razlicna od NULL, postane *m ta matrika, drugace se matrika tvori na novo.
    Ce je d2 0, postane d2 enak d1 (kvadratna matrika), ce pa sta d2 in d1
    enaka 0, postaneta dimenziji matrike *m, ce je ta razlicna od NULL.
    $A Igor jan00; */

matrix zeromat0(int d1,int d2,matrix *m);
    /* Elemente matrike dimenzij d1*d2 postavi na 0 in vrne matriko. Ce je m
    razlicna od NULL, postane *m ta matrika, drugace se matrika tvori na novo.
    Ce je d2 0, postane d2 enak d1 (kvadratna matrika), ce pa sta d2 in d1
    enaka 0, postaneta dimenziji matrike *m, ce je ta razlicna od NULL.
    $A Igor jan00; */

matrix identmat0(int d1,matrix *m);
    /* Naredi identicno kvadratno matriko dimenzij d1*d1 in vrne matriko. Ce
    je m razlicna od NULL, postane *m ta matrika, drugace se matrika tvori na
    novo.
    Ce je d1 enak 0, postane dimenzija matrike kar dimenzija *m, ce m kaze na
    kvadratno matriko.
    $A Igor jan00; */

matrix diagmatconst0(int d1,double c,matrix *m);
    /* Naredi diagonalno kvadratno matriko dimenzij d1*d1 z diagonalnimi
    elementi enakimi c in vrne matriko. Ce je m razlicna od NULL, postane *m ta
    matrika, drugace se matrika tvori na novo.
    Ce je d1 enak 0, postane dimenzija matrike kar dimenzija *m, ce m kaze na
    kvadratno matriko.
    $A Igor jul00; */

matrix diagmatvec0(vector v,matrix *m2);
    /* Creates a diagonal matrix whose diagonal elements are components of the
    vector v. If m!=NULL then the matrix is stored to *m (with eventually
    performing the necessary reallocations), otherwise it is created anew. In
    both cases the matrix is returned.
    $A Igor dec03; */




            /***********************************************/
            /*                                             */
            /*  SUMS AND PRODUCTS OF MATRICES AND VECTORS  */
            /*                                             */
            /***********************************************/



    /* SUMS AND PRODUCTS: VECTORS */

void vecsumplain(vector v1,vector v2,vector res);
    /* V vektor res zapise vsoto vektorjev v1 in v2. Funkcija ne kontrolira
    niti dimenzij niti tega, ce je prostor alociran. Vektor res je lahko isti
    kot v1 ali v2, prav tako sta v1 in v2 lahko ista vektorja.
    $A Igor jul00; */

void vecdifplain(vector v1,vector v2,vector res);
    /* V vektor res zapise razliko vektorjev v1 in v2. Funkcija ne kontrolira
    niti dimenzij niti tega, ce je prostor alociran. Vektor res je lahko isti
    kot v1 ali v2, prav tako sta v1 in v2 lahko ista vektorja.
    $A Igor jul00; */

vector vecsum0(vector v1,vector v2,vector *v3);
    /* Stores a sum of v1 and v2 to *v3 and returns *v3. If v3=NULL then the
    sum is created anew and returned. *v3 can point to v1 or v2, which can be
    the same vectors. If dimensions of *v3 do not match then v3 is reallocated
    first.
    $A jul00; */

vector vecdif0(vector v1,vector v2,vector *v3);
    /* Stores a difference of v1 and v2 to *v3 and returns *v3. If v3=NULL then
    the result vector is created anew and returned. *v3 can point to v1 or v2,
    which can be the same vectors. If dimensions of *v3 do not match then v3 is
    reallocated first.
    $A jul00; */

void vecprodscalplain(vector v1,double s,vector res);
    /* Multiplies vector v1 by scalar s and stores result to res, which can be
    the same vector as v1. v1 and res may not be NULL and must have compatible
    dimensions, since this is not checked in the function.
    $A Igor dec03; */

vector vecprodscal0(vector v1,double s2,vector *v3);
    /* Returns vector v1 multiplied by scalar s2. If v3 is different than NULL
    then the result is stored to *v3 and *v3 is redurned (with all the
    necessary allocations, deallocations or reallocations performed).
    $A Igor dec03; */

double scalprodvec(vector v1,vector v2);
    /* Returns scalar product of vectors v1 and v2 or 0 if vector dimensions
    do not match or vectors are NULL.
    $A Igor <==; */

#define scalprod scalprodvec

void vecprodvectranspplain(vector v1,vector v2,matrix res);
    /* A product of vector v1 and transpose of v2 (i.e. dyadic product of v1
    and v2) is written to matrix res.
      Function does not check the dimensions and whether space is properly
    allocated, it just performs the operation.
    $A Igor apr05;; */

matrix vecprodvectransp0(vector v1,vector v2,matrix *m3);
    /* Returns product of vector v1 and transposed vector v2 (i.e. the dyadic
    product of v1 and v2). If m3!=NULL then the result is written to *m3 and
    returns *m3.
    $A Igor apr05; */



    /* PRODUCTS OF MATRICES AND VECTORS */

void matprodvecplain(matrix m1,vector v2,vector res);
    /* V vektor res zapise produkt matrike m1 in vektorja v2. Funkcija ne
    kontrolira niti dimenzij niti tega, ce je prostor alociran. Vektor res ne
    sme biti isti kot v2.
    $A Igor avg00; */

vector matprodvec0(matrix m1,vector v2,vector *v3);
    /* Vrne produkt matrike m1 in vektorja v2. Ce je v3 razlicen od NULL,
    zapise rezultat v *v3 in vrne *v3. v3 je lahko tudi naslov v2, funkcija v
    tem primeru poskrbi za to, da se najprej izracuna rezultat operacije in
    sele nato prepise operand.
     OPOMBA:
     Ce je v3 razlicen od NULL, se po navadi vektor, ki ga funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze v3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */

void mattranspprodvecplain(matrix m1,vector v2,vector res);
    /* V vektor res zapise produkt transponirane matrike m1 in vektorja v2.
    Funkcija ne kontrolira niti dimenzij niti tega, ce je prostor alociran.
    Vektor res ne sme biti isti kot v2.
    $A Igor avg00; */

vector mattranspprodvec0(matrix m1,vector v2,vector *v3);
    /* Vrne produkt transponirane  matrike m1 in vektorja v2. Ce je v3 razlicen
    od NULL, zapise rezultat v *v3 in vrne *v3. v3 je lahko tudi naslov v2,
    funkcija v tem primeru poskrbi za to, da se najprej izracuna rezultat
    operacije in sele nato prepise operand.
     OPOMBA:
     Ce je v3 razlicen od NULL, se po navadi vektor, ki ga funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze v3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */

double vectranspprodmatprodvec0(vector v1,matrix m,vector v2);
    /* Returns a generalized scalar product v1T*M*v2.
    $A Igor jun05; */

void matproddiagplain(matrix m1,vector v2,matrix res);
    /* Multiplies m1 by a diagonal matrix whose diagonal elements are elements
    of v2, and stores the result in res. All arguments must be of consistent
    dimensions and different than NULL.
    Dimensions:  m1(mxn), v2(n), res(mxn)
    $A Igor dec03; */

void matproddiagplain(matrix m1,vector v2,matrix res);
    /* Multiplies m1 by a diagonal matrix whose diagonal elements are elements
    of v2, and stores the result in res. All arguments must be of consistent
    dimensions and different than NULL.
      Operation can be performed "in place", i.e. res can be the same matrix
    as m1.
    Dimensions:  m1(mxn), v2(n), res(mxn)
    $A Igor dec03; */

matrix matproddiag0(matrix m1,vector v2,matrix *m3);
    /* Returns the product of m1 and diagonal the matrix whose diagnoal
    elements are components of v2. If m3!=NULL then the result is stored to
    *m3 and *m3 returned, with reallocations performed if necessary.
      Operation can be performed "in place", i.e. m3 can be address of m1.
    Dimensions:  m1(mxn), v2(n), *m3(mxn) (=ret. val.)
    $A Igor des03; */

void diagprodmatplain(vector v1,matrix m2,matrix res);
    /* Multiplies a diagonal matrix whose diagonal elements are elements of 
    v1 by m2, and stores the result in res. All arguments must be of consistent
    dimensions and different than NULL.
      Operation can be performed "in place", i.e. res can be the same matrix
    as m2.
    Dimensions:  v1(n), m2(nxm), res(nxm)
    $A Igor jul03; */

matrix diagprodmat0(vector v1,matrix m2,matrix *m3);
    /* Returns the product of a diagonal matrix whose diagonal elements are 
    elements of v1, and m2. If m3!=NULL then the result is stored to
    *m3 and *m3 returned, with reallocations performed if necessary.
      Operation can be performed "in place", i.e. m3 can be address of m2.
    Dimensions:  v1(n), m2(nxm), *m3(mxn) (=ret. val.)
    $A Igor des03; */

void diagprodvecplain(vector v1,vector v2,vector res);
    /* Multiplies a diagonal matrix whose diagonal elements are elements of 
    v1 by v2, and stores the result in res. All arguments must be of consistent
    dimensions and different than NULL.
      Operation can be performed "in place", i.e. res can be the same vector 
    as v1 or v2.
    Dimensions:  v1(n), v2(n), res(nn)
    $A Igor jul03; */

vector diagprodvec0(vector v1,vector v2,vector *v3);
    /* Returns the product of a diagonal matrix whose diagonal elements are 
    elements of v1, and v2. If v3!=NULL then the result is stored to
    *v3 and *v3 returned, with reallocations performed if necessary.
      Operation can be performed "in place", i.e. v3 can be the address of
    v1 or v2.
    Dimensions:  v1(n), v2(n), *v3(n) (=ret. val.)
    $A Igor des03; */




    /* SUMS AND PRODUCTS: MATRICES */

void matsumplain(matrix m1,matrix m2,matrix res);
    /* V matriko res zapise vsoto matrik m1 in m2. Funkcija ne kontrolira
    niti dimenzij niti tega, ce je prostor alociran. Matrika res je lahko ista
    kot m1 ali m2, prav tako sta m1 in m2 lahko isti matriki.
    $A Igor jan00; */

void matdifplain(matrix m1,matrix m2,matrix res);
    /* V matriko res zapise razliko matrik m1 in m2. Funkcija ne kontrolira
    niti dimenzij niti tega, ce je prostor alociran. Matrika res je lahko ista
    kot m1 ali m2, prav tako sta m1 in m2 lahko isti matriki.
    $A Igor jan00; */

matrix matsum0(matrix m1,matrix m2,matrix *m3);
    /* Stores a sum of m1 and m1 to *m3 and returns *m3. If m3=NULL then the
    sum is created anew and returned. *m3 can point to m1 or m2, which can be
    the same matrices. If dimensions of *m3 do not match then *m3 is reallocated
    first.
    $A jul00; */

matrix matdif0(matrix m1,matrix m2,matrix *m3);
    /* Stores a difference of m1 and m1 to *m3 and returns *m3. If m3=NULL then
    the difference is created anew and returned. *m3 can point to m1 or m2,
    which can be the same matrices. If dimensions of *m3 do not match then *m3
    is reallocated first.
    $A jul00; */

void matprodscalplain(matrix m1,double s,matrix res);
    /* Multiplies matrix m1 by scalar s and stores result to res, which can be
    the same matrix as m1. m1 and res may not be NULL and must have compatible
    dimensions, since this is not checked within the function.
    $A Igor dec03; */

matrix matprodscal0(matrix m1,double s2,matrix *m3);
    /* Returns matrix m1 multiplied by scalar s2. If m3 is different than NULL
    then the result is stored to *m3 and *m3 is redurned (with all the
    necessary allocations, deallocations or reallocations performed).
    $A Igor dec03; */

void matprodplain(matrix m1,matrix m2,matrix res);
    /* V matriko res zapise produkt matrik m1 in m2. Funkcija ne kontrolira
    niti dimenzij niti tega, ce je prostor alociran. Matrika res ne sme biti
    ista kot m1 ali m2, m1 in m2 pa sta lahko isti.
    $A Igor jan00; */

matrix matprod0(matrix m1,matrix m2,matrix *m3);
    /* Vrne produkt matrik m1 in m2. Ce je m3 razlicen od NULL, zapise rezultat
    v *m3 in vrne *m3. m3 je lahko tudi naslov m1 ali m2, funkcija v tem
    primeru poskrbi za to, da se najprej izracuna rezultat operacije in sele
    nato prepise operand.
     OPOMBA:
     Ce je m3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze m3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */

void mattranspprodmatplain(matrix m1,matrix m2,matrix res);
    /* V matriko res zapise produkt transponirane matrike m1 in matrike m2.
    Funkcija ne kontrolira niti dimenzij niti tega, ce je prostor alociran.
    Matrika res ne sme biti ista kot m1 ali m2, m1 in m2 pa sta lahko isti.
    $A Igor jan00; */

matrix mattranspprodmat0(matrix m1,matrix m2,matrix *m3);
    /* Vrne produkt transponirane matrike m1 in matrike m2. Ce je m3 razlicen
    od NULL, zapise rezultat v *m3 in vrne *m3. m3 je lahko tudi naslov m1 ali
    m2, funkcija v tem primeru poskrbi za to, da se najprej izracuna rezultat
    operacije in sele nato prepise operand. Ce matriki nista kompatibilni za
    operacijo, je rezultat NULL.
     OPOMBA:
     Ce je m3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze m3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */

void matprodmattranspplain(matrix m1,matrix m2,matrix res);
    /* V matriko res zapise produkt matrike m1 in transponirane matrike m2.
    Funkcija ne kontrolira niti dimenzij niti tega, ce je prostor alociran.
    Matrika res ne sme biti ista kot m1 ali m2, m1 in m2 pa sta lahko isti.
    $A Igor jan00; */

matrix matprodmattransp0(matrix m1,matrix m2,matrix *m3);
    /* Vrne produkt matrike m1 in transponirane matrike m2. Ce je m3 razlicna
    od NULL, zapise rezultat v *m3 in vrne *m3. m3 je lahko tudi naslov m1 ali
    m2, funkcija v tem primeru poskrbi za to, da se najprej izracuna rezultat
    operacije in sele nato prepise operand.
     OPOMBA:
     Ce je m3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze m3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */

void mattranspprodmattranspplain(matrix m1,matrix m2,matrix res);
    /* V matriko res zapise produkt transponirane matrike m1 in transponirane
    matrike m2. Funkcija ne kontrolira niti dimenzij niti tega, ce je prostor
    alociran. Matrika res ne sme biti ista kot m1 ali m2, m1 in m2 pa sta
    lahko isti.
    $A Igor jan00; */

matrix mattranspprodmattransp0(matrix m1,matrix m2,matrix *m3);
    /* Vrne produkt transponirane matrike m1 in transponirane matrike m2. Ce je
    m3 razlicna od NULL, zapise rezultat v *m3 in vrne *m3. m3 je lahko tudi
    naslov m1 ali m2, funkcija v tem primeru poskrbi za to, da se najprej
    izracuna rezultat operacije in sele nato prepise operand. Ce matriki nista
    kompatibilni za operacijo, je rezultat NULL.
     OPOMBA:
     Ce je m3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze m3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */

void mattranspplain(matrix m,matrix res);
    /* Elementi matrike res postanejo elementi transponirane matrike m.
    Funkcija ne preverja dimenzij in obstoja matrik, zato morajo biti dimenzije
    kompatibilne. Ce j m kvadratna matrika, je lahko res ista matrika kot m.
    $A Igor jan00; */

matrix mattransp0(matrix m1,matrix *res);
    /* Vrne transponirano matriko m1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. res je lahko tudi naslov m1, funkcija v tem
    primeru poskrbi za to, da se najprej izracuna rezultat operacije in sele
    nato prepise operand.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */




            /***************************/
            /*                         */
            /*  INVERSION OF MATRICES  */
            /*                         */
            /***************************/



static void matinvplain1(matrix mat,matrix res);
    /* Kvadratna matrika res postane inverzna matrika matrike mat, ce je m 
    obrnljiva. Funkcija ne preverja dimenzij matrik, zato morajo biti te
    kompatibilne.
    - INVERZ PO TOMAZU SUSTERJU
    $A Igor jan00; */

matrix matinv1(matrix m1,matrix *res);
    /* Vrne inverz matrike m1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. res je lahko tudi naslov m1, funkcija v tem
    primeru poskrbi za to, da se najprej izracuna rezultat operacije in sele
    nato prepise operand.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    - INVERZ PO TOMAZU SUSTERJU
    $A Igor jan00; */

void matinvplain(matrix mat,matrix res);
    /* Kvadratna matrika res postane inverzna matrika matrike mat, ce je m 
    obrnljiva. Funkcija ne preverja dimenzij matrik, zato morajo biti te
    kompatibilne.
    $A Igor jan00; */

matrix matinv0(matrix m1,matrix *res);
    /* Vrne inverz matrike m1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. res je lahko tudi naslov m1, funkcija v tem
    primeru poskrbi za to, da se najprej izracuna rezultat operacije in sele
    nato prepise operand.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */




            /********************************/
            /*                              */
            /*  DECOMPOSITIONS OF MATRICES  */
            /*                              */
            /********************************/




    /* LLT (Choleski) DECOMPOSITION (symmetric positive definite matrices) */

int LLTdecomptolplain(matrix m1,matrix res,double smalltol);
    /* Izvede Choleskijevo dekompozicijo matrike m1 in shrane rezultat v res.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 pozitivno definitna)
    ali negativno vrednost, ce operacija ni bila uspesna. V tem primeru vrne
    minus stevilko vrstice, kjer se je pojavil negativni diagonalni element,
    ali -m1->d-1, ce je kvadrat razmerja med min. in maks. elemantom manj kot
    smalltol.
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan diagonalni element ali deljitelj enak 0 (obicajno je kar 0!).
    Matrika res je lahko ista kot m1, v tem primeru funkcija zapise v m1
    spodnjetrikotne elemente dekompozicije ter nicle nad diagonalo.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */

int LLTdecomptolplainrows(matrix m1,matrix res,double smalltol);
    /* Izvede Choleskijevo dekompozicijo matrike m1 in shrane rezultat v res.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 pozitivno definitna)
    ali negativno vrednost, ce operacija ni bila uspesna.
      Dekompozicija se izvede po vrsticah, v nasprotju s funkcijo
    LLTdecomptolplain, ki jo izvede po stolpcih. V splosnem naj se uporablja
    LLTdecomptolplain!
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan diagonalni element ali deljitelj enak 0 (obicajno je kar 0!).
    Matrika res in d je lahko ista kot m1, v tem primeru funkcija zapise
    v m1 spodnjetrikotne elemente res ter nicle nad diagonalo.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira s spodnjim trikotnikom matrike.
    $A Igor jan00; */

matrix LLTdecomptol0(matrix m1,matrix *res,double smalltol);
    /* Vrne LLT (Choleskijevo) dekompozicijo matrike m1. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. res je lahko tudi naslov m1.
    Funkcija vrne NULL, ce dekompozicija  ni bila uspesna. Funkcija ne cekira,
    ce je matrika m1 simetricna, temvec operacijo enostavno izvede na zgornjem
    trikotnik matrike.
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan diagonalni element ali deljitelj enak 0 (obicajno je kar 0!).
    Matrika res in d je lahko ista kot m1, v tem primeru funkcija zapise
    v m1 spodnjetrikotne elemente res ter nicle nad diagonalo.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */

int LLTdecompplain(matrix m1,matrix res);
    /* Izvede Choleskijevo dekompozicijo matrike m1 in shrane rezultat v res.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 pozitivno definitna)
    ali -1, ce operacija ni bila uspesna.
    Matrika res in d je lahko ista kot m1, v tem primeru funkcija zapise
    v m1 spodnjetrikotne elemente res ter nicle nad diagonalo.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */

matrix LLTdecomp0(matrix m1,matrix *res);
    /* Vrne LLT (Choleskijevo) dekompozicijo matrike m1. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. res je lahko tudi naslov m1.
    Funkcija vrne NULL, ce dekompozicija  ni bila uspesna. Funkcija ne cekira,
    ce je matrika m1 simetricna, temvec operacijo enostavno izvede na zgornjem
    trikotnik matrike.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */



    /*  LDLT DECOMPOSITION (symmetric matrices) */


int LLTdecomptolplain(matrix m1,matrix res,double smalltol);
    /* Izvede Choleskijevo dekompozicijo matrike m1 in shrane rezultat v res.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 pozitivno definitna)
    ali -1, ce operacija ni bila uspesna.
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan diagonalni element ali deljitelj enak 0 (obicajno je kar 0!).
    Matrika res in d je lahko ista kot m1, v tem primeru funkcija zapise
    v m1 spodnjetrikotne elemente res ter nicle nad diagonalo.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */

int LLTdecomptolplainrows(matrix m1,matrix res,double smalltol);
    /* Izvede Choleskijevo dekompozicijo matrike m1 in shrane rezultat v res.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 pozitivno definitna)
    ali -1, ce operacija ni bila uspesna. Dekompozicija se izvede po vrsticah,
    v nasprotju s funkcijo LLTdecomptolplain, ki jo izvede po stolpcih.
    V splosnem naj se uporablja LLTdecomptolplain!
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan diagonalni element ali deljitelj enak 0 (obicajno je kar 0!).
    Matrika res in d je lahko ista kot m1, v tem primeru funkcija zapise
    v m1 spodnjetrikotne elemente res ter nicle nad diagonalo.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira s spodnjim trikotnikom matrike.
    $A Igor jan00; */

int LDLTdecomptolplain(matrix m1,matrix res,matrix d,double smalltol);
    /* Izvede LDLT dekompozicijo matrike m1 in shrane rezultat v l in d.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 obrnljiva), ali
    negativno vrednost, ce operacija ni bila uspesna in sicer -i, ce je
    diagonalni element i tocno 0, ali -m1->d1-1, ce je razmerje med absolutno
    najmanjsim in najvecjim izracunanim diagonalnim elementom manj kot
    smalltol (v tem primeru se dekompozicija sicer izracuna do konca, le da je
    treba racunati z vecjim vplivom numericnih napak).
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    razmerje med absolutno najmanjsim in najvecjim diagonalnim elementom zelo
    malo (slaba pogojenost - velikokrat damo za toleranco kar 0!).
    Matriki res in d sta lahko isti kot m1, v tem primeru funkcija zapise
    v m1 diegonalne elemente d in poddiagonalne elemente matrike res, nad
    diagonalo pa zapise nicle.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */

int LDLTdecomptolplainrows(matrix m1,matrix res,matrix d,double smalltol);
    /* Izvede LDLT dekompozicijo matrike m1 in shrane rezultat v l in d.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 obrnljiva) ali
    negativno stevilo (podobno kot LDLTdecomptolplain), ce operacija ni bila
    uspesna.
    Elementi matrike L so v nasprotju s funkcijo LDLTdecomptolplain izracunani
    po vrsticah. Uporablja naj se kar funkcija LDLTdecomptolplain!
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan deljitelj enak 0 (obicajno je ta kar 0!).
    Matriki res in d sta lahko isti kot m1, v tem primeru funkcija zapise
    v m1 diegonalne elemente d in poddiagonalne elemente matrike res, nad
    diagonalo pa zapise nicle.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */

matrix LDLTdecomptol0(matrix m1,matrix *resL,matrix *resD,double smalltol);
    /* Vrne LDLT dekompozicijo matrike m1. Spodnje trikotno matriko zapise v
    matriko *resL , ki jo tudi vrne, diagonalno pa v resD. resL ali resD sta
    lahko tudi naslova m1 ali naslova iste matrike.
    Funkcija vrne NULL, ce dekompozicija  ni bila uspesna. Funkcija ne cekira,
    ce je matrika m1 simetricna, temvec operacijo enostavno izvede na zgornjem
    trikotnik matrike.
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan deljitelj enak 0 (obicajno je kar 0!).
     OPOMBA:
     resL in resD sta lahko tudi NULL.
    $A Igor jan00; */

int LDLTdecompplain(matrix m1,matrix res,matrix d);
    /* Izvede LDLT dekompozicijo matrike m1 in shrane rezultat v l in d.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 obrnljiva) ali -1,
    ce operacija ni bila uspesna.
    Matriki res in d sta lahko isti kot m1, v tem primeru funkcija zapise
    v m1 diegonalne elemente d in poddiagonalne elemente matrike res, nad
    diagonalo pa zapise nicle.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */

matrix LDLTdecomp0(matrix m1,matrix *resL,matrix *resD);
    /* Vrne LDLT dekompozicijo matrike m1. Spodnje trikotno matriko zapise v
    matriko *resL , ki jo tudi vrne, diagonalno pa v resD. resL ali resD sta
    lahko tudi naslova m1 ali naslova iste matrike.
    Funkcija vrne NULL, ce dekompozicija  ni bila uspesna. Funkcija ne cekira,
    ce je matrika m1 simetricna, temvec operacijo enostavno izvede na ZGORNJEM
    TRIKOTNIKU matrike.
     OPOMBA:
     resL in resD sta lahko tudi NULL.
    $A Igor jan00; */


int LUdecomptolplain(matrix m1,matrix ml,matrix mu,indtab ind,
                     int *parity,double smalltol);
    /* Izvede LU dekompozicijo matrike m1 in shrane rezultat v l in d.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 obrnljiva) ali -1,
    ce operacija ni bila uspesna.
    indtab je lahko NULL, v tem primeru se dekompozicija izvede brez
    pivotiranja, vendar to NI PRIPOROCLJIVO, ker lahko dobimo 0 na diagonali,
    ceprav matrika ni singularna. parity je lahko NULL, v tem primeru se ne
    zabelezi, ce je bilo zamenjav liho stevilo, in se ne more racunati
    determinanta matrike.
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan deljitelj enak 0 (obicajno je ta kar 0!).
    Matriki res in d sta lahko isti kot m1, v tem primeru funkcija zapise
    v m1 diegonalne elemente d in poddiagonalne elemente matrike res, nad
    diagonalo pa zapise nicle.
      parity je lahko enak NULL, v tem primeru se ne zabelezi, ali je stevilo
    zamenjav bilo liho ali sodo (to se tako ali tako rabi samo pri racunanju
    determinante). Tudi indtab je naceloma lahko NULL, vendat to NI
    PRIPOROCLJIVO! V tem primeru namrec funkcija ne izvaja pivotiranja in se
    lahko zgodi, da ima matriko za singularno, ceprav ni. Drugace funkcija
    izvaja implicitno pivotiranje.
    Ref. Num. Rec., p.p.43-49.
    $A Igor avg00; */

matrix LUdecomptol0(matrix m1,matrix *resL,matrix *resU,indtab *ind,
                    int *parity,double smalltol);
    /* Vrne LU dekompozicijo matrike m1, t.j. produkt spodnjetrikotne matrike
    z enkami na diagonali in zgornjetrikotne matrike. Spodnjetrikotno matriko
    zapise v matriko *resL , ki jo tudi vrne, zgornjetrikotno pa v resU. resL
    ali resU sta lahko tudi naslova m1 ali naslova iste matrike. V tem primeru
    se enice na diagonali spodnjetrikotne matrike prepisejo z diagonalnimi
    elementi zgornjetrikotne matrike. V *indtab funkcija zabelezi vrstni red
    vrstic po zamenjavah, v *parity pa zapise -1, ce je bilo zamenjav liho st.,
    in 1, ce jih je bilo sodo stevilo (to se rabi pri racunanju determinante).
    indtab je lahko NULL, v tem primeru se dekompozicija izvede brez
    pivotiranja, vendar to NI PRIPOROCLJIVO, ker lahko dobimo 0 na diagonali,
    ceprav matrika ni singularna. parity je lahko NULL, v tem primeru se ne
    zabelezi, ce je bilo zamenjav liho stevilo, in se ne more racunati
    determinanta matrike.
    Funkcija vrne NULL, ce dekompozicija  ni bila uspesna (singularna matrika
    ali kak drug razlog).
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan deljitelj enak 0 (obicajno je kar 0!).
     OPOMBA:
     resL in resU sta lahko tudi NULL, v tem primeru funkcija vrne matriko, v
    kateri ima spravljeni obe trikotni matriki.
    $A Igor avg00; */



            /************************/
            /*                      */
            /*   QR DECOMPOSITION   */
            /*                      */
            /************************/



int QRdecompplaincomp(matrix m1,matrix qr,vector diag);
    /* Performes QR decomposition of m1 and stores the result in compact form
    (used by Meschach) to qr and d. The dimension of m1, qt and d must be
    consisistent, since the function does not check this; arguments must also
    be different than NULL.
      qr can be the same as m1.
      Dimensions: m1(mxn), qr(mxn), diag(n),  m>=n!
      Calculation with the compact form is much faster than if conversion was
    performed to full QR factors.
      To implement: Error control through return value (i.e. catch Meschach
    errors & return nonzero value if an error occurs)!
    $A Igor dec03; */

int QRdecompplain(matrix m1,matrix mq,matrix mr);
    /* Performs the QR decomposition of a matrix mq and stores the orthogonal
    factor to mq and the upper triangular factor to mr. The dimensions of the
    arguments must be consistend and arguments may not be NULL (this is not
    checked within the function).
      If m1 is a square matrix, then it can be the same as mq or mr, in this
    case its contents are overwritten. mq may not be the same as mr.
      Warning: It is not checked whether the method works for non-square
    matrices (m1->d1>m1->d2)!
      WARNING:
      The operations performed by the compact form are normally much faster
    than by the fully wxpanded product as is calculated by this function.
      To implement: Error control through return value (i.e. catch Meschach
    errors & return nonzero value if an error occurs)!
    $A Igor dec03; */




            /*****************************************/
            /*                                       */
            /*   GRAMM-SCHMIDT's ORTHOGONALIZATION   */
            /*                                       */
            /*****************************************/


void GSortplain(matrix v,matrix q,matrix a);
    /* Gramm-Schmidtova ortogonalizacija. Stolpci matrike v so originalni
    vektorji, v matriko q se zapisejo ortogonalni vektorji dobljeni iz teh,
    v matriko a pa (desni) koeficienti, tako da je q=v*a. q postane ortogonalna
    matrika, a pa zgornjetrikotna z enkami na glavni diagonali.
      Dimenzije so naslednje: v n*m, q n*m, a m*m, kjer je n dimenzija
    vektorskega prostora, m pa stevilo vektorjev. Stolpci matrike a so
    vektorji q izrazeni kot linearne kombinacije vektorjev v.
      Matrika a je lahko NULL, v tem primeru se ne izracunajo koeficienti
    linearnih kombinacij.
      POZOR:
    Matriki q in a ne smeta biti isti kot v.
    $A Igor jul00; */

void GSortnormplain(matrix v,matrix q,matrix a);
    /* Gramm-Schmidtova ortogonalizacija z normiranjem. Stolpci matrike v so
    originalni vektorji, v matriko q se zapisejo ortonormirani vektorji
    dobljeni iz teh, v matriko a pa (desni) koeficienti, tako da je q=v*a.
    q postane ortonormalna atrika, a pa zgornjetrikotna z enkami na glavni
    diagonali.
      Dimenzije so naslednje: v n*m, q n*m, a m*m, kjer je n dimenzija
    vektorskega prostora, m pa stevilo vektorjev. Stolpci matrike a postanejo
    vektorji q izrazeni kot linearne kombinacije vektorjev v.
      Matrika a je lahko NULL, v tem primeru se ne izracunajo koeficienti
    linearnih kombinacij.
    $A Igor jul00; */

void GSort0(matrix v,matrix *q,matrix *a);
    /* Gramm-Schmidtova ortogonalizacija. V matriko *q zapise po stolpcih
    ortogonalne vektorje dobljene iz stolpcev matrike v, v matriko *a pa
    ortogonalne vektorje kot linearne kombinacije stolpcev v (tudi po
    stolpcih). Ce je matrika v dimenzije n*m (m<=n), je *q dimenzije n*m in
    *a dimenzije m*m (m je stevilo vektorjev (stolpcev) v v, n pa je dimenzija
    vektorskega prostora).
     Ali q ali a je lahko NULL (ce je a NULL, se ustrezna matrika en izracuna,
    medtem ko se ort. vektorji v *q vedno izracunajo). a ali q je lahko tudi
    naslov v, v tem primeru se alocira nov prostor , originalni v pa zbrise po
    operaciji.
    $A Igor jul00; */

void GSortnorm0(matrix v,matrix *q,matrix *a);
    /* Gramm-Schmidtova ortogonalizacija z normalizacijo. V matriko *q zapise
    po stolpcih ortogonalne in normirane  vektorje dobljene iz stolpcev matrike
    v, v matriko *a pa ortogonalne vektorje kot linearne kombinacije stolpcev v
    (tudi po stolpcih). Ce je matrika v dimenzije n*m (m<=n), je *q dimenzije
    n*m in *a dimenzije m*m (m je stevilo vektorjev (stolpcev) v v, n pa je
    dimenzija vektorskega prostora).
     Ali q ali a je lahko NULL (ce je a NULL, se ustrezna matrika en izracuna,
    medtem ko se ort. vektorji v *q vedno izracunajo). a ali q je lahko tudi
    naslov v, v tem primeru se alocira nov prostor , originalni v pa zbrise po
    operaciji.
    $A Igor jul00; */






            /****************************/
            /*                          */
            /*   SYSTEMS OF EQUATIONS   */
            /*                          */
            /****************************/




    /* SOLUTION OF SYSTEMS WITH LDLT DECOMPOSITION: */


void solvLDLTplain(matrix L,matrix D,vector b,vector x);
    /* Solves the system of equations L D LT x = b, where L is a lower
    triangular matrix with diagonal elemnts 1, D is a diagonal matrix, and
    stores the result in x. Arguments must be allocated and of consistent
    dimensions since this is not checked.
      L and D can point to the same matrix since the function does not operate
    on diagonal elements of L (it just assumes these are 1).
      b and x can also point to the same vector.
    $A Igor nov03; */

    /* SOLUTION OF SYSTEMS WITH LLT DECOMPOSITION: */

void solvLLTplain(matrix L,vector b,vector x);
    /* Solves the system of equations L LT x = b, where L is a lower
    triangular matrix, and stores the result in x. Arguments must be allocated
    and of consistent dimensions since this is not checked.
      b and x can point to the same vector.
      The function is usually used for back-substitution after the choleski
    (LLT) decomposition for positive definite matrices. A system of equations
    with a symmetric matrix A can be converted to a system with a positive
    definite matrix by multiplying the matrix ant the right-hand side vector
    by AT: A x = b => (AT A) x = (AT b). This is however not feasible because
    preparation of the system takes much more time than the solution, and it
    is much better to perform the LDLT deocmposition.
    $A Igor nov03; */


    /* SOLUTION OF TRIANGULAR SYSTEMS AND BY LU DECOMPOSITION: */


void solvlowerplain(matrix ml,vector b,vector x);
    /* Solves the system ml*x=b, where ml is a lower triangular matrix with
    arbitrary elements on the diagonal. 
      Arguments may not be NULL and must be of consistent dimensions.
      Vector b and x can be the same.
    $A Igor dec03; */

void solvupperplain(matrix ml,vector b,vector x);
    /* Solves the system mu*x=b, where mu is a lower triangular matrix with
    arbitrary elements on the diagonal. 
      Arguments may not be NULL and must be of consistent dimensions.
      Vectors b and x can be the same.
    $A Igor dec03; */

vector solvlower0(matrix ml1,vector b2,vector *x3);
    /* Returns the solution of the LOWER TRIANGULAR system ml*x==b2. If
    x3!=NULL then the solution is stored to *x3 and returned. All neccessary
    allocations are performed. If the dimensions of ml and b2 are not
    compatible then NULL is returned. It does not check for zero diagonal
    elements.
    $A Igor avg00; */

vector solvupper0(matrix mu1,vector b2,vector *x3);
    /* Returns the solution of the UPPER TRIANGULAR system ml*x==b2. If
    x3!=NULL then the solution is stored to *x3 and returned. All neccessary
    allocations are performed. If the dimensions of ml and b2 are not
    compatible then NULL is returned. It does not check for zero diagonal
    elements.
    $A Igor avg00; */

void solvLUplain(matrix ml,matrix mu,indtab it,vector b,vector x);
    /* Resi sistem (ml*mu)x=b, kjer vsebujeta matriki ml in mu LU dekompozicijo
    matrike sistema, in resitev zapise v vektor x, ki je lahko tudi
    isti vektor kot vektor desnih strani b. L mora biti spodnjetrikotna z
    enicami na diagonali, U pa zgornjetrikotna matrika, dobljena z LU
    dekompozicijo, it pa je permutacijska tabela, v kateri so spravljene
    zamenjave vrstic. ml in mu sta lahko shranjeni tudi v isti matriki, ker se
    avtomaticno privzameta trikotnost obeh matrik in enice na diagonali pri ml.
     it je lahko tudi NULL, v tem primeru se privzame, da pri dekompoziciji ni
    bilo zamenjav vrstic. to se NIKOLI NE UPORABLJA, ker so v splosnem
    zamenjave vrstic nujne.
    $A Igor avg00; */


vector solvLU0(matrix ml,matrix mu,indtab it,vector b2,vector *x3);
    /* Vrne resitev sistema enacb (ml*mu)*x3=b2, kjer sta ml in mu matriki
    dobljeni z LU dekompozicijo matrike sistema, b2 pa vektor desnih strani.
    it je indeksna tabela, v kateri so zabelezene izvedene zamenjave vrstic
    pri dekompoziciji. Lahko je NULL, ce smo dekompozicijo na siloizvedli
    tako, da ni bilo zamenjav, vendar se to v praksi NE SME narediti, ker
    lahko na ta nacin dekompozicija spodleti tudi pri nesingularnih matrikah.
    Ce je x3 razlicen od NULL, zapise rezultat v *x3 in vrne *x3. x3 je lahko
    tudi naslov b2, funkcija v tem primeru poskrbi za to, da se najprej
    izracuna rezultat operacije in sele nato prepise operand. ml in mu sta
    lahko shranjeni v isti matriki, ker se avtomatsko privzame, da ima ml enice
    na diagonali. Ce je ml ali mu NULL, se vzame, da sta ml in mu shranjeni v
    isti matriki in se za obe uporabi tista, ki je razlicna od NULL.
     OPOMBA:
     Ce je x3 razlicen od NULL, se po navadi vektor, ki ga funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze x3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */

void solvLUmatplain(matrix ml,matrix mu,indtab it,matrix b,matrix mx);
    /* Resi sistem (ml*mu)x=b, kjer vsebujeta matriki ml in mu LU dekompozicijo
    matrike sistema, in resitev zapise v vektor mx, ki je lahko tudi
    isti vektor kot vektor desnih strani b. L mora biti spodnjetrikotna z
    enicami na diagonali, U pa zgornjetrikotna matrika, dobljena z LU
    dekompozicijo, it pa je permutacijska tabela, v kateri so spravljene
    zamenjave vrstic. ml in mu sta lahko shranjeni tudi v isti matriki, ker se
    avtomaticno privzameta trikotnost obeh matrik in enice na diagonali pri ml.
     it je lahko tudi NULL, v tem primeru se privzame, da pri dekompoziciji ni
    bilo zamenjav vrstic. to se NIKOLI NE UPORABLJA, ker so v splosnem
    zamenjave vrstic nujne.
    $A Igor avg00; */



    /* SOLUTION OF SYSTEMS OF EQUATIONS WITH ORTHOGONAL MATRICES: */


void solvortplain(matrix q,vector b,vector x);
    /* Resi sistem enacb q*x=b, kjer je q ortogonalna matrika (stolpci matrike
    so ortogonalni), b pa vektor desnih strani. Resitev se zapise v vektor x.
    Funkcija ne kontrolira dimenzij.
    x ne sme biti isti vektor kot b.
    $A Igor jul00; */

void solvortmatplain(matrix q,matrix b,matrix x);
    /* Resi sistem enacb q*x=b, kjer je q ortogonalna matrika (stolpci matrike
    so ortogonalni), stolpci b pa so vektorji desnih strani. Resitev se zapise
    po stolpcih v matriko x. Funkcija ne kontrolira dimenzij.
    x ne sme biti ista matrika kot b.
    $A Igor jul00; */

void solvortnormplain(matrix q,vector b,vector x);
    /* Resi sistem enacb q*x=b, kjer je q ortonormalna matrika (stolpci matrike
    so paroma ortogonalni in normirani), b pa vektor desnih strani. Resitev se
    zapise v vektor x. Funkcija ne kontrolira dimenzij.
    x ne sme biti isti vektor kot b.
    $A Igor jul00; */

void solvortnormmatplain(matrix q,matrix b,matrix x);
    /* Resi sistem enacb q*x=b, kjer je q ortonormalna matrika (stolpci matrike
    so ortogonalni in normirani), stolpci b pa so vektorji desnih strani.
    Resitev se zapise po stolpcih v matriko x. Funkcija ne kontrolira dimenzij.
    x ne sme biti ista matrika kot b.
    $A Igor jul00; */

vector solvort0(matrix q1,vector b2,vector *x3);
    /* Vrne resitev sistema enacb q1*x3=b2, kjer je q1 ortogonalna matrika,
    t.j. matrika s paroma ortogonalnimi stolpci. Ce je x3 razlicen od NULL,
    zapise rezultat v *x3 in vrne *x3. x3 je lahko tudi naslov b2, funkcija
    v tem primeru poskrbi za to, da se najprej izracuna rezultat operacije
    in sele nato prepise operand.
     OPOMBA:
     Ce je x3 razlicen od NULL, se po navadi vektor, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze x3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */

matrix solvortmat0(matrix q1,matrix b2,matrix *x3);
    /* Vrne resitve sistemov enacb q1*x3=b2, kjer je q1 ortogonalna matrika,
    t.j. matrika s paroma ortogonalnimi stolpci. Ce je x3 razlicen od NULL,
    zapise rezultat v *x3 in vrne *x3. x3 je lahko tudi naslov q1 ali b2,
    funkcija v tem primeru poskrbi za to, da se najprej izracuna rezultat
    operacije in sele nato prepise operand.
     OPOMBA:
     Ce je x3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze x3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor avg00; */

vector solvortnorm0(matrix q1,vector b2,vector *x3);
    /* Vrne resitev sistema enacb q1*x3=b2, kjer je q1 ortogonalna matrika,
    t.j. matrika s paroma ortogonalnimi stolpci. Ce je x3 razlicen od NULL,
    zapise rezultat v *x3 in vrne *x3. x3 je lahko tudi naslov b2, funkcija
    v tem primeru poskrbi za to, da se najprej izracuna rezultat operacije
    in sele nato prepise operand.
     OPOMBA:
     Ce je x3 razlicen od NULL, se po navadi vektor, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze x3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */

matrix solvortnormmat0(matrix q1,matrix b2,matrix *x3);
    /* Vrne resitve sistemov enacb q1*x3=b2, kjer je q1 ortogonormirana matrika,
    t.j. matrika s paroma ortogonalnimi in normiranimi stolpci (v evklidski
    normi). Ce je x3 razlicen od NULL, zapise rezultat v *x3 in vrne *x3. x3
    je lahko tudi naslov q1 ali b2, funkcija v tem primeru poskrbi za to, da
    se najprej izracuna rezultat operacije in sele nato prepise operand.
     OPOMBA:
     Ce je x3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze x3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor avg00; */




    /* SOLUTION OF SYSTEMS BY THE QR DECOMPOSITION: */


void solvQRplaincomp(matrix qr,vector diag,vector b,vector x);
    /* Solves the system of equations A x = b, where qr and diag contain the
    QR decomposition of A in the compact form used bt Meschach. Arguments must
    be of consistend dimensions and may not be NULL, since checks are not
    performed within the function.
      b can be the same as x.
      Dimensions: qr(mxn), diag(n), b(m), x(n),  m>=n!
    $A Igor dec03; */

void solvQRplain(matrix mq,matrix mr,vector b,vector x);
    /* Solves the system of equations A x = b, where mq and mr contain the QR
    factors of A. Arguments must be of consistend dimensions and may not be
    NULL, since checks are not performed within the function.
      Dimensions: mq(nxn), mr(mxn), b(m), x(n),  m>=n!
      b can be the same as x. If m>n then x must be of dimension m and is
    resized within the function to the dimension n.
    $A Igor dec03; */


    /* SOLUTION OF SYSTEMS BY THE GRAMM-SCHMIDT ORTHOGONALIZATION: */


vector solvGS0(matrix M,vector b,vector *x);
    /* Resi sistem enacb M*x=b tako, da najprej izvede normirano
    Gramm-Schmidtovo ortogonalizacijo stolpcev M in v obliki Q=MA, nato
    pa resi sistem v dveh stopnjah, najprej resi Q*y=b, nato pa izracuna x kot
    x=A*y.
     M mora biti kvadratna matrika in b vektor iste dimenzije kot M. x je lahko
    NULL, v tem primeru se na novo kreira in vrne vektor, ki vsebuje resitev.
    Ce je x!=NULL, se resitev zapise v *x (najprej se poskrbi, da ima *x isto
    dimenzijo kot b), *x pa se tudi vrne.
    $A Igor jul00; */

matrix solvmatGS0(matrix M,matrix b,matrix *x);
    /* Resi sisteme enacb M*x=b tako, da najprej izvede normirano
    Gramm-Schmidtovo ortogonalizacijo stolpcev M in v obliki Q=MA, nato
    pa resi sistem v dveh stopnjah, najprej resi Q*y=b, nato pa izracuna x kot
    x=A*y.
     M mora biti kvadratna matrika in b matrika z istim stevilom vrstic, kot je
    dimenzija m, stolpcev pa mora imeti toliko, kolikor sistemov resujemo. x je
    lahko NULL, v tem primeru se na novo kreira in vrne vektor, ki vsebuje
    resitev. Ce je x!=NULL, se resitev zapise v *x (najprej se poskrbi, da ima
    *x iste dimenzije kot b), *x pa se tudi vrne.
    $A Igor jul00; */



            /*****************************/
            /*                           */
            /*   INVERSION OF MATRICES   */
            /*                           */
            /*****************************/



static void matinvortplain(matrix q,matrix inv);
    /* Izracuna inverz ortogonalne matrike q in rezultat zapise v inv. Funkcija
    ne preverja dimenzij. Matrika inv ne sme biti ista kot q.
    $A Igor jul00; */

matrix matinvGS0(matrix M,matrix *inv);
    /* Izracuna inverzno matriko matrike M s pomocjo Gramm-Schmidtove
    ortogonalizacije in jo vrne. Ce je inv!=NULL, vrne inverzno matriko v
    *inv, drugace inverzno matriko tvori na novo.
    $A Igor jul00; */




            /********************************************/
            /*                                          */
            /*   UTILITIES INCORPORATING THE Meschach   */
            /*                                          */
            /********************************************/


int LUdecomp_mes(matrix m1,matrix lu,indtab ind);
    /* Calculates LU decomposition of matrix m1 and stores it to lu. m1 and
    lu may be or not the same matrices. Permutation order is stored to ind.
     The Meschach library is used for calculation.
    $A Igor dec03; */

void solvLU_mes(matrix lu,indtab it,vector b,vector x);
    /* Solves the equation A x = b, where lu contains the LU decomposition of
    A and it the permutation table for this composition. The Meschach library
    is used for calculation.
    $A Igor dec03; */




    /* TEST FUNCTIOS */

void tesmatrixop(void);
    /* A test function for matrix operations. Several types of functionality
    are tested, some of which are included in "if (0)" - change 0 to 1 if you
    want to run tests for this functionality.
    $A Igor nov03; */









#endif  /* INCLUDED_matrixop */
