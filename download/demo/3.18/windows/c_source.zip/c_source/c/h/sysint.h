

/* PLATFORM & APPLICATION DEPENDENT DEFINITIONS - MACROS
This file is included in every source file of Igor G.'s software. */

/* Prevent multiple inclusion: */
#ifndef INCLUDED_sysint
#define INCLUDED_sysint

/* Header IDs - numbers must be the same as in the corresponding headers: */
#define HEADER_ID_optbas 5400
#define HEADER_ID_optpt 5600
#define HEADER_ID_opttest 5800
#define HEADER_ID_optline 6000
#define HEADER_ID_optminbas 6200
#define HEADER_ID_optapprox 6400  
#define HEADER_ID_optapproxbas 6600  
#define HEADER_ID_optglob 6800  


#define MATHINT



/* Comment: FILES CHANGED FOR THE ELFEN'S INTERFACE:
  invelf.h  (created anew)
  invan.h
  sysint.h

 */


/*  Copy the following out of comment when linking with FEAP:
#define FEAPINT
*/


/*  - some definitio for X Windows graphics 
#define LINUX
#define GRX
#define IGS
*/




/*
#define KEYPROT
*/




/*
#define ELFINT
*/



#define INVCLOSED
#define DEMO
#define CFSQP



/* PLATFORM definition: */


#define WN32
#define VISUALC


/*
#define ITK
*/

#define GRITK



#if 0
/* Other possibilities - to copy & paste: */
#define HPUNIX   /* Unix on HP */
#define LINUX    /* Linux */
#define DOS      /* MS-DOS on PC */
#define WN16     /* 16-bit MS Windows on PC */
#define WN32     /* 32-bit MS Windows on PC */
#endif /* if 0 */


/* APPLICATION definition: */
/*
#define CUSTOMAPP
*/



#if 0
/* Possible applications (put one of them outside #if 0 ): */
  #define INVERSE
  #define CUSTOMAPP
  #define CUSTOM_ELF_INV_INTERFACE
#endif


  /* FOR TESTING OF EXCLUSION OF ITK (remove in the future): */

#if 0
 #undef GRITK
 #undef ITK
#endif



#if defined(CUSTOMAPP)  /* Customised application, not pre-defined */

 #define ITK
 #define DEMO
 #define CFSQP
 #define INVCLOSED

#elif defined (INVERSE)

 #define ITK
 #define DEMO
 #define CFSQP
 #define INVCLOSED

#elif defined(CUSTOM_ELF_INV_INTERFACE)  

 #define WN32
 #define VISUALC
 #define DEMO
 #define ELFINT
 #define FORT_DECL __stdcall
 #define CFSQP
 #define INVCLOSED

 /* macro for Domen's changes*/
 #define DOMENMAC

#endif





    /* DOMEN'S DEFINITIONS (TO BE REPLACED WITH OFFICIAL ONES) */

  /*  DOMENMAC : Exclusion of graphics  */

#ifdef DOMENMAC
 #undef GRTCL
 #undef ITK
 #undef GRITK
#endif




/************************************************************/
/*                                                          */
/*                     SYSTEM INTERFACE                     */
/*                                                          */
/************************************************************/


/* DEFINITIONS DEPENDENT ON THE SYSTEM ON WHICH THE PROGRAM IS COMPILED */


/* DEFINITION OF PRE-PROCESSOR VARIABLES SET BY THE DEVELOPER IN THIS FILE,
   WHICH DEFINE THE COMPILATION OF THE DEPENDENT CODE:

Pre-processor variables for the operating system:
HPUNIX  : Unix on HP workstations
LINUX   : Linux
DOS     : MS-DOS on a PC
WN16    : 16-bit MS Windows on a PC
WN32    : 32-bit MS Windows on a PC
WNDOWS  : Any MS Windows on a PC
DOSWN   : Any MS Windows or DOS on a PC

Pre-processor variables for libraries and compilers:
MPI      : MPI (Message Passing Interface - parallel processing)

ITK      : Tcl/Tk libraries extended by ITK (Tcl interpreter enabled)

Graphics:
IGS      : Old grapgics
GRX      : Screen graphics implemented by Xlib
GRPEX    : Screen graphics implemented by PEX graph. library (used on HP)
GRBGI    : Borland graphic libraries - used with DOS, no windows
GRITK    : Screen graphics implemented by ITK
GRTCL    : Graphics implemented through writing Tcl files and viewing by Wish.





Compilers:
BC3      : Borland C 3.x
BC5      : Borland C 5.x
BC       : Borland C
VISUALC  : Microsoft Visual C++


Algorithms:
CFSQP    : Optimizat. alg. CFSQP (http://www.isr.umd.edu/Labs/CACSE/FSQP/fsqp.html)
           Warning - this can be used only for research purposes, not commercial

Licence related:
SHAREWARE  : shareware verzion
DEMO       : demo verzion
COMMERCIAL : commercial version
KEYPROT    : licence key required for the program
DATEPROT   : limited validity - expiration date defined

Variables for linking with other libraries and programs:
OTHERMAIN  : Inverse does not have main
Program Inverse nima main-a (ker se linka s knjiznico, ki ima main)
  
Variables for inclusion of interfaces with analysis programs:
ELFINT     : direct interface with Elfen
FEAPINT    : direct interface with FEAP

MATHINT    : direct interface with FEAP

*/





/****************** DEPENDEND PRE-PROCESSOR VARIABLES: ********************/

/* In the case that the GNU C is used on a PC, we need to switch on UNIX def.: */

#ifdef GCC
  #undef WN16
  #undef WN32
  #undef WNDWOS
  #undef DOS
  #undef DOSWN
  #undef VISUALC
  #define UNIX
#endif



#ifdef WN16
#define WNDOWS /* MS Windows on a PC */
#endif
#ifdef WN32
#define WNDOWS
#endif
#ifdef DOS
#define DOSWN
#endif
#ifdef WNDOWS
#define DOSWN
#endif


#ifdef LINUX
#define UNIX
#endif
#ifdef HPUNIX
#define UNIX
#endif

#ifdef DOS
#define DOSSYNTAX
#endif
#ifdef WN16
#define DOSSYNTAX
#endif
#ifdef WN32
#define DOSSYNTAX
#endif
#ifdef WNDOWS
#define DOSSYNTAX
#endif

#ifdef BC3
#define BC
#endif

#ifdef BC5
#define BC
#endif

#ifdef BC
#define MANARG /* reading command-line arguments from standard input */
#endif


/* Define GRTCL if there is no other graphics: */
#define GRTCL

#ifdef GRX
#undef GRTCL
#endif

#ifdef GRPEX
#undef GRTCL
#endif

#ifdef GRBGI
#undef GRTCL
#endif

#ifdef GRITK
 #undef GRTCL
 #define ITK
#endif




/******************* SYSTEM DEPENDENCIES: *******************/





#ifdef WNDOWS
  #include <windows.h>
#endif


/* Borlandov C++3.x: */
#ifdef BC3
  extern unsigned _floatconvert;
  #pragma extref _floatconvert
  #include <alloc.h>
#endif


#ifdef WN16
  #define system replacementforsysteminWN16
#endif

#ifdef VISUALC
  void sleep(int);
#endif

/*
#if defined(DEMO) || defined(SHAREWARE)
  #undef CFSQP
#endif
*/

#ifdef CFSQP
  #ifdef __STDC__
    void    grobfd(int,int,double *,double *,void (*)(int,int,
                   double *,double *,void *),void *);
    void    grcnfd(int,int,double *,double *,void (*)(int,int,
                 double *,double *,void *),void *);
  #else
    void    grobfd();
    void    grcnfd();
  #endif
#endif


/******************* DIFFERENT VERSIONS: *******************/


#ifdef COMMERCIAL
 #define KEYPROT
#endif

#ifdef SHAREWARE
 #undef KEYPROT
#endif

#ifdef DEMO
 #define DATEPROT
#endif

#ifndef DATEPROT
  #define KEYPROT
#endif


/******************* LINKING WITH OTHER PROGRAMS: *******************/

#ifdef EMELFINT
  #undef ELFINT
#endif
#ifdef ELFINT
  #undef EMELFINT
#endif


#ifdef ELFINT
  #define OTHERMAIN
#endif


/******************* CROSS-LANGUAGE ISSUES: *******************/

/* FOR LINKING WITH FORTRAN CODE: */

/* Instruction: define and declare functions that are called from Fortran and 
declare functions that are defined in Fortran code with the FORT_DECL
specifier! When code is transfered to different platform, the compiler direction
FORT_DECL should be extended accordingly */

#if defined(DOSWN)
 #if defined(VISUALC) /* && defined(VISUALFORTRAN) */
  #define FORT_DECL __stdcall
 #endif
#elif defined(UNIX)
#endif

#ifndef FORT_DECL
 #define FORT_DECL
#endif

/*
#ifndef FORT_DECL
 #define FORT_DECL Error_in_declaration
#endif
*/

/*******************  *******************/




    /* CORRECTIONS AND VITAL DEFINITIONS: */


/* THREAD LOCKING for files; it's not necessary to explicitly include itk.h
just for thread locking macros, inclusion of sysint.h is enough. See itk.h for
comments on the macros! */

#ifndef INCLUDED_itk  /* we don't want to re-define if already defined */


  /* Tracing supplement; takes care of notifications whenever thread locking
  encounters a lock that is already set. This enables to identify hanhing because
  of inproper threas locking. See macros and routines declared in er.h for more
  information on tracing! */

  #ifdef EXTRACE
   #define TRLOCK(lock,macroname)    \
     if ((lock)!=0) \
       TRDOPR(0,0,macroname,NULL,  \
         fprintf(trf(),"Thread Lock = %i  {%i  %s (%s)}\n",  \
           (lock),__LINE__,__FILE__,macroname); fflush(trf()); )
  #else
   #define TRLOCK(lock,macroname)
  #endif

 #ifdef EXTRACE
   #define TRWAITVAL(expr,val,macroname)    \
     if ((expr)!=(val)) \
       TRDOPR(0,0,macroname,NULL,  \
         fprintf(trf(),"Thread Wait Value %i, current %i {%i  %s (%s)}\n",  \
           (val),(expr),__LINE__,__FILE__,macroname); fflush(trf()); )
  #else
   #define TRWAITVAL(expr,val,macroname)
  #endif

 #ifdef EXTRACE
   #define TRWAITNOTVAL(expr,val,macroname)    \
     if ((expr)==(val)) \
       TRDOPR(0,0,macroname,NULL,  \
         fprintf(trf(),"Thread Wait Not Value %i, current %i {%i  %s (%s)}\n",  \
           (val),(expr),__LINE__,__FILE__,macroname); fflush(trf()); )
  #else
   #define TRWAITNOTVAL(expr,val,macroname)
  #endif



  /* Macros that will be different if ITK is defined; they normally call ITK
  functions but are implemented differently if these functions are not defined: */

  #define m_threadlocksleep(lock,sleep)  \
    TRLOCK(lock,"m_threadlocksleep")  \
    while(1)  \
    {  \
      int i;  \
      while(lock>0)  \
        i=10*5;  \
      ++(lock);  \
      if ((lock)<=1)  \
      {  \
        lock=1;  \
        break;  \
      }  \
      else  \
        --(lock);  \
    }

  #define m_threadlocksafesleep(lock,id,time)  \
    TRLOCK(lock,"m_threadlocksleep")  \
    while(1)  \
    {  \
      int i;  \
      while(lock>0)  \
      {  \
        i=10*5;  \
        if (id==getthreadid())  \
          lock=0;  \
      }  \
      ++(lock);  \
      if ((lock)<=1)  \
      {  \
        lock=1;  \
        id=getthreadid();  \
        break;  \
      }  \
      else  \
        --(lock);  \
    }

  #define m_threadwaitvalsleep(expr,val,time)  \
    TRWAITVAL(expr,val,"m_threadwaitvalsleep")    \
    while((expr)!=(val)) {int i; i=3*5;}

  #define m_threadwaitnotvalsleep(expr,val,time)  \
    TRWAITNOTVAL(expr,val,"m_threadwaitnotvalsleep")    \
    while((expr)==(val)) {int i; i=3*5;}

  /* Macros that does not depent in any respect on the existence of ITK
  functions: */

  #define m_threadlock(lock)   m_threadlocksleep(lock,0)

  #define m_threadunlock(lock)  --(lock);

  #define m_threadlocksafe(lock,id)  m_threadlocksafesleep(lock,id,0)  

  #define m_threadwaitval(expr,val)    m_threadwaitvalsleep(expr,val,0)

  #define m_threadwaitnotval(expr,val)    m_threadwaitnotvalsleep(expr,val,0)  

#endif  /* not INCLUDED_itk */





/* Tracing of memory allocation and deallocation:
  In order to get a trace mark whenever memorz allocation or deallocation is
performed by standard functions, define EXTRACE and EXTRACEMEM on the top of
the source file in which you want this kind of tracing. Conditional tracing
can not be used in this case. */

#ifdef EXTRACE
#ifdef EXTRACEMEM
 #include <stdlib.h>

 void *tr_malloc(int size);
 void *tr_calloc(int nelem,int elsize);
 void tr_free(void *ptr);
 void *tr_realloc(void *ptr,int size);
 int tr_mark_mem(char *filename,int linenum,char *function,int size);

 #define malloc(size) \
   ( tr_mark_mem(__FILE__,__LINE__,"malloc",(size)) ?  \
     tr_malloc(size): tr_malloc(size) )

 #define calloc(nelem,elsize) \
   ( tr_mark_mem(__FILE__,__LINE__,"calloc",(nelem)*(elsize)) ?  \
     tr_calloc((nelem),(elsize)): tr_calloc((nelem),(elsize)) )

 #define free(ptr) \
   ( tr_mark_mem(__FILE__,__LINE__,"free",0) ?  \
     tr_free(ptr): tr_free(ptr) )
 
 #define realloc(ptr,size) \
   ( tr_mark_mem(__FILE__,__LINE__,"realloc",(size) ) ?  \
     tr_realloc((ptr),(size)): tr_realloc((ptr),(size)) )


#endif
#endif












#endif  /* #ifndef INCLUDED_sysint */



