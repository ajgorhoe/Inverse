

                      /* DATOTECNI INTERPRETER */


/* Koda, ki omogoca v kljucitev te datoteke v headerjih, ne da bi bilo treba
skrbeti za to, ali ni ta header ze bil kakorkoli vkljucen, ker se v to
eksplicitno preverja preko definicije ustreznega makra: */
#ifndef INCLUDED_fint
#define INCLUDED_fint

/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */

#ifndef INCLUDED_st
#include <st.h>
#endif

#ifndef INCLUDED_lint
#include <lint.h>
#endif

#ifndef INCLUDED_simb
#include <simb.h>
#endif




typedef struct _ficom {
        /* Oklepaji, ki omejujejo izraze in bloke v datoteki: */
        char brac1,brac2,endchar;
        char expbrac1,expbrac2,blockbrac1,blockbrac2;
        char stopint;     /* Ce je 1, se preneha interpretacija datoteke. */
        int level;  /* Globina interpretacije */
        int exitlevels; /* Pove, iz koliko nivojev moramo izstopiti. */
        char *labelstr; /* Niz, ki napoveduje oznako */
        char *gotolabel; /* Oznaka, na katero naj se skoci */
        stack functions; /* Funkcije, instalirane na sistem dat. int. */
        FILE *fp;        /* Datoteka, ki se interpretira */
        char *filename,  /* Ime datoteke, ki se interpretira */
             *origfilename; /* Ime originalne datoteke, iz katere je trenutno 
                             interpretirani blok. Ta kazalec se ne brise! Ce je
                             razlicen od NUL, to pomeni, da so stvari, ki se
                             interpretirajo, v zacasni datoteki, izhajajo pa
                             iz datoteke z imenom origfilename. To se zgodi pri
                             izvedbi funkcij fi_function in fi_update. */
        long from,to,pos, /* Obmocje v dat., ki se interpretira, in trenut.
                             pozicija */
             funcpos,     /* Pozicija imena zadnje funkcije */
             argpos,      /* Pozicija, od koder se isce naslednji argument */
             origpos,     /* Pozicija zacetka bloka v originalni datoteki */
             beginpos,    /* Pozicija zacetka bloka v datoteki, ki se
                             interpretira */
             begin,end;   /* Obmocje ukaza, ki je trenutno v obravnavi */
        int which;        /* Zap. st. ukaza, ki je trenutno v obravnavi */
        void *func;       /* Podatki o funkciji, ki je trenutno v obdelavi,
                             tipa fifunction. */
        FILE *temp;      /* Zacasna datoeka za interpretacijo generiranih blokov */
        char *tempname;  /* Ime zacasne datoteke */
        long temppos;    /* 1+zadnja pozicija v zacasni datoteki, ki je se v rabi */
        FILE *in;  /* Vhodna datoteka */
        FILE *outfl; /* Izhodna datoteka */
        FILE * (*outfile) (struct _ficom *ficom);
        ssyst syst; /* Sisten za simbolno racunanje */
        /* Za funkcije simbolnega kalkulatorja, ki so definirane v ukazni
        datoteki: */
        stack args; /* Sklad argumentov funkcije kalkulatorja, definirane prek
                       interpreterja */
        int numargs; /* Stevilo argumentov funkcije --||-- */
        double doubleret;  /* Vrednost, ki jo vrne funkcija --||-- */
        stack funcdefstack; /* Sklad definicij funkcij --||-- */
        /* Sklad definicij funkcij: */
        stack functionstack;
        /* Sledenje klicov: */
        stack callst;  /* Rekurzivna struktura klicev funkcije */
        char trace;    /* Ce je 1, se sledijo klici funkcij (imena funkcij se
                          nalagajo na callst). */
        /* Preglejevanje sintakse in razhroscevanje: */
        licom lint;    /* Vrsticni interpreter - za razhroscevanje */
        char debug, check; /* Opciji za debagiranje in preverjanje sintakse */
        int linespre,  /* St. vrstic kode pred trenutno pozicijo, ki se izpise */
            linespost; /* St. vrstic kode pred trenutno pozicijo, ki se izpise */
        char stop,     /* Ce je 1, se pri razhroscevanju ustavi pred nasl. ukazom */
             stepover; /* Ce je 1, se izvrsi naslednji ukaz, pri cemer se ne
                          ustavlja pri interpretaciji njegovih blokov */
        int numexec;   /* Stevilo ukazov, ki se naj izvrsijo pred ustavitvijo */
        int stoplevel;  /* Pove, na katerem nivoju naj se debugger ustavi */
        char watch;    /* Ce je 1, se pri vsakem pogonu vrsticnega interpreterja
                          izpisejo vrednosti izrazov na skladu watchst. */
        stack watchst; /* Sklad izrazov, katerih vrednosti opazujemo. */
        char *dfname;  /* Ime pomozne datoteke za izvrsevanje uporabnikovih
                          ukazov v datotecnem interpreterju. */
        char  sball;   /* Ce je 1, so suspendirani vsi breaki razen tisti na
                          skladu (...)->ab. */
        stack sb,      /* Suspendirani brejki */
              ab;      /* Aktivirani brejki */
        } *ficom;


/*
typedef _ficom *ficom;
*/


typedef struct{
        ficom fcom;
        char *filename;
        long begin,end;
        char *name,*block;
        stack argnames;
        } _fifuncdata;

typedef _fifuncdata *fifuncdata;


typedef struct{
        char *name;
        void (*action) (ficom);
        void (*checkaction) (ficom);
        } _fifunction;

typedef _fifunction *fifunction;





int fintgetoutdig(void);
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu fint.c.
    $A Igor mar99; */

int fintgetoutchar(void);
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu fint.c.
    $A Igor mar99; */

void fintsetoutdig(int num);
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu fint.c.
    $A Igor mar99; */

void fintsetoutchar(int num);
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu fint.c.
    $A Igor mar99; */

fifunction newfifuction(void);
    /* Alocira prostor za objekt tipa fifunction in vrne kazalec nanj; Vsa
    polja objekta postavi na NULL.
    $A Igor mar98; */

void dispfifunction(fifunction *func);
    /* Zbrise objekt tipa fifunction *func in ga postavi na NULL. Zbrise tudi 
    (*func)->name.
    $A Igor mar98; */

ficom newficom(void);
      /* Vrne kazalec na objekt tipa _ficom, za katerega alocira prostor. Vsa
      polja strukture postavi na 0, razen obeh skaldov, za katera se tudi 
      alocira prostor. */

void dispficom(ficom *fi);
     /* Sprosti spomin za spremenljivko **fi. Zbrise tudi sklada (**fi).actions
     in (**fi).commands, s tem da pri skladu (**fi).commands zbrise tudi vse 
     nize, ki so na tem skladu. Sprosti se tudi spomin za (**fi).filename. */

void printficom(ficom com);
     /* Izpise vrednosti polj spremenljivke *com. */

void fintpreparetemp(ficom fcom);
    /* Pripravi zacasno datoteko fcom->temp za uporabo: ce ni odprta, jo odpre
    (po potrebi tudi doloci zacasno ime), ce je datoteka v rabi, pa pozicijo
    postavi na prvo pozicijo za delom datoteke, ki je v rabi.
    $A Igor apr99; */

void fintclosetemp(ficom fcom);
    /* Ce je mozno, zapre zacasno datoteko fcom->temp, ce datoteka ni v rabi,
    zbrise tudi povezano fizicno datoteko, ce ta obstaja.
    $A Igor apr99; */

void fintpos(ficom fcom,char **functionname,char **originalfilename,
             int *originalline,char **filename,int *line);
    /* Vrne trenutno pozicijo v datotecnem interpreterju fcom. V *functionname
    zapise kazalec na ime funkcije, ki se trenutno izvaja, v *filename ime
    datoteke, ki se interpretira, v *line vrstico v tej datoteki, kjer je
    trenutna pozicija interpretacije, v originalfilename ime originalne
    datoteke, iz katere izvira koda, ki se trenutno interpretira, v
    *originalline pa stevilko vrstice v tej datoteki, kjer se nahaja trenutno
    interpretirana koda. Ce je interpretirana koda ze tako v originalni
    datoteki, vrne v *filename NULL.
     Argumenti functionname, filename in originalfiilename so lahko NULL, v tem
    primeru se ne zapisejo ustrezni podatki. Kazalcev, na katere ti kazajo po
    izhodu iz funkcije, se ne sme brisati s free, ker se zanje v funkciji ne
    alocira prostor!
    $A Igor apr99; */

void fprintficallstack(FILE *fp,ficom com);
    /* V datoteko fp zapise klicno zaporedje funkcij, ki se v trenutku klica
    te funkcije izvajajo v datotecnem interpreterju com.
    $A Igor mar99; */

void printficallstack(ficom com);
    /* Na standardni izhod fp zapise klicno zaporedje funkcij, ki se v trenutku
    klica te funkcije izvajajo v datotecnem interpreterju com.
    $A Igor mar99; */

void fiwaituser(ficom com);
    /* Izpise podatke o datoteki, ki se interpretira, in mestu interpretacije
    ter caka, dokler uporabnik ne pritisne tipke <Return>. Funkcija se
    uporablja znotraj funkcij, ki preverjajo sintakso funkcij, instaliranih na
    datotecni interpreter. Ta funkcija se razlikuje od fiwaituserout po tem, da
    ne uporablja lokalne spremenljivke functionname, ampak le podatke, ki so na
    com.
    $A Igor apr1998; */
    
void fileinterpret(ficom com);
     /* Interpretira ukaze v datoteki com->fp. Vsa navodila za interpretacijo so
     zbrana v com. Funkcija deluje tako, da v datoteki isce ukaze, to je nize,
     nalozene na com->commands, in ko najde taksen niz, izvrsi pripadajoco mu
     funkcijo. Te funkcije so nalozene na skladu com->actions. */

fifunction instficom(ficom com,char * command,void action(ficom));
    /* Na ukazno spremenljivko com, ki doloca nacin interpretacije datoteke,
    instalira nov ukaz command, ki mu pripada izvrsitev akcije action. Funkcija
    vrne objekt tipa fifunction, kamor nalozi podtke o funkciji (ta objekt da
    tudi na sklad com->functions). Ce funkcija ne uspe instalirati ukaza, vrne
    NULL.
    $A Igor <== dec97 apr98; */

fifunction instficomall(ficom com,char * command,void action(ficom),
                  void checkaction(ficom));
    /* Na ukazno spremenljivko com, ki doloca nacin interpretacije datoteke,
    instalira nov ukaz command, ki mu pripadata izvrsitvena funkcija action
    in kontrolna funkcija checkaction. checkaction je funkcija za preverjanje
    sintakse funkcije. Funkcija vrne objekt tipa fifunction, kamor nalozi
    podtke o funkciji (ta objekt da tudi na sklad com->functions). Ce funkcija
    ne uspe instalirati ukaza, vrne NULL.
    $A Igor apr98; */
    
fifunction setficomcheck(ficom com,char *command,void checkaction(ficom));
    /* Za kontrolno funkcijo, ki kontrolira sintakso funkcije z imenom command
    v datotecnem interpreterju com, postavi funkcijo checkaction. Funkcija
    najprej poisce podatke o ukazu command na skladu com->functions in nastavi
    polje (...)->checkaction pri ustreznem ukazu. Ce je uspesna, vrne objekt
    tipafifunction, na katerem je nastavila kontrolno funkcijo, drugace vrne
    NULL. 
    $A Igor apr98; */

fifunction instficomall(ficom com,char * command,void action(ficom),
                  void checkaction(ficom));
    /* Na ukazno spremenljivko com, ki doloca nacin interpretacije datoteke,
    instalira nov ukaz command, ki mu pripadata izvrsitvena funkcija action
    in kontrolna funkcija checkaction. checkaction je funkcija za preverjanje
    sintakse funkcije. Funkcija vrne objekt tipa fifunction, kamor nalozi
    podtke o funkciji (ta objekt da tudi na sklad com->functions). Ce funkcija
    ne uspe instalirati ukaza, vrne NULL.
    $A Igor apr98; */

void fintblock(ficom com,long from, long to);
       /* Izvrsi interpretacijo bloka v datoteki od from do to. Ko konca
       interpretacijo tega dela, Postavi com->stopint, com->from, com->to in
       com->pos na stare vrednosti. 
       OPOZORILO: Pred interpretaijo bloka se com->from postavi kar na from in
       ne na from+1, enako se com->to postavi kar na to. */

void fintfileblock(ficom com,char *name,long from, long to);
    /* Izvrsi interpretacijo bloka v datoteki z imenom name od from do to.
    Ko konca interpretacijo tega dela, postavi com->fp in com->filename na
    stare vrednosti, com->stopint, com->from, com->to in com->pos pa se
    postavijo na stare vrednosti ze v funkciji fintblock(), ki jo ta funkcija
    klice.
    Ce je from enek 0, se datoteka interpretira od zacetka. Ce je to enak 0, se
    datoteka interpretira do konca.
    OPOZORILO: Pred interpretaijo bloka se com->from postavi kar na from in
    ne na from+1, enako se com->to postavi kar na to.
    $A Igor jun97; */

static void fintfile(ficom com,char *name);
    /* Izvrsi interpretacijo celotne datoteke z imenom name. Ko konca
    interpretacijo, postavi com->fp, com->filename, com->stopint, com->from,
    com->to in com->pos na stare vrednosti (to naredita v bistvu funkciji
    fintfileblock() in fintblock(), ki sta klicani ob izvedbi te funkcije).
    $A Igor jun97; */

void setficheck_write1(void (*func) (char *funcname,long from,long to,ficom com));
    /* Postavi funkcijo, ki se klice v ficheck_write1, na func.
    $A Igor nov99; */

void setfi_write1(void (*func) (char *funcname,FILE *fp,long from,long to,ficom com));
    /* Postavi funkcijo, ki se klice v fi_write1, na func.
    $A Igor nov99; */

void ficheck_write1(char *funcname,long from,long to,ficom com);
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_write1 v ukazni
    datoteki. From in to sta zacetna in koncna pozicija odseka v ukazni
    datoteki, kjer so zapisana navodila za to, kaj naj se izpise.
    Funkcija klice funkcijo, na katero kaze fi_write1ptr, ta pa originalno kaze
    na fi_write1defaunlt, kar se lahko spremeni s funkcijo setfi_write1.
    $A Igor nov99; */

void fi_write1(char *funcname,FILE *fp,long from,long to,ficom com);
    /* Funkcija za izpis, ki jo uporabljata fi_write in fi_fwrite. V datoteko
    fp se zapisejo stvari, kot je zapisano v interpretirani datoteki com->fp
    med pozicijama from in to.
    Funkcija klice funkcijo, na katero kaze fi_write1ptr, ta pa originalno kaze
    na fi_write1defaunlt, kar se lahko spremeni s funkcijo setfi_write1.
    $A Igor nov99; */

void fimountbas(ficom com,FILE *outfile,ssyst syst);
     /* Na com osnovne ukaze, ki sluzijo za interpretacijo datoteke. outfile je
     izhodna datoteka, syst pa je sistem za simbolno racunanje, ki podpira 
     interpretacijo.
     POZOR!
     Za spremenljivko com mora biti prostor ze alociran in inicializiran. */

void fimountall(ficom com, FILE *outfile);
     /* Na com montira osnovne ukaze, ki sluzijo za interpretacijo datoteke.
     Poleg tega tudi vzpostavi podporni sistem za simbolno racunanje. 
     POZOR!
     Za spremenljivko com mora biti prostor ze alociran in inicializiran.*/


/* FUNKCIJE ZA UPORABO INTERPRETERJA IZ PROGRAMA:
Interpreter lahko uporabimo na razlicne nacine:
  1. Z ukazom interpstring(fcom,string) neposredno interpretiramo niz string.
Ce smo ze prej kaj pisali v buffer za interpretacijo (recimo s funkcijo
addfintbuf(), se zinterpretira najprej to.
Primer: nterpstring(fcom,"copyvector{measmom meas0}");
  2. Z ukazi addtofintbuf(str) najprej napomnimo buffer s tem, kar zelimo
interpretirati, nato klicemo ukaz interpfintbuf(fcom).
Primer: addtofintbuf("copyvector{measmom meas0}");
sddtointbuf("copyvector{parammom param0}"); interpfintbuf(fcom);
  3. Buffer lahko napolnimo s katerokoli funkcijo za pisanje v datoteke, pri
cemer dobimo kazalec na buffer (ki se tvori, ce se ni narejen) s klicem
funkcije fintbuf().
Primer: fprintf(fintbuf(),"write{$%i}\n",name); interpfintbuf(fcom);
  Buffer za interpretacijo lahko polnimo na kateregakoli od opisanih nacinov,
vazno je le, da na koncu (ko ga hocemo interpretirati) izvedemo ali funkcijo
interpstring() ali interpfintbuf().
*/

FILE *fintbuf(void);
    /* Vrne datoteko (buffer), kamor lahko pisemo ukaze za interpretacijo z
    datotecnim interpreterjem. Funkcija vedno vrne odprto datoteko (po potrebi
    jo sama odpre). V to datoteko lahko pisemo s katerokoli funkcijo za pisanje
    v datoteke, dokler ne klicemo katerega od ukazov, ki to datoteko zapre
    (interpfintbuf() ali interpstring()).
    $A Igor mar99; */

int addtofintbuf(char *str);
    /* Niz str zapise v datoteko (buffer), ki se pripravlja za interpretacijo
    z datotecnim interpreterjem. Datoteka se po potrebi odpre na novo.
    Interpretacijo lahko potem izvedemo z ukazom interpfintbuf() ali
    interpstring(), z izvedmo katerega od teh ukazov se buffer tudi zapre.
    $A Igor mar99; */

int interpfintbuf(ficom com);
    /* Pozene se interpretacija zacasne datoteke, v katero smo pisali ukaze za
    interpretacijo, v interpreterju com. datoteka se pred interpretacijo zapre,
    po interpretaciji pa se zbrise.
    $A Igor mar99; */

int interpstring(ficom com,char *str);
    /* V datotecnem interpreterju com se interpretira niz str. Ce smo pred
    izvedmo te funkcije kaj napisali v zacasno datoteko za interpretacijo,
    se najprej zinterpretira to. Zacasna datoteka (buffer) se pred
    interpretacijo najprej zapre, po njej pa se zbrise.
    $A Igor mar99; */
















#endif    /* (not defined) INCLUDED_fint */
