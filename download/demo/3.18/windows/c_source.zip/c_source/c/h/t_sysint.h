

/* Undefine IGTEST if this is not Igor's test version (just uncomment
the comment at #undef IGTEST )! */


/*
#define IGTEST
*/

#undef IGTEST








/* Autmatically set data beyond this - do not change! */
#define CDD 6                      
#define CMM 1                      
#define CYY 2003                      



