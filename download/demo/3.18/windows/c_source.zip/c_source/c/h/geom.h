

/* Code that prevents multiple inclusion: */
#ifndef INCLUDED_geom
#define INCLUDED_geom



/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_st
#include <st.h>
#endif
#ifndef INCLUDED_vec
#include <vec.h>
#endif
#ifndef INCLUDED_mat  
#include <mat.h>
#endif


                 /****************************/
                 /*                          */
                 /*  GEOMETRIJSKE OPERACIJE  */
                 /*                          */
                 /****************************/




                   /**********************/
                   /*                    */
                   /*  DEFINICIJE TIPOV  */
                   /*                    */
                   /**********************/




    /* TIPI ZA 3D GEOMETRIJO */


typedef struct {
    double x, y, z;
} _vec3d;

typedef _vec3d *vec3d;

typedef struct {
    _vec3d x, y, z;
} _mat3d;

typedef _mat3d *mat3d;



    /* TIPI ZA KUBICNE ZLEPKE: */

typedef struct _CUBSPLDATA {
  /* Vhodni podatki: robna odvoda, stevilo tock, abscise in ordinate tock: */
  double k1,kn;
  int n,rep; /* rep: is 1 if this is auxiliary repair structure, otherwise 0. */
  struct _CUBSPLDATA *reverse;
  vector x,y;
  /* Vektor izracunanih odvodov v notran. vozliscih u: */
  vector u;
  /* Matrika sistema za izracun u in njena dekompozicija, vektor desnih strani: */
  matrix A,Adec;
  vector b;
  indtab Aind;
  /* Odvodi u po abscisah vozlisc, ordinatah vozlisc in robnih odvodih: */
  stack dudx,dudy;
  vector dudk1,dudkn;
  /* Pomozne spremenljivke, ki se uporabijo pri racunanju odvodob po parametrih
  za hranjenje odvoda matrike A in vektorjev b in u po danem parametru: */
  matrix dA;
  vector db,du;  /* opomba: du se nikoli ne alocora, uporablja se le
                              kot kazalec. */
} _cubspldata;

typedef _cubspldata *cubspldata;


/* TIPI ZA DVOSTOPENJSKE TRANSFORMACIJE: */



typedef struct {
    _vec3d r1,r2,r3,r4;  /* koord. tock v fiz. prost., ki dolocajo transf. */
    /* _vec3d ro,r; */  /* Tocka v referencnih in fizicnih koordinatah */
    char calctransfcoef; /* indikator, da so izracunani koef. transformacije */
    /* Koeficienti transformacije, ki stojijo pri razlicnih potencah ksi in
    eta: */
    _vec3d a0,a1,a2,a12;
} _cubtrdata2d;

typedef _cubtrdata2d *cubtrdata2d;






                    /********************/
                    /*                  */
                    /*  KUBICNI ZLEPKI  */
                    /*                  */
                    /********************/



/* FUNKCIJE ZA MANIPULACIJO S TIPOM cubspldata: */

cubspldata newcubspldata(void);
    /* Naredi nov objekt tipa cubspldata in ga vrne, kazalce na objektu pa pred
    tem postavi na NULL.
    $A Igor avg01; */

void dispcubsplauxvar(cubspldata cs);
    /* Zbrise pomozne alocirane podatke na *cs, torej vse razen cs->x in
    cs->y. Ustrezne kazalce postavi na NULL.
    $A Igor avg01; */

void dispcubsplintvar(cubspldata cs);
    /* Zbrise vse tiste pomozne spremenljivke kubicnega zlepka cs, ki jih
    rabimo za vmesne rezultate, niso pa potrebni pri samem racunanju, ko imamo
    ze izracunane potrebne pomozne spremenljivke (t.j. vektor odvodov v
    notranjih vozliscih in njegovi odvodi po parametrih, glede na katere bomo
    racunali obcutljivosti). To funkcijo lahko uporabimo, da prihranimo
    prostor, ki bi ga drugace cs po nepotrebnem zasedel, vendar deluje le,
    ce pred njenim klicem pripravimo vse potrebne podatke za izracune vrednosti
    in senzitivnosti kubicnega zlepka, ki bodo sledili. To iz vedemo s pomocjo
    funkcij prepcubsplval(), prepcubsplsensy() in podobnih.
    $A Igor avg01; */

void dispcubsplvar(cubspldata cs);
    /* Zbrise vse podatke na cs.
    $A Igor avg01; */

void dispcubspldata(cubspldata *pcs);
    /* Sprosti prostor za podatke o kubicnem zlepku, na katerega kaze **pcs, in
    postavi *pcs na NULL.
    $A Igor avg01; */

cubspldata copycubspldata(cubspldata cs1,cubspldata *cs2);
    /* Vrne kopijo cs1. Ce je cs2 razlicen od NULL, skopira cs1 v *cs2 in vrne
    *cs2. Funkcija je konstruirana podobno kot recimo copyvector().
    $A Igor avg01; */

void fprintcubsplstate(FILE *fp,cubspldata cs);
    /* V datoteko fp izpise stanje sistema za racunanje kubicnih zlepkov.
    $A Igor avg01; */

void printcubsplstate(cubspldata cs);
    /* Na standardni izhod izpise stanje sistema za racunanje kubicnih zlepkov.
    $A Igor avg01; */


/* FUNKCIJE ZA NASTAVITEV KUBICNEHA ZLEPKA: */

cubspldata setcubspl(cubspldata *csp,vector x,vector y,double k1,double kn);
    /* Nastavi definicijo kubicnega zlepka. V vektorju x so abscise, v vektorju
    y pa ordinate vozlisc zlepka, v k1 in kn pa predpisani vrednosti odvoda v
    skrajnih vozliscih. Ce sta x in y NULL, se zbrise trenutna definicija
    zlepka. Vektorja morata imeti enaki dimenziji. Ta funkcija nicesar ne
    izracuna, temvec le postavi podatke na **csp, ki definirajo zlepek.
    Funkcija vrne *csp. Ce je csp NULL, se objekt, ki ga funkcija vrne, tvori
    na novo (ce je seveda situacija taksna, da lahko vrne funkcija kazalec
    razlicen od NULL).
     Ce pride do napake (npr. ce je eden od vektorjev x in y NULL ali ce imata
    razlicno dimenzijo), se *csp (ce obstaja) zbrise in postavi na NULL, javi
    se napaka in funkcija vrne NULL. Ce sta x in y enaka NULL, funkcija ne javi
    napake, ker je to predvidena situacija.
    $A Igor avg01; */

cubspldata setcubspldir(cubspldata *csp,vector x,vector y,double k1,double kn);
    /* Nastavi definicijo kubicnega zlepka. Funkcija deluje podobno kot
    setcubspl(), le da se vektorja abscis in ordinat vozlisc postavita DIREKTNO
    na x in y in se ne kopirata. Ce sta v sistemu ustrezna vektorja abscis in
    ordinat vozlisc ze alocirana, se ta vektorja zbriseta. To funkcijo
    uporabljamo namesto obicajne le izjemoma, predvsem takrat, ko hocemo
    prihraniti cas za kopiranje.
    $A Igor avg01; */



/* KONCNE FUNKCIJE ZA RACUNANJE KUBICNIH ZLEPKOV IN ODVODOV PO PARAMETRIH: */


double cubsplval(cubspldata cs,double x);
    /* Izracuna vrednost kubicnega zlepka cs v tocki x. Podatki na cs, ki
    dolocajo zlepek, so morali biti nastavljeni pred klicem te funkcije npr.
    s funkcijo setcubspline().
    Funkcija samodejno izracuna vmesne rezultete, ki se niso bili izracunani,
    in uporabi tiste, ki so bili.
    $A Igor avg01; */

double cubsplsensy(cubspldata cs,int i,double x);
    /* Vrne odvod vrednost kubicnega zlepka cs v tocki x po ordinati i-tega
    vozlisca, ki doloca zlepek. Podatki, ki dolocajokubicni zlepek, so morali
    biti nastavljeni pred klicem te funkcije npr. s funkcijo setcubspline().
    Funkcija samodejno izracuna vmesne rezultete, ki se niso bili izracunani,
    in uporabi tiste, ki so bili.
    $A Igor avg01; */

double cubsplsensk1(cubspldata cs,double x);
    /* Vrne odvod vrednost kubicnega zlepka cs v tocki x po predpisanem odvodu
    v prvem vozliscu k1. Podatki, ki dolocajo kubicni zlepek, so morali biti
    nastavljeni pred klicem te funkcije npr. s funkcijo setcubspline().
    Funkcija samodejno izracuna vmesne rezultete, ki se niso bili izracunani,
    in uporabi tiste, ki so bili.
    $A Igor avg01; */

double cubsplsenskn(cubspldata cs,double x);
    /* Vrne odvod vrednost kubicnega zlepka cs v tocki x po predpisanem odvodu
    v zadnjem vozliscu kn. Podatki, ki dolocajo kubicni zlepek, so morali biti
    nastavljeni pred klicem te funkcije npr. s funkcijo setcubspline().
    Funkcija samodejno izracuna vmesne rezultete, ki se niso bili izracunani,
    in uporabi tiste, ki so bili.
    $A Igor avg01; */

double cubsplsensx(cubspldata cs,int i,double x);
    /* Vrne odvod vrednost kubicnega zlepka cs v tocki x po abscisi i-tega
    vozlisca, ki doloca zlepek. Podatki, ki dolocajokubicni zlepek, so morali
    biti nastavljeni pred klicem te funkcije npr. s funkcijo setcubspline().
    Funkcija samodejno izracuna vmesne rezultete, ki se niso bili izracunani,
    in uporabi tiste, ki so bili.
    $A Igor avg01; */



/* FUNKCIJE ZA SPROZEN IZRACUN DOLOCENIH VMESNIH VREDNOSTI: */


void prepcubsplval(cubspldata cs);
    /* Pripravi vse potrebno za racunanje vrednosti kubicnega zlepka cs. To se
    sicer samodejno naredi, ko prvic klicemo funkcijo za izracun vrednosti,
    vendar hocemo vcasih to narediti eksplicitno, ker lahko tako takoj po
    pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplintvar()
    in tako prihranimo prostor.
    $A Igor avg01; */

void prepcubsplsensy(cubspldata cs,int i);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka cs
    po ordinati i-tega vozlisca. To se sicer samodejno naredi, ko prvic klicemo
    funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to narediti
    eksplicitno, ker lahko tako takoj po pripravi za racunanje vrednosti in
    senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse vmesne rezultate
    s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */

void prepcubsplsensyall(cubspldata cs);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka cs
    po ordinati kateregakoli vozlisca. To se sicer samodejno naredi, ko prvic
    klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to
    narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */

void prepcubsplsensk1(cubspldata cs);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka po
    predpisanem odvodu v prvem vozliscu. To se sicer samodejno naredi, ko prvic
    klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to
    narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */

void prepcubsplsenskn(cubspldata cs);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka cs
    po predpisanem odvodu v zadnjem vozliscu. To se sicer samodejno naredi, ko
    prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to
    narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */

void prepcubsplsensx(cubspldata cs,int i);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka cs
    po abscisi i-tega vozlisca. To se sicer samodejno naredi, ko prvic klicemo
    funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to narediti
    eksplicitno, ker lahko tako takoj po pripravi za racunanje vrednosti in
    senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse vmesne rezultate
    s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */

void prepcubsplsensxall(cubspldata cs);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka
    po abscisi kateregakoli vozlisca. To se sicer samodejno naredi, ko prvic
    klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to
    narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */



    /* SISTEM KUBICNIH ZLEPKOV, DO KATERIH DOSTOPAMO Z ID. STEVILKAMI: */


/* OPIS SISTEMA: 
Do kubicnih zlepkov na skladu cubsplsys dostopamo preko njihovih
identifikacijskih stevilk, ki so zaporedne stevilke zlepkov na tem skladu. Na
skladu so zlepki nalozeni kot kazalci tipa cubspldata. Funkcije sistema, ki
tvorijo nov kubicni zlepek, zato vedno vrnejo njegovo identifikacijsko stevilko,
ki jo doloci sam sistem. Prav tako moramo v funkcijah, ki izvajajo kalkulacije
s kubicnim zlepkom, navesti identifikacijsko stevilko. Eden od zlepkov je
priviligiran ("globalni"), to je tisti z identifikacijsko stevilko globcubsplid.
Po dogovoru vse funkcije delujejo tako, da se identifikacijska stevilka 0 vedno
razume kot globcubsplid, torej identifikacijska stevilka globalnega kubicnega
zlepka.
OPOZORILO ZA PROGRAMIRANJE:
Ce je dolocen element NULL, se smatra, da ustrezen kubicni zlepek ne obstaja
in je ustrezna identifikacijska stevilka prosta, torej se lahko zasede pri
klicih funkcij, ki naredijo nov zlepek.
*/


void fprintcubsplsysdata(FILE *fp,int id);
    /* V datoteko fp izpise podatke o sistemu kubicnih zlepkov, na katere se
    sklicjemo s pomocjo identifikacijskih stevilk, ce je id manj od 0. Ce je id
    0, se izpisejo le podatki o globalnem kubicnem zlepku, ce pa je id vec od 0,
    se izpisejo le podatki o kubicnem zlepku z ident. st. id.
    $A Igor sep01; */

void printcubsplsysdata(int id);
    /* Na stand. izhod izpise podatke o sistemu kubicnih zlepkov, na katere se
    sklicjemo s pomocjo identifikacijskih stevilk. Ce je id 0, se izpisejo le
    podatki o globalnem kubicnem zlepku, ce pa je id vec od 0, se izpisejo le
    podatki o kubicnem zlepku z ident. st. id.
    $A Igor sep01; */



  /* FUNKCIJE ZA DEFINICIJO KUBICNIH ZLEPKOV SISTEMA: */


int setnewcubspl(vector x,vector y,double k1,double kn);
    /* V sistemu kubicnih zlepkov definira nov kubicni zlepek z vektorjema
    abscis in ordinat kontrolnih tock x in y ter z robnima odvodoma k1 in kn.
    $A Igor avg01; */

void setcubsplid(int id,vector x,vector y,double k1,double kn);
    /* Kubicni zlepek z identifikacijsko stevilko id definira na novo s podatki
    x, y, k1 in kn. Ce ta zlepek ne obstaja, ga naredi, ce le id ni prevelik
    glede na najvisko obstojeco ident. stevilko v sistemu.
    $A Igor avg01; */

int setcubsplglob(vector x,vector y,double k1,double kn);
    /* Definira globalni zlepek z vektorjema abscis in ordinat x in y ter
    robnima odvodoma k1 in kn. Funkcija vrne identifikacijsko stevilko
    globalnega zlepka.
    $A Igor avg01; */



/* DIREKTNA DEFINICIJA BREZ KOPIRANJA VEKTOREV: */

static int setnewcubspldir(vector x,vector y,double k1,double kn);
    /* V sistemu kubicnih zlepkov definira nov kubicni zlepek z vektorjema
    abscis in ordinat kontrolnih tock x in y ter z robnima odvodoma k1 in kn.
    Funkcija spravi na podatke o zlepku direktno vektorja x in y in ne njunih
    kopij, tako da po izvedbi funkcije vektorjev x in y, s katerima smo klicali
    funkcijo, ne smemo eksplicitno brisati.
    $A Igor avg01; */

void setcubspldirid(int id,vector x,vector y,double k1,double kn);
    /* Kubicni zlepek z identifikacijsko stevilko id definira na novo s podatki
    x, y, k1 in kn. Ce ta zlepek ne obstaja, ga naredi, ce le id ni prevelik
    glede na najvisko obstojeco ident. stevilko v sistemu.
    Funkcija spravi na podatke o zlepku direktno vektorja x in y in ne njunih
    kopij, tako da po izvedbi funkcije vektorjev x in y, s katerima smo klicali
    funkcijo, ne smemo eksplicitno brisati.
    $A Igor avg01; */

int setcubsplglobdir(vector x,vector y,double k1,double kn);
    /* Definira globalni zlepek z vektorjema abscis in ordinat x in y ter
    robnima odvodoma k1 in kn. Funkcija vrne identifikacijsko stevilko
    globalnega zlepka.
    Funkcija spravi na podatke o zlepku direktno vektorja x in y in ne njunih
    kopij, tako da po izvedbi funkcije vektorjev x in y, s katerima smo klicali
    funkcijo, ne smemo eksplicitno brisati.
    $A Igor avg01; */



    /* RACUNANJE Z ZLEPKI, NA KATERE SE SKLICUJEMO Z IDENTIFIKACIJSKIMI
    STEVILKAMI, IN Z GLOBALNIM ZLEPKOM: */


double cubsplvalid(int id,double x);
    /* Izracuna vrednost kubicnega zlepka z identifikac. st. id v tocki x.
    $A Igor nov00 avg01; */

double cubsplglobval(double x);
    /* Izracuna vrednost globalnega kubicnega zlepka v tocki x.
    $A Igor nov00 avg01; */

double cubsplsensyid(int id,int i,double x);
    /* Vrne odvod vrednost kubicnega zlepka z id. st. id v tocki x po ordinati
    i-tega vozlisca, ki doloca zlepek.
    $A Igor nov00 avg01; */

double cubsplglobsensy(int i,double x);
    /* Vrne odvod vrednost globalnega kubicnega zlepka v tocki x po ordinati
    i-tega vozlisca, ki doloca zlepek.
    $A Igor nov00 avg01; */

double cubsplsensk1id(int id,double x);
    /* Vrne odvod vrednost kubicnega zlepka z id. st. id v tocki x po
    predpisanem odvodu v prvem vozliscu.
    $A Igor nov00 avg01; */

double cubsplglobsensk1(double x);
    /* Vrne odvod vrednost globalnega kubicnega zlepka v tocki x po predpisanem
    odvodu v prvem vozliscu.
    $A Igor nov00 avg01; */

double cubsplsensknid(int id,double x);
    /* Vrne odvod vrednost kubicnega zlepka z id. st. id v tocki x po
    predpisanem odvodu v zadnjem vozliscu.
    $A Igor nov00 avg01; */

double cubsplglobsenskn(double x);
    /* Vrne odvod vrednost globalnega kubicnega zlepka v tocki x po predpisanem
    odvodu v zadnjem vozliscu.
    $A Igor nov00 avg01; */

double cubsplsensxid(int id,int i,double x);
    /* Vrne odvod vrednost kubicnega zlepka z id. st. id v tocki x po abscisi
    i-tega vozlisca, ki doloca zlepek.
    $A Igor nov00 avg01; */

double cubsplglobsensx(int i,double x);
    /* Vrne odvod vrednost globalnega kubicnega zlepka v tocki x po abscisi
    i-tega vozlisca, ki doloca zlepek.
    $A Igor nov00 avg01; */



/* FUNKCIJE ZA SPROZENO PRIPRAVO VMESNIH REZULTATOV: */


void prepcubsplvalid(int id);
    /* Pripravi vse potrebno za racunanje vrednosti kubicnega zlepka st. id.
    To se sicer samodejno naredi, ko prvic klicemo funkcijo za izracun
    vrednosti, vendar hocemo vcasih to narediti eksplicitno, ker lahko tako
    takoj po pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplintvarid()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */

void prepcubsplglobval(void);
    /* Pripravi vse potrebno za racunanje vrednosti globalnega kubicnega zlepka.
    To se sicer samodejno naredi, ko prvic klicemo funkcijo za izracun
    vrednosti, vendar hocemo vcasih to narediti eksplicitno, ker lahko tako
    takoj po pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplglobintvar()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */

void prepcubsplsensyid(int id,int i);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po ordinati i-tega vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvarid() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */

void prepcubsplglobsensy(int i);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po ordinati i-tega vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */

void prepcubsplsensyallid(int id);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka z
    id. st. id po ordinati kateregakoli vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */

void prepcubsplglobsensyall(void);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po ordinati kateregakoli vozlisca. To se sicer samodejno
    naredi, ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo
    vcasih to narediti eksplicitno, ker lahko tako takoj po pripravi za
    racunanje vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo
    vse vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */

void prepcubsplsensk1id(int id);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka z
    idendifikacijsko st. id po predpisanem odvodu v prvem vozliscu. To se sicer
    samodejno naredi, ko prvic klicemo funkcijo za izracun taksnega odvoda,
    vendar hocemo vcasih to narediti eksplicitno, ker lahko tako takoj po
    pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplintvarid()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */

void prepcubsplglobsensk1(void);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po predpisanem odvodu v prvem vozliscu. To se sicer
    samodejno naredi, ko prvic klicemo funkcijo za izracun taksnega odvoda,
    vendar hocemo vcasih to narediti eksplicitno, ker lahko tako takoj po
    pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplglobintvar()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */

void prepcubsplsensknid(int id);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka z
    idendifikacijsko st. id po predpisanem odvodu v zadnjem vozliscu. To se
    sicer samodejno naredi, ko prvic klicemo funkcijo za izracun taksnega
    odvoda, vendar hocemo vcasih to narediti eksplicitno, ker lahko tako takoj
    po pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplintvarid()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */

void prepcubsplglobsenskn(void);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po predpisanem odvodu v zadnjem vozliscu. To se sicer
    samodejno naredi, ko prvic klicemo funkcijo za izracun taksnega odvoda,
    vendar hocemo vcasih to narediti eksplicitno, ker lahko tako takoj po
    pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplglobintvar()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */

void prepcubsplsensxid(int id,int i);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po abscisi i-tega vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvarid() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */

void prepcubsplglobsensx(int i);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po abscisi i-tega vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */

void prepcubsplsensxallid(int id);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka z
    id. st. id po abscisi kateregakoli vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */

void prepcubsplglobsensxall(void);
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po abscisi kateregakoli vozlisca. To se sicer samodejno
    naredi, ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo
    vcasih to narediti eksplicitno, ker lahko tako takoj po pripravi za
    racunanje vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo
    vse vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */


/* BRISANJE DEFINICIJ: */

void dispcubsplid(int id);
    /* Zbrise definicijo kub. zlepka z identifikacijo id; po klicu te funkcije
    lahko stevilko id prevzamejo na novo definirani zlepki.
    $A Igor nov00 avg01; */

void dispcubsplglob(void);
    /* Zbrise definicijo globalnega kub. zlepka. Sprosti se ves spominski
    prostor povezan s tem zlepkom.
    $A Igor nov00 avg01; */

void dispcubsplintvarid(int id);
    /* Zbrise vse tiste pomozne spremenljivke kubicnega zlepka st. id, ki
    jih rabimo za vmesne rezultate, niso pa potrebni pri samem racunanju, ko
    imamo ze izracunane potrebne pomozne spremenljivke (t.j. vektor odvodov v
    notranjih vozliscih in njegovi odvodi po parametrih, glede na katere bomo
    racunali obcutljivosti). To funkcijo lahko uporabimo, da prihranimo prostor,
    ki bi ga drugace sistem po nepotrebnem zasedel, vendar deluje le, ce pred
    njenim klicem pripravimo vse potrebne podatke za izracune vrednosti in
    senzitivnosti kubicnega zlepka, ki bodo sledili. To iz vedemo s pomocjo
    funkcij prepcubsplglobval(), prepcubsplglobsensy() in podobnih.
    $A Igor nov00 avg01; */

void dispcubsplglobintvar(void);
    /* Zbrise vse tiste pomozne spremenljivke globalnega kubicnega zlepka, ki
    jih rabimo za vmesne rezultate, niso pa potrebni pri samem racunanju, ko
    imamo ze izracunane potrebne pomozne spremenljivke (t.j. vektor odvodov v
    notranjih vozliscih in njegovi odvodi po parametrih, glede na katere bomo
    racunali obcutljivosti). To funkcijo lahko uporabimo, da prihranimo prostor,
    ki bi ga drugace sistem po nepotrebnem zasedel, vendar deluje le, ce pred
    njenim klicem pripravimo vse potrebne podatke za izracune vrednosti in
    senzitivnosti kubicnega zlepka, ki bodo sledili. To iz vedemo s pomocjo
    funkcij prepcubsplglobval(), prepcubsplglobsensy() in podobnih.
    $A Igor nov00 avg01; */

void dispcubsplvarid(int id);
    /* Zbrise vse pomozne spremenljivke kubicnega zlepka st. id. Ne zbrise
    tistih spremenljivk sistema, ki definirajo zlepek, t.j. (..)->x, (...)->y,
    (...)->k1, (...)->kn in (...)->n.
    $A Igor nov00 avg01; */

void dispcubsplglobvar(void);
    /* Zbrise vse pomozne spremenljivke globalnega kubicnega zlepka. Ne zbrise
    tistih spremenljivk sistema, ki definirajo zlepek, t.j. (..)->x, (...)->y,
    (...)->k1, (...)->kn in (...)->n.
    $A Igor nov00 avg01; */

void copycubsplid(int id1,int id2);
    /* Skopira kubicni zlepek z identifikacijsko stevilko id1 na zlepek z
    identifikacijsko stevilko id2 (ce ta se ne obstaja, se ga poskusi tvoriti
    na novo)
    $A Igor avg01; */

void printcubsplstateid(int id);
    /* Na standardni izhod izpise podatke o podatkovni strukturi kubicnega
    zlepka z identifikac. st. id.
    $A Igor avg01; */

void printcubsplglobstate(void);
    /* Na standardni izhod izpise podatke o podatkovni strukturi globalnega
    kubicnega zlepka.
    $A Igor nov00 avg01; */

void fprintcubsplstateid(FILE *fp,int id);
    /* V datoteko fp izpise podatke o podatkovni strukturi kubicnega
    zlepka z identifikac. st. id.
    $A Igor avg01; */

void fprintcubsplglobstate(FILE *fp);
    /* V datoteko fp izpise podatke o podatkovni strukturi globalnega
    kubicnega zlepka.
    $A Igor nov00 avg01; */





            /****************************/
            /*                          */
            /*  3D VEKTORJI IN MATRIKE  */
            /*                          */
            /****************************/




vec3d getvec3d(void);
    /* Alocira in vrne 3D vektor, komponente postavi na 0.
    $A Igor okt01; */

mat3d getmat3d(void);
    /* Alocira in vrne 3D matriko, komponente postavi na 0.
    $A Igor okt01; */

vec3d getvec3dval(double x,double y,double z);
    /* Alocira in vrne 3D vektor, komponente postavi na vrednosti argumentov po
    vrsti.
    $A Igor okt01; */

mat3d getmat3dval(double xx,double xy,double xz,
                    double yx,double yy,double yz,
                    double zx,double zy,double zz);
    /* Alocira in vrne 3D matriko, komponente postavi na vrednosti argumentov po
    vrsti.
    $A Igor okt01; */

vec3d getvec3drand(void);
    /* Alocira in vrne 3D vektor, katerega komponente postavi na nakljucne
    vrednosti med 0 in 1.
    $A Igor okt01; */

mat3d getmat3drand(void);
    /* Alocira in vrne 3D matriko, katere komponente postavi na nakljucne
    argumentov med 0 in 1.
    $A Igor okt01; */

void fprintvec3d(FILE *fp,vec3d v);
    /* Izpise komponente vektorja v vdatoteko fp v eni vrstici.
    $A Igor okt01; */

void printvec3d(vec3d v);
    /* Izpise komponente vektorja v na stand. izhod v eni vrstici.
    $A Igor okt01; */

void fprintmat3d (FILE *fp,mat3d m);
    /* Izpise komponente matrike m vdatoteko fp v treh vrsticah.
    $A Igor okt01; */

void printmat3d (mat3d m);
    /* Izpise komponente matrike m na stand. izhod v treh vrsticah.
    $A Igor okt01; */

void readvec3d(vec3d v);
    /* Prebere komponente vektorja v s standardnega vhoda. Za branje komponent
    uporabi funkcijo readdouble().
    $A Igor okt01; */

void readmat3d(mat3d m);
    /* Prebere komponente matrike m s standardnega vhoda. Za branje komponent
    uporabi funkcijo readdouble().
    $A Igor okt01; */

void zerovec3d(vec3d v);
    /* Komponente 3D vektorja v postavi na 0.
    $A Igor okt01; */

void zeromat3d(mat3d m);
    /* Komponente 3D matrike m postavi na 0.
    $A Igor okt01; */

double vec3dcomp(vec3d v,int i);
    /* Vrne i-to komponento vektorja v (ce je v NULL ali indeks i ni med 1 in 3,
    vrne 0).
    $A Igor okt01; */

double mat3dcomp(mat3d m,int i,int j);
    /* Vrne (i,j)-to komponento matrike m (ce je m NULL ali indeksa nista
     med 1 in 3, vrne 0).
    $A Igor okt01; */

void setvec3dcomp(vec3d v,int i,double val);
    /* i-to komponento vektorja v postavi na val; Ce je v NULL ali indeks i
    ni med 1 in 3, ne naredi nicesar.
    $A Igor okt01; */ 

void setmat3dcomp(mat3d m,int i,int j,double val);
    /* (i,j)-to komponento vektorja v postavi na val; Ce je v NULL ali indeks i
    ni med 1 in 3, ne naredi nicesar.
    $A Igor okt01; */ 

void setvec3d(vec3d v,double x,double y,double z);
    /* Komponente vektorja v postavi na x, y in z.
    $A Igor okt01; */ 

void setmat3d(mat3d m,
              double xx,double xy,double xz,
              double yx,double yy,double yz,
              double zx,double zy,double zz);
    /* Komponente matrike m postavi na vrednosti, kot jih po vrsti dolocajo
    argumenti xx, xy, ..., zz.
    $A Igor okt01; */ 

void mat3dcol(mat3d a,vec3d col,int i);
    /* V vektor col zapise i-ti stolpec matrike a.
    $A Igor okt01; */

void multscalvec3d(vec3d a,double c,vec3d prod);
    /* V prod zapise vektor a pomnozen s skalarjem c.
    $A Igor okt01; */

void lincombvec3d(double a1,vec3d v1,double a2,vec3d v2,vec3d comb);
    /* V vektor comb zapise linearno kombinacijo vektorjev v1 in v2 s
    koeficientoma a1 in a2.
    $A Igor okt01; */

void multscalmat3d(mat3d a,double c,mat3d prod);
    /* V prod zapise matriko a pomnozeno s skalarjem c.
    $A Igor okt01; */

double scalprod3d(vec3d v1,vec3d v2);
    /* Vrne skalarni produkt vektorjev v1 in v2.
    $A Igor okt01; */

void vecprod3d(vec3d a,vec3d b,vec3d prod);
    /* V vektor prod zapise vektorski produkt vektorjev a in b.
    $A Igor okt01; */

double mixprod3d(vec3d a,vec3d b,vec3d c);
    /* Vrne mesani produkt vektorjev a, b in c, ki predstavlja volumen, ki ga
    ti trije vektorji predstavljajo: (a,b,c)=(axb)*c
    $A Igor okt01; */

void vecsum3d(vec3d a,vec3d b,vec3d sum);
    /* V vektor sum zapise vsoto vektorjev a in b. sum lahko kaze na isto mesto
    kot a ali b.
    $A Igor okt01; */

void vecdif3d(vec3d a,vec3d b,vec3d dif);
    /* V vektor dif zapise razliko vektorjev a in b. dif lahko kaze na isto mesto
    kot a ali b.
    $A Igor okt01; */

void matsum3d(mat3d a,mat3d b,mat3d sum);
    /* V matriko sum zapise vsoto matrik a in b. sum lahko kaze na isto mesto
    kot a in b.
    $A Igor okt01; */

void matdif3d(mat3d a,mat3d b,mat3d dif);
    /* V Matriko dif zapise razliko matrik a in b. dif lahko kaze na isto mesto
    kot a in b.
    $A Igor okt01; */

void matprod3d(mat3d a,mat3d b,mat3d prod);
    /* V matriko prod zapise produkt matrik a in b. prod lahko kaze na isto
    mesto kot a ali b ali oba.
    $A Igor okt01; */

void matprodvec3d(mat3d a,vec3d b,vec3d prod);
    /* V vektor prod zapise produkt matrike a in vektorja b. prod lahko kaze na
   isto mesto kot b.
    $A Igor okt01; */

double vecnorm3d(vec3d v);
    /* Vrne evklidsko normo vektorja v. 
    $A Igor okt01; */

void normvec3d(vec3d v);
    /* Normira vektor v.
    $A Igor okt01; */

double detmat2d(mat3d a);
    /* Vrne determinanto 2D matrike a (ce je a NULL, vrne 0).
    $A Igor okt01; */

double detmat3d(mat3d a);
    /* Vrne determinanto 3D matrike a (ce je a NULL, vrne 0).
    $A Igor okt01; */

void transpmat3d(mat3d a,mat3d transp);
    /* Transponirano matriko matrike a zapise v matriko transp. a in transp
    lahko kazeta na isto matriko.
    $A Igor okt01; */

double invmat2d(mat3d a,mat3d inv);
    /* V inv zapise inverzno matriko 2D matrike a in vrne determinanto a.
    inv lahko kaze na isto matriko kot transp.
    $A Igor okt01; */

double invmat3d(mat3d a,mat3d inv);
    /* V 3D matriko inv zapise inverz matrike a. inv lahko kaze na isti prostor
    kot a. Funkcija vrne determinanto a.
    $A Igor okt01; */

double solve2d(mat3d a,vec3d b,vec3d x);
    /* V x zapise resitev sistema dveh enacb z dvema neznankama, kjer so
    koeficienti enacbe v zgornjem levem kotu matrike a, desne strani pa v
    zgornjem delu vektorja b. Funkcija vrne determinanto matrike sistema.
    $A Igor okt01; */

double solve3d(mat3d a,vec3d b,vec3d x);
    /* V x zapise resitev sistema treh enacb s tremi neznankami, kjer so
    koeficienti enacbe v a, desne strani pa v  vektorju b. Funkcija vrne
    determinanto matrike sistema.
    $A Igor okt01; */

int eigensystem2d(mat3d a,mat3d eigenvec,vec3d eigenval);
    /* Calculates eigenvectors and eigenvalues of a 2x2 matrix a and stores
    eigenvectors to lines of eigenvec and eigenvalues to eigenval. eigenvec
    can be the same matrix as a. The number of different real eigenvalues is
    returned.
      Ref.: linalg.nb
    Not tested yet!
    $A Igor nov03; */


            /******************************/
            /*                            */
            /*  3D ANALITICNA GEOMETRIJA  */
            /*                            */
            /******************************/



double distpt3d(vec3d p1,vec3d p2);
    /* Vrne razdaljo med tockama p1 in p2. Ce je kateri od kazalcev p1 oz. p2
    NULL, vrne 0.
    $A Igor okt01; */

double directioncos3d(vec3d s1,vec3d s2);
    /* Vrne kosinus kota med smerema s1 in s2 (smerni kosinus).
    $A Igor okt01; */

double ortprojptline3d(vec3d pt,vec3d r,vec3d s,vec3d proj);
    /* Izracuna ortogonalno projekcijo tocke pt na premico podano s tocko na
    premici r in smernim vektorjem s. Rezultat zapise v proj. Funkcija vrne
    se pozicijo tocke proj na premici izrazeno s koeficientom (c) pri smernem
    vektorju, tako da je proj=r+c*s.
    Formula: proj = r+((pt-r)*s/(s*s)) s
    $A Igor okt01; */

double distptline3d(vec3d pt,vec3d r,vec3d s);
    /* Vrne oddaljenost tocke pt od premice podane s tocko na premici r in s
    smernim vektorjem s.
    Formula: d= || (pt-r) x s || / ||s||
    $A Igor okt01; */

double nearestptlines3d(vec3d r1,vec3d s1,vec3d r2,vec3d s2,vec3d pt1,vec3d pt2);
    /*  V pr1 zapise tocko na 1. premici, ki je najblizje 2. premici, v pr2
    pa tocko na 2, premici, ki je najblizje 1. premici, ter vrne razdaljo med
    obema tockama (t.j. razdaljo med premicama). 1. premica je podana s tocko
    na premici r1 in smefnim vektorjem s1, 2. premica pa s tocko na premici r2
    in smer. vektorjem s2.
     Resitev:
    Resujemo p1=r1+k1*s1, p2=r2+k2*s2, k1,k2:min || p1-p2 ||^2;
    k1 in k2 dobimo dako, da odvod ||...||^2  izenacimo z 0, dobimo
    k1=-(r1*s2)/(s1*s2) in k2=-(r2*s1)/(s1*s2), izracunamo p1 in p2.
     POZOR!
     Problemi so lahko pri vzporednih premicah, ker numericni algoritem premic
    ne prepozna za vzporedne zaradi numericnih napak in vrne neko veliko
    razdaljo med dvema premicama, saj sta ort. projekciji cisto narobe
    izracunani.
    $A Igor okt01; */

double nearestptlinescoef3d(vec3d r1,vec3d s1,vec3d r2,vec3d s2,
       vec3d pt1,double *c1,vec3d pt2,double *c2);
    /*  V pr1 zapise tocko na 1. premici, ki je najblizje 2. premici, v pr2
    pa tocko na 2, premici, ki je najblizje 1. premici, ter vrne razdaljo med
    obema tockama (t.j. razdaljo med premicama). 1. premica je podana s tocko
    na premici r1 in smefnim vektorjem s1, 2. premica pa s tocko na premici r2
    in smer. vektorjem s2. Funkcija vrne v *c1 in *c2 tudi koeficienta, ki na
    obeh premicah dolocata najbljizji tocki, tako da je pt1=r1+c1*s1 in
    pt2=r2+c2*s2.
     Resitev:
    Resujemo p1=r1+k1*s1, p2=r2+k2*s2, k1,k2:min || p1-p2 ||^2;
    k1 in k2 dobimo dako, da odvod ||...||^2  izenacimo z 0, dobimo
    k1=-(r1*s2)/(s1*s2) in k2=-(r2*s1)/(s1*s2), izracunamo p1 in p2.
     POZOR!
     Problemi so lahko pri vzporednih premicah, ker numericni algoritem premic
    ne prepozna za vzporedne zaradi numericnih napak in vrne neko veliko
    razdaljo med dvema premicama, saj sta ort. projekciji cisto narobe
    izracunani.
    $A Igor okt01; */

void ortprojptplane3d(vec3d pt,vec3d r,vec3d n,vec3d proj);
    /* Izracuna ortogonal. projekcijo tocke pt na ravnino, ki je podana s tocko
    na ravnini r in normalo ravnine n. Rezultat zapise v proj.
    Formula: proj = pt+((r-pt)*n) n / n*n
    $A Igor okt01; */

void ortprojlineplane3d(vec3d r1,vec3d s1,vec3d r2,vec3d n2,vec3d rpr,vec3d spr);
    /* Izracuna premico, ki je pravokotna projekcija premice podane s tocko na
    premici r1 in smernim vektorjem s1, na ravnino, ki je podana s tocko na
    ravnini r2 in normalo n2. V vektor rpr zapise tocko na projekciji, v vektor
    spr pa smerni vektor projekcije. Projekcijo se dobi enostavno tako, da se
    na ravnino posebej projicirata tocka na premici in njen smerni vektor.
    Funkcija ne obravnava posebej primera, ko je premica pravokotna na ravnino
    - to se lahko preveri tako, da se pogleda, ce so vse tri komponente vektorja
    spr enake 0.
    $A Igor okt01; */

double signdistptplane3d(vec3d pt,vec3d r,vec3d n);
    /* Vrne razdaljo tocke pt od ravnine, ki je podana s tocko na ravnini r in
    normalo ravnine n. Razdalja je negativna, ce je pt na nasprotni strani
    ravnine, kot je tista, v katero kaze normala n, in pozitivno, ce je tocka na
    isti strani.
    Formula: d= (pt-r)*n / ||n||
    $A Igor okt01; */

double distptplane3d(vec3d pt,vec3d r,vec3d n);
    /* Vrne absolutno razdaljo  tocke pt od ravnine, ki je podana s tocko na
    ravnini r in normalo ravnine n, ki je vedno pozitivno stevilo.
    $A Igor okt01; */

double intsectlineplane3d(vec3d r1,vec3d s1,vec3d r2,vec3d n2,vec3d sect);
    /* V sect zapise presecisce med premico, podano s tocko na premici r1 in
    smernim vektorjem s1, in ravnino podano s tocko na ravnini r2 in normalo
    n2. Ce presecisce obstaja, vrne funkcija 0, drugace vrne predznaceno
    razdaljo med premico in ravnino (to je v primeru, ko sta ravnina in premica
    vzporedni).
    Formula: sect=r1+((r2*n2-r1*n2)/(s1*n2)) s1
    $A Igor okt01; */

double intsectplanes3d(vec3d r1,vec3d n1,vec3d r2,vec3d n2,vec3d r,vec3d s);
    /* Najde premico, ki je PRESECISCE RAVNIN, od katerih je 1. dolocena z
    vektorjem r1 in normalo n1, 2. pa z vektorjem r2 in normalo n2. V r zapise
    tocko na tej premici, v s pa njen smerni vektor. Ce sta ravnini vzporedni,
    vrne funkcija razdaljo med ravninama (v r pa se zapise r1), drugace pa vrne
    0.
     POSTOPEK:
    Smerni vektor premice je n1xn2 (vekt. produkt normal). Rabimo se tocko na
    premici, to dobimo tako, da vzamemo presecisce premice, ki gre skozi r1
    ter je pravokotna na n1*n2 in na n1 (torej lezi v 1. ravnini) z 2. ravnino.
    $A Igor okt01; */



/* PODAJANJE PREMIC IN RAVNIN NA RAZLICNE NACINE: */


void line3dp1p2(vec3d p1,vec3d p2,vec3d r,vec3d s);
    /* Izracuna tocko na premici r in smer. vektor premice s iz dveh tock na
    premici p1 in p2.
    $A Igor okt01; */

void line3p1dn1n2(vec3d p1,vec3d n1,vec3d n2,vec3d r,vec3d s);
    /* Izracuna tocko na premici r in smer. vektor premice s iz tocke na
    premici p1 in in normal na premico n1 in n2.
    $A Igor okt01; */

void plane3dn1d(vec3d n1,double d1,vec3d r,vec3d n);
    /* Izracuna tocko na ravnini r in normalo ravnine n iz normale ravnine n1
    in oddaljenostjo ravnine od izhodisca d1.
    $A Igor okt01; */

void plane3dp1p2p3(vec3d p1,vec3d p2,vec3d p3,vec3d r,vec3d n);
    /* Izracuna tocko na ravnini r in normalo ravnine n iz treh tock na ravnini
    p1, p2 in p3.
    $A Igor okt01; */

void plane3dp1s1s2(vec3d p,vec3d s1,vec3d s2,vec3d r,vec3d n);
    /* Izracuna tocko na ravnini r in normalo ravnine n iz tocke na ravnini p
    ter iz dveh smernih vektorjev premic na ravnini s1 in s2.
    $A Igor okt01; */

void testgeom3d(void);
    /* Test funkcij za analiticno 3D geometrijo.
    $A Igor okt01; */



            /****************************/
            /*                          */
            /*  CO-ORDINATE TRANSFORMS  */
            /*                          */
            /****************************/



void polarcoord(double x,double y,double *r,double *fi);
    /* Converts cartesian co-ordinates (x,y) to polar co-ordinates (*r,*fi).
    $A Igor feb03; */

void polartocartescoord(double r,double fi,double *x,double *y);
    /* Converts polar co-ordinates (r,fi) to cartesian co-ordinates (*x,*y).
    $A Igor feb03; */




            /****************************/
            /*                          */
            /*  1. FAZA TRANSFORMACIJE  */
            /*  (HIERARH. CUB. TRANSF.) */
            /*                          */
            /****************************/





void testcubtr(void);
    /* Testiranje transformacij enotske kocke
    $A Igor okt01; */













#endif /* #ifndef INCLUDED_geom */






























