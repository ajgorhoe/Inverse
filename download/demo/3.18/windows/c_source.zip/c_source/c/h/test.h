

         /**********************************************/
         /*                                            */
         /*     TESTNE IN DEMONSTRACIJSKE FUNKCIJE     */
         /*                                            */
         /**********************************************/



   /**********************************************/
   /*                                            */
   /*    DEFINICIJA FUNKCIJ PREKO KALKULATORJA   */
   /*                                            */
   /**********************************************/

void democalcdeffunc(void);
    /* Demonstrira uporabo funkcij, ki jih uporabnik definira preko
    globalnega kalkulatorja.
    $A Igor maj01; */




   /***********************************************/
   /*                                             */
   /*   SISTEM ZA DEFINICIJO TESTNIH FUNKCIJ      */
   /*           ENE SPREM. Z ODVODI               */
   /*                                             */
   /***********************************************/


void testfunc1dder(double x,double *f,double *d);
    /* Testna funkcija ene spremenljivke; x je argument funkcije, v f se
    zapise vrednost funkcije pri x, v d pa vrednost odvoda.
    %A Igor maj01; */

double testfunc1d(double x);
    /* Testna funkcija ene spremenljivke; x je argument funkcije, vrne se njena
    vrednost.
    %A Igor maj01; */

double testder1d(double x);
    /* Odvod testne funkcije ene spremenljivke; x je argument funkcije, vrne se
    njenodvod.
    $A Igor maj01; */

double testnumder1d(double x);
    /* Numericni odvod testne funkcije ene spremenljivke.
    $A Igor maj01; */

int adddeffunc1dder(void (*func1dder)(double,double *,double *),char *str);
    /* Doda definicijo nove funkcije, ki vrne funkcijo in odvod funkcije
    ene spremenljivke. func1dder je ta funkcija, str pa njen identifikacijski
    niz, ki jo predstavlja. Ni potrebno, da se da str brisati s free().
    Funkcija vrne zapored. stevilko nove definicije.
    $A Igor maj01; */

void initdeffunc1dder(void);
    /* Inicializira sklada defstfunc1dder in strstfunc1dder, ki vsebujeta
    definicije funkcij ene spremenljivke z odvodi. Na sklada da nekaj lastnih
    definicij.
    $A Igor maj01; */

void deldeffunc1dder(int i);
   /* Zbrise i - to definicijo funkcije ene spremenljivke s sklada.
    $A Igor maj01; */

void delalldeffunc1dder(void);
    /* Zbrise vse definicije funkcij ene spremenljivke s sklada.
    $A Igor maj01; */

void *choosfunc1dderint(void);
    /* Interaktivna izbira funkcijo ene spremenljivke z definiranim odvodom.
    Vrne funkcijo tipa void(double,void *,void *) in nastavi ustrezne funkcije
    tako, da ustrezajo tej funkciji.
    $A Igor maj01; */

void demotestfunc1d(void);
    /* Funkcija za demonstracijo delovanja sistema za definicijo testne
    funkcije ene spremenljivke - uporabnik izbere funkcijo, izrise se funkcija
    in odvod. */


