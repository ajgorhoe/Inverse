

    /* Tcl interpreter in Tk */


/* Code for preventing multiple inclusions: */
#ifndef INCLUDED_itk
#define INCLUDED_itk


/* Code for assuring inclusion of necessary headers: */
#ifndef INCLUDED_st
 #include <st.h>
#endif

/* Undefined macros that could possibly defined in sysint.h (for providing the
functionality when ITK is not defined and for avoiding necessity to include this
file (itk.h) only for thread locking macros: */
#undef m_threadlocksleep
#undef m_threadlocksafesleep
#undef m_threadwaitvalsleep
#undef m_threadwaitnotvalsleep
#undef m_threadlock
#undef m_threadunlock
#undef m_threadlocksafe
#undef m_threadwaitval
#undef m_threadwaitnotval



/* Tracing supplement; takes care of notifications whenever thread locking
encounters a lock that is already set. This enables to identify hanhing because
of inproper threas locking. See macros and routines declared in er.h for more
information on tracing! */

#ifdef EXTRACE
 #define TRLOCK(lock,macroname)    \
   if ((lock)!=0) \
     TRDOPR(0,0,macroname,NULL,  \
       fprintf(trf(),"Thread Lock = %i  {%i  %s (%s)}\n",  \
         (lock),__LINE__,__FILE__,macroname); fflush(trf()); )
#else
 #define TRLOCK(lock,macroname)
#endif

#ifdef EXTRACE
 #define TRWAITVAL(expr,val,macroname)    \
   if ((expr)!=(val)) \
     TRDOPR(0,0,macroname,NULL,  \
       fprintf(trf(),"Thread Wait Value %i, current %i {%i  %s (%s)}\n",  \
         (val),(expr),__LINE__,__FILE__,macroname); fflush(trf()); )
#else
 #define TRWAITVAL(expr,val,macroname)
#endif

#ifdef EXTRACE
 #define TRWAITNOTVAL(expr,val,macroname)    \
   if ((expr)==(val)) \
     TRDOPR(0,0,macroname,NULL,  \
       fprintf(trf(),"Thread Wait Not Value %i, current %i {%i  %s (%s)}\n",  \
         (val),(expr),__LINE__,__FILE__,macroname); fflush(trf()); )
#else
 #define TRWAITNOTVAL(expr,val,macroname)
#endif



#ifdef ITK
 
#include <tcl.h>
#include <tk.h>



typedef struct _itkthreaddata {
  stack commands,     /* Commands to be interpreted */
        requests;     /* Requests which require results */
  char *command;      /* Current command */
  int current;        /* Number of the current command on commands */
  /* int result; */         /* Interpretation result */
  /* char *strresult; */    /* Result of the current command */
  /* Locks set by incrementation, unset by decrementation, check of lock after
  incrementation (must be 1): */
  int lock,           /* Lock; commands or events are processed */
      requestlock;    /* Lock for updating requests */
  int procall;
  /* int evalrequest; */    /* Signal that evaluation is requested */
  Tcl_Interp *interp, /* Tcl interpreter */
         *maininterp; /* Interpreter of the main thread */
  int thread;         /* Thread ID cast to type int (used in IG code) */
  Tcl_ThreadId id;    /* Identification of the thread */
} _itkthreaddata;

typedef _itkthreaddata *itkthreaddata;


typedef struct _itkrequest {
  int lock;   /* Insures that only one thread is using the same request data */
  char done;  /* notification that request has been processed */
  char *com,  /* Command to be eval., must be writable */
       *res;  /* Tcl result, dynamic. */
  void (*func) (void *data);  /* Function to be called in the ITK thread
               (called after evaluation of com, if any) */
  void *data; /* A data pointer that will be passed as argument to func */
  int code;   /* Return code */
} _itkrequest;

typedef _itkrequest *itkrequest;





    /* AUXILIARY UTILITIES FOR USE OF ITK: */


double tcl_absolutetime(void);
    /* Returns the absolute time in seconds.
    $A Igor apr04; */

void tcl_sleep(double sec);
    /* Sleeps (pauses the process) for a given number of seconds.
    $A Igor apr04; */

int tcl_processallevents(void);
    /* Processes all events in the queu; used for example to block until
    all user response is processed, windows are refreshed etc. Returns the
    number of events that were processed.
    $A Igor jun03; */

int tcl_processquickevents(void);
    /* Processes all events in the queu that can usually be processed quickly;
    used for example to enable close to normal GUI behavior during a time
    consuming operations such as drawing, but without disturbing the operation
    too much.
    $A Igor jun03; */

int getthreadid(void);
    /* Returns the identification number of the current thread.
    $A Igor apr03; */

int getmainthreadid(void);
    /* Return the identification number of the main program thread.
    $A Igor apr03; */

int ismainthread(void);
    /* Returns 1 if the current thread is the main program thread, 0 otherwise.
    $A Igor apr03; */

int getitkthreadid(void);
    /* Return the identification number of the main program thread.
    $A Igor apr03; */

int createthread(void procmain(void *),void *data);
    /* Creates a new thread and returns its identification number. procmain
    is the main procedure for the new thread and data is an argument to this
    procedure.
    A special mechanism ensures that every thread calls the appropriate
    procedure which was passed as the procmain argument to this function.
    Bodies of this function are serialised, therefore thefunction is thread
    safe and can even be called recursively in procmain.
    $A Igor apr03; */

void tcl_appendarg (char **comaddr,char *arg);
    /* Appends argument arg to the tcl list *comaddr. It converts arg in such a
    way that it is a proper tcl list element, and avoids putting strings in
    curly brackets.
      Warning:
      Even if arg is NULL, function appends it as an empty argument. Therefore,
    if anyhow arh should not appended to the list, this must be arranged by not
    calling this kfunction.
    $A Igor apr04; */

void tcl_appendargbrac (char **comaddr,char *arg);
    /* Appends argument arg to the tcl list com. It converts arg in such a way
    that it is a proper tcl list element. As opposed to tcl_appendarg, this
    function often embeds a string in curly brackets.
      Warning:
      Even if arg is NULL, function appends it as an empty argument. Therefore,
    if anyhow arh should not appended to the list, this must be arranged by not
    calling this kfunction.
    $A Igor apr04; */

char *tcl_listelsubst(char *str);
    /* Returns a copy of the string str, which is modified in such a way
    that it can be a list element, but still allows all substitutions when
    used as command arguments. The string is enclosed in double 1uotes if
    possible and necessary.
    $A Igor apr04; */

char *tcl_stcomsubst(stack list);
    /* Forms a valid Tcl command from a set of strings which are on the stack
    list. The first string on the stack must be the procedure name while the
    subsequent strings are argument. Function converts elements of the stack to
    valid list elements and merges them with separating spaces inserted. The
    returned string is dynamically allocated and can be relesed by free().
    The command must be obtained by using this or a similar function when
    the procedure name or its arguments contain spaces or special characters
    or when they are DOS-like file names.
      Warning:
      The command is such that no string substitution can be done on proc.
    arguments.
    $A Igor apr04; */

char *tcl_multstrcomsubst(char *first,...);
    /* Forms a valid Tcl command from a set of strings which are arguments of
    this function. The first argument must be the procedure name while the
    subsequent strings are arguments. Function converts elements of the stack to
    valid list elements and merges them with separating spaces inserted. The
    returned string is dynamically allocated and can be relesed by free().
    The command must be obtained by using this or a similar function when
    the procedure name or its arguments contain spaces or special characters
    or when they are DOS-like file names.
      WARNING:
      The last argument must be NULL to terminate the string list! Take care
    that none of the strings intended as arguments is NULL, since such an
    argument will terminate the list and would not be treated as an argument
    itself. If the situation is not clear, use multiple calls to tcl_appendarg.
      The command is such that no string substitution can be done on proc.
    arguments.
      Each non-NULL argument must be an individual argument of a Tcl procedure
    (or its name - the first arg.).
    $A Igor apr04; */

char *tcl_stcom(stack list);
    /* Forms a valid Tcl command from a set of strings which are on the stack
    list. The first string on the stack must be the procedure name while the
    subsequent strings are argument. Function converts elements of the stack to
    valid list elements and merges them with separating spaces inserted. The
    returned string is dynamically allocated and can be relesed by free().
    The command must be obtained by using this or a similar function when
    the procedure name or its arguments contain spaces or special characters
    or when they are DOS-like file names.
      Warning:
      The command is such that no string substitution can be done on proc.
    arguments.
    $A Igor apr04; */

char *tcl_multstrcom(char *first,...);
    /* Forms a valid Tcl command from a set of strings which are arguments of
    this function. The first argument must be the procedure name while the
    subsequent strings are argument. Function converts elements of the stack to
    valid list elements and merges them with separating spaces inserted. The
    returned string is dynamically allocated and can be relesed by free().
    The command must be obtained by using this or a similar function when
    the procedure name or its arguments contain spaces or special characters
    or when they are DOS-like file names.
      WARNING:
      The last argument must be NULL to terminate the string list!
      The command is such that no string substitution can be done on proc.
    arguments.
    $A Igor apr04; */

int tcl_okcode(int retcode);
    /* Returns 0 if the Tcl interpretation return code retcode indicates an
    error, 1 otherwise.
    $A Igor jul03; */



   /* INITIALIZATION OF INTERPRETERS */


void tcl_init(Tcl_Interp **interpaddr);
    /* Creates the Tcl interpreter if not yet created and performs the Tcl
    initialisation on the interpreter.
    $A Igor apr03; */

void tk_init(Tcl_Interp **interpaddr);
    /* Creates the Tcl interpreter if not yet created and performs the Tcl
    initialisation on the interpreter.
    $A Igor apr03; */

void itk_init(Tcl_Interp **interpaddr);
    /* Creates the Tcl interpreter if not yet created and performs the ITK
    initialisation on the interpreter. This includes the Tcl and Tk
    initialization.
    $A Igor apr03; */





    /* BARE TCL INTERPRETER FOR ACCESSING THE TCL FUNCTIONALITY.
    
  Use this interpreter exclusively fot evaluating built-in Tcl functions because
it has separate var. space from the ITK server; provided for sped. */


void tcl_initialize(void);
    /* Initializes the bare Tcl interpreter. It is not necessary to call this
    function exprlicitly because it is implicitly called by other functions
    for accessing the ITK functionality.
    $A Igor apr04; */

int tcl_initialized(void);
    /* Returns 1 if the bare Tcl interpreter is already initialized and 0
    otherwise.
    $A Igor apr04; */

int ismainthread(void);
    /* Returns 1 if the current thread is the main thread, 0 otherwise.
    $A Igor apr03; */

Tcl_Interp *tcl_interp(void);
    /* Returns the Tcl interpreter fo the Tcl system so that its state can be
    checked, new commands installed, etc.
      WARNING!
    Make sure that you are in the main thread when using the Tcl interpreter
    directly!
    $A Igor apr04; */

void tcl_sendcom(char *com);
    /* Sends the command com to the Tcl interpreter for execution. com must be
    such that writing on it is enabled, for example dynamically allocated
    (in that case it must be freed after call to this function).
    $A Igor apr03; */

void tcl_sendcomcp(char *com);
    /* Sends the command com to the Tcl interpreter for execution. com does
    not need to be dynamically allocated because a dynamically allocated copy
    of it i screated internally and released after use.
    $A Igor apr03; */

char *tcl_interpret(char *com,int *code);
    /* Interprets the command com in the auxiliary Tcl interpreter and returns
    the dynamically allocated result, which must be deallocated (e.g. by
    free()). If code is not NULL, the return code of evaluation is written to
    *code. If it is not TCL_OK, this indicates an error.
      com must be such that writing on it is possible, it is the best if it is
    dynamically allocated.
    This function can only be called in the main thread. Its aim is to execute
    Tcl commands bypassing the threaded ITK server. This is quicker, however
    only the basic Tcl commands are available. Also both interpreters have
    separate variable spaces.
    $A Igor apr03; */

char *tcl_interpretcp(char *com,int *code);
    /* Interprets the command com in the auxiliary Tcl interpreter and returns
    the dynamically allocated result, which must be deallocated (e.g. by
    free()). If code is not NULL, the return code of evaluation is written to
    *code. If it is not TCL_OK, this indicates an error.
      Command com does not need to be dynamically allocated because a temporary
    dynamic copy of com is created internally.
    This function can only be called in the main thread. Its aim is to execute
    Tcl commands bypassing the threaded ITK server. This is quicker, however
    only the basic Tcl commands are available. Also both interpreters have
    separate variable spaces.
    $A Igor apr03; */

void tcl_shell(void);
    /* A simple shell where useer can evaluate commands in the auxiliary tcl
    interpreter and see the results.
    $A Igor apr03; */






    /* THE ITK SYSTEM.

Enables evaluating Tcl commands extended by Tk and ITK within the main thread,
event loop implemented in a parallel thread (currently also the command
serviceing). */


void itk_initialize(void);
    /* Initializes the ITK server (creates the thread and sets up the server)
    if it has not been initialised yet. It is not necessary to call this
    function exprlicitly because it is implicitly called by other functions
    for accessing the ITK functionality.
    $A Igor apr04; */

int itk_initialized(void);
    /* Returns 1 if the ITK server is already initialized and 0
    otherwise.
    $A Igor apr04; */

void itk_lockinterp(void);
    /* If necessary, waits until the Tcl interpreter of the ITK server thread
    is unlocked, and locks it so that other threads can not access it. After
    this function returns, the interpreter can be accessed, e.g. for installing
    new procedures. This function must aways be called in pair with the
    itk_unlockinterp(), which unlocks the interpreter after use so that the
    ITK server can continue serving requests.
    $A Igor apr04; */

void itk_unlockinterp(void);
    /* Unlock the ITK's Tcl interpreter so that it can be used by another
    threads. This function must be used after the itk_lockinterp().
    $A Igor apr03; */

Tcl_Interp *itk_interp(void);
    /* Returns the Tcl interpreter fo the ITK system so that its state can be
    checked, new commands installed, etc. The portions of code in which the
    the returned interpreter is used should be ALWAYS EMBEDDED within the calls
    to itk_lockinterp() and itk_unlockinterp(). This ensures that the
    interpreter is accessed simultaneously only by one single thread.
    $A Igor apr04; */

void itk_sendcom(char *com);
    /* Sends the command com to the ITK server for execution. com must be
    dynamically allocated; It must not be be freed or modified after execution
    of this command.
    $A Igor apr03; */

void itk_sendcomcp(char *com);
    /* Sends a copy of the command com to the ITK server for execution. com
    does not need to be dynamically allocated because the function creates
    its dynamic copy internally.
    $A Igor apr03; */

char *itk_interpret(char *com,int *code);
    /* Sends a Tcl command com to the ITK server, waits its interpretation
    and returns a dynamically allocated copy of the result of interpretation.
    If code is not NULL, the return code is stored in *code. The returned value
    must be deallocated when not needed anymore. com must be dynamically
    allocated (because it is deallocated by the server by using free()) and may
    not be modified after this function is called.
    $A Igor apr03; */

char *itk_interpretcp(char *com,int *code);
    /* Sends a Tcl command com to the ITK server, waits its interpretation
    and returns a dynamically allocated copy of the result of interpretation.
    If code is not NULL, the return code is stored in *code. The returned value
    must be deallocated when not needed anymore.
      com does not need to be dynamically allocated because the function
    creates its dynamic copy internally.
    $A Igor apr03; */

void itk_sendfunc(void (*func)(void *),void *ptr);
    /* Arranges for the function func to be called in the ITK interpreter. The
    request for the call is posted in the same way as the request for
    interpretation by the itk_sendcom(). The ptr will be passed to the function
    as argument when it is executed. The function will be executed when CPU
    time is available in the thread, but this function returns immediately
    withaut waiting for execution of func.
      The function execution will have priority with respect to commands that
    are sent to the ITK interpreter, since it is loaded on the (...)->requests
    field of the thread structure.
    $A Igor sep03; */

void itk_callfunc(void (*func)(void *),void *ptr);
    /* Arranges for the function func to be called in the ITK interpreter and
    waits until the function returns. The ptr will be passed to the function
    as argument when it is executed. The function will be executed when CPU
    time is available in the thread, with the seme priority as the code
    interpreted by itk_interpret().
    $A Igor sep03; */

void itk_procallrequests(void);
    /* Takes care that all requests are processed by the ITK server, blocks until
    this is done (unless if called in the ITK thread, in which case the function
    has no effect).
    $A Igor apr03; */

void itk_shell(void);
    /* The shell in which user can execute Tcl commands by the ITK server and
    view results; Uses standart input and output, executed serially.
    $A Igor apr04; */




    /* IEK: TESTS FOR INTERPRETER IN THE MAIN THREAD, LOCKING EVENT LOOP IN
    ANOTHER ONE;
    
This is the IEK system - E stands for event loop. The system is quicker that ITK,
but is not stable due to incompatibility of the Tcl interpretation on threads. */

void iek_initialize(void);
    /* Initializes the IEK server (creates the thread and sets up the server)
    if it has not been initialised yet. It is not necessary to call this
    function exprlicitly because it is implicitly called by other functions
    for accessing the IEK functionality.
    $A Igor apr04; */

int iek_initialized(void);
    /* Returns 1 if the bare Tcl interpreter is already initialized and 0
    otherwise.
    $A Igor apr04; */

void iek_lockinterp(void);
    /* If necessary, waits until the Tcl interpreter of the IEK server thread
    is unlocked, and locks it so that other threads can not access it. After
    this function returns, the interpreter can be accessed, e.g. for installing
    new procedures. This function must aways be called in pair with the
    iek_unlockinterp(), which unlocks the interpreter after use so that the
    IEK server can continue serving requests.
    $A Igor apr04; */

void iek_unlockinterp(void);
    /* Unlock the IEK's Tcl interpreter so that it can be used by another
    threads. This function must be used after the iek_lockinterp().
    $A Igor apr03; */

Tcl_Interp *iek_interp(void);
    /* Returns the Tcl interpreter fo the IEK system so that its state can be
    checked, new commands installed, etc. The portions of code in which the
    the returned interpreter is used should be ALWAYS EMBEDDED within the calls
    to iek_lockinterp() and iek_unlockinterp(). This ensures that the
    interpreter is accessed simultaneously only by one single thread.
    $A Igor apr04; */

void iek_sendcom(char *com);
    /* Sends the command com to the ITK server for execution. com must be
    dynamically allocated; It must not be be freed or modified after execution
    of this command.
    $A Igor apr03; */

void iek_sendcomcp(char *com);
    /* Sends a copy of the command com to the IEK server for execution. com
    does not need to be dynamically allocated because the function creates
    its dynamic copy internally.
    $A Igor apr03; */

char *iek_interpret(char *com,int *code);
    /* Sends a Tcl command com to the IEK server, waits its interpretation
    and returns a dynamically allocated copy of the result of interpretation.
    If code is not NULL, the return code is stored in *code. The returned value
    must be deallocated when not needed anymore. com must be dynamically
    allocated (because it is deallocated by the server by using free()) and may
    not be modified after this function is called.
    $A Igor apr03; */

char *iek_interpretcp(char *com,int *code);
    /* Sends a Tcl command com to the IEK server, waits its interpretation
    and returns a dynamically allocated copy of the result of interpretation.
    If code is not NULL, the return code is stored in *code. The returned value
    must be deallocated when not needed anymore.
      com does not need to be3 dynamically allocated because the function
    creates its dynamic copy internally.
    $A Igor apr03; */

void iek_shell(void);
    /* The shell in which user can execute Tcl commands by the IEK server and
    view results; Uses standart input and output, executed serially.
    $A Igor apr04; */




void testitk(void);
    /* Tests the performance of ITK server.
    $A Igor apr04; */


  /* DEFINITION OF THREAD LOCKING MACROS WITH SLEAP: */

/* The following macro sleeps for time milliseconds after each unsuccessful check
if lock has been released (otherwise the same as m_threadlock): */

#define m_threadlocksleep(lock,time)  \
  TRLOCK(lock,"m_threadlocksleep")  \
  while(1)  \
  {  \
    while((lock)>0)  \
      if ((time)>0) \
        Tcl_Sleep(time);  \
    ++(lock);  \
    if ((lock)<=1)  \
    {  \
      (lock)=1;  \
      break;  \
    }  \
    else  \
      --(lock);  \
  }

#define m_threadlocksafesleep(lock,id,time)  \
  TRLOCK(lock,"m_threadlocksafesleep")  \
  while(1)  \
  {  \
    while(lock>0)  \
    {  \
      Tcl_Sleep(time);  \
      if (id==getthreadid())  \
        (lock)=0;  \
    }  \
    ++(lock);  \
    if ((lock)<=1)  \
    {  \
      (lock)=1;  \
      (id)=getthreadid();  \
      break;  \
    }  \
    else  \
      --(lock);  \
  }

#define m_threadwaitvalsleep(expr,val,time)  \
  TRWAITVAL(expr,val,"m_threadwaitvalsleep")    \
  while((expr)!=(val)) Tcl_Sleep(time);

#define m_threadwaitnotvalsleep(expr,val,time)  \
  TRWAITNOTVAL(expr,val,"m_threadwaitnotvalsleep")    \
  while((expr)==(val)) Tcl_Sleep(time);




#else  /* beginning of ! defined (ITK) */




/*
 #define funcdec(dec) dec ;
 funcdec(
 )
 #undef funcdec
*/

  void itk_shell(void);
 

  /* THREAD LOCKING MACROS WITH SLEAP IN ABSCENCE OF ITK: */

#define m_threadlocksleep(lock,sleep)  \
  TRLOCK(lock,"m_threadlocksleep")  \
  while(1)  \
  {  \
    int i;  \
    while(lock>0)  \
      i=10*5;  \
    ++(lock);  \
    if ((lock)<=1)  \
    {  \
      lock=1;  \
      break;  \
    }  \
    else  \
      --(lock);  \
  }



#define m_threadlocksafesleep(lock,id,time)  \
  TRLOCK(lock,"m_threadlocksafesleep")  \
  while(1)  \
  {  \
    int i;  \
    while(lock>0)  \
    {  \
      i=10*5;  \
      if (id==getthreadid())  \
        lock=0;  \
    }  \
    ++(lock);  \
    if ((lock)<=1)  \
    {  \
      lock=1;  \
      id=getthreadid();  \
      break;  \
    }  \
    else  \
      --(lock);  \
  }


#define m_threadwaitvalsleep(expr,val,time)  \
  TRWAITVAL(expr,val,"m_threadwaitvalsleep")    \
  while((expr)!=(val)) {int i; i=3*5;}

#define m_threadwaitnotvalsleep(expr,val,time)  \
  TRWAITNOTVAL(expr,val,"m_threadwaitnotvalsleep")    \
  while((expr)==(val)) {int i; i=3*5;}


    /* EMPTY DEFINITIONS OF SOME ITK FUNCTIONS:
  These functions are defined in the case that ITK is not present, but 
without any functionality. The sole purpose of this is that some standard
functionality such as tracking in er.c can be defined in the same way (e.g.
parts that examin the thread info). */

void itk_shell(void);

int getthreadid(void);

int getmainthreadid(void);

int ismainthread(void);

int getitkthreadid(void);

int createthread(void procmain(void *),void *data);

void tcl_sleep(double sec);




#endif  /* end of not defined(ITK) */





/* Macros for locking and unlocking the thread access lock; lock must be
a static variable initialised to 0. m_treadlock locks the lock so that
all thread that call m_threadlock afterwards will block until the
m_threadunlock unlocks the lock. If a lock has been set by another
thread, then m_threadlock will block until the thread releases it.
  Never call m_threadlock twice in the same thread, make sure that locks
are unlocks somewhere. In a function, make sure that all returns have
their unlock. Always use lock at the beginning of the function or in a
compact code block where it is sure that both lock and unlock are
encountered.
  These macros are used for preventing unsynchronised  access to static
variables from multiple threads at the same time.
  IMPORTANT REMARK:
Macros that wait that something happens in some other thread, should always
call some sleep() function if the first check is not successful (even if
sleep(0)). Otherwise the system could not allocate enough CPU time for the
thread that should do something, but only for the thread that is waiting for
something to be done. */

/*
  while(1)  \
  {  \
    while((lock)>0)  \
      ;  \
    ++(lock);  \
    if ((lock)<=1)  \
    {  \
      (lock)=1;  \
      break;  \
    }  \
    else  \
      --(lock);  \
  }
*/

#define m_threadlock(lock)   m_threadlocksleep(lock,0)

#define m_threadunlock(lock)  --(lock);


/* SAFE THREAD LOCK:
the macro m_threadlocksafe defines a safe thread lock which will not
block if the lock is set twice within the same thread without unlock
performed between the two calls. The macro stores the thread id of the
thread that has set the last lock. If this is the same than the current
thread then the lock is unset by the macro itself because there is no
other thread that will unset the lock.  */


#define m_threadlocksafe(lock,id)  m_threadlocksafesleep(lock,id,0)  


/*
#define m_threadlocksafe(lock,id)  \
  while(1)  \
  {  \
    while(lock>0)  \
    {  \
      if (id==getthreadid())  \
        lock=0;  \
    }  \
    ++(lock);  \
    if ((lock)<=1)  \
    {  \
      lock=1;  \
      id=getthreadid();  \
      break;  \
    }  \
    else  \
      --(lock);  \
  }
*/



/* Macros for waiting until the variable gets a certain value dependent on
operations that are performed in some other
thread: */

#define m_threadwaitval(expr,val)    m_threadwaitvalsleep(expr,val,0)

#define m_threadwaitnotval(expr,val)    m_threadwaitnotvalsleep(expr,val,0)  









#endif    /* (not defined) INCLUDED_itk */




