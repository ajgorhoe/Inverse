
/* Ensure at most one inclusion: */
#ifndef INCLUDED_sgs
#define INCLUDED_sgs


        /************************/
        /*                      */
        /*   COVER SGS MODULE   */
        /*                      */
        /************************/



/* Include the necessary headers if not already included: */
#ifndef INCLUDED_stdarg
 #include <stdarg.h>
 #define INCLUDED_stdarg
#endif
/*
#ifndef INCLUDED_sg_draw
 #include <sg_intfc.h>
#endif
*/
#ifndef INCLUDED_sg_draw
 #include <sg_draw.h>
#endif
#ifndef INCLUSED_sg_obj
 #include <sg_obj.h>
#endif
#ifndef INCLUSED_sg_ploto
 #include <sg_ploto.h>
#endif
#ifndef INCLUDED_sg_graph
 #include <sg_graph.h>
#endif


















#endif    /* (not defined) INCLUDED_sgs */





