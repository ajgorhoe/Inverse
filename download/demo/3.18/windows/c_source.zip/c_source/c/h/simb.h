
    /* KALKULATOR */


/* Koda, ki omogoca v kljucitev te datoteke v headerjih, ne da bi bilo treba
skrbeti za to, ali ni ta header ze bil kakorkoli vkljucen, ker se v to
eksplicitno preverja preko definicije ustreznega makra: */
#ifndef INCLUDED_simb
#define INCLUDED_simb

/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_st
#include <st.h>
#endif
#ifndef INCLUDED_vec
#include <vec.h>
#endif



#ifndef INCLUDED_stdio  /* for definition of type FILE */
  #include <stdio.h>
  #define INCLUDED_stdio
#endif



/* DEFINICIJE TIPOV: */



typedef struct _object {
        struct _object *l,*r; /* levo in desno poddrevo */
        void       *v;     /* vrednost */
        char       *name;  /* ime */
        char       status;
        char       kind; /* vrsta objekta:
            '0': koncni clen
            '1': enoparamet. glob. funkcija
            '2': dvoparamet. global. operator
            'f': def. funkcija z vec parametri
            't': tabela objektov
            */
        char        subkind; /* podvrsta:
            'L': celo st. (tipa int)
            'D': realno st. (tipa double)
            */
        int         place;     /* se zaenkrat ne uporablja */
        char        priority; /* prioriteta */
} *object;




typedef struct{
       int n,r;   /* Stevilo zasedenih in rezerviranih mest */
       int ex;    /* Stevilo preseznih mest ob morebitni potrebni realokaciji */
       object *s;  /* Tabela objektov */
       } b_ostack;

/*
typedef _ostack *ostack;
*/


/* Struktura, ki definira obnasanje funkcij pri klicih uporabniskih funkcij */
typedef struct{
        char *name;
        /* Funkcija, ki jo uporablja doubleval: */
        double (*doubleval) (object,stack,stack,int,void *);
        void *doublevaldata; /* Kazalec na morebitne dodatne podatke */
        void (*put) (object,void *); /* Funkcija se klice v puttreetolist */
        void *putdata;
        } _userfunc;

typedef _userfunc *userfunc;



typedef struct{
        stack user;    /* navodila o ravnanju z uporab. def. funkcijami */
        stack strings; /* izrazi */
        stack cuts;     /* razrezani izrazi */
        stack trees;  /* drevesa, ki jih naredimo iz razrez. izrazov */
        stack syst;   /* sklad sistemskih objektov */
        stack def;    /* sklad definicij funkcij in spremenljivk */
        stack trash;  /* sklad, kamor se nalagajo mrtvi objekti */
        stack fst;    /* sklad, ki ga uporabljajo definirane funkcije */
        } _ssyst;


typedef _ssyst *ssyst;   /* Sistem za simbolno racunanje */



/* DEFINICIJE FUNKCIJ: */


int initobject(object o);
     /* Inicializira podat. strukturo tipa object */

object newobject(void);
       /* Alocira prostor za nov element tipa _object,
       ta element inicializira in vrne kazalec nanj */

int disp1obj(object *oo);
    /* Brise en sam objekt, na katerega kaze oo. Ce objekt vsebuje kako 
    vrednost, brise tudi to. */

void disptree(object *o);
     /* Brise celotno drevo objektov. */

void inssortstackobject(stack st,object o);
    /* Inserts the calc. object o on a sorted stack st in such a way that the
    stack remains sorted.
    $A Igor mar04; */

static int cmpobjectstr(void *name,void *obj);
    /* Funkcija vrne 0, ce ima objekt obj ime name, 1, ce je name>obj->name,
    in -1, ce je name<obj->name.
    $A Igor<== sep99; */

void initsymbsyst(stack *st);
     /* Inicializira tabelo sistemskih (vgrajenih) simbolov. */

ssyst newssyst(stack system);
      /* Zgradi sistem za simbolno racunanje. system je sklad s sistemskimi
      (vgrajenimi) objekti. */

void dispssyst(ssyst *s);
     /* Zbrise sistem za simbolno racunanje */

void doubleobj(object o, double r);
     /* Objektu, ki predstavlja stevilo tipa double, priredi vrednost r. */

int findsortstackobject(stack st,int from,int to,char *name);
    /* Finds a calculator object named name on the stack st btween positions
    from and to and returns its position or 0 if the object is not found.
    $A Igor mar04; */

void longobj(object o, long l);
     /* Objektu, ki predstavlja stevilo tipa long, priredi vrednost r. */

object findobjname(stack syst,char *name);
       /* Na skladu syst najde 1. objekt z imenom name ter vrne njegovo vrednost 
       (to se pravi kazalec na strukturo tipa _object). Ce taksnega objekta ne
       najde, vrne NULL. */

int fprinttabobj(FILE *fp,stack tab);
    /* Izpise seznam objektov tab v datoteko fp */

int printtabobj(stack tab);
    /* Izpise seznam objektov tt na zaslon */

stack cutexpression(char *expression,stack symbsyst);
       /* Izraz, ki ga predstavlja niz expression, razdeli na osnovne elemente,
       ki jih pretvori v simbole. To je prva obdelava izraza. funkcija vrne 
       sklad objektov, ki nastopajo v istem vrstnem redu kot simboli v nizu.
       syst je sklad, na katerem so nalozeni sistemski objekti. */

void displistobj(stack *objlist);
    /* Zbrise seznam objektov, ki ga naredi funkcija cutexpression, in sicer
    tako, da niso prizadeti objekti, ki so uporabljeni v drevesnih strukturah
    (na skladu brise torej samo oklepaje).
    $A Igor okt99; */

int arrangelistobj(stack t);
    /* Uredi sklad objektov t. Preveri tudi, ce so vsi oklepaji zakljuceni.
    ce je kaj narobe, vrne 1, drugace 0. Funkcija tudi dodatno postavi tipe 
    nekaterih objektov. To funkcijo se uporablja vedno takoj za funkcijo 
    cutexpression.*/

object maketree(stack list);
       /* iz tabele objektov naredi drevo, vrne kazalec na koren drevesa. */

static stack findtreeall(object tree,void *ptr,
              int *cmp(void *p1, void *p2) );
       /* V drevesu objektov tree najde vse objekte, ki so enaki objektu
       ptr v smislu funkcije cmp, ki mora vrniti 0, ce sta oba argumenta
       enaka. Najdeni objekti se nalozijo na sklad, ki ga funkcija vrne.
       OPOMBA: Ni nujno, da je ptr ravno tipa object.
       POZOR! 1. argument, ki se nalozi pri klicu funkcije cmp, je ptr, zato mora
       biti tudi funkcija cmp narejena tako, da vzame ptr kot 1. argument. */

stack treelistst(object tree);
      /* Vrne sklad, na katerega potisne vse elemente seznama, ki ga predstavlja
      drevo tree. Ce objekt, na katerega kaze tree, ni vejica, funkcija potisne
      na sklad en sam clen. Funkcija vrne sklad, na katerega je potisnila 
      elemente seznama. */

void puttreetolist(object put,stack *list1,stack *trash1,stack user);
     /* Objekt put vkljuci v seznam list. *trash1 so smeti - na ta sklad
     nalagamo mrtve objekte. */

void fprinttree(FILE *fp,object t,int lines,int columns);
     /* izpise drevo t na konec datoteke fp v okrnjeni obliki. */

void fprinttreefull(FILE *fp,object t,int lines,int columns);
     /* izpise drevo t na konec datoteke fp v polni obliki (pri klicih 
     spremenljivk in funkcij se izpisejo tudi definicije). */

void fprinttreepart(FILE *fp,object t,int lines,int columns);
     /* izpise drevo t na konec datoteke fp v delno polni obliki (le pri klicih
     spremenljivk se izpisejo tudi definicije, pri klicih funkcij pa ne). */

void printtree(object t,int lines,int columns);
     /* izpise drevo t na zaslon. */

void printtreefull(object t,int lines,int columns);
     /* izpise drevo t na zaslon v polni obliki (pri klicih 
     spremenljivk in funkcij se izpisejo tudi definicije). */

void printtreepart(object t,int lines,int columns);
     /* izpise drevo t na zaslon v delno polni obliki (le pri klicih
     spremenljivk se izpisejo tudi definicije, pri klicih funkcij pa ne). */

void fprintlin(FILE *fp,object tr);
     /* Drevo izpise v linearni obliki v datoteko fp. */

void printlin(object tr);
     /* Drevo izpise v linearni obliki */

userfunc getcurrentuserfunc(void);
    /* Vrne kazalec na podatke o uporabniski funkciji, ki se trenutno vrednoti.
    $A Igorsep98; */

double doubleval(object tr,stack st,stack put);
     /* Funkcija vrne realno vrednost, ki ustreza binarnemu drevesu objektov
     tree. st je sklad, na katerega se nalagajo argumenti funkcij. */

userfunc installuserfuncret(ssyst syst,char *name,
     double fdoubleval (object,stack,stack,int,void *), void *doublevaldata,
     void fput (object,void *), void *putdata);
    /* Na sistem za simbolno racunanje syst instalira uporabnisko funkcijo z
    imenom name. fdoubleval je funkcija, ki jo uporablja funkcija doubleval
    za ovrednotenje dreves doubleval, ko naleti na uporabnisko fnkcijo,
    doublevaldata pa je argument klica te funkcije znotraj funkcije
    doubleval in sluzi za prenos podatkov, ce je potreben.
    Funkcija vrne podatke tipa userfunc, ki dolocajo na novo instalirano
    uporabnisko funkcijo.
    $A Igor jun97; */

void installuserfunc(ssyst syst,char *name,
     double fdoubleval (object,stack,stack,int,void *), void *doublevaldata,
     void fput (object,void *), void *putdata);
    /* Podobno kot installuserfuncret, le da ne vrne kazalca na strukturo, ki
    doloca instalirano uporabnisko funkcijo.
    $A Igor <== jun97; */

void comsyst(FILE *fp,ssyst syst,char *command);
     /* V sistemu simbolnega racunanja naredi to, kar ukazuje ukaz command. Ce
     se ukaz ne zacne z znakom '$', pomeni, da je treba niz vkljuciti v sistem
     objektob. Ce pa je 0. znak ukaza '$', pomeni to ukaz za specificno akcijo
     (npr. izpis drevesa na zaslon) */

void instbasuserfunc(ssyst system);
    /* Na sistem za simbolno racunanje instalira osnovne uporabniske funkcije */

void symbcalc(void);
     /* Simbolicni kalkulator */

void fsymbcalc(FILE *in,FILE *out);
     /* Simbolicni kalkulator; Navodila sprejema iz datoteke in, rezultate pa
     zapisuje v datoteko out. */

void filesymbcalc(char *nin,char *nout);
     /* Simbolicni kalkulator; Navodila sprejema iz datoteke  z imenom nin,
     rezultate pa zapisuje v datoteko z imenom nout. */

void includeexp(ssyst syst, char *expression);
     /* V sistem za simbolno racunanje se vkljuci izraz expression. */

double evaluateexp(ssyst syst, char *expression);
       /* Izracuna se vrednost izraza v sistemu za simbolno racunanje syst.
       Sam izraz se ne vkljuci v sistem za simbolno racunanje. */

void assigndouble(ssyst syst,char *name,double x);
     /* V sistemu ssyst poisce definicijo spremenljivke z imenom name in ji
     priredi vrednost tipa double. Ce definicija se ne obstaja, se objekt s
     tem imenom tvori na novo in potisne na sklad syst->def. Ce pa ze obstaja,
     se prejsnja definicija (torej desna veja objekta) potisne na sklad
     syst->trash. */






             /*********************************/
             /*                               */
             /*   VISJENIVOJSKE FUNKCIJE ZA   */
             /*     UPORABO KALKULATORJA      */
             /*                               */
             /*********************************/



    /* GLOBALNI KALKULATOR: */

void initglobcalc(void);
    /* Inicializira globalni kalkulatorj, ce se ni inicializiran.
    $A Igor maj01; */

void instglobcalc(ssyst s);
    /* Postavi globalni kalkulator na eksterni kalkulator s.
    $A Igor maj01; */

ssyst getglobcalc(void);
    /* Vrne globalni kalkulator.
    $A Igor okt01; */

void sendtoglobcalc(char *command);
    /* Poslje ukaz command globalnemu sistemu kalkulatorja. Definicije sprem.
    in funkcij morajo najprej vsebovati ime oz. ime z argumentnim blokom,
    nato dvopicje in nato definicijo.
    $A Igor maj01; */

void globcalcint(void);
    /* Interaktivno delo v sistemu globalnega kalkulatorja. Omogoca definicijo
    in ovrednotenje in definicijo spremenljivk in funkcij ter preverjanje
    stanja sistema global. kalkulatorja (katere stvari so definirane in kako).
    $A Igor maj01; */

double globcalcevaluate(char *expression);
    /* Ovrednoti izraz expression in vrne njegovo vrednost.
    $A Igor maj01; */




         /****************************************/
         /*                                      */
         /*     DEFINICIJA FUNKCIJ S POMOCJO     */
         /*       GLOBALNEGA KALKULATORJA        */
         /*                                      */
         /****************************************/



/* FUNKCIJE ENE SPREMENLJIVKE: */


void *defglobcalcfunc1d(char *defstr);
    /* Definira funkcijo ene spremenljivke v globalnem kalkulatorju z nizom
    defstr, kjer mora biti argument funkcije oznacen z nizom "x". Vrne kazalec,
    s katerim se dostopa do funkcije.
    $A Igor maj01; */

void * defglobcalcfunc1dint(void);
    /* Interaktivna definicija funkcije ene spremenljivke v globalnem
    kalkulatorju z nizom str, kjer mora biti argument funkcije oznacen z
    nizom "x". Funkcija vrne kazalec, s katerim se dostopa do definicije
    funkcije.
    $A Igor maj01; */

double globcalcfunc1d(void *defptr,double x);
    /* Vrne vrednost funkcije ene spremenljivke, ki je definirana preko
    globalnega kalkulatorja in je ptr kazalec na njeno definicijo, v tocki x.
    $A Igor maj01; */



/* FUNKCIJE DVEH SPREMENLJIVK: */

void *defglobcalcfunc2d(char *defstr);
    /* Definira funkcijo dveh spremenljivk v globalnem kalkulatorju z nizom
    defstr, kjer morata biti argumenta funkcije oznacena z nizoma "x" in "y".
    Vrne kazalec, s katerim se dostopa do funkcije.
    $A Igor maj01; */

void * defglobcalcfunc2dint(void);
    /* Interaktivna definicija funkcije dveh spremenljivke v globalnem
    kalkulatorju z nizom str, kjer morata biti argumenta funkcije oznacena z
    nizom "x" in "y". Funkcija vrne kazalec, s katerim se dostopa do definicije
    funkcije.
    $A Igor maj01; */

double globcalcfunc2d(void *defptr,double x,double y);
    /* Vrne vrednost funkcije dveh spremenljivk, ki je definirana preko
    globalnega kalkulatorja in je ptr kazalec na njeno definicijo, v tocki
    (x,y).
    $A Igor maj01; */


/* FUNKCIJE TREH SPREMENLJIVK: */

void *defglobcalcfunc3d(char *defstr);
    /* Definira funkcijo treh spremenljivk v globalnem kalkulatorju z nizom
    defstr, kjer morajo biti argumenti funkcije oznaceni z nizi "x", "y" in "z".
    Vrne kazalec, s katerim se dostopa do funkcije.
    $A Igor maj01; */

void * defglobcalcfunc3dint(void);
    /* Interaktivna definicija funkcije treh spremenljivke v globalnem
    kalkulatorju z nizom str, kjer morajo biti argumenti funkcije oznaceni z
    nizi "x", "y" in "z". Funkcija vrne kazalec, s katerim se dostopa do
    definicije funkcije.
    $A Igor maj01; */

double globcalcfunc3d(void *defptr,double x,double y,double z);
    /* Vrne vrednost funkcije treh spremenljivk, ki je definirana preko
    globalnega kalkulatorja in je ptr kazalec na njeno definicijo, v tocki
    (x,y,z).
    $A Igor maj01; */


/* FUNKCIJE VEKTORSKE SPREMENLJIVKE: */

void *defglobcalcfuncvec(char *defstr,int n);
    /* Definira funkcijo vektorske spremenljivke v globalnem kalkulatorju z
    nizom defstr, kjer morajo biti argumenti funkcije oznaceni z nizi "x1",
    "x2" "x3, ...  n je stevilo argumentov funkcije (oz. komponent vektorskega
    argumenta). Vrne kazalec, s katerim se dostopa do funkcije.
    $A Igor maj01; */

void * defglobcalcfuncvecint(int n);
    /* Interaktivna definicija funkcije vektorske spremenljivke v globalnem
    kalkulatorju z nizom, kjer morajo biti argumenti funkcije oznaceni z
    nizi "x1", "x2", ... Funkcija vrne kazalec, s katerim se dostopa do
    definicije funkcije. n je stevilo argumentov funkcije.
    $A Igor maj01; */

double globcalcfuncvec(void *defptr,vector v);
    /* Vrne vrednost funkcije vektorske spremenljivke, ki je definirana preko
    globalnega kalkulatorja in je ptr kazalec na njeno definicijo, v tocki v.
    $A Igor maj01; */


/* DEFINICIJA FUNKCIJE VEC SPREMENLJIVK Z IMENI ARGUMENTOV, ki so podana na
skladu: */

void *defglobcalcfuncvecsymb(char *defstr,stack st);
    /* Definira funkcijo vec argumentov v globalnem kalkulatorju z nizom
    defstr, kjer morajo biti argumenti funkcije oznaceni z nizi, lo so na
    skladu st. Vrne kazalec, s katerim se dostopa do funkcije.
    $A Igor maj01; */

void * defglobcalcfuncvecsymbint(stack st);
    /* Interaktivna definicija funkcije vec spremenljivk v globalnem
    kalkulatorju. V nizu, ki definira funkcijo, morajo biti argumenti funkcije
    oznaceni z nizi na skladu st. Funkcija vrne kazalec, s katerim se dostopa
    do definicije funkcije.
    $A Igor maj01; */

double globcalcfuncvecsymb(void *defptr,vector v);
    /* Vrne vrednost funkcije vec spremenljivk, ki je definirana preko
    globalnega kalkulatorja in je ptr kazalec na njeno definicijo, v tocki v.
    Namesto te funkcije se lahko uporabi kar globcalcfuncvec().
    $A Igor maj01; */


/* PARAMETRICNE FUNKCIJE (argumenti x1, x2, ... in parametri p1, p2, ...): */

void *defglobcalcfuncvecpar(char *defstr,int m,int n);
    /* Definira parametricno funkcijo vektorske spremenljivke v globalnem
    kalkulatorju z nizom defstr, kjer morajo biti argumenti funkcije oznaceni z
    nizi "x1", "x2" "x3", ... in parametri z nizi "p1", "p2" "p3", ... m je
    stevilo argumentov funkcije (oz. komponent vektorskega argumenta), n pa
    stevilo parametrov. Vrne kazalec, s katerim se dostopa do funkcije.
    $A Igor maj01; */

void * defglobcalcfuncvecparint(int m,int n);
    /* Interaktivna definicija funkcije vektorske spremenljivke v globalnem
    kalkulatorju z nizom, v katerem morajo biti argumenti funkcije oznaceni z
    nizi "x1", "x2", ... in parametri z nizi "p1", "p2" "p3", ... m je stevilo
    argumentov funkcije (oz. komponent vektorskega argumenta), n pa stevilo
    parametrov.  Funkcija vrne kazalec, s katerim se dostopa do
    definicije funkcije.
    $A Igor maj01; */

double globcalcfuncvecpar(void *defptr,vector v,vector p);
    /* Vrne vrednost funkcije parametricne vektorske spremenljivke, ki je
    definirana preko globalnega kalkulatorja in je ptr kazalec na njeno
    definicijo, v tocki v.
    $A Igor maj01; */








#endif    /* (not defined) INCLUDED_simb */
