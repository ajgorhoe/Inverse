



void invinstallcubicsplines(void);
    /* V program Inverse instalira funkcije kalkulatorja in interpreterja za
    racunanje kubicnih zlepkov. */

void invinstallmiscut(void);
    /* V program Inverse instalira razlicne funkcije kalkulatorja in
    interpreterja.
    $A Igor sep01; */

