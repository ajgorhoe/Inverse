




int initobject(object o);
     /* Inicializira podat. strukturo tipa object */

object newobject(void);
       /* Alocira prostor za nov element tipa _object,
       ta element inicializira in vrne kazalec nanj */

int inittabobj(tabobj o);

tabobj newtabobj(void);
       /* Na novo tvori tabelo z enim elementom in vrne kazalec nanjo */

int disptabobj(tabobj *tt);
    /* Brise spremenljivko tabobj, na katero kaze tt. Ta funkcija ne brise 
    tega, kar spremenljivka vsebuje (torej objekta, na katerega kaze (*tt->o). */

int numtabobj(tabobj t);
    /* vrne stevilo elementov v tabli t */

tabobj eltabobj(tabobj o,int n);
       /* Vrne n-ti eleent tabele objektov o. Ce je n vecji od stevila
       elementov, vrne NULL. */

tabobj lasteltabobj(tabobj o);
       /* Vrne zadnji obstojeci element tabele objektov o. Ce je tabela
       prazna, vrne NULL */

tabobj findtabobj(tabobj o,char *s);
       /* Vrne tisti element tabele, ki vsebuje objekt z imenom s) */

int placetabobj(tabobj o,char*s);
    /* Vrne mesto v tabeli objektov o, na katerem se nahaja element,
    ki vsebuje objekt z imenom s)*/

tabobj addtabobj(tabobj o);
       /* Funkcija doda clen v tabeli objektov o in vrne kazalec nanj.
       Ce tabela ne obstaja (torej je enaka NULL), vrne funkcija NULL. */

void initsymbsyst(void);
     /* Inicializira simbolni sistem*/

void doubleobj(object o, double r);
     /* Objektu, ki predstavlja stevilo tipa double, priredi vrednost r. */

void longobj(object o, long l);
     /* Objektu, ki predstavlja stevilo tipa long, priredi vrednost r. */

tabobj cutexpression(char *expression);
       /* Izraz, ki ga predstavlja niz expression, razdeli na osnovne elemente,
       ki jih pretvori v simbole. To je prva obdelava izraza. funkcija vrne 
       tabelo objektov, ki nastopajo v istem vrstnem redu kot simboli v nizu. */

int arrangelistobj(tabobj t);
    /* Uredi seznam objektov t. Preveri tudi, ce so vsi oklepaji zakljuceni.
    ce je kaj narobe, vrne 1, drugace 0. Funkcija tudi dodatno postavi tipe 
    nekaterih objektov. */

int printtabobj(tabobj tab);
    /* Izpise seznam objektov tt na zaslon */

int disp1obj(object *oo);
    /* Brise en sam objekt, na katerega kaze oo. Ce objekt vsebuje kako 
    vrednost, brise tudi to. */

void disptree(object *o);
     /* Brise celotno drevo objektov. */

object _maketree(tabobj list,object *ret);
       /* iz tabele objektov naredi drevo, vrne kazalec na koren drevesa. */

void fprinttree(FILE *fp,object t,int lines,int columns);
     /* izpise drevo t na konec datoteke fp. */

void printtree(object t,int lines,int columns);
     /* izpise drevo t na zaslon. */

void fprinttree1(FILE *fp,object t);
     /* izpise drevo t na konec datoteke fp. */

void printtree1(object t);
     /* izpise drevo t na zaslon. */

void printlin(object tr);
     /* Drevo izpise v linearni obliki */









































































