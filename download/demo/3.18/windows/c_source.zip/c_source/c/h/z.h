

void codestring(char *str,int length,char *key);
    /* Codes string str of length length with the current coding algorithm
    using the key string key. str can contain zero characters ('\0').
    Function setcodingdata() or setcodingdatanum() should be called prior to use
    of this function.
    $A Igor dec02; */

void codestring0(char *str,char *key);
    /* Codes string str of length length with the current coding algorithm
    using the key string key. str must be a zero terminated string.
    Function setcodingdata() or setcodingdatanum() should be called prior to use
    of this function.
    $A Igor dec02; */

void decodestring(char *str,int length,char *key);
    /* Decodes string str of length length with the current coding algorithm
    using the key string key. str can contain zero characters ('\0').
    Function setcodingdata() or setcodingdatanum() should be called prior to use
    of this function.
    $A Igor dec02; */

void decodestring0(char *str,char *key);
    /* Decodes string str of length length with the current coding algorithm
    using the key string key. str must be a zero terminated string.
    Function setcodingdata() or setcodingdatanum() should be called prior to use
    of this function.
    $A Igor dec02; */

int setcodingdata(char *name);
    /* Sets the coding and encoding functions and data according to the
    string name. Returns 1 if successfull, 0 if not.
    $A Igor dec02; */

char *setcodingdatanum(int n);
    /* Sets the coding and encoding functions and data according to the
    successive number n on the stack codingstack. Returns the coding
    identification string if successfull, NULL if not.
    $A Igor dec02; */

void initcodingdata(void);
    /* Initialises data about the available ways of coding identifiable by the
    identification strings. 
    $A Igor dec02; */



char *getmachineid(char *helpstr);
    /* Funkcija vrne identifikacijski niz racunalnika, na katerem tece program.
    Ta niz se lahko uporabi npr. za preverjanje veljavnosti licenc. helpstr
    je pomozni niz, s katerim si funkcija lahko pomaga, da pride do pravega
    identifikacijskega niza. Na DOSu in Windowsih se npr. za identifikacijski
    niz tipicno vzame serijska stevilka diska, na katerem je instaliran
    program, zato pa je treba vedeti, kateri je ta disk in to sporocimo
    funkciji prek argumenta helpstr (na UNIX-u tega argumenta ne uporabljamo).
      Ce se identifikacijskega niza ne more dobiti, funkcija vrne NULL.
    $A Igor avg98; */

char *getuserdatafield(char *data,int length,char *fieldname);
    /* Vrne vrednost polja z imenom fieldname iz niza data dolzine length, ki
    vsebuje podatke o licenci oz. uporabniku programa v primerni obliki. Ce
    taksnega polja niz data ne vsebuje, vrne NULL. Niz, ki ga funkcija vrne,
    lahko brisemo s free.
    $A Igor sep98; */

char *getuserdatafield0(char *data,char *fieldname);
    /* Vrne vrednost polja z imenom fieldname iz niza data, ki vsebuje podatke
    o licenci oz. uporabniku programa v primerni obliki. Ce taksnega polja niz
    data ne vsebuje, vrne NULL. Niz, ki ga funkcija vrne, lahko brisemo s free.
    data mora biti niz zakljucen z znakom '\0'.
    $A Igor sep98; */

static void addfieldtouserdata(char **data,char *fieldname,char *fieldvalue);
    /* V niz *data, ki predstavlja podatke o programu in licenci, doda polje
    z imenom fieldname in vrednostjo fieldvalue.
     OPOMBA:
     Format niza, ki predstavlja podatke o licenci, je nasleden:
       polje1{vrednost1} polje2{vrednost1} polje3{vrednost3} ...
    Ime 1. polja mora biti obvezno "program"!!! Poleg tega mora biti to ime
    takoj na zacetku niza!
    $A Igor avg98; */

char *getuserdatastr(char *first,...);
    /* Returns an allocated string that contains field and values as specified
    by arguments. Arguments must appear in pairs where the first one represents
    the field and the second one the coresponding value (may be NULL). The end
    of the pairs must be indicated by a NULL pointer for the field. There is
    no need to state any corresponding value pointer to this terminating field
    pointer.
    $A Igor dec02; */

char *getuserdata(stack fieldnames,stack fieldvalues);
    /* Returns an allocated string that contains fields and values as specified
    by stack fieldnames and fieldvalues. Fieldnames must contain strings thet
    represent the fields while corresponding strings on fieldvalues must ve
    the values of these fields.
    $A Igor dec02; */

char *getuserdataint(stack fieldnames,stack fieldvalues);
    /* Makes a string that contains data about the program and licence. Stack
    fieldnames must contain names of the fields included in the string while
    the stack fieldvalues must contain the values of these fields at the
    corresponding positions.
      If any values on fieldvalues are NULL then the user is asked to insert
    these values. When all fields on fieldnames are added to the created
    string, the user is asked to add any additional fields. Entering of the
    additional fields stops when the user inserts an empty string for the
    first time.
    $A Igor avg98; dec02; */

char *getuserdataintstr(char *first,...);
    /* Returns an allocated string that contains field and values as specified
    by arguments. Arguments must appear in pairs where the first one represents
    the field and the second one the coresponding value (may be NULL). The end
    of the pairs must be indicated by a NULL pointer for the field. There is
    no need to state any corresponding value pointer to this terminating field
    pointer.
    $A Igor dec02; */

char *getuserdatastandard(void);
    /* Naredi niz, v katerem so osnovni podatki o programu in licenci in ki je
    osnova z kljuc, ki ga cekira program pri zagonu. Nekaj standardnih polj
    funkcija ze sama pripravi za vgraditev v niz.
    $A Igor avg98; */





                /******************/   
                /*                */   
                /*   FROM z/z.h   */
                /*                */   
                /******************/   


char *getuserdatainv(char *key);
    /* Naredi niz, v katerem so osnovni podatki o programu in licenci in ki je
    osnova z kljuc, ki ga cekira program pri zagonu, za program Inverse. Nekaj
    standardnih polj funkcija ze sama pripravi za vgraditev v niz, za ostale
    se vprasa uporabnika.
    $A Igor avg98; */

char *createkeyinv(void);
    /* Naredi zascitno datoteko - kljuc za program Inverse. Pri tem vprasa
    uporabnika za potrebne podatke in za geslo, s katerim se naredi kljuc.
    $A Igor avg98; */

char *ig_getmachinestr(void);
    /* Returns machine-dependent string that can be used for check the machine
    identity.
    $A Igor dec02; */



      /* CODING BY CHARACTER MAPS */

void codetwostepsimp100(char *string,int length,char *key);
    /* Zakodira niz string dolzine length po kljucu key s pomocjo funkcije
    getkeytwostepsimp100(). Ta funkcija priskrbi glede na vsebino niza key
    tabelo za pretvorbo znakov.
    $A Igor avg98; */

void codethreestepsimp100(char *string,int length,char *key);
    /* Zakodira niz string dolzine length po kljucu key s pomocjo funkcije
    getkeythreestepsimp100(). Ta funkcija priskrbi glede na vsebino niza key
    tabelo za pretvorbo znakov.
    $A Igor avg98; */

void codefourstepsimp100(char *string,int length,char *key);
    /* Zakodira niz string dolzine length po kljucu key s pomocjo funkcije
    getkeyfourstepsimp100(). Ta funkcija priskrbi glede na vsebino niza key
    tabelo za pretvorbo znakov.
    $A Igor avg98; */


    /* CODING WITHOUT CHARACTER MAPS, dependent on length: */

void codeblocksimppub(char *str,int length,char *key);
    /* Codes block of length characters pointed to by str according to the
    key string key. Mapping of characters in str is dependent on previous
    characters in this string, therefore the result will be different if str
    is coded in fragments. Backward transformation thet restores the original
    string is performed by decodeblocksimppub().
      Similar to codeblocksimp1001().
    $A Igor jan03; */

void decodeblocksimppub(char *str,int length,char *key);
    /* Decodes block of length characters pointed to by str according to the
    key string key. Mapping of characters in str is dependent on previous
    characters in this string, therefore the result will be different if str
    is coded in fragments. Backward transformation thet restores the original
    string is performed by codeblocksimppub().
      Similar to decodeblocksimp1001().
    $A Igor jan03; */

void codeblocksimpinv(char *str,int length,char *key);
    /* Codes block of length characters pointed to by str according to the
    key string key. Mapping of characters in str is dependent on previous
    characters in this string, therefore the result will be different if str
    is coded in fragments. Backward transformation thet restores the original
    string is performed by decodeblocksimpinv().
      Similar to codeblocksimp1002().
    $A Igor jan03; */

void decodeblocksimpinv(char *str,int length,char *key);
    /* Decodes block of length characters pointed to by str according to the
    key string key. Mapping of characters in str is dependent on previous
    characters in this string, therefore the result will be different if str
    is coded in fragments. Backward transformation thet restores the original
    string is performed by codeblocksimp1002().
      Similar to decodeblocksimp1002().
    $A Igor jan03; */







    /* FROM h_z.h */

void codeblocksimp0(char *str,int length,char *key);
void decodeblocksimp0(char *str,int length,char *key);
void codeblocksimp1001(char *str,int length,char *key);
void decodeblocksimp1001(char *str,int length,char *key);
void codeblocksimp1002(char *str,int length,char *key);
void decodeblocksimp1002(char *str,int length,char *key);
void codeblocksimp100(char *str,int length,char *key);
void decodeblocksimp100(char *str,int length,char *key);





