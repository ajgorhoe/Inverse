
/* The code that ensures at most one inclusion: */
#ifndef INCLUDED_sg_obj
#define INCLUDED_sg_obj


        /************************************/
        /*                                  */
        /*   MANIPULATING GRAPHIC OBJECTS   */
        /*                                  */
        /************************************/



#ifndef INCLUDED_st
  #include <st.h>
#endif


typedef struct {
        double x,
               y,
               z;
        } _coord3d;

typedef _coord3d *coord3d;



typedef struct {
        _coord3d min,
                 max;
        } _frame3d;

typedef _frame3d *frame3d;



typedef struct{
        double fi,
               theta,
               cf,
               sf,
               ct,
               st;
         /*
         fr2d f2d;
         fr3d f3d;
         */
         double maxlength;
        } _transfsimptype;

typedef _transfsimptype *transfsimptype;




typedef struct {
        float red,green,blue;
        } _truecolor;

typedef _truecolor *truecolor;



typedef struct {
        _truecolor color;
        double linewidth;
        int linetype;
        void *extra;
        } _golinesettings;

typedef _golinesettings *golinesettings;



typedef struct {
        _truecolor color;
        void *extra;
        } _gofillsettings;


typedef _gofillsettings *gofillsettings;


typedef struct {
        _truecolor color;
        int font;
        double height;
        double spacing;
        double expansion;
        int xalignment;
        int yalignment;
        void *extra;
        } _gotextsettings;


typedef _gotextsettings *gotextsettings;


typedef struct {
        void (*clear)(void *); /* this function is executed at deletion of the
                                  strcture if it is different than NULL */
        int id;      /* identification number */
        char *name;  /* optional name */
        char limitsset,  /* flag for whether limits are calculated and set */
             transflimitsset;  /* flag for whether transf. limits are calc. and set */
        coord3d min,   /* limits... */
                max,
                mintransf,
                maxtransf;
        golinesettings ls1,  /* properties for contained objects */
                       ls2;
        gofillsettings fs1,
                       fs2;
        gotextsettings ts1,
                       ts2;
        stack primitives;    /* contained primitives that are drawn when the
                             group is drawn */
        stack extraprimitives; /* contained primitives which are not drawn when
          the group is drawn (typically they are drawn in connection with other
          primitives, i.e. their pointers are on the stack (...)->before or
          (...)->after of some other primitive */
        stack groups;
        void  *grp;  /* Group that contains this group */
        } _gogroup;

typedef _gogroup *gogroup;



typedef struct {
  void (*clear)(void *); /* function that is executed at the deletio of this
                         structure if it is different than NULL */
  /* char i1,i2,i3,i4; */  /* Identification of kind of ptimitives */
  short int type;
  double *dp;      /* Additional parameter of the type double */
  /* void *geo; */       /* Geometrical properties; currently not used */
  stack coord,     /* Stack of co-ordinates */
        transfcoord, /* Transformed co-ordinates */
        before, /* Objects to be drawn before this object */
        after;  /* Objects to be drawn after this object */
  void *props1,   /* Non-geometric properties */
       *props2,
       *props3,
       *props4;
  gogroup grp;    /* Group that contains this primitive */
#ifdef IGS
    char i1,i2,i3,i4;  /* Identification of kind of the primitive */
#endif
} _goprimitive;

typedef _goprimitive *goprimitive;


/* Definitions for types of grapgic primitives: */

#define SG_PR_UNDEF     0   /* undefined type */

#define SG_PR_LINE     10  /* line */

#define SG_PR_TRI      30  /* triangle (framed) */
#define SG_PR_F_TRI    31  /* filled triangle */
#define SG_PR_FB_TRI   32  /* filled and bordered triangle */
#define SG_PR_FP_TRI   33  /* filled, partially bordered triangle */

#define SG_PR_FOUR     40  /* fourangle (framed) */
#define SG_PR_F_FOUR   41  /* filled fourangle */
#define SG_PR_FB_FOUR  42  /* filled and bordered fourangle */
#define SG_PR_FP_FOUR  43  /* filled, partially bordered fourangle */

#define SG_PR_TEXT     50  /* text */
#define SG_PR_MARK     60  /* marker (e.g. for points) */
#define SG_PR_ARROW    70  /* arrow (e.g. for vectors) */


/*
Table:
Members of the structure *goprimitive with respect to type of the primitive

Primitive type |  Meaning of the pointers props1, props2, props3 in props4
  (...)->type  |        /   (type of pointers)
---------------+------------------------------------------------------------
 SG_PR_LINE    |  1: Line settings (golinesettings)
---------------+------------------------------------------------------------
 SG_PR_TRI     |  1: Line settings (golinesettings)
---------------+------------------------------------------------------------
 SG_PR_F_TRI   |  1: Fill settings (gofillsettings)
---------------+------------------------------------------------------------
 SG_PR_FB_TRI  |  1: Fill settings (gofillsettings)
                  2: Line settings (golinesettings)
---------------+------------------------------------------------------------
 SG_PR_FP_TRI  |  1: Fill settings (gofillsettings)
                  2: Line settings (golinesettings)
                  3: Flags for bordered edges (char[3])
---------------+------------------------------------------------------------
 SG_PR_FOUR    |  1: Line settings (golinesettings)
---------------+------------------------------------------------------------
 SG_PR_F_FOUR  |  1: Fill settings (gofillsettings)
---------------+------------------------------------------------------------
 SG_PR_FB_FOUR |  1: Fill settings (gofillsettings)
                  2: Line settings (golinesettings)
---------------+------------------------------------------------------------
 SG_PR_FP_FOUR |  1: Fill settings (gofillsettings)
                  2: Line settings (golinesettings)
                  3: Flags for bordered edges (char[4])
---------------+------------------------------------------------------------
 SG_PR_TEXT    |  1: Text string   (char *)
                  2: Text settings (gotextsettings)
---------------+------------------------------------------------------------
 SG_PR_MARK    |  1: Fill settings (gofillsettings)
                  2: Line settings (golinesettings)
                  3: Size (double[1])
                  4: Kind (int[1])
---------------+------------------------------------------------------------
 SG_PR_ARROW   |  1: Fill settings (gofillsettings)
                  2: Line settings (golinesettings)
                  3: {size, angle} (double[2])
                     - size is specified either absolutely (i.e. relative to
                     image size) of relatively to arrow length, dep. on attr.
                     angle is the tangent of the half-angle between the main
                     line and arroe head
                  4: Attributes    (int[1])
                     - should be an orred combination of the following flags
                     defined in sg_draw.h:
            SG_ARROW_NOFILL :  head is not filled
            SG_ARROW_LINE:     head is bordered by lines
            SG_ARROW_TRIANGLE: head border as triangle (with transversal line)
            SG_ARROW_ABS:      head size given in absolute sense

  REMARK:
  The following rules for connecting graphic objects should be observed:
  The primitives that are on the stacks (...)->before or (...)->after of some
primitive xxx (which automatically means that they must be loaded somewhere else,
too, since otherwise they would not be deleted when the containing group of
graphic objects is deleted) can be loaded on the stack (...)->extraprimitives
of the group that contains a given graphic primitive xxx, or on this stack of
some some of its sub-groups (i.e. groups that are loaded on (...)->groups of
this group). Alternatively such primitives can also be loaded on the stack
(...)->primitives of one of these groups, but this is not usual since in this
case they are drawn twice (i.e. once for themselves and once for the primitive
xxx). At most first level sub-groups are possible candidates for containing
these primitives. If the primitives from (...)->after or (...)->before are
loaded on deeper-level groups then copygogroup will not be able to set these
primitives on the copied groups.
  Primitives that are on the stack (...)->extraprimitives of a group should not
contain objects on the stack (...)->before and (...)->after.
*/



    /* BASIC GRAPHIC TYPES: ALLOCATION, DEALLOCATION, COPYING... */

  /* COORDINATES, FRAMES: */

coord3d newcoord3d(void);
    /* Creates a new object of type coord3d and returns it.
    $A Igor nov03; */

void dispcoord3d(coord3d *coord);
    /* Deallocates space occupied by *coord and sets *coord to NULL.
    $A Igor nov03; */

int sizecoord3d(coord3d coord);
    /* Returns the size of memory occupied by coord, in bytes.
    $A Igor nov03; */

coord3d copycoord3d(coord3d c1,coord3d *c2);
    /* Returns a copy of the c1. If c2 is different than NULL then c1 is
    copied to *c2 and *c2 returned, otherwise a dynamic copy of c1 is made
    and returned.
    $A Igor nov03; */

frame3d newframe3d(void);
    /* Creates a new object of type frame3d and returns it.
    $A Igor nov03; */

void dispframe3d(frame3d *frame);
    /* Deallocates space occupied by *frame and sets *frame to NULL.
    $A Igor nov03; */

int sizeframe3d(frame3d frame);
    /* Returns the size of memory occupied by frame, in bytes.
    $A Igor nov03; */

frame3d copyframe3d(frame3d f1,frame3d *f2);
    /* Returns a copy of f1. If f2 is different than NULL then f1 is
    copied to *f2 and *f2 returned, otherwise a dynamic copy of f1 is made
    and returned.
    $A Igor nov03; */

  /* COLOR STRUCTURE: */


truecolor newtruecolor(void);
    /* Creates a new object of type truecolor and returns it.
    $A Igor nov03; */

void disptruecolor(truecolor *coord);
    /* Deallocates space occupied by *coord and sets *coord to NULL.
    $A Igor nov03; */

int sizetruecolor(truecolor coord);
    /* Returns the size of memory occupied by coord, in bytes.
    $A Igor nov03; */

truecolor copytruecolor(truecolor c1,truecolor *c2);
    /* Returns a copy of the c1. If c2 is different than NULL then c1 is
    copied to *c2 and *c2 returned, otherwise a dynamic copy of c1 is made
    and returned.
    $A Igor nov03; */


  /* LINE SETTINGS: */

golinesettings newgolinesettings(void);
    /* Returns a newly allocated object of type golinesettings with default
    values of fields.
    $A Igor nov03; */

void dispgolinesettings(golinesettings *addr);
    /* Deallocates the space for *addr and sets *addr to NULL.
    $A Igor nov03; */

int sizegolinesettings(golinesettings ls);
    /* Returns the total space occupied by the object ls of the type
    golinesettings.
    $A Igor nov03; */

golinesettings copygolinesettings0(golinesettings ls1,golinesettings ls2);
    /* Copy the contents of ls1 to ls2 if BOTH ls1 and ls2 are DIFFERENT THAN
    NULL. ls2 is returned if copying has been performed.
    $A Igor nov03; */

golinesettings copygolinesettings(golinesettings ls1,golinesettings *ls2);
    /* Returns a copy of the ls1. If ls2 is different than NULL then ls1 is
    copied to *ls2 and *ls2 returned, otherwise a dynamic copy of ls1 is made
    and returned.
    $A Igor nov03; */


  /* FILL SETTINGS: */

gofillsettings newgofillsettings(void);
    /* Returns a newly allocated object of type gofillsettings with default
    values of fields.
    $A Igor nov03; */

void dispgofillsettings(gofillsettings *addr);
    /* Deallocates the space for *addr and sets *addr to NULL.
    $A Igor nov03; */

int sizegofillsettings(gofillsettings fs);
    /* Returns the total space occupied by the object fs of the type
    gofillsettings.
    $A Igor nov03; */

gofillsettings copygofillsettings0(gofillsettings fs1,gofillsettings fs2);
    /* Copy the contents of fs1 to fs2 if BOTH fs1 and fs2 are DIFFERENT THAN
    NULL. fs2 is returned if copying has been performed.
    $A Igor nov03; */

gofillsettings copygofillsettings(gofillsettings fs1,gofillsettings *fs2);
    /* Returns a copy of the fs1. If fs2 is different than NULL then fs1 is
    copied to *fs2 and *fs2 returned, otherwise a dynamic copy of fs1 is made
    and returned.
    $A Igor nov03; */


  /* TEXT SETTINGS: */

gotextsettings newgotextsettings(void);
    /* Returns a newly allocated object of type gotextsettings with default
    values of fields.
    $A Igor nov03; */

void dispgotextsettings(gotextsettings *addr);
    /* Deallocates the space for *addr and sets *addr to NULL.
    $A Igor nov03; */

int sizegotextsettings(gotextsettings ts);
    /* Returns the total space occupied by the object ts of the type
    gotextsettings.
    $A Igor nov03; */

gotextsettings copygotextsettings0(gotextsettings ts1,gotextsettings ts2);
    /* Copy the contents of ts1 to ts2 if BOTH ts1 and ts2 are DIFFERENT THAN
    NULL. ts2 is returned if copying has been performed.
    $A Igor nov03; */

gotextsettings copygotextsettings(gotextsettings ts1,gotextsettings *ts2);
    /* Returns a copy of the fs1. If fs2 is different than NULL then fs1 is
    copied to *fs2 and *fs2 returned, otherwise a dynamic copy of fs1 is made
    and returned.
    $A Igor nov03; */


  /* GRAPHIC PRIMITIVES: */

goprimitive newgoprimitive(void);
    /* Allocates space for an object of the type goprimitive and returns its
    pointer.
    $A Igor <== sep03; */

void dispgoprimitive(goprimitive *p);
    /* Releases memory used by **p and sets *p to NULL.
    $A Igor <== sep03; */

int sizegoprimitive(goprimitive gp);
    /* Returns the total amount of memory, in bytes, occupied by gp.
    $A Igor nov03; */

goprimitive copygoprimitive0(goprimitive gp1,goprimitive gp2);
    /* Copies the contents of gp1 to gp2 if BOTH gp1 and gp2 are DIFFERENT THAN
    NULL. gp2 is returned if copying has been performed. Pointers on stacks
    before and after are NOT copied.
    $A Igor nov03; */

goprimitive copygoprimitive(goprimitive gp1,goprimitive *gp2);
    /* Returns a copy of the gp1. If gp2 is different than NULL then gp1 is
    copied to *gp2 and *gp2 returned, otherwise a dynamic copy of gp1 is made
    and returned. Pointers on the stacks gp1->before and gp1->after are not
    copied!
    $A Igor nov03; */


    /* GROUPS OF GRAPHIC OBJECTS: */

gogroup newgogroup(void);
    /* Allocates space for a new object of type gogroup and returns its pointer.
    Space for stack members (...)->groups, (...)->primitives and
    (...)->primitives is not allocated.
    $A Igor <== sep03; */

gogroup newgogroupst(int ngroups,int nprimitives,int nextraprimitives);
    /* Allocates space for a new object of the type gogroup and returns its
    pointer. The space members  (...)->groups, (...)->primitives and
    (...)->primitives (which are stacks) are also initialized where the (...)->ex
    fields are set to ngroups, nprimitives and nextraprimitives, respectively. If
    any of these numbers is less than 1 then space for the corresponding stack is
    not allocated.
    $A Igor <== sep03; */

void dispgogroup(gogroup *p);
    /* Releases the memory space occupied by **p and sets *p to NULL. The space
    that is occupied by the member objects of **p is released first. Sub-groups
    are released recursively.
    $A Igor <== sep03; */

int sizegogroup(gogroup gg);
    /* Returns the total memory space in bytes occupied by gg.
    $A Ikgor nov03; */

gogroup copygogroup0(gogroup gg1,gogroup gg2);
    /* Copies the contents of gg1 to gg2 if BOTH gg1 and gg2 are DIFFERENT THAN
    NULL. gg2 is returned if copying has been performed, otherwise NULL is
    returned. Pointers on stacks before and after are NOT copied.
    $A Igor nov03; */

gogroup copygogroup(gogroup gg1,gogroup *gg2);
    /* Returns a copy of the gg1. If gg2 is different than NULL then gg1 is
    copied to *gg2 and *gg2 returned, otherwise a dynamic copy of gg1 is made
    and returned.
    $A Igor nov03; */




    /* LIMITS OF GRAPHIC GROUPS: */


void printframe3d(frame3d frame);
    /* Prints limits in x, y and z direction that are stored in frame.
    $A Igor avg01 sep03; */

void calcgogroupframe0(gogroup gg,frame3d frame);
    /* Extends the limits stored in frame so that they include co-ordinates of all
    graphic objects that are loaded on the group gg and all its sub-groups. Non-
    tansformed co-ordinates are taken into account.
    $A Igor avg01 sep03; */

void calcgogroupframe(gogroup gg,frame3d frame);
    /* Calculates limits of coordinates of all graphic objects contained in the
    graphic group gg and its sub-groups and stores them in frame (which must point
    to appropriate allocated memory space). This is done by first setting upper
    limits to positive and lower limits to negative numbers with very large
    absolute value, and then calling calcgogroupframe0(). Non-transformed co-
    ordinates of graphic objects are taken into account.
    $A Igor avg01 sep03; */





               /***********************************/
               /* CONSTRUCTION OF GRAPHIC OBJECTS */
               /***********************************/



void goupdatelimits(coord3d p,gogroup gg);
    /* If necessary, extends the limits on gg (gg->min in gg->max) in such a way
    that also the point with the co-ordinates p falls within the limits.
     $A Igor <== avg01 sp03; */

void goupdatetransflimits(coord3d p,gogroup gg);
    /* If necessary, extends the limits of transformed co-ordinates of the group
    gg (gg->mintransf in gg->maxtransf) in such a way that also the point with
    the transformed co-ordinates p falls within the limits.
    $A Igor apr97 sep03; */

void goupdatelimitsgrouptree(gogroup gg);
    /* Recursively extends limits on gg in such a way that new limits include
    all sub-groups of graphic objects on gg.
    $A Igor apr97 sep03; */

goprimitive goaddline(coord3d p1,coord3d p2,stack st,gogroup grp);
    /* Adds a graphic primitive that represents a line from the point with
    co-ordinates p1 to the point with co-ordinates p2 to the stack st. The
    containing group of the primitive is set to grp.
    $A Igor <== sep03; */

goprimitive goaddlinediv(coord3d p1,coord3d p2,stack st,gogroup grp,int num);
    /* Adds a line from the point with co-ordinates p1 to the point with co-
    ordinates p2 composed from num smaller lines (graphical primitives) to
    the stack st. The containing group of the primitives is set to grp.
    $A Igor <== sep03; */

goprimitive goaddtriangle(coord3d p1,coord3d p2,coord3d p3,stack st,gogroup grp);
    /* Adds a graphic primitive that represents a triangle made of lines with
    apices p1, p2 and p3, to the stack st. The containing group of the
    primitive is set to grp.
    $A Igor <== sep03; */

goprimitive goaddfilltriangle(coord3d p1,coord3d p2,coord3d p3,stack st,gogroup grp);
    /* Adds a graphic primitive that represents a filled triangle  with apices
    p1, p2 and p3, to the stack st. The containing group of the primitive is
    set to grp.
    $A Igor <== sep03; */

goprimitive goaddbordtriangle(coord3d p1,coord3d p2,coord3d p3,stack st,gogroup grp);
    /* Adds a graphic primitive that represents a filled and bordered triangle
    with apices p1, p2 and p3, to the stack st. The containing group of the
    primitive is set to grp.
    $A Igor <== sep03; */

goprimitive goaddpartbordtriangle(coord3d p1,coord3d p2,coord3d p3,
            char b1,char b2, char b3,stack st,gogroup grp);
    /* Adds a graphic primitive that represents a filled and partially
    bordered triangle  with apices p1, p2 and p3, to the stack st. b1, b2 and
    b3 indicate whether the corresponding border lines will be drawn (they are
    copied to a string of characters (...)->props3, if at least one of them is
    different than 0, otherwise (...)->props3 remains NULL.
    $A Igor <== sep03; */

goprimitive goaddfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                           stack st,gogroup grp);

    /* Adds a graphic primitive that represents a fourangle compoded of lines
    with apices
    p1, p2, p3 and p4, to the stack st. The containing group of the primitive
    is set to grp.
    $A Igor <== sep03; */

goprimitive goaddfillfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                           stack st,gogroup grp);
    /* Adds a graphic primitive that represents a filled fourangle  with apices
    p1, p2 and p3 and p4, to the stack st. The containing group of the
    primitive is set to grp.
    $A Igor <== sep03; */

goprimitive goaddbordfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                           stack st,gogroup grp);
    /* Adds a graphic primitive that represents a filled and bordered fourangle
    with apices p1, p2 and p3 and p4, to the stack st. The containing group of
    the primitive is set to grp.
    $A Igor <== sep03; */

goprimitive goaddpartbordfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                         char b1,char b2, char b3,char b4,stack st,gogroup grp);
    /* Adds a graphic primitive that represents a filled and partially
    bordered fourangle  with apices p1, p2, p3 and p4, to the stack st. b1, b2,
    b3 and b4 indicate whether the corresponding border lines will be drawn
    (they are copied to a string of characters (...)->props3, if at least one
    of them is differentthan 0, otherwise (...)->props3 remains NULL.
    $A Igor <== sep03; */

goprimitive goaddmarker(coord3d p1,double size,int kind,stack st,gogroup grp);
    /* Adds a graphic primitive that represents a marker at co-ordinates p1,
    to the stack st. size is the requested size and kind the requested type
    of the marker.
    $A Igor <== sep03; */


goprimitive goaddtext(char *str,coord3d p1,stack st,gogroup grp);
    /* Adds a graphic primitive that represents a text string str at
    co-ordinates p2, to the stack st. The containing grou of the primitive is
    set to grp.
    $A Igor <== sep03; */


void goloadtostack(gogroup gg,stack st);
    /* Loads the graphic object or group of graphic objects pointed to by gg,
    to the stack st. All primitives that are on the stacks  gg->primitives
    of gg and all its sub-trees are loaded to st.
    $A Igor <== sep03; */









#endif    /* (not defined) INCLUDED_sg_obj */



