
      /* OPTIMIZATION - BASIC DEFINITIONS */



/* Code that prevents double inclusion (and thus makes possible inclusion of
this header in other headers):  */

#ifndef INCLUDED_optbas
#define INCLUDED_optbas


/* Code that insures inclusion of necessary headers: */
#ifndef INCLUDED_st
 #include <st.h>
#endif
#ifndef INCLUDED_vec
 #include <vec.h>
#endif
#ifndef INCLUDED_mat
 #include <mat.h>
#endif
#ifndef INCLUDED_rand
 #include <rand.h>
#endif


     /* TYPE IDENTIFICATION NUMBERS: */

#ifdef HEADER_ID_optbas
  #if HEADER_ID_optbas!=5400
    #error Wrong header ID HEADER_ID_optbas
  #endif
  #undef HEADER_ID_optbas
#endif
#define HEADER_ID_optbas 5400  /* def. of this header ID */

#define IOptlibname   "IOptlib"
#define IOptlibver    0
#define IOptlibsubver 0
#define IOptlibrel    "experimental"
#define IOptlibyear   2005

extern int   IOptlib_ver;
extern int   IOptlib_subver;
extern int   IOptlib_year;
extern char *IOptlib_name;


#define TYPE_analysispoint            HEADER_ID_optbas+1
#define TYPE_vecfuncpoint             HEADER_ID_optbas+2
#define TYPE_linesearchcd             HEADER_ID_optbas+3
#define TYPE_optalgcd                 HEADER_ID_optbas+4
#define TYPE_analysis_to_vecfunc_cd   HEADER_ID_optbas+5
#define TYPE_vecfuncnumgradcd         HEADER_ID_optbas+6
#define TYPE_ancomb                   HEADER_ID_optbas+7
#define TYPE_lintransfdata            HEADER_ID_optbas+8

#define TYPE_analysis_bas_f           HEADER_ID_optbas+20
#define TYPE_vec_bas_f                HEADER_ID_optbas+21
#define TYPE_scal_bas_f               HEADER_ID_optbas+22


      /* TYPE DEFINITIONS FOR ANALYSIS FUNCTIONS: */

  /* STANDARD ANALYSIS FUNCTION: */

typedef 
  int (*analysis_bas_f) (
      vector param,int *calcobj,double **addrobj,
      int *calcconstr,stack *addrconstr,
      int *calcgradobj,vector *addrgradobj,
      int *calcgradconstr,stack *addrgradconstr,void *clientdata);



/* STANDARD VECTOR FUNCTION OF VECTOR ARGUMENT WITH GRADIENT: 
Function is supposed to store the vector value in a vector pointed to by
addrval (provided that addrval!=NULL) and gradient of each componend in the
matrix pointed to by gradaddr (provided that gradaddr!=NULL). clientdata is
an optional pointer to other data that is used for definition or function or
other tasks.
  By convention, calculation of function value is performed when valaddr!=NULL
and calculation of gradients is performed when addrgrad!=NULL. If in such the
function is unable to evaluate any of the requested results, it must set the
corresponding pointer (i.e. *valaddr or *gradaddr) to NULL. If evaluation can
be done and pointers are NULL, the corresponding vstructures (i.e. vector or
matric) must be allocated by the function, and if they are already allocated
but the dimensions are not consistent, the function must re-allocate the
structures.
  In the matrix of gradients (Jacobian matrix), LINES are GRADIENTS of 
individual function.
*/

typedef int (*vec_bas_f) (vector param,int *calcval,vector *addrval,
               int *calcgrad,matrix *addrgrad, void *clientdata);

/* STANDARD SCALAR FUNCTION of scalar variable: */

typedef int (*scal_bas_f) (vector param,int *calcval,double **addrval,
               int *calcgrad,vector *addrgrad, void *clientdata);





/* Analysis (or vector function) point:
  Remarks:
  The meaning of flags that describe whether something has actually been
calculated or not is always critical. An ultimate rule is that the 
corresponding data may be allocated even if the thing it represents has 
actually not been evaluated at given parameters, and it is the corresponding
flag that tells whether something has actually been calculated or not. This
is to avoid the need for excessive allocation and deallocation (e.g. when 
successive calls to evaluation functions are made in such a way that certain
things - e.g. gradients - are alternately calculated or not calculated,
respectively.
  The agreement is that for data that is not calculated at a given stage, no
update action is performed, i.e. the old data is kept untouched and is ignored
during treatement such as copying. The flags, in contrary, must be 
conscientiously set or unset in order to unambiguously indicate whether the
data carries useful information or not.
 */

/* Remark:
  There is a dilemma whether to change type of request flags (such as calcobj,
calcconstr, etc.) on the analysispoint structure and as arguments of analysis
functions (of type analysis_bas_f) to char (instead of int), which would save
some space. Argument for making these flags of type int is that in this case
we can allow registering number of calculations, not only whether something
has been calculated or not. */

typedef struct _analysispoint {
  int type,id;    /* Type and unique ID */
  int which;
  int calcobj,calcgradobj,  /* flags telling what was actually calculated */
    calcconstr,calcgradconstr;
  char
    reqcalcobj,reqcalcgradobj,  /* original calculation requests */
    reqcalcconstr,reqcalcgradconstr;  /* (use is not obligatory) */
  vector param;  /* vector of parameters */
  /* Analysis results: */
  int ret;
  double *obj;
  vector gradobj;
  stack constr,gradconstr;
  void *data;               /* additional data */
  void (*dispdata)(void **);   /* deallocatin of additional data, if NULL
       then data is not deallocated together with the structure!  */
  void *(*copydata)(void *,void **);  /* function for copying data */
} *analysispoint;



  /* DATA STRUCTURE FOR LINE SEARCHES: */

typedef struct _linesearchcd {
  int type,id;    /* Type and unique ID */
  /* Analysis definition: */
  analysis_bas_f anfunc;
  void *ancd;
  void (*dispancd)(void **);
  /* Line search parameters: */
  vector start,     /* starting point */
         direction; /* line search direction */
  /* Current 1D function parameters and results: */
  int calcval,calcder;
  double param,val,der;
  /* Current analysis evaluation point: */
  analysispoint anpt;
  /* Data that enable recording of analysis evaluations when performing the
  line search: */
  int recordan;
  stack anpoints,  /* analyses performed during line search */
        anstore;   /* storage for unused analysis points */
} *linesearchcd;


  /* STANDARD OPTIMIZATION CLIENT DATA STRUCTURE:
This structure is often used for client data in analysis functions.
  The following lax agreements apply:
  In functions that do not need client data for their complete definition, if
client data pointer is anyway passed as argument, it is assumed that it is of
this type and vasic information is stored in it. Some functions that call
analysis may expect such behavior, and this is normally tested by checking
whether (...)->nparam>0.
  In functions that do need client data for their complete definition, and
which do take client data of this type: if such functions are called without
instructions to calculate anything then they would also store basic information
on the client data structure. Some of these functions would check the
correctness of information on the client data structure when they are instructed
to calculate something.
  This structure is also suitable for adapting or supplementing analysis
functions, e.g. for converting analysis functions of different types 


 */


typedef struct _optalgcd {
  int type,id;    /* Type and unique ID */
  int lock;       /* Thread lock */
  /* Data used by wrapping functions to call original functions: */
  char *funcname,      /* name of the original function */
       *callername,    /* name of the calling function */
       *name;          /* name of the problem */
  analysis_bas_f anfunc;  /* original analysis function */
  void *ancd,            /* original client data */
       *supdata;       /* eventual supplementary data (rarely used) */
  void (*dispancd)(void **); /* function for deletio of client data (...)->ancd  */
  void (*dispsupdata)(void **); /* function for deletio of supplementary data */
  vector lastparam;    /* last vector of parameters for which function was
    called */
  /* Analysis data: */
  int calcobj,calcconstr,calcgradobj,calcgradconstr;  /* instruction flags */
  double *obj;
  vector gradobj;
  stack constr,gradconstr;
  int anprintlevel;  /* printlevel for analysis. */
  FILE *outfile;  /* Eventual output file for printing results. */
  /* Optimization results: */
  int numan;
  vector paramopt;
  double *objopt;
  vector gradobjopt;
  stack constropt,gradconstropt;
  /* Function for analysis and printing results at given param.: */
  void (*fprintan) (FILE *fp,struct _optalgcd *cd,vector param,
                       int printlevel);
  /* Function for generating a random starting guess: */
  void (*genrandpar) (struct _optalgcd *cd,vector *addrparam,randgengen rg,
                      double sizefactor,double distfactor);
  /* Crucial algorithm data; when there are relations between data (e.g. number
  of constraits equals the sum of numbers of equality and inequality constrints)
  the number that is more often 0 is included in the structure (e.g. linear
  inequality constraints, since this is usually 0): */
  int nparam,   /* number of parameters */
      nobj,     /* number of objective functions */
      nobjlin,  /* number of linear objective functions */
      nconstr,  /* number of constraint functions */
      nconstreq,  /* number of equality constraints */
      nconstrineqlin,  /* number of linear inequality constraints */
      nconstreqlin,  /* number of linear equality constraints */
      nongrad;       /* If 1 then no gradient data is provided by analysis */
  vector lowbounds,upbounds;    /* Upper and lower bounds */
  /* Non-standard arrays used by algorithm functions: */
  double *bl, *bu,  /* lower & upper boundary */
    *x,             /* parameters */
    *f, *g,         /* objective and constraint values */
    *lambda;        /* lagrange multipliers */
} *optalgcd;


    /* EVALUATION POINT FOR A VECTOR FUNCTION OF VECTOR ARGUMENT  of type
    vec_bas_f : */

typedef struct _vecfuncpoint {
  int type,id;    /* Type and unique ID */
  int calcval,calcgrad;   /* flags telling what was actually calculated */
  int ret;      /* return value */
  vector param; /* parameters of evaluation */
  vector val;   /* vector value */
  matrix grad;  /* matrix of gradients (lines are gradients of comp. of val */
  void *data;              /* additional data */
  void (*dispdata) (void **);   /* deallocatin of additional data, if NULL
       then data is not deallocated together with the structure! */
} *vecfuncpoint;



  /* CONVERSION BETWEEN STANDARD ANALYSIS FUNCTION AND VECTOR FUNCTION:
  Convention is that all data put on this structure may be deallocated at any
time. However, various types of client data may only be deallocated if the
corresponding pointer to deallocation function is not NULL, otherwise these
must not be deallocated because this will be done in the calling environment.
 */


typedef struct _analysis_to_vecfunc_cd {
  int type,id;    /* Type and unique ID */
  int numparam,numobj,numconstr,numval;
  vector param;   /* Vector of parameters */
  int calcobj;    /* beginning of data for analysis function: */
  double *obj;
  int calcconstr;
  stack constr;
  int calcgradobj;
  vector gradobj;
  int calcgradconstr;
  stack gradconstr;
  int anret;    /* end of data for analysis function */
  int calcval;
  vector vecval;  /* beginning of data for vector function */
  int calcgrad;
  matrix vecgrad;
  int vecret;     /* end of data for vector function */
  /* Data for performing analyses: */
  analysis_bas_f anfunc;
  void *ancd;
  void (*dispancd)(void **);
  int anblockgrad;  /* inhibit gradient calculation by anfunc */
  /* Data for evaluating vector function: */
  vec_bas_f vecfunc;
  void *veccd;
  void (*dispveccd)(void **);
  int vecblockgrad;    /* inhibit gradient calculation by vecfunc */
  /* Auxiliary data for additional operations such as line search or
  numerical differentiation: */
  int recordan;
  int recordvec;
  stack anpoints;
  stack anstore;  /* storage for unused analysis points */
  /* void (*dispanpoint) (void **); */
  stack vecpoints;
  stack vecstore;  /* storage for unused vec. func. points */
  /* Auxiliary points for intermediate results: */
  analysispoint auxanpt;
  vecfuncpoint  auxvecpt;
} *analysis_to_vecfunc_cd;




  /* AUXILIARY STRUCTURE FOR NUMERICAL GRADIENT CALCULATION:
This structure supplements the structure of the type optalgcd for use in the
functions that convert functins of type analysis_bas_f that do not calculate
gradients to funcctions of the same type that do. */

typedef struct _vecfuncnumgradcd {
  int type,id;     /* Type and unique ID */
  int backdif,     /* backward difference flag */
      quadratic,   /* quadratic (central difference) flag */
      noforcenum;  /* don't force numerical (if !=0 then analytical gradients
        are taken if possible */
  double step;   /* perturbation step (if >0) */
  vector vstep;  /* pert. steps in all directions (if !=NULL) */
  vec_bas_f vecfunc;  /* evaluation of vector function */
  void *veccd;   /* definition data for vecfunc */
  void (*dispveccd) (void **);  /* for deallocation o fveccd, if NULL then veccd
            is not deallocated with the structure */
  int recordvec;  /* instructs to record evaluation results */
  stack points, /* stack of perturbed points; Agreement: the first point on
      this stack is always the unperturbed point! */
        storepoints;  /* storage for unused points */
  int notdisppoints; /* if !=0 then stacks auxpoints and storepoints may not
      be deallocated with the structure (external storage). CONSIDER whether
      this is necessary!! */
} *vecfuncnumgradcd;


  /* FLAGS DEFINING HOW ANALYSIS RESPONSE FUNCTIONS ARE COMBINED (each analysis
function has a correspondent flag): */

/* Objective function summed to combined objective function: */
#define ANCOMB_SUMOBJ            0x1  
/* Constraint functions summed to combined constraints: */
#define ANCOMB_SUMCONSTR         0x2  
/* Objective func. summed to combined constraint functions: */
#define ANCOMB_SUMOBJTOCONSTR    0x4
/* Constraint functions summed to combined objective function */
#define ANCOMB_SUMCONSTRTOOBJ    0x8
/* Constraint functions added to constraint functions of combined problem: */
#define ANCOMB_ADDCONSTR         0x10
/* Objective function added to objective functions of combined problem: */
#define ANCOMB_ADDOBJTOCONSTR    0x20

/* Summation of penalty terms obtained as various penalty function of the
constraint function values (for exact definition of penalty functions, see 
the auxiliary function ancombpenalty() in optbas.c): */
/* Constraint functions summed as square penalty terms to the objective function: */
#define ANCOMB_PENALTYSQR        0x40
/* Constraint functions summed as half square (asymmetric) penalty terms to 
the objective function: */
#define ANCOMB_PENALTYSQRHALF    0x80
/* Constraint functions summed as adaptive (asymmetric) penalty terms to 
the objective function: */
#define ANCOMB_PENALTYADAPT      0x100
/* Constraint functions summed as exponential  penalty terms to 
the objective function: */
#define ANCOMB_PENALTYEXP        0x200
/* Constraint functions summed as half fourth power penalty terms to 
combined objective function: */
#define ANCOMB_PENALTYPOW4HALF   0x400
/* Constraint functions summed as adaptive (asymmetric) fourth power 
penalty terms to combined objective function: */
#define ANCOMB_PENALTYADAPT4     0x800

#define ANCOMB_PENALTY (ANCOMB_PENALTYSQR | ANCOMB_PENALTYSQRHALF |  \
        ANCOMB_PENALTYADAPT | ANCOMB_PENALTYEXP |  \
        ANCOMB_PENALTYPOW4HALF | ANCOMB_PENALTYADAPT4 )
/*
#define ANCOMB_DEFAULT ANCOMB_SUMOBJ | ANCOMB_ADDCONSTR 
*/

/* Masks for deciding what must be calculated, define which response of 
individual problems affects which response in the combined problem (these
definitions are normally not needed by the user, but are necessary for
function of combinedanalysis);
  NOTE: when adding new flags above, they must be arranged between the masks
below, wach flag is added to exactly one mask! */

/* Objective function affects combined objective function: */
#define ANCOMB_OBJ_TO_OBJ     (ANCOMB_SUMOBJ)
/* Objective function affect combined constraint functions: */
#define ANCOMB_OBJ_TO_CONSTR  (ANCOMB_ADDOBJTOCONSTR | ANCOMB_SUMOBJTOCONSTR)
/* Constraint functions affect combined objective function: */
#define ANCOMB_CONSTR_TO_OBJ  (ANCOMB_SUMCONSTRTOOBJ | ANCOMB_PENALTY)
/* Constrainr functions affect combined constraint functions: */
#define ANCOMB_CONSTR_TO_CONSTR  (ANCOMB_ADDCONSTR | ANCOMB_SUMCONSTR)



/* Structure that defines how analysis response is combined to form a new
response: */

typedef struct _ancomb {
    int type,id;     /* type and unique object ID */
    int flags;       /* flags defining how response functions are combined */
    double shift,
           factor,   /* shift & weighting factor of objective values */
      constrshift,   /* shift for constraint functions */
      constrfactor,  /* weight. factor for constraints (if 0 then factor is taken) */
      dpen,hpen;     /* penalty parameters */
    int nparam,nobj,nconstr;
    analysispoint anpt;    /* storage of analysis results */
    analysis_bas_f anfunc;  /* analysis function */
    void *andata;   /* analysis definition data */
    void (*dispandata) (void **);  /* for de-allocation of andata */ 
    vector auxvec;  /* auxiliary vector */
} *ancomb;



    /* LINEAR TRANSFORM DATA */


typedef struct _lintransfdata {
  int type,id;     /* type and unique object ID */
  int lock;   /* object locking support (to synchronize access in threads) */
  vector center;   /* Center of transformed co-ordinates */
  double *a_scal;  /* multiplicative factor for transf. matrix */
  matrix A;   /* transformation matrix */
  vector a;   /* components od diagonal transformation matrix */
  vector dA;  /* components are eigenvalues of a */
  matrix UA;  /* columns are eigenvectors of A */
  matrix Ainv; /* Inverse of A */
  matrix Q;   /* coefficients of quadratic form */
  vector q;   /* coefficients of pure quadratic form (Q diagonal) */
  vector dQ;  /* coefficients are eigenvalues of Q */
  matrix UQ;  /* columns are eigenvectors of Q */
  /*
  vector  /* auxiliary vec. of transformed vectors *
    vecaux;
  matrix  /* auxiliary storage for transformed matrices *
    mataux;
  */
  /* Function definition that enables direct use fo transform for
  composition of functions: */
  int functype;
  void *func;
  void *funcdata;
  void (*dispfuncdata) (void **);
  double *val;    /* used when func==NULL */
  vector gradval; /* used when func==NULL */

  /* Auxiliary storage of matrices & vectors: */
  stack matstore;
  stack vecstore;
} *lintransfdata;





          /******************************************/
          /*                                        */
          /*  LINEAR PARAMETER TRANSFORM UTILITIES  */
          /*                                        */
          /******************************************/






          /*********************************************/
          /*                                           */
          /*  ANALYSIS EVALUATION POINT DATA HANDLING  */
          /*                                           */
          /*********************************************/


analysispoint newanalysispoint(void);
    /* Allocates a new structure for containing analysis point data and 
    returns a pointer to this structure.
    $A Igor feb05; */

analysispoint newanalysispointr(int nparam,int nconstr,int grad);
    /* Allocates a new structure for containing analysis point data with 
    allocated space for data and returns a pointer to this structure.
      nparam is the number of parameters, nconstr is the number of constraints
    and grad specifies whether storage for gradients is allocated or not. The
    function allocates space for parameter vector, values of the objective
    and constraint functions, and if grad!=0, also for gradients of the
    objective and constraint functions.
      If nparam==0 then space for parameter vector and gradients is not
    allocated. If nconstr==0 then space for constraints and their gradients
    is not allocated.
    $A Igor feb05; */

void dispanalysispoint(analysispoint *addrpt);
    /* Deallocates the structure pointed to by *addrpt and sets *addrpt to NULL.
    $A Igor feb05; */

analysispoint copyanalysispoint(analysispoint pt1,analysispoint *addrpt2);
    /* Copies analysis evaluation point pt1 to *addrpt2 (if addrpt2 is not 
    NULL) and returns *addrpt2, or (if addrpt2 is NULL) just returns a
    dynamically allocated copy of pt1.
    $A Igor apr05; */

    /* Printing utilities for analysis points: */

void fprintanptparamlist(FILE *fp,analysispoint anpt);
    /* Prints vlaue of anpt->obj without spaces or newlines. Output is to file
    fp.
    $A Igor apr05; */

void fprintanptobjlist(FILE *fp,analysispoint anpt);
    /* Prints vlaue of anpt->obj without spaces or newlines. If anpt==NULL,
    anpt->obj==NULL or anpt->calcobj==0 then "NULL" is printed. Output is to 
    the file fp.
    $A Igor apr05; */

void fprintanptconstrlist(FILE *fp,analysispoint anpt);
    /* Prints vlaues of anpt->constr in list form (comma separated in curly
    brackets). If anpt==NULL, anpt->constr==NULL or anpt->calcconstr==0 then 
    "NULL" is printed. Output is to file fp.
    $A Igor apr05; */

void fprintanptgradobjlist(FILE *fp,analysispoint anpt);
    /* Prints vlaue of anpt->gradobj without spaces or newlines. If anpt==NULL,
    anpt->gradobj==NULL or anpt->calcgradobj==0 then "NULL" is printed. Output 
    is to  the file fp.
    $A Igor apr05; */

void fprintanptgradconstrlist(FILE *fp,analysispoint anpt);
    /* Prints vlaues of anpt->gradconstr in list form (comma separated in curly
    brackets). If anpt==NULL, anpt->gradconstr==NULL or anpt->calcgradconstr==0
    then "NULL" is printed. Output is to file fp.
    $A Igor apr05; */

void fprintanptlist(FILE *fp,analysispoint anpt);
    /* Prints all analysis results on anpt in list form, first anpt->param,
    then anpt->obj, anpt->constr, anpt->gradobj and anpt->gradconstr.
     Output is to file fp.
    $A Igor apr05; */

void fprintanalysispointlist(FILE *fp,analysispoint anpt);
    /* Prints all analysis results on anpt in list form, first anpt->param,
    then anpt->obj, anpt->constr, anpt->gradobj and anpt->gradconstr.
     Output is to the standard output.
    $A Igor apr05; */

void printanalysispointlist(analysispoint anpt);
    /* Prints all analysis results on anpt in list form, first anpt->param,
    then anpt->obj, anpt->constr, anpt->gradobj and anpt->gradconstr.
     Output is to the standard output.
    $A Igor apr05; */

void fprintanalysispoint(FILE *fp,analysispoint anpt);
    /* Prints contents of anpt in longer and more readable form to fp.
    $A Igor apr05; */

void printanalysispoint(analysispoint anpt);
    /* Prints contents of anpt in longer and more readable form to standard
    output.
    $A Igor apr05; */



    /* COPY ANALYSIS RESULTS */



void copyanfuncrestopointplain0(int ret,vector param,int calcobj,double *obj,
      int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr,  analysispoint anpt);
    /* Copies analysis results to a structure of type analysispoint anpt. ret
    is analysis return value while other results aree arguments of the analysis
    function.
      Analysis results are typically generated by a functioin of type 
    analysis_bas_f, and meaning of function arguments is corresponding.
      flags calcobj,calcconstr,calcgradobj and calcgradconstr tell whether
    the objective function, constraints, gradient fo objective and gradients
    of constraints were calculated. If these flags are 0 then corresponding
    values are not copied to anpt and the corresponding members on anpt are
    not touched (i.e. dimension is not adjusted and values are not deleted).
    $A Igor apr05 jul05; */

analysispoint copyanfuncrestopoint0(int res,vector param,int calcobj,
      double *obj,int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr,  analysispoint *addranpt);
    /* Copies analysis results to a structure of type analysispoint and
    returns the pointer of the structure.  ret is analysis return value while 
    other results aree arguments of the analysis function.
      For copying, see copyanfuncrestopointplain0() which does the job.
      If addranpt!=NULL then data is copied to *addranpt (which is allocated
    if necessary) and *addranpt is returned. Otherwise a new structure is
    allocated for copying and its pointer returned.
      In contrary to copyanfuncrestopoint, this funciton does not addresses of
    result storage, but result themselves. Otherwise, functions operate in the
    same way.
    $A Igor apr05 jul05; */

analysispoint copyanfuncrestopoint(int res,vector param,int *addrcalcobj,
      double **addrobj,int *addrcalcconstr,stack *addrconstr,  
      int *addrcalcgradobj,vector *addrgradobj,
      int *addrcalcgradconstr,stack *addrgradconstr,  analysispoint *addranpt);
    /* Copies analysis results to a structure of type analysispoint and
    returns the pointer of the structure.  res is analysis return value while 
    other arguments are results of the analysis function and addranpt is the
    address of the storage where results are copied to.
      For copying, see copyanfuncrestopointplain0() which does the job.
      If addranpt!=NULL then data is copied to *addranpt (which is allocated
    if necessary) and *addranpt is returned. Otherwise a new structure is
    allocated for copying and its pointer returned.
    $A Igor jul05; */



int copypointtoanfuncargs(analysispoint anpt,int *calcobj,double **addrobj,
          int *calcconstr,stack *addrconstr,
          int *calcgradobj,vector *addrgradobj,
          int *calcgradconstr,stack *addrgradconstr);
    /* Copies analysis results from analysis point to arguments of the
    analysis function. Only those results are copied that are requested by
    the request flag pointers and tehir evaluation is at the same time 
    indicated by flags on anpt.
    Function returns anpt->ret.
    $A Igor jul05; */






              /*************************/
              /*                       */
              /*  LINE SEARCH SUPPORT  */
              /*                       */
              /*************************/

linesearchcd newlinesearchcd(void);
    /* Creates a data structure for deifning the line search of type
    linesearchcd and returns its pointer.
    $A Igor apr05; */

void displinesearchcd(linesearchcd *addrcd);
    /* Deallocates the structure pointed to by *addrcd and sets *addrcd to
    NULL.
    $A Igor apr05; */

double linesearchcalcparam(linesearchcd cd,vector paramvec,vector *addraux,
                           double *distfact);
    /* Returns the line search paremeter that yields the point closest to
    paramvec.
      cd defines the line search (only the starting point cd->start and 
    direction cd->direction are used).
      paramvec is the vector of parameters for which line search parameter
    is requested (or l.s. parameter that yields its closest point on the
    line of the search).
      addraux is address of an auxiliary vector whose dimension should ideally
    match the dimension of paramvec. It can be NULL, in tihs case an auxiliary
    vector to support calculation is allocated and deallocated internally.
      distfact - if it is not NULL then the tangens of angle between the search
    direction and the difference between paramvec and cd->start (i.e. the
    starting point of the line search) is calculated and stored in *distfact.
    This is a measure of distance between paramvec and the search line.
    $A Igor apr05; */

vector linesearchcalcparamvec(linesearchcd cd,double param,
                              vector *addrparamvec);
    /* Calculates parameter vector at line search parameter param with
    linesearch data contained in cd, and returns it. If addrvecparam!=NULL
    then calculated parameters are stored in *addrvecparam, which is allocated
    or reallocated when necessary.
      Function does not change anything on cd.
    $A Igor apr05; */

int linesearchfuncmin(double param,int *calcval,double *val,int *calcder,
       double *der,linesearchcd cd);
    /* Evaluation of function and its derivative in the line search (no
    constraints).
    $A Igor apr05; */

double linesearchcalcder(linesearchcd cd,vector gradobj);
    /* Calculate the derivative of the line search function if gradient of the
    onderlying vector function is gradobj.
      cd contains data of the line search, of which only search direction is
    needed.
    $A Igor apr05; */

linesearchcd preplinesearch(analysis_bas_f anfunc,void *ancd,
         void (*dispancd) (void**),
         vector start,vector direction,
         void **addrfunc,
         linesearchcd *addrcd,
         void (**addrdispcd)(void **) );
    /* Prepares data for numerical search.
    $A Igor apr05; */




          /****************************************************/
          /*                                                  */
          /*  VECTOR FUNCTION EVALUATION POINT DATA HANDLING  */
          /*                                                  */
          /****************************************************/


vecfuncpoint newvecfuncpoint(void);
    /* Allocates a new structure for containing vector function point data 
    (i.e. results of the function at a given parameter vector) and returns a 
    pointer to this structure.
    $A Igor apr05; */

vecfuncpoint newvecfuncpointr(int nparam,int nval,int grad);
    /* Allocates a new structure for containing analysis point data with 
    allocated space for data and returns a pointer to this structure.
      nparam is the number of parameters, nval is the number of values (i.e.
    dimension of the range of the function) and grad specifies whether storage
    for gradients is allocated or not. 
      The function allocates space for parameter vector, vector value of the 
    function, and if grad!=0, also for gradient matrix.
      If nparam==0 then space for parameter vector and gradients is not
    allocated.
    $A Igor apr05; */

void dispvecfuncpoint(vecfuncpoint *addrpt);
    /* Deallocates the structure pointed to by *addrpt and sets *addrpt to NULL.
    $A Igor apr05; */


    /* Printing utilities for vector function evaluation point: */


void fprintvecfuncpointlist(FILE *fp,vecfuncpoint pt);
    /* Prints all vector function results on pt in list form, first anpt->param,
    then anpt->val, and finally anpt->grad.
     Output is to file fp.
    $A Igor apr05; */

void printvecfuncpointlist(FILE *fp,vecfuncpoint pt);
    /* Prints all vector function results on pt in list form, first pt->param,
    then pt->val, and finally pt->grad.
     Output is to standard output.
    $A Igor apr05; */

void fprintvecfuncpoint(FILE *fp,vecfuncpoint pt);
    /* Prints contents of pt in longer and more readable form to fp.
    $A Igor apr05; */

void printvecfuncpoint(vecfuncpoint pt);
    /* Prints contents of pt in longer and more readable form to standard
    output.
    $A Igor apr05; */



    /* COPY VEC. FUNC. RESULTS */


void copyvecfuncrestopointplain(vector param,int calcval,vector val,
      int calcgrad,matrix grad,vecfuncpoint pt);
    /* Copies vector function results to the structure pt of type vecfuncpoint. 
      These results are typically generated by a functioin of type 
    vec_bas_f, and meaning of function arguments is corresponding.
      flags calcval and calcgrad tell whether the vector function values and/or 
    gradients have actually been calculated. If some flags are 0 then the
    corresponding data are not copied to pt and the corresponding members on
    pt are kept untouched (i.e. dimension is not adjusted and values are not 
    deleted), even if they eventually contain data previously set.
    $A Igor apr05; */

vecfuncpoint copyvecfuncrestopoint(vector param,int calcval,vector val,
      int calcgrad,matrix grad,  vecfuncpoint *addrpt);
    /* Copies vector function results to a structure of type vecfuncpoint and
    returns the pointer of the structure. 
      For copying, see copyvecfuncrestopointplain() which does the job.
      If addrpt!=NULL then data is copied to *addrpt (which is allocated
    if necessary) and *addrpt is returned. Otherwise a new structure is
    allocated for copying and its pointer returned.
    $A Igor apr05; */




          /*******************************************/
          /*                                         */
          /*  ANALYSIS <-> VEC. FUNCTION CONVERSION  */
          /*                                         */
          /*******************************************/


analysis_to_vecfunc_cd newanalysis_to_vecfunc_cd(void);
    /* Creates a new structure of type analysis_to_vecfunc_cd and returns its
    pointer.
    $A Igor apr05; */

void dispanalysis_to_vecfunc_cd(analysis_to_vecfunc_cd *addrcd);
    /* Deallocates the structure of type analysis_to_vecfunc_cd pointed to by
    *addrcd and sets *addrcd to NULL.
    $A Igor apr05; */

int vecfunc_froman(vector param,int *calcval,vector *addrval,
                     int *calcgrad,matrix *addrgrad,
                     analysis_to_vecfunc_cd cd);
    /* Vector function of vector variable of type vec_bas_f, which is derived
    from the standard analysis function of type analysis_bas_f.
      cd must be a pointer to structure of type analysis_to_vecfunc_cd,
    which has been constructed from a given analysis function and its client
    data by the function prepvecfunc_froman (or in some similar way,
    but this method should normally be used).
      Convention: Gradients are stored *addrgrad by rows. 
    $A Igor feb05; */

int anfunc_fromvec(vector param,int *calcobj,double **addrobj,
          int *calcconstr,stack *addrconstr,
          int *calcgradobj,vector *addrgradobj,
          int *calcgradconstr,stack *addrgradconstr,
          analysis_to_vecfunc_cd cd);
    /* Analysis function that is based on a vector function of vector argument
    of type vec_bas_f, which is called for calculating the objective and /or 
    constraint functions and eventually their gradients. 
      The vector function that does the job is cd->vecfunc and its definition 
    data is cd->veccd. Auxilliary data structures on cdsuch as buffers for 
    intermediate results storage are also used.
      Vector function must be of type vec_bas_f, which is equivalent to
    int (*) (vector,int *,vector *,int *,matrix *, void *).
      Most commonly, the first value of vector function result will represent
    the objective function and subsequent values will represent constraint
    functions. This may be changed by cd->numobj and cd->numconstr to determine
    the number of objective and constraint functions.
      This function is of type analysis_bas_f.
    $A Igor apr05; */

void convert_analysis_to_vecfunc(analysis_bas_f analysis,void *analysiscd,
        void (*dispanalysiscd)(void **),int recordan,int recordvecfunc,
        vec_bas_f *addrfunc,analysis_to_vecfunc_cd *addrcd,
        void (*dispcd)(void **) );
    /* Performs conversion from standard analysis function to vector function
    of vector variable.
    $A Igor feb05; */



        /******************************************/
        /*                                        */
        /*  NUMERICAL DERIVATION OF VECTOR FUNC.  */
        /*                                        */
        /******************************************/


vecfuncnumgradcd newvecfuncnumgradcd(void);
  /* Allocates space for structure of type numgradcd and returns its pointer.
  $A Igor apr05; */

void dispvecfuncnumgradcd(vecfuncnumgradcd *addrnumgradcd);
    /* Deallocates the structure pointed to by *addr and sets *addr to NULL.
    $A Igor nov04; */

int vecfuncnumgrad(vector param,int *calcval,vector *addrval,
                     int *calcgrad,matrix *addrgrad,
                     vecfuncnumgradcd cd);
    /* Vector function of vector variable of type vec_bas_f, which is calculate
    the gradients numerically. All data for gradient calculation are on 
    from the standard analysis function of type analysis_bas_f.
      clientdata must be a pointer to structure of type analysis_to_vecfunc_cd,
    which has been constructed from a given analysis function and its client
    data by the function convert_analysis_to_vecfunc (or in some similar way,
    but this method should normally be used).
      This function is of type vec_bas_f.
    $A Igor feb05; */

analysis_to_vecfunc_cd prepanfuncnumgrad(analysis_bas_f anfunc,void *ancd,
           void (*dispancd) (void**),
         double step,vector vstep,
         int backdif,int quadratic,int noforcenum,
         analysis_bas_f *addrfunc,
         analysis_to_vecfunc_cd *addrcd,
         void (**addrdispcd)(void **) );
    /* Prepares data for numerical derivation of an analysis function. 
      anfunc - original analysis function whose results will be numerically
    differentiated. 
      anfunccd - data for anfunc
      dispancd - function for deallocation of anfunccd. If it is not NULL then
    this function will be used for deallocation of data ancd when the 
    constructed data structure for numerical differentiation (stored in *
    addrcd) is deallocated. If it is NULL then this structure is not 
    deallocated together with data structure for numerical differentiation.
      step - step used for numericall differentiation. If different than 0
    then the same step is used for all variables.
      vstep - vector of steps for numerical differentiation. If it is NULL then
    step will be used for all variables. If it is not NULL but some components
    are 0 then step will be used instead of these components. A copy of vstep
    is put on the structure, therefore original vstep should be deallocated 
    after it is ceased to be used.
      addrfunc - address of storage for pointer to analysis function that
    performs analysis with numerical differentiation
      addrcd - address of storage for definition data for analysis function 
    with numerical  calculation of gradients. It may be NULL or it may point 
    to a  non-NULL pointer fo the correct type, which is already allocated. 
    The function also returns the pointer of the definition data structure. 
      addrdispcd - address for storing pointer to function for deallocation of
    data structure for numerical differentiation (stored at addrcd).
      addrfunc and addrdispcd can be NULL if the caller knows which function 
    should be used as a new anlysis function that performs numerical 
    differentiation of the original and which should be used for deallocation
    of the created data structure. These are ment especially when the caller
    does not now enough about the functio of numerical differentiation and 
    wants to store the data and corresponding deallocation function simply to
    a pointer of type void *.
      The function constructructs a data structure for numerical
    differentiation of analysis results and sets *addrcd so that it points to
    tihs structure. Original analysis function anfunc and its definition data
    is put on the structure as well as data that defines how differntiation
    is performed. If analysis definition data will not be kept somewhere else,
    then dispancd can be specified to be used for deallocation of ancd when 
    the complete data for numerical differentiation is deallocated.
    $A Igor apr05; */









          /********************************/
          /*                              */
          /*  OPTIMIZATION DATA HANDLING  */
          /*                              */
          /********************************/


optalgcd newoptalgcd(void);
    /* Creates and returns an object of type optalgcd. anf and clientdata are
    the analysis function and client data passed to optimization algorithm.
    $A Igor oct 04; */

void dispoptalgcd(optalgcd *addrcd);
    /* Deallocates the space pointed to by *addrcd of type optalgcd and sets
    *addrcd to NULL.
    $A Igor nov04; */







          /******************************************/
          /*                                        */
          /*  BASIC SUPPORT FOR ANALYSIS FUNCTIONS  */
          /*                                        */
          /******************************************/



   /* PRINTING OF ANALYSIS RESULTS: */
  

void fprintanfuncres0(FILE *fp,vector param,double *obj,stack constr,
                     vector gradobj,stack gradconstr);
    /* Prints the results of optimization analysis to file fp. It just prints 
    the contents of arguments and does not care whether something was 
    calculated or not.
    $A Igor mar05; */

void printanfuncres0(vector param,double *obj,stack constr,
                     vector gradobj,stack gradconstr);
    /* Prints the results of optimization analysis to standard output by calling
    fprintanfuncres0().
    $A Igor mar05; */

void fprintanfuncres(FILE *fp,vector param,int calcobj,double *obj,
      int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr);
    /* Prints analysis results (usually obtained by calling a function of 
    type analysis_bas_f) to the file fp. Arguments after fp correspond to
    arguments whose addresses are passed as output arguments of the call of 
    the analysis function.
    $A Igor apr05; */

void printanfuncres(vector param,int calcobj,double *obj,
      int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr);
    /* Prints analysis results to the standard output by use of 
    fprintanfuncres().
    $A Igor apr05; */

void fprintanfuncreslist(FILE *fp,vector param,int calcobj,double *obj,
      int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr);
    /* Prints analysis results (usually obtained by calling a function of 
    type analysis_bas_f) to the file fp in a LIST form (comma separated lists
    of values in curly brackets).
    Arguments after fp correspond to arguments whose addresses are passed as
    output arguments of the call of the analysis function.
    $A Igor apr05; */

void printanfuncreslist(vector param,int calcobj,double *obj,
      int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr);
    /* Prints analysis results to the standard output by use of 
    fprintanfuncreslist().
    $A Igor apr05; */



    /* PREPARATION & MEMORY HANDLING */


int prepanfuncbas(vector param,int *calcobj,double **addrobj,
      int *calcconstr,stack *addrconstr,
      int *calcgradobj,vector *addrgradobj,
      int *calcgradconstr,stack *addrgradconstr,void *clientdata,
      int nparam,int nobj,int nconstr,int derobj,int derconstr,
      char *funcname,char *filename,int fileline);
    /* Prepares storage for analysis function for optimization problems of the
    type analysis_bas_f, reports errors in input data or returns information
    about optimization problem.
      First parameters correspond to parameters of the analysis function, while
    the rest are the following:
      nparam: number of parameters; should be 0 if the optimization problem 
    (and the corrresponding analysis function) is defined for different numbers
    of parameters.
      nobj: must be 1 if analysis defines an objective function or 0 if it does
        not.
      nconstr: number of constraints
      derobj: If 0 then function can not calculate gradient of the objective
    function, otherwise it can
      derconstr: If 0 then function can not calculate gradient of constraint
    functions, otherwise it can.
      funcname: name of the calling function
      filename: name of the file where function was called
      fileline: line number of the function call.

      INFO mode:
      If calcobj==calcconstr==calcgradobj==calcgradconstr == NULL then
    analysis should not be performed, but problem basic information should be
    returned instead (i.e. number of parameters & constraints). The information
    is actually provided by reallocation other arguments: if no objective
    function is defined, *addrobj is deallocated, otherwise it is allocated,
    gradient of objective function *gradobj is allocated with the dimension of 
    parameter vector, and *addrconstr and *addrgradconstr are also allocated
    or re-allocated with appropriate dimensions.
      Aagreements (info mode)
      If some analysis function does not support the info mode, then  it will
    not perform any allocation or re-allocation in this mode, which can be used
    for testing whether info mode is supported or not (call with all storage
    pointers set to NULL - but addresses of storage not NULL - and if info mode
    is not supported then no allocation will be performed.
      When analysis has a fixed number of parameters that is different from the
    dimension of the parameter vector passed, the function will allocate
    gradient information even if it actually does not calculate gradients, to
    pass the actual number of parameters supported (also error or warning
    report will be launched in this case). The same applies when the number of
    parameters is determined by the client data.
      Otherwise, if the function does not calculate gradients, alll gradient
    information will be deallocated in info mode.
      
      Note 
      In info mode, if the problem is not with a fixed number of parameters,
    then the function should be called with vector param allocated with 
    appropriate dimension.
      
      
      RETURNS 0 if analysis should continue, a negative error code if there is
    an error (inconsistency) in input arguments, or 1 if function was called in
    info mode.

    How to call within analysis function:
      if (!(ret=prepanfuncbas( ... ,
                 <nparam>,<nobj>,<nconstr>,<derobj>,<derconstr>,<funcname>,
                 __FILE__,__LINE__)))
        {  << analysis function code >>  }
    where ... means arguments of the analysis function, and __FILE__,__LINE__
    must be included literally (since these are pre-defined macros)

    $A Igor nov04; */


int getanfuncinfo(vector param,analysis_bas_f anfunc,void *cd,
        int *nparam,int *nobj,int *nconstr,int *derobj,int *derconstr );
    /* Returns the basic data for the optimization problem defined by analysis
    function anfunc, data cd and with parameters param (which can be NULL for
    problems with fixed number of parameters or number of parameters defined
    by definition data cd).
      Function returns 0 if everything is OK or a negative number in the case 
      of an error. Number of parameters, objectives or constraints is written
    to *nparam, *nobj and *nconstr if the corresponding pointers are not NULL.
    If something can not be determined then -1 is written to the appropriate 
    place. Whether the function can calculate objective and constraint 
    gratients is written to *gradobj and *gradconstr (1 if it can, 0 if not),
    if these pointers are not NULL.
      Uniform gradient availability for objectives and constraints:
      If the pointers derobj and derconstr are the same then the data pointed
    to by these pointers will be set to 1 only if both gradient of the 
    objective function (if defined) and gradients of the constraint functions
    (if defined) can be calculated. In this case, if either objective or 
    constraint functions are not defined in the problem then non-ability of
    providing the correspoinding gradient will not cause to set the flag
    pointed to by both pointers to 0.
      Analysis function must support info mode for this function to work.
      Return codes:
      0  - everything seems to be OK
      -1 - analysis function does not support info mode
      -2 - dimension of param does not match a fixed dimension of the problem
    or dimension determined by problem data cd.
      -3 - number of parameters could not be determined (typically in case
    when param is NULL and problem is defined for variable number of 
    parameters, which can not be determined just form cd. 
    $A Igor apr05; */



    /* TESTING of analysis function */


void inspectanfunc(vector param,int nconstr,int allocate,
                   analysis_bas_f testanfunc,void *clientdata );
    /* Runs the function testanfunc with specification data clientdata at
    parameters param, and outputs the results. nconstr denotes the number of
    constraints while allocate specifies whether the storage should be allocated
    before calling testanfunc or not. The function requires calculation of
    everything, including the gradients.
      Numerical gradients are also compared to analytical (if provided), with 
    step for numerical differentiation 1.0e-6, and other arguments having
    default values.
    $A Igor apr05; */


void inspectanfuncbas(vector param,int nconstr,int allocate,
         double numgradstep, double reldiflimit, double smallnorm,
         analysis_bas_f testanfunc,void *clientdata );
    /* Runs the function testanfunc with specification data clientdata at
    parameters param, and outputs the results. nconstr denotes the number of
    constraints while allocate specifies whether the storage should be allocated
    before calling testanfunc or not. The function requires calculation of
    everything, including the gradients.
      If numgradstep!=NULL then numerical gradients will be calculated and
    compared to analytical gradients if these are provided. In this case,
    reldiflimit is the admissible limit of relative difference in naallytical
    and numerical gradients, and smallnorm is a small number whihc is added to
    the denominator of the expression for relative difference to avoid infinite
    values where gradients are close to zero. If reldiflimit is 0 then
    it is set to 0.005, and if smallnorm is 0 then it is set to 1e-15.
    $A Igor oct04 apr05; */





        /*************************************************/
        /*                                               */
        /*  WRAPPERS FOR PREVENTING SUCCESSIVE REPETION  */
        /*         AND FOR COUNTING ANALYSES             */
        /*                                               */
        /*************************************************/



int setprintlevelanfuncnorepeat(int level);
    /* Sets the printing level of the analysis function that ensures that
    analysis is not successively repeated at the same parameters. If printing
    level is larger than 0, then function reports each time whether repetion 
    is prevented or not. If the level is larger than 1, then parameters are
    also print.
    $A Igor jul05; */

int anfunccountnorepeat(vector param,int *calcobj,double **addrobj,
          int *calcconstr,stack *addrconstr,
          int *calcgradobj,vector *addrgradobj,
          int *calcgradconstr,stack *addrgradconstr,void *cd[4]);
    /* Performs another (original) analysis in such a way that analyses that 
    have been recently performed are not performed again, but the results of 
    the previous run are picked and returned. This works only if the
    analysis is called successively with the same parameters (only results of
    one analysis can be stored).
      cd must be a pointer to an ARRAY OF FOUR POINTERS:
      cd[0]: address of the original analysis function that actually performs
    calculation 
      cd[1]: pointer to definition data for the original analysis 
      cd[2]: pointer to an integer counter, which is incremented each time the
    analysis is performed. The last pointer may be NULL, in this case 
    incrementation is skipped. Counter is incremented only if evaluation must 
    actually be done (not if results of previous run are copied).
      cd[3]: address of dynamically allocated or NULL pointer of type 
    analysispoint. The function will allocate anything necessary, but it is
    the responsibility of the caller to de-allocate data whose address is
    contained in cd[3] by calling dispanalysispoint(cd[3]). If the cd[3]==NULL
    then the mechanism for prevention of successive repetion of analysis is
    not used (since the data can not be stored), and full evaluation is
    performed each time analysis is called.
      This function is of type analysis_bas_f, except for the type of the
    definition data cd. The function is suitable for parallel threads and
    nested calls.
      Remark:
      This function can also be used as analysis function that returns data
    stored in a variable of type analysispoint - just make sure that the the
    analysis point is put into cd[3] and that the same parameters aree passed
    as those of analysis point.
      If you are using one analysis point with this function first for one
    analysis and then for another, it is recommended to set calculation flags
    on analysis point to 0 before using the second analysis (just to make sure
    that response is re-calculated when changing the analysis).
    $A Igor jul05; */

int anfunccountnorepeatsimp(vector param,int *calcobj,double **addrobj,
          int *calcconstr,stack *addrconstr,
          int *calcgradobj,vector *addrgradobj,
          int *calcgradconstr,stack *addrgradconstr,void *cd[3]);
    /* Performs another (original) analysis in such a way that analyses that 
    have been recently performed are not performed again, but the results of 
    the previous analysis are picked and returned. This works only if the
    analysis is called successively with the same parameters (only results of
    one analysis can be stored).
      cd must be a pointer to an array of three pointers, with 0-th pointer
    being the address of the original analysis function taht actually performs
    calculation, 1-th pointer being the definition data for that analysis 
    function and 2-th pointer being a pointer to an integer counter, which is
    incremented each time the analysis is performed. The last pointer may be 
    NULL, in this case incrementation is skipped.
      ATTENTION:
      Such analyses can not be run nestedly (because of use of static data and
    thread locking - nested call would block).
      In multi-threaded environment, there may be efficiency problems when
    this function is successively run by more than one thread at once, since
    there is only one result storage unit and calls in one thread would destroy
    storage data of another one. Such situation would not caues errors, but 
    could cause redundant repetions of analyses at same parameters.
      For better function, cd itself should contain the results storage unit, 
    but in this case one should take care about de-allocation.
    $A Igor jul05; */

int anfunccount(vector param,int *calcobj,double **addrobj,
          int *calcconstr,stack *addrconstr,
          int *calcgradobj,vector *addrgradobj,
          int *calcgradconstr,stack *addrgradconstr,void *cd[3]);
    /* Analysis function used for counting number of analyses (incrementing
    the counter) performed with some other analysis function. Function is of
    type analysis_bas_f.
      cd must be a pointer to an array of three pointers, in which the
      cd[0] is address of original analysis function, 
      cd[1] is the definition  data that must be passed to the original 
    function and 
      cd[1] is a pointer to an integer counter (type int), which is 
    incremented each time the analysis is performed. The last pointer may be 
    NULL, in this case incrementation is skipped. 
    $A Igor jul05; */




        /***********************************************/
        /*                                             */
        /*  COMBINING RESPONSE FROM SEVERAL ANALYSES:  */
        /*                                             */
        /***********************************************/

  /* DATA HANDLING: */

ancomb newancomb(void);
    /* Creates a new object of type ancomb.
    $A Igor jun05; */

void dispancomb(ancomb *addr);
    /* Deallocates an object of type ancomb.
    $A Igor jun05; */

void fprintancombflags(FILE *fp,int flags);
    /* Prints the contents of analysis combination flags in human readable
    form.
    $A Igor jul05; */

void printancombflags(int flags);
    /* Prints the contents of analysis combination flags in human readable
    form to the standard output.
    $A Igor jul05; */

void readancombflagsbas(int *addrflags,int readall);
    /* Reads the flags for assembling of analysis function response into
    combined response.
    If readall is set then the flags that are not yet implemented are also
    read.
    $A Igor jul05; */

void readancombflags(int *addrflags);
    /* Reads the flags for assembling of analysis function response into
    combined response.
    $A Igor jul05; */

void fprintancomb(FILE *fp,ancomb comb);
    /* Prints the analysis assembling parameters from comb to the file fp.
    $A Igor jul05; */

void printancomb(ancomb comb);
    /* Prints the analysis assembling parameters from comb to the standard
    output.
    $A Igor jul05; */

void fprintancomball(FILE *fp,ancomb comb);
    /* Prints the analysis assembling parameters and other data from comb to 
    the file fp.
    $A Igor jul05; */

void printancomball(ancomb comb);
    /* Prints the analysis assembling parameters and other data from comb to 
    the standard output.
    $A Igor jul05; */


int addancombbas(stack *addrst,analysis_bas_f anfunc,void *andata,int flags,
        double shift,double factor,double constrshift,double constrfactor,
        double dpenalty,double hpenalty);
    /* Adds a problem definition to the definition of a combined problem on
    *addrst.
      addrst - addres of stack where data for individual problems reside. The
    stack itself may be NULL, in this case it is allocated by the function.
      flags - define how response calculated by the analysis function is
    combined to form the overall response. Flags may be an or-ed combination of
    pre-defined values ANCOMB_SUMOBJ, ANCOMB_ADDCONSTR, ANCOMB_ADDOBJTOCONSTR,
    ANCOMB_SUMCONSTR, ANCOMB_SUMCONSTRTOOBJ, ANCOMB_PENALTYSQR, 
    ANCOMB_PENALTYSQRHALF, ANCOMB_SUMPENALTYADAPT, ANCOMB_SUMPENALTYEXP (see
    definitions of these values in optbas.h).
      shift - value that is added to the objective function before assembling
    into the combined response.
      factor - factor by which objective function is eventually multiplied
    (scaled) when assembled into the combined problem. If factor 0 is passed 
    then factor is set to 1 instead. Note that if objective function should be
    ignored, this is achieved by the flags, not by setting factor to 0.
    Scaling is performed after shifting.
      constrshift - value by which constraint functions are shifted before they
    are combined to overall response.
      constrfactor - factor by which constraint functions are eventually
    multiplied before they are assembled into combined response. If c
    onstrfactor is 0 then 1 is taken. Multiplication is performed after 
    shifting.
      dpenalty: Scale length of the penalty term. If dpenalty<=0 then it is
    set to some small value (penalty term can be made 0 by setting hpen to 0).
      hpenalty: Multiplicative (height) penalty parameter.
      NOTE:
      default values 0 for all scaling and shift parameters (i.e. factor, 
    shift, constrfactor, constrshift) can be used in most cases (factor is
    replaced by 1.0 in this case).
      Function returns the position of the definition data pointer of the
    problem on the stack *addrst, or 0 if the definition could not be added.
    $A Igor jun05; */

int addancomb(stack *addrst,analysis_bas_f anfunc,void *andata,int flags,
        double shift,double factor,double constrshift,double constrfactor);
    /* The same as addancombbas, except that penalty parameters are not set.
    $A Igor jun05; */

int combinedanalysis (vector param,int *calcobj,double **addrobj,
      int *calcconstr,stack *addrconstr, int *calcgradobj,vector *addrgradobj,
      int *calcgradconstr,stack *addrgradconstr, stack cd);
    /* Performs an analysis whose definition is obtained by combination of
    several analyses. Stack cd must contain definition data for individual 
    analyses as pointers to structures of type ancomb. These structures define
    how the results (i.e. the values and/or gradients of the objective 
    functions and constraints) of individual problems are combined to form
    the combined response. The data is usually assembled by successive calls
    to addancomb() (see its declaration!).
    $A Igor jun05; */

void testancomb(void);
    /* Function for testing correct performance of the cnalysis combination
    mechanism.
    $A Igor jul05; */

void testancombpenalty(void);
    /* Tests the penaly functions that are built in the system for combining
    analysis response. The user can input parameters of penalty term 
    calculation after which results of calculation are printed.
    $A Igor jul05; */







    /* SOME FUNCTIONS OF TYPE analysis_bas_f: */

  /* SIMPLE TEST FUNCTIONS: */

int testanfunc(vector param,int *calcobj,double **addrobj,
            int *calcconstr,stack *addrconstr,
            int *calcgradobj,vector *addrgradobj,
            int *calcgradconstr,stack *addrgradconstr,void *clientdata);
    /* Function of type analysis_bas_f .
       This is a test analysis function for calculating objective functions,
    constraints, and and their gradients. Its declaration takes the standard
    form for this module.
      Arguments *calcobj, *calcconstr, *calcgradobj and *calcgradconstr must 
    address valid non-constant storage of type int (either allocated, static
    or on stack), and tell the function whether to calculate the objective
    function, the constraint functions, and their gradients, respectively (0
    for yes, 1 for no). The function may change these values with respect to
    whether it was capable to do the job (standard values: 0 - values were not
    calculated, 1 - values were calculated, -1 - values were provided, but they
    are incorrect. Therefore, if the callling function check the status
    returned via these arguments, it should treat the calculated values as
    valid only if these arguments point to values greater than zero.
      addrobj, addrconstr, addrgradobj and addrgradconstr are output arguments 
    that provide the calculated values. addrobj must be an address of a pointer
    to a dynamically allocated double (that pointer may be NULL, though, in 
    which case the function takes responsibility of allocating it if necessary)
    and addrgradobj is an address of a pointer of type vector (definition in
    vec.h). The others two are addresses of pointers of type stack (see st.c
    for definition). *addrconstr contains pointers to dynamically allocated
    doubles, and *addrgradconstr contains pointers of type vector.
      Rules about ALLOCATION OF OUTPUT ARGUMENTS are as follows: 
      A strict rule is that any pointers to allocated memory contained in these
    arguments must be the same handles of allocated memory as are used for
    deallocation by the caller. It is however strongly recommended that the
    caller allocates all potentially necessary storage, in which case the
    function will not need to do any allocation (this also helps to avoid
    problems when function is not written in such a way that it checks the
    storage alone). The last strict rule is that the function does not do any
    reallocation or allocation if this is not necessary.
      There are additional rules that should normally (but not necessarily) be
    followed. These rules are recommended to be followed by the designers of the
    called functions when this is not considered computationally inefficient or
    too demanding for coding, but may be relied on by writers of the calling 
    code only on individual basis. These rules are as follows:
      If something is not allocated properly (wrong dimensions or not allocated
    at all) then the function should allocate or reallocate this correctly. If
    something is allocated, but the function does not calculate that thing at 
    some particular call (while at subsequent calls it still might calculate
    that) then it does not make any deallocation, allocation or reallocation
    (thus saving time). Therefore, the caller may not conclude by the status of output
    arguments whether somethihng was calculated, or not, but must examine the
    value of the flags *calcobj, *clacconstr etc. after the call.
      Standards regarding the optimization problem:
    Optimization problem is stated as arg min f(x), subject to g_i(x)==0
    and g_j(x)<=0.

      This particular function is set up for the problem
    min f(x,y)=( sin( sqrt(A*(x-CX)^2+B*(y-CY)^2) ) )^2,
    subject to x>=TX+y^2 and y>=TY,
    where A=0.1, B=0.005, CX=0.2, CY=-1, TX=0.6, and TY=1.
    Constraint functions are therefore
    g_1(x,y)=TX+y*y-x, g_2(x,y)=TY-y.
    The solution is x=1.6, y=1.
      This function does not need clientdata. If clientdata is different than
    NULL then it is assumed of type optalgcd and basic information is stored
    on it.
    $A Igor oct04; */

int testanfunc1(vector param,int *calcobj,double **addrobj,
            int *calcconstr,stack *addrconstr,
            int *calcgradobj,vector *addrgradobj,
            int *calcgradconstr,stack *addrgradconstr,void *clientdata);
    /* Function of type analysis_bas_f .
       This is a test analysis function. Similar to testanfunc1(), 2 parameters
    and 2 constrint, but with different definition.
      This particular function is set up for the problem
    min f(x,y)=x^2+y^4, subject to y>=(x-3)^6 and y>=17-x^2, 
    therefore f(x,y)=x^2+y^4, g_1(x,y)=(x-3)^6-y, g_2(x,y)=17-x^2-y.
    Optimum: {4,1}, objective func. in optimum: 17.
    $A Igor oct04; */



    /* ANALYSIS FUNCTIONS FOR DEFINITION OF RESTRICTED REGION CONSTRAINTS: */

int unitballconstr (vector param,int *calcobj,double **addrobj,
    int *calcconstr,stack *addrconstr,
    int *calcgradobj,vector *addrgradobj,
    int *calcgradconstr,stack *addrgradconstr,void *clientdata);
    /* Defines a single constraint that vector of parameters must lie within
    the unit ball in the parameter space. Does not need clientdata. Function
    does not define the objective function. If calculation of objective
    function or its gradient is required then both are set to 0, but normally
    they should not be required (i.e. *calcobj and *calcgradobj should be 0).
      This function is of type analysis_bas_f.
    $A Igor mar05; */

int unitballconstrlin (vector param,int *calcobj,double **addrobj,
    int *calcconstr,stack *addrconstr,
    int *calcgradobj,vector *addrgradobj,
    int *calcgradconstr,stack *addrgradconstr,void *clientdata);
    /* Defines a single constraint that vector of parameters must lie within
    the unit ball in the parameter space. Does not need clientdata. Function
    does not define the objective function. If calculation of objective
    function or its gradient is required then both are set to 0, but normally
    they should not be required (i.e. *calcobj and *calcgradobj should be 0).
      Constraint is defined linear in vector size as ||r||-1<0, therefore the
    constrint function has discontinuous derivative at the co-ordinate origin.
      This function is of type analysis_bas_f.
    $A Igor mar05; */







          /******************************/
          /*                            */
          /*  OPTIMIZATION USING FSQP:  */
          /*                            */
          /******************************/




void inspectfsqpparam(int maxiter,double tol,double toleqn,int prn);
    /* Sets parameters for running the fsqp algorithm within inspectfsqp:
      maxiter - max. number of iterations
      tol - tolerance on Kuhn-Tucker conditions
      toleqn - tolerance on equality constraints
      prn - reporting level for 1st optimization (0 - no output)
    Remark: parameters that are <0 are not affected. If all are less than 0
    then the flag ifenforce is set to 0 (which can be used for resetting this
    flag), otherwise ifenforce is set to 1.
    $A Igor mar05; */



void inspectfsqpbas(vector param0,int nconstr,optalgcd cd,
                   analysis_bas_f testanfunc,void *clientdata );
    /* Runs the function testanfunc with specification data clientdata at
    parameters param, and outputs the results. Then it runs optimisation of
    the function by using param0 as a starting guess, and outputs results.
      nconstr is the number of constraints.
      cd is a data structure that can be optionallly provided by the caller.
    If cd==NULL then this structure is allocated inside of function and
    deallocated before return.
      Function is not thread safe since it uses static variables for function
    arguments.
    $A Igor oct04; */

void inspectfsqp(vector param0,int nconstr,
                   analysis_bas_f testanfunc,void *clientdata );
    /* Simplified version of inspectfsqpbas. Always allocates the optimization
    alg. client data automatically and deallocates it before exit.
    Runs the function testanfunc with specification data clientdata at
    parameters param, and outputs the results. Then it runs optimisation of
    the function by using param0 as a starting guess, and outputs results.
      nconstr is the number of constraints. 
      Function is not thread safe since it uses static variables for function
    arguments (??).
    $A Igor apr05; */



          /***************************************/
          /*                                     */
          /*  STANDARD OPTIMIZATION FUNCTIONS :  */
          /*                                     */
          /***************************************/


void optimizebas(vector param0,int nconstr, double tol,int maxit,
         optalgcd cd,int printlevel,
         analysis_bas_f testanfunc,void *clientdata );
    /* Tries to solve the optimization problem defined by testanfunc and 
    clientdata (which is passed to testanfunc at each call). All constraints
    must be inequality constraints. Result is stored back to param0.
      param0 - starting guess, optimal parameters are stored here on return.
      nconstr - number of constraints (must be inequality constraints)
      tol - tolerance (usually on Kuhn-Tucker conditions), defaule 1e-6.
      maxit - maximal number of iterations, default unlimited.
      cd - optionally provided auxiliary structure that is used internally. If
      NULL then the structure is temporarily allocated within the function.
      printlevel - level of output.
      testanfunc - analysis function
      clientdata - definition data for analysis function, this pointer is
    passed as argument to testanfunc at any call.
    $A Igor apr05; */





    /* SIMPLE OPTIMIZATION FUNCTIONS: */

void optimizesimp(vector param0,int nconstr, double tol,int maxit,
         analysis_bas_f testanfunc,void *clientdata );
    /* A simple function that solves the optimization problem defined by
    testanfunc and clientdata (this pointer is passed to testanfunc at
    every call).
    $A Igor apr05; */




    /* INITIALIZATION */

void fprintioptlibhead(FILE *fp);
    /* Prints the IOptlib head to the file fp.
    $A Igor apr05; */

void printioptlibhead(void);
    /* Prints the IOptlib head to the the standard output.
    $A Igor apr05; */

void initioptlib(void);
    /* Initializes IOptlib.
    $A Igor apr05; */





  /* TEST FUNCTION OF THIS MODULE */

void testoptbas(void);
    /* Tests of functions from the module optbas.c. Change conditions in if(0)
    or if(1), respectively, in order to run different tests!
    $A Igor oct04; */


int analyseoptprob1(vector param,int *calcobj,double **addrobj,
      int *calcconstr,stack *addrconstr,
      int *calcgradobj,vector *addrgradobj,
      int *calcgradconstr,stack *addrgradconstr,int *id);
    /* This function performs analysis of the optimization problem that is
    identified by id.
    $A Igor mar05; */




                         /**************/
                         /*            */
                         /*   MACROS   */
                         /*            */
                         /**************/







#endif    /* (not defined) INCLUDED_optbas */
