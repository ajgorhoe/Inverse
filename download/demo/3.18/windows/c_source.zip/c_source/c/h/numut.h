


#ifndef INCLUDED_numut
#define INCLUDED_numut



#ifndef INCLUDED_vec  /* for definition of type vector */
  #include <vec.h>
#endif

#ifndef INCLUDED_mat  /* for definition of type matrix */
  #include <mat.h>
#endif




             /****************************************/
             /*                                      */
             /*      BASIC NUMERICAL OPERATIONS      */
             /*                                      */
             /****************************************/




           /************************************************/
           /*                                              */
           /*  1D LINEAR, QUADRATIC AND CUBIC POLYNOMIALS  */
           /*                                              */
           /************************************************/


/* About the module for 1st, 2nd and 3rd order polynomials:
  On the beginning there are functions that calculate the coefficients of the
polynomial for prescribed values or/and derivatives in given points. For
example, sqrcoef...val calculates the coefficients of the quadratic parabola
when values in three points are specified, while sqrcoef...valder calculates
the coefficients when two points with their derivatives are specified.
  Each of these functions has two versions. If "rel" stands instead of ... in
function name (e.g. sqrcoefrelval), then coefficient of the polynomial through
shifted points such that the first point is (0,0) are calculated. Where there
is nothing in place of ..., the coefficients of the polynomial through the
specified points are calculated. Calculation is usually much easier with points
shifted in such a way that the first one is the origin of the co-ordinate
system.
  Any of these function has a variant that stores the coefficients to a vector;
the higher order coefficients are stored in higher copmponents. This vector
can be used e.g. with the function for calculation of values of a polynomial
valpol() or with the functio for calculatio of its derivatives derpol().
  Follow the functions for calculation of zeros and extrema for a given type
of polynomial with specified coefficient. The last are functions for testing
of these functions.
*/


    /* LINEAR POLYNOMIALS: */

int linzero(double a1,double a0,double *x1);
    /* Calculates a zaro of the 1th order equation a1*x+a0==0. It returns 1
    if the zero exists and 0 if not. If the zero exists, it is written to *x1.
    $A Igor mar01; */

void lincoefrelval(double x1,double y1,double x2,double y2,double *a1,double *a0);
    /* calculates the coefficients of the shifted 1st defree polinomyal
    (a1*x+a0) through the points (0,0) and (x2-x1,y2-y1), and writes them to
    *a1 and *a0.
    $A Igor mar01; */ 

void lincoefval(double x1,double y1,double x2,double y2,double *a1,double *a0);
    /* Calculates the coefficients of the 1st degree polynomial (a1*x+a0)
    through the points (x1,y1) and (x2,y2) and stores them in *a1 and *a2.
    ** Izracuna koeficienta polinoma prve stopnje (a1*x+a0) skozi tocki
    (x1,y1) in (x2,y2) ter ju zapise v *a1 in *a0.
    $A Igor mar01; */ 

void lincoefrelvalder(double x1,double y1,double d1,double *a1,double *a0);
    /* Calculates the coefficients of the 1st degree polynomial (a1*x+a0)
    through the shifted point (0,0) with the derivative d1 in this point, and
    writes them to *a1 and *a0 (arguments x1 and y1 are not used).
    $A Igor mar01; */ 


void lincoefvalder(double x1,double y1,double d1,double *a1,double *a0);
    /* Calculates the coefficients of the 1st order polynomial (a1*x+a0)
    through (x1,y1) with derivative d1 in this point, and writes them in *a1
    and *a0.
    $A Igor mar01; */ 


    /*  QUADRATIC POLYNOMIALS:  */

void sqrcoefrelval(double x1,double y1,double x2,double y2,double x3,double y3,
     double *a2,double *a1,double *a0);
    /* Calculates coefficients of a quadratic parabola that goes through (0,0),
    (x2-x1,y2-y1) and (x3-x1,y3-y1), and writes them to *a2, *a1 and *a0 (the
    formula of the parabola being a2*x^2+a1*x+a0). The abscicas of points can
    be in arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor mar01; */

void sqrcoefval(double x1,double y1,double x2,double y2,double x3,double y3,
     double *a2,double *a1,double *a0);
    /* Calculates coefficients of a quadratic parabola throough points (x1,y1),
    (x2,y2) in (x3,y3) and writes them to *a2, *a1 and *a0 (where formula of
    the parabola is a2*x^2+a1*x+a0)
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor mar01; */

void sqrcoefrelvalder1(double x1,double y1,double d1,double x2,double y2,
     double *a2,double *a1,double *a0);
    /* Calculates coefficients of the quadratic parabola through (0,0) and
    (x2-x1,y2-y1) with the derivatives d1 in the first point. Coefficients are
    stored to *a2, *a1 and *a0 (where the formula of the parabola is
    a2*x^2+a1*x+a0). Points can be stated in an arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor nov03; */

void sqrcoefvalder1(double x1,double y1,double d1,double x2,double y2,
     double *a2,double *a1,double *a0);
    /* Calculates coefficients of the quadratic parabola that goes through
    (x1,y1) and (x2,y2) with the derivative d1 in the first point. Coefficients
    are stored in *a2, *a1 and *a0, where the formula of the
    parabola is a2*x^2+a1*x+a0). Points may be stated in an arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor nov03; */

void sqrcoefrelvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,double *a2,double *a1,double *a0);
    /* Calculates coefficients of the quadratic parabola through (0,0) and
    (x2-x1,y2-y1) with approximate derivatives d1 in the first and d2 in the
    second point. The parabola is calculated as an average between the one
    which has the derivative d1 in the first point and that with the derivative
    d2 in the second. Coefficients are written to *a2, *a1 and *a0 (where the
    formula of the parabola is a2*x^2+a1*x+a0). Points can be stated in an
    arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor mar01; */

void sqrcoefvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,double *a2,double *a1,double *a0);
    /* Calculates coefficients of the quadratic parabola that goes through
    (x1,y1) and (x2,y2) with the derivative approximately d1 in the first and
    d2 in the second point. The parabola is calculated as an average of the one
    with the derivative d1 in the first and d2 in the second point.
    Coefficients are stored in *a2, *a1 and *a0, where the formula of the
    parabola is a2*x^2+a1*x+a0). Points may be stated in an arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor mar01; */

void sqrpolrelval(double x1,double y1,double x2,double y2,double x3,double y3,
     vector *coef);
    /* Stores coefficient of the quadratic parabola as calculated by
    sqrcoefrelval(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.
    $A Igor mar01; */

void sqrpolval(double x1,double y1,double x2,double y2,double x3,double y3,
     vector *coef);
    /* Stores coefficients of the quadratic parabola as calculated by
    sqrcoefval(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.
    $A Igor mar01; */

void sqrpolrelvalder1(double x1,double y1,double d1,double x2,double y2,
     vector *coef);
    /* Stores coefficients of the quadratic parabola as calculated by
    sqrcoefrelvalder1(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.
    $A Igor nov03; */

void sqrpolvalder1(double x1,double y1,double d1,double x2,double y2,
     vector *coef);
    /* Stores coefficients of the quadratic parabola as calculated by
    sqrcoefvalder1(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.
    $A Igor nov03; */

void sqrpolrelvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,vector *coef);
    /* Stores coefficients of the quadratic parabola as calculated by
    sqrcoefrelvalder(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.
    $A Igor mar01; */

void sqrpolvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,vector *coef);
    /* Stores coefficients of the quadratic parabola as calculated by
    sqrcoefvalder(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.
    $A Igor mar01; */

int sqrzeros(double a2,double a1,double a0,double *x1,double *x2);
    /* Calculates the real roots of the quadratic equation a2*x^2+a1*x+a0==0.
    It returns the number of solutions and stores the smaller one in *x1 and
    the larger one in *x2 (if the solution is one, it is stored to *x1).
    $A Igor mar01; */

double sqrextreme(double a2,double a1,double a0,double *x,double *y);
    /* Calculates the extreme of kthe quadratic parabola a2*x^2+a1*x+a0. It
    returns the value of the second derivative in this point or 0 if there is
    no extreme (if the parabola is degenerated to a line). Abscissa of the
    extremal point is stored to *x and the ordinate of *y.
    $A Igor mar01; */

int sqrmin(double a2,double a1,double a0,double *x,double *y);
    /* Calculates the minimum of the quadratic parabola a2*x^2+a1*x+a0. It
    returns 1 if the minimimum exists and 0 if not. The abscisse of the minimum
    is stored to *x and the value in the minimum to *y.
    $A Igor mar01; */

int sqrmax(double a2,double a1,double a0,double *x,double *y);
    /* Calculates the maximum of the quadratic parabola a2*x^2+a1*x+a0. It
    returns 1 if the maximum exists and 0 if not. The abscisse of the minimum
    is stored to *x and the value in the minimum to *y.
    $A Igor mar01; */


    /*  CUBIC POLYNOMIALS:  */

void cubcoefrelval(double x1,double y1,double x2,double y2,double x3,double y3,
     double x4,double y4,double *a3,double *a2,double *a1,double *a0);
    /* Calculates the coefficients of the cubic polynomial through the points
    (0,0),(x2-x1,y2-y1), (x3-x1,y3-y1) and (x4-x1,y4-y1), and stores them to
    *a3, *a2, *a1 and *a0 (formula of the polynomial being a3*x^3+a2*x^2+a1*x+a0).
    The points can be stated in an arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor mar01; */

void cubcoefval(double x1,double y1,double x2,double y2,double x3,double y3,
     double x4,double y4,double *a3,double *a2,double *a1,double *a0);
    /* Calculates the coefficients of the cubic polynomial through the points
    (x1,y1), (x2,y2), (x3,y3) and (x4,y4), and writes them to *a3 *a2, *a1 and
    *a0 (formula of the polynomial being a3*x^3+a2*x^2+a1*x+a0). The points can
    be stated in an arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor mar01; */

void cubcoefrelvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,double *a3,double *a2,double *a1,double *a0);
    /* Calculates the coefficients of a cubic polynimial through the points
    (0,0) and (x2-x1,y2-y1) and has the derivative d1 in 0 and d2 in x2-x1.
    Coefficients are stored in *a3 *a2, *a1 and *a0 (formula of the polynomial
    being a3*x^3+a2*x^2+a1*x+a0). The points can be stated in an arbitrary
    order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor mar01; */

void cubcoefvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,double *a3,double *a2,double *a1,double *a0);
    /* Calculates the coefficients of a cubic polynimial through the points
    (x1,y1) and (x2,y2) and has the derivative d1 in x1 and d2 in x2.
    Coefficients are stored in *a3 *a2, *a1 and *a0 (formula of the polynomial
    being a3*x^3+a2*x^2+a1*x+a0). The points can be stated in an arbitrary
    order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor mar01; */

void cubpolrelval(double x1,double y1,double x2,double y2,double x3,double y3,
     double x4,double y4,vector *coef);
    /* Stores coefficients of the cubic polynomial, as calculated by the
    cubcoefrelval(), to *coef in the way compatible with valpol() (low order
    coefficients first). *coef is allocated or reallocated if necessary.
    $A Igor mar01; */

void cubpolval(double x1,double y1,double x2,double y2,double x3,double y3,
     double x4,double y4,vector *coef);
    /* Stores coefficients of the cubic polynomial, as calculated by the
    cubcoefval(), to *coef in the way compatible with valpol() (low order
    coefficients first). *coef is allocated or reallocated if necessary.
    $A Igor mar01; */

void cubpolrelvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,vector *coef);
    /* Stores coefficients of the cubic polynomial, as calculated by the
    cubcoefrelvalder(), to *coef in the way compatible with valpol() (low order
    coefficients first). *coef is allocated or reallocated if necessary.
    $A Igor mar01; */

void cubpolvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,vector *coef);
    /* Stores coefficients of the cubic polynomial, as calculated by the
    cubcoefvalder(), to *coef in the way compatible with valpol() (low order
    coefficients first). *coef is allocated or reallocated if necessary.
    $A Igor mar01; */

int cubzeros(double a3,double a2,double a1,double a0,double *x1,double *x2,
             double *x3);
    /* Calculates the real roots of the cubic equation a3*x^3+a2*x^2+a1*x+a0==0.
    It returns the number of real roots and writes the roots to *x1, *x2 and
    *x3 (if there is only one, it is written to *x1). Zeros are sorted by size.
      Ref.: Bronstein, Smendjajev,...: Mat. prir., p.p. 28,29.
    $A Igor mar01; */

int cubextremes(double a3,double a2,double a1,double a0,double *x1,double *y1,
    double *d1,double *x2,double *y2,double *d2);
    /* Calculates extremes of the cubic polynomial a3*x^3+a2*x^2+a1*x+a0. It
    returns the number of extremes (which can be 2, 1 if the polynomial is
    degenerated to quadratic pol., or 0). Abscisas of the extremes are written
    to *x1 and *x2, extremal values to *y1 and *y2 and second derivatives in
    these points to *d1 and *d2 (if there is only one extreme, the data is
    stored to *x1, *y1 and *d1). Extremes are sorted by the abscissas.
    $A Igor mar01; */

int cubmin(double a3,double a2,double a1,double a0,double *x,double *y);
    /* Calculates the minimum of the cubic polynomial a3*x^3+a2*x^2+a1*x+a0.
    It returns 1 if the minimum exsists or 0 if it does not (i.e. if the
    polynomial is degenerated to an lower order one). The abscissa of the
    minimum is stored to *x while the value of the polynomial in this point
    is stored to *y if the minimum exists.
    $A Igor mar01; */

int cubmax(double a3,double a2,double a1,double a0,double *x,double *y);
    /* Calculates the maximum of the cubic polynomial a3*x^3+a2*x^2+a1*x+a0.
    It returns 1 if the maximum exsists or 0 if it does not (i.e. if the
    polynomial is degenerated to an lower order one). The abscissa of the
    maximum is stored to *x while the value of the polynomial in this point
    is stored to *y if the maximum exists.
    $A Igor mar01; */


    /* INSPECTING POLYNOMIALS WITH GIVEN DATA: */

void inspsqrval(double x1,double y1,double x2,double y2,
            double x3,double y3);
    /* Calculates the coefficients of the quadratic polynomial through points
    (x1,y1), (x2,y2) and (x3,y3), shifted for (-x1,-x2), and prints the data
    about this polynomial.
    $A Igor mar01; */

void inspsqrvalder(double x1,double y1,double d1,double x2,double y2,
            double d2);
    /* Calculates coefficients of a quadratic polynomial throug points (x1,y1)
    and (x2,y2) with the derivative d2 in (x2,y2), shifted for (-x1,-y1) and
    prints the relevant data about this parabola.
    $A Igor mar01; */

void inspcubval(double x1,double y1,double x2,double y2,
            double x3,double y3,double x4,double y4);
    /* Calculates the coefficients of the cubic polynomial through the points
    (x1,y1), (x2,y2), (x3,y3) and (x4,y4), shifted for (-x1,-y1), and prints
    the data about this polynomial.
    $A Igor mar01; */

void inspcubvalder(double x1,double y1,double d1,double x2,double y2,
            double d2);
    /* Calculates the coefficients of a cubic polynomial through (x1,y1) and
    (x2,y2) with derivatives d1 and d2 in these points, shifted by (-x1,-y1),
    and prints the basic data about this polynomial.
    $A Igor mar01; */




           /*************************************/
           /*                                   */
           /*    SOLUTION OF EQUATIONS IN 1D    */
           /*                                   */
           /*************************************/



int zerofunc1dsimpint0(double func(double,void *),void *clientdata,
          double x1,double x2, double tolx,double tolf,int maxit,
          double *xzero,double *fzero,int *niter);
    /* Calculates an approximation of simple zero of function func,
    beginning with interval [x1,x2], which must be such that the function
    does not have the same sign at x1 and x2.
      func is used to evaluate function, and clientdata is passed to
    func when evaluating (this allows to use specification data for the
    function and therefore combine functions in a thread safe way).
      tolx and tolf are tolerances on the size of the interval which
    for sure contains zero and for function value, respectively. One of
    them can be 0 (which means unspecified), and convergence is achieved
    when both convergence criteria - on interval length and function value
    - are satisfied. 
      maxit limits the maximum number of iterations and is set internally
    if the provided value is less than .1
      The approximate zero of the function is written to *xzero and value
    of the function in this point is written to *fzero. If one or both of
    these are NULL then no error is reported, just the values are not
    returned.
      If niter is not NULL then number of iterations is written to *niter.
    This corresponds to the number of function evaluations.
      Returns 0 if successful, -1 if not (e.g. max. num. iterations
    exceeded).
      WARNINGS:
    ONLY FOR SIMPLE ZEROS!!! Convenient for monotone functions.
    The sign of f1 anf f2 must be the opposite!
    $A Igor mar05; */





           /**********************************/
           /*                                */
           /*      NUMERICAL INTEGRATION     */
           /*                                */
           /**********************************/


double inttrap0(double (*func)(double, void *),void *clientdata,
                double from,double to,int n);
    /* Calculates the definite integral of function of one variable calculated 
    by func on the interval [from,to], by trapesian formula, using n points.
    Function func takes a pointer to definition data, and this function passes
    the clientdata to the function as definition data.
    If n is less than 1 then it is set to 1 again.
    $A Igor mar05; */

double inttrapbas(double (*func)(double),double from,double to,int n);
    /* Izracuna dolocen integral funkcije func od from to to po trapezni
    formuli, pri cemer se fnkcija n+1 krat ovrednoti (interval [from,to] se
    razdeli na n podintervalov). Ce je n manj od 1, ga funkcija postavi na 1.
    $A Igor jan01; */

double inttraptab(double *tab,int n,double h);
    /* Izracuna dolocen integral funkcije tabelirane v tab po trapezni
    formuli. Funkcija mora biti tabelirana z n vrednostmi, ki so izracunane
    v enakomernih razmikih h. Ce je n manj od 2, se javi napaka. Kazalec tab
    mora biti taksen, da je prva vrednost funkcije v tab[0]. Pozor: pri
    inttrapbas() je n st. intervalov, tu pa je n st. tock, torej za ena vec.
    $A Igor jan01; */

double inttrapvec(vector v,double h);
    /* Izracuna dolocen integral funkcije tabelirane v vec po trapezni
    formuli. Funkcija mora biti tabelirana z vec->d vrednostmi, ki so
    izracunane v enakomernih razmikih h. Ce je stevilo vrednosti manj od 2,
    se javi napaka. Za izracun uporabi funkcijo inttraptab().
    $A Igor jan01; */

double intsimp0(double (*func)(double, void *),void *clientdata,
                double from,double to,int n);
    /* Calculates the definite integral of function of one variable calculated 
    by func on the interval [from,to], by the Simpson formula, using n points.
    Function func takes a pointer to definition data, and this function passes
    the clientdata to the function as definition data.
    If n is less than 2 or odd then it is corrected.
    $A Igor mar05; */

double intsimpsbas(double (*func)(double),double from,double to,int n);
    /* Izracuna dolocen integral funkcije func od from to to po Simpsonovi
    formuli, pri cemer se fnkcija n+1 krat ovrednoti (interval [from,to] se
    razdeli na n podintervalov). n mora biti sodo stevilo vecje od 1, ce ni,
    ga funkcija sama popravi (ce je vecji od 1, ga inkrementira).
    $A Igor jan01; */

double intsimptab(double *tab,int n,double h);
    /* Izracuna dolocen integral funkcije tabelirane v tab po simpsonovi
    formuli. Funkcija mora biti tabelirana z n vrednostmi, ki so izracunane
    v enakomernih razmikih h. Ce je n sodo stevilo ali manj od 3, se javi
    napaka. Kazalec tab mora biti taksen, da je prva vrednost funkcije v
    tab[0]. Pozor: pri intsimpbas() je n st. intervalov, tu pa je n st. tock,
    torej za eno vec.
    $A Igor jan01; */

double intsimpvec(vector v,double h);
    /* Izracuna dolocen integral funkcije tabelirane v vec po simpsonovi
    formuli. Funkcija mora biti tabelirana z vec->d vrednostmi, ki so
    izracunane v enakomernih razmikih h. Ce je stevilo vrednosti liho ali
    manj od 4, se javi napaka. Za izracun uporabi funkcijo intsimptab().
    $A Igor jan01; */

double intsimptabsafe(double *tab,int n,double h);
    /* Izracuna dolocen integral funkcije tabelirane v tab po simpsonovi
    formuli. Funkcija mora biti tabelirana z n vrednostmi, ki so izracunane
    v enakomernih razmikih h. Ce je n manj od 3 izracuna integral po trapezni
    formuli. Ce je n sod, se izracunz integral prvega intervala po trapezni
    formuli, integral ostalega dela pa po Simpsonovi. Le, ce je n manj od 1,
    se javi napaka. Kazalec tab mora biti taksen, da je prva vrednost funkcije
    v tab[0]. Pozor: pri intsimpbas() je n st. intervalov, tu pa je n st. tock,
    torej za eno vec.
    $A Igor jan01; */

double intsimpvecsafe(vector v,double h);
    /* Izracuna dolocen integral funkcije tabelirane v vec po simpsonovi
    formuli. Funkcija mora biti tabelirana z vec->d vrednostmi, ki so
    izracunane v enakomernih razmikih h. Ce vec->d ni ustrezno stevilo, si
    pomaga s trapezno formulo. Za izracun uporabi funkcijo intsimptabsafe().
    $A Igor jan01; */





           /*********************************/
           /*                               */
           /*         POLYNOMIALS           */
           /*                               */
           /*********************************/



    /* CALCULATION OF VALUES AND DERIVATIVES OF POLYNOMIAL: */

double valpol(vector v,double x);
    /* Vrne vrednost polinoma, katerega koeficienti so v vektorju v, v tocki
    x.
    $A Igor jul00; */

double derpol(vector v,double x,int order);
    /* Vrne vrednost odvoda reda order polinoma, katerega koeficienti so v
    vektorju v, v tocki x.
    $A Igor jul00; */



           /************************************/
           /*                                  */
           /*     POLYNOMIAL APPROXIMATION     */
           /*                                  */
           /************************************/



    /* CALCULATION OF ORTHOGONAL POLYNOMIALS ON A SET OF POINTS: */


void ortnormpolbas(vector x,int n,matrix *val0,matrix *coef0,char norm);
    /* Konstruira n ortogonalnih polinomov na tockah, katerih abscise so v
    vektorju x. V matriko *val0 zapise vrednosti posam. polinomov v tockah
    vektorja x (po vrsticah), v matriko *coef0 pa zapise koeficiente polinomov
    (tudi po vrsticah). Sistem ortogonalnih polinomov je uporaben predvsem za
    aproksimacijo s polinomi po metodi najmanjsih kvadratov.
    Ce je norm razlicen od 0, potem polinome tudi normira.
      val0 in coef0 sta lahko enaki NULL, v tem primeru se ustrezni matriki ne
    izracunata.
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
    Ref. Bohte, Num. Met., pp. 86.
    $A Igor jul00; */

void ortpol(vector x,int n,matrix *val,matrix *coef);
    /* Konstruira n ortogonalnih polinomov na tockah, katerih abscise so v
    vektorju x. V matriko *val0 zapise vrednosti posam. polinomov v tockah
    vektorja x (po vrsticah), v matriko *coef0 pa zapise koeficiente polinomov
    (tudi po vrsticah). Sistem ortogonalnih polinomov je uporaben predvsem za
    aproksimacijo s polinomi po metodi najmanjsih kvadratov.
      val0 in coef0 sta lahko enaki NULL, v tem primeru se ustrezni matriki ne
    izracunata.
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
    Ref. Bohte, Num. Met., pp. 86.
    $A Igor jul00; */

void ortnormpol(vector x,int n,matrix *val,matrix *coef);
    /* Konstruira n ortonormalnih polinomov na tockah, katerih abscise so v
    vektorju x. V matriko *val0 zapise vrednosti posam. polinomov v tockah
    vektorja x (po vrsticah), v matriko *coef0 pa zapise koeficiente polinomov
    (tudi po vrsticah). Sistem ortogonalnih polinomov je uporaben predvsem za
    aproksimacijo s polinomi po metodi najmanjsih kvadratov.
      val0 in coef0 sta lahko enaki NULL, v tem primeru se ustrezni matriki ne
    izracunata.
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
    Ref. Bohte, Num. Met., pp. 86.
    $A Igor jul00; */


    /* IZRACUN POLINOMSKE APROKSIMACIJE TABELE VREDNOSTI
    S POMOCJO ORTOGONALNIH POLINOMOV NA TABELI TOCK: */

void aportnormpolbas(vector y,int n,matrix val,matrix ortpol,vector *coef0,
    vector *pol0,double *error,char norm);
    /* Izracuna koeficiente lin. aproksimacije tabele vrednosti y z n ortogonalnimi
    polinomi, katerih vrednosti v tockah, na katerih je izracunana tabela, so
    podane v matriki val. Vrstice v tej matriki morajo vsebovati vrednosti
    posameznih polinomov v tockah, na katerih je bila narejena tabela y. V
    vektor coef0 se zapisejo koeficienti aproksimacije pri ortogonalnih
    polinomih, v *pol0 pa kar koeficienti aproksimativnega polinoma (V tem
    primeru MORA biti podana matrika ortpol, ki vsebuje koeficiente
    ortogonalnih polinomov). V *error se zapise napaka aproksimacije, ki se
    izracuna kot koren iz vsote kvadratov odstopanj po tockah, deljen s
    stevilom tock (t.j. povprecni kvadrat odstopanj).
      Ce je norm razlicen od 0, so ortogonalni polinomi v matriki val tudi
    normirani. error je lahko NULL, v tem primeru funkcija ne izracuna napake.
    Tudi edenod argumentov coef0 ali pol0 je lahko NULL, ce katerega od teh
    podatkov ne rabimo (ne pa oba!!!).
      Vhod. parametri:
     y   - vrednosti funkcije, ki jo aproks., v tockah
     n   - stevilo uporabljenih aproksimac. polinomov
     val - matrika vrednosti ort. polinomov v vzorcnih tockah, nad katerimi je
           izracunana tabela y - obvezen podatek!
     ortpol - koeficienti ortogonal. polinomov pri potencah neodvis. sprem.,
           podani morajo biti le, ce je pol0 razlicen od NULL
     norm - mora biti 0, ce ort. polinomi niso normirani
       Izhod. parametri:
     coef0 - koeficienti lin. kombinacije ort. polinomov, ki aproksimira tabelo
          y. Lahko je NULL, ce je pol0 razlic. od NULL.
     pol0  - koeficienti potenc aproksimacijskega polinoma. Lahko je NULL, ce
          je coef0 razlic. od NULL, v tem primeru mora biti tudi ortpol enaka
          NULL. Ce je razlicen od NULL, mora biti ortpol obvezno podan.
     error - napaka aproksimacije (koren iz vsote kvadratov odstopanj, deljen
          s stevilom tock). Lahko je NULL, ce nocemo izracuna koeficientov.
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
      Matrika val vrednosti ort. polinomov v tockah, nad katerimi je
    vzorcena tabela y, mora biti nujno podana in predhodno pravilno izracunana
    (t.j. polinomi morajo biti res ortogonalni na danih tockah in ce je norm
    razlicen od 0, tudi normirani). Podobno velja za matriko koeficientov
    polinomov val v primeru, da hocemo izracunati tudi koeficienta ap polinoma.
    Vsi ti podatki naj bi se izracunali s funkcijo ortpol() ali ortnormpol()!
    $A Igor jul00; */

void aportpol(vector y,int n,matrix val,matrix ortpol,vector *coef,
    vector *pol,double *error);
    /* Izracuna koeficiente lin. aproksimacije tabele vrednosti y z n
    ortogonalnimi polinomi, katerih vrednosti v tockah, na katerih je
    izracunana tabela y, so podane v matriki val. Za razlago argumentov in
    ostala pojasnila glej funkcijo aportnormpolbas(). Uporablja se v glavnem
    v kombinaciji s  ortpol() z ortnormpol().
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
    $A Igor jul00; */

void aportnormpol(vector y,int n,matrix val,matrix ortpol,vector *coef,
    vector *pol,double *error);
    /* Izracuna koeficiente lin. aproksimacije tabele vrednosti y z n
    ORTONORMIRANIMI polinomi, katerih vrednosti v tockah, na katerih je
    izracunana tabela y, so podane v matriki val. Za razlago argumentov in
    ostala pojasnila glej funkcijo aportnormpolbas(). Uporablja se v glavnem
    v kombinaciji z ortnormpol().
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
    $A Igor jul00; */






           /*************************************/
           /*                                   */
           /*      PLOTTING OF FUNCTIONS        */
           /*          IN TEXT MODE             */
           /*                                   */
           /*************************************/




void drawfuncprim(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n,char
     drawxaxis,double level1,double level2,char drawyaxis,double pole1,
     double pole2,int screenwidth,char printcoord,FILE *fp);
    /* Enostavna funkcija za izris funkcij ene spremenljivke na tekstovnem
    zaslonu. func1, func2 in func3 so funkcije, ki jih ta funkcija izrise.
    Katerakoli od teh funkcij je lahko NULL. from in to sta meji intervala,
    na katerem se rise. drawxaxis, drawyaxis in printcoord povejo, ali naj se
    izriseta os x in y ter ali naj se izpisujejo koordinate (0 pomeni ne, 1 pa
    da). Koordinate se izpisujejo na levi ali desni strani, ce je dovolj
    prostora in ce je coord razlicen od 0. Ce je dovolj prostora, se izpiseta
    koordinata x in vrednost funkcije func1, ce pa je prostora manj, se izpise
    samo koordinata x. screenwidth je sirina tekstovnega zaslona v znakih.
    Ce sta level1 in level2 razlicna od 0, se pri njunih vrednostih izriseta
    nivojnici vzporedni z osjo x. Ce sta pole1 in pole2 razlicna od 0, se
    izriseta pola vzporedna z osjo y pri njunih vrednostih.
      Za izris 1. funkcije se uporabi znak *, za izris druge znak +, za izris
    tretje pa znak #. Za izris koordinatnih osi se uporabita znaka - in |, za
    izris polov pa znaka ~ in !. Ce je fp!=NULL, se grafi zapisejo tudi v
    datoteko fp.
    $A Igor jan00; */

void drawfuncprimint(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n,char
     drawxaxis,double level1,double level2,char drawyaxis,double pole1,
     double pole2,int screenwidth,char printcoord,FILE *fp);
    /* Enostavna funkcija za interaktiven izris funkcij ene spremenljivke na
    tekstovnem zaslonu. Za izris se uporablja funkcija drawfuncprim(),
    uporabnik pa lahko v tej funkciji interaktivno spreminja vse parametre
    razen funkcij, ki se izrisejo. Ce je fp!=NULL, se grafi izrisejo tudi v
    datoteko fp.
    $A Igor jan01; */

void drawfuncprimintaddr(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double *from,double *to,int *n,char
     *drawxaxis,double *level1,double *level2,char *drawyaxis,double *pole1,
     double *pole2,int *screenwidth,char *printcoord,FILE *fp);
    /* Enostavna funkcija za interaktiven izris funkcij ene spremenljivke na
    tekstovnem zaslonu. Za izris se uporablja funkcija drawfuncprim(),
    uporabnik pa lahko v tej funkciji interaktivno spreminja vse parametre
    razen funkcij, ki se izrisejo. Parametri so isti kot pri drawfuncprim(),
    le da ta funkcija vecinoma vzame naslove parametrov, da si lahko zapomnimo
    spremenjene parametre. Ce je fp!=NULL, se grafi izrisejo tudi v
    datoteko fp.
    $A Igor jan01; */

void drawfuncsimp(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n);
    /* Narise grafe funkcij func1, func2 in func3 od from do to z n tockami.
    $A Igor jan01; */

void fdrawfuncsimp(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n,FILE *fp);
    /* Narise grafe funkcij func1, func2 in func3 od from do to z n tockami.
    Ce je fp razlicen od NULL, se izrisejo funkcije tudi v datoteke.
    $A Igor jan01; */

void  drawfuncsimpcont(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n);
    /* Narise grafe funkcij func1, func2 in func3 od from do to z n tockami.
    FUNKCIJA NE DELA INTERAKTIVNO.
    $A Igor mar01; */

void fdrawfuncsimpcont(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n,FILE *fp);
    /* Narise grafe funkcij func1, func2 in func3 od from do to z n tockami.
    Ce je fp razlicen od NULL, se izrisejo funkcije tudi v datoteko.
    FUNKCIJA NE DELA INTERAKTIVNO.
    $A Igor mar01; */

void plotvector(vector v1,vector v2,vector v3,int forcen,FILE *fp);
    /* Izrise komponente vektorja v v odvisnosti od indeksa s pomocjo funkcije
    drawfuncprimintaddr. Ce je forcen vecji od 0, se na zacetku izrise forcen
    tock, drugace se na zacetku izrise toliko tock, kolikor je dimenzija
    vektorja. V vsakem primeru je zacetni interval od 1 do dimenzije vektorja.
    Ce je fp!=NULL, se grafi izrisejo tudi v datoteko fp.
    $A Igor jan01; */

void plotvec(vector v,int forcen,FILE *fp);
    /* Izrise komponente vektorja v v odvisnosti od indeksa s pomocjo funkcije
    drawfuncprimintaddr. Ce je forcen vecji od 0, se na zacetku izrise forcen
    tock, drugace se na zacetku izrise toliko tock, kolikor je dimenzija
    vektorja. V vsakem primeru je zacetni interval od 1 do dimenzije vektorja.
    Ce je fp!=NULL, se grafi izrisejo tudi v datoteko fp.
    $A Igor jan01; */

void plotvectorcont(vector v1,vector v2,vector v3,int forcen,FILE *fp);
    /* Izrise komponente vektorja v v odvisnosti od indeksa s pomocjo funkcije
    drawfuncprimintaddr. Ce je forcen vecji od 0, se na zacetku izrise forcen
    tock, drugace se na zacetku izrise toliko tock, kolikor je dimenzija
    vektorja. V vsakem primeru je zacetni interval od 1 do dimenzije vektorja.
    Ce je fp!=NULL, se grafi izrisejo tudi v datoteko fp.
    FUNKCIJA NE DELA INTERAKTIVNO.
    $A Igor mar01; */

void plotveccont(vector v,int forcen,FILE *fp);
    /* Izrise komponente vektorja v v odvisnosti od indeksa s pomocjo funkcije
    drawfuncprimintaddr. Ce je forcen vecji od 0, se na zacetku izrise forcen
    tock, drugace se na zacetku izrise toliko tock, kolikor je dimenzija
    vektorja. V vsakem primeru je zacetni interval od 1 do dimenzije vektorja.
    Ce je fp!=NULL, se grafi izrisejo tudi v datoteko fp.
    FUNKCIJA NE DELA INTERAKTIVNO.
    $A Igor mar01; */

void plotmat2(matrix m,int forcen,FILE *fp);
    /* Izrise komponente 2. vrstice matrike m v odvisnosti od komponente 1.
    vrstice, ki mora linearno narascati, s pomocjo funkcije
    drawfuncprimintaddr. Ce je forcen vecji od 0, se na zacetku izrise
    forcen tock, drugace se na zacetku izrise toliko tock, kolikor je 2.
    dimenzija matrike. V vsakem primeru je zacetni interval od 1 do 2.
    dimenzije matrike. Ce je fp!=NULL, se grafi izrisejo tudi v datoteko fp.
    $A Igor jan01; */







           /************************************************/
           /*                                              */
           /*      CONVERSION TO LOWER NUMBER OF BITS      */
           /*                                              */
           /************************************************/


void rounddouble (double *x);
    /* Zaokrozi stevilo tipa double *x po sistemu zaokrozevanja, ki je trenutno
    v veljavi.
    $A Igor feb01; */

void roundfloat (float *x);
    /* Zaokrozi stevilo tipa long *x po sistemu zaokrozevanja, ki je trenutno
    v veljavi.
    $A Igor feb01; */

void roundlong (long *x);
    /* Zaokrozi stevilo tipa float *x po sistemu zaokrozevanja, ki je trenutno
    v veljavi.
    $A Igor feb01; */

void resetoverflowcount(void);
    /* Stevce overflowov in underflowov postavi na 0.
    $A Igor feb01;  */

void resetrounding(void);
    /* Sistem postavi nazaj v stanje brez zaokrozevanj. Resetira tudi stevce
    underflowov in overflowov.
    $A Igor feb01; */

long getunderflowcount(void);
    /* Vrne vrednost stevca underflowov.
    $A Igor feb01; */

long getoverflowcount(void);
    /* Vrne vrednost stevca underflowov.
    $A Igor feb01; */

void setroundsignfixbit(double range,int numbits);
    /* Postavi zaokrozevanje na signed fixed point z numbits bitno
    reprezentacijo in obsegom range. Funkcija resetira stevec underflowov in
    overflowov.
    $A Igor feb01; */

void setroundsignfixnum(double range,long maxnum);
    /* Postavi zaokrozevanje na signed fixed point z resolucijo maxnum v
    plus in minus in obsegom range. Funkcija resetira stevec underflowov in
    overflowov. Funkcija je podobna setroundsignfixbit(), le da se namesto
    stevila bitov direktno postavi najvecje predstavljivo pozitivno celo
    stevilo (locljivost).
    $A Igor feb01; */




    /* TEST FUNCTION FOR THIS MODULE: */


void testnumut(void);
    /* A set of tests for numut.c. Switch individual tests on or off by
    setting conditions to 0 or 1.
    $A Igor mar05; */








#endif /* ifndef INCLUDED_numut */




