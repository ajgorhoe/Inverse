


#define LINUX

#define DEMO

#define CFSQP



#define INVCLOSED  /* Inverse v zaprti obliki, funkc. odprte knjiznice so
                      vkljucene v glavno datoteko programa Inverse. */



/*
#define EMELFINT
*/




/************************************************************/
/*                                                          */
/*                     SISTEMSKI VMESNIK                    */
/*                                                          */
/************************************************************/


/* DEFINICIJE, ODVISNE OD SISTEMA, NA KATEREM SE PROGRAMI PREVAJAJO */

/* DEFINICIJE SPREMENLJIVK, KI POVEDO PREVAJALNIKU, NA KAKSNEM SISTEMU PREVAJA
   PROGRAM:

Spremenljivke sistema so:
HPUNIX     : Unix na HP-ju
LINUX    : Linux
DOS      : MS-DOS na PC-ju
WN16    : 16-bitni Windowsi na PC-ju
WN32    : 32-bitni Windowsi na PC-ju
WNDOWS  : Katerikoli Windowsi na PC-ju
DOSWN   : Katerikoli Windowsi ali DOS na PC-ju

Spremenljivke knjiznic in prevajalnikov so:
MPI      : MPI (za paralelno procesiranje)
GRX      : Xlib
GRPEX    : PEXove graficne knjiznice
GRBGI    : Borlandove graficne knjiznice
GRTCL    : Grafika implement. preko prikaza datotek v Tcl.
BC3      : Borland C 3.x
BC5      : Borland C 5.x
BC       : Borland C
VISUALC  : Microsoft Visual C++

Spremenljivke algoritmov so:
CFSQP    : Optimizac. alg. CFSQP (http://www.isr.umd.edu/Labs/CACSE/FSQP/fsqp.html)

Spremenljivke, ki se ticejo licenc:
SHAREWARE  : shareware verzija
DEMO       : demo verzija
COMMERCIAL : komercialna verzija
KEYPROT    : zascita s kljucem
DATEPROT   : datumska omejitev veljavnosti

Spremenljivke za linkanje razlicnih knjiznic z inverseom:
OTHERMAIN  : Program Inverse nima main-a (ker se linka s knjiznico, ki ima main)
  
Spremenljivke za vkljucitev razlicnih vmesnikov z analizami:
ELFINT     : direkten vmesnih z Elfenom
EMELFINT   : emulacija direktnega vmesnika z Elfenom.

*/



/****************** ODVISNE SPREMENLJIVKE: ********************/


/* V primeru, da prevajamo z GNU C-jem na widowsih, je potrebno vkljuciti UNIX-ove
definicije namesto DOS-ovih (makro GCC mora biti definiran preko ukazne vrstice, s
katero pozenomo prevajalnik, npr. z opcijo -DGCC): */

#ifdef GCC
  #undef WN16
  #undef WN32
  #undef WNDWOS
  #undef DOS
  #undef DOSWN
  #undef VISUALC
  #define UNIX
#endif





#ifdef WN16
#define WNDOWS /* Windows na PC-ju */
#endif
#ifdef WN32
#define WNDOWS
#endif
#ifdef DOS
#define DOSWN
#endif
#ifdef WNDOWS
#define DOSWN
#endif


#ifdef LINUX
#define UNIX
#endif
#ifdef HPUNIX
#define UNIX
#endif

#ifdef DOS
#define DOSSYNTAX
#endif
#ifdef WN16
#define DOSSYNTAX
#endif
#ifdef WN32
#define DOSSYNTAX
#endif
#ifdef WNDOWS
#define DOSSYNTAX
#endif

#ifdef BC3
#define BC
#endif

#ifdef BC5
#define BC
#endif

#ifdef BC
#define MANARG /* branje argumentov s standardnega vhoda */
#endif


/* Definiramo GRTCL, ce ni druge grafike: */
#define GRTCL

#ifdef GRX
#undef GRTCL
#endif

#ifdef GRPEX
#undef GRTCL
#endif

#ifdef GRBGI
#undef GRTCL
#endif


/******************* SISTEMSKE ODVISNOSTI: *******************/





#ifdef WNDOWS
#include <windows.h>
#endif


/* Borlandov C++3.x: */
#ifdef BC3
extern unsigned _floatconvert;
#pragma extref _floatconvert
#include <alloc.h>
#endif


#ifdef WN16
#define system replacementforsysteminWN16
#endif

#ifdef VISUALC
void sleep(int);
#endif


#ifdef CFSQP
#ifdef __STDC__
void    grobfd(int,int,double *,double *,void (*)(int,int,
               double *,double *,void *),void *);
void    grcnfd(int,int,double *,double *,void (*)(int,int,
               double *,double *,void *),void *);
#else
void    grobfd();
void    grcnfd();
#endif
#endif


/******************* RAZLICNE VERZIJE: *******************/


#ifdef COMMERCIAL
 #define KEYPROT
#endif

#ifdef SHAREWARE
 #undef KEYPROT
#endif

#ifdef DEMO
 #define DATEPROT
#endif

#ifndef DATEPROT
  #define KEYPROT
#endif


/******************* LINKANJE Z RAZLICNIMI KNJIZNICAMI: *******************/

#ifdef EMELFINT
  #define ELFINT
#endif
#ifdef ELFINT
  #define OTHERMAIN
#endif
