


                    /*********************/
                    /*                   */
                    /*  ELFENOV VMESNIK  */
                    /*                   */
                    /*********************/


int invmain(int numargs, char *argv[],char *env[]);  /* definicija je v invan.h */


/* INSTALACIJA VMESNIKA : */

void installelfeninterface(void);
    /* Funkcija, ki instalira direktni vmesnik z Elfenom.
    $A Igor dec99; */


/* FUNKCIJE POSEBEJ ZA ELFINT */

#ifdef ELFINT
  /* Funkcija za instalacijo funkcije, ki se izvrsi ob razlicnih dogodkih
  definiranih v Elfenu: */
  extern void define_elfendyn_user_interrupt_function(int (*func) (const char * message));

  /* Funkcija za dostop do Elfenove podatkovne baze: */
  extern void * elfendyn_database_entry_new(const char * recname,int recnum,const char *arrayname,
         char *datatype,int *arraydim);
  
  /* Funkcija, s katero se pozene Elfenova analiza: */ 
  extern void ELFRUN(void);

  /* Funkcija za ekstrakcijo argumentov iz ukazne vrstice: */
  void get_optimisation_shell_arguments_new(int *nargs,char ***argv);
#endif  /* #ifdef ELFINT */


/*ostale funkcije so NEODVISNE od ELFINT oz. EMELFINT,
ali pa imajo odvisnost vgrajeno v funkciji*/

static void readprogargself(int *numargs,char ***argvp,int from,int to);

int FORT_DECL RUN_INVERSE(void);
    /* Funkcija, ki jo klice Elfen in  ki pozene Inverse.
    $A Igor dec99; */













