

#include <st.h>
#include <vec.h>
#include <mat.h>
#include <fint.h>
#include <simb.h>



            /**********************************************/
            /*                                            */
            /*  OPERACIJE NAD SPREMENLJIVKAMI V PROGRAMU  */
            /*                  INVERSE                   */
            /*                                            */
            /**********************************************/



   /* SPLOSNE FUNKCIJE: */





            /******************************************/
            /*                                        */
            /*  POMOZNE SPREMENLJIVKE IN FUNKCIJE ZA  */
            /*      OPERACIJE NAD SPREMENLJIVKAMI     */
            /*                                        */
            /******************************************/


int invcheckvartype(varholder var,char *typespec);
    /* Vrne pozitivno stevilo (ki ustreza zap. stevilki tipa spremenljivke,
    ki je v var), ce spremenljivka v var ustreza tipu, ki je dolocen z nizom
    typespec. Ce spremenljivka var ni tipa, ki je dolocen s typespec, vrne
    funkcija 0. typespec je lahko tudi "any" ali "default", v tem primeru vrne
    funkcija celi ekvivalent dejanskega tipa spremenljivke.
    $A Igor sep01; */

int invvartype(char *typespec);
    /* Vrne celi ekvivalent tipa spremenljivke, ki ga oznacuje typespec.
    Vrnjena vrednost se lahko neposredno uporabi pri postavljanju ali
    preverjanju tipov spremenljivk.
    $A Igor okt01; */

int invsetvartype(varholder var,char *typespec);
    /* Postavi tip spremenljivke var glede na typespec in vrne celo st., ki
    ustreza temu tipu. Tipicno se rezultata, ki ga funkcija vrne, ne uporabi,
    lahko pa sluzi za kontrolo, ker ima vrednost manj kot 1, ce je prislo do
    napake (npr. ce niz typespec ne doloca znanega tipa).
    $A Igor sep01; */

void * invdispvarel (int type);
    /* Vrne funkcijo, ki zbrise (dealocira) posamezen element spremenljivke in
    njegov kazalec postavi na NULL, glede na tip type. Funkcijo vrne kot
    kazalec tipa void *, tako da je navadno treba ob uporabi izvesti kast na
    tip (void (*) (void **)).
    $A Igor okt01; */

void invdispvarholder(varholder *var);
    /* Zbrise nosilec spremenljivke *var z vsemi elementi ter postavi *var na
    NULL. Funkcija za brisanje elementov nosilca se doloci glede na tip
    spremenljivke (*var)->type.
    $A Igor sep01 okt01; */



double uservarcomponent(object obj,stack st,stack user,int numargs,
               void *ptr);
    /* Funkcija sistema za ovrednotenje izrazov. Vrne komponento spremenljivke,
    ki je trenutno v obdelavi z eno od funkcij, ki iterirajo po komponentah
    spremenljivk in pri tem uporabljajo sistem za ovrednotenje izrazov, npr.
    fi_setvectorcomponents(). Ustrez. funkcija sistema za ovrednotenje izrazov
    zahteva en sam argument, ki je lahko 0 (v tem primeru vrne funkcija stevilo
    dimenzij spremenljivke oz. rang, npr. 1 pri vektorskih spremenljivkah in 2
    pri matricnih) ali ima pozitivno vrednost, v tem primeru funkcija vrne
    ustrezno komponento spremenljivke (npr. ce je v obdelavi matrika in je
    argument 1, vrne funkcija vrstico elementa matrike, ki je trenutno v
    obdelavi, ce pa je vrednost argumenta 2, vrne stolpec elementa, ki je v
    tistem trenutku v obdelavi). Podatke o tem, katera komponenta spremenljivke
    je trenutno v obdelavi, dobi funkcija s sklada varcmponent. Vrednosti na
    tem skladu postavljajo funkcije, ki izvajajo operacije na komponentah
    spremenljivk, zato je lahko ta funkcija klicana le v casu, ko se izvaja
    taksna funkcija (npr. fi_setvectorcomponents()). Drugace vrednost, ki jo
    funkcija vrne, nima pomena.
    $A Igor mar98; */

double uservarindex(object obj,stack st,stack user,int numargs,
               void *ptr);
    /* Funkcija sistema za ovrednotenje izrazov. Vrne indeks elemenda nosilca
    spremenljivke, ki je trenutno v obdelavi z eno od funkcij, ki iterirajo po
    elementih spremenljivk in pri tem uporabljajo sistem za ovrednotenje
    izrazov, npr. fi_setvectorcomponents(). Ustrez. funkcija sistema za
    ovrednotenje izrazov zahteva en sam argument, ki je lahko 0 (v tem primeru
    vrne funkcija stevilo dimenzij oz. rang nosilca spremenljivke) ali ima
    pozitivno vrednost, v tem primeru funkcija vrne ustrezen indeks elementa
    v obdelavi na nosilcu spremenljivke Na primer, ce je v obdelavi element
    z indeksi [3,1,2] na nosilcu ustrezne spremenljivke in je ustrezna funkcija
    kalkulatorja klicana z argumentom, ki ima vrednost 2, vrne ta funkcija 1.
    Podatke o tem, kateri element nosilca spremenljivke je trenutno v obdelavi,
    dobi funkcija s sklada varelementindex. Vrednosti na tem skladu postavljajo
    funkcije, ki izvajajo operacije na skupinah elementov spremenljivk, zato je
    lahko ta funkcija klicana le v casu, ko se izvaja taksna funkcija (npr.
    fi_setvectorcomponents()). Drugace vrednost, ki jo funkcija vrne, nima
    pomena.
    $A Igor mar98; */



                  /******************************/
                  /*                            */
                  /*   OPERACIJE NAD VEKTORJI   */
                  /*                            */
                  /******************************/



/* OPERACIJE NAD VEKTORJI: OSNOVNE FUNKCIJE */


int updatevecvar(char *name,int place);
    /* Ce je name ime preddefinirane vektorske spremenljivke, opravi vse
    potrebno, da je vektorska spremenljivka definirana in ima ustrezne
    dimenzije. Funkcija se na primer uporablja pred branjem ektorske
    spremenljivke zato, da pri preddefinirani spremenljivki ni potrebno navesti
    dimenzije le-te.
      POMEMBNA LASTNOST, ki velja za vse spremenljivke, ne le preddefinirane:
     Z argumentom place lahko funkciji povemo, na katerem mestu je
    spremenljivka z imenom name na skladu com.vec. Ce je place manj kot 1,
    potem funkcija sama poisce spremenljivko. To naredi tudi, ce je place
    napacen (ce na mestu place na skladu com.vec ni spremenljivke z imenom
    name). Funkcija vrne mesto, na katerem je spremenljivka z imenom name na
    skladu com.vec po izvedbi funkcije, ali 0, ce taksne spremenljivke po
    izvedbi funkcije ni na skladu.
    $A Igor maj98; */

varholder updatevecdata(char *name,int place);
    /* Ce je name ime preddefinirane vektorske spremenljivke, postavi
    spremenljivke, ki so odvisne od te spremenljivke, na prave vrednosti.
    Funkcija se uporablja npr. po branju vektorske spremenljivke, da se
    avtomatsko nastavi npr. dimenzija skupine preddefiniranih vektorjev po
    branju vektorja, ki pripada tej skupini. Funkcija vrne kazalec na objekt
    tipa varholder, ki predstavlja vektor z imenom name na skladu com.vec (ce
    spremenljivke z imenom name ni na temskladu, vrne funkcija NULL).
      POMEMBNA LASTNOST, ki velja za vse spremenljivke, ne le preddefinirane:
     Z argumentom place lahko funkciji povemo, na katerem mestu je
    spremenljivka z imenom name na skladu com.vec. Ce je place manj kot 1,
    potem funkcija sama poisce spremenljivko. To naredi tudi, ce je place
    napacen (ce na mestu place na skladu com.vec ni spremenljivke z imenom
    name).
    $A Igor maj98; */

varholder updatevecdata1(char *name,int place);
    /* Podobno kot updatevecdata, le da ne vzame argumenta, ki bi povedal
    funkciji, na katerem mestu na skladu com.vec je spremenljivka z imenom
    name.
    $A Igor maj98; */


/* NOVE OPERACIJE NAD VEKTORJI: INSTALIRANE FUNKCIJE */


/* OPERACIJE NAD CELIMI NOSILCI VEKTORSKIH SPREMENLJIVK: */

void fi_newvector(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki na sklad com.vec doda nov
    nosilec vektorske spremenljivke z imenom in dimenzijami, kot jih dolocajo
    argumenti funkcije. Ce nosilec z damin imenom ze obstaja, se le-ta zbrise
    (skupaj z elementi - vektorji), na njegovo mesto se postavi na novo
    tvorjeni nosilec.
    $A Igor feb98; */

void fi_dimvector(ficom fcom);
    /* Funkicija datotecnega interpreterja, ki nastavi dimenzije nosilca
    vektorske spremenljivke. Ce na skladu com.vec se ne obstaja nosilec s
    podanim imenom, se ta tvori na novo in se vrine na ustrezno mesto sklada.
    Ce nosilec ze obstaja, se pusti nedtaknjen, ce so njegove dimenzije enake
    dimenzijam dolocenim z argumenti, drugace pa se zbrise z elementi (vektorji
    vred) in tvori na novo.
    $A Igor feb98; */

void fi_fprintvectorvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    vektorske spremenljivke, katere ime je edini argument funkcije, v izhodno
    datoteko.
    $A Igor feb98; */

void fi_printvectorvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    vektorske spremenljivke, katere ime je edini argument funkcije, na
    standardni izhod.
    $A Igor feb98; */

void fi_dprintvectorvar(ficom fcom);
    /* Podobno kot fi_printvectorvar, le da izpisuje tako na izhodno datoeko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_deletevectorvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki zbrise celotno vektorsko
    spremenljivko (nosilec z vsemi vrednostmi vred), katere ime je edini
    argument funkcije.
    $A Igor feb98; */

void fi_movevectorvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki premakne vektorsko spremenljivko
    (nosilec z vsemi vrednostmi vred) z danim imenom v vektorsko spremenljivko
    z drugim imenom. Imeni sta argumenta funkcije dat. interpreterja ob klicu.
    Ce spremenljivka z drugim imenom ze obstaja, se le-ta najprej zbrise. Po
    operaciji vektorska spremenljivka s 1. imenom ni vec definirana.
    $A Igor feb98; */

/* BRANJE VEKTORJA IZ UKAZNE DATOTEKE: */

void fi_setvector(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki prebere vektor v ukazni datoteki.
    1. argument mora biti ime vektorja, 2. pa (ce je rang vektorske
    spremenljivke z danim imenom vecji od 0) indeksna specifikacija v oglatih
    oklepajih, ki pove, za kateri element vektorske spremenljivke gre.
    $A Igor feb98; */

void fi_initvector(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki inicializira podtabelo elementov
    vektorske spremenljivke. 1. argument mora biti ime vektorja, 2. pa (ce je
    rang vektorske spremenljivke z danim imenom vecji od 0) indeksna
    specifikacija tabele oz. elementa v oglatih oklepajih. Tretji argument so
    vrednosti, na katere se inicializirajo elementi vektorja.
    $A Igor dec98; */

void fi_deletevector(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki brise podtabelo elementov
    vektorske spremenljivke. 1. argument mora biti podtabele vektorjev, ki je
    sestavljena iz imena vektorske spremenljivke, ki mu opcijsko sledijo indeksi
    podtabele (oz. elementa) v oglatih oklepajih.
    $A Igor jan99; */


/* IZPIS POSAMEZNIH VEKTORJEV ALI SKUPIN VEKTORJEV: */



void fi_fprintvector(ficom fcom);
    /* V izhodno datoteko programa se izpise element ali skupina elementov
    vektorske spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis vektorjev se uporabi
    funkcija fprintvectorelement(), ki klice funkcijo fprintvector().
    $A Igor mar98; */


void fi_printvector(ficom fcom);
    /* Na standardni izhod se izpise element ali skupina elementov
    vektorske spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis vektorjev se uporabi
    funkcija fprintvectorelement(), ki klice funkcijo fprintvector().
    $A Igor mar98; */


void fi_dprintvector(ficom fcom);
    /* podobno kot fi_printvector, le da izpisuje tako v izhodno datoteko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_setvectorcomponents(ficom fcom);
    /* Postavi vse komponente vektorjev, ki jih doloca specifikacija, na
    vrednost matematicnega izraza, ki se izracuna v sistemu fcom->syst.
    Specifikacija vektorjev (t.j. ime vektorske spremenljivke in indeksi, ki
    dolocajo elemente, nad katerimi se izvede operacija) ter matematicni izraz
    sta argumenta ustrezne funkcije datotecnega interpreterja.
    $A Igor mar98; */

void fi_setveccompcond(ficom fcom);
    /* Postavi vse komponente vektorjev, ki jih doloca specifikacija in pri
    katerih je vrednost pogoja razlicna od 0, na vrednost matematicnega izraza,
    ki se izracuna v sistemu fcom->syst. Specifikacija vektrja (t.j. ime
    vektorske spremenljivke in indeksi, ki dolocajo elemente, nad katerimi se
    izvede operacija) je prvi argument ustrezne funkcije datotecnega 
    interpreterja. Pogoj v okroglih oklepajih je drugi argument, tretji pa
    matematicni izraz, katerega vrednost se priredi komponentam.
    $A Igor dec98; */


/* UNARNE OPERACIJE NAD VEKTORJI: */



void fi_copyvector(ficom fcom);
    /* Kopiranje vektorjev; Operacija se izvede s pomocjo funkcije unvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh vektorjev (ali skupin vektorjev), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor mar98; */

void fi_movevector(ficom fcom);
    /* Premikanje vektorjev; Operacija se izvede s pomocjo funkcije unvaropch().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh vektorjev (ali skupin vektorjev), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvaropch().
    $A Igor mar98; */

/* BINARNE OPERACIJE NAD VEKTORJI: */



void fi_vectorsum(ficom fcom);
    /* Sestevanje vektorjev; Operacija se izvede s pomocjo funkcije binvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh vektorjev (ali skupin vektorjev), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo binvarop().
    $A Igor mar98; */

void fi_vectordif(ficom fcom);
    /* Odstevanje vektorjev; Operacija se izvede s pomocjo funkcije binvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh vektorjev (ali skupin vektorjev), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo binvarop().
    $A Igor mar98; */




                  /*******************************/
                  /*                             */
                  /*   OPERACIJE NAD MATRIKAMI   */
                  /*                             */
                  /*******************************/



varholder updatematdata(char *name,int place);
    /* Ce je name ime preddefinirane matricne spremenljivke, postavi
    spremenljivke, ki so odvisne od te spremenljivke, na prave vrednosti.
    Funkcija se uporablja npr. po branju matricne spremenljivke, da se
    avtomatsko nastavi npr. dimenzija skupine preddefiniranih matrik po
    branju matrike, ki pripada tej skupini. Funkcija vrne kazalec na objekt
    tipa varholder, ki predstavlja matriko z imanom name na skladu com.mat
    (ce spremenljivke z imenom name ni na tem skladu, vrne funkcija NULL).
      POMEMBNA LASTNOST, ki velja za vse spremenljivke, ne le preddefinirane:
     Z argumentom place lahko funkciji povemo, na katerem mestu je
    spremenljivka z imenom name na skladu com.mat. Ce je place manj kot 1,
    potem funkcija sama poisce spremenljivko. To naredi tudi, ce je place
    napacen (ce na mestu place na skladu com.mat ni spremenljivke z imenom
    name).
    $A Igor maj98; */

varholder updatematdata1(char *name,int place);
    /* Podobno kot updatematdata, le da ne vzame argumenta, ki bi povedal
    funkciji, na katerem mestu na skladu com.mat je spremenljivka z imenom
    name.
    $A Igor maj98; */


/* NOVE OPERACIJE NAD MATRIKAMI: INSTALIRANE FUNKCIJE */


/* OPERACIJE NAD CELIMI NOSILCI MATRICNIH SPREMENLJIVK: */

void fi_newmatrix(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki na sklad com.mat doda nov
    nosilec matricne spremenljivke z imenom in dimenzijami, kot jih dolocajo
    argumenti funkcije. Ce nosilec z damin imenom ze obstaja, se le-ta zbrise
    (skupaj z elementi - matrikami), na njegovo mesto se postavi na novo
    tvorjeni nosilec.
    $A Igor mar98; */

void fi_dimmatrix(ficom fcom);
    /* Funkicija datotecnega interpreterja, ki nastavi dimenzije nosilca
    matricne spremenljivke. Ce na skladu com.mat se ne obstaja nosilec s
    podanim imenom, se ta tvori na novo in se vrine na ustrezno mesto sklada.
    Ce nosilec ze obstaja, se pusti nedtaknjen, ce so njegove dimenzije enake
    dimenzijam dolocenim z argumenti, drugace pa se zbrise z elementi (matrikami);
    vred in tvori na novo.
    $A Igor mar98; */

void fi_fprintmatrixvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    matricne spremenljivke, katere ime je edini argument funkcije, v izhodno
    datoteko.
    $A Igor mar98; */

void fi_printmatrixvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    matricne spremenljivke, katere ime je edini argument funkcije, na
    standardni izhod.
    $A Igor mar98; */

void fi_dprintmatrixvar(ficom fcom);
    /* Podobno kot fi_printmatrixvar, le da izpisuje tako na izhodno datoeko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_deletematrixvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki zbrise celotno matricno
    spremenljivko (nosilec z vsemi vrednostmi vred), katere ime je edini
    argument funkcije.
    $A Igor mar98; */

void fi_movematrixvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki premakne matricno spremenljivko
    (nosilec z vsemi vrednostmi vred) z danim imenom v matricno spremenljivko
    z drugim imenom. Imeni sta argumenta funkcije dat. interpreterja ob klicu.
    Ce spremenljivka z drugim imenom ze obstaja, se le-ta najprej zbrise. Po
    operaciji matricna spremenljivka s 1. imenom ni vec definirana.
    $A Igor mar98; */

/* BRANJE MATRIKE IZ UKAZNE DATOTEKE: */

void fi_setmatrix(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki prebere matriko v ukazni datoteki.
    1. argument mora biti ime matrike, 2. pa (ce je rang matricne
    spremenljivke z danim imenom vecji od 0) indeksna specifikacija v oglatih
    oklepajih, ki pove, za kateri element matricne spremenljivke gre.
    $A Igor mar98; */

void fi_initmatrix(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki inicializira podtabelo elementov
    matricne spremenljivke. 1. argument mora biti ime matrike, 2. pa (ce je
    rang matricne spremenljivke z danim imenom vecji od 0) indeksna
    specifikacija tabele oz. elementa v oglatih oklepajih. Tretji argument so
    vrednosti, na katere se inicializirajo elementi matrike.
    $A Igor dec98; */

void fi_deletematrix(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki brise podtabelo elementov
    matricne spremenljivke. 1. argument mora biti podtabele matrik, ki je
    sestavljena iz imena matricne spremenljivke, ki mu opcijsko sledijo indeksi
    podtabele (oz. elementa) v oglatih oklepajih.
    $A Igor jan99; */



/* IZPIS POSAMEZNIH MATRIK ALI SKUPIN MATRIK: */


void fi_fprintmatrix(ficom fcom);
    /* V izhodno datoteko programa se izpise element ali skupina elementov
    matricne spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis matrik se uporabi
    funkcija fprintmatrixlement(), ki klice funkcijo fprintmatrix().
    $A Igor mar98; */

void fi_printmatrix(ficom fcom);
    /* Na standardni izhod se izpise element ali skupina elementov
    matricne spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis matrik se uporabi
    funkcija fprintmatrixelement(), ki klice funkcijo fprintmatrix().
    $A Igor mar98; */

void fi_dprintmatrix(ficom fcom);
    /* podobno kot fi_printmatrix, le da izpisuje tako v izhodno datoteko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_setmatrixcomponents(ficom fcom);
    /* Postavi vse komponente matrik, ki jih doloca specifikacija, na
    vrednost matematicnega izraza, ki se izracuna v sistemu fcom->syst.
    Specifikacija matrike (t.j. ime matricne spremenljivke in indeksi, ki
    dolocajo elemente, nad katerimi se izvede operacija) ter matematicni izraz
    sta argumenta ustrezne funkcije datotecnega interpreterja.
    $A Igor mar98; */

void fi_setmatcompcond(ficom fcom);
    /* Postavi vse komponente matrik, ki jih doloca specifikacija in pri
    katerih je vrednost pogoja razlicna od 0, na vrednost matematicnega izraza,
    ki se izracuna v sistemu fcom->syst. Specifikacija matrike (t.j. ime
    matricne spremenljivke in indeksi, ki dolocajo elemente, nad katerimi se
    izvede operacija) je prvi argument ustrezne funkcije datotecnega 
    interpreterja. Pogoj v okroglih oklepajih je drugi argument, tretji pa
    matematicni izraz, katerega vrednost se priredi komponentam.
    $A Igor dec98; */



/* UNARNE OPERACIJE NAD MATRIKAMI: */


void fi_copymatrix(ficom fcom);
    /* Kopiranje matrik; Operacija se izvede s pomocjo funkcije unvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh matrik (ali skupin matrik), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor mar98; */

void fi_movematrix(ficom fcom);
    /* Premikanje matrik; Operacija se izvede s pomocjo funkcije unvaropch().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh matrik (ali skupin matrik), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvaropch().
    $A Igor mar98; */



/* BINARNE OPERACIJE NAD MATRIKAMI: */


void fi_matrixsum(ficom fcom);
    /* Vsota matrik; Operacija se izvede s pomocjo funkcije binvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh matrik (ali skupin matrik), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo binvarop().
    $A Igor mar98; */

void fi_matrixdif(ficom fcom);
    /* Razlika matrik; Operacija se izvede s pomocjo funkcije binvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh matrik (ali skupin matrik), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor mar98; */




            /******************************************/
            /*                                        */
            /*  FUNKCIJE ZA KOMPATIBILNOST S STARIMI  */
            /*  FUNKCIJAMI NAD VEKTORJI IN MATRIKAMI  */
            /*                   -                    */
            /*      POMOZNE FUNKCIJE ZA MATRIXOP      */
            /*                                        */
            /******************************************/



/* ISKANJE VEKTORSKIH SPREMENLJIVK PREKO NIZA, KI JIH DEFINIRA: */



vector * findvectornameall(char *spec,int *n,int **dim,char **outstr);
    /* Poisce vektor s specifikacijo spec ter vrne njegov naslov. Niz spec
    mora vsebovati ime vektorja in indekse v oglatih oklepajih (ti so lahko
    izpusceni, ce je rang ustrezne vektroske spremenljivke enak 0). Indeksi so
    lahko podani kot stevila, kot spremenljivke sistema za ovrednotenje izrazov
    (v tem primeru ime sledi znaku '$') ali kot izrazi, izracunljivi v sistemu
    za ovrednotenje izrazov (izraz moraj biti v zavitem oklepaju, ki sledi
    znaku '$'). Indeksi morajo biti loceni z vejicami ali s presledki.
      V *n zapise zaporedno stevilko uporabnisko definirqnega vektorja z danim
    imenom ali 0, ce vektorja ne najde. V *dim da funkcija naslov dimenzije
    vektorja, v *outstr pa zapise NULL. Nobenega od teh kazalcev se ne sme
    brisati s  free().
      Ce funkcija ne najde vektorja z danim imenom, vrne NULL. Funkcija je
    sluzi kompatibilnostnim namenom - narejena je za uporabo funkcij za
    ravnanje z vektorskimi spremenljivkami, ki so delale se po starem nacinu.
    $A Igor apr98; */

matrix * findmatrixnameall(char *spec,int *n,
                int **dim1,int **dim2,char **outstr);
    /* Poisce matriko s specifikacijo spec ter vrne njen naslov. Niz spec
    mora vsebovati ime matrike in indekse v oglatih oklepajih (ti so lahko
    izpusceni, ce je rang ustrezne matricne spremenljivke enak 0). Indeksi so
    lahko podani kot stevila, kot spremenljivke sistema za ovrednotenje izrazov
    (v tem primeru ime sledi znaku '$') ali kot izrazi, izracunljivi v sistemu
    za ovrednotenje izrazov (izraz moraj biti v zavitem oklepaju, ki sledi
    znaku '$'). Indeksi morajo biti loceni z vejicami ali s presledki.
      V *n zapise zaporedno stevilko uporabnisko definirqne matrike z danim
    imenom ali 0, ce matrike ne najde. V *dim1 in *dim2 da funkcija naslova
    dimenzij matrike, v *outstr pa zapise NULL. Nobenega od teh kazalcev se ne sme
    brisati s  free().
      Ce funkcija ne najde matrike z danim imenom, vrne NULL. Funkcija je
    sluzi kompatibilnostnim namenom - narejena je za uporabo funkcij za
    ravnanje z matricnimi spremenljivkami, ki so delale se po starem nacinu.
    $A Igor apr98; */



varholder adduservector(vector v,char *name);
    /* Vrne naslov nosilca vektorskih spremelivk z imenom name. Ce nosilec s
    tem imeno se ne obstaja, ga naredi na novo (ob tem ga tudi vrine na
    ustrezno mesto sklada com.vec in vrne kazalec nanj). Na nosilec da vektor
    v (na 1. mesto). Ce nosilec z danim imenom se ne obstaja, je na novo
    tvorjeni nosilec ranga 0. Funkcija sluzi za kompatibilnost s starimi
    funkcijami za ravnanje z vektorskimi spremenljivkami.
    $A Igor maj98; */

varholder addusermatrix(matrix m,char *name);
    /* Vrne naslov nosilca matricnih spremelivk z imenom name. Ce nosilec s
    tem imeno se ne obstaja, ga naredi na novo (ob tem ga tudi vrine na
    ustrezno mesto sklada com.mat in vrne kazalec nanj). Na nosilec da matriko
    m (na 1. mesto). Ce nosilec z danim imenom se ne obstaja, je na novo
    tvorjeni nosilec ranga 0. Funkcija sluzi za kompatibilnost s starimi
    funkcijami za ravnanje z matricnimi spremenljivkami.
    $A Igor maj98; */

void fi_matrixop(ficom fcom);
    /* Funkcija, ki izvaja matricne operacije. Funkcija se instalira v datotecni
    interpreter. Pri klicu funkcije v interpreterju morajo biti argumenti
    funkcije nizi, ki predstavljajo operatorje, in nizi, ki predstavljajo
    operande. Obvezno morajo biti loceni s presledki (ali prehodi v novo
    vrstico). Pri nizih, ki predstavljajo opreande, dolocata prvi dve crki vrsto
    operanda (in sicer "m_" za matriko, "v_" za vektor in "s_" za skalar).
    Skalarne vrednosti se priredijo spremenljivkam kalkulatorja. Izrazi morajo
    vedno biti podani v oklepajih.
      Mozne operacije, kot so lahko definirane v klicu funkcije (v primeru, da
    je ime funkcije v interpreterju "matop"):
    matop{m_m0 = m_m1 + m_m2} : matrika m0 postane vsota matrik m1 in m2
    matop{m_m0 = m_m1 - m_m2} : matrika m0 postane razlika matrik m1 in m2
    matop{v_v0 = v_v1 + v_v2} : vektor v0 postane vsota vektorjev v1 in v2
    matop{v_v0 = v_v1 - v_v2} : vektor v0 postane razlika vektorjev v1 in v2
    matop{m_m0 = m_m1 * m_m2} : matrika m0 postane produkt matrik m1 in m2
    matop{v_v0 = m_m1 * v_v2} : vektor v0 postane produkt matrike m1 in v1
    matop{s_s0 = v_v1 * v_v2} : skal. sprem. s0 postane skalar. prod. v1 in v2
    matop{m_m0 = m_m1 * {expr}} : m0 postane m1 pomnozena z vrednostjo izraza expr
    matop{v_v0 = v_v1 * {expr}} : v0 postane v1 pomnozen z vrednostjo expr
    matop{v_x = m_A solve v_b} : x postane resitev enacbe A x = b
    matop{m_m0 = transpose m_m1} : m0 postane transponirana matrika matrike m1
    matop{m_m0 = transpose v_v1} : m0 postane transponirana matrika vektorja v1
    matop{m_m0 = invert m_m1} : m0 postane inverzna matrika matrike m1
    matop{s_s0 = norm m_m1} : s0 postane norma (evklid.) matrike m1
    matop{s_s0 = norm v_v1} : s1 postane norma (evklid.) vektorja v1
    matop{m_m0 = normalize m_m1} : m0 postane normirana matrika m1
    matop{v_v0 = normalize v_v1} : v0 postane normiran vektor v1
    matop{m_m0 = identitymatrix {expr}} m0 postane ident. mat. dim. expr
    matop{m_m0 = zeromatrix {expr1} {expr2}} : m0 postane matrika s samimi
       niclami, vrednosti izrazov expr1 in expr2 podajata dimenzijo, ce je
       izraz en sam, je matrika kvadratna.
    matop{m_m0 = randommatrix {expr1} {expr2}} : m0 postane matrika dimenzije
       expr1*expr1 (ce je izraz en sam, postane kvadratna mat.) z nakljucnimi
       vrednostmi komponent med 0 in 1.
    matop{v_v0 = zerovector {expr}} : v postane nicelni vektor dimenzije expr
    matop{v_v0 = randomvector {expr}} : v0 postane vektor z nakljucnimi
       komponentami (med 0 in 1) dimenzije expr.
    $A Igor jul97 apr98; */




                  /******************************/
                  /*                            */
                  /*   OPERACIJE NAD SKALARJI   */
                  /*                            */
                  /******************************/




int updatescalvar(char *name,int place);
    /* Ce je name ime preddefinirane skalarne spremenljivke, opravi vse
    potrebno, da je ta skalarna spremenljivka definirana in ima ustrezne
    dimenzije. Funkcija se na primer uporablja pred branjem skalarne
    spremenljivke zato, da pri preddefinirani spremenljivki ni potrebno navesti
    dimenzije le-te.
      POMEMBNA LASTNOST, ki velja za vse spremenljivke, ne le preddefinirane:
     Z argumentom place lahko funkciji povemo, na katerem mestu je
    spremenljivka z imenom name na skladu com.scal. Ce je place manj kot 1,
    potem funkcija sama poisce spremenljivko. To naredi tudi, ce je place
    napacen (ce na mestu place na skladu com.scal ni spremenljivke z imenom
    name). Funkcija vrne mesto, na katerem je spremenljivka z imenom name na
    skladu com.scal po izvedbi funkcije, ali 0, ce taksne spremenljivke po
    izvedbi funkcije ni na skladu.
    $A Igor maj98; */

varholder updatescaldata(char *name,int place);
    /* Ce je name ime preddefinirane skalarne spremenljivke, postavi
    spremenljivke, ki so odvisne od te spremenljivke, na prave vrednosti.
    Funkcija se uporablja npr. po branju skalarne spremenljivke. Funkcija vrne
    kazalec na objekt tipa varholder, ki predstavlja skalar z imanom name na
    skladu com.scal (ce spremenljivke z imenom name ni na tem skladu, vrne
    funkcija NULL).
      POMEMBNA LASTNOST, ki velja za vse spremenljivke, ne le preddefinirane:
     Z argumentom place lahko funkciji povemo, na katerem mestu je
    spremenljivka z imenom name na skladu com.scal. Ce je place manj kot 1,
    potem funkcija sama poisce spremenljivko. To naredi tudi, ce je place
    napacen (ce na mestu place na skladu com.scal ni spremenljivke z imenom
    name).
    $A Igor maj98; */

varholder updatescaldata1(char *name,int place);
    /* Podobno kot updatescaldata, le da ne vzame argumenta, ki bi povedal
    funkciji, na katerem mestu na skladu com.scal je spremenljivka z imenom
    name.
    $A Igor maj98; */


 void fprintscalarline(FILE *fp,scalar scal);
    /* Izpise skalar scal v datoteko fp.
    $A Igor maj98; */

void printscalarline(scalar scal);
    /* Izpise skalar scal na stand. izhod.
    $A Igor maj98; */

void fprintscalar(FILE *fp,scalar scal);
    /* Izpise skalar scal v datoteko fp.
    $A Igor maj98; */

void printscalar(scalar scal);
    /* Izpise skalar scal na stand. izhod.
    $A Igor maj98; */



/* NOVE OPERACIJE NAD SKALARJI: INSTALIRANE FUNKCIJE */


/* OPERACIJE NAD CELIMI NOSILCI SKALARNIH SPREMENLJIVK: */

void fi_newscalar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki na sklad com.scal doda nov
    nosilec skalarne spremenljivke z imenom in dimenzijami, kot jih dolocajo
    argumenti funkcije. Ce nosilec z damin imenom ze obstaja, se le-ta zbrise
    (skupaj z elementi - skalarji), na njegovo mesto se postavi na novo
    tvorjeni nosilec.
    $A Igor feb98; */

void fi_dimscalar(ficom fcom);
    /* Funkicija datotecnega interpreterja, ki nastavi dimenzije nosilca
    skalarne spremenljivke. Ce na skladu com.scal se ne obstaja nosilec s
    podanim imenom, se ta tvori na novo in se vrine na ustrezno mesto sklada.
    Ce nosilec ze obstaja, se pusti nedtaknjen, ce so njegove dimenzije enake
    dimenzijam dolocenim z argumenti, drugace pa se zbrise z elementi (skalarji
    vred) in tvori na novo.
    $A Igor feb98; */

void fi_fprintscalarvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    skalarne spremenljivke, katere ime je edini argument funkcije, v izhodno
    datoteko.
    $A Igor feb98; */

void fi_printscalarvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    skalarne spremenljivke, katere ime je edini argument funkcije, na
    standardni izhod.
    $A Igor feb98; */

void fi_dprintscalarvar(ficom fcom);
    /* Podobno kot fi_printscalarvar, le da izpisuje tako na izhodno datoeko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_deletescalarvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki zbrise celotno skalarno
    spremenljivko (nosilec z vsemi vrednostmi vred), katere ime je edini
    argument funkcije.
    $A Igor feb98; */

void fi_movescalarvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki premakne skalarno spremenljivko
    (nosilec z vsemi vrednostmi vred) z danim imenom v skalarno spremenljivko
    z drugim imenom. Imeni sta argumenta funkcije dat. interpreterja ob klicu.
    Ce spremenljivka z drugim imenom ze obstaja, se le-ta najprej zbrise. Po
    operaciji skalarno spremenljivka s 1. imenom ni scal definirana.
    $A Igor feb98; */

/* BRANJE SKALARJA IZ UKAZNE DATOTEKE: */

void fi_setscalar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki prebere skalar v ukazni datoteki.
    1. argument mora biti ime skalarja, 2. pa (ce je rang skalarne
    spremenljivke z danim imenom scalji od 0) indeksna specifikacija v oglatih
    oklepajih, ki pove, za kateri element skalarne spremenljivke gre.
    $A Igor feb98; */

void fi_initscalar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki inicializira podtabelo elementov
    skalarne spremenljivke. 1. argument mora biti ime skalarja, 2. pa (ce je
    rang skalarne spremenljivke z danim imenom vecji od 0) indeksna
    specifikacija tabele oz. elementa v oglatih oklepajih. Tretji argument so
    vrednosti, na katere se inicializirajo elementi skalarja.
    $A Igor dec98; */

void fi_deletescalar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki brise podtabelo elementov
    skalarne spremenljivke. 1. argument mora biti podtabele skalarjev, ki je
    sestavljena iz imena skalarne spremenljivke, ki mu opcijsko sledijo indeksi
    podtabele (oz. elementa) v oglatih oklepajih.
    $A Igor jan99; */

void fi_fprintscalar(ficom fcom);
    /* V izhodno datoteko programa se izpise element ali skupina elementov
    skalarne spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis skalarjev se uporabi
    funkcija fprintscalarelement(), ki klice funkcijo fprintscalar().
    $A Igor maj98; */

void fi_printscalar(ficom fcom);
    /* Na standardni izhod se izpise element ali skupina elementov
    skalarne spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis skalarjev se uporabi
    funkcija fprintscalarelement(), ki klice funkcijo fprintscalar().
    $A Igor maj98; */

void fi_dprintscalar(ficom fcom);
    /* podobno kot fi_printscalar, le da izpisuje tako v izhodno datoteko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_setscalarcomponents(ficom fcom);
    /* Postavi vse komponente skalarjev, ki jih doloca specifikacija, na
    vrednost matematicnega izraza, ki se izracuna v sistemu fcom->syst.
    Specifikacija skalarjev (t.j. ime skalarne spremenljivke in indeksi, ki
    dolocajo elemente, nad katerimi se izvede operacija) ter matematicni izraz
    sta argumenta ustrezne funkcije datotecnega interpreterja.
    $A Igor maj98; */

void fi_setscalcompcond(ficom fcom);
    /* Postavi vse komponente skalarjev, ki jih doloca specifikacija in pri
    katerih je vrednost pogoja razlicna od 0, na vrednost matematicnega izraza,
    ki se izracuna v sistemu fcom->syst. Specifikacija sklrj (t.j. ime
    skalarne spremenljivke in indeksi, ki dolocajo elemente, nad katerimi se
    izvede operacija) je prvi argument ustrezne funkcije datotecnega 
    interpreterja. Pogoj v okroglih oklepajih je drugi argument, tretji pa
    matematicni izraz, katerega vrednost se priredi komponentam.
    $A Igor dec98; */


/* UNARNE OPERACIJE NAD SKALARJI: */



void fi_copyscalar(ficom fcom);
    /* Kopiranje skalarjev; Operacija se izvede s pomocjo funkcije unvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh skalarjev (ali skupin skalarjev), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor maj98; */

void fi_movescalar(ficom fcom);
    /* Premikanje skalarjev; Operacija se izvede s pomocjo funkcije unvaropch().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh skalarjev (ali skupin skalarjev), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvaropch().
    $A Igor maj98; */


/* BINARNE OPERACIJE NAD SKALARJI: */


void fi_scalarsum(ficom fcom);
    /* Sestevanje skalarjev; Operacija se izvede s pomocjo funkcije binvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh skalarjev (ali skupin skalarjev, ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor maj98; */

void fi_scalardif(ficom fcom);
    /* Odstevanje skalarjev; Operacija se izvede s pomocjo funkcije binvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh skalarjev (ali skupin skalarjev, ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor maj98; */





                  /******************************/
                  /*                            */
                  /*     OPERACIJE NAD NIZI     */
                  /*                            */
                  /******************************/



varholder updatestrdata(char *name,int place);
    /* Ce je name ime preddefinirane nizovne spremenljivke, postavi
    spremenljivke, ki so odvisne od te spremenljivke, na prave vrednosti.
    Funkcija se uporablja npr. po branju nizovne spremenljivke. Funkcija vrne
    kazalec na objekt tipa varholder, ki predstavlja niz z imanom name na
    skladu com.str (ce spremenljivke z imenom name ni na tem skladu, vrne
    funkcija NULL).
      POMEMBNA LASTNOST, ki velja za vse spremenljivke, ne le preddefinirane:
     Z argumentom place lahko funkciji povemo, na katerem mestu je
    spremenljivka z imenom name na skladu com.str. Ce je place manj kot 1,
    potem funkcija sama poisce spremenljivko. To naredi tudi, ce je place
    napacen (ce na mestu place na skladu com.str ni spremenljivke z imenom
    name).
    $A Igor jun99; */

varholder updatestrdata1(char *name,int place);
    /* Podobno kot updatestrdata, le da ne vzame argumenta, ki bi povedal
    funkciji, na katerem mestu na skladu com.str je spremenljivka z imenom
    name.
    $A Igor jun99; */



/* NOVE OPERACIJE NAD NIZI: INSTALIRANE FUNKCIJE */


/* OPERACIJE NAD CELIMI NOSILCI NIZOVNIH SPREMENLJIVK: */

void fi_newstring(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki na sklad com.str doda nov
    nosilec nizovne spremenljivke z imenom in dimenzijami, kot jih dolocajo
    argumenti funkcije. Ce nosilec z damin imenom ze obstaja, se le-ta zbrise
    (skupaj z elementi - nizi), na njegovo mesto se postavi na novo
    tvorjeni nosilec.
    $A Igor jun99; */

void fi_dimstring(ficom fcom);
    /* Funkicija datotecnega interpreterja, ki nastavi dimenzije nosilca
    nizovne spremenljivke. Ce na skladu com.str se ne obstaja nosilec s
    podanim imenom, se ta tvori na novo in se vrine na ustrezno mesto sklada.
    Ce nosilec ze obstaja, se pusti nedtaknjen, ce so njegove dimenzije enake
    dimenzijam dolocenim z argumenti, drugace pa se zbrise z elementi (nizi
    vred) in tvori na novo.
    $A Igor jun99; */

void fi_fprintstringvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    nizovne spremenljivke, katere ime je edini argument funkcije, v izhodno
    datoteko.
    $A Igor jun99; */

void fi_printstringvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    nizovne spremenljivke, katere ime je edini argument funkcije, na
    standardni izhod.
    $A Igor jun99; */

void fi_dprintstringvar(ficom fcom);
    /* Podobno kot fi_printstringvar, le da izpisuje tako na izhodno datoeko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_deletestringvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki zbrise celotno nizovno
    spremenljivko (nosilec z vsemi vrednostmi vred), katere ime je edini
    argument funkcije.
    $A Igor jun99; */

void fi_movestringvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki premakne nizovno spremenljivko
    (nosilec z vsemi vrednostmi vred) z danim imenom v nizovno spremenljivko
    z drugim imenom. Imeni sta argumenta funkcije dat. interpreterja ob klicu.
    Ce spremenljivka z drugim imenom ze obstaja, se le-ta najprej zbrise. Po
    operaciji nizovno spremenljivka s 1. imenom ni str definirana.
    $A Igor jun99; */



/* BRANJE NIZA IZ UKAZNE DATOTEKE: */

void fi_setstring(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki prebere niz v ukazni datoteki.
    1. argument mora biti ime niza, 2. pa (ce je rang nizovne
    spremenljivke z danim imenom strji od 0) indeksna specifikacija v oglatih
    oklepajih, ki pove, za kateri element nizovne spremenljivke gre.
    $A Igor jun99; */

void fi_initstring(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki inicializira podtabelo elementov
    nizovne spremenljivke. 1. argument mora biti ime niza, 2. pa (ce je
    rang nizovne spremenljivke z danim imenom vecji od 0) indeksna
    specifikacija tabele oz. elementa v oglatih oklepajih. Tretji argument so
    vrednosti, na katere se inicializirajo elementi niza.
    $A Igor jun99; */

void fi_deletestring(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki brise podtabelo elementov
    nizovne spremenljivke. 1. argument mora biti podtabele nizov, ki je
    sestavljena iz imena nizovne spremenljivke, ki mu opcijsko sledijo indeksi
    podtabele (oz. elementa) v oglatih oklepajih.
    $A Igor jun99; */


/* IZPIS POSAMEZNIH NIZOV ALI SKUPIN NIZOV: */


void fi_fprintstring(ficom fcom);
    /* V izhodno datoteko programa se izpise element ali skupina elementov
    nizovne spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis nizov se uporabi
    funkcija fprintstringelement(), ki klice funkcijo fprintstring().
    $A Igor jun99; */

void fi_printstring(ficom fcom);
    /* Na standardni izhod se izpise element ali skupina elementov
    nizovne spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis nizov se uporabi
    funkcija fprintstringelement(), ki klice funkcijo fprintstring().
    $A Igor jun99; */

void fi_dprintstring(ficom fcom);
    /* podobno kot fi_printstring, le da izpisuje tako v izhodno datoteko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_fprintstring0(ficom fcom);
    /* V izhodno datoteko programa se izpise element nizovne spremnljivke.
    Argumenta funkcije datotecnega interpreterja, s katero je povezana ta
    funkcija, morata biti ime spremenljivke in specifikacija elementa, ki naj
    se izpise. Izpise se samo niz brez vsakega spremnega besedila.
    $A Igor sep99; */

void fi_printstring0(ficom fcom);
   /* Na standardni izhod se izpise element nizovne spremnljivke. Argumenta
    funkcije datotecnega interpreterja, s katero je povezana ta funkcija,
    morata biti ime spremenljivke in specifikacija elementa, ki naj se
    izpise. Izpise se samo niz brez vsakega spremnega besedila.
    $A Igor sep99; */

void fi_dprintstring0(ficom fcom);
    /* V izhodno datoteko in na standardni izhod programa se izpise element
    nizovne spremnljivke. Argumenta funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, morata biti ime spremenljivke in
    specifikacija elementa, ki naj se izpise. Izpise se samo niz brez vsakega
    spremnega besedila.
    $A Igor sep99; */

void fi_fileprintstring0(ficom fcom);
    /* Funkcija interpreterja za zapis niza v datoteko. 1. argument ustrezne 
    funkcije interpreterja je specifikacija datoteke, v katero se niz zapise,
    drugi pa specifikacija niza. Datoteka, v katero se bo izpisal niz, mora
    fiti odprta.
    $A Igor nov99; */

void fi_setstringcomponents(ficom fcom);
    /* Postavi vse komponente nizov, ki jih doloca specifikacija, na
    vrednost matematicnega izraza, ki se izracuna v sistemu fcom->syst.
    Specifikacija nizov (t.j. ime nizovne spremenljivke in indeksi, ki
    dolocajo elemente, nad katerimi se izvede operacija) ter matematicni izraz
    sta argumenta ustrezne funkcije datotecnega interpreterja.
    $A Igor jun99; */

void fi_setstrcompcond(ficom fcom);
    /* Postavi vse komponente nizov, ki jih doloca specifikacija in pri
    katerih je vrednost pogoja razlicna od 0, na vrednost matematicnega izraza,
    ki se izracuna v sistemu fcom->syst. Specifikacija sklrj (t.j. ime
    nizovne spremenljivke in indeksi, ki dolocajo elemente, nad katerimi se
    izvede operacija) je prvi argument ustrezne funkcije datotecnega 
    interpreterja. Pogoj v okroglih oklepajih je drugi argument, tretji pa
    matematicni izraz, katerega vrednost se priredi komponentam.
    $A Igor jun99; */

void ficheck_stringwrite(ficom fcom);
    /* Pregled sintakse funkcije fi_stringwrite.
    $A Igor okt99; */

void fi_stringwrite(ficom fcom);
    /* Pisanje na niz. 1. argument ustrezne funkcije datotecnega interpreterja
    je specifikacija niza, na katerega se pise, ostali pa so enaki kot recimo
    pri fi_write(). Ce niz ze obstaja, se pred brisanjem zbrise in se nato
    naredi na novo. Ce nizovna spremenljivka z danim imenom ne obstaja in niso
    specifirani indeksi, se na novo tvori spremenljivka ranga 0 s tem imenom
    in operacija se izvede nad njo.
    Za pisanje se uporabi kar funkcija fi_write1(), ki najprej zapise vsebino
    v pomozno datoteko.
    $A Igor okt 99; */

void ficheck_stringappend(ficom fcom);
    /* Pregled sintakse funkcije fi_stringappend.
    $A Igor okt99; */

void fi_stringappend(ficom fcom);
    /* Pisanje na konec niza. 1. argument ustrezne funkcije datotecnega
    interpreterja je specifikacija niza, na katerega se pise, ostali pa so
    enaki kot recimo pri fi_write(). Ce niz ze obstaja, se zapisano prikljuci
    na koncu niza, drugace pa se niz z vsebino zapisanega na novo kreira. Ce
    nizovna spremenljivka z danim imenom ne obstaja in niso specifirani
    indeksi, se na novo tvori spremenljivka ranga 0 s tem imenom in operacija
    se izvede nad njo.
    Za pisanje se uporabi kar funkcija fi_write1(), ki najprej zapise vsebino
    v pomozno datoteko.
    $A Igor okt 99; */

void fi_numtostring(ficom fcom);
    /* Pretvori stevilo v niz. 1. argument ustrezne funkcije interpreterja je
    specifikacija niza, kamor se zapise prervorjen niz, 2. je stevilo, ki se
    pretvori, 3. pa je opcijski in pomeni stevilo decimalk, ki se zapisejo pri
    pretvorbi. Ce nizovna spremenljivka z danim imenom ne obstaja in niso
    specifirani indeksi, se na novo tvori spremenljivka ranga 0 s tem imenom in
    operacija se izvede nad njo. Ce niz pred izvedbo funkcije ze ima neko
    vrednost, se ta zbrise.
    $A Igor okt 99; */

void fi_appendnumtostring(ficom fcom);
    /* Pretvori stevilo v niz in ga prilepi na konec niza. Ce nizovna
    spremenljivka z danim imenom ne obstaja in niso specifirani indeksi, se na
    novo tvori spremenljivka ranga 0 s tem imenom in operacija se izvede nad
    njo.
    $A Igor okt 99; */

void fi_stringtonum(ficom fcom);
    /* Pretvorba niza v stevilo.1. argument ustrezne funkcije interpreterja je
    specifikacija niza, drugi pa ime spremenljivke kalkulatorja, kamor se
    shrane pretvorjeno stevilo.
    $A Igor okt 99; */



/* UNARNE OPERACIJE NAD NIZI: */



void fi_copystring(ficom fcom);
    /* Kopiranje nizov; Operacija se izvede s pomocjo funkcije unvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh nizov (ali skupin nizov), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor jun99; */

void fi_copystringpart(ficom fcom);
    /* Kopiranje delov nizov; Operacija se izvede s pomocjo funkcije unvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh nizov (ali skupin nizov), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    1. argument doloca tabelo nizov, katerih deli se kopirajo, 2. tabelo
    nizov, kamor se shranejo kopije, 3. in 4. agument pa sta stevilcna in
    dolocata, kateri del nizov se skopira (3. argument pove, od katerega znaka
    povrsti naprej se kopira, 4. pa, do (vkljucno) katerega znaka se kopira.
    Ce ni 4. argumenta, se niz skopira od zacetka do znaka, ki ga doloca 3.
    arhument. Ce ni 3. in 4. argumenta, se skopira cel niz. C3 j3 3. argument
    manj od 1 ali vec od dolzine niza, se kopira od zacetka niza, ce pa je 4.
    argument manj od 1 ali vec od dolzine niza, se kopira do konca niza.
    $A Igor jun99; */

void fi_movestring(ficom fcom);
    /* Premikanje nizov; Operacija se izvede s pomocjo funkcije unvaropch().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh nizov (ali skupin nizov, ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvaropch().
    $A Igor jun99; */


/* BINARNE OPERACIJE NAD NIZI: */


void fi_stringcat(ficom fcom);
    /* Lepljenje nizov; Operacija se izvede s pomocjo funkcije binvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh nizov (ali skupin nizov), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo binvarop().
    Zlepek nizov, ki ju dolocata prva dva argumenta, se shrani v nizovni
    element, ki je tretji argument. Tretji argument se lahko nanasa na isti
    nizovni element kot prvi ali drugi ali oba.
    $A Igor jun99; */




                  /******************************/
                  /*                            */
                  /*   OPERACIJE Z DATOTEKAMI   */
                  /*                            */
                  /******************************/






               /************************************/
               /*                                  */
               /*   FUNKCIJE SPOLOSNEGA VMESNIKA   */
               /*         Z DIREKTNO ANALIZO       */
               /*                                  */
               /************************************/


void fi_reportfileoperrorexcess(ficom fcom);
    /* Vkljuci ali izkljuci javljanje situacij, ko stevilo napak pri datotecnih
    operacijah naraste cez predpisano mejo in se prvih nekaj zabelezenih napak
    brise s sklada fileoperrors. Ustrezna funkcija interpreterja zahteva
    stevilski argument - ce je ta enak 0, se javljanje izkluci, drugace pa se
    vkjuci.
    $A Igor sep99; */

void fi_setfileopbuflength(ficom fcom);
    /* Funkcija interpreterja, ki nastavi dolzino vmesnega pomnilnika pri
    operacijah z datotekami. Edini argument je dolzina vmesnega pomnilnika.
    $A Igor jun98; */

void fi_fprintfileoperror(ficom fcom);
    /* V izhodno datoteko programa izpise porocilo o specificni napaki pri
    operacijah z datotekami. Ce je ustrezna funkcija interpreterja klicana
    brez argumentov, se izpise porocilo o uspesnosti zadnje izvedene operacije.
    Ce je vrednost argumenta 0, se izpise porocilo o vseh napakah, ki so
    zablezene na skladu fileoperrors. Ce je vrednost argumenta pozitivna, se
    izpise porocilo o napaki, katere zaporedna stevilka je vrednost argumenta,
    ce pa je negativna, se izpise porocilo o napaki, katere zaporedna stevilka
    od zadaj naprej je absolutna vrednost argumenta (ce absolutna vrednost
    argumenta v enem ali drugem primeru presega stevilo kod napak na skladu, se
    izpise porocilo o vseh zabelezenih napakah).
    $A Igor jun98; */

void fi_printfileoperror(ficom fcom);
    /* Podobno kot fi_fprintfileoperror, le da se porocilo izpise na standardni
    izhod.
    $A Igor jun98; */

void fi_dprintfileoperror(ficom fcom);
    /* V izhodno datoteko programa in na standardni izhod izpise porocilo o
    specificni napaki pri operacijah z datotekami. Ce je ustrezna funkcija
    interpreterja klicana brez argumentov, se izpise porocilo o uspesnosti
    zadnje izvedene operacije. Ce je vrednost argumenta 0, se izpise porocilo
    o vseh napakah, ki so zablezene na skladu fileoperrors. Ce je vrednost
    argumenta pozitivna, se izpise porocilo o napaki, katere zaporedna stevilka
    je vrednost argumenta, ce pa je negativna, se izpise porocilo o napaki,
    katere zaporedna stevilka od zadaj naprej je absolutna vrednost argumenta
    (ce absolutna vrednost argumenta v enem ali drugem primeru presega stevilo
    kod napak na skladu, se izpise porocilo o vseh zabelezenih napakah).
    $A Igor jul98; */

void fi_fwritefileoperror(ficom fcom);
    /* V izhodno datoteko programa izpise niz, ki ustreza specificni napaki pri
    operacijah z datotekami. Ce je ustrezna funkcija interpreterja klicana
    brez argumentov, se izpise niz za zadnjo izvedeno operacijo. Ce je vrednost
    argumenta pozitivna, se izpise niz za napako, katere zaporedna stevilka
    je vrednost argumenta, ce pa je negativna, se izpise niz, ki ustreza
    napaki, katere zaporedna stevilka od zadaj naprej je absolutna vrednost
    argumenta (ce absolutna vrednost argumenta v enem ali drugem primeru
    presega stevilo kod napak na skladu, se
    izpise niz "NULL", tako kot ce je vrednost argumenta nic).
    $A Igor jul98; */

void fi_writefileoperror(ficom fcom);
    /* Na standardni izhod izpise niz, ki ustreza specificni napaki pri
    operacijah z datotekami. Ce je ustrezna funkcija interpreterja klicana
    brez argumentov, se izpise niz za zadnjo izvedeno operacijo. Ce je vrednost
    argumenta pozitivna, se izpise niz za napako, katere zaporedna stevilka
    je vrednost argumenta, ce pa je negativna, se izpise niz, ki ustreza
    napaki, katere zaporedna stevilka od zadaj naprej je absolutna vrednost
    argumenta (ce absolutna vrednost argumenta v enem ali drugem primeru
    presega stevilo kod napak na skladu, se
    izpise niz "NULL", tako kot ce je vrednost argumenta nic).
    $A Igor jul98; */

void fi_dwritefileoperror(ficom fcom);
    /* V izhodno datoteko programa in na standardni izhod izpise niz, ki
    ustreza specificni napaki pri operacijah z datotekami. Ce je ustrezna
    funkcija interpreterja klicana brez argumentov, se izpise niz za zadnjo
    izvedeno operacijo. Ce je vrednost argumenta pozitivna, se izpise niz za
    napako, katere zaporedna stevilka je vrednost argumenta, ce pa je
    negativna, se izpise niz, ki ustreza napaki, katere zaporedna stevilka od
    zadaj naprej je absolutna vrednost argumenta (ce absolutna vrednost
    argumenta v enem ali drugem primeru presega stevilo kod napak na skladu,
    se izpise niz "NULL", tako kot ce je vrednost argumenta nic).
    $A Igor jul98; */

void fi_clearfileoperrors(ficom fcom);
    /* Zbrise vse zabelezene napake na skladu fileoperrors, tudi kodo
    uspesnosti zadnje izvedene datotecne operacije postavi na 0.
    $A Igor jun98; */

void fi_fflush(ficom fcom);
    /* Izprazni vmesni pomnilnik preddefinirane datoteke infile oz. zapise
    vse nezapisane podatke iz bufferja v datoteko.
    $A Igor sep99; */

void fi_fsetpos(ficom fcom);
    /* Postavi trenutno pozicijo uporabnisko definirane datoteke infile na
    vrednost argumenta pri klicu funkcije v ukazni datoteki.
    $A Igor jun98; */

void fi_fincreasepos(ficom fcom);
    /* Trenutno pozicijo datoteke infile poveca za vrednost edinega argumenta
    pri klicu ustrezne funkcije v datotecnem interpreterju. Vrednost argumenta
    je lahko tudi negativna, v tem primeru se pozicije pomakne proti zacetku
    datoteke.
    $A Igor jun98; */

void fi_fmarkpos(ficom fcom);
    /* Argument ustrezne funkcije pri klicu v datotecnem interpreterju mora
    biti ime spremenljivke sistema za ovrednotenje izrazov. Spremenljivki s tem
    imenom se priredi trenutna pozicija datoteke infile.
    $A Igor jun98; */

void fi_fprintfpos(ficom fcom);
    /* V izhodno datoteko programa zapise sporocilo o trenutni poziciji v
    datoteki infile.
    $A Igor jun98; */

void fi_printfpos(ficom fcom);
    /* Na standardni izhod programa zapise sporocilo o trenutni poziciji v
    datoteki infile.
    $A Igor jun98; */

void fi_dprintfpos(ficom fcom);
    /* V izhodno datoteko in na standardni izhod programa zapise sporocilo o
    trenutni poziciji v datoteki infile.
    $A Igor jul98; */

void fi_fprintfpart(ficom fcom);
    /* V izhodno datoteko programa zapise del datoteke infile, ki ga dolocajo
    argumenti pri klicu ustrezne funkcije v interpreterju, skupaj s kratkim
    komentarjem o tem, kateri del datoteke je izpisan. Ce je argument en sam,
    se izpise toliko znakov datoteke od trenutne pozicije, kolikor je vrednost
    argumenta, ce pa sta argumenta dva, dolocata njuni vrednosti pozicijo 1. in
    zadnjega izpisanega znaka.
    $A Igor jun98 sep99; */

void fi_printfpart(ficom fcom);
    /* Na standardni izhod programa zapise del datoteke infile, ki ga dolocajo
    argumenti pri klicu ustrezne funkcije v interpreterju, skupaj s kratkim
    komentarjem o tem, kateri del datoteke je izpisan. Ce je argument en sam,
    se izpise toliko znakov datoteke od trenutne pozicije, kolikor je vrednost
    argumenta, ce pa sta argumenta dva, dolocata njuni vrednosti pozicijo 1. in
    zadnjega izpisanega znaka.
    $A Igor jun98 sep99; */

void fi_dprintfpart(ficom fcom);
    /* V izhodno datoteko in na standardni izhod programa zapise del datoteke
    infile, ki ga dolocajo argumenti pri klicu ustrezne funkcije v
    interpreterju, skupaj s kratkim komentarjem o tem, kateri del datoteke je
    izpisan. Ce je argument en sam, se izpise toliko znakov datoteke od
    trenutne pozicije, kolikor je vrednost argumenta, ce pa sta argumenta dva,
    dolocata njuni vrednosti pozicijo 1. in zadnjega izpisanega znaka.
    $A Igor jul98 sep99; */

void fi_fwritefpart(ficom fcom);
    /* V izhodno datoteko programa zapise del datoteke infile, ki ga dolocajo
    argumenti pri klicu ustrezne funkcije v interpreterju. Ce je argument en
    sam, se izpise toliko znakov datoteke od trenutne pozicije, kolikor je
    vrednost argumenta, ce pa sta argumenta dva, dolocata njuni vrednosti
    pozicijo 1. in zadnjega izpisanega znaka. Funkcija izpise le del datoteke
    brez kaksnega spremnega komentarja.
    $A Igor jun98; */

void fi_writefpart(ficom fcom);
    /* Na standardni izhod programa zapise del datoteke infile, ki ga dolocajo
    argumenti pri klicu ustrezne funkcije v interpreterju. Ce je argument en
    sam, se izpise toliko znakov datoteke od trenutne pozicije, kolikor je
    vrednost argumenta, ce pa sta argumenta dva, dolocata njuni vrednosti
    pozicijo 1. in zadnjega izpisanega znaka. Funkcija izpise le del datoteke
    brez kaksnega spremnega komentarja.
    $A Igor jun98; */

void fi_dwritefpart(ficom fcom);
    /* V izhodno datoteko in na standardni izhod programa zapise del datoteke
    infile, ki ga dolocajo argumenti pri klicu ustrezne funkcije v
    interpreterju. Ce je argument en sam, se izpise toliko znakov datoteke od
    trenutne pozicije, kolikor je vrednost argumenta, ce pa sta argumenta dva,
    dolocata njuni vrednosti pozicijo 1. in zadnjega izpisanega znaka. Funkcija
    izpise le del datoteke brez kaksnega spremnega komentarja.
    $A Igor jul98; */

void fi_ffindstring(ficom fcom);
    /* V datoteki infile poisce niz, ki je prvi argument pri klicu ustrezne
    funkcije v datotecnem interpreterju. Za iskanje uporabi funkcijo
    vfilefindstring. Trenutno pozicijo postavi na zacetek najdenega niza.
    Pri klicu funkcije v interpreterju je lahko podan se drugi argument, ki
    je ime spremenljivke kalkulatorja, ki se ji priredi pozicija najdenega
    niza, in tretji argument, ki je ime spremenljivke kalkulatorja, ki se ji
    priredi pozicija 1. znaka za najdenim nizom.
    $A Igor jun98; */

void fi_ffindstringto(ficom fcom);
    /* podobno kot fi_ffindstring(), le da se isce v omejenem obmocju datoteke.
    Pri klicu ustrezne funkcije v datotecnem interpreterju doloca 1. argument 
    mesto v datoteki, do katerega se isce. Operacija se izvrsi s funkcijo
    vfilefindstringto().
    $A Igor jun98; */

void fi_fskipstring(ficom fcom);
    /* V datoteki infile poisce niz, ki je prvi argument pri klicu ustrezne
    funkcije v datotecnem interpreterju. Za iskanje uporabi funkcijo
    vfileskipstring. Trenutno pozicijo postavi na 1. znak za najdenim nizom.
    Pri klicu funkcije v interpreterju je lahko podan se drugi argument, ki
    je ime spremenljivke kalkulatorja, ki se ji priredi pozicija 1. znaka za
    najdenim nizom, in tretji argument, ki je ime spremenljivke kalkulatorja,
    ki se ji priredi pozicija najdenega niza.
    $A Igor jun98; */

void fi_fskipstringto(ficom fcom);
    /* Podobni kot fi_fskipstring(), le da se isce v omejenem obmocju datoteke.
    Pri klicu ustrezne funkcije v interpreterju mora biti 1. argument mesto v
    datoteki, do katerega se isce. Za iskanje uporabi funkcijo
    vfileskipstringto(). 
    $A Igor jun98; */

void fi_fmultfindstring(ficom fcom);
    /* V datoteki infile najde 1. pojav kateregakoli izmed skupine nizov. Pri
    tem uporavi funkcijo vfilemultfindstring(). V argument. bloku pri klicu
    funkcije v datotecnem interpreterju morajo biti najprej v zavitih oklepajih
    nasteti nizi, ki se jih isce, nato lahko sledi (opcijsko) ime spremenljivke
    kalkulatorja, ki se ji priredi zaporedna stevilka najdenega niza, nato ime
    spremenljivke, ki se ji priredi pozicija najdenega niza in nato se ime
    spremenljivke, ki se ji priredi pozicija 1. znaka za najdenim nizom. Ostale
    karakteristike sledijo iz vfilemultfindstring().
    $A Igor jun98; */

void fi_fmultfindstringto(ficom fcom);
    /* Podobno kot fi_fmultfindstring(), le da se isce po omejenem obmocju
    datoteke. Pri klicu ustrezne funkcije v datotecnem interpreterju je 1.
    argument mesto v datoteki, do katerega se isce. Operacija se izvrsi s
    funkcijo vfilemultfindstringto().
    $A Igor jun98; */

void fi_fmultskipstring(ficom fcom);
    /* V datoteki infile najde 1. pojav kateregakoli izmed vec nizov, za kar
    uporabi funkcijo vfilemultskipstring(). V argumentnem bloku ustrezne
    funkcije interpreterja morajo biti najprej nasteti iskani nizi v zavitih
    oklepajih, nato pa lahko sledi (opcijsko) se ime spremenljivke
    kalkulatorja, ki se ji priredi zaporedna stevilka najdenega niza, nato ime
    spremenljivke kalkulatorja, ki se ji priredi  pozicija v datoteki po
    izvedbi operacije (1. znak za najdenim nizom) in po moznosti se ime
    spremenljivke, ki se ji priredi pozicija najdenega niza.
    $A Igor jun98; */

void fi_fmultskipstringto(ficom fcom);
    /* Podobni kot fi_fmultskipstring(), le da se isce v omejenem obmocju
    datoteke. Pri klicu ustrezne funkcije v datotecnem interpreterju mora biti
    prvi argument mesto v datoteki, do katerega se isce. Operacija se izvede
    s funkcijo vfilemultskipstringto().
    $A Igor jun98; */

void fi_ffindcharacter(ficom fcom);
    /* Iskanje znaka v datoteki infile. Iskanje se izvede s funkcijo
    vfilefindcharacter(). Pri klicu ustrezne funkcije interpreterja je 1.
    argument niz znakov, ki se iscejo, nato pa je lahko podano se ime
    spremenljivke kalkulatorja, ki se ji priredi pozicija najdenega znaka.
    Stevilo znakov, ki se iscejo, se doloci kar iz dolzine niza, ki je 1.
    argument, kar pomeni, da s to funkcijo ne moremo izvesti iskanja znaka
    '\0'.
    $A Igor jun98; */

void fi_ffindcharacterto(ficom fcom);
    /* Podobni kot fi_ffindcharacter(), le da se isce v omejenem obmocju
    datoteke. Pri klicu ustrezne funkcije v datotecnem interpreterju je 1.
    argument mesto v datoteki, do katerega si isce. Iskanje se izvede s
    funkcijo vfilefindcharacterto(). 
    $A Igor jun98; */

void fi_fskipcharacters(ficom fcom);
    /* Iskanja 1. znaka, ki ni vsebovan v nizu, ki je podan kot 1. argument
    pri klicu ustrezne funkcije v datotecnem interpreterju. Stevilo znakov,
    ki pridejo v postev za izpuscanje, je doloceno z dolzino tega niza, kar
    pomeni, da zraven ne more biti znaka '\0'. Operacija se izvede s funkcijo
    vfileskipcharacters(), po kateri ta funkcija podeduje karakteristike.
    2. argument pri klicu ustrezne funkcije v datotecnem interpreterju je
    lahko ime spremenljivke kalkulatorja, ki se ji priredi pozicija prvega
    ustreznega znaka.
    $A Igor jun98; */

void fi_fskipcharactersto(ficom fcom);
    /* Podobno kotfi_fskipcharacters, le da se isce v omejenem obmocju
    datoteke. Pri klicu ustrezne funkcije v datotecnem interpreterju je 1.
    argument mesto v datoteki, do katerega se isce. Iskanje se izvede s
    funkcijo vfileskipcharactersto().
    $A Igor jun98; */

void fi_ffindblank(ficom fcom);
    /* Iskanje 1. praznega znaka ('\n', '\r', '\t' ali ' ') v datoteki infile
    od trenutne pozicije naprej. Iskanje se izvede s funkcijo
    vfilefindcharacter(). 1. argument pri klicu ustrezne funkcije datotecnega
    interpreterja je lahko ime spremenljivke kalkulatorja, ki se ji priredi
    pozicija najdenega praznega znaka.
    $A Igor jun98; */

void fi_ffindblankto(ficom fcom);
    /* Podobno kot fi_ffindblankto(), le da se isce v omejenem obmocju. 1.
    argument pri klicu ustrezne funkcije v datotecnem interpreterju doloca
    pozicijo v datoteki, do katere se isce. Operacija se izvede s funkcijo
    vfilefindcharacterto().
    $A Igor jun98; */

void fi_fskipblanks(ficom fcom);
    /* Preskocijo se vsi prazni znaki v datoteki infile. Operacija se izvede
    s funkcijo vfileskipcharacters(). Kot 1. argument lahko pri klicu ustrezne
    funkcije interpreterja podamo ime spremenljivke, v katero se zapise
    pozicija najdenega nepraznega znaka.
    $A Igor jun98; */

void fi_fskipblanksto(ficom fcom);
    /* Podobno kot fi_fskipblanks(), le da se isce v omejenem obmocju datoteke.
    1. argument pri klicu funkcije v datotecnem interpreterju doloca pozicijo
    datoteke, do katere se isce. Operacija se izvede s funkcijo
    vfileskipcharactersto(). 
    $A Igor jun98; */

void fi_fnextline(ficom fcom);
    /* Trenutna pozicija v datoteki infile se postavi na zacetek naslednje
    vrstice. Kot 1. argument lahko pri klicu funkcije navedemo ime
    spremenljivke kalkulatorja, ki se ji priredi trenutna pozicija v datoteki
    po izvedbi operacije.
    $A Igor jun98; */

void fi_ffindbrac(ficom fcom);
    /* Najde 1. pojav zakljucenega oklepaja danega tipa v datoteki infile,
    za kar se uporabi funkcija vfilefindbrac(). 1. argument pri klicu ustrezne
    funkcije v interpreterju mora biti niz, katerega 1. znak je oklepaj, 1. pa
    zaklepaj iskanega tipa oklepaja. Kot 2. argument je lahko se navedeno ime
    spremenljivke kalkulatorja, ki se ji priredi pozicija 1. oklepaja, kot 3.
    argument ime spremenljivke, ki se ji priredi pozicija 2. oklepaja in kot
    4. argument ime spremenljivke, kamor se zapise trenutna pozicija po izvedbi
    funkcije.
    $A Igor jun98; */

void fi_ffindbracto(ficom fcom);
    /* Podobno kot fi_ffindbrac(), le da se isce v omejenem obmocju datoteke.
    Pri klicu ustrezne funkcije v datotecnem interpreterju 1. argument doloca
    ime pozicijo, do katere se isce. Operacija se izvede s funkcijo
    vfilefindbracto().
    $A Igor jun98; */

void fi_fskipbrac(ficom fcom);
    /* Enako kot fi_ffindbrac, le da se za izvedbo operacije uporabi funkcija
    vfileskipbrac() namesto vfilefindbrac().
    $A Igor jun98; */

void fi_fskipbracto(ficom fcom);
    /* Podobno kot fi_fskipbrac(), le da se isce v omejenem obmocju datoteke.
    Pri klicu funkcije v datotecnem interpreterju 1. argument doloca, do katere
    pozicije v datoteki se isce. Operacija se izvede s funkcijo
    vfileskipbracto().
    $A Igor jun98; */


void fi_ffindnumber(ficom fcom);
    /* Iskanje stevila v datoteki infile od trenutne pozicije naprej. Operacija
    se izvede s funkcijo vfilefindnumber(). Pri klicu ustrezne funkcije v
    interpreterju je lahko 1. argument ime spremenljivke kalkulatorja, ki se ji
    priredi zacetni znak najdenega stevila, 2. argument ime spremenljivke, ki
    se ji priredi 1. znak za najdenim stevilom, in 3. argument ime
    spremenljivke, ki se ji priredi vrednost najdenega stevila.
    $A Igor jun98; */


void fi_ffindnumberto(ficom fcom);
    /* Podobno kot fi_ffindnumber, le da se isce v omejenem obmocju datoteke.
    Pri klicu ustrezne funkcije v interpreterju 1. argument doloca, do katere
    pozicije v datoteki se isce. Operacija se izvede s funkcijo
    vfilefindnumberto(). 
    $A Igor jun98; */

void fi_fskipnumber(ficom fcom);
    /* Podobno kot fi_ffindnumber, le da se za izvedbo operacije uporabi
    funkcija vfileskipnumber(). Razlika je tudi v tem, da morebitni 1. argument
    pri klicu ustrezne funkcije interpreterja pomeni ime spremenljivke
    kalkulatorja, ki se ji priredi 1. znak za najdenim stevilom, morebitni 2.
    argument pa spremenljivko kalkulatorja, kamor se zapise pozicija najdenega
    stevila.
    $A Igor jun98; */

void fi_fskipnumberto(ficom fcom);
    /* Podobno kot fi_fskipnumbe(), le da se isce v omejenem obmocju datoteke.
    Pri klicu ustrezne funkcije v datotecnem interpreterju doloca 1. argument
    pozicijo v datoteki, do katere se isce. Operacija se izvede s funkcijo
    vfileskipnumberto().
    $A Igor jun98; */

void fi_freadnumber(ficom fcom);
    /* Iz datoteke infile prebere stevilo in ga priredi spremenljivki sistema
    za ovrednotenje izrazov, katere ime mora biti 1. argument pri klicu
    ustrezne funkcije kalkulatorja. 2. argument je lahko ime spremenljivke,
    kamor se zapise trenutna pozicija po branju (takoj za prebranim stevilom).
    operacija se izvede s funkcijo vfilereaddouble.
    $A Igor jun98; */

void fi_freadnumberto(ficom fcom);
    /* Podobno kot fi_freadnumber(), le da se branje lahko  izvede le v
    omejenem obmocju datoteke. 1. argument pri klicu ustrezne funkcije v
    datotecnem interpreterju pove, do katere pozicije v datoteki se lahko isce.
    Operacija se izvede s funkcijo vfilereaddoubleto().
    $A Igor jun98; */

void fi_freadscalar(ficom fcom);
    /* Prebere skalarno spremenljivko iz datoteke infile. 1. argument pri klicu
    ustrezne funkcije interpreterja mora biti ime skalarne spremenljivke
    programa, ki se prebere. 2. argument je lahko se ime spremenljivke
    kalkulatorja, ki se ji priredi pozicija v datoteki po branju skalarja
    (takoj za prebranim stevilom). Operacija se izvrsi s funkcijo
    vfilereadscalar().
    $A Igor jun98; */

void fi_freadscalarto(ficom fcom);
    /* Podobno kot fi_freadscalar(), le da se lahko bere le v omejenem podrocju
    datoteke. Pri klicu ustrezne funkcije v datotecnem interpreterju je 1.
    argument pozicija v datoteki, do katere se lahko izvede branje. Operacija
    se izvrsi s funkcijo vfilereadscalarto().
    $A Igor jun98; */

void fi_freadvector(ficom fcom);
    /* Prebere vektorako spremenljivko iz datoteke infile. 1. argument pri
    klicu ustrezne funkcije interpreterja mora biti ime vektorske spremenljivke
    programa, ki se prebere. 2. argument je lahko se ime spremenljivke
    kalkulatorja, ki se ji priredi pozicija v datoteki po branju vektorja
    (takoj za zadnjo komponento). Operacija se izvrsi s funkcijo
    vfilereadvector().
    $A Igor jun98; */

void fi_freadvectorto(ficom fcom);
    /* Podobmo kot fi_freadvector(), le da se lahko bere le v omejenem obmocju
    datoteke. Pri klicu ustrezne funkcije je 1. argument pozicija v datoteki,
    do katere se lahko bere. Operacija se izvrsi s funkcijo vfilereadvectorto().
    $A Igor jun98; */

void fi_freadmatrix(ficom fcom);
    /* Prebere matricno spremenljivko iz datoteke infile. 1. argument pri
    klicu ustrezne funkcije interpreterja mora biti ime matricne spremenljivke
    programa, ki se prebere. 2. argument je lahko se ime spremenljivke
    kalkulatorja, ki se ji priredi pozicija v datoteki po branju matrike
    (takoj za zadnjo komponento). Operacija se izvrsi s funkcijo
    vfilereadvector().
    $A Igor jun98; */

void fi_freadmatrixto(ficom fcom);
    /* Podobno kot fi_freadmatrix(), le da se lahko bere le v omejenem obmocju datoteke. Pri
    klicu ustrezne funkcije v datotecnem interpreterju doloca 1. atgument mesto
    v datoteki, do katerega se lahko bere. Operacija se izvrsi s funkcijo
    vfilereadvector().
    $A Igor jun98; */


/* PISANJE V DATOTEKE IN PREPISOVANJE DELOV DATOTEK */






/* FUNKCIJE KALKULATORJA, KI SE TICEJO SPLOSNEGA DATOTECNEGA VMESNIKA: */



double userfileoperror(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne zahtevano kodo napake pri operacijah z datotekami. Ce je klic
    ustrezne funkcije v matematicnem izrazu nima argumentov, se vrne status
    zadnje datotecne operacije, ki je bila izvedena. Ce je vrednost edinega
    argumenta 0, se vrne stevilo zabelezenih kod napak pri datotecnih
    operacijah, ce je vrednost argumenta pozitivna, se vrne koda napake, katere
    zaporedna stevilka na skladu fileoperrors ustreza vrednosti argumenta,
    ce pa je vrednost argumenta negativna, se vrne koda napake, katere
    zaporedna stevilka na skladu fileoperrors  od zadaj naprej ustreza
    absolutni vrednosti argumenta. V zadnjih dveh primerih vrne funkcija 0,
    ce absolutna vrednost argumenta presega stevilo zabelezenih kod napak, ki
    so na skladu.
    $A Igor jun98; */

double usergetfpos(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne trenutno pozicijo datoteke infile oz. stevilo manjse od 1, ce se
    trenutna pozicija ne da dolociti ali ce datoteka ne obstaja.
    $A Igor jun98; */

double usergetfeof(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne 1, ce smo pri datoteki infile ze na koncu (ce je postavljen "end of
    file" indikator), drugace pa 0.
    $A Igor jun98; */

double usergetflength(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dolzino datoteke infile, ce se ta da dolociti (ce datoteka obstaja
    in je odprta), drugace vrne stevilo, manjse od 1.
    $A Igor jun98; */

double userfcheckcharacter(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne 1, ce je znak na trenutni poziciji v datoteki infile, vsebovan v
    nizu, ki je 1. argument ustrezne funkcije kalkulatorja, drugace vrne 0.
    $A Igor jun98; */

double  userfcheckstring(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne 1, ce je na trenutni poziciji v datoteki infile niz, ki je 1.
    argument ustrezne funkcije kalkulatorja, drugace vrne 0.
    $A Igor jun98; */

varholder updatevfidata(char *name,int place);
    /* Ce je name ime preddefinirane datotecne spremenljivke, postavi
    spremenljivke, ki so odvisne od te spremenljivke, na prave vrednosti.
    Funkcija se uporablja npr. po branju datotecne spremenljivke. Funkcija vrne
    kazalec na objekt tipa varholder, ki predstavlja datoteko z imanom name na
    skladu com.vfi (ce spremenljivke z imenom name ni na tem skladu, vrne
    funkcija NULL).
      POMEMBNA LASTNOST, ki velja za vse spremenljivke, ne le preddefinirane:
     Z argumentom place lahko funkciji povemo, na katerem mestu je
    spremenljivka z imenom name na skladu com.vfi. Ce je place manj kot 1,
    potem funkcija sama poisce spremenljivko. To naredi tudi, ce je place
    napacen (ce na mestu place na skladu com.vfi ni spremenljivke z imenom
    name).
    $A Igor maj98; */

varholder updatevfidata1(char *name,int place);
    /* Podobno kot updatevfidata, le da ne vzame argumenta, ki bi povedal
    funkciji, na katerem mestu na skladu com.vfi je spremenljivka z imenom
    name.
    $A Igor maj98; */



/* NOVE OPERACIJE NAD DATOTEKAMI: INSTALIRANE FUNKCIJE */


/* OPERACIJE NAD CELIMI NOSILCI DATOTECNIH SPREMENLJIVK: */

void fi_newvfile(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki na sklad com.vfi doda nov
    nosilec datotecne spremenljivke z imenom in dimenzijami, kot jih dolocajo
    argumenti funkcije. Ce nosilec z damin imenom ze obstaja, se le-ta zbrise
    (skupaj z elementi - datotekami), na njegovo mesto se postavi na novo
    tvorjeni nosilec.
    $A Igor feb98; */

void fi_dimvfile(ficom fcom);
    /* Funkicija datotecnega interpreterja, ki nastavi dimenzije nosilca
    datotecne spremenljivke. Ce na skladu com.vfi se ne obstaja nosilec s
    podanim imenom, se ta tvori na novo in se vrine na ustrezno mesto sklada.
    Ce nosilec ze obstaja, se pusti nedtaknjen, ce so njegove dimenzije enake
    dimenzijam dolocenim z argumenti, drugace pa se zbrise z elementi (datoteke
    vred) in tvori na novo.
    $A Igor feb98; */

void fi_fprintvfiledata(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    datotecne spremenljivke, katere ime je edini argument funkcije, v izhodno
    datoteko.
    $A Igor feb98; */

void fi_printvfiledata(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    datotecne spremenljivke, katere ime je edini argument funkcije, na
    standardni izhod.
    $A Igor feb98; */

void fi_dprintvfiledata(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    datotecne spremenljivke, katere ime je edini argument funkcije, v izhodno
    datoteko in na standardni izhod programa.
    $A Igor jul98; */

void fi_deletevfilevar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki zbrise celotno datotecno
    spremenljivko (nosilec z vsemi vrednostmi vred), katere ime je edini
    argument funkcije.
    $A Igor feb98; */

void fi_closevfile(ficom fcom);
    /* Function of the file interpreter that closes a file or a group of files.
    The only argument of the corresponding file interpreter function must be
    specification of the sub-table of file elements. The function closes any
    open files of those specified.
    $A Igor aug04; */

void fi_flushvfile(ficom fcom);
    /* Function of the file interpreter that flushes an open file or a group of
    files. The only argument of the corresponding file interpreter function 
    must be specification of the sub-table of file elements. Any files that
    are not open are skipped.
    $A Igor aug04; */

void fi_movevfilevar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki premakne datotecno spremenljivko
    (nosilec z vsemi vrednostmi vred) z danim imenom v datotecno spremenljivko
    z drugim imenom. Imeni sta argumenta funkcije dat. interpreterja ob klicu.
    Ce spremenljivka z drugim imenom ze obstaja, se le-ta najprej zbrise. Po
    operaciji datotecna spremenljivka s 1. imenom ni vec definirana.
    $A Igor feb98; */

void fi_deletevfile(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki brise podtabelo elementov
    datotecne spremenljivke. 1. argument mora biti podtabele datotek, ki je
    sestavljena iz imena datotecne spremenljivke, ki mu opcijsko sledijo indeksi
    podtabele (oz. elementa) v oglatih oklepajih.
    $A Igor jan99; */



/* BRANJE PODATKOV O DATOTEKI IZ UKAZNE DATOTEKE: */

void fi_setvfile(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki prebere podatke o datoteki v
    ukazni datoteki. 1. argument mora biti ime datoteke, 2. pa (ce je rang
    datotecne spremenljivke z danim imenom vecji od 0) indeksna specifikacija v oglatih
    oklepajih, ki pove, za kateri element datotecne spremenljivke gre.
    $A Igor feb98; */



/* IZPIS POSAMEZNIH PODATKOV O DATOTEKAH ALI SKUPINAH DATOTEK: */



void fi_fprintvfile(ficom fcom);
    /* V izhodno datoteko programa se izpise element ali skupina elementov
    datotecne spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis datotek se uporabi
    funkcija fprintvfileelement(), ki klice funkcijo fprintvfile().
    $A Igor maj98; */

void fi_printvfile(ficom fcom);
    /* Na standardni izhod se izpise element ali skupina elementov
    datotecne spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis datotek se uporabi
    funkcija fprintvfileelement(), ki klice funkcijo fprintvfile().
    $A Igor maj98; */

void fi_dprintvfile(ficom fcom);
    /* podobno kot fi_printvfile, le da izpisuje tako v izhodno datoteko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_setvfilecomponents(ficom fcom);
    /* Postavi vse komponente datotek, ki jih doloca specifikacija, na
    vrednost matematicnega izraza, ki se izracuna v sistemu fcom->syst.
    Specifikacija datotek (t.j. ime datotecne spremenljivke in indeksi, ki
    dolocajo elemente, nad katerimi se izvede operacija) ter matematicni izraz
    sta argumenta ustrezne funkcije datotecnega interpreterja.
    $A Igor maj98; */


/* UNARNE OPERACIJE NAD DATOTEKAMI: */



void fi_copyvfile(ficom fcom);
    /* Kopiranje datotek; Operacija se izvede s pomocjo funkcije unvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh datotek (ali skupin datotek), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor maj98; */

void fi_movevfile(ficom fcom);
    /* Premikanje datotek; Operacija se izvede s pomocjo funkcije unvaropch().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh datotek (ali skupin datotek), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvaropch().
    $A Igor maj98; */

void fi_vfilesum(ficom fcom);
    /* Sestevanje datotek; Operacija se izvede s pomocjo funkcije binvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh datotek (ali skupin datotek), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor maj98; */

void fi_fileflush(ficom fcom);
    /* Podobno kot fi_fflush, le da mora biti pri klicu ustrezne funkcije
    interpreterja podana specifikacija datoteke, s katero se izvede operacija.
    Ta doloca datoteko v sistemu datotecnih spremenljivk programa.
    $A Igor sep99; */

void fi_filesetpos(ficom fcom);
    /* Podobno kot fi_fsetpos, le da mora biti pri klicu ustrezne funkcije
    interpreterja podana specifikacija datoteke, s katero se izvede operacija.
    Ta doloca datoteko v sistemu datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileincreasepos(ficom fcom);
    /* Podobno kot fi_fincreasepos, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, s katero se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filemarkpos(ficom fcom);
    /* Podobno kot fi_fmarkpos, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, v kateri se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fprintfilepos(ficom fcom);
    /* Podobno kot fi_fprintfpos, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_printfilepos(ficom fcom);
    /* Podobno kot fi_printfpos, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_dprintfilepos(ficom fcom);
    /* Podobno kot fi_dprintfpos, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jul98; */

void fi_fprintfilepart(ficom fcom);
    /* Podobno kot fi_fprintfpart, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98 sep99; */

void fi_printfilepart(ficom fcom);
    /* Podobno kot fi_printfpart, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98 sep99; */

void fi_dprintfilepart(ficom fcom);
    /* Podobno kot fi_dprintfpart, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jul98 sep99; */

void fi_fwritefilepart(ficom fcom);
    /* Podobno kot fi_fwritefpart, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_writefilepart(ficom fcom);
    /* Podobno kot fi_writefpart, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_dwritefilepart(ficom fcom);
    /* Podobno kot fi_dwritefpart, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jul98; */

void fi_filefindstring(ficom fcom);
    /* Podobno kot fi_ffindstring, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filefindstringto(ficom fcom);
    /* Podobno kot fi_ffindstringto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileskipstring(ficom fcom);
    /* Podobno kot fi_fskipstring, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileskipstringto(ficom fcom);

void fi_filemultfindstring(ficom fcom);
    /* Podobno kot fi_fmultfindstring, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filemultfindstringto(ficom fcom);
    /* Podobno kot fi_fmultfindstringto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filemultskipstring(ficom fcom);
    /* Podobno kot fi_fmultskipstring, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filemultskipstringto(ficom fcom);
    /* Podobno kot fi_fmultskipstringto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filefindcharacter(ficom fcom);
    /* Podobno kot fi_ffindcharacter, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filefindcharacterto(ficom fcom);
    /* Podobno kot fi_ffindcharacterto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileskipcharacters(ficom fcom);
    /* Podobno kot fi_fskipcharacters, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileskipcharactersto(ficom fcom);
    /* Podobno kot fi_fskipcharactersto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filefindblank(ficom fcom);
    /* Podobno kot fi_ffindblank, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filefindblankto(ficom fcom);
    /* Podobno kot fi_ffindblankto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileskipblanks(ficom fcom);
    /* Podobno kot fi_fskipblanks, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileskipblanksto(ficom fcom);
    /* Podobno kot fi_fskipblanksto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filenextline(ficom fcom);
    /* Podobno kot fi_fnextline, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filefindbrac(ficom fcom);
    /* Podobno kot fi_ffindbrac, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filefindbracto(ficom fcom);
    /* Podobno kot fi_ffindbracto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileskipbrac(ficom fcom);
    /* Podobno kot fi_fskipbrac, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileskipbracto(ficom fcom);
    /* Podobno kot fi_fskipbracto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filefindnumber(ficom fcom);
    /* Podobno kot fi_ffindnumber, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filefindnumberto(ficom fcom);
    /* Podobno kot fi_ffindnumberto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileskipnumber(ficom fcom);
    /* Podobno kot fi_fskipnumber, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_fileskipnumberto(ficom fcom);
    /* Podobno kot fi_fskipnumberto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filereadnumber(ficom fcom);
    /* Podobno kot fi_freadnumber, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filereadnumberto(ficom fcom);
    /* Podobno kot fi_freadnumberto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filereadscalar(ficom fcom);
    /* Podobno kot fi_freadscalar, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filereadscalarto(ficom fcom);
    /* Podobno kot fi_freadscalarto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filereadvector(ficom fcom);
    /* Podobno kot fi_freadvector, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filereadvectorto(ficom fcom);
    /* Podobno kot fi_freadvectorto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filereadmatrix(ficom fcom);
    /* Podobno kot fi_freadmatrix, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

void fi_filereadmatrixto(ficom fcom);
    /* Podobno kot fi_freadmatrixto, le da mora biti pri klicu ustrezne
    funkcije interpreterja na zacetku argumentnega bloka podana specifikacija
    datoteke, nad katero naj se izvede operacija. Ta doloca datoteko v sistemu
    datotecnih spremenljivk programa.
    $A Igor jun98; */

double usergetfilepos(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne trenutno pozicijo datoteke oz. stevilo manjse od 1, ce se trenutna
    pozicija ne da dolociti ali ce datoteka ne obstaja.
    $A Igor jun98; */

double usergetfileeof(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne 1, ce smo pri datoteki ze na koncu (ce je postavljen "end of file"
    indikator), drugace pa 0 (tudi v primeru, ce je pri klicu funkcije kaj
    narobe). 1. argument funkcije mora biti ime datotecne spremenljivke, ostali
    pa so lahko indeksi specifikacije datoteke na spremenljivki, ce nosi
    spremenljivka vec datotek.
    $A Igor jun98; */

double usergetfilelength(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dolzino datoteke, ce se ta da dolociti (ce datoteka obstaja in je
    odprta), drugace vrne stevilo, manjse od 1. 1. argument mora biti ime
    datotecne spremenljivke, nadaljnji argumenti pa so lahko indeksi datoteke
    v tabeli elementov datotecne spremenljivke, ce vsebuje spremenljivka vec
    datotek.
    $A Igor jun98; */

double userfilecheckcharacter(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne 1, ce je znak na trenutni poziciji v datoteki vsebovan v nizu, ki
    je 2. argument ustrezne funkcije kalkulatorja, drugace vrne 0. 1. argument
    mora biti ime datotecne spremenljivke, od 3. naprej pa so lahko indeksi
    specifikacije, ki doloca datoteko v tabeli elementov datotecne
    spremenljivke v primeru, da ima le-ta vec elementov.
    $A Igor jun98; */

double userfilecheckstring(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne 1, ce je na trenutni poziciji v datoteki niz, ki je 2. argument
    ustrezne funkcije kalkulatorja, drugace vrne 0. 1. argument mora biti ime
    datotecne spremenljivke, argumenti od 3. naprej pa so lahko indeksi
    specifikacije datoteke v tabeli elementov datotecne spremenljivke.
    $A Igor jun98; */

void ficheck_filewrite(ficom fcom);
    /* Preveri sintakso argumentnega bloka funkcije interpreterja, ki ustreza
    funkciji fi_filewrite().
    $A Igor jul98; */

void fi_filewrite(ficom fcom);
    /* Pisanje v datoteko, katere specifikacija je 1. argument pri klicu
    ustrezne funkcije datotecnega interpreterja. Za specifikacijo datoteke
    moajo biti specifikacije tega, kar naj se izpise. Sintaksa za to je ista
    kot recimo pri funkciji fi_fwrite() v modulu fint.c, ker se za tolmacenje
    specifikacije uporablja funkcija fi_write1() tega modula.
    $A Igor jul98; */

void fi_appendtofile(ficom com);
       /* Izpis na datoteko z imenom, ki je podano v narekovajih takoj na
       zacetku navedbe parametrov, s funkcijo fi_write1 */

void fi_copyfpart(ficom fcom);
    /* Skopira del datoteke "infile" v dano datoteko na trenutno pozicijo. Pri
    klicu ustrezne funkcije datotecnega interpreterja je 1. argument
    specifikacija datoteke, v katero naj se kopira, drugi argument je pozicija,
    od katere naj se kopira, tretji pa pozicija, do katere naj se kopira. Ce
    3. argumenta ni, se skopira od trenutne pozicije naprej toliko bytov,
    kolikor je vrednost 2. argumenta. Za kopiranje se uporablja funkcija
    vfilecopyfilepart().
    $A Igor jul98; */

void fi_copyfilepart(ficom fcom);
    /* Skopira del datoteke ene datoteke v drugo na trenutno pozicijo. Pri
    klicu ustrezne funkcije datotecnega interpreterja je 1. argument
    specifikacija datoteke, iz katere naj se kopira,  drugi argument je
    specifikacija datoteke, v katero naj se kopira, 3. arguent je pozicija,
    od katere naj se kopira, 4. pa pozicija, do katere naj se kopira. Ce
    4. argumenta ni, se skopira od trenutne pozicije naprej toliko bytov,
    kolikor je vrednost 3. argumenta. Za kopiranje se uporablja funkcija
    vfilecopyfilepart().
    $A Igor jul98; */









            /******************************************/
            /*                                        */
            /*         FUNKCIJE KALKULATORJA          */
            /*                                        */
            /******************************************/



/* FUNKCIJE ZA DOSTOP DO VEKTORSKIH SPREMENLJIVK */



double usergetvectordim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema za ovrednotenje izrazov. Vrne zahtevano dimenzijo
    vektorske spremenljivke. 1. argument pri klicu ustrezne funkcije
    kalkulatorja mora biti ime vektorske spremenljivke, 2. argument pa je
    stevilka zahtevane dimenzije; ce je ta enaka 0, funkcija vrne rang
    vektorske spremenljivke.
      Ob napaki vrne funkcija vrednost -1. Tudi Ce vektor z danim imenom ne
    obstaja ali ce specifikacija dimenzije presega rang vektorja, vrne funkcija
    -1.
    $A Igor apr98 mar99 sep99; */

double usergetvector(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema kalkulatorja. Vrne zahtevano komponento vektorja (ta je
    lahko preddefiniran ali uporabnisko definiran). 1. argument pri klicu
    ustrezne funkcije kalkulatorja mora biti ime vektorja, 2. argument pa je
    stevilka zahtevane komponente; ce je ta enaka 0, funkcija vrne dimenzijo
    vektorja (oz. 0, ce je vektor enak NULL). Morebitni nadaljnji argumenti
    pomenijo indekse vektorske spremenljivke v primeru, ko je rang le-te
    vecji od 0.
    $A Igor <== mar98; */


/* FUNKCIJE KALKULATORJA ZA PREDDEFINIRANE VEKTORSKE SPREMENLJIVKE: */


double usergetpredefvectordim(object obj,stack st,stack user,int numargs,
              void *ptr,char *functionname,char *vectorname,varholder var);
    /* 
    $A Igor jun98 mar99 sep99; */

double usergetpredefvector(object obj,stack st,stack user,int numargs,
              void *ptr,char *functionname,char *vectorname,varholder var);
    /* 
    $A Igor jun98; */

double usergetmeasdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke meas.
    $A Igor jun98; */

double usergetmeas(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki meas.
    $A Igor jun98; */

double usergetmeasexactdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke measexact.
    $A Igor jun98; */

double usergetmeasexact(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki measexact.
    $A Igor jun98; */

double usergetmeasmomdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke measmom.
    $A Igor jun98; */

double usergetmeasmom(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki measmom.
    $A Igor jun98; */

double usergetmeasoptdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke measopt.
    $A Igor jun98; */

double usergetmeasopt(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki measopt.
    $A Igor jun98; */

double usergetmeas0dim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke meas0.
    $A Igor jun98; */

double usergetmeas0(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki meas0.
    $A Igor jun98; */

double usergetsigmadim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke sigma.
    $A Igor jun98; */

double usergetsigma(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki sigma.
    $A Igor jun98; */

double usergetparammomdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke parammom.
    $A Igor jun98; */

double usergetparammom(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki parammom.
    $A Igor jun98; */

double usergetparammomolddim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke parammomold.
    $A Igor jun98; */

double usergetparammomold(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki parammomold.
    $A Igor jun98; */

double usergetparamoptdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke paramopt.
    $A Igor jun98; */

double usergetparamopt(object obj,stack st,stack user,int numargs,
              void *ptr);

double usergetparam0dim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke param0.
    $A Igor jun98; */

double usergetparam0(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki param0.
    $A Igor jun98; */

double usergetdirectiondim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke direction.
    $A Igor jun98; */

double usergetdirection(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki direction.
    $A Igor jun98; */

double usergetstartpointdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke startpoint.
    $A Igor jun98; */

double usergetstartpoint(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki startpoint.
    $A Igor jun98; */

double usergettransfdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke transf.
    $A Igor jun98; */

double usergettransf(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki transf.
    $A Igor jun98; */

double usergetgradobjectivemomdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke gradobjectivemom.
    $A Igor jun98; */

double usergetgradobjectivemom(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki gradobjectivemom.
    $A Igor jun98; */

double usergetgradobjectiveoptdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke gradobjectiveopt.
    $A Igor jun98; */

double usergetgradobjectiveopt(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki gradobjectiveopt.
    $A Igor jun98; */

double usergetgradobjective0dim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke gradobjective0.
    $A Igor jun98; */

double usergetgradobjective0(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki gradobjective0.
    $A Igor jun98; */

double usergetgradconstraintmomdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke gradconstraintmom.
    $A Igor nov98; */

double usergetgradconstraintmom(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki gradconstraintmom.
    $A Igor nov98; */

double usergetgradconstraintoptdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke gradconstraintopt.
    $A Igor nov98; */

double usergetgradconstraintopt(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki gradconstraintopt.
    $A Igor nov98; */

double usergetgradconstraint0dim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke gradconstraint0.
    $A Igor nov98; */

double usergetgradconstraint0(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki gradconstraint0.
    $A Igor nov98; */

double usergetgradmeasmomdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke gradmeasmom.
    $A Igor jun98; */

double usergetgradmeasmom(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki gradmeasmom.
    $A Igor jun98; */

double usergetgradmeasoptdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke gradmeasopt.
    $A Igor jun98; */

double usergetgradmeasopt(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki gradmeasopt.
    $A Igor jun98; */

double usergetgradmeas0dim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane vektorske spremenljivke gradmeas0.
    $A Igor jun98; */

double usergetgradmeas0(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani vektorski spremenljivki gradmeas0.
    $A Igor jun98; */




/* FUNKCIJE ZA DOSTOP DO MATRICNIH SPREMENLJIVK */


double usergetmatrixdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema za ovrednotenje izrazov. Vrne zahtevano dimenzijo
    matricne spremenljivke. 1. argument pri klicu ustrezne funkcije
    kalkulatorja mora biti ime matricne spremenljivke, 2. argument pa je
    stevilka zahtevane dimenzije; ce je ta enaka 0, funkcija vrne rang
    matricne spremenljivke.
      Ob napaki vrne funkcija vrednost -1. Tudi Ce matrika z danim imenom ne
    obstaja ali ce specifikacija dimenzije presega rang matrike, vrne funkcija
    -1.
    $A Igor maj98 mar99 sep99; */

double usergetmatrix(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema kalkulatorja. Vrne zahtevano komponento matrike (ta je
    lahko preddefinirana ali uporabnisko definirana). 1. argument pri klicu
    ustrezne funkcije kalkulatorja mora biti ime matrike, 2. argument je
    stevilka vrstice in tretji stevilka stolpca; ce je 2. argument enak 0,
    funkcija vrne eno od dimenzij matrike (stevilo vrstic, ce je 3. argument
    enak 1 in stevilo stolpcev, ce je 3. argument enak 0), ali 0, ce je matrika
    enaka NULL. Morebitni nadaljnji argumenti pomenijo indekse matricne
    spremenljivke v primeru, ko je rang le-te vecji od 0.
    $A Igor maj98; */


/* FUNKCIJE KALKULATORJA ZA PREDDEFINIRANE MATRICNE SPREMENLJIVKE: */


double usergetpredefmatrixdim(object obj,stack st,stack user,int numargs,
              void *ptr,char *functionname,char *matrixname,varholder var);
    /* 
    $A Igor jun98 mar99 sep99; */

double usergetpredefmatrix(object obj,stack st,stack user,int numargs,
              void *ptr,char *functionname,char *matrixname,varholder var);
    /* 
    $A Igor jun98; */

double usergetder2objectivemomdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane matricne spremenljivke der2objectivemom.
    $A Igor jun98; */

double usergetder2objectivemom(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani matricni spremenljivki der2objectivemom.
    $A Igor jun98; */

double usergetder2objectiveoptdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane matricne spremenljivke der2objectiveopt.
    $A Igor jun98; */

double usergetder2objectiveopt(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani matricni spremenljivki der2objectiveopt.
    $A Igor jun98; */

double usergetder2objective0dim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane matricne spremenljivke der2objective0.
    $A Igor jun98; */

double usergetder2objective0(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani matricni spremenljivki der2objective0.
    $A Igor jun98; */

double usergetder2measmomdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane matricne spremenljivke der2measmom.
    $A Igor jun98; */

double usergetder2measmom(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani matricni spremenljivki der2measmom.
    $A Igor jun98; */

double usergetder2measoptdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane matricne spremenljivke der2measopt.
    $A Igor jun98; */

double usergetder2measopt(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani matricni spremenljivki der2measopt.
    $A Igor jun98; */

double usergetder2meas0dim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane matricne spremenljivke der2meas0.
    $A Igor jun98; */

double usergetder2meas0(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani matricni spremenljivki der2meas0.
    $A Igor jun98; */



/* FUNKCIJE KALKULATORJA ZA DOSTOP DO SKALARNIH SPREMENLJIVK */


double usergetscalardim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema za ovrednotenje izrazov. Vrne zahtevano dimenzijo
    skalarne spremenljivke. Prvi argument pri klicu ustrezne funkcije
    kalkulatorja mora biti ime skalarne spremenljivke, 2. argument pa je
    stevilka zahtevane dimenzije; ce je ta enaka 0, funkcija vrne rang
    skalarne spremenljivke.
      Ob napaki vrne funkcija vrednost -1. Tudi ce skalar z danim imenom ne
    obstaja ali ce specifikacija dimenzije presega rang skalarja, vrne funkcija
    -1.
    $A Igor maj98 mar99 sep99; */

double usergetscalar(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema kalkulatorja. Vrne vrednost skalarja (ta je lahko
    preddefiniran ali uporabnisko definiran). 1. argument pri klicu ustrezne
    funkcije kalkulatorja mora biti ime skalarja. Morebitni nadaljnji argumenti
    pomenijo indekse skalarne spremenljivke v primeru, ko je rang le-te vecji
    od 0.
    $A Igor maj98; */


/* FUNKCIJE KALKULATORJA ZA PREDDEFINIRANE SKALARNE SPREMENLJIVKE: */



double usergetpredefscalardim(object obj,stack st,stack user,int numargs,
              void *ptr,char *functionname,char *scalarname,varholder var);
    /* 
    $A Igor jun98 sep99; */

double usergetpredefscalar(object obj,stack st,stack user,int numargs,
              void *ptr,char *functionname,char *scalarname,varholder var);
    /* 
    $A Igor jun98; */

double usergetobjectivemomdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane skalarne spremenljivke objectivemom.
    $A Igor jun98; */

double usergetobjectivemom(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani skalarni spremenljivki objectivemom.
    $A Igor jun98; */

double usergetobjectiveoptdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane skalarne spremenljivke objectiveopt.
    $A Igor jun98; */

double usergetobjectiveopt(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani skalarni spremenljivki objectiveopt.
    $A Igor jun98; */

double usergetobjective0dim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane skalarne spremenljivke objective0.
    $A Igor jun98; */

double usergetobjective0(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani skalarni spremenljivki objective0.
    $A Igor jun98; */

double usergetconstraintmomdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane skalarne spremenljivke constraintmom.
    $A Igor nov98; */

double usergetconstraintmom(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani skalarni spremenljivki constraintmom.
    $A Igor nov98; */

double usergetconstraintoptdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane skalarne spremenljivke constraintopt.
    $A Igor nov98; */

double usergetconstraintopt(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani skalarni spremenljivki constraintopt.
    $A Igor nov98; */

double usergetconstraint0dim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane skalarne spremenljivke constraint0.
    $A Igor nov98; */

double usergetconstraint0(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani skalarni spremenljivki constraint0.
    $A Igor nov98; */



/* FUNKCIJE KALKULATORJA ZA DOSTOP DO NIZOVNIH SPREMENLJIVK */


double usergetstringdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema za ovrednotenje izrazov. Vrne zahtevano dimenzijo
    nizovne spremenljivke. 1. argument pri klicu ustrezne funkcije
    kalkulatorja mora biti ime nizovne spremenljivke, 2. argument pa je
    stevilka zahtevane dimenzije; ce je ta enaka 0, funkcija vrne rang
    nizovne spremenljivke.
      Ob napaki vrne funkcija vrednost -1. Tudi Ce niz z danim imenom ne
    obstaja ali ce specifikacija dimenzije presega rang niza, vrne funkcija
    -1.
    $A Igor jun99 sep99; */

double usergetstring(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema kalkulatorja. Vrne zahtevan podatek o nizu (ta je
    lahko preddefiniran ali uporabnisko definiran). 1. argument pri klicu
    ustrezne funkcije kalkulatorja mora biti ime niza, 2. argument pa je
    identifikacijska stevilka zahtevanega podatka, ki naj ga funkcija vrne.
    Ce je ta stevilka 0, vrne funkcija dolzino niza (0, ce niz ne obstaja),
    ce pa je vecja od 0, vrne ASCII kodo danega znaka v nizu.
      Morebitni nadaljnji argumenti pomenijo indekse nizovne spremenljivke v
    primeru, ko je rang le-te vecji od 0.
    $A Igor jun99; */




/* FUNKCIJE ZA DOSTOP DO DATOTECNIH SPREMENLJIVK */


double usergetvfiledim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema za ovrednotenje izrazov. Vrne zahtevano dimenzijo
    datotecne spremenljivke. 1. argument pri klicu ustrezne funkcije
    kalkulatorja mora biti ime datotecne spremenljivke, 2. argument pa je
    stevilka zahtevane dimenzije; ce je ta enaka 0, funkcija vrne rang
    datotecne spremenljivke.
      Ob napaki vrne funkcija vrednost -1. Tudi Ce datotekaz danim imenom ne
    obstaja ali ce specifikacija dimenzije presega rang datoteke, vrne funkcija
    -1.
    $A Igor maj98 mar99 sep99; */

double usergetvfile(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema kalkulatorja. Vrne zahtevan podatek o datoteki (ta je
    lahko preddefiniran ali uporabnisko definiran). 1. argument pri klicu
    ustrezne funkcije kalkulatorja mora biti ime datoteke, 2. argument pa je
    identifikacijska stevilka zahtevanega podatka, ki naj ga funkcija vrne.
    Ce je ta stevilka 0, vrne funkcija 1, ce je datoteka odprta, drugace pa 0; 
    Ce je identifikacijska stevilka 1, vrne funkcija 1, ce je datoteka odprta
    za branje, drugace pa 0, ce je identifikacijska stevilka 2, pa vrne
    funkcija 1, ce je datoteka odprta za pisanje, drugace pa 0. Ce je
    identifikacijska stevilka enaka 3, vrne funkcija trenutno pozicijo v
    datoteki.
      Morebitni nadaljnji argumenti pomenijo indekse datotecne spremenljivke v
    primeru, ko je rang
    le-te vecji od 0.
    $A Igor maj98; */




/* FUNKCIJE KALKULATORJA ZA PREDDEFINIRANE DATOTECNE SPREMENLJIVKE: */


double usergetpredefvfiledim(object obj,stack st,stack user,int numargs,
              void *ptr,char *functionname,char *vfilename,varholder var);
    /* 
    $A Igor jun98 mar99 sep99; */

double usergetpredefvfile(object obj,stack st,stack user,int numargs,
              void *ptr,char *functionname,char *vfilename,varholder var);
    /* 
    $A Igor jun98; */

double usergetinfiledim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane datotecne spremenljivke infile.
    $A Igor jun98; */

double usergetinfile(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani datotecni spremenljivki infile.
    $A Igor jun98; */

double usergetoutfiledim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane datotecne spremenljivke outfile.
    $A Igor jun98; */

double usergetoutfile(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani datotecni spremenljivki outfile.
    $A Igor jun98; */

double usergetaninfiledim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane datotecne spremenljivke aninfile.
    $A Igor jun98; */

double usergetaninfile(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani datotecni spremenljivki aninfile.
    $A Igor jun98; */

double usergetanoutfiledim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne dimenzije preddefinirane datotecne spremenljivke anoutfile.
    $A Igor jun98; */

double usergetanoutfile(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Vrne podatke o preddefinirani datotecni spremenljivki anoutfile.
    $A Igor jun98; */






                  /******************************/
                  /*                            */
                  /*   OPERACIJE NAD STEVCI     */
                  /*                            */
                  /******************************/



/* OPERACIJE NAD STEVCI: NEKAJ POMOZNIH FUNKCIJ */



int updatecountvar(char *name,int place);
    /* Ce je name ime preddefinirane stevcne spremenljivke, opravi vse
    potrebno, da je ta stevcna spremenljivka definirana in ima ustrezne
    dimenzije. Funkcija se na primer uporablja pred branjem stevcne
    spremenljivke zato, da pri preddefinirani spremenljivki ni potrebno navesti
    dimenzije le-te.
      POMEMBNA LASTNOST, ki velja za vse spremenljivke, ne le preddefinirane:
     Z argumentom place lahko funkciji povemo, na katerem mestu je
    spremenljivka z imenom name na skladu com.count. Ce je place manj kot 1,
    potem funkcija sama poisce spremenljivko. To naredi tudi, ce je place
    napacen (ce na mestu place na skladu com.count ni spremenljivke z imenom
    name). Funkcija vrne mesto, na katerem je spremenljivka z imenom name na
    skladu com.count po izvedbi funkcije, ali 0, ce taksne spremenljivke po
    izvedbi funkcije ni na skladu.
    $A Igor nov98; */

int updatecountvar1(char *name);
    /* Podobno kot updatecountvar, le da ne vzame argumenta, ki bi povedal
    funkciji, na katerem mestu na skladu com.count je spremenljivka z imenom
    name.
    $A Igor nov98; */

varholder updatecountdata(char *name,int place);
    /* Ce je name ime preddefinirane stevcne spremenljivke, postavi
    spremenljivke, ki so odvisne od te spremenljivke, na prave vrednosti.
    Funkcija se uporablja npr. po branju stevcne spremenljivke. Funkcija vrne
    kazalec na objekt tipa varholder, ki predstavlja stevec z imanom name na
    skladu com.count (ce spremenljivke z imenom name ni na tem skladu, vrne
    funkcija NULL).
      POMEMBNA LASTNOST, ki velja za vse spremenljivke, ne le preddefinirane:
     Z argumentom place lahko funkciji povemo, na katerem mestu je
    spremenljivka z imenom name na skladu com.count. Ce je place manj kot 1,
    potem funkcija sama poisce spremenljivko. To naredi tudi, ce je place
    napacen (ce na mestu place na skladu com.count ni spremenljivke z imenom
    name).
    $A Igor nov98; */

varholder updatecountdata1(char *name,int place);
    /* Podobno kot updatecountdata, le da ne vzame argumenta, ki bi povedal
    funkciji, na katerem mestu na skladu com.count je spremenljivka z imenom
    name.
    $A Igor nov98; */



/* NOVE OPERACIJE NAD STEVCI: INSTALIRANE FUNKCIJE */


/* OPERACIJE NAD CELIMI NOSILCI STEVCNIH SPREMENLJIVK: */

void fi_newcounter(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki na sklad com.count doda nov
    nosilec stevcne spremenljivke z imenom in dimenzijami, kot jih dolocajo
    argumenti funkcije. Ce nosilec z damin imenom ze obstaja, se le-ta zbrise
    (skupaj z elementi - stevci), na njegovo mesto se postavi na novo
    tvorjeni nosilec.
    $A Igor nov98; */

void fi_dimcounter(ficom fcom);
    /* Funkicija datotecnega interpreterja, ki nastavi dimenzije nosilca
    stevcne spremenljivke. Ce na skladu com.count se ne obstaja nosilec s
    podanim imenom, se ta tvori na novo in se vrine na ustrezno mesto sklada.
    Ce nosilec ze obstaja, se pusti nedtaknjen, ce so njegove dimenzije enake
    dimenzijam dolocenim z argumenti, drugace pa se zbrise z elementi (stevci
    vred) in tvori na novo.
    $A Igor nov98; */

void fi_fprintcountervar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    stevcne spremenljivke, katere ime je edini argument funkcije, v izhodno
    datoteko.
    $A Igor nov98; */

void fi_printcountervar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    stevcne spremenljivke, katere ime je edini argument funkcije, na
    standardni izhod.
    $A Igor nov98; */

void fi_dprintcountervar(ficom fcom);
    /* Podobno kot fi_printcountervar, le da izpisuje tako na izhodno datoeko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_deletecountervar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki zbrise celotno stevcno
    spremenljivko (nosilec z vsemi vrednostmi vred), katere ime je edini
    argument funkcije.
    $A Igor nov98; */

void fi_movecountervar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki premakne stevcno spremenljivko
    (nosilec z vsemi vrednostmi vred) z danim imenom v stevcno spremenljivko
    z drugim imenom. Imeni sta argumenta funkcije dat. interpreterja ob klicu.
    Ce spremenljivka z drugim imenom ze obstaja, se le-ta najprej zbrise. Po
    operaciji stevcno spremenljivka s 1. imenom ni count definirana.
    $A Igor nov98; */


/* BRANJE STEVCA IZ UKAZNE DATOTEKE: */

void fi_setcounter(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki prebere stevec v ukazni datoteki.
    1. argument mora biti ime stevca, 2. pa (ce je rang stevcne
    spremenljivke z danim imenom countji od 0) indeksna specifikacija v oglatih
    oklepajih, ki pove, za kateri element stevcne spremenljivke gre.
    $A Igor nov98; */

void fi_initcounter(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki inicializira podtabelo elementov
    stevcne spremenljivke. 1. argument mora biti ime stevca, 2. pa (ce je
    rang stevcne spremenljivke z danim imenom vecji od 0) indeksna
    specifikacija tabele oz. elementa v oglatih oklepajih. Tretji argument so
    vrednosti, na katere se inicializirajo elementi stevca.
    $A Igor dec98; */

void fi_deletecounter(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki brise podtabelo elementov
    stevcne spremenljivke. 1. argument mora biti podtabele stevcev, ki je
    sestavljena iz imena stevcne spremenljivke, ki mu opcijsko sledijo indeksi
    podtabele (oz. elementa) v oglatih oklepajih.
    $A Igor jan99; */

void setoptioninv0(char *optname,long val);
    /* Naredi podobno kot setoptioninv, le da se privzame, da je rang
    stevcne spremenljivke z imenom optname, ki je nosilec dane opcije, enak 0.
    $A Igor nov98; */

void fi_setoption(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki postavi dano opcijo na 1.
    Specifikacija opcije je edini argument funkcije.
    $A Igor nov98; */

void fi_clearoption(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki postavi dano opcijo na 0.
    Specifikacija opcije je edini argument funkcije.
    $A Igor nov98; */



/* IZPIS POSAMEZNIH STEVCEV ALI SKUPIN STEVCEV: */


void fi_fprintcounter(ficom fcom);
    /* V izhodno datoteko programa se izpise element ali skupina elementov
    stevcne spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis stevcev se uporabi
    funkcija fprintcounterelement(), ki klice funkcijo fprintcounter().
    $A Igor nov98; */

void fi_printcounter(ficom fcom);
    /* Na standardni izhod se izpise element ali skupina elementov
    stevcne spremnljivke. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis stevcev se uporabi
    funkcija fprintcounterelement(), ki klice funkcijo fprintcounter().
    $A Igor nov98; */

void fi_dprintcounter(ficom fcom);
    /* podobno kot fi_printcounter, le da izpisuje tako v izhodno datoteko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_setcountercomponents(ficom fcom);
    /* Postavi vse komponente stevcev, ki jih doloca specifikacija, na
    vrednost matematicnega izraza, ki se izracuna v sistemu fcom->syst.
    Specifikacija stevcev (t.j. ime stevcne spremenljivke in indeksi, ki
    dolocajo elemente, nad katerimi se izvede operacija) ter matematicni izraz
    sta argumenta ustrezne funkcije datotecnega interpreterja.
    $A Igor nov98; */

void fi_setcountcompcond(ficom fcom);
    /* Postavi vse komponente stevcev, ki jih doloca specifikacija in pri
    katerih je vrednost pogoja razlicna od 0, na vrednost matematicnega izraza,
    ki se izracuna v sistemu fcom->syst. Specifikacija sklrj (t.j. ime
    stevcne spremenljivke in indeksi, ki dolocajo elemente, nad katerimi se
    izvede operacija) je prvi argument ustrezne funkcije datotecnega 
    interpreterja. Pogoj v okroglih oklepajih je drugi argument, tretji pa
    matematicni izraz, katerega vrednost se priredi komponentam.
    $A Igor dec98; */



/* UNARNE OPERACIJE NAD STEVCI: */



void fi_copycounter(ficom fcom);
    /* Kopiranje stevcev; Operacija se izvede s pomocjo funkcije unvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh stevcev (ali skupin stevcev), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor nov98; */

void fi_movecounter(ficom fcom);
    /* Premikanje stevcev; Operacija se izvede s pomocjo funkcije unvaropch().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh stevcev (ali skupin stevcev), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvaropch().
    $A Igor nov98; */


/* BINARNE OPERACIJE NAD STEVCI: */


void fi_countersum(ficom fcom);
    /* Sestevanje stevcev; Operacija se izvede s pomocjo funkcije binvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh stevcev (ali skupin stevcev, ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor nov98; */




/* FUNKCIJE KALKULATORJA ZA DOSTOP DO STEVCNIH SPREMENLJIVK */


double usergetcounterdim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema za ovrednotenje izrazov. Vrne zahtevano dimenzijo
    stevcne spremenljivke. Prvi argument pri klicu ustrezne funkcije
    kalkulatorja mora biti ime stevcne spremenljivke, 2. argument pa je
    stevilka zahtevane dimenzije; ce je ta enaka 0, funkcija vrne rang
    stevcne spremenljivke.
      Ob napaki vrne funkcija vrednost -1. Tudi ce stevec z danim imenom ne
    obstaja ali ce specifikacija dimenzije presega rang stevca, vrne funkcija
    -1.
    $A Igor nov98 mar99; */

double usergetcounter(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema kalkulatorja. Vrne vrednost stevca (ta je lahko
    preddefiniran ali uporabnisko definiran). 1. argument pri klicu ustrezne
    funkcije kalkulatorja mora biti ime stevca. Morebitni nadaljnji argumenti
    pomenijo indekse stevcne spremenljivke v primeru, ko je rang le-te vecji
    od 0.
    $A Igor nov98; */

char getoptioninv0(char *name);
    /* Podobno kot getoptioninv, le, da se privzame, da je rang ustrezne
    stevcne spremenljivke, na kateri najdemo opcijo, enak 0.
    $A Igor nov98; */

double usergetoption(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema kalkulatorja. Vrne vrednost stevca (ta je lahko
    preddefiniran ali uporabnisko definiran). 1. argument pri klicu ustrezne
    funkcije kalkulatorja mora biti ime stevca. Morebitni nadaljnji argumenti
    pomenijo indekse stevcne spremenljivke v primeru, ko je rang le-te vecji
    od 0.
    $A Igor maj98; */


/* FUNKCIJE KALKULATORJA ZA PREDDEFINIRANE STEVCNE SPREMENLJIVKE: */



double usergetpredefcounterdim(object obj,stack st,stack user,int numargs,
              void *ptr,char *functionname,char *countername,varholder var);
    /* 
    $A Igor nov98 mar99; */

double usergetpredefcounter(object obj,stack st,stack user,int numargs,
              void *ptr,char *functionname,char *countername,varholder var);
    /* 
    $A Igor nov98; */










































            /********************************************/
            /*                                          */
            /*    DAMJANOV VMESNIK ZA MANIPULACIJO S    */
            /*        POLJI V KONCNIH ELEMENTIH         */
            /*                                          */
            /********************************************/




varholder updateflddata(char *name,int place);
    /* Ce je name ime preddefinirane spremenljivke polja, postavi
    spremenljivke, ki so odvisne od te spremenljivke, na prave vrednosti.
    Funkcija se uporablja npr. po branju spremenljivke polja, da se
    avtomatsko nastavi npr. dimenzija skupine preddefiniranih polj po
    branju polja, ki pripada tej skupini. Funkcija vrne kazalec na objekt
    tipa varholder, ki predstavlja polje z imanom name na skladu com.fld
    (ce spremenljivke z imenom name ni na tem skladu, vrne funkcija NULL).
      POMEMBNA LASTNOST, ki velja za vse spremenljivke, ne le preddefinirane:
     Z argumentom place lahko funkciji povemo, na katerem mestu je
    spremenljivka z imenom name na skladu com.fld. Ce je place manj kot 1,
    potem funkcija sama poisce spremenljivko. To naredi tudi, ce je place
    napacen (ce na mestu place na skladu com.fld ni spremenljivke z imenom
    name).
    $A Igor maj98; Damjan jul98 */



/******** FUNKCIJE ZA INSTALACIJO V INTERPRETER ********/


void fi_newfield(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki na sklad com.fld doda nov
    nosilec spremenljivke polja z imenom in dimenzijami, kot jih dolocajo
    argumenti funkcije. Ce nosilec z damin imenom ze obstaja, se le-ta zbrise
    (skupaj z elementi - polji), na njegovo mesto se postavi na novo
    tvorjeni nosilec.
    $A Igor mar98; Damjan jul98 */

void fi_dimfield(ficom fcom);
    /* Funkicija datotecnega interpreterja, ki nastavi dimenzije nosilca
    spremenljivke polja. Ce na skladu com.fld se ne obstaja nosilec s
    podanim imenom, se ta tvori na novo in se vrine na ustrezno mesto sklada.
    Ce nosilec ze obstaja, se pusti nedtaknjen, ce so njegove dimenzije enake
    dimenzijam dolocenim z argumenti, drugace pa se zbrise z elementi (polji);
    vred in tvori na novo.
    $A Igor mar98; Damjan jul98*/

void fi_deletefieldvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki zbrise celotno spremenljivko
    polja (nosilec z vsemi vrednostmi vred), katere ime je edini argument
    funkcije.
    $A Igor mar98; Damjan jul98 */

void fi_deletefield(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki brise podtabelo elementov
    spremenljivke polja. 1. argument mora biti podtabela spremenljivke polja,
    ki je sestavljena iz imena spremenljivke polja, ki mu opcijsko sledijo
    indeksi podtabele (oz. elementa) v oglatih oklepajih.
    $A Igor jan99; Damjan jan99 */

void fi_movefieldvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki premakne spremenljivko polja
    (nosilec z vsemi vrednostmi vred) z danim imenom v spremenljivko polja
    z drugim imenom. Imeni sta argumenta funkcije dat. interpreterja ob klicu.
    Ce spremenljivka z drugim imenom ze obstaja, se le-ta najprej zbrise. Po
    operaciji spremenljivka polja s 1. imenom ni vec definirana.
    $A Igor mar98; Damjan jul98 */

void fi_setfield(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki prebere polje v ukazni datoteki.
    1. argument mora biti ime polja, 2. pa (ce je rang spremenljivke polja
    z danim imenom vecji od 0) indeksna specifikacija v oglatih oklepajih,
    ki pove, za kateri element spremenljivke polja gre.
    $A Igor mar98; Damjan jul98 */

void fi_initfield(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki inicializira podtabelo elementov
    poljske spremenljivke. 1. argument mora biti ime polja, 2. pa (ce je
    rang poljske spremenljivke z danim imenom vecji od 0) indeksna
    specifikacija tabele oz. elementa v oglatih oklepajih. Tretji argument so
    vrednosti, na katere se inicializirajo elementi polja.
    $A Igor dec98; */

void fi_fprintfieldvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    spremenljivke polja, katere ime je edini argument funkcije, v izhodno
    datoteko.
    $A Igor mar98; Damjan jul98 */

void fi_printfieldvar(ficom fcom);
    /* Funkcija datotecnega interpreterja, ki izpise stanje in vsebino nosilca
    spremenljivke polja, katere ime je edini argument funkcije, na
    standardni izhod.
    $A Igor mar98; Damjan jul98 */

void fi_dprintfieldvar(ficom fcom);
    /* Podobno kot fi_printfieldvar, le da izpisuje tako na izhodno datoeko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_fprintfield(ficom fcom);
    /* V izhodno datoteko programa se izpise element ali skupina elementov
    spremnljivke polja. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis polj se uporabi
    funkcija fprintfieldlement(), ki klice funkcijo fprintfield().
    $A Igor mar98; Damjan jul98 */

void fi_printfield(ficom fcom);
    /* Na standardni izhod se izpise element ali skupina elementov
    spremnljivke polja. Argument funkcije datotecnega interpreterja, s
    katero je povezana ta funkcija, mora biti ime spremenljivke in
    specifikacija elementov, ki naj se izpisejo. Za izpis polj se uporabi
    funkcija fprintfieldelement(), ki klice funkcijo fprintfield().
    $A Igor mar98; Damjan jul98 */

void fi_dprintfield(ficom fcom);
    /* podobno kot fi_printfield, le da izpisuje tako v izhodno datoteko
    programa kot na standardni izhod.
    $A Igor sep99; */

void fi_setfieldcomponents(ficom fcom);
    /* Postavi vse komponente polj, ki jih doloca specifikacija, na
    vrednost matematicnega izraza, ki se izracuna v sistemu fcom->syst.
    Specifikacija polja (t.j. ime spremenljivke polja in indeksi, ki
    dolocajo elemente, nad katerimi se izvede operacija) ter matematicni izraz
    sta argumenta ustrezne funkcije datotecnega interpreterja.
    $A Igor mar98; Damjan jul98 */

void fi_setfldcompcond(ficom fcom);
    /* Postavi vse komponente polj, ki jih doloca specifikacija in pri
    katerih je vrednost pogoja razlicna od 0, na vrednost matematicnega izraza,
    ki se izracuna v sistemu fcom->syst. Specifikacija sklrj (t.j. ime
    poljske spremenljivke in indeksi, ki dolocajo elemente, nad katerimi se
    izvede operacija) je prvi argument ustrezne funkcije datotecnega 
    interpreterja. Pogoj v okroglih oklepajih je drugi argument, tretji pa
    matematicni izraz, katerega vrednost se priredi komponentam.
    $A Igor dec98; */

double usergetfielddim(object obj,stack st,stack user,int numargs,
              void *ptr);
    /* Funkcija sistema za ovrednotenje izrazov. Vrne zahtevano dimenzijo
    spremenljivke polja. 1. argument pri klicu ustrezne funkcije
    kalkulatorja mora biti ime spremenljivke polja, 2. argument pa je
    stevilka zahtevane dimenzije; ce je ta enaka 0, funkcija vrne rang
    spremenljivke polja.
      Ob napaki vrne funkcija vrednost -1. Tudi Ce polje z danim imenom ne
    obstaja ali ce specifikacija dimenzije presega rang polja, vrne funkcija
    -1.
    $A Igor maj98 mar99 sep99; Damjan jul98 */

double usergetfield(object obj,stack st,stack user,int numargs,void *ptr);
    /* Funkcija sistema kalkulatorja. Vrne zahtevano komponento polja (ta je
    lahko preddefinirana ali uporabnisko definirana). 1. argument pri klicu
    ustrezne funkcije kalkulatorja mora biti ime polja, 2. argument je
    stevilka vrstice in tretji stevilka stolpca; ce je 2. argument enak 0,
    funkcija vrne eno od dimenzij polja (stevilo vrstic, ce je 3. argument
    enak 1 in stevilo stolpcev, ce je 3. argument enak 2), ali 0, ce je polje
    enako NULL. Morebitni nadaljnji argumenti pomenijo indekse spremenljivke
    polja v primeru, ko je rang le-tega vecji od 0.
    $A Igor maj98; Damjan jul98 */

void fi_copyfield(ficom fcom);
    /* Kopiranje polj; Operacija se izvede s pomocjo funkcije unvarop().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh polj (ali skupin polj), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvarop().
    $A Igor mar98; Damjan jul98 */

void fi_movefield(ficom fcom);
    /* Premikanje polj; Operacija se izvede s pomocjo funkcije unvaropch().
    Pri klicu funkcije v datotecnem interpreterju morata biti argumenta
    specifikaciji obeh polj (ali skupin polj), ki sta sestavljeni iz
    imena in indeksov. Veljajo ista pravila kot za funkcijo unvaropch().
    $A Igor mar98; Damjan jul98 */


/* FUNKCIJE ZA BRANJE IN PISANJE POLJ V DATOTEKE  */


/*** Splosno branje ***/

void fi_freadfieldcomp(ficom fcom);
    /* Funkcija datotecnega interpreterja prebere polje v vhodni datoteki
    za analizo (aninfile) od trenutne pozicije naprej. 1. argument funkcije
    mora biti specifikacija polja (ce je rang premenljivke polja z danim
    imenom vecji od 0 je to indeksna specifikacija v oglatih oklepajih, ki
    pove, za kateri element spremenljivke polja gre. 3. in 4. argument sta
    opcijska in dolocata stevilo vrstic in stolpcev spremenljivke polja na 
    katero se nalozijo komponente polja iz datoteke. 5. opcijski argument je 
    pozicija byta, ki oznacuje konec polja.
    $A Damjan jul98,jan99 */

void fi_filereadfieldcomp(ficom fcom);
    /* Funkcija datotecnega interpreterja prebere polje v navedeni datoteki
    od trenutne pozicije naprej. 1. argument funkcije mora biti specifikacija
    datotecne spremenljivke, 2. argument pa specifikacija spremenljivke polja.
    (ce je rang premenljivke polja z danim imenom vecji od 0 je to indeksna 
    specifikacija v oglatih oklepajih, ki pove, za kateri element spremenljivke
    polja gre) 3. in 4. argument sta opcijska in dolocata stevilo vrstic in 
    stolpcev spremenljivke polja na katero se nalozijo komponente polja iz 
    datoteke. 5. opcijski argument je pozicija byta, ki oznacuje konec polja.
    $A Damjan jul98 */

void fi_freaddatfield(ficom fcom);
    /* Funkcija datotecnega interpreterja poisce in prebere prvo polje v vhodni
    datoteki za analizo (aninfile) tipa *.dat od navedene pozicije naprej.
    1. argument funkcije mora biti specifikacija polja (ce je rang
    spremenljivke polja z danim imenom vecji od 0 je to indeksna specifikacija
    v oglatih oklepajih, ki pove, za kateri element spremenljivke polja gre.
    2. argument je ime polja kot ga ima v datoteki (iskalni niz),
    3. argument pa je pozicija zacetka iskanja polja. V 4. opcijski argument
    se zapise pozicija konca polja.
    $A Damjan jul98 */

void fi_filereaddatfield(ficom fcom);
    /* Funkcija datotecnega interpreterja poisce in prebere prvo polje v
    navedeni vhodni datoteki za analizo tipa *.dat od navedene pozicije naprej.
    1. argument funkcije mora biti specifikacija datoteke.
    2. argument funkcije mora biti specifikacija polja (ce je rang
    spremenljivke polja z danim imenom vecji od 0 je to indeksna specifikacija
    v oglatih oklepajih, ki pove, za kateri element spremenljivke polja gre.
    3. argument je ime polja kot ga ima v datoteki (iskalni niz),
    4. argument pa je pozicija zacetka iskanja polja. V 5. opcijski argument
    se zapise pozicija konca polja.
    $A Damjan jul98 */

void fi_freadneufield(ficom fcom);
    /* Funkcija datotecnega interpreterja poisce in prebere prvo polje v vhodni
    datoteki za analizo (aninfile) tipa *.neu od navedene pozicije naprej.
    1. argument funkcije mora biti specifikacija polja (ce je rang
    spremenljivke polja z danim imenom vecji od 0 je to indeksna specifikacija
    v oglatih oklepajih, ki pove, za kateri element spremenljivke polja gre.
    2. argument je ime polja kot ga ima v datoteki (iskalni niz),
    3. argument pa je pozicija zacetka iskanja polja. V 4. opcijski argument
    se zapise pozicija konca polja.
    $A Damjan jul98 */

void fi_filereadneufield(ficom fcom);
    /* Funkcija datotecnega interpreterja poisce in prebere prvo polje v
    navedeni vhodni datoteki za analizo tipa *.neu od navedene pozicije naprej.
    1. argument funkcije mora biti specifikacija datoteke.
    2. argument funkcije mora biti specifikacija polja (ce je rang
    spremenljivke polja z danim imenom vecji od 0 je to indeksna specifikacija
    v oglatih oklepajih, ki pove, za kateri element spremenljivke polja gre.
    3. argument je ime polja kot ga ima v datoteki (iskalni niz),
    4. argument pa je pozicija zacetka iskanja polja. V 5. opcijski argument
    se zapise pozicija konca polja.
    $A Damjan jul98 */

void fi_freadresfield(ficom fcom);
    /* Funkcija datotecnega interpreterja poisce in prebere prvo polje v izhodni
    datoteki za analizo (anoutfile) tipa *.res od navedene pozicije naprej.
    1. argument funkcije mora biti specifikacija polja (ce je rang
    spremenljivke polja z danim imenom vecji od 0 je to indeksna specifikacija
    v oglatih oklepajih, ki pove, za kateri element spremenljivke polja gre.
    2. argument je ime polja kot ga ima v datoteki (iskalni niz),
    3. argument pa je pozicija zacetka iskanja polja. V 4. opcijski argument
    se zapise pozicija konca polja.
    $A Damjan jul98 */

void fi_filereadresfield(ficom fcom);
    /* Funkcija datotecnega interpreterja poisce in prebere prvo polje 
    z navedenim imenom v navedeni izhodni datoteki za analizo tipa *.res
    od navedene pozicije naprej. 
    1. argument funkcije mora biti specifikacija datoteke.
    2. argument funkcije mora biti specifikacija polja (ce je rang
    spremenljivke polja z danim imenom vecji od 0 je to indeksna specifikacija
    v oglatih oklepajih, ki pove, za kateri element spremenljivke polja gre.
    3. argument je ime polja kot ga ima v datoteki (iskalni niz),
    4. argument pa je pozicija zacetka iskanja polja. V 5. opcijski argument
    se zapise pozicija konca polja.
    $A Damjan jul98 */

void fi_fwritefieldcomp(ficom fcom);
    /* V izhodno datoteko (outfile) izpise komponente specificiranega
    polja od trenutne pozicije naprej. Argument funkcije datotecnega 
    interpreterja, s katero je povezana ta funkcija, mora biti specifikacija 
    polja, katerega komponente naj se izpisejo. Komponente polja se zapisejo s 
    funkcijo fwritefieldcomp.
    $A Igor mar98; Damjan jul98 */


void fi_filewritefieldcomp(ficom fcom);
    /* V izbrano datoteko interpreterja se izpise komponente specificiranega
    polja od trenutne pozicije naprej. Argument funkcije datotecnega 
    interpreterja, s katero je povezana ta funkcija, mora biti specifikacija 
    datotecne spremenljivke in specifikacija polja, katerega komponente naj 
    se izpisejo. Komponente polja se zapisejo s funkcijo fwritefieldcomp.
    $A Igor mar98; Damjan jul98 */


/*** ZAMENJAVA POLJ V DATOTEKAH ***/


/*** Zamenjava polj v vhodnih datotekah za program Elfen ***/

void fi_freplacefield(ficom fcom);
    /* Funkcija datotecnega interpreterja poisce zamenja prvo polje z 
    ustreznim imenom v vhodni datoteki za analizo (aninfile) od navedene 
    pozicije naprej. 
    1. argument funkcije mora biti specifikacija polja (ce je rang
    spremenljivke polja z danim imenom vecji od 0 je to indeksna specifikacija
    v oglatih oklepajih, ki pove, za kateri element spremenljivke polja gre.
    2. argument je ime polja kot ga ima v datoteki (iskalni niz),
    3. argument pa je pozicija zacetka iskanja polja. 
    4. argument je opcijski argument v katerega se zapise pozicija konca polja.
    $A Damjan jul98 */

void fi_filereplacefield(ficom fcom);
    /* Funkcija datotecnega interpreterja poisce in zamenja prvo polje z 
    ustreznim imenom v navedeni vhodni datoteki za analizo od navedene 
    pozicije naprej. 
    1. argument funkcije mora biti specifikacija datoteke.
    2. argument funkcije mora biti specifikacija polja (ce je rang
    spremenljivke polja z danim imenom vecji od 0 je to indeksna specifikacija
    v oglatih oklepajih, ki pove, za kateri element spremenljivke polja gre.
    3. argument je ime polja kot ga ima v datoteki (iskalni niz),
    4. argument pa je pozicija zacetka iskanja polja. 
    5. argument je opcijski argument v katerega se zapise pozicija zacetka polja.
    $A Damjan jul98 */





    /* INSTALACIJA FUNKCIJ NA DATOTECNI INTERPRETER: */


void installvariableoperations(ficom fcom);
    /* Na datotecni interpreter fcom instalira funkcije interpreterja in
    kalkulatorja za ravnanje s spremenljivkami razlicnih tipov.
    $A Igor sep01; */






