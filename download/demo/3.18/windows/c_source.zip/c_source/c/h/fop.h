


          /*********************************/
          /*                               */
          /*  FILE MANIPULATION UTILITIES  */
          /*                               */
          /*********************************/



/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_st
#include <st.h>
#endif

/* Redefine names: */
#define filelength ig_filelength


/* GUIDLINES: manipulation of file names and interaction with the filesystem
  Function should be such that they give correct results with either path names
containing native or non-native file path separators (i.e. both / or \). If
necessary, internal conversions should be made when necessary. The overhead of
the CPU time spent for this should not be a limiting factor for these functions,
since any interaction with the file system is usually much slover than simple
name conversions.
  Eventual preliminary conversions of path strings should levave the input
arguments intouched, although not declared as constant.
  Output file and directory names should always be expressed in the form native
to the operating system (e.g. with backslash path separators on MS Windows).
Result strings that represent directory names should always end with a path
separator.
*/


/* MANIPULATION OF FILE NAMES */


char filepathseparator(void);
    /* Returns file path separator for current operating system.
    $A Igor jan02; */

void replacepathseparators(char *path,char separator,char targetseparator);
    /* Replaces all occurences of separator in path name path by
    targetseparator.
    $A Igor jan02; */

void changepathseparators(char *path,char targetseparator);
    /* Replaces all occurences of file system's path separator in path name
    path by character targetseparator.
    $A Igor jan02; */

void updatepathseparators(char *path,char separator);
    /* Changes all occurences of character separator in path name path by
    system's path separator.
    $A Igor jan02; */

void convertfilesyst(char *file);
    /* Changes non-native path separators, if present, to the native system
    path separators (e.g. / to \ on Windows and vice versa on UNIX).
    $A Igor avg01; */

void cleanpathname(char **pathaddr);
    /* Cleans the path name *pathaddr, i.e. changes path separators to the
    system path separator and removes unnecessary things like /./ and /../.
    If pathaddr or *pathaddr is NULL, the function does nothing.
    $A Igor apr04; */

char *filenameext(char *name);
    /* Returns pointer to file name extension (inclusive .) of name.
    If there is no dot before the first /, \ or native path separator,
    NULL is returned.
    $A Igor apr04l */  

char *dirplusfile(char *dir,char *file);
    /* Returns the name of the file, which is composed of the directory name
    dir and the file name file. file may contain a relative path composed of
    several directory names spearated by path separators. A path separator is
    inserted between dir and file when necessary. The function can be used
    equally well for composing directory names - just the sevond name must be
    the directory name.
      The returned string is dynamically allocated.
    $A Igor sep98; */

char *multdirplusfile(char *first,...);
    /* Vrne ime datoteke, ki je sestavljeno iz imen vsebovanih direktorijev od
    direktorija first naprej in imena datoteke, ki je zadnji argument razlicen
    od NULL. Funkcija vrne alociran niz. Ce so vsi argumenti prazni nizi ali
    NULL, vrne funkcija NULL. Funkcija vrine med posameznimi argumenti
    separatorje datotecnih imen, ce je to potrebno (tj. ce separatorji niso ze
    vkljuceni na zacetku ali na koncu imen). Ce sta zadnji znak dolocenega
    argumenta in prvi naslednjega separatorja, se namesto njiju vrine en sam
    separator. Prazni nizi se ignorirajo. Ce je na koncu zadnjega argumenta, ki
    ni NULL, separator, se le-ta obdrzi (torej vrnjeno ime predstavlja
    datoteko). Prvi argument, ki je NULL, zakljuci serijo imen, ki sestavljajo
    vrnjeno ime.
     Pravila so ista kot pri multdirplusmultfile(), le da je le ena skupina
    sestavnih delov imena in vedno zadnji niz razlicen od NULL predstavlja
    ime datoteke.
    $A Igor jan02; */

char *multdirplusmultfile(char *first,...);
    /* Vrne ime datoteke, ki je sestavljeno iz imen vsebovanih direktorijev od
    direktorija first do prvega argumenta, ki je NULL, ter iz sledecih delov
    imena datoteke do prvega naslednjega argumenta, ki jhe NULL. Med deli imena
    direktorijev vrine separator, ce je to potrebno (t.j. ce ni ze zadnji znak
    nekega dela ali prvi znak naslednjega dela enak separatorju; ce sta oba
    enaka separatorju za datotec. imena, se enega spusti). Med deli imena
    datoteke ne vriva nicesar. Ce so vsi argumenti prazni nizi ali NULL, vrne
    funkcija NULL, tudi drugace funkcija ignorira prazne nize. Ce je na koncu
    zadnjega argumenta, ki ni NULL, separator, se le-ta obdrzi (torej vrnjeno
    ime predstavlja direktorij). Prvi argument, ki je NULL, zakljuci serijo 
    delov, ki sestavljajo pot, drugi del pa serijo delov, ki sestavljajo ime
    datoteke. Funkcija vrine separator tudi med deli, ki sestavljajo pot (ime
    direktorija) in deli, ki sestavljajo ime datoteke, ce je to potrebno (oz.
    enega odstrani, ce je separator hkrati na koncu poti in na zacetku imena).
      Vrnjeno ime je potrebno brisati (npr. s free()).
      PRIMERI:
    Na Unixu vrne
     multdirplusmultfile("/home","users/igor/","/d",NULL,"readme",".txt",NULL)
    ime "/home/users/igor/d/readme.txt". Niz "/d" bi bil lahko tudi "/d/",
    "readme" pa "/readme", pa bi bil rezultat isti.
     multdirplusmultfile("c",NULL,"a",".c",NULL)
    vrne "c/a.c", enako tudi multdirplusmultfile("c/",NULL,"/a",".c",NULL) .
     multdirplusmultfile("/c",NULL,"a",".c",NULL)
    vrne "/c/a.c".
     multdirplusmultfile("",NULL,"a",".c",NULL)
    vrne "a.c" - na zacetku ni separatorja, ker je skupna dolzina delov, ki
    predstavljajo pot, enaka 0.
     multdirplusmultfile("","/home","","//","/","igor",NULL,"a",".c",NULL)
    vrne "/home/igor/a.c", ravno tako
     multdirplusmultfile("/home","","igor",NULL,"a",".c",NULL) ,
    ker se deli dolzine niz ne upostevajo in ker se pri sestavljanju poti
    steje, da imata "/" in "//" dolzino 0, razen ce je to prvi neprazni niz,
    ki sestavlja pot.
     multdirplusmultfile("/","home","","igor",NULL,"a",".c",NULL)
    vrne "/home/igor/a.c", ker se "/" uposteva, ce je to prvi neprazni niz, ki
    sestavlja pot.
      POZOR:
      Paziti je treba, da sta vsaj dva argumenta enaka NULL, od tega zadnji,
    saj se le tako zakljuci branje argumentov. Paziti je tudi treba, da ni kak
    niz, ki naj bi bil sestavni del poti ali imena, NULL, ker to ustavi
    sestavljanje poti oz. imena.
    $A Igor jan03; */

char *fileminusdir(char *file);
    /* Iz imena datoteke file izlusci in vrne samo ime datoteke brez
    direktorijev. Ime, ki ga vrne, lahko brisemo s free().
    $A Igor sep98; */

char *fileminusfile(char *file);
    /* Iz imena datoteke file izlusci ime direktorija, v katerem je datoteka
    (t.j. 1. del imena z ustreznimi zakljucnimi znaki). Ce je file ime
    direktorija in se zakljuci z '/' oz. '\\' v DOSu, vrne funkcija kar to ime,
    ce pa je to ime direktorija, ki se ne zakljuci s tem znakom, vrne funkcija
    ime enega direktorija nizje.
    $A Igor sep98 jan03; */

char *parentdir(char *file);
    /* Returns parent directory of path. If path is a file name , name of the
    directory that would containin the file is returned. If path is a directory
    name, name of its parent directory that would contain this directory is
    returned. It is not necessary that either path or the returned directory
    exists. Name returned by this function must be deallocated when not used
    any more (e.g. by free()).
      file is a directory name if it ends with a path separator and is a file
    name otherwise. Difference with fileminusfile() is that when file ia a
    directory name, fileminusfile() returns file itself, but parentdir returns
    one level lower directory.
    $A Igor jan03; */

char *getpathvolume(char *path);
    /* Returns the volume (i.e. the root point of the file system) in which the
    given path is contained. On Unix this is always "/". On Windows, if the
    path is for example "c:\windows", then the function returns "c:\". The path
    does not need to be a path of an existent file or directory. The returned
    string is dynamically allocated and can be deallocated by free().
    $A Igor apr03; */

char *filesystemroot(void);
    /* Returns the system root, i.e. the root directory of the drive on which
    the operatind system is located ("/" on UNIX or for example "c:\\" on
    Windows). This information can be used as a starting point for searching
    for a given information stored at the agreed locations. If the f.s. root
    can not be determined, then 0 is returned.
      The returned string is dynamically allocated.
     $A Igor apr03; */



    /* INTERACTION WITH FILE SYSTEM */


void getvolumes(stack st);
    /* Gets pushes on st the volumes currently mounted on the file system.
    $A Igor apr01; */

long ig_filelength(char *filename);
    /* Returns length of the file names filename or -1 if length can not be
    retreived.
    $A Igor <== apr03; */

long getfilemtime(char *filename);
    /* Returns the time of the last modification of the file or directory
    named filename, or 0 if the time can not be retreived or the file does not
    exists.
    $A Igor apr03; */

long getfileatime(char *filename);
    /* Returns the time of the last access to the file or directory named
    filename, or 0 if the time can not be retreived or the file does not
    exists.
    $A Igor apr03; */

char setfilemtime(char *filename,long time);
    /* Sets the last modification time of the file or directory named filename,
    to time seconds. time must be positive. Function returns 1 if successful,
    0 otherwise.
    $A Igor apr03; */

char setfileatime(char *filename,long time);
    /* Sets the last access time of the file or directory named filename,
    to time seconds. time must be positive. Function returns 1 if successful,
    0 otherwise.
    $A Igor apr03; */

char fileexistsprimitive(char *filename);
    /* Does the same as fileexists. It is provided only for initialization in
    globut.c, because Tcl interpreter is not yet initielized at the time when
    this function is called and attempt to call it (which actually happens in
    dfileexists()) would crash the program.
    $A Igor feb04; */

char fileexists(char *filename);
    /* Vrne 1, ce datoteka z imenom filename ze obstaja, in 0, ce ne obstaja.
    0 vrne tudi, ce obstaja direktorij z imenom path.
    $A Igor avg98; */

char filewritable(char *filename);
    /* Returns 1 if filename is a name of a writable file (not a directory)
    and 0 otherwise.
    $A Igor apr03; */

char filereadable(char *filename);
    /* Returns 1 if filename is a name of a readable file (not a directory)
    and 0 otherwise.
    $A Igor apr03; */

char fileexecutable(char *filename);
    /* Returns 1 if filename is a name of a writable file (not a directory)
    and 0 otherwise.
    $A Igor apr03; */

char *getcurrentdir(void);
    /* Returns the current (working) directory. The returned string should be
    deallocated after use. The last character is always a path separator. If
    the current dir can not be obtained for any reason, function returns NULL.
    $A Igor apr03; */

char setcurrentdir(char *dir);
    /* Changes the current (working) directory to dir. It returns 1 if the
    operation succedeeded and 0 otherwise.
    $A Igor apr03; */

char *getabsolutepath(char *filename);
    /* Returns an absolute path of filename with native path separators. The
    returned string must be deallocated e.g. by free().
    $A Igor apr04; */

void pathtoabsolute(char **pathaddr);
    /* Changes path string pointed to by pathaddr to absolute path.
    $A Igor apr03; */

char *getargpath(char *filepath);
    /* Returns the representation of path in the form suitable for using
    as a command line argument of programs, i.e. the path separators are
    system native ones, the path is cleaned and if the path contains any blank
    characters, it is embedded in double quotes.
    $A Igor apr04; */

void pathtoarg(char **pathaddr);
    /* Changes path string pointed to by pathaddr so that it can be used as
    command-line argument at program invocation: converts fileseparator to
    native ones, embeds path in double qoutes if it contains whitespaces and
    cleans the path of meaningless things such as
    ./. .
    $A Igor apr03; */

int direxistsprimitive(char *dir);
    /* Does the same as direxists, it is provided only for initialization in
    globut.c, because Tcl interpreter is not yet initielized at the time when
    this function is called and attempt to call it (which actually happens in
    direxists()) would crash the program.
    $A Igor feb04; */

int direxists(char *dir);
    /* Returns 1 if directory named dir exists and 0 if not.
    $A Igor jan02; */

int dirwritable(char *dir);
    /* Returns 1 if directory named dir exists and is writable, 0 if not.
    This function uses temporary string buffer.
    $A Igor jan02; */

int fileordirexists(char *path);
    /* Returns 1 if either file or directory specified by path exists,
    otherwise returns 0;
    $A Igor apr04; */

int createdir(char *dirname);
    /* Creates a directory named dirname, if it does not yet exist. The
    function works only if parent directory of dirname exists. It returns
    0 if directory dirname have already existed, 1 if it successfully created
    dir. and -1 if it failed to create it.
    This function uses temporary string buffer. 
    $A Igor jan02; */

int createdirsafe(char *dirname);
    /* Creates a directory named dirname, if it does not yet exist. The
    function works even if parent directory of dirname does not exist, in
    which case parent directory is recursively created first. Function returns
    0 if directory dirname have already existed, 1 if it successfully created
    the directory and -1 if it failed to create it.
    This function uses temporary string buffer. 
    $A Igor jan02; */

int removedir(char *dirname);
    /* Removes a directory named dirname. Directory is not deleted if it is not
    empty. This function uses temporary string buffer.
    Returns 0 or 1 if operation is successful, otherwise it returns -1.
    $A Igor jan02; */

int removedirrec(char *dirname);
    /* Removes a directory named dirname. Directory is removed even if it is
    not empty. This function uses temporary string buffer.
    Returns 0 or 1 if operation is successful, otherwise it returns -1.
    $A Igor jan02; */




              /****************************/
              /*                          */
              /*  FILE LISTING UTILITIES  */
              /*                          */
              /****************************/



/* Definitions of file type and sorting flags; these flags should always be of
type long because of some system int is only 2 bytes: */
/* Type flags: */
#define F_LISTFILES     0x1    /* list files */
#define F_LISTDIRS      0x2    /* list directories */
#define F_LISTLINKS     0x4    /* list symbolic links */
#define F_LISTSPECIAL   0x8    /* list special files files (links, devices, etc. */
/* Mask for all listing flags: */
#define F_LISTMASK      0xff

/* Sorting flags: */
#define F_SORTNAME         0x100  /* sort by name */
#define F_SORTEXT          0x200  /* sort by extension */
#define F_SORTSIZE         0x400  /* sort by size */
#define F_SORTCTIME        0x800  /* sort by creation time */
#define F_SORTMTIME       0x1000  /* sort by last modification time */
#define F_SORTATIME       0x2000  /* sort by last access time */
#define F_SORTDIRSFIRST   0x4000  /* list directories first */
#define F_SORTFILESFIRST  0x8000  /* list files first */
#define F_SORTREVERSE    0x10000  /* reverse sorting order */

#define F_RECONELEVEL     0x20000  /* sigle level affected by recursive functions */
#define F_RECBYLEVELS     0x40000  /* recursive listing and actions ordered by levels */
#define F_RECLEVELREACHED 0x80000  /* request. level has been reached. */
#define F_RECBREAK       0x100000  /* Stop the recursion (set by parallel thread)  */
/* Mask for all sorting flags: */
#define F_SORTMASK       0xffff00



int cmpfilenamesflags(char *name1,char *name2,long flags);
    /* Compares files named name1 and name2 according to file sorting
    flags and returns result similar to strcmp(). name1 and name2
    should be vlaid file names that can be used in fopen().
    $A Igor apr04l */  

void updatefilesortflags(long *pflags);
    /* Updates file sorting flags pointed to by pflags so that they are
    consistent, e.g sorting by name and time is not on at the same time.
    $A Igor apr04l */  

void dirlistsys(char *path,char *spec,long flags,stack list);
    /* Loads a list of files (dynamically allocated strings (char *) in the 
    directory path, which match specification spec and flags, to stack list.
    list must be initialised. If it already contains any elements, these are
    not deleted.
      path can be either relative or absolute. spec must be a glob-type
    specification containing wildcharacters such as * or ? (see system
    manuals for details) or a specific name.
      flags specify the types of files that are listed. Macros F_LISTFILES,
    F_LISTDIRS, F_LISTLINKS, F_LISTSPECIAL and F_LISTMASK can be used or any
    or-ed combination of these.
      The system "dir" command (or "ls" on UNIX) is used to get the names.
    $A Igor apr04; */

void dirlisttcl(char *path,char *spec,long flags,stack list);
    /* Loads a list of files (dynamically allocated strings (char *) in the 
    directory path, which match specification spec and flags, to stack list.
    list must be initialised. If it already contains any elements, these are
    not deleted.
      path can be either relative or absolute. spec must be a glob-type
    specification containing wildcharacters such as * or ? (see system
    manuals for details) or a specific name.
      flags specify the types of files that are listed. Macros F_LISTFILES,
    F_LISTDIRS, F_LISTLINKS, F_LISTSPECIAL and F_LISTMASK can be used or any
    or-ed combination of these.
      The Tcl system is used to get the names. If Tcl can not be initialized
    properly then the dirlistsys is called to do the work.
    $A Igor apr04; */

void dirlist(char *path,char *spec,long flags,stack list);
    /* Loads a list of files (dynamically allocated strings (char *)) in the 
    directory path, which match specification spec and flags, to stack list.
    list must be initialised. If it already contains any elements, these are
    not deleted.
      path can be either relative or absolute. spec must be a glob-type
    specification containing wildcharacters such as * or ? (see system
    manuals for details) or a specific name.
      flags specify the types of files that are listed. Macros F_LISTFILES,
    F_LISTDIRS, F_LISTLINKS, F_LISTSPECIAL and F_LISTMASK can be used or any
    or-ed combination of these.
      The Tcl system is used to get the names. If Tcl can not be initialized
    properly then the dirlistsys is called to do the work.
    $A Igor apr04; */

void diractionrec(char *path,char *spec,long flags,long dirflags,
                  int maxlevel,int maxchecked,int maxworked,int printlevel,
                  int *level,int *checked,int *worked,long *signal,
                  stack list,void *pdata,
                  int action(int level,char *name,void *dataptr),
                  int preaction(int level,char *name,void *dataptr),
                  int postaction(int level,char *name,void *dataptr),
                  int postrecaction(int level,char *name,void *dataptr));
    /* Recursively performs an action on files or/and directories contained in
    path and specified by spec, which is a glob-like specification of file
    names or an empty string or NULL for all files (equivalent to "*"). flags
    specify listing and ordering flags for files and/or directories on which
    action is performes, while dirflags specify the directory listing and
    ordering flags for going into directories recursively. If either of these
    is 0, it is set to F_LISTMASK & ~F_LISTSPECIAL, which means that all files
    and directories except special files are listed and orderis system
    dependent.
      *level keeps the level of recursion (or directory level) where initial
    level 1 corresponds to path), *numlisted keeps the number of files on which
    action has been performed and worked keeps cummulative sum of all
    positive values returned by action. *maxlevel, *maxchecked and *maxworked
    are normally set to 0 at the function call. level, maxchecked and maxworked
    can be NULL in which case they are initialised to pointers that point to a
    zero integer internally at the behinning of outer recursion level. *level
    is incremented right at the beginning of function, so initial level is 1,
    not 0.
      signal is intentioned for passing signals from one level to another and
    for interrupting recursion from outside, typically from a parallel thread.
    It can be NULL, but if not, *signal should be 0.
      maxlevel, maxchecked and maxworked are define the maximal values for
    *level, *checked and *worked. Whenever any of these is reached, all
    levels of recursion exit immediately. If either of these argument is
    negative, it means that its correspoonding number (e.g. recursion level or
    number of considered files) is not limited. 
      printlevel specifies the amount of information that is printed to the
    standard output by the function during its execution. It can be 0 (no
    output at all), 1, 2, 3 or 4 (all possible information is printed). This
    is used for control mostly. Usually the action functions are ment to print
    out information for the user.
    function during execution. It can be
      Names of all recursively listed files for which action returns a positive
    number are pushed to staxk list, if it is not NULL. First part of names
    contain path so names are either absolute ore relative to path, dependend
    whether path is absolute or relative to the current directory.
      pdata is pointer that is passed to action. In this way action can store
    its own results or retreive relevant options that depend its behavior.
      action is performed on names (2. argument) of all files that are listed
    according to path, spec and flags. The first argument passed to action()
    is the recursion (sub-directory) level in which the file is listed
    (*level is passed where level is argument of diractionrec()). The third
    argument is the same as the pdata argument of the diractionrec(). action
    must return an integer, which is usually 1 if the file satisfies some
    action specific criteria (possibly defined by contents of the dataptr
    argument) and therefore some action is actually performed on the file, or 0
    otherwise. In any case, each positive return value is added to *worked,
    which can as a consequence end the performance if a nonnegative maxworked
    is reached. If action is NULL then 1 is added to *worked for each listed
    file. If ia action is NULL or its return value is positive, then the
    corresponding file name is added to the stack list.
      There are three functions similar to actoin: preaction, postaction and
    postrecaction. The only difference is that the name of the direcory which
    is being worked is passed to them, rather than a file. preaction is
    executed before the directory is listed and postaction is executed after
    the files are listed in a directory. postrecaction is executed after the
    subdirectories are listed recursively, too. Their return vlaue is also
    added to *worked, therefore they should normally return 0, unless we wanto
    thad number of listed directories contributes to the stopping criteria.
    If action or preaction is NULL, then nothing is added to *worked for each
    directory listed.
      Any or all of the action functions action, preaction or postaction can
    be NULL, this simply causes that no corresponding action is performed
    at a given time (before and after directory listing or after a file is
    listed)
    $A Igor apr04; */

void settreesizespec(FILE *fp1,FILE *fp2,int printdirs,int printfiles,
                     int indent,char numsep);
    /* Defines the behaviour of getting and writing tree size by diractionrec()
    and the appropriate action functions as arguments.
    fp1, fp2: files to which output is written; either of them or both can be
    NULL.
    printdirs: whether to print data about directories.
    printfiles: whether to print data about files.
    indent: Number of spaces used for indentation - must be 0 or positive.
    numsep: Separator character used as a 1000 separator in number output.
    If it is '0' or '\0', numbers are printed without 1000 separators.
    $A Igor apr03; */

int printtreesizepreaction(int level,char *name,void *dataptr);
    /* The preaction argument for printing the tree size by the diractionrec().
    $A Igor apr03; */

int printtreesizeaction(int level,char *name,void *dataptr);
    /* The action argument for printing the tree size by the diractionrec().
    $A Igor apr03; */

int printtreesizepostaction(int level,char *name,void *dataptr);
    /* The postaction argument for printing the tree size by the diractionrec().
    $A Igor apr03; */

int printtreesizepostrecaction(int level,char *name,void *dataptr);
    /* The postrecaction argument for printing the tree size by the
    diractionrec().
    $A Igor apr03; */



/* Empty action functions for use with diractionrec(): just count listed files.
Remark: when diractionrec() is called, the action arguments can be NULL except
the action. */

int dirrecaction0(int level,char *name,void *dataptr);

int dirrecpreaction0(int level,char *name,void *dataptr);

int dirrecpostaction0(int level,char *name,void *dataptr);

int dirrecpostrecaction0(int level,char *name,void *dataptr);


void testfilesysop(void);
    /* A test function for tools for interaction with the file system.
    $A Igor apr04; */




      /****************************/
      /*                          */
      /*  SUPPLEMENT TO system()  */
      /*                          */
      /****************************/


char *filetostr(char *filename,int *length);
    /* Copies the complete contents of the file named filename to a dynamically
    allocated string and returns this string. If length!=NULL, the number of
    bytes successfully copied from the file is returned in length. The
    allocated space in the returned string is one byte more than the file
    length and string is zero terminated (therefore, if the file does not
    contain zero characters, we don't need length information).
    $A Igor jan03; */

char *systemresstr0(char *command);
    /* Returns a string that contains all the output of command to the standard
    output, when executed by the operating system. The returned string is
    dynamically allocated and can be deallocated by free().
      Warning: standard error is not redirected when executing this function!
    $A Igor dec02; */

int systemouterstr(char *command,char **out,char **er);
    /* Returns a string that contains all the output of sommand to the standard
    output, when executed by the operating system. The returned string is
    dynamically allocated and can be deallocated by free(). Function returns
    the code returned by system().
      Warning: standard error is not redirected when executing the file!
    $A Igor dec02; */

char *systemresstr(char *command);
    /* Returns a string that contains all the output of command to the standard
    output, when executed by the operating system. The returned string is
    dynamically allocated and can be deallocated by free(). If possible, the
    standard error is also redirected when executing the command, so that its
    error messages are not printed to the terminal.
    $A Igor dec02; */

FILE *fopensafe(char *name,char *mode);
    /* Odpre datoeko z imenom name in na nacin mode. Ce dtoteke ne more
    odpreti ali ce je name ali mode NULL, vprasa uporabnika za ime datoteke in
    nacin odprtja. V koncni fazi se lahko uporabnik odloci tudi, da se dateke
    ne odpre.
    $A Igor jan01; */

FILE *fopensafeaddr(char **name,char **mode);
    /* Odpre datoeko z imenom *name in na nacin *mode. Ce dtoteke ne more
    odpreti ali ce je *name ali *mode NULL, vprasa uporabnika za ime datoteke
    in nacin odprtja. V koncni fazi se lahko uporabnik odloci tudi, da se
    dateke ne odpre. Razlika s funkcijo fopensafe() je v tem, da se *name in
    *mode spremenita na koncni vrednosti, kot ju (po moznosti) doloci
    uporabnik. Zaradi tega pa morata *name in *mode OBVEZNO kazati na niz,
    ki se lahko brise s free().
    $A Igor jan01; */

long flength(FILE *fp);
        /* Vrne dolzino datoteke, ki je povezana z datotecnim kazalcem fp */

long filelength(char *filename);
        /* Vrne dolzino datoteke z imenom *filename. */

char fileexists(char *filename);
    /* Vrne 1, ce datoteka z imenom filename ze obstaja, in 0, ce ne obstaja.
    $A Igor avg98; */

size_t fileread(void *ptr,size_t elsize,size_t n,FILE *fp,long pos);
       /* Iz datoteke fp prebere n*elsize bytov v spomin. lokacijo, na katero
       kaze ptr, od pozicije pos naprej. Vrne stevilo v resnici prebranih
       bytov. */

size_t filewrite(void *ptr,size_t elsize,size_t n,FILE *fp,long pos);
       /* V datoteko fp zapise n*elsize bytov iz spomin. lokacije, na katero
       kaze ptr, od pozicije pos naprej. Vrne stevilo v resnici zapisanih
       bytov. */

char *filereadline(FILE *fp,int maxlength);
     /* Vrne niz, v katerega prebere vrstico iz datoteke fp. Ta niz lahko brises
     z ukazom free. Zakljucni znaki za vrstico so \n, \r in \0. Najvecje st.
     znakov, ki jih funkcija prebere, je maxlength. */

char *readline(int maxlength);
     /* Vrne niz, v katerega prebere vrstico iz std. inp. Ta niz lahko brises
     z ukazom free. Zakljucni znaki za vrstico so \n, \r in \0. Najvecje st.
     znakov, ki jih funkcija prebere, je maxlength. */

char filereadchar(FILE *fp,long pos);
     /* Vrne znak, ki je v datoteki fp na mestu pos (Stetje od 1 naprej). */

int filewritechar(FILE *fp,char put,long pos);
    /* Zapise znak put v datoteko fp na mesto pos. Neuspesen klic vrne EOF. */

void fcopyfilepart(FILE *fp1,long first,long last,FILE *fp2,int maxbuf);
    /* Iz datoteke fp1 skopira del od vkljucno first do vkljucno last v
    datoteko f2 pri trenutni poziciji. Pozicije se stejejo od 1 naprej. maxbuf
    je najvecja dovoljena dolzina vmesnega pomnilnika.
     POZOR!
    fp1 in fp2 ne smeta biti isti datoteki!
    $A Igor jun97 */

long filecopyfilepart(FILE *fp1,long first,long last,FILE *fp2,long pos2,
                     int maxbuf);
    /* Iz datoteke fp1 skopira del od vkljucno first do vkljucno last v
    datoteko f2 pri poziciji pos2. Pozicije se stejejo od 1 naprej. maxbuf
    je najvecja dovoljena dolzina vmesnega pomnilnika. Funkcija se lahko
    uporablja tudi, ce sta sta fp1 in fp2 ista datotecna kazalca. Uporablja se
    recimo v funkcijah fi_function() in fi_update().
     Funkcija vrne eno vec kot je pozicija zadnjega zapisanega byta v fp2
    ali pos2, ce ni bilo nic zapisano.
     POZOR: Ce je pos2 0 ali vecji kot dolzina datoteke fp2, se postavi na
    dolzino datoteke +1 (torej se zacne pisati na konec datoteke) !!! Ce je
    last enak 0, se prepise datoteka fp1 od first do konca.
    $A Igor apr99; */

long fappend(FILE *f1,FILE *f2,int maxbuf);
    /* Na konec datoteke f1 se skopira vsebina datoteke f2. maxbuf je najvecja
    dovoljena dolzina vmesnega pomnilnika. Funkcija vrne dolzino datoteke f2,
    ce pa je kaj narobe, vrne -1. */

long fileappend(char *s1,char *s2,int maxbuf);
    /* Na konec datoteke z imenom s1 se skopira vsebina datotekez imenom s2.
    maxbuf je najvecja dovoljena dolzina vmesnega pomnilnika. Funkcija vrne
    dolzino datoteke z imenom n2, ce pa je kaj narobe, vrne -1. Funkcijo se
    lahko uporabi tudi za navadno kopiranje datotek, v tem primeru mora biti
    s1 ime datoteke, ki se ne obstaja. */





/* ISKANJE NIZOV ZNAKOV V DATOTEKAH */



    /* ISKANJE OD DOLOCENE POZICIJE DO KONCA DATOTEKE */



        /* ISKANJE PRVEGA POJAVA ENEGA SAMEGA NIZA */


long findfrel(FILE *fp, char *str, int length, int minbuf);
               /* Najde prvo pojavo niza *str v datoteki fp od trenutne pozicije
               naprej. Vrne stevilo bytov od trenutne pozicije do pozicije, kjer
               se iskani niz prvic pojavi. Ce niza ne najde, vrne -1. Niz lahko
               vsebuje tudi nicelne znake. length je dolzina niza, ki se isce.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               Funkcija deluje tako, da rezervira tri nize bytov v spominu eden
               za drugim. prvi ima dolzino iskanega niza, drugi poljubno dolzino
               in tretji spet dolzino iskanega niza.
               Pri iskanju se zaporedoma kopirajo deli datoteke na rezervirani
               prostor, s tem da se vsakic skopira zadnji segment na prvega in
               se preveri, ce tako nastali niz vsebuje iskanega.
               OPOMBA: Ce se iskani niz zacne ze na trenutni poziciji, funkcija
               vrne vrednost 0!*/

long filestr(FILE *fp, char *str, int length, long from, int minbuf);
               /* Najde prvo pojavo niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo bytov do pozicije, kjer se iskani niz
               prvic pojavi. Ce niza ne najde, vrne -1. Pozicija se steje v
               bytih od 1 naprej od zacetka datoteke. length podaja dolzino
               niza, ki ga iscemo (s to funkcijo lahko iscemo tudi nize, ki
               vsebujejo znake '\0').
               */

int allfilestr(FILE *fp,char *str,int length,long from,int minbuf,stack st);
    /* Poisce vse pojave niza str v datoteki fp. Pri tem uporablja za posamezna
    iskanja funkcijo filestr. Funkcija vrne stevilo najdenih pojav, v sklad st
    pa doda kazalce na mesta pojav, ki so tipa longint. */

long filestring(FILE *fp, char *str, long from, int minbuf);
               /* Najde prvo pojavo niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo bytov do pozicije, kjer se iskani niz
               prvic pojavi. Ce niza ne najde, vrne -1. Pozicija se steje v
               bytih od 1 naprej od zacetka datoteke.
               POZOR: S to funkcijo ne moremo iskati nizov, ki vsebujejo znak
               '\0', torej funkcija ni prevec primerne za iskanje po binarnih
               datotekah. Dolzina niza je dolocena kot pri obicajnih nizih s 1.
               pojavom znaka '\0'. */

int allfilestring(FILE *fp, char *str, long from, int minbuf,stack st);
    /* Poisce vse pojave niza str v datoteki fp. Pri tem uporablja za posamezna
    iskanja funkcijo filestring. Funkcija vrne stevilo najdenih pojav, v sklad
    st pa doda kazalce na mesta pojav, ki so tipa longint. */





        /* ISKANJE VSEH POJAVOV ENEGA SAMEGA NIZA */


int findfrelall(FILE *fp, char *str, int length, int minbuf, stack st);
               /* Najde vse pojave niza *str v datoteki fp od trenutne pozicije
               naprej. Vrne stevilo najdenih pojav. Hkrati na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od trenutne pozicije do pozicije, kjer se iskani niz
               pojavi. Niz lahko vsebuje tudi nicelne znake. length je dolzina
               niza, ki se isce. minbuf je nanjmanjsa dolzina pomoznega spomina
               v bytih.
               Funkcija deluje podobno kot findrel.
               OPOMBA: Ce se iskani niz zacne ze na trenutni poziciji, je
               ustrezna pozicija na skladu 0!*/

int filestrall(FILE *fp, char *str, int length, long from, int minbuf,stack st);
               /* Najde vse pojave niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo pojav, hkrati pa na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od zacetka datoteke do pozicije, kjer se iskani niz pojavi.
               Pozicija se steje v bytih od 1 naprej od zacetka datoteke. length
               podaja dolzino niza, ki ga iscemo (s to funkcijo lahko iscemo
               tudi nize, ki vsebujejo znake '\0'). */

int filestringall(FILE *fp, char *str, long from, int minbuf,stack st);
               /* Najde vse pojave niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo pojav, hkrati pa na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od zacetka datoteke do pozicije, kjer se iskani niz pojavi.
               Pozicija se steje v bytih od 1 naprej od zacetka datoteke.               POZOR: S to funkcijo ne moremo iskati nizov, ki vsebujejo znak
               POZOR: S to funkcijo ne moremo iskati nizov, ki vsebujejo znak
               '\0', torej funkcija ni prevec primerne za iskanje po binarnih
               datotekah. Dolzina niza je dolocena kot pri obicajnih nizih s 1.
               pojavom znaka '\0'. */





        /* ISKANJE 1. POJAVA ENEGA OD VEC NIZOV */

long nfindfrel(FILE *fp,stack strst,stack lengthst,int minbuf,int *which);
               /* Najde 1. pojav katerega od nizov na skladu strst. Kazalci na
               dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               funkcija vrne relativ. mesto najdenega niza, v *which pa zapise,
               kateri po vrsti je ta niz na skladu strst.
               OPOMBA: Ce se dani niz zacne ze na trenutni poziciji, je
               ustrezna vrnjena pozicija na skladu 0!
               Vse vrnjene pozicije se stejejo od trenutne pozicije v datoteki
               fp naprej, zacensi z 0.
               POZOR!
               Pri uporabi te funkcije je treba  paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst. */

long nfilestr(FILE *fp,stack strst,stack lengthst,long from,int minbuf,
     int *which);
               /* Najde 1. pojav katerega od nizov na skladu strst. Kazalci na
               dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               Funkcija vrne mesto v datoteki (od zacetka datoteke naprej, steti
               se zacne z 1), na katerem je najdeni niz, v *which pa se zapise
               zaporedna stevilka tega mesta v skladu strst.
               POZOR!
               Pri uporabi te funkcije je treba paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst.
               */

long nfilestring(FILE *fp,stack strst, long from, int minbuf,int *which);
               /* Najde 1. pojav katerega od nizov na skladu strst. Nizi
               morajo biti zakljuceni z znakom '\0', funkcija torej ni preimerna
               za iskanje nizov, ki vsebujejo ta znak. minbuf je nanjmanjsa
               dolzina pomoznega spomina v bytih.
               Na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               */











        /* ISKANJE VSEH POJAVOV VEC NIZOV */





int nfindfrelall(FILE *fp,stack strst,stack lengthst,int minbuf,stack retst);
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Kazalci na
               Dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki.
               OPOMBA: Ce se dani niz zacne ze na trenutni poziciji, je
               ustrezna vrnjena pozicija na skladu 0!
               Vse vrnjene pozicije se stejejo od trenutne pozicije v datoteki
               fp naprej, zacensi z 0.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst. Se bolj je treba paziti, da ima sklad retstr eneko st.
               elementov kot strst ter da vsi kazejo na ze alociran spomin
               tipa _stack.
               $A Igor <== feb97 */

int nfilestrall(FILE *fp,stack strst,stack lengthst,long from,int minbuf,
    stack retst);
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Kazalci na
               Dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst. Se bolj je treba paziti, da ima sklad retstr eneko st.
               elementov kot strst ter da vsi kazejo na ze alociran spomin
               tipa _stack.
               */

 int nfilestringall(FILE *fp,stack strst, long from, int minbuf,stack retst);
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Nizi
               morajo biti zakljuceni z znakom '\0', funkcija torej ni preimerna
               za iskanje nizov, ki vsebujejo ta znak. minbuf je nanjmanjsa
               dolzina pomoznega spomina v bytih.
               Na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da ima sklad retstr
               eneko st. elementov kot strst ter da vsi kazejo na ze alociran
               spomin tipa _stack.
               */






    /* ISKANJE V DOLOCENEM OBMOCJU DATOTEKE */




        /* ISKANJE PRVEGA POJAVA DOLOCENEGA NIZA */


long findfrelto(FILE *fp,char *str,int length,long to,int minbuf);
               /* Najde prvo pojavo niza *str v datoteki fp od trenutne pozicije
               naprej, najvec do pozicije to. Vrne stevilo bytov od trenutne
               pozicije do pozicije, kjer se iskani niz prvic pojavi. Ce niza ne
               najde, vrne -1. Niz lahko vsebuje tudi nicelne znake. length je
               dolzina niza, ki se isce. minbuf je nanjmanjsa dolzina pomoznega
               spomina v bytih. Funkcija isce tako, da ce se iskani niz zacne s
               to-tim znakom, ga se vedno uposteva.
               Funkcija deluje tako, da rezervira tri nize bytov v spominu eden
               za drugim. prvi ima dolzino iskanega niza, drugi poljubno dolzino
               in tretji spet dolzino iskanega niza.
               Pri iskanju se zaporedoma kopirajo deli datoteke na rezervirani
               prostor, s tem da se vsakic skopira zadnji segment na prvega in
               se preveri, ce tako nastali niz vsebuje iskanega.
               OPOMBA: Ce se iskani niz zacne ze na trenutni poziciji, funkcija
               vrne vrednost 0!*/

long filestrto(FILE *fp,char *str,int length,long from,long to,int minbuf);
               /* Najde prvo pojavo niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo bytov do pozicije, kjer se iskani niz
               prvic pojavi. Ce niza ne najde, vrne -1. Pozicija se steje v
               bytih od 1 naprej od zacetka datoteke. length podaja dolzino
               niza, ki ga iscemo (s to funkcijo lahko iscemo tudi nize, ki
               vsebujejo znake '\0').
               */

long filestringto(FILE *fp,char *str,long from,long to,int minbuf);
               /* Najde prvo pojavo niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo bytov do pozicije, kjer se iskani niz
               prvic pojavi. Ce niza ne najde, vrne -1. Pozicija se steje v
               bytih od 1 naprej od zacetka datoteke.
               POZOR: S to funkcijo ne moremo iskati nizov, ki vsebujejo znak
               '\0', torej funkcija ni prevec primerne za iskanje po binarnih
               datotekah. Dolzina niza je dolocena kot pri obicajnih nizih s 1.
               pojavom znaka '\0'. */







        /* ISKANJE VSEH POJAVOV DODLOCENEGA NIZA */


int findfrelallto(FILE *fp,char *str,int length,long to,int minbuf,stack st);
               /* Najde vse pojave niza *str v datoteki fp od trenutne pozicije
               naprej. Vrne stevilo najdenih pojav. Hkrati na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od trenutne pozicije do pozicije, kjer se iskani niz
               pojavi. Niz lahko vsebuje tudi nicelne znake. length je dolzina
               niza, ki se isce. minbuf je nanjmanjsa dolzina pomoznega spomina
               v bytih.
               Funkcija deluje podobno kot findrel.
               OPOMBA: Ce se iskani niz zacne ze na trenutni poziciji, je
               ustrezna pozicija na skladu 0!*/

int filestrallto(FILE *fp,char *str,int length,long from,long to,
    int minbuf,stack st);
               /* Najde vse pojave niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo pojav, hkrati pa na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od zacetka datoteke do pozicije, kjer se iskani niz pojavi.
               Pozicija se steje v bytih od 1 naprej od zacetka datoteke. length
               podaja dolzino niza, ki ga iscemo (s to funkcijo lahko iscemo
               tudi nize, ki vsebujejo znake '\0').
               */

int filestringallto(FILE *fp,char *str,long from,long to,int minbuf,stack st);
               /* Najde vse pojave niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo pojav, hkrati pa na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od zacetka datoteke do pozicije, kjer se iskani niz pojavi.
               Pozicija se steje v bytih od 1 naprej od zacetka datoteke.
               POZOR: S to funkcijo ne moremo iskati nizov, ki vsebujejo znak
               '\0', torej funkcija ni prevec primerne za iskanje po binarnih
               datotekah. Dolzina niza je dolocena kot pri obicajnih nizih s 1.
               pojavom znaka '\0'. */





        /* ISKANJE 1. POJAVA ENEGA IZMED VEC NIZOV */


long nfindfrelto(FILE *fp,stack strst,stack lengthst,long to,int minbuf,
     int *which);
               /* Najde 1. pojav katerega od nizov na skladu strst. Kazalci na
               dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih. Preisce
               se najvec to bytov v datoteki.
               funkcija vrne relativ. mesto najdenega niza, v *which pa zapise,
               kateri po vrsti je ta niz na skladu strst.
               OPOMBA: Ce se dani niz zacne ze na trenutni poziciji, je
               ustrezna vrnjena pozicija na skladu 0!
               Vse vrnjene pozicije se stejejo od trenutne pozicije v datoteki
               fp naprej, zacensi z 0.
               POZOR!
               Pri uporabi te funkcije je treba  paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst. */

long nfilestrto(FILE *fp,stack strst,stack lengthst,long from,long to,
     int minbuf,int *which);
               /* Najde 1. pojav katerega od nizov na skladu strst. Kazalci na
               dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               Funkcija vrne mesto v datoteki (od zacetka datoteke naprej, steti
               se zacne z 1), na katerem je najdeni niz, v *which pa se zapise
               zaporedna stevilka tega mesta v skladu strst. Isce se najvec do
               mesta to v datoteki.
               POZOR!
               Pri uporabi te funkcije je treba paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst.
               */

long nfilestringto(FILE *fp,stack strst,long from,long to,int minbuf,
     int *which);
               /* Najde 1. pojav katerega od nizov na skladu strst. Nizi
               morajo biti zakljuceni z znakom '\0', funkcija torej ni preimerna
               za iskanje nizov, ki vsebujejo ta znak. minbuf je nanjmanjsa
               dolzina pomoznega spomina v bytih. Isce se najvec do mesta to v
               datoteki.
               Na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               */






        /* ISKANJE VSEH POJAVOV VEC NIZOV */


int nfindfrelallto(FILE *fp,stack strst,stack lengthst,long to,
    int minbuf,stack retst);
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Kazalci na
               Dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki.
               OPOMBA: Ce se dani niz zacne ze na trenutni poziciji, je
               ustrezna vrnjena pozicija na skladu 0!
               Vse vrnjene pozicije se stejejo od trenutne pozicije v datoteki
               fp naprej, zacensi z 0.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst. Se bolj je treba paziti, da ima sklad retstr eneko st.
               elementov kot strst ter da vsi kazejo na ze alociran spomin
               tipa _stack.
               $A Igor <== feb97 */

int nfilestrallto(FILE *fp,stack strst,stack lengthst,long from,long to,
    int minbuf,stack retst);
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Kazalci na
               Dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst. Se bolj je treba paziti, da ima sklad retstr eneko st.
               elementov kot strst ter da vsi kazejo na ze alociran spomin
               tipa _stack.
               */

int nfilestringallto(FILE *fp,stack strst,long from,long to,
    int minbuf,stack retst);
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Nizi
               morajo biti zakljuceni z znakom '\0', funkcija torej ni preimerna
               za iskanje nizov, ki vsebujejo ta znak. minbuf je nanjmanjsa
               dolzina pomoznega spomina v bytih.
               Na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da ima sklad retstr
               eneko st. elementov kot strst ter da vsi kazejo na ze alociran
               spomin tipa _stack.
               */




    /* ISKANJE ZNAKOV V DATOTEKAH: */



    /* FUNKCIJE ZA ISKANJE ZNAKOV, KI VRNEJO NAJDENI ZNAK: */


long filecharret(FILE *fp, char *str, int length, long from, int buflength, char *ch);
    /* Najde prvo mesto v datoteki fp od pozicije from naprej, na
    katerem je zapisani znak vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika. V *ch se zapise znak, ki
    konca iskanje.
    $A Igor okt01; */

long filechartoret(FILE *fp,char *str,int length,long from,long to,int buflength,char *ch);
    /* Najde prvo mesto v datoteki fp od pozicije from do pozicije to,
    na katerem je zapisani znak vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika. V *ch se zapise znak, ki
    konca iskanje.
    $A Igor okt01; */

long filenotcharret(FILE *fp, char *str, int length, long from, int buflength, char *ch);
    /* Najde prvo mesto v datoteki fp od mesta from naprej, na
    katerem zapisani znak ni vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika. V *ch se zapise znak, ki
    konca iskanje.
    $A Igor okt01; */

long filenotchartoret(FILE *fp,char *str,int length,long from,long to,
     int buflength,char *ch);
    /* Najde prvo mesto v datoteki fp od mesta from do mesta to, na
    katerem zapisani znak ni vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika. V *ch se zapise znak, ki
    konca iskanje.
    $A Igor okt01; */


    /* FUNKCIJE ZA ISKANJE ZNAKOV, KI NE VRNEJO NAJDENEGA ZNAKA: */


long filechar(FILE *fp, char *str, int length, long from, int buflength);
               /* Najde prvo mesto v datoteki fp od pozicije from naprej, na
               katerem je zapisani znak vsebovan v nizu str dolzine length.
               Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
               od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
               buflength je dolzina pomoznega pomnilnika.
               */

long filecharto(FILE *fp,char *str,int length,long from,long to,int buflength);
               /* Najde prvo mesto v datoteki fp od pozicije from do pozicije to,
               na katerem je zapisani znak vsebovan v nizu str dolzine length.
               Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
               od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
               buflength je dolzina pomoznega pomnilnika.
               */

long filenotchar(FILE *fp, char *str, int length, long from, int buflength);
               /* Najde prvo mesto v datoteki fp od mesta from naprej, na
               katerem zapisani znak ni vsebovan v nizu str dolzine length.
               Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
               od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
               buflength je dolzina pomoznega pomnilnika.
               */

long filenotcharto(FILE *fp,char *str,int length,long from,long to,
     int buflength);
               /* Najde prvo mesto v datoteki fp od mesta from do mesta to, na
               katerem zapisani znak ni vsebovan v nizu str dolzine length.
               Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
               od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
               buflength je dolzina pomoznega pomnilnika.
               */








/* ISKANJE ZAKLJUCENIH OKLEPAJEV V DATOTEKAH: */


int filebrac(FILE *fp,char open,char close,long from,int buflength,
    long *pos1,long *pos2);
            /* Najde mesti v datoteki fp, kjer se zacne in konca prvi oklepaj.
            oklepaj je definiran z znakom open, zaklepaj pa z znakom close.
            Isce se od pozicije from naprej.
            buflength je dolzina pomoznega pomnilnika. Mesto oklepaja se vrne
            v pos1, mesto zaklepaja pa v pos2.
            Funkcija vrne stevilo zakljucenih oklepajev, ki so vsebovani med
            glavnima oklepajema. Ce ni vsebovanih podoklepajev, vrne 0, ce
            ni niti glavnih oklepajev, pa -1.
            */

int filebracto(FILE *fp,char open,char close,long from,long to,int buflength,
    long *pos1,long *pos2);
            /* Najde mesti v datoteki fp, kjer se zacne in konca prvi oklepaj.
            Oklepaj je definiran z znakom open, zaklepaj pa z znakom close.
            Isce se od pozicije from do pozicije to.
            buflength je dolzina pomoznega pomnilnika. Mesto oklepaja se vrne
            v pos1, mesto zaklepaja pa v pos2.
            Funkcija vrne stevilo zakljucenih oklepajev, ki so vsebovani med
            glavnima oklepajema. Ce ni vsebovanih podoklepajev, vrne 0, ce
            ni niti glavnih oklepajev, pa -1.
            */

long filebraclev(FILE *fp,char open,char close,int level,
     long from,int buflength);
               /* Najde mesto v datoteki fp, kjer nivo oklepajev doseze level.
               Oklepaj je definiran z znakom open, zaklepaj pa z znakom close.
               Nivo je na zacetku nic, z vsakim oklepajem se poveca za 1,
               z vsakim zaklepajem pa pade za 1. Isce se od pozicije from
               naprej. Ce ne najde ustreznega nivoja, vrne -1. Ce je level 0,
               vrne 1. mesto za 1. oklepajem, kjer je nivo spet 0.
               buflength je dolzina pomoznega pomnilnika.
               */

long filebraclevto(FILE *fp,char open,char close,int level,
    long from,long to,int buflength);
               /* Najde 1. mesto v datoteki fpmed pozicijama from in to, kjer
               nivo oklepajev doseze level in vrne to mesto (steje od 1).
               Oklepaj je definiran z znakom open, zaklepaj pa z znakom
               close. Nivo je na zacetku nic, z vsakim oklepajem se poveca za 1,
               z vsakim zaklepajem pa pade za 1. Ce ne najde ustreznega nivoja,
               vrne -1. Ce je level 0, vrne 1. mesto za 1. oklepajem, kjer je
               nivo spet 0. buflength je dolzina  pomoznega pomnilnika.
               */






/* ISKANJE STEVIL V DATOTEKAH */


double filenum(FILE *fp,long from,int minbuf,long *start,int *length);
               /* V datoteki *fp najde prvi pojav niza, ki lahko predstavlja
               stevilo, od pozicije from naprej. Vrne vrednost, ki ustreza temu
               nizu, v start zapise mesto v datoteki (steje od 1 naprej), kjer
               se ta niz zacne, v length pa vrne dolzino tega niza. Ce taksnega
               niza ne najde, v start in length zapise -1, vrne pa poljubno
               vrednost.
               */

double filenumbrac(FILE *fp,long from,char *left,int lleft,
       char *right,int lright,int minbuf,long *start,int *length);
               /* V datoteki *fp najde prvi pojav niza, ki lahko predstavlja
               stevilo, od pozicije from naprej. Stejejo samo tisti nizi, ki
               so z leve omejeni z znakom, ki je vsebovan v nizu left dolzine
               lleft, z desne pa z znakom, ki je vsebovan v nizu right dolzine
               lright. Namesto ustreznega znaka na levi velja tudi, ce se niz
               zacne na zacetku datoteke, namesto znaka na desni pa, ce se
               konca na koncu datoteke. Funkcija vrne vrednost, ki ustreza temu
               nizu, v start zapise mesto v datoteki (steje od 1 naprej), kjer
               se ta niz zacne, v length pa vrne dolzino tega niza. Ce taksnega
               niza ne najde, v start in length zapise -1, vrne pa poljubno
               vrednost. Zacetek in dolzina niza sta misljena brez znakov, ki
               ta niz omejujeta.
               Funkcija je uporabna na primer v datotekah, kjer so lahko nizi,
               ki lahko predstavljajo stevila, deli imen spremenljivk.
               */

double filenumto(FILE *fp,long from,long to,int minbuf,long *start,int *length);
               /* V datoteki *fp najde prvi pojav niza, ki lahko predstavlja
               stevilo, od pozicije from naprej. Vrne vrednost, ki ustreza temu
               nizu, v start zapise mesto v datoteki (steje od 1 naprej), kjer
               se ta niz zacne, v length pa vrne dolzino tega niza. Ce taksnega
               niza ne najde, v start in length zapise -1, vrne pa poljubno
               vrednost.
               */




/* STEVILCENJE VRSTIC DATOTEKE S C-JEVSKIMI KOMENTARJI */


int numberfilelines(char *filename,int from, int to,char *beginstr,
            char *endstr,char *begincomment,char *endcomment,int buflength);
    /* V datoteki z imenom filename ostevilci vrstice tako, da na koncu vsake
    vrstice od from do to, ki ni v komentarju, doda beginstr, stevilko vrstice
    in endstr. Ce je begincomment ali endcomment enak NULL, se na komentarje ne
    ozira. buflength je dolzina vmesnega pomnilnika, ki se uporabi pri kopiranju
    datotek in hkrati najvecja dopustna dolzina vrstice. Vrstice, ki so ze
    ostevilcene, se ostevilcijo se enkrat.
      Funkcija vrne 0, ce je klic uspesen, in -1, ce datoteka z danim imenom
    ne obstaja.   */

int renumberfilelines(char *filename,int from, int to,char *beginstr,
               char *endstr,char *begincomment,char *endcomment,int buflength);
    /* Podobno kot funkcija numberfilelines, le da se najprej zbrisejo vse
    obstojece oznake vrstic. */

int denumberfilelines(char *filename,int from, int to,char *beginstr,
             char *endstr,char *begincomment,char *endcomment,int buflength);
    /* Iz datoteke z imenom filename zbrise oznake stevilk vrstic, ki so bile
    postavljene s funkcijama numberfilelines in renumberfilelines, ce smo ti
    funkciji klicali z enakimi argumenti from, to, beginstr, endstr, begincomment
    in endcomment. buflength je dolzina vmesnega pomnilnika, ki se uporabi pri
    prepisovanju datotek in hkrati najvecja dopustna dolzina vrstice.
      Funkcija zbrise tudi vse odvecne presledke na koncu vrstic. Uspesen klic
      vrne 0, neuspesen pa -1, ce datoteka z imenom filename ne obstaja. */




/* SPLOSNE POMOZNE FUNKCIJE : identifikacija stevilke vrstice in stolpca,
     preverjanje oklepajnih parov, izpis nekaj vrstic ... */


void filelinepos(FILE *fp,long pos,int *line,int *column);
    /* V *line in *column zapise vrstico in stolpec znaka, ki ima v datoteki fp
    pozicijo pos.
    $A Igor apr98; */

int fline(FILE *fp,int pos);
    /*Vrne stevilko vrstice v datoteki fp, ki ustreza trenutni poziciji pos.
    $A Igor sep01; */

int fcol(FILE *fp,int pos);
    /*Vrne stevilko stolpca v vrstici v datoteki fp, ki ustreza trenutni
    poziciji pos.
    $A Igor sep01; */

long fileabspos(FILE *fp,int line,int column);
    /* Vrne pozicijo znaka, ki je v datoteki fp v vrstici line in stolpcu
    column.
    $A Igor apr98; */

int fprintcheckfilebracto0(FILE *out,FILE *fp,long from,long to,int buf);
    /* Preveri, ce imajo vsi oklepaji v datoteki fp med from in to svoje
    zaklepaje. V datoteko fp izpise vse oklepaje in zaklepaje, pri cemer oznaci
    tiste, ki nimajo para, in vrne stivilo oklepajev in zaklepajev, ki nimajo
    para. buf je dolzina pomoznega pomnilnika za iskanje po datotekah.
     Preverjajo se pari (), [] in {}.
    Opomba: Ime funkcije ima na koncu znak '0', ker je ime brez nicle
    prihranjeno za bolj splosno funkcijo, pri kateri se z argumenti doloci,
    katere pare oklepajev naj se preverja.
    $A Igor apr98; */

int printcheckfilebracto0(FILE *fp,long from,long to,int buf);
    /* Preveri, ce imajo vsi oklepaji v datoteki fp med from in to svoje
    zaklepaje. Na stand. izhod izpise vse oklepaje in zaklepaje, pri cemer
    oznaci tiste, ki nimajo para, in vrne stivilo oklepajev in zaklepajev, ki
    nimajo para. buf je dolzina pomoznega pomnilnika za iskanje po datotekah.
     Preverjajo se pari (), [] in {}.
    Opomba: Ime funkcije ima na koncu znak '0', ker je ime brez nicle
    prihranjeno za bolj splosno funkcijo, pri kateri se z argumenti doloci,
    katere pare oklepajev naj se preverja.
    $A Igor apr98; */

int checkfilebracto0(FILE *fp,long from,long to,int buf);
    /* Preveri, ce imajo vsi oklepaji v datoteki fp med from in to svoje
    zaklepaje. Vrne stivilo oklepajev in zaklepajev, ki nimajo para oziroma 0,
    ce so vsi pravilno postavljeni. buf je dolzina pomoznega pomnilnika za
    iskanje po datotekah. Preverjajo se pari (), [] in {}.
    Opomba: Ime funkcije ima na koncu znak '0', ker je ime brez nicle
    prihranjeno za bolj splosno funkcijo, pri kateri se z argumenti doloci,
    katere pare oklepajev naj se preverja.
    $A Igor apr98; */

int fprintfewfilelines(FILE *fp,FILE *from,long pos0,int pre,int post,
           char *sign);
    /* V datoteko fp se zapise pre vrstic iz datoteke from pred pozicijo pos0
    in post vrsticiz te datoteke za pozicijo pos0, vkljucno z vrstico, ki
    vsebuje pozicijo pos0. Funkcija vrne zaporedno stevilko vrstice v datoteki
    from, ki vsebuje pozicijo pos0. Tik pred zapisom te vrstice se v datoteko
    fp izpise niz sign.
    $A Igor apr98; */

int printfewfilelines(FILE *from,long pos,int pre,int post,char *sign);
    /* Na stand. izhod se zapise pre vrstic iz datoteke from pred pozicijo pos0
    in post vrsticiz te datoteke za pozicijo pos0, vkljucno z vrstico, ki
    vsebuje pozicijo pos0. Funkcija vrne zaporedno stevilko vrstice v datoteki
    from, ki vsebuje pozicijo pos0. Tik pred zapisom te vrstice se na 
    standardni izhod izpise niz sign.
    $A Igor apr98; */









































































