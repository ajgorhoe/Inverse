
        /* MANIPULACIJA Z UPORABNISKO DEFINIRANIMI SPREMENLJIVKAMI */





/* Ensure at most one inclusion: */
#ifndef INCLUDED_varop
#define INCLUDED_varop



/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_st
#include <st.h>
#endif




typedef enum {
  vt_none1=0,  /* rezervirano za NAPACEN tip */
  vt_counter1,
  vt_scalar1,
  vt_vector1,
  vt_matrix1,
  vt_string1,
  vt_vfile1,
  vt_default1,  /* rezervirano za "splosen" tip */
  
  vt_max       /* marker za ugotavljanje stevila tipov */
} vartype1;



typedef struct{
        char *name;   /* ime spremenljivke */
        int type;   /* tip spremenljivke */
        int rank;     /* red (st. dimenzij) */
        int *dim;     /* tabela dimenzij */
        void **v;     /* tabela kazalcev na elemente (prvi indeks je 1) */
        } _varholder;

typedef _varholder *varholder;

#define VT_UNDEF    -1  /* undefined type (usually indicates an error) */
#define VT_ANY       0  /* any type (usually input parameter) */
#define VT_COUNTER   1  /* counter - pointer to long (def. in mtypes.h) */
#define VT_SCALAR    2  /* scalar - pointer to double (def. in mtypes.h) */
#define VT_VECTOR    3  /* vector (def. in vec.h) */
#define VT_MATRIX    4  /* matrix (def. in mat.h) */
#define VT_STRING    5  /* string - char * (def. in mtypes.h) */
#define VT_VFILE     6  /* vfile (def. in mtypes.h) */
#define VT_FIELD     7  /* field (def. in fld.h) */

#define VT_PREDEF    7  /* number of pre-defined types in this module */

extern int VT_NUMTYPES;  /* Number of currently defined types */



/**************************************************************

                        BASIC FUNCTIONS

***************************************************************/

     /* OLDER VERSIONS (mainly out of datE) */

char *makestindspecstring(stack st);
    /* Vrne niz, ki je reprezentacija indeksne specifikacije na sklatu st.
    Niz se lahko brise s free(). Indeksi na skladu st morajo biti tipa int *.
    Zastarela, uporabljaj makeindspecstring.
    $A Igor jan99; */

void fprintstindspec(FILE *fp,stack st);
    /* Izpise indekse na skladu st v oglatem oklepaju in z vejicami v datoteko
    fp. Indeksi na skladu st morajo biti tipa int *.
    $A Igor jan99; */

void printstindspec(stack st);
    /* Izpise indekse na skladu st v oglatem oklepaju in z vejicami na
    standardni izhod. Indeksi na skladu st morajo biti tipa int *.
    $A Igor jan99; */

void sprintstindspec(char *str,stack st);
    /* Prints comma separated indices on the stack st in square brackets on the
    string str, which must provide enough space for this task. Indices on the
    stack must be of the type int *.
    $A Igor nov02; */

char equalvardimstack(varholder var,stack st);
    /* Vrne 1, ce se dimenzije objekta var ujemajo z dimenzijami, ki so na
    skladu st, drugace pa 0. Elementi sklada st morajo biti tipa int *.
    Zastarela. Uporabljaj equalvardimit.
    $A Igor feb98; */


int stringtovartype(char *typespec);
    /* Returns an integer equivalent of variable type that is determined by
    typespec. The returned value can be used for setting or checking variable
    types. 
    $A Igor okt01; */

char *vartypetostring(int type);
    /* Returns a string that represents a long name of the variable type.
    A constant string is returned that may not be de-allocated.
    Function returns "" if type is not a valid variable type ID.
    $A Igor aug05; */

varholder newvarholderst(stack dim);
    /* Alocira prostor za novo spreemnljivko tipa varholder in vrne kazalec
    nanjo. Na skladu dim morajo biti dimenzije spremenljivke, za katero bomo
    uporabili vrnjen kazalec (s tem so dopuscene tabelaricne spremenljivke
    poljubnega reda in dimenzij, npr. 3x2x5). Ce je sklad dim enak NULL, se
    vrnjen kazalec pripravi na sprejem ene same vrednosti, ne tabele.
    Objekt tipa varholder, ki ga funkcija vrne, ima ze pripravljeno tabelo
    kazalcev, kamor se lahko nalozijo kazalci na vrednosti vsebujocih
    spremenljivk (...->v), (...)->rank je postavljen na rang tabele (je enak 0,
    ce gre za eno samo vrednost in ne za tabelo), v (...)->rank pa so dimenzije
    tabele.
    $A Igor dec97; */

varholder newvarholdernamest(char *name,stack dim);
    /* Naredi nov objekt tipa varholder z imenom name. dim je sklad dimenzij.
    Funkcija alocira prostor za objekt s funkcijo newvarholder(), skopira niz
    name v polje (...)->name in vrne narejeni objekt.
    $A Igor feb98; */

varholder newvarholdernametypest(char *name,int type,stack dim);
    /* Naredi nov objekt tipa varholder z imenom name in tipom type. dim je
    sklad dimenzij.
    Funkcija alocira prostor za objekt s funkcijo newvarholder(), skopira niz
    name v polje (...)->name ter postavi (..)->type na type in vrne narejeni
    objekt.
    $A Igor avg01; */

void getvardimst(varholder var,stack *dimp);
    /* Sklad *dimp popravi tako, da so na njem nalozene dimenzije spremenljivke,
    ki jo nosi var. dimp mora biti obvezno razlicen od NULL, drugace se v
    funkciji nic ne zgodi.
     Sklad *dimp je po izvedbi funkcije taksen, da ce z njim klicemo funkcijo
    newvarholder, vrne ta kazalec tipa varholder, ki ima enake dimenzije kot
    var.
     Ce je var enak NULL, tudi *dimp postane NULL, ravno tako, ce je
    var->rank<0. Ce je var->rank enak 0, *dimp postane prazen sklad. Ce je
    var->rank vecji od 0, postane *dimp sklad s toliko elementi, kolikor je
    var->rank, na njem pa so kazalci na objekte tipa int, katerih vrednosti so
    enake ustreznim dimenzijam v var->dim.
     OPOMBA:
    $A Igor jan98 */

int calcvarplacest(varholder var,stack st);
    /* Izracuna zaporedno stevilko, ki bi jo imel na var element z indeksi,
    tabele, ki so na sklatu st. na skladu morajo biti indeksi tipa int *.
    $A Igor jan98; */

void *varelst(varholder var,stack idx);
    /* Vrne kazalec na element spremenljivke var, katerega indeksi ustrezajo
    indeksom na skladu idx. Za dolocitev elementa se uporabi funkcija
    calcvarplacest(). Ce ni elementa, ki bi ustrezal indeksom, vrne NULL.
    $A Igor jan98; */

void **vareladdrst(varholder var, stack idx);
    /* Vrne naslov kazalca na element spremenljivke var, katerega indeksi
    ustrezajo indeksom na skladu idx. Za dolocitev elementa se uporabi funkcija
    calcvarplacest(). Ce ni elementa, ki bi ustrezal indeksom, vrne NULL.
    $A Igor jan98; */

void restvardimst(varholder var,stack dim,stack *rest);
    /* Na sklad *restst nalozi preostale dimenzije (v obliki kazalcev tipa
    int *) nosilca var (dimenzije so v var->dim), ki niso ze nalozene na
    sklad dim. Funkcija privzame, da je prvih dim->n dimenzij ze nalozenih
    in ne preverja, ce te dimenzije na skladu dim pravilne.
      Funkcija je narejena tako, da zbrise sklad *rest in ga postavi na NULL,
    ce nanj ne da nobenih elementov (to je pomembno za funkcije, ki po klicu te
    funkcije preverijo, ali ima ta sklad kaj elementov ali ne - dovolj je
    preveriti, ali je sklad enak NULL, polje (...)->n pa ni vazno).
     Pozor:
    Ce ob klicu funkcije sklad *rest ni prazen, morajo biti elementi na njem
    obvezno tipa int * in taksni, da jih lahko brez skode brisemo s funkcijo
    free().
    $A Igor jan98; */

int incelst(stack elst,stack dimst);
    /* Funkcija inkrementira element vecdimenzionalne tabele, katere dimenzije
    so v obliki kazalcev tipa int * nalozene na sklad dimst. Element je
    dolocen z indeksi na skladu elst, ki so na tem skladu nalozeni kot kazalci
    tipa int *; funkcija ustrezno spremeni (glede na dimenzije na skladu dimst)
    vrednosti teh indeksov.  Ce funkcija uspesno inkrementira element, ne da bi
    vrednosti indeksov presegle obmocje doloceno z dimenzijami na skladu dimst,
    vrne 1, drugace pa 0.
      Ce je stevilo elementov na skladu elst manjse kot na skladu dimst,
    funkcija privzame, da ustreza indeksom na skladu elst po vrsti zadnjih
    elst->n dimenzij na skladu dimst.
    $A Igor jan98; */

char firstindicesinrangest(varholder var,stack elst);
    /* Vrne 1, ce so vsi indeksi s sklada elst (katerega elementi morajo biti
    tipa int *) v obsegu prvih elst->n dimenzij varholderja var, drugace vrne
    0. Ce je na skladu vec indeksov kot je var->rank, ce je var enak NULL ali
    ce je var->rank manjsi od 1 ali ce je kateri od elementov sklada elst enak
    NULL, vrne funkcija 0.
    $A Igor jan98; */

char elstinrange(stack elst,stack dimst);
    /* Funkcija vrne 1, ce so indeksi, ki so nalozeni na sklad elst, v obmocju,
    ki ga dopuscajo dimenzije vecdimenzionalne dabele, nalozene na sklad dimst.
    indeksi in dimenzije so na sklada nalozeni kot kazalci tipa int *. Ce je
    stevilo elementov na skladu elst manjse kot na skladu dimst, funkcija
    privzame, da ustreza indeksom na skladu elst po vrsti zadnjih elst->n
    dimenzij na skladu dimst.
    $A Igor jan98; */

char equaldimstack(stack st1,stack st2);
    /* Vrne 1, ce sta sklada dimenzij st1 in st2 enaka, in 0, ce nista. Enakost
    pomeni, da morajo biti tudi vse vrednosti, na katere kazejo kazalci
    nalozeni na sklada (ki morajo biti obvezno tipa int *) enake.
    $A Igor jan98; */

int totaldimstack(stack st);
    /* Vrne celotno stevilo elementov tabele glede na njene dimenzije, ki so na
    skladu st.
     POZOR!
    Ce je st==NULL ali st->n==0, vrne funkcija 1!
    $A Igor jan98; */

int simpvaropst(varholder var1,stack which1,void operation(void *operand1));
    /* Izvrsi operacijo operation nad elementi spremenljivke var1. which1 pove,
    nad katero podtabelo spremenljivke var1 se izvrsi operacija.
     Pravila glede dimenzij:
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladiu which1 se nanasajo na prve indekse ustrezne
    spremenljivke. Ce katerakoli od njihovih dimenzij ni v obsegu ustrezne
    dimenzije ali ce je indeksov vec kot ustreznih dimenzij (rang
    spremenljivke), je to napaka. Elementi na tem skladu so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
    $A Igor mar98; */

int simpvaropchst(varholder var1,stack which1,void operation(void **operand1));
    /* Izvrsi operacijo operation nad elementi spremenljivke var1. which1 pove,
    nad katero podtabelo spremenljivke var1 se izvrsi operacija. Funkcija je
    podobna funkciji simpvaropst(), le da operacija, ki se izvrsi, lahko spremeni
    elemente spremenljivke var1 in je zato tipa void (void **).
     Pravila glede dimenzij:
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladiu which1 se nanasajo na prve indekse ustrezne
    spremenljivke. Ce katerakoli od njihovih dimenzij ni v obsegu ustrezne
    dimenzije ali ce je indeksov vec kot ustreznih dimenzij (rang
    spremenljivke), je to napaka. Elementi na tem skladu so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
    $A Igor mar98; */

int simpvaropeldatast(varholder var1,stack which1,
                    void operation(void *operand1,stack elst));
    /* Izvrsi operacijo operation nad elementi spremenljivke var1. which1 pove,
    nad katero podtabelo spremenljivke var1 se izvrsi operacija. Funkciji
    operation(), ki izvede operacijo, posreduje ta funkcija prek njenega
    drugega argumenta sklad, na katerem so indeksi, ki dolocajo element, nad
    katerim se izvede operacija, na nosilcu var1.
     Pravila glede dimenzij:
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladiu which1 se nanasajo na prve indekse ustrezne
    spremenljivke. Ce katerakoli od njihovih dimenzij ni v obsegu ustrezne
    dimenzije ali ce je indeksov vec kot ustreznih dimenzij (rang
    spremenljivke), je to napaka. Elementi na tem skladu so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
    $A Igor mar98; */

int unvaropst(varholder var1,stack which1,varholder *res,stack whichres,
            void *operation(void *operand1,void **res),void disp(void **));
    /* Izvrsi unarno operacijo operation nad elementi spremenljivke var1, pri
    cemer se rezultati spravijo kot elementi spremenljivke res. which1 pove,
    nad katero podtabelo spremenljivke var1 se izvrsi operacija, whichres pa
    pove, v katero podtabelo spremenljivke *res se spravijo rezultati.
     Pravila glede dimenzij:
     Ce na skladu whichres ni nobenih indeksov, je lahko dimenzija
    spremenljivke *res razlicna od dimenzije podtabele, nad katero se izvaja
    operacija. V tem primeru se spremenljivka *res najprej zbrise z vsemi
    elementi vred, nato pa se tvori na novo tako, da so vsi elementi pred
    izvedbo operacije enaki NULL in je dimenzija spremenljivke enaka dimenziji
    podtabele, nad katero se izvede operacija. Za brisanje elementov podtabele
    se uporabi funkcija disp (ce je disp==NULL, se elementi ne brisejo).
     Ce je na skladu whichres kak indeks, mora biti dimenzija podtabele
    spremenljivke *res, ki jo dolocajo indeksi na which, nujno enaka dimenziji
    podtabele, nad katero se izvede operacija operation.
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce  je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladih whichres in which1 se nanasajo na prve indekse
    ustreznih spremenljivk. Ce katerakoli od njihovih dimenzij ni v
    obsegu ustrezne dimenzije ali ce je indeksov vec kot ustreznih dimenzij
    (rang spremenljivke), je to napaka. Elementi na teh skladih so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
    $A Igor jan98 mar98; */

int unvaropchst(varholder var1,stack which1,varholder *res,stack whichres,
            void *operation(void **operand1,void **res),void disp(void **));
    /* Izvrsi unarno operacijo operation nad elementi spremenljivke var1, pri
    cemer se rezultati spravijo kot elementi spremenljivke res. Operacija je
    taksna, da lahko spremeni 1. operand, zatoje njen 1. argument tipa void **.
    Vse ostalo je isto kot pri funkciji unvaropst().
    $A Igor mar98; */

int binvaropst(varholder var1,stack which1, varholder var2,stack which2,
             varholder *res,stack whichres,
             void *operation(void *operand1,void *operand2,void **res),
             void disp(void **));
    /* Izvrsi binarno operacijo operation nad elementi spremenljivk var1 in
    var2, pri cemer se rezultati spravijo kot elementi spremenljivke res.
    which1 in which2 povesta, nad katerima podtabelama spremenljivk var1 in
    var2 se izvrsi operacija, whichres pa pove, v katero podtabelo
    spremenljivke *res se spravijo rezultati.
     Pravila glede dimenzij:
     Dimenziji podtabel, ki ju dolocata which1 in which2, morata biti enaki,
    razen, ce je vsaj na eni od teh podtabel en sam element (rang podtabele
    enak 0). V tem primeru se operacija izvede nad vsakim elementom podtabele,
    katere rang je vecji od 0, in nad edinim elementom druge tabele.
     Ce na skladu whichres ni nobenih indeksov, je lahko dimenzija
    spremenljivke *res razlicna od dimenzije podtabele, nad katero se izvaja
    operacija. V tem primeru se spremenljivka *res najprej zbrise z vsemi
    elementi vred, nato pa se tvori na novo tako, da so vsi elementi pred
    izvedbo operacije enaki NULL in je dimenzija spremenljivke enaka dimenziji
    podtabele, nad katero se izvede operacija. Za brisanje elementov podtabele
    se uporabi funkcija disp (ce je disp==NULL, se elementi ne brisejo).
     Ce je na skladu whichres kak indeks, mora biti dimenzija podtabele
    spremenljivke *res, ki jo dolocajo indeksi na which, nujno enaka dimenziji
    podtabele, nad katero se izvede operacija operation.
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce  je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladih whichres, which1 in which2 se nanasajo na prve
    indekse ustreznih spremenljivk. Ce katerakoli od njihovih dimenzij ni v
    obsegu ustrezne dimenzije ali ce je indeksov vec kot ustreznih dimenzij,
    je to napaka. Elementi na teh skladih so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
    $A Igor jan98 mar98; */




/**************************************************************

                     DELO S SKLADI

***************************************************************/


int simpvaropnamest(stack st1, char *name1, stack which1,
                  void operation(void *operand1));
    /* Izvede operacijo simpvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropnamesortst().
    $A Igor mar98; */

int simpvaropnamesortst(stack st1, char *name1, stack which1,
                  void operation(void *operand1));
    /* Izvede operacijo simpvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropnamest().
    $A Igor mar98; */

int simpvaropchnamest(stack st1, char *name1, stack which1,
                  void operation(void **operand1));
    /* Izvede operacijo simpvaropchst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropchst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropchnamesortst().
    $A Igor mar98; */

int simpvaropchnamesortst(stack st1, char *name1, stack which1,
                  void operation(void **operand1));
    /* Izvede operacijo simpvaropchst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropchst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropchnamest().
    $A Igor mar98; */

int simpvaropeldatanamest(stack st1, char *name1, stack which1,
                  void operation(void *operand1,stack elst));
    /* Izvede operacijo simpvaropeldatast() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropeldatast() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropeldatast(). Ce ne najde operanda z imenom name1 na skladu
    st1, vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropeldatast.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropeldatanamesortst().
    $A Igor mar98; */

int simpvaropeldatanamesortst(stack st1, char *name1, stack which1,
                  void operation(void *operand1,stack elst));
    /* Izvede operacijo simpvaropeldatast() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropeldatast() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropeldatast(). Ce ne najde operanda z imenom name1 na skladu
    st1, vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropnamest().
    $A Igor mar98; */

int unvaropnamest(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void *operand1,void **res),void disp(void **));
    /* Izvede unarno operacijo unvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    unvaropnamesortst().
    $A Igor jan98 mar98; */

int unvaropnamesortst(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void *operand1,void **res),void disp(void **));
    /* Izvede unarno operacijo unvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    unvaropnamest().
    $A Igor jan98 mar98; */


int unvaropchnamest(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void **operand1,void **res),void disp(void **));
    /* Izvede unarno operacijo unvaropchst() nad objektom tipa varholder, ki je
    na skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropchst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropchst().
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropchst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    unvaropchnamesortst().
    $A Igor mar98; */

int unvaropchnamesortst(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void **operand1,void **res),void disp(void **));
    /* Izvede unarno operacijo unvaropchst() nad objektom tipa varholder, ki je
    na skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropchst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropchst().
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropchst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    unvaropchname().
    $A Igor mar98; */

int binvaropnamest(stack st1,char *name1,stack which1,
                 stack st2,char *name2,stack which2,
                 stack stres,char *nameres,stack whichres,
                 void *operation(void *,void *,void **),void disp(void **));
    /* Izvede binarno operacijo binvaropst() nad objektoma tipa varholder, ki sta
    na skladih st1 in st2 in imata imeni name1 in name2. Rezultati se spravijo
    v objekt, ki je na skladu stres in ima ime nameres. Ostali argumenti so
    neposredno argumenti funkcije binvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezne objekte na skladih in izvede nad njimi
    funkcijo binvaropst(). Ce ne najde 1.  ali 2. operanda z ustreznim imenom
    na ustreanem skladu, vrne ustrezno kodo napake (opisni niz za to kodo vrne
    funkcija varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne binvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu binvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    binvaropnamesortst().
    $A Igor jan98 mar98; */

int binvaropnamesortst(stack st1,char *name1,stack which1,
                 stack st2,char *name2,stack which2,
                 stack stres,char *nameres,stack whichres,
                 void *operation(void *,void *,void **),void disp(void **));
    /* Izvede binarno operacijo binvaropst() nad objektoma tipa varholder, ki sta
    na skladih st1 in st2 in imata imeni name1 in name2. Rezultati se spravijo
    v objekt, ki je na skladu stres in ima ime nameres. Ostali argumenti so
    neposredno argumenti funkcije binvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezne objekte na skladih in izvede nad njimi
    funkcijo binvaropst(). Ce ne najde 1.  ali 2. operanda z ustreznim imenom
    na ustreanem skladu, vrne ustrezno kodo napake (opisni niz za to kodo vrne
    funkcija varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne binvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu binvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR!!
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    binvaropnamesortst().
    $A Igor jan98 mar98; */



       /* NEWER VERSIONS */


char *makeindspecstring(indtab it);
    /* Returns a string that represents index specification it, with comma
    separated indices in square brackets. The returned string can  be deleted
    by free().
    $A Igor nov02; */

void fprintindspec(FILE *fp,indtab it);
    /* Prints comma separated indices on it in square brackets to the file fp.
    $A Igor nov02; */

void printindspec(indtab it);
    /* Prints comma separated indices on it in square brackets to the standard
    output.
    $A Igor nov02; */

void sprintindspec(char *ptr,indtab it);
    /*  Prints comma separated indices on the index table it in square brackets
    on the string buffer ptr, which must provide enough space for this task.
    $A Igor nov02; */

int wholevardim(varholder var);
    /* Vrne celotno dimenzijo spremenljivke, ki jo predstavlja var. To je
    produkt posameznih dimenzij na var->dim. Ce je rang var enak 0 (v primeru,
    ko je var->rank==0 in var->v!=NULL), vrne 1. Ce var ni pripravljena za
    nosenje vrednosti, vrne funkcija 0.
    $A igor dec97; */

char equalvardimit(varholder var,indtab it);
    /* returns 1 if the dimensions of the varholder var agree with the
    dimensions on it, otherwise it returns 0.
    $A Igor nov02; */

char equalvardim(varholder var1,varholder var2);
    /* returns 1 if the dimensions of the varholder var1 agree with the
    dimensions of var2, otherwise it returns 0. If either var1 or var2 or
    both are NULL, 0 is returned.
    $A Igor nov02; */

void fprintvarholderspecname(FILE *fp,varholder v,
                             void fprintel(FILE *fp,void *ptr,char *name));
    /* Prints data about the variable v to the file fp. It also prints elements
    of v by the function fprintel(), which prints a specific element with a
    given name.
    $A Igor feb98; */

void printvarholderspecname(varholder v,void printel(void *,char *));
    /* Prints data about the variable v to the standard output. It also prints
    elements of v by the function fprintel(), which prints a specific element
    with a given name.
    $A Igor feb98; */

void fprintvarholderspec(FILE *fp,varholder v,void fprintel(FILE *,void *));
    /* Prints data about the variable v to the file fp. Elements of v are
    printed by the function fprintel().
    $A Igor feb98; */

void printvarholderspec(varholder v,void printel(void *));
    /* Prints data about the variable v to the standard output. Elements of v
    are printed by the function fprintel().
    $A Igor feb98; */

void fprintvarholder(FILE *fp,varholder v);
    /* Prints data about the variable v to the file fp.
    $A Igor jan98, feb98; */

void printvarholder(varholder v);
    /* Prints data about the variable v to the standard output.
    $A Igor jan98, feb98; */

varholder newvarholder(indtab dimit);
    /* Allocates space for a new varholder and returns a pointer to the
    allocated object. dimit must contain dimensions of the returned varholder
    (this enables use of multi-dimensional variables of arbitrary ranks, e.g.
    of dimensions 3x2x5). If dimit is NULL, then tehe returned varholder is of
    rank 0 and a single element can be stored on it (i.e. in the corresponding
    variable represented by the varholder). The same situation occur if
    dimit->n is 0.
      The returned object has the table of elements (...)->v already allocated,
    The rank (...)->rank is seto to the number of indices of dimit, and
    (...)->dim contains the dimensions from it.
    $A Igor nov02; */

varholder newvarholdername(char *name,indtab dimit);
    /* Creates a new varholder object named name. dimit must be a table of
    dimension of the created varholder. The function allocates the space by
    the function newvarholderst(), copies the string name to the field
    (...)->name (space for this is allocated) and returns the created object.
    $A Igor nov02; */

varholder newvarholdernametype(char *name,int type,indtab dimit);
    /* Creates a new varholder object named name of the type type and returns
    its pointer.
    $A Igor avg01; */

void dispvarholder(varholder *pointvar);
    /* Deallocates the varholder pointed to by *pointvar and sets this pointer
    to NULL. The function does not delete the variable elements, which are on
    var->v (since it does not know what types of objects these are).
    $A Igor jan98; */

indtab getvardim(varholder var,indtab *dimp);
    /* Updates index table *dimp in such a way that it contains dimensions of
    the variable represented by the varholder var, and returns *dimp. dimp
    can be NULL, in this case a newly created index table or NULL is returned,
    dependent on the dimensions of var.
      After the function call, *dimp (or the returned index table) is such that
    the function newvarholder() called with *dimp as its argument returns a
    varholder with the same dimensions as var. If var is NULL or var->rank<0,
    then *dimp becomes NULL. If var->rank is 0, then *dimp becomes an
    allocated, but empty index table. If var->rank>0, then *dimp contains
    var->rank indices whose values are equal to the dimensions contained in
    var->dim.
    $A Igor nov02 */

int calcvarplace(varholder var,indtab it);
    /* Calculates and returns the consecutive number of the element defined
    by indices in it, in the element table of varholder var, or 0, if the
    element specified does not exist. If var->rank is 0, it must be NULL or
    nt->n must be 0 in order to return a non-zero value (namely 1).
    $A Igor nov02; */

int setvar(varholder var,void *p,int place);
    /* Puts the pointer p to the absolute place place in the element table of
    var, if this is possible, and returns place or 0, if this is not possible
    (e.g. if the elment table has less entries than place). If place==0, it is
    taken as 1.
    $A Igor nov01; */

void dispvarval(varholder var);
    /* Delets all elements form the varholder var by free() and sets the
    corresponding pointers to NULL. For deleting of elements that are of more
    complex types, the functio dispvarvalspec() must be used.
    $A Igor nov02; */

void dispvarvalspec(varholder var,void disp (void **));
    /* Delets all elements form the varholder var using function disp(), which
    must set pointer to NULL after deletion.
    $A Igor nov02; */

void dispwholevar(varholder *var);
    /* Deallocates the space occupied by *var and sets *var to NULL. Elements
    of var (contained in (*var)->v) are deleted by free(), therefore for
    varholders containing more complex objects, function dispwholevarspec()
    must be used.
    $A Igor nov01; */

void dispwholevarspec(varholder *var,void (*disp)(void **));
    /* Deallocates the spece occupied by *var and sets *var to NULL. Elements
    of *var (contained in (*var)->v) are deleted by disp()
    $A Igor nov02; */

void *varel(varholder var,indtab idx);
    /* Returns the element of var specified by indices on idx, as void *, or
    NULL, if such element does not exist.
    $A Igor nov 02; */

void **vareladdr(varholder var,indtab idx);
    /* Returns the address of the element specified by indices idx of var as
    void **, or NULL if indices are not in range.
    $A Igor nov02; */

void *varelfirst(varholder var);
    /* Returns the first element of var, or NULL, if such element does not
    exist.
    $A Igor aug04; */

void **vareladdrfirst(varholder var);
    /* Returns the address of the first element of var as void **, or NULL if
    indices are not in range.
    $A Igor aug04; */

int simpvarop(varholder var1,indtab which1,void operation(void *operand1));
    /* Performs the operation operation on elements of the varholder
    var1. Index table which1 determines the sub-table of elements on which
    the operation is performed.
      Rules concerning dimensions:
     if which1==NULL or which1->n==0, the operation is performed on all
    elements of var1.
     Indices on which1 correspond to the first dimensions of var1. If any of
    them exceeds the corresponding dimension or the number of indices is
    greater than the number of dimensions of var1, this is an error.
      If an error occurs, the function returns the code of the error. We can
    call the function varoperrorstr() with this code as argument to get a
    string that describes the nature of the error. If everything is OK, the
    number of performed operations is returned.
    $A Igor nov02; */

int simpvaropch(varholder var1,indtab which1,void operation(void **operand1));
    /* Perfomrs the operation "operation()" on those elements of var1, which
    are specified by indices on which1. The operation is such that it can
    change elements, not only use their values (therefore its argument is of
    type void **). For each affected element of var1, operation is called with
    its address as the argument.
      Indices on which1 determine the sub-table of elements of var1 on which
    the operation is performed. If which1==NULL or which1->n==0, then the
    whole table of elements is meant and the operation is performed in turns on
    each of the elements in the element table vari->v. The order is such that
    the last indices vary the most quickly.
      Indices on which1 refer to the first dimensions of var1. If any of them
      is not in the range of the corresponding dimension or if there are more
    indices than the number of dimensions of var1, this is an error.
      If an error occurs, the function returns the code of the error (always
    a negative number), otherwise it returns the number of executions of the
    operation. In the case of error, the function varoperrorstr() can be
    called on the returned error code in order to get a string description of
    the error.
    $A Igor nov02; */

int simpvaropeldata(varholder var1,indtab which1,
                    void operation(void *operand1,indtab elit));

    /* Performs the operation operation on elements of the varholder
    var1. Index table which1 determines the sub-table of elements on which
    the operation is performed. Beside of the element on which it acts, the
    operation also gets the indices of this element through its second
    argument (as an object of type indtab), so that they can be printed, for
    example.
      Rules concerning dimensions:
     if which1==NULL or which1->n==0, the operation is performed on all
    elements of var1.
     Indices on which1 correspond to the first dimensions of var1. If any of
    them exceeds the corresponding dimension or the number of indices is
    greater than the number of dimensions of var1, this is an error.
      If an error occurs, the function returns the code of the error. We can
    call the function varoperrorstr() with this code as argument to get a
    string that describes the nature of the error. If everything is OK, the
    number of performed operations is returned.
    $A Igor nov02; */

int unvarop(varholder var1,stack which1,varholder *res,stack whichres,
            void *operation(void *operand1,void **res),void disp(void **));
    /* 
    $$
    Izvrsi unarno operacijo operation nad elementi spremenljivke var1, pri
    cemer se rezultati spravijo kot elementi spremenljivke res. which1 pove,
    nad katero podtabelo spremenljivke var1 se izvrsi operacija, whichres pa
    pove, v katero podtabelo spremenljivke *res se spravijo rezultati.
     Pravila glede dimenzij:
     Ce na skladu whichres ni nobenih indeksov, je lahko dimenzija
    spremenljivke *res razlicna od dimenzije podtabele, nad katero se izvaja
    operacija. V tem primeru se spremenljivka *res najprej zbrise z vsemi
    elementi vred, nato pa se tvori na novo tako, da so vsi elementi pred
    izvedbo operacije enaki NULL in je dimenzija spremenljivke enaka dimenziji
    podtabele, nad katero se izvede operacija. Za brisanje elementov podtabele
    se uporabi funkcija disp (ce je disp==NULL, se elementi ne brisejo).
     Ce je na skladu whichres kak indeks, mora biti dimenzija podtabele
    spremenljivke *res, ki jo dolocajo indeksi na which, nujno enaka dimenziji
    podtabele, nad katero se izvede operacija operation.
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce  je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladih whichres in which1 se nanasajo na prve indekse
    ustreznih spremenljivk. Ce katerakoli od njihovih dimenzij ni v
    obsegu ustrezne dimenzije ali ce je indeksov vec kot ustreznih dimenzij
    (rang spremenljivke), je to napaka. Elementi na teh skladih so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
    $A Igor jan98 mar98; */

int unvaropch(varholder var1,stack which1,varholder *res,stack whichres,
            void *operation(void **operand1,void **res),void disp(void **));
    /* 
    $$
    Izvrsi unarno operacijo operation nad elementi spremenljivke var1, pri
    cemer se rezultati spravijo kot elementi spremenljivke res. Operacija je
    taksna, da lahko spremeni 1. operand, zatoje njen 1. argument tipa void **.
    Vse ostalo je isto kot pri funkciji unvaropst().
    $A Igor mar98; */

int binvarop(varholder var1,stack which1, varholder var2,stack which2,
             varholder *res,stack whichres,
             void *operation(void *operand1,void *operand2,void **res),
             void disp(void **));
    /* 
    $$
    Izvrsi binarno operacijo operation nad elementi spremenljivk var1 in
    var2, pri cemer se rezultati spravijo kot elementi spremenljivke res.
    which1 in which2 povesta, nad katerima podtabelama spremenljivk var1 in
    var2 se izvrsi operacija, whichres pa pove, v katero podtabelo
    spremenljivke *res se spravijo rezultati.
     Pravila glede dimenzij:
     Dimenziji podtabel, ki ju dolocata which1 in which2, morata biti enaki,
    razen, ce je vsaj na eni od teh podtabel en sam element (rang podtabele
    enak 0). V tem primeru se operacija izvede nad vsakim elementom podtabele,
    katere rang je vecji od 0, in nad edinim elementom druge tabele.
     Ce na skladu whichres ni nobenih indeksov, je lahko dimenzija
    spremenljivke *res razlicna od dimenzije podtabele, nad katero se izvaja
    operacija. V tem primeru se spremenljivka *res najprej zbrise z vsemi
    elementi vred, nato pa se tvori na novo tako, da so vsi elementi pred
    izvedbo operacije enaki NULL in je dimenzija spremenljivke enaka dimenziji
    podtabele, nad katero se izvede operacija. Za brisanje elementov podtabele
    se uporabi funkcija disp (ce je disp==NULL, se elementi ne brisejo).
     Ce je na skladu whichres kak indeks, mora biti dimenzija podtabele
    spremenljivke *res, ki jo dolocajo indeksi na which, nujno enaka dimenziji
    podtabele, nad katero se izvede operacija operation.
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce  je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladih whichres, which1 in which2 se nanasajo na prve
    indekse ustreznih spremenljivk. Ce katerakoli od njihovih dimenzij ni v
    obsegu ustrezne dimenzije ali ce je indeksov vec kot ustreznih dimenzij,
    je to napaka. Elementi na teh skladih so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
    $A Igor jan98 mar98; */

char *varoperrorstr(int error);
    /* Vrne niz,ki opisuje napako s kodo error, ki se je pojavila v funkciji
    unvaropst() ali binvaropst(). Niza se ne sme brisati s free()!
    $A Igor jan98; */



/**************************************************************

                     WORK WITH STACKS

***************************************************************/



int findstackvar(stack st,char *name,int from,int to);
    /* Na skladu st poisce med mestoma from in to spremenljivko (objekt tipa
    varholder) z imenom name ter vrne pozicijo spremenljivke na skladu.
    $A Igor jan98; */

int findsortstackvar(stack st,char *name,int from,int to);
    /* Na skladu st poisce med mestoma from in to spremenljivko (objekt tipa
    varholder) z imenom name ter vrne pozicijo spremenljivke na skladu. Kazalci
    tipa varholder morajo biti na skladu st sortirani po imenih od najmanjsega
    do najvecjega glede na funkcijo strcmp.
    $A Igor jan98; */

int insstackvar(stack st,varholder var);
    /* var da na konec sklada st in vrne zaporedno stevilko na skladu, kjer je
    po izvedbi funkcije var. Ce je st==NULL, vrne 0.
    $A Igor jan98; */

int inssortstackvar(stack st,varholder var);
    /* Kazalec var vrine na ustrezno mesto na sortiranem skladu st tako, da
    sklad ostane sortiran glede na polja (...)->name kazalcev, ki so nalozeni
    nanj. Funkcija vrne mesto na skladu, kamor se vrine var (oz. stevilo manjse
    od 1, ce kazalca var ni mozno vriniti na sklad).
    $A Igor jan98; */

int delstackvar(stack st,char *name);
    /* Na skladu st poisce spremenljivko z imenom name, ki jo predstavlja
    kazalec tipa varholder, in jo zbrise. Zbrise celotno vsebino spremenljivke,
    pri cemer posamezne elemente na (...)->v brise s funkcijo free(). Po
    brisanju spremenljivke sbrise se nastalo prazno mesto na skladu s funkcijo
    delstack().
     Funkcija vrne mesto na skladu st, na katerem je bila spremenljivka z
    imenom name, oziroma stevilo manjse od 1, ce spremenljivke ni nasla.
    $A Igor jan98; */

int delstackvarspec(stack st,char *name,void disp(void**));
    /* Na skladu st poisce spremenljivko z imenom name, ki jo predstavlja
    kazalec tipa varholder, in jo zbrise. Zbrise celotno vsebino spremenljivke,
    pri cemer posamezne elemente na (...)->v brise s funkcijo disp(). Po
    brisanju spremenljivke sbrise se nastalo prazno mesto na skladu s funkcijo
    delstack().
     Funkcija vrne mesto na skladu st, na katerem je bila spremenljivka z
    imenom name, oziroma stevilo manjse od 1, ce spremenljivke ni nasla.
    $A Igor jan98; */

int simpvaropname(stack st1, char *name1, stack which1,
                  void operation(void *operand1));
    /* 
    $$
    Izvede operacijo simpvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropnamesortst().
    $A Igor mar98; */

int simpvaropnamesort(stack st1, char *name1, stack which1,
                  void operation(void *operand1));
    /* 
    $$
    Izvede operacijo simpvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropnamest().
    $A Igor mar98; */

int simpvaropchname(stack st1, char *name1, stack which1,
                  void operation(void **operand1));
    /* 
    $$
    Izvede operacijo simpvaropchst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropchst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropchnamesortst().
    $A Igor mar98; */

int simpvaropchnamesort(stack st1, char *name1, stack which1,
                  void operation(void **operand1));
    /* 
    $$
    Izvede operacijo simpvaropchst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropchst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropchnamest().
    $A Igor mar98; */

int simpvaropeldataname(stack st1, char *name1, stack which1,
                  void operation(void *operand1,stack elst));
    /* 
    $$
    Izvede operacijo simpvaropeldatast() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropeldatast() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropeldatast(). Ce ne najde operanda z imenom name1 na skladu
    st1, vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropeldatast.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropeldatanamesortst().
    $A Igor mar98; */

int simpvaropeldatanamesort(stack st1, char *name1, stack which1,
                  void operation(void *operand1,stack elst));
    /* 
    $$
    Izvede operacijo simpvaropeldatast() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropeldatast() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropeldatast(). Ce ne najde operanda z imenom name1 na skladu
    st1, vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropnamest().
    $A Igor mar98; */

int unvaropname(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void *operand1,void **res),void disp(void **));
    /* 
    $$
    Izvede unarno operacijo unvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    unvaropnamesortst().
    $A Igor jan98 mar98; */

int unvaropnamesort(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void *operand1,void **res),void disp(void **));
    /* 
    $$
    Izvede unarno operacijo unvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    unvaropnamest().
    $A Igor jan98 mar98; */

int unvaropchname(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void **operand1,void **res),void disp(void **));
    /* 
    $$
    Izvede unarno operacijo unvaropchst() nad objektom tipa varholder, ki je
    na skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropchst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropchst().
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropchst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    unvaropchnamesortst().
    $A Igor mar98; */

int unvaropchnamesort(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void **operand1,void **res),void disp(void **));
    /* 
    $$
    Izvede unarno operacijo unvaropchst() nad objektom tipa varholder, ki je
    na skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropchst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropchst().
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropchst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    unvaropchname().
    $A Igor mar98; */

int binvaropname(stack st1,char *name1,stack which1,
                 stack st2,char *name2,stack which2,
                 stack stres,char *nameres,stack whichres,
                 void *operation(void *,void *,void **),void disp(void **));
    /* 
    $$
    Izvede binarno operacijo binvaropst() nad objektoma tipa varholder, ki sta
    na skladih st1 in st2 in imata imeni name1 in name2. Rezultati se spravijo
    v objekt, ki je na skladu stres in ima ime nameres. Ostali argumenti so
    neposredno argumenti funkcije binvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezne objekte na skladih in izvede nad njimi
    funkcijo binvaropst(). Ce ne najde 1.  ali 2. operanda z ustreznim imenom
    na ustreanem skladu, vrne ustrezno kodo napake (opisni niz za to kodo vrne
    funkcija varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne binvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu binvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    binvaropnamesortst().
    $A Igor jan98 mar98; */

int binvaropnamesort(stack st1,char *name1,stack which1,
                 stack st2,char *name2,stack which2,
                 stack stres,char *nameres,stack whichres,
                 void *operation(void *,void *,void **),void disp(void **));
    /* 
    $$
    Izvede binarno operacijo binvaropst() nad objektoma tipa varholder, ki sta
    na skladih st1 in st2 in imata imeni name1 in name2. Rezultati se spravijo
    v objekt, ki je na skladu stres in ima ime nameres. Ostali argumenti so
    neposredno argumenti funkcije binvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezne objekte na skladih in izvede nad njimi
    funkcijo binvaropst(). Ce ne najde 1.  ali 2. operanda z ustreznim imenom
    na ustreanem skladu, vrne ustrezno kodo napake (opisni niz za to kodo vrne
    funkcija varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne binvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu binvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR!!
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    binvaropnamesortst().
    $A Igor jan98 mar98; */












    /* SISTEM ZA MANIPULACIJO S TIPI SPREMENLJIVK: */


int assocvartypename(int type,char *name);
    /* V sistem za manipulacijo s tipi spremenljivk instalira povezavo med
    tipom type in nizom name. Funkcija doda tip type doda na indeksno tabelo
    legalnih tipov legaltypes, na sklad imenskih asociacij tipov typenames
    pa doda varholder z imenom name in tipom type, ce se ne obstaja.
    Funkcija vrne 0, ce pride do kaksne napake,
    $A Igor avg01; */

void assocdefaultvartypenames(void);
    /* Naredi seznam standardnih legalnih tipov spremenljivk s pripadajocimi
    imeni.
    $A Igor avg01; */

void fprintvartypesinfo(FILE *fp);
    /* V fp izpise podatke o legalnih tipih spremenljivk in o imenih, ki jih
    lahko zanje uporabljamo.
    $A Igor avg01; */

void printvartypesinfo(void);
    /* Izpise podatke o legalnih tipih spremenljivk in o imenih, ki jih
    lahko zanje uporabljamo.
    $A Igor avg01; */

int legalvartype(varholder var);
    /* Vrne 0, ce spremenljivka var ni legalnega tipa, in zaporedno stevilko
    njenega tipa na skladu legalnih tipov, ce je.
    $A Igor avg01; */

int legalvartypename(char *name);
    /* Vrne 0, ce str ni legalno ime tipa spremenljivke, ce pa je, vrne
    zaporedno stevilko povezanega tipa na skladu legaltypes.
    $A Igor avg01; */

int vartypename(char *name);
    /* Vrne vt_none (0), ce str ni legalno ime tipa spremenljivke, ce pa je,
    vrne tip, ki je povezan s tem imenom.
    $A Igor avg01; */

void testvartypemanipulation(void);
    /* Izvede test funkcij za manipulacijo s tipi spremanljivk.
    $A Igor avg01; */


/* KONEC FUNKCIJ ZA MANIPULACIJO S TIPI */








#endif    /* (not defined) INCLUDED_varop */
