



void invinstalluserfunc(void);
    /* V program Inverse instalira uporabnske funkcije interpreterja in
    kalkulatorja.
    $A Igor sep01; */

void invinstalldomen(void);
