

         /***************************************/
         /*                                     */
         /*      LIMITED RANGE ENFORCEMENT      */
         /*                                     */
         /***************************************/



#ifndef INCLUDED_limfunc
#define INCLUDED_limfunc

#ifndef INCLUDED_rf
 #include <rf.h>
#endif




double limfuncexpid(double x,double min,double max,double d);
    /* Returns the value of the limiting function that is composed of two
    assymptotic exponential branches and an identity function between them.
    The function is monotonic and continuously differential with respect to x.
      x is the independent variable, min is minimum and max is maximum value
    of the function and d is range of each assymptotic branch (must be less
    or equal to (max-min)/2!).
    $A Igor oct03; */

double derlimfuncexpid(double x,double min,double max,double d);
    /* Returns the derivative of limfuncexpid.
    $A Igor oct03; */


double invlimfuncexpid(double y,double min,double max,double d);
    /* Returns the inverse of limfuncexpid. If y is less or equal to min or
    greater or equal to max then minus or plus infinity is returned,
    respectively.
    $A Igor oct03; */











#endif    /* (not defined) INCLUDED_limfunc */
