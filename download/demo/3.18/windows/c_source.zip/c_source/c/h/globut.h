


    /* GLOBAL UTILITIES (definition of directories, resources, editor, browser,
    program data...) */


/* Cote that ensures inclusion of necessary headers if they have not yet been 
included in the enclosing source file: */
#ifndef INCLUDED_st
#include <st.h>
#endif


/* Code that enables inclusion of this file in header files without taking care
of whether this header has already been included in the enclosing source file,
since this is explicitly checked through definition of the appropriate macro
and ensured through conditional compilation: */
#ifndef INCLUDED_globut
#define INCLUDED_globut





typedef struct {
  char *ighome;
  char *program;  /* Human readable name of the program */
  char *prog;   /* Computer name of the program */
  char *author;    /* Programe author */
  char *authormail;  /* Programe author's mail  */
  char *authorad1,*authorad2; /* Two parts of author's address */
  char *www,*mail;  /* www and mail address */
  int version,subversion; /* Version specification */
  int session;  /* Session number */
  double doubleversion;   /* Double version specification */
  char * stringversion;   /* String version specification */
  char * verspec;  /* For example "DEMO", "shareware", "full", "professinal"... */
  int dd0,mm0,yy0;  /* Date of creation */
  int dd,mm,yy;     /* Expiration date */
  int dd1,mm1,yy1;  /* Reserve creation date */
  /* Main resource directories: Version directory, home directory, session directory */
  char *progdir,*verdir;
  /* Session identification number, session file and session directory: */
  int sesid;
  char *sesfile,*sesdir;
  char *editor,*viewer,*browser; /* Commands for editing, viewing & browsing */
  char *tmpnam;
} _globutdata;

typedef _globutdata *globutdata;




    /* CHANGING THE DEFAULT SOFTWARE HOME NAME SETTINGS: */

void setighomenames(char *envvar,char *idfile,char *markfile,
                    char *defaultname);
    /* Changes the default names related to the software home directory. If any
    of the function arguments is NULL or "", then the corresponding name is not
    changed. Otherwise the corresponding name is set to the argument. Copy of
    the argument is made to represent a given name, therefore the strings passed
    as arguments to this function may be deallocated after the call.
      Meaning of the arguments:
      envvar - the environment variable assigned to store the location of the
    software home directory.
      idfile - name of the identification file which must exist in the software
    home directory in order to identify that this is really a software home.
      markfile - name of the mark file which can be put to a number of standard
    locations on the file system (dependet on the operating system) in order to
    identify the location of the software home. This mechanism is handled
    automatically by this module and enables fast location fo the software home
    directory in the case that the appropriate environment variable is not set
    or is not set correctly.
      defaultname - Usual name of the software root directory. This name can be
    overridden by the user when installing the first software that uses this
    system.
      REMARKS
      This module works in such a way that the software root directory should be
    correctly identified even if the environment variable is not set correctly
    or if mark files do not identify the correct location of software root.
    Information on the location is always checked and any uncorrect information
    (e.g. in mark files) tries to be corrected. The only limitation is that the
    identification fie may not be modified or copied somewhere else on the
    mounted file system.
      This function enables various different softwares to use the functionality
    of this module, but with different names and independently of other
    software.
    $A Igor apr03; */



    /* FUNCTIONS FOR IDENTIFYING THE LOCATION OF THE SOFTWARE HOME: */


void setighomesearch(int i);
    /* Enables (i=1) or disables (i=0) auto location of the software home
    directory.
    $A Igor apr03; */

void setighomereq(int i);
    /* Sets (i=1) or unsets (i=0) the ighome required option. If this option is
    set then, the program must have an ighome directory, but not necessarily
    the proper one (such with the file named ighomeidfile in it).
    $A Igor apr03; */

void setighomereqprop(int i);
    /* Sets (i=1) or unsets (i=0) the proper ighome required option. If this
    option is set, then the program must have a proper ighome directory, (such
    with the file named ighomeidfile in it).
    $A Igor apr03; */

void recighomeloc(stack list);
    /* Loads recommended ighome locations (= complete path of ighome) to the
    stack list, which must be allocated and preferably empty.
    $A Igor apr03; */

void recighomemarkloc(stack list);
    /* Loads recommended ighome mark locations to the stack list, which must be
    allocated and preferably empty.
    $A Igor apr03; */

char *readighomelocmark(char *filename);
    /* Reads the location of the software home directory from a file named
    filename and return its path as a dynamically allocated string. If it can
    not read the information (if the file is corrupted, not readable or not in
    the correct format), then NULL is returned.
    $A Igor apr03; */

void markighomeid(char *path);
    /* Identifies the identity of the softwaqre home directory at path so that
    search routines can locate it.
    If path is NULL then the current software home as 
    $A apr03; */

void markighomeloc(char *path,int num);
    /* Marks the software home location on the computer's file system, i.e.
    writes the path of the ighome directory to a number of files located in
    easily locatable pre-defined places (a list returned by recighomemarkloc).
    num is the maximal number of the locations in which the location is marked.
    It is always marked on at least two locations (for the case that a some
    temporary directory would have been identified as a suitable location).
    $A Igor apr03; */

char * locateighomefrommarks(void);
    /* Tries to locate the software home directory by checking a few standard
    locations on the file system for the mark files that indentify its location.
    Mark files are created by the function markighomeloc().
    $A Igor par03; */

char *locateighomeonfilesys(void);
    /* Searches the file system for the software home directory. It searches for
    the occurances of the directories named recighomename (static variable) and
    files named ighomeidfile. It returns the first valid software home
    directory, i.e. the directory that includes an identification file with
    properly formated identification. Only the system rood drive is searched
    for. The directories are recursively searched by levels (i.e. the root dir.
    first, then all of its contained directories, then contained directories of
    these directories, etc. While searching, files and directories are sorted by
    name and direcotiries are checked before files.
      The function returnes the path of the located software home or NULL if it
    could not be located. The returned string is dynamically allocated and
    can be deallocated by free().
    $A Igor apr03; */





        /**********************************/
        /*                                */
        /* INITIALIZATION OF GLOBAL DATA: */
        /*                                */
        /**********************************/


void fprintglobutdata(FILE *fp);
    /* Print global utility data to file fp.
    $A Igor jan02; */

void printglobutdata(void);
    /* Prints global utility data to standard output.
    $A Igor jan02; */

globutdata getglobutdata(void);
    /* Returns a pointer to the global utility data. If the data does not yer
    exists, it initialises it.
    $A Igor jan02; */



    /* FUNCTIONS FOR SETTING BASIC DATA: */

void globutsetprogram(char *program);
    /* Sets program name to program.
    $A Igor jan02; */

void globutsetprog(char *prog);
    /* Sets program computer name to prog.
    $A Igor jan02; */

void globutsetauthor(char *author);
    /* Sets author name to author.
    $A Igor jan02; */

void globutsetauthormail(char *authormail);
    /* Sets author's mail to authormail.
    $A Igor jan02; */

void globutsetauthorad1(char *authorad1);
    /* Sets first part of author's address to authorad1 (this information is
    rarely set).
    $A Igor jan02; */

void globutsetauthorad2(char *authorad2);
    /* Sets second part of author's address to authorad2 (this information is
    rarely set).
    $A Igor jan02; */

void globutsetwww(char *www);
    /* Sets www address of program home page to www.
    $A Igor jan02; */

void globutsetmail(char *mail);
    /* Sets program correspondence mail address to mail.
    $A Igor jan02; */

void globutsetversion(int version,int subversion);
    /* Sets program version to version and its subversion to subversion.
    If either of them is less than 0, it is not set (this enables setting
    version and subversion at different locations).
    $A Igor jan02; */

void globutsetverspec(char *verspec);
    /* Sets program version specification  to verspec (this should be for
    example "DEMO", "shareware", "full", "professinal", etc.)
    $A Igor jan02; */

void globutsetcreationdate(int dd,int mm,int yy);
   /* Sets program creation date to date specified by dd, mm and yy.
   $A Igor jan02; */

void globutsetexpirationdate(int dd,int mm,int yy);
   /* Sets program expiration date to date specified by dd, mm and yy.
   $A Igor jan02; */

void globutsetreserveexpirationdate(int dd,int mm,int yy);
   /* Sets program expiration date to date specified by dd, mm and yy.
   $A Igor jan02; */

void globutseteditor(char *editor);
    /* Sets external editor command to editor.
    $A Igor jan02; */

void globutsetviewer(char *viewer);
    /* Sets external viewer command to viewer.
    $A Igor jan02; */

void globutsetbrowser(char *browser);
    /* Sets external internet browser command to browser.
    $A Igor jan02; */




    /* FUNCTIONS FOR GETTING SPECIFIC DATA: */


char *globutgetprogram(void);
    /* Returns program name.
    $A Igor jan02; */

char *globutgetprog(void);
    /* Returns program computer name.
    $A Igor jan02; */

char *globutgetauthor(void);
    /* Returns author name.
    $A Igor jan02; */

char *globutgetauthormail(void);
    /* Returns author's mail.
    $A Igor jan02; */

char *globutgetauthorad1(void);
    /* Returns first part of author's address.
    $A Igor jan02; */

char *globutgetauthorad2(void);
    /* Returns second part of author's address.
    $A Igor jan02; */

char *globutgetwww(void);
    /* Returns www address of program home page.
    $A Igor jan02; */

char *globutgetmail(void);
    /* Returns program correspondence mail address.
    $A Igor jan02; */

int globutgetversion(void);
    /* Returns program version.
    $A Igor jan02; */

char *globutgetversionstr(void);
    /* Returns a string representation of program version. The returned
    pointer to string may not be de-allocated.
    $A Igor mar04; */

char *globutgetverspec(void);
    /* Returns program version specification (such as "DEMO", "sgareware"...).
    $A Igor jan02; */

int globutgetsubversion(void);
    /* Returns program subversion.
    $A Igor jan02; */

char *globutgetsubversionstr(void);
    /* Returns a string representation of program subversion. The returned
    pointer to string may not be de-allocated.
    $A Igor mar04; */

void globutgetcreationdate(int *dd,int *mm,int *yy);
   /* Writes program creation date to *dd, *mm and *yy.
   $A Igor jan02; */

void globutgetexpirationdate(int *dd,int *mm,int *yy);
   /* Writes program expiration date to *dd, *mm and *yy.
   $A Igor jan02; */

void globutgetreserveexpirationdate(int *dd,int *mm,int *yy);
   /* Writes program reserve expiration date to *dd, *mm and *yy.
   $A Igor jan02; */

char *globutgeteditor(void);
    /* Returns external editor command.
    $A Igor jan02; */

char *globutgetviewer(void);
    /* Returns external viewer command.
    $A Igor jan02; */

char *globutgetbrowser(void);
    /* Returns external browswer command.
    $A Igor jan02; */


  /* Data which is usually not set directly: */

char *globutgetighome(void);
    /* Returns baisc home directory. If none of initializations of the global
    utility system has been performed before the call to this function, the
    search for this directory is performed.
    $A Igor jan02 apr04; */

char *globutgetstringversion(void);
    /* Returns program version in string form.
    $A Igor jan02; */

char *globutgetprogdir(void);
    /* Returns programe directory.
    $A Igor jan02; */

char *globutgetverdir(void);
    /* Returns programe version directory.
    $A Igor jan02; */

int globutgetsesid(void);
    /* Returns session id or 0 if the program does not create sessions.
    $A Igor jan02; */

char *globutgetsesdir(void);
    /* Returns programe session directory.
    $A Igor jan02; */

char *globutgetsesfile(void);
    /* Returns programe session file.
    $A Igor jan02; */



    /* FUNCTIONS FOR UPDATING VARIOUS DEPENDENCIES: */

void globutupdatedates(void);
    /* Does the necessary houskeeping concerning dates: prompts to exit if the
    expiration date is exceeded, and exits unconditionally if also the reserve
    expiration date is exceeded (this can be prevented by not settting the
    reserve expiration date). */

void globutupdateversion(void);
    /* Updates dependent version data on basis of basic data.
    $A Igor jan02; */

void globutupdateprogdir(void);
    /* Updates directory dependencies; Also checks if individual directories
    are valid.
    $A Igor jan02; */

int globutremovesession(int id);
    /* Removes session directory and file for program session identifyed by id.
    Function returns 1 if the appropriate session file is found, 0 otherwise.
    $A Igor jan02; */

void globutremoveallsessions(void);
    /* Removes session files and directories for all existent sessions
    of the program.
    $A Igor jan02; */

void globutupdatesession(void);
    /* Finds an available session ID and creates session file and session
    directory in the directory gud->verdir/sessions. Name of the session file
    is written to gud->sesfile, name of the session directory to gud->sesdir
    and session ID to gud->ID. Function exits program if it can not find an
    available ID.
    $A Igor jan02; */

void globutupdateexternal(void);
    /* Tries to automatically set external editor, viewer and browser.
    $A Igor jan02; */

void globutinit(char progdir,char sesdir,char autoextern);
    /* Performs necessary initialisation and updates of dependencies on
    global utility data. This function is called after setting basic data,
    which is set automatically by the program. If progdir is 1, program will
    have its home directory. If sesdir is 1, program will allocate unique
    session directory. If autoextern is 0, external viewer, program and
    browser will be defined automatically if possible.
    $A Igor jan02 */

void globutend(void);
    /* Global utility clean-up;
    If session file or directory were created, they are deleted.
    $A Igor jan02; */




    /* FUNCTIONS FOR CHANGING SPECIFIC DATA (similar to functions for setting
    data, but include updating dependencies): */


void globutchangeprogram(char *program);
    /* Changes program name to program.
    $A Igor jan02; */

void globutchangeprog(char *prog);
    /* Changes program computer name to prog.
    $A Igor jan02; */

void globutchangeauthor(char *author);
    /* Changes author name to author.
    $A Igor jan02; */

void globutchangeauthormail(char *authormail);
    /* Changes author's mail to authormail.
    $A Igor jan02; */

void globutchangeauthorad1(char *authorad1);
    /* Changes the first part of author's address to authorad1.
    $A Igor jan02; */

void globutchangeauthorad2(char *authorad2);
    /* Changes the second part of author's address to authorad2.
    $A Igor jan02; */

void globutchangewww(char *www);
    /* Changes www address of program home page to www.
    $A Igor jan02; */

void globutchangemail(char *mail);
    /* Changes program correspondence mail address to mail.
    $A Igor jan02; */

void globutchangeversion(int version,int subversion);
    /* Changes program version to version and its subversion to subversion.
    If either of them is less than 0, it is not changed (this enables setting
    version and subversion at different locations).
    $A Igor jan02; */

void globutchangeverspec(char *verspec);
    /* Changes program version specification to verspec.
    $A Igor jan02; */

void globutchangecreationdate(int dd,int mm,int yy);
   /* Changes program creation date to date specified by dd, mm and yy.
   $A Igor jan02; */

void globutchangeexpirationdate(int dd,int mm,int yy);
   /* Changes program expiration date to date specified by dd, mm and yy.
   $A Igor jan02; */

void globutchangereserveexpirationdate(int dd,int mm,int yy);
   /* Changes program reserve expiration date to date specified by dd, mm and
   yy.
   $A Igor jan02; */

void globutchangeeditor(char *editor);
    /* Changes external (system) editor command to editor.
    $A Igor jan02; */

void globutchangeviewer(char *viewer);
    /* Changes external (system) viewer command to viewer.
    $A Igor jan02; */

void globutchangebrowser(char *browser);
    /* Changes external (system) internet browser command to browser.
    $A Igor jan02; */


  /* Data which is usually not set directly: */


void globutchangeighome(char *ighome);
    /* Changes the ighome directory to ighome. It then updates program
    directories according to this. ighome must not be NULL or an empty string.
    $A Igor jan02; */

void globutchangeprogdir(char *progdir);
    /* Changes the program directory to progdir. It then updates program
    directories according to this change. progdir must not be NULL or an empty
    string.
    $A Igor jan02; */

void globutchangeverdir(char *verdir);
    /* Changes the program version directory to verdir. It then updates program
    directories according to this change.verdir  must not be NULL or an empty
    string.
    $A Igor jan02; */

void globutchangesesdir(char *sesdir,char *sesfile);
    /* Changes the process session directory to sesdir and process session
    file to sesfile. sesfile can be NULL, in which case the old session file
    is kept. sesdir must not be NULL or an empty string.
     WARNING:
    This function will not have any effect if globutupdatesession() is called
    after it (or any function which calls globutupdatesession() such as
    globutinit() or changeprogdir() in case that program session ID has already
    been set, etc.
    $A Igor jan02; */









        /************************/
        /*                      */
        /*  VARIOUS UTILITIES:  */
        /*                      */
        /************************/



void globutprogtitlebas(FILE *fp1,FILE *fp2,int shift);
    /* Prints program title to files fp1 and fp2 if they are not NULL. shift is
    number of spaces printed before the title frame in the text version of the
    title.
    $A Igor jan02; */

void globutprogtitle(FILE *fp,int shift);
    /* Shows program title; if fp!=NULL, a title is also printed in file fp.
    shift is number of spaces printed before the title frame in the text
    version of the title.
    $A Igor jan02; */



    /* GENERAL UTILITIES: */


char *globuttmpnam1(void);
    /* Returns a temporary file name which can be used as auxiliary file, e.g.
    for writing text before showing it in a viewer. All calls to this function
    return the same file name, therefore the function may not be called in
    recursive block, i.e. you must be sure that the next call is made after
    the temporary file from previous call is stopped being used. When you use
    the temporary file name returned by this function, you may not call any
    other functions that might also use a temporary file whose name is obtained
    via the same mechanism.
     You MAY NOT free memory occupied by the returned string. You also don't
    need to remove the file when you stop using it because the globutend()
    that is called at the end of the program will do that (you should however
    close any logical files connected to the temporary file).
     The file whise name is returned by this function can be non-existent or
    nonempty. It is therefore user responsibility to initialise its state
    according to vurrent needs.
    $A Igor jan02; */

void globutsystempar(char *command);
    /* Executes command on the system in such a way that control is immediately
    returned to the program (i.e. editor opens in a window su that user can
    independently edit text, but at the same time the program runs on and user
    can interact with it).
    $A Igor jan02; */


  /* EDITING & VIEWING TEXT FILES, BROWSING HTML DOCUMENTS: */


void globutview(char *filepath,char par);
    /* Opens file filepath in the viewer. if par is 0, program execution is
    blocked until viewer is closed, otherwise it is not.
    $A Igor jan02; */

void globutedit(char *filepath,char par);
    /* Opens file filepath in the editor. if par is 0, program execution is
    blocked until editor is closed, otherwise it is not.
    $A Igor jan02; */

void globutbrowse(char *location,char par);
    /* Opens file filepath in the browser. if par is 0, program execution is
    blocked until browser is closed, otherwise it is not.
    $A Igor jan02; */





    /* MENUS, MESSAGES, etc. */


int globutmenusimp(char *message,stack items);
    /* Launches a simple menu for choosing between various possibilities.
    message is the message that accompanies the menu, and items is a stack of
    strings (char * each) that identify the possible choices.
      The function blocks until user makes a choice and returns the sequential
    number of the chosen item on the stack items (counting starts from 1). there
    is a possibility of making no choice, in which case the function returns 0.
    $A Igor apr03; */

int globutdialogsimp(char *message,stack items);
    /* Launches a simple dialog for choosing between various possibilities.
    message is the message that accompanies the menu, and items is a stack of
    strings (char * each) that appear as buttons and identify the possible
    choices.
      The function blocks until user makes a choice and returns the sequential
    number of the chosen item on the stack items (counting starts from 1). There
    is a possibility of making no choice, in which case the function returns 0.
    $A Igor apr03; */

void globutmessagesimp(char *message);
    /* Launches a simple message and waits until the user responds to it (as a
    notification that he or she really saw the message).
    $A Igor apr03; */




    /* SEARCHING IN PROGRAM HOME DIRECTORIES */


char *globuthomefindfirst(char *first,...);
    /* Searches for the first file in program home directories which satisfies
    criteria specified by string arguments of the function. It returns this
    name, which must be deallocated (e.g. by free()), or a NULL pointer if
    search was not successful. It searches first in gud->verdir, then in
    gud->progdir and finally in gud->ighome (gud must be initialised when
    the function is called, otherwise program can crash).
      Arguments must be separated into two groups by a NULL argument and must
    end with a NULL argument.
      The first group of arguments are directories relative to home directories
    which to search in. More than one can be specified, in which case "" can
    be specified for a home directory and individual directories are checked
    in the order as they appear in function arguments. If no directories are
    specified (i.e. the first argument is NULL), only the  home directories
    will be checked for a file.
      The second group of arguments (i.e. arguments between the first and the
    second NULL argument) specify file names which are searched. The first of
    these arguments specifies the first part of the file name (usually name
    without extension) and the next arguments specify different suffices which
    are combined with the first part. These are combined in the order in which
    they appear when existence of the searched file is checked. There can be
    only one argument in this group, in which case it defines a whole name of
    the single file name we search for in specific directories. If there are
    several arguments in this group, the first argument can be an empty string
    (""), in which case every subsequent argument specify the whole file name
    by its own.
      File name(s) can include file path separators. If any name includes a
    path DOS path separators, but program runs on UNIX, these separators are
    replaced by proper UNIX separators, and vice versa. If the generated file
    names include space characters (' '), these are replaced by underscores
    ('_').
      The search for files is performed only in the specified directories,
    not recursively in their nested subdirectories.
      EXAMPLES:
      globuthomefindfirst("doc","",NULL,"pm",".txt",".html",".htm",NULL)
    will return the first name of an existet file within  directory "doc"
    within any home directory or within any home directory (arg. ""), whose
    name is either "pm.txt","pm.html", or "pm.html".
      globuthomefindfirst(NULL,"","pm.txt","pm.html",NULL)
    will return the first name of an existent file named "pm.txt" or "pm.html"
    within any home directory of the program (because there are no arguments
    which would specift nested directory names).
      globuthomefindfirst("1/doc","hlp",NULL,"ig/a"," 1.txt"," 2.txt",NULL)
    will return (on UNIX) the first name of the existent file "ig/_a1.txt" or
    "ig/a_2.txt" within the directory "1/doc" or "hlp" within any home
    directory of the program. On DOS, this call would return the first file
    named "ig\_a1.txt" or "ig\a_2.txt" within the directory "1\doc" or "hlp"
    within any home directory of the program.
      WARNING:
    When calling this function, make sure that global utility data (gud) is
    initialised, which is achieved by any function that sets or gets any global
    data. Also make sure that two arguments of the function are NULL.
    $A Igor jan02; */

void globuthelpfirst(char *helptopic);
    /* Searches for the first help file named helptopic with extension ".txt"
    or ".html" and opens it in a browser if it has extension ".html" or in
    viewer otherwise. It searches in home directories (version directory,
    program directory and software directory, in this order) and their
    subdirectory "doc". If it doesn't find a matching file, it reports an
    error.
    $A Igor jan02; */











#endif    /* (not defined) INCLUDED_globut */






