
/* CAS, DATUMI */

double stdabsolutetime(void);
    /* Returns the amount of time that has passed since a given moment
    in seconds by use of standard C functions. This function is used to
    synchronize other functions that return absolute time with the C
    definition of the absolute time.
    $A Igor jun03; */

double absolutetime(void);
    /* Vrne preteceni cas od nekega dolocenega trenutka v sekundah.
    $A Igor sep97; */

double cputime(void);
    /* Vrne porabljen CPU cas v sekundah od zacetka programa.
    $A Igor Avg98; */

void fprinttime(FILE *fp);
    /* V datoteko fp zapise trenutni lokalni cas (datum in cas v dnevu) brez
    znaka za novo vrstico v berljivi obliki.
    $A Igor avg98; */

void printtime(void);
    /* Na standardni izhod zapise trenutni lokalni cas (datum in cas v dnevu)
    brez znaka za novo vrstico v berljivi obliki.
    $A Igor avg98; */

void fprintdaytime(FILE *fp);
    /* V datoteko fp zapise trenutni lokalni cas v dnevu brez znaka za novo
    vrstico v berljivi obliki.
    $A Igor avg98; */

void printdaytime(void);
    /* Na standardni izhod zapise trenutni lokalni cas v dnevu brez znaka za
    novo vrstico v berljivi obliki.
    $A Igor avg98; */

void fprintdate(FILE *fp);
    /* V datoteko fp zapise trenutni datum brez znaka za novo vrstico v
    berljivi obliki.
    $A Igor avg98; */

void printdate(void);
    /* Na standardni izhod zapise trenutni datum brez znaka za novo vrstico v
    berljivi obliki.
    $A Igor avg98; */

char laterdate(int day,int month,int year);
    /* Vrne 1, ce je trenutni datum po lokalnem casu poznejsi od datuma (day,
    month,year).
    $A Igor avg98;  */

char laterdate0(int day,int month,int year);
    /* Vrne 1, ce je trenutni datum po lokalnem casu poznejsi od datuma (day,
    month,year). Za razliko od laterdate() ta funkcija uporablja vec orodij,
    ki so v standardnih knjiznicah za C.
    $A Igor avg98; */

int dateshift(int day,int month,int year);
    /* Vrne stevilo dni razlike med datumom dolocenim z (day,month,year) in
    trenutnim datumom. Ce je ta datum pred trenutnim datumom, je razlika
    negativna, ce pa se ujema s trenutnim datumom, je razlika 0. Pri klicu
    mora biti year polna, ne dvomestna letnica.
     POZOR!
     Razlika se na nekaterih sistemom ne racuna pravilno, ce je datum prejsnji
    ali poznejsi od dolocenega datuma (to je lastnost standardnih funkcij, ki
    so uporabljene v tej funkciji).
    $A avg98; */

void calcdate(int dayshift,int *day,int *month,int *year);
    /* Izracuna datum, ki je pomaknjen za dayshift dni od trenutnega datuma.
    Ce je dayshift negativen, vrne datum starejsi od trenutnega. Datum zapise
    v day,month in year (letnice so polne, ne dvomestne).
     POZOR!
     Datum se na nekaterih sistemom ne racuna pravilno, ce je datum prejsnji
    ali poznejsi od dolocenega datuma (to je lastnost standardnih funkcij, ki
    so uporabljene v tej funkciji).
    $A Igor avg98; */

void currentdate(int *day,int *month,int *year);
    /* Trenutni datum zapise v *day, *month in *year;
    $A Igor avg98; */

char * numbertomonth0(int month,int mode);
    /* Pretvori stevilko meseca (month) v niz, ki pripada temu mesecu, in ga
    vrne. Mode doloca nacin pretvorbe in sicer:
     0: Oct
     1: October
     10: okt.
     11: oktober
     $A Igor nov99; */


