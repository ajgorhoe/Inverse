
          /*  ELECTRIC CHARGES  */




/* Code that insures inclusion of necessary headers: */
#ifndef INCLUDED_st
 #include <st.h>
#endif
#ifndef INCLUDED_vec
 #include <vec.h>
#endif
#ifndef INCLUDED_mat
 #include <mat.h>
#endif
#ifndef INCLUDED_rand
 #include <rand.h>
#endif


                         /**************/
                         /*            */
                         /*   MACROS   */
                         /*            */
                         /**************/







