
#ifndef INCLUDED_lin_alg  /* prevent multiple inclusion */
 #define INCLUDED_lin_alg

#ifndef INCLUDED_st
 #include <st.h>
#endif
#ifndef INCLUDED_vec
 #include <vec.h>
#endif
#ifndef INCLUDED_mat
 #include <mat.h>
#endif


            /*******************************/
            /*                             */   
            /*  LINEAR ALGEBRA SUPPLEMENT  */
            /*      BASED ON MESCHACH      */   
            /*                             */   
            /*******************************/





            /************************/
            /*                      */
            /*   QR DECOMPOSITION   */
            /*                      */
            /************************/



int QRdecompplaincomp(matrix m1,matrix qr,vector diag);
    /* Performes QR decomposition of m1 and stores the result in compact form
    (used by Meschach) to qr and d. The dimension of m1, qt and d must be
    consisistent, since the function does not check this; arguments must also
    be different than NULL.
      qr can be the same as m1.
      Dimensions: m1(mxn), qr(mxn), diag(n),  m>=n!
      Calculation with the compact form is much faster than if conversion was
    performed to full QR factors.
      To implement: Error control through return value (i.e. catch Meschach
    errors & return nonzero value if an error occurs)!
    $A Igor dec03; */

int QRdecompplain(matrix m1,matrix mq,matrix mr);
    /* Performs the QR decomposition of a matrix mq and stores the orthogonal
    factor to mq and the upper triangular factor to mr. The dimensions of the
    arguments must be consistend and arguments may not be NULL (this is not
    checked within the function).
      If m1 is a square matrix, then it can be the same as mq or mr, in this
    case its contents are overwritten. mq may not be the same as mr.
      Warning: It is not checked whether the method works for non-square
    matrices (m1->d1>m1->d2)!
      WARNING:
      The operations performed by the compact form are normally much faster
    than by the fully wxpanded product as is calculated by this function.
      To implement: Error control through return value (i.e. catch Meschach
    errors & return nonzero value if an error occurs)!
    $A Igor dec03; */




            /****************************/
            /*                          */
            /*   SYSTEMS OF EQUATIONS   */
            /*                          */
            /****************************/


    /* SOLUTION OF SYSTEMS BY THE QR DECOMPOSITION: */


void solvQRplaincomp(matrix qr,vector diag,vector b,vector x);
    /* Solves the system of equations A x = b, where qr and diag contain the
    QR decomposition of A in the compact form used bt Meschach. Arguments must
    be of consistend dimensions and may not be NULL, since checks are not
    performed within the function.
      b can be the same as x.
      Dimensions: qr(mxn), diag(n), b(m), x(n),  m>=n!
    $A Igor dec03; */




            /************************/
            /*                      */
            /*     EIGENSYSTEMS     */
            /*                      */
            /************************/


int eigsyssymplain(matrix ma,matrix eigvec,vector eigval);
    /* Calculates eigenvectors and eigenvalues of a SYMMETRIC matrix ma and
    stores eigenvectors to COLUMNS of eigvec and eigenvalues to eigval.
      Arguments must be of consistent dimensions and may not be NULL since this
    is not checked by the function.
      Computed EIGENVECTORS are NORMED, therefore
        ma=eigvec*diag(eigval)*eigvec^T .
      Uses the meschach library.
      Currently just returns 0;
    $A Igor dec03; */









    /* EXAMPLE UTILITIES UTILIZING THE Meschach: */


  /* LU DECOMPOSITION: */

int LUdecomp_mes(matrix m1,matrix lu,indtab ind);
    /* Calculates LU decomposition of matrix m1 and stores it to lu. m1 and
    lu may be or not the same matrices. Permutation order is stored to ind.
      The Meschach library is used for calculation.
      To implement: Error control through return value (i.e. catch Meschach
    errors & return nonzero value if an error occurs)!
    $A Igor dec03; */

void solvLU_mes(matrix lu,indtab it,vector b,vector x);
    /* Solves the equation A x = b, where lu contains the LU decomposition of
    A and it the permutation table for this composition. The Meschach library
    is used for calculation.
      To implement: Error control through return value (i.e. catch Meschach
    errors & return nonzero value if an error occurs)!
    $A Igor dec03; */




  /* SYSTEMS OF EQUATIONS: */

int solvitermgcrplain(matrix ma,vector b,vector x,int maxsteps,double tol);
    /* Iteratively solves A*x=b and stores the result in x. maxsteps is the
    maximum allowed number of steps, tol is the relativ tollerance for
    residuum norm (?). x must contain an initial guess!
      - for nonsymmetric matrices!
      RETURNS the number of iterations if successful, otherwise it returns -1.
      Modified generalized conjugate residual alhorithm is utilized.
    $A Igor dec03; */

int solvitercgsplain(matrix ma,vector b,vector x,int maxsteps,double tol);
    /* Iteratively solves A*x=b and stores the result in x. maxsteps is the
    maximum allowed number of steps, tol is the relativ tollerance for
    residuum norm (?). x must contain an initial guess!
      - for nonsymmetric matrices!
      RETURNS the number of iterations if successful, otherwise it returns -1.
      CGS alhorithm is utilized.
    $A Igor dec03; */

int solviterarnoldiplain(matrix ma,vector b,vector x,int maxsteps,double tol);
    /* Iteratively solves A*x=b and stores the result in x. maxsteps is the
    maximum allowed number of steps, tol is the relativ tollerance for
    residuum norm (?). x must contain an initial guess!
      - for nonsymmetric matrices!
      RETURNS the number of iterations if successful, otherwise it returns -1.
      finds least square solution - min ||A*x-b||^2.
    $A Igor dec03; */

int solviterlsqrplain(matrix ma,vector b,vector x,int maxsteps,double tol);
    /* Iteratively solves A*x=b and stores the result in x. maxsteps is the
    maximum allowed number of steps, tol is the relativ tollerance for
    residuum norm (?). x must contain an initial guess!
      - for nonsymmetric matrices!
      RETURNS the number of iterations if successful, otherwise it returns -1.
      finds least square solution - min ||A*x-b||^2.
    $A Igor dec03; */

int solvitergmresplain(matrix ma,vector b,vector x,int maxsteps,double tol);
    /* Iteratively solves A*x=b and stores the result in x. maxsteps is the
    maximum allowed number of steps, tol is the relativ tollerance for
    residuum norm (?). x must contain an initial guess!
      - for nonsymmetric matrices!
      RETURNS the number of iterations if successful, otherwise it returns -1.
      Uses generalised minimum residual algorithm of Saad & Schultz.
    $A Igor dec03; */



















#endif  /* not defined INCLUDED_lin_alg */
