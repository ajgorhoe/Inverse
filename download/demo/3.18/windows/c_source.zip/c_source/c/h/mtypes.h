     /***************** DEFINICIJE OSNOVNIH TIPOV *****************/



/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
/*
#ifndef INCLUDED_st
#include <st.h>
#endif
#ifndef INCLUDED_vec
#include <vec.h>
#endif
#ifndef INCLUDED_mat
#include <mat.h>
#endif
#ifndef INCLUDED_simb
#include <simb.h>
#endif
*/



/* Koda, ki omogoca v kljucitev te datoteke v headerjih, ne da bi bilo treba
skrbeti za to, ali ni ta header ze bil kakorkoli vkljucen, ker se v to
eksplicitno preverja preko definicije ustreznega makra: */
#ifndef INCLUDED_mtypes
#define INCLUDED_mtypes


/* Nad definicijami so navedene osnovne knjiznice,
ki oporabljajo dolocene tipe. */


/* DOGOVORI GLEDE IMEN FUNKCIJ, KI ALOCIRAJO SPOMIN ALI GA SPROSTIJO:
     Funkcija, ki alocira spomin za del neke strukture ter zahteva kot
   enega od argumentov naslov te strukture, vrne pa obicajno ne kaksne
   vrednosti, naj ima predpono get, npr. getmat, getvec. Funkcija
   z nasprotnim ucinkom naj ima predpono disp, npr.  dispvec.
     Funkcije, ki alocirajo spomin za neko strukturo in vrnejo kazalec
   nanjo, naj imajo predpono new, npr. newstack. Funkcije z nasprotnim
   ucinkom naj imajo spet predpono disp, npr. dispstack.
     Funkcije, ki alocirajo prostor za neko enostavno tabelo (array) in
   vrnejo kazalec nanjo, naj imajo predpono make, npr. makestring. Te
   funkcije ne rabijo funkcij z nasprotnim ucinkom, ker je mozna enostavna
   uporaba ukaza free.
*/



#ifndef INCLUDED_stdio  /* for definition of type FILE */
  #include <stdio.h>
  #define INCLUDED_stdio
#endif



#ifndef INCLUDED_vec
 #include <vec.h>  /* for definition of counter & scalar */
#endif

#ifndef INCLUDED_strop
 #include <strop.h>  /* for definition of string */
#endif


/***************************** invan.h *******************************/



typedef struct{
        char *name;    /* name of the file on disk */
        FILE *fp;      /* file pointer */
        char *mode;    /* opening mode */
        long pos;      /* current position (counted from 1 on) */
        fpos_t ps;     /* to be MODIFIED ONLY and ALWAYS by fgetpos() and fsetpos(),
          since these functions store data in internal format! */
        } _vfile;

typedef _vfile *vfile;  /* variable file */




/*****************************  *******************************/







#endif    /* (not defined) INCLUDED_mtypes */
