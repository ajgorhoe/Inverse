


                    /**************************/
                    /*                        */
                    /*  INVERSE OPEN LIBRARY  */
                    /*                        */
                    /**************************/



/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_st
#include <st.h>
#endif
#ifndef INCLUDED_vec
#include <vec.h>
#endif
#ifndef INCLUDED_mat
#include <mat.h>
#endif
#ifndef INCLUDED_simb
#include <simb.h>
#endif
#ifndef INCLUDED_fint
#include <fint.h>
#endif
#ifndef INCLUDED_mtypes
#include <mtypes.h>
#endif
#ifndef INCLUDED_varop
#include <varop.h>
#endif





              /*************************************/
              /*                                   */
              /*     SISTEM ZA JAVLJANJE NAPAK     */
              /*                                   */
              /*************************************/


#if 0
FILE *errorfileextern(void);
    /* Vrne datoteko, v katero naj se izpisujejo porocila o napakah. Normalno
    je to datoteka, ki je vezana na datotecno spremenljivko z imenom outfile,
    ce pa ta ne obstaja ali ni odprta, vrne ta funkcija standardni izhod.
    $A Igor jul99; */
#endif


FILE *inverrorfile(void);
    /* Returns the file into which error reports should be output beside the
    stendard error.
    $A Igor jul99 nov02; */


FILE * inverf(void);
    /* Vrne datoteko, v katero v funkciji zapisemo podatke o napaki. To lahko
    storimo le med klicema ustreznih funkcij (zacetne in koncne funkcije
    iste vrste za vzpostavitev sistema javljanja napak).
    $A Igor jul99; */

char *invers(void);
    /* Returns a string on which a part of the error report can be printed.
    Calls of this function and printing to the string which it returns should
    be performed between the calls to the appropriate error report initialisation
    and error report finalisation function. The minimum amount of space available
    in the returned string is at least 2500 bytes (defined by the macro MINBUF
    in er.c).
    $A Igor nov02; */



    /* FUNKCIJE ZA JAVLJANJE NAPAK V PROGRAMU INVAN: */

void erinv1(int code,char *functionname);
    /* Funkcija, ki jo moramo izvesti pred izpisom opisa napake v datoteko
    com.erfile v primeru, da gre za napako, ki se ne tice kaksne funkcije
    kalkulatorja ali interpreterja. functionname je ime funkcije, v kateri
    javimo napako, code pa je koda napake.
    $A Igor sep98; */

void erinv0(char *functionname);

void erinv2(void);
    /* Funkcija, ki jo moramo izvesti po izpisu opisa napake v datoteko
    com.erfile v primeru, da gre za napako, ki se ne tice kaksne funkcije
    kalkulatorja ali interpreterja.
    $A Igor sep98 apr99; */

void erfintinv1(int code,char *funcname);
    /* Funkcija, ki jo moramo izvesti pred izpisom opisa napake v datoteko
    com.erfile v primeru, da gre za napako, ki ne tice funkcije datotecnega
    interpreterja. code je koda napake.
    $A Igor sep98; */

void erfintinv0(void);

void erfintinv2(void);
    /* Funkcija, ki jo moramo izvesti po izpisu opisa napake v datoteko
    com.erfile v primeru, da gre za napako, ki se tice funkcije datotecnega
    interpreterja.
    $A Igor sep98; */

void ercalcinv1(int code,char *funcname);
    /* Funkcija, ki jo moramo izvesti pred izpisom opisa napake v datoteko
    com.erfile v primeru, da gre za napako, ki se tice funkcije kalkulatorja.
    code je koda napake.
    $A Igor sep98; */

void ercalcinv0(void);

void ercalcinv2(void);
    /* Funkcija, ki jo moramo izvesti po izpisu opisa napake v datoteko
    com.erfile v primeru, da gre za napako, ki se tice funkcije kalkulatorja .
    $A Igor sep98; */






              /******************************************/
              /*                                        */
              /*  FUNKCIJE, KI SE TICEJO INTERPRETERJA  */
              /*                                        */
              /******************************************/



    /*  POGON DIREKTNE ANALIZE:  */

void invanalyse(void);
    /* Izvede direktno numericno analizo z vhodnimi parametri com.parammom ter
    zapise rezultate analize v dogovorjene spremenljivke. Funkcija je
    definirana v invopt.c.
    $A Igor <== jun97; */


    /*  INTERPRETACIJA KODE V SPOMINU:  */

int invinterpstring(char *str);
    /* V datotecnem interpreterju programa Inverse se interpretira niz str.
    $A Igor okt01; */


char *invgetargblocksimp(void);
    /* Naredi in vrne niz, v katerega dobesedno prepise vsebino trenutnega
    argumentnega blokainterpreterja, ki je v obdelavi, in sicer od trenutne
    pozicije pri branju argumentov (ki je na zacetku postavljena na zacetek
    argument. bloka) do konca argumentnega bloka. To funkcijjo navadno
    uporabljamo skupaj s funkcijo invinterpstring, kadar definiramo funkcijo
    interpreterja, ki naj del argumentnega bloka zinterpretira.
    $A Igor okt01; */


    /* INSTALACIJA FUNKCIJ INTERPRETERJA: */


void instfintinv(char *name,void intfunc (ficom fcom));
    /* V datotecni interpreter instalira funkcijo intfunc pod imenom name.
    $A igor avg01; */



    /* TESTIRANJE, CE OBSTAJAJO NADALJNJI ARGUMENTI: */


char invunreadargsimp(void);
    /* Vrne znak, ki je razlicen od \0, ce so v argumentnem bloku se neprebrani
    argumenti. V tem primeru je vrnjeni znak enak znaku, s katerim se zacne
    naslednji neprebrani argument.
    $A Igor sep01; */



    /* VGNEZDENI ARGUMENTNI BLOKI: */


int inventernestblocksimp(void);
    /* Pri interpretaciji argumentov funkcije interpreterja lupine Inverse
    povzroci vhod v vgnezden argumentni blok. Na interpreterju lupine com.fcom
    pripravi podatke tako, da postane argumentni blok vsebina zavitih oklepajev,
   ki sledijo trenutni poziciji v argumentnem bloku (vmes je lahko le prazen
   prostor in vejice). Hkrati se shranejo podatki, ki omogocijo pravilno
   restavracijo pozicij za branje argumentov po izhodu iz vgnezdenega
   argumentnega bloka s funkcijo invexitnestblocksimp.
     Vgnezdeni argumentni bloki se uporabljajo npr. za navedbo blokov kode, ki
    naj se zinterpretira v interpreterju, kot del vsebine argumentnega bloka
    funkcije, ki ima ob klicu se druge podatkovne argumente, ali za grupiranje
    skupin argumentov funkcije, ki so povezani po pomenu in imajo lahko
    variabilno stevilo argumentov (taksne situacije je namrec tezje obvladovati
    brez uporabe vgnezdenih argumentnih blokov)
     Ce je vse OK, vrne pozitivno stevilo, ki je za eno vecje od dolzine
     vsebine vgnezdenega bloka, drugace pa 0.
     POZOR:
     Paziti je treba, da ima vsak vhod v vgnezden blok svoj izhod s klicem
    invexitnestblocksimp, ampak le v primeru, ce je bil vhod uspesen, torej
    ce je funkcija pri klicu vrnila pozitivno stevilo (neuspesen klic namrec
    ne postavi lokalnih podatkov in bi se pri klicu izhodne funkcije
    restavrirali podatki, ki ne pripadajo pravemu vgnezdenemu bloku.
    $A Igor okt01; */



              /*********************************************/
              /*                                           */
              /*  BRANJE ARGUMENTOV FUNKCIJ INTERPRETERJA  */
              /*                                           */
              /*********************************************/


FILE *invgetinterpfile(void);
    /* Vrne datoteko, ki se jo trenutno interpretira.
    $A Igor jul99; */

long invgetargblockbegin(void);
    /* Vrne zacetno pozicijo argumentnega bloka funkcije, ki se jo trenutno
    interpretira.
    $A Igor jul99; */

long invgetargblockend(void);
    /* Vrne koncno pozicijo argumentnega bloka funkcije, ki se jo trenutno
    interpretira.
    $A Igor jul99; */

long invgetargblockpos(void);
    /* Vrne trenutno pozicijo v argumentnem bloku funkcije, ki se jo trenutno
    interpretira.
    $A Igor okt99; */

void invsetargblockpos(long pos);
    /* Postavi trenutno pozicijo v argumentnem bloku funkcije, ki se jo
    trenutno interpretira, na pos.
    $A Igor okt99; */




/* FUNKCIJE ZA BRANJE ARGUMENTOV FUNKCIJ DATOTECNEGA INTERPRETERJA
S PODANO DATOTEKO IN POZICIJAMI: */

/* OPOMBA: Teh dveh funkcij naj se v prihodnje ne uporablja!!! */

int invgetstrarg(FILE *fp,long from,long to,string *str,long *start,long *next);
    /* Prebere nizovni argument in ga zapise v *str.
    $A Igor jul99; */

int invgetvarspecarg(FILE *fp,long from,long to,char **name,stack *indst,
               long *start,long *next);
    /* Prebere specifikacijo elementa ali podtabele spremanljivke. Ime shrane
    v *name, indekse pa nalozi na sklad *indst kot kazalce na int.
    $A Igor jul99; */



/* ENOSTAVNE FUNKCIJE ZA BRANJE ARGUMENTOV FUNKCIJ DATOTECNEGA INTERPRETERJA
BREZ PODANE DATOTEKE IN POZICIJ: */

/* Naslednje funkcije imajo za argument le naslov, kamor naj shranjo prebrane
vrednosti, in po moznosti se kak dodaten argument. Ostale podatke dobijo od
datotecnega interpreterja. Ko preberemo argument s taksno funkcijo, se postavi
pozicija iskanja naslednjega argumenta. To se ne zgodi pri uporabi drugih
funkcij (zgoraj), zato lahko spodnje funkcije upporabljamo le v kombinaciji s
podobnimi funkciji. Zacetno pozicijo iskanja za 1. argument funkcije
interpreterja postavi sam interpreter. */



int invgetvalargsimp(double *val);
    /* Prebere stevilcni argument in ga zapise v *val.
    $A Igor jul99; */

int invgetvalargssimp(int maxnum,stack *valst);
    /* Prebere najvec maxnum stevilcnih argumentov in njihove vrednosti polozi
    na sklad *valst kot kazalce na tip double. Vrne stevilo prebranih
    argumentov oz. -1, ce je kaj narobe.
    $A Igor jul99; */

int invgetcountargsimp(counter *cnt);
    /* Prebere stevcni argument in ga zapise v *cnt.
    $A Igor jul99; */

int invgetscalargsimp(scalar *scal);
    /* Prebere skalarni argument in ga zapise v *scal.
    $A Igor jul99; */

int invgetvecargsimp(vector *vec);
    /* Prebere vektorski argument in ga zapise v *vec.
    $A Igor jul99; */

int invgetmatargsimp(matrix *mat);
    /* Prebere matricni argument in ga zapise v *mat.
    $A Igor jul99; */

int invgetstrargsimp(string *str);
    /* Prebere nizovni argument in ga zapise v *str.
    $A Igor jul99; */

int invgetstrargssimp(int maxnum,stack *st);
    /* Prebere najvec maxnum nizovnih argumentov in jih nalozi na sklad *st
    kot kazalce tipa char *. Ce je maxnum 0, stevilo argumentov ni omejeno.
    $A Igor jul99; */

int invgetvarspecargsimp(char **name,stack *indst);
    /* Prebere specifikacijo elementa ali podtabele spremanljivke. Ime shrane
    v *name, indekse pa nalozi na sklad *indst kot kazalce na int.
    $A Igor jul99; */


           /**************************************************/
           /*                                                */
           /*  MANIPULACIJA Z UPORABNISKIMI SPREMENLJIVKAMI  */
           /*                                                */
           /**************************************************/


/* Deklaracije iz invvar.c: */

int updatecountvar(char *name,int place);
int updatescalvar(char *name,int place);
int updatevecvar(char *name,int place);
int updatematvar(char *name,int place);
int updatefldvar(char *name,int place);
int updatestrvar(char *name,int place);
int updatevfivar(char *name,int place);


varholder updatecountdata(char *name,int place);
varholder updatescaldata(char *name,int place);
varholder updatevecdata(char *name,int place);
varholder updatematdata(char *name,int place);
varholder updateflddata(char *name,int place);
varholder updatestrdata(char *name,int place);
varholder updatevfidata(char *name,int place);




    /* POMOZNE FUNKCIJE ZA MANIPULACIJO S SPREMENLJIVKAMI */




/* FUNKCIJA, KI BREZPOGOJNO ZBRISEJO CELO SPREMENLJIVKO Z DANIM IMENOM: */


int invdispvar(char *typespec,char *name);
    /* Zbrise spremenljivko z imenom name, ce ustreza specifikaciji tipa
    typespec glede na funkcijo invcheckvartype(). Vrne celo stevilo, ki je 0,
    ce spremenljivka z imenom name ne obstaja ali ce ni pravega tipa, oz. zap.
    stevilko na skladu spremenljivk, ce se je brisanje izvedlo. Ce je typespec
    NULL, se brise spremenljivka z imenom name ne glede na tip.
    $A Igor okt01; */


/* FUNKCIJE, KI NAREDIJO NOVO SPREMENLJIVKO (ce spremenljivka z danim imenom
ze obstaja, se jo najprej zbrise z elementi vred): */


int invcreatevar(char *spec,char *name,stack dim);
    /* Naredi spremenljivko z imenom name in dimenzijami dim, katere tip je
    dolocen s spec. spec mora biti specifikacija, ki je razumnljiva funkciji
    invsetvartype(). Ce spremenljivka z imenom name ze obstaja, se jo
    najprej zbrise z elementi vred.
    Dimenzije na dim morajo biti kazalci na tip int. Sklad z nic elementi ali
    nealociran sklad (NULL) pomenita spremenljivko z rangom 0 (1 element).
    $A Igor avg99; */

int invcreatecountvar(char *name,stack dim);
    /* Naredi stevcno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */

int invcreatescalvar(char *name,stack dim);
    /* Naredi skalarno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */

int invcreatevecvar(char *name,stack dim);
    /* Naredi vektorsko spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */

int invcreatematvar(char *name,stack dim);
    /* Naredi matricno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */

int invcreatefldvar(char *name,stack dim);
    /* Naredi poljsko spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */

int invcreatestrvar(char *name,stack dim);
    /* Naredi nizovno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */

int invcreatevfivar(char *name,stack dim);
    /* Naredi datotecno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */



/* FUNKCIJE, KI VRACAJO NASLOVE ELEMENTOV SPREMENLJIVK: */


void **invgetvareladdr(char *spec,char *name,stack indst);
    /* Vrne naslov elementa spremenljivke, katere tip je dolocen s spec, imena
    name in z indeksno specifikacijo indst. Specifikacija tipa spremenljivke
    spec mora biti taksna, kot jo dovoljuje funkcija invgetvariablestack().
    Indeksi na indst morajo biti kazalci na tip int. Sklad z nic elementi ali
    nealociran sklad (NULL) pomenita spremenljivko z rangom 0 (1 element).
    $A Igor jul99 sep01; */

counter *invgetcounteladdr(char *name,stack indst);
    /* Vrne naslov elementa stevcne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */

scalar *invgetscaleladdr(char *name,stack indst);
    /* Vrne naslov elementa skalarne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */

vector *invgetveceladdr(char *name,stack indst);
    /* Vrne naslov elementa vektorske spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */

matrix *invgetmateladdr(char *name,stack indst);
    /* Vrne naslov elementa matricne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */

string *invgetstreladdr(char *name,stack indst);
    /* Vrne naslov elementa nizovne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */

vfile *invgetvfileaddr(char *name,stack indst);
    /* Vrne naslov elementa datotecne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */



/* FUNKCIJE, KI VRACAJO ELEMENTE SPREMENLJIVK: */


void *invgetvarel(char *spec,char *name,stack indst);
    /* Vrne element spremenljivke, katere tip je dolocen s spec, imena
    name in z indeksno specifikacijo indst. Specifikacija tipa spremenljivke
    spec mora biti taksna, kot jo dovoljuje funkcija invgetvariablestack().
    $A Igor jul99; */

counter invgetcountel(char *name,stack indst);
    /* Vrne element stevcne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */

scalar invgetscalel(char *name,stack indst);
    /* Vrne element skalarne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */

vector invgetvecel(char *name,stack indst);
    /* Vrne element vektorske spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */

matrix invgetmatel(char *name,stack indst);
    /* Vrne element matricne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */

string invgetstrel(char *name,stack indst);
    /* Vrne element nizovne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */

vfile invgetvfile(char *name,stack indst);
    /* Vrne element datotecne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */



/* FUNKCIJE, KI VRACAJO SPREMENLJIVKE IN PRVE ELEMENTE SPREMENLJIVK: */

varholder invgetvar(char *spec,char *name);
    /* Vrne nosilec spremenljivke, katere tip je dolocen s spec ter imenom
    name. Specifikacija tipa spremenljivke spec mora biti taksna, kot jo
    dovoljuje funkcija invgetvariablestack().
    $A Igor aug04; */

void *invgetvarelfirst(char *spec,char *name);
    /* Vrne prvi element spremenljivke, katere tip je dolocen s spec ter imenom
    name. Specifikacija tipa spremenljivke spec mora biti taksna, kot jo
    dovoljuje funkcija invgetvariablestack().
    $A Igor aug04; */



/* FUNKCIJE, KI VRNEJO DIMENZIJE SPREMENLJIVK: */


int invvardimension(char *spec,char *name,stack *dim);
    /* Na sklad *dim nalozi dimenzije spremenljivke z imenom name in tipa, ki
    ga doloca spec (ime tipa mora biti prepoznavno za funkcijo
    invgetvariablestack). Nalozene dimenzije so tipa int *. Vrne mesto na skladu,
    na katerem se nahaja spremenljivka.
    $A Igor avg99 sep01; */

int invcountvardimension(char *name,stack *dim);
    /* Na sklad *dim nalozi dimenzije stevcne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */

int invscalvardimension(char *name,stack *dim);
    /* Na sklad *dim nalozi dimenzije skalarne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */

int invvecvardimension(char *name,stack *dim);
    /* Na sklad *dim nalozi dimenzije vektorske spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */

int invmatvardimension(char *name,stack *dim);
    /* Na sklad *dim nalozi dimenzije matricne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */

int invstrvardimension(char *name,stack *dim);
    /* Na sklad *dim nalozi dimenzije nizovne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */

int invvfivardimension(char *name,stack *dim);
    /* Na sklad *dim nalozi dimenzije datotecne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */



/* FUNCTION THAT RETURNS VARIABLE TYPE: */

int invgetvartype(char *name);
    /* Returns the type of the interpreter variable named name, or 0 if the
    variable with this name does not exist. The type can be one of VT_COUNTER,
    VT_SCALAR, VT_VECTOR, VT_MATRIX, VT_STRING, or VT_VFILE, which are 
    constants defined in varop.h (when using these constants, make sure to
    include varop.h!).
    */


/* FUNKCIJE, KI TESTIRAJO OBSTOJ SPREMENLJIVK: */


int invvarexists(char *spec, char *name);
    /* Vrne 0, ce spremenljivka z imenom name in specifikacijo tipa ne obstaja,
    drugace vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na
    ustreznem skladu. Ce je specifikacija NULL, potem funkcija preveri, ce
    obstaja spremenljivka kateregakoli tipa z danim imenom.
    $A Igor avg99 sep01; */

int invcountvarexists0(char *name);
    /* Vrne 0, ce stevcna spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */

int invscalvarexists0(char *name);
    /* Vrne 0, ce skalarna spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */

int invvecvarexists0(char *name);
    /* Vrne 0, ce vektorska spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */

int invmatvarexists0(char *name);
    /* Vrne 0, ce matricna spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */

int invstrvarexists0(char *name);
    /* Vrne 0, ce nizovna spremenljivka z imenom name ne obstaja, drugace vrne
    pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */

int invvfivarexists0(char *name);
    /* Vrne 0, ce datotecna spremenljivka z imenom name ne obstaja, drugace vrne
    pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */



/* OPERACIJE NAD PODTABELAMI ELEMENTOV SPREMENLJIVK: */


int invvaropsimple(char *spec,char *name1,stack which1,
                void operation(void *operand));
    /* Izvede operacijo operation nad podtabelo elementov spremenljivke z imenom
    name1 in tipa, ki ga doloca specifikacija spec1. Ta mora biti prepoznavna za
    fnkcijo invcheckvartype(). Podtabelo elementov doloca indeksna specifkacija
    which1. Spremenljivka mora obstajati in mora vsebovati dano podtabelo.
    Funkcija vrne stevilo izvedenih operacij oz. negativno stevilo, ce je
    med operacijo prislo do napake.  Iz te oznake se lahko dobi niz, ki
    oznacuje napako, s funkcijo varoperrorstr.
    $A Igor okt01; */

int invvaropunary(char *spec1,char *name1,stack which1,
               char *specres,char *nameres,stack whichres,
               void *operation(void *operand1,void **res));
    /* Izvede operacijo operation nad enakoleznimi pari podtabel elementov 
    spremenljivk, ki ju dolocata specifikaciji tipa spremenljivk spec1 in
    specres, imeni spremenljivk name1 in nameres ter specifikaciji podtabel
    which1  in whichres. operation je unarna operacija, ki se izvede na enem
    objektu, rezultat pa shrane v drugega. Spremenljivka ustrez. tipa z imenom
    name1 mora obstajati in vsebovati podtabelo, ki jo doloca which1. Ce
    specifikacija whichres vsebuje kaksne indekse, mora ustrezna podtabela
    spremenljivke z imenom res obstajati in mora imeti iste dimenzije kot
    podtabela 1. operanda. V nasprotnem primeru se vzame celotna tabela
    elementov spremenljivke res in ce ta ni ustrezne dimenzije, se cela
    spremenljivka najprej brise in nato kreira tako, da ima njena tabela
    elementov isto dimenzijo kot podtabela, ki jo doloca which1.
     Ce se funkcija uspesno izvede, vrne stevilo izvedenih operacij, drugace
    vrne negativno oznako napake. Iz te oznake se lahko dobi niz, ki oznacuje
    napako, s funkcijo varoperrorstr.
    $A Igor okt01; */

int invvaropbinary(char *spec1,char *name1,stack which1,
                char *spec2,char *name2,stack which2,
                char *specres,char *nameres,stack whichres,
                void *operation(void *operand1,void *operand2,void **res));
    /* Izvede operacijo operation nad istoleznimi trojicami elementov podtabel,
    ki jih dolocajo specifikacije tipa spremenljivk spec1, spec2 in specres,
    imena spremenljivk name1, name2 in nameres ter specifikacije podtabel
    elementov which1, which2 in whichres. operation je binarna operacija, ki se
    izvede na dveh objektih, rezultat pa shrane v tretjega.
     Spremenljivki ustrez. tipa z imenoma name1 in name2 morata obstajati in
    vsebovati podtabeli, ki jo dolocata which1 in which2, le-ti morata biti
    istih dimenzij. Ce specifikacija whichres vsebuje kaksne indekse, mora
    ustrezna podtabela spremenljivke z imenom res obstajati in mora imeti iste
    dimenzije kot podtabeli operandov. V nasprotnem primeru se vzame celotna
    tabela elementov spremenljivke res in ce ta ni ustrezne dimenzije, se cela
    spremenljivka najprej brise in nato kreira tako, da ima njena tabela
    elementov isto dimenzijo kot podtabela, ki jo doloca which1.
     Ce se funkcija uspesno izvede, vrne stevilo izvedenih operacij, drugace
    vrne negativno oznako napake. Iz te oznake se lahko dobi niz, ki oznacuje
    napako, s funkcijo varoperrorstr.
    $A okt01; */





/* TESTI FUNKCIJ ZA BRANJE ARGUMENTOV: */



/* FUNKCIJE ZA DELO S KALKULATORJEM */


void instcalcinv(char *name,double fdoubleval (object,stack,stack,int,void *));
    /* V sistem kalkulatorja programa instalira funkcijo fdoubleval pod imenom
    name.
    $A igor avg01; */

void invassigncalcvar(char *name,double val);
    /* Spremenljivki kalkulatorja z imenom name priredi vrednost val. Ce taksna
    spremenljivka se ne obstaja, se naredi na novo.
    $A Igor jul99; */

int invgetcalcarg(int i,double *val,char **strval,object obj,stack st,
                  stack user);
    /* Racunanje vrednosti i-tega argumenta uporabniske funkcije kalkulatorja,
    ki se trenutno vrednoti. Ce je i-ti argument stevilski, vrne funkcija 1 in
    zapise v kalkulatorju izracunano vrednost argumenta, ce je argument niz,
    vrne funkcija 2 in zapise niz v *strval, ce pa i. argumenta ni, vrne
    0. Niz, ki se ha zapise v *strval, se ne sme brisati ali spreminjati.
    Argumenti obj, st in user so ustrezni argumenti uporabnisko definirane
    funkcije kalkulatorja, ki jih le-ta dobi ob klicu.
    $A Igor avg01; */

double invgetcalcargval(int i,object obj,stack st,stack user);
    /* Vrne vrednost i-tega argumenta uporabniske funkcije kalkulatorja,
    ki se trenutno vrednoti. Ce ta argument ne obstaja ali ni stevilskega tipa,
    javi funkcija napako.
    $A Igor avg01; */

char *invgetcalcargstr(int i,object obj,stack st,stack user);
    /* Vrne niz, ki ustreza i-temu argumenta uporabniske funkcije kalkulatorja,
    ki se trenutno vrednoti. Ce ta argument ne obstaja ali ni nizovnega tipa,
    javi funkcija napako.
    $A Igor avg01; */







/* BRANJE STEVILSKIH IN NIZOVNIH ARGUMENTOV - NADOMESTKI ZA STAREJSE FUNKCIJE: */


stack freadstringargsprev(FILE *fp,char *left,int nleft,char *right,int nright,
                   long from,long to,int maxnum,int buflength,
                   long *begin,long *next);
    /* Ta funkcija je nadomestilo za prejsnjo funkcijo freadstringssimp(), ki se
    je uporabljala za branje nizovnih argumentov funkcij interpreterja.
    Funkcija naj se NE UPORABLJA vec, namesto tega naj se uporablja
    invgetstrargsimp()! Funkcija ima nekaj odvecnih argumentov, ki se sploh ne
    uporabljajo, ker je njen edini namen nadomestiti prejsnjo funkcijo in
    hkrati delovati na nacin, na katerega delujejo zdajsnje funkcije.
    $A Igor jul99; */

int freadvarspecargprev(FILE *fp,long from, long to,ssyst syst,
                        char **name,stack *ind,long *start,long *newdata);
    /* Ta funkcija je nadomestilo za prejsnjo freadvarspec(), ki se je
    uporabljala za branje specifikacij spremenljivk in njihovih podtabel
    oziroma posameznih elementov.
    Funkcija naj se NE UPORABLJA vec, namesto tega naj se uporablja
    invgetvarspecargsimp()! Funkcija ima nekaj odvecnih argumentov, ki se sploh ne
    uporabljajo, ker je njen edini namen nadomestiti prejsnjo funkcijo in
    hkrati delovati na nacin, na katerega delujejo zdajsnje funkcije.
    $A Igor jul99; */

long freadvarspecargsimpprev(FILE *fp,long from, long to,ssyst syst,
                        char **name,stack *ind);
    /* Ta funkcija je nadomestilo za prejsnjo freadvarspecsimp(), ki se je
    uporabljala za branje specifikacij spremenljivk in njihovih podtabel
    oziroma posameznih elementov.
    Funkcija naj se NE UPORABLJA vec, namesto tega naj se uporablja
    invgetvarspecargsimp()! Funkcija ima nekaj odvecnih argumentov, ki se sploh
    ne uporabljajo, ker je njen edini namen nadomestiti prejsnjo funkcijo in
    hkrati delovati na nacin, na katerega delujejo zdajsnje funkcije.
    $A Igor jul99; */













