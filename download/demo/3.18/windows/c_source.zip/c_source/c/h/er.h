

/* Code which enables inclusion of er.h in headers without taking care that the
header has already been included, since this is explicitly checked through
the macro INCLUDED_er. */

#ifndef INCLUDED_er
#define INCLUDED_er

#ifndef INCLUDED_stdio  /* for definition of type FILE */
  #include <stdio.h>
  #define INCLUDED_stdio
#endif



extern FILE *errfl;
extern int errmode;


void marker(char *s,char c);
     /* Oznaci napako tako, da naredi datoteko, katere prvi znak imena je
     '%', nadaljevanje pa niz s. Ce se program prekine, preden je klicana
     funkcija deler z istim argumentom, datoteka s tem imenom ostane na disku.
     funkcija hkrati zapise znak c na konec datoteke, da se omogoci npr. stetje,
     kolikokrat je bil dolocen del programa izveden, preden je prislo do 
     prekinitve.
     $A Igor <==; */


void deler(char *s);
     /* Zbrise datoteko, ki jo je naredila funkcija marker z enakim nizom kot
     argumentom.
     $A Igor <==; */



/*    THE THREE STAGE ERROR REPORTING SYSTEM

- a set of utilities that enables making an error report in a standard way.
Error reporting is done in three stages: Error message (or report)
initialisation stage, message writing stage, and error report finalisation
stage.
  In the first stage the error report initialisation function is called (e.g.
err0 or err1, errfunc0 or errfunc1). This initialises the file and string
buffers to which the error reporter can write his own messages, prepends a
standard head for an error message (possibly with some useful information for
easier location of the place where error was generated) and does other tiny
necessary things that prepare the system for error reporting.
  In the second stage the error reporter writes the error report to a string
or file buffer. For accessing the string or error buffer there are functions
erf() and ers(). The message is simply printed e.g. by fprintf(erf(),"....",...)
of sprintf(erf(),"...",...). Several successive prints can be made, and the
messages printed may not contain the null characters (i.e. '\0'). In this
stage, the error reporter typically adds to the error message any information
he thinks would be useful for the receiver of the message (usually programme
user). There is an agreement that the printed messages should consist of one
or more full gramatically correct sentences, capitalised and ended by a period.
  In the last stage the error report finalisation function is called (e.g.
err2 or errfunc2). The finalisation function typically outputs the whole
error report to the standard error and the error output file (returned by
the function errorfile()), clears the buffers and possibly does some additional
stuff (such as prints posts a dialog box with an error report).

  All functions from this modula can be replaced by other functions in such a
way that the name of the specific function remains the same, but the
functionality changes. This enables even error reporting in low-level modules
to be adjusted in accordance with a specific application with its own error
reporting and messaging rules. This feature is implemented in such a way that
for each function, there is a function pointer which this function actually
calls, and the value of this function pointer can be modified to refer another
functon. The default function is also availavle, so that a newly defined
function can include a call to the default function. The function that sets
the function pointer returns its old value so it can be referred to or
restored if necessary.
  The default functions from this module have the following behaviour:
The first stage functions (err0, err1, errfunc0, errfunc1) first check if the
error message buffers are empty; If not, this is reported (this situation can
appear if something was printed to error message buffers somewhere else but
between a the calls to the first and the second stage function). Then the
error message buffers are prepared with head of the error messag written to
them. In the second stage, functions that give access to error message buffers
are called and specific information is written to that buffers. The functon
erf() at this stage always returns a file pointer to an open file; any writing
operation can be performed on this file pointer, but the file position should
not be modified (by writing operations, the position is automatically set to
the end of the current contents). The function ers() returns a pointer to the
first character after the end of the current contents of the memory buffer,
so that functions for writing to strings can directly be applied. Any call to
ers() first ensures that at least the specified minimum buffer size is left
in the allocated space; This size is by default 1000 bytes, but can be
increased to any number greater than 1000 bytes by the function setminerbuf().
In the third stage (call to one of th efunctions err2 or errfunc2), the status
of buffers is checked and buffer contents are output to the standard error and
the error output file as it is returned by the function errorfile() (writing
to this file is skipped if the returned file pointer is NULL). An message tail
is appended to the buffers before the contents are output. Finally, the buffers
are emptied. Actually, the string buffer is not deallocated and the file
buffer is not closed, onlt the positions are reset to the beginning.

  An application can either replace one or more error reporting functions in
this module, or can use its own functions for error reporting; usually a
combination of both is used, so that error reporting in low level modules
is also affected and at the same time higher level features are used for
reportnig errors at higher levels (e.g. in file interpreter functions where
additional information about interpretation status is highly appreciated in
error messages). It is recommended that the second stage functions from this
module are always used, because the sufficient access to message buffers is
given by the module. Then it is recommended that the first stage functions
first call the appropriate original first stage functions and then do the
additional job (e.g. append additional information to the gead of the message
or store some addional information elsewhere; here the erorr message buffers
will typically be accessed). In the third stage functions, additional
information should be appended to error buffers first, then additional methods
of output should be used (e.g. by a dialog window) and additional storing
should be made if necessary, and finally the original third stage functions
should be called. 
  Use of the original first and second stage functions should be avoided if
what these functios do is not satisfactory for a specific application. This
usually includes two steps, the replacement of the original function itself
and possible derivation of other higher level fuctions. Sometimes the first
step would be enough, but sometimes we want to have some additional diversity
in the first and third stage functions (e.g. have different error reporting if
the error occured directly in an file interpreter function or not). Building
proper functions for replacement of the first and the second stage error
reporting functions is easy because there are functions that empty error
message buffers (typically this will be done within third stage functions, and
second stage functions will check if the buffers are empty and report if they
are not).
*/

 

/*      FILE AND STRING BUFFERS FOR WRITING DOWN ERROR MESSAGES 

  erf() returns the file and ers() returns the string into which the whole or
a part of the error message can be printed directly. If both are used, the
information in the string buffer is output first. For output, the message in
the string buffer can be accessed by ersbuf() as a standard C string ('\0'
terminated char *). The message in the file buffer is the whole contents
of the file from its beginning to the current position (therefore, if you
use this yourself, take care that you set appropriately the position after
usage). It is recommended to use only the string buffer. Function ermes()
appends the file buffer to the string buffer, clears the contents of the file
buffer and returns the contents of the string buffer, therefore it returns the
current contents of the whole error message.
  The function clearerbuf() clears the contents of both buffers, but does
not close the file or deallocate the string buffer. Function deleteerbuf()
deallocates the string buffer and closes (removes) the file buffer.
Function call setminerbuf(minbuf) sets the minimum space in the string
buffer, so that whenever ers() is called, in the returned string buffer
there is enough space for at least minbuf characters. If enough characters
are printed to the buffer that there is less than for minbuf characters
free space left, the next call to the ers() extends the buffer in such a
way that the current content of the message is unchanged.
An open file (file pointer)is returned by erf(), into which we can write the
error message between the calls to error message initialisation and
finalisation functions. The file position is set after the end of the current
message.
  WARNING: Anything you print to ers() must be NULL terminated!
*/



/* FILE BUFFER: */

FILE *erfdefault(void);
    /* The default version of erf(). Made globally avaliable such that it can
    be upgraded. The position is at the end of the current contents of the
    error message buffer. 
    $A Igor jul99, nov02; */

void * seterf(FILE * (*func) (void));
    /* Sets the funcion erf(), which returns a file buffer for writing error
    messages, to func. Returns the previous function assigned to this task.
    $A Igor jul99, nov02; */

FILE *erf(void);
    /* Returns a file buffer for writing error messages. An error message can
    be written to that file between the two successive calls to the functions
    that initialise and finalise error reporting. The finalising function
    (i.e. err2 or errfunc2) will take care that the message written to the
    buffer will be output to the proper output streams and files. The
    message is contained in the file from the beginning to the current
    position.
    $A Igor jul99, nov02; */


/*  STRING BUFFER: */

char *ersdefault(void);
    /* Default version of the ers() function.
    Returns the string buffer on which one can print (e.g. by sprintf())
    a part of the error message. It is guaranteed that at least a certain
    minimum amount of space is allocated for the returned pointer, which can
    be set by setminerbufdefault() (the function setminerbuf() is initially
    set to that function).
    $A Igor nov02; */

char *ersbufdefault(void);
    /* Default version of ersbuf().
    Returns the current contents of the string error message buffer,
    intended for output of the error report.
      WARNING: The function can return NULL if there was no need to allocate
    the buffer.
    $A Igor nov02; */

char *ermesdefault(void);
    /* Default version of ermes.
    Returns the complete contents of the error reporting buffers. If file
    buffer is not empty, its contents is appended to the string buffer and
    then the pointer to the beginning of the string buffer is returned.
    $A Igor nov02; */

char *ers(void);
    /* Returns the string buffer on which one can print (e.g. by sprintf())
    a part of the error message. It is guaranteed that at least a certain
    minimum amount of space is alocated for the returned pointer, which can
    be set by setminerbuf().
    $A Igor nov02; */

char *ersbuf(void);
    /* Returns the current contents of the string error message buffer,
    intended for output of the error report.
      WARNING: The function can return NULL if there was no need to allocate
    the buffer.
    $A Igor nov02; */

char *ermes(void);
    /* Returns the complete contents of the error message buffers, intended
    for output of the error report. If the file error buffer is not empty, it
    appends its contents to the end of the string error message buffer first.
    It actually returns the contents of the string error message buffer.
      The function can not return NULL.
    $A Igor nov02; */


void *seters(char * (*func) (void));
    /* Sets the function ers() to func and returns the address of the current
    function used as ers() as void *.
      WARNING:
      When the ers() is re-defined, the functions ersbuf(), setminerbuf(),
    deleteerbuf(), clearerbuf() and aldso erf() should be redefined
    consistently! As an example of how to define these functions, see the
    definitions of their default versions in this module.
    $A Igor nov02; */

void *setersbuf();
    /* Sets the function ersbuf() to func and returns the address of the
    current function used as ersbuf() as void *.
      WARNING:
      When the ersbuf() is re-defined, the functions ers(), setminerbuf(),
    deleteerbuf(), clearerbuf() and aldso erf() should be redefined
    consistently! As an example of how to define these functions, see the
    definitions of their default versions in this module.
    $A Igor nov02; */

void *setermes();
    /* Sets the function ermes() to func and returns the address of the
    current function used as ermes() as void *.
      WARNING:
      When the ermes() is re-defined, the functions ers(), setminerbuf(),
    deleteerbuf(), clearerbuf() and aldso erf() should be redefined
    consistently! As an example of how to define these functions, see the
    definitions of their default versions in this module.
    $A Igor nov02; */


/* INITIALISATION AND SETTINGS FOR ERROR BUFFERS: */

int minerbufdefault(int size);
    /* Default version of minerbuf(). Sets the minimum number of bytes that
    will always be available in the error buffer, and returns the previous
    value. If size<0, then it only returns the current value of the minimum
    size, but does not change it. If min is smaller than the MINBUF (a macro
    defined in er.c), then the minimum buffer size is set to MINBUF.
    $A Igor nov02; */

int checkminerbufdefault(int size);
    /* Checks if minimum number of bytes that is always available in the error
    buffer is at least size. If not, it is increased to size, otherwise it is
    left unchanged. Returns previous minimum size of error buffer.
    $A Igor jul03; */

void clearerbufdefault(void);
    /* Default version of clearerbufdefault().
    Resets error reporting buffers so that their content is empty. It does
    not deallocate temporary memory space or close the temporary file.
    $A Igor nov02; */

void deleteerbufdefault(void);
    /* Defauld version of deleteerbuf().
    Closes the error reporting system buffer file and deallocates the string
    buffer. Before that, it checks if any messages are still buffered and
    outputs these messages to the standard output.
    $A Igor nov02; */

void *setminerbuf(int (*func) (int));
    /* Sets minerbuf() to func() and returns the address of the current
    function used as minerbuf() as void *.
      WARNING:
      When the minerbuf() is re-defined, other functions concerning the
    error reporting buffers such as ersbuf(), minerbuf(), deleteerbuf(),
    clearerbuf() and erf() should be redefined consistently! As an example of
    how to define these functions, see the definitions of their default
    versions in this module.
    $A Igor nov02; */

void *setcheckminerbuf(int (*func) (int));
    /* Sets checkminerbuf() to func() and returns the address of the current
    function used as minerbuf() as void *.
      WARNING:
      When the checkminerbuf() is re-defined, other functions concerning the
    error reporting buffers such as ersbuf(), minerbuf(), deleteerbuf(),
    clearerbuf() and erf() should be redefined consistently! As an example of
    how to define these functions, see the definitions of their default
    versions in this module.
    $A Igor jul03; */

void *setclearerbuf(void (*func) (void));
    /* Sets clearerbuf() to func() and returns the address of the current
    function used as clearerbuf() as void *.
      WARNING:
      When the clearerbuf() is re-defined, other functions concerning the
    error reporting buffers such as ersbuf(), minerbuf(), deleteerbuf(),
    clearerbuf() and erf() should be redefined consistently! As an example of
    how to define these functions, see the definitions of their default
    versions in this module.
    $A Igor nov02; */

void *setdeleteerbuf(void (*func) (void));
    /* Sets deleteerbuf() to func() and returns the address of the current
    function used as deleteerbuf() as void *.
      WARNING:
      When the deleteerbuf() is re-defined, other functions concerning the
    error reporting buffers such as ersbuf(), minerbuf(), deleteerbuf(),
    clearerbuf() and erf() should be redefined consistently! As an example of
    how to define these functions, see the definitions of their default
    versions in this module.
    $A Igor nov02; */


int minerbuf(int min);
    /* Sets the minimum number of available bytes in the string error reporting
    buffer to min and returns the previous minimum vlue.
    $A Igor nov01; */

int checkminerbuf(int min);
    /* Checks if minimum number of bytes that is always available in the error
    buffer is at least size. If not, it is increased to size, otherwise it is
    left unchanged. Returns previous minimum size of error buffer.
    $A Igor jul03; */

void clearerbuf(void);
    /* Clears the contents of error reporting buffers. This function must be
    called after the error messages residing in these buffers are output, so
    the buffer contents are not needed any more and buffers should be ready
    for filling with new messages.
    $A Igor nov02; */

void deleteerbuf(void);
    /* Releases resources occupied by the error reporting buffers, e.g. closes
    the error buffer file and deallocates the string buffer. Before a call to
    this function, the contents of the buffers should be cleared by the
    clearerbuf().
      In principle this function is rarely used. Typical use is when for some
    special error message a lot of space is needed, so we needed to increase
    the buffer size in order to create the message, and after usage we want
    to release the unnecessary space. Typically we would call minerbuf(0)
    together with this function.
    $A Igor nov02; */



/* OUTPUT FILE FOR WRITING ERROR MESSAGES:
Defines a (possibly open) file into which program writes error reports
beside the standard error. Error message initialising and finalising
functions must be written in such a way that this file can be NULL! */

FILE *errorfiledefault(void);
    /* The default function, which returns the programme file for writing
    error reports - simply returns NULL, which means that eroror reports
    will not be written to a file by the error message finalising functions.
    $A Igor nov02; */

void *seterrorfile(FILE * (*func) (void));
    /* Sets the function errorfile, which returns the file (either open or NULL)
    into which the function finalising the error report should also write the
    error message. The argument can be NULL, in that case the function errorfile
    will return NULL in any case. Function returns the previous version of
    errorfile() as void *.
      Typically, in applications this function will return an open output file
    or a special file for collecting error reports.
    $A Igor nov02; */

FILE *errorfile(void);
    /* Returns the file (either a file pointer to an open file or null) into
    which error messages should be also written beside the standard locations.
    $A Igor nov02; */




/* FUNCTION PAIRS FOR INITIALISING AND FINALISING ERROR REPORTS: */


void errfunc0default(char *funcname);
    /* Default version of errfunc0(). 
    Check if error buffers are empty and outputs a head of the error report
    on the standard error and the appropriate file if specified, where
    funcname must be the name of theC function in which the error appeared.
    $A Igor jul99 nov02; */

void *seterrfunc0(void (*func) (char * funcname));
    /* Sets the function errfunc0 to func() and returns the previous version
    of errfunc0.
    $A Igor jul99 nov02; */

void errfunc0(char *funcname);
    /* Initialises the error report, in which the name funcname of the
    function in which error occurred is also noted.
    $A Igor jul99 nov02; */

void errfunc1default(int code,char *funcname);
    /* Default version of errfunc1(). Prints a head of the error report
    containing the name of the function where error occured funcname and
    the error code code, to the standard error and the appropriate file if
    specified.
    $A Igor jul99 nov02; */

void *seterrfunc1(void (*func) (int code,char *funcname));
    /* Sets the function errfunc1 to func() and returns the previous version
    of errfunc1.
    $A Igor jul99 nov02; */

void errfunc1(int code,char *funcname);
    /* Initialises the error report, in which the name funcname of the
    function in which error occurred and the error code code are also noted.
    $A Igor jul99 nov02; */

void errfunc2default(void);
    /* Default version of errfunc2(). Copies error message from the error
    string of file buffer to the standart erorr and the appropriate file as
    specified by errorfile(), resets (empties) the error reporting buffers.
    $A Igor jul99 nov02; */

void errfunc2(void);
    /* Finalises the error report in which the name of the function in which\
    error occurred is also noted. In error reporting, this function is
    combined with either the error report initialisation function errfunc0()
    or errfunc1(); between the two calls arbitrary messages can be written to
    the error reporting file buffer (obtained by the function erf()) or the
    error reporting string buffer (obtained by the function ers()).
    $A Igor jul99 nov02; */

void err0default(void);
    /* Default version of err0().
    Check if error buffers are empty and outputs a head of the error report
    on the standard error and the appropriate file if specified.
    $A Igor jul99 nov01; */

void *seterr0(void (*func) (void));
    /* sets err0() to func(), returns previous version of err0.
    $A Igor jul99; */

void err0(void);
    /* Performs initialisation of the error report.
    $A Igor jul99; */

void err1default(int code);
    /* Default version of err1().
    Check if error buffers are empty and outputs a head of the error report
    on the standard error and the appropriate file if specified, including
    the error code code.
    $A Igor jul99 nov02; */

void *seterr1( void (*func) (int code) );
    /* Sets err1() to func() and returns the previous version of err1 as
    void *.
    $A Igor jul99 nov01; */

void err1(int code);
    /* Performs initialisation of the error report, also notes the error code.
    $A Igor jul99 nov01; */

void err2default(void);
    /* default err2(). Completes the error report.
    $A Igor jul99 nov01; */

void *seterr2( void (*func) (void) );
    /* Sets err2() to func() and returns the previous version of err2 as
    void *.
    $A Igor jul99 nov01; */

void err2(void);
    /* Finalises the error report. It can be used in combination of either
    err0() or err1(0).
    $A Igor jul99 nov01; */



/* Warning:
  This macro must be used very carefully because it represents a composed
statement. If macro is called with ; after it, then it will actually
represent two statements (the latter of which is an empty statement),
therefore its use with if/else would generate an error.
  The body MUST be in curly brackets {} because otherwise the first
statement could be executed separately from the others (e.g. if the macro
call would follow the "if" keyword).
 */

#define m_errorreport0(funcname,errorstring)  \
{ errfunc0(funcname);  \
if ((errorstring)!=NULL)  \
  sprintf(ers(),"%s",(errorstring));  \
else  \
  sprintf(ers(),"Unknown error.\n");  \
errfunc2(); }


/*
#define m_errorreport0(funcname,errorstring) errorreport00(funcname,errorstring)
*/


void errorreport00(char *functionname,char *errorstring);
    /* Launches an error report. functionname is the name of the function where
    error occured and erorr string is a string containing the report. Either of
    these can be omitted.
      This function is conglomeration of the errfunc0(), printing on error
    buffer and errfunc2(), and its use is more comfortable than using individual
    parts when the error string is not composed of different parts.
      WARNING:
      The report generated by this function will not include correct information
    on the location where the error occured. To correct this, use the macro
    m_errorreport0.
      REMARK:
      This function was called errorreport0 before and was a global definition.
    Now it is replaced by a macro defined in er.h. This is necessary because
    the macro must extract position in the file (file name and line number).
    $A Igor feb05; */




/* WARNINGS: */

int warnoutleveldefault(int level);
    /* Default version of warnoutlevel().
    Sets the level of warning output to level, which should be 0 1, 2 or 3.
    Only those warnings which have the level lesser or equal to the level set
    by this function will be reported from the function call on. 0 will switch
    off warnings completely. Function returns the previous value of the
    warning output level.
    $A Igor nov02; */

void warnfunc1default(int level,char *funcname);
    /* Default version of warnfunc1().
    Initialises an warning message. level determines whether the warning
    is actually reported or not and should have a value 1, 2 or 3. The smaller
    the value is, the more important the warning is considered and greater the
    chance is that the warning will be output. Function warnoutdefault() can
    be used to specify which level warnings are printed out. funcname can
    specify the function in which the warning is produced. If it is NULL or an
    empty string, function name is considered irrelevant and is not stated inthe output.
    $A nov02; */

void warnfunc2default(void);
    /* Default version of warnfunc2(). Finalises the warning message.
    $A Igor nov02; */

    
void *setwarnoutlevel(int (*func)(int));
    /* Sets the function warnoutlevel to func and returns previous version of
    this function so that it can be restored later or called within the new
    version (if this one is meant only as an supplemented version of the old
    function).
    $A Igor nov02; */

void *setwarnfunc1 (void (*func)(int, char *));
    /* Sets the function warnfunc1 to func and returns the previous version of
    this function so that it can be restored later or called within the new
    version (if this one is meant only as an supplemented version of the old
    function).
    $A Igor nov02; */

void *setwarnfunc2(void (*func)(void));
    /* Sets the function warnfunc1 to func and returns the previous version of
    this function so that it can be restored later or called within the new
    version (if this one is meant only as an supplemented version of the old
    function).
    $A Igor nov02; */

int warnoutlevel(int level);
    /* Sets the level of warning output to level, which should be 0 1, 2 or 3.
    Only those warnings which have the level lesser or equal to the level set
    by this function will be reported from the function call on. 0 will switch
    off warnings completely. Function returns the previous value of the
    warning output level.
    $A Igor nov02; */

void warnfunc1(int level,char *funcname);
    /* Initialises an warning message. level determines whether the warning
    is actually reported or not and should have a value 1, 2 or 3. The smaller
    the value is, the more important the warning is considered and greater the
    chance is that the warning will be output. Function warnoutdefault() can
    be used to specify which level warnings are printed out. funcname can
    specify the function in which the warning is produced. If it is NULL or an
    empty string, function name is considered irrelevant and is not stated inthe output.
    $A nov02; */

void warnfunc2(void);
    /* Finalises the warning message.
    $A Igor nov02; */



int warnoutlevel(int level);
    /* Sets the level of warning output to level, which should be 0 1, 2 or 3.
    Only those warnings which have the level lesser or equal to the level set
    by this function will be reported from the function call on. 0 will switch
    off warnings completely. Function returns the previous value of the
    warning output level.
    $A Igor nov02; */


void warningreport1(int level,char *funcname,char *errorstring);
    /* Launches an error report. funcname is the name of the function where
    error occured and erorr string is a string containing the report. Either of
    these can be omitted.
      This function is conglomeration of the errfunc0(), printing on error
    buffer and errfunc2(), and its use is more comfortable than using individual
    parts when the error string is not composed of different parts.
    $A Igor feb05; */



void instersys(FILE * (*erffunc) (void),
               void (*errfunc0func) (char * funcname),
               void (*errfunc1func) (int code,char *funcname),
               void (*errfunc2func) (void),
               void (*err0func) (void),
               void (*err1func) (int code),
               void (*err2func) (void)    );
    /* Sets the most important user defined functions of the error reporting
    system. This does not include the error buffer functions since these can
    usually be taken from this module.
    Names of the arguments unambiguously indicate, which functions are in
    question.
    $A Igor jul99 avg01 nov01; */





/* Correction to error reporting, enables adding file name, line mumber and
compilation date of the source file: */
#define errfunc0(func) errfunc0cor(func,__FILE__,__LINE__,__DATE__)
#define errfunc1(code,func)  errfunc1cor(code,func,__FILE__,__LINE__,__DATE__)
#define warnfunc1(level,func)  warnfunc1cor(level,func,__FILE__,__LINE__,__DATE__)


void errfunc0cor(char *function,char *file,int line,char *date);
    /* Corrected function for error reporting called by macto errfunc0 (to
    override the original function) - adds more accurate data about the
    erro like source file, line number and date of compilation.
      DON'T CALL this function DIRECTLY, it should be called only by the
    macro errfunc0!
    $A Igor dec03; */

void errfunc1cor(int code,char *function,char *file,int line,char *date);
    /* Corrected function for error reporting called by macro errfunc1 (to
    override the original function) - adds more accurate data about the
    erro like source file, line number and date of compilation.
      DON'T CALL this function DIRECTLY, it should be called only by the
    macro errfunc1!
    $A Igor dec03; */

void warnfunc1cor(int level,char *function,char *file,int line,char *date);
    /* Corrected function for warnings called by macro watnfunc1 (to override
    the original function) - adds more accurate data about the error, i.e.
    source file, line number and date of compilation.
      DON'T CALL this function DIRECTLY, it should be called only as warnfunc1!
    $A Igor dec03; */





              /***************************/
              /*                         */
              /*  CALLING STACK TRACING  */
              /*                         */
              /***************************/


/*
Initial specification:

SISTEM ZA SLEDENJE FUNKCIJ

OSNOVNI NAMEN

Osnovni namen je omogociti sledenje klicem funkcij. Sistem naj bi dopolnil
splosne mehanizme sledenja.

Razlike glede na splosno sledenje:

Dodana bi bila globalna spremenljivka, ki kontrolira, ali se slednje funkcijam
izvaja ali ne.

Sledenje bi se izvajalo s klicem makra na zacetku in koncu funkcije.

Naj bi se dalo kontrolirati, ali se klici funkcij registrirajo v datoteki za
sledenje ali ne. 

Sistem naj bi bil narejen tako, da bi bil primeren za izdelavo "debug" verzij,
kjer bi se sledenje klicem funkcij linkalo zraven, vendar bi se dalo
izkljuciti preko globalnih spremenljivk. Sistem bi moral biti narejen tako,
da debug verzije ne bi bile bistveno pocasnejse od release verzij - vsaj v 
primeru, ko je sledenje funkcijam izkljuceno.

Vstavljanje sledenja funkcijam naj bo zelo enostavno - le s klicem dveh
makrojev - enega za zacetek, drugega pa za konec funkcije, katerih argument
bi bil ime funkcije.

Ko bi bilo sledenje vkljuceno, bi se izpisal klicni sklad tudi v sporocilih o
napakah.

*/


/*
  Macros below provide a mechanism for tracing function calling stack and
calling sequence. Both is done for each thread specially. The calling stack is
traced by registration of entrance and exit from a function by a macro call.
Effect of these macro calls can be annihilated on compile-time level by 
unsetting the appropriate macro definition, which enables confortable 
production of either release or debug executable or libraries. Besides, tracing
can be controlled by a global variable when the mechanisim is linked in the
code.
  Tracing of function calls does not provide any means of action (such as 
printing the information), it just keeps track of information. This information
can be used by error reportinf or execution tracking functions.

*/




          /*************************************/
          /*                                   */
          /*  TRACING UTILITIES FOR DEBUGGING  */
          /*                                   */
          /*************************************/

/*
  Macros below provide a simple tracing facility by which you can for example
trace down where the program has crashed.
  Tracing must be activated by defining the precompiler variable EXTRACE before
this file (er.h) is included. If this macro variable is not defined, then
calling the macros TRIN, TRPT and TROUT has absolutely no effect, not even on
the compiled code (see the definitions below).
  Each time one of the macro calls TRPT, TRIN or TROUT is passed, a concise
information about the location within the source file is printed to a file,
normally to .0tracefile.txt in the current directory at the time when first
such macro is passed. The file is automatically open (created if necessary)
when first needed.
  Programmer can assign a group and identity number to each macro call, and also
pass the name of the function within which the macro is invoked and an additional
comment for his use. Position in the source code is automatically captured and 
reported to the trace file by using pre-defined preprocessor macros.
  An alternative mechanism to switch tracing at given locations on or off is to
define the tracing condition through the macto TRCOND, whose arguments are
different parameters of the tracing point or pair. By default it evaluates to 1.
By changing the definition of this macro we can cause that the condition
evaluates to zero for some tracing points, which are consequently not executed,
however this does not ensure that the compiled code is the same as without
calling macros (since at least the condition is evaluated and checked at each
macro call).
  TRIN (entrance to a given block of code) and TROUT (exit from the block) must
always be called in nested pairs and in such a way that either both calls in the
pair or none is passed by the execution flow. They must have the same group and
identity parameters, since otherwise an error is reported in the trace file.
These macros are used to check that the execution of a block of code indeed ends
where expected. Internally a level of nested TRIN/TROUT calls is managed, and
it is checked that each TROUT corresponds to the appropriate TRIN with the same
group and identity number (otherwise an error is reported in the trace file).
The trace level is managed for each thread separately if there are more threads.
In this case, if the thread is not the main thread, the trace mark head <, > or
| is combined by the internal thread ID, e.g. <1 or |4 .
  TRPT is intended just to mark that execution has passed a given point, it is
not called in pairs and does not affect the internal trace level. Everything else
is the same.
  Marks that these macros write to the trace file are something similar to
  < 1: 1.40 (2)  {133  sgs_test.h (main)}    // around test_sg_intfc //t=4.3/0.2
< indicates this is an entrance trace to a given block, 1: indicates the level,
1.40 is group (1) and identity number (40) provided by the caller, (2) is a
unique identifier assigned to a trace internally, inside {} there are data about
the location within the source where the appropriate macro was called (line
number, source file and functin name (the latter is provided by the caller) and
finally there is caller's comment between // . Finally the time mark appears
in the form t=//4.3/0.2, where 4.3 is the total CPU time since initialization of
the tracing facilities and 0.2 is the CPU time since the last mark in the same
thread. For TROUT this is the CPU time since the corresponding call to TRIN
while for TRIN (in rund brackets!) and for TRPT this is the CPU time since the
last (executed) call to either TRPT or TROUT.
  Lines are indented according to
the current trace level. > indicate an exit trace (macro TROUT) and | a point
trace (TRPT). Warning and erroe lines begin with ! and are indented more than
the trace marks.
  Remarks on thread locking:
  In order to switch on tracing for a given source file, include <er.h> in this
file and insert the line "#define EXTRACE" above before including any header in
the file. If calls to THREAD LOCKING macros appear in the file, traces will be
marked whenever a lock to be set is nonzero when a thread lock is called. Group
and ID arguments are set to 0 while func is set to the name of the thread
locking macro comment is set to NULL in these trace invocations; this is
important to know if we redefine the default condition for actually marking
the trace (by redefining TRCOND, which by default is just 1). When program
hangs because of trying to lock a lock that is already locked, but is for some
reason not released by another threas, this would enable to find where it
happened. See definitions of thread locking macros and TRLOCK for more details.
  To trace MEMORY ALLOCATION and DEALLOCATION:
  Macros are defined in sysint.h, which replace calls to functions malloc(),
calloc(), realloc() and free() with calls that include marking tracing
information. These macros are defined if the following preprocessor variables
are defined: EXTRACE and EXTRACEMEM.

*/






/* Condition for marking an individual trace: */
#define TRCOND(group,id,func,comment,file,line) (1)


/* invokes an arbitrary action,typically print something */
#ifdef EXTRACE
 #define TRDO(group,id,func,comment,action)    \
   if (TRCOND(group,id,func,comment,__FILE__,__LINE__)) { action }
#else
 #define TRDO(group,id,func,comment,action)
#endif


/* Mark entrance to a code block */
#define TRIN(group,id,func,comment)   TRDO (group,id,func,comment, \
    extraceinfunc(group,id,func,comment,__FILE__,__LINE__); )

/* Mark exit from a code block */
#define TROUT(group,id,func,comment)   TRDO (group,id,func,comment, \
    extraceoutfunc(group,id,func,comment,__FILE__,__LINE__);  )

/* Mark a point in a code block */
#define TRPT(group,id,func,comment)   TRDO (group,id,func,comment, \
    extraceptfunc(group,id,func,comment,__FILE__,__LINE__);  )

/* Write a comment to the trace file */
#define TRCOM(group,id,func,comment)   TRDO (group,id,func,comment, \
   extracecomfunc(comment,__FILE__,__LINE__);  )

/* The following is used for printing to the trace file; action must include
a print to the trace file (trf()), which appends a newline at the end. */
#define TRDOPR(group,id,func,comment,action)   TRDO (group,id,func,comment, \
   extracecomfunc(NULL,__FILE__,__LINE__); action  )


FILE *trf(void);
    /* Returns the trace file. It opens it if it is not yet open, so one can
    always directly write to the returned file without any checks.
    $A Igor feb03; */

int tracelockstate(void);
    /* Returns the state of tracelock; Needed in tr_mark_mem() in sysint.h to
    prevent infinite recursion.
    $A Igor feb04; */

int extraceinfunc(int group,int id,char *funcname,char *comment,
                   char *filename,int line);
    /* Marks the beginning of the nested block whose execution we are tracing.
    This function should be always called through the macro TRIN in combination
    with TROUT. In such a way one can easily switch whether the function is
    actually compiled (macro EXTRACE) or executed (macro TRCOND) in a given
    portion of code, and it makes absolutely no effect on the compiled code
    when the compilation is switched off.
      Used for tracing which portions of code are executed and in which order
    and which code were executed before program crash.
    $A Igor feb04; */

int extraceoutfunc(int group,int id,char *funcname,char *comment,
                    char *filename,int line);
    /* Marks the end of the nested block whose execution we are tracing.
    This function should be always called through the macro TROUT in 
    combination with (preceeding) TRIN. In such a way one can easily switch
    whether the function is actually compiled (macro EXTRACE) or executed
    (macro TRCOND) in a given portion of code, and it makes absolutely no
    effect on the compiled code when the compilation is switched off.
      Used for tracing which portions of code are executed and in which order
    and which code were executed before program crash.
    $A Igor feb04; */

int extraceptfunc(int group,int id,char *funcname,char *comment,
                     char *filename,int line);
    /* Marks the position in a block of code whose execution we are tracing.
    This function should be always called through the macro TRPT. In such a 
    way one can easily switch whether the function is actually compiled (macro
    EXTRACE) or executed (macro TRCOND) in a given portion of code, and it
    makes absolutely no effect on the compiled code when the compilation is
    switched off.
      Used for tracing which portions of code are executed and in which order
    and which code were executed before program crash.
    $A Igor feb04; */

int extracecomfunc(char *comment,char *filename,int line);
    /* Writes a comment to the trace file.
    $A Igor feb03; */



















#endif    /* (not defined) INCLUDED_er */

