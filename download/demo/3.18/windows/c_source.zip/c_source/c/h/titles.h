void ftitleigs(FILE *fp,int spaces);

void titleigs(int spaces);

void ftitleinverse20(FILE *fp,int spaces);

void titleinverse20(int spaces);

void ftitleinverse(FILE *fp,int spaces);

void titleinverse(int spaces);

void ftitlec3m(FILE *fp,int spaces);

void titlec3m(int spaces);

void fprogtitle0(FILE *fp1,FILE *fp2,char *progname,double progversion,
     char *spec,int month,int year,char *creator,char *creatormail,char *line1,
     char *line2,char *line3,char *line4,int shift,char *info1,
     char *info2,char *info3,int shiftinfo,int spaces,int edge);
    /* V datotekoi fp1 in fp2 zapise naslovnico programa. progname je ime
    programa, progversion je verzija programa, spec je specifikacija (npr. Beta
    ali DEMO), month in year sta mesec in leto izdelave (ce je leto manj od 1
    se datum ne izpise, ce pa je mesec manj od 1 ali vec od 12, se ne izpise
    mesec), creator je ime ustvarjalca programa, creatormail je njegov e-mail
    naslov (ce je creator NULL, se ne izpise enako velja za creatormail),
    line1, line2, line3 in line4 so vrstice, ki se izpisejo pod ustvarjalcem
    programa, shift je zamik teh vrstic, info1, info2 in info3 so naslovi, kjer
    se dobijo informacije (obicajno html in e-mail), shiftinfo je st. znakov,
    za katero so ti nizi zamaknjeni od okvirja (vmes ni roba edge kot pri
    ostalih znakih), spaces je stevilo praznih znakov na zacetku vsake vrstice,
    edge pa najmanjse stevilo praznih znakov med robom in nizi (kar ne velja za
    levi rob pri info1, info2 in info3).
     Opomba: letnica year je lahko dvostevilcna.
    $A Igor mar99; */

void finvtitle0(FILE *fp1,FILE *fp2,
     char *name,double version,char *verspec,int month,int year,
     char *creator,char *creatormail,
     char *line1,char *line2,char *line3,char *line4,
     char *info1,char *info2,char *info3);
    /* V datoteki fp1 in fp2 izpise naslovnici za program Inverse.
    name je ime programa, version je verzija, verspec dopolnilna specifikacija
    verzije (npr. "Beta" ali "Demo", month in year sta mesec in leto izdelave,
    creator in creatormail sta ime in e-mail ustvarjalca programa, line1 ...
    line4 so vrstice, ki se izpisejo pod imenom ustvarjalca (in imajo enak
    zamik), info1 ... info3 pa so vrstice, ki se izpisejo na koncu (in so
    zamaknjene malo v levo, med njimi in spodnjim robom okvira ni praznega
    prostora).
     Opomba: letnica year je lahko dvostevilcna.
    $A Igor mar99; */






