

                 /* VRSTICNI UKAZNI INTERPRETER */




/* Koda, ki omogoca v kljucitev te datoteke v headerjih, ne da bi bilo treba
skrbeti za to, ali ni ta header ze bil kakorkoli vkljucen, ker se v to
eksplicitno preverja preko definicije ustreznega makra: */
#ifndef INCLUDED_lint
#define INCLUDED_lint



/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_st
#include <st.h>
#endif




/* DEFINICIJE RELEVANTNIH TIPOV: */


typedef struct{
        char end;          /* signal za konec interpretacije */
        char *buf,         /* vmesni pomnilnik */
             *line,        /* vrstica (ukaz) */
             *com,         /* cisti ukaz */
             *param;       /* kazalec na prvi znak niza parametrov */
        int  maxlength;    /* najvecja dopustna dolzina vrstice */
        stack commands,    /* seznam ukazov */
              actions;     /* seznam ustreznih akcij, ki pripadajo ukazom */
        void (*before) (void *); /* funkcija, ki se izvrsi pred zacetkom interpretacije */
        void (*signal) (void *); /* funkcija, ki se izvrsi, ko se caka na ukaz*/
        void (*preaction) (void *); /* funkcija, ki se izvrsi tik pred akcijo */
        void (*unknown) (void *); /* funkcija, ki se izvrsi, ce interpreter
                              naleti na neznan ukaz. Ob izvrsitvi te funkcije se
                              kot parameter prenese isti parameter kot pri klicu
                              znanih ukazov. */
        void (*postaction) (void *); /* funkcija, ki se izvrsi tik po akciji */
        void (*after) (void *); /* funkcija, ki se izvrsi po koncu interpretacije */
        } _licom;
typedef _licom *licom;



/* DEFINICIJE FUNKCIJ: */



licom newlicom(int maxlength);
    /* Vrne kazalec na objekt tipa _licom, za katerega alocira prostor. Vsa
    polja strukture postavi na 0, razen obeh skaldov, za katera se tudi
    alocira prostor, ter maxlength, kateremu se priredi argument funkcije. */

void displicom(licom *li);
    /* Sprosti spomin za spremenljivko **li. Zbrise tudi sklada (**li).actions
    in (**li).commands, s tem da pri skladu (**li).commands zbrise tudi vse
    nize, ki so na tem skladu (?). */

void lineinterpret(licom com);
     /* Vrsticni interpreter za interpretacijo standardnega vhoda. Funkcija
     bere vrstice s standardnega vhoda in izvrsuje ukaze, ki so v teh vrsticah.
     Ko se najde ukaz (1. beseda v vrstici) na skaldu com->commands, se izvrsi
     ustrezna funkcija tipa void(licom), nalozena na sladu com->actions. */

void instlicom(licom com,char * command,void action(licom));
    /* Na ukazno spremenljivko com, ki doloca nacin interpretacije vrstic,
    instalira nov ukaz command, ki mu pripada izvrsitev akcije action. */








#endif    /* (not defined) INCLUDED_lint */

