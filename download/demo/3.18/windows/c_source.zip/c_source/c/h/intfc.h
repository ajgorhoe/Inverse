/* VMESNIK MED PROGRAMOM ZA INVERZNO IN PROGRAMOM ZA DIREKTNO ANALIZO */





/*

struct _OUTINFO{
       char *name;
       long pos,start,end;
       stack cont;
       stack res;
       void *point;
       struct _OUTINFO * superior;
       };


typedef struct _OUTINFO _outinfo;
typedef _outinfo *outinfo;

*/

/*
double fieldval(long incnum,char *fieldname,long nodenum,int coord,
       FILE *fp,outinfo *oi1);
*/
       /* Vrne koordinato coord vrednosti polja z imenom fieldname po inkrementu
       s stevilko incnum v vozlu s stevilko nodnum. Podatke najde v datoteki fp,
       ze najdene podatki pa so vpisani v sistemu oi1. */

/*
double fieldval(long incnum,char *fieldname,long nodenum,int coord,
       FILE *fp);
*/
       /* Vrne koordinato coord vrednosti polja z imenom fieldname po inkrementu
       s stevilko incnum v vozlu s stevilko nodnum. Podatke najde v datoteki fp,
       ze najdene podatki pa so vpisani v sistemu oi1. */








/* FUNKCIJE ZA MANIPULACIJO Z IZHODNO DATOTEKO DIREKTNE ANALIZE: */


void instintfcuserfunc(ssyst system);
     /* Na sistem za simbolno racunanje instalira funkcije za ekstrakcijo
     podatkov iz izhodne datoteke programa za direktne analize. */

void setintfcoutfile(FILE *outfile);
     /* Postavi izhodno datoteko direktne analize, iz katere se jemlejo podatki.
     To datoteko uporabljajo funkcije usernoddisp, userlocnoddisp, usernodreac,
     userlocnodreac, ... */

void clearintfcoutinfo(void);
     /* Funkcija zbrise celoten sistem podatkov oi o izhodni datoteki direktne
     analize. oi se postavi na NULL. Ta kazalec na sistem podatkov uporabljajo
     funkcije usernoddisp, userlocnoddisp, usernodreac, userlocnodreac, ... */

void setintfcoutinfo(void *ptr);
     /* Funkcija postavi kazalec na sistem podatkov oi o izhodni datoteki
     direktne analize (ta sistem uporabljajo funkcije usernoddisp, userlocnoddisp,
     usernodreac, userlocnodreac, ... ) na ptr. V resnici je funkcija namenjena
     za postavljanje tega kazalca na NULL. */

void setintfcincstr(char *str);
    /* Postavi niz incstr na niz str (str se najprej skopira v incstraux, nato
    pa se postavi incstr na incstraux). incstr je niz, ki v izhodni datoteki
    direktne analize oznacuje zacetek novega inkrementa.
    $A Igor feb98; */







/* FUNKCIJE ZA MANIPULACIJO Z VHODNO DATOTEKO DIREKTNE ANALIZE: */


int intfcgetoutdig(void);
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu intfc.c.
    $A Igor mar99; */

int intfcgetoutchar(void);
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu intfc.c.
    $A Igor mar99; */

void intfcsetoutdig(int num);
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu intfc.c.
    $A Igor mar99; */

void intfcsetoutchar(int num);
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu intfc.c.
    $A Igor mar99; */



int findinputparam(FILE *fp,stack stfileplace,stack stlength,stack stparamnum);
                  /* V datoteki fp, ki mora biti vhodna datoteka za analizo,
                  najde vsa mesta, kjer so zapisani tisti vhodni parametri, ki
                  jih spreminjamo. V datoteki morajo biti ta mesta predhodno
                  oznacena z oklepajem tipa
                    { $$INV {p1:s1} {p2:s2} {p3:s3} ....  END }
                  2. stevila (s) povedo, s katerim parametrom inverzne analize
                  se mora povezati doticni podatek v datoteki. 1. stevila (p)
                  pa povedo, kje se doticni podatek najde, konkretno ta stevila
                  povedo, katero stevilo po vrsti od oznacevalnega oklepaja
                  naprej predstavlja nas doticni podatek.
                    Funkcija v v ustrezna mesta na skladih zapise potrebne
                  podatke, in sicer v paramnum stevilko parametra, v fileplace
                  mesto v datoteki (steti se zacne z 1), kjer se doticni podatek
                  nahaja, v length pa stevilo bytov, ki jih je treba zapisati
                  pri prepisovanju tega podatka. To je pomembno zato, da se pri
                  prepisovanju podatka ne bi pisalo na mesta, ki pripadajo ze
                  drugim podatkom, ter da se lahko preprecijo napake, ki bi
                  nastale, ko bi pri naslednjem pisanju niz, ki predstavlja
                  novo vrednost doloceneka podatka, bil krajsi kot pri
                  predhodnem ter bi zato pri prepisanju podatka ostali
                  nepravilni znaki. Dolzina se vzame tako, da se od konca niza,
                  ki predstavlja vrednost doticnega podatka, k dolzini stejejo
                  se vsi presledki razen zadnjega do naslednjega podatka.
                    PRIMER: Ce so v vhodni datoteki za analizo naslednje vrstice
                  {$$INV {2:4} {3:1} {4:1} {5:2} END}
                  LOCAL DOF 1
                  12 14 16 17 18 19 20 21
                  , bo vrednost 12 pripadala 4. parametru (in se skupaj z njim
                  spreminjala), vrednosti 14 in 16 1. parametru ter vrednost 18
                  2. parametru.
                    POZOR!
                  Vsi skladi morajo kazati na ze alociran spominski preostor!
                  Oznacevalni niz $$INV se mora drzati skupaj!
                  */

void setinputparam(FILE *fp,struct _vector param,stack stfileplace,
                  stack stlength,stack stparamnum);
                  /* V datoteki fp, ki mora biti vhodna datoteka za analizo,
                  nastavi tiste vhodne parametre, ki se varirajo, na vrednosti,
                  ki so zapisane v vektorju param. v skladih stfileplace,
                  stlength in stparamnum je za vsak podatek v datoteki, ki ga je
                  treba spremeniti, zapisano, kje v datoteki je njegov zacetek,
                  kako dolg je in kateremu parametru po vrsti iz vektorja param
                  pripada.
                  */




void setintfcinfile(FILE *fp);
     /* Postavi vhodno datoteko direktne analize */

void setintfcstacks(void *fileplace,void *length,void *paramnum);
     /* Sklade, ki vsebujejo podatke o parametrih direktne analize v vhodni
     datoteki za direktno analizo, postavi na vrednosti, ki so navedene kot
     argumenti. V resnici je funkcija namenjena temu, da te sklade postavi na
     NULL. */

void clearintfcstacks(void);
     /* Funkcija zbrise vse sklade, ki vsebujejo podatke o parametrih direktne
     analize v vhodni datoteki za direktno analizo, in jih postavi na NULL.
     Zbrise tudi vse podatke, ki so nalozeni na te sklade. */

int intfcfindinputparam(void);
           /* V Ustrezne sklade zapise pozicije in dolzine parametrov, pri cemer
           uporablja funkcijo findinputparam(...). Datoteka, ki jo uporablja ta
           funkcija, je fin. */

void intfcsetinputparam(struct _vector param);
            /* V datoteki fin postavi vhodne parametre za inverzno znalizo na
            vrednosti, ki so v vektorju param. Pri tem uporablja funkcijo
            setinputparam(...). */

void intfccheckincfield(char ch);
     /* Postavi spremenljivko checkincfield, ki je notranja spremenljivka
     vmesnika, na vrednost, ki jo ima ch. */








