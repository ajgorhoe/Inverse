

#ifdef CFSQP
void setcfsqpout(FILE *fp);
  /* Postavi datoteko, na katero se bodo izpisovali izpisi funkcije cfsqp.
  $A Igor feb99; */


#endif


void minsimp(matrix simp, vector y, vector centre,
             double tol, int *it, int maxit, 
             double func(vector x), int connection(int), FILE *fp);
     /* Poisce minimum vektorske funkcije funk s simpleksno metodo.
        simp je zacetni priblizek (matrika, katere vrstice so 
        ogljisca simpleksa v vecdimenzionalnem vektorskem  prostoru).
        y je tabela vrednosti funkcije v ustreznih ogljiscih simpleksa
        simp. tol je toleranca - najvecje dovoljeno razmerje med razliko 
        in vsoto najvecje in najmanjse vrednosti funkcije v ogljiscih 
        simpleksa. */

double minsimpshort1(double func(vector x),vector start,vector step,double tol,
int maxit);
    /* Poenostavljena funkcja za minimizacijo funkcije func po simpleksni
    metodi. Start je vektor zacetnih priblizkov, step je korak, po katerem
    se tvorijo drugi zacetni priblizki, tol je toleranca, maxit pa je maks.
    st. iteracij. Po izvedbi optimizacije se v vektor start zapisejo komponente
    srediscnega vektorja koncnega simpleksa, v step p afunkcijske vrednosti.
    Funkcija vrne  povprecno vrednost namenske funkcije func v ogliscih.
    $A Igor feb00; */

double minsimpshort0(double func(vector x),vector start,double step,double tol,
                     int maxit);
    /* Podobno kot minsimpshort1, le da je korak podan s skalarjem step,
    vektorski korak pa ima vse komponente enake step. V start se zapisejo
    komponente sredisca koncnegs simpleksa, funkcija pa vrne povprecno vrednost
    namenske funkcije v ogliscih.
    $A Igor feb00; */





void minrec2d(vector pmin, double *fmin, vector h0, double tol, 
              int *it, int maxit,
              double func(vector), int connection(int), FILE *fp);
     /* Najde minimum funkcije dveh spremenljivk func. pmin je zacetni
        priblizek, fmin pa vrednost funkcije v pmin, ki mora biti ob klicu
        funkcije ze izracunana. h0 je vektor zacetnih korakov za objemanje
        minimuma, tol je relativna toleranca, it stevilo iteracij, maxit pa
        najvecje dovoljeno stevilo iteracij.
     */






void powellinitdir(vector pointmin, double *fmin, matrix mdir,
            double tol, int *it, int maxit,
            vector hbrak, double *tolbrent, int maxitbrent,
            double func(vector x), int connection(int), FILE *fp);




void powell(vector pointmin, double *fmin, matrix mdir,
            double tol, int *it, int maxit,
            vector hbrak, double *tolbrent, int maxitbrent,
            double func(vector x), int connection(int), FILE *fp);
            /* Minimizira skalarno funkcijo vektorske spremenljivke func.
               pointmin je priblizek za minimum funkcije, fmin pa vrednost
               funkcije v pointmin. Na vhodu morata imeti obe spremenljivki
               ustrezne zacetne vrednosti. mdir je matrika, katere vrstice
               dolocajo smeri linijskih minimizacij. Dobro je, da so smeri
               na zacetku normirane. tol je relativna toleranca za razliko
               vrednosti funkcije v minimumu pred in po zadnji iteraciji.
               it je stevilo iteracij, maxit pa najvecje dovoljeno stevilo
               iteracij. hbrak je vektor zacetnih korakov v smereh minimizacij
               za funkcijo, ki objame minimum. tolbrent je vektor relativnih
               toleranc za linijske minimizacije v razlicnih smereh.
               func je funkcija, ki jo minimiziramo, connection je funkcija za
               zvezo z zunanjim okoljem, fp pa je izhodna datoteka. 
               Ta funkcija uporablja funkcijo v dani smeri linefunc in zato
               tudi zunanje spremenljivke basefunc, linestart in linedir, ki
               so s to funkcijo povezane. */




void powell1(vector pointmin, double *fmin, matrix mdir,
            double tol, int *it, int maxit,
            vector hbrak, double *tolbrent, int maxitbrent,
            double func(vector x), int connection(int), FILE *fp);
            /* Minimizira skalarno funkcijo vektorske spremenljivke func.
            Ta funkcija je ekvivalent funkcije powell, le da je narejena
            po vzorcu iz Numerical recipes.
            */


void ext_cfsqp(int nparam,int nf,int nfsr,int nineqn,int nineq,int neqn,
      int neq,int ncsrl,int ncsrn,int *mesh_pts,
      int mode,int iprint,int miter,int *inform,double bigbnd,
      double eps,double epseqn,double udelta,double *bl,double *bu,
      double *x,double *f,double *g,double *lambda,
      void (*obj)(int, int, double *, double *,void *),
      void (*constr)(int,int,double *,double *,void *),
      void (*gradob)(int,int,double *,double *, 
                     void (*)(int,int,double *,double *,void *),void *),
      void (*gradcn)(int,int,double *,double *, 
                     void (*)(int,int,double *,double *,void *),void *),
      void *cd);
    /* Algoritem CFSQP (Feasible sequential quadratic programming) */

void 	grobfd(int,int,double *,double *,void (*)(int,int,
	       double *,double *,void *),void *);
	       
void 	grcnfd(int,int,double *,double *,void (*)(int,int,
	       double *,double *,void *),void *);

void setcfsqpout(FILE *fp);
  /* Postavi datoteko, na katero se bodo izpisovali izpisi funkcije cfsqp.
  $A Igor feb99; */








































