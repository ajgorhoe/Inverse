
/* Ensure at most one inclusion: */
#ifndef INCLUDED_sg_ploto
#define INCLUDED_sg_ploto


        /***********************************/
        /*                                 */
        /*   PLOTTING OF GRAPHIC OBJECTS   */
        /*                                 */
        /***********************************/



#ifndef INCLUDED_sg_obj
 #include <sg_obj.h>
#endif



               /*****************************************/
               /*   CONVERSION TO WINDOW CO-ORDINATES   */
               /*****************************************/


/* Function that calculates window coordinates from the space coordinates of a
point: */
extern void (*gpwindowcoord) (coord3d,coord3d);


               /*********************************/
               /* TRANSFORMS OF GRAPHIC OPJECTS */
               /*********************************/


void gotransfgroup(gogroup gg);
    /* Transforms the whole graphic object gg (transforms all primitives loaded
    on gg->primitives, gg->extraprimitives and on the corresponding stacks of
    sub-trees of gg. gotransfprimitive() is used for the transformation of
    primitives.
    $A Igor <== sep03; */

void gotransfstack(stack st);
    /* Transforms all graphic primitives that are loaded to st by the function
    gotransfprimitive(). It also transforms primitives from the stacks
    (...)->before and (...)->after of these primitives.
    $A Igor <== sep03; */

void gosettransfsimp(double fi, double theta);
    /* Sets parameters for the rotation of graphic primitives to fi and
    theta. transfcoordsimp() becomes the function for transformation of
    co-ordinates , while baswindowcoord() becomes the function for conversion
    to window co-ordinates.
    $A Igor <== sep03; */

void gosettransfsimpscale(double fi, double theta);
    /* Sets the parameters for the rotation of graphic objects to fi and
    theta. Sets function for transformation of co-ordinates to
    transfcoordsimpscale() and function for conversion to window co-ordinates
    to baswindowcoord().
    $A Igor <== sep03; */

void gosettransfeyesimp(double fi, double theta);
    /* Sets the parameters for rotation of graphic objects to fi and theta.
    transfcoordsimp() becomes the function for transformation of co-ordinates
    and eyewindowcoord() for the conversion to window co-ordinates.
    $A Igor <== sep03; */

void gosettransfeyesimpscale(double fi, double theta);
    /* Sets parameters for rotation of graphic objects to fi and theta.
    Function for transformation of co-ordinates is set to 
    transfcoordsimpscale() whilw function for conversion to window co-ordinates
    is set to eyewindowcoord()
    $A Igor <== sep03; */

void gosettransfscalingfactors(double xfac,double yfac,double zfac);
    /* Sets the factors for scaling of co-ordinates after the transform
    by the function gosettransfsimpscale().
    $A Igor <== sep03; */

void gosetdistancefactor(double factor);
    /* SEts the ratio between the distance of the observer from the center of
    the plotted 3D area and the diagonal of this area.
    $A Igor <== sep03; */

void preparegraph3dbas(frame3d limits,frame3d frame);
    /* Prepares parameters for plotting the graph. Parameters that affect
    mapping from spatial to window co-ordinates on the screen are set according
    to the variables limits (geometric borders of a 3D object) and frame
    (window co-ordinates or limits within which everything within limits
    should be plotted). It also sets functions that are used for mapping of
    co-ordinates.
      Remark:
      frame can be NULL, in this case the default frame is taken ([0,1]x[0,1]).
    $A Igor <== sep03; */




               /*************************/
               /* LIGHTING OF 3D GRAPHS */
               /*************************/


extern char sg_dolighting; /* if 0 then lighting does not take effect */


void godolighting(char dl);
    /* If dl is 0 then lighting will not be accounted for when drawing graphic
    objects, otherwise lighting will take effect.
    $A Igor <== sep09; */

double gogetlightfactor(void);
    /* Returns the factor by which intensities of colors are multiplied after
    calculation of lighting effects.
    $A Igor <== sep09; */

void gosetlightfactor(double factor);
    /* Sets the factor by which the intensities of object colors are multiplied
    after all lighting effects are calculated. The factor is stored to a local
    variable lightfactor.
    $A Igor <== sep09; */

double goupdatelightfactor(double factor);
    /* Sets the factor by which the intensities of object colors are multiplied
    after all lighting effects are calculated. First this factor is calculated
    in such a way that the largest component of the sum of intensities of all
    lights is 1, then this factor is multiplied by 'factor' that is the
    argument of this function. The factor obtained in this way is stored to a
    local variable lightfactor.
    $A Igor <== sep09; */

void gosetdifuselight(double red,double green,double blue);
    /* Sets the intensities of components of the diffuse light. Values are
    stored in a local variable intdifuselight(). The components can be more
    than 1.
    $A Igor <== sep09; */

void gosetfarlight(double red,double green,double blue,
                   double xdir,double ydir,double zdir);
    /* Adds an infinitely distant illuminant that lights with the intensity
    (red,green,blue) and whose direction (towards the light source) is
    (xdir,ydir,zdir). Intensity is pushed as an object of type truecolor
    on the stack intfarlights, directions are pusher as an object of type
    coord3d on the stack dirfarlights.
    $A Igor <== sep09; */

double gogetpowfarlighting(void);
    /* Returns the power to which the cosine of the incident angle of light is
    raised when calculating the brightness of the lit object. (for surfaces
    this is the cosine of the angle between the normal and the reverse
    direction of the ray while for lines this is the absolute of the sine
    between the direction angle of the line and the incident direction of the
    ray.
    $A Igor <== sep09; */

void gosetpowfarlighting(double pw);
    /* Sets the power to which the cosine of the incident angle of light
    is raised when calculating brightnes of the lit object.
    $A Igor <== sep09; */

void calclightintensity(stack coord,truecolor original,truecolor calc);
    /* Calculates the intensity of the light reflected from an object with
    respect to the arrangement of all defined light sources. coord must be a
    stack on which there are co-ordinates of the graphic object (primitive)
    and original must contain the natural color of the object. The calculated
    reflected color is put into *calc.
    $A Igor <== sep09; */





           /******************************************/
           /*   FUNCTIONS FOR PLOTTING 3D OBJECTS:   */
           /******************************************/



void sg_godrawprimitive(goprimitive gp);
    /* Plots the primitive gp with the currently active plotting interface.
    $A Igor sep03; */




void gosortstack(stack st);
    /* Sorts stack with the graphic primitives where the relation "is greater"
    is defined by a local function gpcompare().
    $A Igor <== sep03; */























#endif /* not defined INCLUDED_sg_ploto */


