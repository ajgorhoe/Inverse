
/* The following code enables inclusion of this header withoutthe need for
taking care explicitly that it is included only once: */
#ifndef INCLUDED_gro
#define INCLUDED_gro



/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_sg_obj
  #include <sg_obj.h>
#endif





/*

           VRSTE GRAFICNIH PRIMITIVOV

identifikac. znak:         vrsta:
  i1  |  i2  |  i3  |     opis
------+------+------+----------------------
  t   |  \0  |  \0  |  navaden tekst
  l   |  \0  |  \0  |  navadna crta
  3   |  \0  |  \0  |  trikotnik iz crt
  3   |  f   |  \0  |  zapolnjem trikotnik
  3   |  b   |  \0  |  zapolnjem obrobljen trikotnik
  4   |  \0  |  \0  |  stirikotnik iz crt
  4   |  f   |  \0  |  zapolnjem stirikotnik
  4   |  b   |  \0  |  zapolnjem obrobljen stirikotnik

*/


goprimitive newgoprimitive(void);
            /* Alocira prostor za strukturo tipa _goprimitive in vrne kazalec
            nanj. */

void dispgoprimitive(goprimitive *p);
     /* Sprosti prostor za **p in postavi *p na NULL. */

gogroup newgogroup(void);
        /* Alocira prostor za nov objekt tipa _gogroup in vrne kazalec nanj.
        Prostor za sklade groups, primitives in extraprimitives se ne alocira. */

gogroup newgogroupst(int ngroups,int nprimitives,int nextraprimitives);
    /* Alocira prostor za nov objekt tipa _gogroup in vrne kazalec nanj.
    alocira se tudi prostor za sklade groups, primitives in extraprimitives,
    polja ex ustreznih skladov pa se postavijo na ngroups, nprimitives in
    nextraprimitives. Ce je katero od teh stevil manj od 1, se za ustrezni
    sklad ne alocira prostor. */

void dispgogroup(gogroup *p);
     /* Sprosti spomin, ki ka zaseda **p in postavi *p na NULL. Pred tem sprosti
     prostor, ki ga zasedajo strukture, na katere kazejo kazalci na **p. */

void dispgogrouptree(gogroup *p);
    /* Rekurzivno sprosti drevesno strukturo graficnih objektov s korenom *p
    ter postavi *p na NULL.
    $A Damjan mar97; */


  /* MEJE GRAFICNIH OBJEKTOV: */

void printframe3d(frame3d frame);
    /* Izpise vrednosti mej po x, y in z za frame.
    $A Igor avg01; */

void calcgogroupframe0(gogroup gg,frame3d frame);
    /* Izracuna skupne meje koordinat graficnih objektov skupine gg in skupin,
    za katere so ze izracunane meje na frame, ter rezultate zapise v frame.
    Za izracun mej od zacetka je treba uporabiti funkcijo calcgogroupframe().
    $A Igor avg01; */

void calcgogroupframe(gogroup gg,frame3d frame);
    /* Izracuna meje koordinat graficnih objektov skupine gg in jih zapise na
    frame. Najprej postavi zgornje meje na negativna stevila z veliko absolutno
    vrednostjo, spodnje pa na velika pozitivna stevila in nato uporabi funkcijo
    calcgogroupframe0 za dejanski izracun.
    $A Igor avg01; */



               /**************************************/
               /*   PRETVORBA V OKENSKE KOORDINATE   */
               /**************************************/


extern char sg_drawtransf;  /* If 0 then untransformed objects are plotted. */


/* Function that calculates window coordinates from the space coordinates of a
point: */
extern void (*gpwindowcoord) (coord3d,coord3d);




           /****************************************************/
           /*   FUNKCIJE ZA IZRIS TRIDIMENZIONALNIH OBJEKTOV   */
           /****************************************************/



extern char sg_dolighting; /* if different than 0 then lighting takes effect */


void godolighting(char dl);
     /* Ce je dl razlicen od 0, potem se bo nadalje pri risanju graficnih
     objektov upostevalo osvetljevanje, drugace pa ne. */

double gogetlightfactor(void);
       /* Vrne faktor, s katerim se pri osvetljevanju na koncu pomnozijo
       intenzitete barv */

void gosetlightfactor(double factor);
     /* Postavi lokalno spremenljivko lightfactor (faktor, s katerim se mnozijo
     intenzitete pri osvetljevanju) na vrednost factor) */

double goupdatelightfactor(double factor);
       /* Nastavi lokalno spremenljivko lightfactor, s katero se mnozijo
       intenzitete pri osvetljevanju graf. objektov. Najprej se izracuna
       lightvactor tako, da je najvecja komponenta vsote osnovnih intenzitet
       vseh svetil enaka 1, nato pa se lightfactor pomnozi z argumentom factor. */

void gosetdifuselight(double red,double green,double blue);
     /* Nastavi jakosti komponent difuzne svetlobe (lokalna spremenljivka
     intdifuselight). */

void gosetfarlight(double red,double green,double blue,
                   double xdir,double ydir,double zdir);
     /* Svetilom doda neskoncno oddaljeno svetilo, ki sveti z intenzitetami
     komponent red green in blue ter ima komponente smeri proti svetilu xdir,
     ydir in zdir. Intenzitete da v obliki kazalca na _truecolor na sklad
     intfarlights, smeri pa v obliki kazalca na _coord3d na sklad dirfarlights. */

double gogetpowfarlighting(void);
       /* Vrne potenco, na katero se da kosinus vpadnega kota svetlobe pri
       izracunu osvetljenosti gravicnega objekta. (pri ploskvah je to kosinus
       kota med normalo in nasprotno smerjo zarka, pri crtah pa absolutna
       vrednost sinusa kota med smernim vektorjem crte in smerjo zarka. */

void gosetpowfarlighting(double pw);
       /* Nastavi potenco, na katero se da kosinus vpadnega kota svetlobe pri
       izracunu osvetljenosti gravicnega objekta. (pri ploskvah je to kosinus
       kota med normalo in nasprotno smerjo zarka, pri crtah pa absolutna
       vrednost sinusa kota med smernim vektorjem crte in smerjo zarka. */

void calclightintensity(stack coord,truecolor original,truecolor calc);
       /* Izracuna barvo (intenziteto komponent) odbite svetlobe glede na
       razpored svetlobnih virov v prostoru. Coord je sklad, na katerem so
       v obliki tipa coord3d trenutne koordinate kraficnega objekta, original
       je lastna barva objekta, v *calc pa se zapisejo rezultati. */


/* RISANJE RAZLICNIH VRST GRAFICNIH PRIMITIVOV */



void godrawprimitive(goprimitive gp);
     /* Izrise graficni primitiv gp. */

void godrawstack(stack st);
     /* Izrise sklad, na katerega so nalozeni graficni primitivi. */

void godrawstackscreen(stack st);
    /* Izrise sklad, na katerega so nalozeni graficni primetivi. Deluje
    podobno kot godrawstack(), le da je funkcija namenjena le za risanje
    na zaslon in ne tudi v datoteke, poleg tega pa vedno poskusa najti nacin
    za izris - ce v sistem niso povezane graficne knjiznice, izris izvede
    z izrisom v Tcl-ovo datoteko in interpretacijo z lupino wish.
    $A Igor maj01; */

void gosetdrawtransf(char dt);
    /* Funkcija nastavi vrednost lokalne spremenljivke drawtransf, ki
    kontrolira, ali se izrisejo graficni objekti v originalnih koordinatah (ce
    je vrednost spremenljivke 0) ali transformiranih (ce je razlicna od 0). */

void goloadtostack(gogroup gg,stack st);
     /* Graficni objekt, ki ga predstavlja gg, nalozi na sklad st (na sklad
     nalozi vse primidive, ki so na skladu gg->primitives in na vseh skladih
     ...->primitives poddreves skupine gg. */

void gosortstack(stack st);
     /* Uredi elemente skladast, na katerem so graficni primitivi, po velikosti.
     Kriterij za relacijo "je vecji" je funkcija gpcompare. */

void preparegraph3dbas(frame3d limits,frame3d frame);
     /* Pripravi parametre sistem za izris grfa. Glede na spremenljivki limits
     (geometrijske meje 3 dimenzionlnega objekta) in frame (okenske koordinate,
     znotraj katerih naj se izrise vse, kar je znotraj meja limits) se nastavijo
     parametri, ki vplivajo na mapiranje z geometrijskih v okenske koordinate na
     zaslonu. Nastavi tudi funkcije, ki se uporabljajo za izris primitivov,
     mapiranje koordinat, sortiranje skladov primitivov ... */



     /***************************************************/
     /*     FUNKCIJE ZA IZRIS V RAZLICNIH FORMATIH:     */
     /***************************************************/



void gopsfdrawstack(FILE *fp,stack st);
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko fp v formatu PostScript. 
     $A Igor apr97; */

void gopsfiledrawstack(char *name,stack st);
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko z imenom name v formatu PostScript. Ce datoteka ze obstaja,
     se prepise. 
     $A Igor apr97; */

void gotclfdrawstack(FILE *fp,stack st);
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko fp v formatu Tcl. 
     $A Igor apr97; */

void gotclfiledrawstack(char *name,stack st);
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko z imenom name v formatu Tcl. Ce datoteka ze obstaja,
     se prepise. 
     $A Igor apr97; */

void gotclscreendrawstack(stack st,int width,int height);
    /* Izrise objekte na skladu st s pomocjo Tcl-a in interpreterja wish.
    width in height sta sirina in visina okna, v katerem se grafika izrise;
    ce sta 0, se vzameta ze nastavljeni meri.
    $A Igor maj01; */

void gotclscreendrawstackautosize(stack st);
    /* Izrise objekte na skladu st s pomocjo Tcl-a in interpreterja wish.
    Velikost okna nastavi avtomatsko glede na trenutno sirino in visino okna
    v graficnem sistemu.
    $A Igor maj01; */

void godxffdrawstack(FILE *fp,stack st);
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko fp v formatu DXF. 
     $A Igor apr97; */

void godxffiledrawstack(char *name,stack st);
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko z imenom name v formatu DXF. Ce datoteka ze obstaja,
     se prepise. 
     $A Igor apr97; */




               /*************************************/
               /* TRANSFORMACIJE GRAFICNIH OBJEKTOV */
               /*************************************/




void gotransfgroup(gogroup gg);
     /* Pretransformira cel graficni objekt gg tako, da pretransformira vse
     graficne primitive, nalozene na skladih gg->primitives, gg->extraprimitives
     in ustreznih skladih poddreves gg. */

void gotransfstack(stack st);
    /* Pretransformira vse graficne primitive, ki so nalozeni na sklad st, s
    funkcijo gotransfprimitive(). Transformira tudi primitive s skladov
    (...)->before in (...)->after primitivov.
    $A Igor <== feb97 */

void gosettransfsimp(double fi, double theta);
     /* Nastavi parametre za rotacijo graficnih objektov za azimut fi in polarni
     kot theta. */

void gosettransfsimpscale(double fi, double theta);
     /* Nastavi parametre za rotacijo graficnih objektov za azimut fi in
     polarni  kot theta. Funkcija za transformacijo koordinat postane
     transfcoordsimpscale(). */

void gosettransfeyesimp(double fi, double theta);
     /* Nastavi parametre za rotacijo graficnih objektov za azimut fi in
     polarni kot theta. Funkcija za transformacijo koordinat postane
     transfcoordsimp(), funkcija za pretvorbo v okenske koordinate pa
     eyewindowcoord (). */

void gosettransfeyesimpscale(double fi, double theta);
     /* Nastavi parametre za rotacijo graficnih objektov za azimut fi in
     polarni  kot theta. Funkcija za transformacijo koordinat postane
     transfcoordsimpscale(), funkcija za pretvorbo v okenske koordinate pa
     eyewindowcoord(). */

void gosettransfscalingfactors(double xfac,double yfac,double zfac);
    /* Nastavi faktorje skaliranja koordinat pri transformaciji s funkcijo
    gosettransfsimpscale(). */

void gosetdistancefactor(double factor);
    /* Nastavi razmerje med razdaljo opazovalca od sredisca 3D obmocja, ki se
    rise, in diagonalo tega obmocja. */





               /***********************************/
               /* KONSTRUKCIJA GRAFICNIH OBJEKTOV */
               /***********************************/



void goupdatelimits(coord3d p,gogroup gg);
     /* Ce je potrebno, razsiri meje na gg (gg->min in gg->max) tako, da tudi
     tocka s koordinatamo *p pade v notranjost teh mej.
     $A Igor <== avg01; */

void goupdatetransflimits(coord3d p,gogroup gg);
     /* Ce je potrebno, razsiri meje v transformiranih koordinatah na gg
     (gg->mintransf in gg->maxtransf) tako, da tudi tocka s koordinatamo *p
     pade v notranjost teh mej.
     $A Igor apr97; */

void goupdatelimitsgrouptree(gogroup gg);
    /* Ce je potrebno, razsiri meje v transformiranih koordinatah na gg
    (gg->mintransf in gg->maxtransf) tako, da tudi tocka s koordinatamo *p
    pade v notranjost teh mej.
    $A Igor apr97; */

goprimitive goaddline(coord3d p1,coord3d p2,stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja crto od tocke s koordinatami p1 do
    tocke s koordinatami p2 na sklad st. Skupino primitiva postavi na grp. */

goprimitive goaddlinediv(coord3d p1,coord3d p2,stack st,gogroup grp,int num);
    /* Doda crto od tocke s koordinatami p1 do tocke s koordinatami p2,
    sestavljeno iz num manjsih crt - graficnih primitivov, na sklad st. Skupino
    primitivov postavi na grp. */

goprimitive goaddtriangle(coord3d p1,coord3d p2,coord3d p3,stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja trikotnik iz crt z oglisci p1, p2
    in p3 na sklad st. Skupino primitiva postavi na grp. */

goprimitive goaddfilltriangle(coord3d p1,coord3d p2,coord3d p3,stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja zapolnjen trikotnik z oglisci p1,
    p2 in p3 na sklad st. Skupino primitiva postavi na grp. */

goprimitive goaddbordtriangle(coord3d p1,coord3d p2,coord3d p3,stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja obrobljen zapolnjen trikotnik z
    oglisci p1, p2 in p3 na sklad st. Skupino primitiva postavi na grp. */

goprimitive goaddpartbordtriangle(coord3d p1,coord3d p2,coord3d p3,
            char b1,char b2, char b3,stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja delno obrobljen zapolnjen trikot-
    nik z oglisci p1, p2 in p3 na sklad st. Skupino primitiva postavi na grp.
    b1, b2 in b3 so razlicni od 0 oz. '\0', ce se naj ustrezni robovi izrisejo.
    Prepisejo se v niz znakov ...->props3, ce je vsaj eden od njih razlicen od
    0 (drugace ostane ...->props3 enak NULL). */

goprimitive goaddfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                           stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja stirikotnik iz crt z oglisci p1,
    p2, p3 in p4 na sklad st. Skupino primitiva postavi na grp. */

goprimitive goaddfillfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                           stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja zapolnjen stirikotnik z oglisci
    p1, p2, p3 in p4 na sklad st. Skupino primitiva postavi na grp. */

goprimitive goaddbordfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                           stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja obrobljen zapolnjen stirikotnik z
    oglisci p1, p2, p3 in p4 na sklad st. Skupino primitiva postavi na grp. */

goprimitive goaddpartbordfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                         char b1,char b2, char b3,char b4,stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja delno obrobljen zapolnjen stirikot-
    nik z oglisci p1, p2, p3 in p4 na sklad st. Skupino primitiva postavi na grp.
    b1, b2, b3 in b4 so razlicni od 0 oz. '\0', ce se naj ustrezni robovi izri-
    sejo. Prepisejo se v niz znakov ...->props3, ce je vsaj eden od njih razli-
    cen od 0 (drugace ostane ...->props3 enak NULL). */

goprimitive goaddmarker(coord3d p1,double size,int kind,stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja marker pri koordinatah p1 na
    sklad st. Skupino primitiva postavi na grp. size je velikost, kind pa vrsta
    markerja. */

goprimitive goaddarrow(coord3d p1,coord3d p2,double size,
                       double tgangle,int attr,
                       stack st,gogroup grp);
    /* Adds a graphic primitive that represents an arrow from the point p1 to
    the point p2, to the stack stck st. Gtoup of the containing primitive is
    set to grp. size must be the size of the head (either relative to the size
    of the graph or relative to the size of the arrow, dependent on attr),
    tgangle is the tangens of a half-angle between the head and the basic
    line, and attr must contain line attributes understood by sg_arrow().
    $A igor sep03; */

goprimitive goaddtext(char *str,coord3d p1,stack st,gogroup grp);
    /* Doda graficni primitiv, ki predstavlja niz str pri koordinatah p1 na
    sklad st. Skupino primitiva postavi na grp. */








#endif    /* (not defined) INCLUDED_grtypes */


