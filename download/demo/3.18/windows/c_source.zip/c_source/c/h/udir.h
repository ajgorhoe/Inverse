




/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_st
#include <st.h>
#endif


typedef struct{
        int day,month,year,hour,min,sec,msec;
        } Datetype;

typedef Datetype *datetype;


typedef struct{
        char *   str;     /* Niz, s katerim je dano ime predstavljeno v Unixu */
        char *   name;    /* Ime datoteke ali direktorija */
        char *   relpath; /* Pot do direktorija */
        char *   link;    /* Ime dat., na katero kaze ta link */
        char *   own;     /* Lastnik */
        char *   grp;     /* Skupina */
        char *   permit;  /* Dovoljenja */
        long *   length;  /* Dolzina */
        long *   nlinks;  /* Stevilo linkov */
        long *   dlength; /* Dolzina direktorija */
        long *   tdlength; /* Dolzina direktorija s poddirektoriji vred */
        long *   nf;      /* St. datotek v direktoriju */
        long *   tnf;     /* St. datotek v direktoriju s poddirektoriji vred */
        datetype date;    /* Datum */
        stack    cont;    /* Vsebina (poddirektoriji) */
        } Dirtype; /* Struktura za podatke o direktorijskih drevesih */

typedef Dirtype *dirtype;


typedef struct{
        char str,name,link,own,grp,permit,length,nlinks,date,cont;
        } Dirmask;  /* Maska za to, kateri podatki naj se shranejo ali izpisejo */

typedef Dirmask *dirmask;


typedef struct{
        char file,dir,link,unknown,rest;
        } Dirkindmask; /* Maska za vrsto datotek, ki naj se izpise */

typedef Dirkindmask *dirkindmask;



typedef struct{
        FILE *fp; /* Datoteka, v katero se zapisejo podatki */
        int spaces, /* Zacet. stevilo presledkov v izpisih */
            plusspaces, /* St. presledkov, ki se pristeje pri poddirektorijih */
            dlevel, /* Nivo, do katerega se gledajo poddirektoriji */
            llevel, /* Nivo, do katerega se gledajo podlinki */
            pdlevel, /* Nivo, do katerega se izpisejo poddirektoriji */
            pllevel; /* Nivo, do katerega se izpisejo podlinki */
        char spacechar, /* Znak, ki se izpise namesto presledkov */
             inslines, /* Ce ni 0, so direktoriji loceni s praznimi vrsticami */
             printdirdata, /* Ce ni 0, se izpisujejo splos. pod. o direktorijih */
             printhead; /* Ce ni 0, se izpise koncna suma za direktorije */
        dirmask dm; /* Pove, kaj naj se pri posam. dat. shrani */
        dirmask pdm; /* Pove, kaj naj se pri posam. dat. izpise */
        dirkindmask dkm; /* Pove, katere vrste datotek naj se izpisejo */
        } Dircom; /* Ukazna struktura za visje funkcije za podatke o direktorijih */

typedef Dircom* dircom;





dirtype newdirtype(void);
        /* Vrne objekt tipa dirtype, za katerega rezervira prostor v spominu. */

void dispdirtype(dirtype *d);
     /* Sprosti spomin, ki ga zaseda d. Pred tem sprosti tudi spomin, ki ga
     zasedajo komponente *d. */

void dispdirtree(dirtype *d);
     /* Zbrise celotno drevo *d, ki predstavlja direktorijsko strukturo
     (rekurzivno se brisejo vsi poddirektoriji). Po brisanju postavi *d na
     NULL. */

dircom newdircom(void);
       /* Vrne objekt tipa dircom, za katerega rezervira prostor. Rezervira
       tudi prostor za (...)->dm in (...)->dkm. */

void dispdircom(dircom *dc);
     /* Zbrise objekt tipa dircom, na katerega kaze *dc. Ta kazalec potem
     postavi na NULL. Zbrise tudi (*dc)->dm in (*dc)->dkm. */

dircom copydircom(dircom dc);
       /* Vrne kopijo objekta tipa dirkom. Skopira tudi dc->dm in dc->dkm. */

void consistentdircom(dircom dc);
     /* Zagotovi notranjo konsistenco ukazne strukture za delo z direktoriji
     dc (Zagotovi na primer, da zahteve v dc->pdm niso vecje kot zahteve v
     dc->dm; to bi namrez privedlo do neuresnicljivih zahtev, saj se ne da
     uresniciti zahteva za izpis necesa, kar ni bilo shranjeno). */

stack dirdatatree(char *path,dirmask dm,int dlevel,int llevel);
      /* Vrne sklad, na katerem so nalozeni podatki o direktoiju oziroma
      datoteki z imenom path. Ce gre za datoteko, nalozi na sklad le en podatek
      tipa dirtype, ce pa gre za direktorij, nalozi na sklad po en podatek te
      vrste za vsak direktorij, link, datoteko itd. v tem direktoriju.
        Pri direktorijih in linkih lahko funkcija (odvisno od vrednosti dlevel
      oz. llevel) rekurzivno doda podatke o njihovih poddirektorijih in linkih.
        Kateri podatki se shranejo, je odvisno od vrednosti polj strukture *dm.
      dlevel pove, za koliko poddirektorijev v globino se shranjujejo podatki,
      llevel pa pove, do kaksne globine se gre pri linkih (globina se steje
      neodvisno za podlinke in poddirektorije. */

void fprintdirtree(FILE *fp,stack st,int spaces,int plusspaces,char spacechar,
     dirmask dm, dirkindmask dkm,int dlevel,int llevel,char inslines,
     char printdirdata,char printhead);
     /* Naredi podobno kot fprintdirtree0, le da v primeru, ko so na skladu st
     podatki o direktoriju ali linku, na koncu pregledno izpise podatke o skupni
     dolzini in stevilu datotek, ce je printhead razlicen od 0 (Funkcija
     fprintdirtree0 maredi to le za podnivoje). */

int flistdirectory(FILE *fp,char *path,dircom dc);
    /* Zapise vsebino direktorija path (ali podatke o datoteki, ce je path ime
    datoteke) glede na vrednosti polj *dc. Ce je fp razlicna od NULL, se podatki
    zapisejo v datoteko fp (dc->fp se pri tem ne spremeni), ce pa je fp enaka
    NULL, se podatki zapisejo v datoteko dc->fp. */

stack stringparamlistsimp(char *paramstr);
      /* Vrne sklad, na katerega nalozi parametre (v obliki nizov), ki jih
      izlusci iz niza paramstr. Kot locila med posameznimi parametri uposteva
      znake ' ', '\n' in '\r'. */

int setdiroption(dircom dc,char *opt);
    /* V ukazni strukturi za zajemanje in izpis podatkov o direktorijih in
    datotekah dc nastavi nastavitev, ki jo veleva niz opt. Dogovori so
    naslednji:
      Opcije, ki imajo dve moznosti, se nastavijo z nizom, ki se zacne s '+' za
    nastavitev oziroma z '-' za umaknitev opcije. Preostali del niza je
    dogovorjeno ime doticne opcije in sicer:
        "inslines" - vrivanje praznih vrstic med poddirektoriji
        "printdirdata" - izpis skup. dolzine in st. datotek pri direktorijih
        "printhead" - izpis splosnih podatkov o direktoriju (osnov. nivo)
        "ms" - sharanitev niza, ki ga generiria ukaz ll
        "mn" - shranitev imena
        "mlk" - shranitev linka
        "mo" - shranitev lastnika
        "mg" - shranitev skupine
        "mp" - shranitev dovoljenj
        "ml" - shranitev dolzine dat.
        "mnlk" - shranitev stevila linkov
        "md" - shranitev datuma
        "mc" - shranitev vsebine poddirektorijev
        "ps" - sharanitev niza, ki ga generiria ukaz ll
        "pn" - izpis imena
        "plk" - izpis linka
        "po" - izpis lastnika
        "pg" - izpis skupine
        "pp" - izpis dovoljenj
        "pl" - izpis dolzine dat.
        "pnlk" - izpis stevila linkov
        "pd" - izpis datuma
        "pc" - izpis vsebine poddirektorijev
        "kmf" - izpis datotek
        "kmd" - izpis direktorijev
        "kml" - izpis linkov
        "kmu" - izpis datotek neznane vrste
        "kmr" - izpis ostalih vrst datotek
      Opcije, ki imajo stevilcno ali znakovno vrednost, so sestavljeni iz niza
    za identifikacijo opcije in iz znaka oziroma stevilcne vrednosti.
    Identifikacijski nizi so:
        "sc" - znak, ki se uporablja kot presledek pri zamikanju
        "s+" - stevilo dodatnih presledkov pri zamikih
        "s" - zacetno stevilo presledkov
        "dl" - nivo, do katerega se shranejo podatki o poddirektorijih
        "ll" - nivo, do katerega se shranejo podatki o podlinkih
        "pdl" - nivo, do katerega se izpisejo podatki o poddirektorijih
        "pll" - nivo, do katerega se izpisejo podatki o podlinkih
    */

void fcomlistdir(FILE *fp,char *command,dircom dc,stack *dir);
     /* V datoteko fp izpise podatke o datoteki oz. direktoriju - glede na
     vrednosti spremenljivk command, dc in dir.
       1. del niza command je ime direktorija oz. datoteke, drugi del pa so
     lahko opcije, prepoznavne za funkcijo setdiroption(). Deli tega niza so
     lahko med seboj loceni z locili ' ', '\n' ali '\r'. Poleg tega obstaja
     se nekaj posebnih primerov za ta niz. Ce je 1. del niza ">", potem se ne
     iscejo novi podatki za datoteko oz. direktorij s tem imenom, temvec se
     vzamejo podatki, ki so ze spravljeni na skladu *dir, s tem da se upostevajo
     morebitne dodatne opcije v nadaljevanju niza commmand.
       podatki na skladu *dir se vsakic zbrisejo na zacetku funkcije, razen, ce
     je 1. del niza command enak ">". Po izpisu podatkov pa se podatki na *dir
     ne brisejo, tako da so dostopni za morebitno naslednjo izvrsitev te
     funkcije s 1. delom niza command enakim "<".
       Spremenljivka dc pove, na kaksen nacin naj se zajamejo in izpisejo
     podatki. Ce so v nizu command kaksne todatne opcije, se njihov efekt cuti
     le med izvajanjem te funkcije, po izvedbi pa ostane *dc nespremenjen. */

void dirsettings(dircom dc);
     /* Nastavitveukazne spremenljivke za zajem in izpis podatkov o direktorijih
     oz. datotekah prek terminala. */

void fprintdirsettings(FILE *fp,dircom dc);
     /* V datoteko fp zapise vse nastavitve za prikazovanje direktorijev iz dc
     in sicer v obliki, v kakrsni so posamezne nastavitve berljive za funkcijo
     setdiroption(). */

stack getdecomposeddirdata(char *path);
    /*  Vrne sklad, na katerem so skladi z dekompozicijami nizov s podatki
    o datotekah v direktoriju path, kot jih generira ustrezen sistemski ukaz.
    Za zajem sistemskih podatkov se uporabi funkcija getlinedirdata, za njihovo
    dekompozicijo pa funkcija decomposedirdata.
    Funkcija vedno vrne sklad, ki je razlicen od NULL in tudi skladi, ki so
    nanj nalozeni, so vsi razlicni od NULL (lahko pa so prazni).
    $A Igor okt99; */

stack getdirdatanames(char *path);
    /* Vrne sklad, na katerem so imena datotek iz nizov s podatki o datotekah
    v direktoriju path, kot jih generira ustrezen sistemski ukaz. Za zajem
    sistemskih podatkov se uporabi funkcija getlinedirdata, za njihovo
    dekompozicijo pa funkcija decomposedirdata.
    Funkcija vedno vrne sklad, ki je razlicen od NULL.
    $A Igor okt99; */

char *getpwdstring(void);
     /* Vrne niz, ki predstavlja tekoci direktorij, za UNIX. Vrnjeni niz je
     potrebno po uporabi brisati.
     $A Igor okt99; */






