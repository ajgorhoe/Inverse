

          /******************************/
          /*                            */
          /*  RANDOM NUMBER GENERATION  */
          /*                            */
          /******************************/


#ifndef INCLUDED_rand
#define INCLUDED_rand





     /* TYPE IDENTIFICATION NUMBERS: */

#ifdef HEADER_ID_rand
  #if HEADER_ID_rand!=25825
    #error Wrong header ID HEADER_ID_rand
  #endif
  #undef HEADER_ID_rand
#endif
#define HEADER_ID_rand 25825  /* def. of this header ID */


#define TYPE_twopartpotdata            HEADER_ID_optpt+1
#define TYPE_cloudpotstruct            HEADER_ID_optpt+2


/*
#define TYPE_randgengenun HEADER_ID_rand+1  /* union of generators */

#define TYPE_randgengen   HEADER_ID_rand+2  /* generic generator type */

  /* Random generator identity numbers (sub-type IDs): */

#define SUBTYPE_randgenexp   1  /* experimental generator */
#define SUBTYPE_randgenmt    2  /* Mersenne twister */

/* Just maximum pre-defined random generator ID */
#define SUBTYPE_randgenlast      SUBTYPE_randgenmt
/* Default generator: */
#define SUBTYPE_randgendefault  SUBTYPE_randgenmt  


  /* TYPE DEFINITIONS: */


  /* GENERIC GENERATOR: */

typedef struct _randgenfunc {
  void * (*newgen) (void);  /* creation of structure */
  void (*dispgen) (void **);  /* deletion of structure */
  /* deterministic initialization by seed: */
  unsigned long (*seed) (void *rg,unsigned long seed);
  /* non-deterministic initialization by time and seed: */
  unsigned long (*seedrandtime) (void *rg,unsigned long seed);
  /* time uncorrelated non-deterministic initialization: */
  unsigned long (*seedrandrand) (void *rg,unsigned long pert);
  /* random integer in a given range: */
  unsigned long (*randint) (void *rg,unsigned long max);
  /* random number on the interval [0,1]: */
  double (*rand) (void *rg);
};

  /* NOTE: all random generator structure types must first contain the
same fields as _randgengen below. */

typedef struct _randgengen {
  int type,   /* must be the first element for each rand. gen. structure */
      id,     /* identification number */
      gentype, /* precise type specification */
      init,   /* initialized */
      randinit,detinit,  /* randomly / deterministically inialized */
      threadlock;  /* thread lock */
  struct _randgenfunc func;
  char *name;
  void *data;  /* additional data - for random generator */
  void (*dispdata) (void **);  /* deallocation function for data */
  unsigned long 
      count,  /* number of generations */
      max,    /* maximal generated number (bit mask) */
      first,  /* first generated full unsigned long */
      last;   /* last generated full unsigned long */
        /* Above fields should be the same for all generators */
  int error,generror;   /* for passing error information, error is meant
      for basic generation (uniform) and generror for derived. */
  unsigned long rejected;  /* for passing information on number of rejected
           generations */
} *randgengen;


  /* EXPERIMENTAL GENERATOR: */

typedef struct _randgenexp {
  /* Field below should be the first member of all generator structures: */
  struct _randgengen bs;  /* general data (structure base) */
  /* Above field should be the same for all generators */
  unsigned long p1,p2,p3,p4;
} *randgenexp;




  /* MERSENNE TWISTER GENERATOR: */

#define PAR_rand_mt_N 624


typedef struct _randgenmt {
  /* Field below should be the first member of all generator structures: */
  struct _randgengen bs;  /* general data (structure base) */
  unsigned long  mt[PAR_rand_mt_N];
  int mti /* =N+1 */ ; 
  unsigned long mag01[2] /* ={0x0UL, MATRIX_A} */ ;
} *randgenmt;




  /* BASIC DATA HANDLING: */

/*
randgengen newrandgengen(void);
*/
    /* Creates a gneeric random generator data structure and returns its
    address.
    $A Igor mar05; */



          /************************************/
          /*                                  */
          /*  USER DEFINED RANDOM GENERATORS  */
          /*                                  */
          /************************************/

/*
  NOTE on how to define and install random generator: 
  First data structure representing the generator must be defined. The first
element of the structure must always be struct _randgengen (see e.g. definition
of the type struct _randgenmt), which is by convention named bs (from "base").
  Then define the function for creating random generator data (e.g. such as
newrandgenmt) and the rest of the functions. Create a new generator data
structure, put relevant information on it (e.g. assign dynamically allocated
descriptive string to (...)->bs.name and addresses of functions that perform 
generation to elements of (...)->bs.func). Register the random generator by
calling definerandgen() with the address of the created structure (which must
be casted to type randgengen). Store the returned value, which will be used
as the generator's ID to a static variable where the data creation function can
read it. The data creation functuon must assign this generator ID to the
element (...)->bs.gentype of the structure it creates.
  It is recommended that the function for creation of generator data structure
(e.g. newmyrandgen()) assigns addresses of functions for various operations
to elements of the structure (...)->bs.func. If this is not done then using
the new generator through generic functions is a bit slower, since these must
look at the definition structure for function addresses.
  Don't forget that the function for generation of generator data structure
must assign the generator ID to (...)->bs.gentype. If checking of this type is
peformed by the generator functions then the generator should not be installed
more than once.
*/


  /* FUNCTIONS FOR DEFINITION OF CUSTOM GENERATORS: */


int definerandgen(randgengen rg);
    /* Installs a new user defined random number generator and returns its ID.
    rg must contain all relevant data for the random generator, and it may not
    be deallocated elsewhere because rg is directly put to the stack of
    random generator definitions.
    $A Igor mar05; */

randgengen randgendef(int id);
    /* Returns definition data for user defined random number generator whose
    identity number is id.
    $A Igor mar05; */




          /****************************************/
          /*                                      */
          /*  GENERIC RANDOM GENERATOR FUNCTIONS  */
          /*                                      */
          /****************************************/


randgengen newrandgen0(int gentype,char *description);
    /* Returns a new random number generator of the type gentype. Allocation
    and initialization is performed by the appropriate function provided for
    that type of generator.
      Pre-defined generator ID-s such as SUBTYPE_randgenmt or 
    SUBTYPE_randgenexp can be used.
      If gentype is 0 then a generator of default type is created (i.e. the
    type that is considered most appropriate for general purpose).
      If desccription is not NULL then its dynamic copiy is assigned to
    (...)->bs.name.
    $A Igor mar05; */

randgengen newrandgen();
    /* Returns a new random number generator of the default type. Allocation
    and initialization is performed by the appropriate function provided for
    that type of generator.
    $A Igor mar05; */

void disprandgen(randgengen *rg);
    /* Deallocates the random generator structure pointed to by *rg and sets
    *rg to NULL.
    $A Igor mar05; */

unsigned long seedrandgen(randgengen rg,unsigned long seed);
    /* Initializes random generator rg by the seed. If two generators of the
    same type are initialized by the same seed then they should generate the
    same sequences.
    $A Igor mar05; */

unsigned long seedrandgentime(randgengen rg,unsigned long seed);
    /* Initializes random generator rg semi-randomly by using the current 
    system and CPU time and by the seed.
    $A Igor mar05; */

unsigned long seedrandgenrand(randgengen rg,unsigned long seed);
    /* Randomly initializes the random generator rg; The initialization is
    uncorrelated among successive calls within the same process and among
    calls within different programs, even if they were called at the same time.
    seed is additional perturbation used in initialization and can be set to 0
    without affecting too much the behavior (otherwise, it can be some random
    number previously calculated).
    $A Igor mar05; */

unsigned long randintgen(randgengen rg,unsigned long max);
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    current state of rg (which can be initialised by seedrandgen() or some
    other function).
    $A Igor mar05; */

double randgen(randgengen rg);
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    the current state of rg (which can be initialised by seedrandbasmt).
    $A Igor mar05; */



          /************************************/
          /*                                  */
          /*  DIFFERENT RANDOM DISTRIBUTIONS  */
          /*                                  */
          /************************************/


    /* NORMAL DISTRIBUTION: standard (0,1) and parametric (mean,sigma) */


double randgennormstd(randgengen rg);
    /* Returns a normally distributed random number with mean value 0 and
    standard deviation 1, generated by using rg. Box-Miller transform is
    used (Ref. Wikipedia).
      The number of rejected generations is added to rg->rejected.
    $A Igor mar05; */

double randgennorm(randgengen rg,void *clientdata);
    /* Returns a normally (Gaussian) distributed random number generated by
    using rg. 
      If clientdata is NULL then the distribution with mean value 0 and 
    standard deviation 1 is returned. Otherwise, clientdata must point to a
    table of two numbers of type double (offset 0), which define the mean
    and the standard deviation.
      The number of rejected generations is added to rg->rejected.
    $A Igor mar05; */

double densfuncnorm(double x,void *clientdata);
    /*  Normal probability density. If cd!=NULL it must point to a table of two
    numbers of type double, which represent the distribution mean value and
    standard deviation, respectively. Otherwise dens. of standard normal dist.
    is returned (mean 0, std. dev. 1).
      The density is normalized (integral from - to + infinity is 1).
    $A Igor mar05; */

double densfuncnormstd(double x);
    /*  Standard normal probability distribution (mean 0 and std. deviation 1)
   density function.
    The density is normalized (integral from - to + infinity is 1).
    $A Igor mar05; */


  /* Uniform distribution related functions: */

double constdistgenpar(randgengen rg,void *clientdata);
    /* Returns an uniformly distributed random number in the interval [0,1]. 
    clientdata is ignored.
    $A Igor mar05; */

static double densfuncconstdist01(double x,void *cd);
    /* Constant probability density on [0,1], 0 elsewhere, normalized.
    $A Igor mar05; */

static double densfuncconstdist(double x,void *cd);
    /* Constant probability density everywhere; not normalized (actually it can
    not be normalized and is used only for testing).
    $A Igor mar05; */

double densfunchyperballcoord1(double x,int *n);
    /* Returns non-normalized probability density function that corresponds to
    probability distribution with respect to given co-ordinate of points that
    are uniformly distributed in 0 centered unit ball in R^dim, namely
      1-x^2)^(dim/2) on [-1,1], 0 elsewhere.
    Values are not normalized an 0 -> 1.
    $A Igor mar05; */


double densfunchyperballcoord(double x,int *dim);
    /* The same as densfunchyperballcoord1, but normalized such that integral
    from -1 to 1 (and over all real number) is 1.
    $A Igor mar05; */




    /* CO-ORDINATE DISTRIBUTION IN A UNIT HYPERBAL */


double randgenhyperballcoord(randgengen rg,int *n);
    /* Returns a random number whose probability distribution corresponds to
    probability distribution with respect to given co-ordinate of points that
    are uniformly distributed in 0 centered unit ball in R^(n+1).
      The pdf (density function) is proportional to (1-x^2)^(n/2) on [-1,1].
    Instances are generated by the rejection method.
      The number of rejected generations is added to rg->rejected.
    $A Igor mar05; */

double densfunchyperballcoord1(double x,int *n);
    /* Returns non-normalized probability density function that corresponds to
    probability distribution with respect to given co-ordinate of points that
    are uniformly distributed in 0 centered unit ball in R^dim, namely
      1-x^2)^(dim/2) on [-1,1], 0 elsewhere.
    Values are not normalized an 0 -> 1.
    $A Igor mar05; */

double densfunchyperballcoord(double x,int *dim);
    /* The same as densfunchyperballcoord1, but normalized such that integral
    from -1 to 1 (and over all real number) is 1.
    $A Igor mar05; */




          /***************************************/
          /*                                     */
          /*  TESTS OF RANDOM NUMBER GENERATION  */
          /*                                     */
          /***************************************/


    /* TESTING PROBABILITY DISTRIBUTIONS: */

double inspranddist(randgengen rg,double from,double to,int n,int numint,
          int numgen,
          double distgen(randgengen rg,void *cd),void *distdata,
          double densfunc(double x,void *cd),void *funcdata);
    /* This function tests whether the generator distgen actually generates
    random numbers with expected probability distribution. Test is performed
    by generating numgen random numbers, checks how many of them falls into
    n intervals between from and to, and compares the counted hits with
    expected. The function returns average relative discrepancy between
    expected and counted number.
      rg is the random generator used for generation.
      from, to and n define the limits and number of equidistand test intervals.
      numgen is the total number of generations.
      distgen is the function for generating random numbers with specific
    probability distribution, which takes the random generator and definition
    data as arguments.
      distdata is the definition data for random distribution (e.g. average
    and standard deviation for Gauss distribution)
      densfunc must be a function whose returned values are proportional to
    the probability density of the distribution, which takes the value of
    independent variable and additional definition data as arguments.
      funcdata is the definition data for densfunc.
    $A Igor mar05; */




          /*****************************/
          /*                           */
          /*  GLOBAL RANDOM GENERATOR  */
          /*                           */
          /*****************************/


randgengen globrandgen(void);
    /* Returns the global random generator data. If the global generator has
    not yet been created then it is created first.
    $A Igor mar05; */

unsigned long seedrandglob(unsigned long seed);
    /* Seeds the global random generator by seed.
    $A Igor mar05; */

unsigned long seedrandtimeglob(unsigned long seed);
    /* Seeds the global random generator semi-randomly by seed and the current
    wallclock and CPU time.
    $A Igor mar05; */

unsigned long seedrandrandglob(unsigned long seed);
    /* SRandomly initializes the global random generator. The initialization is
    uncorrelated among successive calls within the same process and among
    calls within different programs, even if they were called at the same time.
    seed is additional perturbation used in initialization and can be set to 0
    without affecting too much the behavior (otherwise, it can be some random
    number previously calculated).
    $A Igor mar05; */

unsigned long randintglob(unsigned long max);
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by the global random generator. The generated sequence is 
    deterministic, dependent on the current state of the generator (this can
    be initialized e.g. by seedrandglob().
    $A Igor mar05; */

double randglob();
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by the global random generator. The generated sequence is 
    deterministic, dependent on the current state of the generator (which can
    be initialised e.g. by seedrandglob(), seedrandtimeglob() or 
    seedrandrandglob).
    $A Igor mar05; */


     /*  DIFFERENT RANDOM DISTRIBUTIONS by global generator  */

double normdistglobstd();
    /* Returns a normally distributed random number by mean value 0 and
    standard deviation 1, generated by using the global generator.
    $A Igor mar05; */



          /*****************************/
          /*                           */
          /*  SYSTEM RANDOM GENERATOR  */
          /*   (provided by compiler)  */
          /*                           */
          /*****************************/


void initrand(int seed);
    /* Inicializira random generator z vrednostjo seed.
    $A Igor sep00; */

void timeinitrand(void);
     /* Inicializira generator nakljucnih stevil s pomocjo sistemskega casa */

double random1(void);
       /* Vrne nakljucno stevilo med 0 in 1. */

double normdist(void);
       /* Vrne nakljucno stevilo po normalni porazdelitvi s srednjo vrednostjo 0
          in standardno deviacijo 1 */





          /*****************************/
          /*                           */
          /*  BASIC RANDOM GENERATORS  */
          /*                           */
          /*****************************/


/*   QUICK INSTRUCTIONS

  There are more than one random generator algorithms, and one of them is 
chosen as the official algorithm. The last suffix in a function name refers
to the algorithm, such as "mt" for Mersenne twister or "exp" for the 
experimental algorithm. For the official algorithm there are pre-process
definitions (via #define), which bind names without the type sffix to the
names that correspond to appropriate official algorithm.
  For each algorithm there is a data type. A couple of fields in this
such structural types are standard (such as type, count, etc.). There are
two groups of functions, one that takes the data structure representing the
random generator as the first argument, and one that operates on a "global"
random generator defined as a static variable. For the first kind of functions,
the random generator must be allocated before use by newrandgen*, where *
stands for the algorithm suffix, and must be released after use by the
disprandgen*. For the second kind of functions generator data is automatically
allocated.
  There are three types of initialisation for each generator -
deterministically by the seed, by the current time (and a seed) and random
initialisation that attemps to get rid of any correlation between different
random generators that might be used simultaneously within a single process
or across processes.
  Functions are divided to deterministic and random or non-deterministic,
which attempt to use "random" phenomena (such as current time or CPU time or
operations count from time to time to overcome the deterministic nature of 
software generation of random numbers. It is not necessary that the non-
deterministic generator would pass statistical tests better, it is just that
its output is less predictable in some sense.
  Each group of functions is further divided to those that generate integer
numbers (unsigned long) with a prescribed maximum and those that generate
real numbers (type double) between 0.0 and 1.0 (inclusively in the basic
variant).
*/


      /***********************************/
      /*                                 */
      /*  EXPERIMENTAL RANDOM GENERATOR  */
      /*                                 */
      /***********************************/


void *newrandgenexp(void);
    /* Creates and returna a new random generator; All data is initialized to
    0.
    $A Igor jun04; */

void disprandgenexp(void **addr);
    /* Deallocates the space pointed to by *addr and sets this pointer to NULL.
    $A Igor jun04; */

unsigned long seedrandbasexp(void *rg,unsigned long seed);
    /* Initializes the random generator rg by the seed.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

unsigned long seedrandtimebasexp(void *rg,unsigned long seed);
    /* Initializes the random generator rg semi-randomly by using the current
    system and CPU time and by the seed.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

unsigned long seedrandrandbasexp(void *rg,unsigned long pert);
    /* Randomly initializes the random generator rg; The initialization is
    uncorrelated among successive calls within the same process and among
    calls within different programs, even if they were called at the same time.
    pert is additional perturbation used in initialization and can beset to 0
    without affecting too much the behavior (otherwise, it can be some random
    number previously calculated).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

unsigned long randintdetbasexp(void *rg,unsigned long max);
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    current state of rg (which can be initialised by seedrandbas).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

unsigned long randintdetbassimpexp(void *rg,unsigned long max);
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    current state of rg (which can be initialised by seedrandbas).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

double randdetbasexp(void *rg);
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    the current state of rg (which can be initialised by seedrandbasexp).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

unsigned long randintrandbasexpexp(void *rg,unsigned long max);
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is randinit.
      This function is about 10 times SLOWER than randintdetbas(). and in wasp
      majority of cases that function should be used.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

double randrandbasexp(void *rg);
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by rg. The generated sequence is not deterministic.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */




    /* GLOBAL EXPERIMENTAL RANDOM GENERATOR: */


unsigned long seedrandexp(unsigned long seed);
    /* Initializes the global random generator by seed. Following this command,
    the subsequent calls to the deterministic generator would produce always
    the same series of results.
      The function is thread safe.
    $A Igor jun04; */

unsigned long seedrandtimeexp(unsigned long seed);
    /* Initializes the global random generator quasi-randomly by using the
    system time, and by seed.
      The function is thread safe.
    $A Igor jun04; */

unsigned long seedrandrandexp(unsigned long pert);
    /* Initializes the global random generator randomly. Such initialization
    is not correlated across subsequent calls to this function within a process
    or across calls by different processes, even if these are performed at the
    same time. pert is additional perturbation used in initialization and can
    be 0 without affecting too much the behavior (otherwise, it can be some
    random number previously calculated).
      The function is thread safe.
    $A Igor jun04; */

unsigned long randintdetexp(unsigned long max);
    /* Returns a random number from 0 to max inclusively, produced by the
    global random generator. The series of numbers generated  is deterministic,
    dependent only on the current state fo the global generator, which can be
    initialized by seedrand().
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */

double randdetexp(void);
    /* Returns a random number from 0 to 1.0 inclusively, produced by the
    global random generator. The series of numbers generated  is deterministic,
    dependent only on the current state fo the global generator, which can be
    initialized by seedrandexp().
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */

unsigned long randintrandexp(unsigned long max);
    /* Returns a random number from 0 to max inclusively, produced by the
    global random generator. The series of numbers generated  is
    randinit.
      This function is about 10 times SLOWER than randintder(), and that
    function should be used in most cases.
      The function is thread safe.
    $A Igor jun04; */

double randrandexp(void);
    /* Returns a random number from 0 to 1.0 inclusively, produced by the
    global random generator. The series of numbers generated  is 
    nondeterministic.
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */




          /********************************/
          /*                              */
          /*  MERSENNE TWISTER GENERATOR  */
          /*                              */
          /********************************/


/*  MERSENNE TWISTER GENERATOR
  Below is the code of Mersenne Twister random generator, which has been
modified in such a way that several generators with independent sequences
can be used at a time. The generator is very quality and efficient, the 
drawback is the amount of storage per generator (more than 600 long integers).
See the directory rand/mt/ for the original code with
copyright notices! */


void * newrandgenmt(void);
    /* Creates and returna a new random generator; All data is initialized to
    0.
    $A Igor jun04; */


void disprandgenmt(void **addr);
    /* Deallocates the space pointed to by *addr and sets this pointer to NULL.
    $A Igor jun04; */


unsigned long seedrandbasmt(void *rg,unsigned long seed);
    /* Initializes the random generator rg by the seed.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

unsigned long seedrandtimebasmt(void *rg,unsigned long seed);
    /* Initializes the random generator rg semi-randomly by using the current
    system and CPU time and by the seed.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

unsigned long seedrandrandbasmt(void *rg,unsigned long pert);
    /* Randomly initializes the random generator rg; The initialization is
    uncorrelated among successive calls within the same process and among
    calls within different programs, even if they were called at the same time.
    pert is additional perturbation used in initialization and can beset to 0
    without affecting too much the behavior (otherwise, it can be some random
    number previously calculated).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

unsigned long randintdetbasmt(void *rg,unsigned long max);
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    current state of rg (which can be initialised by seedrandbasmt).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

double randdetbasmt(void *rg);
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    the current state of rg (which can be initialised by seedrandbasmt).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

unsigned long randintrandbasmt(void *rg,unsigned long max);
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is randinit.
      This function is about 10 times SLOWER than randintdetbasmt(). and in wasp
      majority of cases that function should be used.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */

double randrandbasmt(void *rg);
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by rg. The generated sequence is nondeterministic.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */


    /* GLOBAL MERSENNE TWISTER RANDOM GENERATOR: */

unsigned long seedrandmt(unsigned long seed);
    /* Initializes the global random generator by seed. Following this command,
    the subsequent calls to the deterministic generator would produce always
    the same series of results.
      The function is thread safe.
    $A Igor jun04; */

unsigned long seedrandtimemt(unsigned long seed);
    /* Initializes the global random generator quasi-randomly by using the
    system time, and by seed.
      The function is thread safe.
    $A Igor jun04; */

unsigned long seedrandrandmt(unsigned long pert);
    /* Initializes the global random generator randomly. Such initialization
    is not correlated across subsequent calls to this function within a process
    or across calls by different processes, even if these are performed at the
    same time. pert is additional perturbation used in initialization and can
    be 0 without affecting too much the behavior (otherwise, it can be some
    random number previously calculated).
      The function is thread safe.
    $A Igor jun04; */

unsigned long randintdetmt(unsigned long max);
    /* Returns a random number from 0 to max inclusively, produced by the
    global random generator. The series of numbers generated  is deterministic,
    dependent only on the current state fo the global generator, which can be
    initialized by seedrand().
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */

double randdetmt(void);
    /* Returns a random number from 0 to 1.0 inclusively, produced by the
    global random generator. The series of numbers generated  is deterministic,
    dependent only on the current state fo the global generator, which can be
    initialized by seedrandmt().
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */

unsigned long randintrandmt(unsigned long max);
    /* Returns a random number from 0 to max inclusively, produced by the
    global random generator. The series of numbers generated  is
    randinit.
      This function is about 10 times SLOWER than randintder(), and that
    function should be used in most cases.
      The function is thread safe.
    $A Igor jun04; */

double randrandmt(void);
    /* Returns a random number from 0 to 1.0 inclusively, produced by the
    global random generator. The series of numbers generated  is 
    nondeterministic.
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */




#if 0

      /*******************************/
      /*                             */
      /*  OFFICIAL RANDOM GENERATOR  */
      /*                             */
      /*******************************/


/* The definitions below specify the default random number generator functions: */




#define newrandgen newrandgenmt      /* creation of generator */
#define disprandgen disprandgenmt    /* deletion of generator */

#define seedrandbas seedrandbasmt          /* seed init */
#define seedrandtimebas seedrandtimebasmt  /* time init */
#define seedrandrandbas seedrandrandbasmt  /* random init */

#define randintdetbas randintdetbasmt    /* integer deterministic */
#define randdetbas randdetbasmt          /* real deterministic */
#define randintrandbas randintrandbasmt  /* integer nondeterministic */
#define randrandbas randrandbasmt        /* real nondeterministic */

    /* GLOBAL RANDOM GENERATOR: */

#define seedrand seedrandmt
#define seedrandtime seedrandtimemt
#define seedrandrand seedrandrandmt
#define randintdet randintdetmt

#define randintdet randintdetmt
#define randdet randdetmt
#define randintrand randintrandmt
#define randrand randrandmt


/* Uncomment definitions below if you want to use the experimental random
generator as the default one! Do this only for testing purposes! */



#ifdef officialrandexp

#define newrandgen newrandgenexp
#define disprandgen disprandgenexp

#define seedrandbas seedrandbasexp
#define seedrandtimebas seedrandtimebasexp
#define seedrandrandbas seedrandrandbasexp

#define randintdetbas randintdetbasexp
#define randdetbas randdetbasexp
#define randintrandbas randintrandbasexp
#define randrandbas randrandbasexp


#define seedrand seedrandexp
#define seedrandtime seedrandtimeexp
#define seedrandrand seedrandrandexp

#define randintdet randintdetexp
#define randdet randdetexp
#define randintrand randintrandexp
#define randrand randrandexp

#endif /* defined (randexp) */



#endif    /* to if 0 */








void testrand();
    /* Test random utilities. */




#endif  /* not defined INCLUDED_rand */
