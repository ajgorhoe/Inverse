



/* The following code enables inclusion of this header withoutthe need for
taking care explicitly that it is included only once: */
#ifndef INCLUDED_grint
#define INCLUDED_grint



void giinstallfont(int num,char *name);
    /* Instalira font z imenom name na mesto num. */

void gicoloring(int yes);
    /* Ce je yes 0, bodo grafi izrisani v sivih odtenhih, drugace pa v barvnih.
    funkcija ima efekt, ce jo klicemo pred giinitdisplay(). */

void ginumshades(int num);
    /* Nastavi stevilo barvnih odtenkov vsake komponente barve na num. Funkcija
    ima efekt, ce jo klicemo pred initdisplay(). Ce je num 0, so barve zvezne
    (v tem primeru se tudi ne more uporabiti indeksiranje). */

void gicolortabsize(int size);
    /* Nastavi velikost tabele, v kateri so shranjeni indeksi ze alociranih
    barvnih celic, na size. Ce je size 0, se ne uporablja indeksiranje in se
    pri vsaki uporabi katerekoli barve prenese X serverju ukaz za alokacijo
    ustrezne barvne celice ne glede na to, ali je bila tista barva ze prej
    uporabljena. */

void gipreindexcolors(int yes);
    /* Ce je yes 0, se zahteve za alokacijo barvnih celic dajejo serverju
    sproti, ce je 1, pa se predhodno (ob inicializaciji zaslona) rezervirajo
    celice za vse mozne barve (seveda le, ce je tabela indeksov dovolj
    velika). */

void gisetwindowtitle(char *title);
     /* Naslov oken, ki se na novo odpirajo, postavi na title. */

char *gigetwindowtitle(void);

float gisetwindowxpos(float z);
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri x na z. Vrne prej.
    pozicijo. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */

float gigetwindowxpos(void);

float gisetwindowypos(float z);
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri y na z. Vrne prej.
    pozicijo. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */

float gigetwindowypos(void);

float gisetwindowwidth(float z);
    /* Postavi zaceto sirino oken pri odpiranju v smeri na z. Vrne prej.
    sirino. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */

float gigetwindowwidth(void);

float gisetwindowheight(float z);
    /* Postavi zaceto visino oken pri odpiranju v smeri na z. Vrne prej.
    visino. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */

float gigetwindowheight(void);

int ginsetwindowxpos(int z);
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri x na z. Vrne prej.
    pozicijo.
    $A Igor maj97; */

int gingetwindowxpos(void);
    /* $A Igor maj97; */

int ginsetwindowypos(int z);
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri y na z. Vrne prej.
    pozicijo.
    $A Igor maj97; */

int gingetwindowypos(void);
    /* $A Igor maj97; */

int ginsetwindowwidth(int z);
    /* Postavi zaceto sirino oken pri odpiranju v smeri na z. Vrne prej.
    sirino.
    $A Igor maj97; */

int gingetwindowwidth(void);
    /* $A Igor maj97; */

int ginsetwindowheight(int z);
    /* Postavi zaceto visino oken pri odpiranju v smeri na z. Vrne prej.
    visino.
    $A Igor maj97; */

int gingetwindowheight(void);
    /* $A Igor maj97; */

float gisetpointsize(float size);
      /* Nastavi velikost tock. Vrne trenutno velokost. */

float gigetpointsize(void);

int gisetcurvepoints(int num);
    /* Nastavi stevilo vmesnih tock pri risanju krivuljnih objektov, npr.
    kroznic. Vrne trenutno stevilo tock. */

int gigetcurvepoints();

void gisetlinecolor(float red,float green,float blue);
     /* Nastavi barvo za risanje crt. */

void gigetlinecolor(float *red,float *green,float *blue);

void gisetfillcolor(float red,float green,float blue);
     /* Nastavi barvo za risanje zapolnjenih likov */

void gigetfillcolor(float *red,float *green,float *blue);

void gisetlinewidth(double width);
     /* Nastavi sirino crt pri risanju (velja tudi za nezapolnjene like) */

double gigetlinewidth(void);

void gisetlinetype(int type);
     /* Nastavi tip crt */

int gigetlinetype(void);

void gisettextcolor(float red,float green,float blue);
     /* Nastavi barvo teksta. */

void gigettextcolor(float *red,float *green,float *blue);

void gisettextprecision(float precision);
     /* Ta funkcija ni izdelana do konca! */

float gigettextprecision();

void gisettextfont(int font);
     /* Nastavi pisavo, ki se uporablja pri tekstu. */

int gigettextfont(void);

void gisettextheight(float height);
     /* Nastavi velikost (visino) teksta. */

float gigettextheight(void);

void gisettextspacing(float spacing);
     /* Nastavi velikost presledkov med crkami pri tekstu. */

float gigettextspacing(void);

void gisettextexpansion(float expansion);
     /* Nastavi razsiritev teksta v vodoravni smeri. */

float gigettextexpansion(void);

void gisettextxalignment(int alignment);
     /* Nastavi poravnavanje teksta v vodoravni smeri. Ce je alignment -1, je
     poravnavanje levo, ce je 0, je centrirano, ce pa je 1, je desno. */

int gigettextxalignment(void);

void gisettextyalignment(int alignment);
     /* Nastavi poravnavanje teksta v navpicni smeri. Ce je -1, je poravnavanje
     spodnje, ce je 0, je centrirano, ce pa je 1, je zgornje. */

int gigettextyalignment(void);

void gisettextalignment(int xalignment,int yalignment);
     /* Hkrati nastavi poravnavanje teksta v obeh smereh, pri cemer uporablja
     funkciji settextxalignment in settextyalignment. */

void gigettextalignment(int *xalignment,int *yalignment);

int giinitdisplay(void);
    /* Odpre display. */

int giinitgraph(void);
    /* Zacetne nastavitve za grafiko. To funkcijo se lahko pozene le enkrat ne
    glede na stevilo oken, ki so odprta (nastavitve veljajo za vsa okna). */

int giopenwindow(void);
    /* Odpre novo okno. Vrne identifikacijsko stevilko tega okna, s to stevilko
    se nato sklicujemo na to okno v programu. Okno, ki ga odpre, postane
    aktivno. */

int gisetwindow(int num);
    /* Okno z zaporedno stevilko num naredi za aktivno. */

void giresetwindow(void);
     /* Resetiranje aktivnega okna. Vsebina okna se zbrise. */

void giclosewindow(void);
     /* Zapre aktivno okno. */

void giclearwindow(void);
     /* Zbrise vsebino okna z identifikacijsko stevilko window. */

void giflushdisplay(void);
     /* Povzroci izris vsega, kar se se ni izrisalo. */

void giline(float x1,float y1,float x2,float y2);
     /* Narise crto med tockama (x1,y1) in (x2,y2). */

void gitriangle(float x1,float y1,float x2,float y2,float x3,float y3);
     /* Narise trikonik iz crt z oglisci (x1,y1), (x2,y2) in (x3,y3). */

void gifourangle(float x1,float y1,float x2,float y2,float x3,float y3,
               float x4,float y4);
     /* Narise stirikotnik iz crt z oglisci (x1,y1), (x2,y2), (x3,y3) in
     (x4,y4). */

void girectangle(float x1,float y1,float x2,float y2);
     /* Narise pravokotnik iz crt z nasprotileznima ogliscema (x1,y1) in
     (x2,y2). */

void gicircle(float x,float y,float r);
     /* Narise krog iz curvepoints crt s srediscem (x,y) in radijem r. */

void gicirclearc(float x,float y,float r,float fi1,float fi2);
     /* Narise krozni lok iz curvepoints crt s srediscem (x,y), radijem r ter
     z zacetnim kotom fi1 in s koncnim kotom fi2. Koti so v radianih. */

void giellipse(float x,float y,float a,float b);
     /* Narise elipso iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri. */

void giellipsearc(float x,float y,float a,float b,float fi1,float fi2);
     /* Narise elipsin lok iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri ter z zacetnim kotom fi1 in
     s koncnim kotom fi2. Koti so v radianih. */

void gifilltriangle(float x1,float y1,float x2,float y2,float x3,float y3);
     /* Narise pobarvan trikotnik z oglisci (x1,y1), (x2,y2) in (x3,y3). */

void gifillfourangle(float x1,float y1,float x2,float y2,float x3,float y3,
                   float x4,float y4);
     /* Narise pobarvan stirikotnik z oglisci (x1,y1), (x2,y2), (x3,y3) in
     (x4,y4). */

void gifillrectangle(float x1,float y1,float x2,float y2);
     /* Narise zapolnjen pravokotnik s protileznima ogliscema (x1,y1) in
     (x2,y2). */

void gipoint(float x,float y);
     /* Narise tocko s koordinatami (x,y). Za barvo se uporalbja barva za
     polnjenje likov. */

void gifillcircle(float x,float y,float r);
     /* Narise zapolnjen krog s srediscem v (x,y) in polmerom r iz curvepoints
     zapolnjenih trikotnikov. */

void gifillcirclearc(float x,float y,float r,float fi1,float fi2);
     /* Narise zapolnjen krozni lok s srediscem (x,y), polmerom r ter zacetnim
     kotom fi1 in koncnim kotom fi2 zi curvepoints zapolnjenih trikotnikov. Koti
     so v radianih. */

void gifillellipse(float x,float y,float a,float b);
     /* Narise zapolnjeno elipso s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b iz curvepoints zapolnjenih trikornikov. */

void gifillellipsearc(float x,float y,float a,float b,float fi1,float fi2);
     /* Narise zapolnjen elipsin lok s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b ter zacetnim kotom fi1 in koncnim fi2 iz curvepoints
     zapolnjenih trikornikov. Koti so v radianih. */

void gitext(char *str,float x,float y);
     /* Izpise niz str pri koordinatah (x,u). */

void gifillcirclearc(float x,float y,float r,float fi1,float fi2);
     /* Narise zapolnjen krozni lok s srediscem (x,y), polmerom r ter zacetnim
     kotom fi1 in koncnim kotom fi2 zi curvepoints zapolnjenih trikotnikov. */

void gidrawloop(void (*redraw)(void));
     /* Zanka okrog funkcije redraw, ki naj bi bila taksna funkcija, ki nekaj
     narise v aktivno okno. Funkcija na novo izrise aktivno okno vsakic, ko je
     potrebno zaradi odkrivanja okna ali cesa drugega. Ko kliknemo z misko v
     okno, se le-to zapre. */

int gibuttonpressed(void);
    /* Vrne st. gumba miske, ki je bil pritisnjen v aktivnem oknu. Ce ni bil
    pritisnjen noben gumb, vrne 0. Funkcija caka, dokler ni dejansko pritisnjen
    kak gumb ali se ne izpostavi aktivno okno. */


void gimarker(float x1,float x2,float size,int kind);
    /* Narise marker velikosti size in vrste kind pri koordinatah (x,y). */

void giarrow(float x1,float y1,float x2,float y2,float size,float angle,
            char l, char f,char kind);
  /* Narise puscico od (x1,y1) do (x2,y2) z velikostjo glave size in korom
  puscice angle. line doloca izris linijske stresice, fill pa zapolnjene
  trikotne glave (0 - se ne izrise, 1 - se izrise)
  $A Igor maj01; */







          /**************************************************/
          /*   GRAFICNI VMESNIK ZA FORMATE PS, DXF IN TCL   */
          /**************************************************/



                     /**************************/
                     /*       FORMAT TCL       */
                     /**************************/


void tclsetwindowsize(int width,int height);
    /* Postavi sirino tcl-ovega okna, v katerem se izrise graf iz tcl-ove
    datoteke, na width, in visino na height. Ce je eden ali drugi 0, se
    ohranita dimenziji, ki sta trenutno nastavljeni.
    $A Igor maj01; */





/* POSPLOSENE FUNKCIJE GRAFICNEGA VMESNIKA: */

void (*griline) (float,float,float,float);

void (*gritriangle) (float,float,float,float,float,float);

void (*grifourangle) (float,float,float,float,float,float,float,float);

void (*grifilltriangle) (float,float,float,float,float,float);

void (*grifillfourangle) (float,float,float,float,float,float,float,float);

void (*gritext) (char *,float,float);


/* ENOTE, KI SE NARISEJO S POMOCJO DRUGIH FUNKCIJ ZA IZRIS: */

void (*grirectangle) (float,float,float,float);

void (*gricircle) (float,float,float);

void (*gricirclearc) (float,float,float,float,float);

void (*griellipse) (float,float,float,float);

void (*griellipsearc) (float,float,float,float,float,float);

void (*grifillrectangle) (float,float,float,float);

void (*grifillcircle) (float,float,float);

void (*grifillcirclearc) (float,float,float,float,float);

void (*grifillellipse) (float,float,float,float);

void (*grifillellipsearc) (float,float,float,float,float,float);


void (*grimarker) (float,float,float,int);

void (*griarrow) (float x1,float y1,float x2,float y2,float size,float angle,
                  char l,char f,char kind);



/* FUNKCIJE ZA IZPIS GLAVE IN REPA V DATOTECNIH FORMATIH: */

void (*griprinthead) (void);

void (*griprinttail) (void);



/* FUNKCIJE ZA NASTAVITEV VMESNIKA OZ. FORMATA: */

void grisavefunc(void);

void grirestorefunc(void);

void setgrintdisp(void);

void setgrintps(FILE *outfile);

void setgrinttcl(FILE *outfile);
    /* $A Igor apr97; */

void setgrintdxf(FILE *outfile);
    /* $A Igor apr97; */











#endif    /* (not defined) INCLUDED_grint */


