

#define INV_OLDPREDEF   /* Old way of handling pre-defined inverse variables: */

#ifdef INV_OLDPREDEF    /* Undefine INV_OLDPREDEF (use new handling of predefined variables) */
  #undef INV_OLDPREDEF
#endif


/* Code that prevents multiple inclusion: */
#ifndef INCLUDED_inv
#define INCLUDED_inv



    /* DEFINICIJE ZA NOV SISTEM ZA INVERZNO ANALIZO */



/* Koda, ki zagotovi vkljucitev potrebnih headerjev, ce niso ze vkljuceni v
izvorni kodi pred tem headerjem: */
#ifndef INCLUDED_vec
#include <vec.h>
#endif
#ifndef INCLUDED_mat
#include <mat.h>
#endif
#ifndef INCLUDED_fld
#include <fld.h>
#endif
#ifndef INCLUDED_st
#include <st.h>
#endif
#ifndef INCLUDED_fint
#include <fint.h>
#endif
#ifndef INCLUDED_varop
#include <varop.h>
#endif

#include <iotool.h>


typedef struct{
        void *var;
        char *name;
      } _uservartype;

typedef _uservartype *uservartype;


typedef struct{
       /* Program arguments and system variables: */
       int argc;
       char **argv,**env;
       ficom
        fcom;       /* Podatki za osnovni datotecni interpreter */
       _fifuncdata
        andata,    /* Podatki o bloku analysis */
        compdata; /* Podatki o bloku completion */
       long
        transffrom, /* Zacetek definicije transformacije */
        transfto;   /* Konec definicije transformacije */
       stack args;  /* Argumenti iz command line */
       /*
       char
        chi2spec,   /* Je true, ce se chi2 izracuna ze v funkciji analyse *
        chi2add,    /* Je true, ce moramo chi2 dodati del, ki se izracuna ze v
                       funkciji analyse. *
        autoin,     /* Avtomatska inicializacija dela vmesnika, ki spreminja
                    podatke v vhod. dat. direkt. analize  (glej fi_initinput() *
        autoout,    /* Avtomatska inicializacija dela vmesnika, ki bere podatke
                    iz izhod. dat. direkt. analize (glej funk. fi_initoutput()) *
        autotransf, /* Avtomatska transformacija vektorja parammom pri analizi *
        parallel,   /* Ce je true, je proces del paralelne sheme *
        master,     /* Ce je 1, je proces nadrejeni proc. v paralel. shemi *
        slave,      /* Ce je 1, je proces podrejeni proc. v paralel. shemi *
        check,
        debug;
       */

       char check;  /* options for checking */
       FILE *checkoutfile;  /* output file for checkinh */

       varholder

        scalobjectivemom,
        scalobjectiveopt,
        scalobjective0,
        scalconstraintmom,
        scalconstraintopt,
        scalconstraint0,

        vecmeas,
        vecmeasexact,
        vecmeasmom,
        vecmeasopt,
        vecmeas0,
        vecsigma,
        vecparammom,
        vecparamopt,
        vecparam0,
        vecparammomold,

        vecdirection,
        vecstartpoint,
        vectransf,

        vecgradobjectivemom,
        vecgradobjectiveopt,
        vecgradobjective0,
        vecgradconstraintmom,
        vecgradconstraintopt,
        vecgradconstraint0,

        vecgradmeasmom,
        vecgradmeasopt,
        vecgradmeas0,

        matder2objectivemom,
        matder2objectiveopt,
        matder2objective0,
        matder2measmom,
        matder2measopt,
        matder2meas0

#ifdef INV_OLDPREDEF
        ,
        vfiinfile,
        vfioutfile,
        vfianinfile,
        vfianoutfile
#endif
        ;

       vector
        meas,      /* meritve (vhodni podatek) */
        measexact, /* natancne meritve */
        measmom,   /* simulirane meritve po zadnji simulaciji */
        sigma,     /* standardne deviacije izmerkov */
        param0,    /* zacetni priblizek za neznane parametre (vhod. pod.) */
        parammom,  /* poskusne vrednosti neznanih parametrov */
        parammomold, /* sem se shrane parammom pred transformacijo */
        paramopt,  /* izracunane optimalne vrednosti parametrov (izhod. pod.) */
        startpoint,/* zacet. tocka za funkcijo chi2linold */
        direction, /* smer za funkcijo chi2linold */
        transf;    /* vektor, v katerega je shranjena transformacija */
       matrix
        gradmeas0old;  /* matrika, katere stolpci so gradienti meritev */
       stack
        var,       /* Sklad, ki vsebuje vse spremenljivke */
        str,       /* Sklad, na katerega se spravijo definirani nizi */
        count,     /* Sklad, na katerega se spravijo definirani stevci */
        scal,      /* Sklad, na katerega se spravijo definirani skalarji */
        vec,       /* Sklad, na katerega se spravijo definirani vektorji */
        mat,       /* Sklad, na katerega se shranejo uporabnisko definirane matrike */
        vfi,       /* Datotecne spremenljivke */
        fld,       /* Spremenljivke, ki nosijo polja */
        proc,      /* Sklad, nakaterem so podatki o podrejenih procesih */
        lockproc;  /* Sklad zaklenjenih procesov */
       int
        countan,   /* stevec izvedenih simulacij */
        numparam,  /* stevilo neznanih parametrov (vhodni podatek) */
        nummeas,   /* stevilo meritev */
        numobjectives, /* stevilo vrednostih funkcij */
        numconstraints, /* stevilo omejitvenih funkcij */
        numtransf, /* st. komponent transformiranega vektorja */
        parrank,   /* Identifikac. shema procesa v paralelni shemi */
        numprocs,  /* Stevilo inicializiranih podrejenih procesov */
        talkto,    /* Proces, s katerim se nas proces pogovarja */
        forceproc; /* Proces, ki naj se ultimativno uporabi za analizo */
       double
        chi2mom,   /* vrednost hi-kvadrat po zadnji simulaciji */
        chi2opt;     /* koncna vrednost hi-kvadrat (izhodni podatek) */
       FILE
        *commandfile,  /* ukazna datoteka */
#ifdef INV_OLDPREDEF
        *infile,       /* vhodna datoteka */
        *outfile,      /* izhodna datoteka */
        *aninfile,     /* vhodna datoteka za analizo */
        *anoutfile,    /* izhodna datoteka za analizo */
#endif
        *erfile;       /* zacasna datoteka za zapis porocil o napakah */
       /*
       FILE (*getinvoutfile) (void);
       FILE (*getinvinfile) (void);
       FILE (*getinvanoutfile) (void);
       FILE (*getinvaninfile) (void);
       */
       char
        *directoryname,
        *commandfilename,
#ifdef INV_OLDPREDEF
        *infilename,
        *outfilename,
        *aninfilename,
        *anoutfilename,
#endif
        *proclockfilename;
       char *programname;
       double version;
       int
        dd0,mm0,yy0, /* Datum izdelave te verzije */
        dd,mm,yy,    /* datum poteka veljavnosti programa */
        dd1,mm1,yy1, /* rezervni datum poteka veljavnosti (malo poznejsi) */
        daystillexp; /* stevilo dni do poteka veljavnosti */
       char
        silentex,    /* Ce je 1, ce ne izpise glava programa */
        *programme,
        *verspec,
        *creator,
        *creatormail,
        *creatorad1,
        *creatorad2,
        *www,
        *mail,
        *homedir;
       } _invcomstruct;


typedef _invcomstruct *invcomstruct;


extern  _invcomstruct invcom;

#define com invcom



/* FUNCTION FOR ACCESSING PRE-DEFINED VARIABLES: */

/* Comment:
  In the usual system, special variables were accessed through the invcom
structure (somewhere alias com by a #define directive) and variable handling
routines had to take care about updating the appropriate fields whenever the
corresponding variable has changed. The system will be gradually modified in
such a way that all special variables will be accessed through appropriate 
functions. The corresponding fields will be removed from the invcom structure
when all references are changed to function calls. 
  The system is may be changed only for files, since there are too many
interdependencies for other variables (parameters, objectives, constraints...).
  Motivation for changing the system for files were some bugs which were hard 
to locate, and the best way to avoid the related problems was to completely 
change functions like setfile and deletefile.
*/



    /* Special variables (whole varholders): */

  /* File variables: */

varholder inv_vfiinfile(void);
varholder inv_vfioutfile(void);
varholder inv_vfianinfile(void);
varholder inv_vfianoutfile(void);

  /* File pointers: */

FILE *inv_infile(void);
FILE *inv_outfile(void);
FILE *inv_aninfile(void);
FILE *inv_anoutfile(void);

FILE *inv_fintoutfile(ficom fcom);
    /* Function that returns the output file, prepared for installation on file
    interpreter. In this way, functions that are defined in the file
    interpreter module, can use the program output file. 
    $A Igor aug04; */

  /* File names: */

char *inv_infilename(void);
char *inv_outfilename(void);
char *inv_aninfilename(void);
char *inv_anoutfilename(void);








void initerrorsysteminv(void);
    /* Nastavi funkcije sistema napak pri klicu standardnih funkcij v er.c za
    program Inverse.
    $A Igor avg01; */



    /* FUNKCIJE ZA NASTAVITEV PARAMETROV PRI IZPISU STEVIL: */

int invgetoutdig(void);
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu inv.c.
    $A Igor mar99; */

int invgetoutchar(void);
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu inv.c.
    $A Igor mar99; */

void invsetoutdig(int num);
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu inv.c.
    $A Igor mar99; */

void invsetoutchar(int num);
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu inv.c.
    $A Igor mar99; */

void invsetoutdigall(int num);
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v vseh modulih.
    $A Igor mar99; */

void invsetoutcharall(int num);
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v vseh modulih.
    $A Igor mar99; */












#endif  /*  #ifndef INCLUDED_inv  */






