/*
 @(#) LU - dekompozicija  - Version 0.0
 Author: Tomaz Sustar
 Date  : 18.02.97
 Description of the program
 LU - Dekompozicija


 Revision History
 Num   Date    Who     Description
 ----------------------------------------------------------------------------


 ----------------------------------------------------------------------------
*/

#include <mtypes.h>
#include <mat.h>
#include <vec.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include <rand.h>

#define DIM 3
#define NMAT 2




static double testspeed(void)
{
double det=0,ret;
int dim=3,i,j;
matrix mat;
time_t t1,t2;
t1=time(NULL);
mat=getmatrix(dim,dim);
for(i=1;i<=dim;i++)
{
  for(j=1;j<=dim;j++)
    mat->m[i][j]=random1();
}
det=detmat(*mat);

printf("Det. = %g\n",det);

dispmatrix(&mat);
t2=time(NULL);
ret=difftime(t2,t1);
return ret;
}




int main()
{
matrix stress[300],u,l,inv;
double det;
int i,j,n;
int *order;
vector b,x,scale;



/*
printf("Speed test: %g seconds\n",testspeed());
exit(0);
*/


/*
  timeinitrand();    
*/

for (n=0;n<NMAT;++n)
{  
  printf("Alocating stress[%i]:\n",n);
  stress[n]=getmatrix(DIM,DIM);
}
l=getmatrix(DIM,DIM);
u=getmatrix(DIM,DIM);
order=(int *)malloc((1+DIM)*sizeof(int));  /* !!!! eno vec kot je dimenzija! */
scale=getvector(DIM);

/*
inv=getmatrix(DIM,DIM);
b=getvector(DIM);
x=getvector(DIM);
*/
    
    
    /*
    for(i=1;i<=DIM;i++)
      {
	for(j=1;j<=DIM;j++)
	    fscanf(dataf,"%lg",&(stress->m[i][j]));
	fscanf(dataf,"%lg",&(b->v[i]));

      }
      */
  
for (n=0;n<NMAT;++n)  
{  
  printf("Initializing stress[%i]\n",n);
  for(i=1;i<=DIM;i++)
  {
    for(j=1;j<=DIM;j++)
      stress[n]->m[i][j]=random1();
    /* b->v[i]=random1(); */
  }
}     
      
/*
printvec(*b);
*/
     
     
for (n=0;n<NMAT;++n)
{
  luordermat(scale,stress[n],order);
  ludecompmat(scale,stress[n],order);
  printf("det(stress[%i]) = %g \n",n,ludetmat(stress[n],order));
}

/*
printmatrow(stress[0]);
*/

/*
lusolvemat(stress[0],b,x,order);
printvec(*x);
*/

/*
luinvmat(stress[0],inv,order);
printmatrow(inv);
*/

/*
dispmat(stress[0]);
dispmat(u);
dispmat(l);
dispmat(inv);
dispvec(x);
dispvec(scale);
dispvec(b);
free(order);
*/

}












