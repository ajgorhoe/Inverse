

    /* OSNOVNE FUNKCIJE ZA SIMBOLNI KALKULATOR. */


#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stddef.h>


#include <mtypes.h>
#include <er.h>
#include <strop.h>
#include <st.h>
#include <rf.h>
#include <rand.h>
#include <fop.h>
#include <globut.h>
#include <simb.h>

/*
#include <intfc.h>
*/

/*
int system(char *com)
{
  printf("Can't execute command %s.\n",com);
}
*/

/*
    TIPI OBJEKTOV:

KIND | SUBK. | TIP
   V |   V   | spremenljivka
   V |   F   | klic funkcije
   V |   U   | klic uporabniske funkcije
   0 |       | konstanta
   0 |   l   | konstanta tipa longint
   0 |   d   | konstanta tipa double
   A |   i   | i. argument na splos. skladu (i je stevlka!)
   D |       | definicija
   D |   V   | definicija spremenljivke
   D |   F   | definicija funkcije
   P |       | kazalec na objekt

*/





void beep(void)
    /* Funkcija, ki opozori na napako.
    $A Igor <== okt99; */
{
err0();
fprintf(erf(),"Internal Calculator Error.\n");
err2();
}




int initobject(object o)
     /* Inicializira podat. strukturo tipa object */
{
if (o!=NULL)
{
  o->l=NULL;  o->r=NULL;  o->v=NULL; o->name=NULL;
  o->kind='@'; o->subkind='@'; o->priority=0;
  return 0;
} else
  return 1;
}



object newobject(void)
       /* Alocira prostor za nov element tipa _object,
       ta element inicializira in vrne kazalec nanj */
{
object o;
o=malloc(sizeof(*o));
initobject(o);
return(o);
}




int disp1obj(object *oo)
    /* Brise en sam objekt, na katerega kaze oo. Ce objekt vsebuje kako
    vrednost, brise tudi to. */
{
object o1;
int ret=0;
o1=*oo;
if (o1!=NULL)
{
  if (o1->l==NULL || o1->r==NULL) ret=1;
  if (o1->name!=NULL)
    free(o1->name);
  if (o1->v!=NULL)
  {
    /*
    if (o1->kind=='V' && o1->subkind=='U')    $$$ 
      free(o1->v);
    */
    
    disppointer((void **) &(o1->v));  /* $$$ */
    /*
    if (o1->kind=='0' && ((o1->subkind=='d') || o1->subkind=='l'))
      free(o1->v);
    */
  }
  free(o1);
  *oo=NULL;
}
return ret;
}



void disptree(object *o)
     /* Brise celotno drevo objektov. */
{
if (*o !=NULL)
{
  if ((*o)->l!=NULL)
    disptree(&((*o)->l));
  if ((*o)->r!=NULL)
    disptree(&((*o)->r));
  disp1obj(o);
  *o=NULL;
}
}




static int cmpobject(void *p1,void *p2)
    /* Primerja kazalca p1 in p2 tipa object po (...)->name. Ce sta p1 in p2
    razlicna od NULL, vrne funkcija kar cmpstrings(p1->name,p2->name), ce sta oba
    NULL, vrne 0, ce je le p1 NULL, vrne 2 (v tem primeru se smatra, da je p1
    vecji od p2), ce pa je le p2 NULL, vrne -2.
    $A Igor dec97; */ 
{
object o1,o2;
o1=p1; o2=p2;
if (o1!=NULL && o2!=NULL)
  return cmpstrings(o1->name,o2->name);
else if (o1==NULL)
{
  if (o2==NULL)
    return 0;
  else
    return 2;
} else if (o2==NULL)
  return -2;
return -2; /* samo zaradi prevajalnika */
}



static int cmpobjectstr(void *name,void *obj)
    /* Funkcija vrne 0, ce ima objekt obj ime name, 1, ce je name>obj->name,
    in -1, ce je name<obj->name.
    $A Igor<== sep99; */
{
if (obj!=NULL)
  return cmpstrings(name,( (object) obj)->name);
else
  return -2;
}


int findsortstackobject(stack st,int from,int to,char *name)
    /* Finds a calculator object named name on the stack st btween positions
    from and to and returns its position or 0 if the object is not found.
    $A Igor mar04; */
{
return findsortstack(st,name,from,to,cmpobjectstr);
}

void inssortstackobject(stack st,object o)
    /* Inserts the calc. object o on a sorted stack st in such a way that the
    stack remains sorted.
    $A Igor mar04; */
{
inssortstack(st,o,cmpobject);
}


static int cmpuserfunc(void *p1,void *p2)
    /* Primerja kazalca p1 in p2 tipa userfunc po (...)->name. Ce sta p1 in p2
    razlicna od NULL, vrne funkcija kar cmpstrings(p1->name,p2->name), ce sta oba
    NULL, vrne 0, ce je le p1 NULL, vrne 2 (v tem primeru se smatra, da je p1
    vecji od p2), ce pa je le p2 NULL, vrne -2.
    $A Igor dec97; */ 
{
userfunc u1,u2;
u1=p1; u2=p2;
if (u1!=NULL && u2!=NULL)
  return cmpstrings(u1->name,u2->name);
else if (u1==NULL)
{
  if (u2==NULL)
    return 0;
  else
    return 2;
} else if (u2==NULL)
  return -2;
return -2; /* samo zaradi prevajalnika */
}


static int cmpuserfuncstr(void *name,void *usr)
    /* Funkcija primerja name z usr->name s funkcijo cmpstrings (usr mora biti
    tipa userfunc) in vrne stevilo, ki ga vrne funkcija cmpstrings, ce pa je
    usr enak NULL, vrne -2.
    $A Igor <== sep99; */
{
if (usr!=NULL)
  return cmpstrings((char *) name, ((userfunc) usr)->name);
else
  return -2;
}



static void setelsymbsyst(stack tt,char *name,
                   char kind, char subkind,char priority)
    /* V 1. element tabele objektov tt vpise objekt,
    katerega polja ustrezajo parametrom funkcije. Funkcija tudi tvori naslednji
    element tabele in vrne kazalec nanj. To funkcijo uporablja le funkcija
    initsymbsyst.
    $A Igor <== dec97; */
{
object o;
o=newobject();
o->name=stringcopy(name);
o->kind=kind;
o->subkind=subkind;
o->priority=priority;
o->v=NULL;
o->l=o->r=NULL;
/*
pushstack(tt,o);
*/
inssortstack(tt,o,cmpobject);
}

void initsymbsyst(stack *st)
     /* Inicializira tabelo sistemskih (vgrajenih) simbolov. */
{
stack ref;
if (*st==NULL)
  *st=(stack) newstack(1);
ref=*st;
setelsymbsyst(ref,"+",'2','@',4);
setelsymbsyst(ref,"-",'2','@',4);
setelsymbsyst(ref,"*",'2','@',3);
setelsymbsyst(ref,"/",'2','@',3);
setelsymbsyst(ref,"%",'2','@',3);
setelsymbsyst(ref,"^",'2','@',2);
setelsymbsyst(ref,"P",'2','@',2);
setelsymbsyst(ref,"CP",'2','@',2);
setelsymbsyst(ref,"LOG",'2','@',2);
setelsymbsyst(ref,"MIN",'2','@',2);
setelsymbsyst(ref,"MAX",'2','@',2);
setelsymbsyst(ref,"(",'(','@',1);
setelsymbsyst(ref,")",')','@',1);
setelsymbsyst(ref,"[",'[','@',1);
setelsymbsyst(ref,"]",']','@',1);
setelsymbsyst(ref,"{",'{','@',1);
setelsymbsyst(ref,"}",'}','@',1);
setelsymbsyst(ref,"<",'2','@',5);
setelsymbsyst(ref,">",'2','@',5);
setelsymbsyst(ref,"=",'2','@',10);
setelsymbsyst(ref,"!",'1','@',1);
setelsymbsyst(ref,"!=",'2','@',5);
setelsymbsyst(ref,"<=",'2','@',5);
setelsymbsyst(ref,">=",'2','@',5);
setelsymbsyst(ref,"==",'2','@',5);
setelsymbsyst(ref,"&&",'2','@',6);
setelsymbsyst(ref,"||",'2','@',6);
setelsymbsyst(ref,":",'2','@',10);
setelsymbsyst(ref,",",'2','@',9);
setelsymbsyst(ref,"EQ",'1','@',1);
setelsymbsyst(ref,"_",'1','@',1);
setelsymbsyst(ref,"NEGV",'1','@',1);
setelsymbsyst(ref,"exp",'1','@',1);
setelsymbsyst(ref,"ln",'1','@',1);
setelsymbsyst(ref,"sqr",'1','@',1);
setelsymbsyst(ref,"sqrt",'1','@',1);
setelsymbsyst(ref,"abs",'1','@',1);
setelsymbsyst(ref,"sin",'1','@',1);
setelsymbsyst(ref,"cos",'1','@',1);
setelsymbsyst(ref,"tg",'1','@',1);
setelsymbsyst(ref,"ctg",'1','@',1);
setelsymbsyst(ref,"arcsin",'1','@',1);
setelsymbsyst(ref,"arccos",'1','@',1);
setelsymbsyst(ref,"arctg",'1','@',1);
setelsymbsyst(ref,"arcctg",'1','@',1);
setelsymbsyst(ref,"sh",'1','@',1);
setelsymbsyst(ref,"ch",'1','@',1);
setelsymbsyst(ref,"th",'1','@',1);
setelsymbsyst(ref,"cth",'1','@',1);
setelsymbsyst(ref,"arsh",'1','@',1);
setelsymbsyst(ref,"arch",'1','@',1);
setelsymbsyst(ref,"arth",'1','@',1);
setelsymbsyst(ref,"arcth",'1','@',1);
setelsymbsyst(ref,"st",'1','@',1);
setelsymbsyst(ref,"deg",'1','@',1);
setelsymbsyst(ref,"rad",'1','@',1);
setelsymbsyst(ref,"round",'1','@',1);
setelsymbsyst(ref,"trunc",'1','@',1);
setelsymbsyst(ref,"floor",'1','@',1);
setelsymbsyst(ref,"int",'1','@',1);
setelsymbsyst(ref,"frac",'1','@',1);
setelsymbsyst(ref,"sign",'1','@',1);
setelsymbsyst(ref,"positive",'1','@',1);
setelsymbsyst(ref,"pospart",'1','@',1);
setelsymbsyst(ref,"negative",'1','@',1);
setelsymbsyst(ref,"negpart",'1','@',1);
setelsymbsyst(ref,"double",'0','d',0);
setelsymbsyst(ref,"long",'0','l',0);
setelsymbsyst(ref,"string",'0','s',0);
}



ssyst newssyst(stack system)
      /* Zgradi sistem za simbolno racunanje. system je sklad s sistemskimi
      (vgrajenimi) objekti. */
{
ssyst ret;
ret=malloc(sizeof(*ret));
ret->strings=newstack(5);
ret->user=newstack(5);
ret->cuts=newstack(5);
ret->trees=(stack)newstack(5);
ret->syst=system;  /* (stack)newstack(5); */
if (ret->syst==NULL)
  initsymbsyst(& ret->syst);
ret->def=(stack)newstack(5);
ret->trash=(stack)newstack(5);
ret->fst=(stack)newstack(5);
return ret;
}


void dispssyst(ssyst *s)
     /* Zbrise sistem za simbolno racunanje */
{
ssyst ss;
ss=*s;
if (ss->strings!=NULL)
  dispstack(& ss->strings);
if (ss->cuts!=NULL)
  dispstack(& ss->cuts);
if (ss->trees!=NULL)
  dispstack( (stack *) & ss->trees);
if (ss->syst!=NULL)
  dispstack( (stack *) & ss->syst);
if (ss->def!=NULL)
  dispstack( (stack *) & ss->def);
if (ss->trash!=NULL)
  dispstack( (stack *) & ss->trash);
if (ss->fst!=NULL)
  dispstack( (stack *) & ss->fst);
free(ss);
*s=NULL;
}



void doubleobj(object o, double r)
    /* Objektu, ki predstavlja stevilo tipa double, priredi vrednost r.
    $A Igor <== okt99; */
{
double *x;
if (o==NULL)
{
  errfunc0("doubleobj");
  fprintf(erf(),"Calculator object is NULL.\n");
  errfunc2();
} else
{
  if (o->kind=='0' && o->subkind=='d')
  {
    if (o->v==NULL)
      o->v=malloc(sizeof(double));
    x=o->v;
    *x=r;
  } else
  {
    errfunc0("doubleobj");
    fprintf(erf(),"Calculator object is not of correct type (type %c-%c).\n",o->kind,o->subkind);
    fprintf(erf(),"Should be of type 0-d.\n");
    errfunc2();
  }
}
}

void longobj(object o, long l)
    /* Objektu, ki predstavlja stevilo tipa long, priredi vrednost l.
    $A Igor <== okt99; */
{
long *x;
if (o==NULL)
{
  errfunc0("longobj");
  fprintf(erf(),"Calculator object is NULL.\n");
  errfunc2();
} else
{
  if (o->kind=='0' && o->subkind=='l')
  {
    if (o->v==NULL)
      o->v=malloc(sizeof(long));
    x=o->v;
    *x=l;
  } else
  {
    errfunc0("longobj");
    fprintf(erf(),"Calculator object is not of correct type (type %c-%c).\n",o->kind,o->subkind);
    fprintf(erf(),"Should be of type 0-l.\n");
    errfunc2();
  }
}
}



static userfunc finduserfuncnamesort(stack syst,char *name)
       /* Na skladu syst najde 1. objekt z imenom name ter vrne njegovo vrednost
       (to se pravi kazalec na strukturo tipa _object). Ce taksnega objekta ne
       najde, vrne NULL. */
{
int i;
/*
i=findstack((stack) syst,name,1,-1,cmpuserfuncstr);
*/
i=findsortstack(syst,name,0,0,cmpuserfuncstr);
if (i>0)
  return syst->s[i];
else
  return NULL;
}



object findobjname(stack syst,char *name)
       /* Na skladu syst najde 1. objekt z imenom name ter vrne njegovo vrednost
       (to se pravi kazalec na strukturo tipa _object). Ce taksnega objekta ne
       najde, vrne NULL. */
{
int i;
i=findstack((stack) syst,name,1,-1,cmpobjectstr);
if (i>0)
  return syst->s[i];
else
  return NULL;
}


object findobjnamesort(stack syst,char *name)
       /* Na skladu syst najde 1. objekt z imenom name ter vrne njegovo
       vrednost (kazalec na strukturo tipa _object). Ce taksnega objekta ne
       najde, vrne NULL. Objekti morajo biti na sklatu syst sortirani po
       imenih.
       $A Igor sep99; */
{
int i;
i=findsortstack(syst,name,0,0,cmpobjectstr);
if (i>0)
  return syst->s[i];
else
  return NULL;
}


static int findstackobjname(stack syst,char *name)
       /* Na skladu syst najde 1. objekt z imenom name ter vrne njegovo zap.
       stevilko na skladu. Ce taksnega objekta ne najde, vrne -1. */
{
int i;
i=findstack((stack) syst,name,1,-1,cmpobjectstr);
return i;
}


static int findstackobjnamesort(stack syst,char *name)
       /* Na skladu syst najde 1. objekt z imenom name ter vrne njegovo zap.
       stevilko na skladu. Ce taksnega objekta ne najde, vrne -1. Objekti
       morajo biti na sklatu syst sortirani po imenih.
       $A Igor sep99; */
{
int i;
i=findsortstack(syst,name,0,0,cmpobjectstr);
return i;
}



char *strobj(object oo)
     /* vrne niz, ki predstavlja objekt o. to je tak niz, ki je za nek objekt
     najbolj specificen (npr. ime za objekt, ki predstavlja spremneljivko,
     ali niz, ki predstavlja stevilsko vrednost, za objekte, ki predstavljajo
     realna ali cela stevila.
     Niz, ki ka vrne funkcija, lahko brises z ukazom free!
     */
{
char s1[100],*s2,*ret;
if (oo==NULL)
  ret=NULL;
else
{
  if (oo->kind=='0')
  {
    if (oo->subkind=='d' || oo->subkind=='l')
    {
      sprintf(s1,"-:");
      s1[0]=oo->subkind;
      ret=stringcat(s1,oo->name);
    } else
    {
      ret=stringcopy(oo->name);
    }
  } else if(oo->kind=='D') /* Definicija funkcije ali spremenljivke */
  {
    sprintf(s1,"DEF__:");
    s1[4]=oo->subkind;
    ret=stringcat(s1,oo->name);
  } else if (oo->kind=='A') /* Argument finkcije */
  {
    sprintf(s1,"ARG:");
    s2=stringlong(oo->subkind);
    ret=stringcat(s1,s2);
    free(s2);
  } else if (oo->kind=='P')
  {
    ret=stringcopy("Ptr");
  } else
  {
    ret=stringcopy(oo->name);
  }
}
return ret;
}




int fprinttabobj(FILE *fp,stack tab)
    /* Izpise seznam objektov tab v datoteko fp */
{
int i,num,ret=0;
object oo;
char *str;
if (fp!=NULL && tab!=NULL)
{
  num=tab->n;
  if (num>0)
  {
    ret=0;
    for (i=1;i<=num; ++i)
    {
      oo=tab->s[i];
      fprintf(fp,"%c %c %i %s\n",oo->kind,oo->subkind,oo->priority,oo->name);
    }
    fprintf(fp,"\n");
    for (i=1; i<=num;++i)
    {
      oo=tab->s[i];
      str=strobj(oo);
      fprintf(fp," %s ",str);
      if (str!=NULL)
      {
        free(str);
        str=NULL;
      }
    }
    fprintf(fp,"\n");
  } else ret=1;
}
return ret;
}


int printtabobj(stack tab)
    /* Izpise seznam objektov tt na zaslon */
{
  return fprinttabobj(stdout,tab);
}



static char necessary(char ch)
     /* Vrne 0, ce je znak ch tak, da ga moramo izpustiti
     pri predelavi niza znakov za rezanje */
{
if (ch==' ' || ch=='\n' || ch=='\r')
  return(0);
else
  return(1);
}

char *modifyexp(char *expression)
     /* Vrne predelan niz expression, ki je pripravljen za
     rezanje na elemente. Iz niza odstrani vse presledke in
     znake za novo vrstico.
     $A Igor <== okt99; */
{
size_t l,spaces,i,j;
char *returned=NULL;
l=strlen(expression);
spaces=0;
if (expression!=NULL)
{
  /*
  for (i=0; i<l; ++i)
    if (!necessary(expression[i]))
      ++spaces;
  returned=malloc((l-spaces)+1);
  */
  returned=malloc(l+1);
  j=0;
  for (i=0;i<l;++i)
  {
    if (necessary(expression[i]))
    {
      returned[j]=expression[i];
      ++j;
    }
  }
  returned[j]='\0';
}
return returned;
}




stack cutexpression(char *expression,stack symbsyst)
       /* Izraz, ki ga predstavlja niz expression, razdeli na osnovne elemente,
       ki jih pretvori v simbole. To je prva obdelava izraza. funkcija vrne
       sklad objektov, ki nastopajo v istem vrstnem redu kot simboli v nizu.
       syst je sklad, na katerem so nalozeni sistemski objekti. */
{
int length,i;
char *str,*modexp,*strel;
stack list;
object oo,el1;
int numel;
char *end;
double xd;
numel=0;
list=NULL;
oo=NULL;
str=NULL;
modexp=NULL;
modexp=modifyexp(expression);
str=modexp;
list=newstack(1);
while (strlen(str)>0)
{
  if (str[0]=='\"') /* Niz znakov */
  {
    length=1;
    while(str[length]!='\"')
      ++length;
    strel=stringncopy(str+1,length-1);
    oo=newobject();
    pushstack((stack)list,oo);
    oo->kind='0';
    oo->subkind='s';
    oo->v=strel;
    oo->name=stringncopy(str,length+1);
    oo->priority=0;
    oo=NULL;
    str=str+length+1;
    strel=NULL;
    ++numel;
  } else if (letter(str[0]))
  {
    /* 1. znak niza str je crka, torej clen predstavlja ime spremenljivke,
    funkcije ali operatorja */
    /* najprej se ugotovi dolzina izraza, ki predstavlja ime */
    length=1;
    while (letter(str[length]) || decdigit(str[length]) || str[length]=='_')
      ++length;
    strel=stringncopy(str,length);
    for (i=1;i<=length;++i)
      ++ str; /* str spet kaze zacetek nerazrezanega izraza */
    oo=newobject();
    pushstack((stack) list,oo);
     /* Preveri se, ali obstaja kak objekt z danim imenom v globalni tabeli
    objektov (symbsyst). Ce obstaja, se polja objekta prepisejo na polja
    objekta, ki ga vpisujemo v seznam list. */
    el1=findobjname(symbsyst,strel);
    if (el1!=NULL)
    {
      *oo=*(el1);
    } else
    {
      oo->kind='V';     /* Spremenljivka */
      oo->subkind='V';
    }
    oo->name=strel;
    strel=NULL;
    ++numel;
  } else if (str[0]=='-')
  {
    if (numel==0 || oo->name[0]=='(' || oo->name[0]=='[' || oo->name[0]=='{'
         || oo->kind=='2')
    {
      /* Ce je - 1. element ali ce je predhodnji element eden od oklepajev,
      potem je lahko ali del stevila ali pa pomeni znak za funkcijo 'negativna
      vrednost' */
      length=nstrnum(str);
      if (length<=0) /* Minus pomeni funkcijo vzemi neg. vred. */
      {
        ++str;
        oo=newobject();
        pushstack((stack)list,oo);
        el1=findobjname(symbsyst,"NEGV");
        /* Tak element je gotovo v tabeli symbsyst */
        if (el1!=NULL)
        {
          *oo=*(el1);
        } else
        {
          oo->kind='0';
          oo->subkind='@';
        }
        oo->name=stringcopy("-");
        ++numel;
      } else /* znak - je del stevila */
      {
        strel=stringncopy(str,length);
        for (i=1;i<=length;++i)
          ++ str; /* str spet kaze zacetek nerazrezanega izraza */
        oo=newobject();
        pushstack((stack)list,oo);
        oo->kind='0';
        if (floatstr(strel))
        {
          oo->subkind='d';
          xd=strtod(strel,&end);
          doubleobj(oo,xd);
        } else
        {
          oo->subkind='l';
          xd=strtol(strel,&end,10);
          longobj(oo,(long) xd);
        }
        oo->name=strel;
        strel=NULL;
        ++numel;
      }
    } else
    {
      /* znak - pomeni dvoparametricen operator */
      ++str;
      oo=newobject();
      pushstack((stack)list,oo);
      el1=findobjname(symbsyst,"-");
      /* Tak element je gotovo v tabeli symbsyst */
      if (el1!=NULL)
      {
        *oo=*(el1);
      } else
      {
        oo->kind='0';
        oo->subkind='@';
      }
      oo->name=stringcopy("-");
      ++numel;
    }
  } else if (str[0]=='+' || str[0]=='*' || str[0]=='/' || str[0]=='^' 
    || str[0]=='%' || str[0]=='('
   || str[0]==')' || str[0]=='[' || str[0]==']' || str[0]=='{' || str[0]=='}'
   /* || str[0]=='=' */ || str[0]==':' || str[0]==',' || str[0]=='_' )
  {
    strel=stringcopy("-");
    strel[0]=str[0];
    ++str;
    oo=newobject();
    pushstack((stack)list,oo);
    el1=findobjname(symbsyst,strel);
    /* Tak element je gotovo v tabeli symbsyst */
    if (el1!=NULL)
    {
      *oo=*(el1);
    } else
    {
      oo->kind='0';
      oo->subkind='@';
    }
    oo->name=strel;
    strel=NULL;
    ++numel;
  } else if (str[0]=='=' || str[0]=='<' || str[0]=='>' || str[0]=='!')
  {
    length=1;
    if (str[1]=='=')
      length=2;
    strel=stringncopy(str,length);
    str+=length;
    oo=newobject();
    pushstack((stack)list,oo);
    el1=findobjname(symbsyst,strel);
    /* Tak element je gotovo v tabeli symbsyst */
    if (el1!=NULL)
    {
      *oo=*(el1);
    } else
    {
      oo->kind='0';
      oo->subkind='@';
    }
    oo->name=strel;
    strel=NULL;
    ++numel;
  }else if (str[0]=='&' || str[0]=='|')
  {
    length=1;
    if (str[1]=='&' || str[1]=='|')
      length=2;
    strel=stringncopy(str,length);
    str+=length;
    oo=newobject();
    pushstack((stack)list,oo);
    el1=findobjname(symbsyst,strel);
    /* Tak element je gotovo v tabeli symbsyst */
    if (el1!=NULL)
    {
      *oo=*(el1);
    } else
    {
      oo->kind='0';
      oo->subkind='@';
    }
    oo->name=strel;
    strel=NULL;
    ++numel;
  } else if ((length=nstrnum(str))>0) /* naslednji element je stevilo */
  {
    strel=stringncopy(str,length);
    for (i=1;i<=length;++i)
      ++ str; /* str spet kaze zacetek nerazrezanega izraza */
    oo=newobject();
    pushstack((stack)list,oo);
    oo->kind='0';
    if (floatstr(strel))
    {
      oo->subkind='d';
      xd=strtod(strel,&end);
      doubleobj(oo,xd);
    } else
    {
      oo->subkind='l';
      xd=strtol(strel,&end,10);
      longobj(oo,(long) xd);
    }
    oo->name=strel;
    strel=NULL;
    ++numel;
  } else
  {
    ++str;
    beep();
  }
}
free(modexp);
return(list);
}



void displistobj(stack *objlist)
    /* Zbrise seznam objektov, ki ga naredi funkcija cutexpression, in sicer
    tako, da niso prizadeti objekti, ki so uporabljeni v drevesnih strukturah
    (na skladu brise torej samo oklepaje).
    $A Igor okt99; */
{
/*
KOMENTAR: Izkazalo se je, da je bolje, ce je ta koda v maketree().
int i;
object oo;
stack list=NULL;
if (objlist!=NULL)
  list=*objlist;
if (list!=NULL)
  if (list->n!=NULL)
    for (i=1;i<=list->n;++i)
    {
      oo=list->s[i];
      if (oo->name[0]=='(' || oo->name[0]=='[' || oo->name[0]=='{' || 
       oo->name[0]==')' || oo->name[0]==']' || oo->name[0]=='}')
      disp1obj((object *) &(list->s[i]) );
    }
*/
dispstack(objlist);
}



int arrangelistobj(stack t)
    /* Uredi sklad objektov t. Preveri tudi, ce so vsi oklepaji zakljuceni.
    ce je kaj narobe, vrne 1, drugace 0. Funkcija tudi dodatno postavi tipe
    nekaterih objektov. To funkcijo se uporablja vedno takoj za funkcijo
    cutexpression.*/
{
int num,i,j1,j2,j3,retval=0,bracmismatch=0;
char refch;
object oo;
num=t->n;
j1=j2=j3=0;
for (i=1; i<=num;++i)
{
  oo=t->s[i];
  switch(oo->kind)
  {
    case '(' : {++j1; break;};
    case ')' : {--j1; break;};
    case '[' : {++j2; break;};
    case ']' : {--j2; break;};
    case '{' : {++j3; break;};
    case '}' : {--j3; break;};
  }
  if (j1<0 || j2<0 || j3<0)
  {
    if (!bracmismatch)
    {
      errfunc0("arrangelistobj");
      fprintf(erf(),"Parentheses do not match in the expression. Cut expression:\n");
      fprinttabobj(erf(),t);
      errfunc2();
    }
    retval=1; bracmismatch=1;
  }
  if (oo->kind=='V')
  {
    if (i<num)
    {
      refch=((object)t->s[i+1])->kind;
      if (refch=='('||refch=='['||refch=='{')
      {
        /* Ce stoji simbol z nekim imenom, ki ni definirano v globalnem sistemu
        (to vemo po tem, da je vrsta eneka '0'), pred odprtim oklepajem, potem
        je to definirana funkcija. */
        /* oo->kind='F'; */
        oo->subkind='F';
        oo->priority=1;
      }
    }
  }
}
return retval;
}



static void putright(object *t, object el)
{
object ref;
if (*t==NULL)
  *t=el;
else
{
  ref=*t;
  while (ref->r!=NULL)
    ref=ref->r;
  ref->r=el;
}
}

int ref;

object _maketree1(stack list,int *pos,object *ret)
       /* iz tabele objektov naredi drevo, vrne kazalec na koren drevesa. */
{
object oo;
char end=0;
char priority;
ref=*pos;
while (ref<=list->n && !end)
{
  switch( ( (object) (list->s[ref]) )->kind)
  {
    case '0': case '@':
      putright(ret,list->s[ref]);
      ++ref;
      break;
    case ')': case ']': case '}':
      end=1;
      ++ref;
      break;
    case '(': case '[': case '{':
      ++ref;
      oo=NULL;
      _maketree1(list,&ref,&oo);
      priority=oo->priority;
      oo->priority=0;
      putright(ret,oo);
      _maketree1(list,&ref,ret);
      oo->priority=priority;
      return *ret; /* Bistceno je, da v tem trenutku izstopimo iz funkcije.
      Drugace pride do nepravilnosti, ko imamo objekt v dvojnem oklepaju. */
      break;
    case '1': case 'f':
      oo=list->s[ref];
      putright(ret,oo);
      ++ref; ++ref; /* ker je 1. naslednji oklepaj -PREMISLI !! */
      /* oo->r=*/ _maketree1(list,&ref,/*ret*/&(oo->r));
      break;
    case '2':
      if ( ( (object) (list->s[ref]) )->priority >= (*ret)->priority)
      {
        ( (object) (list->s[ref]) )->l=*ret;
        *ret=list->s[ref];
      } else
      {
        oo=*ret;
        while ( ( (object) (list->s[ref]) )->priority < oo->r->priority)
          oo=oo->r;
        ( (object) (list->s[ref]) )->l=oo->r;
        oo->r=list->s[ref];
      }
      ++ref;
      break;
  }
}
return *ret;
}




static object _maketree(stack list,int *pos,object *ret)
       /* iz tabele objektov naredi drevo, vrne kazalec na koren drevesa. */
{
object oo;
char end=0;
char priority;
while (*pos<=list->n && !end)
{
  switch( ( (object) (list->s[*pos]) )->kind)
  {
    case '0': case '@':
      putright(ret,list->s[*pos]);
      ++*pos;
      break;
    case 'V':
      if (((object) list->s[*pos])->subkind=='V')
      {
        putright(ret,list->s[*pos]);
        ++*pos;
      } else if (((object) list->s[*pos])->subkind=='F')
      {
        oo=list->s[*pos];
        putright(ret,oo);
        ++*pos; ++*pos; /* ker je 1. naslednji oklepaj -PREMISLI !! */
        /* oo->r=*/ _maketree(list,pos,/*ret*/&(oo->r));
      }
      break;
    case ')': case ']': case '}':
      end=1;
      ++*pos;
      break;
    case '(': case '[': case '{':
      ++*pos;
      oo=NULL;
      _maketree(list,pos,&oo);
      priority=oo->priority;
      oo->priority=0;
      putright(ret,oo);
      _maketree(list,pos,ret);
      oo->priority=priority;
      return *ret; /* Bistveno je, da v tem trenutku izstopimo iz funkcije.
      Drugace pride do nepravilnosti, ko imamo objekt v dvojnem oklepaju. To se
      zgodi zaradi tega, ker se *ret ze poveca prioriteta (pri 2. zaklepaju),
      nato pa se gre v isti funkciji tvoriti drevo naprej. Pravilno je, da se
      pri 2. oklepaju prioriteta sicer povisa, vendar pa se po izhodu iz
      funkcije spet zniza zaradi 1. oklepaja. */
      break;
    case '1': /* case 'f': */
      oo=list->s[*pos];
      putright(ret,oo);
      /* PREJSNJA KODA: 
      ++*pos; 
      ++*pos;   /* $$MARK ker je 1. naslednji oklepaj -PREMISLI !! 
      */
      /* Popravljena koda: */
      ++*pos;
      ++*pos; 
      /*
      if (*pos>=list->n)
      {
        object oo1=list->s[*pos];
        if (cmpstrings(oo1->name,"(")==0)
          ++*pos;
      }
      */
      /* oo->r=*/ _maketree(list,pos,/*ret*/&(oo->r));
      break;
    case '2':
      if ( ( (object) (list->s[*pos]) )->priority >= (*ret)->priority)
      {
        ( (object) (list->s[*pos]) )->l=*ret;
        *ret=list->s[*pos];
      } else
      {
        oo=*ret;
        while ( ( (object) (list->s[*pos]) )->priority < oo->r->priority)
          oo=oo->r;
        ( (object) (list->s[*pos]) )->l=oo->r;
        oo->r=list->s[*pos];
      }
      ++*pos;
      break;
  }
}
return *ret;
}


object maketree(stack list)
    /* iz tabele objektov naredi drevo, vrne kazalec na koren drevesa.
    $A Igor <== okt99; */
{
int pos=1,i;
object obj=NULL,ret,oo;
ret= _maketree(list,&pos,&obj);
/* Zbrisejo se vsi objekte na skladu list, ki niso uporabljeni v drevesni
strukturi (to so vsi oklepaji): */
if (list!=NULL)
  if (list->n>0)
    for (i=1;i<=list->n;++i)
    {
      oo=list->s[i];
      if (oo!=NULL)
        if (oo->name[0]=='(' || oo->name[0]=='[' || oo->name[0]=='{' || 
         oo->name[0]==')' || oo->name[0]==']' || oo->name[0]=='}')
      disp1obj((object *) &(list->s[i]) );
    }
return ret;
}


static void _findtreeall(object tree,void *ptr,
              int *cmp(void *p1, void *p2) ,stack ret)
       /* V drevesu objektov tree najde vse objekte, ki so enaki objektu
       ptr v smislu funkcije cmp, ki mora vrniti 0, ce sta oba argumenta
       enaka. Najdeni objekti se nalozijo na sklad ret.
       OPOMBA: Ni nujno, da je ptr ravno tipa object.
       POZOR! 1. argument, ki se nalozi pri klicu funkcije cmp, je ptr, zato mora
       biti tudi funkcija cmp narejena tako, da vzame ptr kot 1. argument. */
{
if (tree->r!=NULL)
  _findtreeall(tree->r,ptr,cmp,ret);
if (tree->l!=NULL)
  _findtreeall(tree->l,ptr,cmp,ret);
if ( cmp(ptr,tree)==0)
  pushstack(ret,tree);
}


static stack findtreeall(object tree,void *ptr,
              int *cmp(void *p1, void *p2) )
       /* V drevesu objektov tree najde vse objekte, ki so enaki objektu
       ptr v smislu funkcije cmp, ki mora vrniti 0, ce sta oba argumenta
       enaka. Najdeni objekti se nalozijo na sklad, ki ga funkcija vrne.
       OPOMBA: Ni nujno, da je ptr ravno tipa object.
       POZOR! 1. argument, ki se nalozi pri klicu funkcije cmp, je ptr, zato mora
       biti tudi funkcija cmp narejena tako, da vzame ptr kot 1. argument. */
{
stack ret;
ret=newstack(5);
_findtreeall(tree,ptr,cmp,ret);
return ret;
}




static void _treelist(object tree,stack list)
      /* Na sklad list potisne vse elemente seznama, ki ga predstavlja drevo
      tree. Ce objekt, na katerega kaze tree, ni vejica, funkcija potisne na
      sklad en sam clen. */
{
if (tree!=NULL)
{
  if (tree->kind=='2' && tree->name[0]==',')
  {
    _treelist(tree->l,list);
    _treelist(tree->r,list);
  } else
    pushstack((stack) list,tree);
}
}

stack treelist(object tree)
      /* Vrne sklad, na katerega potisne vse elemente seznama, ki ga predstavlja
      drevo tree. Ce objekt, na katerega kaze tree, ni vejica, funkcija potisne
      na sklad en sam clen. Funkcija vrne sklad, na katerega je potisnila
      elemente seznama. */
{
stack s;
s=(stack)newstack(5);
_treelist(tree,s);
return s;
}

static void findarguments(object tree,stack list)
     /* V drevesu objektov tree najde vse objekte, ki imajo enako ime kot
     kateri od objektov na skladu list, ter jih spremeni v objekte tipa
     argument funkcije z isto zaporedno stevilko, kot jo ima objekt na skladu
     z istim imenom. */
{
int i;
if (tree->l!=NULL)
  findarguments(tree->l,list);
if (tree->r!=NULL)
  findarguments(tree->r,list);
if ((i=findstackobjname(list,tree->name))>0)
{
  free(tree->name);
  tree->name=NULL;
  tree->kind='A';
  tree->subkind=(char) i;
}
}

static void setargnum(object tree,int *add)
      /* Ustrezno poveca zaporedne stevilke argumentov definirane funkcije
      znotraj vgnezdenih funkcij. Zaporedne stevilke poveca za skupno stevilo
      argumentov vseh predgodno vgnezdenih funkcij. */
{
if (tree->kind=='V' && tree->subkind=='F')
{
  int i;
  object oo;
  int addprev;
  stack aux=NULL;
  /* Naleteli smo na novo vgnezdeno funkcijo. Argumentom klica te funkcije se,
  ce se nanasajo na sklad, povecajo referencne stevilke le za *add. Vsem pos-
  drevesom teh argumentov pa se referencne stevilke povisajo dodatno se za
  stevilo klicanih argumentov doticne funkcije. */
  aux=treelist(tree->r);  /* aux postane seznam klicanih argumentov finkcije */
  if (aux->n>0)
  {
    addprev=*add;
    *add+=aux->n;
    for (i=1; i<=aux->n;++i)
    {
      oo=aux->s[i];
      /* Ce je doticni argument referenca na sklad, mu povecamo referencno
      stevilko za stari *add: */
      if (oo->kind=='A')
        oo->subkind+=addprev;
      else
      /* Drugace se povecajo referencne stevilke v poddrevesih za novi *add: */
      {
        /*
        if (oo->l!=NULL)
          setargnum(oo->l,add);
        if (oo->r!=NULL)
          setargnum(oo->r,add);
        */
        setargnum(oo,add);
      }
    }
    /* Ko je delo opravljeno, mora dobiti *add nazaj staro vrednost: */
    *add=addprev;
    if (aux!=NULL)
      dispstack((stack *) &aux);
  }
} else
{
  /* Ce drevo tree na predstavlja klica funkcije, se izvrsi normalno povecevanje
  referencnih stevilk: */
  if (tree->kind=='A')
    tree->subkind+=*add;
  else
  {
    if (tree->l!=NULL)
      setargnum(tree->l,add);
    if (tree->r!=NULL)
      setargnum(tree->r,add);
  }
}
}


void puttreetolist(object put,stack *list1,stack *trash1,stack user)
     /* Objekt put vkljuci v seznam list. *trash1 so smeti - na ta sklad
     nalagamo mrtve objekte. user je seznam, na katerem najde ta funkcija
     navodila za uporabnisko funkcijo. Pri uporabniskih funkcijah se v *put->v
     ne shrane kazalec na obicajno definicijo funkcije, temvec na objekt tipa
     userfunc, ki ga ta rutina najde na skladu user in ima isto ime kot uporab.
     definirana funkcija.
     OPOMBA: Pred izvrsitvijo te funkcije imajo uporabniske funkcije podvrsto
     'F' namesto 'U'.
     $A Igor <== sep99; */
{
object obj,*point;
userfunc usf;
int place,ii;
stack list,trash,aux;
if (*list1==NULL)
  *list1=(stack)newstack(5);
list=*list1;
if (*trash1==NULL)
  *trash1=(stack)newstack(5);
trash=*trash1;
if (put->kind=='V')
{
  if (put->subkind=='F')
  {
    /* Ce gre za funkcijo (po dosedanji specifikaciji), se najprej preveri, ali
    ni to morda v resnici uporabniska funkcija; V tem primeru podvrsta objekta
    namesto 'F' postane 'U'. */
    usf=finduserfuncnamesort(user,put->name);
    if (usf!=NULL)
    {
      put->subkind='U';
      put->v=malloc(sizeof(userfunc));
      *( (userfunc*) put->v)=usf;
      if (put->r!=NULL)
        puttreetolist(put->r,list1,trash1,user);
      if (usf->put!=NULL)
        usf->put(put,usf->putdata);
    }
  }
  if (put->subkind=='V' || put->subkind=='F')
  /* Spremenljivka ali klic funkcije. Vrednost postane kazalec na definicijo. */
  {
    /* Poisce se mesto na skladu list, ki vsebuje definicijo s takim imenom: */
    /*
    place=findstack((stack) list,put->name,1,-1,cmpobjectstr);
    */
    place=findsortstack(list,put->name,0,0,cmpobjectstr);
    if (place<=0)
    {
      
      /* $$ */
      /*
      printf("\n\nPOZOR 1:\nObjekt z imenom %s se ne obstaja!\n\n",put->name);
      */
      
      /* V tabeli list se ni definicije te spremenljivke, zato se tvori na novo */
      obj=newobject();
      /*
      pushstack( (stack) list,obj);
      */
      obj->kind='D';
      obj->subkind=put->subkind;
      obj->name=stringcopy(put->name);
      /*
      place=list->n;
      
      
      place=placesortstack(list,obj,cmpobject);
      */
      place=inssortstack(list,obj,cmpobject);
      
    }
    point=malloc(sizeof(*point));
    *point=list->s[place];
    put->v=point;
    /*
    put->v=malloc(sizeof(object));
    *( (object *) put->v)=list->s[place];
    */
    if (put->subkind=='F')
      if (put->r!=NULL)
        puttreetolist(put->r,list1,trash1,user);
  }
} else if (put->kind=='2' && put->name[0]==':')  /* Definicija sprmenljivk in funkcij */
{
  if (put->l->kind=='V' && put->l->subkind=='V')
  {
    /* Definicija spremenljivke. */
    /* pushstack((stack)trash,put); $$$ */ /* Dvopicje damo na sklad trash, ker bi bil to
    drugace mrtev objekt in bi ga lahko pozabili brisati. */
    /* pushstack((stack)trash,put->l); */  /* $$$ */
    if (put->name!=NULL)
      free(put->name);
    put->name=NULL;
    put->kind='P';
    put->subkind='@';
    put->priority=1;
    /* Zgornje prireditve se izvedejo zato, da je mozno ovrednotiti na primer
    izraze oblike 3*(x:a+b), kar je podobno kot v sintaksi jezika c. */
    /* Poisce se mesto na skladu list, ki vsebuje definicijo s takim imenom: */
    /*
    place=findstack((stack) list,put->l->name,1,-1,cmpobjectstr);
    */
    place=findsortstack(list,put->l->name,0,0,cmpobjectstr);
    if (place<=0)
    {
      
      /* $$ */
      /*
      printf("\n\nPOZOR 2:\nObjekt z imenom %s se ne obstaja!\n\n",put->l->name);
      */
      
      /* V tabeli list se ni definicije te spremenljivke, zato se tvori na novo */
      obj=newobject();
      /*
      pushstack( (stack) list,obj);
      */
      obj->kind='D';
      obj->subkind=put->l->subkind;
      obj->name=stringcopy(put->l->name);
      /*
      place=list->n;
      */
      place=inssortstack(list,obj,cmpobject);
      
    }
    obj=list->s[place];
    /* Definicija spremenljivke se zakljuci. Se prej se morebitna stara
    definicija potisne na sklad trash, da se ne bi slucajno kaj izgubilo: */
    if (obj->r!=NULL)
    {
    
      /* pushstack((stack) trash,obj->r); */  /* $$$ */
      disptree(&(obj->r)); /* $$$ */
    }
    obj->r=put->r;
    put->r=NULL;
    disptree(&(put->l));  /* $$$ */
    put->l=NULL;
    point=malloc(sizeof(*point));
    *point=obj;
    put->v=point;
    puttreetolist(obj->r,list1,trash1,user);
  } else if (put->l->kind=='V' && put->l->subkind=='F')
  {
    /* Definicija funkcije. */
    aux=treelist(put->l->r); /* seznam argumentov funkcije */
    pushstack((stack)trash,put); /* Dvopicje damo na sklad trash, ker bi bil to
    drugace mrtev objekt in bi ga lahko pozabili brisati. */
    /* pushstack((stack)trash,put->l); */  /* $$$ */
    if (put->name!=NULL)
      free(put->name);
    put->name=NULL;
    put->kind='P';
    put->subkind='@';
    put->priority='1';
    /* Zgornje prireditve se izvedejo zato, da je mozno ovrednotiti na primer
    izraze oblike 3*(x:a+b), kar je podobno kot v sintaksi jezika c. */
    /* Poisce se mesto na skladu list, ki vsebuje definicijo s takim imenom: */
    /*
    place=findstack((stack) list,put->l->name,1,-1,cmpobjectstr);
    */
    place=findsortstack(list,put->l->name,0,0,cmpobjectstr);
    if (place<=0)
    {
      
      /* $$ */
      /*
      printf("\n\nPOZOR 3:\nObjekt z imenom %s se ne obstaja!\n\n",put->l->name);
      */
      
      /* V tabeli list se ni definicije te spremenljivke, zato se tvori na novo */
      obj=newobject();
      /*
      pushstack( (stack) list,obj);
      */
      obj->kind='D';
      obj->subkind=put->l->subkind;
      obj->name=stringcopy(put->l->name);
      /*
      place=list->n;
      
      place=placesortstack(list,obj,cmpobject);
      */
      place=inssortstack(list,obj,cmpobject);
    }
    obj=list->s[place];
    /* Definicija spremenljivke se zakljuci. Se prej se morebitna stara
    definicija potisne na sklad trash, da se ne bi slucajno kaj izgubilo: */
    if (obj->r!=NULL)
    {
    
      /* pushstack((stack) trash,obj->r); */  /* $$$ */
      disptree(&(obj->r)); /* $$$ */
    }
    obj->r=put->r;
    put->r=NULL;
    point=malloc(sizeof(*point));
    *point=obj;
    put->v=point;
    findarguments(obj->r,aux);
    disptree(&(put->l));  /* $$$ */
    /* put->l=NULL; */
    dispstack((stack *) &aux);
    ii=0;
    setargnum(obj->r,&ii);
    puttreetolist(obj->r,list1,trash1,user);
  }
} else
{
  if (put->l!=NULL)
    puttreetolist(put->l,list1,trash1,user);
  if (put->r!=NULL)
    puttreetolist(put->r,list1,trash1,user);
}
}





static void  disppaper(stack *pap)
      /* Sprosti papir st (t.j. sklad, na katerem so spomin. bufferji) */
{
int i;
if (pap!=NULL)
{
  for (i=1;i<=(*pap)->n;++i)
    dispmembuf((membuf *) &((*pap)->s[i]));
  dispstack(pap);
}
}



void fprintpaper(FILE *fp,stack pap)
    /* V datoteko fp izpise vsebino papirja pap. Papir je sklad, na katerem so
    spominski bufferji tipa membuf.
    $A Igor jan02; */
{
int i,j,last;
membuf m;
if (pap!=NULL && fp!=NULL)
{
  fprintf(fp,"\nNEW FUNCTION FOR PRINTING TREES:\n");
  for (i=1;i<=pap->n;++i)
  {
    if ((m=pap->s[i])!=NULL)
    {
      last=m->r-1;
      while (m->b[last]==' ' || m->b[last]=='\0' && last>=0)
        --last;
      for (j=0;j<=last;++j)
        fputc(m->b[j],fp);
    }
    #ifdef DOSWN
      fputc('\r',fp);
    #endif
    fputc('\n',fp);
  }
}
}



static void printchartopaper(stack pap,int row,int col,char c)
    /* Na papir pap na mestih (row,col) zapise znak c.
    $A Igor jan02; */
{
int ex=20; /* Excess za alokacijo vrstic */
int r=0,i;
membuf m;
if (pap->n<row)
{
  /* Dodajanje vrstice: */
  insstack(pap,(m=newmembuf(col+1+ex)),row);
  /* Alokacija vrstice, buffer zapolnimo s presledki, zadnji znak pa postane '\0': */
  for (i=0;i<m->r;++i)
    m->b[i]=' ';
  m->b[m->r-1]='\0';
} else if ((m=pap->s[row])==NULL)
{
  /* Alokacija vrstice, buffer zapolnimo s presledki, zadnji znak pa postane '\0': */
  pap->s[row]=(m=newmembuf(col+1+ex));
  for (i=0;i<m->r;++i)
    m->b[i]=' ';
  m->b[m->r-1]='\0';
} else if ((r=m->r)<col+1)
{
  /* Realokacija, znake od prejsnjega zadnjega do konca zapolnimo s presledki
  in dodamo '\0' na koncu: */
  increasemembufex(m,col+1,ex);
  for (i=r-1;i<m->r;++i)
    m->b[i]=' ';
  m->b[m->r-1]='\0';
}
m->b[col-1]=c;
}


static void papertree(object d,int *x,int y,char pod,int *k,stack *papaddr)
{
char *st;
int l,i,k1,k2;
int xx,yy,ii;
stack pap;
if (d!=NULL && papaddr!=NULL)
{
  if (*papaddr==NULL)
    *papaddr=newstack(20);
  pap=*papaddr;
  papertree(d->l,x,y+2,':',&k1,papaddr);
  st=strobj(d);
  l=strlen(st);
  xx=*x; yy=y;
  for (ii=1;ii<= (int) strlen(st);++ii)
  {
    if(yy>0 && xx>0)
      printchartopaper(pap,yy,xx,st[ii-1]);
    ++xx;
  }
  *k=*x+(l/2);
  if (y-1>0 && *k>0)
    printchartopaper(pap,y-1,*k,pod);
  if (d->l!=NULL)
  {
    for (i=k1+1; i<=*k-1; ++i)
      if (y+1>0 && i>0)
        printchartopaper(pap,y+1,i,'-');
  }
  if (d->l==NULL)
  {
    if (d->r==NULL)
      if (y+1>0 && *k>0)
        printchartopaper(pap,y+1,*k,' ');
    else
      if (y+1>0 && *k>0)
        printchartopaper(pap,y+1,*k,'"');
  } else
  {
    if (d->r==NULL)
      if (y+1>0 && *k>0)
        printchartopaper(pap,y+1,*k,'$');
    else
      if (y+1>0 && *k>0)
        printchartopaper(pap,y+1,*k,'^');
  }
  *x+=l+1;
  papertree(d->r,x,y+2,':',&k2,papaddr);
  if (d->r!=NULL)
  {
    for (i=*k+1;i<=k2-1;++i)
      if (y+1>0 && i>0)
        printchartopaper(pap,y+1,i,'-');
  }
}
}



static void papertreefull(object d,int *x,int y,char pod,int *k,stack *papaddr)
{
char *st;
int l,i,k1,k2;
int xx,yy,ii;
object *point;
stack pap;
if (d!=NULL && papaddr!=NULL)
{
  if (*papaddr==NULL)
    *papaddr=newstack(20);
  pap=*papaddr;
  if (d->kind=='V' && d->subkind=='V' && d->r==NULL)
  {
    if (d->v!=NULL)
    {
      point=d->v;
      d->r=*point;
      /* Za ta trenutek postane desna veja d objekt, na katerega kaze *(d->v). */
      papertreefull(d,x,y,pod,k,papaddr);
      d->r=NULL;
    }
  } else if (d->kind=='V' && d->subkind=='F' && d->l==NULL)
  {
    if (d->v!=NULL)
    {
      point=d->v;
      d->l=*point;
      /* Za ta trenutek postane desna veja d objekt, na katerega kaze *(d->v). */
      papertreefull(d,x,y,pod,k,papaddr);
      d->l=NULL;
    }
  } else if (d->kind=='P' && d->r==NULL)
  {
    if (d->v!=NULL)
    {
      point=d->v;
      d->r=*point;
      /* Za ta trenutek postane desna veja d objekt, na katerega kaze *(d->v). */
      papertreefull(d,x,y,pod,k,papaddr);
      d->r=NULL;
    }
  } else
  {
    papertreefull(d->l,x,y+2,':',&k1,papaddr);
    st=strobj(d);
    l=strlen(st);
    xx=*x; yy=y;
    for (ii=1;ii<= (int) strlen(st);++ii)
    {
      if(yy>0 && xx>0)
        printchartopaper(pap,yy,xx,st[ii-1]);
      ++xx;
    }
    *k=*x+(l/2);
    if (y-1>0 && *k>0)
      printchartopaper(pap,y-1,*k,pod);
    if (d->l!=NULL)
    {
      for (i=k1+1; i<=*k-1; ++i)
        if (y+1>0 && i>0)
          printchartopaper(pap,y+1,i,'-');
    }
    if (d->l==NULL)
    {
      if (d->r==NULL)
        if (y+1>0 && *k>0)
          printchartopaper(pap,y+1,*k,' ');
      else
        if (y+1>0 && *k>0)
          printchartopaper(pap,y+1,*k,'"');
    } else
    {
      if (d->r==NULL)
        if (y+1>0 && *k>0)
          printchartopaper(pap,y+1,*k,'$');
      else
        if (y+1>0 && *k>0)
          printchartopaper(pap,y+1,*k,'^');
    }
    *x+=l+1;
    papertreefull(d->r,x,y+2,':',&k2,papaddr);
    if (d->r!=NULL)
    {
      for (i=*k+1;i<=k2-1;++i)
        if (y+1>0 && i>0)
          printchartopaper(pap,y+1,i,'-');
    }
  }
}
}



static void papertreepart(object d,int *x,int y,char pod,int *k,stack *papaddr)
{
char *st;
int l,i,k1,k2;
int xx,yy,ii;
object *point;
stack pap;
if (d!=NULL && papaddr!=NULL)
{
  if (*papaddr==NULL)
    *papaddr=newstack(20);
  pap=*papaddr;
  if (d->kind=='V' && d->subkind=='V' && d->r==NULL)
  {
    if (d->v!=NULL)
    {
      point=d->v;
      d->r=*point;
      /* Za ta trenutek postane desna veja d objekt, na katerega kaze *(d->v). */
      papertreepart(d,x,y,pod,k,papaddr);
      d->r=NULL;
    }
  } else if (d->kind=='P' && d->r==NULL)
  {
    if (d->v!=NULL)
    {
      point=d->v;
      d->r=*point;
      /* Za ta trenutek postane desna veja d objekt, na katerega kaze *(d->v). */
      papertreepart(d,x,y,pod,k,papaddr);
      d->r=NULL;
    }
  } else
  {
    papertreepart(d->l,x,y+2,':',&k1,papaddr);
    st=strobj(d);
    l=strlen(st);
    xx=*x; yy=y;
    for (ii=1;ii<= (int) strlen(st);++ii)
    {
      if(yy>0 && xx>0)
        printchartopaper(pap,yy,xx,st[ii-1]);
      ++xx;
    }
    *k=*x+(l/2);
    if (y-1>0 && *k>0)
      printchartopaper(pap,y-1,*k,pod);
    if (d->l!=NULL)
    {
      for (i=k1+1; i<=*k-1; ++i)
        if (y+1>0 && i>0)
          printchartopaper(pap,y+1,i,'-');
    }
    if (d->l==NULL)
    {
      if (d->r==NULL)
        if (y+1>0 && *k>0)
          printchartopaper(pap,y+1,*k,' ');
      else
        if (y+1>0 && *k>0)
          printchartopaper(pap,y+1,*k,'"');
    } else
    {
      if (d->r==NULL)
        if (y+1>0 && *k>0)
          printchartopaper(pap,y+1,*k,'$');
      else
        if (y+1>0 && *k>0)
          printchartopaper(pap,y+1,*k,'^');
    }
    *x+=l+1;
    papertreepart(d->r,x,y+2,':',&k2,papaddr);
    if (d->r!=NULL)
    {
      for (i=*k+1;i<=k2-1;++i)
        if (y+1>0 && i>0)
          printchartopaper(pap,y+1,i,'-');
    }
  }
}
}



void fprinttree(FILE *fp,object t,int lines,int columns)
     /* izpise drevo t na konec datoteke fp.
     $A Igor <== jan02; */
{
int x,y,k;
char pod='Y';
stack pap=NULL;
if (fp!=NULL)
{
  /* getpaper(&pap,lines,columns); */
  x=1; y=5; k=0; pod=' ';
  papertree(t,&x,y,pod,&k,&pap);
  fprintpaper(fp,pap);
  disppaper(&pap);
}
}

void fprinttreefull(FILE *fp,object t,int lines,int columns)
     /* izpise drevo t na konec datoteke fp.
     $A Igor <== jan02; */
{
int x,y,k;
char pod='Y';
stack pap=NULL;
if (fp!=NULL)
{
  /* getpaper(&pap,lines,columns); */
  x=1; y=5; k=0; pod=' ';
  papertreefull(t,&x,y,pod,&k,&pap);
  fprintpaper(fp,pap);
  disppaper(&pap);
}
}

void fprinttreepart(FILE *fp,object t,int lines,int columns)
     /* izpise drevo t na konec datoteke fp.
     $A Igor <== jan02; */
{
int x,y,k;
char pod='Y';
stack pap=NULL;
if (fp!=NULL)
{
  /* getpaper(&pap,lines,columns); */
  x=1; y=5; k=0; pod=' ';
  papertreepart(t,&x,y,pod,&k,&pap);
  fprintpaper(fp,pap);
  disppaper(&pap);
}
}


void printtree(object t,int lines,int columns)
     /* izpise drevo t na zaslon. */
{
fprinttree(stdout,t,lines,columns);
}

void printtreefull(object t,int lines,int columns)
     /* izpise drevo t na zaslon. */
{
fprinttreefull(stdout,t,lines,columns);
}

void printtreepart(object t,int lines,int columns)
     /* izpise drevo t na zaslon. */
{
fprinttreepart(stdout,t,lines,columns);
}



void fprintlin(FILE *fp,object tr)
     /* Drevo izpise v linearni obliki v datoteko fp. */
{
char *str;
if (fp!=NULL)
{
  if (tr!=NULL)
  {
    if (tr->l!=NULL)
    {
      if (tr->l->kind=='0' || tr->l->kind=='A'
      || (tr->l->kind=='V' && tr->l->subkind=='V') )
        fprintlin(fp,tr->l);
      else if (tr->l->kind=='1' || (tr->l->kind=='V' && tr->l->subkind=='F') )
      {
        /* fprintf(fp,"(");*/ fprintlin(fp,tr->l); /* fprintf(fp,")"); */
      } else if (tr->l->kind=='2')
      {
        if (tr->l->priority<=tr->priority) /**/
          fprintlin(fp,tr->l);
        else
        {
          fprintf(fp,"(");
          fprintlin(fp,tr->l);
          fprintf(fp,")");
        }
      }
    }
    fprintf(fp," %s ",str=strobj(tr));
    free(str);
    if (tr->r!=NULL)
    {
      if (tr->kind=='1' || (tr->r->kind=='V' && tr->r->subkind=='F') )
      {
        /* Ce tr predstavlja funkcijo, se mora argument, to je desno poddrefo,
        izpisati v oklepajih. */
        fprintf(fp,"[");  fprintlin(fp,tr->r);   fprintf(fp,"]");
      } else if (tr->r->kind=='0' || tr->r->kind=='A'
      || (tr->r->kind=='V' && tr->r->subkind=='V') )
        fprintlin(fp,tr->r);
      else if(tr->r->kind=='1' || tr->r->kind=='f')
      {
        fprintlin(fp,tr->r);
      }
      else if (tr->r->kind=='2' /*|| tr->r->kind=='1' || tr->kind->r=='f'*/)
      {
        if (tr->r->priority<=tr->priority)
          fprintlin(fp,tr->r);
        else
        {
          fprintf(fp,"(");
          fprintlin(fp,tr->r);
          fprintf(fp,")");
        }
      }
    }
  }
  }
}

void printlin(object tr)
     /* Drevo izpise v linearni obliki na zaslon. */
{
fprintlin(stdout,tr);
}





static double unopval(char *name,double x)
       /* Vrne vrednost unarnega operatorja z imenom name pri argumentu x. */
{
switch (name[0])
{
  case '-':
    if (name[1]=='\0')
      return -x;
    break;
  case '!':
    if (x==0.0)
      return 1.0;
    else
      return 0.0;
    break;
  case 'a':  /* "abs", "arcsin", "arccos", "arctg", "arcctg", "arsh", "arch",
  "arth", "arcth" */
    switch (name[2])
    {
      case 'c': /* funkcije tipa arcus */
        switch(name[3])
        {
          case 'h':  /* "arch" */
            return infinity();
            break;
           case 's':  /* "arcsin" */
            return arcsin(x);
            break;
          case 'c':  /* "arccos" ali "arcctg" */
            if (name[4]=='o') /* "arccos" */
              return arccos(x);
            else if (name[4]=='t') /* "arcctg" */
              return arcctg(x);
            break;
          case 't':  /* "arctg" ali "arcth" */
            if (name[4]=='g') /* "arctg"  - arkus tangens */
              return arctg(x);
            else if (name[4]=='h') /* "arcth" - area kotangens hip. */
              return infinity();
            break;
        }
        break;
      case 's': /* "abs" ali "arsh" */
        if (name[1]=='b') /* "abs" */
          return fabs(x);
        else if (name[1]=='s') /* "arsh" */
          return infinity();
        break;
      case 't': /* "arth" */
        return infinity();
        break;
    }
    break;
  case 'c':  /* "cos", "ctg", "ch", "cth" */
    switch(name[1])
    {
      case 't': /* "ctg", "cth" */
        if (name[2]=='g')  /* "ctg" */
          return ctg(x);
        else if (name[2]=='h')  /* "cth" */
          return cth(x);
        break;
      case 'o': /* "cos" */
        return cos(x);
        break;
      case 'h': /* ch */
        return ch(x);
        break;
    }
    break;
  case 'd':  /* "deg" */
    return st(x);
    break;
  case 'e':  /* "exp" */
    return exp(x);
    break;
  case 'f':  /* "floor", "frac" */
    switch(name[1])
    {
      case 'l':
        return trunc(x);  /* "floor" */
        break;
      case 'r':
        return frac(x);
        break;
    }
    break;
  case 'i':  /* "int" */
    return trunc(x);
    break;
  case 'l':  /* "ln" */
    return ln(x);
    break;
  case 'N':  /* "NEGV" */
    return -x;
    break;
  case 'n':  /* "negative", "negpart" */
    if (strcmp(name,"negative")==0)  /* "negative" */
    {
      if (x<0)
        return 1;
      else
        return 0;
    } else if (strcmp(name,"negpart")==0)  /* "negpart" */
    {
      if (x<0)
        return x;
      else
        return 0;
    }
    break;
  case 'p':  /* "positive", "pospart" */
    if (strcmp(name,"positive")==0)  /* "positive" */
    {
      if (x>0)
        return 1;
      else
        return 0;
    } else if (strcmp(name,"pospart")==0)  /* "pospart" */
    {
      if (x>0)
        return x;
      else
        return 0;
    }
    break;
  case 'r':  /* "rad", "round" */
    switch(name[1])
    {
      case 'a':  /* "rad" */
        return rad(x);
        break;
      case 'o': 
        return round(x);  /* "round" */
        break;
    }
    break;
  case 's':  /* "sqr", "sqrt", "sin", "sh", "st"  */
    switch (name[1])
    {
      case 'q':
        if (name[3]=='t')  /* "sqrt" */
          return sqrt(x);
        else    /* "sqr" */
          return m_sqr(x);
        break;
      case 'i':  /* "sin", "sign" */
        switch (name[2])
        {
          case 'n':  /* "sin" */
            return sin(x);
            break;
          case 'g':  /* "sign" */
            if (x>0)
              return 1;
            else if (x<0)
              return -1;
            else
              return 0;
            break;
        }
      case 'h':   /* sh */
        return sh(x);
        break;
      case 't':   /* "st" */
        return st(x);
        break;
    }
    break;
  case 't':  /* tg, "th", "trunc" */
    switch (name[1])
    {
      case 'g': /* "tg" */
        return tg(x);
        break;
      case 'h': /* "th" */
        return th(x);
        break;
      case 'r': /* "trunc" */
        return trunc(x);
        break;
    }
    break;
}
return infinity(); /* samo zaradi prevajalnika */
}


static double binopval(char *name,double x, double y)
       /* Vrne vrednost binarnega operatorja z imenom name pri levem argumentu
       x in desnem argumentu y. */
{
switch (name[0])
{
  case '=': /* "==" */
    if (name[1]=='=') /* "==" */
    {
      if (x==y)
        return 1.0;
      else
        return 0.0;
    }
    break;
  case '<':  /* "<=", "<" */
    if (name[1]=='=')  /* "<=" */
    {
      if (x<=y)
        return 1.0;
      else
        return 0.0;
    } else if (name[1]=='\0')  /* "<" */
    {
      if (x<y)
        return 1.0;
      else
        return 0.0;
    }
    break;
  case '>':  /* ">=", ">" */
    if (name[1]=='=')  /* ">=" */
    {
      if (x>=y)
        return 1.0;
      else
        return 0.0;
    } else if (name[1]=='\0')  /* ">" */
    {
      if (x>y)
        return 1.0;
      else
        return 0.0;
    }
    break;
  case '!':  /* "!=" */
    if (name[1]=='=')  /* "!=" */
    {
      if (x!=y)
        return 1.0;
      else
        return 0.0;
    }
    break;
  case '|':  /* "||" */
    if (name[1]=='|')  /* "||" */
    {
      if (x!=0.0 || y!=0.0)
        return 1.0;
      else
        return 0.0;
    }
    break;
  case '&':  /* "&&" */
    if (name[1]=='&')  /* "&&" */
    {
      if (x!=0.0 && y!=0.0)
        return 1.0;
      else
        return 0.0;
    }
    break;
  case '+':  /* "+" */
    return x+y;
    break;
  case '-':  /* "-" */
    return x-y;
    break;
  case '*':  /* "*" */
    return x*y;
    break;
  case '/':  /* "/" */
    return x/y;
    break;
  case '%':  /* "/" */
    return (double) ((long) x % (long) y);
    break;
  case '^':  /* "^" */
    return pow(x,y);
    break;
  case 'P': /* Poljubna potenca P */
    return pow(x,y);
    break;
  case 'C': /* cela potenca "CP" */
     return pow(x,round(y));
     break;
  case 'L': /* poljubni logaritem "LOG" od x z osnovo y */
    return ln(x)/ln(y);
    break;
  case 'M': /* minimum "MIN", maksimum "MAX" */
    if (name[1]=='I')  /* "MIN" */
    {
      if (x<y)
        return x;
      else return y;
    }  else if (name[1]=='A')  /* "MAX" */
    {
      if (x>y)
        return x;
      else return y;
    }
    break;
}
return infinity(); /* samo zaradi prevajalnika */
}


static userfunc currentuserfunc=NULL;

userfunc getcurrentuserfunc(void)
    /* Vrne kazalec na podatke o uporabniski funkciji, ki se trenutno vrednoti.
    $A Igor sep98; */
{
return currentuserfunc;
}

double doubleval(object tr,stack st,stack user)
     /* Funkcija vrne realno vrednost, ki ustreza binarnemu drevesu objektov
     tree. st je sklad, na katerega se nalagajo argumenti funkcij. user je
     sklad, na katerem ta funkcija najde navodila za ravnanje z uorabniskimi
     funkcijami. */
{
long *a;
double *x,xx=0,yy;
object *point,arg;
userfunc *pointuser;
stack refst;
int i,j,num;
if (tr!=NULL)
{
  if (tr->kind=='0')
  {
    if (tr->subkind=='l')
    {
      if (tr->v!=NULL)
      {
        a=tr->v;
        xx=(double) *a;
        return xx;
      }
    } else if (tr->subkind=='d')
    {
      if (tr->v!=NULL)
      {
        x=tr->v;
        return *x;
      } else
        return infinity();
    }
  } else if (tr->kind=='V')
  {
    if (tr->subkind=='V') /* spremenljivka */
    {
      point=tr->v;
      return doubleval(*point,st,user);
    } else if (tr->subkind=='F') /* funkcija */
    {
      /* refst postane seznam argumentov funkcije: */
      refst=treelist(tr->r);
      num=refst->n;
      if (num>0)
      {
        /* Argumenti se v obratnem vrstnem redu nalozijo na glavni sklad: */
        for (i=1; i<=num; ++i)
        {
          /*
          pushstack((stack) st, popstack((stack) refst));
          */
          arg=popstack((stack) refst);
          if(arg->kind=='A')
          {
            /* Ce argument ni navaden objekt, temvec objekt tipa argument, potem
            na glav. sklad ne bomo polozili direktno tega objekta, temvec objekt,
            ki ga le-ta naslavlja, to pa je j-ti argument na skladu od zadaj
            naprej, pri cemer s skladom mislimo stanje sklada, preden smo zaceli
            nalagati objekte za tekoco funkcijo (torej moramo k  j pristeti se
            stevilo objektov, ki smo jih ze nalozili za tekoco funkcijo, to je
            i-1) */
            j=arg->subkind;
            pushstack((stack) st, nstack((stack) st, j+i-1 ) );
          } else pushstack((stack) st,arg);
        }
        dispstack((stack *) &refst);
        /* Izvrsi se finkcija, kot je predpisano v njeni definiciji: */
        point=tr->v;
        xx=doubleval(*point,st,user);
        /* Argumenti funkcije se spet poberejo s sklada */
        for (i=1; i<=num; ++i)
        {
          popstack((stack) st);
        }
        /* Na koncu se se vrne izracunana vrednost: */
        return xx;
      } else return infinity();
    } else if (tr->subkind=='U') /* Uporabnisko definirana funkcija */
    {
      refst=NULL;
      /* refst postane seznam argumentov funkcije: */
      refst=treelist(tr->r);
      num=refst->n;
      /* if (num>0) */ if (1)
      {
        if (num>0)
        {
        /* Argumenti se v obratnem vrstnem redu nalozijo na glavni sklad: */
        for (i=1; i<=num; ++i)
        {
          /*
          pushstack((stack) st, popstack((stack) refst));
          */
          arg=popstack((stack) refst);
          if(arg->kind=='A')
          {
            /* Ce argument ni navaden objekt, temvec objekt tipa argumrnt, potem
            na glav. sklad ne bomo polozili direktno tega objekta, temvec objekt,
            ki ga le-ta naslavlja, to pa je j-ti argument na skladu od zadaj
            naprej, pri cemer s skladom mislimo stanje sklada, preden smo zaceli
            nalagati objekte za tekoco funkcijo (torej moramo k  j pristeti se
            stevilo objektov, ki smo jih ze nalozili za tekoco funkcijo, to je
            i-1) */
            j=arg->subkind;
            pushstack((stack) st, nstack((stack) st, j+i-1 ) );
          } else pushstack((stack) st,arg);
        }
        }
        if (refst!=NULL)
          dispstack((stack *) &refst);
        pointuser=tr->v;
        /* Klice se funkcija, ki je definirana za izracun realne vrednosti za to
        funkcijo. */
        if (pointuser!=NULL)
          if (*pointuser!=NULL)
            if ( (*pointuser)->doubleval !=NULL )
            {
              userfunc olduserfunc;
              olduserfunc=currentuserfunc;
              currentuserfunc=*pointuser;
              xx=(*pointuser)->doubleval
               ( tr,st,user,num,(*pointuser)->doublevaldata);
              currentuserfunc=olduserfunc;
            }
        /* Argumenti funkcije se spet poberejo s sklada */
        for (i=1; i<=num; ++i)
        {
          popstack((stack) st);
        }
        /* Na koncu se se vrne izracunana vrednost: */
        return xx;
      } else return infinity();
    }
  } else if (tr->kind=='D')
  {
    if (tr->subkind=='F' || tr->subkind=='V')
    {
      return(doubleval(tr->r,st,user));
    }
  } else if (tr->kind=='A')
  {
    i=(int) tr->subkind;
    return doubleval( (object) nstack((stack) st,i) ,st,user);
  } else if (tr->kind=='1')
  {
    if (cmpstrings(tr->name,"EQ")==0 || cmpstrings(tr->name,"_")==0)
    {
      return doubleval(tr->r,st,user);
    } else
    {
      xx=doubleval(tr->r,st,user);
      return unopval(tr->name,xx);
    }
  } else if (tr->kind=='2')
  {
    xx=doubleval(tr->l,st,user);
    yy=doubleval(tr->r,st,user);
    return binopval(tr->name,xx,yy);
  } else if (tr->kind=='P')  /* Kazalec na drug objekt */
  {
    if (tr->v!=NULL)
    {
      point=tr->v;
      return doubleval(*point,st,user);
    }
  } else if (tr==NULL)
  {
    /* napaka */
    return infinity();
  } else
  {
    /* napaka */
    return infinity();
  }
} else
  return infinity(); /* napaka */
return infinity(); /* samo zaradi prevajalnika */
}



userfunc installuserfuncret(ssyst syst,char *name,
     double fdoubleval (object,stack,stack,int,void *), void *doublevaldata,
     void fput (object,void *), void *putdata)
    /* Na sistem za simbolno racunanje syst instalira uporabnisko funkcijo z
    imenom name. fdoubleval je funkcija, ki jo uporablja funkcija doubleval
    za ovrednotenje dreves doubleval, ko naleti na uporabnisko funkcijo,
    doublevaldata pa je argument klica te funkcije znotraj funkcije
    doubleval in sluzi za prenos podatkov, ce je potreben.
    Funkcija vrne podatke tipa userfunc, ki dolocajo na novo instalirano
    uporabnisko funkcijo.
    $A Igor jun97 dec97; */
{
userfunc usf;
usf=malloc(sizeof(*usf));
usf->name=stringcopy(name);
usf->doubleval=fdoubleval;
usf->doublevaldata=doublevaldata;
usf->put=fput;
usf->putdata=putdata;
/*
if (syst->user!=NULL)
  pushstack(syst->user,usf);
*/
if (syst!=NULL)
  inssortstack(syst->user,usf,cmpuserfunc);

return usf;
}


void installuserfunc(ssyst syst,char *name,
     double fdoubleval (object,stack,stack,int,void *), void *doublevaldata,
     void fput (object,void *), void *putdata)
    /* Podobno kot installuserfuncret, le da ne vrne kazalca na strukturo, ki
    doloca instalirano uporabnisko funkcijo.
    $A Igor <== jun97; */
{
userfunc usf;
usf=installuserfuncret(syst,name,fdoubleval,doublevaldata,fput,putdata);
}




void comsyst(FILE *fp,ssyst syst,char *command)
     /* V sistemu simbolnega racunanja naredi to, kar ukazuje ukaz command. Ce
     se ukaz ne zacne z znakom '$', pomeni, da je treba niz vkljuciti v sistem
     objektov. Ce pa je 0. znak ukaza '$', pomeni to ukaz za specificno akcijo
     (npr. izpis drevesa na zaslon) */
{
int i,num,lines=55,columns=155;
stack list;
object t;
char *name;
int jj,kk;
char autoevaluate;
if (fp!=NULL)
{
  if (command[0]=='$') /* Ukaz za specificno akcijo */
  {
    if (command[1]=='S' || command[1]=='s') /* Izpis preb. niza */
    {
      if (command[2]=='L' || command[2]=='l') /* Zadnji */
      {
        if (syst->strings->n>0)
          fprintf(fp,"\"%s\"", (char *) (syst->strings->s[syst->strings->n]) );
          fprintf(fp,"\n\n");
      } else if (command[2]=='A' || command[2]=='a')  /* vsi */
      {
        if (syst->strings->n>0)
        {
          fprintf(fp,"  Input strings:\n");
          for (i=1; i<=syst->strings->n; ++i)
          {
            fprintf(fp,"%i: ",i);
            fprintf(fp,"\"%s\"", (char *) (syst->strings->s[i]) );
            fprintf(fp,"\n");
          }
          fprintf(fp,"\n");
        }
      } else if (command[2]=='N' || command[2]=='n')  /* dolocen */
      {
        i=sscanf(command+3,"%i",&num);
        if (i==1)
          if (syst->strings->n >=num)
          {
            fprintf(fp,"%i. inp. string:\n",num);
            fprintf(fp,"\"%s\"", (char *) (syst->strings->s[num]) );
            fprintf(fp,"\n\n");
          }
      }
    } else if (command[1]=='C' || command[1]=='c') /* Izpis v linearizirani obliki */
    {
      if (command[2]=='L' || command[2]=='l')
      {
        if (syst->cuts->n>0)
          fprinttabobj(fp,(stack) syst->cuts->s[syst->cuts->n]);
          fprintf(fp,"\n\n");
      } else if (command[2]=='A' || command[2]=='a')
      {
        if (syst->cuts->n>0)
          for (i=1; i<=syst->cuts->n; ++i)
          {
            fprintf(fp,"%i. cut:\n",i);
            fprinttabobj(fp,(stack) (syst->cuts->s[i]) );
            fprintf(fp,"\n\n");
          }
        fprintf(fp,"\n");
  
      } else if (command[2]=='N' || command[2]=='n')
      {
        i=sscanf(command+3,"%i",&num);
        if (i==1)
          if (syst->cuts->n >=num)
          {
            fprintf(fp,"%i. cut:\n",num);
            fprinttabobj(fp,(stack) (syst->cuts->s[num]) );
            fprintf(fp,"\n\n");
          }
      }
    } else if (command[1]=='L' || command[1]=='l') /* Izpis v linearizirani obliki */
    {
      if (command[2]=='L' || command[2]=='l')
      {
        if (syst->def->n>0)
          fprintlin(fp,(object) syst->def->s[syst->def->n]);
          fprintf(fp,"\n\n");
  
      } else if (command[2]=='A' || command[2]=='a')
      {
        if (syst->def->n>0)
          for (i=1; i<=syst->def->n; ++i)
          {
            fprintf(fp,"%i. def:\n",i);
            fprintlin(fp,(object) (syst->def->s[i]) );
            fprintf(fp,"\n\n");
          }
        fprintf(fp,"\n");
  
      } else if (command[2]=='N' || command[2]=='n')
      {
        i=sscanf(command+3,"%i",&num);
        if (i==1)
          if (syst->def->n >=num)
          {
            fprintf(fp,"%i. def:\n",num);
            fprintlin(fp,(object) (syst->def->s[num]) );
            fprintf(fp,"\n\n");
          }
      } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
      {
        jj=3;
        while (command[jj]==' ') ++jj;
        kk=jj;
        while (command[kk]!=' ' && command[kk]!='\0') ++kk;
        if (kk>jj)
        {
          name=stringncopy(command+jj,kk-jj);
          t=findobjname(syst->def,name);
          fprintf(fp,"\"%s\" :\n",name);
          fprintlin(fp,t);
          fprintf(fp,"\n\n");
          free(name);
        }
      }
    } else if (command[1]=='T' || command[1]=='t' /* Izpisi drevo v okrnjeni obliki */
      || command[1]=='F' || command[1]=='f'  /* Izpisi drevo v polni obliki */
      || command[1]=='P' || command[1]=='p')  /* Izpisi drevo v delno polni obliki */
    {
      if (command[2]=='L' || command[2]=='l')
      {
        if (syst->def->n>0)
          if (command[1]=='T' || command[1]=='t') /* okrnjena oblika */
            fprinttree(fp,(object) syst->def->s[syst->def->n],lines,columns);
          else if(command[1]=='F' || command[1]=='f') /* polna oblika */
            fprinttreefull(fp,(object) syst->def->s[syst->def->n],lines,columns);
          else if (command[1]=='P' || command[1]=='p')  /* delno okrnjena oblika */
            fprinttreepart(fp,(object) syst->def->s[syst->def->n],lines,columns);
          fprintf(fp,"\n\n");
      } else if (command[2]=='A' || command[2]=='a')
      {
        if (syst->def->n>0)
          for (i=1; i<=syst->def->n; ++i)
          {
            fprintf(fp,"%i. def:\n",i);
            if (command[1]=='T' || command[1]=='t') /* okrnjena oblika */
              fprinttree(fp,(object) (syst->def->s[i]) ,lines,columns);
            else if(command[1]=='F' || command[1]=='f') /* polna oblika */
              fprinttreefull(fp,(object) (syst->def->s[i]) ,lines,columns);
            else if (command[1]=='P' || command[1]=='p')  /* delno okrnjena oblika */
              fprinttreepart(fp,(object) (syst->def->s[i]) ,lines,columns);
            fprintf(fp,"\n\n");
          }
        fprintf(fp,"\n");
  
      } else if (command[2]=='N' || command[2]=='n')
      {
        i=sscanf(command+3,"%i",&num);
        if (i==1)
          if (syst->def->n >=num)
          {
            fprintf(fp,"%i. def:\n",num);
            if (command[1]=='T' || command[1]=='t') /* okrnjena oblika */
              fprinttree(fp,(object) (syst->def->s[num]) ,lines,columns);
            else if(command[1]=='F' || command[1]=='f') /* polna oblika */
              fprinttreefull(fp,(object) (syst->def->s[num]) ,lines,columns);
            else if (command[1]=='P' || command[1]=='p')  /* delno okrnjena oblika */
              fprinttreepart(fp,(object) (syst->def->s[num]) ,lines,columns);
            fprintf(fp,"\n\n");
          }
      } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
      {
        jj=3;
        while (command[jj]==' ') ++jj;
        kk=jj;
        while (command[kk]!=' ' && command[kk]!='\0') ++kk;
        if (kk>jj)
        {
          name=stringncopy(command+jj,kk-jj);
          t=findobjname((stack) syst->def,name);
          fprintf(fp,"\"%s\" :\n",name);
          if (command[1]=='T' || command[1]=='t') /* okrnjena oblika */
            fprinttree(fp,t,lines,columns);
          else if(command[1]=='F' || command[1]=='f') /* polna oblika */
            fprinttreefull(fp,t,lines,columns);
          else if (command[1]=='P' || command[1]=='p')  /* delno okrnjena oblika */
            fprinttreepart(fp,t,lines,columns);
          fprintf(fp,"\n\n");
          free(name);
        }
      }
    } else if (command[1]=='E' || command[1]=='e') /* Ovrednotenje dreves */
    {
      if (command[2]=='L' || command[2]=='l')
      {
        if (syst->def->n>0)
        {
          t=syst->def->s[syst->def->n];
          fprintf(fp,"Vrednost spremenljivke \"%s\" :\n",t->name);
          if (t->subkind=='V')
            fprintf(fp,"%.10g",doubleval(t,syst->fst,syst->user));
          else fprintf(fp,"ni spremenljivka.");
          fprintf(fp,"\n\n");
        } else fprintf(fp,"Na skladu ni definicij.\n\n");
      } else if (command[2]=='A' || command[2]=='a')
      {
        if (syst->def->n>0)
        {
          for (i=1; i<=syst->def->n; ++i)
          {
            t=syst->def->s[i];
            fprintf(fp,"Vrednost %i. spremenljivke (\"%s\") : ",i,t->name);
            if (t->subkind=='V')
              fprintf(fp,"%.10g",doubleval(t,syst->fst,syst->user));
            else fprintf(fp,"ni spremenljivka.");
            fprintf(fp,"\n");
          }
        } else fprintf(fp,"Na skladu ni definicij.\n\n");
        fprintf(fp,"\n\n");
      } else if (command[2]=='N' || command[2]=='n')
      {
        i=sscanf(command+3,"%i",&num);
        if (i==1)
          if (syst->def->n >=num)
          {
            t=syst->def->s[num];
            fprintf(fp,"Vrednost %i. spremenljivke (\"%s\") : ",num,t->name);
            if (t->subkind=='V')
              fprintf(fp,"%.10g",doubleval(t,syst->fst,syst->user));
            else fprintf(fp,"ni spremenljivka.");
            fprintf(fp,"\n");
          } else fprintf(fp,"Na skladu ni definicij.\n\n");
      } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
      {
        jj=3;
        while (command[jj]==' ') ++jj;
        kk=jj;
        while (command[kk]!=' ' && command[kk]!='\0') ++kk;
        if (kk>jj)
        {
          name=stringncopy(command+jj,kk-jj);
          t=findobjname((stack) syst->def,name);
          fprintf(fp,"Vrednost spremenljivke \"%s\" :\n",name);
          if (t->subkind=='V')
            fprintf(fp,"%.10g",doubleval(t,syst->fst,syst->user));
          else fprintf(fp,"ni spremenljivka.");
          fprintf(fp,"\n\n");
          free(name);
        }
      }
    } else if (command[1]=='V' || command[1]=='v') /* Imena spremenljivk in
    definiranih funkcij */
    {
      if (command[2]=='L' || command[2]=='l')
      {
        if (syst->def->n>0)
          fprintf(fp,"Name of the last object in main list: \"%s\"\n",
           ((object) syst->def->s[syst->def->n])->name );
          fprintf(fp,"\n\n");
      } else if (command[2]=='A' || command[2]=='a')
      {
        if (syst->def->n>0)
          for (i=1; i<=syst->def->n; ++i)
          {
            /* fprintf(fp,"%i. def:\n",i); */
            fprintf(fp,"Name of %i. object in main list: \"%s\"\n", i,
             ((object) syst->def->s[i])->name );
            /* fprintf(fp,"\n\n"); */
          }
        fprintf(fp,"\n");
      } else if (command[2]=='N' || command[2]=='n')  /* Sprem. z doloc. zap. st. */
      {
        i=sscanf(command+3,"%i",&num);
        if (i==1)
          if (syst->def->n >=num)
          {
            fprintf(fp,"%i. def:\n",num);
            fprintf(fp,"Name of %i. object in main list: \"%s\"\n",num,
             ((object) syst->def->s[num])->name );
  
            fprintf(fp,"\n\n");
          }
      }
    } else if (command[1]=='R' || command[1]=='r') /* Pogon sistem. ukaza */
    {
      system(command+3);
    } else if (command[1]=='X' || command[1]=='x') /* Ponovitev ukaza z dano zap. st. */
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->strings->n >= num)
          comsyst(fp,syst,syst->strings->s[num]);
    } else if (command[1]=='*' || command[1]=='*') /* Komentar */
    {
      fprintf(fp,"%s\n",command+2);
    }
  } else if (command!=NULL) if (command[0]!='\0')
  {
    list=cutexpression(command,syst->syst);
    arrangelistobj(list);
    t=NULL;
    t=maketree(list);
    if (t->name[0]==':' && t->name[1]=='\0' && t->kind=='2')
      autoevaluate=0;
    else
      autoevaluate=1;
    /*
    printtree(t,lines,columns);
    */
    /*
    pushstack(syst->strings,stringcopy(command));
    pushstack(syst->cuts,list);
    pushstack((stack) syst->trees,t);
    */
    puttreetolist(t,& (syst->def), & (syst->trash), syst->user);
    displistobj(&list);
    if (autoevaluate)
      fprintf(fp,"\n    Vrednost:  %.10g\n\n",doubleval(t,syst->fst,syst->user));
  }
  }
}



static void helpsymbcalc(void)
{
printf("       ********** SIMBOLNI KALKULATOR **********\n\n");
printf(" Vstavljaj izraze ali ukaze oblike $XYopt, kjer je X ukaz,\n");
printf("Y specifikazija in opt mozna dodatna opredelitev.\n\n");
printf("  UKAZI:\n");
printf("S, s: izpis prebranih izrazov\n");
printf("L, l: izpis dreves v linearizirani obliki\n");
printf("C, c: izpis razrezanih izrazov\n");
printf("T, t: izpis dreves\n");
printf("V, v: izpis imen spremenljivk\n");
printf("E, e: izpis vrednosti spremenljivk\n");
printf("R, r: izvedba sistemskega ukaza\n");
printf("?: Ta izpis\n");
printf("\n");
printf("  SPECIFIKACIJE:\n");
printf("A, a: Ukaz se nanasa na vse\n");
printf("L, l: Ukaz se nanasa na zadnjega\n");
printf("N, n: Ukaz se nanasa na element z zap. st, ki je navedena kot opt.\n");
printf("V, v: Ukaz se nanasa na element z imenom, ki je navedeno kot opt. brez presledka.\n");
printf("\n");
}


/*
double plusdoubleval (object obj,stack st,stack user,int numargs,void *ptr)
{
double x1,x2;
object o1,o2;
o1=nstack((stack)st,1);
o2=nstack((stack)st,2);
x1=doubleval(o1,st,user);
x2=doubleval(o2,st,user);
return x1+x2;
}
*/



/*    UPORABNISKO DEFINIRANE FUNKCIJE KALKULATORJA    */ 


static double userrandom(object obj,stack st,stack user,int numargs,void *ptr)
    /* Funkcija, ki vrne nakljucno stevilo med 0 (kljucno) in 1.
    $A Igor sep97; */
{
return random1();
}


static double usersum(object obj,stack st,stack user,int numargs,void *ptr)
       /* Funkcija, ki vrne vsoto vseh argumentov. Funkcijo se lahko vkljuci
       v sistem za simbolno racunanje kot uporabnisko funkcijo. */
{
double xx,ret=0;
object oo;
int i;
if (numargs>0)
  for (i=1;i<=numargs; ++i)
  {
    oo=nstack((stack)st,i);
    if (oo!=NULL)
    {
      xx=doubleval(oo,st,user);
      ret+=xx;
    }
  }
return ret;
}

static double userprod(object obj,stack st,stack user,int numargs,void *ptr)
       /* Funkcija, ki vrne produkt vseh argumentov. Funkcijo se lahko vkljuci
       v sistem za simbolno racunanje kot uporabnisko funkcijo. */
{
double xx,ret=1;
object oo;
int i;
if (numargs>0)
  for (i=1;i<=numargs; ++i)
  {
    oo=nstack((stack)st,i);
    if (oo!=NULL)
    {
      xx=doubleval(oo,st,user);
      ret*=xx;
    }
  }
return ret;
}

static double usermax(object obj,stack st,stack user,int numargs,void *ptr)
       /* Funkcija, ki vrne produkt vseh argumentov. Funkcijo se lahko vkljuci
       v sistem za simbolno racunanje kot uporabnisko funkcijo. */
{
double xx,ret=0;
object oo;
int i;
if (numargs>0)
  oo=nstack((stack)st, 1 );
  if (oo!=NULL)
    ret=doubleval(oo,st,user);
  if (numargs>1)
  for (i=2;i<=numargs; ++i)
  {
    oo=nstack((stack)st,i);
    if (oo!=NULL)
    {
      xx=doubleval(oo,st,user);
      ret=m_maxval(ret,xx);
    }
  }
return ret;
}

static double usermin(object obj,stack st,stack user,int numargs,void *ptr)
       /* Funkcija, ki vrne produkt vseh argumentov. Funkcijo se lahko vkljuci
       v sistem za simbolno racunanje kot uporabnisko funkcijo. */
{
double xx,ret=0;
object oo;
int i;
if (numargs>0)
  oo=nstack((stack)st, 1 );
if (oo!=NULL)
  ret=doubleval(oo,st,user);
if (numargs>1)
for (i=2;i<=numargs; ++i)
{
  oo=nstack((stack)st,i);
  if (oo!=NULL)
  {
    xx=doubleval(oo,st,user);
    ret=m_minval(ret,xx);
  }
}
return ret;
}



static double definedfunc(object def,stack st,stack user,double x)
       /* Vrne funkcijsko vrednost definirane funkcije pri argumentu x.
       Definicijo vsebuje def, ki mora biti objekt, ki je bil vkljucen v nek
       delujoci sistem za simbolno racunanje z ukazom oblike
         imef_unk[1.0]
       ime_funk mora biti ime funkcije, katere definicija je tudi ze vkljucena v
       sistem za simb.
         POZOR! Treba je paziti, da je argument res tipa double, tako da ce
       ga v vkljucevanju v simb. int. zapises kot stevilo, ga moras zapisati
       vedno z decimalno piko (ce ne funkcija ne deluje.) */
{
double xx;
doubleobj(def->r,x);
xx=doubleval(def->r,st,user);
return xx;
}


static double usertab(object obj,stack st,stack user,int numargs,void *ptr)
{
int i,n;
object func,from,to,num,param;
double dfrom,dto,dnum,step,ret=0;
func=nstack((stack)st, 1 );
from=nstack((stack)st, 2 );
to=nstack((stack)st, 3 );
num=nstack((stack)st, 4 );
dfrom=doubleval(from,st,user);
dto=doubleval(to,st,user);
dnum=round(doubleval(num,st,user));
param=func->r;
n=(int) dnum;
if (n>0)
{
  step=(dto-dfrom)/dnum;
  printf("\n%15s%-15s\n","Argument:   ","  Value:");
  if (n>=1)
    for (i=0;i<=n;++i)
      {
        doubleobj(param,dfrom+(double)i*step);
        ret=doubleval(func,st,user);
        printf("%15g  %-15g\n",dfrom+(double)i*step,ret);
      }
  ret=ret*(step);
}
return ret;
}


static double usertrapint(object obj,stack st,stack user,int numargs,void *ptr)
       /* Funkcija, ki vrne doloceni integral neke funkcije po trapeznem pravilu.
       funkcijo lahko vkljucimo v sistem za simbolno racnanje kot uporabnisko
       funkcijo. 1. argument, ki se pobere s sklada st, je integrirana funkcija,
       drugi je spodnja meja, tretji zgornja meja integrala in cetrti stevilo
       tock integrala. */
{
int i,n;
object func,from,to,num,param;
double dfrom,dto,dnum,step,ret=0;
func=nstack((stack)st, 1 );
from=nstack((stack)st, 2 );
to=nstack((stack)st, 3 );
num=nstack((stack)st, 4 );
dfrom=doubleval(from,st,user);
dto=doubleval(to,st,user);
dnum=round(doubleval(num,st,user));
param=func->r;
n=(int) dnum;
if (n>0)
{
  step=(dto-dfrom)/dnum;
  doubleobj(param,dfrom);
  ret+=0.5*doubleval(func,st,user);
  doubleobj(param,dto);
  ret+=0.5*doubleval(func,st,user);
  if (n>1)
    for (i=1;i<=n-1;++i)
      {
        doubleobj(param,dfrom+(double)i*step);
        ret+=doubleval(func,st,user);
      }
  ret=ret*(step);
}
return ret;
}

static double userelse(object obj,stack st,stack user,int numargs,void *ptr)
{
object oo;
double ret=0,cond;
oo=nstack((stack)st, 1 );
cond=doubleval(oo,st,user);
if (cond==0.0)
{
  /* Ce je vrednost 1. argumenta 0, se vrne vrednost 3. argumenta: */
  oo=nstack((stack)st, 3 );
  ret=doubleval(oo,st,user);
} else
{
  /* Ce vrednost 1. argumenta ni 0, se vrne vrednost 2. argumenta: */
  oo=nstack((stack)st, 2 );
  ret=doubleval(oo,st,user);
}
return ret;
}

static double userif(object obj,stack st,stack user,int numargs,void *ptr)
{
object oo;
double ret=0,cond;
oo=nstack((stack)st, 1 );
cond=doubleval(oo,st,user);
if (cond!=0.0)
{
  oo=nstack((stack)st, 2 );
  ret=doubleval(oo,st,user);
}
return ret;
}

static double usercase(object obj,stack st,stack user,int numargs,void *ptr)
       /* Ce ima funkcija sodo stevilo argumentov, potem vrne prvega izmed
       tistih sodih argumentov, ki sledijo argumentom, katerih vrednost je
       razlicna od 0.0 (kar pomeni false). Ce ima funkcija liho stevilo
       argumentov, je razlika le v tem, da vrne zadnji argument, ce pred tem ni
       bil izpolnjen nobeden od pogojev, ki jih predstavljajo lihi argumenti.
       Ce ima funkcija sodo stevilo argumentov, vrne vrednost 0, ce ni izpolnjen
       nobeden od pogojev (to je torej isto, kot ce bi dodali se en argument z
       vrednostjo 0. */
{
object oo;
double ret,cond;
int i=1;
char truecond=0;
ret=0.0; i=1;
while (2*i<=numargs && !truecond)
{
  /* Preveri se pogoj: */
  oo=nstack((stack)st, 2*i-1 );
  cond=doubleval(oo,st,user);
  if (cond!=0.0)
  {
    /* Ce je pogoj izpolnjen, se vrne vrednost naslednjega argumenta. Hkrati
    se konca iskanje izpolnjenega pogoja (truecond postane 1): */
    oo=nstack((stack)st, 2*i);
    ret=doubleval(oo,st,user);
    truecond=1;
  }
  ++i;
}
if (2*i-1<=numargs && !truecond)
{
  oo=nstack((stack)st, 2*i-1);
  ret=doubleval(oo,st,user);
}
return ret;
}

static double userintdef(object obj,stack st,stack user,int numargs,void *ptr)
       /* Vrne vrednost v odvisnosti od tega, v katerem intervalu je vrednost
       1. argumenta. ce je vrednost 1. argumenta manjsa od vrednosti 2.
       argumenta, se vrne vrednost 3. argumenta, ce je vrednost 1. argumenta
       vecja od vrednosti 4. argumenta, se vrne vrednost 5. argumenta, drugace
       pa se vrne vrednost (8+3*(i-1)). argumenta, ce je vrednost 1. argumenta
       med vrednostma (6+3*(i-1)) - tega in (7+3*(i-1)) - tega argumenta.
       */
{
int i;
char end=0;
double ret=0,min,max,x,x1,x2;
object oo;
i=1;
if (numargs>=5)
{
  oo=nstack((stack)st, 1 );
  x=doubleval(oo,st,user);
  oo=nstack((stack)st, 2 );
  min=doubleval(oo,st,user);
  oo=nstack((stack)st, 4 );
  max=doubleval(oo,st,user);
  if (x<=min)
  {
    /* Ce je vrednost 1. argumenta manj od vrednosti 2. argumenta, se vrne
    vrednost 3. argumenta: */
    oo=nstack((stack)st, 5 );
    ret=doubleval(oo,st,user);
    end=1;
  } else if (x>=max)
  {
    /* Ce je vrednost 1. argumenta vec od vrednosti 4. argumenta, se vrne
    vrednost 5. argumenta: */
    oo=nstack((stack)st, 5 );
    ret=doubleval(oo,st,user);
    end=1;
  }
}
while (3*i<numargs && !end)
{
  oo=nstack((stack)st, 6+3*(i-1) );
  x1=doubleval(oo,st,user);
  oo=nstack((stack)st, 7+3*(i-1) );
  x2=doubleval(oo,st,user);
  if (x>=x1 && x<=x2)
  {
    end=1;
    oo=nstack((stack)st, 8+3*(i-1) );
    ret=doubleval(oo,st,user);
  }
}
return ret;
}


void assigndouble(ssyst syst,char *name,double x);

void instbasuserfunc(ssyst system)
    /* Na sistem za simbolno racunanje instalira osnovne uporabniske funkcije */
{
installuserfunc(system,"random",userrandom,NULL,NULL,NULL);
installuserfunc(system,"Sum",usersum,NULL,NULL,NULL);
installuserfunc(system,"Prod",userprod,NULL,NULL,NULL);
installuserfunc(system,"Tab",usertab,NULL,NULL,NULL);
installuserfunc(system,"Trapint",usertrapint,NULL,NULL,NULL);
installuserfunc(system,"Min",usermin,NULL,NULL,NULL);
installuserfunc(system,"Max",usermax,NULL,NULL,NULL);
installuserfunc(system,"If",userif,NULL,NULL,NULL);
installuserfunc(system,"Else",userelse,NULL,NULL,NULL);
installuserfunc(system,"Case",usercase,NULL,NULL,NULL);
installuserfunc(system,"Intdef",userintdef,NULL,NULL,NULL);
/* Definicija stevila pi in osnove naravnega logaritma: */
assigndouble(system,"c_pi",2*arcsin(1));
assigndouble(system,"c_e",exp(1));
}

void symbcalc(void)
     /* Simbolicni kalkulator */
{
ssyst system=NULL;
stack syst=NULL;
char *cmd,end=0;
initsymbsyst(&syst);
system=newssyst(syst);
instbasuserfunc(system);
helpsymbcalc();
do
{
  printf("\n com.: ");
  cmd=readline(500);
  if (cmd[0]=='$' && cmd[1]=='?')
    helpsymbcalc();
  comsyst(stdout,system,cmd);
  if (cmd[1]=='$')
    end=1;
  if (cmd[0]=='$')  /* Drugace se nizov ne sme brisati, ker so nalozeni na sklad. */
  {
    free(cmd);
    cmd=NULL;
  }
} while (!end);
}


void fsymbcalc(FILE *in,FILE *out)
     /* Simbolicni kalkulator; Navodila sprejema iz datoteke in, rezultate pa
     zapisuje v datoteko out. */
{
ssyst system=NULL;
stack syst=NULL;
char *cmd,end=0;
if (in!=NULL && out!=NULL)
{
  initsymbsyst(&syst);
  system=newssyst(syst);
  instbasuserfunc(system);
  do
  {
    fprintf(out,"\n com.: ");
    cmd=filereadline(in,500);
    /*
    if (cmd[strlen(cmd)-1]=='\n' || cmd[strlen(cmd)-1]=='\r')
      cmd[strlen(cmd)-1]='\0';
    */
    fprintf(out,"\"%s\"\n",cmd);
    comsyst(out,system,cmd);
    if (cmd[1]=='$')
      end=1;
    free(cmd);
    cmd=NULL;
  } while (!end);
  }
}

void filesymbcalc(char *nin,char *nout)
     /* Simbolicni kalkulator; Navodila sprejema iz datoteke  z imenom nin,
     rezultate pa zapisuje v datoteko z imenom nout. */
{
FILE *in, *out;
in=fopen(nin,"rb");
out=fopen(nout,"ab");
fsymbcalc(in,out);
fclose(in);
fclose(out);
}


void includeexp(ssyst syst, char *expression)
     /* V sistem za simbolno racunanje se vkljuci izraz expression. */
{
object t;
stack list=NULL;
list=cutexpression(expression,syst->syst);
arrangelistobj(list);
t=NULL;
t=maketree(list);
/* $$ SPREMEMBA!! To je vcasih bilo v rabi!
pushstack(syst->strings,stringcopy(expression));
pushstack(syst->cuts,list);
pushstack((stack) syst->trees,t);
*/
puttreetolist(t,& (syst->def), & (syst->trash), syst->user);
disptree(&t);
displistobj(&list);
}


double evaluateexp(ssyst syst, char *expression)
    /* Izracuna se vrednost izraza v sistemu za simbolno racunanje syst.
    Sam izraz se ne vkljuci v sistem za simbolno racunanje.
    $A Igor <== sep99; */
{
object t;
stack list=NULL;
double val;
int ndef,ntrash;
/* Izraz se ovrednoti glede na sistem za simbol. racunanje: */
list=cutexpression(expression,syst->syst);
arrangelistobj(list);
/* t=NULL; */
t=maketree(list);
/*
pushstack(syst->strings,stringcopy(expression));
pushstack(syst->cuts,list);
pushstack((stack) syst->trees,t);
*/
/* Zapomnim si velikost skladov def in trash na syst: */
ndef=syst->def->n; ntrash=syst->trash->n;
puttreetolist(t,& (syst->def), & (syst->trash), syst->user);
val=doubleval(t,syst->fst,syst->user);
/* Sedaj zbrisemo drevo t in spravimo sklada syst->def in
syst->trash v prvotno stanje: */
disptree(&t);
ndef=syst->def->n-ndef;
ntrash=syst->trash->n-ntrash;
/* $$$
if (ndef>0)
  npopstack( (stack) syst->def,ndef);
if (ntrash>0)
  npopstack( (stack) syst->trash,ntrash);
*/
displistobj(&list); /* $$$ */
return val;
}



void assigndouble(ssyst syst,char *name,double x)
     /* V sistemu ssyst poisce definicijo spremenljivke z imenom name in ji
     priredi vrednost tipa double. Ce definicija se ne obstaja, se objekt s
     tem imenom tvori na novo in potisne na sklad syst->def. Ce pa ze obstaja,
     se prejsnja definicija (torej desna veja objekta) potisne na sklad
     syst->trash. */
{
object t,r;
double *pval;
/* Najprej pogledamo, ce definicija taksne spremenljivke ze obstaja na skladu
syst->def: */
t=findobjnamesort(syst->def,name);
if (t==NULL)
{
  /* Ce taksna definicija se ne obstaja, jo dodamo: */
  t=newobject();
  /* $$
  pushstack( (stack) syst->def,t);
  */
  t->kind='D';
  t->subkind='V';
  t->name=stringcopy(name);
  t->l=t->r=NULL;
  
  inssortstack(syst->def,t,cmpobject);
  
}
/* Morebitne prejsnje definicije moramo spraviti na syst->trash: */
if (t->r!=NULL)
{
  /* $$$
  pushstack( (stack) syst->trash,t->r);
  */
  disptree(&(t->r)); /* $$$ */
  t->r=NULL;
}
if (t->l!=NULL)
{
  /* $$$
  pushstack( (stack) syst->trash,t->l);
  */
  disptree(&(t->l)); /* $$$ */
  t->l=NULL;
}
/* Desna veja objekta, ki sluzi kot definicija nase spremenljivke, postane
objekt, ki predstavlja stevilo tipa double z vrednostjo *pval, ki smo jo prej
priredili nasemu izrazu: */
t->r=newobject();
r=t->r;
r->name=stringdouble(x);
pval=malloc(sizeof(*pval));
*pval=x;
r->v=pval;
r->kind='0';
r->subkind='d';
}







             /*********************************/
             /*                               */
             /*   VISJENIVOJSKE FUNKCIJE ZA   */
             /*     UPORABO KALKULATORJA      */
             /*                               */
             /*********************************/




    /* GLOBALNI KALKULATOR: */


static ssyst globsyst=NULL;


double globcalcevaluate(char *expression)
    /* Ovrednoti izraz expression in vrne njegovo vrednost.
    $A Igor maj01; */
{
return evaluateexp(globsyst,expression);
}

void sendtoglobcalc(char *command);

void initglobcalc(void)
    /* Inicializira globalni kalkulatorj, ce se ni inicializiran.
    $A Igor maj01; */
{
if (globsyst==NULL)
{
  stack syststack=NULL;
  initsymbsyst(&syststack);
  globsyst=newssyst(syststack);
  instbasuserfunc(globsyst);
  /* Nastavi se funkcija za ovrednotenje izrazov pri branju stevil v strop.c: */
  setstropevaluateexpression(globcalcevaluate);
  setstropsendtocalc(sendtoglobcalc);
  printf("\n\nThe global calculator system has been initialised.\n\n");
}
}


void instglobcalc(ssyst s)
    /* Postavi globalni kalkulator na eksterni kalkulator s.
    $A Igor maj01; */
{
globsyst=s;
/* Nastavi se funkcija za ovrednotenje izrazov pri branju stevil v strop.c: */
if (s!=NULL)
  setstropevaluateexpression(globcalcevaluate);
}


ssyst getglobcalc(void)
    /* Vrne globalni kalkulator.
    $A Igor okt01; */
{
return globsyst;
}



static void edprinttree(object o,int lines,int columns)
    /* Pomozna funkcija za sendtoglobcalc.
    $A Igor maj01; */
{
FILE *fp;
char *fname;
fname=globuttmpnam1();
fp=fopen(fname,"wb");
if (fp!=NULL)
{
  fprinttree(fp,o,lines,columns);
  fclose(fp);
  globutview(fname,1);
} else
{
  errfunc0("edprinttree");
  fprintf(erf(),"Unable to open a temporary file \"%s\"\nprovided by function %s.\n",
   fname,"globuttmpnam1");
  errfunc2();
}
/*
FILE *fp;
fp=tmpfile();
if (fp!=NULL)
{
  fprinttree(fp,o,lines,columns);
  rewind(fp);
  while(!feof(fp))
    putchar(fgetc(fp));
  fclose(fp);
}
*/
}

static void edprinttreepart(object o,int lines,int columns)
    /* Pomozna funkcija za sendtoglobcalc.
    $A Igor maj01; */
{
FILE *fp;
char *fname;
fname=globuttmpnam1();
fp=fopen(fname,"wb");
if (fp!=NULL)
{
  fprinttreepart(fp,o,lines,columns);
  fclose(fp);
  globutview(fname,1);
} else
{
  errfunc0("edprinttreepart");
  fprintf(erf(),"Unable to open a temporary file \"%s\"\nprovided bt function %s.\n",
   fname,"globuttmpnam1");
  errfunc2();
}
}

static void edprinttreefull(object o,int lines,int columns)
    /* Pomozna funkcija za sendtoglobcalc.
    $A Igor maj01; */
{
FILE *fp;
char *fname;
fname=globuttmpnam1();
fp=fopen(fname,"wb");
if (fp!=NULL)
{
  fprinttreefull(fp,o,lines,columns);
  fclose(fp);
  globutview(fname,1);
} else
{
  errfunc0("edprinttreefull");
  fprintf(erf(),"Unable to open a temporary file \"%s\"\nprovided bt function %s.\n",
   fname,"globuttmpnam1");
  errfunc2();
}
}



void sendtoglobcalc(char *command)
    /* Poslje ukaz command globalnemu sistemu kalkulatorja. Definicije sprem.
    in funkcij morajo najprej vsebovati ime oz. ime z argumentnim blokom,
    nato dvopicje in nato definicijo.
    $A Igor maj01; */
{
ssyst syst;
int i,num,lines=55,columns=155,elines=100,ecolumns=1000;
stack list;
object t;
char *name;
int jj,kk;
char autoevaluate;
char *helpfile=NULL,*cm=NULL;
if (globsyst==NULL)
{
  /* Ce kalkulatorja se nismo uporabljali, se najprej zgradi njegov sistem: */
  initglobcalc();
}
syst=globsyst;
if (command[0]=='\\') /* Ukaz za specificno akcijo */
{
  if (command[1]=='h' || command[1]=='?')
  {
    /*
    helpfile=stringcat(com.basedir,"calc.hlp");
    cm=stringcat("more ",helpfile);
    system(cm);
    if (helpfile!=NULL) free(helpfile);
    if (cm!=NULL) free(cm);
    */
    FILE *fp=NULL;
    fp=fopensafe("calc.hlp","rb");
    if (fp==NULL)
      helpsymbcalc();
    else
    {
      char *ln;
      int i=0;
      while (!feof(fp))
      {
        ++i;
        ln=filereadline(fp,500);
        printf("%s\n",ln);
        if (ln!=NULL)
          free(ln);
        if (i==19)
        {
          printf("Press <Return>! ");
          readint(&i);
          i=0;
        }
      }
      fclose(fp);
    }
  }
  if (command[1]=='S' || command[1]=='s') /* Izpis preb. niza */
  {
    if (command[2]=='L' || command[2]=='l') /* Zadnji */
    {
      if (syst->strings->n>0)
        printf("\"%s\"", (char *) (syst->strings->s[syst->strings->n]) );
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')  /* vsi */
    {
      if (syst->strings->n>0)
      {
        printf("  Input strings:\n");
        for (i=1; i<=syst->strings->n; ++i)
        {
          printf("%i: ",i);
          printf("\"%s\"", (char *) (syst->strings->s[i]) );
          printf("\n");
        }
        printf("\n");
      }
    } else if (command[2]=='N' || command[2]=='n')  /* dolocen */
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->strings->n >=num)
        {
          printf("%i. inp. string:\n",num);
          printf("\"%s\"", (char *) (syst->strings->s[num]) );
          printf("\n\n");
        }
    }
  } else if (command[1]=='C' || command[1]=='c') /* Izpis v linearizirani obliki */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->cuts->n>0)
        printtabobj((stack) syst->cuts->s[syst->cuts->n]);
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->cuts->n>0)
        for (i=1; i<=syst->cuts->n; ++i)
        {
          printf("%i. cut:\n",i);
          printtabobj((stack) (syst->cuts->s[i]) );
          printf("\n\n");
        }
      printf("\n");

    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->cuts->n >=num)
        {
          printf("%i. cut:\n",num);
          printtabobj((stack) (syst->cuts->s[num]) );
          printf("\n\n");
        }
    }
  } else if (command[1]=='L' || command[1]=='l') /* Izpis v linearizirani obliki */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
        printlin((object) syst->def->s[syst->def->n]);
        printf("\n\n");

    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->def->n>0)
        for (i=1; i<=syst->def->n; ++i)
        {
          printf("%i. def:\n",i);
          printlin((object) (syst->def->s[i]) );
          printf("\n\n");
        }
      printf("\n");

    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          printf("%i. def:\n",num);
          printlin((object) (syst->def->s[num]) );
          printf("\n\n");
        }
    } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
    {
      jj=3;
      while (command[jj]==' ') ++jj;
      kk=jj;
      while (command[kk]!=' ' && command[kk]!='\0') ++kk;
      if (kk>jj)
      {
        name=stringncopy(command+jj,kk-jj);
        t=findobjname(syst->def,name);
        printf("\"%s\" :\n",name);
        printlin(t);
        printf("\n\n");
        free(name);
      }
    }
  } else if (command[1]=='T' || command[1]=='t' /* Izpisi drevo v okrnjeni obliki */
    || command[1]=='F' || command[1]=='f'  /* Izpisi drevo v polni obliki */
    || command[1]=='P' || command[1]=='p')  /* Izpisi drevo v delno polni obliki */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
        if (command[1]=='t') /* okrnjena oblika */
          printtree((object) syst->def->s[syst->def->n],lines,columns);
        else if(command[1]=='T') /* okrnjena oblika, izpis v editorju */
          edprinttree((object) syst->def->s[syst->def->n],elines,ecolumns);
        else if(command[1]=='f') /* polna oblika */
          printtreefull((object) syst->def->s[syst->def->n],lines,columns);
        else if(command[1]=='F') /* polna oblika, izpis v editorju */
          edprinttreefull((object) syst->def->s[syst->def->n],elines,ecolumns);
        else if (command[1]=='p')  /* delno okrnjena oblika */
          printtreepart((object) syst->def->s[syst->def->n],lines,columns);
        else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
          edprinttreepart((object) syst->def->s[syst->def->n],elines,ecolumns);
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      FILE *fp;
      char *temp=NULL;
      if (command[1]=='T' || command[1]=='F' || command[1]=='P')
      {
        fp=tmpfile();  /* fopen(com.tempfile,"wb"); */
      }
      if (syst->def->n>0)
        for (i=1; i<=syst->def->n; ++i)
        {
          if (command[1]=='T' || command[1]=='F' || command[1]=='P')
            fprintf(fp,"%i. def:\n",i);
          else
            printf("%i. def:\n",i);
          if (command[1]=='t') /* okrnjena oblika */
            printtree((object) (syst->def->s[i]) ,lines,columns);
          else if (command[1]=='T') /* okrnjena oblika, izpis v editorju */
            fprinttree(fp, (object) (syst->def->s[i]) ,elines,ecolumns);
          else if(command[1]=='f') /* polna oblika */
            printtreefull((object) (syst->def->s[i]) ,lines,columns);
          else if(command[1]=='F') /* polna oblika, izpis v editorju */
            fprinttreefull(fp, (object) (syst->def->s[i]) ,elines,ecolumns);
          else if (command[1]=='p')  /* delno okrnjena oblika */
            printtreepart((object) (syst->def->s[i]) ,lines,columns);
          else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
            fprinttreepart(fp, (object) (syst->def->s[i]) ,elines,ecolumns);
          if (command[1]=='T' || command[1]=='F' || command[1]=='P')
            fprintf(fp,"\n\n");
          else
            printf("\n\n");
        }
      printf("\n");
      if (command[1]=='T' || command[1]=='F' || command[1]=='P')
      {
        if (fp!=NULL)
        {
          rewind(fp);;
          while (!feof(fp))
            putchar(fgetc(fp));
          fclose(fp);
        }
        /*
        temp=com.lcom->param;
        com.lcom->param=com.tempfile;
        li_edit(com.lcom);
        com.lcom->param=temp;
        */
      }
    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          printf("%i. def:\n",num);
          if (command[1]=='t') /* okrnjena oblika */
            printtree((object) (syst->def->s[num]) ,lines,columns);
          else if (command[1]=='T') /* okrnjena oblika, izpis v editorju */
            edprinttree((object) (syst->def->s[num]) ,elines,ecolumns);
          else if(command[1]=='f') /* polna oblika */
            printtreefull((object) (syst->def->s[num]) ,lines,columns);
          else if(command[1]=='F') /* polna oblika, izpis v editorju */
            edprinttreefull((object) (syst->def->s[num]) ,elines,ecolumns);
          else if (command[1]=='p')  /* delno okrnjena oblika */
            printtreepart((object) (syst->def->s[num]) ,lines,columns);
          else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
            edprinttreepart((object) (syst->def->s[num]) ,elines,ecolumns);
          printf("\n\n");
        }
    } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
    {
      jj=3;
      while (command[jj]==' ') ++jj;
      kk=jj;
      while (command[kk]!=' ' && command[kk]!='\0') ++kk;
      if (kk>jj)
      {
        name=stringncopy(command+jj,kk-jj);
        t=findobjname((stack) syst->def,name);
        printf("\"%s\" :\n",name);
        if (command[1]=='t') /* okrnjena oblika */
          printtree(t,lines,columns);
        else if (command[1]=='T') /* okrnjena oblika, izpis v editorju */
          edprinttree(t,elines,ecolumns);
        else if(command[1]=='f') /* polna oblika */
          printtreefull(t,lines,columns);
        else if(command[1]=='F') /* polna oblika, izpis v editorju */
          edprinttreefull(t,elines,ecolumns);
        else if (command[1]=='p')  /* delno okrnjena oblika */
          printtreepart(t,lines,columns);
        else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
          edprinttreepart(t,elines,ecolumns);
        printf("\n\n");
        free(name);
      }
    }
  } else if (command[1]=='E' || command[1]=='e') /* Ovrednotenje dreves */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
      {
        t=syst->def->s[syst->def->n];
        printf("Vrednost spremenljivke \"%s\" :\n",t->name);
        if (t->subkind=='V')
          printf("%.10g",doubleval(t,syst->fst,syst->user));
        else printf("ni spremenljivka.");
        printf("\n\n");
      } else printf("Na skladu ni definicij.\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->def->n>0)
      {
        for (i=1; i<=syst->def->n; ++i)
        {
          t=syst->def->s[i];
          printf("Vrednost %i. spremenljivke (\"%s\") : ",i,t->name);
          if (t->subkind=='V')
            printf("%.10g",doubleval(t,syst->fst,syst->user));
          else printf("ni spremenljivka.");
          printf("\n");
        }
      } else printf("Na skladu ni definicij.\n\n");
      printf("\n\n");
    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          t=syst->def->s[num];
          printf("Vrednost %i. spremenljivke (\"%s\") : ",num,t->name);
          if (t->subkind=='V')
            printf("%.10g",doubleval(t,syst->fst,syst->user));
          else printf("ni spremenljivka.");
          printf("\n");
        } else printf("Na skladu ni definicij.\n\n");
    } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
    {
      jj=3;
      while (command[jj]==' ') ++jj;
      kk=jj;
      while (command[kk]!=' ' && command[kk]!='\0') ++kk;
      if (kk>jj)
      {
        name=stringncopy(command+jj,kk-jj);
        t=findobjname((stack) syst->def,name);
        printf("Vrednost spremenljivke \"%s\" :\n",name);
        if (t->subkind=='V')
          printf("%.10g",doubleval(t,syst->fst,syst->user));
        else printf("ni spremenljivka.");
        printf("\n\n");
        free(name);
      }
    }
  } else if (command[1]=='V' || command[1]=='v') /* Imena spremenljivk in
  definiranih funkcij */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
        printf("Name of the last object in main list: \"%s\"\n",
         ((object) syst->def->s[syst->def->n])->name );
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->def->n>0)
        for (i=1; i<=syst->def->n; ++i)
        {
          /* printf("%i. def:\n",i); */
          printf("Name of %i. object in main list: \"%s\"\n", i,
           ((object) syst->def->s[i])->name );
          /* printf("\n\n"); */
        }
      printf("\n");
    } else if (command[2]=='N' || command[2]=='n')  /* Sprem. z doloc. zap. st. */
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          printf("%i. def:\n",num);
          printf("Name of %i. object in main list: \"%s\"\n",num,
           ((object) syst->def->s[num])->name );

          printf("\n\n");
        }
    }
  } else if (command[1]=='R' || command[1]=='r') /* Pogon sistem. ukaza */
  {
    system(command+3);
  } else if (command[1]=='X' || command[1]=='x') /* Ponovitev ukaza z dano zap. st. */
  {
    i=sscanf(command+3,"%i",&num);
    if (i==1)
      if (syst->strings->n >= num)
        sendtoglobcalc(stringcopy(syst->strings->s[num]));
  } else if (command[1]=='*' || command[1]=='*') /* Komentar */
  {

    printf("%s\n",command+2);
  }
} else if (command!=NULL) if (command[0]!='\0')
{
  char *point=NULL;
  double x=0;
  int start,end;
  point=strchr(command,':');
  if (point!=NULL)
  {
    ++point;
    /* Ce v izrazu nastopa "::", gre za prireditev vrednosti izraza na desni
    strani dvojnega dvopicja spremenljivki z imenom na levi strani dvojnega
    dvopicja: */
    if (point[0]==':' || point[0]=='=')
      ++point;
    else
      point=command;
  } else
    point=command;
  list=cutexpression(point,syst->syst);
  arrangelistobj(list);
  t=NULL;
  t=maketree(list);
  if (t->name[0]==':' && t->name[1]=='\0' && t->kind=='2')
    autoevaluate=0;
  else
    autoevaluate=1;
  /*
  printtree(t,lines,columns);
  */
  pushstack(syst->strings,stringcopy(command));
  pushstack(syst->cuts,list);
  pushstack((stack) syst->trees,t);
  puttreetolist(t,& (syst->def), & (syst->trash), syst->user);
  if (autoevaluate)
    printf("        = %.10g\n",doubleval(t,syst->fst,syst->user));
  if (point!=command)
  {
    /* Prireditev vrednosti izraza, ki je na desni strani dvojnega dvopicja v
    command, spremenljivki z imanom, ki je na levi strani dvojnega dvopicja: */
    start=0;
    while (command[start]==' ')
      ++start;
    end=start;
    while (command[end]!=' ' && command[end]!=':')
      ++end;
    point=stringncopy(command+start,end-start);
    x=doubleval(t,syst->fst,syst->user);
    assigndouble(globsyst,point,x);
    free(point); point=NULL;
  }
  /*
  printtreefull(t,lines,columns);
  */
}
}



void globcalcint(void)
    /* Interaktivno delo v sistemu globalnega kalkulatorja. Omogoca definicijo
    in ovrednotenje in definicijo spremenljivk in funkcij ter preverjanje
    stanja sistema global. kalkulatorja (katere stvari so definirane in kako).
    $A Igor maj01; */
{
int buflength=2000; /* Maksimalna dolzina vrstice */
char end=0,*buf=NULL,*command;
/* Ce ima ukaz argumente, se izvrsi le vrstica od zacetka 1. argumenta naprej: */
if (globsyst==NULL)
  initglobcalc();
{
  printf("Type in commands or expressions; \"\\x\" or \"\\q\" for quit, \"\\?\" or \"\\h\" for help.\n\n");
  /* statusline(); */
  buf=malloc(buflength);
  while (!end)
  {
    printf("Calc >");
    buf[0]='\0';
    gets(buf);
    command=memnotnchr(buf,strlen(buf)," ",1);
    /*
    if (command!=NULL)
    {
      pos=(void *) memnchr(command,strlen(command)," ",1);
      if (pos!=NULL)
        cm=stringncopy(command,pos-command);
      else
        cm=stringcopy(command);
    }
    */
    if (command[0]=='\\' && (command[1]=='q' || command[1]=='x'))
      end=1;
    else
      sendtoglobcalc(command);
  }
  if (buf!=NULL)
    free(buf);
  printf("\n");
}
}



         /****************************************/
         /*                                      */
         /*     DEFINICIJA FUNKCIJ S POMOCJO     */
         /*       GLOBALNEGA KALKULATORJA        */
         /*                                      */
         /****************************************/


/* Struktura za reprezentacijo definicij: */
typedef struct {
    stack args;
    char *namevar,*namefunc;
    object t;
} _calcdefffunc;

typedef _calcdefffunc *calcdefffunc;

/* Sklad definicij in pomozni spremenljivki: */
static stack calcdeffuncst=NULL;
static calcdefffunc df=NULL;
static double *dptr=NULL;



/* FUNKCIJE ENE SPREMENLJIVKE: */


void *defglobcalcfunc1d(char *defstr)
    /* Definira funkcijo ene spremenljivke v globalnem kalkulatorju z nizom
    defstr, kjer mora biti argument funkcije oznacen z nizom "x". Vrne kazalec,
    s katerim se dostopa do funkcije.
    $A Igor maj01; */
{
calcdefffunc def=NULL;
char *str=NULL,*str1=NULL;
int place,i;
if (defstr==NULL)
  return NULL;
else if (strlen(defstr)<1)
  return NULL;
if (calcdeffuncst==NULL)
  calcdeffuncst=newstack(1);
/* Naredimo objekt, kjer bodo podatki o definiciji, in ga damo na ustrezno
mestno na skladu: */
def=malloc(sizeof(*def));
place=0;   i=1;
while (i<=calcdeffuncst->n && !place)
{
  if (calcdeffuncst->s[i]==NULL)
    place=i;
  else ++i;
}
if (place)
  calcdeffuncst->s[place]=def;
else
{
  pushstack(calcdeffuncst,(void *)def);
  place=calcdeffuncst->n;
}
/* Kreiramo imeni funkcije in spremenljivke v sistemu kalkulatorja, ki
predstavlja definicijo: */
def->namefunc=stringcat("globcalcfuncdef",(str=stringlong(place)));
disppointer((void **)&str);
def->namevar=stringcat("var",def->namefunc);
/* Definiramo ustrezno funkcijo in spremenljivko, preko katere jo bomo
dostopali, v sistemu globalnega kalkulatorja: */
str=stringcat(def->namefunc,"[x]: ");
str1=stringcat(str,defstr);
sendtoglobcalc(str1);
disppointer((void **)&str);
disppointer((void **)&str1);
str=stringcat(def->namevar,": ");
str1=stringcat(str,def->namefunc);
disppointer((void **)&str);
str=stringcat(str1,"[1.0]");
sendtoglobcalc(str);
disppointer((void **)&str);
disppointer((void **)&str1);
/* Poiscemo definicijo speremenljivke, preko katere bomo dostopali do
definicije, in pozicijo parametra, ki jo damo na def->args kot kazalce na
double: */
def->t=findobjname(globsyst->def,def->namevar);
def->args=newstack(1);
pushstack(def->args,(void *) def->t->r->r->v);
return (void *) def;
}


void * defglobcalcfunc1dint(void)
    /* Interaktivna definicija funkcije ene spremenljivke v globalnem
    kalkulatorju z nizom str, kjer mora biti argument funkcije oznacen z
    nizom "x". Funkcija vrne kazalec, s katerim se dostopa do definicije
    funkcije.
    $A Igor maj01; */
{
char *def=NULL;
void *ret=NULL;
printf("f[x]: ");
readstring(&def);
if (strlensafe(def)<1)
{
  disppointer((void **) &def);
  def=stringcopy("0.0");
}
ret=defglobcalcfunc1d(def);
disppointer((void **) &def);
return ret;
}


double globcalcfunc1d(void *defptr,double x)
    /* Vrne vrednost funkcije ene spremenljivke, ki je definirana preko
    globalnega kalkulatorja in je ptr kazalec na njeno definicijo, v tocki x.
    $A Igor maj01; */
{
if (defptr==NULL)
{
  errfunc0("globcalcfunc1d");
  fprintf(erf(),"Pointer to function definition is NULL.\n");
  errfunc2();
  return 0;
} else
{
  df= (calcdefffunc) defptr;  /* podatki o definiciji funkcije */
  if (df->args->n!=1)
  {
    /* Neustrezno stevilo argumentov v definiciji funkcije: */
    errfunc0("globcalcfunc1d");
    fprintf(erf(),"Number of arguments in function definition different than 1 (%i).\n",
     df->args->n);
    errfunc2();
    return 0;
  } else
  {
    /* Argumente postavimo na ustrezna mesta in ovrednotimo funkcijo: */
    dptr=df->args->s[1];
    *dptr=x;
    return doubleval(df->t,globsyst->fst,globsyst->user);
  }
}
}



/* FUNKCIJE DVEH SPREMENLJIVK: */


void *defglobcalcfunc2d(char *defstr)
    /* Definira funkcijo dveh spremenljivk v globalnem kalkulatorju z nizom
    defstr, kjer morata biti argumenta funkcije oznacena z nizoma "x" in "y".
    Vrne kazalec, s katerim se dostopa do funkcije.
    $A Igor maj01; */
{
calcdefffunc def=NULL;
char *str=NULL,*str1=NULL;
int place,i;
if (defstr==NULL)
  return NULL;
else if (strlen(defstr)<1)
  return NULL;
if (calcdeffuncst==NULL)
  calcdeffuncst=newstack(1);
/* Naredimo objekt, kjer bodo podatki o definiciji, in ga damo na ustrezno
mestno na skladu: */
def=malloc(sizeof(*def));
place=0;   i=1;
while (i<=calcdeffuncst->n && !place)
{
  if (calcdeffuncst->s[i]==NULL)
    place=i;
  else ++i;
}
if (place)
  calcdeffuncst->s[place]=def;
else
{
  pushstack(calcdeffuncst,(void *)def);
  place=calcdeffuncst->n;
}
/* Kreiramo imeni funkcije in spremenljivke v sistemu kalkulatorja, ki
predstavlja definicijo: */
def->namefunc=stringcat("globcalcfuncdef",(str=stringlong(place)));
disppointer((void **)&str);
def->namevar=stringcat("var",def->namefunc);
/* Definiramo ustrezno funkcijo in spremenljivko, preko katere jo bomo
dostopali, v sistemu globalnega kalkulatorja: */
str=stringcat(def->namefunc,"[x,y]: ");
str1=stringcat(str,defstr);
sendtoglobcalc(str1);
disppointer((void **)&str);
disppointer((void **)&str1);
str=stringcat(def->namevar,": ");
str1=stringcat(str,def->namefunc);
disppointer((void **)&str);
str=stringcat(str1,"[1.0,2.0]");
sendtoglobcalc(str);
disppointer((void **)&str);
disppointer((void **)&str1);
/* Poiscemo definicijo speremenljivke, preko katere bomo dostopali do
definicije, in pozicijo parametra, ki jo damo na def->args kot kazalce na
double: */
def->t=findobjname(globsyst->def,def->namevar);
def->args=newstack(1);
pushstack(def->args,(void *) def->t->r->r->l->v);
pushstack(def->args,(void *) def->t->r->r->r->v);
return (void *) def;
}


void * defglobcalcfunc2dint(void)
    /* Interaktivna definicija funkcije dveh spremenljivke v globalnem
    kalkulatorju z nizom str, kjer morata biti argumenta funkcije oznacena z
    nizom "x" in "y". Funkcija vrne kazalec, s katerim se dostopa do definicije
    funkcije.
    $A Igor maj01; */
{
char *def=NULL;
void *ret=NULL;
printf("f[x,y]: ");
readstring(&def);
if (strlensafe(def)<1)
{
  disppointer((void **) &def);
  def=stringcopy("0.0");
}
ret=defglobcalcfunc2d(def);
disppointer((void **) &def);
return ret;
}

double globcalcfunc2d(void *defptr,double x,double y)
    /* Vrne vrednost funkcije dveh spremenljivk, ki je definirana preko
    globalnega kalkulatorja in je ptr kazalec na njeno definicijo, v tocki
    (x,y).
    $A Igor maj01; */
{
if (defptr==NULL)
{
  errfunc0("globcalcfunc2d");
  fprintf(erf(),"Pointer to function definition is NULL.\n");
  errfunc2();
  return 0;
} else
{
  df= (calcdefffunc) defptr;  /* podatki o definiciji funkcije */
  if (df->args->n!=2)
  {
    /* Neustrezno stevilo argumentov v definiciji funkcije: */
    errfunc0("globcalcfunc2d");
    fprintf(erf(),"Number of arguments in function definition different than 2 (%i).\n",
     df->args->n);
    errfunc2();
    return 0;
  } else
  {
    /* Argumente postavimo na ustrezna mesta in ovrednotimo funkcijo: */
    dptr=df->args->s[1];
    *dptr=x;
    dptr=df->args->s[2];
    *dptr=y;
    return doubleval(df->t,globsyst->fst,globsyst->user);
  }
}
}



/* FUNKCIJE TREH SPREMENLJIVK: */


void *defglobcalcfunc3d(char *defstr)
    /* Definira funkcijo treh spremenljivk v globalnem kalkulatorju z nizom
    defstr, kjer morajo biti argumenti funkcije oznaceni z nizi "x", "y" in "z".
    Vrne kazalec, s katerim se dostopa do funkcije.
    $A Igor maj01; */
{
calcdefffunc def=NULL;
char *str=NULL,*str1=NULL;
int place,i;
if (defstr==NULL)
  return NULL;
else if (strlen(defstr)<1)
  return NULL;
if (calcdeffuncst==NULL)
  calcdeffuncst=newstack(1);
/* Naredimo objekt, kjer bodo podatki o definiciji, in ga damo na ustrezno
mestno na skladu: */
def=malloc(sizeof(*def));
place=0;   i=1;
while (i<=calcdeffuncst->n && !place)
{
  if (calcdeffuncst->s[i]==NULL)
    place=i;
  else ++i;
}
if (place)
  calcdeffuncst->s[place]=def;
else
{
  pushstack(calcdeffuncst,(void *)def);
  place=calcdeffuncst->n;
}
/* Kreiramo imeni funkcije in spremenljivke v sistemu kalkulatorja, ki
predstavlja definicijo: */
def->namefunc=stringcat("globcalcfuncdef",(str=stringlong(place)));
disppointer((void **)&str);
def->namevar=stringcat("var",def->namefunc);
/* Definiramo ustrezno funkcijo in spremenljivko, preko katere jo bomo
dostopali, v sistemu globalnega kalkulatorja: */
str=stringcat(def->namefunc,"[x,y,z]: ");
str1=stringcat(str,defstr);
sendtoglobcalc(str1);
disppointer((void **)&str);
disppointer((void **)&str1);
str=stringcat(def->namevar,": ");
str1=stringcat(str,def->namefunc);
disppointer((void **)&str);
str=stringcat(str1,"[1.0,2.0,3.0]");
sendtoglobcalc(str);
disppointer((void **)&str);
disppointer((void **)&str1);
/* Poiscemo definicijo speremenljivke, preko katere bomo dostopali do
definicije, in pozicijo parametra, ki jo damo na def->args kot kazalce na
double: */
def->t=findobjname(globsyst->def,def->namevar);
def->args=newstack(1);
pushstack(def->args,(void *) def->t->r->r->l->l->v);
pushstack(def->args,(void *) def->t->r->r->l->r->v);
pushstack(def->args,(void *) def->t->r->r->r->v);
return (void *) def;
}


void * defglobcalcfunc3dint(void)
    /* Interaktivna definicija funkcije treh spremenljivke v globalnem
    kalkulatorju z nizom str, kjer morajo biti argumenti funkcije oznaceni z
    nizi "x", "y" in "z". Funkcija vrne kazalec, s katerim se dostopa do
    definicije funkcije.
    $A Igor maj01; */
{
char *def=NULL;
void *ret=NULL;
printf("f[x,y,z]: ");
readstring(&def);
if (strlensafe(def)<1)
{
  disppointer((void **) &def);
  def=stringcopy("0.0");
}
ret=defglobcalcfunc3d(def);
disppointer((void **) &def);
return ret;
}

double globcalcfunc3d(void *defptr,double x,double y,double z)
    /* Vrne vrednost funkcije treh spremenljivk, ki je definirana preko
    globalnega kalkulatorja in je ptr kazalec na njeno definicijo, v tocki
    (x,y,z).
    $A Igor maj01; */
{
if (defptr==NULL)
{
  errfunc0("globcalcfunc3d");
  fprintf(erf(),"Pointer to function definition is NULL.\n");
  errfunc2();
  return 0;
} else
{
  df= (calcdefffunc) defptr;  /* podatki o definiciji funkcije */
  if (df->args->n!=3)
  {
    /* Neustrezno stevilo argumentov v definiciji funkcije: */
    errfunc0("globcalcfunc3d");
    fprintf(erf(),"Number of arguments in function definition different than 2 (%i).\n",
     df->args->n);
    errfunc2();
    return 0;
  } else
  {
    /* Argumente postavimo na ustrezna mesta in ovrednotimo funkcijo: */
    dptr=df->args->s[1];
    *dptr=x;
    dptr=df->args->s[2];
    *dptr=y;
    dptr=df->args->s[3];
    *dptr=z;
    return doubleval(df->t,globsyst->fst,globsyst->user);
  }
}
}




/* FUNKCIJE VEKTORSKE SPREMENLJIVKE: */


static char *numargstr(int n)
    /* Naredi in vrne niz, ki je sestavljen iz n stevilcnih argumentov
    (1.1, 2.1, 3.1, ...) v oglatih oklepajih. Niz se lahko brise s free().
    $A igor maj01; */
{
int i;
char *str=NULL,*str1=NULL,*str2=NULL;
if (n==0)
  return stringcopy("[]");
str=stringcopy("[");
for (i=1;i<=n;++i)
{
  str1=stringlong(i);
  str2=stringcat(str,str1);
  disppointer((void **) &str);
  disppointer((void **) &str1);
  if (i<n) /* ker to ni zadnji argument, moramo dodati vejico */
  {
    str=stringcat(str2,".1,");
    disppointer((void **) &str2);
  } else
  {
    str=stringcat(str2,".1");
    disppointer((void **) &str2);
  }
}
str1=stringcat(str,"]");
disppointer((void **) &str);
return str1;
}

static char *xargstr(int n)
    /* Naredi in vrne niz, ki je sestavljen iz n simbolnih argumentov
    (x1, x2, x3, ...) v oglatih oklepajih. Niz se lahko brise s free().
    $A igor maj01; */
{
int i;
char *str=NULL,*str1=NULL,*str2=NULL;
if (n==0)
  return stringcopy("[]");
str=stringcopy("[");
for (i=1;i<=n;++i)
{
  str1=stringlong(i);
  str2=stringcat("x",str1);
  disppointer((void **) &str1);
  str1=stringcat(str,str2);
  disppointer((void **) &str);
  disppointer((void **) &str2);
  if (i<n) /* ker to ni zadnji argument, moramo dodati vejico */
  {
    str=stringcat(str1,",");
    disppointer((void **) &str1);
  } else
  {
    str=str1;
    str1=NULL;
  }
}
str1=stringcat(str,"]");
disppointer((void **) &str);
return str1;
}

static char *xpargstr(int m, int n)
    /* Naredi in vrne niz, ki je sestavljen iz m simbolnih argumentov
    x1, x2, x3, ..., in n simbolnih argumentov p1, p2, ... v oglatih
    oklepajih. Niz se lahko brise s free().
    $A igor maj01; */
{
int i;
char *str=NULL,*str1=NULL,*str2=NULL;
if (n==0 && m==0)
  return stringcopy("[]");
str=stringcopy("[");
for (i=1;i<=m;++i)
{
  str1=stringlong(i);
  str2=stringcat("x",str1);
  disppointer((void **) &str1);
  str1=stringcat(str,str2);
  disppointer((void **) &str);
  disppointer((void **) &str2);
  if (i<m || n>0) /* ker to ni zadnji argument, moramo dodati vejico */
  {
    str=stringcat(str1,",");
    disppointer((void **) &str1);
  } else
  {
    str=str1;
    str1=NULL;
  }
}
for (i=1;i<=n;++i)
{
  str1=stringlong(i);
  str2=stringcat("p",str1);
  disppointer((void **) &str1);
  str1=stringcat(str,str2);
  disppointer((void **) &str);
  disppointer((void **) &str2);
  if (i<n) /* ker to ni zadnji argument, moramo dodati vejico */
  {
    str=stringcat(str1,",");
    disppointer((void **) &str1);
  } else
  {
    str=str1;
    str1=NULL;
  }
}
str1=stringcat(str,"]");
disppointer((void **) &str);
return str1;
}

static char *symbargstr(stack st)
    /* Naredi in vrne niz, ki je sestavljen iz simbolnih argumentov z imeni,
    ki so kot nizi na skladu st, v oglatih oklepajih. Niz se lahko brise s
    free().
    $A igor maj01; */
{
int i;
char *str=NULL,*str1=NULL,*str2=NULL;
if (st==NULL)
  return stringcopy("[]");
else if (st->n==0)
  return stringcopy("[]");
str=stringcopy("[");
for (i=1;i<=st->n;++i)
{
  str2=stringcopy(st->s[i]);
  str1=stringcat(str,str2);
  disppointer((void **) &str);
  disppointer((void **) &str2);
  if (i<st->n) /* ker to ni zadnji argument, moramo dodati vejico */
  {
    str=stringcat(str1,",");
    disppointer((void **) &str1);
  } else
  {
    str=str1;
    str1=NULL;
  }
}
str1=stringcat(str,"]");
disppointer((void **) &str);
return str1;
}



void *defglobcalcfuncvec(char *defstr,int n)
    /* Definira funkcijo vektorske spremenljivke v globalnem kalkulatorju z
    nizom defstr, kjer morajo biti argumenti funkcije oznaceni z nizi "x1",
    "x2" "x3", ...  n je stevilo argumentov funkcije (oz. komponent vektorskega
    argumenta). Vrne kazalec, s katerim se dostopa do funkcije.
    $A Igor maj01; */
{
calcdefffunc def=NULL;
char *str=NULL,*str1=NULL,*str2=NULL;
int place,i;
object o;
if (defstr==NULL)
  return NULL;
else if (strlen(defstr)<1)
  return NULL;
if (calcdeffuncst==NULL)
  calcdeffuncst=newstack(1);
/* Naredimo objekt, kjer bodo podatki o definiciji, in ga damo na ustrezno
mestno na skladu: */
def=malloc(sizeof(*def));
place=0;   i=1;
while (i<=calcdeffuncst->n && !place)
{
  if (calcdeffuncst->s[i]==NULL)
    place=i;
  else ++i;
}
if (place)
  calcdeffuncst->s[place]=def;
else
{
  pushstack(calcdeffuncst,(void *)def);
  place=calcdeffuncst->n;
}
/* Kreiramo imeni funkcije in spremenljivke v sistemu kalkulatorja, ki
predstavlja definicijo: */
def->namefunc=stringcat("globcalcfuncdef",(str=stringlong(place)));
disppointer((void **)&str);
def->namevar=stringcat("var",def->namefunc);
/* Definiramo ustrezno funkcijo in spremenljivko, preko katere jo bomo
dostopali, v sistemu globalnega kalkulatorja: */
str1=xargstr(n);
str2=stringcat(def->namefunc,str1);
str=stringcat(str2,": ");
disppointer((void **)&str1);
disppointer((void **)&str2);
str1=stringcat(str,defstr);
sendtoglobcalc(str1);
disppointer((void **)&str);
disppointer((void **)&str1);
str=stringcat(def->namevar,": ");
str1=stringcat(str,def->namefunc);
str2=numargstr(n);
disppointer((void **)&str);
str=stringcat(str1,str2);
sendtoglobcalc(str);
disppointer((void **)&str);
disppointer((void **)&str1);
disppointer((void **)&str1);
/* Poiscemo definicijo speremenljivke, preko katere bomo dostopali do
definicije, in pozicijo parametra, ki jo damo na def->args kot kazalce na
double: */
def->t=findobjname(globsyst->def,def->namevar);
/* Seznam argumentov v drevesni obliki spravimo na sklad def->args: */
def->args=treelist(def->t->r->r);
if (def->args==NULL)
  def->args=newstack(1);
for (i=1;i<=def->args->n;++i)
{
  /* Na skladu morajo biti namesto objektov njihovi kazalci (...)->v: */
  o=(object) def->args->s[i];
  def->args->s[i]=o->v;
}
return (void *) def;
}


void * defglobcalcfuncvecint(int n)
    /* Interaktivna definicija funkcije vektorske spremenljivke v globalnem
    kalkulatorju z nizom, kjer morajo biti argumenti funkcije oznaceni z
    nizi "x1", "x2", ... Funkcija vrne kazalec, s katerim se dostopa do
    definicije funkcije. n je stevilo argumentov funkcije.
    $A Igor maj01; */
{
char *def=NULL,*argstr=NULL;
void *ret=NULL;
argstr=xargstr(n);
printf("f%s:\n",argstr);
disppointer((void **) &argstr);
readstring(&def);
if (strlensafe(def)<1)
{
  disppointer((void **) &def);
  def=stringcopy("0.0");
}
ret=defglobcalcfuncvec(def,n);
disppointer((void **) &def);
return ret;
}

double globcalcfuncvec(void *defptr,vector v)
    /* Vrne vrednost funkcije vektorske spremenljivke, ki je definirana preko
    globalnega kalkulatorja in je ptr kazalec na njeno definicijo, v tocki v.
    $A Igor maj01; */
{
int i;
if (defptr==NULL)
{
  errfunc0("globcalcfuncvec");
  fprintf(erf(),"Pointer to function definition is NULL.\n");
  errfunc2();
  return 0;
} else if (v==NULL)
{
  errfunc0("globcalcfuncvec");
  fprintf(erf(),"Function argument is NULL.\n");
  errfunc2();
  return 0;
} else
{
  df= (calcdefffunc) defptr;  /* podatki o definiciji funkcije */
  if (df->args->n!=v->d)
  {
    /* Neustrezno stevilo argumentov v definiciji funkcije: */
    errfunc0("globcalcfuncvec");
    fprintf(erf(),"Number of arguments in function definition different than %i (%i).\n",
     v->d,df->args->n);
    errfunc2();
    return 0;
  } else
  {
    /* Argumente postavimo na ustrezna mesta in ovrednotimo funkcijo: */
    for (i=1;i<=v->d;++i)
    {
      dptr=df->args->s[i];
      *dptr=v->v[i];
    }
    return doubleval(df->t,globsyst->fst,globsyst->user);
  }
}
}




/* DEFINICIJA FUNKCIJE VEC SPREMENLJIVK Z IMENI ARGUMENTOV, ki so podana na
skladu: */

void *defglobcalcfuncvecsymb(char *defstr,stack st)
    /* Definira funkcijo vec argumentov v globalnem kalkulatorju z nizom
    defstr, kjer morajo biti argumenti funkcije oznaceni z nizi, lo so na
    skladu st. Vrne kazalec, s katerim se dostopa do funkcije.
    $A Igor maj01; */
{
calcdefffunc def=NULL;
char *str=NULL,*str1=NULL,*str2=NULL;
int place,i;
object o;
if (defstr==NULL)
  return NULL;
else if (strlen(defstr)<1)
  return NULL;
if (calcdeffuncst==NULL)
  calcdeffuncst=newstack(1);
/* Naredimo objekt, kjer bodo podatki o definiciji, in ga damo na ustrezno
mestno na skladu: */
def=malloc(sizeof(*def));
place=0;   i=1;
while (i<=calcdeffuncst->n && !place)
{
  if (calcdeffuncst->s[i]==NULL)
    place=i;
  else ++i;
}
if (place)
  calcdeffuncst->s[place]=def;
else
{
  pushstack(calcdeffuncst,(void *)def);
  place=calcdeffuncst->n;
}
/* Kreiramo imeni funkcije in spremenljivke v sistemu kalkulatorja, ki
predstavlja definicijo: */
def->namefunc=stringcat("globcalcfuncdef",(str=stringlong(place)));
disppointer((void **)&str);
def->namevar=stringcat("var",def->namefunc);
/* Definiramo ustrezno funkcijo in spremenljivko, preko katere jo bomo
dostopali, v sistemu globalnega kalkulatorja: */
str1=symbargstr(st);
str2=stringcat(def->namefunc,str1);
str=stringcat(str2,": ");
disppointer((void **)&str1);
disppointer((void **)&str2);
str1=stringcat(str,defstr);
sendtoglobcalc(str1);
disppointer((void **)&str);
disppointer((void **)&str1);
str=stringcat(def->namevar,": ");
str1=stringcat(str,def->namefunc);
if (st==NULL)
  str2=numargstr(0);
else
  str2=numargstr(st->n);
disppointer((void **)&str);
str=stringcat(str1,str2);
sendtoglobcalc(str);
disppointer((void **)&str);
disppointer((void **)&str1);
disppointer((void **)&str1);
/* Poiscemo definicijo speremenljivke, preko katere bomo dostopali do
definicije, in pozicijo parametra, ki jo damo na def->args kot kazalce na
double: */
def->t=findobjname(globsyst->def,def->namevar);
/* Seznam argumentov v drevesni obliki spravimo na sklad def->args: */
def->args=treelist(def->t->r->r);
if (def->args==NULL)
  def->args=newstack(1);
for (i=1;i<=def->args->n;++i)
{
  /* Na skladu morajo biti namesto objektov njihovi kazalci (...)->v: */
  o=(object) def->args->s[i];
  def->args->s[i]=o->v;
}
return (void *) def;
}


void * defglobcalcfuncvecsymbint(stack st)
    /* Interaktivna definicija funkcije vec spremenljivk v globalnem
    kalkulatorju. V nizu, ki definira funkcijo, morajo biti argumenti funkcije
    oznaceni z nizi na skladu st. Funkcija vrne kazalec, s katerim se dostopa
    do definicije funkcije.
    $A Igor maj01; */
{
char *def=NULL,*argstr=NULL;
void *ret=NULL;
argstr=symbargstr(st);
printf("f%s:\n",argstr);
disppointer((void **) &argstr);
readstring(&def);
if (strlensafe(def)<1)
{
  disppointer((void **) &def);
  def=stringcopy("0.0");
}
ret=defglobcalcfuncvecsymb(def,st);
disppointer((void **) &def);
return ret;
}

double globcalcfuncvecsymb(void *defptr,vector v)
    /* Vrne vrednost funkcije vec spremenljivk, ki je definirana preko
    globalnega kalkulatorja in je ptr kazalec na njeno definicijo, v tocki v.
    Namesto te funkcije se lahko uporabi kar globcalcfuncvec().
    $A Igor maj01; */
{
return globcalcfuncvec(defptr,v);
}





/* PARAMETRICNE FUNKCIJE (argumenti x1, x2, ... in parametri p1, p2, ...): */

void *defglobcalcfuncvecpar(char *defstr,int m,int n)
    /* Definira parametricno funkcijo vektorske spremenljivke v globalnem
    kalkulatorju z nizom defstr, kjer morajo biti argumenti funkcije oznaceni z
    nizi "x1", "x2" "x3", ... in parametri z nizi "p1", "p2" "p3", ... m je
    stevilo argumentov funkcije (oz. komponent vektorskega argumenta), n pa
    stevilo parametrov. Vrne kazalec, s katerim se dostopa do funkcije.
    $A Igor maj01; */
{
calcdefffunc def=NULL;
char *str=NULL,*str1=NULL,*str2=NULL;
int place,i;
object o;
if (defstr==NULL)
  return NULL;
else if (strlen(defstr)<1)
  return NULL;
if (calcdeffuncst==NULL)
  calcdeffuncst=newstack(1);
/* Naredimo objekt, kjer bodo podatki o definiciji, in ga damo na ustrezno
mestno na skladu: */
def=malloc(sizeof(*def));
place=0;   i=1;
while (i<=calcdeffuncst->n && !place)
{
  if (calcdeffuncst->s[i]==NULL)
    place=i;
  else ++i;
}
if (place)
  calcdeffuncst->s[place]=def;
else
{
  pushstack(calcdeffuncst,(void *)def);
  place=calcdeffuncst->n;
}
/* Kreiramo imeni funkcije in spremenljivke v sistemu kalkulatorja, ki
predstavlja definicijo: */
def->namefunc=stringcat("globcalcfuncdef",(str=stringlong(place)));
disppointer((void **)&str);
def->namevar=stringcat("var",def->namefunc);
/* Definiramo ustrezno funkcijo in spremenljivko, preko katere jo bomo
dostopali, v sistemu globalnega kalkulatorja: */
str1=xpargstr(m,n);
str2=stringcat(def->namefunc,str1);
str=stringcat(str2,": ");
disppointer((void **)&str1);
disppointer((void **)&str2);
str1=stringcat(str,defstr);
sendtoglobcalc(str1);
disppointer((void **)&str);
disppointer((void **)&str1);
str=stringcat(def->namevar,": ");
str1=stringcat(str,def->namefunc);
str2=numargstr(m+n);
disppointer((void **)&str);
str=stringcat(str1,str2);
sendtoglobcalc(str);
disppointer((void **)&str);
disppointer((void **)&str1);
disppointer((void **)&str1);
/* Poiscemo definicijo speremenljivke, preko katere bomo dostopali do
definicije, in pozicijo parametra, ki jo damo na def->args kot kazalce na
double: */
def->t=findobjname(globsyst->def,def->namevar);
/* Seznam argumentov v drevesni obliki spravimo na sklad def->args: */
def->args=treelist(def->t->r->r);
if (def->args==NULL)
  def->args=newstack(1);
for (i=1;i<=def->args->n;++i)
{
  /* Na skladu morajo biti namesto objektov njihovi kazalci (...)->v: */
  o=(object) def->args->s[i];
  def->args->s[i]=o->v;
}
return (void *) def;
}


void * defglobcalcfuncvecparint(int m,int n)
    /* Interaktivna definicija funkcije vektorske spremenljivke v globalnem
    kalkulatorju z nizom, v katerem morajo biti argumenti funkcije oznaceni z
    nizi "x1", "x2", ... in parametri z nizi "p1", "p2" "p3", ... m je stevilo
    argumentov funkcije (oz. komponent vektorskega argumenta), n pa stevilo
    parametrov.  Funkcija vrne kazalec, s katerim se dostopa do
    definicije funkcije.
    $A Igor maj01; */
{
char *def=NULL,*argstr=NULL;
void *ret=NULL;
argstr=xpargstr(m,n);
printf("f%s:\n",argstr);
disppointer((void **) &argstr);
readstring(&def);
if (strlensafe(def)<1)
{
  disppointer((void **) &def);
  def=stringcopy("0.0");
}
ret=defglobcalcfuncvecpar(def,m,n);
disppointer((void **) &def);
return ret;
}

double globcalcfuncvecpar(void *defptr,vector v,vector p)
    /* Vrne vrednost funkcije parametricne vektorske spremenljivke, ki je
    definirana preko globalnega kalkulatorja in je ptr kazalec na njeno
    definicijo, v tocki v.
    $A Igor maj01; */
{
int i;
if (defptr==NULL)
{
  errfunc0("globcalcfuncvecpar");
  fprintf(erf(),"Pointer to function definition is NULL.\n");
  errfunc2();
  return 0;
} else if (v==NULL)
{
  errfunc0("globcalcfuncvecpar");
  fprintf(erf(),"Function argument is NULL.\n");
  errfunc2();
  return 0;
} else
{
  df= (calcdefffunc) defptr;  /* podatki o definiciji funkcije */
  if (df->args->n!=v->d+p->d)
  {
    /* Neustrezno stevilo argumentov v definiciji funkcije: */
    errfunc0("globcalcfuncvecpar");
    fprintf(erf(),"Common number of arguments and parameters in function definition \ndifferent than %i (%i).\n",
     v->d+p->d,df->args->n);
    errfunc2();
    return 0;
  } else
  {
    /* Argumente postavimo na ustrezna mesta in ovrednotimo funkcijo: */
    for (i=1;i<=v->d;++i)
    {
      dptr=df->args->s[i];
      *dptr=v->v[i];
    }
    for (i=1;i<=p->d;++i)
    {
      dptr=df->args->s[v->d+i];
      *dptr=p->v[i];
    }
    return doubleval(df->t,globsyst->fst,globsyst->user);
  }
}
}





