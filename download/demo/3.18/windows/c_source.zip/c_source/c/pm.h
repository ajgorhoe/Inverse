/*
		  ***********PROGRAMMING MANAGER***********

  Orodje za pomoc pri programiranju.

*/


#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
# ifdef WNDOWS
 #include <direct.h>
#endif
# ifdef UNIX
 #include <unistd.h>
#endif


#include <mtypes.h>
#include <st.h>
#include <strop.h>
#include <fop.h>
#include <lint.h>
#include <fint.h>
#include <fint.h>
#include <globut.h>
#include <udir.h>



struct
{
   int buflength,
       id,        /* identifikacijska stevilka */
       numfiles,  /* st. imen datotek za hitro referenco */
       numdirs,   /* st. imen direktorijev za hitro referenco */
       numcoms,   /* st. ukazov za hitro referenco */
       numhist;
   char *buf;
   licom lcom;
   ficom fcom;
   char *basedir,   /* bazicni direktorij programa */
        *tempdir,
        *tempfile,  /* ime pomozne datoteke */
        *sesfile,   /* ime identifikacijske datoteke procesa */
        *editcom;   /* ime ukaza za editiranje (na koncu mora biti presledek */
   stack files,     /* imena datotek (za hitro referenco) */
         dirs,      /* imena direktorijev (za hitro referenco) */
         coms,      /* ukazi (za hitro referenco) */
         hist,      /* zgodovina unixovih ukazov */
         csyst;     /* za kalkulator */
   ssyst csystem;   /* sistem kalkulatorja */
   stack dir;       /* podatki o direktorijih */
   dircom dc;       /* ukazna struktura za izpis direktorijev */
   /* Command-line arguments and environment variables: */
   int argc;
   char **argv,**env;
} com={0};


#ifdef DOSSYNTAX
 static char isDOS=1;
#else
 static char isDOS=0;
#endif





void showmore(char *file)
     /* Pokaze vsebino tekstovne datoteke file in sicer po en zaslon naenkrat. */
{
char *command=NULL,*str=NULL,*tempfile=NULL;
if (file!=NULL)
{
  /* Tempfile postane unikatno ime datoteke na sistemu, ki ni prirejeno nobeni
  obstojeci datoteki; To datoteko bomo uporabili za kopiranje originala: */
  /*
  tempfile= (char *) makestring(256);
  tempfile=tmpnam(tempfile);
  */
  tempfile=stringcopy(com.tempfile);
  /* Originalno datoteko skopiramo v datoteko tempfile: */
  if (isDOS)
  {
    command=stringcat("copy ",file);
  } else
  {
    command=stringcat("cp ",file);
  }
  str=stringcat(command," ");
  if (command!=NULL)
    free(command);
  command=stringcat(str,tempfile);
  if (str!=NULL)
    free(str);
  str=NULL;
  if (command!=NULL)
  {
    system(command);
    free(command);
    command=NULL;
  }
  /* Izvrsitev ukaz more nad kopijo originala: */
  if (isDOS)
  {
    command=stringcat("type ",tempfile);
  } else
  {
    command=stringcat("more ",tempfile);
  }
  system(command);
  if (command!=NULL)
    free(command);
  command=NULL;
  /* Brisanje kopije originala: */
  if (tempfile!=NULL)
  {
    /* remove(tempfile); */
    free(tempfile);
    tempfile=NULL;
  }
}
}



void showedit(char *file)
{
char *command=NULL,*str=NULL,*tempfile=NULL;
if (file!=NULL)
{
  /* Tempfile postane unikatno ime datoteke na sistemu, ki ni prirejeno nobeni
  obstojeci datoteki; To datoteko bomo uporabili za kopiranje originala: */
  /*
  tempfile= (char *) makestring(256);
  tempfile=tmpnam(tempfile);
  */
  tempfile=stringcopy(com.tempfile);
  /* Originalno datoteko skopiramo v datoteko tempfile: */
  if (isDOS)
  {
    command=stringcat("copy ",file);
  } else
  {
    command=stringcat("cp ",file);
  }
  str=stringcat(command," ");
  if (command!=NULL)
    free(command);
  command=stringcat(str,tempfile);
  if (str!=NULL)
    free(str);
  str=NULL;
  if (command!=NULL)
  {
    system(command);
    free(command);
    command=NULL;
  }
  /* Izvrsitev ukaz more nad kopijo originala: */
  command=stringcat(com.editcom,tempfile);
  system(command);
  if (command!=NULL)
    free(command);
  command=NULL;
  /* Brisanje kopije originala: */
  if (tempfile!=NULL)
  {
    /* remove(tempfile); */
    free(tempfile);
    tempfile=NULL;
  }
}
}



void showeditpar(char *file)
{
char *command=NULL,*str=NULL,*tempfile=NULL;
if (file!=NULL)
{
  /* Tempfile postane unikatno ime datoteke na sistemu, ki ni prirejeno nobeni
  obstojeci datoteki; To datoteko bomo uporabili za kopiranje originala: */
  /*
  tempfile= (char *) makestring(256);
  tempfile=tmpnam(tempfile);
  */
  tempfile=stringcopy(com.tempfile);
  /* Originalno datoteko skopiramo v datoteko tempfile: */
  if (isDOS)
  {
    command=stringcat("copy ",file);
  } else
  {
    command=stringcat("cp ",file);
  }
  str=stringcat(command," ");
  if (command!=NULL)
    free(command);
  command=stringcat(str,tempfile);
  if (str!=NULL)
    free(str);
  str=NULL;
  if (command!=NULL)
  {
    system(command);
    free(command);
    command=NULL;
  }
  /* Izvrsitev ukaz more nad kopijo originala: */
  str=stringcat(com.editcom,tempfile);
  command=stringcat(str," &");
  system(command);
  if (str!=NULL)
    free(str);
  if (command!=NULL)
    free(command);
  command=str=NULL;
  /* Brisanje kopije originala: */
  if (tempfile!=NULL)
  {
    /* remove(tempfile); */
    free(tempfile);
    tempfile=NULL;
  }
}
}




void edit(char *filename)
{
char *comint=NULL;
comint=stringcat(com.editcom,filename);
if (comint!=NULL)
{
  system(comint);
  free(comint);
}
}


void editpar(char *filename)
{
char *comint=NULL,*temp=NULL;
temp=stringcat(com.editcom,filename);
comint=stringcat(temp," &");
if (comint!=NULL)
{
  system(comint);
  free(comint);
}
if (temp!=NULL)
  free(temp);
}




/* FUNKCIJE, KI SKRBIJO ZA HITRO REFERENCO: */



void puttohistory(char * command)
{
void * ptr;
if (com.hist!=NULL && com.numhist>0 && command!=NULL)
{
  if (cmpstrings(command, (char *) com.hist->s[1])!=0)
  {
    insstack(com.hist,stringcopy(command),1);
    if (com.hist->n>com.numhist)
    {
      ptr=popstack(com.hist);
      if (ptr!=NULL)
        free(ptr);
    }
  }
}
}


static void setnum(stack st,int num)
{
int i,n;
void *p;
if (st!=NULL)
{
  n=st->n;
  if (num<n)
  {
    for (i=1; i<=n-num; ++i)
    {
      p=popstack(st);
      if (p!=NULL)
        free(p);
    }
  } else if (num>n)
  {
    for (i=1; i<=num-n; ++i)
      pushstack(st,stringcopy(""));
  }
} else
  printf("ERROR: stack not initialized.\n");
}


static void setnumfiles(int num)
{
com.numfiles=num;
if (com.files==NULL)
  com.files=newstack(5);
setnum(com.files,num);
}


static void setnumdirs(int num)
{
com.numdirs=num;
if (com.dirs==NULL)
  com.dirs=newstack(5);
setnum(com.dirs,num);
}


static void setnumcoms(int num)
{
com.numcoms=num;
if (com.coms==NULL)
  com.coms=newstack(5);
setnum(com.coms,num);
}


static void setnumhist(int num)
{
com.numhist=num;
if (com.hist==NULL)
  com.hist=newstack(5);
setnum(com.hist,num);
}



static void setstring(int num,char *str,stack st)
{
if (st!=NULL)
{
  if (num>0 && num<=st->n)
  {
    if (st->s[num]!=NULL)
      free(st->s[num]);
    st->s[num]=stringcopy(str);
  } else printf("ERROR: out of stack range.\n");
} else printf("ERROR: stack not initialized.\n");
}



static void printstrings(stack st)
{
char *str;
int i;
if (st!=NULL && st->n>0)
{
  /* printf("%i strings:\n\n"); */
  for (i=1; i<=st->n; ++i)
  {
    str=st->s[i];
    if (str!=NULL)
      if (strlen(str)>0)
        printf("%3i.: \"%s\"\n",i,str);
  }
} else
  printf("Empty stack.\n");
}


static char* choosefileold(void)
       /* POZOR! Niza, ki ga vrne ta funkcija, ne smes brisati s free() ! */
{
int num,cont,buflength=500;
char *buf=NULL;
buf=malloc(buflength);
printf("Files:\n");
printstrings(com.files);
printf("Your choice (%i to %i): ",1,com.files->n);
gets(buf);
cont=sscanf(buf,"%i",&num);
if (buf!=NULL) free(buf);
if (cont>0 && num>0 && num<com.files->n)
{
  if (com.files->s[num]!=NULL)
    /* return stringcopy(com.files->s[num]); */
    return com.files->s[num];
  else return NULL;
}
if (cont<=0)
  return /* stringcopy(com.files->s[1]); */ com.files->s[1];
return NULL;
}




static char* choosefile(void)
       /* POZOR! Niza, ki ga vrne ta funkcija, ne smes brisati s free() ! */
{
int num,cont,buflength=500;
char *buf=NULL;
buf=malloc(buflength);
printf("Files:\n");
printstrings(com.files);
printf("Your choice (%i to %i): ",1,com.files->n);
gets(buf);
cont=sscanf(buf,"%i",&num);
if (cont<1 && strlen(buf)>0)
{
  int i=0,j=0,numfound=0,whichfound=0;
  char found=0;
  printf("Found:");
  while (i<com.files->n)
  {
    ++i;
    found=1;
    for (j=0; j<=(int) strlen(buf)-1; ++j)
      if (buf[j]!=((char *)(com.files->s[i]))[j])
        found=0;
    if (found)
    {
      ++numfound;
      printf(" %s ",com.files->s[i]);
      if (numfound==1)
        whichfound=i;
    }
  }
  printf("\n");
  if (numfound>1)
  {
    printf("More than one found.\n");
    return com.files->s[whichfound];
  } else if (numfound<1)
  {
    printf("None found.\n");
    return NULL;
  } else
  {
    return com.files->s[whichfound];
  }
} else
{
  if (buf!=NULL) free(buf);
  if (cont>0 && num>0 && num<com.files->n)
  {
    if (com.files->s[num]!=NULL)
      /* return stringcopy(com.files->s[num]); */
      return com.files->s[num];
    else return NULL;
  }
  if (cont<=0)
    return /* stringcopy(com.files->s[1]); */ com.files->s[1];
  return NULL;
}
}



static char* choosedir(void)
{
int num,cont,buflength=500;
char *buf=NULL;
buf=malloc(buflength);
printf("Directories:\n");
printstrings(com.dirs);
printf("Your choice (%i to %i): ",1,com.dirs->n);
gets(buf);
cont=sscanf(buf,"%i",&num);
if (buf!=NULL) free(buf);
if (cont>0 && num>0 && num<com.dirs->n)
{
  if (com.dirs->s[num]!=NULL)
    return stringcopy(com.dirs->s[num]);
  else return NULL;
}
if (cont<=0)
  return stringcopy(com.dirs->s[1]);
return NULL;
}



static char* choosecom(void)
       /* POZOR! Niza, ki ga vrne ta funkcija, ne smes brisati s free() ! */
{
int num,cont,buflength=500;
char *buf=NULL;
buf=malloc(buflength);
printf("Commands:\n");
printstrings(com.coms);
printf("Your choice (%i to %i): ",1,com.coms->n);
gets(buf);
cont=sscanf(buf,"%i",&num);
if (cont<1 && strlen(buf)>0)
{
  int i=0,j=0,numfound=0,whichfound=0;
  char found=0;
  printf("Found:");
  while (i<com.coms->n)
  {
    ++i;
    found=1;
    for (j=0; j<=(int) strlen(buf)-1; ++j)
      if (buf[j]!=((char *)(com.coms->s[i]))[j])
        found=0;
    if (found)
    {
      ++numfound;
      printf(" %s ",com.coms->s[i]);
      if (numfound==1)
        whichfound=i;
    }
  }
  printf("\n");
  if (numfound>1)
  {
    printf("More than one found.\n");
    return com.coms->s[whichfound];
  } else if (numfound<1)
  {
    printf("None found.\n");
    return NULL;
  } else
  {
    return com.coms->s[whichfound];
  }
} else
{
  if (buf!=NULL) free(buf);
  if (cont>0 && num>0 && num<com.coms->n)
  {
    if (com.coms->s[num]!=NULL)
      /* return stringcopy(com.coms->s[num]); */
      return com.coms->s[num];
    else return NULL;
  }
  if (cont<=0)
    return /* stringcopy(com.coms->s[1]); */ com.coms->s[1];
  return NULL;
}
}



static char* choosehist(void)
       /* POZOR! Niza, ki ga vrne ta funkcija, ne smes brisati s free() ! */
{
int num,cont,buflength=500;
char *buf=NULL;
buf=malloc(buflength);
printf("History of commands:\n");
printstrings(com.hist);
printf("Your choice (%i to %i): ",1,com.hist->n);
gets(buf);
cont=sscanf(buf,"%i",&num);
if (cont<1 && strlen(buf)>0)
{
  int i=0,j=0,numfound=0,whichfound=0;
  char found=0;
  printf("Found:");
  while (i<com.hist->n)
  {
    ++i;
    found=1;
    for (j=0; j<=(int) strlen(buf)-1; ++j)
      if (buf[j]!=((char *)(com.hist->s[i]))[j])
        found=0;
    if (found)
    {
      ++numfound;
      printf(" %s ",com.hist->s[i]);
      if (numfound==1)
        whichfound=i;
    }
  }
  printf("\n");
  if (numfound>1)
  {
    printf("More than one found.\n");
    return com.hist->s[whichfound];
  } else if (numfound<1)
  {
    printf("None found.\n");
    return NULL;
  } else
  {
    return com.hist->s[whichfound];
  }
} else
{
  if (buf!=NULL) free(buf);
  if (cont>0 && num>0 && num<com.hist->n)
  {
    if (com.hist->s[num]!=NULL)
      /* return stringcopy(com.hist->s[num]); */
      return com.hist->s[num];
    else return NULL;
  }
  if (cont<=0)
    return /* stringcopy(com.hist->s[1]); */ com.hist->s[1];
  return NULL;
}
}



static char *pwdinfo(void)
     /* Vrne niz, ki vsebuje kombinacijo Unixovih ukazov hostname in pwd.
     Niz, ki ga vrne ta funkcija, se lahko brise s free. */
{
int buflength=100;
char *ret=NULL,*buf=NULL,*tmp=NULL;
FILE *fp;
buf=malloc(buflength);
tmp=stringcat("hostname > ",com.tempfile);
system(tmp);   free(tmp);  tmp=NULL;
fp=fopen(com.tempfile,"rb");
tmp=fgets(buf,buflength,fp);
fclose(fp);
if (buf[strlen(buf)-1]=='\n' || buf[strlen(buf)-1]=='\r')
  buf[strlen(buf)-1]='\0';
ret=stringcat(buf,":");
tmp=stringcat("pwd > ",com.tempfile);
system(tmp);   free(tmp);  tmp=NULL;
fp=fopen(com.tempfile,"rb");
tmp=fgets(buf,buflength,fp);
fclose(fp);
if (buf[strlen(buf)-1]=='\n' || buf[strlen(buf)-1]=='\r')
  buf[strlen(buf)-1]='\0';
tmp=ret;
ret=stringcat(tmp,buf);
free(tmp);
if (buf!=NULL)
  free(buf);
return ret;
}



static void endpm(void);

static void statusline(void)
{
char *str=NULL;
FILE *fp=NULL;
if (com.sesfile!=NULL)
{
  fp=fopen(com.sesfile,"rb");
  if (fp==NULL)
  {
    printf("\nSession file \"%s\" removed,\nterminating process (%s %s, ID %i).\n\n",
     com.sesfile,globutgetprogram(),globutgetstringversion(),globutgetsesid());
    endpm();
    exit(1);
  } else fclose(fp);
}

if (isDOS)
{

}
else
{
  str=pwdinfo();
  printf("  <<  %s/  >> \n",str);
}
if (str!=NULL)
  free(str);
}







void li_viewcom(licom lcom)
    /* Nastavitev imena viewerja. */
{
char printname=0,*str=NULL;
if (lcom->param!=NULL)
{
  if (strlen(lcom->param)>0)
  {
    /*
    if (com.editcom!=NULL)
      free(com.editcom);
    com.editcom=stringcat(lcom->param," ");
    */
    globutsetviewer(lcom->param);
  } else
    printname=1;
} else
  printname=1;
if (printname)
{
  /*
  str=stringcopy(com.editcom);
  if (str[strlen(str)-1]==' ')
    str[strlen(str)-1]='\0';
  */
  printf("Viewer is currently \"%s\".\n",globutgetviewer());
  if (str!=NULL)
  {
    free(str);
    str=NULL;
  }
}
}


void li_browsecom(licom lcom)
    /* Nastavitev imena viewerja. */
{
char printname=0,*str=NULL;
if (lcom->param!=NULL)
{
  if (strlen(lcom->param)>0)
  {
    /*
    if (com.editcom!=NULL)
      free(com.editcom);
    com.editcom=stringcat(lcom->param," ");
    */
    globutsetbrowser(lcom->param);
  } else
    printname=1;
} else
  printname=1;
if (printname)
{
  /*
  str=stringcopy(com.editcom);
  if (str[strlen(str)-1]==' ')
    str[strlen(str)-1]='\0';
  */
  printf("Browser is currently \"%s\".\n",globutgetbrowser());
  if (str!=NULL)
  {
    free(str);
    str=NULL;
  }
}
}


void li_editcom(licom lcom)
    /* Nastavitev imena editorja. */
{
char printname=0,*str=NULL;
if (lcom->param!=NULL)
{
  if (strlen(lcom->param)>0)
  {
    /*
    if (com.editcom!=NULL)
      free(com.editcom);
    com.editcom=stringcat(lcom->param," ");
    */
    globutseteditor(lcom->param);
  } else
    printname=1;
} else
  printname=1;
if (printname)
{
  /*
  str=stringcopy(com.editcom);
  if (str[strlen(str)-1]==' ')
    str[strlen(str)-1]='\0';
  */
  printf("Editor is currently \"%s\".\n",globutgeteditor());
  if (str!=NULL)
  {
    free(str);
    str=NULL;
  }
}
}



void li_listfiles(licom lcom)
{
printf("Files:\n");
printstrings(com.files);
}


void li_listdirs(licom lcom)
{
printf("Directories:\n");
printstrings(com.dirs);
}


void li_listcoms(licom lcom)
{
printf("Commands:\n");
printstrings(com.coms);
}


void li_setnumfiles(licom lcom)
{
int cont,num,buflength=500;
char *buf=NULL;
buf=malloc(buflength);
if (lcom->param!=NULL)
{
  cont=sscanf(lcom->param,"%i",&num);
} else
{
  printf("Number of files (now %i): ",com.numfiles);
  gets(buf);
  cont=sscanf(buf,"%i",&num);
}
if (cont>0 && num>0)
  setnumfiles(num);
if (buf!=NULL)
  free(buf);
}

void li_setnumdirs(licom lcom)
{
int cont,num,buflength=500;
char *buf=NULL;
buf=malloc(buflength);
if (lcom->param!=NULL)
{
  cont=sscanf(lcom->param,"%i",&num);
} else
{
  printf("Number of directories (now %i): ",com.numdirs);
  gets(buf);
  cont=sscanf(buf,"%i",&num);
}
if (cont>0 && num>0)
  setnumdirs(num);
if (buf!=NULL)
  free(buf);
}


void li_setnumcoms(licom lcom)
{
int cont,num,buflength=500;
char *buf=NULL;
buf=malloc(buflength);
if (lcom->param!=NULL)
{
  cont=sscanf(lcom->param,"%i",&num);
} else
{
  printf("Number of commands (now %i): ",com.numcoms);
  gets(buf);
  cont=sscanf(buf,"%i",&num);
}
if (cont>0 && num>0)
  setnumcoms(num);
if (buf!=NULL)
  free(buf);
}


void li_setnumhist(licom lcom)
{
int cont,num,buflength=500;
char *buf=NULL;
buf=malloc(buflength);
if (lcom->param!=NULL)
{
  cont=sscanf(lcom->param,"%i",&num);
} else
{
  printf("Number of commands in history list (now %i): ",com.numhist);
  gets(buf);
  cont=sscanf(buf,"%i",&num);
}
if (cont>0 && num>0)
  setnumhist(num);
if (buf!=NULL)
  free(buf);
}


void li_setfiles(licom lcom)
{
int cont,i,buflength=200;
char *buf=NULL;
buf=malloc(buflength);
if (lcom->param!=NULL)
{
  cont=sscanf(lcom->param,"%i",&i);
  if (cont>0)
  {
    printf("  %i. file (now \"%s\"): ",i,com.files->s[i]);
    buf[0]='\0';
    gets(buf);
    if (strlen(buf)>0)
    {
      if (com.files->s[i]!=NULL) free(com.files->s[i]);
      com.files->s[i]=stringcopy(buf);
    }
  }
} else
{
  for (i=1; i<=com.files->n; ++i)
  {
    printf("  %i. file (now \"%s\"): ",i,com.files->s[i]);
    buf[0]='\0';
    gets(buf);
    if (strlen(buf)>0)
    {
      if (com.files->s[i]!=NULL) free(com.files->s[i]);
      com.files->s[i]=stringcopy(buf);
    }
  }
}
if (buf!=NULL)
  free(buf);
}



void li_setdirs(licom lcom)
{
int cont,i,buflength=200;
char *buf=NULL;
buf=malloc(buflength);
if (lcom->param!=NULL)
{
  cont=sscanf(lcom->param,"%i",&i);
  if (cont>0)
  {
    printf("  %i. directory (now \"%s\"): ",i,com.dirs->s[i]);
    buf[0]='\0';
    gets(buf);
    if (strlen(buf)>0)
    {
      if (com.dirs->s[i]!=NULL) free(com.dirs->s[i]);
      com.dirs->s[i]=stringcopy(buf);
    }
  }
} else
{
  for (i=1; i<=com.dirs->n; ++i)
  {
    printf("  %i. directory (now \"%s\"): ",i,com.dirs->s[i]);
    buf[0]='\0';
    gets(buf);
    if (strlen(buf)>0)
    {
      if (com.dirs->s[i]!=NULL) free(com.dirs->s[i]);
      com.dirs->s[i]=stringcopy(buf);
    }
  }
}
if (buf!=NULL)
  free(buf);
}



void li_setcoms(licom lcom)
{
int cont,i,buflength=200;
char *buf=NULL;
buf=malloc(buflength);
if (lcom->param!=NULL)
{
  cont=sscanf(lcom->param,"%i",&i);
  if (cont>0)
  {
    printf("  %i. command (now \"%s\"): ",i,com.coms->s[i]);
    buf[0]='\0';
    gets(buf);
    if (strlen(buf)>0)
    {
      if (com.coms->s[i]!=NULL) free(com.coms->s[i]);
      com.coms->s[i]=stringcopy(buf);
    }
  }
} else
{
  for (i=1; i<=com.coms->n; ++i)
  {
    printf("  %i. com (now \"%s\"): ",i,com.coms->s[i]);
    buf[0]='\0';
    gets(buf);
    if (strlen(buf)>0)
    {
      if (com.coms->s[i]!=NULL) free(com.coms->s[i]);
      com.coms->s[i]=stringcopy(buf);
    }
  }
}
if (buf!=NULL)
  free(buf);
}



void li_execute(licom lcom)
     /* Izvrsi v unixu ukaz, ki je bil vtipkan v vrsticnem interpreterju. */
{
puttohistory(lcom->line);
system(lcom->line);
}






/* FUNKCIJE ZA UPORABO KALKULATORJA: */




void li_edit(licom);

void edprinttree(object o,int lines,int columns)
{
FILE *fp;
char *temp=NULL;
fp=fopen(com.tempfile,"wb");
fprinttree(fp,o,lines,columns);
fclose(fp);
temp=com.lcom->param;
com.lcom->param=com.tempfile;
li_edit(com.lcom);
com.lcom->param=temp;
}

void edprinttreepart(object o,int lines,int columns)
{
FILE *fp;
char *temp=NULL;
fp=fopen(com.tempfile,"wb");
fprinttreepart(fp,o,lines,columns);
fclose(fp);
temp=com.lcom->param;
com.lcom->param=com.tempfile;
li_edit(com.lcom);
com.lcom->param=temp;
}

void edprinttreefull(object o,int lines,int columns)
{
FILE *fp;
char *temp=NULL;
fp=fopen(com.tempfile,"wb");
fprinttreefull(fp,o,lines,columns);
fclose(fp);
temp=com.lcom->param;
com.lcom->param=com.tempfile;
li_edit(com.lcom);
com.lcom->param=temp;
}



void pmsendtocalc(char *command)
{
ssyst syst;
int i,num,lines=55,columns=155,elines=100,ecolumns=1000;
stack list;
object t;
char *name;
int jj,kk;
char autoevaluate;
char *helpfile=NULL,*cm=NULL;
if (com.csystem==NULL)
{
  /* Ce kalkulatorja se nismo uporabljali, se najprej zgradi njegov sistem: */
  initsymbsyst((stack *)&com.csyst);
  com.csystem= newssyst( (stack) com.csyst);
  instbasuserfunc(com.csystem);
  instglobcalc(com.csystem);
}
syst=com.csystem;
if (command[0]=='\\') /* Ukaz za specificno akcijo */
{
  if (command[1]=='h' || command[1]=='?')
  {
    helpfile=stringcat(com.basedir,"calc.hlp");
    cm=stringcat("more ",helpfile);
    system(cm);
    if (helpfile!=NULL) free(helpfile);
    if (cm!=NULL) free(cm);
  }
  if (command[1]=='S' || command[1]=='s') /* Izpis preb. niza */
  {
    if (command[2]=='L' || command[2]=='l') /* Zadnji */
    {
      if (syst->strings->n>0)
        printf("\"%s\"", (char *) (syst->strings->s[syst->strings->n]) );
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')  /* vsi */
    {
      if (syst->strings->n>0)
      {
        printf("  Input strings:\n");
        for (i=1; i<=syst->strings->n; ++i)
        {
          printf("%i: ",i);
          printf("\"%s\"", (char *) (syst->strings->s[i]) );
          printf("\n");
        }
        printf("\n");
      }
    } else if (command[2]=='N' || command[2]=='n')  /* dolocen */
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->strings->n >=num)
        {
          printf("%i. inp. string:\n",num);
          printf("\"%s\"", (char *) (syst->strings->s[num]) );
          printf("\n\n");
        }
    }
  } else if (command[1]=='C' || command[1]=='c') /* Izpis v linearizirani obliki */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->cuts->n>0)
        printtabobj((stack) syst->cuts->s[syst->cuts->n]);
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->cuts->n>0)
        for (i=1; i<=syst->cuts->n; ++i)
        {
          printf("%i. cut:\n",i);
          printtabobj((stack) (syst->cuts->s[i]) );
          printf("\n\n");
        }
      printf("\n");

    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->cuts->n >=num)
        {
          printf("%i. cut:\n",num);
          printtabobj((stack) (syst->cuts->s[num]) );
          printf("\n\n");
        }
    }
  } else if (command[1]=='L' || command[1]=='l') /* Izpis v linearizirani obliki */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
        printlin((object) syst->def->s[syst->def->n]);
        printf("\n\n");

    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->def->n>0)
        for (i=1; i<=syst->def->n; ++i)
        {
          printf("%i. def:\n",i);
          printlin((object) (syst->def->s[i]) );
          printf("\n\n");
        }
      printf("\n");

    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          printf("%i. def:\n",num);
          printlin((object) (syst->def->s[num]) );
          printf("\n\n");
        }
    } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
    {
      jj=3;
      while (command[jj]==' ') ++jj;
      kk=jj;
      while (command[kk]!=' ' && command[kk]!='\0') ++kk;
      if (kk>jj)
      {
        name=stringncopy(command+jj,kk-jj);
        t=findobjname(syst->def,name);
        printf("\"%s\" :\n",name);
        printlin(t);
        printf("\n\n");
        free(name);
      }
    }
  } else if (command[1]=='T' || command[1]=='t' /* Izpisi drevo v okrnjeni obliki */
    || command[1]=='F' || command[1]=='f'  /* Izpisi drevo v polni obliki */
    || command[1]=='P' || command[1]=='p')  /* Izpisi drevo v delno polni obliki */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
        if (command[1]=='t') /* okrnjena oblika */
          printtree((object) syst->def->s[syst->def->n],lines,columns);
        else if(command[1]=='T') /* okrnjena oblika, izpis v editorju */
          edprinttree((object) syst->def->s[syst->def->n],elines,ecolumns);
        else if(command[1]=='f') /* polna oblika */
          printtreefull((object) syst->def->s[syst->def->n],lines,columns);
        else if(command[1]=='F') /* polna oblika, izpis v editorju */
          edprinttreefull((object) syst->def->s[syst->def->n],elines,ecolumns);
        else if (command[1]=='p')  /* delno okrnjena oblika */
          printtreepart((object) syst->def->s[syst->def->n],lines,columns);
        else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
          edprinttreepart((object) syst->def->s[syst->def->n],elines,ecolumns);
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      FILE *fp;
      char *temp=NULL;
      if (command[1]=='T' || command[1]=='F' || command[1]=='P')
      {
        fp=fopen(com.tempfile,"wb");
      }
      if (syst->def->n>0)
        for (i=1; i<=syst->def->n; ++i)
        {
          if (command[1]=='T' || command[1]=='F' || command[1]=='P')
            fprintf(fp,"%i. def:\n",i);
          else
            printf("%i. def:\n",i);
          if (command[1]=='t') /* okrnjena oblika */
            printtree((object) (syst->def->s[i]) ,lines,columns);
          else if (command[1]=='T') /* okrnjena oblika, izpis v editorju */
            fprinttree(fp, (object) (syst->def->s[i]) ,elines,ecolumns);
          else if(command[1]=='f') /* polna oblika */
            printtreefull((object) (syst->def->s[i]) ,lines,columns);
          else if(command[1]=='F') /* polna oblika, izpis v editorju */
            fprinttreefull(fp, (object) (syst->def->s[i]) ,elines,ecolumns);
          else if (command[1]=='p')  /* delno okrnjena oblika */
            printtreepart((object) (syst->def->s[i]) ,lines,columns);
          else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
            fprinttreepart(fp, (object) (syst->def->s[i]) ,elines,ecolumns);
          if (command[1]=='T' || command[1]=='F' || command[1]=='P')
            fprintf(fp,"\n\n");
          else
            printf("\n\n");
        }
      printf("\n");
      if (command[1]=='T' || command[1]=='F' || command[1]=='P')
      {
        fclose(fp);
        temp=com.lcom->param;
        com.lcom->param=com.tempfile;
        li_edit(com.lcom);
        com.lcom->param=temp;
      }
    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          printf("%i. def:\n",num);
          if (command[1]=='t') /* okrnjena oblika */
            printtree((object) (syst->def->s[num]) ,lines,columns);
          else if (command[1]=='T') /* okrnjena oblika, izpis v editorju */
            edprinttree((object) (syst->def->s[num]) ,elines,ecolumns);
          else if(command[1]=='f') /* polna oblika */
            printtreefull((object) (syst->def->s[num]) ,lines,columns);
          else if(command[1]=='F') /* polna oblika, izpis v editorju */
            edprinttreefull((object) (syst->def->s[num]) ,elines,ecolumns);
          else if (command[1]=='p')  /* delno okrnjena oblika */
            printtreepart((object) (syst->def->s[num]) ,lines,columns);
          else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
            edprinttreepart((object) (syst->def->s[num]) ,elines,ecolumns);
          printf("\n\n");
        }
    } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
    {
      jj=3;
      while (command[jj]==' ') ++jj;
      kk=jj;
      while (command[kk]!=' ' && command[kk]!='\0') ++kk;
      if (kk>jj)
      {
        name=stringncopy(command+jj,kk-jj);
        t=findobjname((stack) syst->def,name);
        printf("\"%s\" :\n",name);
        if (command[1]=='t') /* okrnjena oblika */
          printtree(t,lines,columns);
        else if (command[1]=='T') /* okrnjena oblika, izpis v editorju */
          edprinttree(t,elines,ecolumns);
        else if(command[1]=='f') /* polna oblika */
          printtreefull(t,lines,columns);
        else if(command[1]=='F') /* polna oblika, izpis v editorju */
          edprinttreefull(t,elines,ecolumns);
        else if (command[1]=='p')  /* delno okrnjena oblika */
          printtreepart(t,lines,columns);
        else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
          edprinttreepart(t,elines,ecolumns);
        printf("\n\n");
        free(name);
      }
    }
  } else if (command[1]=='E' || command[1]=='e') /* Ovrednotenje dreves */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
      {
        t=syst->def->s[syst->def->n];
        printf("Vrednost spremenljivke \"%s\" :\n",t->name);
        if (t->subkind=='V')
          printf("%.10g",doubleval(t,syst->fst,syst->user));
        else printf("ni spremenljivka.");
        printf("\n\n");
      } else printf("Na skladu ni definicij.\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->def->n>0)
      {
        for (i=1; i<=syst->def->n; ++i)
        {
          t=syst->def->s[i];
          printf("Vrednost %i. spremenljivke (\"%s\") : ",i,t->name);
          if (t->subkind=='V')
            printf("%.10g",doubleval(t,syst->fst,syst->user));
          else printf("ni spremenljivka.");
          printf("\n");
        }
      } else printf("Na skladu ni definicij.\n\n");
      printf("\n\n");
    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          t=syst->def->s[num];
          printf("Vrednost %i. spremenljivke (\"%s\") : ",num,t->name);
          if (t->subkind=='V')
            printf("%.10g",doubleval(t,syst->fst,syst->user));
          else printf("ni spremenljivka.");
          printf("\n");
        } else printf("Na skladu ni definicij.\n\n");
    } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
    {
      jj=3;
      while (command[jj]==' ') ++jj;
      kk=jj;
      while (command[kk]!=' ' && command[kk]!='\0') ++kk;
      if (kk>jj)
      {
        name=stringncopy(command+jj,kk-jj);
        t=findobjname((stack) syst->def,name);
        printf("Vrednost spremenljivke \"%s\" :\n",name);
        if (t->subkind=='V')
          printf("%.10g",doubleval(t,syst->fst,syst->user));
        else printf("ni spremenljivka.");
        printf("\n\n");
        free(name);
      }
    }
  } else if (command[1]=='V' || command[1]=='v') /* Imena spremenljivk in
  definiranih funkcij */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
        printf("Name of the last object in main list: \"%s\"\n",
         ((object) syst->def->s[syst->def->n])->name );
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->def->n>0)
        for (i=1; i<=syst->def->n; ++i)
        {
          /* printf("%i. def:\n",i); */
          printf("Name of %i. object in main list: \"%s\"\n", i,
           ((object) syst->def->s[i])->name );
          /* printf("\n\n"); */
        }
      printf("\n");
    } else if (command[2]=='N' || command[2]=='n')  /* Sprem. z doloc. zap. st. */
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          printf("%i. def:\n",num);
          printf("Name of %i. object in main list: \"%s\"\n",num,
           ((object) syst->def->s[num])->name );

          printf("\n\n");
        }
    }
  } else if (command[1]=='R' || command[1]=='r') /* Pogon sistem. ukaza */
  {
    system(command+3);
  } else if (command[1]=='X' || command[1]=='x') /* Ponovitev ukaza z dano zap. st. */
  {
    i=sscanf(command+3,"%i",&num);
    if (i==1)
      if (syst->strings->n >= num)
        pmsendtocalc(stringcopy(syst->strings->s[num]));
  } else if (command[1]=='*' || command[1]=='*') /* Komentar */
  {

    printf("%s\n",command+2);
  }
} else if (command!=NULL) if (command[0]!='\0')
{
  char *point=NULL;
  double x=0;
  int start,end;
  point=strchr(command,':');
  if (point!=NULL)
  {
    ++point;
    /* Ce v izrazu nastopa "::", gre za prireditev vrednosti izraza na desni
    strani dvojnega dvopicja spremenljivki z imenom na levi strani dvojnega
    dvopicja: */
    if (point[0]==':')
      ++point;
    else
      point=command;
  } else
    point=command;
  list=cutexpression(point,syst->syst);
  arrangelistobj(list);
  t=NULL;
  t=maketree(list);
  if (t->name[0]==':' && t->name[1]=='\0' && t->kind=='2')
    autoevaluate=0;
  else
    autoevaluate=1;
  /*
  printtree(t,lines,columns);
  */
  pushstack(syst->strings,stringcopy(command));
  pushstack(syst->cuts,list);
  pushstack((stack) syst->trees,t);
  puttreetolist(t,& (syst->def), & (syst->trash), syst->user);
  if (autoevaluate)
    printf("        = %.10g\n",doubleval(t,syst->fst,syst->user));
  if (point!=command)
  {
    /* Prireditev vrednosti izraza, ki je na desni strani dvojnega dvopicja v
    command, spremenljivki z imanom, ki je na levi strani dvojnega dvopicja: */
    start=0;
    while (command[start]==' ')
      ++start;
    end=start;
    while (command[end]!=' ' && command[end]!=':')
      ++end;
    point=stringncopy(command+start,end-start);
    x=doubleval(t,syst->fst,syst->user);
    assigndouble(com.csystem,point,x);
    free(point); point=NULL;
  }
  /*
  printtreefull(t,lines,columns);
  */
}
}






void li_calcold(licom lcom)
{
int buflength=1000; /* Maksimalna dolzina vrstice */
char end=0,*buf=NULL,*command;
/* Ce ima ukaz argumente, se izvrsi le vrstica od zacetka 1. argumenta naprej: */
if (lcom->param!=NULL)
{
  pmsendtocalc(lcom->param);
}
else
{
  printf("Type in commands or expressions; \"\\x\" or \"\\q\" for quit, \"\\?\" or \"\\h\" for help.\n\n");
  /* statusline(); */
  buf=malloc(buflength);
  while (!end)
  {
    printf("Calc >");
    buf[0]='\0';
    gets(buf);
    command=memnotnchr(buf,strlen(buf)," ",1);
    /*
    if (command!=NULL)
    {
      pos=(void *) memnchr(command,strlen(command)," ",1);
      if (pos!=NULL)
        cm=stringncopy(command,pos-command);
      else
        cm=stringcopy(command);
    }
    */
    if (command[0]=='\\' && (command[1]=='q' || command[1]=='x'))
      end=1;
    else
      pmsendtocalc(command);
  }
  if (buf!=NULL)
    free(buf);
  printf("\n");
}
}



static void li_calc(licom lcom)
    /* Izvede vrstico, ki je parameter ukaza v vrsticnem interpreterju, v
    kalkulatorju, pri cemer uporabi globalni kalkulator.
    $A Igor avg01; */
{
int buflength=1000; /* Maksimalna dolzina vrstice */
char end=0,*buf=NULL,*command;
/* Ce ima ukaz argumente, se izvrsi le vrstica od zacetka 1. argumenta naprej: */
if (lcom->param!=NULL)
{
  sendtoglobcalc(lcom->param);
}
else
{
  printf("Type in commands or expressions; \"\\x\" or \"\\q\" for quit, \"\\?\" or \"\\h\" for help.\n\n");
  buf=malloc(buflength);
  while (!end)
  {
    printf("Calc> ");
    buf[0]='\0';
    gets(buf);
    command=memnotnchr(buf,strlen(buf)," ",1);
    if (command!=NULL)
    {
      if (command[0]=='\\' && (command[1]=='q' || command[1]=='x'))
        end=1;
      else
        sendtoglobcalc(command);
    }
  }
  if (buf!=NULL)
    free(buf);
  printf("\n");
}
}





/* KONEC FUNKCIJ ZA UPORABO KALKULATORJA */



void li_system(licom lcom)
     /* Pozene se intepreter, ki vse ukaze razen nekaterih specificnih poslje
     sistemu. Funkcija je namenjena izvrsitvi pek vrsticnega interpreterja. */
{
int i,buflength=500; /* Maksimalna dolzina vrstice */
char end=0,*buf=NULL,*pos=NULL,*command,*cm;
/* Ce ima ukaz argumente, se izvrsi le vrstica od zacetka 1. argumenta naprej: */
if (lcom->param!=NULL)
{
  /* printf("\n"); */
  puttohistory(lcom->param);
  system(lcom->param);
  /* printf("\n"); */
  /*
  printf("\n  <System command executed.>\n");
  */
} else
{
  printf("Type in System commands; \"x\" or \"q\" for quit.\n\n");
  statusline();
  buf=malloc(buflength);
  i=0;
  while (!end)
  {
    printf("Sys> ");
    buf[0]='\0';
    gets(buf);
    /*
    cl=choosehist();
    if (cmpstrings(buf," ")==0 && cl!=NULL)
      strcpy(buf,cl);
    */
    cm=NULL;
    command=memnotnchr(buf,strlen(buf)," ",1);
    if (command!=NULL)
    {
      pos=(void *) memnchr(command,strlen(command)," ",1);
      if (pos!=NULL)
        cm=stringncopy(command,pos-command);
      else
        cm=stringcopy(command);
      if (cmpstrings(cm,"x")==0 || cmpstrings(cm,"q")==0)
      {
        if (pos==NULL)
          end=1;
        else
          command=pos;
      }
      if (!end)
      {
        puttohistory(command);
        system(command);
      }
      if (cm!=NULL)
        free(cm);
    }
  }
  if (buf!=NULL)
    free(buf);
  printf("\n");
}
}


void li_env(licom lcom)
     /* Pozene se intepreter, ki vse ukaze razen nekaterih specificnih poslje
     sistemu. Funkcija je namenjena izvrsitvi pek vrsticnega interpreterja. */
{
char *env;
int i;
/* Ce ima ukaz argumente, se izvrsi le vrstica od zacetka 1. argumenta naprej: */
if (lcom->param!=NULL)
{
  printf("\n\nValue of environment variable %s (in quotes):\n",lcom->param);
  printf("\"%s\"\n",env=getenv(lcom->param));
  if (env==NULL)
  {
    /* The variable is not defined, maybe we should have capitalized it: */
    for (i=0;i<(int) strlen(lcom->param);++i)
    {
      lcom->param[i]=toupper(lcom->param[i]);
      if ((env=getenv(lcom->param))!=NULL)
      {
        printf("\nCapitalizing...\nValue of environment variable %s (in quotes):\n",lcom->param);
        printf("\"%s\"\n",env=getenv(lcom->param));
      }
    }
  }
  printf("\n\n");
} else
{
  printf("System environment:\n\n");
  /* printf("%s",getenv(NULL)); */
  for (i=0; com.env[i]!=NULL;++i)
    printf("%s\n",com.env[i]);
  printf("\n\nProgram arguments (in quotes):\n");
  for (i=0;i<com.argc;++i)
    printf("\"%s\" ",com.argv[i]);
  printf("\n");
}
}





void li_quit(licom lcom)
     /* Funkcija, ki sprozi izhod iz vrsticnega interpreterja */
{
lcom->end=1;
}




void li_help(licom lcom)
{
globuthelpfirst(lcom->param);
/*
char *helpfile=NULL;
helpfile=stringcat(com.basedir,"pm.hlp");
showmore(helpfile);
if (helpfile!=NULL) free(helpfile);
*/
}

void li_helpedit(licom lcom)
{
li_help(lcom);
/*
char *helpfile=NULL;
helpfile=stringcat(com.basedir,"pm.hlp");
showedit(helpfile);
if (helpfile!=NULL) free(helpfile);
*/
}

void li_helpeditpar(licom lcom)
{
li_help(lcom);
/*
char *helpfile=NULL;
helpfile=stringcat(com.basedir,"pm.hlp");
showeditpar(helpfile);
if (helpfile!=NULL) free(helpfile);
*/
}



void li_hcd(licom lcom)
     /* V drugem direktoriju pozene nov ta program. Ime direktorija je lahko
     parameter ukaza v vrsticnem interpreterju, ce pa je ukaz brez parametrov,
     uporabnik izbere ime direktorija prek pomnilnika za hitri dostop. */
{
char *cm=NULL;
if (lcom->param==NULL)
{
  lcom->param=choosedir();
}
cm=stringcat("hpm ",lcom->param);
if (cm!=NULL)
{
  system(cm);
  free(cm);
}
statusline();
}


void li_cd(licom lcom)
     /* Spremeni tekoci direktorij procesa. Ime direktorija je lahko
     parameter ukaza v vrsticnem interpreterju, ce pa je ukaz brez parametrov,
     uporabnik izbere ime direktorija prek pomnilnika za hitri dostop.  */
{
if (lcom->param==NULL)
{
  lcom->param=choosedir();
}
printf("  Changing directory to \"%s\".\n",lcom->param);
chdir(lcom->param);
statusline();
}



static void readsettings(void);

void li_cdr(licom lcom)
     /* Spremeni tekoci direktorij procesa in hkrati pozene nastavitve za nov
     direktorij. Ime direktorija je lahko parameter ukaza v vrsticnem
     interpreterju, ce pa je ukaz brez parametrov, uporabnik izbere ime
     direktorija prek pomnilnika za hitri dostop.  */
{
if (lcom->param==NULL)
{
  lcom->param=choosedir();
}
printf("  Changing directory to \"%s\".\n",lcom->param);
chdir(lcom->param);
printf("  Read settings for new directory.\n");
readsettings();
statusline();
}


void li_cd1(licom lcom)
     /* V drugem direktoriju pozene nov ta program. Ime direktorija je lahko
     parameter ukaza v vrsticnem interpreterju, ce pa je ukaz brez parametrov,
     uporabnik izbere ime direktorija prek pomnilnika za hitri dostop.
     Ta funkcija se ne uporablja vec! */
{
char *cm=NULL;
if (lcom->param==NULL)
{
  lcom->param=choosedir();
}
cm=stringcat("pmcd ",lcom->param);
if (cm!=NULL)
{
  system(cm);
  free(cm);
}
statusline();
}


void li_fm(licom lcom)
{
char *cm=NULL,*tmp=NULL,*oldparam=NULL;
if (lcom->param==NULL)
{
  lcom->param=choosedir();
}
if (lcom->param!=NULL && cmpstrings(lcom->param,"")!=0)
{
  if (lcom->param[0]!='/')
  {
    /* Zaradi lastnosti vuefile ime direktorija ne sme biti relativno glede na
    trenutni direktorij, temvec mora biti podana absolutna pot do direktorija. */
    oldparam=lcom->param;
    tmp=pwdinfo();
    if (tmp[strlen(tmp)-1]!='/')
    {
      cm=stringcat(tmp,"/");
      free(tmp);
      tmp=cm; cm=NULL;
    }
    cm=strchr(tmp,':')+1;
    cm=stringcat(cm,oldparam);
    if (tmp!=NULL)
      free(tmp);
    tmp=NULL;
    lcom->param=cm;
    cm=NULL;
  }
  tmp=stringcat("vuefile -view small_icon -directory ",lcom->param);
  if (tmp!=NULL)
  {
    cm=stringcat(tmp," &");
    free(tmp);
  }
  if (cm!=NULL)
  {
    system(cm);
    free(cm);
  }
  if (oldparam!=NULL)
  {
    free(lcom->param);
    lcom->param=oldparam;
  }
}
statusline();
}


void li_view(licom lcom)
{
char *comint=NULL,*temp=NULL;
if (lcom->param==NULL)
{
  lcom->param=choosefile();
}
if (lcom->param!=NULL)
{
  globutview(lcom->param,1);
  /*
  temp=stringcat(com.editcom,lcom->param);
  comint=stringcat(temp," &");
  if (comint!=NULL)
  {
    system(comint);
    free(comint);
  }
  */
}
if (temp!=NULL)
  free(temp);
}

void li_browse(licom lcom)
{
char *comint=NULL,*temp=NULL;
if (lcom->param==NULL)
{
  lcom->param=choosefile();
}
if (lcom->param!=NULL)
{
  globutbrowse(lcom->param,1);
  /*
  temp=stringcat(com.editcom,lcom->param);
  comint=stringcat(temp," &");
  if (comint!=NULL)
  {
    system(comint);
    free(comint);
  }
  */
}
if (temp!=NULL)
  free(temp);
}

void li_edit(licom lcom)
{
char *comint=NULL,*temp=NULL;
if (lcom->param==NULL)
{
  lcom->param=choosefile();
}
if (lcom->param!=NULL)
{
  globutedit(lcom->param,1);
  /*
  temp=stringcat(com.editcom,lcom->param);
  comint=stringcat(temp," &");
  if (comint!=NULL)
  {
    system(comint);
    free(comint);
  }
  */
}
if (temp!=NULL)
  free(temp);
}


void li_numedit(licom lcom)
{
if (lcom->param==NULL)
{
  lcom->param=choosefile();
}
numberfilelines(lcom->param,1,0,"","",NULL,NULL,1000);
li_edit(lcom);
}


void li_renumedit(licom lcom)
{
if (lcom->param==NULL)
{
  lcom->param=choosefile();
}
renumberfilelines(lcom->param,1,0,"","",NULL,NULL,1000);
li_edit(lcom);
}


void li_denumedit(licom lcom)
{
if (lcom->param==NULL)
{
  lcom->param=choosefile();
}
denumberfilelines(lcom->param,1,0,"","",NULL,NULL,1000);
li_edit(lcom);
}


void li_tempnumedit(licom lcom)
{
char *comint=NULL;
if (lcom->param==NULL)
{
  lcom->param=choosefile();
}
renumberfilelines(lcom->param,1,0,"","",NULL,NULL,1000);
comint=stringcat(com.editcom,lcom->param);
if (comint!=NULL)
{
  system(comint);
  free(comint);
}
denumberfilelines(lcom->param,1,0,"","",NULL,NULL,1000);
}






static void helpdirmore(void)
       /* Izpise pomoc za ukaza dir in setdir na zaslon, po en zaslon
       naenkrat. */
{
char *path=NULL;
if (isDOS)
{
  if (com.basedir[strlen(com.basedir)-1]=='\\')
    path=stringcat(com.basedir,"dir.hlp");
  else
    path=stringcat(com.basedir,"\\dir.hlp");
} else
{
  if (com.basedir[strlen(com.basedir)-1]=='/')
    path=stringcat(com.basedir,"dir.hlp");
  else
    path=stringcat(com.basedir,"/dir.hlp");
}
showmore(path);
if (path!=NULL)
  free(path);
}

static void helpdiredit(void)
       /* Izpise pomoc za ukaza dir in setdir v editor, izvajanje programa se
       nadaljuje sele po zaprtju editorja. */
{
char *path=NULL;
if (isDOS)
{
  if (com.basedir[strlen(com.basedir)-1]=='\\')
    path=stringcat(com.basedir,"dir.hlp");
  else
    path=stringcat(com.basedir,"\\dir.hlp");
} else
{
  if (com.basedir[strlen(com.basedir)-1]=='/')
    path=stringcat(com.basedir,"dir.hlp");
  else
    path=stringcat(com.basedir,"/dir.hlp");
}
showedit(path);
if (path!=NULL)
  free(path);
}

static void helpdireditpar(void)
       /* Izpise pomoc za ukaza dir in setdir v editor, izvajanje programa se
       nemoteno nadaljuje. */
{
char *path=NULL;
if (isDOS)
{
  if (com.basedir[strlen(com.basedir)-1]=='\\')
    path=stringcat(com.basedir,"dir.hlp");
  else
    path=stringcat(com.basedir,"\\dir.hlp");
} else
{
  if (com.basedir[strlen(com.basedir)-1]=='/')
    path=stringcat(com.basedir,"dir.hlp");
  else
    path=stringcat(com.basedir,"/dir.hlp");
}
showeditpar(path);
if (path!=NULL)
  free(path);
}


void li_setdir(licom lcom)
{
int i;
char *p;
stack param;
if (lcom->param==NULL)
{
  dirsettings(com.dc);
} else
{
  param=stringparamlistsimp(lcom->param);
  if (param!=NULL)
  {
    if (param->n>=1)
      for (i=1; i<=param->n; ++i)
      {
        p=(char*) param->s[i];
        setdiroption(com.dc,p);
      }
  }
}
consistentdircom(com.dc);
printf("\n\n");
fprintdirsettings(stdout,com.dc);
printf("\n\n");
}



void li_dir(licom lcom)
{
char swapparam=0,*command=NULL,*paramold=NULL;
FILE *fp=NULL;
if (lcom->param==NULL)
{
  paramold=lcom->param;
  lcom->param=choosedir();
  swapparam=1;
}
if (lcom->param!=NULL)
{
  if (cmpstrings(lcom->param,"?")==0) /* Zahteva za pomoc */
  {
    helpdirmore();
  } else if (cmpstrings(lcom->param,"?e")==0)
  {
    helpdiredit();
  } else if (cmpstrings(lcom->param,"?ep")==0)
  {
     helpdireditpar();
  } else
  {
    fp=fopen(com.tempfile,"wb");
    fcomlistdir(fp,lcom->param,com.dc,&(com.dir));
    fclose(fp);
    fp=NULL;
    command=stringcat("more ",com.tempfile);
    system(command);
    if (command!=NULL)
      free(command);
    command=NULL;
  }
}
if (swapparam)
{
  if (lcom->param!=NULL)
    free(lcom->param);
  lcom->param=paramold;
}
}


void li_diredit(licom lcom)
{
char swapparam=0,*command=NULL,*paramold=NULL;
FILE *fp=NULL;
if (lcom->param==NULL)
{
  paramold=lcom->param;
  lcom->param=choosedir();
  swapparam=1;
}
if (lcom->param!=NULL)
{
  if (cmpstrings(lcom->param,"?")==0) /* Zahteva za pomoc */
  {
    helpdirmore();
  } else if (cmpstrings(lcom->param,"?e")==0)
  {
    helpdiredit();
  } else if (cmpstrings(lcom->param,"?ep")==0)
  {
     helpdireditpar();
  } else
  {
    fp=fopen(com.tempfile,"wb");
    fcomlistdir(fp,lcom->param,com.dc,&(com.dir));
    fclose(fp);
    fp=NULL;
    /*
    command=stringcat("more ",com.tempfile);
    system(command);
    if (command!=NULL)
      free(command);
    command=NULL;
    */
    edit(com.tempfile);
  }
}
if (swapparam)
{
  if (lcom->param!=NULL)
    free(lcom->param);
  lcom->param=paramold;
}
}


void li_direditpar(licom lcom)
{
char swapparam=0,*command=NULL,*paramold=NULL;
FILE *fp=NULL;
if (lcom->param==NULL)
{
  paramold=lcom->param;
  lcom->param=choosedir();
  swapparam=1;
}
if (lcom->param!=NULL)
{
  if (cmpstrings(lcom->param,"?")==0) /* Zahteva za pomoc */
  {
    helpdirmore();
  } else if (cmpstrings(lcom->param,"?e")==0)
  {
    helpdiredit();
  } else if (cmpstrings(lcom->param,"?ep")==0)
  {
     helpdireditpar();
  } else
  {
    fp=fopen(com.tempfile,"wb");
    fcomlistdir(fp,lcom->param,com.dc,&(com.dir));
    fclose(fp);
    fp=NULL;
    /*
    command=stringcat("more ",com.tempfile);
    system(command);
    if (command!=NULL)
      free(command);
    command=NULL;
    */
    editpar(com.tempfile);
  }
}
if (swapparam)
{
  if (lcom->param!=NULL)
    free(lcom->param);
  lcom->param=paramold;
}
}







void li_run(licom lcom)
{
if (lcom->param==NULL)
{
  lcom->param=choosecom();
}
puttohistory(lcom->param);
system(lcom->param);
}


void li_runhist(licom lcom)
{
if (lcom->param==NULL)
{
  lcom->param=choosehist();
}
puttohistory(lcom->param);
system(lcom->param);
}


void dofileint(FILE *fp);

void li_rs(licom lcom)
     /* Prebere nastavitve iz datoteke, ki je parameter ukaza. */
{
FILE *fp;
if (lcom->param==NULL)
  lcom->param="0pm.set";
if (lcom->param!=0)
{
  fp=fopen(lcom->param,"rb");
  if (fp!=0)
  {
    printf("  Reading settings from file %s\n",lcom->param);
    dofileint(fp);
    fclose(fp);
  }
}
}


void li_ws(licom lcom)
     /* Na konec datoteke, katere ime je parameter ukaza, se zapisejo trenutne
     nastavitve. Ce je ukaz brez parametrov, se nastavitve zapisejo v datoteko
     */
{
FILE *fp=NULL;
char *str=NULL;
int i;
if (lcom->param==NULL)
  lcom->param="0pm.set";
fp=fopen(lcom->param,"wb");
if (fp!=NULL)
{
  printf("  Writing current settings to file \"%s\"\n",lcom->param);
  fprintf(fp,"\n\n*\n{\n  ***** Settings from PM: *****\n}\n\n");
  if (com.editcom!=NULL)  /* editor */
  {
    str=stringcopy(com.editcom);
    if (str[strlen(str)-1]==' ')
      str[strlen(str)-1]='\0';
    fprintf(fp,"editor{%s}\n\n",str);
    if (str!=NULL)
    {
      free(str);
      str=NULL;
    }
  }
  fprintf(fp,"numfiles{%i}\n\n",com.files->n);
  fprintf(fp,"numdirs{%i}\n\n",com.dirs->n);
  fprintf(fp,"numcoms{%i}\n\n",com.coms->n);
  fprintf(fp,"numhist{%i}\n\n",com.hist->n);
  fprintf(fp,"files\n{\n");
  for (i=1; i<=com.files->n; ++i)
    fprintf(fp,"  %i{%s}\n",i,com.files->s[i]);
  fprintf(fp,"}\n\n");
  fprintf(fp,"dirs\n{\n");
  for (i=1; i<=com.dirs->n; ++i)
    fprintf(fp,"  %i{%s}\n",i,com.dirs->s[i]);
  fprintf(fp,"}\n\n");
  fprintf(fp,"coms\n{\n");
  for (i=1; i<=com.coms->n; ++i)
    fprintf(fp,"  %i{%s}\n",i,com.coms->s[i]);
  fprintf(fp,"}\n\n");
  fprintf(fp,"dirsettings{");
  fprintdirsettings(fp,com.dc);
  fprintf(fp,"}\n\n");
  fclose(fp);
}
}



static void endpm(void);

void li_rmall(licom lcom)
       /* Zbrise vse datoteke in direktorije, ki pripadajo programom z istim
       osnovnim direktorijem. */
{
FILE *fp;
char *sesfile=NULL,*cm=NULL,*tmp,end=0;
int i=1,len;
if (0)
{
  for (i=1; i<=200; ++i)
  {
    if (sesfile!=NULL)
      free(sesfile);
    sesfile=NULL;
    sesfile=stringcat(com.basedir,"session.          ");  /* 10 presledkov */
    len=strlen(sesfile)-10;
    sprintf(sesfile+len,"%i",i);
    fp=fopen(sesfile,"rb");
    if (fp!=NULL)
    {
      /* Nasli smo zasedeno identifikacijsko stevilko. Najprej se brise sesfile. */
      fclose(fp);
  #ifdef DOSWN
      cm=stringcat("del ",sesfile);
  #else
      cm=stringcat("rm ",sesfile);
  #endif
      system(cm);
      free(cm); cm=NULL;
  #ifdef DOSWN
      sprintf(sesfile,"%i\\",i);
      tmp=stringcat(com.basedir,sesfile);
      cm=stringcat("rd /S /Q ",tmp);
  #else
      sprintf(sesfile,"%i/",i);
      tmp=stringcat(com.basedir,sesfile);
      cm=stringcat("rm -r ",tmp);
  #endif
      free(tmp); tmp=NULL;
      system(cm);
      free(cm); cm=NULL;
    } else fclose(fp);
  }
  free(sesfile);
}
globutremoveallsessions();
endpm();
exit(1);
}




/*



  if (cmpstrings(argv[1],"n")==0)
    numberfilelines(argv[2],1,0,"","",NULL,NULL,1000);

  if (cmpstrings(argv[1],"d")==0)
    denumberfilelines(argv[2],1,0,"","",NULL,NULL,1000);

  if (cmpstrings(argv[1],"r")==0)
    renumberfilelines(argv[2],1,0,"","",NULL,NULL,1000);


  if (cmpstrings(argv[1],"nn")==0)
  {
    numberfilelines(argv[2],1,0,"","",NULL,NULL,1000);
    system(stringcat(com.editcom,stringcat(argv[2]," &")));
  }

  if (cmpstrings(argv[1],"dd")==0)
  {
    denumberfilelines(argv[2],1,0,"","",NULL,NULL,1000);
    system(stringcat(com.editcom,stringcat(argv[2]," &")));
  }

  if (cmpstrings(argv[1],"rr")==0)
  {
    renumberfilelines(argv[2],1,0,"","",NULL,NULL,1000);
    system(stringcat(com.editcom,stringcat(argv[2]," &")));
  }


*/




void ftitle(FILE *fp,int spaces)
{
char *sp=malloc(spaces+1);
int i;
if (spaces>0)
  for (i=1; i<=spaces; ++i)
    sp[i-1]=' ';
sp[spaces]='\0';
fprintf(fp,"\n");
fprintf(fp,"%s-------------------------------------------\n",sp);
fprintf(fp,"%s||---------------------------------------||\n",sp);
fprintf(fp,"%s||                          Jan 26 1996  ||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s||   PROGRAMMING MANAGER version 2.4     ||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s||      Developed by                     ||\n",sp);
fprintf(fp,"%s||        Igor Gresovnik                 ||\n",sp);
fprintf(fp,"%s||        Crnece 147                     ||\n",sp);
fprintf(fp,"%s||        62370 Dravograd                ||\n",sp);
fprintf(fp,"%s||      for                              ||\n",sp);
fprintf(fp,"%s||        C3M                            ||\n",sp);
fprintf(fp,"%s||        Vandotova 55                   ||\n",sp);
fprintf(fp,"%s||        Ljubljana, Slovenia            ||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s||---------------------------------------||\n",sp);
fprintf(fp,"%s-------------------------------------------\n",sp);
if (sp!=NULL)
  free(sp);
}

void title(int spaces)
{
  ftitle(stdout,spaces);
}

static void endpm(void);

static void defaultsignal(void *ptr)
{
FILE *fp=NULL;
printf("*>");
if (com.sesfile!=NULL)
{
  fp=fopen(com.sesfile,"rb");
  if (fp==NULL)
  {
    printf("\nSession file \"%s\" removed,\nterminating process (%s %s, ID %i).\n\n",
     com.sesfile,globutgetprogram(),globutgetstringversion(),globutgetsesid());
    endpm();
    exit(1);
  } else fclose(fp);
}
}


static void setsession(void)
       /* Najde prosto identifikacijsko st. procesa, naredi identifikacijsko
       datoteko, zacasni direktorij in zacasno datoteko za proces. */
{
FILE *fp;
char *sesfile=NULL,*cm=NULL,end=0;
int i=1,len;
if (0)
{
sesfile=stringcat(com.basedir,"session.          ");  /* 10 presledkov */
len=strlen(sesfile)-10;
while (!end)
{
  /* Postopoma se preverja, ali ze obstaja identifikacijska datoteka procesa z
  dano identifikacijsko stevilko (i). ce datoteka z neko stevilko se ne obstaja,
  lahko proces prevzame to datoteko in s tem identifikacijsko stevilko. Na novo
  je potrebno tvoriti identifikacijsko datoteko in ustrezni direktorij
  (direktorij se naredi v funkciji initpm). */
  sprintf(sesfile+len,"%i",i);
  fp=fopen(sesfile,"rb");
  if (fp==NULL)
  {
    /* Nasli smo prosto identifikacijsko stevilko. */
    end=1;
	if (fp!=NULL)
      fclose(fp);
    cm=stringcat("date > ",sesfile);
#ifdef DOSWN
    fp=fopen(sesfile,"wb");
	if (fp!=NULL)
	{
      fprintf(fp,"PM Session file.\n");
      fclose(fp);
    }
#else
    system(cm);
#endif
    free(cm); cm=NULL;
    com.id=i;
    com.sesfile=stringcopy(sesfile);
    if (isDOS)
    {
      sprintf(sesfile,"%i\\",i);
    } else
    {
      sprintf(sesfile,"%i/",i);
    }
    com.tempdir=stringcat(com.basedir,sesfile);
    cm=stringcat("mkdir ",com.tempdir);
    if ( 1 /* isDOS */ )
    {
      if (cm!=NULL)
	cm[strlen(cm)-1]='\0';
    }
    system(cm);
    free(cm);
    com.tempfile=stringcat(com.tempdir,"pm.tmp");
    fp=fopen(com.tempfile,"wb");
    fprintf(fp,"PROGRAMMING MANAGER temporary file.");
    fclose(fp);
    /* printf("  ID: %i\n",i); */
  } else fclose(fp);
  ++i;
}
free(sesfile);
}

/* printf("  ID: %i\n",globutgetsesid()); */
com.id=globutgetsesid();
com.sesfile=stringcopy(globutgetsesfile());
com.tempdir=stringcopy(globutgetsesdir());
com.tempfile=stringcat(globutgetsesdir(),"pm.tmp");

}





/* FUNKCIJE ZA INTERPRETACIJO UKAZNE DATOTEKE */


void fi_pmcomment(ficom fcom)
    /* Branje imena editorja */
{
}


void fi_editcom(ficom fcom)
{
char *str=NULL;
int length;
length=fcom->end-fcom->begin-1;
if (length>0)
{
  str=makestring(length+1);
  fileread((void *) str,1,length,fcom->fp,fcom->begin+1);
  str[length]=' ';
  str[length+1]='\0';
  if (com.editcom!=NULL)
    free(com.editcom);
  com.editcom=str;
}
}



void fi_dirsettings(ficom fcom)
     /* Branje nastavitev za ukaz dir. Nastavitve morajo biti znotraj prostora
     parametrov funkcije, napisane z nizi, ki so loceni s presledki in ki so
     prepoznavni za funkcijo setdiroption(). */
{
char *str=NULL,*p;
stack param=NULL;
int length,i;
length=fcom->end-fcom->begin-1;
if (length>0)
{
  str=makestring(length);
  fileread((void *) str,1,length,fcom->fp,fcom->begin+1);
  str[length]='\0';
  param=stringparamlistsimp(str);
  if (param!=NULL)
  {
    if (param->n>0)
      for (i=1;i<=param->n;++i)
      {
        p=(char *) param->s[i];
        setdiroption(com.dc,p);
      }
    dispstackval(param);
    dispstack(&param);
    param=NULL;
  }
  if (str!=NULL)
    free(str);  str=NULL;
}
}


void fi_numfiles(ficom fcom)
{
int num,length;
long pos;
num=(int) filenum(fcom->fp,fcom->begin,100,&pos,&length);
if (pos>0 && pos<fcom->end)
{
  setnumfiles(num);
  /* printf("Number of files for quick access: %i\n",num); */
}
}


void fi_numdirs(ficom fcom)
{
int num,length;
long pos;
num=(int) filenum(fcom->fp,fcom->begin,100,&pos,&length);
if (pos>0 && pos<fcom->end)
{
  setnumdirs(num);
  /* printf("Number of directories for quick access: %i\n",num); */
}
}


void fi_numcoms(ficom fcom)
{
int num,length;
long pos;
num=(int) filenum(fcom->fp,fcom->begin,100,&pos,&length);
if (pos>0 && pos<fcom->end)
{
  setnumcoms(num);
  /* printf("Number of commands for quick access: %i\n",num); */
}
}


void fi_numhist(ficom fcom)
{
int num,length;
long pos;
num=(int) filenum(fcom->fp,fcom->begin,100,&pos,&length);
if (pos>0 && pos<fcom->end)
{
  setnumhist(num);
  /* printf("Number of commands for quick access: %i\n",num); */
}
}


void fi_setstackstrings(ficom fcom,stack st)
{
char *name=NULL;
int num,length;
long pos,pos1,pos2;
char end=0;
pos=fcom->begin;
while (!end)
{
  num=(int) filenum(fcom->fp,pos,100,&pos,&length);
  if (pos>0 && length>0 && pos<fcom->end)
  {
    filebracto(fcom->fp,'{','}',pos+length-1,fcom->end,100,&pos1,&pos2);
    if (pos1>0 && pos2>0 && num>0 && num<=st->n)
    {
      free(st->s[num]); st->s[num]=NULL;
      length=pos2-pos1-1;
      name=makestring(length);
      name[length]='\0';
      if (length>0)
        fileread(name,1,length,fcom->fp,pos1+1);
      st->s[num]=name;
      /* printf("%i.: \"%s\"\n",num,name); */
      name=NULL;
    } else if (pos1<=0 || pos2<=0) end=1;
    pos=pos2;
  } else end=1;
}
}

void fi_files(ficom fcom)
{
fi_setstackstrings(fcom,com.files);
}

void fi_dirs(ficom fcom)
{
fi_setstackstrings(fcom,com.dirs);
}

void fi_coms(ficom fcom)
{
fi_setstackstrings(fcom,com.coms);
}


void dofileint(FILE *fp)
{
com.fcom=newficom();
com.fcom->fp=fp;
fimountall(com.fcom,NULL);
instficom(com.fcom,"*",fi_pmcomment);
instficom(com.fcom,"editor",fi_editcom);
instficom(com.fcom,"comment",fi_pmcomment);
instficom(com.fcom,"dirsettings",fi_dirsettings);
instficom(com.fcom,"numfiles",fi_numfiles);
instficom(com.fcom,"numdirs",fi_numdirs);
instficom(com.fcom,"numcoms",fi_numcoms);
instficom(com.fcom,"numhist",fi_numhist);
instficom(com.fcom,"files",fi_files);
instficom(com.fcom,"dirs",fi_dirs);
instficom(com.fcom,"coms",fi_coms);
fileinterpret(com.fcom);
/*
ficlosetemp(com.fcom);
*/
if (com.fcom!=NULL)
  dispficom(&com.fcom);
}






static void readsettings(void)
/* Interpretacija ukazne datoteke za nastavitev parametrov: */
{
char *str;
FILE *fp=NULL;
str="0pm.set";
fp=fopen(str,"rb");
if (fp!=NULL)
{
  dofileint(fp);
  fclose(fp);
} else
{
  str=stringcat(com.basedir,"0pm.set");
  fp=fopen(str,"rb");
  free(str);
  if (fp!=NULL)
  {
    dofileint(fp);
    fclose(fp);
  }
}
str=NULL;
}



static void initpm(void)
{
char *str=NULL;
FILE *fp=NULL;


printf("Initialising global data...\n");
printglobutdata();

/* Setting basic program data: */

globutsetprogram("Programming manager");
globutsetprog("pm");
globutsetauthor("Igor Gresovnik");
globutsetauthormail("igor@c3m.si");
globutsetversion(3,0);
globutsetcreationdate(21,2,2002);
globutsetexpirationdate(21,2,2070);
globutsetwww("http://www.c3m.si/");
/* globutsetmail("igor@c3m.si"); */

/*
printf("Global utility data before update:\n");
printglobutdata();
*/

/*
printf("Updating dependencies:\n\n\n\n");
*/

globutinit(1,1,1);

/*
printf("Global utility data after update:\n");
*/

if (0)
  printglobutdata();





com.basedir=stringcopy(globutgetverdir());


printf("\nStarting %s %s, ID %i.\nSes. dir.: \"%s\"\n\n",
  globutgetprogram(),globutgetstringversion(),globutgetsesid(),globutgetsesdir());
printf("  Input commands (\"?\" or \"h\" for quick help) !\n\n");


if (isDOS)
{
  com.editcom=stringcopy("edit ");
} else
{
  com.editcom=stringcopy("vuepad ");
}
com.buflength=1000;
com.buf=malloc(com.buflength);
com.lcom=newlicom(500);
com.lcom->unknown= (void (*) (void *)) li_execute;
com.lcom->signal=defaultsignal;
com.csyst=NULL;
com.csystem=NULL;
com.dir=NULL;
com.dc=newdircom();
setsession();
setnumfiles(15);
setnumdirs(15);
setnumcoms(15);
setnumhist(15);

setstring(1,stringcopy("pm.h"),com.files);
setstring(2,stringcopy("invan.h"),com.files);
setstring(3,stringcopy("fop.c"),com.files);
setstring(4,stringcopy("strop.c"),com.files);
setstring(5,stringcopy("fint.c"),com.files);

setstring(1,stringcopy("/users/igor/c/"),com.dirs);
setstring(2,stringcopy("/users/igor/c/h/"),com.dirs);
setstring(3,stringcopy("/users/igor/elfen/projects/"),com.dirs);
setstring(4,stringcopy(""),com.dirs);
setstring(5,stringcopy(""),com.dirs);
setstring(6,stringcopy(""),com.dirs);

setstring(1,stringcopy("elfen"),com.coms);
setstring(2,stringcopy("pm"),com.coms);
setstring(3,stringcopy("rlogin pluton"),com.coms);
setstring(4,stringcopy("rlogin jupiter"),com.coms);
setstring(5,stringcopy("rlogin apolon"),com.coms);
setstring(6,stringcopy("fm"),com.coms);


statusline();

instlicom(com.lcom,"q",&li_quit);
instlicom(com.lcom,"x",&li_quit);
instlicom(com.lcom,"c",&li_calc);
instlicom(com.lcom,"u",&li_system);
instlicom(com.lcom,"s",&li_system);
instlicom(com.lcom,"system",&li_system);
instlicom(com.lcom,"env",&li_env);
instlicom(com.lcom,"h",&li_help);
instlicom(com.lcom,"?",&li_help);
instlicom(com.lcom,"?e",&li_helpedit);
instlicom(com.lcom,"?ep",&li_helpeditpar);
instlicom(com.lcom,"hcd",&li_hcd);
instlicom(com.lcom,"cd",&li_cd);
instlicom(com.lcom,"cdr",&li_cdr);
instlicom(com.lcom,"fm",&li_fm);
instlicom(com.lcom,"viewer",&li_viewcom);
instlicom(com.lcom,"view",&li_view);
instlicom(com.lcom,"v",&li_view);
instlicom(com.lcom,"browser",&li_browsecom);
instlicom(com.lcom,"browse",&li_browse);
instlicom(com.lcom,"b",&li_browse);
instlicom(com.lcom,"editor",&li_editcom);
instlicom(com.lcom,"e",&li_edit);
instlicom(com.lcom,"en",&li_numedit);
instlicom(com.lcom,"er",&li_renumedit);
instlicom(com.lcom,"ed",&li_denumedit);
instlicom(com.lcom,"et",&li_tempnumedit);
instlicom(com.lcom,"setdir",&li_setdir);
instlicom(com.lcom,"dir",&li_dir);
instlicom(com.lcom,"dire",&li_diredit);
instlicom(com.lcom,"direp",&li_direditpar);
instlicom(com.lcom,"r",&li_run);
instlicom(com.lcom,"rr",&li_runhist);
instlicom(com.lcom,"rh",&li_runhist);
instlicom(com.lcom,"listf",&li_listfiles);
instlicom(com.lcom,"listd",&li_listdirs);
instlicom(com.lcom,"listc",&li_listcoms);
instlicom(com.lcom,"setnf",&li_setnumfiles);
instlicom(com.lcom,"setnd",&li_setnumdirs);
instlicom(com.lcom,"setnc",&li_setnumcoms);
instlicom(com.lcom,"setnh",&li_setnumhist);
instlicom(com.lcom,"setf",&li_setfiles);
instlicom(com.lcom,"setd",&li_setdirs);
instlicom(com.lcom,"setc",&li_setcoms);
instlicom(com.lcom,"rs",&li_rs);
instlicom(com.lcom,"ws",&li_ws);
instlicom(com.lcom,"rmall",&li_rmall);

/*
instlicom(com.lcom,"cdb",&li_execute);
instlicom(com.lcom,"cco",&li_execute);
instlicom(com.lcom,"cco0",&li_execute);
instlicom(com.lcom,"cco1",&li_execute);
instlicom(com.lcom,"cco2",&li_execute);
instlicom(com.lcom,"cco3",&li_execute);
instlicom(com.lcom,"cco4",&li_execute);
instlicom(com.lcom,"cli",&li_execute);
instlicom(com.lcom,"cli0",&li_execute);
instlicom(com.lcom,"cli1",&li_execute);
instlicom(com.lcom,"cli2",&li_execute);
instlicom(com.lcom,"cli3",&li_execute);
instlicom(com.lcom,"cli4",&li_execute);

instlicom(com.lcom,"at",&li_execute);
instlicom(com.lcom,"batch",&li_execute);
instlicom(com.lcom,"bdf",&li_execute);
instlicom(com.lcom,"cat",&li_execute);
instlicom(com.lcom,"cc",&li_execute);
instlicom(com.lcom,"chgrp",&li_execute);
instlicom(com.lcom,"chmod",&li_execute);
instlicom(com.lcom,"chown",&li_execute);
instlicom(com.lcom,"clear",&li_execute);
instlicom(com.lcom,"cmp",&li_execute);
instlicom(com.lcom,"comm",&li_execute);
instlicom(com.lcom,"cp",&li_execute);
instlicom(com.lcom,"cpio",&li_execute);
instlicom(com.lcom,"csh",&li_execute);
instlicom(com.lcom,"cu",&li_execute);
instlicom(com.lcom,"date",&li_execute);
instlicom(com.lcom,"devnm",&li_execute);
instlicom(com.lcom,"df",&li_execute);
instlicom(com.lcom,"diff",&li_execute);
instlicom(com.lcom,"du",&li_execute);
instlicom(com.lcom,"dircmp",&li_execute);
instlicom(com.lcom,"echo",&li_execute);
instlicom(com.lcom,"env",&li_execute);
instlicom(com.lcom,"find",&li_execute);
instlicom(com.lcom,"file",&li_execute);
instlicom(com.lcom,"grep",&li_execute);
instlicom(com.lcom,"hostname",&li_execute);
instlicom(com.lcom,"id",&li_execute);
instlicom(com.lcom,"ioscan",&li_execute);
instlicom(com.lcom,"keysh",&li_execute);
instlicom(com.lcom,"kill",&li_execute);
instlicom(com.lcom,"ll",&li_execute);
instlicom(com.lcom,"ln",&li_execute);
instlicom(com.lcom,"lp",&li_execute);
instlicom(com.lcom,"lpstat",&li_execute);
instlicom(com.lcom,"ls",&li_execute);
instlicom(com.lcom,"mail",&li_execute);
instlicom(com.lcom,"mesg",&li_execute);
instlicom(com.lcom,"mkdir",&li_execute);
instlicom(com.lcom,"mknod",&li_execute);
instlicom(com.lcom,"grep",&li_execute);
instlicom(com.lcom,"hostname",&li_execute);
instlicom(com.lcom,"man",&li_execute);
instlicom(com.lcom,"mkrs",&li_execute);
instlicom(com.lcom,"mv",&li_execute);
instlicom(com.lcom,"newgrp",&li_execute);
instlicom(com.lcom,"news",&li_execute);
instlicom(com.lcom,"nice",&li_execute);
instlicom(com.lcom,"nl",&li_execute);
instlicom(com.lcom,"pack",&li_execute);
instlicom(com.lcom,"unpack",&li_execute);
instlicom(com.lcom,"passwd",&li_execute);
instlicom(com.lcom,"pcat",&li_execute);
instlicom(com.lcom,"paste",&li_execute);
instlicom(com.lcom,"pr",&li_execute);
instlicom(com.lcom,"ps",&li_execute);
instlicom(com.lcom,"pwd",&li_execute);
instlicom(com.lcom,"rcp",&li_execute);
instlicom(com.lcom,"rm",&li_execute);
instlicom(com.lcom,"rmdir",&li_execute);
instlicom(com.lcom,"sed",&li_execute);
instlicom(com.lcom,"sh",&li_execute);
instlicom(com.lcom,"shutdown",&li_execute);
instlicom(com.lcom,"sleep",&li_execute);
instlicom(com.lcom,"sort",&li_execute);
instlicom(com.lcom,"split",&li_execute);
instlicom(com.lcom,"stty",&li_execute);
instlicom(com.lcom,"su",&li_execute);
instlicom(com.lcom,"tail",&li_execute);
instlicom(com.lcom,"tar",&li_execute);
instlicom(com.lcom,"tee",&li_execute);
instlicom(com.lcom,"test",&li_execute);
instlicom(com.lcom,"tic",&li_execute);
instlicom(com.lcom,"time",&li_execute);
instlicom(com.lcom,"touch",&li_execute);
instlicom(com.lcom,"tr",&li_execute);
instlicom(com.lcom,"tty",&li_execute);
instlicom(com.lcom,"umask",&li_execute);
instlicom(com.lcom,"uname",&li_execute);
instlicom(com.lcom,"uniq",&li_execute);
instlicom(com.lcom,"uustat",&li_execute);
instlicom(com.lcom,"uux",&li_execute);
instlicom(com.lcom,"wait",&li_execute);
instlicom(com.lcom,"wc",&li_execute);
instlicom(com.lcom,"who",&li_execute);
instlicom(com.lcom,"whoami",&li_execute);
instlicom(com.lcom,"write",&li_execute);
*/

/*
instlicom(com.lcom,"",&);
instlicom(com.lcom,"",&);
instlicom(com.lcom,"",&);
instlicom(com.lcom,"",&);
instlicom(com.lcom,"",&);
instlicom(com.lcom,"",&);
instlicom(com.lcom,"",&);
instlicom(com.lcom,"",&);
instlicom(com.lcom,"",&);
instlicom(com.lcom,"",&);
instlicom(com.lcom,"",&);
*/
readsettings();
}


static void endpm(void)
{
char *cm=NULL;
int i;
/*
displicom(&com.lcom);
*/
/*
#ifdef DOSWN
cm=stringcat("rd /S /Q ",com.tempdir);
#else
cm=stringcat("rm -r ",com.tempdir);
#endif
system(cm); free(cm);
#ifdef DOSWN
cm=stringcat("del ",com.sesfile);
#else
cm=stringcat("rm ",com.sesfile);
#endif
system(cm); free(cm);
*/
cm=NULL;
if (com.files!=NULL)
{
  dispstackval(com.files);
  dispstack(&com.files);
}
if (com.dirs!=NULL)
{
  dispstackval(com.dirs);
  dispstack(&com.dirs);
}
if (com.coms!=NULL)
{
  dispstackval(com.coms);
  dispstack(&com.coms);
}
if (com.hist!=NULL)
{
  dispstackval(com.hist);
  dispstack(&com.hist);
}
if (com.editcom!=NULL)
  free(com.editcom);
if (com.basedir!=NULL)
  free(com.basedir);
if (com.tempdir!=NULL)
  free(com.tempdir);
if (com.tempfile!=NULL)
  free(com.tempfile);
if (com.sesfile!=NULL)
  free(com.sesfile);
if (com.dir!=NULL)
{
  if (com.dir->n>0)
  {
    for (i=1; i<=com.dir->n; ++i)
      dispdirtree( (dirtype *) &(com.dir->s[i]) );
  }
  dispstack(&(com.dir));
  com.dir=NULL;
}
if (com.dc!=NULL)
{
  dispdircom(&(com.dc));
  com.dc=NULL;
}

globutend(); /* global utilities clean-up */

}


/* V Windowsih na PC-jih je treba argumente programa posebej prebrati, ker
se jih ne da prenesti prek ukazne vrstice: */

#ifdef MANARG

static void readprogargs(int *numargs,char **argv,int from,int to)
    /* Prebere nize (argumente) v tabelo argv od mesta from do mesta to (steje
    se od 0 naprej), v i se zapise najvisje mesto argumenta, ki ni prazen niz.
    Funkcija se uporablja predvsem za branje argumentov v okoljih, kjer se
    programu ne da prenesti argumentov z ukazom, s katerim se pozene program,
    npr. v okolju Windows na PC-jih. */
{
int i;
char *buf=NULL;
buf=makestring(100);
if (argv!=NULL && from>=0 && to>=from)
  for (i=from;i<=to;++i)
  {
    printf("%i. argument: ",i);
    buf[0]='\0';
    gets(buf);
    argv[i]=stringcopy(buf);
    if (cmpstrings(buf,"")!=0)
      *numargs=i+1;
  }
if (buf!=NULL)
  free(buf);
}

#endif



char *buf;

#ifdef MANARG
main(void)
#else
main(int argc, char *argv[],char *env[])
#endif
{

#ifdef MANARG
int numargs=0;
char *argv[10];
readprogargs(&argc,argv,0,1);
#endif


#ifdef MANARG
#else
memset(&com,0,sizeof(com));
com.argc=argc;
com.argv=argv;
com.env=env;
if (0)
{
  int i;
  printf("\n\nEnvironment:\n");
  for (i=0; com.env[i]!=NULL; ++i)
    printf("%s\n",com.env[i]);
  printf("\n");
}
#endif

/*
if (numargs<2)
  printf("Usage: %s directory_name\n",argv[0]);
else
{
  /*
  if (isDOS)
  {
    if ( argv[1] [ strlen(argv[1]) -1 ] =='\\' )
      com.basedir=stringcopy(argv[1]);
    else
      com.basedir=stringcat(argv[1],"\\");
  } else
  {
    if ( argv[1] [ strlen(argv[1]) -1 ] =='/' )
      com.basedir=stringcopy(argv[1]);
    else
      com.basedir=stringcat(argv[1],"/");
  }
*/
  
  
  
  initpm();
  lineinterpret(com.lcom);
  
  globutprogtitle(NULL,10);
  endpm();

  /* title(10); */
/* } */
return 0;
}





