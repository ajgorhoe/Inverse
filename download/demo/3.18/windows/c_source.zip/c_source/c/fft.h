#include <sysint.h>

          /************************************/
          /*                                  */
          /*     FAST FOURIER TRANSFORMS      */
          /*                                  */
          /************************************/


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>



#include <mtypes.h>
#include <er.h>
#include <vec.h>
#include <mat.h>
#include <st.h>
#include <rf.h>
#include <mtime.h>
#include <strop.h>
#include <fop.h>
#include <numut.h>
#include <minnd.h>
#include <simb.h>


#define Pi ConstPi



#define SWAP(a,b) tempr=(a);(a)=(b);(b)=tempr

void four1(double data[], unsigned long nn, int isign)
{
  unsigned long n,mmax,m,j,istep,i;
  double wtemp,wr,wpr,wpi,wi,theta;
  double tempr,tempi;

  n=nn << 1;
  j=1;
  for (i=1;i<n;i+=2) {
    if (j > i) {
      SWAP(data[j],data[i]);
      SWAP(data[j+1],data[i+1]);
    }
    m=n >> 1;
    while (m >= 2 && j > m) {
      j -= m;
      m >>= 1;
    }
    j += m;
  }
  mmax=2;
  while (n > mmax) {
    istep=mmax << 1;
    theta=isign*(6.28318530717959/mmax);
    wtemp=sin(0.5*theta);
    wpr = -2.0*wtemp*wtemp;
    wpi=sin(theta);
    wr=1.0;
    wi=0.0;
    for (m=1;m<mmax;m+=2) {
      for (i=m;i<=n;i+=istep) {
        j=i+mmax;
        tempr=wr*data[j]-wi*data[j+1];
        tempi=wr*data[j+1]+wi*data[j];
        data[j]=data[i]-tempr;
        data[j+1]=data[i+1]-tempi;
        data[i] += tempr;
        data[i+1] += tempi;
      }
      wr=(wtemp=wr)*wpr-wi*wpi+wr;
      wi=wi*wpr+wtemp*wpi+wi;
    }
    mmax=istep;
  }
}
#undef SWAP
/* (C) Copr. 1986-92 Numerical Recipes Software 41]:. */


void realft(double data[], unsigned long n, int isign)
{
  void four1(double data[], unsigned long nn, int isign);
  unsigned long i,i1,i2,i3,i4,np3;
  double c1=0.5,c2,h1r,h1i,h2r,h2i;
  double wr,wi,wpr,wpi,wtemp,theta;

  theta=3.141592653589793/(double) (n>>1);
  if (isign == 1) {
    c2 = -0.5;
    four1(data,n>>1,1);
  } else {
    c2=0.5;
    theta = -theta;
  }
  wtemp=sin(0.5*theta);
  wpr = -2.0*wtemp*wtemp;
  wpi=sin(theta);
  wr=1.0+wpr;
  wi=wpi;
  np3=n+3;
  for (i=2;i<=(n>>2);i++) {
    i4=1+(i3=np3-(i2=1+(i1=i+i-1)));
    h1r=c1*(data[i1]+data[i3]);
    h1i=c1*(data[i2]-data[i4]);
    h2r = -c2*(data[i2]+data[i4]);
    h2i=c2*(data[i1]-data[i3]);
    data[i1]=h1r+wr*h2r-wi*h2i;
    data[i2]=h1i+wr*h2i+wi*h2r;
    data[i3]=h1r-wr*h2r+wi*h2i;
    data[i4] = -h1i+wr*h2i+wi*h2r;
    wr=(wtemp=wr)*wpr-wi*wpi+wr;
    wi=wi*wpr+wtemp*wpi+wi;
  }
  if (isign == 1) {
    data[1] = (h1r=data[1])+data[2];
    data[2] = h1r-data[2];
  } else {
    data[1]=c1*((h1r=data[1])+data[2]);
    data[2]=c1*(h1r-data[2]);
    four1(data,n>>1,-1);
  }
}
/* (C) Copr. 1986-92 Numerical Recipes Software 41]:. */






static double sinwave(double t,double amp,double freq,double phase)
    /* Vrne vrednost sinusnega vala z amplitudo amp, frekvenco freq in fazo
    phase ob casu t; Faza se meri v stopinjah, frekvenca pa v hercih. */
{
return amp*sin(2*Pi*freq*t+rad(phase));
}

static double func1(double x)
{
return sin(x);
}

static double func2(double x)
{
return cos(x);
}

static double func3(double x)
{
return -cos(x);
}


static double (*func)(double)=func1;


static double normalfunc(double x,double mean,double dev)
    /* Vrne vrednost Gaussove normalne funkcije s srednjo vrednostjo mean in
    sirino dev pri x. Integral funkcije od minus neskoncno do plus neskoncno
    je 1. Funkcija ima prevoja pri x+-dev.
    $A Igor jan01; */
{
return exp(-0.5*(x-mean)*(x-mean)/(dev*dev))/(dev*sqrt(2*ConstPi));
}


static stack waves=NULL;

static void resetwaves(void)
    /* Zbrise vse valove s sklada waves.
    $A Igor dec00; */
{
dispstackvalspec(waves,(void (*)(void **)) dispvector);
}

static void addwave(double power,double freq,double phase)
    /* Na sklad waves doda val z mocjo power, frekvenco freq in fazo phase.
    $A Igor jan00; */
{
vector w;
if (power>0 && freq>0)
{
  w=getvector(3);
  w->v[1]=sqrt(2)*sqrt(power); w->v[2]=freq; w->v[3]=phase;
  if (waves==NULL)
    waves=newstack(10);
  pushstack(waves,w);
}
}

static void addnormalpack(double totpow,double mean,double dev,
                          double relwidth,int n,double phase)
    /* Na sklad waves doda valovni paket, ki je sestavljen iz skupine n valov
    z amplitudami porazdeljenimi po normalni porazdelitvi s srednjo vrednostjo
    mean in deviacijo dev, s skupno mocjo paketa totpow ter relativno
    sirino glede na dev relwidth. Ce je rel*dev vecji kot mean, se frekvence
    zacnejo pri prvi frekvenci, ki bi bila vecja od 0. Vsi posamezni valovi v
    paketu imajo fazo phase.
    $A Igor jan01; */
{
double from,to,h,ss,x;
int i;
if (n<=1)
  n=10;
if (relwidth<=0)
  relwidth=2;
if (dev<=0)
  dev=0.1;
if (mean<0)
  mean=-mean;
from=mean-dev*relwidth;
to=mean+dev*relwidth;
if (from<=0)
  from=to/n;
h=(to-from)/(n-1);
/* Izracun vsote moci normalne funkcije po diskretnih vrednostih frekvenc: */
ss=0; x=from;
for (i=1;i<=n;++i)
{
  ss+=normalfunc(x,mean,dev);
  x+=h;
}
/* Izracun normirnega faktorja: */
ss=totpow/ss;
x=from;
to=0;
for (i=1;i<=n;++i)
{
  addwave(ss*normalfunc(x,mean,dev),x,phase);
  to+=ss*normalfunc(x,mean,dev);
  x+=h;
}
printf("Total power of wave packet: %g.\n",to);
}

static void printwaves(void)
    /* Izpise podatke o valovih, ki so na skladu waves.
    $A Igor dec00; */
{
int i;
vector w;
double wpow,totpow=0;
if(waves==NULL)
  printf("No waves.\n");
else if (waves->n==0)
  printf("No waves.\n");
else
{
  printf("%5s  %15s %15s %15s %15s %15s\n",
   "No.","power","freq.","phase","cum. power","amplitude");
  for (i=1;i<=waves->n;++i)
  {
    w=waves->s[i];
    wpow=0.5*w->v[1]*w->v[1];
    totpow+=wpow;
    printf("%5i: %15g %15g %15g %15g %15g\n",i,wpow,w->v[2],w->v[3],totpow,
     w->v[1]);
  }
}
}

static void fprintwaves(FILE *fp)
    /* Izpise podatke o valovih, ki so na skladu waves, v datoteko fp.
    $A Igor dec00; */
{
int i;
vector w;
double wpow,totpow=0;
if (fp!=NULL)
{
if(waves==NULL)
  fprintf(fp,"No waves.\n");
else if (waves->n==0)
  fprintf(fp,"No waves.\n");
else
{
  fprintf(fp,"%5s  %15s %15s %15s %15s %15s\n",
   "No.","power","freq.","phase","cum. power","amplitude");
  for (i=1;i<=waves->n;++i)
  {
    w=waves->s[i];
    wpow=0.5*w->v[1]*w->v[1];
    totpow+=wpow;
    fprintf(fp,"%5i: %15g %15g %15g %15g %15g\n",i,wpow,w->v[2],w->v[3],totpow,
     w->v[1]);
  }
}
}
}

double wavpack(double t)
    /* Vrne vrednost paketa sinusnih valov ob casu t. Paket je dolocen s
    podatki na skladu waves. Ti so vektorji, ki vsebujejo amplitudo, frekvenco
    in fazni zamik posam. valov.
    $A Igor dec00; */
{
double ret=0;
int i;
vector w;
if (waves!=NULL)
  if (waves->n>0)
    for (i=1;i<=waves->n;++i)
    {
      w=waves->s[i];
      ret+=sinwave(t,w->v[1],w->v[2],w->v[3]);
    }
return ret;
}

static double squarewavpack(double t)
    /* Vrne kvadrat paketa sinusnih valov ob casu t.
    $A Igor jan01; */
{
double ret;
ret=wavpack(t);
return ret*ret;
}

static int roundsamples=0;
static int smoothsamples=0;
static double sm0=20,sm1=10,sm2=5,sm3=2,sm4=0.5,sm5=0.005,sm6=0,sm7=0,sm8=0,
              sm9=0,sm10=0,smfac=1;


static void printsmoothpar(void)
{
  printf("\n\nCurrent values of smoothing parameters:\n");
  printf("smfac=%g\nsm0=%g\nsm1=%g\nsm2=%g\nsm3=%g\nsm4=%g\nsm5=%g\nsm6=%g\nsm7=%g\nsm8=%g\nsm9=%g\nsm10=%g\n\n\n",
   smfac,sm0,sm1,sm2,sm3,sm4,sm5,sm6,sm7,sm8,sm9,sm10);
}

static void readsmoothpar(void)
{
printf("\nSmooth sampled signal (0/1)? "); readint(&smoothsamples);
if (smoothsamples)
{
  printsmoothpar();
  printf("Input smoothing factors!\n");
  printf("smfac: "); readdouble(&smfac);
  printf("sm0: "); readdouble(&sm0);
  printf("sm1: "); readdouble(&sm1);
  printf("sm2: "); readdouble(&sm2);
  printf("sm3: "); readdouble(&sm3);
  printf("sm4: "); readdouble(&sm4);
  printf("sm5: "); readdouble(&sm5);
  printf("sm6: "); readdouble(&sm6);
  printf("sm7: "); readdouble(&sm7);
  printf("sm8: "); readdouble(&sm8);
  printf("sm9: "); readdouble(&sm9);
  printf("sm10: "); readdouble(&sm10);
}
}

static void smoothsampledsig1(vector samp)
    /* Zgladi vzorcen signal z majhno resolucijo na ta nacin, da i. vzorec 
    izracuna kot linearno kombinacijo originalnega vzorca in predhodnih ze
    izracunanih (zglajenih) vzorcev. */
{
double sum=0;
int i;
if (samp!=NULL)
{
  sum=sm0+sm1+sm2+sm3+sm4+sm5+sm6+sm7+sm8+sm9+sm10;
  sum/=smfac; /* obicajno je smfac 1) */
  sm0/=sum; sm1/=sum; sm2/=sum; sm3/=sum; sm4/=sum; sm5/=sum; sm6/=sum; sm7/=sum;
   sm8/=sum; sm9/=sum; sm10/=sum;
  for (i=11;i<=samp->d;++i)
    samp->v[i]=sm0*samp->v[i]+sm1*samp->v[i-1]+sm2*samp->v[i-2]+
     sm3*samp->v[i-3]+sm4*samp->v[i-4]+sm5*samp->v[i-5]+sm6*samp->v[i-6]
     +sm7*samp->v[i-7]+sm8*samp->v[i-8]+sm9*samp->v[i-9]+sm10*samp->v[i-10];
}
}

vector smoothbuf=NULL;

static void smoothsampledsig2(vector samp)
    /* Zgladi vzorcen signal z majhno resolucijo na ta nacin, da i. vzorec 
    izracuna kot linearno kombinacijo originalnega i. vzorca in predhodnih
    originalnih vzorcev (zato rabi vmesni pomnilnik, kamor shrane toliko
    originalnih vzorcev, kolikor uporablja korekturnih faktorjev). */
{
double sum=0;
int i,j;
vector buf;
if (samp!=NULL)
{
  if (smoothbuf==NULL)
    smoothbuf=getvector(11);
  buf=smoothbuf;
  sum=sm0+sm1+sm2+sm3+sm4+sm5+sm6+sm7+sm8+sm9+sm10;
  sum/=smfac; /* obicajno je smfac 1) */
  sm0/=sum; sm1/=sum; sm2/=sum; sm3/=sum; sm4/=sum; sm5/=sum; sm6/=sum; sm7/=sum;
   sm8/=sum; sm9/=sum; sm10/=sum;
  /* prvih 11 vzorcev spravimo v obratnem vrstnem redu v vmesni pomnilnik: */
  for (i=1;i<=buf->d;++i)
    buf->v[buf->d+1-i]=samp->v[i];
  for (i=11;i<=samp->d;++i)
  {
    
    samp->v[i]=sm0*buf->v[1]+sm1*buf->v[2]+sm2*buf->v[3]+sm3*buf->v[4]+
     sm4*buf->v[5]+sm5*buf->v[6]+sm6*buf->v[7]+sm7*buf->v[8]+sm8*buf->v[9]+
      sm9*buf->v[10]+sm10*buf->v[11];
    /* krozni premik vmesnega pomnilnika za 1 element v desno in dodajanje
    naslednjega elementa: */
    if (i<samp->d)
    {
      for (j=buf->d;--j;j>1)
        buf->v[j]=buf->v[j-1];
      buf->v[1]=samp->v[i+1];
    }
  }
}
}

static void smoothsampledsig(vector samp)
    /* Kombinacija obeh nacinov glajenja. Prvih pet parametrov je za drugi
    nacin, naslednjih pet pa za prvega.  */
{
double sum=0;
int i,j;
vector buf;
if (samp!=NULL)
{
  if (smoothbuf==NULL)
    smoothbuf=getvector(11);
  buf=smoothbuf;
  sum=sm0+sm1+sm2+sm3+sm4+sm5+sm6+sm7+sm8+sm9+sm10;
  sum/=smfac; /* obicajno je smfac 1) */
  sm0/=sum; sm1/=sum; sm2/=sum; sm3/=sum; sm4/=sum; sm5/=sum; sm6/=sum; sm7/=sum;
   sm8/=sum; sm9/=sum; sm10/=sum;
  /* prvih 11 vzorcev spravimo v obratnem vrstnem redu v vmesni pomnilnik: */
  for (i=1;i<=buf->d;++i)
    buf->v[buf->d+1-i]=samp->v[i];
  for (i=11;i<=samp->d;++i)
  {
    samp->v[i]=sm0*buf->v[1]+sm1*buf->v[2]+sm2*buf->v[3]+sm3*buf->v[4]+
     sm4*buf->v[5]+sm5*buf->v[6]+
     sm6*samp->v[i-1]+sm7*samp->v[i-2]+sm8*samp->v[i-3]+sm9*samp->v[i-4]+
     sm10*samp->v[i-5];
     /*
     sm6*buf->v[7]+sm7*buf->v[8]+sm8*buf->v[9]+
      sm9*buf->v[10]+sm10*buf->v[11];
     */
    /* krozni premik vmesnega pomnilnika za 1 element v desno in dodajanje
    naslednjega elementa: */
    if (i<samp->d)
    {
      for (j=buf->d;--j;j>1)
        buf->v[j]=buf->v[j-1];
      buf->v[1]=samp->v[i+1];
    }
  }
}
}

static vector samplesig(double (*sig)(double),double from,double to,int n)
    /* Vzorec signala sig v n vzorcnih tockah med from in to spravi v vektor
    in ga vrne.
    $A Igor jan01; */
{
vector ret=NULL;
double h;
int i;
h=(to-from)/(n-1);
ret=getvector(n);
for (i=1;i<=n;++i)
  ret->v[i]=sig(from+(i-1)*h);
if (roundsamples)  /* zaokrozevanje vrednosti */
  for (i=1;i<=n;++i)
    rounddouble(&(ret->v[i]));
if (smoothsamples)
  smoothsampledsig(ret);
return ret;
}

static void samplesig0(double (*sig)(double),double start,double Ts,int n,
     vector *vec)
    /* Vzorci signal sig v n vzorcih int rezultat spravi v vektor *v. ima
    na koncu dimenzijo n. Ts je casov. razmik med vzorci, start pa je cas
    prvega vzorca.
    $A Igor jan01; */
{
vector v;
double t;
int i;
if (*vec!=NULL)
{
  if ((*vec)->d<n)
    dispvector(vec);
  else (*vec)->d=n;
}
if (*vec==NULL)
  *vec=getvector(n);
t=start;
for (i=1;i<=n;++i)
{
  (*vec)->v[i]=sig(t);
  t+=Ts;
}
if (roundsamples)  /* zaokrozevanje vrednosti */
  for (i=1;i<=n;++i)
    rounddouble(&((*vec)->v[i]));
if (smoothsamples)
  smoothsampledsig(*vec);
}


static void samplesigtime(double (*sig)(double),double start,double Ts,
        double t,vector *vec)
    /* Signal sig vzorci od start naprej za cas t s periodo zajemanja Ts in
    shrane rezultat v vektor *vec. */
{
vector v;
int i,n;
n=(int) round(1.0+t/Ts);
samplesig0(sig,start,Ts,n,vec);
}


static void multiplysig(vector samp,double factor)
    /* Vzorcen signal samp pomnozi s faktorjem factor. */
{
int i;
if (samp!=NULL)
  for (i=1;i<=samp->d;++i)
    samp->v[i]*=factor;
}

static vector fourtransf(vector sample)
    /* Vrne vektor, ki vsebuje Fourierovo transformacijo vektorja sample.
    Njegova dolzina je prva cela potenca 2, ki je vecja ali enaka dolzini
    vektorja sample. Prva elementa vsebujeta F_0 in F_N/2, naslednje pa realni
    in imaginarni del (F_1), (F_2), ..., F_(N/2-1)
    $A Igor jan01; */
{
int n=sample->d,nft,p,i;
vector ret=NULL;
/* Zagotovimo, da bo nft=2^p in nft>=n in 2^(p-1)<n, kjer je p celo st.: */
p=(int)round(ln(n)/ln(2));
nft= (int) pow(2,p);
if (nft<n)
  nft*=2;
ret=getvector(nft);
/* Pripravimo vhodne podatke; prvi del so vzorcne vrednosti, kolikor pa ostane
prostora do konca (t.j. do cele potence 2, kar zahteva funkcija za fft), ga
zapolnimo z 0: */
for (i=1;i<=n;++i)
  ret->v[i]=sample->v[i];
for (i=n+1;i<=nft;++i)
  ret->v[i]=0;
/* Izvedba Fouriereve transformacije na podatkih: */
realft(ret->v,ret->d,1);
return ret;
}

static matrix procfourtransf(vector transf,double h,int M)
    /* Obdela podatke dobljene s Fourierovo transfomacijo ter vrne matriko,
    katere prva vrstica vsebuje frekvence v hertzih, druga pa kvadrate
    ustreznih diskretnih Fourierovih valov. V vektorju transf mora biti
    fourierova transformacija vzorca dobljena s funkcijo fourtransf, h mora
    biti korak vzorcenja, M pa originalno stevilo vzorcenj. Vektor transf ima
    namrec toliko elementov, kolikor je prva cela potenca 2, vecja ali enaka
    M.
    $A Igor jan01; */
{
matrix ret=NULL;
int i,N;
double factor;
N=transf->d;
/*
printf("\nN=%i, M=%i\n",N,M);
*/
ret=getmatrix(2,1+N/2);
/* Frekvence: */
for (i=1;i<=ret->d2;++i)
  ret->m[1][i]=(i-1)/(N*h);
/* Moci valov; Prva in zadnja realna amplituda sta v 1. in 2. elementu,
nato pa si sledijo po vrsti dvojice kompleksnih in realnih amplitud, ki jih je
treba kvadrirati in sesteti: */
factor=(double) 1/((double) M * (double) N);
ret->m[2][1]=transf->v[1]*transf->v[1]*factor;
ret->m[2][ret->d2]=transf->v[2]*transf->v[2]*factor;
for (i=2;i<ret->d2;++i)
{
  ret->m[2][i]=( transf->v[2*i-1]*transf->v[2*i-1]+
   transf->v[2*i]*transf->v[2*i] ) *factor*2;
}
return ret;
}

static vector fourtransf1(vector sample)
    /* Vrne vektor, ki vsebuje Fourierovo transformacijo vektorja sample.
    Njegova dolzina je prva cela potenca 2, ki je vecja ali enaka dvakratni 
    dolzini vektorja sample. Transformacijo se izvede s funkcijo four1 v
    nasprotju s fourtransf, kjer se transformacijo izvede s funkcijo realft.
    $A Igor jan01; */
{
int n=sample->d,nft,p,i;
vector ret=NULL;
/* Zagotovimo, da bo nft=2^p in nft>=n in 2^(p-1)<n, kjer je p celo st.: */
p=(int)round(ln(n)/ln(2));
nft= (int) pow(2,p);
if (nft<n)
  nft*=2;
ret=getvector(2*nft);
/* Pripravimo vhodne podatke; prvi del so vzorcne vrednosti, kolikor pa ostane
prostora do konca (t.j. do cele potence 2, kar zahteva funkcija za fft), ga
zapolnimo z 0. Vsaka vzorcna vrednost je sestavljena iz realnega in
imaginarnega dela, ki je 0, saj je nasa funkcija realna: */
for (i=1;i<=n;++i)
{
  ret->v[2*i-1]=sample->v[i]; /* real. del (i-1). vrednosti */
  ret->v[2*i]=0; /* imaginarni del */
}
for (i=n+1;i<=nft;++i)
{
  ret->v[2*i-1]=0;
  ret->v[2*i]=0;
}
/* Izvedba Fouriereve transformacije na podatkih: */
four1(ret->v,nft,1);
return ret;
}

static matrix procfourtransf1(vector transf,double h,int M)
    /* Obdela podatke dobljene s Fourierovo transfomacijo ter vrne matriko,
    katere prva vrstica vsebuje frekvence v hertzih, druga pa moci
    ustreznih diskretnih Fourierovih valov. V vektorju transf mora biti
    fourierova transformacija vzorca dobljena s funkcijo fourtransf1, h mora
    biti korak vzorcenja, M pa originalno stevilo vzorcenj. Vektor transf ima
    namrec toliko elementov, kolikor je prva cela potenca 2, vecja ali enaka
    M, krat 2.
    $A Igor jan01; */
{
matrix ret=NULL;
int i,N;
double factor;
N=transf->d/2;  /* polovica, ker so vrednosti v vektorju kompleksne */

printf("\nN=%i, M=%i\n",N,M);

ret=getmatrix(2,1+N/2);
/* Frekvence: */
for (i=1;i<=ret->d2;++i)
  ret->m[1][i]=(i-1)/(N*h);
/* Moci valov; Prva in zadnja realna amplituda sta v 1. in 2. elementu,
nato pa si sledijo po vrsti dvojice kompleksnih in realnih amplitud, ki jih je
treba kvadrirati in sesteti: */
factor=(double) 1/((double) M * (double) N);
ret->m[2][1]=(transf->v[1]*transf->v[1]+transf->v[2]*transf->v[2])*factor;
ret->m[2][ret->d2]=(transf->v[N+1]*transf->v[N+1]+
 transf->v[N+2]*transf->v[N+2])*factor;
for (i=2;i<ret->d2;++i)
{
  /* Za vsak i v tem obmocju moramo sesteti prispevek pozitivne in negativne
  frekvence, kar da faktor 2, saj sta amplitudi adjungirani drug drugi in sta
  zato kvadrata absolutnih vrednosti enaka: */
  ret->m[2][i]=( transf->v[2*i-1]*transf->v[2*i-1]+
   transf->v[2*i]*transf->v[2*i] ) *factor*2;
}
return ret;
}

static matrix procfourtransfold(vector transf,double h)
    /* Obdela podatke dobljene s Fourierovo transfomacijo ter vrne matriko,
    katere prva vrstica vsebuje frekvence v hertzih, druga pa kvadrate
    ustreznih diskretnih Fourierovih amplitud. V vektorju transf mora biti
    fourierova transformacija vzorca dobljena s funkcijo fourtransf, h pa mora
    biti korak vzorcenja.
    $A Igor jan01; */
{
matrix ret=NULL;
int i;
ret=getmatrix(2,transf->d/2+1);
/* Frekvence: */
for (i=1;i<=ret->d2;++i)
  ret->m[1][i]=(i-1)/(ret->d2*h*2);  /* Ugotovi, zakaj faktor 2!!! */
/* Kvadrati amplitud; Prva in zadna realna amplituda sta v 1. in 2. elementu,
nato pa si sledijo po vrsti dvojice kompleksnih in realnih amplitud, ki jih je
treba kvadrirati in sesteti: */
ret->m[2][1]=transf->v[1]*transf->v[1]*h*h;
ret->m[2][ret->d2]=transf->v[2]*transf->v[2]*h*h;

ret->m[2][1]*=2;  /* Ugotovi, zakaj mora biti tu faktor 2!!! */
ret->m[2][ret->d2]*=2;

for (i=2;i<ret->d2;++i)
{
  ret->m[2][i]=( transf->v[2*i-1]*transf->v[2*i-1]+
   transf->v[2*i]*transf->v[2*i] ) *h*h;
}
return ret;
}

static void printprocfourtransf(matrix data,double rel)
    /* Izpise podatke o sprocesitani fouriejevi analizi, t.j. o kvadratih
    amplitud pri diskretnih frekvencah. rel je relativen faktor, nad katerim
    mora biti kvadrat amplitude glede na maksimalno vrednost, da se dana
    frekvenca se izpise. Ce je rel manj ali enako 0 ali vec ali enako 1, se
    postavi na 10^-6.
    $A Igor jan01; */
{
double max=0,cum=0;
int i;
printf("Processed data of the fourier analysis:\n");
if (rel<=0 || rel>=1)
  rel=1.0e-3;
for (i=1;i<=data->d2;++i)
  if (data->m[2][i]>max)
    max=data->m[2][i];
printf("Frequency range from %g to %g, step %g\n",
 data->m[1][1],data->m[1][data->d2],data->m[1][2]-data->m[1][1]);
printf("Maximum wave power:            %g\n",max);
printf("Minimum wave power for output: %g\n",max*rel);
max*=rel;
printf("%15s %15s %15s\n","Frequency","Wave power.","Cumulative power");
for (i=1;i<=data->d2;++i)
{
  cum+=data->m[2][i];
  if (data->m[2][i]>=max)
    printf("%15g %15g %15g\n",data->m[1][i],data->m[2][i],cum);
}
printf("\nTotal power.: %.15g.\n\n",cum);
}

static void fprintprocfourtransf(matrix data,double rel,FILE *fp)
    /* Izpise podatke o sprocesitani fouriejevi analizi, t.j. o kvadratih
    amplitud pri diskretnih frekvencah. rel je relativen faktor, nad katerim
    mora biti kvadrat amplitude glede na maksimalno vrednost, da se dana
    frekvenca se izpise. Ce je rel manj ali enako 0 ali vec ali enako 1, se
    postavi na 10^-6.
    $A Igor jan01; */
{
double max=0,cum=0;
int i;
if (fp!=NULL)
{
fprintf(fp,"Processed data of the fourier analysis:\n");
if (rel<=0 || rel>=1)
  rel=1.0e-6;
for (i=1;i<=data->d2;++i)
  if (data->m[2][i]>max)
    max=data->m[2][i];
fprintf(fp,"Frequency range from %g to %g, step %g\n",
 data->m[1][1],data->m[1][data->d2],data->m[1][2]-data->m[1][1]);
fprintf(fp,"Maximum wave power:            %g.\n",max);
fprintf(fp,"Minimum wave power for output: %g.\n",max*rel);
max*=rel;
fprintf(fp,"%15s %15s %15s\n","Frequency","Wawe power","Cumulative power");
for (i=1;i<=data->d2;++i)
{
  cum+=data->m[2][i];
  if (data->m[2][i]>=max)
    fprintf(fp,"%15g %15g %15g\n",data->m[1][i],data->m[2][i],cum);
}
fprintf(fp,"\nTotal power: %.15g.\n\n",cum);
}
}


static void composewaves(FILE *fp)
    /* Funkcija za interaktivno zlaganje valov in valovnih paketov v paket, ki
    ga vrne funkcija wavpack. Ce je fp!=NULL, se rezultati in grafi izpisejo
    tudi v datoteko fp.
    $A Igor dec00; */
{
static double pamp=1,freq=500,phase=0,dev=1,dn=15,width=3,h=1e-4,sper=1,rel=1e-6;
static double cont=1,del=0,add=1,addpack=0,plot=1,dexit=0,treat=0,plotsig=0;
static double val1,val2,val3,val4;
static double from=0,to=0.01;
static int n=100,sn=40000,i;
static char drawxaxis=1,drawyaxis=1;
static double level1=0,level2=0;
static double pole1=0,pole2=0;
static int screenwidth=79;
static char printcoord=1;
static vector sample=NULL,sqsamp=NULL,transf=NULL;
static matrix proctransf;
printf("\n\nWave composer; Gradually add waves!\n");
dexit=0; pamp=1;
while(pamp!=0 && !dexit)
{
  printf("Waves that are currently included:\n\n");
  printwaves();
  printf("\n\nAdd another wave (0/1; now %g)? ",add); readdouble(&add);
  if (add!=0)
  {
    printf("Insert a zero amplitude to exit wave composition!\n");
    printf("Power     (last:%g): ",pamp); readdouble(&pamp);
    printf("Frequence (last:%g): ",freq); readdouble(&freq);
    printf("Phase     (last:%g): ",phase); readdouble(&phase);
    addwave(pamp,freq,phase);
    printf("\nWave added: power=%g, frequency=%g, phase=%g\n",pamp,freq,phase);
    if (fp!=NULL)
      fprintf(fp,"\n\n\nWave added: power=%g, frequency=%g, phase=%g\n\n\n",pamp,freq,phase);
  }
  printf("\n\nAdd another normal wave packet (0/1; now %g)? ",addpack); readdouble(&addpack);
  if (addpack!=0)
  {
    printf("Insert a zero amplitude to exit wave composition!\n");
    printf("Total power        (last: %g): ",pamp); readdouble(&pamp);
    printf("Mean frequence     (last: %g): ",freq); readdouble(&freq);
    printf("Standard deviation (last: %g): ",dev); readdouble(&dev);
    printf("Relative width     (last: %g): ",width); readdouble(&width);
    printf("Number of  waves   (last: %g): ",dn); readdouble(&dn);
    printf("Phase              (last: %g): ",phase); readdouble(&phase);
    addnormalpack(pamp,freq,dev,width,(int) round(dn),phase);
    printf("\nGauss wave packet added:\n");
    printf("power=%g, mean frequency=%g, deviation=%g,\n",pamp,freq,dev);
    printf("rel. width with respect to deviation =%g, number of waves=%i, phase=%g.\n",width,dn,phase);
    if (fp!=NULL)
    {
      fprintf(fp,"\n\n\nGauss wave packet added:\n");
      fprintf(fp,"power=%g, mean frequency=%g, deviation=%g,\n",pamp,freq,dev);
      fprintf(fp,"rel. width with respect to deviation =%g, number of waves=%i, phase=%g.\n\n\n",width,dn,phase);
    }
  }
  printf("\nWaves that are currently included:\n");
  printwaves();
  if (fp!=NULL)
  {
    fprintf(fp,"\n\n\n\nWaves that are currently included:\n");
    fprintwaves(fp);
  }
  printf("\nPlot a graph of the wave packet (0/1; now %g)? ",plot); readdouble(&plot);
  if (plot!=0)
  {
    if (fp!=NULL)
      fprintf(fp,"\n\nGRAPH OF THE WAVE PACKET:\n\n");
    drawfuncprimintaddr(wavpack,NULL,NULL,&from,&to,&n,&drawxaxis,
     &level1,&level2,&drawyaxis,&pole1,&pole2,&screenwidth,&printcoord,fp);
  }
  printf("\nProcess the signal (0/1; now %g)? ",treat); readdouble(&treat);
  if (treat)
  {
    printf("Sampling period (in seconds; now %g): ",sper);  readdouble(&sper);
    printf("You can insert number of sampling points instead of sampling step!\n");
    printf("Sampling step (in seconds; now %g, %i points): ",h,(int) round(sper/h)); readdouble(&h);
    if (h>1)  /* Prebrali smo n, ne h */
    {
      sn= (int) round(h);
      h=sper/(sn);
    } else
    {
      sn= (int) round(sper/h);
      h=sper/(sn);
    }
    printf("\nSampling period :        %g\n",sper);
    printf("Number of sampling points: %i\n",sn);
    printf("h: %g, 1/h: %g\n",h,1/h);
    if (fp!=NULL)
    {
      fprintf(fp,"\n\n\nSIGNAL PROCESSING:\n\n");
      fprintf(fp,"\nSampling period:         %g\n",sper);
      fprintf(fp,"Number of sampling points: %i\n",sn);
      fprintf(fp,"h: %g, 1/h: %g\n",h,1/h);
    }
    plotsig=0;
    printf("Plot sampled and analised signals (0/1; now %g)? ",plotsig); readdouble(&plotsig);
    printf("\nSampling the signal...\n");
    sample=samplesig(wavpack,0,sper,sn);
    sqsamp=getvector(sample->d);
    for (i=1;i<=sqsamp->d;++i)
      sqsamp->v[i]=sample->v[i]*sample->v[i];
    if (plotsig)
    {
      printf("\n\nSAMPLED DATA:\n\n");
      if (fp!=NULL)
        fprintf(fp,"\n\nSAMPLED DATA:\n\n");
      plotvec(sample,0,fp);
    }
    printf("\nIntegrating the wave packet on the sampling interval...\n");
    val1=intsimpsbas(wavpack,0,sper,10000);
    printf("\nIntegrating the square of the wave pack on the sampling interval...\n");
    val2=intsimpsbas(squarewavpack,0,sper,10000);
    val4=intsimpvecsafe(sqsamp,h);
    printf("\n\nINTEGRALS:\n");
    printf("Integral of the wave packet is          %g.\n",val1);
    printf("Integral of square wave pack is         %g, total power is %g.\n",val2,val2/sper);
    printf("Integral of sampled square wave pack is %g, total power is %g.\n",val4,val4/sper);
    val3=0;
    for (i=1;i<=sample->d;++i)
      val3+=sample->v[i]*sample->v[i];
    val3/=sample->d;
    printf("Average square amplitude is %.10g.\n",val3);
    if (fp!=NULL)
    {
      fprintf(fp,"\n\nINTEGRALS:\n");
      fprintf(fp,"Integral of the wave packet is  %g.\n",val1);
      fprintf(fp,"Integral of square wave pack is %g.\n",val2);
      fprintf(fp,"Average square amplitude is %.10g.\n",val3);
    }
    printf("\nCalculating Fourier transform of the sampled data...\n");
    transf=fourtransf(sample);
    if (plotsig)
    {
      if (fp!=NULL)
        fprintf(fp,"\n\n\nGRAPH OF FOURIER TRANSFORM OF THE SAMPLED SIGNAL:\n\n");
      plotvec(transf,0,fp);
    }
    printf("\nProcessing Fourier transform...\n");
    printf("Relative amplitude limit for frequency output: "); readdouble(&rel);
    proctransf=procfourtransf(transf,h,sn);
    printprocfourtransf(proctransf,rel);
    if (plotsig)
    {
      if (fp!=NULL)
      {
        fprintf(fp,"\n\n\nPOWER SPECTRUM:\n\n");
        fprintprocfourtransf(proctransf,rel,fp);
        fprintf(fp,"\n\n\n");
      }
      plotmat2(proctransf,0,fp);
      printprocfourtransf(proctransf,rel);
    }
    /* Brisanje vektorjev in matrik, ki vsebujejo podatke: */
    /*
    printvector(transf);
    printmatrix(proctransf);
    */
    dispvector(&sample);
    dispvector(&sqsamp);
    dispvector(&transf);
    dispmatrix(&proctransf);
  }
  del=0;
  printf("\nDelete all waves (0/1; now %g)? ",del); readdouble(&del);
  if (del!=0)
  {
    printf("Reaally delete all waves (0/1)? "); readdouble(&del);
    if (del!=0)
      resetwaves();
  }
  printf("\n\nExit wave composer (0/1; now %g)? ",dexit); readdouble(&dexit);
  printf("\n\n\n");
  if (fp!=NULL)
    fflush(fp);
}
}



static double normf0(double x)
{
return normalfunc(x,0,1);
}

static double ident(double x)
{
return x;
}


static double db(double R)
   /* Vrne decibele pri razmerju moci R */
{
return 10*ln(R)/ln(10);
}

static double dbamp(double A)
   /* Vrne decibele pri razmerju amplitud A */
{
return 20*ln(A)/ln(10);
}

static double invdb(double db)
    /* Vrne razmerje moci pri dani vrednosti v decibelih */
{
return pow(10,0.1*db);
}

static double invdbamp(double db)
    /* Vrne razmerje amplitud pri dani vrednosti v decibelih */
{
return pow(10,0.05*db);
}


/* ODZIVI FILTROV: */

/* LOW PASS & HIGH PASS FILTRI (ANALOGNI) */

double amplow(double f,double fhigh)
    /* Vrne razmerje med izhodno in vhodno amplitudo nizkoprepustnega filtra
    s karakterist. zgornjo frekvencno mejo fhigh pri frekvenci f */
{
return fhigh/sqrt(fhigh*fhigh+f*f);
}

double amphigh(double f,double flow)
    /* Vrne razmerje med izhodno in vhodno amplitudo visokoprepustnega filtra
    s karakterist. spodnjo frekvencno mejo flow pri frekvenci f */
{
return f/sqrt(flow*flow+f*f);
}

double ampres(double f,double f0,double hr)
{
double w,w0,beta,x;
w=2*ConstPi*f;
w0=2*ConstPi*f0;
beta=0.5*hr*w0;
x=w/w0;
return 1/sqrt(sqr(1-sqr(x))+sqr(2*beta/w0)*sqr(x));
}

double ampresmir(double f,double f0,double hr)
{
return ampres(sqr(f0)/f,f0,hr);
/*
double w,w0,beta,x;
w=2*ConstPi*f;
w0=2*ConstPi*f0;
beta=0.5*hr*w0;
x=w/w0;
return 1/sqrt(sqr(1-sqr(x))+sqr(2*beta/w0)*sqr(x));
*/
}


/* FILTRI ZA UTEZEVANJE: */


double dbC(double f,double fhigh1,double fhigh2,double flow3,double flow4)
    /* Vrne odziv filtra C pri frekvenci f v decibelih. fhigh1,fhigh2,flow3 in flow4
    so karakteristicne frekvence posameznih filtrov (dveh nizkofrekvencnih in
    dveh visokofrekvencnih). */
{
return dbamp(amplow(f,fhigh1))+dbamp(amplow(f,fhigh2))
 +dbamp(amphigh(f,flow3))+dbamp(amphigh(f,flow4));
}

double dbB(double f,double fhigh1,double fhigh2,double flow3,double flow4,
           double flow5)
    /* Vrne odziv filtra B pri frekvenci f v decibelih. fhigh1,fhigh2,flow3, flow4
     in flow5 so karakteristicne frekvence posameznih filtrov (dveh
    nizkofrekvencnih in treh visokofrekvencnih). */
{
return dbamp(amplow(f,fhigh1))+dbamp(amplow(f,fhigh2))
 +dbamp(amphigh(f,flow3))+dbamp(amphigh(f,flow4))+dbamp(amphigh(f,flow5));
}

double dbA(double f,double fhigh1,double fhigh2,double flow3,double flow4,
       double flow5,double flow6)
    /* Vrne odziv filtra A pri frekvenci f v decibelih. fhigh1,fhigh2,flow3 in flow4,
    flow5 in flow6 so karakteristicne frekvence posameznih filtrov (dveh
    nizkofrekvencnih in stirih visokofrekvencnih). */
{
return dbamp(amplow(f,fhigh1))+dbamp(amplow(f,fhigh2))
 +dbamp(amphigh(f,flow3))+dbamp(amphigh(f,flow4))+dbamp(amphigh(f,flow5))+
  dbamp(amphigh(f,flow6));
}



/* FREKVENCE IN KOREKTURNI FAKTORJI OJACANJA ZA FILTRE A,
B in C: */

/* Frekvence za utezevanje: */
static double fhigh1=12200, fhigh2=12200, flow3=20.6, flow4=20.6,
flow5=158.5, 
flow6=107.7,  flow7=737.9;
/* Korekturni faktorji za utezevanje: */
static double corA=1.2589,corB=1.01972,corC=1.00715;

/* Frekvence za filtre */
static double flow=20.6,fhigh=12200,fres=1000,hres=0.5; 

/* Frekvence za pasovne filtre: */
static double fhigh3=12200,fhigh4=12200,fhigh5=12200,fhigh6=12200,
fhigh7=12200,fhigh8=12200,fhigh9=12200,fhigh10=12200,
  flow1=20.6,flow2=20.6,flow8=20.6,flow9=20.6,flow10=20.6;

/* Frekvence za zvonaste filtre: */

static double fres1=1000,hres1=0.5,fres2=1000,hres2=0.5,fres3=1000,hres3=0.5,
              fres4=1000,hres4=0.5,fres5=1000,hres5=0.5,fres6=1000,hres6=0.5, 
              fres7=1000,hres7=0.5,fres8=1000,hres8=0.5,fres9=1000,hres9=0.5, 
              fres10=1000,hres10=0.5;

int multiplicity=1;  /* veckratnost resonancnih filtrov */
/* Frekvence za low in high pass filtre, ki jih kombiniramo z zvonastimi: */
static double freslow1=0,freslow2=0,freshigh1=0,freshigh2=0;

/* Koeficienti za splosne filtre: */
static double cfa0=0,cfa1=0,cfa2=0,cfa3=0,cfa4=0,cfa5=0,cfa6=0,cfa7=0,cfa8=0,
              cfa9=0,cfa10=0,
              cfb0=0,cfb1=0,cfb2=0,cfb3=0,cfb4=0,cfb5=0,cfb6=0,cfb7=0,cfb8=0,
              cfb9=0,cfb10=0;


/* Frekvence za antialias filtre: */
static int antialias=0;
static double falias1=40000,falias2=80000;

/* Cas vzorcenja */
static double Ts=1.0e-5;

/* Casovno utezevanje ('S', 'F' ali 'I'): */
static char timewt='F';

/* Testna frekvenca: */
static double testf=0;

/* FUNKCIJE ZA RISANJE ODZIVOV FILTROV. PARAMETER JE VEDNO INDEKS n STANDARDNE
FREKVENCE, KI JE SICER ZVEZEN, VRNE PA SE ODZIV V DECIBELIH. */

static double fstdcont(double n)
    /* Vrne natancno vrednost n-te standardne frekvenco, n je zvezen argument. */
{
return 1000.0*pow(10.0,0.1*(double)n);
}

static double invfstd(double f)
    /* Vrne indeks n frekvence f (to je inverzna funkcija od fstdcont). */
{
return 10*ln(f/1000)/ln(10);
}

static double respC(double n)
    /* Filter za A utezevanje brez korekcije */
{
return dbC(fstdcont(n),fhigh1,fhigh2,flow3,flow4);
}

static double respB(double n)
    /* Filter za A utezevanje brez korekcije */
{
return dbB(fstdcont(n),fhigh1,fhigh2,flow3,flow4,flow5 );
}

static double respA(double n)
    /* Filter za A utezevanje brez korekcije */
{
return dbA(fstdcont(n),fhigh1,fhigh2,flow3,flow4,flow6,flow7);
}

static double resplow(double n)
    /* Low pass filter */
{
return dbamp(amplow(fstdcont(n),fhigh));
}    

static double resphigh(double n)
    /* High pass filter */
{
return dbamp(amphigh(fstdcont(n),flow));
}    



void printweight(void)
{
double fhigh1,fhigh2,flow3,flow4,flow5,flow6,flow7;
int i;
double f,decA,decB,decC;
printf("\n\nFrequency response of the A weighting circuit:\n");
printf("fhigh1=%g, fhigh2=%g,flow3=%g,flow4=%g\n",fhigh1,fhigh2,flow3,flow4);
printf("%15s %15s %15s %15s\n","freq.","db(A)","db(B)","db(C)");
for (i=-20;i<=13;++i)
{
  f=1000.0*pow(10.0,((double)i/10));  /* pokritje frekvenc iz standarda */
  decC=dbC(f,fhigh1,fhigh2,flow3,flow4);
  decB=dbB(f,fhigh1,fhigh2,flow3,flow4,flow5);
  decA=dbA(f,fhigh1,fhigh2,flow3,flow4,flow6,flow7);
  printf("%15.8g %15.8g %15.8g %15.8g\n",f,decA,decB,decC);
}
printf("\n\n");
}


             /**********************/
             /*                    */
             /*  DIGITALNI FILTRI  */
             /*                    */
             /**********************/


/* Pomoz. stvari za funkcijo numfiltresp */
static vector numtestsamp=NULL;
static double numtestangf=0,numtestamp=1.0;

static void filtsqrav(vector v); /* samo deklaracija vnaprej */

static double numtestwave(double t)
{
return numtestamp*sin(Pi/4+ numtestangf*t);
}

static double numfiltresp( void (*filtdig)(vector v),double f,double Ts)
    /* Vrne odziv filtra filtdig pri frekvenci f in casu sempliranja Ts v
    decibelih. */
{
double nstart,num,period,eni=0,eno=0;
int i,j=0,rounds,smooths;
char p=0;  /* izpis vmesnih rezultatov */
/* Shranijo se zastavice, ki dolocajo, ali se vzorec zaokrozuje in gladi: */
rounds=roundsamples;
smooths=smoothsamples;
period=1/f;
numtestangf=2*Pi*f; /* frekvenca testnega vala */
/* Zacetek merjenja energije, naj bi bilo cca. 20 period, vendar ne vec kot
200000 vzorcev: */
nstart=round(20*period/Ts);
if (nstart>30000)
  nstart=30000;
if (nstart<=1000)
  nstart=1000;
/* Stevilo vzorcev, ki se porabi za merjenje energije; Cas mora pretecti celo
stevilo period, zajetih naj bo vsaj 10000 vzorcev, nikakor pa vec kot 500000. */
i=1;
num=round(i*period/Ts);
while(num<10000)
{
  ++i;
  num=round(i*period/Ts);
}
/*
while (num>500000 && (num-1)*Ts>period)
{
  --i;
  num=round(i*period/Ts);
}
*/
if (num>100000)  /* skrajna dopustna meja za num */
{
  num=100000;
  printf("\nWarning: numerical response is estimated on less than a whole period\n");
  printf("at frequency %g (period %g, sampled %g).\n",f,period,num*Ts);
}
if (p)
{
  printf("\nstart=%g, num=%g, %g periods. Sampling...",nstart,num,num*Ts/period);
}
/* Zajem referencnega vzorca; Referencni vzorec se niti ne zaokrozuje niti
ne gladi: */
roundsamples=smoothsamples=0;
samplesig0(numtestwave,0,Ts,(int)(nstart+num+1),&numtestsamp);
/* Celotna vsota kvadratov po testiranem obmocju vhod. signala: */
for (i=(int)nstart;i<(int)nstart+num;++i)
  eni+=sqr(numtestsamp->v[i]);
/* Zajem vzorca, ki se filtrira . Vzorec, ki se filtrira, se zaokrozuje in
gladi, ce je tako doloceno: */
roundsamples=rounds;
smoothsamples=smooths;
if (p)
  printf("Sampling...\n");
samplesig0(numtestwave,0,Ts,(int)(nstart+num+1),&numtestsamp);
if (p)
  printf("Filtering...\n");
filtdig(numtestsamp);
/* Celotna vsota kvadratov po testiranem obmocju izhod. signala: */
for (i=(int)nstart;i<(int)nstart+num;++i)
  eno+=sqr(numtestsamp->v[i]);
return db(eno/eni);
}


static double numfiltresp1( void (*filtdig)(vector v),double f,double Ts)
    /* Vrne odziv filtra filtdig pri frekvenci f in casu sempliranja Ts v
    decibelih. IZPISE SE PODATEK O SITUACIJI, CE JE VKLJUCENO POVPRECENJE. */
{
double nstart,num,period,eni=0,eno=0,enoav=0;
int i,j=0,rounds,smooths;
char p=0;  /* izpis vmesnih rezultatov */
/* Shranijo se zastavice, ki dolocajo, ali se vzorec zaokrozuje in gladi: */
rounds=roundsamples;
smooths=smoothsamples;
period=1/f;
numtestangf=2*Pi*f; /* frekvenca testnega vala */
/* Zacetek merjenja energije, naj bi bilo cca. 20 period, vendar ne vec kot
200000 vzorcev: */
nstart=round(20*period/Ts);
if (nstart>30000)
  nstart=30000;
if (nstart<=1000)
  nstart=1000;
if (timewt=='S' || timewt=='s')
  nstart+=100000;
else
  nstart+=20000;
/* Stevilo vzorcev, ki se porabi za merjenje energije; Cas mora pretecti celo
stevilo period, zajetih naj bo vsaj 10000 vzorcev, nikakor pa vec kot 500000. */
i=1;
num=round(i*period/Ts);
while(num<10000)
{
  ++i;
  num=round(i*period/Ts);
}
/*
while (num>500000 && (num-1)*Ts>period)
{
  --i;
  num=round(i*period/Ts);
}
*/
if (num>100000)  /* skrajna dopustna meja za num */
{
  num=100000;
  printf("\nWarning: numerical response is estimated on less than a whole period\n");
  printf("at frequency %g (period %g, sampled %g).\n",f,period,num*Ts);
}
if (p)
{
  printf("\nstart=%g, num=%g, %g periods. Sampling...",nstart,num,num*Ts/period);
}
/* Zajem referencnega vzorca; Referencni vzorec se niti ne zaokrozuje niti
ne gladi: */
roundsamples=smoothsamples=0;
samplesig0(numtestwave,0,Ts,(int)(nstart+num+1),&numtestsamp);
/* Celotna vsota kvadratov po testiranem obmocju vhod. signala: */
for (i=(int)nstart;i<(int)nstart+num;++i)
  eni+=sqr(numtestsamp->v[i]);
/* Zajem vzorca, ki se filtrira . Vzorec, ki se filtrira, se zaokrozuje in
gladi, ce je tako doloceno: */
roundsamples=rounds;
smoothsamples=smooths;
if (p)
  printf("Sampling...\n");
samplesig0(numtestwave,0,Ts,(int)(nstart+num+1),&numtestsamp);
if (p)
  printf("Filtering...\n");
filtdig(numtestsamp);
/* Celotna vsota kvadratov po testiranem obmocju izhod. signala: */
for (i=(int)nstart;i<(int)nstart+num;++i)
  eno+=sqr(numtestsamp->v[i]);
if (1)
{
  /* Casovno utezevanje (povprecenje): */
  filtsqrav(numtestsamp);
  for (i=(int)nstart;i<(int)nstart+num;++i)
    enoav+=numtestsamp->v[i];
  printf("\nLevel of unaveraged signal: %g\n level of averaged signal: %g\n",
   db(eno/eni),db(enoav/eni));
  printf("Averaged level based on single (last) sample:%g\n",
    db((double) num*numtestsamp->v[numtestsamp->d]/eni));
}
return db(eno/eni);
}




static double numfiltrespsamp( void (*filtdig)(vector v),double Ts,
              vector samp)
    /* Vrne odziv filtra filtdig pri frekvenci f in casu sempliranja Ts v
    decibelih. */
{
double nperiod,nstart,num,period,eni=0,eno=0,
 f=testf; /* Testna frekvenca, ki je glob. stat. spremanljivka */
int i,j=0,rounds,smooths;
char p=0;  /* izpis vmesnih rezultatov */
/* Shranijo se zastavice, ki dolocajo, ali se vzorec zaokrozuje in gladi: */
rounds=roundsamples;
smooths=smoothsamples;
if (f!=0)
  period=1/f;
/* Zacetek merjenja energije, naj bi bilo cca. 20 period, vendar ne vec kot
200000 vzorcev: */
nstart=round(samp->d/5);
if (nstart>30000)
  nstart=30000;
/* Stevilo vzorcev, ki se porabi za merjenje energije; Cas mora pretecti celo
stevilo period, zajetih naj bo vsaj 10000 vzorcev, nikakor pa vec kot 500000. */
i=1;
if (f!=0)
{
  num=round(i*period/Ts);
  while(num<10000 && samp->d-num>period/Ts)
  {
    ++i;
    num=round(i*period/Ts);
  }
  if (num>100000)  /* skrajna dopustna meja za num */
  {
    num=100000;
    printf("\nWarning: numerical response is estimated on less than a whole period\n");
    printf("at frequency %g (period %g, sampled %g).\n",f,period,num*Ts);
  }
  else if (num+nstart>samp->d)
  {
    num=samp->d-nstart;
    printf("\nWarning: numerical response is estimated on less than a whole period\n");
    printf("at frequency %g (period %g, sampled %g).\n",f,period,num*Ts);
  }
} else
{
  num=samp->d-nstart;
  if (num>100000)
    num=100000;
}
if (nstart<1 || num<1 || num+nstart>samp->d)
{
  errfunc0("numfiltrespsamp");
  fprintf(erf(),"Wrong parameters.\n");
  errfunc2();
}
if (p)
{
  printf("\nstart=%g, num=%g, %g periods. Sampling...",nstart,num,num*Ts/period);
}
/* Celotna vsota kvadratov po testiranem obmocju vhod. signala: */
for (i=(int)nstart;i<(int)nstart+num;++i)
  eni+=sqr(samp->v[i]);
if (p)
  printf("Filtering...\n");
filtdig(samp);
/* Celotna vsota kvadratov po testiranem obmocju izhod. signala: */
for (i=(int)nstart;i<(int)nstart+num;++i)
  eno+=sqr(samp->v[i]);
return db(eno/eni);
}


/* SPLOSNI DIGITALNI FILTRI */


static void filtgendig5(vector v,double a0,double a1,double a2,double a3,
            double a4,double a5,double b1,double b2,double b3,double b4,
            double b5)
    /* Filtrira vzorcen signal, ki je v vektorju v, s splosnim filtrom s petimi
    +1 vhodnimi in petimi izhodnimi koeficienti a0, a1, ... a5, b1, b2, ..., b5.
    $A Igor mar01; */
{
double Ui1,Ui2,Ui3,Ui4,Ui5,Uo1,Uo2,Uo3,Uo4,Uo5,Uo;
int i;
if (v!=NULL) if (v->d>5)
{
  Ui1=Uo1=v->v[5];  /* prejsnji vhodni in izhodni vzorec */
  Ui2=Uo2=v->v[4];  /* predprejsnji vhodni in izhodni vzorec */
  Ui3=Uo3=v->v[3];
  Ui4=Uo4=v->v[2];
  Ui5=Uo5=v->v[1];
  for (i=6;i<=v->d;++i)
  {
    Uo=a0*v->v[i]+a1*Ui1+a2*Ui2+a3*Ui3+a4*Ui4+a5*Ui5+
                  b1*Uo1+b2*Uo2+b3*Uo3+b4*Uo4+b5*Uo5;
    Ui5=Ui4; Ui4=Ui3; Ui3=Ui2; Ui2=Ui1; Ui1=v->v[i];
    Uo5=Uo4; Uo4=Uo3; Uo3=Uo2; Uo2=Uo1; Uo1=Uo;
    v->v[i]=Uo;
  }
}
}

static void filtgendig10(vector v,double a0,double a1,double a2,double a3,
                        double a4,double a5,double a6,double a7,double a8,
                        double a9,double a10,double b1,double b2,double b3,
                        double b4,double b5,double b6,double b7,double b8,
                        double b9,double b10)
    /* Filtrira vzorcen signal, ki je v vektorju v, s splosnim filtrom z desetimi
    +1 vhodnimi in desetimi izhodnimi koeficienti a0, a1, ... a5, b1, b2, ..., b5.
    $A Igor mar01; */
{
double Ui1,Ui2,Ui3,Ui4,Ui5,Ui6,Ui7,Ui8,Ui9,Ui10,
       Uo1,Uo2,Uo3,Uo4,Uo5,Uo6,Uo7,Uo8,Uo9,Uo10,Uo;
int i;
if (v!=NULL) if (v->d>10)
{
  Ui1=Uo1=v->v[10];  /* prejsnji vhodni in izhodni vzorec */
  Ui2=Uo2=v->v[9];  /* predprejsnji vhodni in izhodni vzorec */
  Ui3=Uo3=v->v[8];
  Ui4=Uo4=v->v[7];
  Ui5=Uo5=v->v[6];
  Ui6=Uo6=v->v[5];
  Ui7=Uo7=v->v[4];
  Ui8=Uo8=v->v[3];
  Ui9=Uo9=v->v[2];
  Ui10=Uo10=v->v[1];
  for (i=11;i<=v->d;++i)
  {
    Uo=a0*v->v[i]+a1*Ui1+a2*Ui2+a3*Ui3+a4*Ui4+a5*Ui5+a6*Ui6+a7*Ui7+a8*Ui8
                 +a9*Ui9+a10*Ui10+
       b1*Uo1+b2*Uo2+b3*Uo3+b4*Uo4+b5*Uo5+b6*Uo6+b7*Uo7+b8*Uo8+b9*Uo9+b10*Uo10;
    Ui10=Ui9; Ui9=Ui8; Ui8=Ui7; Ui7=Ui6; Ui6=Ui5; Ui5=Ui4; Ui4=Ui3; Ui3=Ui2;
     Ui2=Ui1; Ui1=v->v[i];
    Uo10=Uo9; Uo9=Uo8; Uo8=Uo7; Uo7=Uo6; Uo6=Uo5; Uo5=Uo4; Uo4=Uo3; Uo3=Uo2;
     Uo2=Uo1; Uo1=Uo;
    v->v[i]=Uo;
  }
}
}


/* LOW PASS & HIGH PASS FILTRI (DIGITALNI) */

static double amplowdig(double f,double fhigh,double Ts)
    /* Vrne razmerje med izhodno in vhodno amplitudo nizkoprepustnega
    digitalnega filtra s karakterist. zgornjo frekvencno mejo fhigh pri
    frekvenci f in s casom vzorcenja (smpling time) Ts */
{
double a,b,RC,w;
RC=1/(2*Pi*fhigh);
a=Ts/(Ts+RC);
b=RC/(Ts+RC);
w=2*Pi*f;
return a/sqrt( 1+b*b-2*b*cos(w*Ts) );
}

static void filtlowdig(vector v,double fhigh,double Ts)
    /* Filtrira vzorcen signal, ki je v vektorju v, z nizkoprepustnim filtrom
    s karakteristicno frekvenco fhigh. Ts je vzorcni cas.
    $A Igor jan01; */
{
double a0,b1,RC;
int i;
RC=1/(2*Pi*fhigh);
a0=Ts/(Ts+RC);
b1=RC/(Ts+RC);
if (v!=NULL)
  for (i=2;i<=v->d;++i)
    v->v[i]=
     a0*v->v[i]+    /* i. vhodna vrednost */
     b1*v->v[i-1];  /* (i-1). izhodna vrednost */
}

static void filtlowdigcor(vector v,double fhigh,double Ts,
    double corf,double cora0,double corb1)
    /* Filtrira vzorcen signal, ki je v vektorju v, z nizkoprepustnim filtrom
    s karakteristicno frekvenco fhigh. Ts je vzorcni cas. corf, cora0
    in corb1 so relativni popravki za karakteristicno frekvenco, faktor a0
    in faktor b1.
    $A Igor jan01; */
{
double a0,b1,RC;
int i;
fhigh*=(1+corf);
RC=1/(2*Pi*fhigh);
a0=Ts/(Ts+RC);
b1=RC/(Ts+RC);
a0*=(1+cora0);
b1*=(1+corb1);
if (v!=NULL)
  for (i=2;i<=v->d;++i)
    v->v[i]=
     a0*v->v[i]+    /* i. vhodna vrednost */
     b1*v->v[i-1];  /* (i-1). izhodna vrednost */
}

static void filtlowdigcor1(vector v,double fhigh,double Ts,
    double corf,double cora0,double corb1)
    /* Filtrira vzorcen signal, ki je v vektorju v, z nizkoprepustnim filtrom
    s karakteristicno frekvenco fhigh. Ts je vzorcni cas. corf, cora0
    in corb1 so relativni popravki za karakteristicno frekvenco, faktor a0
    in faktor b1.
    $A Igor jan01; */
{
double a0,b1,RC;
int i;
fhigh*=(1+corf);
RC=1/(2*Pi*fhigh);
a0=Ts/(Ts+RC);
b1=RC/(Ts+RC);
a0*=(1+cora0);
b1*=(1+corb1);
filtgendig5(v,a0,0,0,0,0,0,b1,0,0,0,0);
}

static void filtlowdigold(vector v,double fhigh,double Ts)
    /* Filtrira vzorcen signal, ki je v vektorju v, z nizkoprepustnim filtrom
    s karakteristicno frekvenco fhigh. Ts je vzorcni cas.
    $A Igor jan01; */
{
double a,b,RC;
int i;
RC=1/(2*Pi*fhigh);
a=Ts/(Ts+RC);
b=RC/(Ts+RC);
if (v!=NULL)
  for (i=2;i<=v->d;++i)
    v->v[i]=v->v[i-1]+(Ts/(Ts+RC)*(v->v[i]-v->v[i-1]));
}

static void filtlowdigcent(vector v,double fhigh,double Ts)
    /* Filtrira vzorcen signal, ki je v vektorju v, z nizkoprepustnim filtrom
    s karakteristicno frekvenco fhigh. Ts je vzorcni cas.
    $A Igor jan01; */
{
double a,b,c,RC;
int i,start=5000;
vector in=NULL,out=NULL,cnt=NULL;
char p=0;
if (v!=NULL) if (v->d>0)
{
  RC=1/(2*Pi*fhigh);
  c=Ts/RC;
  a=Ts/(Ts+RC);
  b=RC/(Ts+RC);
  
  if (p) printf("NEW CENT. DIF. F., c=%g\n",c);
  
  /* Priprava vektorjev: */
  out=v;
  in=copyvector0(v,NULL);
  for (i=1;i<=out->d;++i)
    out->v[i]=0;
  cnt=copyvector0(out,NULL);
  
  start=in->d;
   start=20; 
  if (start<2)
    start=2;
  
  /* Obicajni low pass filter do start: */
  /* Zacetni pogoj: */
  out->v[1]=in->v[1];
  cnt->v[1]=in->v[1];
  
  if (p)
    printf(" %4s %10s %10s %10s %10s %10s %10s %10s %10s %10s %10s \n",
     "i","Ii-1","Ui","Ui-1","Ii-1-Ui-1","add",
     "Ci","Ci-2","Ii-1-Ci-1","add","Ui-Ci");
  
  for (i=2;i<=start && i<=v->d ;++i)
  {
    out->v[i]=out->v[i-1]+c*(in->v[i-1]-out->v[i-1]);
    cnt->v[i]=cnt->v[i-1]+c*(in->v[i-1]-cnt->v[i-1]);
    
    if (p)
      printf(" %4i %10g %10g %10g %10g %10g %10g %10g %10g %10g %10g \n",
      i,in->v[i-1],out->v[i],out->v[i-1],in->v[i-1]-out->v[i-1],c*(in->v[i-1]-out->v[i-1]),
      cnt->v[i],0.0,0.0,0.0,out->v[i]-cnt->v[i]);
  }
  
  /* Central difference low pass od start+1: */
  
  for (i=start+1;i<=v->d;++i)
  {
    /* Srediscna metoda za resevanje diferencialnih enacb: */
    out->v[i]=out->v[i-2]+2*c*(in->v[i-1]-out->v[i-1]);
    
    if (0)
    {
      /* Runge Kutta 4. reda: */
      double k1,k2,k3,k4;
      k1=c*(in->v[i-1]-out->v[i-1]);
      k2=c*(0.5*(in->v[i-1]+in->v[i])-out->v[i-1]-k1/2);
      k3=c*(0.5*(in->v[i-1]+in->v[i])-out->v[i-1]-k2/2);
      k3=c*(in->v[i]-out->v[i-1]-k3);
      out->v[i]=out->v[i-1]+(k1+2*k2+2*k3+k4)/6;
    }
    
    if (0)
    {
      /* Millnova metoda: */
      out->v[i]=out->v[i-4]+(4*c/3)*
       (2*(in->v[i-3]-out->v[i-3])-(in->v[i-2]-out->v[i-2])+
       2*(in->v[i-1]-out->v[i-1]) );
      out->v[i]=out->v[i-1]+(c/3)*
      ( (in->v[i-2]-out->v[i-2])+4*(in->v[i-1]-out->v[i-1])+
       (in->v[i]-out->v[i]) );
    }
    
    /* Pogojevanje: */
    if (0)
      out->v[i]=out->v[i-1]+c*(in->v[i-1]-out->v[i-1]);
    /* Kontrola: */
    cnt->v[i]=cnt->v[i-1]+c*(in->v[i-1]-cnt->v[i-1]);
    
    if (p)
      printf(" %4i %10g %10g %10g %10g %10g %10g %10g %10g %10g %10g \n",
      i,in->v[i-1],out->v[i],out->v[i-1],in->v[i-1]-out->v[i-1],2*c*(in->v[i-1]-out->v[i-1]),
      cnt->v[i],cnt->v[i-2],in->v[i-1]-cnt->v[i-1],c*(in->v[i-1]-cnt->v[i-1]),
      out->v[i]-cnt->v[i]);
  }
}
dispvector(&in);
dispvector(&cnt);
}

static double amphighdig(double f,double flow,double Ts)
    /* Vrne razmerje med izhodno in vhodno amplitudo visokoprepustnega
    digitalnega filtra s karakterist. spodnjo frekvencno mejo fhigh pri
    frekvenci f in s casom vzorcenja (smpling time) Ts */
{
double c,a1,b1,a2,b2,RC,w,counter;
RC=1/(2*Pi*flow);
c=RC/(Ts+RC);
w=2*Pi*f;
a1=1-cos(w*Ts);
b1=sin(w*Ts);
a2=1-c*cos(w*Ts);
b2=c*sin(w*Ts);
counter=a2*a2+b2*b2;
return c*sqrt( sqr( (a1*a2+b1*b2)/counter ) + sqr( (a2*b1-a1*b2)/counter ) );
}




static void filthighdig(vector v,double flow,double Ts)
    /* Filtrira vzorcen signal, ki je v vektorju v, z visokoprepustnim filtrom
    s karakteristicno frekvenco flow. Ts je vzorcni cas.
    $A Igor jan01; */
{
double c,RC,Uiprev,Uo,a0,a1,b1;
int i;
RC=1/(2*Pi*flow);
c=RC/(Ts+RC);
a0=c; a1=-c; b1=c;
if (v!=NULL)
{
  Uiprev=v->v[1];
  for (i=2;i<=v->d;++i)
  {
    Uo=a0*v->v[i]    /* i. vhodna vrednost */
     +a1*Uiprev      /* (i-1). vhodna vrednost */
     +b1*v->v[i-1];  /* (i-1). izhodna vrednost */
    Uiprev=v->v[i];
    v->v[i]=Uo;
  }
}
}

static void filthighdigcor(vector v,double flow,double Ts,
    double corf,double cora0,double cora1,double corb1)
    /* Filtrira vzorcen signal, ki je v vektorju v, z visokoprepustnim filtrom
    s karakteristicno frekvenco flow. Ts je vzorcni cas. corf, cora0, cora1
    in corb so relativni popravki za karakteristicno frekvenco, faktor a0,
    faktor a1 in faktor b1.
    $A Igor jan01; */
{
double c,RC,Uiprev,Uo,a0,a1,b1;
int i;
flow*=(1+corf);
RC=1/(2*Pi*flow);
c=RC/(Ts+RC);
a0=c; a1=-c; b1=c;
a0*=(1+cora0);  a1*=(1+cora1);  b1*=(1+corb1);
if (v!=NULL)
{
  Uiprev=v->v[1];
  for (i=2;i<=v->d;++i)
  {
    Uo=a0*v->v[i]    /* i. vhodna vrednost */
     +a1*Uiprev      /* (i-1). vhodna vrednost */
     +b1*v->v[i-1];  /* (i-1). izhodna vrednost */
    Uiprev=v->v[i];
    v->v[i]=Uo;
  }
}
}

static void filthighdigcor1(vector v,double flow,double Ts,
    double corf,double cora0,double cora1,double corb1)
    /* Filtrira vzorcen signal, ki je v vektorju v, z visokoprepustnim filtrom
    s karakteristicno frekvenco flow. Ts je vzorcni cas. corf, cora0, cora1
    in corb so relativni popravki za karakteristicno frekvenco, faktor a0,
    faktor a1 in faktor b1.
    $A Igor jan01; */
{
double c,RC,Uiprev,Uo,a0,a1,b1;
int i;
flow*=(1+corf);
RC=1/(2*Pi*flow);
c=RC/(Ts+RC);
a0=c; a1=-c; b1=c;
a0*=(1+cora0);  a1*=(1+cora1);  b1*=(1+corb1);
filtgendig5(v,a0,a1,0,0,0,0,b1,0,0,0,0);
}



static void filtresdigcorfalse(vector v,double f0,double hr,double Ts,
    double corf0,double corhr,double cora0,double cora1,double cora2,
    double corb1,double corb2)
    /* Filtrira vzorcen signal, ki je v vektorju v, z resonancnim filtrom
    z osrednjo frekvenco f0 in relativno sirino hr. Ts je vzorcni cas. corf,
    corhr, cora0, cora1, cora2, corb1 in corb2 so relativni popravki za
    osrednjo frekvenco, relativno sirino in faktorje a0, a1, a2, b1 in b2.
    $A Igor mar01; */
{
double beta,w0,a0,a1,a2,b1,b2,Ui1,Ui2,Uo1,Uo2,Uo;
int i;
f0*=(1+corf0);
hr*=(1+corhr);
w0=2*ConstPi*f0;
beta=0.5*hr*w0;
a0=1/(1+beta*Ts);
a1=-1/(1+beta*Ts);
a2=1/(1+beta*Ts);
b1=(2-sqr(w0)*sqr(Ts))/(1+beta*Ts);
b2=(beta*Ts-1)/(1+beta*Ts);
a0*=(1+cora0); a1*=(1+cora1); a2*=(1+cora2); b1*=(1+corb1); b2*=(1+corb2); 
if (v!=NULL) if (v->d>2)
{
  /* V filter dodamo slabljenje, ker bi sicer imeli preveliko ojacanje: */
  for (i=1;i<=v->d;++i)
    v->v[i]*=0.01;
  Ui2=Uo2=v->v[1];  /* prejsnji vhodni vzorec */
  Ui1=Uo1=v->v[2];  /* predprejsnji vhodni vzirec */
  for (i=3;i<=v->d;++i)
  {
    Uo=a0*v->v[i]+a1*Ui1+a2*Ui2+b1*Uo1+b2*Uo2;
    Ui2=Ui1; Ui1=v->v[i];
    Uo2=Uo1; Uo1=Uo;
    v->v[i]=Uo;
  }
}
}

static void filtresdigcorfalse2(vector v1,double f0,double hr,double Ts,
    double corf0,double corhr,double cora0,double cora1,double cora2,
    double corb1,double corb2)
    /* Filtrira vzorcen signal, ki je v vektorju v, z resonancnim filtrom
    z osrednjo frekvenco f0 in relativno sirino hr. Ts je vzorcni cas. corf,
    corhr, cora0, cora1, cora2, corb1 in corb2 so relativni popravki za
    osrednjo frekvenco, relativno sirino in faktorje a0, a1, a2, b1 in b2.
    OPOMBA: Ta funkcija PODVOJI HITROST VZORCENJA tako, da linearno interpolira
    en vmesni vzorec.
    $A Igor mar01; */
{
double beta,w0,a0,a1,a2,b1,b2,Ui1,Ui2,Uo1,Uo2,Uo;
int i;
vector v=NULL;
Ts/=2;
v=getvector(2*v1->d-1);
for (i=1;i<=v1->d;++i)
{
  v->v[2*i-1]=v1->v[i];
  if (i<v1->d)
  {
    /* Interpolirani vmesni vzorec: */
    v->v[2*i]=v1->v[i]+0.5*(v1->v[i+1]-v1->v[i]);
  }
}
f0*=(1+corf0);
hr*=(1+corhr);
w0=2*ConstPi*f0;
beta=0.5*hr*w0;
a0=1/(1+beta*Ts);
a1=-1/(1+beta*Ts);
a2=1/(1+beta*Ts);
b1=(2-sqr(w0)*sqr(Ts))/(1+beta*Ts);
b2=(beta*Ts-1)/(1+beta*Ts);
a0*=(1+cora0); a1*=(1+cora1); a2*=(1+cora2); b1*=(1+corb1); b2*=(1+corb2); 
if (v!=NULL) if (v->d>2)
{
  /* V filter dodamo slabljenje, ker bi sicer imeli preveliko ojacanje: */
  for (i=1;i<=v->d;++i)
    v->v[i]*=0.01;
  Ui2=Uo2=v->v[1];  /* prejsnji vhodni vzorec */
  Ui1=Uo1=v->v[2];  /* predprejsnji vhodni vzirec */
  for (i=3;i<=v->d;++i)
  {
    Uo=a0*v->v[i]+a1*Ui1+a2*Ui2+b1*Uo1+b2*Uo2;
    Ui2=Ui1; Ui1=v->v[i];
    Uo2=Uo1; Uo1=Uo;
    v->v[i]=Uo;
  }
}
for (i=1;i<=v1->d;++i)
  v1->v[i]=v->v[2*i-1];
dispvector(&v);
}


static void filtresdigcorfalse4(vector v1,double f0,double hr,double Ts,
    double corf0,double corhr,double cora0,double cora1,double cora2,
    double corb1,double corb2)
    /* Filtrira vzorcen signal, ki je v vektorju v, z resonancnim filtrom
    z osrednjo frekvenco f0 in relativno sirino hr. Ts je vzorcni cas. corf,
    corhr, cora0, cora1, cora2, corb1 in corb2 so relativni popravki za
    osrednjo frekvenco, relativno sirino in faktorje a0, a1, a2, b1 in b2.
    OPOMBA: Ta funkcija POCETVERI HITROST VZORCENJA tako, da linearno
    interpolira tri vmesne vzorce.
    $A Igor mar01; */
{
double beta,w0,a0,a1,a2,b1,b2,Ui1,Ui2,Uo1,Uo2,Uo;
int i;
vector v=NULL;
Ts/=4;
v=getvector(4*v1->d-3);
for (i=1;i<=v1->d;++i)
{
  v->v[4*i-3]=v1->v[i];
  if (i<v1->d)
  {
    /* Interpolirani vmesni vzorci: */
    v->v[4*i-2]=v1->v[i]+0.25*(v1->v[i+1]-v1->v[i]);
    v->v[4*i-1]=v1->v[i]+0.5*(v1->v[i+1]-v1->v[i]);
    v->v[4*i-0]=v1->v[i]+0.75*(v1->v[i+1]-v1->v[i]);
  }
}
f0*=(1+corf0);
hr*=(1+corhr);
w0=2*ConstPi*f0;
beta=0.5*hr*w0;
a0=1/(1+beta*Ts);
a1=-1/(1+beta*Ts);
a2=1/(1+beta*Ts);
b1=(2-sqr(w0)*sqr(Ts))/(1+beta*Ts);
b2=(beta*Ts-1)/(1+beta*Ts);
a0*=(1+cora0); a1*=(1+cora1); a2*=(1+cora2); b1*=(1+corb1); b2*=(1+corb2); 
if (v!=NULL) if (v->d>2)
{
  /* V filter dodamo slabljenje, ker bi sicer imeli preveliko ojacanje: */
  for (i=1;i<=v->d;++i)
    v->v[i]*=0.01;
  Ui2=Uo2=v->v[1];  /* prejsnji vhodni vzorec */
  Ui1=Uo1=v->v[2];  /* predprejsnji vhodni vzirec */
  for (i=3;i<=v->d;++i)
  {
    Uo=a0*v->v[i]+a1*Ui1+a2*Ui2+b1*Uo1+b2*Uo2;
    Ui2=Ui1; Ui1=v->v[i];
    Uo2=Uo1; Uo1=Uo;
    v->v[i]=Uo;
  }
}
for (i=1;i<=v1->d;++i)
  v1->v[i]=v->v[4*i-3];
dispvector(&v);
}


static void filtresmirdigcorbd(vector v,double f0,double hr,double Ts,
    double corf0,double corhr,double cora0,double cora1,double cora2,
    double corb1,double corb2)
    /* Zrcalni resonancni filter dobljen s "backward difference" aproksimacijo
    odvodov:
    Filtrira vzorcen signal, ki je v vektorju v, z zrcalnim resonancnim filtrom
    z osrednjo frekvenco f0 in relativno sirino hr. Ts je vzorcni cas. corf,
    corhr, cora0, cora1, cora2, corb1 in corb2 so relativni popravki za
    osrednjo frekvenco, relativno sirino in faktorje a0, a1, a2, b1 in b2.
    $A Igor mar01; */
{
double beta,w0,a0,a1,a2,b1,b2,Ui1,Ui2,Uo1,Uo2,Uo;
int i;
f0*=(1+corf0);
hr*=(1+corhr);
w0=2*ConstPi*f0;
beta=0.5*hr*w0;
a0=1/(1+beta*Ts+sqr(w0*Ts));
a1=-2/(1+beta*Ts+sqr(w0*Ts));
a2=1/(1+beta*Ts+sqr(w0*Ts));
b1=(2)/(1+beta*Ts+sqr(w0*Ts));
b2=(beta*Ts-1)/(1+beta*Ts+sqr(w0*Ts));
a0*=(1+cora0); a1*=(1+cora1); a2*=(1+cora2); b1*=(1+corb1); b2*=(1+corb2); 
if (v!=NULL) if (v->d>2)
{
  /* V filter dodamo slabljenje, ker bi sicer imeli preveliko ojacanje: */
  /*
  for (i=1;i<=v->d;++i)
    v->v[i]*=0.01;
  */
  Ui2=Uo2=v->v[1];  /* prejsnji vhodni vzorec */
  Ui1=Uo1=v->v[2];  /* predprejsnji vhodni vzirec */
  for (i=3;i<=v->d;++i)
  {
    Uo=a0*v->v[i]+a1*Ui1+a2*Ui2+b1*Uo1+b2*Uo2;
    Ui2=Ui1; Ui1=v->v[i];
    Uo2=Uo1; Uo1=Uo;
    v->v[i]=Uo;
  }
}
}



static void filtresmirdigcor(vector v,double f0,double hr,double Ts,
    double corf0,double corhr,double cora0,double cora1,double cora2,
    double corb1,double corb2)
    /* Filtrira vzorcen signal, ki je v vektorju v, z zrcalnim resonancnim filtrom
    z osrednjo frekvenco f0 in relativno sirino hr. Ts je vzorcni cas. corf,
    corhr, cora0, cora1, cora2, corb1 in corb2 so relativni popravki za
    osrednjo frekvenco, relativno sirino in faktorje a0, a1, a2, b1 in b2.
    $A Igor mar01; */
{
double beta,w0,a0,a1,a2,b1,b2,Ui1,Ui2,Uo1,Uo2,Uo;
int i;
f0*=(1+corf0);
hr*=(1+corhr);
w0=2*ConstPi*f0;
beta=0.5*hr*w0;
a0=1/(1+beta*Ts);
a1=-2/(1+beta*Ts);
a2=1/(1+beta*Ts);
b1=(2-sqr(w0*Ts))/(1+beta*Ts);
b2=(beta*Ts-1)/(1+beta*Ts);
a0*=(1+cora0); a1*=(1+cora1); a2*=(1+cora2); b1*=(1+corb1); b2*=(1+corb2); 
if (v!=NULL) if (v->d>2)
{
  /* V filter dodamo slabljenje, ker bi sicer imeli preveliko ojacanje: */
  /*
  for (i=1;i<=v->d;++i)
    v->v[i]*=0.01;
  */
  Ui2=Uo2=v->v[1];  /* prejsnji vhodni vzorec */
  Ui1=Uo1=v->v[2];  /* predprejsnji vhodni vzirec */
  for (i=3;i<=v->d;++i)
  {
    Uo=a0*v->v[i]+a1*Ui1+a2*Ui2+b1*Uo1+b2*Uo2;
    Ui2=Ui1; Ui1=v->v[i];
    Uo2=Uo1; Uo1=Uo;
    v->v[i]=Uo;
  }
}
}





static void filtresdigcorbd(vector v,double f0,double hr,double Ts,
    double corf0,double corhr,double cora0,double cora1,double cora2,
    double corb1,double corb2)
    /* Resonancni filter dobljen s "backward difference" aproksimacijo
    odvodov:
    Filtrira vzorcen signal, ki je v vektorju v, z resonancnim filtrom
    z osrednjo frekvenco f0 in relativno sirino hr. Ts je vzorcni cas. corf,
    corhr, cora0, cora1, cora2, corb1 in corb2 so relativni popravki za
    osrednjo frekvenco, relativno sirino in faktorje a0, a1, a2, b1 in b2.
    $A Igor mar01; */
{
double beta,w0,a0,a1,a2,b1,b2,Ui1,Ui2,Uo1,Uo2,Uo;
int i;
f0*=(1+corf0);
hr*=(1+corhr);
w0=2*ConstPi*f0;
beta=0.5*hr*w0;
a0=sqr(w0*Ts)/(1+beta*Ts+sqr(w0*Ts));
a1=0;
a2=0;
b1=(2)/(1+beta*Ts+sqr(w0*Ts));
b2=(beta*Ts-1)/(1+beta*Ts+sqr(w0*Ts));
a0*=(1+cora0); a1*=(1+cora1); a2*=(1+cora2); b1*=(1+corb1); b2*=(1+corb2); 
if (v!=NULL) if (v->d>2)
{
  /* V filter dodamo slabljenje, ker bi sicer imeli preveliko ojacanje: */
  /*
  for (i=1;i<=v->d;++i)
    v->v[i]*=0.01;
  */
  Ui2=Uo2=v->v[1];  /* prejsnji vhodni vzorec */
  Ui1=Uo1=v->v[2];  /* predprejsnji vhodni vzirec */
  for (i=3;i<=v->d;++i)
  {
    Uo=a0*v->v[i]+a1*Ui1+a2*Ui2+b1*Uo1+b2*Uo2;
    Ui2=Ui1; Ui1=v->v[i];
    Uo2=Uo1; Uo1=Uo;
    v->v[i]=Uo;
  }
}
}



static void filtresdigcor(vector v,double f0,double hr,double Ts,
    double corf0,double corhr,double cora0,double cora1,double cora2,
    double corb1,double corb2)
    /* Filtrira vzorcen signal, ki je v vektorju v, z resonancnim filtrom
    z osrednjo frekvenco f0 in relativno sirino hr. Ts je vzorcni cas. corf,
    corhr, cora0, cora1, cora2, corb1 in corb2 so relativni popravki za
    osrednjo frekvenco, relativno sirino in faktorje a0, a1, a2, b1 in b2.
    $A Igor mar01; */
{
double beta,w0,a0,a1,a2,b1,b2,Ui1,Ui2,Uo1,Uo2,Uo;
int i;
f0*=(1+corf0);
hr*=(1+corhr);
w0=2*ConstPi*f0;
beta=0.5*hr*w0;
a0=0;
a1=sqr(w0*Ts)/(1+beta*Ts);
a2=0;
b1=(2-sqr(w0*Ts))/(1+beta*Ts);
b2=(beta*Ts-1)/(1+beta*Ts);
a0*=(1+cora0); a1*=(1+cora1); a2*=(1+cora2); b1*=(1+corb1); b2*=(1+corb2); 
if (v!=NULL) if (v->d>2)
{
  /* V filter dodamo slabljenje, ker bi sicer imeli preveliko ojacanje: */
  /*
  for (i=1;i<=v->d;++i)
    v->v[i]*=0.01;
  */
  Ui2=Uo2=v->v[1];  /* prejsnji vhodni vzorec */
  Ui1=Uo1=v->v[2];  /* predprejsnji vhodni vzirec */
  for (i=3;i<=v->d;++i)
  {
    Uo=a0*v->v[i]+a1*Ui1+a2*Ui2+b1*Uo1+b2*Uo2;
    Ui2=Ui1; Ui1=v->v[i];
    Uo2=Uo1; Uo1=Uo;
    v->v[i]=Uo;
  }
}
}



filtresmirdig(vector v,double f0,double hr,double Ts)
    /* Filtrira vzorcen signal, ki je v vektorju v, z resonancnim filtrom
    z osrednjo frekvenco f0 in relativno sirino hr. Ts je vzorcni cas. corf,
    corhr, cora0, cora1, cora2, corb1 in corb2 so relativni popravki za
    osrednjo frekvenco, relativno sirino in faktorje a0, a1, a2, b1 in b2.
    $A Igor mar01; */
{
filtresmirdigcor(v,f0,hr,Ts,0,0,0,0,0,0,0);
}



filtresdig(vector v,double f0,double hr,double Ts)
    /* Filtrira vzorcen signal, ki je v vektorju v, z resonancnim filtrom
    z osrednjo frekvenco f0 in relativno sirino hr. Ts je vzorcni cas. corf,
    corhr, cora0, cora1, cora2, corb1 in corb2 so relativni popravki za
    osrednjo frekvenco, relativno sirino in faktorje a0, a1, a2, b1 in b2.
    $A Igor mar01; */
{
filtresdigcor(v,f0,hr,Ts,0,0,0,0,0,0,0);
}



static void filtrescombdig(vector v,double mirf0,double mirhr,double
            resf0,double reshr,double Ts)
    /* KOMBINIRAN resonancni in zrcalno resonancni filter (dobljen s
    sestevanjem diferencnih enacb; odvodi po centralnih diferencah)
    Filtrira vzorcen signal, ki je v vektorju v, s kombiniranim resonancnim
    filtrom; resf0 in reshr sta centralna frekvenca in relativna sirina
    resonancnega filtra, mirf0 in mirhr pa centralna frekvenca in relativna
    sirina zrcalno resonancnega filtra. */
{
double beta,w0,a0,a1,a2,b1,b2,Ui1,Ui2,Uo1,Uo2,Uo;
int i;
/* Koeficienti za resonancen filter: */
w0=2*ConstPi*resf0;
beta=0.5*reshr*w0;
a0=0;
a1=sqr(w0*Ts)/(1+beta*Ts);
a2=0;
b1=(2-sqr(w0*Ts))/(1+beta*Ts);
b2=(beta*Ts-1)/(1+beta*Ts);
/* Dodajo se koeficienti za zrcalno resonancen filter: */
w0=2*ConstPi*mirf0;
beta=0.5*mirhr*w0;
a0+=1/(1+beta*Ts);
a1+=-2/(1+beta*Ts);
a2+=1/(1+beta*Ts);
b1+=(2-sqr(w0*Ts))/(1+beta*Ts);
b2+=(beta*Ts-1)/(1+beta*Ts);
/* Vsi koef. se delijo z 2: */
a0/=2.0;
a1/=2.0;
a2/=2.0;
b1/=2.0;
b2/=2.0;
if (v!=NULL) if (v->d>2)
{
  /* V filter dodamo slabljenje, ker bi sicer imeli preveliko ojacanje: */
  /*
  for (i=1;i<=v->d;++i)
    v->v[i]*=0.01;
  */
  Ui2=Uo2=v->v[1];  /* prejsnji vhodni vzorec */
  Ui1=Uo1=v->v[2];  /* predprejsnji vhodni vzirec */
  for (i=3;i<=v->d;++i)
  {
    Uo=a0*v->v[i]+a1*Ui1+a2*Ui2+b1*Uo1+b2*Uo2;
    Ui2=Ui1; Ui1=v->v[i];
    Uo2=Uo1; Uo1=Uo;
    v->v[i]=Uo;
  }
}
}





static void filthighdigold(vector v,double flow,double Ts)
    /* Filtrira vzorcen signal, ki je v vektorju v, z visokoprepustnim filtrom
    s karakteristicno frekvenco flow. Ts je vzorcni cas.
    $A Igor jan01; */
{
double c,RC,Uiprev,Uo;
int i;
RC=1/(2*Pi*flow);
c=RC/(Ts+RC);
if (v!=NULL)
{
  Uiprev=v->v[1];
  for (i=2;i<=v->d;++i)
  {
    Uo=c*(v->v[i]-Uiprev+v->v[i-1]);
    Uiprev=v->v[i];
    v->v[i]=Uo;
  }
}
}



/* FUNKCIJE ZA DIGITALNE FILTRE, KI UPORABLJAJO STATICNE PODATKE: */

static void filtlowdig0(vector v)
    /* Nizkofrekvencni filter, karakterist. frekvenca fhigh in vzorcni cas
    Ts (obe staticni spremenljivki!!!). Sfiltrira vzorec, ki je v vektorju v
    in spravi rezultat v isti vektor. */
{
filtlowdig(v,fhigh,Ts);
}

static void filtlowdigcent0(vector v)
    /* Nizkofrekvencni filter, karakterist. frekvenca fhigh in vzorcni cas
    Ts (obe staticni spremenljivki!!!). Sfiltrira vzorec, ki je v vektorju v
    in spravi rezultat v isti vektor. Filter uporablja formulo, kjer se odvodi
    racunajo po centralnih diferencah. */
{
filtlowdigcent(v,fhigh,Ts);
}

static void filthighdig0(vector v)
    /* Visokoprepustni filter, karakterist. frekvenca flow in vzorcni cas
    Ts (obe staticni spremenljivki!!!). Sfiltrira vzorec, ki je v vektorju v
    in spravi rezultat v isti vektor. */
{
filthighdig(v,flow,Ts);
}

static void filtresdig0(vector v)
    /* Resonancni filter, karakterist. frekvenca fres, rel. sirina hres in
    vzorcni cas Ts (vse staticne spremenljivke!!!). Sfiltrira vzorec, ki je v
    vektorju v in spravi rezultat v isti vektor. */
{
filtresdig(v,fres,hres,Ts);
}

static void filtresmirdig0(vector v)
    /* Resonancni zrcalni filter, karakterist. frekvenca fres, rel. sirina hres in
    vzorcni cas Ts (vse staticne spremenljivke!!!). Sfiltrira vzorec, ki je v
    vektorju v in spravi rezultat v isti vektor. */
{
filtresmirdig(v,fres,hres,Ts);
}



/* DIGITALNI FILTRI ZA UTEZEVANJE: */

/* Korekcije: */

static double corl1f=0,corl1a0=0,corl1b1=0,      /* low pass 1 */
              corl2f=0,corl2a0=0,corl2b1=0,     /* low pass 2 */
              corh3f=0,corh3a0=0,corh3a1=0,corh3b1=0, /* high pass 3 */
              corh4f=0,corh4a0=0,corh4a1=0,corh4b1=0, /* high pass 4 */
              corh5f=0,corh5a0=0,corh5a1=0,corh5b1=0, /* high pass 5 */
              corh6f=0,corh6a0=0,corh6a1=0,corh6b1=0, /* high pass 6 */
              corh7f=0,corh7a0=0,corh7a1=0,corh7b1=0; /* high pass 7 */
/* Konstantna korekcija amplitude: */
static double corAdig=1,corBdig=1,corCdig=1;

/* Korekcije dodatnih filtrov: */
static double corl3f=0,corl3a0=0,corl3b1=0,       /* low pass 3 */
              corl4f=0,corl4a0=0,corl4b1=0,       /* low pass 4 */
              corl5f=0,corl5a0=0,corl5b1=0,     /* low pass 5 */
              corl6f=0,corl6a0=0,corl6b1=0,     /* low pass 6 */
              corl7f=0,corl7a0=0,corl7b1=0,       /* low pass 7 */
              corl8f=0,corl8a0=0,corl8b1=0,       /* low pass 8 */
              corl9f=0,corl9a0=0,corl9b1=0,       /* low pass 9 */
              corl10f=0,corl10a0=0,corl10b1=0,       /* low pass 10 */
              corh1f=0,corh1a0=0,corh1a1=0,corh1b1=0, /* high pass 1 */
              corh2f=0,corh2a0=0,corh2a1=0,corh2b1=0, /* high pass 2 */
              corh8f=0,corh8a0=0,corh8a1=0,corh8b1=0, /* high pass 8 */
              corh9f=0,corh9a0=0,corh9a1=0,corh9b1=0, /* high pass 9 */
              corh10f=0,corh10a0=0,corh10a1=0,corh10b1=0; /* high pass 10 */

/* Redi clenov v pasovnem filtru: */

static double ord1=2,ord2=2,ord3=2,ord4=2,ord5=2,ord6=2,ord7=2,ord8=2,ord9=2,
              ord10=2;

static void setoptweightcor(void)
    /* Postavi korekcijske faktorje tako, da so optimalni za utezevalne filtre
    pri frekvenci sempliranja 10^5/s. */
{
corl1f=0.308381;
corl2f=0.421121;
corh3f=-0.0313729;
corh4f=0.0498406;
corh5f=0.0107605;
corh6f=0.00377726;
corh7f=0.0223711;
corCdig=1.00915;
corBdig=1.02703;
corAdig=1.29495;
}

static void setoptweightcor48(void)
    /* Postavi korekcijske faktorje tako, da so optimalni za utezevalne filtre
    pri frekvenci sempliranja 48000/s. */
{
corl1f=0.70186012;
corl2f=0.3080125;
corh3f=-0.066932889;
corh4f=0.17758009;
corh5f=0.025312964;
corh6f=-0.062682515;
corh7f=0.053132337;
corCdig=1.01372;  /* = 0.118355 dB */
corBdig=1.03763;  /* = 0.320819 dB */
corAdig=1.33966;  /* = 2.53991 dB */
}


static void setzeroweightcor(void)
    /* Postavi korekcijske faktorje tako, da so optimalni za utezevalne filtre
    pri frekvenci sempliranja 10^5/s. */
{
corl1f=0;
corl2f=0;
corh3f=0;
corh4f=0;
corh5f=0;
corh6f=0;
corh7f=0;
corCdig=1;
corBdig=1;
corAdig=1;
}

static void fprintdigcor(FILE *fp)
{
/* Izpis korekturnih faktorjev: */
fprintf(fp,"\nCurrent correction data for digital weighting filters:\n");
fprintf(fp,"Ts=%g, fhigh1=%g, fhigh2=%g, flow3=%g, flow4=%g,\nflow5=%g, flow6=%g, flow7=%g.\n",
 Ts,fhigh1, fhigh2, flow3, flow4, flow5, flow6, flow7); 
fprintf(fp,"Low pass 1: corf=%g, cora0=%g, corb1=%g\n",
  corl1f,corl1a0,corl1b1);
fprintf(fp,"Low pass 2: corf=%g, cora0=%g, corb1=%g\n",
  corl2f,corl2a0,corl2b1);
fprintf(fp,"Low pass 3: corf=%g, cora0=%g, corb1=%g\n",
  corl3f,corl3a0,corl3b1);
fprintf(fp,"Low pass 4: corf=%g, cora0=%g, corb1=%g\n",
  corl4f,corl4a0,corl4b1);
fprintf(fp,"High pass 1: corf=%g, cora0=%g, cora1=%g, corb1=%g\n",
  corh1f,corh1a0,corh1a1,corh1b1);
fprintf(fp,"High pass 2: corf=%g, cora0=%g, cora1=%g, corb1=%g\n",
  corh2f,corh2a0,corh2a1,corh2b1);
fprintf(fp,"High pass 3: corf=%g, cora0=%g, cora1=%g, corb1=%g\n",
  corh3f,corh3a0,corh3a1,corh3b1);
fprintf(fp,"High pass 4: corf=%g, cora0=%g, cora1=%g, corb1=%g\n",
  corh4f,corh4a0,corh4a1,corh4b1);
fprintf(fp,"High pass 5: corf=%g, cora0=%g, cora1=%g, corb1=%g\n",
  corh5f,corh5a0,corh5a1,corh5b1);
fprintf(fp,"High pass 6: corf=%g, cora0=%g, cora1=%g, corb1=%g\n",
  corh6f,corh6a0,corh6a1,corh6b1);
fprintf(fp,"High pass 7: corf=%g, cora0=%g, cora1=%g, corb1=%g\n",
  corh7f,corh7a0,corh7a1,corh7b1);
fprintf(fp,"\n");
}

static void readdigcor(void)
{
static double l1=0,l2=0,l3=0,l4=0,h1=0,h2=0,h3=0,h4=0,h5=0,h6=0,h7=0;
fprintdigcor(stdout);
printf("Adjust low pass 1 (0/1)? "); readdouble(&l1);
if (l1)
{
  printf("    corl1f:  "); readdouble(&corl1f);
  printf("    corl1a0: "); readdouble(&corl1a0);
  printf("    corl1b1: "); readdouble(&corl1b1);
}
printf("Adjust low pass 2 (0/1)? "); readdouble(&l2);
if (l2)
{
  printf("    corl2f:  "); readdouble(&corl2f);
  printf("    corl2a0: "); readdouble(&corl2a0);
  printf("    corl2b1: "); readdouble(&corl2b1);
}
printf("Adjust low pass 3 (0/1)? "); readdouble(&l3);
if (l3)
{
  printf("    corl3f:  "); readdouble(&corl3f);
  printf("    corl3a0: "); readdouble(&corl3a0);
  printf("    corl3b1: "); readdouble(&corl3b1);
}
printf("Adjust low pass 4 (0/1)? "); readdouble(&l4);
if (l4)
{
  printf("    corl4f:  "); readdouble(&corl4f);
  printf("    corl4a0: "); readdouble(&corl4a0);
  printf("    corl4b1: "); readdouble(&corl4b1);
}

printf("Adjust high pass 1 (0/1)? "); readdouble(&h1);
if (h1)
{
  printf("    corh1f:  "); readdouble(&corh1f);
  printf("    corh1a0: "); readdouble(&corh1a0);
  printf("    corh1a1: "); readdouble(&corh1a1);
  printf("    corh1b1: "); readdouble(&corh1b1);
}
printf("Adjust high pass 2 (0/1)? "); readdouble(&h2);
if (h2)
{
  printf("    corh2f:  "); readdouble(&corh2f);
  printf("    corh2a0: "); readdouble(&corh2a0);
  printf("    corh2a1: "); readdouble(&corh2a1);
  printf("    corh2b1: "); readdouble(&corh2b1);
}
printf("Adjust high pass 3 (0/1)? "); readdouble(&h3);
if (h3)
{
  printf("    corh3f:  "); readdouble(&corh3f);
  printf("    corh3a0: "); readdouble(&corh3a0);
  printf("    corh3a1: "); readdouble(&corh3a1);
  printf("    corh3b1: "); readdouble(&corh3b1);
}
printf("Adjust high pass 4 (0/1)? "); readdouble(&h4);
if (h4)
{
  printf("    corh4f:  "); readdouble(&corh4f);
  printf("    corh4a0: "); readdouble(&corh4a0);
  printf("    corh4a1: "); readdouble(&corh4a1);
  printf("    corh4b1: "); readdouble(&corh4b1);
}
printf("Adjust high pass 5 (0/1)? "); readdouble(&h5);
if (h5)
{
  printf("    corh5f:  "); readdouble(&corh5f);
  printf("    corh5a0: "); readdouble(&corh5a0);
  printf("    corh5a1: "); readdouble(&corh5a1);
  printf("    corh5b1: "); readdouble(&corh5b1);
}
printf("Adjust high pass 6 (0/1)? "); readdouble(&h6);
if (h6)
{
  printf("    corh6f:  "); readdouble(&corh6f);
  printf("    corh6a0: "); readdouble(&corh6a0);
  printf("    corh6a1: "); readdouble(&corh6a1);
  printf("    corh6b1: "); readdouble(&corh6b1);
}
printf("Adjust high pass 7 (0/1)? "); readdouble(&h7);
if (h7)
{
  printf("    corh7f:  "); readdouble(&corh7f);
  printf("    corh7a0: "); readdouble(&corh7a0);
  printf("    corh7a1: "); readdouble(&corh7a1);
  printf("    corh7b1: "); readdouble(&corh7b1);
}
printf("\n\n");
}


static void setoptaliaspar_40_80()
    /* Nastavi optimalne parametre utezevalnih filtrov za primer, ko imamo
    antialiasni filter iz low pass filtra pri 40 kHz in low pass filtra pri
    80 kHz. */
{
setoptweightcor();
corl1f+= 0.1390767 ;
corl2f+= 0.17767954 ;
corh3f+= 0.050619013;
corh4f+= -0.0674372 ;
}


static void setoptsmoothpar15_11(void)
    /* Postavi 15 optimalnih faktorjev glajenja za primer, ko imamo 11 bitno
    predstavitev podatkov. Parametri glajenja so za zadnjo funkcijo glajenja,
    prvi je faktor ojacanja, nato imamo 5 parametrov glajenja po 1. metodi,
    3 parametre glajenja po 2. metodi in 2 popravka frekvence (za low pass
    filtra). */
{
sm1=sm2=sm3=sm4=sm5=sm6=sm7=sm8=sm9=sm10=0;
smfac= 0.176 ;
sm0= 1 ;
sm1= 0.468083 ;
sm2= 1.03061 ;
sm3= 0.13549 ;
sm4= 0.191356 ;
sm5= -0.455425 ;
sm6= 0.593386 ;
sm7= 0.503326 ;
sm8= 1.32264 ;
sm9= 0.0127942 ;
sm10= -0.0157227 ;
corl1f=0.308381+ 0.12773064 ;
corl2f=0.421121+ 0.16430692 ;
corh3f=-0.0313729+ 0.040728358 ;
corh4f=0.0498406+ 0.043000601 ;
}

static void setoptsmoothpar15_10(void)
    /* Postavi 15 optimalnih faktorjev glajenja za primer, ko imamo 10 bitno
    predstavitev podatkov. Parametri glajenja so za zadnjo funkcijo glajenja,
    prvi je faktor ojacanja, nato imamo 5 parametrov glajenja po 1. metodi,
    3 parametre glajenja po 2. metodi in 2 popravka frekvence (za low pass
    filtra). */
{
sm1=sm2=sm3=sm4=sm5=sm6=sm7=sm8=sm9=sm10=0;
smfac= 0.552596 ;
sm0= 1 ;
sm1= 0.364923 ;
sm2= 0.929885 ;
sm3= 0.10754 ;
sm4= 0.111817 ;
sm5= -0.348089 ;
sm6= 0.641554 ;
sm7= 0.304872 ;
sm8= 1.2093 ;
sm9= -0.113139 ;
sm10= 0.117206 ;
corl1f=0.308381+ 0.083774901 ;
corl2f=0.421121+ -0.15911668 ;
corh3f=-0.0313729+ 0.23410037 ;
corh4f=0.0498406+ 0.18429066 ;
}

static void setoptsmoothpar15_9(void)
    /* Postavi 15 optimalnih faktorjev glajenja za primer, ko imamo 9 bitno
    predstavitev podatkov. Parametri glajenja so za zadnjo funkcijo glajenja,
    prvi je faktor ojacanja, nato imamo 5 parametrov glajenja po 1. metodi,
    3 parametre glajenja po 2. metodi in 2 popravka frekvence (za low pass
    filtra). */
{
sm1=sm2=sm3=sm4=sm5=sm6=sm7=sm8=sm9=sm10=0;
smfac= 0.57349 ;
sm0= 1 ;
sm1= -0.0753649 ;
sm2= 0.823142 ;
sm3= 0.27108 ;
sm4= 0.508386 ;
sm5= -0.09888 ;
sm6= -0.981172 ;
sm7= 0.495653 ;
sm8= 1.56497 ;
sm9= 0.274826 ;
sm10= 0.211673 ;
corl1f=0.308381+ -0.23160415 ;
corl2f=0.421121+ -0.25683963 ;
corh3f=-0.0313729+ 0.42910768 ;
corh4f=0.0498406+ 0.90659255 ;
}

static void setoptsmoothpar11_12(void)
    /* Postavi 11 optimalnih faktorjev glajenja za primer, ko imamo 12 bitno
    predstavitev podatkov. Parametri glajenja so za zadnjo funkcijo glajenja,
    prvi je faktor ojacanja, nato imamo 5 parametrov glajenja po 1. metodi,
    3 parametre glajenja po 2. metodi in 2 popravka frekvence (za low pass
    filtra). */
{
sm1=sm2=sm3=sm4=sm5=sm6=sm7=sm8=sm9=sm10=0;
smfac= -0.342767 ;
sm0= 1 ;
sm1= 0.500799 ;
sm2= 1.02536 ;
sm3= 0.230529 ;
sm4= -0.0695769 ;
sm5= -0.00634214 ;
sm6= 0.435393 ;
sm7= 0.365259 ;
sm8= 1.31993 ;
sm9= 0 ;
sm10= 0 ;
corl1f=0.308381+ 0.088427853 ;
corl2f=0.421121+ 0.1142135 ;
}

static void setoptsmoothpar11_11(void)
    /* Postavi 11 optimalnih faktorjev glajenja za primer, ko imamo 11 bitno
    predstavitev podatkov. Parametri glajenja so za zadnjo funkcijo glajenja,
    prvi je faktor ojacanja, nato imamo 5 parametrov glajenja po 1. metodi,
    3 parametre glajenja po 2. metodi in 2 popravka frekvence (za low pass
    filtra). */
{
sm1=sm2=sm3=sm4=sm5=sm6=sm7=sm8=sm9=sm10=0;
smfac= 0.151441 ;
sm0= 1 ;
sm1= 0.452631 ;
sm2= 0.972314 ;
sm3= 0.152012 ;
sm4= 0.0218216 ;
sm5= -0.186294 ;
sm6= 0.28245 ;
sm7= 0.403697 ;
sm8= 1.18994 ;
sm9= 0 ;
sm10= 0 ;
corl1f=0.308381+ 0.1807298 ;
corl2f=0.421121+ 0.17574106 ;
}

static void setoptsmoothpar11_10(void)
    /* Postavi 11 optimalnih faktorjev glajenja za primer, ko imamo 10 bitno
    predstavitev podatkov. Parametri glajenja so za zadnjo funkcijo glajenja,
    prvi je faktor ojacanja, nato imamo 5 parametrov glajenja po 1. metodi,
    3 parametre glajenja po 2. metodi in 2 popravka frekvence (za low pass
    filtra). */
{
sm1=sm2=sm3=sm4=sm5=sm6=sm7=sm8=sm9=sm10=0;
smfac= 0.659298 ;
sm0= 1 ;
sm1= 0.296634 ;
sm2= 0.875751 ;
sm3= 0.00129326 ;
sm4= 0.181436 ;
sm5= -0.3118 ;
sm6= 0.437119 ;
sm7= 0.418145 ;
sm8= 1.31501 ;
sm9= 0 ;
sm10= 0 ;
corl1f=0.308381+ 0.024799879 ;
corl2f=0.421121+ 0.03625019 ;
}

static void setoptsmoothpar11_9(void)
    /* Postavi 11 optimalnih faktorjev glajenja za primer, ko imamo 9 bitno
    predstavitev podatkov. Parametri glajenja so za zadnjo funkcijo glajenja,
    prvi je faktor ojacanja, nato imamo 5 parametrov glajenja po 1. metodi,
    3 parametre glajenja po 2. metodi in 2 popravka frekvence (za low pass
    filtra). */
{
sm1=sm2=sm3=sm4=sm5=sm6=sm7=sm8=sm9=sm10=0;
smfac= 0.826537 ;
sm0= 1 ;
sm1= -0.0217988 ;
sm2= 0.668776 ;
sm3= 0.273708 ;
sm4= 0.450476 ;
sm5= -0.144728 ;
sm6= 0.220847 ;
sm7= 0.384455 ;
sm8= 1.50632 ;
sm9= 0 ;
sm10= 0 ;
corl1f=0.308381+ -0.20052626 ;
corl2f=0.421121+ -0.18496127 ;
}

static void setoptsmoothpar11_8(void)
    /* Postavi 11 optimalnih faktorjev glajenja za primer, ko imamo 8 bitno
    predstavitev podatkov. Parametri glajenja so za zadnjo funkcijo glajenja,
    prvi je faktor ojacanja, nato imamo 5 parametrov glajenja po 1. metodi,
    3 parametre glajenja po 2. metodi in 2 popravka frekvence (za low pass
    filtra). */
{
sm1=sm2=sm3=sm4=sm5=sm6=sm7=sm8=sm9=sm10=0;
smfac= 1.21199 ;
sm0= 1 ;
sm1= -0.0935869 ;
sm2= 0.362064 ;
sm3= 0.270621 ;
sm4= 0.644568 ;
sm5= 0.169751 ;
sm6= 0.0345246 ;
sm7= 0.379964 ;
sm8= 1.57879 ;
sm9= 0 ;
sm10= 0 ;
corl1f=0.308381+ -0.26458798 ;
corl2f=0.421121+ -0.46110871 ;
}

static void setoptsmoothpar7_12(void)
    /* Postavi 7 optimalnih faktorjev glajenja za primer, ko imamo 12 bitno
    predstavitev podatkov */
{
sm1=sm2=sm3=sm4=sm5=sm6=sm7=sm8=sm9=sm10=0;
sm0= 1 ;
sm1= 1.94569 ;
sm2= 1.1514 ;
sm3= 5.96656 ;
sm4= 5.34443 ;
sm5= 3.71993 ;
sm6= 2.70848 ;
sm7= 2.27191 ;
}



static void filtsqravF(vector v)
    /* Izvede kvadriranje in povprecenje signala v s casovno konstanto 125 ms
    (fast).
    $A Igor mar01; */
{
int i;
if (v!=NULL)
{
  for (i=1;i<=v->d;++i)
    v->v[i]*=v->v[i];
  filtlowdigcor(v,1/(2*Pi*0.125),Ts,0,0,0);
}
}

static void filtsqravS(vector v)
    /* Izvede kvadriranje in povprecenje signala v s casovno konstanto 1000 ms
    (slow).
    $A Igor mar01; */
{
int i;
if (v!=NULL)
{
  for (i=1;i<=v->d;++i)
    v->v[i]*=v->v[i];
  filtlowdigcor(v,1/(2*Pi*1),Ts,0,0,0);
}
}

static void filtsqravI(vector v)
    /* Izvede kvadriranje in povprecenje signala v s casovno konstanto 35 ms
    (impulse).
    $A Igor mar01; */
{
int i;
double Uo1,k,val;
k=exp(-Ts/1.5);
if (v!=NULL)
{
  for (i=1;i<=v->d;++i)
    v->v[i]*=v->v[i];
  filtlowdigcor(v,1/(2*Pi*0.035),Ts,0,0,0);
  /* Dodatek za peak detektor: */
  Uo1=v->v[1];
  for (i=2;i<=v->d;++i)
  {
    if (Uo1>v->v[i])
    {
      val=Uo1*k;
      if (val>v->v[i])
        v->v[i]=val;
    }
    Uo1=v->v[i];
  }
}
}

static void filtsqrav(vector v)
    /* Izvade kvadriranje in casovno povprecenjes (=casovno utezevanje) signala
    v na nacin, ki ga doloca staticna spremenljivka timewt (fast, slow ali
    impulse). */
{
if (timewt=='f' || timewt=='F')
  filtsqravF(v);
else if (timewt=='s' || timewt=='S')
  filtsqravS(v);
else if (timewt=='i' || timewt=='I')
  filtsqravI(v);
}

static void filtlow1dig(vector v)
    /* 1. nizkofrekvencni filter pri utezevanju, karakterist. frekvenca
    fhigh1 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filtlowdigcor(v,fhigh1,Ts,corl1f,corl1a0,corl1b1);
}

static void filtlow2dig(vector v)
    /* 2. nizkofrekvencni filter pri utezevanju, karakterist. frekvenca
    fhigh2 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filtlowdigcor(v,fhigh2,Ts,corl2f,corl2a0,corl2b1);
}

static void filtlow3dig(vector v)
    /* 3. nizkofrekvencni filter pri utezevanju, karakterist. frekvenca
    fhigh3 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filtlowdigcor(v,fhigh3,Ts,corl3f,corl3a0,corl3b1);
}

static void filtlow4dig(vector v)
    /* 4. nizkofrekvencni filter pri utezevanju, karakterist. frekvenca
    fhigh4 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filtlowdigcor(v,fhigh4,Ts,corl4f,corl4a0,corl4b1);
}

static void filtlow5dig(vector v)
    /* 5. nizkofrekvencni filter pri utezevanju, karakterist. frekvenca
    fhigh5 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filtlowdigcor(v,fhigh5,Ts,corl5f,corl5a0,corl5b1);
}

static void filtlow6dig(vector v)
    /* 6. nizkofrekvencni filter pri utezevanju, karakterist. frekvenca
    fhigh6 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filtlowdigcor(v,fhigh6,Ts,corl6f,corl6a0,corl6b1);
}

static void filtlow7dig(vector v)
    /* 7. nizkofrekvencni filter pri utezevanju, karakterist. frekvenca
    fhigh7 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filtlowdigcor(v,fhigh7,Ts,corl7f,corl7a0,corl7b1);
}

static void filtlow8dig(vector v)
    /* 8. nizkofrekvencni filter pri utezevanju, karakterist. frekvenca
    fhigh8 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filtlowdigcor(v,fhigh8,Ts,corl8f,corl8a0,corl8b1);
}

static void filtlow9dig(vector v)
    /* 9. nizkofrekvencni filter pri utezevanju, karakterist. frekvenca
    fhigh8 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filtlowdigcor(v,fhigh9,Ts,corl9f,corl9a0,corl9b1);
}

static void filtlow10dig(vector v)
    /* 10. nizkofrekvencni filter pri utezevanju, karakterist. frekvenca
    fhigh8 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filtlowdigcor(v,fhigh10,Ts,corl10f,corl10a0,corl10b1);
}


static void filthigh1dig(vector v)
    /* 1. visokofrekvencni filter pri utezevanju, karakterist. frekvenca
    flow1 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filthighdigcor(v,flow1,Ts,corh1f,corh1a0,corh1a1,corh1b1);
}

static void filthigh2dig(vector v)
    /* 2. visokofrekvencni filter pri utezevanju, karakterist. frekvenca
    flow2 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filthighdigcor(v,flow2,Ts,corh2f,corh2a0,corh2a1,corh2b1);
}

static void filthigh3dig(vector v)
    /* 3. visokofrekvencni filter pri utezevanju, karakterist. frekvenca
    flow3 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filthighdigcor(v,flow3,Ts,corh3f,corh3a0,corh3a1,corh3b1);
}

static void filthigh4dig(vector v)
    /* 4. visokofrekvencni filter pri utezevanju, karakterist. frekvenca
    flow4 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filthighdigcor(v,flow4,Ts,corh4f,corh4a0,corh4a1,corh4b1);
}

static void filthigh5dig(vector v)
    /* 5. visokofrekvencni filter pri utezevanju, karakterist. frekvenca
    flow5 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filthighdigcor(v,flow5,Ts,corh5f,corh5a0,corh5a1,corh5b1);
}

static void filthigh6dig(vector v)
    /* 6. visokofrekvencni filter pri utezevanju, karakterist. frekvenca
    flow6 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filthighdigcor(v,flow6,Ts,corh6f,corh6a0,corh6a1,corh6b1);
}

static void filthigh7dig(vector v)
    /* 7. visokofrekvencni filter pri utezevanju, karakterist. frekvenca
    flow7 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filthighdigcor(v,flow7,Ts,corh7f,corh7a0,corh7a1,corh7b1);
}

static void filthigh8dig(vector v)
    /* 8. visokofrekvencni filter pri utezevanju, karakterist. frekvenca
    flow7 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filthighdigcor(v,flow8,Ts,corh8f,corh8a0,corh8a1,corh8b1);
}

static void filthigh9dig(vector v)
    /* 9. visokofrekvencni filter pri utezevanju, karakterist. frekvenca
    flow7 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filthighdigcor(v,flow9,Ts,corh9f,corh9a0,corh9a1,corh9b1);
}

static void filthigh10dig(vector v)
    /* 10. visokofrekvencni filter pri utezevanju, karakterist. frekvenca
    flow7 in cas vzorcenja Ts (obe sta staticni spremenljivki!). Sfiltrira vzorec,
    ki je v vektorju v, in spravi rezultat v isti vektor. Uporabi korekcijske
    faktorje, ki so lokalne spremenljivke. */
{
filthighdigcor(v,flow10,Ts,corh10f,corh10a0,corh10a1,corh10b1);
}

static void filtCdig(vector v)
    /* Digitalni filter za utezevanje C. */
{
filtlow1dig(v); filtlow2dig(v); filthigh3dig(v); filthigh4dig(v);
multiplysig(v,corCdig);
}


static void filtBdig(vector v)
    /* Digitalni filter za utezevanje B. */
{
filtCdig(v);
filthigh5dig(v);
multiplysig(v,corBdig/corCdig);
}

static void filtAdig(vector v)
    /* Digitalni filter za utezevanje A. */
{
filtCdig(v);
filthigh6dig(v); filthigh7dig(v); 
multiplysig(v,corAdig/corCdig);
/* ANTIALIAS FILTER: */
/* Dva low pass s karakterist. frek. 30kHz in 50kHz: */
/*
fhigh3=50000; fhigh4=70000; 
filtlow3dig(v);  
filtlow4dig(v);  
*/
}

/* Ostri C filtri: */

static void filtC2dig(vector v)
    /* Digitalni filter za dvakratno utezevanje C (oster pasovni). */
{
filtCdig(v); filtCdig(v);
}

static void filtC4dig(vector v)
    /* Digitalni filter za stirikratno utezevanje C (zelo oster pasovni). */
{
filtCdig(v); filtCdig(v); filtCdig(v); filtCdig(v);
}

static void filtC6dig(vector v)
    /* Digitalni filter za stirikratno utezevanje C (zelo oster pasovni). */
{
filtCdig(v); filtCdig(v); filtCdig(v); filtCdig(v); filtCdig(v); filtCdig(v);
}


/* Pasovni filtri: */

static void filtband2222dig(vector v)
{
filthigh1dig(v); filthigh1dig(v); 
filthigh2dig(v); filthigh2dig(v); 
filthigh3dig(v); filthigh3dig(v); 
filthigh4dig(v); filthigh4dig(v); 
filtlow1dig(v); filtlow1dig(v); 
filtlow2dig(v); filtlow2dig(v); 
filtlow3dig(v); filtlow3dig(v); 
filtlow4dig(v); filtlow4dig(v); 
}

static void filtband3322dig(vector v)
{
filthigh1dig(v); filthigh1dig(v);  filthigh1dig(v);
filthigh2dig(v); filthigh2dig(v);  filthigh2dig(v);
filthigh3dig(v); filthigh3dig(v); 
filthigh4dig(v); filthigh4dig(v); 

filtlow1dig(v); filtlow1dig(v);  filtlow1dig(v);
filtlow2dig(v); filtlow2dig(v);  filtlow2dig(v);
filtlow3dig(v); filtlow3dig(v); 
filtlow4dig(v); filtlow4dig(v); 
}

static void filtband222222dig(vector v)
{
filthigh1dig(v); filthigh1dig(v);
filthigh2dig(v); filthigh2dig(v);
filthigh3dig(v); filthigh3dig(v); 
filthigh4dig(v); filthigh4dig(v); 
filthigh5dig(v); filthigh5dig(v); 
filthigh6dig(v); filthigh6dig(v); 

filtlow1dig(v); filtlow1dig(v);
filtlow2dig(v); filtlow2dig(v);
filtlow3dig(v); filtlow3dig(v); 
filtlow4dig(v); filtlow4dig(v); 
filtlow5dig(v); filtlow5dig(v); 
filtlow6dig(v); filtlow6dig(v); 
}

static void filtband333333dig(vector v)
{
filthigh1dig(v); filthigh1dig(v);  filthigh1dig(v);
filthigh2dig(v); filthigh2dig(v);  filthigh2dig(v);
filthigh3dig(v); filthigh3dig(v);  filthigh3dig(v); 
filthigh4dig(v); filthigh4dig(v);  filthigh4dig(v); 
filthigh5dig(v); filthigh5dig(v);  filthigh5dig(v);
filthigh6dig(v); filthigh6dig(v);  filthigh6dig(v);

filtlow1dig(v); filtlow1dig(v);  filtlow1dig(v);
filtlow2dig(v); filtlow2dig(v);  filtlow2dig(v);
filtlow3dig(v); filtlow3dig(v);  filtlow3dig(v);
filtlow4dig(v); filtlow4dig(v);  filtlow4dig(v);
filtlow5dig(v); filtlow5dig(v);  filtlow5dig(v);
filtlow6dig(v); filtlow6dig(v);  filtlow6dig(v); 
}

static void filtband6dig(vector v)
      /* Pasovni filter, sestavljen iz sestih parov, sestavljenih iz
      nizko in visokoprepustnega filtra danega reda. Redi parov so v staticnih
      spremenljivkah ord1, .., ord6, sami filtri pa so filtlow1dig, ...,
      filthigh1dig, ..., in uporabljajo ustrezne staticne spremenljivke. */
{
int i;
setzeroweightcor();
for (i=1;i<=ord1;++i) {  filthigh1dig(v);  filtlow1dig(v);  }
for (i=1;i<=ord2;++i) {  filthigh2dig(v);  filtlow2dig(v);  }
for (i=1;i<=ord3;++i) {  filthigh3dig(v);  filtlow3dig(v);  }
for (i=1;i<=ord4;++i) {  filthigh4dig(v);  filtlow4dig(v);  }
for (i=1;i<=ord5;++i) {  filthigh5dig(v);  filtlow5dig(v);  }
for (i=1;i<=ord6;++i) {  filthigh6dig(v);  filtlow6dig(v);  }
}

static void filtband10dig(vector v)
      /* Pasovni filter, sestavljen iz osmih parov, sestavljenih iz
      nizko in visokoprepustnega filtra danega reda. Redi parov so v staticnih
      spremenljivkah ord1, .., ord8, sami filtri pa so filtlow1dig, ...,
      filthigh1dig, ..., in uporabljajo ustrezne staticne spremenljivke. */
{
int i;
setzeroweightcor();
for (i=1;i<=ord1;++i) {  filthigh1dig(v);  filtlow1dig(v);  }
for (i=1;i<=ord2;++i) {  filthigh2dig(v);  filtlow2dig(v);  }
for (i=1;i<=ord3;++i) {  filthigh3dig(v);  filtlow3dig(v);  }
for (i=1;i<=ord4;++i) {  filthigh4dig(v);  filtlow4dig(v);  }
for (i=1;i<=ord5;++i) {  filthigh5dig(v);  filtlow5dig(v);  }
for (i=1;i<=ord6;++i) {  filthigh6dig(v);  filtlow6dig(v);  }
for (i=1;i<=ord7;++i) {  filthigh7dig(v);  filtlow7dig(v);  }
for (i=1;i<=ord8;++i) {  filthigh8dig(v);  filtlow8dig(v);  }
for (i=1;i<=ord9;++i) {  filthigh9dig(v);  filtlow9dig(v);  }
for (i=1;i<=ord10;++i) {  filthigh10dig(v);  filtlow10dig(v);  }
}

static void filtres10dig(vector v)
    /* Pasovni filter iz desetih resonancnih filtrov, katerih parametri so
    staticne spremenljivke fres1, hres1, fres2, hres2 itd. Ce je kaksna
    centralna frekvenca ali sirina razlicna od 0, potem je ustrezni filter
    izvzet. */
{
if (fres1>0 && hres1>0) filtresdig(v,fres1,hres1,Ts);
if (fres2>0 && hres2>0) filtresdig(v,fres2,hres2,Ts);
if (fres3>0 && hres3>0) filtresdig(v,fres3,hres3,Ts);
if (fres4>0 && hres4>0) filtresdig(v,fres4,hres4,Ts);
if (fres5>0 && hres5>0) filtresdig(v,fres5,hres5,Ts);
if (fres6>0 && hres6>0) filtresdig(v,fres6,hres6,Ts);
if (fres7>0 && hres7>0) filtresdig(v,fres7,hres7,Ts);
if (fres8>0 && hres8>0) filtresdig(v,fres8,hres8,Ts);
if (fres9>0 && hres9>0) filtresdig(v,fres9,hres9,Ts);
if (fres10>0 && hres10>0) filtresdig(v,fres10,hres10,Ts);
}

static void filtressym10dig(vector v)
    /* Pasovni filter iz petih resonancnih in petih zrcalnih resonancnih
    filtrov, katerih parametri so staticne spremenljivke fres1, hres1, fres2,
    hres2, ..., fres5, hres5 za zrcalno resonancne in fres5, hres5, ...,
    fres10, hres10 za resonancne filtre. Ce je kaksna centralna frekvenca ali
    sirina enaka 0, potem je ustrezni filter izvzet iz verige.
    POZOR: Najprej so zrcalni resonancni filtri, nato pa resonancni. */
{
int i;
for (i=1;i<=multiplicity;++i) /* multiplicity je 1, ce tega ne spremenis! */
{
  if (fres1>0 && hres1>0) filtresmirdig(v,fres1,hres1,Ts);
  if (fres2>0 && hres2>0) filtresmirdig(v,fres2,hres2,Ts);
  if (fres3>0 && hres3>0) filtresmirdig(v,fres3,hres3,Ts);
  if (fres4>0 && hres4>0) filtresmirdig(v,fres4,hres4,Ts);
  if (fres5>0 && hres5>0) filtresmirdig(v,fres5,hres5,Ts);
  if (fres6>0 && hres6>0) filtresdig(v,fres6,hres6,Ts);
  if (fres7>0 && hres7>0) filtresdig(v,fres7,hres7,Ts);
  if (fres8>0 && hres8>0) filtresdig(v,fres8,hres8,Ts);
  if (fres9>0 && hres9>0) filtresdig(v,fres9,hres9,Ts);
  if (fres10>0 && hres10>0) filtresdig(v,fres10,hres10,Ts);
  /* Dodatni nizko in visokoprepustni filtri, ki so opcijski: */
  if (freshigh1!=0)
    filtlowdig(v,freshigh1,Ts);
  if (freshigh2!=0)
    filtlowdig(v,freshigh2,Ts);
  if (freslow1!=0)
    filthighdig(v,freslow1,Ts);
  if (freslow2!=0)
    filthighdig(v,freslow2,Ts);
}
}


static void filtrescombsym10dig(vector v)
    /* Pasovni filter iz petih kombiniranih resonancnih in zrcalnih resonancnih
    filtrov, katerih parametri so staticne spremenljivke fres1, hres1, fres2,
    hres2, ..., fres5, hres5 za zrcalno resonancne in fres5, hres5, ...,
    fres10, hres10 za resonancne filtre. Ce je kaksna centralna frekvenca ali
    sirina enaka 0, potem je ustrezni filter izvzet iz verige.
    POZOR: Najprej so zrcalni resonancni filtri, nato pa resonancni. */
{
if (fres1>0 && hres1>0 && fres6>0 && hres6>0)
  filtrescombdig(v,fres1,hres1,fres6,hres6,Ts);
if (fres2>0 && hres2>0 && fres7>0 && hres7>0)
  filtrescombdig(v,fres2,hres2,fres7,hres7,Ts);
if (fres3>0 && hres3>0 && fres8>0 && hres8>0)
  filtrescombdig(v,fres3,hres3,fres8,hres8,Ts);
if (fres4>0 && hres4>0 && fres9>0 && hres9>0)
  filtrescombdig(v,fres4,hres4,fres9,hres9,Ts);
if (fres5>0 && hres5>0 && fres10>0 && hres10>0)
  filtrescombdig(v,fres5,hres5,fres10,hres10,Ts);
}


static void filtres10high6dig(vector v)
    /* Pasovni filter iz desetih resonancnih filtrov in sestih visokoprepustnih
    filtrov, katerih parametri so
    staticne spremenljivke fres1, hres1, fres2, hres2 itd. Ce je kaksna
    centralna frekvenca ali sirina manj ali enaka  0, potem je ustrezni filter
    izvzet. Podobno velja za visokofrekvencne filtre  */
{
if (fres1>0 && hres1>0) filtresdig(v,fres1,hres1,Ts);
if (fres2>0 && hres2>0) filtresdig(v,fres2,hres2,Ts);
if (fres3>0 && hres3>0) filtresdig(v,fres3,hres3,Ts);
if (fres4>0 && hres4>0) filtresdig(v,fres4,hres4,Ts);
if (fres5>0 && hres5>0) filtresdig(v,fres5,hres5,Ts);
if (fres6>0 && hres6>0) filtresdig(v,fres6,hres6,Ts);
if (fres7>0 && hres7>0) filtresdig(v,fres7,hres7,Ts);
if (fres8>0 && hres8>0) filtresdig(v,fres8,hres8,Ts);
if (fres9>0 && hres9>0) filtresdig(v,fres9,hres9,Ts);
if (fres10>0 && hres10>0) filtresdig(v,fres10,hres10,Ts);
if (flow1>0) filthighdig(v,flow1,Ts);
if (flow2>0) filthighdig(v,flow2,Ts);
if (flow3>0) filthighdig(v,flow3,Ts);
if (flow4>0) filthighdig(v,flow4,Ts);
if (flow5>0) filthighdig(v,flow5,Ts);
if (flow6>0) filthighdig(v,flow6,Ts);
}

static void filtgen5dig(vector v)
    /* Solosni digitalni filter s 5+1 vhodnimi in 5 izhodnimi koeficienti,
    ki so v staticnih spremenjivkah cfa0, cfa1, ..., cfa5, cfb1, ..., cfb5. */
{
filtgendig5(v,cfa0,cfa1,cfa2,cfa3,cfa4,cfa5,cfb1,cfb2,cfb3,cfb4,cfb5);
}

static void filtgen10dig(vector v)
    /* Splosni digitalni filter z 10+1 vhodnimi in 10 izhodnimi koeficienti,
    ki so v staticnih spremenjivkah cfa0, cfa1, ..., cfa10, cfb1, ..., cfb10. */
{
filtgendig10(v,cfa0,cfa1,cfa2,cfa3,cfa4,cfa5,cfa6,cfa7,cfa8,cfa9,cfa10,
               cfb1,cfb2,cfb3,cfb4,cfb5,cfb6,cfb7,cfb8,cfb9,cfb10);
}


static void filtkopCdig(vector v)
    /* Kopacev prvi filter C (z dvema celicama); Narejen je za Ts=2.5e-05 */
{
int i;
double 
        b10 = 0.4805,			b20 = 0.5,
        b11 = -0.961,			b21 = 0.99997,
        b12 = 0.4805,			b22 = 0.5,
        a10 = 0.99997,			a20 = 0.5,
        a11 = -0.04318,			a21 = -0.99673,
        a12 = 0.000458,			a22 = 0.49677;
if (v!=NULL)
{
  filtgendig5(v,b10/a10,b11/a10,b12/a10,0,0,0,-a11/a10,-a12/a10,0,0,0);
  filtgendig5(v,b20/a20,b21/a20,b22/a20,0,0,0,-a21/a20,-a22/a20,0,0,0);
}
}

static void filtkopC1dig(vector v)
    /* Kopacev prvi filter C1 (z eno celico); Narejen je za Ts=2.5e-05 */
{
int i;
double k=0.5;
double 
        b0=0.24,			a0=1,
        b1=0,				a1=-2.036,
        b2=-0.48,			a2=1.08,
        b3=0,				a3=-0.0438,
        b4=0.24,			a4=0.0004631;
if (v!=NULL)
{
  for (i=1;i<=v->d;++i)
    v->v[i]*=k;
  filtgendig5(v,b0/a0,b1/a0,b2/a0,b3/a0,b4/a0,0,-a1/a0,-a2/a0,-a3/a0,-a4/a0,0);
}
}


static void filtkopAdig(vector v)
    /* Kopacev filter A; Narejen je za Ts=2.5e-05 */
{
int i;
double k=0.281475043464418,
       b10=1.000000000000000,    b20=1.000000000000000,    b30=1.000000000000000,
       b11=2.000000000000002,    b21=-2.000159470066238,   b31=-1.999840529933763,
       b12=1.000000000000002,    b22=1.000159482785269,    b32=0.999840542645436,
       a10=1.000000000000000,    a20=1.000000000000000,    a30=1.000000000000000,
       a11=-1.873677451467970,   a21=-1.993539086921573,   a31=-0.043181033803798,
       a12=0.875514486511374,    a22=0.993549522770461,    a32=0.000466150420091;
if (v!=NULL)
{
  for (i=1;i<=v->d;++i)
    v->v[i]*=k;
  filtgendig5(v,b10/a10,b11/a10,b12/a10,0,0,0,-a11/a10,-a12/a10,0,0,0);
  filtgendig5(v,b20/a20,b21/a20,b22/a20,0,0,0,-a21/a20,-a22/a20,0,0,0);
  filtgendig5(v,b30/a30,b31/a30,b32/a30,0,0,0,-a31/a30,-a32/a30,0,0,0);
}
}


static void filt8lowdig(vector v)
      /* Nizkoprepustni filter, sestavljen iz osmih nizkoprepustnih filtrov
      danega reda. Redi filtrov so v staticnih spremenljivkah ord1, .., ord8,
      sami filtri pa so filtlow1dig, ..., in uporabljajo ustrezne staticne
      spremenljivke. */
{
int i;
for (i=1;i<=ord1;++i)  filtlow1dig(v);  
for (i=1;i<=ord2;++i)  filtlow2dig(v);  
for (i=1;i<=ord3;++i)  filtlow3dig(v);  
for (i=1;i<=ord4;++i)  filtlow4dig(v);  
for (i=1;i<=ord5;++i)  filtlow5dig(v);  
for (i=1;i<=ord6;++i)  filtlow6dig(v);  
for (i=1;i<=ord7;++i)  filtlow7dig(v);  
for (i=1;i<=ord8;++i)  filtlow8dig(v);  
}


static void filt8highdig(vector v)
      /* Visokoprepustni filter, sestavljen iz osmih visokooprepustnih filtrov
      danega reda. Redi filtrov so v staticnih spremenljivkah ord1, .., ord8,
      sami filtri pa so filthigh1dig, ..., in uporabljajo ustrezne staticne
      spremenljivke. */
{
int i;
for (i=1;i<=ord1;++i)   filthigh1dig(v);
for (i=1;i<=ord2;++i)   filthigh2dig(v);
for (i=1;i<=ord3;++i)   filthigh3dig(v);
for (i=1;i<=ord4;++i)   filthigh4dig(v);
for (i=1;i<=ord5;++i)   filthigh5dig(v);
for (i=1;i<=ord6;++i)   filthigh6dig(v);
for (i=1;i<=ord7;++i)   filthigh7dig(v);
for (i=1;i<=ord8;++i)   filthigh8dig(v);
}




/* FUNKCIJE ZA RISANJE ODZIVOV DIGITALNIH FILTROV: */

static double resplowdig(double n)
    /* Digitalni low pass filter - teoreticni odziv */
{
return dbamp(amplowdig(fstdcont(n),fhigh,Ts));
}

static double resphighdig(double n)
    /* Digitalni high pass filter - teoreticni odziv */
{
return dbamp(amphighdig(fstdcont(n),fhigh,Ts));
}

static double resplowdignum(double n)
    /* Digitalni low pass filter - numericni odziv */
{
return numfiltresp(filtlowdig0,fstdcont(n),Ts);
}

static double resplowdigcentnum(double n)
    /* Digitalni low pass filter izveden s srediscno formulo - numericni odziv */
{
return numfiltresp(filtlowdigcent0,fstdcont(n),Ts);
}

static double resphighdignum(double n)
    /* Digitalni high pass filter - numericni odziv */
{
return numfiltresp(filthighdig0,fstdcont(n),Ts);
}

static double respresdignum(double n)
    /* Digitalni high pass filter - numericni odziv */
{
return numfiltresp(filtresdig0,fstdcont(n),Ts);
}


/* Filtri za utezevanje: */

static double resplow1dignum(double n)
    /* Nizkoprepustni filter st. 1; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtlow1dig,fstdcont(n),Ts);
}
static double resplow2dignum(double n)
    /* Nizkoprepustni filter st. 2; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtlow2dig,fstdcont(n),Ts);
}
static double resphigh3dignum(double n)
    /* Nizkoprepustni filter st. 3; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filthigh3dig,fstdcont(n),Ts);
}
static double resphigh4dignum(double n)
    /* Nizkoprepustni filter st. 4; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filthigh4dig,fstdcont(n),Ts);
}
static double resphigh5dignum(double n)
    /* Nizkoprepustni filter st. 5; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filthigh5dig,fstdcont(n),Ts);
}
static double resphigh6dignum(double n)
    /* Nizkoprepustni filter st. 6; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filthigh6dig,fstdcont(n),Ts);
}
static double resphigh7dignum(double n)
    /* Nizkoprepustni filter st. 7; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filthigh7dig,fstdcont(n),Ts);
}

static double respCdignum(double n)
    /* Filter za utezevanje C; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtCdig,fstdcont(n),Ts);
}
static double respBdignum(double n)
    /* Filter za utezevanje B; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtBdig,fstdcont(n),Ts);
}
static double respAdignum(double n)
    /* Filter za utezevanje A; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtAdig,fstdcont(n),Ts);
}

static double respC2dignum(double n)
    /* Filter za dvakratno utezevanje C; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtC2dig,fstdcont(n),Ts);
}

static double respC4dignum(double n)
    /* Filter za stirikratno utezevanje C; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtC4dig,fstdcont(n),Ts);
}

static double respC6dignum(double n)
    /* Filter za sestkratno utezevanje C; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtC6dig,fstdcont(n),Ts);
}

/* Odzivi pasovnih filtrov: */

static double respband2222dignum(double n)
    /* Pasovni filter 2222; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtband2222dig,fstdcont(n),Ts);
}

static double respband3322dignum(double n)
    /* Pasovni filter 3322; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtband3322dig,fstdcont(n),Ts);
}

static double respband222222dignum(double n)
    /* Pasovni filter 222222; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtband222222dig,fstdcont(n),Ts);
}

static double respband333333dignum(double n)
    /* Pasovni filter 333333; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtband333333dig,fstdcont(n),Ts);
}

static double respband6dignum(double n)
    /* Pasovni filter 6; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtband6dig,fstdcont(n),Ts);
}

static double respband10dignum(double n)
    /* Pasovni filter 8; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filtband10dig,fstdcont(n),Ts);
}

static double respband10an(double n)
    /* Vrne analogni odziv pasovnega filtra iz 8 nizkoprepustnih in 8
    visokoprepustnih filtrov. n je logaritemska mera za frekvenco. */
{
double f;
double ret=1;
setzeroweightcor();
f=fstdcont(n);
ret*=pow(amphigh(f,flow1)*amplow(f,fhigh1),ord1);
ret*=pow(amphigh(f,flow2)*amplow(f,fhigh2),ord2);
ret*=pow(amphigh(f,flow3)*amplow(f,fhigh3),ord3);
ret*=pow(amphigh(f,flow4)*amplow(f,fhigh4),ord4);
ret*=pow(amphigh(f,flow5)*amplow(f,fhigh5),ord5);
ret*=pow(amphigh(f,flow6)*amplow(f,fhigh6),ord6);
ret*=pow(amphigh(f,flow7)*amplow(f,fhigh7),ord7);
ret*=pow(amphigh(f,flow8)*amplow(f,fhigh8),ord8);
ret*=pow(amphigh(f,flow9)*amplow(f,fhigh9),ord9);
ret*=pow(amphigh(f,flow10)*amplow(f,fhigh10),ord10);
return dbamp(ret);
}

static double respres10dignum(double n)
    /* Resonancni filter 10; Uporablja staticne podatke fres1, hres1,
    ..., Ts, ... */
{
return numfiltresp(filtres10dig,fstdcont(n),Ts);
}


static double respressym10dignum(double n)
    /* Resonancni filter sym10; Uporablja staticne podatke (fres1, hres1,
    ..., fres10, hres10, Ts,  ... */
{
return numfiltresp(filtressym10dig,fstdcont(n),Ts);
}

static double resprescombsym10dignum(double n)
    /* Resonancni filter combsym10 Uporablja staticne podatke (fres1, hres1,
    ..., fres10, hres10, Ts,  ... */
{
return numfiltresp(filtrescombsym10dig,fstdcont(n),Ts);
}

static double respres10an(double n)
    /* Vrne analogni odziv pasovnega filtra iz 10 resonancnih
    filtrov. n je logaritemska mera za frekvenco. */
{
double f;
double ret=1;
setzeroweightcor();
f=fstdcont(n);
if (fres1!=0 && hres1!=0) ret*=ampres(f,fres1,hres1);
if (fres2!=0 && hres2!=0) ret*=ampres(f,fres2,hres2);
if (fres3!=0 && hres3!=0) ret*=ampres(f,fres3,hres3);
if (fres4!=0 && hres4!=0) ret*=ampres(f,fres4,hres4);
if (fres5!=0 && hres5!=0) ret*=ampres(f,fres5,hres5);
if (fres6!=0 && hres6!=0) ret*=ampres(f,fres6,hres6);
if (fres7!=0 && hres7!=0) ret*=ampres(f,fres7,hres7);
if (fres8!=0 && hres8!=0) ret*=ampres(f,fres8,hres8);
if (fres9!=0 && hres9!=0) ret*=ampres(f,fres9,hres9);
if (fres10!=0 && hres10!=0) ret*=ampres(f,fres10,hres10);
return dbamp(ret);
}

static double respres10high6dignum(double n)
    /* Pasovni filter iz 10 res. in 4 low pass filtrov; Uporablja staticne 
    podatke (flow1, flow2,  ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0,
    corh4a1, corh4b1, ... */
{
return numfiltresp(filtres10high6dig,fstdcont(n),Ts);
}

static double respres10high6an(double n)
    /* Vrne analogni odziv pasovnega filtra iz 10 resonancnih in 6
    visokoprepustnih filtrov. n je logaritemska mera za frekvenco. */
{
double f;
double ret=1;
setzeroweightcor();
f=fstdcont(n);
if (fres1!=0 && hres1!=0) ret*=ampres(f,fres1,hres1);
if (fres2!=0 && hres2!=0) ret*=ampres(f,fres2,hres2);
if (fres3!=0 && hres3!=0) ret*=ampres(f,fres3,hres3);
if (fres4!=0 && hres4!=0) ret*=ampres(f,fres4,hres4);
if (fres5!=0 && hres5!=0) ret*=ampres(f,fres5,hres5);
if (fres6!=0 && hres6!=0) ret*=ampres(f,fres6,hres6);
if (fres7!=0 && hres7!=0) ret*=ampres(f,fres7,hres7);
if (fres8!=0 && hres8!=0) ret*=ampres(f,fres8,hres8);
if (fres9!=0 && hres9!=0) ret*=ampres(f,fres9,hres9);
if (fres10!=0 && hres10!=0) ret*=ampres(f,fres10,hres10);
if (flow1>0) ret*=amphigh(f,flow1);
if (flow2>0) ret*=amphigh(f,flow2);
if (flow3>0) ret*=amphigh(f,flow3);
if (flow4>0) ret*=amphigh(f,flow4);
if (flow5>0) ret*=amphigh(f,flow5);
if (flow6>0) ret*=amphigh(f,flow6);
return dbamp(ret);
}


static double respgen5dignum(double n)
    /* Splosni filter s 5+1 vhodnimi in 5 izhodnimi koeficienti, ki so v
    staticnih spremenljivkah cfa0, ..., cfa5, cfb1, ..., cfb5. */
{
return numfiltresp(filtgen5dig,fstdcont(n),Ts);
}

static double respgen10dignum(double n)
    /* Splosni filter z 10+1 vhodnimi in 10 izhodnimi koeficienti, ki so v
    staticnih spremenljivkah cfa0, ..., cfa10, cfb1, ..., cfb10. */
{
return numfiltresp(filtgen10dig,fstdcont(n),Ts);
}

static double respkopCdignum(double n)
    /* Kopacev filter C, narejen za Ts=2.5e-05. */
{
return numfiltresp(filtkopCdig,fstdcont(n),Ts);
}

static double respkopC1dignum(double n)
    /* Kopacev filter C1, narejen za Ts=2.5e-05. */
{
return numfiltresp(filtkopC1dig,fstdcont(n),Ts);
}

static double respkopAdignum(double n)
    /* Kopacev filter A, narejen za Ts=2.5e-05. */
{
return numfiltresp(filtkopAdig,fstdcont(n),Ts);
}


static double resplow8dignum(double n)
    /* Nizkoprepustni filter 8; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filt8lowdig,fstdcont(n),Ts);
}

static double resphigh8dignum(double n)
    /* Visokoprepustni filter 8; Uporablja staticne podatke (flow1, flow2,
    ..., Ts, corl1f, corl1a0, corl1b1, ..., corh4a0, corh4a1, corh4b1, ... */
{
return numfiltresp(filt8highdig,fstdcont(n),Ts);
}



/* TEORETICNI ODZIVI FILTROV IZ STANDARDA:

Opomba: formule iz standarda morajo biti korigirane s konstantnim faktorjem,
ki se izracuna s primerjavo odzivov. */


static double fstd(int n)
    /* Vrne natancno vrednost n-te standardne frekvenco, n je lahko celo
    st. od -20 do 13, vkljucno z 0. */
{
if (n<-20 || n>13)
{
  errfunc0("fstd");
  fprintf(erf(),"Frequency index (%i) is not in range\n",n);
  errfunc2();
}
return 1000.0*pow(10.0,0.1*(double)n);
}



static double RC0(double f)
    /* Vrne teoreticni C utezen amplitudni relativni frekvencni odziv. */
{
return 12200.0*12200.0*f*f/( (f*f+20.6*20.6) * (f*f+12200.0*12200.0) );
}

static double RB0(double f)
    /* Vrne teoreticni B utezen amplitudni relativni frekvencni odziv. */
{
return 12200.0*12200.0*f*f*f/
 ( (f*f+20.6*20.6) * (f*f+12200.0*12200.0) * sqrt(f*f+158.5*158.5) );
}

static double RA0(double f)
    /* Vrne teoreticni A utezen amplitudni relativni frekvencni odziv. */
{
return 12200.0*12200.0*f*f*f*f/
 ( (f*f+20.6*20.6) * (f*f+12200.0*12200.0) * 
 sqrt((f*f+107.7*107.7) * (f*f+737.9*737.9)) );
}

static double RC(double f)
    /* Vrne teoreticni C utezen amplitudni relativni frekvencni odziv,
    ki je korigiran za ustrezen faktor corC. */
{
return corC*12200.0*12200.0*f*f/( (f*f+20.6*20.6) * (f*f+12200.0*12200.0) );
}

static double RB(double f)
    /* Vrne teoreticni B utezen amplitudni relativni frekvencni odziv,
    ki je korigiran za ustrezen faktor corB. */
{
return corB*12200.0*12200.0*f*f*f/
 ( (f*f+20.6*20.6) * (f*f+12200.0*12200.0) * sqrt(f*f+158.5*158.5) );
}

static double RA(double f)
    /* Vrne teoreticni A utezen amplitudni relativni frekvencni odziv,
    ki je korigiran za ustrezen faktor corA. */
{
return corA*12200.0*12200.0*f*f*f*f/
 ( (f*f+20.6*20.6) * (f*f+12200.0*12200.0) * 
 sqrt((f*f+107.7*107.7) * (f*f+737.9*737.9)) );
}

static double respCth(double n)
    /* Vrne izracunani teoreticni odziv filtra C, ki je ze korigiran tako,
    da je pri 1000 Hz enak 0. */
{
return dbamp(RC(fstdcont(n)));
}

static double respBth(double n)
    /* Vrne izracunani teoreticni odziv filtra B, ki je ze korigiran tako,
    da je pri 1000 Hz enak 0. */
{
return dbamp(RB(fstdcont(n)));
}

static double respAth(double n)
    /* Vrne izracunani teoreticni odziv filtra A, ki je ze korigiran tako,
    da je pri 1000 Hz enak 0. */
{
return dbamp(RA(fstdcont(n)));
}



/* PODATKI IZ TABEL (v glavnem iz standardov): */

static vector
nomf=NULL,  /* nominalne frekvence */
nomA=NULL,nomB=NULL,nomC=NULL, /* nominalne utezi v decibelih */
tol0min=NULL,tol0max=NULL,  /* +- tolerance za tip 0 v decibelih */
tol1min=NULL,tol1max=NULL,  /* +- tolerance za tip 1 v decibelih */
tol2min=NULL,tol2max=NULL,  /* +- tolerance za tip 2 v decibelih */
filtind=NULL,filtindthird=NULL,
filt0min=NULL,filt0max=NULL, /* sp. in zg. meja za prep. okt. filt. za tip 0 v db */
filt1min=NULL,filt1max=NULL, /* sp. in zg. meja za prep. okt. filt. za tip 1 v db */
filt2min=NULL,filt2max=NULL; /* sp. in zg. meja za prep. okt. filt. za tip 2 v db */


static double filtmin1(double ind)
    /* Vrne spodnjo mejo prepustnosti oktavnega filtra tipa 1 pri faktorju
    centralne frekvence filtra (t.j. norm. frek. omega) 2^ind. */
{
int i,imin,imax;
ind=fabs(ind);  /* funkcija je simetricna */
i=filtind->d;
while(filtind->v[i]>ind)
  --i;
if (filtind->v[i]==ind || i==filtind->d)
  return filt1min->v[i];
else
  return filt1min->v[i]+(filt1min->v[i+1]-filt1min->v[i])*
   (ind-filtind->v[i])/(filtind->v[i+1]-filtind->v[i]);
}

static double filtmin1plot(double ind)
    /* Funkcija filtmin1 za grafe; Tam, kjer je vrednost manj kot 1000, vrne 0. */
{
double ret;
ret=filtmin1(ind);
if (ret<-20)
  ret=-20;
return ret;
}

static double filtmax1(double ind)
    /* Vrne zgornjo mejo prepustnosti oktavnega filtra tipa 1 pri faktorju
    centralne frekvence filtra (t.j. norm. frek. omega) 2^ind. */
{
int i,imin,imax;
ind=fabs(ind);  /* funkcija je simetricna */
i=filtind->d;
while(filtind->v[i]>ind)
  --i;
if (filtind->v[i]==ind || i==filtind->d)
  return filt1max->v[i];
else
  return filt1max->v[i]+(filt1max->v[i+1]-filt1max->v[i])*
   (ind-filtind->v[i])/(filtind->v[i+1]-filtind->v[i]);
}




static double filtminthird1(double ind)
    /* Vrne spodnjo mejo prepustnosti tretjinsko oktavnega filtra tipa 1 pri
    faktorju centralne frekvence filtra (t.j. norm. frek. omega) 2^ind. */
{
int i,imin,imax;
ind=fabs(ind);  /* funkcija je simetricna */
i=filtindthird->d;
while(filtindthird->v[i]>ind)
  --i;
if (filtindthird->v[i]==ind || i==filtindthird->d)
  return filt1min->v[i];
else
  return filt1min->v[i]+(filt1min->v[i+1]-filt1min->v[i])*
   (ind-filtindthird->v[i])/(filtindthird->v[i+1]-filtindthird->v[i]);
}

static double filtminthird1plot(double ind)
    /* Funkcija filtminthird1 za grafe; Tam, kjer je vrednost manj kot -1000,
    vrne 0. */
{
double ret;
ret=filtminthird1(ind);
if (ret<-20)
  ret=-20;
return ret;
}

static double filtmaxthird1(double ind)
    /* Vrne zgornjo mejo prepustnosti oktavnega filtra tipa 1 pri faktorju
    centralne frekvence filtra (t.j. norm. frek. omega) 2^ind. */
{
int i,imin,imax;
ind=fabs(ind);  /* funkcija je simetricna */
i=filtindthird->d;
while(filtindthird->v[i]>ind)
  --i;
if (filtindthird->v[i]==ind || i==filtindthird->d)
  return filt1max->v[i];
else
  return filt1max->v[i]+(filt1max->v[i+1]-filt1max->v[i])*
   (ind-filtindthird->v[i])/(filtindthird->v[i+1]-filtindthird->v[i]);
}




static double filtminthird1old(double ind)
    /* Vrne spodnjo mejo prepustnosti oktavnega filtra tipa 1 pri faktorju
    centralne frekvence filtra 2^ins. */
{
return filtmin1(3*ind);
}

static double filtminthird1plotold(double ind)
    /* Funkcija filtmin1 za grafe; Tam, kjer je vrednost manj kot 1000, vrne 0. */
{
double ret;
ret=filtminthird1(ind);
if (ret<-1000 || fabs(ind)>0.5)
  ret=0;
return ret;
}

static double filtmaxthird1old(double ind)
    /* Vrne zgornjo mejo prepustnosti oktavnega filtra tipa 1 pri faktorju
    centralne frekvence filtra 2^ins. */
{
return filtmax1(3*ind);
}


static void checkdata(vooid)
    /* Izpise razlicne primerjave podatkov. */
{
int i;
const int ntab=34;
/* Povprecne razlike v decibelih, ki bi jih morali pristeti k formuli za
teoreticni odziv, da bi dobili podatke iz tabele */
double avdifA=0,avdifB=0,avdifC=0,avdifAnom=0,avdifBnom=0,avdifCnom=0;
if (nomf==NULL || nomA==NULL || nomB==NULL || nomC==NULL ||
 tol0min==NULL || tol0max==NULL || tol1min==NULL ||
 tol1max==NULL || tol2min==NULL || tol2max==NULL)
{
  printf("ERROR: Data vector NULL!\n\n");
  return;
}
printf("\n\nComparing A, B & C weighting data; Data from tables vs. data by formulas:\n\n");
printf("\nA weighting:\n");
printf("%4s %6s %12s %10s %12s %14s %14s\n",
 "n","nom. f.","freq.","tab. w.","calc. w.","c. w. nom. f.","dif.");
for (i=1;i<=ntab;++i)
{
  printf("%4i %6g %12g %10g %12g %14g %14g\n",
  i-21,nomf->v[i],fstd(i-21),nomA->v[i],
  dbamp(RA0(fstd(i-21))),dbamp(RA0(nomf->v[i])), dbamp(RA0(fstd(i-21)))-nomA->v[i] );
  avdifA+=nomA->v[i]-dbamp(RA0(fstd(i-21)));
  avdifAnom+=nomA->v[i]-dbamp(RA0(nomf->v[i]));
}
printf("\nB weighting:\n");
printf("%4s %6s %12s %10s %12s %14s %14s\n",
 "n","nom. f.","freq.","tab. w.","calc. w.","c. w. nom. f.","dif.");
for (i=1;i<=ntab;++i)
{
  printf("%4i %6g %12g %10g %12g %14g %14g\n",
  i-21,nomf->v[i],fstd(i-21),nomB->v[i],
  dbamp(RB0(fstd(i-21))),dbamp(RB0(nomf->v[i])), dbamp(RB0(fstd(i-21)))-nomB->v[i] );
  avdifB+=nomB->v[i]-dbamp(RB0(fstd(i-21)));
  avdifBnom+=nomB->v[i]-dbamp(RB0(nomf->v[i]));
}
printf("\nC weighting:\n");
printf("%4s %6s %12s %10s %12s %14s %14s\n",
 "n","nom. f.","freq.","tab. w.","calc. w.","c. w. nom. f.","dif.");
for (i=1;i<=ntab;++i)
{
  printf("%4i %6g %12g %10g %12g %14g %14g\n",
  i-21,nomf->v[i],fstd(i-21),nomC->v[i],
  dbamp(RC0(fstd(i-21))),dbamp(RC0(nomf->v[i])), dbamp(RC0(fstd(i-21)))-nomC->v[i] );
  avdifC+=nomC->v[i]-dbamp(RC0(fstd(i-21)));
  avdifCnom+=nomC->v[i]-dbamp(RC0(nomf->v[i]));
}
avdifA/=ntab; avdifB/=ntab; avdifC/=ntab;
avdifAnom/=ntab; avdifBnom/=ntab; avdifCnom/=ntab;
printf("\nAv. dif. between theoretical and tabulated response:\n");
printf("Exact frequencies:   A:%g, B:%g, C:%g\n",avdifA,avdifB,avdifC);
printf("Nominal frequencies: A:%g, B:%g, C:%g\n",avdifAnom,avdifBnom,avdifCnom);
/*
printf("\n\nCorrected theoretical response (for average difference):\n\n");
printf("\nA weighting:\n");
printf("%6s %10s %12s %12s %12s %12s %5g\n",
 "nom. f.","tab. w.","cor. ex.","cor. nom.","dif. ex.","dif. nom.","tol.");
for (i=1;i<=ntab;++i)
{
  printf("%6g %10g %12g %12g %12g %12g %5g\n",
   nomf->v[i],nomA->v[i],
   dbamp(RA0(fstd(i-21)))+avdifA,dbamp(RA0(nomf->v[i]))+avdifAnom,
   dbamp(RA0(fstd(i-21)))+avdifA-nomA->v[i],
   dbamp(RA0(nomf->v[i]))+avdifAnom-nomA->v[i],tol1max->v[i]);
}
*/
printf("\n\nCorrected theoretical response (so that it gives 0 at 1000 Hz):\n\n");
printf("\nA weighting:\n");
printf("Correction = %.12g db (amplitude factor %.12g).\n",
 nomA->v[21]-dbamp(RA0(fstd(0))),
 invdbamp( nomA->v[21]-dbamp(RA0(fstd(0))) ) );
corA=invdbamp( nomA->v[21]-dbamp(RA0(fstd(0))) );
printf("%6s %10s %12s %12s %5s %12s\n",
 "nom. f.","tab. w.","cor. w.","dif.","tol.","dif./tol.");
for (i=1;i<=ntab;++i)
{
  printf("%6g %10g %12g %12g %5g %12g\n",
   nomf->v[i],nomA->v[i],
   dbamp(RA(fstd(i-21))),
   dbamp(RA(fstd(i-21)))-nomA->v[i],
   tol1max->v[i],
   (dbamp(RA(fstd(i-21)))-nomA->v[i])/tol1max->v[i]
   );
}
printf("\nB weighting:\n");
printf("Correction = %.12g db (amplitude factor %.12g).\n",
 nomB->v[21]-dbamp(RB0(fstd(0))),
 invdbamp( nomB->v[21]-dbamp(RB0(fstd(0))) ) );
printf("%6s %10s %12s %12s %5s %12s\n",
 "nom. f.","tab. w.","cor. w.","dif.","tol.","dif./tol.");
corB=invdbamp( nomB->v[21]-dbamp(RB0(fstd(0))) );
for (i=1;i<=ntab;++i)
{
  printf("%6g %10g %12g %12g %5g %12g\n",
   nomf->v[i],nomB->v[i],
   dbamp(RB(fstd(i-21))),
   dbamp(RB(fstd(i-21)))-nomB->v[i],
   tol1max->v[i],
   (dbamp(RB(fstd(i-21)))-nomB->v[i])/tol1max->v[i]
   );
}
printf("\nC weighting:\n");
printf("Correction = %.12g db (amplitude factor %.12g).\n",
 nomC->v[21]-dbamp(RC0(fstd(0))),
 invdbamp( nomC->v[21]-dbamp(RC0(fstd(0))) ) );
printf("%6s %10s %12s %12s %5s %12s\n",
 "nom. f.","tab. w.","cor. w.","dif.","tol.","dif./tol.");
corC=invdbamp( nomC->v[21]-dbamp(RC0(fstd(0))) );
for (i=1;i<=ntab;++i)
{
  printf("%6g %10g %12g %12g %5g %12g\n",
   nomf->v[i],nomC->v[i],
   dbamp(RC(fstd(i-21))),
   dbamp(RC(fstd(i-21)))-nomC->v[i],
   tol1max->v[i],
   (dbamp(RC(fstd(i-21)))-nomC->v[i])/tol1max->v[i]
   );
}
printf("\n\nLimits on octave band filters permeability:\n");
printf("%8s %10s %10s %10s %10s %10s %10s\n",
 "index","0min","0max","1min","1max","2min","2max");
for (i=1;i<=filtind->d;++i)
  printf("%8g %10g %10g %10g %10g %10g %10g\n",
   filtind->v[i],filt0min->v[i],filt0max->v[i],filt1min->v[i],filt1max->v[i],
   filt2min->v[i],filt2max->v[i]);
printf("\n\nLimits on third octave band filters permeability:\n");
printf("%8s %10s %10s %10s %10s %10s %10s %10s\n",
 "index","omega","0min","0max","1min","1max","2min","2max");
for (i=1;i<=filtind->d;++i)
  printf("%8g %10g %10g %10g %10g %10g %10g %10g\n",
   filtindthird->v[i],pow(2,filtindthird->v[i]),filt0min->v[i],filt0max->v[i],
   filt1min->v[i],filt1max->v[i],filt2min->v[i],filt2max->v[i]);
if (1)
{
  double ind;
  printf("\nPrints according to functions that return filter limits:\n");
  printf("\n\nLimits on octave band filters permeability:\n");
  printf("%-8s %10s %10s %10s %10s %10s %10s %10s\n",
   "index","omega","0min","0max","1min","1max","2min","2max");
  for (i=1;i<=filtind->d;++i)
  {
    ind=filtind->v[i];
    printf("%-8g %10g %10g %10g %10g %10g %10g %10g\n",
     ind,pow(2,ind),filt0min->v[i],filt0max->v[i],filtmin1(ind),
     filtmax1(ind),filt2min->v[i],filt2max->v[i]);
    if (i<filtind->d)
    {
      ind=0.5*(filtind->v[i]+filtind->v[i+1]);
      printf("  ");
      printf("%-8g %10g %10g %10g %10g %10g %10g %10g\n",
       ind,pow(2,ind),filt0min->v[i],filt0max->v[i],filtmin1(ind),
       filtmax1(ind),filt2min->v[i],filt2max->v[i]);
    }
  }
  printf("\n\nLimits on third octave band filters permeability:\n");
  printf("%-8s %10s %10s %10s %10s %10s %10s %10s\n",
   "index","omega","0min","0max","1min","1max","2min","2max");
  for (i=1;i<=filtind->d;++i)
  {
    ind=filtindthird->v[i];
    printf("%-8g %10g %10g %10g %10g %10g %10g %10g\n",
     ind,pow(2,ind),filt0min->v[i],filt0max->v[i],
     filtminthird1(ind),filtmaxthird1(ind),filt2min->v[i],filt2max->v[i]);
    if (i<filtind->d)
    {
      ind=0.5*(filtindthird->v[i]+filtindthird->v[i+1]);
      printf("  ");
      printf("%-8g %10g %10g %10g %10g %10g %10g %10g\n",
       ind,pow(2,ind),filt0min->v[i],filt0max->v[i],
       filtminthird1(ind),filtmaxthird1(ind),filt2min->v[i],filt2max->v[i]);
    }
  }
}
if (0)
{
  drawfuncsimp(filtmax1,filtmin1plot,NULL,-5,5,6*5+1+6*5*7);
  drawfuncsimp(filtmaxthird1,filtminthird1plot,NULL,-5,5,6*5+1+6*5*7);
  drawfuncsimp(filtmaxthird1,filtmax1,NULL,-5,5,6*5+1+6*5*7);
}
printf("\n\n");
}


static void readdata(char *filename)
    /* Branje tabelaricnih podatkov iz datoteke; filename je ime datoteke, kjer
    naj funkcija isce podatke.
    $A Igor jan01; */
{
FILE *fp;
long pos1;
int l,i,er=0;
const int ntab=34,nfilt=10;
int ntab1,nfilt1;
double x;
/* Alokacija vektorjev: */
nomf=getvector(ntab);
nomA=getvector(ntab);
nomB=getvector(ntab);
nomC=getvector(ntab);
tol0min=getvector(ntab);
tol0max=getvector(ntab);
tol1min=getvector(ntab);
tol1max=getvector(ntab);
tol2min=getvector(ntab);
tol2max=getvector(ntab);
filt0min=getvector(nfilt);
filt0max=getvector(nfilt);
filtind=getvector(nfilt);
filtindthird=getvector(nfilt);
filt1min=getvector(nfilt);
filt1max=getvector(nfilt);
filt2min=getvector(nfilt);
filt2max=getvector(nfilt);
fp=fopensafe(filename,"rb");
if (fp==NULL)
{
  errfunc0("readdata");
  fprintf(erf(),"Could not open the data file.\n");
  errfunc2();
} else
{
  /* Branje podatkov; najprej iskanje 1. tabele in branje iz nje: */
  pos1=filestring(fp,"weight",1,1000);
  if (pos1<1) ++er;
  pos1=filestring(fp,"data",pos1,100);
  if (pos1<1) ++er;
  pos1=filechar(fp,"\n\r",2,pos1,10);
  if (pos1<1) ++er;
  /* Branje nominalnih frekvenc in utezi v decibelih: */
  for (i=1;i<=ntab;++i)
  {
    x=filenum(fp,pos1,30,&pos1,&l);
    if (pos1<1) ++er; pos1+=l;
    if (i-x!=21) ++er;
    x=filenum(fp,pos1,30,&pos1,&l);  nomf->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  nomA->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  nomB->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  nomC->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
  }
  
  pos1=filestring(fp,"toler",pos1,1000);
  if (pos1<1) ++er;
  pos1=filestring(fp,"data",pos1,100);
  if (pos1<1) ++er;
  pos1=filechar(fp,"\n\r",2,pos1,10);
  if (pos1<1) ++er;
  /* Branje toleranc v decibelih: */
  for (i=1;i<=ntab;++i)
  {
    x=filenum(fp,pos1,30,&pos1,&l);
    if (pos1<1) ++er; pos1+=l;
    if (i-x!=21) ++er;
    x=filenum(fp,pos1,30,&pos1,&l);  tol0min->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  tol0max->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  tol1min->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  tol1max->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  tol2min->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  tol2max->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
  }
  
  pos1=filestring(fp,"filter lim",pos1,1000);
  if (pos1<1) ++er;
  pos1=filestring(fp,"data",pos1,100);
  if (pos1<1) ++er;
  nfilt1=filenum(fp,pos1+strlen("data"),30,&pos1,&l);
  if (nfilt1!=nfilt) ++er;
  pos1=filechar(fp,"\n\r",2,pos1,10);
  if (pos1<1) ++er;
  /* Branje spodnjih in zgornjih mej dusenja filtrov (pozitivna veja): */
  for (i=1;i<=nfilt;++i)
  {
    x=filenum(fp,pos1,30,&pos1,&l);  filtind->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  filt0min->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  filt0max->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  filt1min->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  filt1max->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  filt2min->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
    x=filenum(fp,pos1,30,&pos1,&l);  filt2max->v[i]=x;
    if (pos1<1) ++er; pos1+=l;
  }
  if (filtind!=NULL && filtindthird!=NULL) for (i=1;i<=nfilt;++i)
  {
    double G=2.0,K;
    /* Racunanje prelomnih indeksov za meje prepustnosti pri tretjinskooktavnih
    filtrih: */
    K=filtind->v[i];   /* ustrez. indeks za oktav. filter */
    /*
    printf("(pow(G,K)-1)*(pow(G,1/(2*3))-1)/(pow(G,0.5)-1) : %g\n",(pow(G,K)-1)*(pow(G,1/(2*3))-1)/(pow(G,0.5)-1));
    printf("(pow(G,K)-1) : %g\n",(pow(G,K)-1) );
    printf("(pow(G,(double) 1/(2*3))-1) : %g\n",(pow(G,(double) 1/(2*3))-1) );
    */
    filtindthird->v[i]=ln(1+ (pow(G,K)-1)*(pow(G,(double) 1/(2*3))-1)/(pow(G,0.5)-1) ) /ln(G);
    printf("i:%i, indokt:%g, indthird:%g\n",i,K,filtindthird->v[i]);
  }
}
fclose(fp);
if (er)
{
  errfunc0("readdata");
  fprintf(erf(),"Data is not in teh right format, %i errors detectet.\n",er);
  errfunc2();
}
}










static double objective(vector par)
{
vector samp=NULL;
double r,rcent,di;
double erA=0,erB=0,erC=0;

double klow=-0.45,khigh=0.45,kfact=1,kcum,space=0.05,num=4,step;
double s1=1,s2=1,s3=1,s4=1,s5=1,s6=1,s7=1,s8=1,s9=1,s10=1,balance=0;
double r1=-0.4,r2=-.35,r3=-.25,r4=-.15,r5=-.005,r6=.005,r7=.15,r8=.25,r9=.35,r10=.4,
       h1=0.05,h2=0.1,h3=0.1,h4=0.1,h5=0.1,h6=0.1,h7=0.1,h8=0.1,h9=0.1,h10=0.05,
       rbalance=0,shift=0,k1=-0.5,k2=-0.5,k3=-0.5,k4=-0.5,k5=-100,k6=-100;

int numbits;
double range;

static int numit=1;
double maxer=0;
double ret=-1000,chi2=0;
char minmax=1;  /* ce je 1, je namen. funkcija maks. napaka, drugace pa hi kvadrat */

setoptweightcor();  /* Optimalni korekcijski faktorji za filtre A, B, C */

++numit;
printf("\n\n==========================\n%i. iteration:\n\n",numit);
printf("parameters:\n");
printvector(par);
printf("\n\n");

/* Za optimizacijo korekcijskih faktorjev za filtre: */
roundsamples=0;    smoothsamples=0;

/* Antialiasni filter: */
setoptweightcor();

/*
corl1f=par->v[1];
corl2f=par->v[2];
corh3f=par->v[3];
corh4f=par->v[4];

corh5f=par->v[5];
corh6f=par->v[6];
corh7f=par->v[7];
*/

/*
corl1f+=par->v[1];
corl2f+=par->v[2];
corh3f+=par->v[3];
corh4f+=par->v[4];
*/

/*
if (par->v[1]<2) par->v[1]=2;
if (par->v[2]<2) par->v[2]=2;
if (par->v[3]<2) par->v[3]=2;
if (par->v[4]<2) par->v[4]=2;
if (par->v[5]<2) par->v[5]=2;
if (par->v[6]<2) par->v[6]=2;
*/

/* Iskanje frekvenc filtrov za utezevanje iz nicle: */
/*
fhigh1=par->v[1];
fhigh2=par->v[2];
flow3=par->v[3];
flow4=par->v[4];
flow6=par->v[5];
flow7=par->v[6];
*/


/*
corh5f=par->v[5];
corh6f=par->v[6];
corh7f=par->v[7];
*/

fprintdigcor(stdout);

/* Za desetparametricno optimizacijo faktorjev glajenja: */
/*
roundsamples=1;    smoothsamples=1;
numbits=11;
numtestamp=1;
range=1;
setroundsignfixbit(range,numbits);
sm1=sm2=sm3=sm4=sm5=sm6=sm7=sm8=sm9=sm10=0; smfac=1;
sm0=1;
smfac=par->v[1];
sm1=par->v[2];
sm2=par->v[3];
sm3=par->v[4];
sm4=par->v[5];
sm5=par->v[6];
sm6=par->v[7];
sm7=par->v[8];
sm8=par->v[9];
sm9=par->v[10];
sm10=par->v[11];

corl1f=0.308381+par->v[12];
corl2f=0.421121+par->v[13];
corh3f=-0.0313729+par->v[14];
corh4f=0.0498406+par->v[15];
*/


/*
sm9=par->v[9];
sm10=par->v[10];
printsmoothpar();
*/


/* Za oktavne filtre: */
/*
k1=-0.5; k2=-0.5;
k3=0;   k4=0;
k5=0.5; k6=0.5;
h1=h2=h3=h4=h5=h6=h7=h8=h9=h10=0;
r1=par->v[1];
h1=par->v[2];
r2=par->v[3];
h2=par->v[4];
r3=par->v[5];
h3=par->v[6];
r4=par->v[7];
h4=par->v[8];
shift=par->v[9];
*/

/*
s1=par->v[1];
s2=par->v[2];
s3=par->v[3];
s4=par->v[4];
s5=par->v[5];
s6=par->v[6];
s7=par->v[7];
s8=par->v[8];
s9=par->v[9];
s10=par->v[10];
balance=par->v[11];
shift=par->v[12];
ord1=ord2=ord3=ord4=ord5=ord6=ord7=ord8=ord9=ord10=2;
ord1=ord2=ord3=ord4=ord5=ord6=ord7=1;

cfa0=par->v[1];
cfa1=par->v[2];
cfa2=par->v[3];
cfa3=par->v[4];
cfa4=par->v[5];
cfa5=par->v[6];
cfb1=par->v[7];
cfb2=par->v[8];
cfb3=par->v[9];
cfb4=par->v[10];
cfb5=par->v[11];
*/



/* Oktavni filt. iz dveh resonancnih in dveh zrcalno resonancnih: */

/*
r3=r4=r5=0;
r8=r9=r10=0;
h3=h4=h5=0;
h8=h9=h10=0;

r1=par->v[1];
h1=par->v[2];
r2=par->v[3];
h2=par->v[4];
r6=par->v[5];
h6=par->v[6];
r7=par->v[7];
h7=par->v[8];
shift=par->v[9];
*/

/* Pasovni filt. iz treh resonancnih in treh zrcalno resonancnih: */


/*
r3=r4=r5=0;
r8=r9=r10=0;
h3=h4=h5=0;
h8=h9=h10=0;

r1=par->v[1];
h1=par->v[2];
r2=par->v[3];
h2=par->v[4];
r3=par->v[5];
h3=par->v[6];

r6=par->v[7];
h6=par->v[8];
r7=par->v[9];
h7=par->v[10];
r8=par->v[11];
h8=par->v[12];

shift=par->v[13];
*/



/* Pasovni filt. iz stirih resonancnih in stirih zrcalno resonancnih: */
/*
r3=r4=r5=0;
r8=r9=r10=0;
h3=h4=h5=0;
h8=h9=h10=0;

r1=par->v[1];
h1=par->v[2];
r2=par->v[3];
h2=par->v[4];
r3=par->v[5];
h3=par->v[6];
r4=par->v[7];
h4=par->v[8];

r6=par->v[9];
h6=par->v[10];
r7=par->v[11];
h7=par->v[12];
r8=par->v[13];
h8=par->v[14];
r9=par->v[15];
h9=par->v[16];

shift=par->v[17];
*/



if (1)
{
  Ts=1e-5;
  /* Ts=1/(double) 48000; */
  
  if (0)
  {
    printf("\nLimited representation (0/1) "); readint(&roundsamples);
    if (roundsamples)
    {
      printf("Amplitude: "); readdouble(&numtestamp);
      printf("Number of bits: "); readint(&numbits);
      printf("range: "); readdouble(&range);
      setroundsignfixbit(range,numbits);
    }
    readsmoothpar();
  }
  
  if (0) readdigcor();
  
  if (0)
  {
  printf("\n\nAdjust frequencies:\n");
  printf("fhigh1: "); readdouble(&fhigh1);
  printf("fhigh2: "); readdouble(&fhigh2);
  printf("flow3: ");  readdouble(&flow3);
  printf("flow4: ");  readdouble(&flow4);
  }
  


  if (0)   /* oktavni filter */
  {
  vector respan=NULL,respnum=NULL,resper=NULL,respmin=NULL,respmax=NULL;
  double draw=1,di,i,ii,k,ran,rnum,f,normf,fcent=62.5/2;
  double cor,er,ermin,ermax,maxer=-100;
  int ivec=1;
  double ifrom=-2.0,ito=1.25;  /* obseg frekvenc */
  double div=6;          /* stevilo razdelkov pri frekvencah */
  
  setzeroweightcor();
  
  respan=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  respnum=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  resper=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  respmin=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  respmax=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  
  flow1=flow2=flow3=flow4=707.1067812;
  fhigh1=fhigh2=fhigh3=fhigh4=1414.213562;
  
  fhigh1=flow1=900.896;
  fhigh2=flow2=1189.21;
  fhigh3=flow3=807.107;
  fhigh4=flow4=1414.21;
  fhigh5=flow5=1414.21;
  fhigh6=flow6=1414.21;
  
  num=6;
  /*
  printf("klow: "); readdouble(&klow);
  printf("khigh: "); readdouble(&khigh);
  printf("progressive factor (normally less than 1): "); readdouble(&kfact);
  printf("space: "); readdouble(&space);
  step=(khigh-klow)/(num-1);
  */
    
  
  if (((int)num)%2==0)
  {
    step=1;
    kcum=0.5*step;
    for (i=1;i<num/2;++i)
    {
      step*=kfact;
      kcum+=step;
    }
    step=1/kcum;
    kcum=0.5*step;
    /* 1. negativen k: */
    k=kcum*klow;
    flow1=fcent*pow(2,k-space/2); fhigh1=fcent*pow(2,k+space/2);
    /* 1. pozitiven k: */
    k=kcum*khigh;
    flow2=fcent*pow(2,k-space/2); fhigh2=fcent*pow(2,k+space/2);
    step*=kfact;
    kcum+=step;
    /* 2. negativen k: */
    k=kcum*klow;
    flow3=fcent*pow(2,k-space/2); fhigh3=fcent*pow(2,k+space/2);
    /* 2. pozitiven k: */
    k=kcum*khigh;
    flow4=fcent*pow(2,k-space/2); fhigh4=fcent*pow(2,k+space/2);
    step*=kfact;
    kcum+=step;
    /* 3. negativen k: */
    k=kcum*klow;
    flow5=fcent*pow(2,k-space/2); fhigh5=fcent*pow(2,k+space/2);
    /* 3. pozitiven k: */
    k=kcum*khigh;
    flow6=fcent*pow(2,k-space/2); fhigh6=fcent*pow(2,k+space/2);
  }
  
  printf("\nbalance=%g\ns1=%g\ns2=%g\ns3=%g\ns4=%g\ns5=%g\ns6=%g\n\n",
   balance,s1,s2,s3,s4,s5,s6);
  printf("ord1=%g\nord2=%g\nord3=%g\nord4=%g\nord5=%g\nord6=%g\n\n",
   ord1,ord2,ord3,ord4,ord5,ord6);
  
  if (0)  /* za filter band10 */
  {
    printf("balance: "); readdouble(&balance);
    printf("s1: "); readdouble(&s1);
    printf("s2: "); readdouble(&s2);
    printf("s3: "); readdouble(&s3);
    printf("s4: "); readdouble(&s4);
    printf("s5: "); readdouble(&s5);
    printf("s6: "); readdouble(&s6);
    printf("s7: "); readdouble(&s7);
    printf("s8: "); readdouble(&s8);
  
    printf("ord. 1: "); readdouble(&ord1);
    printf("ord. 2: "); readdouble(&ord2);
    printf("ord. 3: "); readdouble(&ord3);
    printf("ord. 4: "); readdouble(&ord4);
    printf("ord. 5: "); readdouble(&ord5);
    printf("ord. 6: "); readdouble(&ord6);
    printf("ord. 7: "); readdouble(&ord7);
    printf("ord. 8: "); readdouble(&ord8);
  
    flow1=fcent*pow(2,balance-s1);  fhigh1=fcent*pow(2,balance+s1);
    flow2=fcent*pow(2,balance-s2);  fhigh2=fcent*pow(2,balance+s2);
    flow3=fcent*pow(2,balance-s3);  fhigh3=fcent*pow(2,balance+s3);
    flow4=fcent*pow(2,balance-s4);  fhigh4=fcent*pow(2,balance+s4);
    flow5=fcent*pow(2,balance-s5);  fhigh5=fcent*pow(2,balance+s5);
    flow6=fcent*pow(2,balance-s6);  fhigh6=fcent*pow(2,balance+s6);
    flow7=fcent*pow(2,balance-s7);  fhigh7=fcent*pow(2,balance+s7);
    flow8=fcent*pow(2,balance-s8);  fhigh8=fcent*pow(2,balance+s8);
  
    printf("\nbalance=%g\ns1=%g\ns2=%g\ns3=%g\ns4=%g\ns5=%g\ns6=%g\ns7=%g\ns8=%g\n\n",
     balance,s1,s2,s3,s4,s5,s6,s7,s8);
    printf("ord1=%g\nord2=%g\nord3=%g\nord4=%g\nord5=%g\nord6=%g\nord7=%g\nord8=%g\n\n",
     ord1,ord2,ord3,ord4,ord5,ord6,ord7,ord8);
  
    printf("flow1 = %-10g, fhigh1 = %g\n",flow1,fhigh1);
    printf("flow2 = %-10g, fhigh2 = %g\n",flow2,fhigh2);
    printf("flow3 = %-10g, fhigh3 = %g\n",flow3,fhigh3);
    printf("flow4 = %-10g, fhigh4 = %g\n",flow4,fhigh4);
    printf("flow5 = %-10g, fhigh5 = %g\n",flow5,fhigh5);
    printf("flow6 = %-10g, fhigh6 = %g\n",flow6,fhigh6);
    printf("flow7 = %-10g, fhigh7 = %g\n",flow7,fhigh7);
    printf("flow8 = %-10g, fhigh8 = %g\n",flow8,fhigh8);
    printf("\n");
  }
  
  if (0) /* za filter res10high6 */
  {
    printf("\nbalance=%g\nr1=%g\nr2=%g\nr3=%g\nr4=%g\nr5=%g\nr6=%g\nr7=%g\nr8=%g\nr9=%g\nr10=%g\n\n",
     rbalance,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10);
    printf("h1=%g\nh2=%g\nh3=%g\nh4=%g\nh5=%g\nh6=%g\nh7=%g\nh8=%g\nh9=%g\nh10=%g\n\n",
     h1,h2,h3,h4,h5,h6,h7,h8,h9,h10);
    
    printf("Insert data for multiple resonance filter!\n");
    printf("balance: "); readdouble(&rbalance);
    printf("r1: "); readdouble(&r1);
    printf("r2: "); readdouble(&r2);
    printf("r3: "); readdouble(&r3);
    printf("r4: "); readdouble(&r4);
    printf("r5: "); readdouble(&r5);
    printf("r6: "); readdouble(&r6);
    printf("r7: "); readdouble(&r7);
    printf("r8: "); readdouble(&r8);
    printf("r9: "); readdouble(&r9);
    printf("r10: "); readdouble(&r10);
  
    printf("\nhr 1: "); readdouble(&h1);
    printf("hr 2: "); readdouble(&h2);
    printf("hr 3: "); readdouble(&h3);
    printf("hr 4: "); readdouble(&h4);
    printf("hr 5: "); readdouble(&h5);
    printf("hr 6: "); readdouble(&h6);
    printf("hr 7: "); readdouble(&h7);
    printf("hr 8: "); readdouble(&h8);
    printf("hr 9: "); readdouble(&h9);
    printf("hr 10: "); readdouble(&h10);
    
    hres1=h1; hres2=h2; hres3=h3; hres4=h4; hres5=h5; hres6=h6; hres7=h7;
    hres8=h8; hres9=h9; hres10=h10;
    
    
    fres1=fcent*pow(2,rbalance+r1);
    fres2=fcent*pow(2,rbalance+r2);
    fres3=fcent*pow(2,rbalance+r3);
    fres4=fcent*pow(2,rbalance+r4);
    fres5=fcent*pow(2,rbalance+r5);
    fres6=fcent*pow(2,rbalance+r6);
    fres7=fcent*pow(2,rbalance+r7);
    fres8=fcent*pow(2,rbalance+r8);
    fres9=fcent*pow(2,rbalance+r9);
    fres10=fcent*pow(2,rbalance+r10);
    
    printf("\nbalance=%g\nr1=%g\nr2=%g\nr3=%g\nr4=%g\nr5=%g\nr6=%g\nr7=%g\nr8=%g\nr9=%g\nr10=%g\n\n",
     rbalance,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10);
    printf("h1=%g\nh2=%g\nh3=%g\nh4=%g\nh5=%g\nh6=%g\nh7=%g\nh8=%g\nh9=%g\nh10=%g\n\n",
     h1,h2,h3,h4,h5,h6,h7,h8,h9,h10);
    
    printf("fcent=%g.\n",fcent);
    printf("fres1 = %-10g, hres1 = %g,\nfres2 = %-10g, hres2 = %g\n",
     fres1,hres1,fres2,hres2);
    printf("fres3 = %-10g, hres3 = %g,\nfres4 = %-10g, hres4 = %g\n",
     fres3,hres3,fres4,hres4);
    printf("fres5 = %-10g, hres5 = %g,\nfres6 = %-10g, hres6 = %g\n",
     fres5,hres5,fres6,hres6);
    printf("fres7 = %-10g, hres7 = %g,\nfres8 = %-10g, hres8 = %g\n",
     fres7,hres7,fres8,hres8);
    printf("fres9 = %-10g, hres9 = %g,\nfres10 = %-10g, hres10 = %g\n",
     fres9,hres9,fres10,hres10);
    
    printf("shift: "); readdouble(&shift);
    printf("Par. for high pass filters:\n");
    printf("k1: ");  readdouble(&k1);
    printf("k2: ");  readdouble(&k2);
    printf("k3: ");  readdouble(&k3);
    printf("k4: ");  readdouble(&k4);
    flow1=fcent*pow(2,k1);
    flow2=fcent*pow(2,k2);
    flow3=fcent*pow(2,k3);
    flow4=fcent*pow(2,k4);
    printf("flow1 = %g\nflow2 = %g\nflow3 = %g\nflow4 = %g\n\n",
     flow1,flow2,flow3,flow4);
  }
  
  if (0) /* za filter res10high6 */
  {
  
    fres1=fcent*pow(2,rbalance+r1);
    fres2=fcent*pow(2,rbalance+r2);
    fres3=fcent*pow(2,rbalance+r3);
    fres4=fcent*pow(2,rbalance+r4);
    fres5=fcent*pow(2,rbalance+r5);
    fres6=fcent*pow(2,rbalance+r6);
    fres7=fcent*pow(2,rbalance+r7);
    fres8=fcent*pow(2,rbalance+r8);
    fres9=fcent*pow(2,rbalance+r9);
    fres10=fcent*pow(2,rbalance+r10);
    hres1=h1; hres2=h2; hres3=h3; hres4=h4; hres5=h5; hres6=h6; hres7=h7;
    hres8=h8; hres9=h9; hres10=h10;
    
    printf("\nbalance=%g\nr1=%g\nr2=%g\nr3=%g\nr4=%g\nr5=%g\nr6=%g\nr7=%g\nr8=%g\nr9=%g\nr10=%g\n\n",
     rbalance,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10);
    printf("h1=%g\nh2=%g\nh3=%g\nh4=%g\nh5=%g\nh6=%g\nh7=%g\nh8=%g\nh9=%g\nh10=%g\n\n",
     h1,h2,h3,h4,h5,h6,h7,h8,h9,h10);
    
    flow1=fcent*pow(2,k1);
    flow2=fcent*pow(2,k2);
    flow3=fcent*pow(2,k3);
    flow4=fcent*pow(2,k4);
    flow5=fcent*pow(2,k5);
    flow6=fcent*pow(2,k6);
    if (k1<=-10) flow1=0;
    if (k2<=-10) flow2=0;
    if (k3<=-10) flow3=0;
    if (k4<=-10) flow4=0;
    if (k5<=-10) flow5=0;
    if (k6<=-10) flow6=0;
    
    printf("k1=%g\nk2=%g\nk3=%g\nk4=%g\nk5=%g\nk6=%g\n",k1,k2,k3,k4,k5,k6);
    printf("shift = %g\n\n",shift);
    printf("flow1 = %g\nflow2 = %g\nflow3 = %g\nflow4 = %g\nflow5 = %g\nflow6 = %g\n\n",
     flow1,flow2,flow3,flow4,flow5,flow6);
  
    printf("fcent=%g.\n",fcent);
    printf("fres1 = %-10g, hres1 = %g,\nfres2 = %-10g, hres2 = %g\n",
     fres1,hres1,fres2,hres2);
    printf("fres3 = %-10g, hres3 = %g,\nfres4 = %-10g, hres4 = %g\n",
     fres3,hres3,fres4,hres4);
    printf("fres5 = %-10g, hres5 = %g,\nfres6 = %-10g, hres6 = %g\n",
     fres5,hres5,fres6,hres6);
    printf("fres7 = %-10g, hres7 = %g,\nfres8 = %-10g, hres8 = %g\n",
     fres7,hres7,fres8,hres8);
    printf("fres9 = %-10g, hres9 = %g,\nfres10 = %-10g, hres10 = %g\n",
     fres9,hres9,fres10,hres10);
  }
  
  if (0) /* filter band10 */
  {
    
    flow1=fcent*pow(2,balance-s1);  fhigh1=fcent*pow(2,balance+s1);
    flow2=fcent*pow(2,balance-s2);  fhigh2=fcent*pow(2,balance+s2);
    flow3=fcent*pow(2,balance-s3);  fhigh3=fcent*pow(2,balance+s3);
    flow4=fcent*pow(2,balance-s4);  fhigh4=fcent*pow(2,balance+s4);
    flow5=fcent*pow(2,balance-s5);  fhigh5=fcent*pow(2,balance+s5);
    flow6=fcent*pow(2,balance-s6);  fhigh6=fcent*pow(2,balance+s6);
    flow7=fcent*pow(2,balance-s7);  fhigh7=fcent*pow(2,balance+s7);
    flow8=fcent*pow(2,balance-s8);  fhigh8=fcent*pow(2,balance+s8);
    flow9=fcent*pow(2,balance-s9);  fhigh9=fcent*pow(2,balance+s9);
    flow10=fcent*pow(2,balance-s10);  fhigh10=fcent*pow(2,balance+s10);
  
    printf("\nbalance=%g\nshift=%g\ns1=%g\ns2=%g\ns3=%g\ns4=%g\ns5=%g\ns6=%g\ns7=%g\ns8=%g\ns9=%g\ns10=%g\n\n",
     balance,shift,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10);
    printf("ord1=%g\nord2=%g\nord3=%g\nord4=%g\nord5=%g\nord6=%g\nord7=%g\nord8=%g\nord9=%g\nord10=%g\n\n",
     ord1,ord2,ord3,ord4,ord5,ord6,ord7,ord8,ord9,ord10);
  
    printf("flow1 = %-10g, fhigh1 = %g\n",flow1,fhigh1);
    printf("flow2 = %-10g, fhigh2 = %g\n",flow2,fhigh2);
    printf("flow3 = %-10g, fhigh3 = %g\n",flow3,fhigh3);
    printf("flow4 = %-10g, fhigh4 = %g\n",flow4,fhigh4);
    printf("flow5 = %-10g, fhigh5 = %g\n",flow5,fhigh5);
    printf("flow6 = %-10g, fhigh6 = %g\n",flow6,fhigh6);
    printf("flow7 = %-10g, fhigh7 = %g\n",flow7,fhigh7);
    printf("flow8 = %-10g, fhigh8 = %g\n",flow8,fhigh8);
    printf("flow9 = %-10g, fhigh9 = %g\n",flow9,fhigh9);
    printf("flow10 = %-10g, fhigh10 = %g\n",flow10,fhigh10);
    printf("\n");
  }

  if (1)  /* Za filter ressym10 */
  {
    hres1=h1;  hres2=h2;  hres3=h3;  hres4=h4;  hres5=h5;
    hres6=h6;  hres7=h7;  hres8=h8;  hres9=h9;  hres10=h10;
    fres1=fcent*pow(2,r1);
    fres2=fcent*pow(2,r2);
    fres3=fcent*pow(2,r3);
    fres4=fcent*pow(2,r4);
    fres6=fcent*pow(2,r6);
    fres7=fcent*pow(2,r7);
    fres8=fcent*pow(2,r8);
    fres9=fcent*pow(2,r9);
    
    printf("\n\nr1: %g  \nh1: %g\n",r1,h1);
    printf("\nr2: %g  \nh2: %g\n",r2,h2);
    printf("\nr3: %g  \nh3: %g\n",r3,h3);
    printf("\nr4: %g  \nh4: %g\n",r4,h4);
    printf("\nr6: %g  \nh6: %g\n",r6,h6);
    printf("\nr7: %g  \nh7: %g\n",r7,h7);
    printf("\nr8: %g  \nh8: %g\n",r8,h8);
    printf("\nr9: %g  \nh9: %g\n",r9,h9);
    
    printf("\n\nr3: %g  \nh3: %g\n",r3,h3);
    printf("\nr4: %g  \nh4: %g\n",r4,h4);
    printf("\nr5: %g  \nh5: %g\n",r5,h5);
    printf("\nr8: %g  \nh8: %g\n",r8,h8);
    printf("\nr9: %g  \nh9: %g\n",r9,h9);
    printf("\nr10: %g  \nh10: %g\n",r10,h10);
  }
  

  
  printf("\n\nResponse of  digital (numerical) band filter, f0=%gHz.\n",fcent);
  
  /*
  printf("\n\nfres: "); readdouble(&fres);
  printf("hres: "); readdouble(&hres);
  */
  
  printf(" %9s %12s %12s %12s %12s %10s\n","norm. f","f [Hz]",
  "num. dig.","low. lim.","up. lim.","---");
  for (di=ifrom*8;di<=ito*8;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ii=i;
      normf=i/8;  /* Normalizirana frekvenca */
      f=fcent*pow(2,normf);
      i=invfstd(f);
      /* f=fstdcont(i); */
      /*
      ran=dbamp(ampres(f,fres,hres));
      rnum=respresdignum(i);
      */
      
      
      /*
      rnum=respband10dignum(i);
      */
      
      /*
      rnum=respband10an(i);
      */
      
      /*
      rnum=respres10an(i)+dbamp(amphigh(f,flow1))+dbamp(amphigh(f,flow2))
           +dbamp(amphigh(f,flow3))+dbamp(amphigh(f,flow4));
      */
      
      /*
      rnum=respres10high6dignum(i);
      */
      /*
      rnum=respgen5dignum(i);
      */
      
      /*
      freshigh1=fcent; printf("Warning: Low pass at fcent (%g Hz) is added!\n",fcent);
      freshigh1=freshigh2=fcent; printf("Warning: Double low pass at fcent (%g Hz) is added!\n",fcent);
      */
      
      
      rnum=respressym10dignum(i);
      
      
      /* Varnostni ventil, ce da odziv nedefinirano stevilo: */
      if (!(rnum<1e6 && rnum>-1e6))
      {
        rnum=1000;
        ermax=100000;
      }
      
      if (ii==0)
        cor=-rnum+filtmaxthird1(0);  /* egzaktna korekcija pri centralni frekvenci */
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %12g %12g %10g\n", normf,
       f,rnum,filtminthird1(normf),filtmaxthird1(normf),0,0 );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %10s - %10s %9s %9s  %-8s\n","norm. f","f [Hz]",
  "num. dig.","low. lim.","up. lim.","errmin","errmax","error");
  ivec=1;
  for (di=ifrom*8;di<=ito*8;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      normf=i/8;  /* Normalizirana frekvenca */
      f=fcent*pow(2,normf);
      respnum->v[ivec]+=cor+shift;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      ermax=rnum-filtmaxthird1(normf);
      ermin=filtminthird1(normf)-rnum;
      if (ermax>ermin)
        er=ermax;
      else
        er=ermin;
      if (er>maxer)
        maxer=er;
      resper->v[ivec]=er;
      respmin->v[ivec]=filtminthird1plot(normf);
      respmax->v[ivec]=filtmaxthird1(normf);
      if (k==0)
        printf("*");
      else
        printf(" ");
      
      printf("%9g %12g %12g %10g - %-10g %9.3g %9.3g  %-8.5g\n", normf,
       f,rnum,filtminthird1(normf),filtmaxthird1(normf),ermin,ermax,er);
      
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corC);
  
  
  if (1)  /* Izpis parametrov filtra: */
  {
    printf("\n\nfcent: %g\n",fcent);
    
    printf("\nr1: %g  \nh1: %g\n",r1,h1);
    printf("\nr2: %g  \nh2: %g\n",r2,h2);
    printf("\nr3: %g  \nh3: %g\n",r3,h3);
    /* printf("\nr4: %g  \nh4: %g\n",r4,h4); */
    printf("\nr6: %g  \nh6: %g\n",r6,h6);
    printf("\nr7: %g  \nh7: %g\n",r7,h7);
    printf("\nr8: %g  \nh8: %g\n",r8,h8);
    /* printf("\nr9: %g  \nh9: %g\n",r9,h9); */
  }
  
  printf("\n\nTOTAL correction: %g db, amp. factor %g \n",
   cor+shift,invdbamp(cor+shift));
  printf("\nShift: %g db, amp. factor %g\n",shift,invdbamp(shift));
  
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erC=maxer;
  if (maxer>ret)
    ret=maxer;
  printf("\n\n");
  /*
  plotvector(respnum,NULL,NULL,0,NULL);
  printf("Draw graph? "); readdouble(&draw);
  */
  if (1)
  {
    plotvectorcont(respnum,respmin,respmax,0,NULL);
    /*
    printf("\nError:\n");
    plotvector(resper,NULL,NULL,0,NULL);
    */
  }
  
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  dispvector(&resper); dispvector(&respmin); dispvector(&respmax);
  }


  
  
  if (1)   /* filter C */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,voidvar=0;
  int ivec=1;
  int ifrom=-20,ito=13;  /* obseg frekvenc */
  double div=1;          /* stevilo razdelkov pri frekvencah */
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) C filter, f0 = %g, Ts=%g.\n",fhigh,Ts);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=respCth(i);
      rnum=respCdignum(i);
      /* Antialias filter: */
      if (antialias) 
        rnum+=dbamp(amplow(fstdcont(i),falias1))+
              dbamp(amplow(fstdcont(i),falias2));
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if (er<0)
        er/=tol1min->v[(int) di+21];
      else
        er/=tol1max->v[(int) di+21];
      er=fabs(er);
      chi2+=sqr(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corC);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  if (maxer>ret)
    ret=maxer;
  erC=maxer;
  printf("\n\n");
  plotvectorcont(respnum,respan,NULL,0,NULL);
  if (0) plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
  
  
  if (1)  /* filter B */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,voidvar=0;
  int ivec=1;
  int ifrom=-20,ito=13;  /* obseg frekvenc */
  double div=1;          /* stevilo razdelkov pri frekvencah */
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) B filter, f0 = %g.\n",fhigh);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=respBth(i);
      rnum=respBdignum(i);
      /* Antialias filter: */
      if (antialias) 
        rnum+=dbamp(amplow(fstdcont(i),falias1))+
              dbamp(amplow(fstdcont(i),falias2));
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if (er<0)
        er/=tol1min->v[(int) di+21];
      else
        er/=tol1max->v[(int) di+21];
      er=fabs(er);
      chi2+=sqr(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corB);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  if (maxer>ret)
    ret=maxer;
  erB=maxer;
  printf("\n\n");
  plotvectorcont(respnum,respan,NULL,0,NULL);
  if (0) plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
  if (1)   /* filter A */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,voidvar=0;
  int ivec=1;
  int ifrom=-20,ito=13;  /* obseg frekvenc */
  double div=1;          /* stevilo razdelkov pri frekvencah */
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) A filter, f0 = %g.\n",fhigh);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=respAth(i);
      rnum=respAdignum(i);
      /* Antialias filter: */
      if (antialias) 
        rnum+=dbamp(amplow(fstdcont(i),falias1))+
              dbamp(amplow(fstdcont(i),falias2));
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if ((int) di+21<=34)
      {
        if (er<0)
          er/=tol1min->v[(int) di+21];
        else
          er/=tol1max->v[(int) di+21];
      } else  /* Za primer, ko upostevamo tudi visje frekvence od 20 kHz */
      {
        if (er<0)
          er/=tol1min->v[34];
        else
          er/=tol1max->v[34];
      }
      er=fabs(er);
      chi2+=sqr(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corA);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  if (maxer>ret)
    ret=maxer;
  erA=maxer;
  printf("\n\n");
  plotvectorcont(respnum,respan,NULL,0,NULL);
  if (0) plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
  printf("\n\nerA=%g, erB=%g, erC=%g.\n\n",erA,erB,erC);
   
  if (0)   /* low pass filter */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,voidvar=0;
  int ivec=1;
  int ifrom=-20,ito=13;  /* obseg frekvenc */
  double div=1;          /* stevilo razdelkov pri frekvencah */
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) low pass filter, f0 = %g, f0=%g.\n",fhigh,fhigh2);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=resplow(i);
      rnum=resplow2dignum(i);
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      cor=0;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if (er<0)
        er/=tol1min->v[(int) di+21];
      else
        er/=tol1max->v[(int) di+21];
      er=fabs(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corA);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erA=maxer;
  printf("\n\n");
  if (0) plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
 
  
  if (0)   /* high pass filter */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,voidvar=0;
  int ivec=1;
  int ifrom=-20,ito=13;  /* obseg frekvenc */
  double div=1;          /* stevilo razdelkov pri frekvencah */
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) high parr filter, f0 = %g, f0=%g.\n",flow,flow3);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=resphigh(i);
      rnum=resphigh3dignum(i);
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      cor=0;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if (er<0)
        er/=tol1min->v[(int) di+21];
      else
        er/=tol1max->v[(int) di+21];
      er=fabs(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corA);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erA=maxer;
  printf("\n\n");
  if (0) plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }

}

fprintdigcor(stdout);
if (!minmax)
  ret=chi2;
printf("\n\nIteration %i, objective function: %g\n\n--------------\n\n\n\n",
 numit,ret);


return ret;
}




/*******************************************************************

                            ONLINE FILTRI

********************************************************************/


/* ONLINE ZAJEMANJE: */

/* Filterska struktura: */
typedef struct {
    double a0,a1,a2,b1,b2,k,    /* koeficienti filtra */
    out,Ui1,Ui2,Ui3,Uo1,Uo2,Uo3;  /* buffer za pred. izhod. in vhod. vzorce */
} _filtdata;

typedef _filtdata *filtdata;


static int numsamp=0;  /* zap. st. vzorca */
static double cursamp=0;  /* vrednost trenut. vzorca (vhod. ali izhod.) */
static vector vecsamp=NULL;  /* vektor semplov za nacin, ko vektor pripravimo vnaprej */
static double refrms=0.5;

#define incnumsamp {++numsamp; if (numsamp==vecsamp->d) numsamp=-10; }

#define incnumsampcont { ++numsamp; if (numsamp==10100) numsamp=100 }

static double *getnextsamplevec(void)
    /* Vrne kazalec na naslednji vzorec, kjer so vzorci shranjeni v vektorju
    vecsamp (lokalna spremenljivka definirana zgoraj).
    $A Igor mar00; */
{
incnumsamp;
if (vecsamp!=NULL)
  if (numsamp>0 && vecsamp->d>=numsamp)
    return &(vecsamp->v[numsamp]);
return &(vecsamp->v[vecsamp->d]);
}

static double * (* getnextsample) (void)=getnextsamplevec;

static filtdata getlowfilt(double fhigh,double Ts,double corf,double cora0,
              double corb1)
    /* Naredi in vrne filter, ki ustreza low pass filtru. fhigh je karakterist.
    frekvenca filtra, Ts je perioda vzorcenja (smapling time), corf je
    relativna korekcija karakteristicne frekvence, cora0 je rel. korekcija
    koeficienta a0, s katerim je pomnozen trenutni  vhod. signal, corb1 pa je
    korekcija koeficienta b1, s katerim je pomnozen predhodji izhodni signal.
    $A Igor mar00; */
{
filtdata ret;
double RC;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
fhigh*=(1+corf);
RC=1/(2*Pi*fhigh);
ret->a0=Ts/(Ts+RC);
ret->b1=RC/(Ts+RC);
ret->a0*=(1+cora0);
ret->b1*=(1+corb1);
return ret;
}

static void lowfilt(double *sample,int numsamp,filtdata filt)
    /* Izvede pretvorbo vhodnega vzorca *sample v izhodnega z nizkoprepustnim
    (low pass) filtrom, katerega podatki so na *filt. numsamp je zaporedna
    stevilka vzorca.
    $A Igor mar01; */
{
if (numsamp>1)
{
  filt->out=filt->a0*(*sample)+filt->b1*filt->Uo1;
  filt->Uo1=filt->out;
  *sample=filt->out;
} else if (numsamp==1)
  filt->Uo1=*sample;
}

static void sqravfilt(double *sample,int numsamp,filtdata filt)
    /* Izvede pretvorbo vhodnega vzorca *sample v izhodnega s casovnoim
    utezevanjem S (kvadriranje in povprecenje). Podatki za nizkoprepustni
    filter za povprecenje so v *filt, numsamp pa je zap. st. vzorca.
    $A Igor mar01; */
{
*sample*=(*sample);
lowfilt(sample,numsamp,filt);
}

static void peakfilt(double *sample,int numsamp,filtdata filt)
    /* Izvede pretvorbo vhodnega vzorca *sample v izhodnega pri peak detekciji
    I . filt->k mora biti nastavljen na exp(-Ts/T), kjer je Ts vzorcni cas,
    T pa je razpadni cas peak detektorja. Tipicno so v *filt tudi podatki za
    nizkoprepustni filter, ki se uporablja za povprecenje.
    $A Igor mar01; */
{
if (numsamp>1)
{
  if (filt->Uo1>*sample)
  {
    filt->out=filt->Uo1*filt->k;
    if (filt->out>*sample)
      *sample=filt->out;
  }
  filt->Uo1=*sample;
} else if (numsamp==1)
  filt->Uo1=*sample;
}

static filtdata gethighfilt(double flow,double Ts,double corf,double cora0,
                double cora1,double corb1)
    /* Naredi in vrne filter, ki ustreza high pass filtru. fhlow je karakterist.
    frekvenca filtra, Ts je perioda vzorcenja (smapling time), corf je
    relativna korekcija karakteristicne frekvence, cora0 je rel. korekcija
    koeficienta a0, s katerim je pomnozen trenutni  vhod. signal, cora1 je
    relativna korekcija koeficienta a0, s katerim je pomnozen prejsnji  vhod.
    signal,vcorb1 pa je korekcija koeficienta b1, s katerim je pomnozen
    predhodji izhodni signal.
    $A Igor mar00; */
{
filtdata ret;
double c,RC;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
flow*=(1+corf);
RC=1/(2*Pi*flow);
c=RC/(Ts+RC);
ret->a0=c;
ret->a1=-c;
ret->b1=c;
ret->a0*=(1+cora0); 
ret->a1*=(1+cora1); 
ret->b1*=(1+corb1);
return ret;
}


static void highfilt(double *sample,int numsamp,filtdata filt)
    /* Izvede pretvorbo vhodnega vzorca *sample v izhodnega z visokoprepustnim
    (high pass) filtrom, katerega podatki so na *filt. numsamp je zaporedna
    stevilka vzorca.
    $A Igor mar01; */
{
if (numsamp>1)
{
  filt->out=filt->a0*(*sample)+filt->a1*filt->Ui1+filt->b1*filt->Uo1;
  filt->Ui1=*sample;
  filt->Uo1=filt->out;
  *sample=filt->out;
} else if (numsamp==1)
{
  filt->Ui1=*sample;
  filt->Uo1=*sample;
}
}


static filtdata getresfilt(double f0,double hr,double Ts,double corf0,
                double corhr,double cora0,double cora1,double cora2,
                double corb1,double corb2)
    /* Naredi in vrne filter, ki ustreza high pass filtru. f0 je karakterist.
    frekvenca filtra, hr je relativna prepustna sirina, Ts je perioda vzorcenja
    (smapling time), corf0 je relativna korekcija karakteristicne frekvence,
    corhr je relativna korekcija relativ. prepust. sirine, sledijo se relativne
    korekcije faktorjev filtra.
    $A Igor mar00; */
{
filtdata ret;
double beta,w0;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
f0*=(1+corf0);
hr*=(1+corhr);
w0=2*ConstPi*f0;
beta=0.5*hr*w0;
ret->a0=1/(1+beta*Ts);
ret->a1=-1/(1+beta*Ts);
ret->a2=1/(1+beta*Ts);
ret->b1=(2-sqr(w0)*sqr(Ts))/(1+beta*Ts);
ret->b2=(beta*Ts-1)/(1+beta*Ts);
ret->a0*=(1+cora0);
ret->a1*=(1+cora1);
ret->a2*=(1+cora2);
ret->b1*=(1+corb1);
ret->b2*=(1+corb2);
return ret;
}

static void resfilt(double *sample,int numsamp,filtdata filt)
    /* Izvede pretvorbo vhodnega vzorca *sample v izhodnega z resonancnim
    filtrom, katerega podatki so na *filt. numsamp je zaporedna stevilka vzorca.
    $A Igor mar01; */
{
if (numsamp>2)
{
  filt->out=filt->a0*(*sample)+filt->a1*filt->Ui1+filt->a2*filt->Ui2
   +filt->b1*filt->Uo1+filt->b2*filt->Uo2;
  filt->Ui2=filt->Ui1;
  filt->Uo2=filt->Uo1;
  filt->Ui1=*sample;
  filt->Uo1=filt->out;
  *sample=filt->out;
} else if (numsamp==1)
{
  filt->Ui2=*sample;
  filt->Uo2=*sample;
} else if (numsamp==2)
{
  filt->Ui1=*sample;
  filt->Uo1=*sample;
}
}



/* PODATKI ZA ONLINE FILTRE: */

/* Filtri za frekvencno utezevanje: */
static filtdata low1=NULL,low2=NULL,high3=NULL,high4=NULL,high5=NULL,
                high6=NULL,high7=NULL;

/* Filtri za casovno utezevanje: */
static filtdata Slow=NULL,Fast=NULL,Impulse=NULL,
                Slow1=NULL,Fast1=NULL,Impulse1=NULL,
                Slow2=NULL,Fast2=NULL,Impulse2=NULL;

static void initfiltdata(void)
    /* Pripravi podatke za razlicne (online) filtre v instrumentu. Uporablja
    lokalne spremenljivke, ki definirajo filtre ter lokalno spremenljivko za
    cas vzorcenja Ts.
    $A Igor mar01; */
{
setoptweightcor(); /* nastavi podatke za frekvencno utezevanje */
/* Filtri za frekvencno utezevanje: */
low1=getlowfilt(fhigh1,Ts,corl1f,corl1a0,corl1b1);
low2=getlowfilt(fhigh2,Ts,corl2f,corl2a0,corl2b1);
high3=gethighfilt(flow3,Ts,corh3f,corh3a0,corh3a1,corh3b1);
high4=gethighfilt(flow4,Ts,corh4f,corh4a0,corh4a1,corh4b1);
high5=gethighfilt(flow5,Ts,corh5f,corh5a0,corh5a1,corh5b1);
high6=gethighfilt(flow6,Ts,corh6f,corh6a0,corh6a1,corh6b1);
high7=gethighfilt(flow7,Ts,corh7f,corh7a0,corh7a1,corh7b1);
/* Filtri za casovno utezevanje: */
Slow=getlowfilt(1/(2*Pi*1),Ts,0,0,0); /* casov. konstanta 1000 ms */
Fast=getlowfilt(1/(2*Pi*0.125),Ts,0,0,0); /* casov. konstanta 125 ms */
Impulse=getlowfilt(1/(2*Pi*0.035),Ts,0,0,0); /* casov. konstanta 35 ms */
Impulse->k=exp(-Ts/1.5);
Slow1=getlowfilt(1/(2*Pi*1),Ts,0,0,0); /* casov. konstanta 1000 ms */
Fast1=getlowfilt(1/(2*Pi*0.125),Ts,0,0,0); /* casov. konstanta 125 ms */
Impulse1=getlowfilt(1/(2*Pi*0.035),Ts,0,0,0); /* casov. konstanta 35 ms */
Impulse1->k=exp(-Ts/1.5);
Slow2=getlowfilt(1/(2*Pi*1),Ts,0,0,0); /* casov. konstanta 1000 ms */
Fast2=getlowfilt(1/(2*Pi*0.125),Ts,0,0,0); /* casov. konstanta 1000 ms */
Impulse2=getlowfilt(1/(2*Pi*0.035),Ts,0,0,0); /* casov. konstanta 125 ms */
Impulse2->k=exp(-Ts/1.5);
}

static void Cfilt(double *sample,int numsamp)
    /* C online filter */
{
lowfilt(sample,numsamp,low1);
lowfilt(sample,numsamp,low2);
highfilt(sample,numsamp,high3);
highfilt(sample,numsamp,high4);
*sample*=corCdig;
}

static void Baddfilt(double *sample,int numsamp)
    /* Dodatek k C filtru za B online filter */
{
highfilt(sample,numsamp,high5);
*sample*=corBdig/corCdig;
}

static void Bfilt(double *sample,int numsamp)
    /* B online filter */
{
Cfilt(sample,numsamp);
Baddfilt(sample,numsamp);
}

static void Aaddfilt(double *sample,int numsamp)
    /* Dodatek k C filtru za A online filter */
{
highfilt(sample,numsamp,high6);
highfilt(sample,numsamp,high7);
*sample*=corAdig/corCdig;
}

static void Afilt(double *sample,int numsamp)
    /* A online filter */
{
Cfilt(sample,numsamp);
Aaddfilt(sample,numsamp);
}

static void Sfilt(double *sample,int numsamp)
{
sqravfilt(sample,numsamp,Slow);
}

static void Ffilt(double *sample,int numsamp)
{
sqravfilt(sample,numsamp,Fast);
}

static void Ifilt(double *sample,int numsamp)
{
sqravfilt(sample,numsamp,Impulse);
peakfilt(sample,numsamp,Impulse);
}

/* Po dva rezervna filtra za vsak nacin casovnega utezevanja: */

static void S1filt(double *sample,int numsamp)
{
sqravfilt(sample,numsamp,Slow1);
}

static void F1filt(double *sample,int numsamp)
{
sqravfilt(sample,numsamp,Fast1);
}

static void I1filt(double *sample,int numsamp)
{
sqravfilt(sample,numsamp,Impulse1);
peakfilt(sample,numsamp,Impulse1);
}

static void S2filt(double *sample,int numsamp)
{
sqravfilt(sample,numsamp,Slow2);
}

static void F2filt(double *sample,int numsamp)
{
sqravfilt(sample,numsamp,Fast2);
}

static void I2filt(double *sample,int numsamp)
{
sqravfilt(sample,numsamp,Impulse2);
peakfilt(sample,numsamp,Impulse2);
}

static void ASfilt(double *sample,int numsamp)
{
Afilt(sample,numsamp);
Sfilt(sample,numsamp);
}

static void AFfilt(double *sample,int numsamp)
{
Afilt(sample,numsamp);
Ffilt(sample,numsamp);
}

static void AIfilt(double *sample,int numsamp)
{
Afilt(sample,numsamp);
Ifilt(sample,numsamp);
}


/* Spremenljivke, ki dolocjo, kateri odzivi se izpisujejo: */
static int prA=1,prB=1,prC=1,prF=1,prS=1,prI=1;

static void testfiltonline(int outf)
    /* Test online delovanja filtrov za frekvencno in casovno utezevanje.
    Rezultati se izpisejo na vsakih outf vzorcev. Zajemanje opravi funkcija
    getnextsample() - to je sicer kazalec na funkcijo in ga je potrebno pred
    izvedbo funkcije testfiltonline() postaviti na pravo vrednost.
    $A Igor jan00; */
{
double AS,AF,AI,BS,BF,BI,CS,CF,CI,t0,t1;
initfiltdata();
t0=absolutetime();
t1=cputime();
while (numsamp>=0)
{
  CS=*getnextsample();   /* novi vzorec za obdelavo */
  Cfilt(&CS,numsamp);
  CF=CI=CS;  /* vzorec sfiltriran s C filtrom */
  BS=AS=CS;  /* vzorec sfiltriran s C filtrom */
  Baddfilt(&BS,numsamp);
  BF=BI=BS;  /* vzorec sfiltriran z B filtrom */
  Aaddfilt(&AS,numsamp);
  AF=AI=AS;  /* vzorec sfiltriran z A filtrom */
  /* Casovno utezevanje: */
  Sfilt(&AS,numsamp);
  S1filt(&BS,numsamp);
  S2filt(&CS,numsamp);
  Ffilt(&AF,numsamp);
  F1filt(&BF,numsamp);
  F2filt(&CF,numsamp);
  Ifilt(&AI,numsamp);
  I1filt(&BI,numsamp);
  I2filt(&CI,numsamp);
  /* Izpis rezultatov: */
  if (numsamp==vecsamp->d-2 || numsamp%outf==0)
  {
    printf("\n\n\nMeasured response, t = %8g s (%i samples):\n",numsamp*Ts,numsamp);
    printf(    "Total real time      = %8g s, total CPU time = %g s.\n",
     absolutetime()-t0,cputime()-t1);
    if (prA)
    {
      printf("\nA weighting levels:\n");
      if (prS) printf("  Slow:    rms = %12g,    dB: %g\n",AS,db(AS/refrms));
      if (prF) printf("  Fast:    rms = %12g,    dB: %g\n",AF,db(AF/refrms));
      if (prI) printf("  Impulse: rms = %12g,    dB: %g\n",AI,db(AI/refrms));
    }
    if (prB)
    {
      printf("\nB weighting levels:\n");
      if (prS) printf("  Slow:    rms = %12g,    dB: %g\n",BS,db(BS/refrms));
      if (prF) printf("  Fast:    rms = %12g,    dB: %g\n",BF,db(BF/refrms));
      if (prI) printf("  Impulse: rms = %12g,    dB: %g\n",BI,db(BI/refrms));
    }
    if (prC)
    {
      printf("\nC weighting levels:\n");
      if (prS) printf("  Slow:    rms = %12g,    dB: %g\n",CS,db(CS/refrms));
      if (prF) printf("  Fast:    rms = %12g,    dB: %g\n",CF,db(CF/refrms));
      if (prI) printf("  Impulse: rms = %12g,    dB: %g\n",CI,db(CI/refrms));
    }
  }
}
}

static void testfiltonlinegensig(double f,double Ts,long length,int outf)
    /* Opravi test online filtrov na signalu frekvence f z amplitudo 1,
    vzorcenem pri vzorcnem casu Ts. length je stevilo vzorcev, ki se zajamejo,
    outf pa je pogostnost izpisov (na vsakih outf vzorcev). */
{
getnextsample=getnextsamplevec;
numsamp=0;
numtestangf=2*Pi*f;
refrms=0.5;
samplesig0(numtestwave,0,Ts,length,&vecsamp);
testfiltonline(outf);
}

static void measonline1(int outf)
    /* Opravi online filtriranje signala, ki ga zajema preko funkcije
    getnextsample(). outf je pogostnost izpisov (na vsakih outf vzorcev). */
{
readdata("0itdata");
initfiltdata();
getnextsample=getnextsamplevec;
numsamp=0;
refrms=0.5;
testfiltonline(outf);
}

static void simtestfiltonline(void)
    /* simulacije online filtriranja, ki delajo z vzorcenim signalom
    spravljenim v vektor vecsamp. */
{
double f=100;
long length=200000,outf=1000;
while (f!=0)
{
  printf("Frequency: ");  readdouble(&f);
  printf("Num. of samples: "); readlong(&length);
  printf("Output freq. in num. samp.: "); readlong(&outf);
  if (f>0 && length>0 && outf>0)
    testfiltonlinegensig(f,Ts,length,outf);
}
}


static double numresp(void (*filtdig)(double *sample,int numsamp),double f,
                      double Ts)
    /* Vrne odziv online filtra filtdig pri frekvenci f in casu sempliranja Ts
    v decibelih. */
{
double nstart,num,period,eni=0,eno=0,*s;
int i,j=0,rounds,smooths;
char p=0;  /* izpis vmesnih rezultatov */
vector save;
/* Shranijo se zastavice, ki dolocajo, ali se vzorec zaokrozuje in gladi: */
rounds=roundsamples;
smooths=smoothsamples;
period=1/f;
numtestangf=2*Pi*f; /* frekvenca testnega vala */
/* Zacetek merjenja energije, naj bi bilo cca. 20 period, vendar ne vec kot
200000 vzorcev: */
nstart=round(20*period/Ts);
if (nstart>30000)
  nstart=30000;
if (nstart<=1000)
  nstart=1000;
/* Stevilo vzorcev, ki se porabi za merjenje energije; Cas mora pretecti celo
stevilo period, zajetih naj bo vsaj 10000 vzorcev, nikakor pa vec kot 500000. */
i=1;
num=round(i*period/Ts);
while(num<10000)
{
  ++i;
  num=round(i*period/Ts);
}
/*
while (num>500000 && (num-1)*Ts>period)
{
  --i;
  num=round(i*period/Ts);
}
*/
if (num>100000)  /* skrajna dopustna meja za num */
{
  num=100000;
  printf("\nWarning: numerical response is estimated on less than a whole period\n");
  printf("at frequency %g (period %g, sampled %g).\n",f,period,num*Ts);
}
if (p)
{
  printf("\nstart=%g, num=%g, %g periods. Sampling...",nstart,num,num*Ts/period);
}
/* Zajem referencnega vzorca; Referencni vzorec se niti ne zaokrozuje niti
ne gladi: */
roundsamples=smoothsamples=0;
samplesig0(numtestwave,0,Ts,(int)(nstart+num+1),&numtestsamp);
/* Celotna vsota kvadratov po testiranem obmocju vhod. signala: */
for (i=(int)nstart;i<(int)nstart+num;++i)
  eni+=sqr(numtestsamp->v[i]);
/* Zajem vzorca, ki se filtrira . Vzorec, ki se filtrira, se zaokrozuje in
gladi, ce je tako doloceno: */
roundsamples=rounds;
smoothsamples=smooths;
if (p)
  printf("Sampling...\n");
samplesig0(numtestwave,0,Ts,(int)(nstart+num+1),&numtestsamp);
if (p)
  printf("Filtering...\n");
save=vecsamp;
vecsamp=numtestsamp;
numsamp=0;
/*
filtdig(numtestsamp);
*/
for (i=1;i<=vecsamp->d;++i)
{
  s=getnextsamplevec();
  filtdig(s,numsamp);
}
vecsamp=save;
/* Celotna vsota kvadratov po testiranem obmocju izhod. signala: */
for (i=(int)nstart;i<(int)nstart+num;++i)
  eno+=sqr(numtestsamp->v[i]);
return db(eno/eni);
}




static double numresp1(void (*filtdig)(double *sample,int numsamp),double f,
                      double Ts)
    /* Vrne odziv online filtra filtdig pri frekvenci f in casu sempliranja Ts
    v decibelih.
    OPOMBA: TO JE FUNKCIJA ZA FILTRE, KI VKLJUCUJEJO CASOVNO UTEZEVANJE (torej
    tudi kvadriranje) */
{
double nstart,num,period,eni=0,eno=0,*s;
int i,j=0,rounds,smooths;
char p=0;  /* izpis vmesnih rezultatov */
vector save;
/* Shranijo se zastavice, ki dolocajo, ali se vzorec zaokrozuje in gladi: */
rounds=roundsamples;
smooths=smoothsamples;
period=1/f;
numtestangf=2*Pi*f; /* frekvenca testnega vala */
/* Zacetek merjenja energije, naj bi bilo cca. 20 period, vendar ne vec kot
200000 vzorcev: */
nstart=round(20*period/Ts);
if (nstart>30000)
  nstart=30000;
if (nstart<=1000)
  nstart=1000;
nstart+=100000;  /* zaradi velike casovne konstante filtra za povprecenje */
/* Stevilo vzorcev, ki se porabi za merjenje energije; Cas mora pretecti celo
stevilo period, zajetih naj bo vsaj 10000 vzorcev, nikakor pa vec kot 500000. */
i=1;
num=round(i*period/Ts);
while(num<10000)
{
  ++i;
  num=round(i*period/Ts);
}
/*
while (num>500000 && (num-1)*Ts>period)
{
  --i;
  num=round(i*period/Ts);
}
*/
if (num>100000)  /* skrajna dopustna meja za num */
{
  num=100000;
  printf("\nWarning: numerical response is estimated on less than a whole period\n");
  printf("at frequency %g (period %g, sampled %g).\n",f,period,num*Ts);
}
if (p)
{
  printf("\nstart=%g, num=%g, %g periods. Sampling...",nstart,num,num*Ts/period);
}
/* Zajem referencnega vzorca; Referencni vzorec se niti ne zaokrozuje niti
ne gladi: */
roundsamples=smoothsamples=0;
samplesig0(numtestwave,0,Ts,(int)(nstart+num+1),&numtestsamp);
/* Celotna vsota kvadratov po testiranem obmocju vhod. signala: */
for (i=(int)nstart;i<(int)nstart+num;++i)
  eni+=sqr(numtestsamp->v[i]);
/* Zajem vzorca, ki se filtrira . Vzorec, ki se filtrira, se zaokrozuje in
gladi, ce je tako doloceno: */
roundsamples=rounds;
smoothsamples=smooths;
if (p)
  printf("Sampling...\n");
samplesig0(numtestwave,0,Ts,(int)(nstart+num+1),&numtestsamp);
if (p)
  printf("Filtering...\n");
save=vecsamp;
vecsamp=numtestsamp;
numsamp=0;
/*
filtdig(numtestsamp);
*/
for (i=1;i<=vecsamp->d;++i)
{
  s=getnextsamplevec();
  filtdig(s,numsamp);
}
vecsamp=save;
/* Celotna vsota kvadratov po testiranem obmocju izhod. signala: */
for (i=(int)nstart;i<(int)nstart+num;++i)
  eno+=(numtestsamp->v[i]);
return db(eno/eni);
}








/* FUNKCIJE ZA TESTIRANJE: */


/* Signal za pravokotne pulze: */

static double tper,      /* perioda */
              rms,       /* root mean square */
              crest,     /* crest factor */
              tpeak,     /* cas, ko je sig. maksimalen */
              amph,      /* zgornja amplituda */
              ampl,      /* spodnja amplituda */
              tonef,     /* frekvenca tona pri "tone bursts" */
              repf;      /* ponavljalna frekvenca (1/tper) */
static vector sig=NULL; /* Testni signal */

static void setrectsig(double period,double rootmeansquare,double crestfact)
    /* Pripravi podatke za pravokotni signal s periodo period, r.m.s. vrednostjo
    rootmeansquare in krest faktorjem crestfact. */ 
{
tper=period;
rms=rootmeansquare;
crest=crestfact;
tpeak=tper/(1+crest*crest);
amph=crest*rms;
ampl=-amph*tpeak/(tper-tpeak);
printf("Installing rectangular signal:\n");
printf("Period: %g (frequency %g)\n",tper,1/tper);
printf("RMS value: %g\n",rms);
printf("Crest factor: %g\n",crest);
printf("Peak duration: %g\n",tpeak);
printf("Upper value: %g\n",amph);
printf("Lower value: %g\n",ampl);
printf("\n");
}


static double rectsig(double t)
    /* Vrne vrednost pravokotnega signala, katerega podatki so v staticnih
    spremenljivkah tper ... ampl, ob casu t. */
{
if (t<0)
  return rectsig(-t+tpeak);
else if (t>tper)
{
  double factor=t/tper;
  return rectsig(frac(factor)*tper);
} else
{
  if (t<tpeak)
    return amph;
  else
    return ampl;
}
}

static double negrectsig(double t)
    /* Vrne vrednost pravokotnega signala, ki gre v negativno smer, ob casu t. */
{
return -rectsig(t);
}

static void setburstsig(double freq,double repfreq,
              double rootmeansquare,double crestfact)
    /* Pripravi podatke za signal "tone bursts", kjer je freq frekvenca osnovnega
    tona v signalu, repfreq ponavljalna frekvenca, rootmeansquare r.m.s.
    signala, crestfact pa njegov krest faktor (razmerje med amplitudo in r.m.s. */
{
double num;
tonef=freq;
tper=1/repfreq;
rms=rootmeansquare;
crest=crestfact;
tpeak=2*tper/(crest*crest);
amph=crest*rms;
ampl=0;
printf("Installing a sequence of tone bursts:\n");
printf("Basic tone frequency: %g\n",tonef);
printf("Repetition frequency: %g\n",repfreq);
printf("Period:               %g\n",tper);
printf("RMS value:            %g\n",rms);
printf("Crest factor:         %g\n",crest);
printf("Tone duration:        %g\n",tpeak);
printf("Tone amplitude:       %g\n",amph);
printf("\nChecking if there are integer number of waves:\n");
num=tpeak*tonef;
printf("Number of waves: %g, changing to %g.\n",num,round(num));
num=round(num);
tpeak=num/tonef;
crest=sqrt(2*tper/tpeak);
amph=crest*rms;
printf("New tone duration: %g\n",tpeak);
printf("Crest factor has changed to new value of %g.\n",crest);
printf("\n");
}


static void setsingleburstsig(double freq, double rootmeansquare,double duration)
    /* Pripravi podatke za signal "single tone burst", kjer je freq frekvenca
    osnovnega tona v signalu, rootmeansquare r.m.s. signala, duration pa cas
    trajanja signala. */
{
double num;
tonef=freq;
tper=tpeak=duration;
rms=rootmeansquare;
crest=sqrt(2);
amph=rms*sqrt(2);
ampl=0;
printf("\nInstalling a single tone burst:\n");
printf("Basic tone frequency: %g\n",tonef);
printf("Duration:             %g\n",tper);
printf("RMS value:            %g\n",rms);
printf("Tone duration:        %g\n",tpeak);
printf("Tone amplitude:       %g\n",amph);
printf("\nChecking if there are integer number of waves:\n");
num=tpeak*tonef;
printf("Number of waves: %g, changing to %g.\n",num,round(num));
num=round(num);
tper=tpeak=num/tonef;
printf("New tone duration: %g\n",tpeak);
printf("\n");
}



double burstsig(double t)
    /* Vrne vrednost signala "tone bursts" za podatke, ki so v staticnih
    spremenljivkah zgoraj, ob casu t. */
{
if (t<0)
  return -burstsig(-t);
else if (t>tper)
{
  double factor=t/tper;
  return burstsig(frac(factor)*tper);
} else
{
  if (t<tpeak)
    return amph*sin(2*Pi*tonef*t);
  else
    return 0;
}
}


double negburstsig(double t)
{
return -burstsig(t);
}


double singleburstsig(double t)
    /* Vrne vrednost signala "single tone burst" za podatke, ki so v staticnih
    spremenljivkah zgoraj, ob casu t. */
{
if (t<0)
  return 0;
else if (t<=tper)
  return amph*sin(2*Pi*tonef*t);
else
  return 0;
}


static void printsig(vector sig,double Ts,int jump,double from,double to)
    /* Izpise vrednost vzorcenega signala sig, pri cemer je Ts cas vzorcenja,
    jump pove, po koliko vzorcev se preskakuje pri izpisu (ce je 1 ali 0, se
    izpisejo vsi vzorci), from je prvi cas, ki se izpise (t.j. 0 za prvi vzorec),
    to pa je zadnji cas, ki se se izpise (ce je 0, se izpise tudi se zadnji
    vzorec)  */
{
int ifrom, ito,i;
if (sig==NULL)
  printf("Signal is NULL.\n");
else
{
  printf("Number of samples: %i. Time running from 0 to %g s.\n",sig->d,(sig->d-1)*Ts);
  printf("Samples:\n%6s %12s %-12s\n","Sample","Time","Signal");
  ifrom=1+(int) floor(from/Ts); if (ifrom<1) ifrom=1;
  if (to<=0) to=1e10;
  ito=1+(int) ceil(to/Ts); if (to>sig->d) to=sig->d;
  if (ito<ifrom) ito=ifrom=0;
  i=ifrom;
  if (i>0) while (i<=sig->d && i<ito)
  {
    printf("%6i %12g %-12g\n",i,(i-1)*Ts,sig->v[i]);
    i+=jump;
  }
}
}

static void printsigext(vector sig,double Ts)
    /* Izpise ekstreme (tudi sibke) signala sig; Ts je perioda vzorcenja. */
{
int i;
if (sig==NULL)
  printf("Signal is NULL.\n");
else
{
  printf("Number of samples: %i. Time running from 0 to %g s.\n",sig->d,(sig->d-1)*Ts);
  printf("Weak extremes:\n%6s %12s %-12s\n","Sample","Time","Signal");
 for (i=1;i<sig->d;++i)
  {
    if (sig->v[i]>sig->v[i-1] && sig->v[i]>sig->v[i+1])
    {
      /* strong max. */
      printf("%6i %12g %-12g +\n",i,(i-1)*Ts,sig->v[i]);
    } else if (sig->v[i]>=sig->v[i-1] && sig->v[i]>sig->v[i+1] || 
     sig->v[i]>sig->v[i-1] && sig->v[i]>=sig->v[i+1] )
    {
      /* weak max. */
      printf("%6i %12g %-12g +=\n",i,(i-1)*Ts,sig->v[i]);
    } else if (sig->v[i]<sig->v[i-1] && sig->v[i]<sig->v[i+1])
    {
      /* strong min. */
      printf("%6i %12g %-12g -\n",i,(i-1)*Ts,sig->v[i]);
    } else if (sig->v[i]<=sig->v[i-1] && sig->v[i]<sig->v[i+1] || 
     sig->v[i]<sig->v[i-1] && sig->v[i]<=sig->v[i+1] )
    {
      /* weak min. */
      printf("%6i %12g %-12g -=\n",i,(i-1)*Ts,sig->v[i]);
    } else if (sig->v[i-1]*sig->v[i+1]<0 && fabs(sig->v[i])<=fabs(sig->v[i-1]) &&
     fabs(sig->v[i])<=fabs(sig->v[i+1]) )
    {
      /* isolated zero */
      printf("%6i %12g %-12g 0\n",i,(i-1)*Ts,sig->v[i]);
    }
  }
}
}


static double sigmax(vector sig)
    /* Vrne najvisji vzorec v sig */
{
double ret=-1e30;
int i;
if (sig!=NULL)
  for (i=1;i<=sig->d;++i)
    if (sig->v[i]>ret)
      ret=sig->v[i];
return ret;
}

static double sigrms(vector sig)
{
double ret=0;
int i;
if (sig!=NULL)
  for (i=1;i<=sig->d;++i)
    ret+=sqr(sig->v[i]);
if (sig->d>0)
  ret/=sig->d;
ret=sqrt(ret);
return ret;
}

static void runtests(void)
{
int printinp=0,plotinp=0,printout=1,plotout=1,cont=1;
double printfrom=0,printto=1,from=0,to=1,x,tao;
int jump=5,i,opt=1;
while (cont)
{
  if (0)
  {
    printf("Sampling period: "); readdouble(&Ts);
  }
  if (0)
  {
    /* Vstavljanje signalov */
    printf("Input data for test signals!\n");
    
    printf("\n  Repetitive tone bursts:\n");
    printf("Tone frequency: "); readdouble(&tonef);
    printf("Repetition frequency: "); readdouble(&repf);
    tper=1/repf;
    printf("r.m.s.: "); readdouble(&rms);
    printf("Crest factor: "); readdouble(&crest);
    setburstsig(tonef,repf,rms,crest);
    printf("\nEnd time of the sampled signal in seconds: ");
    readdouble(&to);
    from=0;
    printf("Sampling...\n");
    samplesigtime(burstsig,from,Ts,to-from,&sig);
    printsigext(sig,Ts);
    printf("\nPrint sampled values? "); readint(&printinp);
    if (printinp)
    {
      printf("Print from: "); readdouble(&printfrom);
      printf("Print to: "); readdouble(&printto);
      printf("Print every ?-th signal: "); readint(&jump);
      printsig(sig,Ts,jump,printfrom,printto);
    }
    printf("\nPlot sampled signal? "); readint(&plotinp);
    if (plotinp)
      plotvector(sig,NULL,NULL,0,NULL);
    printf("\n\n");

    printf("  Single tone burst:\n");
    printf("Tone frequency: "); readdouble(&tonef);
    printf("Burst duration: "); readdouble(&tpeak);
    printf("r.m.s.: "); readdouble(&rms);
    setsingleburstsig(tonef,rms,tpeak);
    printf("\nEnd time of the sampled signal in seconds: ");
    readdouble(&to);
    from=0;
    printf("Sampling...\n");
    samplesigtime(singleburstsig,from,Ts,to-from,&sig);
    printsigext(sig,Ts);
    printf("\nPrint sampled values? "); readint(&printinp);
    if (printinp)
    {
      printf("Print from: "); readdouble(&printfrom);
      printf("Print to: "); readdouble(&printto);
      printf("Print every ?-th signal: "); readint(&jump);
      printsig(sig,Ts,jump,printfrom,printto);
    }
    printf("\nPlot sampled signal? "); readint(&plotinp);
    if (plotinp)
      plotvector(sig,NULL,NULL,0,NULL);
    printf("\n\n");

    printf("  Rectangular signal:\n");
    printf("Signal period: "); readdouble(&tper);
    printf("r.m.s.: "); readdouble(&rms);
    printf("Crest factor: "); readdouble(&crest);
    setrectsig(tper,rms,crest);
    printf("\nEnd time of the sampled signal in seconds: ");
    readdouble(&to);
    from=0;
    printf("Sampling...\n");
    samplesigtime(rectsig,from,Ts,to-from,&sig);
    printsigext(sig,Ts);
    printf("\nPrint sampled values? "); readint(&printinp);
    if (printinp)
    {
      printf("Print from: "); readdouble(&printfrom);
      printf("Print to: "); readdouble(&printto);
      printf("Print every ?-th signal: "); readint(&jump);
      printsig(sig,Ts,jump,printfrom,printto);
    }
    printf("\nPlot sampled signal? "); readint(&plotinp);
    if (plotinp)
      plotvector(sig,NULL,NULL,0,NULL);
    printf("\n\n");

  }
  
  if (0)
  {
    /* Merjenje razpada pri izkljucitvi sin. signala (konec 7.2), reakcije
    na tone burst in nenadno vkljucitev signala (7.2), razpad pri impulse
    (7.3): */
    printf("  Input data for single tone burst:\n");
    printf("Tone frequency: "); readdouble(&tonef);
    printf("Burst duration: "); readdouble(&tpeak);
    printf("r.m.s.: "); readdouble(&rms);
    setsingleburstsig(tonef,rms,tpeak);
    printf("\nEnd time of the sampled signal in seconds: ");
    readdouble(&to);
    if (to<tper)
      to=tper+1/tonef;
    from=0;
    printf("Sampling...\n");
    samplesigtime(singleburstsig,from,Ts,to-from,&sig);
    /* printsigext(sig,Ts); */
    printf("\nPrint sampled values? "); readint(&printinp);
    if (printinp)
    {
      printf("Print from: "); readdouble(&printfrom);
      printf("Print to: "); readdouble(&printto);
      printf("Print every ?-th signal: "); readint(&jump);
      printsig(sig,Ts,jump,printfrom,printto);
    }
    printf("\n\n");
    printf("Choose time weighting (1 - Slow, 2 - Fast, 3 - Impulse)? ");
    readint(&opt);
    if (opt==1)      {timewt='s'; tao=1;}
    else if (opt==2) {timewt='f'; tao=0.125;}
    else             {timewt='i'; tao=0.035;}
    printf("Time constant: %g\n\n",tao);
    printf("Time weighting (squaring + averaging)...\n");
    filtsqrav(sig);
    printf("\nPrint the weighted signal? "); readint(&printout);
    if (printout)
    {
      printf("Print from: "); readdouble(&printfrom);
      printf("Print to: "); readdouble(&printto);
      printf("Print every ?-th signal: "); readint(&jump);
      printsig(sig,Ts,jump,printfrom,printto);
    }
    x=sig->v[i=(int) round(tper/Ts)+1];
    printf("\n\n\nValue at the time when signal was switched off: %g,\nr.m.s. at that time: %g\n\n",
     x,sqrt(x));
    printf("Max. value of the signal: %g, i.e. %g db ref. cont. sig.\n",
     x=sigmax(sig),db(x/(rms*rms)));
    printf("\nPrint the decay? "); readint(&printout);
    if (printout)
    {
      printf("Print every ?-th signal: "); readint(&jump);
      i=(int) round(tper/Ts)+1;
      printf("%6s %12s %-12s %-12s %-12s %-12s\n",
         "Sample","Time","Signal","SQR ratio","db","Predict.");
      while (i<=sig->d)
      {
        printf("%6i %12g %-12g %-12g %-12g %-12g\n",i,(i-1)*Ts,sig->v[i],
         sig->v[i]/x,db(sig->v[i]/x),db(exp(-((i-1)*Ts-tper)/tao)) );
        i+=jump;
      }
    }
  }
  
  if (1)
  {
    if (0)
    {
      /* Merjenje odziva na pravokotne signale (7.2,7.3) */
      printf("  Input data for rectangular signal:\n");
      printf("Signal period: "); readdouble(&tper);
      printf("r.m.s.: "); readdouble(&rms);
      printf("Crest factor: "); readdouble(&crest);
      setrectsig(tper,rms,crest);
      printf("\nEnd time of the sampled signal in seconds: ");
      readdouble(&to);
      from=0;
      printf("Sampling...\n");
      samplesigtime(rectsig,from,Ts,to-from,&sig);
      x=sigrms(sig);
      printf("Measured r.m.s.: %g (m.s.=%g)\n",x,x*x);
      printf("\nPrint sampled values? "); readint(&printinp);
      if (printinp)
      {
        printf("Print from: "); readdouble(&printfrom);
        printf("Print to: "); readdouble(&printto);
        printf("Print every ?-th signal: "); readint(&jump);
        printsig(sig,Ts,jump,printfrom,printto);
      }

      printf("\n\n");
      printf("Choose time weighting (1 - Slow, 2 - Fast, 3 - Impulse)? ");
      readint(&opt);
      if (opt==1)      {timewt='s'; tao=1;}
      else if (opt==2) {timewt='f'; tao=0.125;}
      else             {timewt='i'; tao=0.035;}
      printf("Time constant: %g\n\n",tao);
      printf("Time weighting (squaring + averaging)...\n");
      filtsqrav(sig);
      printf("\nPrint the weighted signal? "); readint(&printout);
      if (printout)
      {
        printf("Print from: "); readdouble(&printfrom);
        printf("Print to: "); readdouble(&printto);
        printf("Print every ?-th signal: "); readint(&jump);
        printsig(sig,Ts,jump,printfrom,printto);
      }
      x=sig->v[sig->d];
      printf("\n\n\nValue of the last sample: %g,\nr.m.s. at that time: %g\n\n",
       x,sqrt(x));
      x=sigmax(sig);
      printf("Max. value of the signal: %g, i.e. %g db ref. cont. sig.\n",
       x,db(x/(rms*rms)));
      x=sig->v[sig->d];
      printf("Last value of the signal: %g, i.e. %g db ref. cont. sig.\n",
       x,db(x/(rms*rms)));
       x=sigrms(sig);
      printf("Measured r.m.s.: %g (m.s.=%g)\n",x,x*x);
    }    
    
    
    if (1)
    {
      /* Merjenje odziva na zaporedje "tone bursts" (7.2,7.3) */
      printf("\n  Repetitive tone bursts:\n");
      printf("Tone frequency: "); readdouble(&tonef);
      printf("Repetition frequency: "); readdouble(&repf);
      tper=1/repf;
      printf("r.m.s.: "); readdouble(&rms);
      printf("Crest factor: "); readdouble(&crest);
      setburstsig(tonef,repf,rms,crest);
      printf("\nEnd time of the sampled signal in seconds: ");
      readdouble(&to);
      from=0;
      printf("Sampling...\n");
      samplesigtime(burstsig,from,Ts,to-from,&sig);
      x=sigrms(sig);
      printf("Measured r.m.s.: %g (m.s.=%g)\n",x,x*x);
      printf("\nPrint sampled values? "); readint(&printinp);
      if (printinp)
      {
        printf("Print from: "); readdouble(&printfrom);
        printf("Print to: "); readdouble(&printto);
        printf("Print every ?-th signal: "); readint(&jump);
        printsig(sig,Ts,jump,printfrom,printto);
      }
      /*
      printf("\n\n");
      printf("Choose time weighting (1 - Slow, 2 - Fast, 3 - Impulse)? ");
      readint(&opt);
      if (opt==1)      {timewt='s'; tao=1;}
      else if (opt==2) {timewt='f'; tao=0.125;}
      else             {timewt='i'; tao=0.035;}
      */
      printf("\nTime constant: %g\n\n",tao);
      printf("Time weighting (squaring + averaging)...\n");
      filtsqrav(sig);
      printf("\nPrint the weighted signal? "); readint(&printout);
      if (printout)
      {
        printf("Print from: "); readdouble(&printfrom);
        printf("Print to: "); readdouble(&printto);
        printf("Print every ?-th signal: "); readint(&jump);
        printsig(sig,Ts,jump,printfrom,printto);
      }
      x=sig->v[sig->d];
      printf("\n\n\nValue of the last sample: %g,\nr.m.s. at that time: %g\n\n",
       x,sqrt(x));
      x=sigmax(sig);
      printf("Max. value of the signal: %g, i.e. %g db ref. cont. sig.\n",
       x,db(x/(rms*rms)));
      x=sig->v[sig->d];
      printf("Last value of the signal: %g, i.e. %g db ref. cont. sig.\n",
       x,db(x/(rms*rms)));
      /* Za tabelo XI: */
      printf("\nResponse with respect to cont. sig.\n");
      printf("with the same amplitude: %g\n\n",db(x/(0.5*amph*amph)));
      
      x=sigrms(sig);
      printf("Measured r.m.s.: %g (m.s.=%g)\n",x,x*x);
    }
  }
  
  
  printf("\nContinue (0/1)? ");
  readint(&cont);
  printf("\n");
}
}








main()
{
char *filename="0fft.dat";
FILE *fp;
double R,dec,decamp,ramp,rpow;

int i,j;
float x,y;

char *name1,*mode1;
vector start, step;

initglobcalc();


readdata("0itdata");   checkdata();
initfiltdata();


if (0) runtests();

if (0) simtestfiltonline();


/*
setoptsmoothpar11_10();
*/

start=getvector(9);
start->v[1]= -0.15 ;
start->v[2]= 0.01 ;
start->v[3]= -0.05 ;
start->v[4]= 0.03 ;
start->v[5]= 0.05 ;
start->v[6]= 0.03 ;
start->v[7]= 0.15 ;
start->v[8]= 0.01 ;
start->v[9]= -0.3 ;


start=getvector(13);
start->v[1]= -0.324298 ;
start->v[2]= 0.145933 ;
start->v[3]= -0.184024 ;
start->v[4]= 0.159291 ;
start->v[5]= -0.0930019 ;
start->v[6]= 0.186468 ;

start->v[7]= 0.0518724 ;
start->v[8]= 0.194747 ;
start->v[9]= 0.1643 ;
start->v[10]= 0.132904 ;
start->v[11]= 0.263865 ;
start->v[12]= 0.131516 ;
start->v[13]= 0.966267 ;




/*

start=getvector(17);
start->v[1]= -0.1457 ;
start->v[2]= 0.04 ;
start->v[3]= -0.10714 ;
start->v[4]= 0.04 ;
start->v[5]= -0.06428 ;
start->v[6]= 0.04 ;
start->v[7]= -0.02142 ;
start->v[8]= 0.04 ;
start->v[9]= 0.02142 ;
start->v[10]= 0.04 ;
start->v[11]= 0.06428 ;
start->v[12]= 0.04 ;
start->v[13]= 0.10714 ;
start->v[14]= 0.04 ;
start->v[15]= 0.1457 ;
start->v[16]= 0.04 ;
start->v[17]= -0.3 ;

*/


start=getvector(7);
start->v[1]= 0.0 ;
start->v[2]= 0.0 ;
start->v[3]= 0.0 ;
start->v[4]= 0.0 ;
start->v[5]= 0.0 ;
start->v[6]= 0.0 ;
start->v[7]= 0.0 ;


if (1) R=minsimpshort0(objective,start,0.1,0.0002,3000);

printf("Optimal parameters:\n");
printvector(start);
printf("Objective function = %g\n",R);






printf("sizeof(int)=%i, sizeof(long)=%i, sizeof(float)=%i, sizeof(double)=%i.\n",
 sizeof(int),sizeof(long),sizeof(float),sizeof(double));



/* Numericne primerjave digitalnih filtrov s parametricnimi popravki: */
if (1)
{
vector samp=NULL;
double r,rcent,di;
double erA,erB,erC;

double klow=-0.45,khigh=0.45,kfact=1,kcum,space=0.05,num=4,step;
double s1=1,s2=1,s3=1,s4=1,s5=1,s6=1,s7=1,s8=1,balance=0;
double r1=-0.4,r2=-.35,r3=-.25,r4=-.15,r5=-.005,r6=.005,r7=.15,r8=.25,r9=.35,r10=.4,
       h1=0.05,h2=0.1,h3=0.1,h4=0.1,h5=0.1,h6=0.1,h7=0.1,h8=0.1,h9=0.1,h10=0.05,
       rbalance=0,shift=0,k1=-0.5,k2=-0.5,k3=-0.5,k4=-0.5,k5=-100,k6=-100;
int numsmpar=0;

int numbits;
double range;

if (1) setoptweightcor();  /* Optimalni korekcijski faktorji za filtre A, B, C */


while(Ts!=0)
{
  printf("Ts = ");   readdouble(&Ts);
  
  if (0)
  {
    printf("Antialias filter (0/1)? "); readint(&antialias);
    if (antialias)
    {
      setoptaliaspar_40_80();
      printf("First antialias frequency:  "); readdouble(&falias1);
      printf("Second antialias frequency: "); readdouble(&falias2);
    }
  }
  
  if (1)
  {
    printf("\nLimited representation (0/1) "); readint(&roundsamples);
    if (roundsamples)
    {
      printf("Amplitude: "); readdouble(&numtestamp);
      printf("Number of bits: "); readint(&numbits);
      printf("range: "); readdouble(&range);
      setroundsignfixbit(range,numbits);
      
      printf("Number of smoothing parameters (11, 15 or 0 for no smoothing): ");
      readint(&numsmpar);
      if (numsmpar==15)
      {
        if (numbits<=9)  setoptsmoothpar15_9();
        if (numbits==10)  setoptsmoothpar15_10();
        if (numbits==11)  setoptsmoothpar15_11();
      } else if (numsmpar==11)
      {
        if (numbits<=8)  setoptsmoothpar11_8();
        if (numbits==9)  setoptsmoothpar11_9();
        if (numbits==10)  setoptsmoothpar11_10();
        if (numbits==11)  setoptsmoothpar11_11();
        if (numbits==12)  setoptsmoothpar11_12();
      } else if (numsmpar==3)
      {
      } else if (numsmpar==2)
      {
      }
    }
    readsmoothpar();
  }
  
  if (0) readdigcor();
  
  if (0)
  {
    composewaves(NULL);
    smoothsamples=0;
    printf("Sampling...\n");
    samplesig0(wavpack,0,Ts,20000,&samp);
    printf("\n\nSampled input signal:\n\n");
    plotvec(samp,0,NULL);
    /*
    timewt='F';
    */
    filtsqrav(samp);
    printf("\n\nSquare averaged input signal:\n\n");
    plotvec(samp,0,NULL);
    /*
    printf("\n\nSampled input signal without smoothing:\n\n");
    plotvec(samp,0,NULL);
    smoothsamples=1;
    printf("Sampling...\n");
    samplesig0(wavpack,0,Ts,10000,&samp);
    printf("\n\nSampled input signal without smoothing:\n\n");
    plotvec(samp,0,NULL);
    
    */
    /*
    printf("Filtering...\n");
    filtlowdigcent(samp,fhigh,Ts);
    printf("\n\nSampled output signal:\n\n");
    plotvec(samp,0,NULL);
    */
  }
  
  if (0)
  {
  printf("\n\nAdjust frequencies:\n");
  printf("fhigh1: "); readdouble(&fhigh1);
  printf("fhigh2: "); readdouble(&fhigh2);
  printf("flow3: ");  readdouble(&flow3);
  printf("flow4: ");  readdouble(&flow4);
  }
  
  
  
  
  
  
  
  
  
  
  
  
  if (0)   /* TRETJINSKO OKTAVNI filter */
  {
  vector respan=NULL,respnum=NULL,resper=NULL,respmin=NULL,respmax=NULL;
  double draw=1,di,i,ii,k,ran,rnum,f,normf;
  static double fcent=1000;
  double cor,er,ermin,ermax,maxer=-100;
  int ivec=1;
  double ifrom=-2.5,ito=2.5;  /* obseg frekvenc */
  double div=1*3;          /* stevilo razdelkov pri frekvencah */
  
  printf("Central freq.: "); readdouble(&fcent);
  
  setzeroweightcor();
  
  respan=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  respnum=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  resper=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  respmin=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  respmax=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  
  flow1=flow2=flow3=flow4=707.1067812;
  fhigh1=fhigh2=fhigh3=fhigh4=1414.213562;
  
  fhigh1=flow1=900.896;
  fhigh2=flow2=1189.21;
  fhigh3=flow3=807.107;
  fhigh4=flow4=1414.21;
  fhigh5=flow5=1414.21;
  fhigh6=flow6=1414.21;
  
  num=6;
  /*
  printf("klow: "); readdouble(&klow);
  printf("khigh: "); readdouble(&khigh);
  printf("progressive factor (normally less than 1): "); readdouble(&kfact);
  printf("space: "); readdouble(&space);
  step=(khigh-klow)/(num-1);
  */
  
  if (((int)num)%2==0)
  {
    step=1;
    kcum=0.5*step;
    for (i=1;i<num/2;++i)
    {
      step*=kfact;
      kcum+=step;
    }
    step=1/kcum;
    kcum=0.5*step;
    /* 1. negativen k: */
    k=kcum*klow;
    flow1=fcent*pow(2,k-space/2); fhigh1=fcent*pow(2,k+space/2);
    /* 1. pozitiven k: */
    k=kcum*khigh;
    flow2=fcent*pow(2,k-space/2); fhigh2=fcent*pow(2,k+space/2);
    step*=kfact;
    kcum+=step;
    /* 2. negativen k: */
    k=kcum*klow;
    flow3=fcent*pow(2,k-space/2); fhigh3=fcent*pow(2,k+space/2);
    /* 2. pozitiven k: */
    k=kcum*khigh;
    flow4=fcent*pow(2,k-space/2); fhigh4=fcent*pow(2,k+space/2);
    step*=kfact;
    kcum+=step;
    /* 3. negativen k: */
    k=kcum*klow;
    flow5=fcent*pow(2,k-space/2); fhigh5=fcent*pow(2,k+space/2);
    /* 3. pozitiven k: */
    k=kcum*khigh;
    flow6=fcent*pow(2,k-space/2); fhigh6=fcent*pow(2,k+space/2);
  }
  
  printf("\nbalance=%g\ns1=%g\ns2=%g\ns3=%g\ns4=%g\ns5=%g\ns6=%g\n\n",
   balance,s1,s2,s3,s4,s5,s6);
  printf("ord1=%g\nord2=%g\nord3=%g\nord4=%g\nord5=%g\nord6=%g\n\n",
   ord1,ord2,ord3,ord4,ord5,ord6);
  
  if (0)  /* za filter band10 */
  {
    printf("balance: "); readdouble(&balance);
    printf("s1: "); readdouble(&s1);
    printf("s2: "); readdouble(&s2);
    printf("s3: "); readdouble(&s3);
    printf("s4: "); readdouble(&s4);
    printf("s5: "); readdouble(&s5);
    printf("s6: "); readdouble(&s6);
    printf("s7: "); readdouble(&s7);
    printf("s8: "); readdouble(&s8);
  
    printf("ord. 1: "); readdouble(&ord1);
    printf("ord. 2: "); readdouble(&ord2);
    printf("ord. 3: "); readdouble(&ord3);
    printf("ord. 4: "); readdouble(&ord4);
    printf("ord. 5: "); readdouble(&ord5);
    printf("ord. 6: "); readdouble(&ord6);
    printf("ord. 7: "); readdouble(&ord7);
    printf("ord. 8: "); readdouble(&ord8);
  
    flow1=fcent*pow(2,balance-s1);  fhigh1=fcent*pow(2,balance+s1);
    flow2=fcent*pow(2,balance-s2);  fhigh2=fcent*pow(2,balance+s2);
    flow3=fcent*pow(2,balance-s3);  fhigh3=fcent*pow(2,balance+s3);
    flow4=fcent*pow(2,balance-s4);  fhigh4=fcent*pow(2,balance+s4);
    flow5=fcent*pow(2,balance-s5);  fhigh5=fcent*pow(2,balance+s5);
    flow6=fcent*pow(2,balance-s6);  fhigh6=fcent*pow(2,balance+s6);
    flow7=fcent*pow(2,balance-s7);  fhigh7=fcent*pow(2,balance+s7);
    flow8=fcent*pow(2,balance-s8);  fhigh8=fcent*pow(2,balance+s8);
  
    printf("\nbalance=%g\ns1=%g\ns2=%g\ns3=%g\ns4=%g\ns5=%g\ns6=%g\ns7=%g\ns8=%g\n\n",
     balance,s1,s2,s3,s4,s5,s6,s7,s8);
    printf("ord1=%g\nord2=%g\nord3=%g\nord4=%g\nord5=%g\nord6=%g\nord7=%g\nord8=%g\n\n",
     ord1,ord2,ord3,ord4,ord5,ord6,ord7,ord8);
  
    printf("flow1 = %-10g, fhigh1 = %g\n",flow1,fhigh1);
    printf("flow2 = %-10g, fhigh2 = %g\n",flow2,fhigh2);
    printf("flow3 = %-10g, fhigh3 = %g\n",flow3,fhigh3);
    printf("flow4 = %-10g, fhigh4 = %g\n",flow4,fhigh4);
    printf("flow5 = %-10g, fhigh5 = %g\n",flow5,fhigh5);
    printf("flow6 = %-10g, fhigh6 = %g\n",flow6,fhigh6);
    printf("flow7 = %-10g, fhigh7 = %g\n",flow7,fhigh7);
    printf("flow8 = %-10g, fhigh8 = %g\n",flow8,fhigh8);
    printf("\n");
  }
  
  if (0) /* za filter res10 */
  {
    printf("\nbalance=%g\nr1=%g\nr2=%g\nr3=%g\nr4=%g\nr5=%g\nr6=%g\nr7=%g\nr8=%g\nr9=%g\nr10=%g\n\n",
     rbalance,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10);
    printf("h1=%g\nh2=%g\nh3=%g\nh4=%g\nh5=%g\nh6=%g\nh7=%g\nh8=%g\nh9=%g\nh10=%g\n\n",
     h1,h2,h3,h4,h5,h6,h7,h8,h9,h10);
    
    printf("Insert data for multiple resonance filter!\n");
    printf("balance: "); readdouble(&rbalance);
    printf("r1: "); readdouble(&r1);
    printf("r2: "); readdouble(&r2);
    printf("r3: "); readdouble(&r3);
    printf("r4: "); readdouble(&r4);
    printf("r5: "); readdouble(&r5);
    printf("r6: "); readdouble(&r6);
    printf("r7: "); readdouble(&r7);
    printf("r8: "); readdouble(&r8);
    printf("r9: "); readdouble(&r9);
    printf("r10: "); readdouble(&r10);
  
    printf("\nhr 1: "); readdouble(&h1);
    printf("hr 2: "); readdouble(&h2);
    printf("hr 3: "); readdouble(&h3);
    printf("hr 4: "); readdouble(&h4);
    printf("hr 5: "); readdouble(&h5);
    printf("hr 6: "); readdouble(&h6);
    printf("hr 7: "); readdouble(&h7);
    printf("hr 8: "); readdouble(&h8);
    printf("hr 9: "); readdouble(&h9);
    printf("hr 10: "); readdouble(&h10);
    
    hres1=h1; hres2=h2; hres3=h3; hres4=h4; hres5=h5; hres6=h6; hres7=h7;
    hres8=h8; hres9=h9; hres10=h10;
    
    
    fres1=fcent*pow(2,rbalance+r1);
    fres2=fcent*pow(2,rbalance+r2);
    fres3=fcent*pow(2,rbalance+r3);
    fres4=fcent*pow(2,rbalance+r4);
    fres5=fcent*pow(2,rbalance+r5);
    fres6=fcent*pow(2,rbalance+r6);
    fres7=fcent*pow(2,rbalance+r7);
    fres8=fcent*pow(2,rbalance+r8);
    fres9=fcent*pow(2,rbalance+r9);
    fres10=fcent*pow(2,rbalance+r10);
    
    printf("\nbalance=%g\nr1=%g\nr2=%g\nr3=%g\nr4=%g\nr5=%g\nr6=%g\nr7=%g\nr8=%g\nr9=%g\nr10=%g\n\n",
     rbalance,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10);
    printf("h1=%g\nh2=%g\nh3=%g\nh4=%g\nh5=%g\nh6=%g\nh7=%g\nh8=%g\nh9=%g\nh10=%g\n\n",
     h1,h2,h3,h4,h5,h6,h7,h8,h9,h10);
    
    printf("fcent=%g.\n",fcent);
    printf("fres1 = %-10g, hres1 = %g,\nfres2 = %-10g, hres2 = %g\n",
     fres1,hres1,fres2,hres2);
    printf("fres3 = %-10g, hres3 = %g,\nfres4 = %-10g, hres4 = %g\n",
     fres3,hres3,fres4,hres4);
    printf("fres5 = %-10g, hres5 = %g,\nfres6 = %-10g, hres6 = %g\n",
     fres5,hres5,fres6,hres6);
    printf("fres7 = %-10g, hres7 = %g,\nfres8 = %-10g, hres8 = %g\n",
     fres7,hres7,fres8,hres8);
    printf("fres9 = %-10g, hres9 = %g,\nfres10 = %-10g, hres10 = %g\n",
     fres9,hres9,fres10,hres10);
    
    printf("\nshift: "); readdouble(&shift);
    printf("\nPar. for high pass filters:\n");
    printf("k1: ");  readdouble(&k1);
    printf("k2: ");  readdouble(&k2);
    printf("k3: ");  readdouble(&k3);
    printf("k4: ");  readdouble(&k4);
    flow1=fcent*pow(2,k1);
    flow2=fcent*pow(2,k2);
    flow3=fcent*pow(2,k3);
    flow4=fcent*pow(2,k4);
    flow5=fcent*pow(2,k5);
    flow6=fcent*pow(2,k6);
    if (k1<=-10) flow1=0;
    if (k2<=-10) flow2=0;
    if (k3<=-10) flow3=0;
    if (k4<=-10) flow4=0;
    if (k5<=-10) flow5=0;
    if (k6<=-10) flow6=0;
    
    printf("k1=%g\nk2=%g\nk3=%g\nk4=%g\nk5=%g\nk6=%g\n",k1,k2,k3,k4,k5,k6);
    printf("shift = %g\n\n",shift);
    printf("flow1 = %g\nflow2 = %g\nflow3 = %g\nflow4 = %g\nflow5 = %g\nflow6 = %g\n\n",
     flow1,flow2,flow3,flow4,flow5,flow6);
  
  }
  
  
  if (1) /* za filter res10 */
  {
    printf("\nbalance=%g\nr1=%g\nr2=%g\nr3=%g\nr4=%g\nr5=%g\nr6=%g\nr7=%g\nr8=%g\nr9=%g\nr10=%g\n\n",
     rbalance,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10);
    printf("h1=%g\nh2=%g\nh3=%g\nh4=%g\nh5=%g\nh6=%g\nh7=%g\nh8=%g\nh9=%g\nh10=%g\n\n",
     h1,h2,h3,h4,h5,h6,h7,h8,h9,h10);
    
    
    r4=r5=0;
    r9=r10=0;
    h4=h5=0;
    h9=h10=0;
    
    printf("\nr1: %g  \nh1: %g\n",r1,h1);
    printf("\nr2: %g  \nh2: %g\n",r2,h2);
    printf("\nr3: %g  \nh3: %g\n",r3,h3);
    printf("\nr6: %g  \nh6: %g\n",r6,h6);
    printf("\nr7: %g  \nh7: %g\n",r7,h7);
    printf("\nr8: %g  \nh8: %g\n",r8,h8);
    
    printf("\n\nr1: "); readdouble(&r1);  printf("h1: "); readdouble(&h1);
    printf("\nr2: "); readdouble(&r2);  printf("h2: "); readdouble(&h2);
    printf("\nr3: "); readdouble(&r3);  printf("h3: "); readdouble(&h3);
    printf("\nr6: "); readdouble(&r6);  printf("h6: "); readdouble(&h6);
    printf("\nr7: "); readdouble(&r7);  printf("h7: "); readdouble(&h7);
    printf("\nr8: "); readdouble(&r8);  printf("h8: "); readdouble(&h8);
    
    hres1=h1;  hres2=h2;  hres3=h3;  hres4=h4;  hres5=h5;
    hres6=h6;  hres7=h7;  hres8=h8;  hres9=h9;  hres10=h10;
    
    fres1=fcent*pow(2,r1);
    fres2=fcent*pow(2,r2);
    fres3=fcent*pow(2,r3);
    fres6=fcent*pow(2,r6);
    fres7=fcent*pow(2,r7);
    fres8=fcent*pow(2,r8);
    
  }
  
  
  printf("\nshift: "); readdouble(&shift);
  
  printf("\nFilter multiplicity (now %i): ",multiplicity);  readint(&multiplicity);
  
  printf("\n\nResponse of  digital (numerical) band filter, f0=%gHz.\n",fcent);
  
  
  printf(" %9s %12s %12s %12s %12s %10s\n","norm. f","f [Hz]",
  "num. dig.","low. lim.","up. lim.","---");
  for (di=ifrom*8;di<=ito*8;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ii=i;
      normf=i/8;  /* 2. logaritem normalizirane frekvenca */
      f=fcent*pow(2,normf);
      i=invfstd(f);
      /* f=fstdcont(i); */
      /*
      ran=dbamp(ampres(f,fres,hres));
      rnum=respresdignum(i);
      */
      
      /*
      rnum=respband10dignum(i);
      
      /*
      rnum=respband10an(i);
      */
      /*
      rnum=respres10high6dignum(i);
      */
      
      
      /* ################## */
      /*
      ran=dbamp(ampresmir(f,fres,hres));
      rnum=respresdignum(i);
      */
      
      rnum=respressym10dignum(i);
      
      /* Popravek z dvema nizkoprepustnima filtroma eno oktavo nad fcent: 
      fhigh=2*fcent;
      rnum+=2*resplow(invfstd(f));
      */
      
      if (ii==0)
        cor=-rnum+filtmaxthird1(0);  /* egzaktna korekcija pri centralni frekvenci */
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %12g %12g %10g\n", normf,
       f,rnum,filtminthird1(normf),filtmaxthird1(normf),0,0 );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %10s - %10s %9s %9s  %-8s\n","norm. f","f [Hz]",
  "num. dig.","low. lim.","up. lim.","errmin","errmax","error");
  ivec=1;
  for (di=ifrom*8;di<=ito*8;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      normf=i/8;  /* Normalizirana frekvenca */
      f=fcent*pow(2,normf);
  if (1)    respnum->v[ivec]+=cor+shift;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      ermax=rnum-filtmaxthird1(normf);
      ermin=filtminthird1(normf)-rnum;
      if (ermax>ermin)
        er=ermax;
      else
        er=ermin;
      if (er>maxer)
        maxer=er;
      resper->v[ivec]=er;
      respmin->v[ivec]=filtminthird1plot(normf);
      respmax->v[ivec]=filtmaxthird1(normf);
      if (k==0)
        printf("*");
      else
        printf(" ");
      
      printf("%9g %12g %12g %10g - %-10g %9.3g %9.3g  %-8.5g\n", normf,
       f,rnum,filtminthird1(normf),filtmaxthird1(normf),ermin,ermax,er);
      
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g\n",
   cor,invdbamp(cor));
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erC=maxer;
  printf("\n\n");
  /*
  plotvector(respnum,NULL,NULL,0,NULL);
  */
  
if (0)  plotvector(respnum,respan,NULL,0,NULL);
  
  printf("Draw graph? "); readdouble(&draw);
  draw=1;
  if (draw)
  {
    plotvector(respnum,respmin,respmax,0,NULL);
    /*
    printf("\nError:\n");
    plotvector(resper,NULL,NULL,0,NULL);
    */
  }
  
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  dispvector(&resper); dispvector(&respmin); dispvector(&respmax);
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  if (1)   /* OKTAVNI filter */
  {
  vector respan=NULL,respnum=NULL,resper=NULL,respmin=NULL,respmax=NULL;
  double draw=1,di,i,ii,k,ran,rnum,f,normf;
  static double fcent=1000;
  double cor,er,ermin,ermax,maxer=-100;
  int ivec=1;
  double ifrom=-4,ito=4;  /* obseg frekvenc */
  double div=2;          /* stevilo razdelkov pri frekvencah */
  
  printf("Central freq.: "); readdouble(&fcent);
  
  setzeroweightcor();
  
  respan=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  respnum=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  resper=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  respmin=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  respmax=getvector((int)round( div*(1+8*(ito-ifrom)) ));
  
  flow1=flow2=flow3=flow4=707.1067812;
  fhigh1=fhigh2=fhigh3=fhigh4=1414.213562;
  
  fhigh1=flow1=900.896;
  fhigh2=flow2=1189.21;
  fhigh3=flow3=807.107;
  fhigh4=flow4=1414.21;
  fhigh5=flow5=1414.21;
  fhigh6=flow6=1414.21;
  
  num=6;
  /*
  printf("klow: "); readdouble(&klow);
  printf("khigh: "); readdouble(&khigh);
  printf("progressive factor (normally less than 1): "); readdouble(&kfact);
  printf("space: "); readdouble(&space);
  step=(khigh-klow)/(num-1);
  */
  
  if (((int)num)%2==0)
  {
    step=1;
    kcum=0.5*step;
    for (i=1;i<num/2;++i)
    {
      step*=kfact;
      kcum+=step;
    }
    step=1/kcum;
    kcum=0.5*step;
    /* 1. negativen k: */
    k=kcum*klow;
    flow1=fcent*pow(2,k-space/2); fhigh1=fcent*pow(2,k+space/2);
    /* 1. pozitiven k: */
    k=kcum*khigh;
    flow2=fcent*pow(2,k-space/2); fhigh2=fcent*pow(2,k+space/2);
    step*=kfact;
    kcum+=step;
    /* 2. negativen k: */
    k=kcum*klow;
    flow3=fcent*pow(2,k-space/2); fhigh3=fcent*pow(2,k+space/2);
    /* 2. pozitiven k: */
    k=kcum*khigh;
    flow4=fcent*pow(2,k-space/2); fhigh4=fcent*pow(2,k+space/2);
    step*=kfact;
    kcum+=step;
    /* 3. negativen k: */
    k=kcum*klow;
    flow5=fcent*pow(2,k-space/2); fhigh5=fcent*pow(2,k+space/2);
    /* 3. pozitiven k: */
    k=kcum*khigh;
    flow6=fcent*pow(2,k-space/2); fhigh6=fcent*pow(2,k+space/2);
  }
  
  printf("\nbalance=%g\ns1=%g\ns2=%g\ns3=%g\ns4=%g\ns5=%g\ns6=%g\n\n",
   balance,s1,s2,s3,s4,s5,s6);
  printf("ord1=%g\nord2=%g\nord3=%g\nord4=%g\nord5=%g\nord6=%g\n\n",
   ord1,ord2,ord3,ord4,ord5,ord6);
  
  if (0)  /* za filter band10 */
  {
    printf("balance: "); readdouble(&balance);
    printf("s1: "); readdouble(&s1);
    printf("s2: "); readdouble(&s2);
    printf("s3: "); readdouble(&s3);
    printf("s4: "); readdouble(&s4);
    printf("s5: "); readdouble(&s5);
    printf("s6: "); readdouble(&s6);
    printf("s7: "); readdouble(&s7);
    printf("s8: "); readdouble(&s8);
  
    printf("ord. 1: "); readdouble(&ord1);
    printf("ord. 2: "); readdouble(&ord2);
    printf("ord. 3: "); readdouble(&ord3);
    printf("ord. 4: "); readdouble(&ord4);
    printf("ord. 5: "); readdouble(&ord5);
    printf("ord. 6: "); readdouble(&ord6);
    printf("ord. 7: "); readdouble(&ord7);
    printf("ord. 8: "); readdouble(&ord8);
  
    flow1=fcent*pow(2,balance-s1);  fhigh1=fcent*pow(2,balance+s1);
    flow2=fcent*pow(2,balance-s2);  fhigh2=fcent*pow(2,balance+s2);
    flow3=fcent*pow(2,balance-s3);  fhigh3=fcent*pow(2,balance+s3);
    flow4=fcent*pow(2,balance-s4);  fhigh4=fcent*pow(2,balance+s4);
    flow5=fcent*pow(2,balance-s5);  fhigh5=fcent*pow(2,balance+s5);
    flow6=fcent*pow(2,balance-s6);  fhigh6=fcent*pow(2,balance+s6);
    flow7=fcent*pow(2,balance-s7);  fhigh7=fcent*pow(2,balance+s7);
    flow8=fcent*pow(2,balance-s8);  fhigh8=fcent*pow(2,balance+s8);
  
    printf("\nbalance=%g\ns1=%g\ns2=%g\ns3=%g\ns4=%g\ns5=%g\ns6=%g\ns7=%g\ns8=%g\n\n",
     balance,s1,s2,s3,s4,s5,s6,s7,s8);
    printf("ord1=%g\nord2=%g\nord3=%g\nord4=%g\nord5=%g\nord6=%g\nord7=%g\nord8=%g\n\n",
     ord1,ord2,ord3,ord4,ord5,ord6,ord7,ord8);
  
    printf("flow1 = %-10g, fhigh1 = %g\n",flow1,fhigh1);
    printf("flow2 = %-10g, fhigh2 = %g\n",flow2,fhigh2);
    printf("flow3 = %-10g, fhigh3 = %g\n",flow3,fhigh3);
    printf("flow4 = %-10g, fhigh4 = %g\n",flow4,fhigh4);
    printf("flow5 = %-10g, fhigh5 = %g\n",flow5,fhigh5);
    printf("flow6 = %-10g, fhigh6 = %g\n",flow6,fhigh6);
    printf("flow7 = %-10g, fhigh7 = %g\n",flow7,fhigh7);
    printf("flow8 = %-10g, fhigh8 = %g\n",flow8,fhigh8);
    printf("\n");
  }
  
  if (0) /* za filter res10 */
  {
    printf("\nbalance=%g\nr1=%g\nr2=%g\nr3=%g\nr4=%g\nr5=%g\nr6=%g\nr7=%g\nr8=%g\nr9=%g\nr10=%g\n\n",
     rbalance,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10);
    printf("h1=%g\nh2=%g\nh3=%g\nh4=%g\nh5=%g\nh6=%g\nh7=%g\nh8=%g\nh9=%g\nh10=%g\n\n",
     h1,h2,h3,h4,h5,h6,h7,h8,h9,h10);
    
    printf("Insert data for multiple resonance filter!\n");
    printf("balance: "); readdouble(&rbalance);
    printf("r1: "); readdouble(&r1);
    printf("r2: "); readdouble(&r2);
    printf("r3: "); readdouble(&r3);
    printf("r4: "); readdouble(&r4);
    printf("r5: "); readdouble(&r5);
    printf("r6: "); readdouble(&r6);
    printf("r7: "); readdouble(&r7);
    printf("r8: "); readdouble(&r8);
    printf("r9: "); readdouble(&r9);
    printf("r10: "); readdouble(&r10);
  
    printf("\nhr 1: "); readdouble(&h1);
    printf("hr 2: "); readdouble(&h2);
    printf("hr 3: "); readdouble(&h3);
    printf("hr 4: "); readdouble(&h4);
    printf("hr 5: "); readdouble(&h5);
    printf("hr 6: "); readdouble(&h6);
    printf("hr 7: "); readdouble(&h7);
    printf("hr 8: "); readdouble(&h8);
    printf("hr 9: "); readdouble(&h9);
    printf("hr 10: "); readdouble(&h10);
    
    hres1=h1; hres2=h2; hres3=h3; hres4=h4; hres5=h5; hres6=h6; hres7=h7;
    hres8=h8; hres9=h9; hres10=h10;
    
    
    fres1=fcent*pow(2,rbalance+r1);
    fres2=fcent*pow(2,rbalance+r2);
    fres3=fcent*pow(2,rbalance+r3);
    fres4=fcent*pow(2,rbalance+r4);
    fres5=fcent*pow(2,rbalance+r5);
    fres6=fcent*pow(2,rbalance+r6);
    fres7=fcent*pow(2,rbalance+r7);
    fres8=fcent*pow(2,rbalance+r8);
    fres9=fcent*pow(2,rbalance+r9);
    fres10=fcent*pow(2,rbalance+r10);
    
    printf("\nbalance=%g\nr1=%g\nr2=%g\nr3=%g\nr4=%g\nr5=%g\nr6=%g\nr7=%g\nr8=%g\nr9=%g\nr10=%g\n\n",
     rbalance,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10);
    printf("h1=%g\nh2=%g\nh3=%g\nh4=%g\nh5=%g\nh6=%g\nh7=%g\nh8=%g\nh9=%g\nh10=%g\n\n",
     h1,h2,h3,h4,h5,h6,h7,h8,h9,h10);
    
    printf("fcent=%g.\n",fcent);
    printf("fres1 = %-10g, hres1 = %g,\nfres2 = %-10g, hres2 = %g\n",
     fres1,hres1,fres2,hres2);
    printf("fres3 = %-10g, hres3 = %g,\nfres4 = %-10g, hres4 = %g\n",
     fres3,hres3,fres4,hres4);
    printf("fres5 = %-10g, hres5 = %g,\nfres6 = %-10g, hres6 = %g\n",
     fres5,hres5,fres6,hres6);
    printf("fres7 = %-10g, hres7 = %g,\nfres8 = %-10g, hres8 = %g\n",
     fres7,hres7,fres8,hres8);
    printf("fres9 = %-10g, hres9 = %g,\nfres10 = %-10g, hres10 = %g\n",
     fres9,hres9,fres10,hres10);
    
    printf("shift: "); readdouble(&shift);
    printf("Par. for high pass filters:\n");
    printf("k1: ");  readdouble(&k1);
    printf("k2: ");  readdouble(&k2);
    printf("k3: ");  readdouble(&k3);
    printf("k4: ");  readdouble(&k4);
    flow1=fcent*pow(2,k1);
    flow2=fcent*pow(2,k2);
    flow3=fcent*pow(2,k3);
    flow4=fcent*pow(2,k4);
    flow5=fcent*pow(2,k5);
    flow6=fcent*pow(2,k6);
    if (k1<=-10) flow1=0;
    if (k2<=-10) flow2=0;
    if (k3<=-10) flow3=0;
    if (k4<=-10) flow4=0;
    if (k5<=-10) flow5=0;
    if (k6<=-10) flow6=0;
    
    printf("k1=%g\nk2=%g\nk3=%g\nk4=%g\nk5=%g\nk6=%g\n",k1,k2,k3,k4,k5,k6);
    printf("shift = %g\n\n",shift);
    printf("flow1 = %g\nflow2 = %g\nflow3 = %g\nflow4 = %g\nflow5 = %g\nflow6 = %g\n\n",
     flow1,flow2,flow3,flow4,flow5,flow6);
  
  }
  
  
  if (1) /* za filter res10 */
  {
    printf("\nbalance=%g\nr1=%g\nr2=%g\nr3=%g\nr4=%g\nr5=%g\nr6=%g\nr7=%g\nr8=%g\nr9=%g\nr10=%g\n\n",
     rbalance,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10);
    printf("h1=%g\nh2=%g\nh3=%g\nh4=%g\nh5=%g\nh6=%g\nh7=%g\nh8=%g\nh9=%g\nh10=%g\n\n",
     h1,h2,h3,h4,h5,h6,h7,h8,h9,h10);
    
    
    r3=r4=r5=0;
    r8=r9=r10=0;
    h3=h4=h5=0;
    h8=h9=h10=0;
    
    printf("\nr1: %g  \nh1: %g\n",r1,h1);
    printf("\nr2: %g  \nh2: %g\n",r2,h2);
    printf("\nr6: %g  \nh6: %g\n",r6,h6);
    printf("\nr7: %g  \nh7: %g\n",r7,h7);
    
    printf("\n\nr1: "); readdouble(&r1);  printf("h1: "); readdouble(&h1);
    printf("\nr2: "); readdouble(&r2);  printf("h2: "); readdouble(&h2);
    printf("\nr6: "); readdouble(&r6);  printf("h6: "); readdouble(&h6);
    printf("\nr7: "); readdouble(&r7);  printf("h7: "); readdouble(&h7);
    
    hres1=h1;  hres2=h2;  hres3=h3;  hres4=h4;  hres5=h5;
    hres6=h6;  hres7=h7;  hres8=h8;  hres9=h9;  hres10=h10;
    
    fres1=fcent*pow(2,r1);
    fres2=fcent*pow(2,r2);
    fres6=fcent*pow(2,r6);
    fres7=fcent*pow(2,r7);
    
  }
  
  
  printf("shift: "); readdouble(&shift);
  
  
  printf("\n\nResponse of  digital (numerical) band filter, f0=%gHz.\n",fcent);
  
  
  
  
  printf(" %9s %12s %12s %12s %12s %10s\n","norm. f","f [Hz]",
  "num. dig.","low. lim.","up. lim.","---");
  for (di=ifrom*8;di<=ito*8;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ii=i;
      normf=i/8;  /* Normalizirana frekvenca */
      f=fcent*pow(2,normf);
      i=invfstd(f);
      /* f=fstdcont(i); */
      /*
      ran=dbamp(ampres(f,fres,hres));
      rnum=respresdignum(i);
      */
      
      /*
      rnum=respband10dignum(i);
      
      /*
      rnum=respband10an(i);
      */
      /*
      rnum=respres10high6dignum(i);
      */
      
      
      /* ################## */
      /*
      ran=dbamp(ampresmir(f,fres,hres));
      rnum=respresdignum(i);
      */
      
      rnum=respressym10dignum(i);
      
      
      if (ii==0)
        cor=-rnum+filtmax1(0);  /* egzaktna korekcija pri centralni frekvenci */
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %12g %12g %10g\n", normf,
       f,rnum,filtmin1(normf),filtmax1(normf),0,0 );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %10s - %10s %9s %9s  %-8s\n","norm. f","f [Hz]",
  "num. dig.","low. lim.","up. lim.","errmin","errmax","error");
  ivec=1;
  for (di=ifrom*8;di<=ito*8;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      normf=i/8;  /* Normalizirana frekvenca */
      f=fcent*pow(2,normf);
  if (1)    respnum->v[ivec]+=cor+shift;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      ermax=rnum-filtmax1(normf);
      ermin=filtmin1(normf)-rnum;
      if (ermax>ermin)
        er=ermax;
      else
        er=ermin;
      if (er>maxer)
        maxer=er;
      resper->v[ivec]=er;
      respmin->v[ivec]=filtmin1plot(normf);
      respmax->v[ivec]=filtmax1(normf);
      if (k==0)
        printf("*");
      else
        printf(" ");
      
      printf("%9g %12g %12g %10g - %-10g %9.3g %9.3g  %-8.5g\n", normf,
       f,rnum,filtmin1(normf),filtmax1(normf),ermin,ermax,er);
      
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g\n",
   cor,invdbamp(cor));
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erC=maxer;
  printf("\n\n");
  /*
  plotvector(respnum,NULL,NULL,0,NULL);
  */
  
if (1)  plotvector(respnum,respan,NULL,0,NULL);
  
  printf("Draw graph? "); readdouble(&draw);
  if (draw)
  {
    plotvector(respnum,respmin,respmax,0,NULL);
    /*
    printf("\nError:\n");
    plotvector(resper,NULL,NULL,0,NULL);
    */
  }
  
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  dispvector(&resper); dispvector(&respmin); dispvector(&respmax);
  }


  
  
  
  
  
  
  
  if (0)   /* Posamezni filtri (low pass, high pass, resonancni...) */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,maxer=0;
  int ivec=1;
  static int ifrom=-20,ito=13;  /* obseg frekvenc */
  static double div=1;          /* stevilo razdelkov pri frekvencah */
  
  printf("ifrom: "); readint(&ifrom);
  printf("ito: "); readint(&ito);
  printf("div: "); readdouble(&div);
  printf("\n\nfres: "); readdouble(&fres);
  printf("hres: "); readdouble(&hres);
  
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) filters.\n");
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      
      ran=dbamp(ampres(fstdcont(i),fres,hres));
      rnum=respresdignum(i);
      
      /*
      fhigh=1000;
      ran=dbamp(amplow(fstdcont(i),fhigh));
      rnum=resplowdignum(i);
      
      flow=1000;
      ran=dbamp(amphigh(fstdcont(i),flow));
      rnum=resphighdignum(i);
      */
      
      /* Antialias filter: */
      /*3.97
      if (antialias) 3.973.973.97
        rnum+=dbamp(amplow(fstdcont(i),falias1))+
              dbamp(amplow(fstdcont(i),falias2));
      */
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if (er<0)
        er/=tol1min->v[(int) di+21];
      else
        er/=tol1max->v[(int) di+21];
      er=fabs(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corA);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erA=maxer;
  printf("\n\n");
  plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
  
  
  if (0)   /* filter C */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,maxer=0;
  int ivec=1;
  int ifrom=-20,ito=13;  /* obseg frekvenc */
  double div=1;          /* stevilo razdelkov pri frekvencah */
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) C filter, f0 = %g.\n",fhigh);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=respCth(i);
      /*
      rnum=respCdignum(i);
      */
      
      rnum=respkopC1dignum(i);
      
      /* Antialias filter: */
      if (antialias) 
        rnum+=dbamp(amplow(fstdcont(i),falias1))+
              dbamp(amplow(fstdcont(i),falias2));
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if (er<0)
        er/=tol1min->v[(int) di+21];
      else
        er/=tol1max->v[(int) di+21];
      er=fabs(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corC);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erC=maxer;
  printf("\n\n");
  plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
  
  if (0)  /* filter B */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,maxer=0;
  int ivec=1;
  int ifrom=-20,ito=13;  /* obseg frekvenc */
  double div=1;          /* stevilo razdelkov pri frekvencah */
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) B filter, f0 = %g.\n",fhigh);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=respBth(i);
      rnum=respBdignum(i);
      /* Antialias filter: */
      if (antialias) 
        rnum+=dbamp(amplow(fstdcont(i),falias1))+
              dbamp(amplow(fstdcont(i),falias2));
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if (er<0)
        er/=tol1min->v[(int) di+21];
      else
        er/=tol1max->v[(int) di+21];
      er=fabs(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corB);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erB=maxer;
  printf("\n\n");
  plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
  if (0)   /* filter A */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,maxer=0;
  int ivec=1;
  int ifrom=-20,ito=13;  /* obseg frekvenc */
  double div=1;          /* stevilo razdelkov pri frekvencah */
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) A filter, f0 = %g.\n",fhigh);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=respAth(i);
      
      /*
      rnum=respAdignum(i);
      */
      
      rnum=respkopAdignum(i);
            
      /* Antialias filter: */
      if (antialias) 
        rnum+=dbamp(amplow(fstdcont(i),falias1))+
              dbamp(amplow(fstdcont(i),falias2));
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if (er<0)
        er/=tol1min->v[(int) di+21];
      else
        er/=tol1max->v[(int) di+21];
      er=fabs(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corA);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erA=maxer;
  printf("\n\n");
  plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
  printf("\n\nerA=%g, erB=%g, erC=%g.\n\n",erA,erB,erC);
   
  if (0)   /* low pass filter */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,maxer=0;
  int ivec=1;
  int ifrom=-20,ito=13;  /* obseg frekvenc */
  double div=1;          /* stevilo razdelkov pri frekvencah */
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) low pass filter, f0 = %g, f0=%g.\n",fhigh,fhigh2);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=resplow(i);
      rnum=resplow2dignum(i);
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      cor=0;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if (er<0)
        er/=tol1min->v[(int) di+21];
      else
        er/=tol1max->v[(int) di+21];
      er=fabs(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corA);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erA=maxer;
  printf("\n\n");
  plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
 
  
  if (0)   /* high pass filter */
  {
  vector respan=NULL,respnum=NULL;
  double di,i,k,ran,rnum;
  double cor,er,maxer=0;
  int ivec=1;
  int ifrom=-20,ito=13;  /* obseg frekvenc */
  double div=1;          /* stevilo razdelkov pri frekvencah */
  respan=getvector((int)round((ito-ifrom+1)*div));
  respnum=getvector((int)round((ito-ifrom+1)*div));
  printf("\n\nResponse of analogue and digital (numerical) high parr filter, f0 = %g, f0=%g.\n",flow,flow3);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=resphigh(i);
      rnum=resphigh3dignum(i);
      if (i==0)
        cor=ran-rnum;  /* egzaktna korekcija pri 1000 Hz */
      cor=0;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\nCorrected digital response, correction=%g db:\n",cor);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  ivec=1;
  for (di=ifrom;di<=ito;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      respnum->v[ivec]+=cor;
      ran=respan->v[ivec];
      rnum=respnum->v[ivec];
      er=rnum-ran;
      if (er<0)
        er/=tol1min->v[(int) di+21];
      else
        er/=tol1max->v[(int) di+21];
      er=fabs(er);
      if (er>maxer)
        maxer=er;
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       er );
      ++ivec;
    }
  }
  printf("\nCorrection: %g db, amp. factor %g (th. cor=%g)\n",
   cor,invdbamp(cor),corA);
  printf("\nMaximum relative error in decibels: %g\n",maxer);
  erA=maxer;
  printf("\n\n");
  plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
  
}
}



/* Primerjalno testiranje teoreticnega odziva low pass in high pass filtrov: */
if (0)
{
vector samp=NULL;
double r,rcent,di;
while(Ts!=0)
{
  printf("Ts = ");   readdouble(&Ts);
  
  if (0)
  {
    composewaves(NULL);
    printf("Sampling...\n");
    samplesig0(wavpack,0,Ts,10000,&samp);
    printf("\n\nSampled input signal:\n\n");
    plotvec(samp,0,NULL);
    printf("Filtering...\n");
    filtlowdigcent(samp,fhigh,Ts);
    printf("\n\nSampled output signal:\n\n");
    plotvec(samp,0,NULL);
  }
  
  if (0)
    drawfuncsimp(resplow,resplow,NULL,-20,13,34);
  
  if (0)
  {
  vector respan=NULL,respnum=NULL;
  double di,div=2,i,k,ran,rnum;
  int ivec=1;
  respan=getvector((int)round(34*div)); respnum=getvector((int)round(34*div));
  printf("\n\nResponse of analogue and digital (numerical) low pass filter, f0 = %g.\n",fhigh);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.d.-a.)/+tol.");
  for (di=-20;di<=13;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=resplow(i);
      rnum=resplowdignum(i);
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g   %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\n\n");
  plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
  if (0)
  {
  printf("\n\nResponse of analogue and digital low pass filter, f0 = %g.\n",fhigh);
  printf("%9s %12s %12s %12s %12s %10s\n","freq. [Hz]","an. resp. [db]",
  "dig. resp. [db]","dif. (dig-an)","tol. type 1","dif./+tol.");
  for (i=-20;i<=13;++i)
  {
    printf("%9g %12g %12g %12g   %5g - %-5g %10g\n ", fstdcont(i),
     resplow(i), resplowdig(i), 
      resplowdig(i)-resplow(i),
      tol1min->v[i+21],tol1max->v[i+21],
      (resplowdig(i)-resplow(i))/tol1max->v[i+21] );
  }
  printf("\n\n");
  }
  
  if (0)
  {
  printf("\n\nResponse of analogue and digital cent. low pass filter, f0 = %g.\n",fhigh);
  printf("%9s %12s %12s %12s %12s %10s\n","freq. [Hz]","an. resp. [db]",
  "dig. resp. [db]","dif. (dig-an)","tol. type 1","dif./+tol.");
  for (i=-20;i<=13;++i)
  {
    rcent=resplowdigcentnum(i);
    printf("%9g %12g %12g %12g   %5g - %-5g %10g\n ", fstdcont(i),
     resplow(i), rcent, 
      rcent-resplow(i),
      tol1min->v[i+21],tol1max->v[i+21],
      (rcent-resplow(i))/tol1max->v[i+21] );
  }
  printf("\n\n");
  }
  
  if (0)
  {
    printf("\n\nTheoretical versus numerical esponse of digital low pass filter, f0 = %g.\n",fhigh);
    printf("%9s %12s %12s %12s %12s %12s %12s\n","freq. [Hz]","an. resp.",
    "th. r.[db]","num. r.[db]","num.-th.","num. cent.","n.c.-th.");
    for (i=-20;i<=13;++i)
    {
      r=resplowdignum(i);
      rcent=resplowdigcentnum(i);
      printf("%9g %12g %12g %12g %12g %12g %12g\n ", fstdcont(i),
       resplow(i), resplowdig(i),r,r-resplowdig(i),rcent,rcent-resplowdig(i) );
    }
    printf("\n\n");
  }
  
  if (0)
  {
    composewaves(NULL);
    printf("Sampling...\n");
    samplesig0(wavpack,0,Ts,1000,&samp);
    printf("\n\nSampled input signal:\n\n");
    plotvec(samp,0,NULL);
    printf("Filtering...\n");
    filthighdig(samp,flow,Ts);
    printf("\n\nSampled output signal:\n\n");
    plotvec(samp,0,NULL);
  }
  
  if (0)
    drawfuncsimp(resphigh,resphighdig,NULL,-20,13,100);
  
  if (0)
  {
  vector respan=NULL,respnum=NULL;
  double di,div=2,i,k,ran,rnum;
  int ivec=1;
  respan=getvector((int)round(34*div)); respnum=getvector((int)round(34*div));
  printf("\n\nResponse of analogue and digital (numerical) high pass filter, f0 = %g.\n",flow);
  printf(" %9s %12s %12s %12s %12s %10s\n","f [Hz]","an. r. [db]",
  "num. dig.","n.d.-a.","tol. type 1","(n.f.-a.)/+tol.");
  for (di=-20;di<=13;++di)
  {
    for (k=0;k<div;++k)
    {
      i=di+k/div;
      ran=resphigh(i);
      rnum=resphighdignum(i);
      if (k==0)
        printf("*");
      else
        printf(" ");
      printf("%9g %12g %12g %12g   %5g - %-5g %10g\n", fstdcont(i),
       ran,rnum,rnum-ran,tol1min->v[(int) di+21],tol1max->v[(int) di+21],
       (rnum-ran)/tol1max->v[(int) di+21] );
      respan->v[ivec]=ran;
      respnum->v[ivec]=rnum;
      ++ivec;
    }
  }
  printf("\n\n");
  plotvector(respnum,respan,NULL,0,NULL);
  printf("\n\n");
  dispvector(&respan); dispvector(&respnum);
  }
  
  if (0)
  {
  printf("\n\nResponse of analogue and digital high pass filter, f0 = %g.\n",flow);
  printf("%9s %12s %12s %12s %12s %10s\n","freq. [Hz]","an. resp. [db]",
  "dig. resp. [db]","dif. (dig-an)","tol. type 1","dif./+tol.");
  for (i=-20;i<=13;++i)
  {
    printf("%9g %12g %12g %12g   %5g - %-5g %10g\n ", fstdcont(i),
     resphigh(i), resphighdig(i), 
      resphighdig(i)-resphigh(i),
      tol1min->v[i+21],tol1max->v[i+21],
      (resphighdig(i)-resphigh(i))/tol1max->v[i+21] );
  }
  printf("\n\n");
  }
  
  if (0)
  {
    printf("\n\nTheoretical versus numerical esponse of digital high pass filter, f0 = %g.\n",flow);
    printf("%9s %12s %12s %12s %12s %12s %12s\n","freq. [Hz]","an. resp.",
    "th. r.[db]","num. r.[db]","num.-th.","num.-an.","(n-a)/tol");
    for (i=-20;i<=13;++i)
    {
      r=resphighdignum(i);
      printf("%9g %12g %12g %12g %12g %12g %12g\n ", fstdcont(i),
       resphigh(i), resphighdig(i),r,r-resphighdig(i),
       r-resphigh(i),(r-resphigh(i))/tol1max->v[i+21] );
    }
    
    for (di=9.95;di<=10.05;di+=0.01)
    {
      r=resphighdignum(di);
      printf("%9g %12g %12g %12g %12g %12g %12g\n ", fstdcont(di),
       resphigh(di), resphighdig(di),r,r-resphighdig(di),
       r-resphigh(di),(r-resphigh(di))/tol1max->v[(int)round(di)+21] );
    }
    
    printf("\n\n");
  }
  
}
}

drawfuncsimp(respA,respB,respC,-20,12,100);
drawfuncsimp(respA,resplow,resphigh,-20,12,100);


checkdata();

exit(1);

printf("\n\n%15s %15s %15s %15s %15s %15s\n",
 "dbpow","rpow","invdbpow","dbamp","ramp","invdbamp");
for (i=-10;i<=10;++i)
{
  dec=0.1*i;
  rpow=invdb(dec); ramp=sqrt(rpow);
  decamp=dbamp(ramp);
  printf("%15.8g %15.8g %15.8g %15.8g %15.8g %15.8g\n",
   dec,rpow,invdb(dec),decamp,ramp,invdbamp(decamp));
}
for (i=1;i<=24;++i)
{
  dec=5*i;
  
  rpow=invdb(dec); ramp=sqrt(rpow);
  dec=db(rpow);  decamp=dbamp(ramp);
  printf("%15.8g %15.8g %15.8g %15.8g %15.8g %15.8g\n",
   dec,rpow,invdb(dec),decamp,ramp,invdbamp(decamp));
  
  /*
  dec+=0.5;
  rpow=invdb(dec); ramp=sqrt(rpow);
  dec=db(rpow);  decamp=dbamp(ramp);
  printf("%15.8g %15.8g %15.8g %15.8g %15.8g %15.8g\n",
   dec,rpow,invdb(dec),decamp,ramp,invdbamp(decamp));
  
  dec+=0.5;
  rpow=invdb(dec); ramp=sqrt(rpow);
  dec=db(rpow);  decamp=dbamp(ramp);
  printf("%15.8g %15.8g %15.8g %15.8g %15.8g %15.8g\n",
   dec,rpow,invdb(dec),decamp,ramp,invdbamp(decamp));
  */
}
printf("\n\n");


printweight();

exit(1);














printf("Velikost float: %i, velikost double:%i\n\n",sizeof(float),sizeof(double));

if (filename!=NULL)
{
  fp=fopen(filename,"ab");
  fprintf(fp,"\n\n\n\n\n\n\n             FOURIER TRA0NSFORM TESTS\n\n\n");
}

/*
printf("Integral sin(x)-1 od 0 do Pi/2:\n");
printf("%8s %25s %25s\n","St. int.","Trapez. formula","Simps. formula");
for (i=2;i<=100;++i)
{
  printf("%8i %25.15g %25.15g\n",
   i,inttrapbas(sin,0,0.5*ConstPi,i)-1,intsimpsbas(sin,0,0.5*ConstPi,i)-1);
}
*/


      
composewaves(fp);





/*
drawfuncprimint(func1,func2,NULL,0,5,50,1,0,0,1,0,0,0,1);
*/






if (fp!=NULL)
  fclose(fp);
}
