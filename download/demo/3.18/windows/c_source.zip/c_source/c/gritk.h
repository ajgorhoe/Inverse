

# include <stdlib.h>

# include <er.h>
# include <itk.h>
#include <sg_obj.h>



          /***********************************/
          /*   GRAPHICAL INTERFACE FOR ITK   */
          /***********************************/


   /* THIS FILE IS NICLUDED IN grint.c by #include "gritk.h". */


typedef struct
    {
      int id;         /* ID number for IGS */
      
      /* IS THIS NECESSARY (fields open and visible)? */
      char   open;    /* 0 if the window is not open */
      char   visible; /* 0 if the window is not visible - currently not used */

      int width,
          height;     /* Dimensions in pixels */
      char *tkid;     /* Tk's window name */
      char *forcewin;
      char *windowtitle;
    } _itkwin;

typedef _itkwin *itkwin;


typedef struct {
  char *tkid;
  char *inststr;
  char *family;
  char bold,italic,underline,overstrike;
} _itkfont;

typedef _itkfont *itkfont;


/* Execution flag - determines how the Tcl Commands are executed.
  0: direct execution via itk_sendcomcp
  1: prints commands into a file.
  */
static char exflag=0;
static char *combuf=NULL;     /* Command buffer */
static int combuflength=600;  /* Size of the command buffer, should be enough to store
                       any command */

static stack fonts=NULL;



/* FOR DEVELOPERS:
There is an ambiguitiy related to functions like gisetwindowidth() and
gigetwindowwidth(). Functions with the prefic giset set the size for windows
that will be open, wgile functions with the prefix get return the size of the
current window. This ambiguity must be resolved in such a way that the complete
functionality is preserved. 
*/

static stack itkwindows=NULL;      /* Stack of windows */
static int   locitkwin=0;         /* Current window ID */
static char *locwindowstr=NULL; /* Tk string ID for the current window */
static char *locforcewin=NULL;  /* Forces particular window to be used by the
            giopenwindow() - string is not deleted in the module! */
static char *locitkwinprefix=".itk_igs_win_";

static char *loccursor=NULL;  /* Stores initial shape of the cursor for the canvas */

/* Window handling options: */
static char *sharwindowtitle=NULL;
static int sharMAXX=1280,sharMAXY=1024;  /* Screen width and height */
/* Window positioning and size: */
static float sharwindowxpos=-1,sharwindowypos=-1,
             sharwindowwidth=0.3f,sharwindowheight=0.3f;
static int shariwindowxpos=-1,shariwindowypos=-1,
             shariwindowwidth=500,shariwindowheight=500;


static _coord3d p1,p2,p3,p4,p5;  /* Auxiliary variables for coord. transf. */




/* Common parameters that are shared for all graphics: */

/* screen graphics: */


/* Color handling for screen graphics - enables to handle problems where images
contain too many different colors to fit in the color table. It has not yet
been decided whether color restrictions should (such as gray scale and coarse
divisions of shades) should be taken into account while printing to files.
*/

static char sharcoloring=1; /* Whether color or grayscale plotting is used */
static int sharnumshades=256; /* Number of discrete accessible shades for color comp. */
static int sharnumdiscretecolors=0;
static int sharindexsize=0; /* Size of color index tables */
static int sharnumindices=0;
static char sharpreindexall=0; /* If 1, all possible pixel colors are allocated
            at the initialization. */

static _truecolor sharlinecolor /* ={0.01f,0.01f,0.01f} */,
                  sharfillcolor /* ={0.8f,0.8f,0.8f} */,
                  shartextcolor /* ={0.8f,0.8f,0.8f} */;

static char loclinecolor[8], locfillcolor[8], loctextcolor[8];




/* Line, text and oter settings: */
static int sharilinewidth=1;
static double sharlinewidth=0.01;
static int sharlinetype=1;

static int shartextfont;
static int shartextxalignment=0,shartextyalignment=0;
static char *loctextanchor="center";
static char *loctextfontstr="times";
static float shartextheight=0.02f;
static int sharitextheight=8;

static float shartextprecision=(float) 0.01f;
static float shartextspacing=0.0f;
static float shartextexpansion=1.0f;





/* Options for drawing points and curved object such as circle arcs: */
static float sharpointsize=0.01f;
static int sharcurvepoints=30;





/* $$ Poglej, ce to rabis! !/
static char tclioldwish=0; /* Ce je 1, se naredi datoteka tcli za wish verzij
                          manj kot 8.0. */


/* Definicije za Tcl-ov shell: */
/*
static char *tclishellstr="#!/usr/bin/wish -f";
static char *tcliwindowtitle="IGS - Tcl window";
*/

/* static int tclwindowwidth=600; */ /* Sirina okna, kamor se bo izrisala datoteka */
/* static int tclwindowheight=600; */ /* Visina okna */

/*
static double tcltextscalingfactor=600;
*/


  /* SKALIRANJE KOORDINAT PRI ZAPISU V FORMATU Tcl: */


/* static int tcliprecision=6; */
/* static char tcliscalecoordinates=1; */ /* Ce je 1, se koordinate skalirajo kot pri
              risanju grafov, drugace se zapisejo naravne koordinate. */


/* Okno, v katerega se izrise slika: */
/*
static double tclistartx=0,   /* koordinata x leve strani okna 
              tclistarty=600,   /* koordinata y spodnje strani okna 
              tclisizex=600,  /* sirina okna 
              tclisizey=-600;  /* visina okna 
*/



/* Nizi, ki predstavljajo lastnosti graficnih objektov v datoteki formata Tcl: */
/*
static char *tclifillcolorstr="fillcolor";
static char *tclilinecolorstr="linecolor";
static char *tclilinewidthstr="linewidth";
static char *tclitextcolorstr="textcolor";
static char *tclitextfontstr="textfont";
static char *tclitextanchorstr="textanchor";
*/

/* Imena procedur za izris graficnih objektov v datoteki formata Tcl: */
/*
static char *tclilinestr="tcliline";
static char *tclitrianglestr="tclitriangle";
static char *tclifouranglestr="tclifourangle";
static char *tclifilltrianglestr="tclifilltriangle";
static char *tclifillfouranglestr="tclifillfourangle";
static char *tclitextstr="tclitext";
*/


/*
static char *="";
static char *="";
static char *="";
static char *="";
static char *="";
static char *="";
static char *="";
static char *="";
*/

/* static char alloctclipsoutfile=0; /* Ce je 1, se tcliepsoutfile lahko brise s
                                 free(). */
/* static char *tcliepsoutfile="0.eps"; /* Ime datoteke v formatu eps, v katero naj
    Tcl-ov interpreter zapise sliko. Ce je NULL, se v datoteke v formatu tcli ne
    zapisejo navodila interpreterju, naj izpise sliko v formatu eps. */


/* Nastavitve za risanje: */
/*
static _truecolor tclifillcolor={(float) 0.8,(float) 0.8,(float) 0};
static _truecolor tclilinecolor={(float) 0,(float) 0,(float) 1};
static int tclilinewidth=1;
static _truecolor tclitextcolor={(float) 1,(float) 0,(float) 0};
*/

/* FONTI: */


/*
static char *tclidefaultfontpre="times";
static char *tclidefaultfontpost="bold italic";
static stack tclifontpre=NULL,tclifontpost=NULL;
*/


static stack plotst=NULL;
static Tcl_Interp *itkinterp;
static int directitk=0;

static int itkplotcmd(ClientData clientData, Tcl_Interp *interp,
       int argc,const char *argv[])
    /* Function for the Tcl command installed in the ITK interpreter, which
    plots the IGS graphics stacks by passing commands directly to the
    interprter. This can be done because the function is executed by the
    same thread in which the interpreter was created. Such plotting is much
    quicker because there are no delays due to synchronization of threads.
    $A Igor jul03; */
{
itkinterp=interp;
directitk=1;
godrawstack(plotst);
tcl_processallevents(); /* Block until window is actually redrawn */
directitk=0;
return TCL_OK;
}



static void initgritk(void)
{
/*
printf("\nWITHIN initgritk.\n");
waituserresponse();
*/
if (combuf==NULL)
{
  combuf=malloc(1+combuflength);
  *combuf='\0';
  fonts=newstack(10);
  /* Install the plotting procedure: */
  itk_lockinterp();
  Tcl_CreateCommand(itk_interp(), "itk_igs_plot",itkplotcmd,(ClientData) NULL,
                    (Tcl_CmdDeleteProc *) NULL);
  itk_unlockinterp();
}
/*
waituserresponse();
*/
}



static int itkerrorreported=0;

static void runbufblock(void)
    /* Executes the command buffer and sets the writing position to the
    beginning of the buffer. $A Igor jul03; */
{
char *res;
int code;
if (directitk)
{
  /* When this command is called in the thread of the ITK's Tcl interpreter,
  the commands can be passed directly to the interpreter: */
  Tcl_Eval(itkinterp,combuf);
  *combuf='\0';
} else
{
  res=itk_interpretcp(combuf,&code);
  if (!tcl_okcode(code) && !itkerrorreported)
  {
    itkerrorreported=1;
    errfunc0("runbufblock");
    sprintf(ers(),"IGS - ITK error. Tcl error report:\n");
    checkminerbuf(stringlength(res));
    sprintf(ers(),"%s",res);
    errfunc2();
  }
  disppointer((void **) &res);
  *combuf='\0';
}
}




static void runbuf(void)
    /* Executes the command buffer and sets the writing position to the
    beginning of the buffer. $A Igor jul03; */
{
static int num=0;
if (directitk)
{
  /* When this command is called in the thread of the ITK's Tcl interpreter,
  the commands can be passed directly to the interpreter: */
  Tcl_Eval(itkinterp,combuf);
  *combuf='\0';
} else
{
  if (exflag==0)
    itk_sendcomcp(combuf);
  *combuf='\0';
}
++num;
if (num>=100)
{
  /* Process events between draving to enable window handling */
  tcl_processquickevents();
  num=0;
}
}



int godrawstackitk(stack st)
    /* Arranges that the stack of graphic objects is drawn in the same thread
    as the ITK's Tcl interpreter was created, in order to eliminate delays due
    to sinchronization of threads and speed up interpretation.
    $A Igor jul03; */
{
char *com=NULL,*res=NULL,*ptr;
int code;
static int reccount=0;
++reccount;
if (reccount>1)
{
  --reccount;
  return 0;
} else
{  
/* The following line will check if the Tk window that corresponds to the
  current window still exists, and if not, it will be re-created: */
  /*
  int savedirectitk=directitk;
  directitk=0;
  gisetwindow(locitkwin);
  directitk=savedirectitk;
  */
  plotst=st;
  com=malloc(1000);
  ptr=com;
  if (loccursor!=NULL)
    /* to set cursor to indicate that the window is busy */
    ptr+=sprintf(ptr,"catch {%s configure -cursor %s } ;\n",locwindowstr,"watch");
  ptr+=sprintf(ptr,"itk_igs_plot ;\n "); /* to invoke plotting command */
  printf("Running ITK command:\n%s",com);
  res=itk_interpretcp(com,&code);
  disppointer((void **) &res);
  ptr=com;
  if (loccursor!=NULL)
    /* to restore window's cursor to the initial state */
    ptr+=sprintf(ptr,"%s configure -cursor {%s} ;",locwindowstr,loccursor);
  itk_sendcomcp(com);
  disppointer((void **) &com);
}
--reccount;
return 1;
}



static void xxx_tclinaturalwindowcoord(float x,float y,coord3d p)
    /* Pri transformaciji koordinat objektov v njihove okenske koordinate
    se pusti kar naravne koordinate.
    $A Igor apr97; */
{
p->x=x; p->y; p->z=0;
}


static void xxx_tcligpwindowcoord(float x,float y,coord3d p)
    /* Normalni okenski koordinati (ki gresta v obeh smereh od 0 do 1 s
    koordinatnim izhodiscem v spodnjem levem kotu) se pretvorita v okenski
    koordinati za format Tcl.
    $A Igor apr97; */
{
/* $$$ TO BE IMPLEMENTED! */
/*
p->x=tclistartx+x*tclisizex;
p->y=tclistarty+y*tclisizey;
p->z=0;
*/
}



/*
*/


/* FOR DEVELOPERS: 
TAKE CARE OF THESE FUNCTIONS! */

static void xxx_tclisetscaling(char scaling)
    /* Doloci skaliranje koordinat pri zapisu graficnih objektov v formatu Tcl.
    ce je scaling==0, postane funkcija tcliwindowcoord() za skaliranje koordinat
    kar funkcija tclinaturalwindowcoord(), ki ohranja naravne koordinate objektov,
    drugace pa to postane funkcija tcligpwindowcoord(), ki skalira koordinati x
    in y tako, kot se to naredi pri risanju na zaslon, koordinato z pa poskusa
    skalirati na podoben nacin.
    $A Igor <== apr97; */
{
/*
tcliscalecoordinates=scaling;
if (tcliscalecoordinates==0)
  tcliwindowcoord=tclinaturalwindowcoord;
else tcliwindowcoord=tcligpwindowcoord;
*/
}




static void xxx_tclsetwindowsize(int width,int height)
    /* Postavi sirino tcl-ovega okna, v katerem se izrise graf iz tcl-ove
    datoteke, na width, in visino na height. Ce je eden ali drugi 0, se
    ohranita dimenziji, ki sta trenutno nastavljeni.
    $A Igor maj01; */
{
  /*
if (width>0)
{
  tclwindowwidth=width;
  tclisizex=tclwindowwidth;
}
if (height>0)
{
  tclwindowheight=height;
  tclistarty=tclwindowheight;
  tclisizey=-tclwindowheight;
}
*/
}


static void xxx_tclisetwindowsize(double width,double height)
    /* Postavi sirino tcl-ovega okna, v katerem se izrise graf iz tcl-ove
    datoteke,xxx_ na width, in visino na height. Ce je eden ali drugi 0, se
    ohranita dimenziji, ki sta trenutno nastavljeni.
    $A Igor maj01; */
{
/*
if (width>0)
{
  tclwindowwidth=(int) width;
  tclisizex=tclwindowwidth;
}
if (height>0)
{
  tclwindowheight=(int) height;
  tclistarty=tclwindowheight;
  tclisizey=-tclwindowheight;
}
*/
}


static double xxx_tcligetwindowwidth(void)
    /* Vrne sirino trenutnega Tcl-ovega okna oz. skalirni faktor v smeri x.
    $A Igor maj01; */
{
/*
return fabs(tclisizex);
*/
}

static double xxx_tcligetwindowheight(void)
    /* Vrne visino trenutnega Tcl-ovega okna oz. skalirni faktor v smeri y.
    $A Igor maj01; */
{
/*
return fabs(tclisizey);
*/
}










static itkwin newitkwin(void)
    /* Allocates an empty itkwin structure and returns its pointer.
    $A Igor jul03; */
{
itkwin itkw;
itkw=malloc(sizeof(*itkw));
memset(itkw,0,sizeof(*itkw));
return itkw;
}

void dispitkwin(itkwin *wp)
    /* Deletes a dynamically allocated structure *wp and sets *wp to NULL.
    $A Igor jul03; */
{
itkwin itkw;
if ((itkw=*wp)!=NULL)
{
  disppointer((void *) &itkw->tkid);
  disppointer((void *) &itkw->forcewin);
  disppointer((void *) &itkw->windowtitle);
}
*wp=NULL;
}



int giinitdisplay(void)
{
return 1;
}

int giinitgraph(void)
{
return 1;
}


/* WARNING for programmers:
  When a window is closed, its ID can be used by another window that is opened
after that. This can make some errors more difficult to find, for example
operations on a window that has been closed already may become well defined
for a program just because some other window newly opened after this window
has been closed reused its ID. */



static void itkgiwindowcoord (float x,float y,coord3d p)
{
p->x=x*shariwindowwidth;
p->y=shariwindowheight*(1-y);
p->z=0;
}



static void itkinstalldefaultfonts(void);
int gisetwindow(int id);
static int fontinitialized=0;

int giopenwindow(void)
    /* Opens a new window, which also becomes the current plotting window of
    IGS. Returns the identification number of the opened whindow, through
    which the window can be accessed e.g. for closing, clearing, activating,
    etc.
      sharwindowwidth, sharwindowheight, sharwindowxpos and sharwindowxpos are
    used to determine the size and position of the window. These variables
    are set by commands like gisetwindowwidth(), ginsetwindowwidth(),
    gisetwindowxpos(), ginsetwindowxpos(), etc. 

    $A Igor jul03; */
{
int id=0,i=1,code=0;
char *tkname=NULL,*toplevel=NULL,ext[30],*ptr=NULL,*res=NULL;
itkwin itkw;
if (!fontinitialized)
  itkinstalldefaultfonts();
if (combuf==NULL)
  initgritk();
if (itkwindows==NULL)
  itkwindows=newstack(10);
i=1;
while (id<1 && i<=itkwindows->n)
{
  /* Look for a vacant ID on the window stack: */
  if (itkwindows->s[i]==NULL)
    id=i;
  ++i;
}
if (id<1)
{
  /* If no ID is vacant, add one: */
  pushstack(itkwindows,NULL);
  id=itkwindows->n;
}
itkw=newitkwin();
itkwindows->s[id]=itkw;
itkw->id=id;
/* Save opening settings: */
itkw->windowtitle=stringcopy(sharwindowtitle);
itkw->forcewin=stringcopy(locforcewin);
ptr=combuf;
if (0 /* stringlength(locforcewin)>0 */)
{
  locforcewin=NULL;
  /* TO BE IMPLEMENTED!!!! (uncomment also the condition!) */

} else
{
  /* Create a new toplevel window containing a canvas: */
  sprintf(ext,"%i",id);
  stringappend(&toplevel,ext);   /* Toplevel window */
  toplevel=stringcat(locitkwinprefix,ext);
  tkname=stringcat(toplevel,".c");
  ptr+=sprintf(ptr,"catch {toplevel %s} ;\n",toplevel);
  ptr+=sprintf(ptr,"catch {canvas %s -bg #FFFFFF -width %i -height %i} ;\n",
    tkname,shariwindowwidth,shariwindowheight);
  ptr+=sprintf(ptr,"catch {pack %s -expand 1 -fill both} ;\n",tkname);
  if (sharwindowxpos<1 && sharwindowypos<1)
  {
    ptr+=sprintf(ptr,"catch {wm geometry %s +%i+%i}; \n",
      toplevel,shariwindowxpos,shariwindowypos);
  }
  ptr+=sprintf(ptr,"catch {wm geometry %s {}}; \n",toplevel);
  if (sharwindowtitle!=NULL)
    ptr+=sprintf(ptr,"catch {wm title %s {%s}}",toplevel,sharwindowtitle);
  else
    /* This is not really necessary - change in the future? */
    ptr+=sprintf(ptr,"catch {wm title %s {igs - itk win. %i}}",toplevel,id);
  /*
  printf("\nITK command for opening the IGS window (length: %i):\n%s\n\n",
    strlen(combuf),combuf);
  */
  res=itk_interpretcp(combuf,NULL);
  disppointer((void **) &res);
  disppointer((void **) &toplevel);
  itkw->tkid=tkname;
  tkname=NULL;
  itkw->width=shariwindowwidth;
  itkw->height=shariwindowheight;
}
/* The following takes care of variables related to the current window */
gisetwindow(id);
runbufblock();
if (loccursor==NULL)
{
  /* Obtain common cursor shape if we don't have it yet: */
  ptr=combuf;
  ptr+=sprintf(ptr,"%s cget -cursor \n",locwindowstr);
  res=itk_interpretcp(combuf,&code);
  *combuf=0;
  if (tcl_okcode(code) /* stringlength(res)>0 */)
  {
    loccursor=res;
    res=NULL;
    if (loccursor==NULL)
      loccursor=stringcopy("");
  } else
    disppointer((void **) &res);
}
return id;
}



int gisetwindow(int id)
    /* Sets the window identified by id as the current plotting window.
    Returns 0 if for any reason the window identified by ID can not set to
    the current window (e.g. it does not exist or actual window has been
    closed outside the IGS).
      If the actual window does not exist (e.g. it was closed by user
    interaction), this function tries to reopen it.
    $A Igor jul03; */
{
int ret=0,code=0;
static int reclev=0; /* recursion counter */
char *ptr=NULL,*res=NULL;
itkwin itkw;
++reclev;
if (reclev==5)  /* prevent infinite recursion */
{
  errfunc0("gisetwindow");
  sprintf(ers(),"Infinite recursion when trying to activate window %i.\n",id);
  sprintf(ers(),"The attempt is given up, current window (%i) will be used.\n",locitkwin);
  errfunc2();
  return 0;
}
if (itkwindows==NULL)
  itkwindows=newstack(10);
if (id<0)
{
  errfunc0("gisetwindow");
  sprintf(ers(),"Non-positive window ID (%i) passed. Must be a positive integer.\n",id);
  errfunc2();
} else if (itkwindows->n<id)
{
  errfunc0("gisetwindow");
  sprintf(ers(),"There is no window identified by %i.\n",id);
  errfunc2();
} else
{
  if ((itkw=itkwindows->s[id])==NULL)
  {
    errfunc0("gisetwindow");
    sprintf(ers(),"There is no window identified by %i.\n",id);
    sprintf(ers(),"The corresponding data structure is NULL.\n");
    errfunc2();
  } else
  {
    /* Window structure with a specific id exists: */
    ptr=combuf;
    ptr+=sprintf(ptr,"winfo exists %s ;\n",itkw->tkid);
    res=itk_interpretcp(combuf,&code);
    if (!tcl_okcode(code))
    {
      errfunc0("gisetwindow");
      sprintf(ers(),"Existence of the tk window %s (ID %i)\n",itkw->tkid,id);
      sprintf(ers(),"could not be checked - Tcl error code %i, error:\n",code);
      checkminerbuf(stringlength(res)); /* Ensure that error buffer can hold the
                                        message */
      sprintf(ers(),"%s",res);
      errfunc2();
      disppointer((void **) &res);
    } else
    {
      if (!cmpstrings(res,"0"))
      {
        /* Actual window identified by id does not exist, we try to reopen the
        window in the same way as it has been opened initially: */
        char *saveforcewin=NULL,*savewindowtitle=NULL;
        int idnew,saveiwidth,saveiheight;
        float savewidth,saveheight;
        /* Save affected IGS settings and change them to the original settings
        for the window to be opened: */
        saveforcewin=locforcewin; locforcewin=itkw->forcewin;
        savewindowtitle=sharwindowtitle; sharwindowtitle=itkw->windowtitle;
        savewidth=sharwindowwidth;
        saveiwidth=shariwindowwidth; shariwindowwidth=itkw->width;
        saveheight=sharwindowheight;
        saveiheight=shariwindowheight; shariwindowheight=itkw->height;
        /* Try to re-open window: */
        idnew=giopenwindow();
        /* Restore affected IGS settings: */
        locforcewin=saveforcewin;
        sharwindowtitle=savewindowtitle;
        sharwindowwidth=savewidth; sharwindowheight=saveheight;
        shariwindowwidth=saveiwidth; shariwindowheight=saveiheight;
        dispitkwin(&itkw);  /* deallocate the old window structure */
        itkwindows->s[id]=NULL;
        if (idnew>0)
        {
          /* Change the ID of the newly created window to id and set itkw: */
          itkw=itkwindows->s[idnew];
          itkw->id=id;
          /*
          itkwindows->s[id]=NULL;
          */
          itkwindows->s[id]=itkw;
          itkwindows->s[idnew]=NULL;
        } else
        {
          /* Iv creation was not successful, we return, recursion level must be
          decremented back: */
          --reclev;
          return ret;
        }

        /* 
        errfunc0("gisetwindow");
        sprintf(ers(),"Re - creation of IGS ITK windows is not yet implemented.\n");
        sprintf(ers(),"You must take care that the IGS ITK windows are not closed\n");
        sprintf(ers(),"outside the IGS!\n");
        errfunc2();
        */
      }
      disppointer((void **) &res);
      if (itkw!=NULL)
      {
        ptr=combuf;
        ptr+=sprintf(ptr,"winfo exists %s ;\n",itkw->tkid);
        res=itk_interpretcp(combuf,&code);
      }
      if (!cmpstrings(res,"0") || res==NULL || !tcl_okcode(code))
      {
        disppointer ((void **) &res);
        errfunc0("gisetwindow");
        sprintf(ers(),"Can not set the current window to %i - actual window does not exist.\n",
          id);
        errfunc2();
      } else
      {
        ret=locitkwin=id;
        disppointer((void **) &res);
        /* The window exists, we update the data on the window structure: */
        sprintf(combuf,"winfo width %s ;\n",itkw->tkid);
        res=itk_interpretcp(combuf,&code);
        if (!tcl_okcode(code))
        {
          errfunc0("gisetwindow");
          sprintf(ers(),"IGS can not determine the actual width and height of the window %i.\n",
            id);
          errfunc2();
        } else
        {
          itkw->width=atol(res);
          disppointer((void **) &res);
          sprintf(combuf,"winfo height %s ;\n",itkw->tkid);
          res=itk_interpretcp(combuf,&code);
          if (!tcl_okcode(code))
          {
            errfunc0("gisetwindow");
            sprintf(ers(),"IGS can not determine the actual height of the window %i.\n",
              id);
            errfunc2();
          } else
          {
            itkw->height=atol(res);
            disppointer((void **) &res);
          }
        }
      }
      disppointer((void **) &res);
    }
    locwindowstr=itkw->tkid;
  }
  /* else
  {
    errfunc0("");
    sprintf(ers(),"Can not set the current window ID to %i: window does not exist.\n",
      id);
    errfunc2();
  }
  */
}
runbufblock();
--reclev;
return ret;
}



void giclearwindow(void)
     /* Deletes the contents of the active window.
    $A Igor jul03; */
{
sprintf(combuf,"catch {%s delete all}; \n",locwindowstr);
runbufblock();
}


void giresetwindow(void)
    /* Resets the currrent window. Window contents is deleted and its size is
    checked.
    $A Igor jul03; */
{
int code;
char *res=NULL;
sprintf(combuf,"catch {%s delete all}; \n",locwindowstr);
runbufblock();
if (locitkwin>0 && itkwindows!=NULL)
  if (itkwindows->n>=locitkwin)
  {
    itkwin w;
    w=itkwindows->s[locitkwin];
    if (w!=NULL)
    {
      /* Check the dimensions of the window: */
      sprintf(combuf,"winfo width %s; \n",locwindowstr);
      res=itk_interpretcp(combuf,&code);
      if (tcl_okcode(code))
        w->width=atol(res);
      disppointer((void **) &res);
      sprintf(combuf,"winfo height %s; \n",locwindowstr);
      res=itk_interpretcp(combuf,&code);
      if (tcl_okcode(code))
        w->height=atol(res);
      disppointer((void **) &res);
      shariwindowwidth=w->width;
      shariwindowheight=w->height;
    }
  }
}

void giclosewindow(void)
     /* Closes the current (active) windeow.
     $A Igor jul03; */
{
char *res=NULL;
int code;
if (locitkwin>0 && itkwindows!=NULL)
  if (itkwindows->n>=locitkwin)
  {
    if (ncmpstrings(locitkwinprefix,locwindowstr,
      stringlength(locitkwinprefix))==0)
    {
      /* IGS opened a new toplevel window to hold the canvas; the toplevel
      window is destroyed: */
      sprintf(combuf,"destroy [toplevel %s] ;\n",locwindowstr);
      res=itk_interpretcp(combuf,&code);
      disppointer((void **) &res);
    } else
    {
      /* The canvas window was created in an existent window or the existent
      canvas is used; only the canvas is unmaped, parent windows are not
      affected: */
      sprintf(combuf,"pack forget %s ;\n",locwindowstr);
      res=itk_interpretcp(combuf,&code);
      disppointer((void **) &res);
    }
    /* Window structure is deallocated so that window ID can be reused by
    another window: */
    if (itkwindows->s[locitkwin]!=NULL)
      dispitkwin((itkwin *) &(itkwindows->s[locitkwin]));
  }
}



void giraisewindow(void)
    /* Raises the current graphics window to the top of the window stack so
    that it is not obscured by other windows. */
{
sprintf(combuf,"catch \"raise [winfo toplevel %s]\"; \n",locwindowstr);
runbufblock();
}

int gigetwindow(void)
{
return locitkwin;
}


void giflushdisplay(void)
     /* Enforces drawing of everything from IGS what has not been drawn yet.
    $A Igor jul03; */
{
}



  /* BASIC FUNCTIONS FOR PLOTTING BY Tk: */




void itkinstallfont(int id,char *spec)
{
char *ptr;
if (combuf==NULL)
  initgritk();
ptr=combuf;
if (fonts->n>=id)
{
  if (fonts->s[id]!=NULL)
  {
    ptr+=sprintf(ptr,"font delete %s; ",fonts->s[id]);
  }
} else
  insstack(fonts,NULL,id);
if (fonts->s[id]==NULL)
{
  char *str;
  str=malloc(30);
  sprintf(str,"%i",id);
  fonts->s[id]=stringcat("ITK_IGS_font_",str);
  free(str); str=NULL;
}
ptr+=sprintf(ptr,"font create %s;\n",spec);
runbuf();
}


static void itkinstalldefaultfonts(void)
    /* Installs default fonts for the IGS system */
{
fontinitialized=1;
itkinstallfont(1,"courier");
itkinstallfont(2,"times");
itkinstallfont(3,"system");
itkinstallfont(4,"helvetica");
itkinstallfont(5,"lucida");
itkinstallfont(6,"swiss");
itkinstallfont(7,"ariel");
itkinstallfont(8,"script");
itkinstallfont(9,"terminal");
itkinstallfont(10,"symbol");
itkinstallfont(11,"greek");
itkinstallfont(12,"gothic");
}




static void printcolorhandlingstatus(void)
    /* Izpise nastavitve, ki se ticejo ravnanja z barvami. */
{
printf("IG coloring status:\n");
if (sharcoloring)
  printf("Using RGB colors.\n");
else
  printf("Using gray scale.\n");
if (sharnumshades==0)
  printf("Using continuous colors.\n");
else
{
  printf("Number of shades: %i\n",sharnumshades);
  printf("Number of colors: %i\n",sharnumdiscretecolors);
}
if (sharindexsize>0)
{
  printf("Size of index table: %i\n",sharindexsize);
  printf("Number of indeces used: %i\n",sharnumindices);
  if (sharnumindices==sharnumdiscretecolors)
    printf("Cells for all possible colors are allocated.\n");;
} else printf ("No indexing.\n");
}








void gicoloring(int yes)
    /* If yes is 0, then graphics will be plotted in grey, otherwise in colors.
    $A Igor jul03; */
{
if (yes)
  sharcoloring=1;
else
  sharcoloring=0;
}

void ginumshades(int num)
    /* Sets the number of shades for each color component to num (or the number
    of gray scales if coloring is switched off). If num is 0, the colors are
    contiguous, in this case also indexing can not be used on the systems where
    it can otherwise be enabled.
    $A Igor jul03; */
{
if (num<0)
  num=0;
if (num==1) /* Must be at least 2!!! */
  num=2;
if (num>1024)
  num=1024;
sharnumshades=num;
}

void gicolortabsize(int size)
    /* Sets the size of the table that stores indices of already allocated
    collor cells, to size. If size is 0, indexing is not used, which means that
    for use of any color the graphic underlying library is instructed to
    allocate the appropriate color cell, regardless of whether the color has
    been used before.
    With ITK, this does not have any effect (but does e.g. with Xlib)
    $A Igor jul03; */
{
if (size<0)
  size=0;
sharindexsize=size;
}

void gipreindexcolors(int yes)
    /* If yes is 0, then the requests for allocation of colors are sent to the
    library each time. If it is 1, then colors are allocated in advance at the
    initialization of the screen, if the table of indices is large enough.
      This function has no effect with ITK, but does w.g. with Xlib.
    $A Igor jul03; */
{
if (yes)
  sharpreindexall=1;
else
  sharpreindexall=0;
}





void gisetwindowtitle(char *title)
    /* Sets the window title for windows that will be open anew. If title is
    NULL, then the IGS chooses its own title when opening new toplevel
    windows, which distinguishes the IGS graphics windows from the others and
    also indicates the number of the window (recommended unless this would
    affect the look of the application in an undesired way, useful for
    debugging).
      The IGS makes a dynamic copy of the string title. Therefore, if a
    dynamically allocated string is passed as an argument, it can be
    deallocated after the function call.
    $A Igor jul03; */
{
if (sharwindowtitle!=NULL)
  free(sharwindowtitle);
sharwindowtitle=stringcopy(title);
}

char *gigetwindowtitle(void)
    /* Returns the current window title as has been set by the user. A pointer
    to the title is returned, therefore it may not be allocated or modified by
    the user.
      Warning:
    This function must be used with care when graphics is used by multiple
    threads.
    $A Igor jul03; */
{
return sharwindowtitle;
}

float gisetwindowxpos(float z)
    /* Sets the initial position of windows (upper left corner) at opening in
    the x direction to z where z is relative to screen width with the
    range from 0 to 1. If z is out of range (e.g. negative), the underlying
    graphic library will chose the window position position.
      The previous position is returned.
    $A Igor jul03; */
{
float ret;
ret=sharwindowxpos;
if (z>=0 && z<=1)
{
  sharwindowxpos=z;
  shariwindowxpos=1+(int) (z*(sharMAXX-1));
} else
{
  shariwindowxpos=(int) z;
  sharwindowxpos=(float) shariwindowxpos/(float) sharMAXX;
}
return ret;
}

float gigetwindowxpos(void)
    /* return the current position for opening new windows in the x direction
    relative to the screen width. Negative value means that the system chooses
    the position.
    $A Igor jul03; */
{
return sharwindowxpos;
}


float gisetwindowypos(float z)
    /* Sets the initial position of windows (upper left corner) at opening in
    the y direction to z where z is relative to screen height with the
    range from 0 to 1. If z is out of range (e.g. negative), the underlying
    graphic library will chose the window position position.
    $A Igor jul03; */
{
float ret;
ret=sharwindowypos;
if (z>=0 && z<=1)
{
  sharwindowypos=z;
  shariwindowypos=1+(int) (z*(sharMAXY-1));
} else
{
  shariwindowypos=(int) z;
  sharwindowypos=(float) shariwindowxpos/(float) sharMAXY;

}
return ret;
}

float gigetwindowypos(void)
    /* return the current position for opening new windows in the x direction
    relative to the screen width. Negative value means that the system chooses
    the position.
    $A Igor jul03; */
{
return sharwindowypos;
}




float gisetwindowwidth(float z)
    /* Sets the initial width of windows when they are open to z. Returns
    previous value. Possible range is from 0 to 1.
    $A Igor jul03; */
{
float ret;
ret=sharwindowwidth;
if (z>=0 && z<=1)
{
  sharwindowwidth=z;
  shariwindowwidth=(int) ( 1.0f+(z*(sharMAXX-1)) );
}
return ret;
}

float gigetwindowwidth(void)
    /* Returns the currently set value of the window width for newly open
    windows.
    $A Igor jul03; */
{
return sharwindowwidth;
}



float gisetwindowheight(float z)
    /* Sets the initial height of windows when they are open to z. Returns
    previous value. Possible range is from 0 to 1.
    $A Igor jul03; */
{
float ret;
ret=sharwindowheight;
if (z>=0 && z<=1)
{
  sharwindowheight=z;
  shariwindowheight=(int) ( 1+(z*(sharMAXY-1)) );
}
return ret;
}

float gigetwindowheight(void)
    /* Returns the currently set value of the window height for newly open
    windows.
    $A Igor jul03; */
{
return sharwindowheight;
}




int ginsetwindowxpos(int z)
    /* Sets the initial position for newly open windows in the x direction in
    pixels from the upper left corner of the screen. Negative vlaues imposes
    that the system can choose the position. The previous value is returned.
    If the value is greater than the screen widt, it is adjusted to the screen
    width. Negative values mean that the system is let to choose the position.
    $A Igor jul03; */
{
int ret;
ret=shariwindowxpos;
if (z<0)
{
  sharwindowxpos=-1;
  shariwindowxpos=-1;
} else
{
  if (z>sharMAXX)
    z=sharMAXX;
  sharwindowxpos=(float) z/sharMAXX;
  shariwindowxpos=z;
}
return ret;
}


int gingetwindowxpos(void)
    /* Returns the current position in the x direction in pixels from the
    upper-left corner of the screen for newly open windows (negative value
    means that the system positions newly open windows).
    $A Igor jul03; */
{
return shariwindowxpos;
}



int ginsetwindowypos(int z)
    /* Sets the initial position for newly open windows in the y direction in
    pixels from the upper left corner of the screen. Negative vlaues imposes
    that the system can choose the position. The previous value is returned.
    If the value is greater than the screen height, it is adjusted to the screen
    height. Negative values mean that the system is let to choose the position.
    $A Igor jul03; */
{
int ret;
ret=shariwindowypos;
if (z<0)
{
  sharwindowypos=-1;
  shariwindowypos=-1;
} else
{
  if (z>sharMAXY)
    z=sharMAXY;
  sharwindowypos=(float) z/sharMAXY;
  shariwindowypos=z;
}
return ret;
}


int gingetwindowypos(void)
    /* Returns the current position in the y direction in pixels from the
    upper-left corner of the screen for newly open windows (negative value
    means that the system positions newly open windows).
    $A Igor jul03; */
{
return shariwindowypos;
}





int ginsetwindowwidth(int z)
    /* Sets the initial width of newly open graphical windows in pixels and
    returns the previous value. If z is greater than the screen width, it is
    corrected do the screen width; if it is less than 1 then it is corrected
    to some reasonable value.
    $A Igor jul03; */
{
int ret;
if (z<1)
  z=100;
if (z>sharMAXX)
  z=sharMAXX;
ret=shariwindowwidth;
sharwindowwidth=(float) z/sharMAXX;
shariwindowwidth=z;
return ret;
}

int gingetwindowwidth(void)
    /* Returns the currently set width for newly open windows in pixels.
    $A Igor jul03; */
{
return shariwindowwidth;
}



int ginsetwindowheight(int z)
    /* Sets the initial height of newly open graphical windows in pixels and
    returns the previous value. If z is greater than the screen height, it is
    corrected do the screen heigth; if it is less than 1 then it is corrected
    to some reasonable value.
    $A Igor jul03; */
{
int ret;
if (z<1)
  z=100;
if (z>sharMAXY)
  z=sharMAXY;
ret=shariwindowheight;
sharwindowheight=(float) z/sharMAXY;
shariwindowheight=z;
return ret;
}

int gingetwindowheight(void)
    /* Returns the currently set height for newly open windows in pixels.
    $A Igor jul03; */
{
return shariwindowheight;
}



/* Settings for plotting points: */


float gisetpointsize(float size)
      /* Sets the size of points relative to screen width and height and
      returns the current size. The size must be within the range from 0 to 1.0
      inclusively. If it is out of range, some reasonable size is set.
      $A Igor jul03; */
{
float ret=sharpointsize;
if (size>0 && size<=1)
  sharpointsize=size;
else
  sharpointsize=0.01f;
return ret;
}

float gigetpointsize(void)
    /* Returns the current relative size for plotting points. 
    $A Igor jul03; */
{
return sharpointsize;
}


int gisetcurvepoints(int num)
    /* Sets the number of divisions for drawing curved objects such as circles,
    and returns the current number. If num is less than 4, then 4 points are
    used. If it is more than 4000, then 4000 points are used.
    $A Igor jul03; */
{
int ret=sharcurvepoints;
if (num<4)
  num=4;
else if (num>4000)
  num=4000;
sharcurvepoints=num;
return ret;
}

int gigetcurvepoints()
    /* Returns number of divisions used for drawing curved objects
    $A Igor jul03; */
{
return sharcurvepoints;
}




/* SETTING COLORS: */


/* Auxiliary functions for specifying colors in Tk: */

static void sprinthexcolor(char *str,float red,float green,float blue)
    /* Prints a 6 digit hexadecimal color specification starting by a leading
    '#' to the string str. Color components red, green and blue must be within
    the range [0.0,1.0]!
    $A Igor jul03; */
{
div_t res;
int digit;
sprintf(str,"#");  /* print leading '#' */
++str;
/* Red component: */
res=div((int) (red*255),16);
digit=res.quot;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
digit=res.rem;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
/* Green component: */
res=div((int) (green*255),16);
digit=res.quot;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
digit=res.rem;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
/* Blue component: */
res=div((int) (blue*255),16);
digit=res.quot;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
digit=res.rem;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
}



static void itksetcolor(float red,float green, float blue,truecolor col,
                      char *tkcol)
{
float c1;
if (!sharcoloring)
{
  /* Plotting in grey scale */
  c1=(red+green+blue)/3.0f;
  /* Force colors within the limits: */
  if (c1<0)
    c1=0.0;
  else if (c1>1.0)
    c1=1;
  if (sharnumshades>0 && sharnumshades<256)
  {
    /* Discretize colors: */
    c1=(float) round((double) c1 * ((double) sharnumshades-0.8))/
      ((float) sharnumshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (c1>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Grey level was set to %g>1 after discretization.\n",
        c1);
      errfunc2();
      c1=(float) 1;
    }
  }
  red=green=blue=c1;
} else
{
  /* Coloring; Force limits: */
  if (red<0.0) red=0.0; else if (red>1.0) red=1.0;
  if (green<0.0) green=0.0; else if (green>1.0) green=1.0;
  if (blue<0.0) blue=0.0; else if (blue>1.0) blue=1.0;
  if (sharnumshades>0 && sharnumshades<256)
  {
    /* Discretize colors: */
    red=(float) round((double) red * ((double) sharnumshades-0.8))/
      ((float) sharnumshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (red>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Red color component set to %g>1 after discretization.\n",
        red);
      errfunc2();
      red=(float) 1;
    }
    green=(float) round((double) green * ((double) sharnumshades-0.8))/
      ((float) sharnumshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (green>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Green color component set to %g>1 after discretization.\n",
        green);
      errfunc2();
      green=(float) 1;
    }
    green=(float) round((double) green * ((double) sharnumshades-0.8))/
      ((float) sharnumshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (green>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Red color component set to %g>1 after discretization.\n",
        green);
      errfunc2();
      green=(float) 1;
    }
  }
}
col->red=red;
col->green=green;
col->blue=blue;
sprinthexcolor(tkcol,red,green,blue);
}



void gisetlinecolor(float red,float green,float blue)
     /* Sets the color for drawing lines. Color components red, green and blue
     should be in the range between 0 and 1. Color discretization and grayscale
     conversion is performed if specified by the settings.
     $A Igor jul03; */
{
itksetcolor(red,green,blue,&sharlinecolor,loclinecolor);
}

void gigetlinecolor(float *red,float *green,float *blue)
    /* Sets *red, *green and *blue to the current values of RGB color
    components for drawing lines. These components are as have been set by the
    last call to the gisetlinecolor() and possibly updated according to the
    discrete shading or grayscale settings.
     $A Igor jul03; */
{
*red=sharlinecolor.red; *green=sharlinecolor.green; *blue=sharlinecolor.blue;
}


void gisetfillcolor(float red,float green,float blue)
     /* Sets the color for filling. Color components red, green and blue
     should be in the range between 0 and 1. Color discretization and grayscale
     conversion is performed if specified by the settings.
     $A Igor jul03; */
{
itksetcolor(red,green,blue,&sharfillcolor,locfillcolor);
}

void gigetfillcolor(float *red,float *green,float *blue)
    /* Sets *red, *green and *blue to the current values of RGB color
    components for filling. These components are as have been set by the
    last call to the gisetfillcolor() and possibly updated according to the
    discrete shading or grayscale settings.
     $A Igor jul03; */
{
*red=sharfillcolor.red; *green=sharfillcolor.green; *blue=sharfillcolor.blue;
}


void gisettextcolor(float red,float green,float blue)
     /* Sets the color for drawing text. Color components red, green and blue
     should be in the range between 0 and 1. Color discretization and grayscale
     conversion is performed if specified by the settings.
     $A Igor jul03; */
{
itksetcolor(red,green,blue,&sharfillcolor,loctextcolor);
}

void gigettextcolor(float *red,float *green,float *blue)
    /* Sets *red, *green and *blue to the current values of RGB color
    components for drawing text. These components are as have been set by the
    last call to the gisettextcolor() and possibly updated according to the
    discrete shading or grayscale settings.
     $A Igor jul03; */
{
*red=shartextcolor.red; *green=shartextcolor.green; *blue=shartextcolor.blue;
}



    /* LINE SETTINGS */

void gisetlinewidth(double width)
     /* Sets width of the lines to width. width should normally be an integer
     starting from 1. 
       WARNING - For programmers:
       This function should be replaced in the future in order to take integer
     arguments, possibly supplemented by one that takes floating point
     arguments. Handling for floating point values should be such that if they
     are less than 1, they are considered as relative width with respect to the
     window size, otherwise they are considered as width in window pixels.
     $A Igor jul03; */
{
if (width<0)
  width=0;
sharlinewidth=width;
if (width>=1)
  sharilinewidth=(int) width;
else
  sharilinewidth=1+(int) (width*(float) m_minval(shariwindowwidth,shariwindowheight));
}

double gigetlinewidth(void)
    /* Returns the current line width.
     $A Igor jul03; */
{
return sharlinewidth;
}



void gisetlinetype(int type)
     /* Sets the type of lines to type. If type is 1 then lines are continuous.
     $A Igor jul03; */
{
if( type<1)
  type=1;
else if (type>3)
  type=3;
sharlinetype=type;
}

int gigetlinetype(void)
    /* Returns the current line type.
     $A Igor jul03; */
{
return sharlinetype;
}



    /* TEXT SETTINGS: */



void gisettextprecision(float precision)
     /* This function is not yet elaborated and does currently not have any
     effect.
     $A Igor jul03; */
{
shartextprecision=0;
}

float gigettextprecision()
     /* This function is not yet elaborated and does currently not have any
     effect.
     $A Igor jul03; */
{
return shartextprecision;
}


void gisettextfont(int font)
     /* Sets the font that is used for plotting text.
     $A Igor jul03; */
{
if (font<1)
  font=1;
shartextfont=font;
}

int gigettextfont(void)
    /* Returns the current font that is used for plotting text strings.
    $A Igor jul03; */
{
return shartextfont;
}



void gisettextheight(float height)
     /* Sets the height of the plotted text. height can either specify the
     height relative to the window size, in which case it must be less than
     1 (0 means the smallest admissible height that is system dependent) or
     an integer meaning the height in pixels. Floating point values greater
     than 1 are rounded to the nearest integer. Values smaller than 0 are
     treated as 0.
     $A Igor jul03; */
{
if (height<0.0)
  height=(float) 6.0;
if (height>=1)
  shartextheight=(float) (int) height;
else
  shartextheight=1.0f+(int) (height*(float) m_minval(shariwindowwidth,shariwindowheight));
}

float gigettextheight(void)
{
return shartextheight;
}


void gisettextspacing(float spacing)
    /* Sets the size of spaces between the letters of plotted text strings.
      WARNING:
      This function is currently not standardised and it is better not to
     use it.
     $A Igor apr03; */
{
if (spacing<(float) 0.0)
  spacing=(float) 0.0;
shartextspacing=spacing;
}

float gigettextspacing(void)
    /* Returns the text spacing as it is currently set.
    $A Igor jul03; */
{
return shartextspacing;
}


void gisettextexpansion(float expansion)
     /* Sets the text expansion in the horizontal direction.
       WARNING:
       This function is currently not standardized and its use should be
     avoided.
    $A Igor jul03; */
{
if (expansion<=0.0f)
  expansion=1.0;
shartextexpansion=expansion;
}

float gigettextexpansion(void)
    /* Returns the text expansion as it is currently set.
    $A Igor jul03; */
{
return shartextexpansion;
}


void gisettextxalignment(int alignment)
    /* Sets the alignment of text in the horizontal direction. If alignment
    is -1 then text is aligned to the left of the anchor position, if it is
    0, the text is centered around the anchor position and if it is 1, the
    text is aligned to the right of the anchor position.
    $A Igor jul03; */
{
if (alignment<-1)
  alignment=-1;
else if (alignment>1)
  alignment=1;
shartextxalignment=alignment;
if (shartextxalignment==-1)
{
  if (shartextyalignment==-1)
    loctextanchor="sw";
  else if (shartextyalignment==0)
    loctextanchor="w";
  else if (shartextyalignment==1)
    loctextanchor="nw";
} else if (shartextxalignment==0)
{
  if (shartextyalignment==-1)
    loctextanchor="s";
  else if (shartextyalignment==0)
    loctextanchor="center";
  else if (shartextyalignment==1)
    loctextanchor="n";
} else
{
  if (shartextyalignment==-1)
    loctextanchor="se";
  else if (shartextyalignment==0)
    loctextanchor="e";
  else if (shartextyalignment==1)
    loctextanchor="ne";
}
}

int gigettextxalignment(void)
    /* Returns the current allignment of plotted text strings in the horizontal
    direction.
    $A Igor jul03; */
{
return shartextxalignment;
}



void gisettextyalignment(int alignment)
    /* Sets the alignment of text in the vertical direction. If alignment
    is -1 then text is aligned below the anchor position, if it is 0, the text
    is centered around the anchor position and if it is 1, the text is aligned
    above the anchor position.
    $A Igor jul03; */
{
if (alignment<-1)
  alignment=-1;
else if (alignment>1)
  alignment=1;
shartextyalignment=alignment;
if (shartextxalignment==-1)
{
  if (shartextyalignment==-1)
    loctextanchor="sw";
  else if (shartextyalignment==0)
    loctextanchor="w";
  else if (shartextyalignment==1)
    loctextanchor="nw";
} else if (shartextxalignment==0)
{
  if (shartextyalignment==-1)
    loctextanchor="s";
  else if (shartextyalignment==0)
    loctextanchor="center";
  else if (shartextyalignment==1)
    loctextanchor="n";
} else
{
  if (shartextyalignment==-1)
    loctextanchor="se";
  else if (shartextyalignment==0)
    loctextanchor="e";
  else if (shartextyalignment==1)
    loctextanchor="ne";
}
}

int gigettextyalignment(void)
    /* Returns the current allignment of plotted text strings in the vertical
    direction.
    $A Igor jul03; */
{
return shartextxalignment;
}



void gisettextalignment(int xalignment,int yalignment)
    /* Sets the alignment of text in both horizontal and vertical directions
    by using the functions gisettextxalignment() and settextyalignment().
    $A Igor jul03; */
{
gisettextxalignment(xalignment);
gisettextyalignment(yalignment);
}

void gigettextalignment(int *xalignment,int *yalignment)
    /* Returns the current allignment of the plotted text strings in the
    horizontal direction in *xalignment and in vertical direction in
    *yalignment. The pointer arguments may not be NULL.
    $A Igor jul03; */
{
*xalignment=shartextxalignment;  *yalignment=shartextyalignment;
}




/* WARNING - For programmers:
Implemented should be also plotting with integer coordinates!
Implement calculation of fp coordinates from window coordinates and vice versa!
*/



void giline(float x1,float y1,float x2,float y2)
    /* Draws a line with given relative window coordinates of endpoints.
    Current line drawing settings are used.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
itkgiwindowcoord(x2,y2,&p2);
sprintf(combuf,"%s create line %g %g %g %g -fill %s -width %i\n",
        locwindowstr,p1.x,p1.y,p2.x,p2.y,loclinecolor,sharilinewidth);
runbuf();
}


void gitriangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* Draws a frame triangle with given relative window coordinates of
    apices. Current line drawing settings are used.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
itkgiwindowcoord(x2,y2,&p2);
itkgiwindowcoord(x3,y3,&p3);
sprintf(combuf,"%s create line %g %g %g %g %g %g %g %g -fill %s -width %i\n",
        locwindowstr,p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,p1.x,p1.y,
        loclinecolor,sharilinewidth);
runbuf();
}


void gifourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* Draws a frame fourangle with given relative window coordinates of
    apices. Current line drawing settings are used.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
itkgiwindowcoord(x2,y2,&p2);
itkgiwindowcoord(x3,y3,&p3);
itkgiwindowcoord(x4,y4,&p4);
sprintf(combuf,"%s create line %g %g %g %g %g %g %g %g %g %g -fill %s -width %i\n",
        locwindowstr,p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,p4.x,p4.y,p1.x,p1.y,
        loclinecolor,sharilinewidth);
runbuf();
}


void gifilltriangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* Draws a filled triangle with given relative window coordinates of
    apices. Current fill settings are used.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
itkgiwindowcoord(x2,y2,&p2);
itkgiwindowcoord(x3,y3,&p3);
sprintf(combuf,"%s create polygon %g %g %g %g %g %g -fill %s\n",
        locwindowstr,p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,
        locfillcolor);
runbuf();
}


void gifillfourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* Draws a filled fourangle with given relative window coordinates of
    apices. Current fill settings are used.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
itkgiwindowcoord(x2,y2,&p2);
itkgiwindowcoord(x3,y3,&p3);
itkgiwindowcoord(x4,y4,&p4);
sprintf(combuf,"%s create polygon %g %g %g %g %g %g %g %g -fill %s\n",
        locwindowstr,p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,p4.x,p4.y,
        locfillcolor);
runbuf();
}


static void xxx_tclimarktextpos(char *str,float x,float y,char mark,char box)
    /* Currently not implemented. Supposed to mark the predicted position of
    the plotted text by a frame.
    $A Igor apr97; */
{
errfunc0("tclimarktextpos");
sprintf(ers(),"The function is currently not implemented.\n");
errfunc2();
}


void gitext(char *str,float x1,float y1)
    /* Plots the text strings at the relative window coordinates (x1,y1) with
    the current font settings.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
sprintf(combuf,"%s create text %g %g -text {%s} -fill %s -anchor %s -font \"%s %i\"\n",
        locwindowstr,p1.x,p1.y,str,loctextcolor,loctextanchor,
        loctextfontstr,sharitextheight);
/*
printf("Text command: \"%s\"\n",combuf);
*/
runbuf();
}



   /* BASIC ELEMENTS THAT ARE DRAWN BY OTHER DRAWING FUNCTIONS: */



void girectangle(float x1,float y1,float x2,float y2)
     /* Narise pravokotnik iz crt z nasprotileznima ogliscema (x1,y1) in
     (x2,y2). */
{
gifourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}


void gicircle(float x,float y,float r)
     /* Narise krog iz curvepoints crt s srediscem (x,y) in radijem r. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) sharcurvepoints);
x1=x+r;
y1=y;
for (i=1;i<=sharcurvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  giline((float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}


void gicirclearc(float x,float y,float r,float fi1,float fi2)
     /* Narise krozni lok iz curvepoints crt s srediscem (x,y), radijem r ter
     z zacetnim kotom fi1 in s koncnim kotom fi2. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) sharcurvepoints);
x1=x+r*cos(fi);
y1=y+r*sin(fi);
for (i=1;i<=sharcurvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  giline((float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}


void giellipse(float x,float y,float a,float b)
     /* Narise elipso iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) sharcurvepoints);
x1=x+a;
y1=y;
for (i=1;i<=sharcurvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  giline((float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}


void giellipsearc(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise elipsin lok iz sharcurvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri ter z zacetnim kotom fi1 in
     s koncnim kotom fi2. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) sharcurvepoints);
x1=x+a*cos(fi);
y1=y+b*sin(fi);
for (i=1;i<=sharcurvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  giline((float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}


void gifillrectangle(float x1,float y1,float x2,float y2)
     /* Narise zapolnjen pravokotnik s protileznima ogliscema (x1,y1) in
     (x2,y2). */
{
gifillfourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}

void gipoint(float x,float y)
     /* Narise tocko s koordinatami (x,y). Za barvo se uporalbja barva za
     polnjenje likov. */
{
gifillfourangle(x,y,x,y,x,y,x,y);
}




void gifillcircle(float x,float y,float r)
     /* Narise zapolnjen krog s srediscem v (x,y) in polmerom r iz sharcurvepoints
     zapolnjenih trikotnikov. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double)  sharcurvepoints);
x1=x+r;
y1=y;
for (i=1;i<=sharcurvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  gifilltriangle((float) x,(float) y,(float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}


void gifillcirclearc(float x,float y,float r,float fi1,float fi2)
     /* Narise zapolnjen krozni lok s srediscem (x,y), polmerom r ter zacetnim
     kotom fi1 in koncnim kotom fi2 zi sharcurvepoints zapolnjenih trikotnikov. Koti
     so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) sharcurvepoints);
x1=x+r*cos(fi);
y1=y+r*sin(fi);
for (i=1;i<=sharcurvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  gifilltriangle((float) x,(float) y,(float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}


void gifillellipse(float x,float y,float a,float b)
     /* Narise zapolnjeno elipso s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b iz sharcurvepoints zapolnjenih trikornikov. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) sharcurvepoints);
x1=x+a;
y1=y;
for (i=1;i<=sharcurvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  gifilltriangle((float) x,(float) y,(float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}


void gifillellipsearc(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise zapolnjen elipsin lok s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b ter zacetnim kotom fi1 in koncnim fi2 iz sharcurvepoints
     zapolnjenih trikornikov. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i=0;
fi=fi1;
hfi=(fi2-fi1)/((double) sharcurvepoints);
x1=x+a*cos(fi);
y1=y+b*sin(fi);
for (i=1;i<=sharcurvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  gifilltriangle((float) x,(float) y,(float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}








#if 0


static void tcliprinthead(void)
    /* V datoteko formata tcli izpise glavo, ki omogoca risanje. V glavi so
    definicija lupine, ki jo uporabimo za prikaz oken, nastavitve za risanje in
    definicije procedur za risanje osnovnih graficnih objektov.
    $A Igor apr97; */
{
if (fp!=NULL)
{
  /* Klic lipine wish: */
  fprintf(fp,"%s\n",tclishellstr);

  fprintf(fp,"bind . <Button-3> {quit 1}\n");     /* S 3. gumbom unicimo okno */
  fprintf(fp,"wm title . {%s}\n",tcliwindowtitle); /* Naslov glavnega okna */ 
  fprintf(fp,"set epsfilename %s\n",tcliepsoutfile);
  /* Definicija platna: */
  fprintf(fp,"canvas .c -width %i -height %i -bd 0\n",tclwindowwidth,tclwindowheight);
  fprintf(fp,"pack .c -side top -fill both -expand 1\n");
  fprintf(fp,".c config -bg #EEEEEE\n");
  /* Spodnje okno za sporocilo, gumba in vstavljanje: */
  fprintf(fp,"frame .fmes -bd 3 -relief sunken\n");
  fprintf(fp,"pack .fmes -side top -fill both\n");
  /* Sporocilo: */
  fprintf(fp,"message .fmes.m -text {Press <Quit> to destroy window or <Print> to write\\\n");
  fprintf(fp,"the canvas to a file in eps format. Pressing the third mouse button in\\\n");
  fprintf(fp,"the window also quits.} -width 550 -anchor center -bd 6\n");
  fprintf(fp,"pack .fmes.m -side top -fill both\n");
  /* Okvir za gumbe: */
  fprintf(fp,"frame .fmes.bot -bd 5\n");
  fprintf(fp,"pack .fmes.bot -side top -fill both\n");
  fprintf(fp,"button .fmes.bot.print -text Print -command {printeps $epsfilename}\n");
  fprintf(fp,"button .fmes.bot.quit -text Quit -command {quit 0}\n");
  fprintf(fp,"label .fmes.bot.lab -text {Name of the eps file:}\n");
  fprintf(fp,"entry .fmes.bot.eps -textvariable epsfilename\n");
  fprintf(fp,"pack .fmes.bot.quit  -side left -expand 1\n");
  fprintf(fp,"pack .fmes.bot.print -side left -expand 1\n");
  fprintf(fp,"pack  .fmes.bot.eps .fmes.bot.lab -side right -expand 1\n");
  fprintf(fp,"bind .fmes.bot.eps <FocusIn> {%cW select from 0 ; %cW select to end}\n",'%','%');
  fprintf(fp,"proc printeps x {\n");
  fprintf(fp,"global .c\n");
  fprintf(fp,".c postscript -file $x\n");
  fprintf(fp,"}\n");
  fprintf(fp,"proc quit x {\n");
  fprintf(fp,"global .\n");
  fprintf(fp,"destroy .\n");
  fprintf(fp,"}\n");
  fprintf(fp,"\n");
  
  if (0)
  {
  /* Naslov okna: */
  fprintf(fp,"wm title . {%s}\n",tcliwindowtitle);
  /* Sirina in visina okna: */
  fprintf(fp,"wm geometry . %ix%i\n",tclisizex,tclisizey);
  /* Definicija platna: */
  fprintf(fp,"canvas .c\n");
  /* Omogoci se spreminjanje velikosti platna: */
  fprintf(fp,"pack .c -side top -fill both -expand 1\n");
  }

  
  /* Nastavitve za risanje: */
  fprintf(fp,"set %s ",tclifillcolorstr);
   fwritehexcolor(fp,tclifillcolor.red,tclifillcolor.green,tclifillcolor.blue);
   fprintf(fp,"\n");
  
  fprintf(fp,"set %s ",tclilinecolorstr);
   fwritehexcolor(fp,tclilinecolor.red,tclilinecolor.green,tclilinecolor.blue);
   fprintf(fp,"\n");

  fprintf(fp,"set %s %i\n",tclilinewidthstr,tclilinewidth);
  
  fprintf(fp,"set %s ",tclitextcolorstr);
   fwritehexcolor(fp,tclitextcolor.red,tclitextcolor.green,tclitextcolor.blue);
   fprintf(fp,"\n");
  
  fprintf(fp,"set %s {times 10}\n",tclitextfontstr);
  
  fprintf(fp,"set %s center\n",tclitextanchorstr);
  
  /* Definicije procedur za risanje osnovnih objektov: */
  /* Procedura za risanje crt: */
  fprintf(fp,"\n");
  fprintf(fp,"proc %s {x1 y1 x2 y2} {\n",tclilinestr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclilinecolorstr);
  fprintf(fp," global %s\n",tclilinewidthstr);
  fprintf(fp," .c create line $x1 $y1 $x2 $y2 -fill $%s -width $%s\n",tclilinecolorstr,tclilinewidthstr);
  fprintf(fp,"}\n\n");
  /* Procedura za risanje trikotnikov iz crt: */
  fprintf(fp,"proc %s {x1 y1 x2 y2 x3 y3} {\n",tclitrianglestr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclilinecolorstr);
  fprintf(fp," global %s\n",tclilinewidthstr);
  fprintf(fp," .c create line $x1 $y1 $x2 $y2 $x3 $y3 $x1 $y1 -fill $%s -width $%s\n",tclilinecolorstr,tclilinewidthstr);
  fprintf(fp,"}\n\n");
  /* Procedura za risanje stirikotnikov iz crt: */
  fprintf(fp,"proc %s {x1 y1 x2 y2 x3 y3 x4 y4} {\n",tclifouranglestr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclilinecolorstr);
  fprintf(fp," global %s\n",tclilinewidthstr);
  fprintf(fp," .c create line $x1 $y1 $x2 $y2 $x3 $y3 $x4 $y4 $x1 $y1 -fill $%s -width $%s\n",tclilinecolorstr,tclilinewidthstr);
  fprintf(fp,"}\n\n");
  /* Procedura za risanje polnih trikotnikov: */
  fprintf(fp,"proc %s {x1 y1 x2 y2 x3 y3} {\n",tclifilltrianglestr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclifillcolorstr);
  fprintf(fp," .c create polygon $x1 $y1 $x2 $y2 $x3 $y3 -fill $%s\n",tclifillcolorstr);
  fprintf(fp,"}\n\n");
  /* Procedura za risanje polnih stirikotnikov: */
  fprintf(fp,"proc %s {x1 y1 x2 y2 x3 y3 x4 y4} {\n",tclifillfouranglestr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclifillcolorstr);
  fprintf(fp," .c create polygon $x1 $y1 $x2 $y2 $x3 $y3 $x4 $y4 -fill $%s\n",tclifillcolorstr);
  fprintf(fp,"}\n\n");
  /* Procedura za risanje teksta: */
  fprintf(fp,"proc %s {x1 y1 str} {\n",tclitextstr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclitextcolorstr);
  fprintf(fp," global %s\n",tclitextfontstr);
  fprintf(fp," global %s\n",tclitextanchorstr);
  fprintf(fp," .c create text $x1 $y1 -text $str -fill $%s -font $%s -anchor $%s\n",
   tclitextcolorstr,tclitextfontstr,tclitextanchorstr);
  fprintf(fp,"}\n\n");

  /* Ce ni instaliran nobena pisava, se instalirajo preddefinirane pisave: */
  if (tclifontpre==NULL || tclifontpost==NULL)
  {
    tcliinstalldefaultfonts();
  }
  fprintf(fp,"\n# ZACETEK RISBE:\n\n");
}
}



static void tcliprinttail(void)
    /* $A Igor apr97; */
{
if (fp!=NULL)
{
  fprintf(fp,"\n# KONEC RISBE.\n\n");
  /* Ukaz za izpis v formatu eps: */
  if (tcliepsoutfile!=NULL)
    fprintf(fp,"update\n");
}
}











          /************************************************************/
         /*          POSPLOSENE FUNKCIJE GRAFICNEGA VMESNIKA:        */
        /************************************************************/


double (*grigetwindowwidth) (void) =tcligetwindowwidth;

double (*grigetwindowheight) (void) =tcligetwindowheight;


void (*griline) (float,float,float,float)
             = giline;

void (*gritriangle) (float,float,float,float,float,float)
             = gitriangle;

void (*grifourangle) (float,float,float,float,float,float,float,float)
             = gifourangle;

void (*grifilltriangle) (float,float,float,float,float,float)
             = gifilltriangle;

void (*grifillfourangle) (float,float,float,float,float,float,float,float)
             = gifillfourangle;

void (*gritext) (char *,float,float)
             = gitext;






/* ENOTE, KI SE NARISEJO S PoMOCJO DRUGIH FUNKCIJ ZA IZRIS: */



void grirectangle0(float x1,float y1,float x2,float y2)
     /* Narise pravokotnik iz crt z nasprotileznima ogliscema (x1,y1) in
     (x2,y2). */
{
grifourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}


void gricircle0(float x,float y,float r)
     /* Narise krog iz sharcurvepoints crt s srediscem (x,y) in radijem r. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=(float) (4*asin(1)/(sharcurvepoints));
x1=x+r;
y1=y;
for (i=1;i<=sharcurvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+r*cos(fi));
  y2=(float) (y+r*sin(fi));
  griline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gricirclearc0(float x,float y,float r,float fi1,float fi2)
     /* Narise krozni lok iz sharcurvepoints crt s srediscem (x,y), radijem r ter
     z zacetnim kotom fi1 in s koncnim kotom fi2. Koti so v radianih. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(float) ((fi2-fi1)/(sharcurvepoints));
x1=(float) (x+r*cos(fi));
y1=(float) (y+r*sin(fi));
for (i=1;i<=sharcurvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+r*cos(fi));
  y2=(float) (y+r*sin(fi));
  griline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void griellipse0(float x,float y,float a,float b)
     /* Narise elipso iz sharcurvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=(float) (4*asin(1)/(curvepoints));
x1=x+a;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+a*cos(fi));
  y2=(float) (y+b*sin(fi));
  griline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void griellipsearc0(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise elipsin lok iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri ter z zacetnim kotom fi1 in
     s koncnim kotom fi2. Koti so v radianih. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(float) ((fi2-fi1)/(curvepoints));
x1=(float) (x+a*cos(fi));
y1=(float) (y+b*sin(fi));
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+a*cos(fi));
  y2=(float) (y+b*sin(fi));
  griline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void grifillrectangle0(float x1,float y1,float x2,float y2)
     /* Narise zapolnjen pravokotnik s protileznima ogliscema (x1,y1) in
     (x2,y2). */
{
grifillfourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}




void grifillcircle0(float x,float y,float r)
     /* Narise zapolnjen krog s srediscem v (x,y) in polmerom r iz curvepoints
     zapolnjenih trikotnikov. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=(float) (4*asin(1)/(curvepoints));
x1=x+r;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+r*cos(fi));
  y2=(float) (y+r*sin(fi));
  grifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void grifillcirclearc0(float x,float y,float r,float fi1,float fi2)
     /* Narise zapolnjen krozni lok s srediscem (x,y), polmerom r ter zacetnim
     kotom fi1 in koncnim kotom fi2 zi curvepoints zapolnjenih trikotnikov. Koti
     so v radianih. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(float) ((fi2-fi1)/(curvepoints));
x1=(float) (x+r*cos(fi));
y1=(float) (y+r*sin(fi));
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+r*cos(fi));
  y2=(float) (y+r*sin(fi));
  grifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void grifillellipse0(float x,float y,float a,float b)
     /* Narise zapolnjeno elipso s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b iz curvepoints zapolnjenih trikornikov. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=(float) ( 4*asin(1)/(curvepoints) );
x1=x+a;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) ( x+a*cos(fi) );
  y2=(float) ( y+b*sin(fi) );
  grifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void grifillellipsearc0(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise zapolnjen elipsin lok s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b ter zacetnim kotom fi1 in koncnim fi2 iz curvepoints
     zapolnjenih trikornikov. Koti so v radianih. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(float) ( (fi2-fi1)/curvepoints );
x1=(float) (x+a*cos(fi));
y1=(float) (y+b*sin(fi));
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+a*cos(fi));
  y2=(float) (y+b*sin(fi));
  grifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}






/* FUNKCIJE ZA RISANJE MARKERJEV: */


static void grimarker1(float x,float y,float size)
  /* Vodoravni kriz */
{
float step=size/2;
griline(x-step,y,x+step,y);
griline(x,y+step,x,y-step);
}

static void grimarker2(float x,float y,float size)
  /* Posevni kriz */
{
float step=size*sin45/2;
griline(x-step,y-step,x+step,y+step);
griline(x-step,y+step,x+step,y-step);
}

static void grimarker3(float x,float y,float size)
{
}

static void grimarker4(float x,float y,float size)
{
}

static void grimarker5(float x,float y,float size)
{
}

static void grimarker6(float x,float y,float size)
{
}

static void grimarker7(float x,float y,float size)
{
}

static void grimarker8(float x,float y,float size)
{
}

static void grimarker9(float x,float y,float size)
{
}

static void grimarker10(float x,float y,float size)
{
}

static void grimarker11(float x,float y,float size)
{
}


static void (*gridefaultmarker) (float x,float y,float size) = grimarker1;
static stack grimarkerstack=NULL;

static void griinitmarkerstack(void)
{
grimarkerstack=newstack(5);
pushstack(grimarkerstack,(void *) grimarker1);
pushstack(grimarkerstack,(void *) grimarker2);
/*
pushstack(grimarkerstack,(void *) grimarker3);
pushstack(grimarkerstack,(void *) grimarker4);
pushstack(grimarkerstack,(void *) grimarker5);
pushstack(grimarkerstack,(void *) grimarker6);
pushstack(grimarkerstack,(void *) grimarker7);
pushstack(grimarkerstack,(void *) grimarker8);
pushstack(grimarkerstack,(void *) grimarker9);
pushstack(grimarkerstack,(void *) grimarker10);
pushstack(grimarkerstack,(void *) grimarker11);
pushstack(grimarkerstack,(void *) grimarker12);
pushstack(grimarkerstack,(void *) grimarker13);
pushstack(grimarkerstack,(void *) grimarker14);
pushstack(grimarkerstack,(void *) grimarker15);
pushstack(grimarkerstack,(void *) grimarker16);
pushstack(grimarkerstack,(void *) grimarker17);
*/
}

void grimarker0(float x,float y,float size,int kind)
    /* Narise marker velikosti size in vrste kind pri koordinatah (x,y). */
{
void (*marker) (float x,float y,float size)=gridefaultmarker;
/* Ce je potrebno, se na sklad markerstack nalozijo funkcije za izris
markerjev: */
if (grimarkerstack==NULL)
  griinitmarkerstack();
/* S sklada markerstack se vzame ustrezna funkcija. Ce funkcije za zahtevano
vrsto markerja ni na skladu, ostane ta funkcija defaultmarker. */
if (kind>0 && kind<=grimarkerstack->n)
  if (grimarkerstack->s[kind]!=NULL)
    marker= (void(*)(float,float,float)) grimarkerstack->s[kind];
marker(x,y,size);
}



void griarrow0(float x1,float y1,float x2,float y2,float size,float angle,
            char l,char f,char kind)
  /* Narise puscico od (x1,y1) do (x2,y2) z velikostjo glave size in korom
  puscice angle. line doloca izris linijske stresice, fill pa zapolnjene
  trikotne glave (0 - se ne izrise, 1 - se izrise)
  $A Igor maj01; */
{
float cosfi,sinfi,wcosfi,wsinfi,length,cx,cy,px1,py1,px2,py2,width,height,
       aspectratio;
griline(x1,y1,x2,y2);
if (l!='0' && l!=0 || f!='0' && f!=0)
{
  /* Da lahko narisemo puscice v nepopaceni obliki, rabimo razmerje med visino
  in sirino okna: */
  width=(float) grigetwindowwidth();
  height=(float) grigetwindowheight();
  aspectratio=height/width;
  /* Kosinus in sinus kota, ki ga oklepa crta z vodoravnico, v realnih
  koordinatah (od 0.0 do 1.1): */
  cosfi=(float) ( (x2-x1)/(length=(float) sqrt(sqr(x2-x1)+sqr(y2-y1))) );
  sinfi=(y2-y1)/length;
  /* Kosinus in sinus kota, ki ga oklepa crta z vodoravnico, v okenskih
  (t.j. celih) koordinatah: */
  wcosfi=(float) ( (x2-x1)/(length=(float) sqrt(sqr(x2-x1)+sqr(aspectratio*(y2-y1)))) );
  wsinfi=aspectratio*(y2-y1)/length;
  /* Velikost moramo skalirati tako, da bo absolutna velikost glave pri vseh
  kotih, ki jih puscica oklepa z vodoravnico, enaka v okenskih koord; velikost
  se skalira glede na visino okna in ne glede na sirino (faktor aspectratio): */
  size*=(float) ( aspectratio/sqrt(sqr(sinfi)+sqr(cosfi/aspectratio)) );
  if (kind=='r' || kind=='R')
    size*=length;
  /* Tocka, kjer glava seka crto: */
  cx=x2-size*cosfi; cy=y2-size*sinfi;
  /* Za izracun pravokotnice rabimo naklonski kot v okenskih koordinatah,
  realne x koordinate pa moramo mnoziti z aspectratio, da se ohranijo koti (tj.
  razmerja med x in y) v okenskih koordinatah: */
  /* Prvi in drugi vogal puscice (simetricno na (cx,xy)) : */
  size*=angle;
  px1=cx-aspectratio*size*wsinfi;   py1=cy+size*wcosfi;
  px2=cx+aspectratio*size*wsinfi;   py2=cy-size*wcosfi;
  if (f!='0' && f!=0)
  {
    /* Izris zapolnjene glave: */
    grifilltriangle(px1,py1,px2,py2,x2,y2);
  }
  if (l=='T' || l=='t')
  {
    /* Izris glave kot trikotnika iz crt: */
    gritriangle(px1,py1,px2,py2,x2,y2);
  } else if (l!='0' && l!=0)
  {
    /* Izris puscice iz crt */
    griline(px1,py1,x2,y2);
    griline(px2,py2,x2,y2);
  }
}
}



void (*grirectangle) (float,float,float,float)
             = girectangle;

void (*gricircle) (float x,float y,float r)
             = gicircle;

void (*gricirclearc) (float x,float y,float r,float fi1,float fi2)
            =  gicirclearc;

void (*griellipse) (float x,float y,float a,float b)
            = giellipse;

void (*griellipsearc) (float x,float y,float a,float b,float fi1,float fi2)
            =  giellipsearc;

void (*grifillrectangle) (float x1,float y1,float x2,float y2)
            =  gifillrectangle;

void (*grifillcircle) (float x,float y,float r)
            =  gifillcircle;

void (*grifillcirclearc) (float x,float y,float r,float fi1,float fi2)
            =  gifillcirclearc;

void (*grifillellipse) (float x,float y,float a,float b)
            =  gifillellipse;

void (*grifillellipsearc) (float x,float y,float a,float b,float fi1,float fi2)
            =  gifillellipsearc;

void (*grimarker) (float,float,float,int)
             = gimarker;

void (*griarrow) (float x1,float y1,float x2,float y2,float size,float angle,
                  char l,char f,char kind)
             = giarrow;







/* FUNKCIJE ZA IZPIS GLAVE IN REPA V DATOTECNIH FORMATIH: */

void (*griprinthead) (void)=giprinthead;

void (*griprinttail) (void)=giprinttail;






/* FUNKCIJE ZA NASTAVITEV VMESNIKA OZ. FORMATA: */

stack grifuncstack=NULL;

static void * grintfunc[24]={0};
/* Hranilnik, kamor se shranejo vrednosti posplosenih funkcij graficnega
vmsnika pri klicu funkcije grisavefunc() oziroma iz katerega se te vrednosti
restavrirajo pri klicu funkcije grirestorefunc(). */


void grisavefunc(void)
    /* Shrane trenutne vrednosti kazalcev na funkcije vmesnika.
    POZOR: Paziti je treba, da ima tabela grintfunc dovolj elementov! Ce se
    dodajajo nove funkcije, ki se lahko shranejo s to funkcijo in restavrirajo
    z grirestorefunc(), je hkrati treba povecati dimenzijo tabele grintfunc.
    $A Igor apr97; */
{
grintfunc[0]=(void *) griline;
grintfunc[1]=(void *) gritriangle;
grintfunc[2]=(void *) grifourangle;
grintfunc[3]=(void *) grifilltriangle;
grintfunc[4]=(void *) grifillfourangle;
grintfunc[5]=(void *) gritext;

grintfunc[6]=(void *) grirectangle;
grintfunc[7]=(void *) gricircle;
grintfunc[8]=(void *) gricirclearc;
grintfunc[9]=(void *) griellipse;
grintfunc[10]=(void *) griellipsearc;
grintfunc[11]=(void *) grifillrectangle;
grintfunc[12]=(void *) grifillcircle;
grintfunc[13]=(void *) grifillcirclearc;
grintfunc[14]=(void *) grifillellipse;
grintfunc[15]=(void *) grifillellipsearc;
grintfunc[16]=(void *) grimarker;
grintfunc[17]=(void *) griarrow;

grintfunc[18]=(void *) griprinthead;
grintfunc[19]=(void *) griprinttail;

grintfunc[20]=(void *) grigetwindowwidth;
grintfunc[21]=(void *) grigetwindowheight;

}


void grirestorefunc(void)
    /* Restavrira vrednosti kazalcev na funkcije vmesnika, kakrsne je shranila
    funkcija grisavefunc().
    $A Igor apr97; */
{
griline= (void (*) (float,float,float,float))
        grintfunc[0];
gritriangle= (void (*) (float,float,float,float,float,float))
            grintfunc[1];
grifourangle= (void (*) (float,float,float,float,float,float,float,float))
             grintfunc[2];
grifilltriangle= (void (*) (float,float,float,float,float,float))
                grintfunc[3];
grifillfourangle= (void (*) (float,float,float,float,float,float,float,float))
                 grintfunc[4];
gritext= (void (*) (char *,float,float))
        grintfunc[5];

grirectangle= (void (*) (float,float,float,float))
          grintfunc[6];
gricircle= (void (*) (float,float,float))
          grintfunc[7];
gricirclearc= (void (*) (float,float,float,float,float))
          grintfunc[8];
griellipse= (void (*) (float,float,float,float))
          grintfunc[9];
griellipsearc= (void (*) (float,float,float,float,float,float))
          grintfunc[10];
grifillrectangle= (void (*) (float,float,float,float))
          grintfunc[11];
grifillcircle= (void (*) (float,float,float))
          grintfunc[12];
grifillcirclearc= (void (*) (float,float,float,float,float))
          grintfunc[13];
grifillellipse= (void (*) (float,float,float,float))
          grintfunc[14];
grifillellipsearc= (void (*) (float,float,float,float,float,float))
          grintfunc[15];

grimarker= (void (*) (float,float,float,int))
          grintfunc[16];
griarrow=  (void (*) (float,float,float,float,float,float,char,char,char))
          grintfunc[17];

griprinthead= (void (*) (void))
             grintfunc[18];
griprinttail= (void (*) (void))
             grintfunc[19];

grigetwindowwidth=(double (*)(void))
             grintfunc[20];
grigetwindowheight=(double (*)(void))
             grintfunc[21];
}

void grisavefunc1(void)
    /* Shrane trenutne vrednosti kazalcev na funkcije vmesnika.
    $A Igor apr97; */
{
if (grifuncstack==NULL)
  grifuncstack=newstack(4);
pushstack(grifuncstack,(void *) griline);
pushstack(grifuncstack,(void *) gritriangle);
pushstack(grifuncstack,(void *) grifourangle);
pushstack(grifuncstack,(void *) grifilltriangle);
pushstack(grifuncstack,(void *) grifillfourangle);
pushstack(grifuncstack,(void *) gritext);
pushstack(grifuncstack,(void *) grimarker);
}

void grirestorefunc1(void)
    /* Restavrira vrednosti kazalcev na funkcije vmesnika, kakrsne je shranila
    funkcija grisavefunc().
    $A Igor apr97; */
{
if (grifuncstack!=NULL)
{
grimarker= (void (*) (float,float,float,int)) popstack(grifuncstack);
gritext= (void (*) (char *,float,float)) popstack(grifuncstack);
grifillfourangle= (void (*) (float,float,float,float,float,float,float,float)) popstack(grifuncstack);
grifilltriangle= (void (*) (float,float,float,float,float,float)) popstack(grifuncstack);
grifourangle= (void (*) (float,float,float,float,float,float,float,float)) popstack(grifuncstack);
gritriangle= (void (*) (float,float,float,float,float,float)) popstack(grifuncstack);
griline= (void (*) (float,float,float,float)) popstack(grifuncstack);
}
}


void setgrintdisp(void)
    /* $A Igor apr97; */
{
fp=NULL;
griline=giline;
gritriangle=gitriangle;
grifourangle=gifourangle;
grifilltriangle=gifilltriangle;
grifourangle=gifillfourangle;
gritext=gitext;

grirectangle=girectangle;
gricircle=gicircle;
gricirclearc=gicirclearc;
griellipse=giellipse;
griellipsearc=giellipsearc;
grifillrectangle=gifillrectangle;
grifillcircle=gifillcircle;
grifillcirclearc=gifillcirclearc;
grifillellipse=gifillellipse;
grifillellipsearc=gifillellipsearc;

grimarker=gimarker;

griprinthead=giprinthead;
griprinttail=giprinttail;
}


void setgrintps(FILE *outfile)
    /* $A Igor apr97; */
{
fp=outfile;
if (fp==NULL)
  printf("Error in module grfint: output graphic file not open.\n");
grigetwindowwidth=psigetwindowwidth;
grigetwindowheight=psigetwindowheight;

griline=psiline;
gritriangle=psitriangle;
grifourangle=psifourangle;
grifilltriangle=psifilltriangle;
grifillfourangle=psifillfourangle;
gritext=psitext;

grirectangle=grirectangle0;
gricircle=gricircle0;
gricirclearc=gricirclearc0;
griellipse=griellipse0;
griellipsearc=griellipsearc0;
grifillrectangle=grifillrectangle0;
grifillcircle=grifillcircle0;
grifillcirclearc=grifillcirclearc0;
grifillellipse=grifillellipse0;
grifillellipsearc=grifillellipsearc0;

grimarker=grimarker0;
griarrow=griarrow0;

griprinthead=psiprinthead;
griprinttail=psiprinttail;
}



void setgrinttcl(FILE *outfile)
    /* $A Igor apr97; */
{
fp=outfile;
if (fp==NULL)
  printf("Error in module grfint: output graphic file not open.\n");
grigetwindowwidth=tcligetwindowwidth;
grigetwindowheight=tcligetwindowheight;

griline=tcliline;
gritriangle=tclitriangle;
grifourangle=tclifourangle;
grifilltriangle=tclifilltriangle;
grifillfourangle=tclifillfourangle;
gritext=tclitext;

grimarker=grimarker0;
griarrow=griarrow0;

grirectangle=grirectangle0;
gricircle=gricircle0;
gricirclearc=gricirclearc0;
griellipse=griellipse0;
griellipsearc=griellipsearc0;
grifillrectangle=grifillrectangle0;
grifillcircle=grifillcircle0;
grifillcirclearc=grifillcirclearc0;
grifillellipse=grifillellipse0;
grifillellipsearc=grifillellipsearc0;

griprinthead=tcliprinthead;
griprinttail=tcliprinttail;
}


void setgrintdxf(FILE *outfile)
    /* $A Igor apr97; */
{
fp=outfile;
if (fp==NULL)
  printf("Error in module grfint: output graphic file not open.\n");
grigetwindowwidth=dxfigetwindowwidth;
grigetwindowheight=dxfigetwindowheight;

griline=dxfiline;
gritriangle=dxfitriangle;
grifourangle=dxfifourangle;
grifilltriangle=dxfifilltriangle;
grifillfourangle=dxfifillfourangle;
gritext=dxfitext;

grirectangle=grirectangle0;
gricircle=gricircle0;
gricirclearc=gricirclearc0;
griellipse=griellipse0;
griellipsearc=griellipsearc0;
grifillrectangle=grifillrectangle0;
grifillcircle=grifillcircle0;
grifillcirclearc=grifillcirclearc0;
grifillellipse=grifillellipse0;
grifillellipsearc=grifillellipsearc0;

grimarker=grimarker0;
griarrow=griarrow0;

griprinthead=dxfiprinthead;
griprinttail=dxfiprinttail;
}


#endif  /* if 0 */





