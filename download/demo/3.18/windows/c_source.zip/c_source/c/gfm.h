
#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include <mtypes.h>
#include <st.h>
#include <strop.h>
#include <fop.h>

#include <er.h>


typedef struct{
        int i;
        double x,y,z;
        } _nodcoord;

typedef _nodcoord *nodcoord;

typedef struct{
        int i,
        x,y,z;
        } _nodconstr;

typedef _nodconstr *nodconstr;





int comparenodenumbers(void *p1,void *p2)
    /* Primerja vozlisci, ki sta zapisani v podatku tipa nodcoord, po zapored.
    stevilki. Funkcija vrne -1, ce je zap. stevilka vozlisca p1 manjsa od
    zaporedne stevilke vozlisca p2, 0, ce sta koordinati enaki, drugace pa 1.
    */
{
nodcoord n1,n2;
n1= (nodcoord) p1; n2= (nodcoord) p2;
if (n1==NULL || n2==NULL)
  return 0;
else if (n1->i<n2->i)
  return -1;
else if (n1->i==n2->i)
  return 0;
else return 1;
}




int comparenodexcoords(void *p1,void *p2)
    /* Primerja vozlisci, ki sta zapisani v podatku tipa nodcoord, po velikosti
    koordinate x. Funkcija vrne -1, ce je koordinata x vozlisca p1 manjsa od
    ustrezne koordinate vozlisca p2, 0, ce sta koordinati enaki, drugace pa 1.
    */
{
nodcoord n1,n2;
n1= (nodcoord) p1; n2= (nodcoord) p2;
if (n1==NULL || n2==NULL)
  return 0;
else if (n1->x<n2->x)
  return -1;
else if (n1->x==n2->x)
  return 0;
else return 1;
}




int comparenodeycoords(void *p1,void *p2)
    /* Primerja vozlisci, ki sta zapisani v podatku tipa nodcoord, po velikosti
    koordinate y. Funkcija vrne -1, ce je koordinata y vozlisca p1 manjsa od
    ustrezne koordinate vozlisca p2, 0, ce sta koordinati enaki, drugace pa 1.
    */
{
nodcoord n1,n2;
n1= (nodcoord) p1; n2= (nodcoord) p2;
if (n1==NULL || n2==NULL)
  return 0;
else if (n1->y<n2->y)
  return -1;
else if (n1->y==n2->y)
  return 0;
else return 1;
}



int comparenodezcoords(void *p1,void *p2)
    /* Primerja vozlisci, ki sta zapisani v podatku tipa nodcoord, po velikosti
    koordinate z. Funkcija vrne -1, ce je koordinata z vozlisca p1 manjsa od
    ustrezne koordinate vozlisca p2, 0, ce sta koordinati enaki, drugace pa 1.
    */
{
nodcoord n1,n2;
n1= (nodcoord) p1; n2= (nodcoord) p2;
if (n1==NULL || n2==NULL)
  return 0;
else if (n1->z<n2->z)
  return -1;
else if (n1->z==n2->z)
  return 0;
else return 1;
}



stack createimage(stack list,stack reference)
      /* Vrne sklad, na katerega so nalozeni kazalci na vsa tista vozlisca na
      skladu s2, ki so tudi na skladu s1. Ce je kateri od skladov prazen, je
      tudi rezultat funkcije prazen sklad in ce je kateri od skladov enak NULL,
      je taksen tudi rezultat. Na sklad, ki ga vrne fukcija, so nalozeni le
      kazalci na vozlisca na sklasu reference, prostor za zapis vozlisc se torej
      ne rezervira! */
{
stack ret=NULL;
int i,j;
if (list!=NULL && reference!=NULL)
{
  ret=newstack(20);
  if (list->n!=0 && reference->n!=0)
  {
    for (i=1;i<=list->n; ++i)
    {
      j=findstack(reference,list->s[i],0,0,comparenodenumbers);
      if (j>0)
      {
        pushstack(ret,reference->s[j]);
      }
    }
  }
}
return ret;
}



stack createhardimage(stack list,stack reference,int size)
      /* Podobno kot createimage, le, da se ne skopirajo kazalci, ki so na
      skladu, ampak objekti, na katere ti kazalci kazejo. Zato funkcija rabi
      dodaten argument size, ki je velikost taksnega objekta v bytih. */
{
stack ret=NULL;
int i,j;
void *p;
if (list!=NULL && reference!=NULL)
{
  ret=newstack(5);
  if (list->n!=0 && reference->n!=0)
  {
    for (i=1;i<=list->n; ++i)
    {
      j=findstack(reference,list->s[i],0,0,comparenodenumbers);
      if (j>0)
      {
        /*  pushstack(ret,reference->s[j]);  */
        p=malloc(size);
        pushstack(ret,p);
        memcpy(p,reference->s[j],size);
      }
    }
  }
}
return ret;
}





long copyfilepart(FILE *fp1,long from,long to,FILE *fp2,int bufsize)
    /* Iz datoteke fp1 skopira del od byta from do vkljucno byta to (steti se
    zacne z 1) na datoteko fp2. Zapis na datoteko fp2 se zacne pri trenutni
    poziciji v tej datoteki. Bufsize je velikost pomoznega pomnilnika.
      Funkcija vrne stevilo uspesno prenesenih bytov.
      Ce je to enak 0, postane enak dolzini datoteke. */
{
long ret=0,rd=0,length,all;
void *buf=NULL;
int doread,wasread,waswritten;
char end=0;
length=flength(fp1);
if (fp1!=NULL && fp2!=NULL && from>0 && from<=length && (to>from || to==0) )
{
  if (to==0) to=length;
  if (to>length) to=length;
  if (bufsize<=0) bufsize=500;
  all=to-from+1;    /* toliko bytov naj bi se prepisalo */
  if (bufsize>all) bufsize=all;
  buf=malloc(bufsize);
  fseek(fp1,from-1,SEEK_SET);
  while (!end)
  {
    doread=all-rd;
    if (doread>bufsize)
      doread=bufsize;
    wasread=fread(buf,1,doread,fp1);
    rd+=wasread;
    waswritten=fwrite(buf,1,wasread,fp2);
    ret+=waswritten;
    if (feof(fp1) || rd>=all)
      end=1;
  }
fflush(fp2);
}
if (buf!=NULL)
  free(buf);
return ret;
}



int ffindnodefield(char *keystr,FILE *fp,long from,long *first,long *last)
     /* V vhodni datoteki za program Elfen fp najde vozliscno polje, doloceno
     z nizom keystr (za vozliscne koordinate je to npr. "NODE COORDINATES", za
     predpisane pomike "PRESCRIBED DISPLACEMENTS" itd.). Funkcija vrne zacetek
     polja v begin (1. znak za tistim \n ali \r, ki je v isti vrstici kot
     niz keystr) in konec v end (znak \n ali \r za zadnjim zapisom vozlisca).
     Funkcija vrne stevilo vozlisc, ki so zabelezena v polju.
     */
{
int buflength=1000,ret=0,length;
double x;
char end=0,ch;
long pos,pos1,pos2;
*first=*last=-1;
if (from<=0) from=1;
pos=filestring(fp,keystr,from,buflength);
if (pos<=0)
  ret=-1;
else
{
  ret=0;
  pos=filechar(fp,"\n\r",2,pos,20);
  if (pos<=0)
    end=1;
  pos1=filenotchar(fp,"\n\r",3,pos,20);
  if (pos1>0) *first=pos1;
  while (!end)
  {
    *last=pos;
    pos1=filenotchar(fp,"\n\r ",3,pos,20);
    x=filenum(fp,pos,20,&pos2,&length);
    if (pos2<=0)
      end=1;
    else if (pos1!=pos2)
    {
      fileread(&ch,1,1,fp,pos1);
      if (ch!='*')
        end=1;
      else
        pos=filechar(fp,"\n\r",2,pos1,50);
      if (pos<=0)
        end=1;
    } else
    {
      ++ret;
      pos=filechar(fp,"\n\r",2,pos2,20);
      if (pos<=0)
      {
        pos=0;
        end=1;
      }
    }
  }
}
return ret;
}






int fresfindnodefield(char *keystr,FILE *fp,long from,long *first,long *last)
     /* V datoteki rezultatov programa Elfen fp najde vozliscno polje, doloceno
     z nizom keystr (za vozliscne koordinate je to npr. "NODE COORDINATES", za
     predpisane pomike "PRESCRIBED DISPLACEMENTS" itd.). Funkcija vrne zacetek
     polja v begin (1. znak za tistim \n ali \r, ki je v isti vrstici kot
     niz keystr) in konec v end (znak \n ali \r za zadnjim zapisom vozlisca).
     Funkcija vrne stevilo vozlisc, ki so zabelezena v polju.
     */
{
int buflength=1000,ret=0,length,passes=0;
double x;
char end=0,ch;
long pos,pos1,pos2;
*first=*last=-1;
if (from<=0) from=1;
pos=filestring(fp,keystr,from,buflength);
if (pos<=0)
  ret=-1;
else
{
  ret=0;
  pos=filechar(fp,"\n\r",2,pos,20);
  if (pos<=0)
    end=1;
  pos1=filenotchar(fp,"\n\r",3,pos,20);
  if (pos1>0) *first=pos1;
  while (!end)
  {
    ++passes;
    *last=pos;
    pos1=filenotchar(fp,"\n\r ",3,pos,20);
    x=filenum(fp,pos,20,&pos2,&length);
    if (passes==1) pos1=pos2;
    if (pos2<=0)
      end=1;
    else if (pos1!=pos2)
    {
      fileread(&ch,1,1,fp,pos1);
      if (ch!='*')
        end=1;
      else
        pos=filechar(fp,"\n\r",2,pos1,50);
      if (pos<=0)
        end=1;
    } else
    {
      ++ret;
      pos=filechar(fp,"\n\r",2,pos2,20);
      if (pos<=0)
      {
        pos=0;
        end=1;
      }
    }
  }
}
return ret;
}






int freadnodefield(char *keystr,FILE *fp,long from,stack nod)
     /* Iz vhodne datoteke za program Elfen fp prebere vozliscno polje, doloceno
     z nizom keystr (za vozliscne koordinate je to npr. "NODE COORDINATES", za
     predpisane pomike "PRESCRIBED DISPLACEMENTS" itd.) z njihovimi koordinatami
     in jih nalozi na sklad nod. Podatki o vozliscih so nalozeni v podatke tipa
     nodcoord.
     */
{
int buflength=1000,ret=0,length;
double x;
char end=0,ch;
long pos,pos1,pos2;
nodcoord nc=NULL;
if (from<=0) from=1;
if (nod==NULL)
{
  end=1;
  ret=-1;
}
pos=filestring(fp,keystr,from,buflength);
if (pos<=0)
  ret=-1;
else
{
  if (!end)
    nc=malloc(sizeof(*nc));
  pos=filechar(fp,"\n\r",2,pos,20);
  if (pos<=0)
  {
    end=1;
    ret=-1;
  }
  while (!end)
  {

    /* printf("1 "); */

    pos1=filenotchar(fp,"\n\r ",3,pos,20);
    x=filenum(fp,pos,20,&pos2,&length);

    /* printf("2 "); */

    if (pos2<=0)
      end=1;
    else if (pos1!=pos2)
    {

      /* printf("3 "); */

      fileread(&ch,1,1,fp,pos1);
      if (ch!='*')
        end=1;
      else
        pos=filechar(fp,"\n\r",2,pos1,50);
      if (pos<=0)
        end=1;

      /* printf("4 "); */

    } else
    {

      /* printf("5 "); */

      nc->i=(int) x;
      nc->x=0;
      nc->y=0;
      nc->z=0;
      pos=filechar(fp,"\n\r",2,pos2,50);

      /* printf("6 "); */

      if (pos<=0)
      {
        pos=0;
        end=1;
      }
      x=filenumto(fp,pos2+length,pos,20,&pos2,&length);

      /* printf("7 "); */

      if (pos2>0)
      {

        /* printf("8 "); */

        nc->x=x;
        x=filenumto(fp,pos2+length,pos,20,&pos2,&length);

        /* printf("9 "); */

        if (pos2>0)
        {
          nc->y=x;
          x=filenumto(fp,pos2+length,pos,20,&pos2,&length);

          /* printf("10 "); */

          if (pos2>0)
          {
            nc->z=x;
          }
        }
      }

      /*
      printf("11 ");
      */

      pushstack(nod,nc);
      nc=malloc(sizeof(*nc));
    }
  }
}
if (nc!=NULL)
  free(nc);
return ret;
}



int freadnodecoords(FILE *fp,long from,stack nod)
{
freadnodefield("NODE COORDINATES",fp,from,nod);
}

int freadnodeprescdisp(FILE *fp,long from,stack nod)
{
freadnodefield("PRESCRIBED DISPLACEMENTS",fp,from,nod);
}

int fnreadnodecoords(FILE *fp,int which,stack nod)
    /* Iz datoteke fp prebere polje vozliscnih koordinat z zaporedno stevilko
    which glede na mesto pojave (ce je v datoteki vec polj, ki opisujejo
    vozliscne koordinate). */
{
int n;
long from;
stack st=NULL;
st=newstack(5);
if (nod==NULL || which<0) return -1;
n=filestringall(fp,"NODE COORDINATES",1,1000,st);
if ( n>0 && (which==0 || n>=which) )
{
  if (which==0) which=n;
  from=* (long *) st->s[which];
  freadnodefield("NODE COORDINATES",fp,from,nod);
  if (nod->n>0)
    return nod->n;
  else
    return -1;
} else return -1;
}

int fnreadnodeprescdisp(FILE *fp,int which,stack nod)
    /* Iz datoteke fp, ki je vhodna datoteka za direktno analizo, prebere polje
    predpisanih pomikov z zaporedno stevilko which glede na mesto v datoteki
    (ce je v datoteki vec polj, ki opisujejo predpisane pomike). */
{
int n;
long from;
stack st=NULL;
st=newstack(5);
if (nod==NULL || which<0) return -1;
n=filestringall(fp,"PRESCRIBED DISPLACEMENTS",1,1000,st);
if ( n>0 && (which==0 || n>=which) )
{
  if (which==0) which=n;
  from=* (long *) st->s[which];
  freadnodefield("PRESCRIBED DISPLACEMENTS",fp,from,nod);
  if (nod->n>0)
    return nod->n;
  else
    return -1;
} else return -1;
}







int fresreadnodefield(char *keystr,FILE *fp,long from,stack nod)
     /* Iz datoteke rezultatov za program Elfen fp prebere vozliscno polje, doloceno
     z nizom keystr (za vozliscne koordinate je to npr. "NODE COORDINATES", za
     predpisane pomike "PRESCRIBED DISPLACEMENTS" itd.) z njihovimi koordinatami
     in jih nalozi na sklad nod. Podatki o vozliscih se nalozijo v podatke tipa
     nodcoord.
     */
{
int buflength=1000,ret=0,length,passes=0;
double x;
char end=0,ch;
long pos,pos1,pos2;
nodcoord nc=NULL;

/*
FILE *err=0;
err=fopen("0err","w");
*/

if (from<=0) from=1;
if (nod==NULL)
{
  end=1;
  ret=-1;
}
pos=filestring(fp,keystr,from,buflength);
if (pos<=0)
  ret=-1;
else
{
  if (!end)
    nc=malloc(sizeof(*nc));
  pos=filechar(fp,"\n\r",2,pos,20);
  if (pos<=0)
  {
    end=1;
    ret=-1;
  }
  while (!end)
  {
    ++passes;

    /*
    fprintf(err,"\n P%i ",passes);
    fflush(err);
    fprintf(err,"1 "); fflush(err);
    */

    pos1=filenotchar(fp,"\n\r ",3,pos,20);
    x=filenum(fp,pos,20,&pos2,&length);
    if (passes==1) pos1=pos2;

    /*
    fprintf(err,"2 "); fflush(err);
    */

    if (pos2<=0)
      end=1;
    else if (pos1!=pos2)
    {

      /*
      fprintf(err,"3 "); fflush(err);
      */

      fileread(&ch,1,1,fp,pos1);
      if (ch!='*')
        end=1;
      else
        pos=filechar(fp,"\n\r",2,pos1,50);
      if (pos<=0)
        end=1;

      /*
      fprintf(err,"4 "); fflush(err);
      */

    } else
    {

      /*
      fprintf(err,"5 "); fflush(err);
      */

      nc->i=(int) x;
      nc->x=0;
      nc->y=0;
      nc->z=0;
      pos=filechar(fp,"\n\r",2,pos2,50);

      /*
      fprintf(err,"6 "); fflush(err);
      */

      if (pos<=0)
      {
        pos=0;
        end=1;
      }
      x=filenumto(fp,pos2+length,pos,20,&pos2,&length);

      /*
      fprintf(err,"7 "); fflush(err);
      */

      if (pos2>0)
      {

        /*
        fprintf(err,"8 "); fflush(err);
        */

        nc->x=x;
        x=filenumto(fp,pos2+length,pos,20,&pos2,&length);

        /*
        fprintf(err,"9 "); fflush(err);
        */

        if (pos2>0)
        {

          nc->y=x;
          x=filenumto(fp,pos2+length,pos,20,&pos2,&length);

          /*
          fprintf(err,"10 "); fflush(err);
          */

          if (pos2>0)
          {
            nc->z=x;
          }
        }
      }

      /*
      fprintf(err,"11 "); fflush(err);
      fprintf(err,"X "); fflush(err);
      */

      pushstack(nod,nc);
      nc=malloc(sizeof(*nc));
    }
  }
}
if (nc!=NULL)
  free(nc);

/*
fclose(err);
*/

return ret;
}



int fresreadnodecoords(FILE *fp,long from,stack nod)
{
fresreadnodefield("NODE COORDINATES",fp,from,nod);
}

int fresreadnodeprescdisp(FILE *fp,long from,stack nod)
{
fresreadnodefield("PRESCRIBED DISPLACEMENTS",fp,from,nod);
}

int fresnreadnodecoords(FILE *fp,int which,stack nod)
    /* Iz datoteke fp, ki je datoteka rezultatov direktne analize, prebere polje
    vozliscnih koordinat z zaporedno stevilko which glede na mesto v datoteki
    (ce je v datoteki vec polj, ki opisujejo predpisane pomike). */
{
int n;
long from;
stack st=NULL;
st=newstack(5);
if (nod==NULL || which<0) return -1;
n=filestringall(fp,"NODE COORDINATES",1,1000,st);
if ( n>0 && (which==0 || n>=which) )
{
  if (which==0) which=n;
  from=* (long *) st->s[which];
  fresreadnodefield("NODE COORDINATES",fp,from,nod);
  if (nod->n>0)
    return nod->n;
  else
    return -1;
} else return -1;
}

int fresnreadnodeprescdisp(FILE *fp,int which,stack nod)
    /* Iz datoteke fp, ki je datoteka rezultatov direktne analize, prebere polje
    predpisanih pomikov z zaporedno stevilko which glede na mesto v datoteki
    (ce je v datoteki vec polj, ki opisujejo predpisane pomike). */
{
int n;
long from;
stack st=NULL;
st=newstack(5);
if (nod==NULL || which<0) return -1;
n=filestringall(fp,"NODE COORDINATES",1,1000,st);
if ( n>0 && (which==0 || n>=which) )
{
  if (which==0) which=n;
  from=* (long *) st->s[which];
  fresreadnodefield("PRESCRIBED DISPLACEMENTS",fp,from,nod);
  if (nod->n>0)
    return nod->n;
  else
    return -1;
} else return -1;
}








void fwritenodecoords(FILE *fp,stack nodes,int dim)
     /* V datoteko fp izpise polje vozliscnih koordinat, nalozenih na sklad 
     nodes. Izpis se zacne pri trenutni poziciji v datoteki. dim je dimenzija
     polja, ki se izpise. */
{
int i;
nodcoord nc;
if (nodes==NULL)
  fprintf(fp,"  PRAZEN SKLAD.\n");
else if (nodes->n<=0)
  fprintf(fp,"  NA SKLADU NI NOBENEGA VOZLISCA.\n");
else
{
  for (i=1; i<=nodes->n; ++i)
  {
    nc= (nodcoord) nodes->s[i];
    if (nc!=NULL)
    {
      fprintf(fp,"  %-5i  %15.10g",nc->i,nc->x);
      if (dim>=2)
        fprintf(fp,"  %15.10g",nc->y);
      if (dim>=3)
        fprintf(fp,"  %15.10g",nc->z);
      fprintf(fp,"\n");
    }
  }
}
if (fp!=NULL) fflush(fp);
}









int freadnodeconstr(FILE *fp,stack nod)
     /* Iz vhodne datoteke za program Elfen fp prebere 1. polje podpor vozlisc v
     datoteki in jih nalozi na sklad nod. Podatki o vozliscih se nalozijo v
     podatke tipa nodcoonstr.
     */
{
int buflength=1000,ret=0,length;
double x;
char *keystr="RESTRAINED NODES",end=0,ch,cstr[3];
long pos,pos1,pos2;
nodconstr nc=NULL;
if (nod==NULL)
{
  end=1;
  ret=-1;
}
pos=filestring(fp,keystr,1,buflength);
if (pos<=0)
  ret=-1;
else
{
  if (!end)
    nc=malloc(sizeof(*nc));
  pos=filechar(fp,"\n\r",2,pos,20);
  if (pos<=0)
  {
    end=1;
    ret=-1;
  }
  while (!end)
  {
    pos1=filenotchar(fp,"\n\r ",3,pos,20);
    x=filenum(fp,pos,20,&pos2,&length);
    if (pos2<=0)
      end=1;
    else if (pos1!=pos2)
    {
      fileread(&ch,1,1,fp,pos1);
      if (ch!='*')
        end=1;
      else
        pos=filechar(fp,"\n\r",2,pos1,50);
      if (pos<=0)
        end=1;
    } else
    {
      nc->i=(int) x;
      nc->x=0;
      nc->y=0;
      nc->z=0;
      pos=filechar(fp,"\n\r",2,pos2,20);
      if (pos<=0)
      {
        pos=0;
        end=1;
      }
      x=filenumto(fp,pos2+length,pos,20,&pos2,&length);
      if (pos2>0)
      {
        cstr[0]=cstr[1]=cstr[2]='0';
        fileread(cstr,1,3,fp,pos2);
        if (cstr[0]=='1')
          nc->x=1;
        if (cstr[1]=='1')
          nc->y=1;
        if (cstr[2]=='1')
          nc->z=1;
      }
      pushstack(nod,nc);
      nc=malloc(sizeof(*nc));
    }
  }
}
if (nc!=NULL)
  free(nc);
return ret;
}



int fnreadnodeconstr(FILE *fp,int which,stack nod)
     /* Iz vhodne datoteke za program Elfen fp prebere polje podpor vozlisc z
     zapovrstno stevilko which; podatke nalozi na sklad nod in so tipa
     nodcoonstr.
     */
{
int buflength=1000,ret=0,length;
double x;
char *keystr="RESTRAINED NODES",end=0,ch,cstr[3];
int n;
long pos,pos1,pos2,from;
nodconstr nc=NULL;
stack st=NULL;
st=newstack(5);
if (nod==NULL || which<0) return -1;
n=filestringall(fp,keystr,1,1000,st);
if ( n>0 && (which==0 || n>=which) )
{
  if (which==0) which=n;
  from=* (long *) st->s[which];
} else return -1;
if (nod==NULL)
{
  end=1;
  ret=-1;
}
pos=filestring(fp,keystr,from,buflength);
if (pos<=0)
  ret=-1;
else
{
  if (!end)
    nc=malloc(sizeof(*nc));
  pos=filechar(fp,"\n\r",2,pos,20);
  if (pos<=0)
  {
    end=1;
    ret=-1;
  }
  while (!end)
  {
    pos1=filenotchar(fp,"\n\r ",3,pos,20);
    x=filenum(fp,pos,20,&pos2,&length);
    if (pos2<=0)
      end=1;
    else if (pos1!=pos2)
    {
      fileread(&ch,1,1,fp,pos1);
      if (ch!='*')
        end=1;
      else
        pos=filechar(fp,"\n\r",2,pos1,50);
      if (pos<=0)
        end=1;
    } else
    {
      nc->i=(int) x;
      nc->x=0;
      nc->y=0;
      nc->z=0;
      pos=filechar(fp,"\n\r",2,pos2,20);
      if (pos<=0)
      {
        pos=0;
        end=1;
      }
      x=filenumto(fp,pos2+length,pos,20,&pos2,&length);
      if (pos2>0)
      {
        cstr[0]=cstr[1]=cstr[2]='0';
        fileread(cstr,1,3,fp,pos2);
        if (cstr[0]=='1')
          nc->x=1;
        if (cstr[1]=='1')
          nc->y=1;
        if (cstr[2]=='1')
          nc->z=1;
      }
      pushstack(nod,nc);
      nc=malloc(sizeof(*nc));
    }
  }
}
if (nc!=NULL)
  free(nc);
return ret;
}




void fwritenodeconstr(FILE *fp,stack nodes,int dim)
     /* V datoteko fp zapise polje vozliscnih podpor, ki so nalozene na skladu
     nodes (podatki morajo biti tipa nodconstr). dim je dimenzija polja. */
{
int i;
nodconstr nc;
if (nodes==NULL)
  fprintf(fp,"  PRAZEN SKLAD.\n");
else if (nodes->n<=0)
  fprintf(fp,"  NA SKLADU NI NOBENEGA VOZLISCA.\n");
else
{
  for (i=1; i<=nodes->n; ++i)
  {
    nc= (nodconstr) nodes->s[i];
    if (nc!=NULL)
    {
      fprintf(fp,"  %i  ",nc->i);
      if (nc->x==0)
        fprintf(fp,"0");
      else
        fprintf(fp,"1");
      if (dim>=2)
      {
        if (nc->y==0)
          fprintf(fp,"0");
       else
          fprintf(fp,"1");
      }
      if (dim>=3)
      {
        if (nc->z==0)
          fprintf(fp,"0");
       else
          fprintf(fp,"1");
      }
      fprintf(fp,"\n");
    }
  }
}
if (fp!=NULL) fflush(fp);
}




int filereplacefield(char *filename1,char *filename2,char *keystr,long from,
                     stack field,int dim,int bufsize)
    /* V datoteki z imenom filename1 nadomesti vozliscno polje, ki ga doloca
    keystr, z vrednostmi, ki so zapisane na skladu field (elementi na tem skladu
    morajo biti tipa nodcoord!). Novo vsebino datoteke zapise v datoteko z
    imenom filename2 (1. datoteka ostane nespremenjena, 2. pa se prepise).
    Pojav polja, ki se nadomesti, se isce od pozicije from naprej (ce je v
    1. datoteki vec polj z istim imenom, se nadomesti 1. ustrezno polje od
    pozicije from naprej).
      dim je stevilo prostostnih stopenj vsakega vozlisca, bufsize pa velikost
    pomoznega pomnilnika.
    */
{
int num,ret=0;
long first,last;
FILE *fp1,*fp2;
if (bufsize<=0)
  bufsize=500;
fp1=fopen(filename1,"r");
fp2=fopen(filename2,"w");
if (fp1!=NULL && fp2!=NULL && keystr!=NULL && field!=NULL)
{
  num=ffindnodefield(keystr,fp1,from,&first,&last);
  if (num>0)
  {
    if (first>0)
      copyfilepart(fp1,1,first-1,fp2,bufsize);
    fwritenodecoords(fp2,field,dim);
    if (last>0)
      copyfilepart(fp1,last+1,0,fp2,bufsize);
  } else
  {
    copyfilepart(fp1,1,0,fp2,bufsize);
  }
} else ret=-1;
if (fp1!=NULL) fclose(fp1);
if (fp2!=NULL) fclose(fp2);
return ret;
}






int gennewconstr(FILE *fp1,int which1,FILE *fp2,int which2,stack st)
    /* Generira taksno polje vozliscnih podpor, kot je potrebno, da nadomestimo
    polje podpor z zapovrstno stevilko which1 iz datoteke fp1 s podporami z za-
    povrstno stevilko which2 iz datoteke fp2. Polje se na lozi na sklad st v
    obliki podatkov tipa nodconstr. */
{
stack st1=NULL,st2=NULL;
int ret=-1,n1,n2,i,j,k,dopush;
nodconstr nc1,nc2;
if (fp1!=NULL && fp2!=NULL && which1>=0 && which2>=0 && st!=NULL)
{
  st1=newstack(5);
  st2=newstack(5);
  n1=fnreadnodeconstr(fp1,which1,st1);
  n2=fnreadnodeconstr(fp2,which2,st2);

  printf("V 1. datoteki:\n");
  fwritenodeconstr(stdout,st1,2);
  printf("V 2. datoteki:\n");
  fwritenodeconstr(stdout,st2,2);
  printf("Zamenjava:\n");

  if (st1->n>0)
  {
    for (i=1;i<=st1->n; ++i)
    {
      j=findstack(st2,st1->s[i],0,0,comparenodenumbers);
      if (j<=0)
      {
        /* Podpore vozlisc, ki so na 1. skladu, niso pa na drugem, se postavijo
        na nic in potisnejo na sklad st (ce so v tem primeru podpore enake 0 v
        vseh smereh, se ne potisnejo na sklad): */
        nc1=st1->s[i];
        st1->s[i]=NULL;
        dopush=0;
        if (nc1->x!=0) dopush=1;
        if (nc1->y!=0) dopush=1;
        if (nc1->z!=0) dopush=1;
        nc1->x=0; nc1->y=0; nc1->z=0;
        if (dopush)
          pushstack(st,nc1);
      }
    }
    for (i=1;i<=st1->n; ++i)
    {
      if (st1->s[i]!=NULL)
        j=findstack(st2,st1->s[i],0,0,comparenodenumbers);
      else j=0;
      if (j>0)
      {
        /* Podpore vozlisc, ki so na 1. in 2. skladu, se vzamejo z 2. sklada in
        se potisnejo na sklad st. Na obeh skladih se ustrezna mesta nadomestijo
        z nictimi kazalci. */
        free(st1->s[i]);  st1->s[i]=NULL;
        nc2=st2->s[j];
        st2->s[j]=NULL;
        pushstack(st,nc2);
      }
    }
    if (st2->n>0)
      for (i=1; i<=st2->n; ++i)
      {
        if (st2->s[i]!=NULL)
        {
          pushstack(st,st2->s[i]);
          st2->s[i]=NULL;
        }
      }
  }
ret=st->n;
}
return ret;
}



/*

void transformnodesold(stack st1,stack st2)
{
nodcoord n1,n2;
double y1,y2,y3,y4;
int i,i1,i2,i3,i4;
for (i=1;i<=st2->n;++i)
{
  n2=st2->s[i];
  n1=st1->s[i];
  n2->x-=-5.123456789;
  n2->x-=n1->x;
  n2->y=0; n2->z=0;
}
}

*/




static int nearesty(double y,stack st)
    /* Na skladu st najde vozlisce, ki ima koordinato y najblizje y in vrne
    zaporedno stevilko vozlisca na skladu. Vozlisca morajo biti na skladu
    urejena po narascajocem vrstnem redu glede na koordinato y. */
{
int i;
nodcoord nc1,nc2;
i=1;
nc2=st->s[i];
while (nc2->y<=y && i<st->n)
{
  ++i;
  nc2=st->s[i];
}
if (i==1)
  nc1=nc2;
else
  nc1=st->s[i-1];
if (fabs(nc2->y-y)<fabs(nc1->y-y))
  return i;
else
  return i-1;
}

static double calcx(double y)
       /* Izracuna koordinato x vozlisca na desni povrsini orodja iz znane
       koordinate y (pri ravni povrsini orodja). */
{
double x0,y0,pi=3.141593;
x0=20.2;  y0=49;   /* Zgornja desna tocka na orodju */
return x0+(y0-y)*tan(pi/180);
}

void transformnodes(char *fname,stack st1,stack st2)
{
long pos;
nodcoord n1,n2;
double x1,x2,x3,x4,x10,x20,x30,x40,y1,y2,y3,y4,y10,y20,y30,y40,
       ycent=17.4641,xup=20.2,yup=49,ydown=0,
       a,b,dr,dz,k,kx,ky,ki;
int length,i,i1,i2,i3,i4,mindif;
FILE *fp=NULL;
mindif=2; /* Minimalno stevilo vozlisc v enem odseku zleba */
/* Branje vrednosti parametrov a,b,dr in dz iz datoteke: */
fp=fopen(fname,"r");
pos=filestring(fp,"a:",1,100);
a=filenum(fp,pos,40,&pos,&length);
pos=filestring(fp,"b:",1,100);
b=filenum(fp,pos,40,&pos,&length);
pos=filestring(fp,"dr:",1,100);
dr=filenum(fp,pos,40,&pos,&length);
pos=filestring(fp,"dz:",1,100);
dz=filenum(fp,pos,40,&pos,&length);
fclose(fp);   fp=NULL;
/* Izracun koordinat ogljisc zleba: */
y1=ycent-0.5*a-b+dz;
y2=ycent-0.5*a+dz;
y3=ycent+0.5*a+dz;
y4=ycent+0.5*a+b+dz;
x1=calcx(y1);
x2=calcx(y2)-dr;
x3=calcx(y3)-dr;
x4=calcx(y4);
/* Izracuna se, katera vozlisca naj se pomaknejo v posamezna oglisca zleba: */
i1=nearesty(y1,st2);
i2=nearesty(y2,st2);
i3=nearesty(y3,st2);
i4=nearesty(y4,st2);
if (dz>0)
{
  if (i3-i2<2)
    i2=i3-2;
} else
{
  if (i3-i2<2)
    i3=i2+2;
}
if (i4-i3<2)
  i4=i3+2;
if (i2-i1<2)
  i1=i2-2;
if (i4>=st2->n)
{
  i=i4-st2->n+1;
  i4-=i;
  i3-=i;
  i2-=i;
  i1-=i;
}
if (i1<=1)
{
  i=-i1+2;
  i1+=i;
  i2+=i;
  i3+=i;
  i4+=i;
}
/* Zacetne koordinate vozlisc, ki bodo premaknjena v oglisca zleba: */
n2=st2->s[i1];   x10=n2->x;   y10=n2->y;
n2=st2->s[i2];   x20=n2->x;   y20=n2->y;
n2=st2->s[i3];   x30=n2->x;   y30=n2->y;
n2=st2->s[i4];   x40=n2->x;   y40=n2->y;
/* Izracun koordinat vozlisc na desni strani: */
/* Koordinate pod zlebom: */
/*
ki= (double) i1-1;
ky=y1-ydown;
*/
ky=(y1-ydown)/(y10-ydown);
for (i=1; i<=i1; ++i)
{
  /*
  n2=st2->s[i];
  n2->y=ydown+ky*(double)(i-1)/ki;
  n2->x=calcx(n2->y);
  */
  n1=st1->s[i];
  n2=st2->s[i];
  n2->y=ydown+(n1->y-ydown)*ky;
  n2->x=calcx(n2->y);
}
/* Koordinate nad zlebom: */
/*
ki= (double) st2->n-i4;
ky=yup-y4;
*/
ky=(y4-yup)/(y40-yup);
for (i=i4; i<=st2->n; ++i)
{
  /*
  n2=st2->s[i];
  n2->y=yup-ky*(double)(st2->n-i)/ki;
  n2->x=calcx(n2->y);
  */
  n1=st1->s[i];
  n2=st2->s[i];
  n2->y=yup+(n1->y-yup)*ky;
  n2->x=calcx(n2->y);
}
/* Zgornja posevnina zleba: */
ky=(y4-y3)/(y40-y30);
for (i=i3; i<=i4; ++i)
{
  /* k=(double) i-i3; */
  n1=st1->s[i];
  n2=st2->s[i];
  n2->y=y3+ky*(n1->y-y30);
  n2->x=x3+(x4-x3)*(n2->y-y3)/(y4-y3);
}
/* Spodnja posevnina zleba: */
ky=(y2-y1)/(y20-y10);
for (i=i1;i<=i2;++i)
{
  n1=st1->s[i];
  n2=st2->s[i];
  n2->y=y1+ky*(n1->y-y10);
  n2->x=x1+(x2-x1)*(n2->y-y1)/(y2-y1);
}
/* Dno zleba: */
ky=(y3-y2)/(y30-y20);
for (i=i2;i<=i3;++i)
{
  n1=st1->s[i];
  n2=st2->s[i];
  n2->y=y2+ky*(n1->y-y20);
  n2->x=x2+(x3-x2)*(n2->y-y2)/(y3-y2);
}
/* Predpisani pomiki se izracunajo tako, da se od novih koordinat odstejejo
stare: */
for (i=1; i<=st2->n; ++i)
{
  n1=st1->s[i];
  n2=st2->s[i];
  n2->x-=n1->x;
  n2->y-=n1->y;
  n2->z-=n1->z;
}
}




main (int numargs,char *argv[])
{

int dim=2;
int i,j;

stack nodecoord=NULL,nodeconst=NULL,nodprescdisp=NULL,
      rightside=NULL,rightsidecp=NULL,newcoord=NULL;
char *tempfilename=NULL,*buf=NULL;
FILE *temp,*fp,*fp1,*fp2;
char *datafile="0setg";
nodcoord nc1=NULL,nc2=NULL;

buf=malloc(1000);

/*
fp=fopen("0setg","r");
num=ffindnodefield("PRESCRIBED DISPL",fp,1,&first,&last);
printf("  Polje traja od %i. do %i. byta in vsebuje podatke o %i vozliscih.\n\n\n",
          first,last,num);
fclose(fp);
exit(0);
*/

tempfilename=stringcopy("0danftmp");
temp=fopen(tempfilename,"w");
fprintf(temp,"ZACETEK:\n\n\n");



/*

newcoord=newstack(20);
fp=fopen("danf.res","r");
printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");
fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
printf("\n\nPREBRANI 1.\n\n");
fclose(fp);

newcoord=newstack(20);
fp=fopen("danf.res","r");
printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");
fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
printf("\n\nPREBRANI 2.\n\n");
fclose(fp);

newcoord=newstack(20);
fp=fopen("danf.res","r");
printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");
fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
printf("\n\nPREBRANI 3.\n\n");
fclose(fp);

newcoord=newstack(20);
fp=fopen("danf.res","r");
printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");
fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
printf("\n\nPREBRANI 4.\n\n");
fclose(fp);

newcoord=newstack(20);
fp=fopen("danf.res","r");
printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");
fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
printf("\n\nPREBRANI 5.\n\n");
fclose(fp);

newcoord=newstack(20);
fp=fopen("danf.res","r");
printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");
fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
printf("\n\nPREBRANI 6.\n\n");
fclose(fp);

newcoord=newstack(20);
fp=fopen("danf.res","r");
printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");
fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
printf("\n\nPREBRANI 7.\n\n");
fclose(fp);

newcoord=newstack(20);
fp=fopen("danf.res","r");
printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");
fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
printf("\n\nPREBRANI 8.\n\n");
fclose(fp);

newcoord=newstack(20);
fp=fopen("danf.res","r");
printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");
fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
printf("\n\nPREBRANI 9.\n\n");
fclose(fp);

newcoord=newstack(20);
fp=fopen("danf.res","r");
printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");
fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
printf("\n\nPREBRANI 10.\n\n");
fclose(fp);

exit(0);

*/






/*
nodeconst=newstack(200);
fp1=fopen("danf.dat2b","r");
fp2=fopen("danf.dat4a","r");
nodeconst=newstack(200);
gennewconstr(fp1,1,fp2,1,nodeconst);
fclose(fp1);
fclose(fp2);
fp1=fopen("danf.dat4b","w");
fprintf(fp1,"RESTRAINED NODES\n");
fwritenodeconstr(fp1,nodeconst,dim);
fclose(fp1);
fwritenodeconstr(stdout,nodeconst,dim);
fwritenodeconstr(temp,nodeconst,dim);
exit(0);
*/



nodecoord=newstack(1000);
printf("Branje vozliscnih koordinat osnovne geometrije.\n");
fprintf(temp,"Branje vozliscnih koordinat osnovne geometrije.\n");
fp=fopen(datafile,"r");
freadnodecoords(fp,1,nodecoord);
fclose(fp);
printf("\n\n\n  VOZLISCNE KOORDINATE (zacetne) ZA VSA VOZLISCA:\n\n\n");
fprintf(temp,"\n\n\n  VOZLISCNE KOORDINATE (zacetne) ZA VSA VOZLISCA:\n\n\n");
fflush(temp);
/*
fwritenodecoords(stdout,nodecoord,dim);
*/
fwritenodecoords(temp,nodecoord,dim);


nodeconst=newstack(400);
printf("Branje podprtih vozlisc.\n");
fprintf(temp,"Branje podprtih vozlisc.\n");
fp=fopen(datafile,"r");
freadnodeconstr(fp,nodeconst);
fclose(fp);
printf("\n\n\n  PODPRTA VOZLISCA:\n\n\n");
/*
fwritenodeconstr(stdout,nodeconst,dim);
*/
fprintf(temp,"\n\n\n  PODPRTA VOZLISCA:\n\n\n");
fflush(temp);
fwritenodeconstr(temp,nodeconst,dim);


nodprescdisp=newstack(1000);
printf("Branje vozlisc s predpisanimi pomiki (vozlisca na desni strani matrice).\n");
fprintf(temp,"Branje vozlisc s predpisanimi pomiki (vozlisca na desni strani matrice).\n");
fp=fopen(datafile,"r");
freadnodeprescdisp(fp,1,nodprescdisp);
fclose(fp);
printf("\n\n\n  PREDPISANI POMIKI (vozlisca na desni strani):\n\n\n");
fprintf(temp,"\n\n\n  PREDPISANI POMIKI (vozlisca na desni strani):\n\n\n");
fflush(temp);
/*
fwritenodecoords(stdout,nodprescdisp,dim);
*/
fwritenodecoords(temp,nodprescdisp,dim);




rightside=createimage(nodprescdisp,nodecoord);
printf("\n\n\n  KOORDINATE VOZLISC NA DESNI STRANI:\n\n\n");
fprintf(temp,"\n\n\n  KOORDINATE VOZLISC NA DESNI STRANI:\n\n\n");
fflush(temp);
/*
fwritenodecoords(stdout,rightside,dim);
*/
fwritenodecoords(temp,rightside,dim);
fflush(temp);
qsortstack(rightside,comparenodeycoords);
printf("\n\n\n  KOORDINATE SORTIRANIH VOZLISC NA DESNI STRANI:\n\n\n");
fprintf(temp,"\n\n\n  KOORDINATE SORTIRANIH VOZLISC NA DESNI STRANI:\n\n\n");
fflush(temp);
/*
fwritenodecoords(stdout,rightside,dim);
*/
fwritenodecoords(temp,rightside,dim);
fflush(temp);

rightsidecp=createhardimage(rightside,rightside,sizeof(_nodcoord));
printf("\n\n\n  KOORDINATE SORTIRANIH VOZLISC NA DESNI STRANI -NETRANSF.:\n\n\n");
fprintf(temp,"\n\n\n  KOORDINATE SORTIRANIH VOZLISC NA DESNI STRANI -NETRANSF.:\n\n\n");
fflush(temp);
/*
fwritenodecoords(stdout,rightside,dim);
*/
fwritenodecoords(temp,rightside,dim);
fflush(temp);


/* Sedaj dobimo predpisane pomike vozlisc na desni strani za datoteko, s katero
Elfen izracuna celotno geometrijo: */

transformnodes("0param",rightside,rightsidecp);

fprintf(temp,"n\n\n  PREDPISANI POMIKI VOZLISC:\n\n\n");
fwritenodecoords(temp,rightsidecp,dim);

filereplacefield("0setg","danf.dat","PRESCRIBED DISPLACEMENTS",
                 1,rightsidecp,dim,1000);


system("elfendyn danf 24");

newcoord=newstack(2000);
fp=fopen("danf.res","r");

printf("\n\n\nREADING NODAL DISPLACEMENTS:\n\n");

fresreadnodefield("NODAL DISPLACEMENTS",fp,1,newcoord);
fclose(fp);

/*
nc1=malloc(sizeof(*nc1));
nc2=malloc(sizeof(*nc2));
*/

printf("ADDING DISPLACEMENTS TO ORIGINAL COORDINATES:\n\n");

for (i=1;i<=nodecoord->n;++i)
{
  nc1=nodecoord->s[i];
  nc2=newcoord->s[i];
  nc2->x+=nc1->x;
  nc2->y+=nc1->y;
}

printf("SETTING ANALYSIS FILE:\n\n");

filereplacefield("0danf","danf.dat","NODE COORDINATES",1,newcoord,dim,1000);

system("elfendyn danf 24");

if (nodecoord!=NULL)
{
  dispstack(&nodecoord);
  nodecoord=NULL;
}

/*
if (nod!=NULL)
{
  dispstack(&nod);
  nod=NULL;
}
*/

if (buf!=NULL)
  free(buf);
if (tempfilename!=NULL)
  free(tempfilename);
if (temp!=NULL)
  fclose(temp);
}


