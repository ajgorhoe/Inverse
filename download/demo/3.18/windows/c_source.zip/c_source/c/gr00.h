

void gisetwindowtitle(char *title)
     /* Naslov oken, ki se na novo odpirajo, postavi na title. */
{
}

int gisetwindowxpos(float z)
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri x na i. Vrne prej.
    pozicijo. Mozni obseg z je od 0 do 1. */
{
}

int gisetwindowypos(float z)
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri y na i. Vrne prej.
    pozicijo. Mozni obseg z je od 0 do 1. */
{
}

int gisetwindowwidth(float z)
    /* Postavi zaceto sirino oken pri odpiranju v smeri na i. Vrne prej.
    sirino. Mozni obseg z je od 0 do 1. */
{
}

int gisetwindowheight(float z)
    /* Postavi zaceto visino oken pri odpiranju v smeri na i. Vrne prej.
    visino. Mozni obseg z je od 0 do 1. */
{
}


float gisetpointsize(float size)
      /* Nastavi velikost tock. Vrne trenutno velokost. */
{
}

int gisetcurvepoints(int num)
    /* Nastavi stevilo vmesnih tock pri risanju krivuljnih objektov, npr.
    kroznic. Vrne trenutno stevilo tock. */
{
}



static float testcolor(float color)
       /* Ce barvna komponenta ni v dovoljenem obsegu, jo postavi v dovoljen
       obseg in jo vrne, drugace vrne nespremenjno komponento. To funkcijo
       uporabljajo funkcije za nastavitev barv. */
{
}


void gisetlinecolor(float red,float green,float blue)
     /* Nastavi barvo za risanje crt. */
{
}


void gisetfillcolor(float red,float green,float blue)
     /* Nastavi barvo za risanje zapolnjenih likov */
{
}

void gisetlinewidth(double width)
     /* Nastavi sirino crt pri risanju (velja tudi za nezapolnjene like) */
{
}

void gisetlinetype(int type)
     /* Nastavi tip crt */
{
}

void gisettextcolor(float red,float green,float blue)
     /* Nastavi barvo teksta. */
{
}

void gisettextprecision(float precision)
     /* Ta funkcija ni izdelana do konca! */
{
}

void gisettextfont(int font)
     /* Nastavi pisavo, ki se uporablja pri tekstu. */
{
}

void gisettextheight(float height)
     /* Nastavi velikost (visino) teksta. */
{
}

void gisettextspacing(float spacing)
     /* Nastavi velikost presledkov med crkami pri tekstu. */
{
}

void gisettextexpansion(float expansion)
     /* Nastavi razsiritev teksta v vodoravni smeri. */
{
}

void gisettextxalignment(int alignment)
     /* Nastavi poravnavanje teksta v vodoravni smeri. Ce je alignment -1, je
     poravnavanje levo, ce je 0, je centrirano, ce pa je 1, je desno. */
{
}

void gisettextyalignment(int alignment)
     /* Nastavi poravnavanje teksta v navpicni smeri. Ce je -1, je poravnavanje
     spodnje, ce je 0, je centrirano, ce pa je 1, je zgornje. */
{
}

void gisettextalignment(int xalignment,int yalignment)
     /* Hkrati nastavi poravnavanje teksta v obeh smereh, pri cemer uporablja
     funkciji gisettextxalignment in settextyalignment. */
{
}





int giinitdisplay(void)
    /* Odpre display. */
{
}




int giinitgraph(void)
    /* Zacetne nastavitve za grafiko. To funkcijo se lahko pozene le enkrat ne
    glede na stevilo oken, ki so odprta (nastavitve veljajo za vsa okna). */
{
}


int giopenwindow(void)
    /* Odpre novo okno. Vrne identifikacijsko stevilko tega okna, s to stevilko
    se nato sklicujemo na to okno v programu. Okno, ki ga odpre, postane
    aktivno. */
{
}


int gisetwindow(int num)
    /* Okno z zaporedno stevilko num naredi za aktivno. */
{
}

void giresetwindow(void)
     /* Resetiranje aktivnega okna. Vsebina okna se zbrise. */
{
}

void giclosewindow(void)
     /* Zapre aktivno okno. */
{
}

void giclearwindow(void)
     /* Zbrise vsebino aktivnega okna. */
{
}

void giflushdisplay(void)
     /* Povzroci izris vsega, kar se se ni izrisalo. */
{
}



void giline(float x1,float y1,float x2,float y2)
     /* Narise crto med tockama (x1,y1) in (x2,y2). */
{
}

void gitriangle(float x1,float y1,float x2,float y2,float x3,float y3)
     /* Narise trikonik iz crt z oglisci (x1,y1), (x2,y2) in (x3,y3). */
{
}


void gifourangle(float x1,float y1,float x2,float y2,float x3,float y3,
               float x4,float y4)
     /* Narise stirikotnik iz crt z oglisci (x1,y1), (x2,y2), (x3,y3) in
     (x4,y4). */
{
}


void girectangle(float x1,float y1,float x2,float y2)
     /* Narise pravokotnik iz crt z nasprotileznima ogliscema (x1,y1) in
     (x2,y2). */
{
}


void gicircle(float x,float y,float r)
     /* Narise krog iz curvepoints crt s srediscem (x,y) in radijem r. */
{
}


void gicirclearc(float x,float y,float r,float fi1,float fi2)
     /* Narise krozni lok iz curvepoints crt s srediscem (x,y), radijem r ter
     z zacetnim kotom fi1 in s koncnim kotom fi2. Koti so v radianih. */
{
}


void giellipse(float x,float y,float a,float b)
     /* Narise elipso iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri. */
{
}


void giellipsearc(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise elipsin lok iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri ter z zacetnim kotom fi1 in
     s koncnim kotom fi2. Koti so v radianih. */
{
}


void gifilltriangle(float x1,float y1,float x2,float y2,float x3,float y3)
     /* Narise pobarvan trikotnik z oglisci (x1,y1), (x2,y2) in (x3,y3). */
{
}


void gifillfourangle(float x1,float y1,float x2,float y2,float x3,float y3,
                   float x4,float y4)
     /* Narise pobarvan stirikotnik z oglisci (x1,y1), (x2,y2), (x3,y3) in
     (x4,y4). */
{
}

void gifillrectangle(float x1,float y1,float x2,float y2)
     /* Narise zapolnjen pravokotnik s protileznima ogliscema (x1,y1) in
     (x2,y2). */
{

}

void gipoint(float x,float y)
     /* Narise tocko s koordinatami (x,y). Za barvo se uporalbja barva za
     polnjenje likov. */
{

}




void gifillcircle(float x,float y,float r)
     /* Narise zapolnjen krog s srediscem v (x,y) in polmerom r iz curvepoints
     zapolnjenih trikotnikov. */
{
}


void gifillcirclearc(float x,float y,float r,float fi1,float fi2)
     /* Narise zapolnjen krozni lok s srediscem (x,y), polmerom r ter zacetnim
     kotom fi1 in koncnim kotom fi2 zi curvepoints zapolnjenih trikotnikov. Koti
     so v radianih. */
{
}


void gifillellipse(float x,float y,float a,float b)
     /* Narise zapolnjeno elipso s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b iz curvepoints zapolnjenih trikornikov. */
{
}


void gifillellipsearc(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise zapolnjen elipsin lok s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b ter zacetnim kotom fi1 in koncnim fi2 iz curvepoints
     zapolnjenih trikornikov. Koti so v radianih. */
{
}



void gitext(char *str,float x,float y)
     /* Izpise niz str pri koordinatah (x,u). */
{
}



void gidrawloop(void (*redraw)(void))
     /* Zanka okrog funkcije redraw, ki naj bi bila taksna funkcija, ki nekaj
     narise v aktivno okno. Funkcija na novo izrise aktivno okno vsakic, ko je
     potrebno zaradi odkrivanja okna ali cesa drugega. Ko kliknemo z misko v
     okno, se le-to zapre. */
{
}




int gibuttonpressed(void)
    /* Vrne st. gumba miske, ki je bil pritisnjen v aktivnem oknu. Ce ni bil
    pritisnjen noben gumb, vrne 0. Funkcija caka, dokler ni dejansko pritisnjen
    kak gumb ali se aktivno okno izpostavi. */
{
}

