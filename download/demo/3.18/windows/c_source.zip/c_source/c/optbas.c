
#define EXTRACE   /* Switch on tracing */

#ifdef EXTRACE
  #undef EXTRACE    /* Switch off tracing */
#endif




    /* OPTIMIZATION - BASIC DEFINITIONS */



#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#include <er.h>
#include <mtypes.h>
#include <mtime.h>
#include <strop.h>
#include <rf.h>
#include <vec.h>
#include <mat.h>
#include <matrixop.h>
#include <minnd.h>

#include <optbas.h>










          /*********************************************/
          /*                                           */
          /*  ANALYSIS EVALUATION POINT DATA HANDLING  */
          /*                                           */
          /*********************************************/



analysispoint newanalysispoint(void)
    /* Allocates a new structure for containing analysis point data and 
    returns a pointer to this structure.
    $A Igor feb05; */
{
analysispoint ret;
static int id=0;
ret=calloc(1,sizeof(*ret));
++id;  ret->id=id;  ret->type=TYPE_analysispoint;
return ret;
}

analysispoint newanalysispointr(int nparam,int nconstr,int grad)
    /* Allocates a new structure for containing analysis point data with 
    allocated space for data and returns a pointer to this structure.
      nparam is the number of parameters, nconstr is the number of constraints
    and grad specifies whether storage for gradients is allocated or not. The
    function allocates space for parameter vector, values of the objective
    and constraint functions, and if grad!=0, also for gradients of the
    objective and constraint functions.
      If nparam==0 then space for parameter vector and gradients is not
    allocated. If nconstr==0 then space for constraints and their gradients
    is not allocated.
    $A Igor feb05; */
{
analysispoint ret;
int i;
ret=newanalysispoint();
ret->obj=calloc(1,sizeof(*(ret->obj)));
if (nparam>0)
{
  ret->param=getvector(nparam);
  if (grad)
  {
    ret->gradobj=getvector(nparam);
    if (nconstr>0)
    {
      ret->gradconstr=newstackrn(5,nconstr);
      for (i=1;i<=nconstr;++i)
        ret->gradconstr->s[i]=getvector(nconstr);
    }
  }
}
if (nconstr>0)
{
  ret->constr=newstackrn(5,nconstr);
  for (i=1;i<=nconstr;++i)
    ret->constr->s[i]=calloc(1,sizeof(*(ret->obj)));
}

return ret;
}


void dispanalysispoint(analysispoint *addrpt)
    /* Deallocates the structure pointed to by *addrpt and sets *addrpt to NULL.
    $A Igor feb05; */
{
analysispoint pt;
if (addrpt!=NULL) if ((pt=*addrpt)!=NULL)
{
  if (pt->type!=TYPE_analysispoint)  /* Type check */
  {
    m_errorreport0("dispanalysispoint","Incorrect type.\n");
    return;
  }
  if (pt->param!=NULL)
    dispvector(&(pt->param));
  if (pt->obj!=NULL)
    free(pt->obj);
  if (pt->gradobj!=NULL)
    dispvector(&(pt->gradobj));
  if (pt->constr!=NULL)
    dispstackall(&(pt->constr));
  if (pt->gradconstr!=NULL)
    dispstackallspec(&(pt->gradconstr),(void (*)(void **)) dispvector);
  if (pt->data!=NULL)
  {
    if (pt->dispdata!=NULL)
      pt->dispdata(&(pt->data));
    /* 
    else
      free(pt->data);
    */
  }
  free(pt);
  *addrpt=NULL;
}
}



analysispoint copyanalysispoint(analysispoint pt1,analysispoint *addrpt2)
    /* Copies analysis evaluation point pt1 to *addrpt2 (if addrpt2 is not 
    NULL) and returns *addrpt2, or (if addrpt2 is NULL) just returns a
    dynamically allocated copy of pt1.
    $A Igor apr05; */
{
analysispoint ret=NULL;
if (addrpt2==NULL)
  addrpt2=&ret;
if (pt1==NULL)
{
  if (*addrpt2!=NULL)
    dispanalysispoint(addrpt2);
} else
{
  if (*addrpt2==NULL)
    *addrpt2=newanalysispoint();
  ret=*addrpt2;
  /* Perform copying of contents; copy flags first: */
  ret->calcobj=pt1->calcobj;
  ret->calcconstr=pt1->calcconstr;
  ret->calcgradobj=pt1->calcgradobj;
  ret->calcgradconstr=pt1->calcgradconstr;
  /* Copy parameters and results: */
  copyvector(pt1->param,&(ret->param));
  copyscalar(pt1->obj,&(ret->obj));
  copystackspec(pt1->constr,&(ret->constr),
      (void (*) (void **)) dispscalar,
       (void *(*) (void *,void **)) copyscalar);
  copyvector(pt1->gradobj,&(ret->gradobj));
  copystackspec(pt1->gradconstr,&(ret->gradconstr),
      (void (*) (void **)) dispvector,
      (void *(*) (void *,void **)) copyvector);
  if (pt1->copydata!=NULL)
    pt1->copydata(pt1->data,&(ret->data));
}
return *addrpt2;
}


    /* Printing utilities for analysis points: */

void fprintanptparamlist(FILE *fp,analysispoint anpt)
    /* Prints vlaue of anpt->obj without spaces or newlines. Output is to file
    fp.
    $A Igor apr05; */
{
if (fp!=NULL)
{
  if (anpt==NULL)
    fprintf(fp,"NULL");
  else
    fprintvectorlist(fp,anpt->param);
}
}


void fprintanptobjlist(FILE *fp,analysispoint anpt)
    /* Prints vlaue of anpt->obj without spaces or newlines. If anpt==NULL,
    anpt->obj==NULL or anpt->calcobj==0 then "NULL" is printed. Output is to 
    the file fp.
    $A Igor apr05; */
{
if (fp!=NULL)
{
  if (anpt==NULL)
    fprintf(fp,"NULL");
  else if (anpt->calcobj==0)
    fprintf(fp,"NULL");
  else
    fprintscalarlist(fp,anpt->obj);
}
}


void fprintanptconstrlist(FILE *fp,analysispoint anpt)
    /* Prints vlaues of anpt->constr in list form (comma separated in curly
    brackets). If anpt==NULL, anpt->constr==NULL or anpt->calcconstr==0 then 
    "NULL" is printed. Output is to file fp.
    $A Igor apr05; */
{
if (fp!=NULL)
{
  if (anpt==NULL)
    fprintf(fp,"NULL");
  else if (anpt->calcconstr==0)
    fprintf(fp,"NULL");
  else
    fprintstacklistline(fp,anpt->constr,fprintscalarlist);
}
}


void fprintanptgradobjlist(FILE *fp,analysispoint anpt)
    /* Prints vlaue of anpt->gradobj without spaces or newlines. If anpt==NULL,
    anpt->gradobj==NULL or anpt->calcgradobj==0 then "NULL" is printed. Output 
    is to  the file fp.
    $A Igor apr05; */
{
if (fp!=NULL)
{
  if (anpt==NULL)
    fprintf(fp,"NULL");
  else if (anpt->calcgradobj==0)
    fprintf(fp,"NULL");
  else
    fprintvectorlist(fp,anpt->gradobj);
}
}


void fprintanptgradconstrlist(FILE *fp,analysispoint anpt)
    /* Prints vlaues of anpt->gradconstr in list form (comma separated in curly
    brackets). If anpt==NULL, anpt->gradconstr==NULL or anpt->calcgradconstr==0
    then "NULL" is printed. Output is to file fp.
    $A Igor apr05; */
{
if (fp!=NULL)
{
  if (anpt==NULL)
    fprintf(fp,"NULL");
  else if (anpt->calcgradconstr==0)
    fprintf(fp,"NULL");
  else
    fprintstacklistline(fp,anpt->gradconstr,fprintvectorlist);
}
}


void fprintanptlist(FILE *fp,analysispoint anpt)
    /* Prints all analysis results on anpt in list form, first anpt->param,
    then anpt->obj, anpt->constr, anpt->gradobj and anpt->gradconstr.
     Output is to file fp.
    $A Igor apr05; */
{
if (fp!=NULL)
{
  if (anpt==NULL)
    fprintf(fp,"NULL\n");
  else
  {
    fprintf(fp,"{ ");
    fprintanptparamlist(fp,anpt);  fprintf(fp,", ");
    fprintanptobjlist(fp,anpt);  fprintf(fp,", ");
    fprintanptconstrlist(fp,anpt);   fprintf(fp,", ");
    fprintanptgradobjlist(fp,anpt);  fprintf(fp,", ");
    fprintanptgradconstrlist(fp,anpt);   fprintf(fp," ");
    fprintf(fp,"} ");
  }
}
}


void fprintanalysispointlist(FILE *fp,analysispoint anpt)
    /* Prints all analysis results on anpt in list form, first anpt->param,
    then anpt->obj, anpt->constr, anpt->gradobj and anpt->gradconstr.
     Output is to file fp.
    $A Igor apr05; */
{
fprintanptlist(fp,anpt);
}


void printanalysispointlist(analysispoint anpt)
    /* Prints all analysis results on anpt in list form, first anpt->param,
    then anpt->obj, anpt->constr, anpt->gradobj and anpt->gradconstr.
     Output is to the standard output.
    $A Igor apr05; */
{
fprintanalysispointlist(stdout,anpt);
}


void fprintanalysispoint(FILE *fp,analysispoint anpt)
    /* Prints contents of anpt in longer and more readable form to fp.
    $A Igor apr05; */
{
if (fp!=NULL)
{
  if (anpt==NULL)
    fprintf(fp,"NULL.\n");
  else
  {
    fprintf(fp,"Flags:\n");
    fprintf(fp,"calcobj = %i, calcconstr = %i, calcgradobj = %i, calcgradconstr = %i\n",
        anpt->calcobj,anpt->calcconstr,anpt->calcgradobj,anpt->calcgradconstr);
    fprintf(fp,"Parameters (dim = %i):\n",anpt->param==NULL?0:anpt->param->d);
    fprintanptparamlist(fp,anpt);  fprintf(fp,"\n");
    fprintf(fp,"Objective function: ");
    fprintanptobjlist(fp,anpt);  fprintf(fp,"\n");
    fprintf(fp,"Constraint functions:\n");
    fprintanptconstrlist(fp,anpt);   fprintf(fp,"\n");
    fprintf(fp,"Objective gratient:\n");
    fprintanptgradobjlist(fp,anpt);  fprintf(fp,"\n");
    fprintf(fp,"Constraint gratients:\n");
    fprintanptgradconstrlist(fp,anpt);  fprintf(fp,"\n");
  }
}
}


void printanalysispoint(analysispoint anpt)
    /* Prints contents of anpt in longer and more readable form to standard
    output.
    $A Igor apr05; */
{
fprintanalysispoint(stdout,anpt);
}




    /* COPY ANALYSIS RESULTS TO analysispoint STRUCTURE */


void copyanfuncrestopointplain0(int ret,vector param,int calcobj,double *obj,
      int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr,  analysispoint anpt)
    /* Copies analysis results to a structure of type analysispoint anpt. ret
    is analysis return value  while other arguments results of the analysis 
    function and addranpt is the address of the storage where results are 
    copied to.
      Analysis results are typically generated by a functioin of type 
    analysis_bas_f, and meaning of function arguments is corresponding.
      flags calcobj,calcconstr,calcgradobj and calcgradconstr tell whether
    the objective function, constraints, gradient fo objective and gradients
    of constraints were calculated. If these flags are 0 then corresponding
    values are not copied to anpt and the corresponding members on anpt are
    not touched (i.e. dimension is not adjusted and values are not deleted).
    $A Igor apr05 jul05; */
{
if (anpt!=NULL)
{
  copyvector(param,&(anpt->param));
  anpt->calcobj=calcobj;
  anpt->calcconstr=calcconstr;
  anpt->calcgradobj=calcgradobj;
  anpt->calcgradconstr=calcgradconstr;
  if (calcobj)
    copyscalar(obj,&(anpt->obj));
  if (calcconstr)
    copystackspec(constr,&(anpt->constr),  (void (*) (void **)) dispscalar,
         (void * (*) (void *, void **)) copyscalar);
  if (calcgradobj)
    copyvector(gradobj,&(anpt->gradobj));
  if (calcgradconstr)
    copystackspec(gradconstr,&(anpt->gradconstr),  (void (*) (void **)) dispvector,
          (void * (*) (void *, void **)) copyvector);
}
}


analysispoint copyanfuncrestopoint0(int res,vector param,int calcobj,
      double *obj,int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr,  analysispoint *addranpt)
    /* Copies analysis results to a structure of type analysispoint and
    returns the pointer of the structure.  res is analysis return value while 
    other arguments results of the analysis function and addranpt is the
    address of the storage where results are copied to.
      For copying, see copyanfuncrestopointplain0() which does the job.
      If addranpt!=NULL then data is copied to *addranpt (which is allocated
    if necessary) and *addranpt is returned. Otherwise a new structure is
    allocated for copying and its pointer returned.
      In contrary to copyanfuncrestopoint, this funciton does not addresses of
    result storage, but result themselves. Otherwise, functions operate in the
    same way.
    $A Igor apr05 jul05; */
{
analysispoint ret;
if (addranpt!=NULL)
{
  /* addranpt!=NULL, therefore data are copied to *addranpt (which is created
  if necessary) and *addranpt is returned: */
  if (*addranpt==NULL)
    *addranpt=newanalysispoint();
  ret=*addranpt;
} else
  ret=newanalysispoint();
copyanfuncrestopointplain0(res,param,calcobj,obj,calcconstr,constr,calcgradobj,
    gradobj,calcgradconstr,gradconstr,ret);
return ret;
}


analysispoint copyanfuncrestopoint(int res,vector param,int *addrcalcobj,
      double **addrobj,int *addrcalcconstr,stack *addrconstr,  
      int *addrcalcgradobj,vector *addrgradobj,
      int *addrcalcgradconstr,stack *addrgradconstr,  analysispoint *addranpt)
    /* Copies analysis results to a structure of type analysispoint and
    returns the pointer of the structure.  res is analysis return value while 
    other arguments are results of the analysis function and addranpt is the
    address of the storage where results are copied to.
      For copying, see copyanfuncrestopointplain0() which does the job.
      If addranpt!=NULL then data is copied to *addranpt (which is allocated
    if necessary) and *addranpt is returned. Otherwise a new structure is
    allocated for copying and its pointer returned.
    $A Igor jul05; */
{
int calcobj=0,calcconstr=0,calcgradobj=0,calcgradconstr=0;
double *obj=NULL;
vector gradobj=NULL;
stack constr=NULL,gradconstr=NULL;
if (addrcalcobj!=NULL)
  calcobj=*addrcalcobj;
if (addrcalcconstr!=NULL)
  calcconstr=*addrcalcconstr;
if (addrcalcgradobj!=NULL)
  calcgradobj=*addrcalcgradobj;
if (addrcalcgradconstr!=NULL)
  calcgradconstr=*addrcalcgradconstr;
if (addrobj!=NULL)
  obj=*addrobj;
if (addrconstr!=NULL)
  constr=*addrconstr;
if (addrgradobj!=NULL)
  gradobj=*addrgradobj;
if (addrgradconstr!=NULL)
  gradconstr=*addrgradconstr;
return copyanfuncrestopoint0(res,param,calcobj,obj,
      calcconstr,constr,calcgradobj,gradobj,
      calcgradconstr,gradconstr,  addranpt);
}


int copypointtoanfuncargs(analysispoint anpt,int *calcobj,double **addrobj,
          int *calcconstr,stack *addrconstr,
          int *calcgradobj,vector *addrgradobj,
          int *calcgradconstr,stack *addrgradconstr)
    /* Copies analysis results from analysis point to arguments of the
    analysis function. Only those results are copied that are requested by
    the request flag pointers and tehir evaluation is at the same time 
    indicated by flags on anpt.
    Function returns anpt->ret.
    $A Igor jul05; */
{
int ret=-1;  /* for the case if anpt==NULL */
if (anpt!=NULL)
{
  if (calcobj==NULL && calcconstr==NULL && calcgradobj==NULL && calcgradconstr==NULL)
  {
    /* Info mode, just copy all the results: */
    copyscalar(anpt->obj,addrobj);
    copystackspec(anpt->constr,addrconstr,(void (*) (void **)) dispscalar, 
                  (void * (*) (void *,void **)) copyscalar);
    copyvector(anpt->gradobj,addrgradobj);
    copystackspec(anpt->gradconstr,addrgradconstr,
        (void (*) (void **)) dispvector,(void * (*) (void *,void **)) copyvector);
  } else
  {
    /* Set return information on what has been calculated: */
    if (calcobj!=NULL)
      *calcobj=anpt->calcobj && *calcobj;
    if (calcconstr!=NULL)
      *calcconstr=anpt->calcconstr && *calcconstr;
    if (calcgradobj!=NULL)
      *calcgradobj=anpt->calcgradobj && *calcgradobj;
    if (calcgradconstr!=NULL)
      *calcgradconstr=anpt->calcgradconstr && *calcgradconstr;
    /* Copy analysis results that are on anpt: */
    if (calcobj!=NULL) if (*calcobj)
      copyscalar(anpt->obj,addrobj);
    if (calcconstr!=NULL) if (*calcconstr)
      copystackspec(anpt->constr,addrconstr,(void (*) (void **)) dispscalar, 
                    (void * (*) (void *,void **)) copyscalar);
    if (calcgradobj!=NULL) if (*calcgradobj)
      copyvector(anpt->gradobj,addrgradobj);
    if (calcgradconstr!=NULL) if (*calcgradconstr)
      copystackspec(anpt->gradconstr,addrgradconstr,
          (void (*) (void **)) dispvector,(void * (*) (void *,void **)) copyvector);
  }
  ret=anpt->ret;
}
return ret;
}






          /****************************************************/
          /*                                                  */
          /*  VECTOR FUNCTION EVALUATION POINT DATA HANDLING  */
          /*                                                  */
          /****************************************************/



vecfuncpoint newvecfuncpoint(void)
    /* Allocates a new structure for containing vector function point data 
    (i.e. results of the function at a given parameter vector) and returns a 
    pointer to this structure.
    $A Igor apr05; */
{
vecfuncpoint ret;
static int id=0;
ret=calloc(1,sizeof(*ret));
++id;  ret->id=id;  ret->type=TYPE_vecfuncpoint;
return ret;
}

vecfuncpoint newvecfuncpointr(int nparam,int nval,int grad)
    /* Allocates a new structure for containing analysis point data with 
    allocated space for data and returns a pointer to this structure.
      nparam is the number of parameters, nval is the number of values (i.e.
    dimension of the range of the function) and grad specifies whether storage
    for gradients is allocated or not. 
      The function allocates space for parameter vector, vector value of the 
    function, and if grad!=0, also for gradient matrix.
      If nparam==0 then space for parameter vector and gradients is not
    allocated.
    $A Igor apr05; */
{
vecfuncpoint ret;
ret=newvecfuncpoint();
/*
ret->obj=calloc(1,sizeof(*(ret->obj)));
*/
if (nval>0)
  ret->val=getvector(nval);

if (nparam>0)
{
  ret->param=getvector(nparam);
  if (grad)
    if (nval>0)
      ret->grad=getmatrix(nval,nparam);
}
return ret;
}


void dispvecfuncpoint(vecfuncpoint *addrpt)
    /* Deallocates the structure pointed to by *addrpt and sets *addrpt to NULL.
    $A Igor apr05; */
{
vecfuncpoint pt;
if (addrpt!=NULL) if ((pt=*addrpt)!=NULL)
{
  if (pt->type!=TYPE_vecfuncpoint)  /* Type check */
  {
    m_errorreport0("dispvecfuncpoint","Incorrect type. Not deallocated.\n");
    return;
  }
  if (pt->param!=NULL)
    dispvector(&(pt->param));
  if (pt->val!=NULL)
    dispvector(&(pt->val));
  if (pt->grad!=NULL)
    dispmatrix(&(pt->grad));
  if (pt->data!=NULL)
  {
    if (pt->dispdata!=NULL)
      pt->dispdata(&(pt->data));
    /*
    else
      free(pt->data);
    */
  }
  *addrpt=NULL;
}
}


    /* Printing utilities for vector function evaluation point: */


void fprintvecfuncpointlist(FILE *fp,vecfuncpoint pt)
    /* Prints all vector function results on pt in list form, first anpt->param,
    then anpt->val, and finally anpt->grad.
     Output is to file fp.
    $A Igor apr05; */
{
if (fp!=NULL)
{
  if (pt==NULL)
    fprintf(fp,"NULL\n");
  else
  {
    fprintf(fp,"{ ");
    fprintvectorlist(fp,pt->param);  fprintf(fp,", ");
    fprintvectorlist(fp,pt->val);  fprintf(fp,", ");
    fprintmatrixlistline(fp,pt->grad);   fprintf(fp," ");
    fprintf(fp,"} ");
  }
}
}


void printvecfuncpointlist(FILE *fp,vecfuncpoint pt)
    /* Prints all vector function results on pt in list form, first pt->param,
    then pt->val, and finally pt->grad.
     Output is to standard output.
    $A Igor apr05; */
{
fprintvecfuncpointlist(stdout,pt);
}

void fprintvecfuncpoint(FILE *fp,vecfuncpoint pt)
    /* Prints contents of pt in longer and more readable form to fp.
    $A Igor apr05; */
{
if (fp!=NULL)
{
  if (pt==NULL)
    fprintf(fp,"NULL.\n");
  else
  {
    fprintf(fp,"Flags:\n");
    fprintf(fp,"calcval = %i, calcgrad = %i\n",pt->calcval,pt->calcgrad);
    fprintf(fp,"Parameters (dim = %i):\n",pt->param==NULL?0:pt->param->d);
    fprintvectorlist(fp,pt->param);  fprintf(fp,"\n");
    fprintf(fp,"Vector of values (dim = %i):\n",pt->val==NULL?0:pt->val->d);
    fprintvectorlist(fp,pt->val);  fprintf(fp,"\n");
    fprintf(fp,"Gradient");
    if (pt->grad==NULL)
      fprintf(fp,":\n  NULL\n");
    else
    {
      fprintf(fp," (dim = %i x %i):\n",pt->grad->d1,pt->grad->d2);
      fprintmatrixlist(fp,pt->grad);
      fprintf(fp,"\n");
    }
  }
}
}


void printvecfuncpoint(vecfuncpoint pt)
    /* Prints contents of pt in longer and more readable form to standard
    output.
    $A Igor apr05; */
{
fprintvecfuncpoint(stdout,pt);
}




    /* COPY VEC. FUNC. RESULTS */


void copyvecfuncrestopointplain(vector param,int calcval,vector val,
      int calcgrad,matrix grad,vecfuncpoint pt)
    /* Copies vector function results to the structure pt of type vecfuncpoint. 
      These results are typically generated by a functioin of type 
    vec_bas_f, and meaning of function arguments is corresponding.
      flags calcval and calcgrad tell whether the vector function values and/or 
    gradients have actually been calculated. If some flags are 0 then the
    corresponding data are not copied to pt and the corresponding members on
    pt are kept untouched (i.e. dimension is not adjusted and values are not 
    deleted), even if they eventually contain data previously set.
    $A Igor apr05; */
{
if (pt!=NULL)
{
  copyvector(param,&(pt->param));
  pt->calcval=calcval;
  pt->calcgrad=calcgrad;
  if (calcval)
    copyvector(val,&(pt->val));
  if (calcgrad)
    copymatrix(grad,&(pt->grad));
}
}


vecfuncpoint copyvecfuncrestopoint(vector param,int calcval,vector val,
      int calcgrad,matrix grad,  vecfuncpoint *addrpt)
    /* Copies vector function results to a structure of type vecfuncpoint and
    returns the pointer of the structure. 
      For copying, see copyvecfuncrestopointplain() which does the job.
      If addrpt!=NULL then data is copied to *addrpt (which is allocated
    if necessary) and *addrpt is returned. Otherwise a new structure is
    allocated for copying and its pointer returned.
    $A Igor apr05; */
{
vecfuncpoint ret;
if (addrpt!=NULL)
{
  /* addrpt!=NULL, therefore data are copied to *addrpt (which is created
  if necessary) and *addranpt is returned: */
  if (*addrpt==NULL)
    *addrpt=newvecfuncpoint();
  ret=*addrpt;
} else
  ret=newvecfuncpoint();
copyvecfuncrestopointplain(param,calcval,val,calcgrad,grad,ret);
return ret;
}





          /*******************************************/
          /*                                         */
          /*  ANALYSIS <-> VEC. FUNCTION CONVERSION  */
          /*                                         */
          /*******************************************/


analysis_to_vecfunc_cd newanalysis_to_vecfunc_cd(void)
    /* Creates a new structure of type analysis_to_vecfunc_cd and returns its
    pointer.
    $A Igor apr05; */
{
analysis_to_vecfunc_cd ret;
static int id=0;
ret=calloc(1,sizeof(*ret));
++id;  ret->id=id;  ret->type=TYPE_analysis_to_vecfunc_cd;
return ret;
}


void dispanalysis_to_vecfunc_cd(analysis_to_vecfunc_cd *addrcd)
    /* Deallocates the structure of type analysis_to_vecfunc_cd pointed to by
    *addrcd and sets *addrcd to NULL.
    $A Igor apr05; */
{
analysis_to_vecfunc_cd cd;
if (addrcd!=NULL) if ((cd=*addrcd)!=NULL)
{
  if (cd->type!=TYPE_analysis_to_vecfunc_cd)  /* Type check */
  {
    errfunc0("displinesearchcd");
    sprintf(ers(),"Incorrect type (%i, should be %i).\n",
        cd->type,TYPE_analysis_to_vecfunc_cd);
    sprintf(ers(),"Deallocation is not performed.\n");
    errfunc2();
    return;
  }
  if (cd->param!=NULL) dispvector(&(cd->param));
  /* Analysis results: */
  if (cd->obj!=NULL)
    free(cd->obj);
  if (cd->constr!=NULL)
    dispstackall(&(cd->constr));
  if (cd->gradobj!=NULL)
    dispvector(&(cd->gradobj));
  if (cd->gradconstr!=NULL)
    dispstackallspec(&(cd->gradconstr),(void (*)(void **)) dispvector);
  /* Vector function results: */
  if (cd->vecval!=NULL)
    dispvector(&(cd->vecval));
  if (cd->vecgrad!=NULL)
    dispmatrix(&(cd->vecgrad));
  /* Data for evaluating analysis function: */
  if (cd->ancd!=NULL)
  {
    if (cd->dispancd!=NULL)
      cd->dispancd(&(cd->ancd));
    /* If the function for deleting is not specified then we may not delete the
    data!!!
    else
      free(cd->analysiscd);
    */
  }
  /* Data for evaluating vector function: */
  if (cd->veccd!=NULL)
  {
    if (cd->dispveccd!=NULL)
      cd->dispveccd(&(cd->veccd));
    /* If the function for deleting is not specified then we may not delete the
    data!!!
    else
      free(cd->vecfunccd);
    */
  }
  /* Recorded analysis points: */
  if (cd->anpoints!=NULL)
  {
    /* if (cd->dispanpoint!=NULL) */
    dispstackvalspec(cd->anpoints, (void (*)(void **)) 
        dispanalysispoint /* cd->dispanpoint */ );
    dispstack(&(cd->anpoints));
  }
  if (cd->anstore!=NULL)
  {
    /* if (cd->dispanpoint!=NULL) */
    dispstackvalspec(cd->anstore, (void (*)(void **)) 
        dispanalysispoint /* cd->dispanpoint */);
    dispstack(&(cd->anstore));
  }
  /* Recorded vector function points: */
  if (cd->vecpoints!=NULL)
  {
    /* if (cd->dispvecpoint!=NULL) */
    dispstackvalspec(cd->vecpoints,(void (*)(void **))
         dispvecfuncpoint /* cd->dispvecpoint */ );
    dispstackall(&(cd->vecpoints));
  }
  if (cd->vecstore!=NULL)
  {
    /* if (cd->dispvecpoint!=NULL) */
    dispstackvalspec(cd->vecstore,(void (*)(void **))
        dispvecfuncpoint /* cd->dispvecpoint */ );
    dispstackall(&(cd->vecstore));
  }
  if (cd->auxanpt==NULL)
    dispanalysispoint(&(cd->auxanpt));
  if (cd->auxvecpt==NULL)
    dispvecfuncpoint(&(cd->auxvecpt));
  free(*addrcd);
  *addrcd=NULL;
}
}




int anfunc_fromvec(vector param,int *calcobj,double **addrobj,
          int *calcconstr,stack *addrconstr,
          int *calcgradobj,vector *addrgradobj,
          int *calcgradconstr,stack *addrgradconstr,
          analysis_to_vecfunc_cd cd)
    /* Analysis function that is based on a vector function of vector argument
    of type vec_bas_f, which is called for calculating the objective and /or 
    constraint functions and eventually their gradients. 
      The vector function that does the job is cd->vecfunc and its definition 
    data is cd->veccd. Auxilliary data structures on cdsuch as buffers for 
    intermediate results storage are also used.
      Vector function must be of type vec_bas_f, which is equivalent to
    int (*) (vector,int *,vector *,int *,matrix *, void *).
      Most commonly, the first value of vector function result will represent
    the objective function and subsequent values will represent constraint
    functions. This may be changed by cd->numobj and cd->numconstr to determine
    the number of objective and constraint functions.
      This function is of type analysis_bas_f.
      Remarks:
      In this function, cd->calcobj, cd->calcconstr, cd->calcgradobj, 
    cd->calcgradconstr, cd->obj, cd->constr, cd->gradobj and cd->gradconstr
    MAY NOT BE USED (to prevent conflicts when cd is used for two-way 
    conversion)!
    $A Igor apr05; */
{
int i=0,j=0,ret=0,which,gotnumval;
double *dptr;
vector v;
stack st;
analysispoint auxpt;  /* auxiliary pointer */
if (cd==NULL)
{
  m_errorreport0("anfunc_fromvec","Client data is NULL.\n");
  return -1;
} else if (param==NULL)
{
  m_errorreport0("anfunc_fromvec","Vector of parameters is NULL.\n");
  cd->vecret=-2;
} else
{
  /* Auxiliary storage for easier transcription of results: */
  if (cd->auxanpt==NULL)
	cd->auxanpt=newanalysispoint();
  auxpt=cd->auxanpt;
  /* Identify what to calculate by the vector function: */
  cd->calcval=cd->calcgrad=0;
  if (calcobj!=NULL) if (*calcobj)
    cd->calcval=1;
  if (calcconstr!=NULL)  if (*calcconstr)
    cd->calcval=1;
  if (!(cd->vecblockgrad))
  {
    if (calcgradobj!=NULL)  if (*calcgradobj)
      cd->calcgrad=1;
    if (calcgradconstr!=NULL)  if (calcgradconstr)
      auxpt->calcgradconstr=1;
  }
  /* Call vector function for calculation: */
  ret=cd->vecret=
    cd->vecfunc(param,&(cd->calcval),&(cd->vecval),
        &(cd->calcgrad),&(cd->vecgrad), cd->veccd );
  if (cd->vecblockgrad)
  {
    /* Gradient calculation blocking is set, make sure that this is enforced: */
    cd->calcgrad=0;
  }
  if (cd->recordvec)
  {
    /* Record vector function evaluation point: */
    vecfuncpoint vecpt=NULL;
    if (cd->vecstore!=NULL) if (cd->vecstore->n>0)
      vecpt=popstack(cd->vecstore);
    pushstack(cd->vecpoints,
        copyvecfuncrestopoint(param,cd->calcval,cd->vecval,
        cd->calcgrad,cd->vecgrad,  &vecpt)  );
  }
  /* Determine the number of parameters, constraints, objectives, components
  of vector function, etc.: */
  cd->numparam=param->d;
  gotnumval=0;
  if (cd->calcval)
    if (cd->vecval!=NULL)
    {
      cd->numval=cd->vecval->d;
      gotnumval=1;
    }
  if (!gotnumval) 
    if (cd->calcgrad)
      if (cd->vecgrad!=NULL)
      {
        cd->numval=cd->vecgrad->d1;
        gotnumval=1;
      }
  if (cd->numval<1)
  {
    ret=cd->vecret=-10;
    errfunc0("anfunc_fromvec");
    sprintf(ers(),"Dimension of vector function result is less than 1.\n");
    errfunc2();
  } else
  {
    if (cd->numobj+cd->numconstr!=cd->numval)
    {
      /* Try to determine the number of objective and constraint functions: */
      if (auxpt->obj==0 && cd->numconstr==cd->numval-1)
        cd->numobj=1;
      else if (cd->numconstr==cd->numval)
        cd->numobj=0;
      else
      {
        cd->numobj=1;
        cd->numconstr=cd->numobj-1;
      }
    }
    if (cd->numobj>1)
    {
      cd->numobj=1;
      ret=cd->vecret=-20;
      errfunc0("anfunc_fromvec");
      sprintf(ers(),"Number of objective functions is grater then 1 (%i).\n",
          cd->numobj);
      sprintf(ers(),"The number will be set to 1 and transctiprion of results continued.\n");
      errfunc2();
    }

    copyvector(param,&(cd->param));  /* CONSIDER whether this is necessary */
    /* Copying results - values: */
    /* IMPLEMENT MORE CHECKING AT RESULT TRANSCRIPTION (?) */
    if ( (cd->calcval && cd->vecval!=NULL)  )
    {
      /* cd->calcval=1; */
      which=0;
      if (cd->numobj>0)
      {
        which=1;
        if (calcobj!=NULL)
          if (*calcobj)
          {
            if (addrobj!=NULL)
            {
              if (*addrobj==NULL)
                *addrobj=calloc(1,sizeof(**addrobj));
              **addrobj=cd->vecval->v[which];
            }
          }
      } else
        if (calcobj!=NULL)
          *calcobj=0;
      if (calcconstr!=NULL)
        if (*calcconstr && addrconstr!=NULL)
        {
          if (*addrconstr==NULL)
            *addrconstr=newstackrn(1,cd->numconstr);
          else if ((*addrconstr)->n!=cd->numconstr)
            resizestack(addrconstr,0,cd->numconstr,(void (*) (void **)) dispscalar);
          st=*addrconstr;
          for (i=1;i<=cd->numconstr;++i)
          {
            ++which;
            if (st->s[i]==NULL)
              st->s[i]=calloc(1,sizeof(**addrobj));
            dptr=st->s[i];
            *dptr=cd->vecval->v[which];
          }
        }
    } else
    {
      if (calcobj!=NULL)
        *calcobj=0;
      if (calcconstr!=NULL)
        *calcconstr=0;
    }
    if ( (cd->calcgrad && cd->vecgrad!=NULL)  )
    {
      /* cd->calcval=1; */
      which=0;
      if (cd->numobj>0)
      {
        which=1;
        if (calcgradobj!=NULL)
          if (*calcgradobj)
          {
            if (addrgradobj!=NULL)
            {
              if (*addrgradobj==NULL)
                *addrgradobj=getvector(cd->numparam);
              else if ((*addrgradobj)->d!=cd->numparam)
                resizevector(addrgradobj,cd->numparam);
              v=*addrgradobj;
              for (j=1;j<=v->d;++j)
                v->v[j]=cd->vecgrad->m[which][j];
            }
          }
      } else
        if (calcgradobj!=NULL)
          *calcgradobj=0;
      if (calcgradconstr!=NULL)
        if (*calcgradconstr && addrgradconstr!=NULL)
        {
          if (*addrgradconstr==NULL)
            *addrgradconstr=newstackrn(1,cd->numconstr);
          else if ((*addrgradconstr)->n!=cd->numconstr)
            resizestack(addrgradconstr,0,cd->numconstr,
                (void (*) (void **)) dispvector);
          st=*addrgradconstr;
          for (i=1;i<=cd->numconstr;++i)
          {
            ++which;
            if (st->s[i]==NULL)
              st->s[i]=getvector(cd->numparam);
            else if ((v=st->s[i])->d!=cd->numparam)
              resizevector((vector *)&(st->s[i]),cd->numparam);
            v=st->s[i];
            for (j=1;j<=cd->numparam;++j)
              v->v[j]=cd->vecgrad->m[which][j];
          }
        }
    } else
    {
      if (calcgradobj!=NULL)
        *calcgradobj=0;
      if (calcgradconstr!=NULL)
        *calcgradconstr=0;
    }

  }
}
return ret;
}



int vecfunc_froman(vector param,int *calcval,vector *addrval,
                     int *calcgrad,matrix *addrgrad,
                     analysis_to_vecfunc_cd cd)
    /* Vector function of vector variable of type vec_bas_f, which is derived
    from the standard analysis function of type analysis_bas_f.
      clientdata must be a pointer to structure of type analysis_to_vecfunc_cd,
    which has been constructed from a given analysis function and its client
    data by the function convert_analysis_to_vecfunc (or in some similar way,
    but this method should normally be used).
      Convention: Gradients are stored *addrgrad by rows.
      Remarks:
      In this function, cd->calcval, cd->calcgrad, cd->vecval and cd->vecgrad
    MAY NOT BE USED (in order to prevent conflicts when cd is used for two-way 
    conversion)!
    $A Igor feb05 jul05; */
{
int i=0,j=0,ret=0,which;
double *dptr;
vector vec;
vecfuncpoint auxpt;  /* auxiliary pointer */
if (cd==NULL)
{
  m_errorreport0("vecfunc_froman","Client data is NULL.\n");
  ret=-1;
} else if (param==NULL)
{
  m_errorreport0("vecfunc_froman","Vector of parameters is NULL.\n");
  ret=cd->anret=-2;
} else
{
  /* Prepare auxiliary point for intermediate storage: */
  if (cd->auxvecpt==NULL)
    cd->auxvecpt=newvecfuncpoint();
  auxpt=cd->auxvecpt;
  /* Identify what to calculate by the analysis: */
  /* if (valaddr!=NULL) */
  cd->calcobj=cd->calcconstr=cd->calcgradobj=cd->calcgradconstr=0;
  if (calcval!=NULL)  if (*calcval)
    cd->calcobj=cd->calcconstr=1;
  if (!(cd->anblockgrad))
  {
    if (calcgrad!=NULL)  if (*calcgrad)
      /* calcgradobj=calcgradconstr= */ /* auxpt->calcgrad= */ 
               cd->calcgradobj=cd->calcgradconstr=1;
  }
  /* Run analysis: */
  ret=cd->anret=
    cd->anfunc(param,&(cd->calcobj),&(cd->obj),&(cd->calcconstr),
    &(cd->constr), &(cd->calcgradobj),&(cd->gradobj),&(cd->calcgradconstr),
    &(cd->gradconstr),cd->ancd );
  if (cd->anblockgrad)
  {
    /* Gradient calculation blocking is set, make sure that this is enforced: */
    cd->calcgradobj=cd->calcgradconstr=0;
  }
  if (cd->recordan)
  {
    /* Record analysis point: */
    analysispoint anpt=NULL;
    if (cd->anstore!=NULL) if (cd->anstore->n>0)
      anpt=popstack(cd->anstore);
    pushstack(cd->anpoints,
        copyanfuncrestopoint0(cd->anret,param,cd->calcobj,cd->obj,
        cd->calcconstr,cd->constr, cd->calcgradobj, cd->gradobj,
        cd->calcgradconstr,cd->gradconstr,  &anpt)  );
  }
  /* Determine the number of parameters, constraints, objectives, components
  of vector function, etc.: */
  cd->numparam=param->d;
  cd->numobj=0;
  if (cd->calcobj && cd->obj!=NULL)
    cd->numobj=1;
  else if (cd->calcgradobj && cd->gradobj!=NULL)
    cd->numobj=1;
  cd->numconstr=0;
  if (cd->calcconstr && cd->constr!=NULL)
    cd->numconstr=cd->constr->n;
  else if (cd->calcgradconstr && cd->gradconstr!=NULL)
    cd->numconstr=cd->gradconstr->n;

  copyvector(param,&(cd->param));  /* CONSIDER whether necessary */
  cd->numval=cd->numobj+cd->numconstr;
  /* Copying results - values: */
  
  /* IMPLEMENT MORE CHECKING AT RESULT TRANSCRIPTION (?) */

  if ( (cd->calcobj && cd->obj!=NULL) || (cd->calcconstr && cd->constr!=NULL) )
  {
    *calcval=1;
    resizevector(&(auxpt->val),cd->numval);
    which=0;
    if (cd->calcobj && cd->obj!=NULL)
    {
      auxpt->val->v[1]=*(cd->obj);
      which=1;
    }
    if (cd->calcconstr && cd->constr!=NULL)
    {
      if (cd->constr->n!=cd->numconstr)
      {
        ret=cd->anret=-4;
        errfunc0("vecfunc_froman");
        sprintf(ers(),"Inconsistent number of constraints, %i against %i.\n",
          cd->constr->n,cd->numconstr);
        errfunc2();
      }
      for (i=1;i<=cd->constr->n;++i)
      {
        ++which;
        if (which<=cd->numval && cd->constr->s[i]!=NULL)
        {
          dptr=cd->constr->s[i];
          auxpt->val->v[which]=*dptr;
        }
      }
    }
    if (addrval!=NULL)
      copyvector(auxpt->val,addrval);
  } else 
  {
    if (calcval!=NULL)
      *calcval=0;
  }
  if (cd->calcgradobj && cd->gradobj!=NULL || 
      cd->calcgradconstr && cd->gradconstr!=NULL)
  {
    if (calcgrad!=NULL)
      *calcgrad=1;
    resizematrix(&(auxpt->grad),cd->numval,cd->numparam);
    which=0;
    if (cd->calcgradobj && cd->gradobj!=NULL)
    {
      which=1;
      for (j=1;j<=cd->gradobj->d;++j)
        auxpt->grad->m[which][j]=cd->gradobj->v[j];
    }
    if (cd->calcgradconstr && cd->gradconstr!=NULL)
    {
      for (i=1;i<=cd->gradconstr->n;++i)
      {
        ++which;
        vec=cd->gradconstr->s[which];
        for (j=1;j<=vec->d;++j)
          auxpt->grad->m[which][j]=vec->v[j];
      }
    }
    if (addrgrad!=NULL)
      copymatrix(auxpt->grad,addrgrad);
  } else
  {
    if (calcgrad!=NULL)
      calcgrad=0;
  }
}
return ret;
}




































void prepvecfunc_froman(analysis_bas_f analysis,void *analysiscd,
        void (*dispanalysiscd)(void **),int recordan,int recordvecfunc,
        vec_bas_f *addrfunc,analysis_to_vecfunc_cd *addrcd,
        void (*dispcd)(void **))
    /* Performs conversion from standard analysis function to vector function
    of vector variable.
    $A Igor feb05; */
{
if (addrcd==NULL)
{
  m_errorreport0("prepvecfunc_froman",
    "Address for vector function client data is missing.\n");
} else
{
  m_errorreport0("prepvecfunc_froman",
    "This function (conversion of analysis to vector function) is not implemented yet.\n");
}

}




        /******************************************/
        /*                                        */
        /*  NUMERICAL DERIVATION OF VECTOR FUNC.  */
        /*                                        */
        /******************************************/


vecfuncnumgradcd newvecfuncnumgradcd(void)
  /* Allocates space for structure of type numgradcd and returns its pointer.
  $A Igor apr05; */
{
vecfuncnumgradcd ret;
static int id=0;
ret=calloc(1,sizeof(*ret));
++id;  ret->id=id;  ret->type=TYPE_vecfuncnumgradcd;
return ret;
}


void dispvecfuncnumgradcd(vecfuncnumgradcd *addrnumgradcd)
    /* Deallocates the structure pointed to by *addr and sets *addr to NULL.
    $A Igor nov04; */
{
vecfuncnumgradcd numgrad;
if (addrnumgradcd!=NULL)
{
  numgrad=*addrnumgradcd;
  if (numgrad->type!=TYPE_vecfuncnumgradcd)  /* Type check */
  {
    m_errorreport0("dispnumgradcd","Incorrect type.\n");
    return;
  }
  if (numgrad->veccd!=NULL && numgrad->dispveccd!=NULL)
    numgrad->dispveccd(&(numgrad->veccd));
  dispvector(&numgrad->vstep);
  /* Delete data on the stack of other points: */
  if (!numgrad->notdisppoints)
  {
    dispstackallspec(&(numgrad->points),(void (*) (void **)) dispvecfuncpoint);
    dispstackallspec(&(numgrad->storepoints),(void (*) (void **)) dispvecfuncpoint);
  }
  free(numgrad);
  *addrnumgradcd=NULL;
}
}


int vecfuncnumgrad(vector param,int *calcval,vector *addrval,
                     int *calcgrad,matrix *addrgrad,
                     vecfuncnumgradcd cd)
    /* Vector function of vector variable of type vec_bas_f, which is calculate
    the gradients numerically. All data for gradient calculation are on 
    from the standard analysis function of type analysis_bas_f.
      clientdata must be a pointer to structure of type analysis_to_vecfunc_cd,
    which has been constructed from a given analysis function and its client
    data by the function convert_analysis_to_vecfunc (or in some similar way,
    but this method should normally be used).
      This function is of type vec_bas_f.
    $A Igor feb05; */
{
int ret=0,nparam=0,nval=0,cval=0,cgrad=0,ptcval,ptcgrad,i,j,whichpt,docalc;
static int reportednotimp=0;
vecfuncpoint pt=NULL,pt1=NULL,pt2=NULL,ptaux;
double hi,defaultstep=1.0e-6;
matrix grad;
/* Store original instructions carried by flags, set falgs to 0 until things
are actually calculated: */
if (calcval!=NULL)
{
  cval=*calcval;
  *calcval=0;
}
if (calcgrad!=NULL)
{
  cgrad=*calcgrad;
  *calcgrad=0;
}
if (param!=NULL)
  nparam=param->d;
if (nparam<1)
{
  ret=-1;
  errfunc0("vecfuncnumgrad");
  if (param==NULL)
    sprintf(ers(),"Vector of parameters is NULL.\n");
  else
    sprintf(ers(),"Number of parameters is less than 1.\n");
  errfunc2();
} else if (cd==NULL)
{
  ret=-2;
  errfunc0("vecfuncnumgrad");
  sprintf(ers(),"Data for gradient calculation is NULL.\n");
  errfunc2();
} else if (cd->vecfunc==NULL)
{
  ret=-3;
  errfunc0("vecfuncnumgrad");
  sprintf(ers(),"For test:\n");
  sprintf(ers(),"Vector function whose gradient should be calculated is not defined.\n");
  errfunc2();
} else
{
  /* Prepare stack of points if necessary: */
  if (cd->notdisppoints && (cd->points==NULL || cd->storepoints==NULL))
  {
    /* We can allow external stacks only if both have been allocated. */
    cd->points=cd->storepoints=NULL;
    cd->notdisppoints=0;
  }
  if (cd->points==NULL)
    cd->points=newstack(2);
  if (cd->storepoints==NULL)
    cd->storepoints=newstack(2);
  if (cval || cgrad)
  {
    /* Get a storage point for calculation at original parameters: */
    if (cd->recordvec)
    {
      /* We need to record analyses, so we must add a point to st->points: */
      ptaux=popstack(cd->storepoints);
      if (ptaux==NULL)
        ptaux=newvecfuncpoint();
      pushstack(cd->points,ptaux);
    } else
    {
      /* We don't record analyses, pt will be the first point on the stack: */
      whichpt=1;
      while (cd->points->n<whichpt)
        pushstack(cd->points,popstack(cd->storepoints));
      if (cd->points->s[whichpt]==NULL)
        cd->points->s[whichpt]=newvecfuncpoint();
      ptaux=cd->points->s[whichpt];
    }
    pt=ptaux;  /* point for calculation at original parameters */

    /* Determine what to evaluate at original parameters: */
    if (cgrad && cd->noforcenum)
      ptcgrad=1;  /* numerical derivation not forced, analytical gradient
          will be used if available. */
    else
      ptcgrad=0;  /* we will not use analytical gradients */
    if (cval || !cd->noforcenum)
      ptcval=1;
    else
      ptcval=0;
    pt->calcval=ptcval;
    pt->calcgrad=ptcgrad;
    /* Evaluation at original parameters: */
    copyvector(param,&(pt->param));
    cd->vecfunc(pt->param,&(pt->calcval),&(pt->val),&(pt->calcgrad),&(pt->grad),
          cd->veccd);
    if (!cgrad || (pt->calcgrad && pt->grad!=NULL && cd->noforcenum) )
    {
      /* Either gradient information has not been requested, or it has been
      been calculated analytically and this is admissible, so there is no need
      for numerical derivation: */
      if (cval)
      {
        /* Calculation of values requested, means that calcval!=NULL: */
        *calcval=pt->calcval;
        if (*calcval)
        {
          if (addrval!=NULL)
            copyvector(pt->val,addrval);
          else
          {
            errfunc0("vecfuncnumgrad");
            sprintf(ers(),"Address of storage for function values is not specified.\n");
            errfunc2();
          }
        }
      }
      if (cgrad)
      {
        /* Calculation of gradients was requested: */
        *calcgrad=pt->calcgrad;
        if (*calcgrad)
        {
          if (addrgrad!=NULL)
            copymatrix(pt->grad,addrgrad);
          else
          {
            errfunc0("vecfuncnumgrad");
            sprintf(ers(),"Address of storage for function gradients is not specified.\n");
            errfunc2();
          }
        }
      }
    } else
    {
      /* We need to calculate gradients numerically, first check the data: */
      if (cd->vstep!=NULL)
        if (cd->vstep->d!=nparam)
        {
          warnfunc1(1,"vecfuncnumgrad");
          sprintf(ers(),"Vector of steps for numerical derivation is of wrong dimension (%i, should be %i).\n",
              cd->vstep->d,nparam);
          if (cd->step==0 && cd->vstep->d<1)
          {
            cd->step=defaultstep;
            sprintf(ers(),"Default step (%g) will be used.\n",cd->step);
          } else if (cd->step==0)
          {
            cd->step=cd->vstep->v[1];
            if (cd->step==0)
              cd->step=defaultstep;
            sprintf(ers(),"The first component of the vector (%g) will be used.\n",cd->step);
          }
          warnfunc2();
          dispvector(&(cd->vstep));
        }
      if (cd->step==0)
      {
        cd->step=defaultstep;
        warnfunc1(1,"vecfuncnumgrad");
        sprintf(ers(),"Step for numerical derivation was 0, the default step (%g) will be used.\n",
            cd->step);
        warnfunc2();
      }
      if (!ptcval)
      {
        /* Values were not requested in previous call, obviously we have tested
        whether analytical gradients would be provided but they were not. Call 
        vector function again: */
        ptcval=pt->calcval=1;
        ptcgrad=pt->calcgrad=0;  /* gradients calculated numerically! */
        copyvector(param,&(pt->param));
        cd->vecfunc(pt->param,&(pt->calcval),&(pt->val),&(pt->calcgrad),&(pt->grad),
          cd->veccd);
      }
      if (ptcval && (!(pt->calcval) || pt->val==NULL))
      {
        /* Values were requwsted but could not be calculated; do nothing - just
        return, since return flags were already set to 0; Eventually an erorr
        or warning can be launched here. */
      } else
      {
        if (cval)
        {
          /* Calculation of values requested (therefore calcval!=NULL),
          copy the result: */
          *calcval=pt->calcval;
          if (*calcval)
          {
            if (addrval!=NULL)
              copyvector(pt->val,addrval);
            else
            {
              errfunc0("vecfuncnumgrad");
              sprintf(ers(),"Address of storage for function values is not specified.\n");
              errfunc2();
            }
          }
        }
        if (pt->calcval)
          if (pt->val!=NULL)
            nval=pt->val->d;
        /* Now calculate gradients by the chosen method defined by cd: */
        if (0)   /* IMPLEMENT OTHER METHODS! */
        {
          /* UNCOMMENT BELOW and implement the other methods! */
        } else
        {
          /* Not implemented or UNKNOWN METHOD, or forward difference: */
          if (! reportednotimp && (0 && cd->quadratic ) )
          {
            /* Flags on cd did not indicate the forward difference method, but
            the method to use seems not implemented, report this and continue: */
            ++reportednotimp;
            warnfunc1(1,"vecfuncnumgrad");
            sprintf(ers(),"The requested method is currently not implemented,\n  ordinary forward difference is used.\n");
            sprintf(ers(),"Flags:\n");
            sprintf(ers(),"backdif: %i, quadratic: %i\n",cd->backdif,cd->quadratic);
            sprintf(ers(),"Further warning message of this type will be omitted.\n");
            warnfunc2();
          }

          /* Ordinary FORWARD or BACKWARD DIFFERENCE method: */

          if (addrgrad!=NULL && nval>0 && nparam>0)
          {
            /* CONSIDER how gradient matrix should be stored - gradients 
            column-wise or row-wise, CURRENTLY ROW-WISE. */
            resizematrix(addrgrad,nval,nparam);
            grad=*addrgrad;
            *calcgrad=1;
            for (i=1;i<=nparam;++i)
            {
              /* Calculate derivative with respect to i-th parameter: */
              pt1=pt2=NULL;
              
              /* Get a storage point for calculation at perturbed parameters: */
              if (cd->recordvec)
              {
                /* We need to record analyses, so we must add a point to st->points: */
                ptaux=popstack(cd->storepoints);
                if (ptaux==NULL)
                  ptaux=newvecfuncpoint();
                pushstack(cd->points,ptaux);
              } else
              {
                /* We don't record analyses, take the second point on the stack
                (the first point is for original parameters) : */
                whichpt=2;
                while (cd->points->n<whichpt)
                  pushstack(cd->points,popstack(cd->storepoints));
                if (cd->points->s[whichpt]==NULL)
                  cd->points->s[whichpt]=newvecfuncpoint();
                ptaux=cd->points->s[whichpt];
              }
              ptaux->calcval=1;
              ptaux->calcgrad=0;
              pt1=ptaux;  /* point for calculation at original parameters */

              if (cd->quadratic)
              {
                /* Central difference method, we need another storage point: */
                if (cd->recordvec)
                {
                  /* We need to record analyses, so we must add a point to st->points: */
                  ptaux=popstack(cd->storepoints);
                  if (ptaux==NULL)
                    ptaux=newvecfuncpoint();
                  pushstack(cd->points,ptaux);
                } else
                {
                  /* We don't record analyses, take the second point on the stack
                  (the first point is for original parameters) : */
                  whichpt=3;
                  while (cd->points->n<whichpt)
                    pushstack(cd->points,popstack(cd->storepoints));
                  if (cd->points->s[whichpt]==NULL)
                    cd->points->s[whichpt]=newvecfuncpoint();
                  ptaux=cd->points->s[whichpt];
                }
                ptaux->calcval=1;
                ptaux->calcgrad=0;
                pt2=ptaux;  /* point for calculation at original parameters */
              }
              
              if (cd->vstep!=NULL)
              {
                hi=cd->vstep->v[i];
                if (hi==0)  /* permit definition of specific step of different size */
                  hi=cd->step;
              } else
                hi=cd->step;
              if (hi==0)
                hi=defaultstep;
              else if (hi<0)
                hi=-hi;
              docalc=1;
              copyvector(param,&(pt1->param));
              if (!cd->backdif && !cd->quadratic)
                pt1->param->v[i]+=hi;
              else
                pt1->param->v[i]-=hi;
              /* Perform calculation at the perturbed parameters: */
              cd->vecfunc(pt1->param,&(pt1->calcval),&(pt1->val),
                  &(pt1->calcgrad),&(pt1->grad),  cd->veccd);
              if (pt1->calcval==0 || pt1->val==NULL)
              {
                *calcgrad=0;  docalc=0;
              }
              if (cd->quadratic)
              {
                /* Perform calculation at the second perturbed parameters: */
                copyvector(param,&(pt2->param));
                pt2->param->v[i]+=hi;
                cd->vecfunc(pt2->param,&(pt2->calcval),&(pt2->val),
                    &(pt2->calcgrad),&(pt2->grad),  cd->veccd);
                if (pt2->calcval==0 || pt2->val==NULL)
                {
                  *calcgrad=0;  docalc=0;
                }
              }
              if (docalc)
              {
                for (j=1;j<=nval;++j)
                {
                  if (!cd->backdif && !cd->quadratic)  /* forward dif. */
                    grad->m[j][i]=(pt1->val->v[j]-pt->val->v[j])/hi;
                  else if (!cd->quadratic)  /* backward dif. */
                    grad->m[j][i]=(pt->val->v[j]-pt1->val->v[j])/hi;
                  else if (cd->quadratic)  /* central dif. */
                    grad->m[j][i]=(pt2->val->v[j]-pt1->val->v[j])/(2.0*hi);
                }
              }
            }
            /*
            if (0)
            {
              printf("\n\nTest output: Matrix of gradients:\n");
              printmatrixlist(grad);  printf("\n\n");
            }
            */
          } else
          {
            *calcgrad=0;
          }
        }

      }
    }
  }
}
return ret;
}




analysis_to_vecfunc_cd prepanfuncnumgrad(analysis_bas_f anfunc,void *ancd,
           void (*dispancd) (void**),
         double step,vector vstep,
         int backdif,int quadratic,int noforcenum,
         analysis_bas_f *addrfunc,
         analysis_to_vecfunc_cd *addrcd,
         void (**addrdispcd)(void **) )
    /* Prepares data for numerical derivation of an analysis function. 
      anfunc - original analysis function whose results will be numerically
    differentiated. 
      anfunccd - data for anfunc
      dispancd - function for deallocation of anfunccd. If it is not NULL then
    this function will be used for deallocation of data ancd when the 
    constructed data structure for numerical differentiation (stored in *
    addrcd) is deallocated. If it is NULL then this structure is not 
    deallocated together with data structure for numerical differentiation.
      step - step used for numericall differentiation. If different than 0
    then the same step is used for all variables.
      vstep - vector of steps for numerical differentiation. If it is NULL then
    step will be used for all variables. If it is not NULL but some components
    are 0 then step will be used instead of these components. A copy of vstep
    is put on the structure, therefore original vstep should be deallocated 
    after it is ceased to be used.
      addrfunc - address of storage for pointer to analysis function that
    performs analysis with numerical differentiation
      addrcd - address of storage for definition data for analysis function 
    with numerical  calculation of gradients. It may be NULL or it may point 
    to a  non-NULL pointer fo the correct type, which is already allocated. 
    The function also returns the pointer of the definition data structure. 
      addrdispcd - address for storing pointer to function for deallocation of
    data structure for numerical differentiation (stored at addrcd).
      addrfunc and addrdispcd can be NULL if the caller knows which function 
    should be used as a new anlysis function that performs numerical 
    differentiation of the original and which should be used for deallocation
    of the created data structure. These are ment especially when the caller
    does not now enough about the functio of numerical differentiation and 
    wants to store the data and corresponding deallocation function simply to
    a pointer of type void *.
      The function constructructs a data structure for numerical
    differentiation of analysis results and sets *addrcd so that it points to
    tihs structure. Original analysis function anfunc and its definition data
    is put on the structure as well as data that defines how differntiation
    is performed. If analysis definition data will not be kept somewhere else,
    then dispancd can be specified to be used for deallocation of ancd when 
    the complete data for numerical differentiation is deallocated.
      Remark:
      addrcd must be non-NULL. If *addrcd!=NULL then it is checked if it is
    of appropriate type. If it is not then it is de-allocated by *addrdispcd
    if it is not NULL, or just set to NULL.
    $A Igor apr05; */
{
analysis_to_vecfunc_cd cd=NULL;
vecfuncnumgradcd numgradcd=NULL;
int dodelete=0;
if (addrcd==NULL)  /* actualllty, address may be NULL - in this case return matters */
{
  errfunc0("prepanfuncnumgrad");
  sprintf(ers(),"Address to store analysis data for numerical derivation is NULL.\n");
  errfunc2();
} else if (anfunc==NULL)
{
  errfunc0("prepanfuncnumgrad");
  sprintf(ers(),"Analysis function (original) is not specified.\n");
  errfunc2();
} else
{
  /* Prepare data for the analysis function that will calculates objective and
  constraint functions by anfunc, and their gradients by numerical derivation
  of anfunc results: */
  if (*addrcd!=NULL)
  {
    /* If addrcd points to already allocated data then we need to check if the
    data is of correct type. If it is not we need to de-allocate it (or set
    to NULL when de-allocation is not applicable): */
    dodelete=0;
    if (addrdispcd!=NULL)
      if (*addrdispcd!=NULL &&
          *addrdispcd!=(void (*) (void **)) dispanalysis_to_vecfunc_cd)
        dodelete=1;  /* different de-allocation function, indicates 
            incompatible type */
    if (!dodelete && (cd=*addrcd)->type!=TYPE_analysis_to_vecfunc_cd)
      dodelete=1;
    if (dodelete)
    {
      if (addrdispcd!=NULL) if (*addrdispcd!=NULL)
        (*addrdispcd) (addrcd);
      *addrcd=NULL;
    }
  }
  if (addrdispcd!=NULL)
    *addrdispcd=(void (*)(void **)) dispanalysis_to_vecfunc_cd;
  if (addrfunc!=NULL)
    *addrfunc=anfunc_fromvec;
  if (*addrcd==NULL)
    *addrcd=newanalysis_to_vecfunc_cd();
  cd=*addrcd;
  cd->anfunc=anfunc;
  /* Delete current analysis definition data if defined: */
  if (cd->ancd!=NULL)
    if (cd->dispancd!=NULL)
      cd->dispancd(&(cd->ancd));
  cd->ancd=ancd;
  cd->dispancd=dispancd;

  /* Prepare data structure for numerical differentiation */
  if (cd->veccd!=NULL)
  {
    /* De-allocate cd->veccd if it is of different type than specified by
    this function: */
    if (cd->dispveccd!= (void (*) (void **)) dispvecfuncnumgradcd)
      cd->dispveccd(&(cd->veccd));
  }
  if (cd->veccd==NULL)
    cd->veccd=newvecfuncnumgradcd();
  numgradcd=cd->veccd;
  cd->vecfunc=vecfuncnumgrad;  /* function that performs numerical differentiation */
  cd->dispveccd=(void (*) (void **)) dispvecfuncnumgradcd;
  numgradcd->vecfunc=vecfunc_froman; /* basic data for vector function ... */
  if (numgradcd->veccd!=NULL)
    if (numgradcd->dispveccd!=NULL)
      numgradcd->dispveccd(&(numgradcd->veccd));
  numgradcd->veccd=cd;
  numgradcd->dispveccd=NULL;  /* don't deallocate */
  if (numgradcd->notdisppoints)
    numgradcd->points=numgradcd->storepoints=NULL;
  if (numgradcd->points==NULL)
    numgradcd->points=newstack(2);
  if (numgradcd->storepoints==NULL)
    numgradcd->storepoints=newstack(2);
  numgradcd->notdisppoints=0;  
  numgradcd->step=step;/* control data defining numerical differentiation... */
  copyvector(vstep,&(numgradcd->vstep));
  numgradcd->backdif=backdif;
  numgradcd->quadratic=quadratic;
  numgradcd->noforcenum=noforcenum;
}
return cd;
}








          /********************************/
          /*                              */
          /*  OPTIMIZATION DATA HANDLING  */
          /*                              */
          /********************************/


optalgcd newoptalgcd(void)
    /* Creates and returns an object of type optalgcd. anf and clientdata are
    the analysis function and client data passed to optimization algorithm.
    $A Igor oct 04; */
{
optalgcd ret;
static int id=0;
ret=calloc(1,sizeof(*ret));
++id;  ret->id=id;  ret->type=TYPE_optalgcd;
/*
ret->anf=anf;
ret->cd=clientdata;
*/
ret->lastparam=NULL;
/* Analysis data: */
ret->obj=NULL; ret->gradobj=NULL; ret->constr=NULL; ret->gradconstr=NULL;
/* Algorithm data: */
/* Arrays used as arguments to the cfsqp function: */
ret->lowbounds=ret->upbounds=NULL;
ret->bl=ret->bu=ret->x=ret->f=ret->g=ret->lambda=NULL;
return ret;
}

void dispoptalgcd(optalgcd *addrcd)
    /* Deallocates the space pointed to by *addrcd of type optalgcd and sets
    *addrcd to NULL.
    $A Igor nov04; */
{
optalgcd cd;
if (addrcd!=NULL)
{
  cd=*addrcd;
  if (cd!=NULL)
  {
    m_threadlock(cd->lock);       /* Wait pending requests */
    if (cd->type!=TYPE_optalgcd)  /* Type check */
    {
      m_errorreport0("dispoptalgcd","Incorrect type.\n");
      return;
    }
    /* Wrapper data: */
    if (cd->funcname==NULL)   { free(cd->funcname); cd->funcname=NULL; }
    if (cd->callername=NULL)  { free(cd->callername); cd->callername=NULL; }
    if (cd->name=NULL)  { free(cd->name); cd->name=NULL; }
    if (cd->ancd!=NULL && cd->dispancd!=NULL)
      cd->dispancd(&(cd->ancd));
    if (cd->supdata!=NULL)
    {
      if (cd->dispsupdata!=NULL)
        cd->dispsupdata(cd->supdata);
      else
        free(cd->supdata);
      cd->supdata=NULL;
    }
    /* Analysis data: */
    dispvector(&(cd->lastparam));
    disppointer(&(cd->obj));
    dispvector(&(cd->gradobj));
    dispstackallspec(&(cd->constr),disppointer);
    dispstackallspec(&(cd->gradconstr),(void (*)(void **)) dispvector);
    /* Optimization results: */
    dispvector(&(cd->paramopt));
    disppointer(&(cd->objopt));
    dispvector(&(cd->gradobjopt));
    dispstackallspec(&(cd->constropt),disppointer);
    dispstackallspec(&(cd->gradconstropt),(void (*)(void **)) dispvector);
    /* Algorithm data: */
    dispvector(&(cd->lowbounds));
    dispvector(&(cd->upbounds));
    disppointer(&(cd->bl));
    disppointer(&(cd->bu));
    disppointer(&(cd->x));
    disppointer(&(cd->f));
    disppointer(&(cd->g));
    disppointer(&(cd->lambda));
    m_threadunlock(cd->lock);
    free(cd);
  }
  *addrcd=NULL;
}
}






          /******************************************/
          /*                                        */
          /*  BASIC SUPPORT FOR ANALYSIS FUNCTIONS  */
          /*                                        */
          /******************************************/



   /* PRINTING OF ANALYSIS RESULTS: */
  

void fprintanfuncres0(FILE *fp,vector param,double *obj,stack constr,
                     vector gradobj,stack gradconstr)
    /* Prints the results of optimization analysis to file fp. It just prints 
    the contents of arguments and does not care whether something was 
    calculated or not.
    $A Igor mar05; */
{
double *dptr;
vector v;
int i;
if (fp==NULL)
  return;
fprintf(fp,"\n\nAnalysis results:\n");
if (param==NULL)
  fprintf(fp,"Parameters: NULL.\n");
else 
{
  fprintf(fp,"Parameters (dim=%i):\n  ",param->d);
  fprintvectorlist(fp,param); fprintf(fp,"\n");
}
if (obj==NULL)
  fprintf(fp,"\nObjective function: NULL.\n\n");
else
  fprintf(fp,"\nObjective function: %g .\n\n",*obj);
if (gradobj==NULL)
  fprintf(fp,"Gradient of the objective function: NULL.\n\n");
else
{
  fprintf(fp,"Gradient of the objective function (dim=%i):\n  ",gradobj->d);
  fprintvectorlist(fp,gradobj); fprintf(fp,"\n\n");
}
if (constr==NULL)
  fprintf(fp,"Constraints: NULL.\n\n");
else if (constr->n<1)
  fprintf(fp,"No constraints.\n\n");
else
{
  fprintf(fp,"Constraints (num=%i):\n  ",constr->n);
  fprintf(fp,"{ ");
  for (i=1;i<=constr->n;++i)
  {
    dptr=constr->s[i];
    if (dptr==NULL)
      fprintf(fp,"NULL");
    else
      fprintf(fp,"%g",*dptr);
    if (i==constr->n)
      fprintf(fp," }\n\n");
    else
      fprintf(fp,", ");
  }
}
if (gradconstr==NULL)
  fprintf(fp,"Constraint gradients: NULL.\n\n");
else if (constr->n<1)
  fprintf(fp,"No constraint gradients.\n\n");
else
{
  int dim=0,num=0;
  num=gradconstr->n;
  if (num>0)
    if (gradconstr->s[1]!=NULL)
      dim=((vector) gradconstr->s[1])->d;
  fprintf(fp,"Constraint gradients (num x dim = %i x %i):\n  ",num,dim);
  fprintf(fp,"{\n  ");
  for (i=1;i<=gradconstr->n;++i)
  {
    v=gradconstr->s[i];
    if (v==NULL)
      fprintf(fp,"NULL");
    else
      fprintvectorlist(fp,v);
    if (i==gradconstr->n)
      fprintf(fp,"\n}\n\n");
    else
      fprintf(fp,",\n  ");
  }
}
fprintf(fp,"\n\n");
}


void printanfuncres0(vector param,double *obj,stack constr,
                     vector gradobj,stack gradconstr)
    /* Prints the results of optimization analysis to standard output by calling
    fprintanfuncres0().
    $A Igor mar05; */
{
fprintanfuncres0(stdout,param,obj,constr,gradobj,gradconstr);
}



static analysispoint printanfuncrespt=NULL;
static int printanfuncreslock=0;


void fprintanfuncres(FILE *fp,vector param,int calcobj,double *obj,
      int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr)
    /* Prints analysis results (usually obtained by calling a function of 
    type analysis_bas_f) to the file fp. Arguments after fp correspond to
    arguments whose addresses are passed as output arguments of the call of 
    the analysis function.
    $A Igor apr05; */
{
m_threadlock(printanfuncreslock);
copyanfuncrestopoint0(0,param,calcobj,obj,
      calcconstr,constr,calcgradobj,gradobj,
      calcgradconstr,gradconstr, &printanfuncrespt );
fprintanalysispoint(fp,printanfuncrespt);
m_threadunlock(printanfuncreslock);
}

void printanfuncres(vector param,int calcobj,double *obj,
      int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr)
    /* Prints analysis results to the standard output by use of 
    fprintanfuncres().
    $A Igor apr05; */
{
fprintanfuncres(stdout,param,calcobj,obj,
      calcconstr,constr,calcgradobj,gradobj,
      calcgradconstr,gradconstr);
}



void fprintanfuncreslist(FILE *fp,vector param,int calcobj,double *obj,
      int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr)
    /* Prints analysis results (usually obtained by calling a function of 
    type analysis_bas_f) to the file fp in a LIST form (comma separated lists
    of values in curly brackets).
    Arguments after fp correspond to arguments whose addresses are passed as
    output arguments of the call of the analysis function.
    $A Igor apr05; */
{
m_threadlock(printanfuncreslock);
copyanfuncrestopoint,(0,param,calcobj,obj,
      calcconstr,constr,calcgradobj,gradobj,
      calcgradconstr,gradconstr, &printanfuncrespt );
fprintanalysispointlist(fp,printanfuncrespt);
m_threadunlock(printanfuncreslock);
}

void printanfuncreslist(vector param,int calcobj,double *obj,
      int calcconstr,stack constr,  int calcgradobj,vector gradobj,
      int calcgradconstr,stack gradconstr)
    /* Prints analysis results to the standard output by use of 
    fprintanfuncreslist().
    $A Igor apr05; */
{
fprintanfuncreslist(stdout,param,calcobj,obj,
      calcconstr,constr,calcgradobj,gradobj,
      calcgradconstr,gradconstr);
}




    /* PREPARATION & MEMORY HANDLING */


int prepanfuncbas(vector param,int *calcobj,double **addrobj,
      int *calcconstr,stack *addrconstr,
      int *calcgradobj,vector *addrgradobj,
      int *calcgradconstr,stack *addrgradconstr,void *clientdata,
      int nparam,int nobj,int nconstr,int derobj,int derconstr,
      char *funcname,char *filename,int fileline)
    /* Prepares storage for analysis function for optimization problems of the
    type analysis_bas_f, reports errors in input data or returns information
    about optimization problem.
      First parameters correspond to parameters of the analysis function, while
    the rest are the following:
      nparam: number of parameters; should be 0 if the optimization problem 
    (and the corrresponding analysis function) is defined for different numbers
    of parameters.
      nobj: must be 1 if analysis defines an objective function or 0 if it does
        not.
      nconstr: number of constraints
      derobj: If 0 then function can not calculate gradient of the objective
    function, otherwise it can
      derconstr: If 0 then function can not calculate gradient of constraint
    functions, otherwise it can.
      funcname: name of the calling function
      filename: name of the file where function was called
      fileline: line number of the function call.

      INFO mode:
      If calcobj==calcconstr==calcgradobj==calcgradconstr == NULL then
    analysis should not be performed, but problem basic information should be
    returned instead (i.e. number of parameters & constraints). The information
    is actually provided by reallocation other arguments: if no objective
    function is defined, *addrobj is deallocated, otherwise it is allocated,
    gradient of objective function *gradobj is allocated with the dimension of 
    parameter vector, and *addrconstr and *addrgradconstr are also allocated
    or re-allocated with appropriate dimensions.
      Aagreements (info mode)
      If some analysis function does not support the info mode, then  it will
    not perform any allocation or re-allocation in this mode, which can be used
    for testing whether info mode is supported or not (call with all storage
    pointers set to NULL - but addresses of storage not NULL - and if info mode
    is not supported then no allocation will be performed.
      When analysis has a fixed number of parameters that is different from the
    dimension of the parameter vector passed, the function will allocate
    gradient information even if it actually does not calculate gradients, to
    pass the actual number of parameters supported (also error or warning
    report will be launched in this case). The same applies when the number of
    parameters is determined by the client data.
      Otherwise, if the function does not calculate gradients, alll gradient
    information will be deallocated in info mode.
      
      Note 
      In info mode, if the problem is not with a fixed number of parameters,
    then the function should be called with vector param allocated with 
    appropriate dimension.
      
      
      RETURNS 0 if analysis should continue, a negative error code if there is
    an error (inconsistency) in input arguments, or 1 if function was called in
    info mode.

    How to call within analysis function:
      if (!(ret=prepanfuncbas( ... ,
                 <nparam>,<nobj>,<nconstr>,<derobj>,<derconstr>,<funcname>,
                 __FILE__,__LINE__)))
        {  << analysis function code >>  }
    where ... means arguments of the analysis function, and __FILE__,__LINE__
    must be included literally (since these are pre-defined macros)

    $A Igor nov04; */
{
int ret=0,i;
stack st;
if (funcname==NULL)
  funcname="";
if (filename==NULL)
  filename="";
if (nparam>0)
{
  if (param!=NULL)
    if (param->d!=nparam)
    {
      ret=-1;
      errfunc0("prepanfuncbas");
      if (funcname!=NULL || filename!=NULL)
        sprintf(ers(),">>  In  function \"%s\", file \"%s\", line %i:\n",funcname,filename,fileline);
      sprintf(ers(),"Wrong dimension of parameter vector (%i, should be %i).\n",
          param->d,nparam);
      errfunc2();
      if (calcobj!=NULL) *calcobj=0;
      if (calcconstr!=NULL) *calcconstr=0;
      if (calcgradobj!=NULL) *calcgradobj=0;
      if (calcgradconstr!=NULL) *calcgradconstr=0;

    }
} else if (param!=NULL)
    nparam=param->d;
if (calcobj==NULL && calcconstr==NULL && calcgradobj==NULL && calcgradconstr==NULL)
{
  /* INFO mode, function tries to return information about the optimization
  problem by allocating space for the data. */
  ret=1;
  /* Handle objective gradient: */
  if (nobj>0)
  {
    if (nobj>1)
    {
      ret=-1000;
      errfunc0("prepanfuncbas");
      if (funcname!=NULL || filename!=NULL)
        sprintf(ers(),">>  In  function \"%s\", file \"%s\", line %i:\n",funcname,filename,fileline);
      sprintf(ers(),"Number of objective functions greater than 1 not supported in \"prepanfuncbas\".\n");
      sprintf(ers(),"Provided number of objective functions: %i.\n",nobj);
      errfunc2();
    }
    if (addrobj!=NULL)
      if (*addrobj==NULL)
        *addrobj=calloc(1,sizeof(**addrobj));
  } else
  {  /* This analysis function does not define objective functions */
    if (addrobj!=NULL)
      if (*addrobj!=NULL)
        dispscalar(addrobj);
  }
  
  if (addrgradobj!=NULL)
  {
    if (nparam>0)
    {
      if (nobj>0 && (derobj || (param==NULL)))  /* Even if the function can not
          calculate gradients of the objective function, but parameters were not
          specified and nparam>0, storage for objective function is allocated
          in order to pass back information about fixed number of parameters. */
      {
        resizevector(addrgradobj,nparam);
      } else
      {
        /* Objective gradient can not be provided by the function & we does not
        need to pass information about number of parameters */
        resizevector(addrgradobj,nparam);
      }
    } else
    {
      /* We don't konw the number of parameters, delete objective gradient: */
      if (addrgradobj!=NULL)
        dispvector(addrgradobj);
    }
  }

  if (addrconstr!=NULL)
  {
    if (nconstr>0)
    {
      resizestack(addrconstr,1,nconstr,(void (*) (void **)) dispscalar);
      st=*addrconstr;
      for (i=1;i<=st->n;++i)
        if (st->s[i]==NULL)
          st->s[i]=malloc(sizeof(**addrobj));
    } else
    {
      dispstackallspec(addrconstr,(void (*) (void **)) dispscalar);
    }
  }

  if (addrgradconstr!=NULL)
  {
    if (nconstr>0 && nparam>0 && (derconstr || (param!=NULL)) )
    {
      resizestack(addrgradconstr,1,nconstr,(void (*) (void **)) dispvector);
      st=*addrgradconstr;
      for (i=1;i<=st->n;++i)
        resizevector((vector *) &(st->s[i]),nparam);
    } else
      dispstackallspec(addrgradconstr,(void (*) (void **)) dispvector);
  }

} else if (nparam==0)
{
  ret=-2;
  errfunc0("prepanfuncbas");
  if (funcname!=NULL || filename!=NULL)
    sprintf(ers(),">>  In  function \"%s\", file \"%s\", line %i:\n",funcname,filename,fileline);
  sprintf(ers(),"Vector of parameters is NULL.\n");
  errfunc2();

} else
{
  if (calcobj!=NULL)
    if (*calcobj)
    {
      if (addrobj==NULL && nobj>0)
      {
        ret=-11;
        *calcobj=0;
        errfunc0("prepanfuncbas");
        if (funcname!=NULL || filename!=NULL)
          sprintf(ers(),">>  In  function \"%s\", file \"%s\", line %i:\n",funcname,filename,fileline);
        sprintf(ers(),"Address of storage for the objective function value has not been provided.\n");
        errfunc2();
      } else 
      {
        if (nobj<=0)
        {
          *calcobj=0;
          if (addrobj!=NULL) if (*addrobj!=NULL)
          {
            dispscalar(addrobj);
          }
        } else
        {
          if (nobj>1)
          {
            warnfunc1(1,"prepanfuncbas");
            sprintf(ers(),"Number of objective functions (%i) is greater than 1.\n",nobj);
            sprintf(ers(),"This function is not intended for cases wit multiple objectives.\n");
            warnfunc2();
          }
          if (*addrobj==NULL)
            *addrobj=malloc(sizeof(**addrobj));
        }
      }
    }
  if (calcconstr!=NULL)
    if (*calcconstr)
    {
      if (addrconstr==NULL)
      {
        ret=-12;
        *calcconstr=0;
        errfunc0("prepanfuncbas");
        if (funcname!=NULL || filename!=NULL)
          sprintf(ers(),">>  In  function \"%s\", file \"%s\", line %i:\n",funcname,filename,fileline);
        sprintf(ers(),"Address of storage for the constraint function values has not been provided.\n");
        errfunc2();
      } else
      {
        if (nconstr<=0)
        {
          *calcconstr=0;   /* problem has no constraints */
          if (*addrconstr!=NULL)
            if ((*addrconstr)->n>0)
              dispstackvalspec(*addrconstr,(void (*) (void **)) dispscalar);
        } else
        {
          if ( (*addrconstr)==NULL )
            *addrconstr=newstackrn(1,nconstr);
          else if ( (*addrconstr)->n!=nconstr )
            resizestack(addrconstr,0,nconstr,(void (*) (void **)) dispscalar);
          st=*addrconstr;
          for (i=1;i<=nconstr;++i)
            if (st->s[i]==NULL)
              st->s[i]=malloc(sizeof(**addrobj));
        }
      }
    }
  if (calcgradobj!=NULL)
    if (*calcgradobj)
    {
      if (addrgradobj==NULL && nobj>0)
      {
        ret=-13;
        *calcgradobj=0;
        errfunc0("prepanfuncbas");
        if (funcname!=NULL || filename!=NULL)
          sprintf(ers(),">>  In  function \"%s\", file \"%s\", line %i:\n",funcname,filename,fileline);
        sprintf(ers(),"Address of storage for the objective function gradient has not been provided.\n");
        errfunc2();
      } else 
      {
        if (nobj<=0)
        {
          *calcgradobj=0;
          if (addrgradobj!=NULL) if (*addrgradobj!=NULL)
          {
            dispvector(addrgradobj);
          }
        } else
        {
          if (nobj>1)
          {
            warnfunc1(1,"prepanfuncbas");
            sprintf(ers(),"Number of objective functions (%i) is greater than 1.\n",nobj);
            sprintf(ers(),"This function is not intended for cases wit multiple objectives.\n");
            warnfunc2();
          }
          if (*addrgradobj==NULL)
            *addrgradobj=getvector(nparam);
          else if ((*addrgradobj)->d!=nparam)
            resizevector(addrgradobj,nparam);
        }
      }
    }

  if (calcgradconstr!=NULL)
    if (*calcgradconstr)
    {
      if (addrgradconstr==NULL)
      {
        ret=-14;
        *calcgradconstr=0;
        errfunc0("prepanfuncbas");
        if (funcname!=NULL || filename!=NULL)
          sprintf(ers(),">>  In  function \"%s\", file \"%s\", line %i:\n",funcname,filename,fileline);
        sprintf(ers(),"Address of storage for the constraint function gradients has not been provided.\n");
        errfunc2();
      } else
      {
        if (nconstr<=0 || nparam<=0)
        {
          *calcgradconstr=0;   /* problem has no constraints, or there are no parameters */
          if (*addrgradconstr!=NULL)
            if ((*addrgradconstr)->n>0)
              dispstackvalspec(*addrgradconstr,(void (*) (void **)) dispvector);
        } else
        {
          if ( (*addrgradconstr)==NULL )
            *addrgradconstr=newstackrn(1,nconstr);
          else if ( (*addrgradconstr)->n!=nconstr )
            resizestack(addrgradconstr,0,nconstr,(void (*) (void **)) dispvector);
          st=*addrgradconstr;
          for (i=1;i<=nconstr;++i)
          {
            if (st->s[i]==NULL)
              st->s[i]=getvector(nparam);
            else if ( ((vector) st->s[i])->d!=nparam)
              resizevector((vector *) &(st->s[i]), nparam);
          }
        }
      }
    }
}
return ret;
}



int getanfuncinfo(vector param,analysis_bas_f anfunc,void *cd,
        int *nparam,int *nobj,int *nconstr,int *derobj,int *derconstr )
    /* Returns the basic data for the optimization problem defined by analysis
    function anfunc, data cd and with parameters param (which can be NULL for
    problems with fixed number of parameters or number of parameters defined
    by definition data cd).
      Function returns 0 if everything is OK or a negative number in the case 
      of an error. Number of parameters, objectives or constraints is written
    to *nparam, *nobj and *nconstr if the corresponding pointers are not NULL.
    If something can not be determined then -1 is written to the appropriate 
    place. Whether the function can calculate objective and constraint 
    gratients is written to *gradobj and *gradconstr (1 if it can, 0 if not),
    if these pointers are not NULL.
      Uniform gradient availability for objectives and constraints:
      If the pointers derobj and derconstr are the same then the data pointed
    to by these pointers will be set to 1 only if both gradient of the 
    objective function (if defined) and gradients of the constraint functions
    (if defined) can be calculated. In this case, if either objective or 
    constraint functions are not defined in the problem then non-ability of
    providing the correspoinding gradient will not cause to set the flag
    pointed to by both pointers to 0.
      Analysis function must support info mode for this function to work.
      Return codes:
      0  - everything seems to be OK
      -1 - analysis function does not support info mode
      -2 - dimension of param does not match a fixed dimension of the problem
    or dimension determined by problem data cd.
      -3 - number of parameters could not be determined (typically in case
    when param is NULL and problem is defined for variable number of 
    parameters, which can not be determined just form cd. 
    $A Igor apr05; */
{
int calcobj=0,calcconstr=0,calcgradobj=0,calcgradconstr=0,
    ret=0,retan, numparam,numobj,numconstr,cderobj,cderconstr, 
    dimpar=0,dimparorig=0;
double *obj=NULL;
vector gradobj=NULL,par=NULL,v=NULL;
stack constr=NULL,gradconstr=NULL;
/*
*/
/* prepare result storage where pointers are NULL: */
if (nparam==NULL)  nparam=&numparam;
if (nobj==NULL)  nobj=&numobj;
if (nconstr==NULL)  nconstr=&numconstr;
if (derobj==NULL)  derobj=&cderobj;
if (derconstr==NULL)  derconstr=&cderconstr;
*nparam=*nobj=*nconstr=*derobj=*derconstr=0;
if (param!=NULL)
  dimparorig=param->d;
retan=anfunc(param,  NULL,&obj,  NULL,&constr,
       NULL,&gradobj,NULL,&gradconstr,  cd);
if (obj!=NULL || constr!=NULL || gradobj!=NULL || gradconstr!=NULL )
{
  /* We obtained response, it seems that analysis function supports info mode: */
  /* Check if dimension of parameter vector matches suggested dimension: */
  if (gradobj!=NULL)
    dimpar=gradobj->d;
  else if (gradconstr!=NULL)
  {
    if (gradconstr->n>0) if ((v=gradconstr->s[1])!=NULL)
      dimpar=v->d;
    v=NULL;
  } else
    dimpar=dimparorig;
  if (dimpar>0 && dimparorig>0 && dimpar!=dimparorig)
    ret=-2;  /* dimension of provided vector param does not match */
  if (dimpar!=dimparorig)
  {
    /* Either parameter vector was not provided or its dimension is wrong,
    we run another analysis wirh parameter vector of right dimensions; this
    is because previous function call might have allocated gradobj or 
    gradconstr just to inform about the number of parameters, even if the 
    function is actually not able to calculate gradients: */
    if (dimpar>0)
    {
      disppointer(&obj); dispvector(&gradobj);
      dispstackall(&constr);
      dispstackallspec(&gradconstr,(void (*) (void **)) dispvector);
      par=getvector(dimpar);
      retan=anfunc(par,  NULL,&obj,  NULL,&constr,
       NULL,&gradobj,NULL,&gradconstr,  cd);
    }
  }
  if (dimpar<=0 && dimparorig>0)
    dimpar=dimparorig;
  if (dimpar<=0)
    ret=-3;   /* could not determine the number of parameters */
  *nparam=dimpar;
  if (obj!=NULL)
    *nobj=1;
  if (constr!=NULL)
    *nconstr=constr->n;
  else if (gradconstr!=NULL)
    *nconstr=gradconstr->n;
  if (derconstr!=derobj)
  {
    if (*nobj>0 && gradobj!=NULL)
        *derobj=1;
    if (nconstr>0 && gradconstr!=NULL)
      *derconstr=1;
  } else
  {
    /* Pointers derobj and derconstr are the same, which means that the flag 
    they point to should be set to 1 only if both gradient of the objective 
    function (if objective is defined) and constraint functions (if 
    constraints are defined) can be calculated: */
    if ( (gradobj!=NULL || *nobj<1) && (gradconstr!=NULL || *nconstr<1) )
      *derobj=1;
  }
} else
{
  /* Info mode is not supported. */
  ret=-1;
  *nparam=dimparorig;
}
disppointer(&obj); dispvector(&gradobj);   dispvector(&par);
dispstackall(&constr);
dispstackallspec(&gradconstr,(void (*) (void **)) dispvector);
return ret;
}




void inspectanfunc(vector param,int nconstr,int allocate,
                   analysis_bas_f testanfunc,void *clientdata )
    /* Runs the function testanfunc with specification data clientdata at
    parameters param, and outputs the results. nconstr denotes the number of
    constraints while allocate specifies whether the storage should be allocated
    before calling testanfunc or not. The function requires calculation of
    everything, including the gradients.
      Numerical gradients are also compared to analytical (if provided), with 
    step for numerical differentiation 1.0e-6, and other arguments having
    default values.
    $A Igor apr05; */
{
inspectanfuncbas(param,nconstr,allocate,1e-6,0.,0.,testanfunc,clientdata );
}


void inspectanfuncbas(vector param,int nconstr,int allocate,
         double numgradstep, double reldiflimit, double smallnorm,
         analysis_bas_f testanfunc,void *clientdata )
    /* Runs the function testanfunc with specification data clientdata at
    parameters param, and outputs the results. nconstr denotes the number of
    constraints while allocate specifies whether the storage should be allocated
    before calling testanfunc or not. The function requires calculation of
    everything, including the gradients.
      If numgradstep!=NULL then numerical gradients will be calculated and
    compared to analytical gradients if these are provided. In this case,
    reldiflimit is the admissible limit of relative difference in naallytical
    and numerical gradients, and smallnorm is a small number whihc is added to
    the denominator of the expression for relative difference to avoid infinite
    values where gradients are close to zero. If reldiflimit is 0 then
    it is set to 0.005, and if smallnorm is 0 then it is set to 1e-15.
    $A Igor oct04 apr05; */
{
int nparam=0,i,is0=0,is1=1;
int calcobj=1,calcconstr=1,calcgradobj=1,calcgradconstr=1,
    retinfo,derobj,derconstr;
stack constr=NULL,gradconstr=NULL;
double *obj=NULL /* ,dptr=NULL */ ;
double t0,t1,ct0,ct1;
vector gradobj=NULL,vecptr=NULL;
struct _optalgcd cd={0};
if (param==NULL)
{
  warnfunc1(1,"inspectanfunc");
  sprintf(ers(),"Vector of parameters is NULL.\n");
  warnfunc2();
  nparam=0;
} else
  nparam=param->d;
if (testanfunc==NULL)
{
  errfunc0("inspectanfunc");
  sprintf(ers(),"The alalysis function is not specified.\n");
  errfunc2();
} else
{
  printf("\n====\nTesting an analysis function:\n");
  printf("Number of parameters: %i, number of constraints: %i.\n",nparam,nconstr);
  
  /* Try to get basic information about the analysis function: */
  retinfo=getanfuncinfo(param,testanfunc,clientdata,
      &(cd.nparam),&(cd.nobj),&(cd.nconstr),&derobj,&derconstr);
  if ( (derobj || cd.nobj<1) && (derconstr || cd.nconstr<1) )
    cd.nongrad=0;  /* derivatives are calculated */
  else
    cd.nongrad=1;
  if (retinfo==-1)
    printf("\nAnalysis function does not support info mode.\n\n");
  else
  {
    printf("\nAnalysis function in info mode provided the following results:\n");
    if (retinfo==-2)
      printf("Dimension of provided parameter vector (%i) is inconstist.\n",
              param==NULL?0:param->d);
    if (retinfo==3)
      printf("Number of parameters couold not be determined.\n");
    printf("Number of parameters: %i\n",cd.nparam);
    printf("Number of objective functions: %i\n",cd.nobj);
    printf("Number of constraint functions: %i\n",cd.nconstr);
    if (cd.nongrad)
      printf("Derivatives are NOT provided.\n");
    else
      printf("Derivatives are provided.\n");
    printf("\n");
  }

  if (allocate)
    printf("Output storage will be allocated as necessary.\n");
  else
    printf("Output storage will not be allocated or reallocated.\n");
  if (allocate)
  {
    if (calcobj)
    {
      if (obj==NULL)
        obj=calloc(1,sizeof(*obj));
    } else
      disppointer(&obj);
    
    if (calcgradobj)
    {
      resizevector(&gradobj,nparam);
    } else
      dispvector(&gradobj);
    
    if (calcconstr)
    {
      resizestack(&constr,0,nconstr,disppointer);
      if (constr!=NULL)
        for (i=1;i<=constr->n;++i)
        {
          if (constr->s[i]==NULL)
            constr->s[i]=calloc(1,sizeof(*obj));
        }
    }

    if (calcgradconstr)
    {
      resizestack(&gradconstr,0,nconstr,disppointer);
      if (gradconstr!=NULL)
        for (i=1;i<=gradconstr->n;++i)
        {
          resizevector((vector *) &(gradconstr->s[i]),nparam);
        }
    }
  }
  printf("----\nTest - all data requested:\n");
  printf("Running function...\n");
  t0=absolutetime();  ct0=cputime();
  testanfunc(param,&calcobj,&obj,&calcconstr,&constr,&calcgradobj,&gradobj,
      &calcgradconstr,&gradconstr,clientdata);
  t1=absolutetime();  ct1=cputime();
  printf("\n... finished in %g s (CPU time %g seconds).\n",t1-t0,ct1-ct0);
  printf("\n\nParameters (dim=%i):\n",param==NULL?0:param->d);
  printvectorlist(param);
  printf("\nCalculation flags:\n");
  printf("calcobj = %i, calcconstr = %i, calcgradobj = %i, calcgradconstr = %i\n",
      calcobj,calcconstr,calcgradobj,calcgradconstr);
  if (obj==NULL)
    printf("Objective function: NULL.\n");
  else
    printf("\n\nValue of the objective function: %g\n",*obj);
  printf("\nConstraint functions (num=%i):\n",
    constr==NULL?0:constr->n);
  printstacklistline(constr,fprintscalarlist);
  printf("\n");
  if (gradobj==NULL)
    printf("Gradient of the objective function is NULL.\n");
  else
  {
    printf("Gradient of the objective function (dim=%i):\n  ",
      gradobj==NULL?0:gradobj->d);
    printvectorlist(gradobj);
    printf("\n");
  }
  if (gradconstr==NULL)
    printf("Table of constraint gradients is NULL.\n");
  else if (gradconstr->n==0)
    printf("There are no constraint gradients.\n");
  else
  {
    int num=0,dim=0;
    num=gradconstr->n;
    if (num>0)
      dim=(((vector) gradconstr->s[1])->d);
    printf("Constraint gradients (num x dim = %ix%i):\n",num,dim);
    printstacklist(gradconstr,fprintvectorlist);
  }
  /*
  printf("\n----\nTest - no gradients requested:\n");
  printf("Running function...\n");
  t0=absolutetime();  ct0=cputime();
  testanfunc(param,&calcobj,&obj,&calcconstr,&constr,&calcgradobj,&gradobj,
      &calcgradconstr,&gradconstr,clientdata);
  t1=absolutetime();  ct1=cputime();
  printf("\n... finished in %g s (CPU time %g seconds).\n\n",t1-t0,ct1-ct0);
  */
  printf("\n----\nResults overview:\n");
  if (obj==NULL)
    printf("Objective function: NULL.\n");
  else
    printf("Objective function: value defined, %g.\n",*obj);
  if (constr==NULL)
    printf("Table of constraints: NULL.\n");
  else if (constr->n<1)
    printf("Length of the table of constraints: %i\n",constr->n);
  else
  {
    printf("Constraints defined (out of %i):\n  ",constr->n);
    for (i=1;i<=constr->n;++i)
      if (constr->s[i]!=NULL)
        printf("%i ",i);
    printf("\n");
  }
  if (gradobj==NULL)
    printf("Objective gradients is NULL.\n");
  else
    printf("Objective gradient: %i components.\n",gradobj->d);
  if (gradconstr==NULL)
    printf("Table of constraint gradients: NULL.\n");
  else if (gradconstr->n<1)
    printf("Length of the table of constraint gradients: %i\n",constr->n);
  else
  {
    printf("Dimensions of %i constraint gradients:\n  ",gradconstr->n);
    for (i=1;i<=gradconstr->n;++i)
    {
      vecptr=gradconstr->s[i];
      if (vecptr!=NULL)
      {
        printf("%i:%i ",i,vecptr->d);
      }
    }
    printf("\n");
  }
  if (numgradstep!=0)
  {
    analysis_bas_f numdifan=NULL;
    analysis_to_vecfunc_cd numdifcd=NULL;
    void (*dispnumdifcd) (void **) =NULL;
    analysispoint pt=NULL;


    /* Numerical gradients should be calculated: */
    if (numgradstep<0)
      numgradstep=-numgradstep;
    printf("\n________\nCalculation of numerical gradients, using step %g.\n",
        numgradstep);
    /* Prepare data for numerical gradient evaluation, analysis point first: */
    pt=newanalysispoint();
    copyvector(param,&(pt->param));
    pt->calcobj=pt->calcconstr=pt->calcgradobj=pt->calcgradconstr=1;
    /* Data and parameters and function for numerical differentiation: */
    prepanfuncnumgrad(testanfunc,clientdata,NULL  /* dellocate elsewhere */,
        numgradstep,NULL,   0, 0, 0,
        &(numdifan), &(numdifcd), &(dispnumdifcd) );
    /* Perform analysis with numerical calculation of gradients: */
    numdifan(pt->param,&(pt->calcobj),&(pt->obj),&(pt->calcconstr),&(pt->constr),
        &(pt->calcgradobj),&(pt->gradobj),
        &(pt->calcgradconstr),&(pt->gradconstr),  numdifcd );
    /* Output: */
    printf("\nResults:\n");
    printanalysispoint(pt);
    printf("--\n");
    if (calcgradobj || calcgradconstr)
    {
      vector dif=NULL;
      double norman,normdif,reldif;
      if (reldiflimit<0)
        reldiflimit=-reldiflimit;
      if (smallnorm<0)
        smallnorm=-smallnorm;
      if (reldiflimit==0)
        reldiflimit=0.005;
      if (smallnorm==0)
        smallnorm=1.0e-15;
      /* Analytical gradients have also been provided, make comparison of
      analytical snd numerical gradients: */
      printf("\nComparison of analytical and numerical gradients:\n");
      printf("  step = %g, rel. limit = %g, small norm = %g):\n\n",
          numgradstep,reldiflimit,smallnorm);
      if (calcgradobj && pt->calcgradobj && gradobj!=NULL && 
          pt->gradobj!=NULL)
      {
        vectordif0(gradobj,pt->gradobj,&dif);
        norman=vecnorm(gradobj);  normdif=vecnorm(dif);
        reldif=normdif/(norman+smallnorm);
        printf("Objective function gradient:\n");
        printf("  Grad. norm: %.3g, dif. norm: %.3g\n",norman,normdif);
        printf("                   Relative difference: %.3g\n",reldif);
        if (reldif>reldiflimit)
        {
          printf("\nObjective function gradient NOT ACCURATE.\n\n");
        }
      } else
        printf("Gradients of objective function can not be compared.\n");
      if (calcgradconstr && pt->calcgradconstr && 
          gradconstr!=NULL && pt->gradconstr!=NULL)
      {
        printf("\n");
        for (i=1;i<=gradconstr->n;++i)
        {
          if (gradconstr->n>=i && pt->gradconstr->n>=i)
          {
            vectordif0(gradconstr->s[i],pt->gradconstr->s[i],&dif);
            norman=vecnorm(gradconstr->s[i]);  normdif=vecnorm(dif);
            reldif=normdif/(norman+smallnorm);
            printf("Gradient of constraint %i:\n",i);
            printf("  Grad. norm: %.3g, dif. norm: %.3g\n",norman,normdif);
            printf("                   Relative difference: %.3g\n",reldif);
            if (reldif>reldiflimit)
            {
              printf("\n      Gradient of constraint %i NOT ACCURATE!\n\n",i);
            }
          } else
          {
            printf("Numerical gradient of constraint %i not defined.\n");
          }
        }
      } else
        printf("Numerical or / and analytical constraint gradients not defined.\n");
      printf("\n");

      dispvector(&dif);
    }

    if (numdifcd!=NULL && dispnumdifcd!=NULL)
      dispnumdifcd(&numdifcd);
    dispanalysispoint(&pt);
  }
  printf("====\n\n");
}
if (1)  /* Speed test */
{
  double ct0,ct1,ctlim=0.1 /* limit for CPU time */,nrep=1.0;
  int i,num=0;
  printf("\n\nSpeed test:\n");
  printf("Running analyses, CPU time limit is %g seconds...\n",ctlim);
  ct0=ct1=cputime();
  while(ct1-ct0<ctlim)
  {
    for (i=1;i<=nrep;++i)
    {
      testanfunc(param,&calcobj,&obj,&calcconstr,&constr,&calcgradobj,&gradobj,
          &calcgradconstr,&gradconstr,clientdata);
      ++num;
      if (num<200)
        printf(".");
    }
    printf(" nrep=%g ",nrep);
    ct1=cputime();
    if ((ct1-ct0)/ctlim <0.01)
      nrep=1.01*(double) num / 0.01;
    else if ((ct1-ct0)/ctlim <0.04) 
      nrep=1.01*(double) num / 0.04;
    else if ((ct1-ct0)/ctlim <0.1) 
      nrep=1.01*(double) num / 0.1;
    else if ((ct1-ct0)/ctlim <0.4) 
      nrep=1.01*(double) num / 0.4;
    else if ((ct1-ct0)/ctlim <0.8) 
      nrep=1.01*(double) num / 0.8;
    else if ((ct1-ct0)/ctlim <0.95) 
      nrep=1.01*(double) num / 0.95;
    else if ((ct1-ct0)/ctlim <0.99) 
      nrep=1.01*(double) num / 0.99;
    else if ((ct1-ct0)<ctlim) 
      nrep=1.01*(double) num / 1.0;
  }
  printf("\n\n%i analyses run in %g s of CPU time.\n",num,ct1-ct0);
  printf("                Time for one analysis:   %g\n",(ct1-ct0)/(double) num);
  printf("                No. analyses per second: %g\n\n",(double) num / ((ct1-ct0)));
}
/* Deallocation: */
disppointer(&obj);
dispvector(&gradobj);
dispstackallspec(&constr,disppointer);
dispstackallspec(&gradconstr,(void (*) (void **)) dispvector);
}








/* THIS CODE SHOULD BE USED LATER FOR DEFINITION OF THE SAFE WRAPPING
ANALYSIS FUNCTION: */

void safeanfunc(vector param,int nconstr,int allocate,
            int testanfunc(vector param,int *calcobj,double *addrobj,
            int *calcconstr,stack *addrconstr,
            int *calcgradobj,vector *addrgradobj,
            int *calcgradconstr,stack *addrgradconstr,void *clientdata) ,
            void *clientdata)
    /* Runs the function testanfunc with specification data clientdata at
    parameters param, and outputs the results. nconstr denotes the number of
    constraints while allocate specifies whether the storage should be allocated
    in before calling testanfunc or not. The function requires calculation of
    everything, including the gradients.
      Function is not thread safe since it uses static variables for function
    arguments.
    $A Igor oct04; */
{
int nparam=0;
int calcobj=1,calcconstr=1,calcgradobj=1,calcgradconstr=1;
static stack constr=NULL,gradconstr=NULL;
if (param==NULL)
{
  warnfunc1(1,"safeanfunc");
  sprintf(ers(),"Vector of parameters is NULL.\n");
  warnfunc2();
  nparam=0;
} else
  nparam=param->d;
if (testanfunc==NULL)
{
  errfunc0("safeanfunc");
  sprintf(ers(),"The alalysis function is not specified.\n");
  errfunc2();
} 
#if 0
else if (addrobj==NULL || addrgradobj==NULL || 
           (nconstr>0 && (addrconstr==NULL || addrgradconstr==NULL)) )
{
  /* Some addresses for storing output data are NULL */
  errfunc0("safeanfunc");
  sprintf(ers(),"The references to following output data are not specified:\n");
  if (addrobj==NULL)
    sprintf(ers(),"addrobj");
  if (addrgradobj==NULL)
    sprintf(ers(),"addrgradobj");
  if (addrconstr==NULL)
    sprintf(ers(),"addrconstr");
  if (addrgradconstr==NULL)
    sprintf(ers(),"addrgradconstr");
  sprintf(ers(),"\n");
  erfunc2();
} else
{
  if (allocate)
  {
    if (*calcobj)
    {
      if (*addrobj==NULL)
        *addrobj=calloc(1,sizeof(**addrobj));
    } else
      disppointer(addrobj);

    if (nconstr<1 && allocate)
    {
      dispstackvalspec(addrconstr,disppointer);
      dispstackvalspec(addrgradconstr,dispvector);
    } else if (allocate)
    {
      reallocstack(addrconstr,0,n,nconstr,dispvector);
      reallocstack(addrgradconstr,0,n,nconstr,dispvector);
      constr=*addrconstr;
      gradconstr=*addrgradconstr;
      for (i=1;i<=nconstr;++i)
      {
        if (constr->s[i]==NULL)
          constr->s[i]=calloc(1,sizeof(*scalar));
        resizevector(&(gradconstr->s[i]),nparam);
      }
    }

  }
}
#endif 
}




    /* SOME FUNCTIONS OF TYPE analysis_bas_f: */


  /* SIMPLE TEST FUNCTIONS: */


int testanfunc(vector param,int *calcobj,double **addrobj,
            int *calcconstr,stack *addrconstr,
            int *calcgradobj,vector *addrgradobj,
            int *calcgradconstr,stack *addrgradconstr,void *clientdata)
    /* Function of type analysis_bas_f .
       This is a test analysis function for calculating objective functions,
    constraints, and and their gradients. Its declaration takes the standard
    form for this module.
      Arguments *calcobj, *calcconstr, *calcgradobj and *calcgradconstr must 
    address valid non-constant storage of type int (either allocated, static
    or on stack), and tell the function whether to calculate the objective
    function, the constraint functions, and their gradients, respectively (0
    for yes, 1 for no). The function may change these values with respect to
    whether it was capable to do the job (standard values: 0 - values were not
    calculated, 1 - values were calculated, -1 - values were provided, but they
    are incorrect. Therefore, if the callling function check the status
    returned via these arguments, it should treat the calculated values as
    valid only if these arguments point to values greater than zero.
      addrobj, addrconstr, addrgradobj and addrgradconstr are output arguments 
    that provide the calculated values. addrobj must be an address of a pointer
    to a dynamically allocated double (that pointer may be NULL, though, in 
    which case the function takes responsibility of allocating it if necessary)
    and addrgradobj is an address of a pointer of type vector (definition in
    vec.h). The others two are addresses of pointers of type stack (see st.c
    for definition). *addrconstr contains pointers to dynamically allocated
    doubles, and *addrgradconstr contains pointers of type vector.
      Rules about ALLOCATION OF OUTPUT ARGUMENTS are as follows: 
      A strict rule is that any pointers to allocated memory contained in these
    arguments must be the same handles of allocated memory as are used for
    deallocation by the caller. It is however strongly recommended that the
    caller allocates all potentially necessary storage, in which case the
    function will not need to do any allocation (this also helps to avoid
    problems when function is not written in such a way that it checks the
    storage alone). The last strict rule is that the function does not do any
    reallocation or allocation if this is not necessary.
      There are additional rules that should normally (but not necessarily) be
    followed. These rules are recommended to be followed by the designers of the
    called functions when this is not considered computationally inefficient or
    too demanding for coding, but may be relied on by writers of the calling 
    code only on individual basis. These rules are as follows:
      If something is not allocated properly (wrong dimensions or not allocated
    at all) then the function should allocate or reallocate this correctly. If
    something is allocated, but the function does not calculate that thing at 
    some particular call (while at subsequent calls it still might calculate
    that) then it does not make any deallocation, allocation or reallocation
    (thus saving time). Therefore, the caller may not conclude by the status of output
    arguments whether somethihng was calculated, or not, but must examine the
    value of the flags *calcobj, *clacconstr etc. after the call.
      Standards regarding the optimization problem:
    Optimization problem is stated as arg min f(x), subject to g_i(x)==0
    and g_j(x)<=0.

      This particular function is set up for the problem
    min f(x,y)=( sin( sqrt(A*(x-CX)^2+B*(y-CY)^2) ) )^2,
    subject to x>=TX+y^2 and y>=TY,
    where A=0.1, B=0.005, CX=0.2, CY=-1, TX=0.6, and TY=1.
    Constraint functions are therefore
    g_1(x,y)=TX+y*y-x, g_2(x,y)=TY-y.
    The solution is x=1.6, y=1.
      This function does not need clientdata. If clientdata is different than
    NULL then it is assumed of type optalgcd and basic information is stored
    on it.
    $A Igor oct04; */
{
double x,y,*dptr;
stack st;
vector v;
int npar=2,nconstr=2,i,ret=0;
double A=0.1, B=0.005, CX=0.2, CY=-1, TX=0.6, TY=1,
       fr,ff,fder;
if (! (ret=prepanfuncbas(param,calcobj,addrobj,
          calcconstr,addrconstr,
          calcgradobj,addrgradobj,
          calcgradconstr,addrgradconstr,clientdata ,
          2, /* number of parameters */
          1, /* number of objective func. */
          2, /* number of constraints */
          1,1,  /* can calc. grad. of objectives / constraints */
          "testanfunc",__FILE__,__LINE__))  )
{
  if (clientdata!=NULL)
  {
    /* Definition data is not necessary for this problem, launch a warning 
    when the pointer is non-NULL: */
    warnfunc1(1,"testanfunc");
    sprintf(ers(),"The client data is not necessary for this function, ignored.\n");
    sprintf(ers(),"This argument could be NULL for this function.\n");
    warnfunc2();
  }
  /* Store the two parameters */
  x=param->v[1];
  y=param->v[2];
  /* Auxiliary functions: */
  fr=sqrt(A*(x-CX)*(x-CX)+B*(y-CY)*(y-CY));
  ff=sin(fr); ff=ff*ff;  /* ff=sin(fr)^2 */
  if (calcobj!=NULL) if (*calcobj)
    **addrobj=ff;  /* Objective function */
  if (calcconstr!=NULL)
  {
    st=*addrconstr;
    for (i=1;i<=nconstr;++i)
    {
      dptr=st->s[i];
      if (i==1)
      {
        *dptr=TX+y*y-x;  /* The first constraint function */
      } else if (i==2)
      {
        *dptr=TY-y;  /* The second constraint function */
      }
    }
  }
  if (calcgradobj!=NULL)
    if (*calcgradobj)
    {
      v=*addrgradobj;
      /* Explicit calculation of objective gradient: */
      /* Replace  for limit when fr approaches zero */
      if (fr<1e-8)
      {
        /* Replace sin(fr)/fr with limit value 1 when fr approaches zero: */
        fder=2*cos(fr);
      } else
        fder=2*cos(fr)*(sin(fr)/fr);
      v->v[1]=fder /* *2 */ *A*(x-CX);
      v->v[2]=fder /* *2 */ *B*(y-CY);
    }
  if (calcgradconstr!=NULL)
    if (*calcgradconstr)
    {
        st=*addrgradconstr;
      /* After the stack holding constraint gradients has been prepared, take
      care of each gradient vector on the stack: */
      for (i=1;i<=st->n;++i)
      {
        v=st->s[i];
        if (i==1)
        {
          v->v[1]=-1;      /* 1. comp. of gradient, 1. constraint */
          v->v[2]=2*y;     /* 2. comp. of gradient, 1. constraint */
        } else if (i==2)
        {
          v->v[1]=0;       /* 1. comp. of gradient, 2. constraint */
          v->v[2]=-1;      /* 2. comp. of gradient, 2. constraint */
        }
      }
    }
}
return ret;
}








int testanfunc1(vector param,int *calcobj,double **addrobj,
          int *calcconstr,stack *addrconstr,
          int *calcgradobj,vector *addrgradobj,
          int *calcgradconstr,stack *addrgradconstr,void *clientdata)
  /* Function of type analysis_bas_f .
     This is a test analysis function. Similar to testanfunc1(), 2 parameters
  and 2 constrint, but with different definition.
    This particular function is set up for the problem
  min f(x,y)=x^2+y^4, subject to y>=(x-3)^6 and y>=17-x^2, 
  therefore f(x,y)=x^2+y^4, g_1(x,y)=(x-3)^6-y, g_2(x,y)=17-x^2-y.
  Optimum: {4,1}, objective func. in optimum: 17.
  $A Igor oct04; */
{
double x,y,*dptr;
stack st;
vector v;
int npar=2,nobj=1,nconstr=2,i,ret;

if (! (ret=prepanfuncbas(param,calcobj,addrobj,
        calcconstr,addrconstr,
        calcgradobj,addrgradobj,
        calcgradconstr,addrgradconstr,clientdata ,
        npar, /* number of parameters */
        nobj, /* number of objective func. */
        nconstr, /* number of constraints */
        1,1,  /* can calc. grad. of objectives / constraints */
        "testanfunc1",__FILE__,__LINE__))  )
{
  if (clientdata!=NULL)
  {
    warnfunc1(1,"testanfunc1");
    sprintf(ers(),"The client data is not necessary for this function, ignored.\n");
    sprintf(ers(),"This argument could be NULL for this function.\n");
    warnfunc2();
  }
  /* Store the two parameters */
  x=param->v[1];
  y=param->v[2];
  if (calcobj!=NULL)
    if (*calcobj)
      **addrobj=x*x+y*y*y*y;  /* Objective function */
  if (calcconstr!=NULL) 
    if (*calcconstr)
    {
      st=*addrconstr;
      for (i=1;i<=st->n;++i)
      {
        dptr=st->s[i];
        if (i==1)
        {
          *dptr=(x-3)*(x-3)*(x-3)*(x-3)*(x-3)*(x-3)-y;  /* The first constraint function */
        } else if (i==2)
        {
          *dptr=17-x*x-y;  /* The second constraint function */
        }
      }
    }
  if (calcgradobj!=NULL)
    if (*calcgradobj)
    {
      v=*addrgradobj;
      v->v[1]=2*x;
      v->v[2]=4*y*y*y;
    }
  if (calcgradconstr!=NULL)
    if (*calcgradconstr)
    {
      st=*addrgradconstr;
      /* After the stack holding constraint gradients has been prepared, take
      care of each gradient vector on the stack: */
      for (i=1;i<=st->n;++i)
      {
        v=st->s[i];
        if (i==1)
        {
          v->v[1]=6*(x-3)*(x-3)*(x-3)*(x-3)*(x-3);   /* 1. comp. of gradient, 
            1. constraint */
          v->v[2]=-1;         /* 2. comp. of gradient, 1. constraint */
        } else if (i==2)
        {
          v->v[1]=-2*x;       /* 1. comp. of gradient, 2. constraint */
          v->v[2]=-1;         /* 2. comp. of gradient, 2. constraint */
        }
      }
    }
}
return ret;
}







          /******************************/
          /*                            */
          /*  OPTIMIZATION USING FSQP:  */
          /*                            */
          /******************************/


static int fsqp_numan=0,fsqp_prn=0;


/*
typedef struct _clientdatacfsqp {
  int flags;
} *clientdatacfsqp;
*/


static double chi2vec(vector param)
    /* ...
    $A Igor oct04; */
{
errfunc0("chi2vec");
sprintf(ers(),"The analysis function chi2vec0 is not yet properly defined\n");
sprintf(ers(),"in the module optbas.c .\n");
errfunc2();
}


/* AUXILIARY FUNCTIONS FOR fi_optfsqp1() WITH AUXILIARY VARIABLES: */






static char checkparamfsqp1(int nparam,double *x,void *clientdata)
    /* Returns 1 if parameters in the table x correspond to the parameters in
    the vector clientdata->paramlast, otherwise it returns 0. nparam is the
    number of elements in the table x. clientdata specifies how the objective
    function is calculated and must be of type optalgcd.
    $A Igor oct04; */
{
char ret=0;
int i;
optalgcd cd=clientdata;
vector parvec=NULL;
if (clientdata!=NULL)
{
  cd=clientdata;
  parvec=cd->lastparam;  /* The last parameters from clientdata */
  if (parvec!=NULL)
    if (parvec->d==nparam)
    {
      ret=1;
      for (i=1;i<=nparam && ret; ++i)
        if (x[i-1]!=parvec->v[i])
          ret=0;
    }
}
return ret;
}


static void analysefsqp1(int nparam,double *x,void *clientdata)
    /* Runs direct analysis as specified by clientdata (must be of type optalgcd).
    Analysis is run at parameters that are stored in x (zero offset), nparam
    is the number of parameters.
    $A Igor sep98; */
{
char calculated=0;
int i;
optalgcd cd=clientdata;
vector parvec=NULL;
if (cd==NULL)
{
  errfunc0("analysefsqp1");
  sprintf(ers(),"Analysis specification data is NULL.\n");
  errfunc2();
}
calculated=checkparamfsqp1(nparam,x,clientdata);   /* Check if we have
           already run the analysis at particular values of parameters */
if (!calculated)
{
  /* Copy parameters: */
  if (cd->lastparam==NULL)
  {
    cd->lastparam=getvector(nparam);
  } else if (cd->lastparam->d!=nparam)
    resizevector(&(cd->lastparam),nparam);
  parvec=cd->lastparam;
  for (i=1;i<=nparam;++i)
    parvec->v[i]=x[i-1];
  /* Perform analysis: */
  if (cd->anfunc==NULL)
  {
    errfunc0("analysefsqp1");
    sprintf(ers(),"The analysis function is NULL.\n");
    errfunc2();
  } else
  {
    /* Specify that all results should be calculated: */
    ++fsqp_numan;
    if (fsqp_prn>0) printf("Analysis No. %i...",fsqp_numan);
    cd->calcobj=cd->calcconstr=cd->calcgradobj=cd->calcgradconstr=1;
    cd->anfunc(cd->lastparam,&(cd->calcobj),&(cd->obj),&(cd->calcconstr),
            &(cd->constr),&(cd->calcgradobj),&(cd->gradobj),
            &(cd->calcgradconstr),&(cd->gradconstr),cd->ancd);
    if (fsqp_prn>0) printf("  - done.\n");
  }
}
}

static void objfsqp1(int nparam,int j,double *x,double *fj,void *clientdata)
    /* Returns the value of the j-th objective function to the calling
    algorithm. If necessary, analysis is run by analysefsqp1. x contains
    parameter (zero offset) whose number is nparam. Objective function is
    stored in *fj. clientdata specifies how the function is calculated and
    must be of type optalgcd.
      Remark: This function works only for j=1 (a single objective function).

    Vrne vrednost j-te namenske funkcije za funkcijo fi_optfsqp1. Ce je
    potrebno, pred tem pozene direktno analizo (ce se ni bila izvedena pri
    danih parametrih). nparam je stevilo parametrov, v x so trenutne vrednosti
    parametrov, v *fj pa funkcija zapise vrednost j-tega parametra. Argument
    clientdata nima pomena (je le zaradi kompatimbilnosti).
    $A Igor jul98 sep98; */
{
optalgcd cd=clientdata;
static int reported=0;
*fj=infinity();
if (fsqp_prn>0) printf("objfsqp1...  ");
analysefsqp1(nparam,x,clientdata);
if (j!=1)
{
  errfunc0("objfsqp1");
  sprintf(ers(),"Invalid number of objective function (%i):\n",j);
  sprintf(ers(),"This system works only for a single objective function");
  errfunc2();
} else if (cd==NULL)
{
  errfunc0("objfsqp1");
  sprintf(ers(),"Analysis specification data is NULL.\n");
  errfunc2();
} else if (!cd->calcobj)
{
  if (!reported)
  {
    reported=1;
    errfunc0("objfsqp1");
    sprintf(ers(),"Objective functin was not calculated.\n");
    errfunc2();
  }
} else if (cd->obj==NULL)
{
  if (!reported)
  {
    reported=1;
    errfunc0("objfsqp1");
    sprintf(ers(),"Objective function data is NULL.\n");
    errfunc2();
  }
} else
  *fj=*(cd->obj);
if (fsqp_prn>0) printf("objfsqp1 done.\n");
}



static void constfsqp1(int nparam,int j,double *x,double *gj,void *clientdata)
    /* Returns the value of the j-th constraint function to the calling
    algorithm. If necessary, analysis is run by analysefsqp1. x contains
    parameter (zero offset) whose number is nparam. Constraint function is
    stored in *gj. clientdata specifies how the function is calculated and
    must be of type optalgcd.
      
        Vrne vrednost j-te omejitvene funkcije za funkcijo fi_optfsqp1. Ce je
    potrebno, pred tem pozene direktno analizo (ce se ni bila izvedena pri
    danih parametrih). nparam je stevilo parametrov, v x so trenutne vrednosti
    parametrov, v *gj pa funkcija zapise vrednost j-tega parametra. Argument
    clientdata nima pomena (je le zaradi kompatimbilnosti).
    $A Igor jul98 sep98; */
{
optalgcd cd=clientdata;
static int reported=0;
double *dptr;
if (fsqp_prn>0) printf("constfsqp1...  ");
*gj=infinity();
analysefsqp1(nparam,x,clientdata);
if (cd==NULL)
{
  errfunc0("constfsqp1");
  sprintf(ers(),"Analysis specification data is NULL.\n");
  errfunc2();
} else if (!cd->calcconstr)
{
  if (!reported)
  {
    reported=1;
    errfunc0("constfsqp1");
    sprintf(ers(),"Constraint functions were not calculated.\n");
    errfunc2();
  }
} else if (cd->constr==NULL)
{
  if (!reported)
  {
    reported=1;
    errfunc0("constfsqp1");
    sprintf(ers(),"Constraint function data is NULL.\n");
    errfunc2();
  }
} else if (j<1 || j>cd->constr->n)
{
  errfunc0("constfsqp1");
  sprintf(ers(),"Invalid number of the requested constraint function (%i):\n",j);
  sprintf(ers(),"Actual number of constraint functios is %i",cd->constr->n);
  errfunc2();
} else
{
  dptr=cd->constr->s[j];
  *gj=*dptr;
}
if (fsqp_prn>0) printf("constfsqp1 done.\n");
}

static void gradobjfsqp1(int nparam,int j,double *x,double *gradfj,
                         void (*dummy)(int,int,double *,double *,void *),void *clientdata)
    /* Returns the gradient of the j-th objective function to the calling
    algorithm. If necessary, analysis is run by analysefsqp1. x contains
    parameter (zero offset) whose number is nparam. The gradient is stored in
    *gradfj. clientdata specifies how the function is calculated and must be
    of type optalgcd.
      Remark: This function works only for j=1 (a single objective function).

    Vrne trenutne vrednosti komponent gradienta vrednost j-te namenske
    funkcije za funkcijo fi_optfsqp1. Ce je potrebno, pred tem pozene direktno
    analizo (ce se ni bila izvedena pri danih parametrih). nparam je stevilo
    parametrov, v x so trenutne vrednosti parametrov, v gradfj pa funkcija
    zapise komponente j-tega gradienta. Argument clientdata nima pomena (je le zaradi
    kompatimbilnosti), prav tako dummy.
    $A Igor jul98 sep98; */
{
int i;
optalgcd cd=clientdata;
static int reported=0;
vector grad=NULL;
if (fsqp_prn>0) printf("gradobjfsqp1...  ");
analysefsqp1(nparam,x,clientdata);
if (j!=1)
{
  errfunc0("gradobjfsqp1");
  sprintf(ers(),"Invalid number of objective function (%i):\n",j);
  sprintf(ers(),"This system works only for a single objective function");
  errfunc2();
} else if (cd==NULL)
{
  errfunc0("gradobjfsqp1");
  sprintf(ers(),"Analysis specification data is NULL.\n");
  errfunc2();
} else if (!cd->calcgradobj)
{
  if (!reported)
  {
    reported=1;
    errfunc0("gradobjfsqp1");
    sprintf(ers(),"Objective functin gradient was not calculated.\n");
    errfunc2();
  }
} else if (cd->gradobj==NULL)
{
  if (!reported)
  {
    reported=1;
    errfunc0("gradobjfsqp1");
    sprintf(ers(),"Objective function gradient data is NULL.\n");
    errfunc2();
  }
} else
{
  grad=cd->gradobj;
  if (grad->d!=nparam)
  {
    if (!reported)
    {
      reported=1;
      errfunc0("gradobjfsqp1");
      sprintf(ers(),"Incorrect dimension of calculated gradient (%i, should be %i).\n",
        grad->d,nparam);
      errfunc2();
    }
  } else 
  {
    for (i=1;i<=nparam;++i)   /* copy gradient components */
      gradfj[i-1]=grad->v[i];
  }
}
if (fsqp_prn>0) printf("gradobjfsqp1 done.\n");
}

static void gradconstfsqp1(int nparam,int j,double *x,double *gradgj,
             void (*dummy)(int,int,double *,double *,void *),void *clientdata)
    /*Returns the gradient of the j-th constraint function to the calling
    algorithm. If necessary, analysis is run by analysefsqp1. x contains
    parameter (zero offset) whose number is nparam. The gradient is stored in
    *gradfj. clientdata specifies how the function is calculated and must be
    of type optalgcd.

    Vrne trenutne vrednosti komponent gradienta j-te omejitvene funkcije za
    funkcijo fi_optfsqp1. Ce je potrebno, pred tem pozene direktno analizo (ce
    se ni bila izvedena pri danih parametrih). nparam je stevilo parametrov, v
    x so trenutne vrednosti parametrov, v gradgj pa funkcija zapise komponente
    j-tega gradienta. Argument clientdata nima pomena (je le zaradi kompatimbilnosti),
    prav tako dummy..
    $A Igor jul98 sep98; */
{
optalgcd cd=clientdata;
static int reported=0;
vector grad=NULL;
int i;
if (fsqp_prn>0) printf("gradconstfsqp1...  ");
analysefsqp1(nparam,x,clientdata);
if (cd==NULL)
{
  errfunc0("gradconstfsqp1");
  sprintf(ers(),"Analysis specification data is NULL.\n");
  errfunc2();
} else if (!cd->calcgradconstr)
{
  if (!reported)
  {
    reported=1;
    errfunc0("gradconstfsqp1");
    sprintf(ers(),"Constraint gradients were not calculated.\n");
    errfunc2();
  }
} else if (cd->gradconstr==NULL)
{
  if (!reported)
  {
    reported=1;
    errfunc0("gradconstfsqp1");
    sprintf(ers(),"Constraint gradient data is NULL.\n");
    errfunc2();
  }
} else if (j<1 || j>cd->gradconstr->n)
{
  errfunc0("gradconstfsqp1");
  sprintf(ers(),"Invalid number of the requested constraint function (%i):\n",j);
  sprintf(ers(),"Actual number of constraint functios is %i",cd->gradconstr->n);
  errfunc2();
} else
{
  grad=cd->gradconstr->s[j];
  if (grad->d!=nparam)
  {
    if (!reported)
    {
      reported=1;
      errfunc0("gradconstfsqp1");
      sprintf(ers(),"Incorrect dimension of calculated gradient (%i, should be %i).\n",
        grad->d,nparam);
      errfunc2();
    }
  } else 
  {
    for (i=1;i<=nparam;++i)   /* copy gradient components */
      gradgj[i-1]=grad->v[i];
  }
}
if (fsqp_prn>0) printf("gradconstfsqp1 done.\n");
}




int optfsqpbas0(int nf,int nconstr,int nconstreq,
                   int nconstrineqlin,int nconstreqlin,
             double eps, double epseqn,
             int miter,int gradients,double udelta,
             int monotone,
             vector param0,
             vector lowboundsin,vector upboundsin,
             int prn,FILE *outfile,

             /* Output parameters: */
             vector *paramopt,
             double ** objectiveopt,
             vector *constraintopt,
             /*
             vector *gradobjectiveopt,
             stack *constropt,
             stack *gradconstraintopt,
             */

             /* algorithm and analysis information: */
             optalgcd algclientdata,
             analysis_bas_f anfunc,void *clientdata)
{
errfunc0("optfsqpbas");
sprintf(ers(),"Not implemented yet.\n");
errfunc2();
return -1;
}

int optfsqpbas(int nf,int nconstr,int nconstreq,
                   int nconstrineqlin,int nconstreqlin,
             double eps, double epseqn,
             int miter,int gradients,double udelta,
             int monotone,
             vector param0,
             vector lowboundsin,vector upboundsin,
             int prn,FILE *outfile,

             /* Output parameters: */
             vector *paramopt,
             double ** objectiveopt,
             vector *constraintopt,
             /*
             vector *gradobjectiveopt,
             stack *constropt,
             stack *gradconstraintopt,
             */

             /* algorithm and analysis information: */
             optalgcd algclientdata,
             analysis_bas_f anfunc,void *clientdata)
    /*
      nf: number of objective functions
      nineqn: number of nonlinear inequality constraints
      nineql: number of linear inequality constraints
      neqn:   number of nonlinear equality constraints
      neql:   number of linear equality constraint
      eps     tolerance for Newton's direction
      epseqn  tolerance for breaking equality constraints in optimum
      miter   max. number of iterations (unlimited if less than 1)
      gradients: if 0 then gradients are not provided by analysis and will be
        calculated numerically. ??? change so that step is specified ???
      udelta: suggested step size for numerical differentiation.
      monotone: if 1 then monotone decrease of the objective function is
        required
      param0: initial guess
      lowboundsin: lower bounds on parameters
      upboundsin: upper bounds on parameters
      prn: printing level (0: no printing)
      outfile: output file (NULL for no file output)
    $A Igor ovt04; */
{
#ifdef CFSQP
int nineq,neq,nineqn,nineql,neqn,neql;
int ret=-1,nparam,place,i,allocbounds=0;
double bigbnd=DBL_MAX/5 /* 1.0e50 */, *dptr;
int ncsrl=0,ncsrn=0,nfsr=0,mesh_pts[1],  /* param. set in advance */
    mode=110,  /* subject to change! */
    iprint=prn, /* print level */
    inform;     /* output info - error mode */
optalgcd cd=NULL;

TRIN(16,1,"optfsqpbas","Beginning of optfsqpbas")

ncsrl=ncsrn=nfsr=mesh_pts[0]=0;

if (monotone)
  mode-=10;

nineq=nconstr-nconstreq;
nineqn=(nconstr-nconstreq)-nconstrineqlin;
nineql=nconstrineqlin;
neq=nconstreq;
neqn=nconstreq-nconstreqlin;
neql=nconstreqlin;
if (nf!=1)
{
  errfunc0("optfsqpbas");
  sprintf(ers(),"The number of objective functions should be 1, called with %i\n",nf);
  errfunc2();   return ret;
} else if (param0==NULL)
{
  errfunc0("optfsqpbas");
  sprintf(ers(),"Initial guess is not specified\n",nf);
  errfunc2();   return ret;
} else if ((nparam=param0->d)<1)
{
  errfunc0("optfsqpbas");
  sprintf(ers(),"Number of parameters (%i) is less than 1.\n",nparam);
  errfunc2();   return ret;
} else if (anfunc==NULL)
{
  errfunc0("optfsqpbas");
  sprintf(ers(),"analysis function is not specidied\n",nf);
  errfunc2();   return ret;
} else
{
  if (algclientdata==NULL)
  {
    cd=newoptalgcd();
    cd->anfunc=anfunc;
    cd->ancd=clientdata;
  } else
  {
    cd=algclientdata;  /* Algorithm data structers provided by the caller */
    cd->anfunc=anfunc;
    cd->ancd=clientdata;
  }
  if (eps<=0) eps=1.0e-8;  if (epseqn<=0) epseqn=1.0e-8;
  if (miter<1)
  {
    miter=100;
    if (miter<5*nparam)
      miter=5*nparam;
  }
  if (miter<nparam)
  {
    warnfunc1(3,"optfsqpbas");
    sprintf(ers(),"The maximal number of iterations %i is smaller than the number of parameters (%i).\n",
      miter,nparam);
    warnfunc2();
  }
  nineq=nineqn+nineql;
  neq=neqn+neql;
  /* Write basic data about optimization problem to cd: */
  if (clientdata==NULL)
  {
    cd->nparam=nparam;
    cd->nobj=nf;
    cd->nconstr=nineqn+nineql+neqn+neql;
    cd->nconstreq=neq;
    cd->nconstreqlin=neql;
    cd->nconstrineqlin=nineql;
  }
  /* Vectors of lower and upper parameter bounds are first initialized in
  such a way that all components are equal to -bigbnd or +bigbnd,
  respectively (for the algorithm this means that parameters are not
  bound). Input arguments lowbounds and upbounds are then checked in order
  to set those bounds that are set by the caller: */
  
  if (1)
  {
    resizevector(&cd->lowbounds,nparam);
    resizevector(&cd->upbounds,nparam);
    for (i=1;i<=nparam;++i)
    {
      cd->lowbounds->v[i]=-bigbnd; cd->upbounds->v[i]=bigbnd;
      if (lowboundsin!=NULL) if (lowboundsin->d>=i)
      {
        /* Lower bound i was specified by the user: */
        cd->lowbounds->v[i]=lowboundsin->v[i];
        if (upboundsin!=NULL)
          if (upboundsin->d>=i)  /* Both bounds specified */
          {
            /* Check if the lower is greater or equal than the uppper, which
            means omission of the particular bound: */
            if (lowboundsin->v[i]>=upboundsin->v[i])
              cd->lowbounds->v[i]=-bigbnd;
          }
      }
      if (upboundsin!=NULL) if (upboundsin->d>=i)
      {
        /* Upper bound i was specified by the user: */
        cd->upbounds->v[i]=upboundsin->v[i];
        if (lowboundsin!=NULL)
          if (lowboundsin->d>=i)  /* Both bounds specified */
          {
            /* Check if the lower is greater or equal than the uppper, which
            means omission of the particular bound: */
            if (lowboundsin->v[i]>=upboundsin->v[i])
              cd->upbounds->v[i]=bigbnd;
          }
      }

      /* Check for "infinity" overflow: */
      if (cd->lowbounds->v[i]<-bigbnd)  cd->lowbounds->v[i]=-bigbnd;
      if (cd->upbounds->v[i]>bigbnd)  cd->upbounds->v[i]=bigbnd;
    }
  }

  /* allocation of data for algorithm: */
  
  TRPT(16,6,"optfsqpbas","Before allocation of algorithm arguments")
  
#if 1   /* these will be allocated out of the algorithm, don't do allocation
           and deallocation here. */
  if (1)   /* $$$ */
  {
    disppointer(&(cd->bl));
    disppointer(&(cd->bu));
    disppointer(&(cd->x));
    disppointer(&(cd->f));
    disppointer(&(cd->g));
    disppointer(&(cd->lambda));
  
    copyvectortotable(cd->lowbounds,&(cd->bl),NULL);
    copyvectortotable(cd->upbounds,&(cd->bu),NULL);
    copyvectortotable(param0,&(cd->x),NULL);
    cd->f=(double *)calloc(nf,sizeof(double));
    cd->g=(double *)calloc(nineq+neq,sizeof(double));
    cd->lambda=(double *) calloc(cd->nconstr+cd->nobj+cd->nparam,sizeof(double));
  }
#endif

  TRPT(16,8,"optfsqpbas","After allocation, before printing of basic data")
  

  if (prn>0)
  {
    printf("\n\nOptimizing using the FSQP algorithm (\"optfsqpbas\"):\n\n");
    printf("Number of objectives: %i.\n",nf);
    printf("Number of nonlinear inequality constraints: %i.\n",nineqn);
    printf("Number of linear inequality constraints: %i.\n",nineql);
    printf("Number of nonlinear equality constraints: %i.\n",neqn);
    printf("Number of linear equality constraints: %i.\n",neql);
    printf("Total number of constraints (except bound constraints):\n",cd->nconstr);
    printf("Final norm requirement for Newton direction: %g.\n",eps);
    printf("Maximum violtion of nonlinear equality constraints: %g.\n",epseqn);
    printf("Maximum allowed number of iterations: %i\n", miter);
    printf("Initial guess:\n");
    printvector(param0);
    place=0;
    if (cd->lowbounds!=NULL && cd->upbounds!=NULL)
      if (cd->lowbounds->d>0 && cd->upbounds->d==cd->lowbounds->d)
      {
        printf("Parameter bounds:\n");
        for (i=1;i<=cd->lowbounds->d;++i)
        {
          if (cd->lowbounds->v[i]>-bigbnd || cd->upbounds->v[i]<bigbnd)
          {
            place=1;
            if (cd->lowbounds->v[i]>-bigbnd)
            {
              printf("  %10.8g  <=  x",cd->lowbounds->v[i]);
              if (cd->upbounds->v[i]<bigbnd)
                printf("  <=  %-10.8g\n",cd->upbounds->v[i]);
              else
                printf("\n");
            } else if (cd->upbounds->v[i]<-bigbnd)
            {
              printf("  x  <=  %-10.8g \n",cd->upbounds->v[i]);
            }
          }
        }
      }
    if (!place)
      printf("  No bounds specified.\n");
    printf("=================Output from algorithm:\n");
  }
  setcfsqpout(NULL);
  /* Perform the algorithm: */

#if 1

  TRIN(16,88,"optfsqpbas","Check of tracing operation")
  TRPT(16,88,"optfsqpbas","Check - first point")
  TRPT(16,88,"optfsqpbas","Check - second point")
  TROUT(16,88,"optfsqpbas","Check of tracing operation")

  TRIN(16,10,"optfsqpbas","Before running the algorithm")
  
  fsqp_numan=0;  /* Reset analysis counter */
  
  if (gradients)
  {

    
    for (i=1;i<=0;++i)
    {
      int k=0;
      
      /*
      printf("\n\n\n\nIn optfsqpbas: calling cfsqp, repetion %i:\n\n\n",i);
      printf("nparam: %i, nobj: %i, nconstr: %i.\n\n\n",
        cd->nparam,cd->nobj,cd->nconstr);
      printf("x={");
      for (k=1;k<=cd->nparam;++k)
      {
        printf("%g",cd->x[k-1]);
        if (k<cd->nparam) printf(", "); else printf("}\n\n\n\n");
      }
      */
      

      /*
      cd->bl=calloc(10+cd->nparam,sizeof(double));
      cd->bu=calloc(10+cd->nparam,sizeof(double));
      for (k=1;k<=cd->nparam;++k)
      {
        cd->bl[k-1]=-bigbnd;
        cd->bu[k-1]=bigbnd;
      }
      cd->x=calloc(10+cd->nparam,sizeof(double));

      cd->f=calloc(10+cd->nobj,sizeof(double));
      cd->g=calloc(10+cd->nconstr,sizeof(double));
      cd->lambda=calloc(10+cd->nconstr+cd->nparam,sizeof(double));
      
      for (k=1;k<=cd->nparam;++k)
        cd->x[k-1]=param0->v[k];

      */

      /*
      cd->lastparam=getvector(cd->nparam);
      cd->obj=calloc(10,sizeof(double));
      cd->gradobj=getvector(cd->nparam);
      cd->constr=newstack(cd->nconstr);
      for (k=1;k<=cd->nconstr;++k)
        pushstack(cd->constr,calloc(10,sizeof(double)));
      cd->gradconstr=newstack(cd->nconstr);
      for (k=1;k<=cd->nconstr;++k)
        pushstack(cd->gradconstr,getvector(cd->nparam));
      */
       
      /*
      printf("\n\n\n\nIn optfsqpbas, after repetion %i, %i analyses:\n",i,fsqp_numan);
      printf("x={");
      for (k=1;k<=cd->nparam;++k)
      {
        printf("%g",cd->x[k-1]);
        if (k<cd->nparam) printf(", "); else printf("}\n\n\n\n");
      }
      */
      

    }

    ext_cfsqp(nparam,nf,nfsr,nineqn,nineq,neqn,neq,ncsrl,ncsrn,mesh_pts,
          mode,iprint,miter,&inform,bigbnd,eps,epseqn,udelta,
          cd->bl,cd->bu,cd->x,
          cd->f,cd->g,cd->lambda,
          objfsqp1,constfsqp1,gradobjfsqp1,gradconstfsqp1,cd);
    
    
  } else
  {
    if (prn>0)
      printf("Running FSQP with internal numerical gradient calculation.\n");
    ext_cfsqp(nparam,nf,nfsr,nineqn,nineq,neqn,neq,ncsrl,ncsrn,mesh_pts,
          mode,iprint,miter,&inform,bigbnd,eps,epseqn,udelta,
          cd->bl,cd->bu,cd->x,
          cd->f,cd->g,cd->lambda,
          objfsqp1,constfsqp1,grobfd,grcnfd,cd);
  }
  TROUT(16,10,"optfsqpbas","After running the algorithm")

#endif

  TRPT(16,50,"optfsqpbas","Checkpoint")
    
  /* Store results: */
  if (paramopt!=NULL)
    copytabletovector(cd->x,nparam,paramopt);

  TRPT(16,51,"optfsqpbas","Checkpoint")
    
  if (objectiveopt!=NULL)
  {
    if (cd->f==NULL)
      disppointer(objectiveopt);
    else
    {
      if (*objectiveopt==NULL)
        *objectiveopt=calloc(1,sizeof(**objectiveopt));
      **objectiveopt=*(cd->f);
    }
  }

  TRPT(16,52,"optfsqpbas","Checkpoint")
    
  if (constraintopt!=NULL)
    copytabletovector(cd->g,cd->nconstr,constraintopt);
  
  TRPT(16,53,"optfsqpbas","Checkpoint")
  
  if (inform!=0)
    ret=-inform;    
  
  TRPT(16,12,"optfsqpbas","After copying results, before printing")
  
  if (prn>0)
  {
    if (inform>0)
    {
      errfunc0("optfsqpbas");
      sprintf(ers(),"Algorithm FSQP finished without a proper solution, code %i:\n",
        inform);
      switch (inform)
      {
        case 0: 
          sprintf(ers(),"  Normal termination, solution has obtained.\n");
          break;
        case 1:
          sprintf(ers(),"  no feasible point found for linear constraints.\n");
        case 2:
          sprintf(ers(),"  no feasible point found for nonlinear constraints.\n");
        case 3:
          sprintf(ers(),"  no solution has been found in miter (%i) iterations.\n",
              miter);
        case 4:
          sprintf(ers(),"  stepsize smaller than machine precision before a successful\n");
          sprintf(ers(),"  new iterate is found.\n");
        case 5:
          sprintf(ers(),"  failure in attempting to construct d0.\n");
        case 6:
          sprintf(ers(),"  failure in attempting to construct d1.\n");
        case 7:
          sprintf(ers(),"  inconsistent input data.\n");
        case 8:
          sprintf(ers(),"  new iterate essentially identical to previous iterate, though\n");
          sprintf(ers(),"  stopping criterion not satisfied.\n");
        case 9:
          sprintf(ers(),"  penalty parameter too large, unable to satisfy nonlinear equality constraint.\n");
        default:
          sprintf(ers(),"  unknown situation.\n");;
      }
      errfunc2();
    }
  }

  if (prn>0)
  {
    printf("----------------\nOptimization using FSQP finished, Num. anal.: %i.\nResults:\n",
      fsqp_numan);
    printf("Optimal parameters:\n  {");
    for (i=1;i<=nparam;++i)
    {
      printf("%g",cd->x[i-1]);
      if (i<nparam) printf(", "); else printf("}\n");
    }
    printf("Optimal value of the objective function: %g\n",*(cd->f));
    if (cd->nconstr>0)
    {
      printf("Optimal values of constraint functions: \n");
      for (i=1;i<=cd->nconstr;++i)
      {
        printf("%g",cd->g[i-1]);
        if (i<cd->nconstr) printf(", "); else printf("}\n");
      }
    }
    if (prn>1)
    {
      printf("\n==\nResults from client data:\n");

      printf("\n\nOptimal parameters:\n  ");  printvectorline(cd->lastparam);
      if (cd->obj==NULL)
        printf("Objective function: NULL.\n");
      else
        printf("\n\nValue of the objective function: %g\n",*(cd->obj));
      printf("\nConstraint functions:\n");
      if (cd->constr==NULL)
        printf("Table of constraints is NULL.\n");
      else if (cd->constr->n==0)
        printf("No constraints.\n");
      else for (i=1;i<=cd->constr->n;++i)
      {
        dptr=cd->constr->s[i];
        if (dptr==NULL)
          printf("  %i: NULL\n",i);
        else
        {
          printf("  %i: %g\n",i,*dptr);
        }
      }
      printf("\n");
      if (cd->gradobj==NULL)
        printf("Gradient of the objective function is NULL.\n");
      else
      {
        printf("Gradient of the objective function:\n  ");
        printvectorline(cd->gradobj);
        printf("\n");
      }
      if (cd->gradconstr==NULL)
        printf("Table of constraint gradients is NULL.\n");
      else if (cd->gradconstr->n==0)
        printf("There are no constraint gradients.\n");
      else
      {
        printf("Constraint gradients:\n");
        for (i=1;i<=cd->gradconstr->n;++i)
        {
          if (cd->gradconstr->s[i]==NULL)
            printf("  %i: NULL.\n",i);
          else
          {
            printf("  %i:\n    ",i);
            printvectorline(cd->gradconstr->s[i]);
          }
        }
      }

    }
    printf("=================\n\n");
  }

  TRPT(16,15,"optfsqpbas","After printing results")


}

/* Algorithm data structure was not provided by the caller, it was allocated
here and thus we must deallocate it: */

TRIN(16,18,"optfsqpbas","Before deallocating")

if (algclientdata==NULL)
  dispoptalgcd(&cd);
ret=0;

TROUT(16,18,"optfsqpbas","After deallocating")

TROUT(16,1,"optfsqpbas","Beginning of optfsqpbas")

return ret;
#else   /* not defined CFSQP */
  errfunc0("optfsqpbas");
  sprintf(ers(),"The fsqp algorithm is not defined.\n");
  errfunc2();
  return -1;
#endif
}




/* Adjustable parameters for inspectfsqp(), can be set by inspectfsqpparam(): */
static int ifmiter=100,  /* max. num. iter. */
           ifprn=0;  /* Print level for the first optimization */
           ifenforce=0;     /* enforce these parameters */
static double iftol=1.0e-6,iftoleqn=1.0e-6;  /* tolerances */


void inspectfsqpparam(int maxiter,double tol,double toleqn,int prn)
    /* Sets parameters for running the fsqp algorithm within inspectfsqp:
      maxiter - max. number of iterations
      tol - tolerance on Kuhn-Tucker conditions
      toleqn - tolerance on equality constraints
      prn - reporting level for 1st optimization (0 - no output)
    Remark: parameters that are <0 are not affected. If all are less than 0
    then the flag ifenforce is set to 0 (which can be used for resetting this
    flag), otherwise ifenforce is set to 1.
    $A Igor mar05; */
{
if (maxiter<0 && tol<0 && toleqn<0 && ifprn<0)
{
  ifenforce=0;
  printf("\n\nEnforcing parameters (max. iter. in particular) for inspectfsqp() turned off.\n");
  printf("Parameters: maxiter = %i, tol = %g, toleqn = %g, prn=%i.\n\n",
    ifmiter,iftol,iftoleqn,ifprn);
} else
{
  printf("\n\nThe following parameters for inspectfsqp() are set:\n");
  ifenforce=1;
  if (maxiter>=0)
  {
    ifmiter=maxiter;
    printf("  Max. num. of iterations set to %i.\n",ifmiter);
  }
  if (tol>=0)
  {
    iftol=tol;
    printf("  Tol. on KT conditions set to %g.\n",iftol);
  } 
  if (toleqn>=0)
  {
    iftoleqn=toleqn;
    printf("  Tol. on equality constraints set to %g.\n",iftoleqn);
  }
  if (prn>=0)
  {
    ifprn=prn;
    printf("  Reporting level set to %i.\n",ifprn);
  }
  printf("Enforcing parameters is turned on.\n\n");
}
}



void inspectfsqpbas(vector param0,int nconstr,optalgcd cd,
                   analysis_bas_f testanfunc,void *clientdata )
    /* Runs the function testanfunc with specification data clientdata at
    parameters param, and outputs the results. Then it runs optimisation of
    the function by using param0 as a starting guess, and outputs results.
      nconstr is the number of constraints.
      cd is a data structure that can be optionallly provided by the caller.
    If cd==NULL then this structure is allocated inside of function and
    deallocated before return.
      Function is not thread safe since it uses static variables for function
    arguments.
    $A Igor oct04; */
{
int nf=1, /* allocate=1, */ info,num=0,allocate=0,retinfo=0,derobj,derconstr;
/*
optalgcd cd=NULL;
*/
double ct0=0,ct1=0,t0=0,t1=0,ctlim=0.3 /* limit for CPU time */;
#define return0 {if (allocate) dispoptalgcd(&cd); return;}
TRIN(21,1,"inspectfsqp","Beginning of func. inspectfsqp")
if (cd==NULL)
  allocate=1;

if (param0==NULL)
{
  errfunc0("inspectfsqp");
  sprintf(ers(),"Vector of parameters is not allocated.\n");
  errfunc2();
  return0;
} else
{
  printf("\n\nTest run of the analysis funciton at initial parameters:\n");
  inspectanfunc(param0,nconstr,1,testanfunc,clientdata);
  printf("\n\nRetrieving basic data about optimization problem...\n");
  if (allocate)
    cd=newoptalgcd();
  {
    info=1;
    /*
    testanfunc(param0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,clientdata);
    */
    retinfo=getanfuncinfo(param0,testanfunc,clientdata,
        &(cd->nparam),&(cd->nobj),&(cd->nconstr),&derobj,&derconstr);
    if ( (derobj || cd->nobj<1) && (derconstr || cd->nconstr<1) )
      cd->nongrad=0;  /* derivatives are calculated */
    else
      cd->nongrad=1;
    if (cd->nparam==0 || retinfo<0)
    {
      /* info=cd->nparam; */
      errfunc0("inspectfsqp");
      sprintf(ers(),"Analysis function could not return all basic algorithm data.\n");
      /*
      sprintf(ers(),"Even with parameters different than NULL.\n");
      */
      sprintf(ers(),"It seems that info functionality is not supported.\n");
      if (retinfo<0)
        sprintf(ers(),"Function \"getanfuncdatabas\" returned error code: %i.\n",
             retinfo);
      errfunc2();
      info=0;
    } else if (cd->nconstr!=nconstr)
    {
      errfunc0("inspectfsqp");
      sprintf(ers(),"Number of constraints %i does not match the number returned by\n",nconstr);
      sprintf(ers(),"  analysis function (%i).\n",cd->nconstr);
      errfunc2();
    }
    if (retinfo==-1)
      printf("\nInfo functionality is not supported by the analysis function.\n\n\n");
    else
    {
      printf("\nAnalysis function in info mode provided the following results:\n");
      if (retinfo==-2)
        printf("Dimension of provided parameter vector (%i) is inconstist.\n",
                param0==NULL?0:param0->d);
      if (retinfo==3)
        printf("Number of parameters couold not be determined.\n");
      printf("Number of parameters: %i\n",cd->nparam);
      printf("Number of objective functions: %i\n",cd->nobj);
      printf("Number of constraint functions: %i\n",cd->nconstr);
      if (cd->nongrad)
        printf("Derivatives are NOT provided.\n");
      else
        printf("Derivatives are provided.\n");
      printf("\n\n");
    }
  }
  {
    int gradients=1,monotone=0;
    double udelta=1.0e-10;
    FILE *outfile=NULL;
    vector paramopt=NULL;
    double *objectiveopt=NULL;
    vector constraintopt=NULL;

    if (cd->nconstr>0 && nconstr<1)
      nconstr=cd->nconstr;

    /*
    optalgcd cd1=NULL;
    */

    TRIN(21,30,"inspectfsqp","Beginning of optimization block")

    /* Run the FSQP algorithm; basic data are on cd, where put by the
    analysis function: */
    if (!info)
    {
      if (param0==NULL)
      {
        errfunc0("inspectfsqp");
        sprintf(ers(),"Parameters are NULL and info is not enabled at this analysis function.\n");
        errfunc2();
        return0;
      }
      if (cd->nparam>0 && ( cd->nparam>0 && cd->nparam!=param0->d ) )
      {
        errfunc0("inspectfsqp");
        sprintf(ers(),"Number of parameters is different than the requested.\n");
        sprintf(ers(),"Specified number: %i, requested by the function: %i.\n");
        errfunc2();
        return0;
      }
      /* Info functionality is not supported by this analysis function, we
      must therefore set the data on cd: */
      cd->nparam=param0->d;
      cd->nobj=1;
      cd->nconstr=nconstr;
      cd->nconstrineqlin=cd->nconstreqlin=cd->nconstreq=0;
    }
    /* Set max. number of iteration to at least square of the number of
    parameters: */
    if (!ifenforce)
      if (cd->nparam*cd->nparam>ifmiter)
        ifmiter=cd->nparam*cd->nparam;
    printf("Number of parameters: %i\n",cd->nparam);
    printf("Number of objective functions: %i\n",cd->nobj);
    printf("Number of constraints: %i\n",cd->nconstr);
    printf("             equality: %i\n",cd->nconstreq);
    printf("      linear equality: %i\n",cd->nconstreqlin);
    printf("    linear inequality: %i\n",cd->nconstrineqlin);
    
    
    /*
    optfsqpbas(...);
    */
        
    if (cd->nobj!=1)
    {
      errfunc0("inspectfsqp");
      sprintf(ers(),"Number of objective functions is different than  1 (%i).\n",
        cd->nobj);
      errfunc2();
      return0;
    }
    /*
    cd1=newoptalgcd();
    cd1->nparam=cd->nparam;
    cd1->nobj=cd->nobj;
    cd1->nconstr=cd->nconstr;
    cd1->anf=cd->anf;
    cd1->cd=cd->cd;
    */

    TRIN(21,46,"inspectfsqp","Before first optimization")

    printf("\n\n>>Optimization:\n");
    printf("Max. num. iter.: %i, tol. cond.: %g, tol. eq.: %g\n\n",
      ifmiter,iftol,iftoleqn); 
      
    ct0=cputime();  t0=absolutetime();
    optfsqpbas(1,cd->nconstr,cd->nconstreq,
          cd->nconstrineqlin,cd->nconstreqlin,
          iftol,iftoleqn,
          ifmiter,gradients,udelta,monotone,
          param0,
          NULL,NULL,   /* lowbounds,upbounds */
          ifprn,outfile,
          & paramopt, &objectiveopt, &constraintopt,
          cd,
          testanfunc,clientdata);

#if 0
    prn=0;
    optfsqpbas(1,cd->nconstr,cd->nconstreq,
          cd->nconstrineqlin,cd->nconstreqlin,
          iftol,iftoleqn,
          ifmiter,gradients,udelta,monotone,
          param0,
          NULL,NULL,   /* lowbounds,upbounds */
          ifprn,outfile,
          & paramopt, &objectiveopt, &constraintopt,
          cd,
          testanfunc,clientdata);

#endif

    ct1=cputime();  t1=absolutetime();


    TROUT(21,46,"inspectfsqp","After second optimization")

    
    printf("\n=====\nAlgorithm results:\n");
    printf("Optimal parameters (dim=%i):\n  ",
      paramopt==NULL?0:paramopt->d); 
      printvectorlist(paramopt);
    printf("\nValue of the objective function:\n");
    if (objectiveopt==NULL)  printf("  NULL\n");
    else printf("  %g.\n",*objectiveopt);
    printf("Values of constraint functions (num=%i):\n" ,
      constraintopt==NULL?0:constraintopt->d); 
      printvectorlist(constraintopt);

    copyvector(paramopt,&param0);  /* pass back information about optimal parameters */
    
    if (1 && (ct1-ct0<=ctlim))  /* Speed test */
    {
      double nrep=1.0 /* ct0,ct1, */ /* ctlim=0.3 limit for CPU time, */ ;
      int i;
      num=0;
      cd->anprintlevel=ifprn=0;
      printf("\n\nSpeed test:\n");
      printf("Running optimizations, CPU time limit is %g seconds...\n",ctlim);
      t0=absolutetime();
      ct0=ct1=cputime();
      while(ct1-ct0<ctlim)
      {
        for (i=1;i<=nrep;++i)
        {
          optfsqpbas(1,cd->nconstr,cd->nconstreq,
                cd->nconstrineqlin,cd->nconstreqlin,
                iftol,iftoleqn,
                ifmiter,gradients,udelta,monotone,
                param0,
                NULL,NULL,   /* lowbounds,upbounds */
                ifprn,outfile,
                & paramopt, &objectiveopt, &constraintopt,
                cd,
                testanfunc,clientdata);
          /*
          testanfunc(param,&calcobj,&obj,&calcconstr,&constr,&calcgradobj,&gradobj,
              &calcgradconstr,&gradconstr,clientdata);
          */
          ++num;
          if (num<200)
            printf(".");
        }
        printf(" nrep=%g ",nrep);
        ct1=cputime();
        if ((ct1-ct0)/ctlim <0.01)
          nrep=1.01*(double) num / 0.01;
        else if ((ct1-ct0)/ctlim <0.04) 
          nrep=1.01*(double) num / 0.04;
        else if ((ct1-ct0)/ctlim <0.1) 
          nrep=1.01*(double) num / 0.1;
        else if ((ct1-ct0)/ctlim <0.4) 
          nrep=1.01*(double) num / 0.4;
        else if ((ct1-ct0)/ctlim <0.8) 
          nrep=1.01*(double) num / 0.8;
        else if ((ct1-ct0)/ctlim <0.95) 
          nrep=1.01*(double) num / 0.95;
        else if ((ct1-ct0)/ctlim <0.99) 
          nrep=1.01*(double) num / 0.99;
        else if ((ct1-ct0)<ctlim) 
          nrep=1.01*(double) num / 1.0;
      }
      t1=absolutetime();
      printf("\n\n%i optimizations run in %g s of CPU time.\n",num,ct1-ct0);
      printf("Wallclock time: %g\n",t1-t0);
      printf("                  Time for one opt.:   %g\n",(ct1-ct0)/(double) num);
      printf("                  No. opt. per second: %g\n\n\n\n",(double) num / ((ct1-ct0)));
    } else
    {
      num=1; /* time of the single optimization is used as speed result */
      printf("\n\nSpeed test: one run exceeded CPU time limit %g s\n",ctlim);
      printf("\n%i optimizations run in %g s of CPU time.\n",num,ct1-ct0);
      printf("Wallclock time: %g\n",t1-t0);
      printf("                  Time for one opt.:   %g\n",(ct1-ct0)/(double) num);
      printf("                  No. opt. per second: %g\n\n\n\n",(double) num / ((ct1-ct0)));
    }
    
    dispvector(&paramopt);
    disppointer(&objectiveopt);
    dispvector(&constraintopt);
  }


  TRIN(21,32,"inspectfsqp","Before deletion of algorithm client data")
  
  /* $$
  */

  
  

  TROUT(21,32,"inspectfsqp","After deletion of algorithm client data")
  
  /*
  printf("After deletion of the algorithm client data.\n");
  */

  TROUT(21,30,"inspectfsqp","End of optimization block")
  
}

return0;

TRIN(21,1,"inspectfsqp","End of func. inspectfsqp")

#undef return0

}



void inspectfsqp(vector param0,int nconstr,
                   analysis_bas_f testanfunc,void *clientdata )
    /* Simplified version of inspectfsqpbas. Always allocates the optimization
    alg. client data automatically and deallocates it before exit.
    Runs the function testanfunc with specification data clientdata at
    parameters param, and outputs the results. Then it runs optimisation of
    the function by using param0 as a starting guess, and outputs results.
      nconstr is the number of constraints. 
      Function is not thread safe since it uses static variables for function
    arguments (??).
    $A Igor apr05; */
{
inspectfsqpbas(param0,nconstr,NULL,testanfunc,clientdata);
}





void optimizebas(vector param0,int nconstr, double tol,int maxit,
         optalgcd cd,int printlevel,
         analysis_bas_f testanfunc,void *clientdata )
    /* Tries to solve the optimization problem defined by testanfunc and 
    clientdata (which is passed to testanfunc at each call). All constraints
    must be inequality constraints. Result is stored back to param0.
      param0 - starting guess, optimal parameters are stored here on return.
      nconstr - number of constraints (must be inequality constraints)
      tol - tolerance (usually on Kuhn-Tucker conditions), defaule 1e-6.
      maxit - maximal number of iterations, default unlimited.
      cd - optionally provided auxiliary structure that is used internally. If
      NULL then the structure is temporarily allocated within the function.
      printlevel - level of output.
      testanfunc - analysis function
      clientdata - definition data for analysis function, this pointer is
    passed as argument to testanfunc at any call.
    $A Igor apr05; */
{
int nf=1, info=0,num=0,allocate=0,derobj=0,derconstr=0,retinfo=0;
/*
optalgcd cd=NULL;
*/
double ct0=0,ct1=0,t0=0,t1=0,ctlim=0.3 /* limit for CPU time */;
#define return0 {if (allocate) dispoptalgcd(&cd); return;}
if (cd==NULL)
  allocate=1;
if (maxit<=0)
  maxit=INT_MAX;
if (tol<=0)
  tol=1e-6;
TRIN(56,1,"optimizebas","Beginning of func. optimizebas")

if (param0==NULL)
{
  errfunc0("optimizebas");
  sprintf(ers(),"Vector of parameters is not allocated.\n");
  errfunc2();
  return0;
} else
{
  /*
  printf("\n\nTest run of the analysis funciton at initial parameters:\n");
  inspectanfunc(param0,nconstr,1,testanfunc,clientdata);
  printf("\n\nRetrieving basic data about optimization problem...\n");
  */
  if (allocate)
    cd=newoptalgcd();
  /* check if the function rfeturns basic problem info: */
  retinfo=getanfuncinfo(param0,testanfunc,clientdata,
        &(cd->nparam),&(cd->nobj),&(cd->nconstr),&derobj,&derconstr);
  if ( (derobj || cd->nobj<1) && (derconstr || cd->nconstr<1) )
    cd->nongrad=0;  /* derivatives are calculated */
  else
    cd->nongrad=1;
  if (retinfo!=-1)
    info=1;

  {
    int gradients=1,monotone=0;
    double udelta=1.0e-10;
    FILE *outfile=NULL;
    vector paramopt=NULL;
    double *objectiveopt=NULL;
    vector constraintopt=NULL;

    /*
    optalgcd cd1=NULL;
    */

    TRIN(56,30,"optimizebas","Beginning of optimization block")

    /* Run the FSQP algorithm; basic data are on cd, where put by the
    analysis function: */
    if (!info)
    {
      if (param0==NULL)
      {
        errfunc0("optimizebas");
        sprintf(ers(),"Parameters are NULL and info is not enabled at this analysis function.\n");
        errfunc2();
        return0;
      } else if (cd->nparam>0 && cd->nparam!=param0->d)
      {
        errfunc0("optimizebas");
        sprintf(ers(),"Number of parameters is different than the requested.\n");
        sprintf(ers(),"Specified number: %i, requested by the function: %i.\n");
        errfunc2();
        return0;
      }
      /* Info functionality is not supported by this analysis function, we
      must therefore set the data on cd: */
      cd->nparam=param0->d;
      cd->nobj=1;
      cd->nconstr=nconstr;
      cd->nconstrineqlin=cd->nconstreqlin=cd->nconstreq=0;
    }
    /* Set max. number of iteration to at least square of the number of
    parameters: */
    if (!ifenforce)
      if (cd->nparam*cd->nparam>ifmiter)
        ifmiter=cd->nparam*cd->nparam;
    if (0 || printlevel>0)
    {
      printf("Number of parameters: %i\n",cd->nparam);
      printf("Number of objective functions: %i\n",cd->nobj);
      printf("Number of constraints: %i\n",cd->nconstr);
      printf("             equality: %i\n",cd->nconstreq);
      printf("      linear equality: %i\n",cd->nconstreqlin);
      printf("    linear inequality: %i\n",cd->nconstrineqlin);
    }
    
    
    /*
    optfsqpbas(...);
    */
        
    if (cd->nobj!=1)
    {
      errfunc0("optimizebas");
      sprintf(ers(),"Number of objective functions is different than  1 (%i).\n",
        cd->nobj);
      errfunc2();
      return0;
    }
    /*
    cd1=newoptalgcd();
    cd1->nparam=cd->nparam;
    cd1->nobj=cd->nobj;
    cd1->nconstr=cd->nconstr;
    cd1->anf=cd->anf;
    cd1->cd=cd->cd;
    */

    TRIN(56,46,"optimizebas","Before first optimization")

    if (printlevel>0)
    {
      printf("\n\n>>Optimization:\n");
      printf("Max. num. iter.: %i, tol. cond.: %g, tol. eq.: %g\n\n",
      ifmiter,iftol,iftoleqn); 
    }
      
    ct0=cputime();  t0=absolutetime();
    optfsqpbas(1,cd->nconstr,cd->nconstreq,
          cd->nconstrineqlin,cd->nconstreqlin,
          /* iftol,iftoleqn, */ tol, tol,
          /*ifmiter, */ maxit, gradients,udelta,monotone,
          param0,
          NULL,NULL,   /* lowbounds,upbounds */
          /* ifprn */ printlevel,outfile,
          & paramopt, &objectiveopt, &constraintopt,
          cd,
          testanfunc,clientdata);


    ct1=cputime();  t1=absolutetime();


    TROUT(56,46,"optimizebas","After second optimization")

    if (printlevel>0)
    {
      printf("\n=====\nAlgorithm results:\n");
      printf("Optimal parameters (dim=%i):\n  ",
        paramopt==NULL?0:paramopt->d); 
        printvectorlist(paramopt);
      printf("\nValue of the objective function:\n");
      if (objectiveopt==NULL)  printf("  NULL\n");
      else printf("  %g.\n",*objectiveopt);
      printf("Values of constraint functions (num=%i):\n" ,
        constraintopt==NULL?0:constraintopt->d); 
        printvectorlist(constraintopt);
    }

    copyvector(paramopt,&param0);  /* pass back information about optimal parameters */
    
    if (0 && (ct1-ct0<=ctlim))  /* Speed test */
    {
      double nrep=1.0 /* ct0,ct1, */ /* ctlim=0.3 limit for CPU time, */ ;
      int i;
      num=0;
      cd->anprintlevel=ifprn=0;
      printf("\n\nSpeed test:\n");
      printf("Running optimizations, CPU time limit is %g seconds...\n",ctlim);
      t0=absolutetime();
      ct0=ct1=cputime();
      while(ct1-ct0<ctlim)
      {
        for (i=1;i<=nrep;++i)
        {
          optfsqpbas(1,cd->nconstr,cd->nconstreq,
                cd->nconstrineqlin,cd->nconstreqlin,
                iftol,iftoleqn,
                ifmiter,gradients,udelta,monotone,
                param0,
                NULL,NULL,   /* lowbounds,upbounds */
                ifprn,outfile,
                & paramopt, &objectiveopt, &constraintopt,
                cd,
                testanfunc,clientdata);
          /*
          testanfunc(param,&calcobj,&obj,&calcconstr,&constr,&calcgradobj,&gradobj,
              &calcgradconstr,&gradconstr,clientdata);
          */
          ++num;
          if (num<200)
            printf(".");
        }
        printf(" nrep=%g ",nrep);
        ct1=cputime();
        if ((ct1-ct0)/ctlim <0.01)
          nrep=1.01*(double) num / 0.01;
        else if ((ct1-ct0)/ctlim <0.04) 
          nrep=1.01*(double) num / 0.04;
        else if ((ct1-ct0)/ctlim <0.1) 
          nrep=1.01*(double) num / 0.1;
        else if ((ct1-ct0)/ctlim <0.4) 
          nrep=1.01*(double) num / 0.4;
        else if ((ct1-ct0)/ctlim <0.8) 
          nrep=1.01*(double) num / 0.8;
        else if ((ct1-ct0)/ctlim <0.95) 
          nrep=1.01*(double) num / 0.95;
        else if ((ct1-ct0)/ctlim <0.99) 
          nrep=1.01*(double) num / 0.99;
        else if ((ct1-ct0)<ctlim) 
          nrep=1.01*(double) num / 1.0;
      }
      t1=absolutetime();
      printf("\n\n%i optimizations run in %g s of CPU time.\n",num,ct1-ct0);
      printf("Wallclock time: %g\n",t1-t0);
      printf("                  Time for one opt.:   %g\n",(ct1-ct0)/(double) num);
      printf("                  No. opt. per second: %g\n\n\n\n",(double) num / ((ct1-ct0)));
    } else
    {
      num=1; /* time of the single optimization is used as speed result */
      if (printlevel>0)
      {
        printf("\n\nSpeed test: one run exceeded CPU time limit %g s\n",ctlim);
        printf("\n%i optimizations run in %g s of CPU time.\n",num,ct1-ct0);
        printf("Wallclock time: %g\n",t1-t0);
        printf("                  Time for one opt.:   %g\n",(ct1-ct0)/(double) num);
        printf("                  No. opt. per second: %g\n\n\n\n",(double) num / ((ct1-ct0)));
      }
    }
    
    dispvector(&paramopt);
    disppointer(&objectiveopt);
    dispvector(&constraintopt);
  }


  TRIN(56,32,"optimizebas","Before deletion of algorithm client data")
  
  /* $$
  */

  TROUT(56,32,"optimizebas","After deletion of algorithm client data")
  
  /*
  printf("After deletion of the algorithm client data.\n");
  */

  TROUT(56,30,"optimizebas","End of optimization block")
}

return0;

TRIN(56,1,"optimizebas","End of func. optimizebas")

#undef return0
}




void optimizesimp(vector param0,int nconstr, double tol,int maxit,
         analysis_bas_f testanfunc,void *clientdata )
    /* A simple function that solves the optimization problem defined by
    testanfunc and clientdata (this pointer is passed to testanfunc at
    every call). All constraints must be inequality constraints. Results are
    stored back to param0.
      param0 - starting guess, optimal parameters are stored here on return.
      nconstr - number of constraints (must be inequality constraints)
      tol - tolerance (usually on Kuhn-Tucker conditions), defaule 1e-6.
      maxit - maximal number of iterations, default unlimited.
      testanfunc - analysis function
      clientdata - definition data for analysis function, this pointer is
    passed as argument to testanfunc at any call.
    $A Igor apr05; */

    /* Tries to solve the optimization problem defined by testanfunc and 
    clientdata (which is passed to testanfunc at each call). All constraints
    must be inequality constraints. Result is stored back to param0.
    $A Igor apr05; */

{
optimizebas(param0,nconstr,tol,maxit,NULL,0,testanfunc,clientdata);
}









    /* INITIALIZATION */

int   IOptlib_ver=-1;
int   IOptlib_subver=-1;
int   IOptlib_year=-1;
char *IOptlib_name=NULL;

void fprintioptlibhead(FILE *fp)
    /* Prints the IOptlib head to the file fp.
    $A Igor apr05; */
{
double ver=0;
char *sp="        ";

if (fp!=NULL)
{
  ver=(double) IOptlibver+0.01*(double) IOptlibsubver;
  fprintf(fp,"\n");

  fprintf(fp,"%s ----------------------------------------------------- \n",sp);
  fprintf(fp,"%s|                                                     |\n",sp);
  fprintf(fp,"%s|   %-8s initialized.                             |\n",sp,IOptlibname);
  fprintf(fp,"%s|   This is a free open source optimization library,  |\n",sp);
  fprintf(fp,"%s|     version %4g, %12s release (%i).      |\n",sp,ver,IOptlibrel,IOptlibyear);
  fprintf(fp,"%s|   developed by Igor Gresovnik,                      |\n",sp);
  fprintf(fp,"%s|                http://www.c3m.si/igor               |\n",sp);
  fprintf(fp,"%s ----------------------------------------------------- \n",sp);
  fprintf(fp,"\n");
}
}

void printioptlibhead(void)
    /* Prints the IOptlib head to the the standard output.
    $A Igor apr05; */
{
fprintioptlibhead(stdout);
}



void initioptlib(void)
    /* Initializes IOptlib.
    $A Igor apr05; */
{
static int initialized=0,lock=0;
if (!initialized)
{
  m_threadlock(lock);  /* serialize threads */
  if (!initialized)
  {
    IOptlib_ver=IOptlibver;
    IOptlib_subver=IOptlibsubver;
    IOptlib_year=IOptlibyear;
    IOptlib_name=stringcopy(IOptlibname);
    fprintioptlibhead(stdout);
  }
  ++initialized;
  m_threadunlock(lock);
}
}













































  /* TEST FUNCTION OF THIS MODULE */

void testoptbas(void)
    /* Tests of functions from the module optbas.c. Change conditions in if(0)
    or if(1), respectively, in order to run different tests!
    $A Igor oct04; */
{

if (1)
{
  /* Test of the basic analysis function: */
  vector param=NULL;
  int nparam=2,nconstr=2;
  void *clientdata=NULL;
  printf("\n\nTest of the basic test analysis function:\n");
  param=getvector(nparam);
  /* Test of optimization algorithm: */
  param->v[1]=-5; param->v[2]=-5;
  printf("\nEnd of the test of the basic analysis function.\n");
  printf("\nTest of optimization with the basic analysis function:\n\n");
  param->v[1]=-5; param->v[2]=-5;
  inspectfsqp(param,2,testanfunc,clientdata);
}

if (0)
{
  /* Test of the basic analysis function: */
  vector param=NULL;
  int nparam=2,nconstr=2;
  void *clientdata=NULL;
  printf("\n\nTest of the basic test analysis function:\n");
  param=getvector(nparam);
  /* Test at parameters (0,0): */
  param->v[1]=0;  param->v[2]=0;
  inspectanfunc(param,nconstr,1 /* allocate output arguments */,testanfunc,clientdata);
  /* Test at some parameters that are set by the FSQP optimization algorithm
  in the example for Inverse: */
  param->v[1]=1.85909666961724;  param->v[2]=1.08307629576691;
  inspectanfunc(param,nconstr,1 /* allocate output arguments */,testanfunc,clientdata);
  /* Test at optimal parameters: */
  param->v[1]=1.6;  param->v[2]=1;
  inspectanfunc(param,nconstr,1 /* allocate output arguments */,testanfunc,clientdata);
  /* Test of optimization algorithm: */
  param->v[1]=-5; param->v[2]=-5;
  printf("\nEnd of the test of the basic analysis function.\n");
  printf("\nTest of optimization with the basic analysis function:\n\n");
  param->v[1]=-5; param->v[2]=-5;
  inspectfsqp(param,2,testanfunc,clientdata);
}



}









int analyseoptprob1(vector param,int *calcobj,double **addrobj,
      int *calcconstr,stack *addrconstr,
      int *calcgradobj,vector *addrgradobj,
      int *calcgradconstr,stack *addrgradconstr,int *id)
    /* This function performs analysis of the optimization problem that is
    identified by id.
    $A Igor mar05; */
{
if (id==NULL)
{
  errfunc0("analyseoptprob1");
  sprintf(ers(),"Pointer to problem ID is NULL.\n");
  errfunc2();
  return -1;
} else if (*id==1)
{
    return testanfunc(param,calcobj,addrobj,
      calcconstr,addrconstr,
      calcgradobj,addrgradobj,
      calcgradconstr,addrgradconstr,id);
} else if (*id==2)
{
    return testanfunc1(param,calcobj,addrobj,
      calcconstr,addrconstr,
      calcgradobj,addrgradobj,
      calcgradconstr,addrgradconstr,id);
} else
{
    return testanfunc1(param,calcobj,addrobj,
      calcconstr,addrconstr,
      calcgradobj,addrgradobj,
      calcgradconstr,addrgradconstr,id);
}
}

