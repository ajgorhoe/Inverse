

         /* REAL FUNCTIONS OF ONE VARIABLE */


#include <sysint.h>

#include <math.h>
#include <limits.h>
#include <float.h>

#include <er.h>
#include <st.h>

#include <rf.h>

/* Funkcije, ki jih pozna c:
  cos  (kot. funkcije)
  sin
  tan
  acos  (inverz. kot. funkcije)
  asin
  atan
  cosh  (hiperbolicne funkcije)
  sinh
  tanh
  exp   (naravni eksponent)
  log   (narav. logaritem)
  log10 (logaritem z osnovo 2)
  ceil    (zaokrozevanje navzgor)
  floor   (zaokrozevanje navzdol)
  fabs    (absolut. vrednost)
  fmod(x,y) ( x mod y)
  pow(x,y) (y^x)
  sqrt     (kvadrat. koren)

  double modf(double value, double *i_ptr) (razbije vrednost na celo in neceli
         dedouble x= frexp(double val,int*expp) -> val=x*2^(*exp)
  double ldexp(double x,int exp)  (x*2^exp)
*/





#define doubleinfinity (0.9*DBL_MAX) /* *DBL_MAX */

/* Number of digits printed in outputs: */
int rf_printdigits_accuracy_definition=8;
/* Flag for avoiding exponential notation (such as 1.3e-8 or 14.0E15 when
printing numbers or converting them to strings: */
int rf_avoid_print_exp=0;


double pi(void)
    /* Vrne razmerje med obsegom in premerom kroga. */
{
return ConstPi;
}


double infinity(void)
       /* + neskoncno */
{
return doubleinfinity;
}






    /* ZAOKROZEVANJE: */

double round(double x)
       /* Vrne x zaokrozen na celo vrednost */
{
double y;
if (x<0)
  return -round(-x);
y=floor(x);
if (x-y<0.5)
  return y;
else return y+1;
}

double trunc(double x)
       /* Vrne x, kateremu odreze neceli del */
{
return floor(x);
}


double frac(double x)
       /* vrne neceli del x */
{
return x-floor(x);
}


double intpow(double x,int pow)
    /* Vrne celo potenco pow stevila x.
    $A Igor jul00; */
{
double ret=1;
int i;
if (pow<0)
  ret=1/intpow(x,-pow);
for (i=1;i<=pow;++i)
  ret*=x;
return ret;
}


  /* BASIC INTEGERS AND FRACTIONS */

unsigned long greatcomdivul(unsigned long a,unsigned long b)
    /* Returns the greatest common divisor of a and b for unsigned long
    numbers.
    $A Igor jul04; */
{
unsigned long c;
while (b!=0)
{
  c=a%b;
  a=b;
  b=c;
}
return a;
}

long greatcomdiv(long a,long b)
    /* Returns the greatest common divisor of a and b.
    $A Igor jul04; */
{
unsigned long c;
while (b!=0)
{
  c=a%b;
  a=b;
  b=c;
}
if (a<0)
  a=-a;  /* To handle negative arguments */
return a;
}


    /* COMBINATORICS, GAMMA FUNCTION ... */

unsigned long factorialint0(int n)
    /* Returns the factorial of n (n!) calculated exactly.
    On overflow or if argument is less than 0, the function returns 0 but
    does not report an error.
    $A Ifor jul04; */
{
unsigned long ret;
int factor;
if (n<0)
  return 0;
else
{
  switch (n)
  {
    case 0:
    case 1:
      return 1;
      break;
    case 2:
      return 2;
      break;
    case 3:
      return 6;
      break;
    case 4:
      return 24;
      break;
    case 5:
      return 120;
      break;
    case 6:
      return 720;
      break;
    case 7:
      return 5040;
      break;
    default:
    {
      ret=n;
      factor=n-1;
      while(factor>1)
      {
        if (ret>=(ULONG_MAX/(factor+1)) )
          return 0;  /* overflow */
        else
        {
          ret*=factor;
          --factor;
        }
      }
      return ret;
    }
  }
}
}


unsigned long factorialint(int n)
    /* The same as factorialint0, just that it reports an error in the case that
    n is less than 0 or in the case of overflow when the result can not be
    represented by an unsigned long.
    $A Igor jul04; */
{
unsigned long ret;
ret=factorialint0(n);
if (ret<1)
{
  if (n<0)
  {
    errfunc0("factorialint");
    sprintf(ers(),"Factorial is not defined for negative integers (called with %i).\n",
      n);
    errfunc2();
  } else
  {
    errfunc0("factorialint");
    sprintf(ers(),"Overflow (%i! > %ul).\n",
      n,ULONG_MAX);
    errfunc2();
  }
}
return ret;
}



double doublefactorial0(int n)
    /* Returns factorial of n, or 0 if n is invalid, i.e. less than 0.
    $A Igor jul04; */
{
unsigned long fac;
double ret,factor;
fac=factorialint0(n);
if (fac>0)
  return (double) fac;
else if (n<0)
  return 0;  /* invalid argument */
else
{
  ret=(int) n;
  factor=ret-1.0;
  while(factor>1.0)
  {
    ret*=factor;
    factor=factor-1.0;
  }
  return ret;
}
}


double doublefactorial(int n)
    /* The same as doublefactorial(), except that it reports an error
    in the case of an invalid argument, i.e. n<0.
    Ref. http://mathworld.wolfram.com/Multifactorial.html
    $A Igor jul04; */
{
double ret;
ret=doublefactorial0(n);
if (ret<1 &&  n<0)
{
  errfunc0("doublefactorial");
  sprintf(ers(),"Factorial is not defined for negative arguments (called with %i).\n",
    n);
  errfunc2();
}
return ret;
}


unsigned long multifactorialint0(int n,int m)
    /* Returns the multifactorial fac_m(n)=n*(n-m)*(n-2*m)*...*1, or 0 if
    n<0 or k<1 or in the case of overflow.
    Ref. http://mathworld.wolfram.com/Multifactorial.html
    $A Igor jul04; */
{
unsigned long ret;
int factor;
if (n<0 || m<1)   /* invalid arguments */
  return 0;
else if (n==0)
  return 1;
else if (n<=m+1)
  return n;
else
{
  ret=n;
  factor=n-m;
  while(factor>1)
  {
    if (ret>=(ULONG_MAX/(factor+1)))
      return 0;  /* overflow */
    else
    {
      ret*=factor;
      factor-=m;
    }
  }
  return ret;
}
}

unsigned long multifactorialint(int n,int m)
    /* The same as multifactorialint0, except that it reports error in the case
    of invalid arguments or overflow.
    ref. http://mathworld.wolfram.com/Multifactorial.html
    $A Igor jul04; */
{
unsigned long ret;
ret=multifactorialint0(n,m);
if (ret<1)
{
  if (n<0)
  {
    errfunc0("multifactorialint");
    sprintf(ers(),"Multifactorial is not defined for negative integers (called with %i).\n",
      n);
    errfunc2();
  } else if (m<1)
  {
    errfunc0("multifactorialint");
    sprintf(ers(),"The multifactorial index should be positive (called with %i).\n",
      m);
    errfunc2();
  } else
  {
    errfunc0("multifactorialint");
    sprintf(ers(),"Overflow (%i(!,%i) > %ul).\n",
      n,m,ULONG_MAX);
    errfunc2();
  }
}
return ret;
}


double doublemultifactorial0(int n,int m)
    /* Returns the multifactorial fac_m(n)=n*(n-m)*(n-2*m)*...*1, or 0 if
    n<0 or k<1 or in the case of overflow.
    Ref. http://mathworld.wolfram.com/Multifactorial.html ,
    $A Igor jul04; */
{
double ret,factor;
ret=(double) multifactorialint0(n,m);
if (ret<1.0)
{
  if (n<0 || m<1)  /* invalid arguments */
    ;
  else
  {
    ret=(double) n;  factor=ret-(double) m;
    while (factor>1.0)  
    {
      ret*=factor;
      factor=factor-(double) m;
    }
  }
}
return ret;
}


double doublemultifactorial(int n,int m)
    /* The same as doublemultifactorial0, except that it reports error in the
    case of invalid arguments.
    Ref. http://mathworld.wolfram.com/Multifactorial.html
    $A Igor jul04; */
{
double ret;
ret=doublemultifactorial0(n,m); 
if (ret<1)
{
  if (n<0)
  {
    errfunc0("doublemultifactorial");
    sprintf(ers(),"Multifactorial is not defined for negative integers (called with %i).\n",
      n);
    errfunc2();
  } else if (m<1)
  {
    errfunc0("doublemultifactorial");
    sprintf(ers(),"The multifactorial index should be positive (called with %i).\n",
      m);
    errfunc2();
  }}
return ret;
}


static long binomialint00(int n,int k,int *recl,int *ovfl)
    /* Function that does the job for binomialint1.
    $A Igor jul04; */
{
long ret,numerator=0,denominator=0;
int overflow=0,i=0,coef,gcd;
++(*recl);
if (k<0)
  return 0;
else if (k==0)
  return 1;
else if (k==1)
  return n;
else if (n<0)
  return (k%2==0?1:-1)*binomialint00(k-n-1,k,recl,ovfl);
else
{
  if (k>n-k)
  {
    k=n-k;
    if (k<0)
      return 0;
    else if (k==0)
      return 1;
  }
  /* Here n>0 & k<0, k<n */
  /*
  if (*recl==1)
  {
    numerator=denominator=1;
    for (i=0;i<k && !overflow;++i)
    {
      if (numerator>LONG_MAX/(n-i) )
      {
        overflow=1;
      }
      numerator*=(n-i);
      denominator*=(k-i);
    }
    if (!overflow)
      return (numerator/denominator);
    else overflow=0;
  }
  */
  /* Direct calculation failed because of overflow, try with recursion: */
  if (k==1)
    return n;
  ret=binomialint00(n,k-1,recl,&overflow);
  if (!overflow)
  {
    /* Return ret*(n-(k-1))/k, which is integer, but check for overflow: */
    coef=n-(k-1);
    if (ret<=LONG_MAX/coef)
    {
      /* Since even ret ret*(n-(k-1)) does not overflow, calculate directly: */
      ret=(ret*coef)/k;
    } else
    {
      /* Product overflows, we must perform division first; Check whether one
      of the terms is divisible by k, or else reduce both by common divisor: */
      if (coef%k==0)
        coef=coef/k;  /* coefficient divisible by k */
      else if (ret%k==0)
        ret=ret/k;    /* lower binomial divisible by k */
      else
      {
        /* Neither coef nor ret is divisible by k, we must find the greatest
        common divisor of coef and k, divide both by it, and then divide 
        ret by the reminder. */
        gcd=greatcomdiv(coef,k);
        coef/=gcd;
        k/=gcd;
        ret/=k;
      }
      if (ret>LONG_MAX/coef)
        overflow=1;
      else
        ret=ret*coef;
    }
  }
  if (overflow)
  {
    *ovfl=1;
    if (*recl==1)
    {
      /* Add error reporting here! */
      printf("!!");
    }
    return 0;
  }
  return ret;
}
}


long binomialint0(int n,int k)
    /* The same as binomialint (see below), except that it DOES NOT report
    an errror in the case of overflow. It may be used when such exceptions
    are handled in the calling scope according to return value (=0) and
    arguments (the binomial coefficient is not 0 when 0<=k<=n or when n<0 and
    k>=0). 
    $A Igor jul04; */
{
int reclevel=0,overflow=0;
long ret;
ret=binomialint00(n,k,&reclevel,&overflow);
if (overflow)
  ret=0;
return ret;
}


long binomialint(int n,int k)
    /* Returns a binomial coefficient n over k C(n,k). By definition,
    C(n,k)=0 for k<0 and k>n, and C(n,k)=n!/((n-k)!*k!). For negative n,
    C(n,k)=(-1)^k*C(k-n-1,k) and for k<0 the coefficient is always 0.
      Warnings:
      On overflow, function returns 0 and reports an error.
      When direct calculation by multiplication causes overflow (which happens
    relatively quickly), recursive formulae are applied in order to try to
    overcome this, which makes the function much slower.
    formulas are applied
    Ref. http://mathworld.wolfram.com/BinomialCoefficient.html
    $A Igor jul04; */
{
int reclevel=0,overflow=0;
long ret;
ret=binomialint00(n,k,&reclevel,&overflow);
if (overflow)
{
  errfunc0("binomialint");
  sprintf(ers(),"Overflow ocurred when calculating binomial coefficient C(%i,%i).\n",
    n,k);
  errfunc2();
  return 0;
}
return ret;
}


double doublebinomial(int n,int k);


double doublebinomial0(int n,int k)
{
    /* Returns the binomial coefficient n over k, or 0 in the case of invalid
    arguments, i.e. n<0.
    $A Igor jul04; */
return doublebinomial(n,k);
}


double doublebinomial(int n,int k)
    /* Returns the binomial coefficient n over k, or 0 in the case of invalid
    arguments, i.e. n<0.
    $A Igor jul04; */
{
double numerator,denominator;
int i;
if (k<0)
  return 0;
else if (k==0)
  return 1;
else if (n<0)
  return (k%2==0?1:-1)*doublebinomial(k-n-1,k);
else
{
  if (k>n-k)
  {
    k=n-k;
    if (k<0)
      return 0;
    else if (k==0)
      return 1;
  }
  numerator=denominator=1.0;
  for (i=0;i<k;++i)
  {
    numerator*=(double) (n-i);
    denominator*=(double) (k-i);
  }
}
return round(numerator/denominator);
}

double doublefallingfactorial(double x,int n);


double doublerisingfactorial(double x,int n)
    /* Returns the rising factorial of x, of range n (=x*(x+1)*...(x+n-1).
    Ref. http://mathworld.wolfram.com/RisingFactorial.html
    By definition, result is 1 for n=0 and x for n=1.
    $A Igor jul06; */
{
double ret,factor;
ret=x;
if (n<0)
{
  ret=doublefallingfactorial((x-1.0),-n);
  if (ret==0)
    return doubleinfinity;
  else
    return 1/ret;
} else if (n==0)
  return 1;
else if (n==1)
  return x;
ret=x;
factor=x+1.0;
while(factor<-0.5+x + (double) n)  
/* account for round-off errors (should be factor<=-1+x+n) */
{
  ret*=factor;
  factor+=1.0;
}
return ret;
}

double doublefallingfactorial(double x,int n)
    /* Returns the falling factorial of x, of range n (=x*(x-1)*...(x-n+1).
    Ref. http://mathworld.wolfram.com/FallingFactorial.html
    By definition, result is 1 for n=0 and x for n=1.
    $A Igor jul06; */
{
double ret,factor;
ret=x;
if (n<0)
{
  ret=doublerisingfactorial((x+1.0),-n);
  if (ret==0)
    return doubleinfinity;
  else
    return 1/ret;
} else if (n==0)
  return 1;
else if (n==1)
  return x;
else if (n<0)
  return 0;
ret=x;
factor=x-1.0;
while(factor>0.5+x - (double) n)  
/* account for round-off errors (should be factor>=x-k+1) */
{
  ret*=factor;
  factor-=1.0;
}
return ret;
}


double num_k_cycles_permgrp(int r,int n,int k)
    /* Returns the number of permutations of order n that have exactly k cycles 
    all of which are of length >=r. Used in definition of the Stirling series
    and gamma function.
    Ref. http://mathworld.wolfram.com/PermutationCycle.html ,
      http://en.wikipedia.org/wiki/Permutation_group
    $A Igor jul06; */
{
if (n<=k*r-1)
 return 0;
else if (k==1)
  return doublefactorial(n-1);
else
  return (n-1)*num_k_cycles_permgrp(r,n-1,k)+
    doublefallingfactorial(n-1,r-1)*num_k_cycles_permgrp(r,n-r,k-1);
}


double gammacoef(int n)
    /* Returns the n-th (n=0, 1, ...) coefficient at z^-n in the formula for
    the gamma function.
    Ref. http://mathworld.wolfram.com/StirlingsSeries.html
      Warning: very slow, inaccurate.
    $A Igor jul06; */
{
static stack cst=NULL;
double *dp;
double ret;
double a,b,c;
int k;
if (n==0)
  return 1;
else if (n<0)
  return 0;
ret=0;
/* Remember calculated values, take them from a table if already calculated: */
if (cst==NULL)
  cst=newstack(1);
if ((dp=nstack(cst,n))!=NULL)
  return *dp;
else
{
  for (k=1;k<=2*n;++k)
  {
    a=num_k_cycles_permgrp(3,2*n+2*k,k);
    b=pow(2.0,(double)(n+k));
    c=doublefactorial(n+k);
    ret+=(k%2==0?1.0:-1.0)*a/(b*c);
  }
  dp=malloc(sizeof(*dp));
  *dp=ret;
  setstack(cst,dp,n);
}
return ret;
}




static int cmpdoubleptrabs(double *ptr1,double *ptr2)
    /* Comparison of two pointers to double, used for sorting the stack in 
    sumdoublestack(). Function returns 0 when at least one of the pointers
    is NULL.
    $A Igor jul04; */
{
if (ptr1==NULL || ptr2==NULL)
  return 0;
else if (fabs(*ptr1)<fabs(*ptr2))
  return -1;
else if (fabs(*ptr1)==fabs(*ptr2))
  return 0;
else return 1;
}

static void pushdoubletostack(stack st,double num)
    /* Adds num as a dynamically allocated double pointer to stack st.
    $A Igor jul04; */
{
double *dp;
if (st!=NULL)
{
  dp=malloc(sizeof(*dp));
  *dp=num;
  pushstack(st,dp);
}
}

static double sumdoublestack(stack st)
    /* Summates numberes on stack st and stores the result in the first number
    on stack. st must contain dynamically allocated pointers to double.
    Summation is done in such a way that pairs of similar numbers (by absolute
    value) are summed consequently (each such summation reduce the number of 
    numbers on stack by half), such that numerical error is reduced.
      Warning:
      Function changes st and its elements.
    $A Igor jul04; */
{
double *dp1,*dp2,*dpres;
int i,j,k,num;
/* Delete empty entries - just for any case, if there are any */
i=1;  /* current first NULL */
while(i<=st->n && st->s[i]!=NULL)
  ++i;
if (i<st->n)
{
  j=i+1;
  while(j<=st->n)
  {
    if (st->s[j]!=NULL)
    {
      st->s[i]=st->s[j];
      ++i;
    }
    ++j;
  }
}
st->n=i-1;
qsortstack(st,cmpdoubleptrabs);
num=st->n;
while(num>1)
{
  /* sum by pairs: */
  k=i=1;
  while(i<=st->n)
  {
    dpres=st->s[k];
    if (st->n>i)
    {
      dp1=st->s[i];
      dp2=st->s[i+1];
      *dpres=*dp1+*dp2;
    } else
    {
      dp1=st->s[i];
      *dpres=*dp1;
    }
    i+=2;
    ++k;
  }
  num=st->n=k-1;
}
if (st->n>0)
{
  dpres=st->s[1];
  return *dpres;
} else
return 0;
}


double bernoullinum(int n)
    /* Returns the n-th Bernouli number. It uses recursive relation 
    Sum[k=0,n-1]((n,k)B(k))=0 where (n,k) is the binomial symbol.
      Caution:
      Calculated coefficient are accurate to 6 decimal places only up to n=37,
    for n>37 they are completely inaccurate.
      Functions stores already calculated values into a table.
    Ref. http://mathworld.wolfram.com/BernoulliNumber.html
    $A Igor jul06; */
{
double ret=0,t1=0,t2=0;
double *dp;
static stack tab=NULL;
static int lock=0;
if (n<0)  /* invalid argument */
  return 0;
else if (n==0)
  return 1;
else if (n==1)
  return -0.5;
else if (n%2==1)  /* even coefficients are 0 */
  return 0;
else
{
  int /* r, */ k;
  /* double sint; */
  m_threadlock(lock);
  if (tab==NULL)
    tab=newstack(5);
  dp=stackel(tab,n);
  m_threadunlock(lock);
  if (dp!=NULL)
    return *dp;
  else
  {
    /* stack st; */
    dp=malloc(sizeof(*dp));
    /*
    st=newstack(20);
    for (k=0;k<=n-1;++k)
      pushdoubletostack(st,
        doublebinomial(n+1,k)*bernoullinum(k)  );
    ret=sumatedoublestack(st);
    */
    ret=0;
    for (k=0;k<=n-1;++k)
      ret+=doublebinomial(n+1,k)*bernoullinum(k);
    /*
    dispstackall(&st);
    */
    ret=-ret/(double)(n+1);
    *dp=ret;
    m_threadlock(lock);
    setstack(tab,dp,n);
    m_threadunlock(lock);
    return ret;
  }
}
return ret;
}


double lngammaplus(double z)
    /* Returns logarithm gamma for z>0!!!
    Stirling's series is used for computation.
    Ref. http://mathworld.wolfram.com/StirlingsSeries.html
    $A Igor jul06; */    
{
int n;
double sum,term,base,accuracy=1e-12;
if (z<=0)
  return 0;   /* invalid argument */
else if (z<8)
{
  return lngammaplus(1+z)-ln(z);
}
base=0.5*ln(2*ConstPi)+(z-0.5)*ln(z)-z;
sum=0.0;
term=1;
n=1;
while(n<=3 || fabs(term/(fabs(sum)+1.0))>accuracy)
{
  term=bernoullinum(2*n) /
  (2.0*(double) n*(double)(2*n-1)*pow(z,(double)(2*n-1)));
  sum+=term;
  ++n;
  /* printf("."); */
}
/* printf(" "); */
return base+sum;
}



double gamma(double z)
    /* Returns the value of the gamma function at real argument z. It uses the
    asymptotic expansion of the logarithm of gamma for positive arguments and
    the recursive formula gamma(z+1)=z*gamma(z).
    Ref. http://mathworld.wolfram.com/GammaFunction.html
    $A Igor jul04; */
{
if (z==0)
  return doubleinfinity;
else if (z<0)
  return gamma(z+1.0)/z;
else
  return exp(lngammaplus(z));
}


double digamma(double z)
    /* Returns value of the digamma function, defined as the first derivative
    of the natural logarithm of the gamma function, used for calculation of
    the derivative of the gamma function. Calculated by the derivation of the
    series for ln(gamma) (i.e. the Stirling's series).
    Ref. http://mathworld.wolfram.com/DigammaFunction.html
    $A Igor jul04; */
{
int n;
double sum,term,base,accuracy=1e-12;
if (z==0)
  return doubleinfinity;
else if (z<8)
  return digamma(z+1.0)-1.0/z;
/*
z=z-1.0;
base=ln(z)+0.5/z;
sum=0.0;
term=1;
n=1;
while(n<=3 || fabs(term/(fabs(sum)+1.0))>accuracy)
{
  term=bernoullinum(2*n) /
  (2.0*(double) n * pow(z,(double)(2*n)));
  sum+=term;
  ++n;
}
return base-sum;
*/
base=ln(z)-0.5/z;
sum=0.0;
term=1;
n=1;
while(n<=3 || fabs(term/(fabs(sum)+1.0))>accuracy)
{
  term=-bernoullinum(2*n) /
  (2.0*(double) n * pow(z,(double)(2*n)));
  sum+=term;
  ++n;
}
return base+sum;
}



double trigamma(double z)
    /* Returns value of the digamma function, defined as the second derivative
    of the natural logarithm of the gamma function, used for calculation of
    the second derivative of the gamma function. Calculated by the derivation
    of the series for ln(gamma).
    Ref. http://mathworld.wolfram.com/TrigammaFunction.html
         http://mathworld.wolfram.com/PolygammaFunction.html
    $A Igor jul04; */
{
int n;
double sum,term,base,accuracy=1e-20;
if (z==0)
  return doubleinfinity;
else if (z<8.1)
  return trigamma(z+1.0)+1.0/(z*z);
base=(1.0+2.0*z)/(2.0*(z*z));
sum=0.0;
term=1;
n=1;
while(n<=3 || fabs(term/(fabs(sum)+1.0))>accuracy)
{
  term=bernoullinum(2*n) /
  (/* 2.0* (double) n * */ pow(z,(double)(1+2*n)));
  sum+=term;
  ++n;
}
return base+sum;
}


double polygamma(double z,int r)
    /* Returns value of the polygamma function of range r, defined as the
    (r+1) -th derivative of the natural logarithm of the gamma function, used
    for calculation of the derivatives of the gamma function. Calculated by 
    the derivation of the series for ln(gamma).
    Ref. http://mathworld.wolfram.com/TrigammaFunction.html
         http://mathworld.wolfram.com/PolygammaFunction.html
    $A Igor jul04; */
{
int n,P;
double sum,term,base,accuracy=1e-20;
if (r<0)
{
  return 0;
} else if (r==0)
  return digamma(z);
else if (r==1)
  return trigamma(z);
else if (z==0)
  return doubleinfinity;
else if (z<8.1)
  return polygamma(z+1.0,r)-(r%2==0?1.0:-1.0)*pow(z,(double)(-r-1)) *
           doublefactorial(r);
/*
  return trigamma(z+1.0)+1.0/(z*z);
*/
P=r-1;  /* since we will calculate polygamma by derivation of trigamma, which
           has range r=1 */
/* From trigamma: 
base=(1.0+2.0*z)/(2.0*(z*z));
*/
/* base: P-th der. of 1/z + 0.5* P-th der. of 1/z^2 */
base=doublefactorial(P)*(P%2==0?1.0:-1.0)/pow(z,(double) (P+1));
base+=0.5*doublefactorial(P+1)*(P%2==0?1.0:-1.0)/pow(z, (double) (P+2));
sum=0.0;
term=1;
n=1;
while(n<=3 || fabs(term/(fabs(sum)+1.0))>accuracy)
{
  /* From trigamma: 
  term=bernoullinum(2*n) /
  (pow(z,(double)(1+2*n)));
  */
  /* Term: Bernoulli coef. (2*n) * P-th derivative of 1/x^(2*n+1): */
  term=bernoullinum(2*n) * (P%2==0?1.0:-1.0)
    *doublerisingfactorial((double) (2*n+1),P) / pow(z, (double) (2*n+P+1));

  sum+=term;
  ++n;
}
return base+sum;
}




double dergamma(double z)
    /* Returns the first derivative of the gamma function. Calculated through
    the digamma function, which is the derivative of the logarithm of gamma.
    $A Igor jul04; */
{
return gamma(z)*digamma(z);
}


double der2gamma(double z)
    /* Returns the second derivative of the gamma function. Calculated through
    the digamma and trigamma functions (i.e. first and second derivatives of
    logarithm of gamma).
    $A Igor jul04; */
{

/*
return gamma(z)*trigamma(z)+pow(dergamma(z),2.0)/gamma(z);
*/
return gamma(z)*(pow(digamma(z),2.0)+trigamma(z));
}



    /* SESTEVANJE V CIKLICNIH GRUPAH: */



int mapcyclicshift(int length,int shift,long num)
  /* Maps the number num to an element of the cyclic group with number of
  elements length (0 thru length-1) and shifts it by shift.
  $AS Igor dec02; */
{
if (length<=0)
{
  errfunc0("mapcyclicshift");
  sprintf(ers(),"Invalid length %i of the cyclic group: should be greater than zero!\n",
    length);
  errfunc2();
  num=0;
} else
{
  /*
  return m_mapcyclicshift(length,shift,num);
  */
  
  num-=shift;
  if (num<0)
    num+=(1+abs(num)/length)*length;
  if (num>=length)
    num%=length;
  num+=shift;
}
return (int) num;
}

pluscyclicshift(int length,int shift, long n1,long n2)
  /* Returns a sum of n1 and n1 mapped by the function mapcyclicshift to a
  cyclic group length shifted by shift. Operation result would be the same if
  n1 and n2 would be mapped to a shifted cyclic group first and then they would
  added together.
  $A Igor dec02; */
{
return mapcyclicshift(length,shift,n1+n2);
}

























































































