
#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>




#include <er.h>

#include <mtypes.h>
#include <mat.h>
#include <vec.h>
#include <min1d.h>
#include <minnd.h>


main()
{

system("an r");
system("an r1");
system("an r2");
system("an r3");
system("an r4");




}
