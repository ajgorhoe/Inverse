#include <sysint.h>

#include <math.h>
#include <stdio.h>




#include <er.h>

#include <mtypes.h>
#include <vec.h>
#include <mat.h>






double chi2func(struct _vector meas, struct _vector calc, struct _vector sigma)
       /* Izracuna funkcijo hi-kvadrat iz izmerkov meas, izracunanih vrednosti
          calc in standardnih deviacij izmerkov sigma. */
{
double c,d;
int i;
c=0;
for (i=1; i<=meas.d; ++i)
{
  d=(meas.v[i]-calc.v[i])/sigma.v[i];
  c+=d*d;
}
return(c);
}







/*

double odvod1(double x,double h,double funk(double))
{
return (funk(x+h)-funk(x-h))/(2*h);
}


double odvod(double x,double *h,double funk(double))
{
  double od2,h0,hpom,f1,f2,f3;
  int i;
  hpom=*h+x;
  for (i=1;i<=1;i++)
  {
    od2=5;
    f1=funk(x+*h); f2=funk(x); f3=funk(x-*h);
    od2=f1-2*f2+f3;
    od2/=(*h * *h);
    od2=(funk(x+*h)-2*funk(x)+funk(x-*h))/(*h* *h);
    if (od2!=0 && funk(x)!=0)
    {
      h0=fabs(1.0e-9*funk(x)/(*h*od2));  /*Konstanta je racunalnikova natancnost/
      if (*h/h0>5 || *h/h0<1/5) *h=h0;
    }
  }
  return odvod1(x,*h,funk);
}

*/


vector hpoint, meascalcpoint;

/* Kazalca na vektor korakov pri racunanju odvodov in na vektor trenutnih
izracunanih meritev. Skrbita za prenos podatkov med funkcijo levmarq in
ustrezno pomozno funkcijo za numericno racunanje odvodov. */

double *numerrpoint;

/* Kazalec na numericno natancnost pri racunanju funkcije; Tudi ta kazalec
skrbi za prenos podatkov med funkcijo levmarq in ustrezno pomozno funkcijo
za numericno racunanje odvodov. */

static double funk(double x)
{
  return 0;
}


double levmarqder(struct _vector a,int whichmeas,int whichpar,
                  void lmfunc(struct _vector,struct _vector *))
        /* Funkcija, ki numericno izracuna odvode za Levenberg-Marquardtovo
        metodo. */
{
int numit=1; /* Stevilo iteracij pri nastavljanju koraka */
double numerr=1.0e-9; /* relativna natancnost pri racunanju funkcije */
double od2,h0,f1,f2,f3,dvalue;
double h,x;
int i;
char end=0;
struct _vector param={0},meascalc={0};
copyvec(&param,&a);
copyvec(&meascalc,meascalcpoint);
h=hpoint->v[whichpar];
x=param.v[whichpar];
/* hpom=h+x; */
for (i=1;i<=numit;i++)  if (! end)
{
  od2=5;
  param.v[whichpar]=a.v[whichpar]+h;
  lmfunc(param,&meascalc);
  f1=meascalc.v[whichmeas];
  f2=meascalcpoint->v[whichmeas];
  param.v[whichpar]=a.v[whichpar]-h;
  lmfunc(param,&meascalc);
  f3=meascalcpoint->v[whichmeas];
  dvalue=(f1-f3)/(2*h);
  od2=f1-2*f2+f3;
  od2/=(h * h);

/*  od2=(funk(x+*h)-2*funk(x)+funk(x-*h))/(*h* *h); */
  if (od2!=0 && funk(x)!=0)
  {
    h0=fabs(numerr*f2/(h*od2));  /*Konstanta je racunalnikova natancnost*/
    if (h/h0>5 || h/h0<1/5)
      h=h0;
    else end=1;
  }
}
hpoint->v[whichpar]=h;
return dvalue;
}



double levmarqdconsth(struct _vector a,int whichmeas,int whichpar,
                  void lmfunc(struct _vector,struct _vector *))
        /* Funkcija, ki numericno izracuna odvode za Levenberg-Marquardtovo
        metodo. */
{
int numit=1; /* Stevilo iteracij pri nastavljanju koraka */
/* double numerr=1.0e-9;*/ /* relativna natancnost pri racunanju funkcije */
double f1,/*f2,*/f3,dvalue;
double h /*,x */;
/* char end=0; */
struct _vector param={0},meascalc={0};
copyvec(&param,&a);
copyvec(&meascalc,meascalcpoint);
h=hpoint->v[whichpar];
/* x=param.v[whichpar]; */
  param.v[whichpar]=a.v[whichpar]+h;
  lmfunc(param,&meascalc);
  f1=meascalc.v[whichmeas];
  /* f2=meascalcpoint->v[whichmeas]; */
  param.v[whichpar]=a.v[whichpar]-h;
  lmfunc(param,&meascalc);
  f3=meascalcpoint->v[whichmeas];
  dvalue=(f1-f3)/(2*h);

return dvalue;
}


void levmarqanalit(struct _vector meas, struct _vector sigma, struct _vector * a,
             struct _vector * meascalc,
             double * chi2, struct _matrix *covar,
             void func(struct _vector, struct _vector *),
             double dfunc(struct _vector, int, int,void basfunc(struct _vector,struct _vector *) ),
             double tol,
             int *it, int maxit, int connection(int), FILE *fp)

      /* Levenberg-Marquardtova metoda. Izracuna nabor parametrov
      modela a, pri katerih se izracunane vrednosti po modelu najbolje
          ujemajo z izmerjenimi vednostmi(po kruteriju hi-kvadrat).
      meas: vektor izmerjenih vrednosti; vhodni podatek.
      sigma: vektor napak izmerkov; vhodni podatek.
      a: vektor parametrov; na vhodu mora biti enak zacetnemu priblizku
          za parametre. Na izhodu zavzame vrednost najboljsih najdenih
          parametrov.
      meascalc: vektor izracunanih vrednosti po izvedbi parametrov.
      chi2: vrednost hi-kvadrat na koncu.
      covar: Kovariancna matrika parametrov
      it: stevilo iteracij. Po izvedbi funkcije se poveca za stevilo
          izvedenih iteracij.
      maxit: najvecje dovoljeno stevilo iteracij.
      connection: funkcija za povezavo z glavnim programom.
      fp: datoteka, kamor se zapisujejo sprotni podatki in obvestila.
      func : fukcija, ki izracuna izracunane vrednosti pri danih parametrih.
          1. parameter je vektor parametrov (vhodni podatek), 2. pa vektor
          izracunanih vrednosti (izhodni podatek).
      dfunc: funkcija, ki izracuna odvode izracunanih vrednosti pri danih
          parametrih. 1. parameter funkcije je vektor parametrov, 2. pove,
          katero izracunano vrednost odvajamo, 3. pa, po katerem parametru
          jo odvajamo. 4. parameter je funkcija, ki izracuna vrednosti pri danih
          parametrih. Funkcija vrne zahtevani odvod.
      Ta metoda je primerna za primere, ko poznamo analiticno funkcijo za odvode
      merjenih vrednosti po parametrih.
      */
{
struct _matrix alpha={0},dmat={0},beta={0},invalpha={0},correction={0};
struct _vector anew={0},meascalcprev={0};
double lambda=0.001,chi2_0,chi2_1,chi2_2,chi2_3,chi2_4,chi2_5;
double w1;
int dimmeas,dimpar,i,j,k,l,itlocal=0,countfail=0;
char end=0;
/* Inicializacija: */
itlocal=0;
dimmeas=meas.d;
dimpar=a->d;
if (meascalc==NULL) getvec(meascalc,dimmeas);
else if (meascalc->d!=dimmeas)
{
  dispvec(meascalc);
  getvec(meascalc,dimmeas);
}
if (covar!=NULL) dispmat(covar);
copyvec(&anew,a);
getmat(&alpha,dimpar,dimpar);
getmat(&dmat,dimmeas,dimpar);
getmat(&beta,dimpar,1);
getmat(&correction,dimpar,1);
/* Izracun izracunanih vrednosti in hi-kvadrat v zacetnem prilbizku */
func(*a,meascalc);
chi2_0=chi2func(meas,* meascalc,sigma);
/* Da ni izpolnjen konvergencni kriterij: */
chi2_1=chi2_2=chi2_3=chi2_4=chi2_5=chi2_0;
/* Kontrolni izpis */
/*
printf("Kontrolni izpis pred glavno zanko:\n\nChi Square: %g\n",chi2_0);
printvecname(meas,"meritev");
printvecname(sigma,"napaka");
printvecname(*a,"parameter");
printvecname(*meascalc,"izrac. meritev");
*/
do   /* Izvajanje iteracije */
{
  ++ itlocal;
  if (itlocal >=maxit) end=1;
  /*
  printf("%i. iteracija: Hi-kvadrat = %g\n",itlocal,chi2_0);
  */

  printf("%i. iteracija: lambda = %g     %g\n",itlocal,lambda,chi2_0);

  /* Najprej izracunamo matriko odvodov, tako da je dmat.m[i][j] odvod i.
  izracunane vrednosti po j. parametru: */
  for (i=1; i<=dimmeas; ++i)
    for (j=1; j<=dimpar; ++j)
      dmat.m[i][j]=dfunc(*a,i,j,func);
  /* Racunanje popravka parametrov */
  /* Racunanje vektorja beta */
  for (i=1; i<=dimpar; ++i)
  {
    beta.m[i][1]=0;
    for (j=1; j<=dimmeas; ++j)
    {
      beta.m[i][1]-=dmat.m[j][i]
       *(meascalc->v[i]-meas.v[i])/(sigma.v[i]*sigma.v[i]);
    }
  }
  /* Racunanja matrike alfa' */
  for (k=1; k<=dimpar; ++k)
  {
    for (l=1; l<=dimpar; ++l)
    {
      alpha.m[k][l]=0;
      for (i=1; i<=dimmeas; ++i)
      {
        alpha.m[k][l]+=dmat.m[i][k]*dmat.m[i][l]/(sigma.v[i]*sigma.v[i]);
      }
      if (k==l) alpha.m[k][l]*=1+lambda;
    }
  }
  /* Resevanje sistema enacb alfa' popravek = beta */

  dispmat(&invalpha);
  dispmat(&correction);

  invalpha=invmat(alpha);
  correction=prodmat(invalpha,beta);
  /* Popravek: */
  for (i=1; i<=dimpar; ++i)
    anew.v[i]+=correction.m[i][1];
  func(anew,meascalc);
  /*
  w3=chi2_2;
  w2=chi2_1;
  */
  w1=chi2_0;
  /*
  printf("chi2_0: %g\n",chi2_0);
  printf("chi2_1: %g\n",chi2_1);
  printf("chi2_2: %g\n",chi2_2);
  */
  chi2_0=chi2func(meas,* meascalc,sigma);
  /*
  printf("chi2_0: %g\n",chi2_0);
  */
  if (chi2_0<w1)
  {
    countfail=0;
    lambda/=10;
    copyvec(a,&anew);
    copyvec(&meascalcprev,meascalc);
    /*
    chi2_1=w1;
    chi2_2=w2;
    */
    chi2_5=chi2_4;
    chi2_4=chi2_3;
    chi2_3=chi2_2;
    chi2_2=chi2_1;
    chi2_1=w1;
    /* Konvergencni kriterij: */
    if (fabs(chi2_5-chi2_0)<=tol)
      end=1;
    /* varnostni ventil: */
    /* if (fabs(chi2_3-chi2_0)<=tol) lambda=1.0e-10; */
  } else
  {
    ++ countfail;
    lambda*=10;
    copyvec(&anew,a);
    copyvec(meascalc,&meascalcprev);
    chi2_0=w1;
    if (lambda>1.0e15) end=1;
    if (countfail>=2) lambda*=10;
    if (countfail>=4) lambda*=10;
  }
} while (! end);
/*
printf("\n&g\n%g\n%g\n%g\n%g\n%g\n%g",lambda,chi2_0,chi2_1,chi2_2,chi2_3,chi2_4,chi2_4);
*/
* it+=itlocal;
/* Racunanja matrike alfa */
for (k=1; k<=dimpar; ++k)
{
  for (l=1; l<=dimpar; ++l)
  {
    alpha.m[k][l]=0;
    for (i=1; i<=dimmeas; ++i)
    {
      alpha.m[k][l]+=dmat.m[i][k]*dmat.m[i][l]/(sigma.v[i]*sigma.v[i]);
    }
  }
}
*covar=invmat(alpha);
*chi2=chi2_0;
dispmat(&alpha);
dispmat(&dmat);
dispmat(&beta);
dispmat(&invalpha);
dispmat(&correction);
dispvec(&anew);
dispvec(&meascalcprev);
}
















void levmarqconsth(struct _vector meas, struct _vector sigma, struct _vector * a,
             struct _vector *h, struct _vector * meascalc,
             double * chi2, struct _matrix *covar,
             void func(struct _vector, struct _vector *),
             double tol,
             int *it, int maxit, int connection(int), FILE *fp)

      /*
      Odvodi se racunajo s konstantnim korakom, poleg tega pa se z dvema tockama
      namesto s tremi.
      Levenberg-Marquardtova metoda. Izracuna nabor parametrov
      modela a, pri katerih se izracunane vrednosti po modelu najbolje
          ujemajo z izmerjenimi vednostmi(po kruteriju hi-kvadrat).
      meas: vektor izmerjenih vrednosti; vhodni podatek.
      sigma: vektor napak izmerkov; vhodni podatek.
      a: vektor parametrov; na vhodu mora biti enak zacetnemu priblizku
          za parametre. Na izhodu zavzame vrednost najboljsih najdenih
          parametrov.
      h: vektor korakov pri numericnem racunanju odvodov izracunanih vrednosti
          po parametrih. Kazalec na ta vektor je lahko NULL, ce uporabimo
          funkcijo, ki izracuna odvode analiticno !
      meascalc: vektor izracunanih vrednosti po izvedbi parametrov.
      chi2: vrednost hi-kvadrat na koncu.
      covar: Kovariancna matrika parametrov
      it: stevilo iteracij. Po izvedbi funkcije se poveca za stevilo
          izvedenih iteracij.
      maxit: najvecje dovoljeno stevilo iteracij.
      connection: funkcija za povezavo z glavnim programom.
      fp: datoteka, kamor se zapisujejo sprotni podatki in obvestila.
      func : fukcija, ki izracuna izracunane vrednosti pri danih parametrih.
          1. parameter je vektor parametrov (vhodni podatek), 2. pa vektor
          izracunanih vrednosti (izhodni podatek).
      dfunc: funkcija, ki izracuna odvode izracunanih vrednosti pri danih
          parametrih. 1. parameter funkcije je vektor parametrov, 2. pove,
          katero izracunano vrednost odvajamo, 3. pa, po katerem parametru
          jo odvajamo. 4. parameter je funkcija, ki izracuna vrednosti pri danih
          parametrih. Funkcija vrne zahtevani odvod.

      */
{
struct _matrix alpha={0},dmat={0},beta={0},invalpha={0},correction={0};
struct _vector anew={0},meascalcprev={0},meascalcdif={0},adif={0};
double lambda=0.001,chi2_0,chi2_1,chi2_2,chi2_3,chi2_4,chi2_5;
double w1;
int dimmeas,dimpar,i,j,k,l,itlocal=0,countfail=0;
char end=0;
/* Inicializacija: */
itlocal=0;
hpoint=h; meascalcpoint=meascalc; /* Podatki za funkcijo, ki racuna odvode */
dimmeas=meas.d;
dimpar=a->d;
if (meascalc==NULL) getvec(meascalc,dimmeas);
else if (meascalc->d!=dimmeas)
{
  dispvec(meascalc);
  getvec(meascalc,dimmeas);
}
if (covar!=NULL) dispmat(covar);
copyvec(&anew,a);
getvec(&adif,dimpar);
getvec(&meascalcdif,dimmeas);
getmat(&alpha,dimpar,dimpar);
getmat(&dmat,dimmeas,dimpar);
getmat(&beta,dimpar,1);
getmat(&correction,dimpar,1);
/* Izracun izracunanih vrednosti in hi-kvadrat v zacetnem prilbizku */
func(*a,meascalc);
chi2_0=chi2func(meas,* meascalc,sigma);
/* Da ni izpolnjen konvergencni kriterij: */
chi2_1=chi2_2=chi2_3=chi2_4=chi2_5=chi2_0;
/* Kontrolni izpis */
/*
printf("Kontrolni izpis pred glavno zanko:\n\nChi Square: %g\n",chi2_0);
printvecname(meas,"meritev");
printvecname(sigma,"napaka");
printvecname(*a,"parameter");
printvecname(*meascalc,"izrac. meritev");
*/
do   /* Izvajanje iteracije */
{
  ++ itlocal;
  if (itlocal >=maxit) end=1;
  /*
  printf("%i. iteracija: Hi-kvadrat = %g\n",itlocal,chi2_0);
  */
  /*
  printf("%i. iteracija: lambda = %g     %g\n",itlocal,lambda,chi2_0);
  */
  /* Najprej izracunamo matriko odvodov, tako da je dmat.m[i][j] odvod i.
  izracunane vrednosti po j. parametru: */
  for (j=1; j<=dimpar; ++j)
  {
    /* Izracunamo meritve pri spremenjenih parametrih (j. parameter je
    povecan za h.v[j]): */
    a->v[j]+=h->v[j];  /* Najprej spremenimo vektor parametrov*/
    func(*a,&meascalcdif); /* Izracun meritev */
    a->v[j]-=h->v[j];  /* Vektor parametrov popravimo nazaj na prejsnjo vrednost*/
    for (i=1; i<=dimmeas; ++i)
    {
      dmat.m[i][j]=(meascalcdif.v[i]-meascalc->v[i])/h->v[j];
    }
  }

  /* Racunanje popravka parametrov */
  /* Racunanje vektorja beta */
  for (i=1; i<=dimpar; ++i)
  {
    beta.m[i][1]=0;
    for (j=1; j<=dimmeas; ++j)
    {
      beta.m[i][1]-=dmat.m[j][i]
       *(meascalc->v[i]-meas.v[i])/(sigma.v[i]*sigma.v[i]);
    }
  }
  /* Racunanja matrike alfa' */
  for (k=1; k<=dimpar; ++k)
  {
    for (l=1; l<=dimpar; ++l)
    {
      alpha.m[k][l]=0;
      for (i=1; i<=dimmeas; ++i)
      {
        alpha.m[k][l]+=dmat.m[i][k]*dmat.m[i][l]/(sigma.v[i]*sigma.v[i]);
      }
      if (k==l) alpha.m[k][l]*=1+lambda;
    }
  }
  /* Resevanje sistema enacb alfa' popravek = beta */

  dispmat(&invalpha);
  dispmat(&correction);

  invalpha=invmat(alpha);
  correction=prodmat(invalpha,beta);
  /* Popravek: */
  for (i=1; i<=dimpar; ++i)
    anew.v[i]+=correction.m[i][1];
  func(anew,meascalc);
  /*
  w3=chi2_2;
  w2=chi2_1;
  */
  w1=chi2_0;
  /*
  printf("chi2_0: %g\n",chi2_0);
  printf("chi2_1: %g\n",chi2_1);
  printf("chi2_2: %g\n",chi2_2);
  */
  chi2_0=chi2func(meas,* meascalc,sigma);
  /*
  printf("chi2_0: %g\n",chi2_0);
  */
  if (chi2_0<w1)
  {
    countfail=0;
    lambda/=10;
    copyvec(a,&anew);
    copyvec(&meascalcprev,meascalc);
    /*
    chi2_1=w1;
    chi2_2=w2;
    */
    chi2_5=chi2_4;
    chi2_4=chi2_3;
    chi2_3=chi2_2;
    chi2_2=chi2_1;
    chi2_1=w1;
    /* Konvergencni kriterij: */
    if (fabs(chi2_5-chi2_0)<=tol)
      end=1;
    /* varnostni ventil: */
    /* if (fabs(chi2_3-chi2_0)<=tol) lambda=1.0e-10; */
  } else
  {
    ++ countfail;
    lambda*=10;
    copyvec(&anew,a);
    copyvec(meascalc,&meascalcprev);
    chi2_0=w1;
    if (lambda>1.0e15) end=1;
    if (countfail>=2) lambda*=10;
    if (countfail>=4) lambda*=10;
  }
} while (! end);
/*
printf("\n&g\n%g\n%g\n%g\n%g\n%g\n%g",lambda,chi2_0,chi2_1,chi2_2,chi2_3,chi2_4,chi2_4);
*/
* it+=itlocal;
/* Racunanja matrike alfa */
for (k=1; k<=dimpar; ++k)
{
  for (l=1; l<=dimpar; ++l)
  {
    alpha.m[k][l]=0;
    for (i=1; i<=dimmeas; ++i)
    {
      alpha.m[k][l]+=dmat.m[i][k]*dmat.m[i][l]/(sigma.v[i]*sigma.v[i]);
    }
  }
}
*covar=invmat(alpha);
*chi2=chi2_0;
dispvec(&adif);
dispvec(&meascalcdif);
dispmat(&alpha);
dispmat(&dmat);
dispmat(&beta);
dispmat(&invalpha);
dispmat(&correction);
dispvec(&anew);
dispvec(&meascalcprev);
}
























void levmarq1(struct _vector meas, struct _vector sigma, struct _vector * a,
             struct _vector *h, struct _vector * meascalc,
             double * chi2, struct _matrix *covar,
             void func(struct _vector, struct _vector *),
             double dfunc(struct _vector, int, int,void basfunc(struct _vector,struct _vector *) ),
             double tol,
             int *it, int maxit, int connection(int), FILE *fp)

      /* Levenberg-Marquardtova metoda. Izracuna nabor parametrov
      modela a, pri katerih se izracunane vrednosti po modelu najbolje
          ujemajo z izmerjenimi vednostmi(po kruteriju hi-kvadrat).
      meas: vektor izmerjenih vrednosti; vhodni podatek.
      sigma: vektor napak izmerkov; vhodni podatek.
      a: vektor parametrov; na vhodu mora biti enak zacetnemu priblizku
          za parametre. Na izhodu zavzame vrednost najboljsih najdenih
          parametrov.
      h: vektor korakov pri numericnem racunanju odvodov izracunanih vrednosti
          po parametrih. Kazalec na ta vektor je lahko NULL, ce uporabimo
          funkcijo, ki izracuna odvode analiticno !
      meascalc: vektor izracunanih vrednosti po izvedbi parametrov.
      chi2: vrednost hi-kvadrat na koncu.
      covar: Kovariancna matrika parametrov
      it: stevilo iteracij. Po izvedbi funkcije se poveca za stevilo
          izvedenih iteracij.
      maxit: najvecje dovoljeno stevilo iteracij.
      connection: funkcija za povezavo z glavnim programom.
      fp: datoteka, kamor se zapisujejo sprotni podatki in obvestila.
      func : fukcija, ki izracuna izracunane vrednosti pri danih parametrih.
          1. parameter je vektor parametrov (vhodni podatek), 2. pa vektor
          izracunanih vrednosti (izhodni podatek).
      dfunc: funkcija, ki izracuna odvode izracunanih vrednosti pri danih
          parametrih. 1. parameter funkcije je vektor parametrov, 2. pove,
          katero izracunano vrednost odvajamo, 3. pa, po katerem parametru
          jo odvajamo. 4. parameter je funkcija, ki izracuna vrednosti pri danih
          parametrih. Funkcija vrne zahtevani odvod.

      */
{
struct _matrix alpha={0},dmat={0},beta={0},invalpha={0},correction={0};
struct _vector anew={0},meascalcprev={0};
double lambda=0.001,chi2_0,chi2_1,chi2_2,chi2_3,chi2_4,chi2_5;
double w1;
int dimmeas,dimpar,i,j,k,l,itlocal=0,countfail=0;
char end=0;
/* Inicializacija: */
itlocal=0;
hpoint=h; meascalcpoint=meascalc; /* Podatki za funkcijo, ki racuna odvode */
dimmeas=meas.d;
dimpar=a->d;
if (meascalc==NULL) getvec(meascalc,dimmeas);
else if (meascalc->d!=dimmeas)
{
  dispvec(meascalc);
  getvec(meascalc,dimmeas);
}
if (covar!=NULL) dispmat(covar);
copyvec(&anew,a);
getmat(&alpha,dimpar,dimpar);
getmat(&dmat,dimmeas,dimpar);
getmat(&beta,dimpar,1);
getmat(&correction,dimpar,1);
/* Izracun izracunanih vrednosti in hi-kvadrat v zacetnem prilbizku */
func(*a,meascalc);
chi2_0=chi2func(meas,* meascalc,sigma);
/* Da ni izpolnjen konvergencni kriterij: */
chi2_1=chi2_2=chi2_3=chi2_4=chi2_5=chi2_0;
/* Kontrolni izpis */
/*
printf("Kontrolni izpis pred glavno zanko:\n\nChi Square: %g\n",chi2_0);
printvecname(meas,"meritev");
printvecname(sigma,"napaka");
printvecname(*a,"parameter");
printvecname(*meascalc,"izrac. meritev");
*/
do   /* Izvajanje iteracije */
{
  ++ itlocal;
  if (itlocal >=maxit) end=1;
  /*
  printf("%i. iteracija: Hi-kvadrat = %g\n",itlocal,chi2_0);
  */
  /*
  printf("%i. iteracija: lambda = %g     %g\n",itlocal,lambda,chi2_0);
  */
  /* Najprej izracunamo matriko odvodov, tako da je dmat.m[i][j] odvod i.
  izracunane vrednosti po j. parametru: */
  for (i=1; i<=dimmeas; ++i)
    for (j=1; j<=dimpar; ++j)
      dmat.m[i][j]=dfunc(*a,i,j,func);
  /* Racunanje popravka parametrov */
  /* Racunanje vektorja beta */
  for (i=1; i<=dimpar; ++i)
  {
    beta.m[i][1]=0;
    for (j=1; j<=dimmeas; ++j)
    {
      beta.m[i][1]-=dmat.m[j][i]
       *(meascalc->v[i]-meas.v[i])/(sigma.v[i]*sigma.v[i]);
    }
  }
  /* Racunanja matrike alfa' */
  for (k=1; k<=dimpar; ++k)
  {
    for (l=1; l<=dimpar; ++l)
    {
      alpha.m[k][l]=0;
      for (i=1; i<=dimmeas; ++i)
      {
        alpha.m[k][l]+=dmat.m[i][k]*dmat.m[i][l]/(sigma.v[i]*sigma.v[i]);
      }
      if (k==l) alpha.m[k][l]*=1+lambda;
    }
  }
  /* Resevanje sistema enacb alfa' popravek = beta */

  dispmat(&invalpha);
  dispmat(&correction);

  invalpha=invmat(alpha);
  correction=prodmat(invalpha,beta);
  /* Popravek: */
  for (i=1; i<=dimpar; ++i)
    anew.v[i]+=correction.m[i][1];
  func(anew,meascalc);
  /*
  w3=chi2_2;
  w2=chi2_1;
  */
  w1=chi2_0;
  /*
  printf("chi2_0: %g\n",chi2_0);
  printf("chi2_1: %g\n",chi2_1);
  printf("chi2_2: %g\n",chi2_2);
  */
  chi2_0=chi2func(meas,* meascalc,sigma);
  /*
  printf("chi2_0: %g\n",chi2_0);
  */
  if (chi2_0<w1)
  {
    countfail=0;
    lambda/=10;
    copyvec(a,&anew);
    copyvec(&meascalcprev,meascalc);
    /*
    chi2_1=w1;
    chi2_2=w2;
    */
    chi2_5=chi2_4;
    chi2_4=chi2_3;
    chi2_3=chi2_2;
    chi2_2=chi2_1;
    chi2_1=w1;
    /* Konvergencni kriterij: */
    if (fabs(chi2_5-chi2_0)<=tol)
      end=1;
    /* varnostni ventil: */
    /* if (fabs(chi2_3-chi2_0)<=tol) lambda=1.0e-10; */
  } else
  {
    ++ countfail;
    lambda*=10;
    copyvec(&anew,a);
    copyvec(meascalc,&meascalcprev);
    chi2_0=w1;
    if (lambda>1.0e15) end=1;
    if (countfail>=2) lambda*=10;
    if (countfail>=4) lambda*=10;
  }
} while (! end);
/*
printf("\n&g\n%g\n%g\n%g\n%g\n%g\n%g",lambda,chi2_0,chi2_1,chi2_2,chi2_3,chi2_4,chi2_4);
*/
* it+=itlocal;
/* Racunanja matrike alfa */
for (k=1; k<=dimpar; ++k)
{
  for (l=1; l<=dimpar; ++l)
  {
    alpha.m[k][l]=0;
    for (i=1; i<=dimmeas; ++i)
    {
      alpha.m[k][l]+=dmat.m[i][k]*dmat.m[i][l]/(sigma.v[i]*sigma.v[i]);
    }
  }
}
*covar=invmat(alpha);
*chi2=chi2_0;
dispmat(&alpha);
dispmat(&dmat);
dispmat(&beta);
dispmat(&invalpha);
dispmat(&correction);
dispvec(&anew);
dispvec(&meascalcprev);
}













































































































































