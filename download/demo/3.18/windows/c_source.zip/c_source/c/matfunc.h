#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>



#include <mtypes.h>
#include <er.h>
#include <vec.h>
#include <mat.h>
#include <st.h>
#include <rf.h>
#include <matrixop.h>
#include <rand.h>
#include <strop.h>
#include <mtime.h>
#include <spmat.h>
#include <smat.h>




            /**********************/
            /*                    */
            /*   TEST FUNCTIONS   */
            /*                    */
            /**********************/


/****************************************************************************/


double testLDLTlow1(matrix m,matrix *L,matrix *D,matrix *U,char print)
    /* Funkcija za testiranje dekompozicije LDLT za simetricne matrike. m je
    matrika, iz katere delamo dekompozicijo, v L, D in U pa se zapisejo
    faktorji. Ce je print razlicen od 0, se rezultati postopka izpisejo ze
    v sami funkciji. Dekompozicija se izvede na spodnjem trikotniku matrike po
    1. postopku (to je po vrsticah), originalna matrika se unici.
    Funkcija vrne cas, ki se porabi za dekompozicijo matrike.
    $A Igor sep00; */
{
int dim,i,j,k;
double val,t1=0,t2=0;
matrix mcopy=NULL;
if (m==NULL)
{
  errfunc0("testLDLTlow");
  fprintf(erf(),"NULL matrix.\n");
  errfunc2();
} else if ((dim=m->d1)<1 || m->d2!=dim)
{
  errfunc0("testLDLTlow");
  fprintf(erf(),"Inconsistent dimansions (d1 = %i, d2 = %i).\n",m->d1,m->d2);
  errfunc2();
} else
{
  if (print)
  {
    printf("\n\nTesting algorithm for LDLT decomposition....\n\n");
    printf("Original matrix:\n");
    printmatrix(m);
    printf("\n");
  }
  zeromat0(m->d1,m->d2,L);
  zeromat0(m->d1,m->d2,U);
  zeromat0(m->d1,m->d2,D);
  copymatrix0(m,&mcopy);
  /* Izvedba dekompozicije LDLT: */
  t1=cputime();
  for (i=1;i<=dim;++i)
  {
    for (j=1;j<i;++j)
    {
      val=m->m[i][j];
      for (k=1;k<j;++k)
        val-=m->m[i][k]*m->m[j][k]*m->m[k][k];
      m->m[i][j]=val/m->m[j][j];
    }
    val=m->m[i][i];
    for (k=1;k<i;++k)
      val-=m->m[i][k]*m->m[i][k]*m->m[k][k];
    if (val==0)
    {
      errfunc0("testLDLTlow");
      fprintf(erf(),"Singular matrix.\n");
      errfunc2();
      dispmatrix(L);
      dispmatrix(U);
      dispmatrix(D);
      return;
    } else
      m->m[i][i]=val;
  }
  t2=cputime();
  /* Prepis elementov v matrike L, D in U (=transp(L)): */
  for (i=1;i<=m->d1;++i)
  {
    (*L)->m[i][i]=(*U)->m[i][i]=1;
    (*D)->m[i][i]=m->m[i][i];
    for (j=1;j<i && j<=m->d2;++j)
      (*L)->m[i][j]=(*U)->m[j][i]=m->m[i][j];
  }
  if (print)
  {
    matrix a=NULL;
    matprod0(*L,*D,&a);
    matprod0(a,*U,&a);
    printf("\nLDLT product:\n");
    printmatrix(a);
    printf("\nMatrix L:\n");
    printmatrix(*L);
    printf("\nMatrix D:\n");
    printmatrix(*D);
    matdif0(a,mcopy,&a);
    printf("\nDifference between the original matrix and its LDLT product:\n");
    printmatrix(a);
    printf("\n\n");
    dispmatrix(&a);
    printf("\nCPU time needed for decomposition: %g s.\n",t2-t1);
  }
}
dispmatrix(&mcopy);
printf("\nCPU time needed for decomposition: %g s.\n",t2-t1);
return t2-t1;
}



double testspLDLTlow1(matrix m,char print)
    /* Funkcija za testiranje dekompozicije LDLT za simetricne matrike. m je
    matrika, iz katere delamo dekompozicijo vanjio se zapisejo tudi faktorji
    dekompozicije. Ce je print razlicen od 0, se rezultati postopka izpisejo ze
    v sami funkciji. Dekompozicija se izvede na spodnjem trikotniku matrike po
    1. postopku (to je po vrsticah), originalna matrika se unici.
    Funkcija vrne cas, ki se porabi za dekompozicijo razprsene matrike.
    Ce je print 1, se izpise primerjava med dekompozicijo izvedeno na razprseni
    matriki in dekompozicijo izvrseno na realni matriki.
    $A Igor sep00; */
{
matrix copym=NULL,L=NULL,D=NULL,U=NULL;
spmat sm=NULL;
double tfull,t1,t2;
int i,j;
if (print)
{
  printf("\n\nTesting algorithm for LDLT decomposition of sparse matrices....\n\n");
  printf("Original matrix:\n");
  printmatrix(m);
  printf("\n");
}
copymatrixlowtospmat(m,&sm,10);

printf("St. zasedenih mest pri matriki sm pred dekompozicijo:\n");
for (i=1;i<=sm->d1;++i)
{
  if (i%50==0)
    printf("%i:%i ",i,sm->m[i]->it->n);
}
printf("\n");

t1=cputime();
spLDLTdecomplowrow(sm);
t2=cputime();
printf("\nCPU time for decomposition of sparse matrix: %g s.\n\n\n",t2-t1);
copymatrixlowtospmat(m,&sm,10);
t1=cputime();
spLDLTdecomplowrow(sm);
t2=cputime();
printf("\nCPU time for second decomposition of the same sparse matrix: %g s.\n\n\n",t2-t1);
tfull=testLDLTlow1(m,&L,&D,&U,0);
printf("\nCPU time for decomposition of full matrix:   %g s.\n",tfull);
if (print)
{
  matdif0(m,L,&L);
  printf("\nDifference between full decomposition and lower triangle:\n");
  printmatrix(L);
  matdif0(m,D,&D);
  printf("\nDifference between full decomposition and diagonal:\n");
  printmatrix(D);
  copyspmattomatrix(sm,&L);
  matdif0(m,L,&L);
  printf("\nDifference between full and sparse decomposition:\n");
  printmatrix(L);
  for (i=1;i<=L->d1;++i)
  {
    for (j=1;j<=L->d2 && j<=i;++j)
      printf("%g ",L->m[i][j]);
    printf("\n");
  }
  printf("\nCPU time for decomposition of full matrix:   %g s.\n",tfull);
  printf("\nCPU time for decomposition of sparse matrix: %g s.\n\n",t2-t1);
}
dispmatrix(&L); dispmatrix(&D); dispmatrix(&U);
return (t2-t1);
}







main()
{
 
matrix A=NULL,A1=NULL,A2=NULL,B=NULL,B1=NULL,B2=NULL,B3=NULL,C=NULL;
matrix V=NULL,Q=NULL,X=NULL,L=NULL,U=NULL,D=NULL;
vector x=NULL,y=NULL,u=NULL,v=NULL,b=NULL,b1=NULL,b2=NULL,b3=NULL;
int i,j,k,lm,m=20,n=1000,ex=100,al=0;
double d,e,t1,t2,t3,seed;
indtab it=NULL,it1=NULL;
stack st=NULL;

int *ptrs=NULL,*cumptrs=NULL,*indxs=NULL;
double *diag=NULL,*coefs=NULL;

double ddim1=4,ddim2=4,dwhich=11,dnum=2,dpar1=-1,dpar2=3,dcont=1;

spmat SA=NULL,SB=NULL,SC=NULL;

smat sA=NULL,sB=NULL,sC=NULL;


timeinitrand();
/*
printf("Seed for random generator: "); readdouble(&seed);
initrand((int) seed);   printf("\n");
*/



randmatsp0(ddim1,ddim2,dwhich,dnum,dpar1,dpar2,&A);
printf("\n\n");

printf("Full matrix:\n");
printmatrix(A);

copymatrixtosmat(A,&sA);
printf("\n\nSparse copy in long form:\n");
printsmatfull(sA);
printf("\n\nSparse copy in natural form:\n");
printsmat(sA);
printf("\n\nSparse copy in line form:\n");
printsmatline(sA);

exit(1);


testspLDLTlow1(A,0);

exit(1);

copymatrixlowtospmat(A,&SA,20);



/* copyspmat(SA,&SB); /* Shranemo original */

copymatrixlowtospmat(A,&SB,20);

printf("St. rezerviranih mest pri matriki SA pred dekompozicijo:\n");
for (i=1;i<=SA->d1;++i)
{
  if (i%50==0)
    printf("%i:%i ",i,SA->m[i]->it->r);
}
printf("\n");




t1=cputime();
spLDLTdecomplowrow(SA);
t2=cputime();
printf("\nCPU time for decomposition of sparse matrix SA: %g s.\n\n",t2-t1);

printf("St. rezerviranih mest pri matriki SA po dekompoziciji:\n");
for (i=1;i<=SA->d1;++i)
{
  if (i%50==0)
    printf("%i:%i ",i,SA->m[i]->it->r);
}
printf("\n");


/* SA postane kopija originalne SA, vendar s toliko alociranega prostora,
kolikor se rabi za dekomponirano SA: */
copyspmat(SB,&SA);

t1=cputime();
spLDLTdecomplowrow(SA);
t2=cputime();
printf("\nCPU time for SECOND decomposition of THE SAME sparse matrix: %g s.\n\n",t2-t1);


/* SA postane kopija originalne SA, vendar s toliko alociranega prostora,
kolikor se rabi za dekomponirano SA: */
copyspmat(SB,&SA);

t1=cputime();
spLDLTdecomplowrow(SA);
t2=cputime();
printf("\nCPU time for THIRD decomposition of THE SAME sparse matrix: %g s.\n\n",t2-t1);


/* SA postane kopija originalne SA, vendar s toliko alociranega prostora,
kolikor se rabi za dekomponirano SA: */
copyspmat(SB,&SA);

t1=cputime();
spLDLTdecomplowrow(SA);
t2=cputime();
printf("\nCPU time for FOURTH decomposition of THE SAME sparse matrix: %g s.\n\n",t2-t1);


printf("St. rezerviranih mest pri matriki SA po dekompoziciji:\n");
for (i=1;i<=SA->d1;++i)
{
  if (i%50==0)
    printf("%i:%i ",i,SA->m[i]->it->r);
}
printf("\n");


/*
testspLDLTlow1(A,0);
testLDLTlow1(A,&L,&D,&U, 0 );
*/
exit(1);

printf("Ispis polne matrike v razprseni obliki:\n");
/*
printmatrixsplinesimp(A);
*/
printf("----\n");
copymatrixtospmat(A,&SA,2);
printf("Izpis razprsene matrike v enostavni obliki:\n");
/*
printspmatline(SA);
*/
printf("----\n");
/*
/printf("Izpis razprsene matrike v dolgi obliki:\n");
printspmat(SA);
printf("----\n");
printf("Izpis zasedenosti razprsene matrike v najkrajsi obliki:\n");
printspmattablinesimp(SA);
printf("----\n");
printf("Izpis zasedenosti razprsene matrike v kratki obliki:\n");
printspmattabline(SA);
printf("----\n");
*/

printf("\nMatrix A:\n");
/*
printmatrix(A);
*/

printf("\nSparse matrix SA:\n");
/*
printspmatline(SA);
*/

printf("\nSparse matrix SA:\n");
/*
printspmatfull(SA);
*/

printf("\nTransponiranje razprsene matrike...\n");
spmattransp(SA,&SA,NULL);

printf("\nTransposed sparse matrix:\n");
/*
printspmatfull(SA);
*/

printf("\nPress <Enter> to continue!\n");  readdouble(&d);

printf("Izpis transponirane razprsene matrike v enostavni obliki:\n");
/*
printspmatline(SA);
*/
printf("----\n");

/* Kopiranje transp. razp. matrike v polno mat. in transponiranje te matrike
nazaj: */
copyspmattomatrix(SA,&B);
mattransp0(B,&B);
printf("\nTwice transp. matrix (B) through sparse transpose:\n");
/*
printmatrix(B);
*/
printmatrixsptablinesimp(B);

printf("\nPress <Enter> to continue!\n");  readdouble(&d);

matdif0(A,B,&C);
printf("\nDifference between the original and twice transposed matrix:\n");
/*
printmatrix(C);
*/
for (i=1;i<=C->d1;++i)
{
  for (j=1;j<=C->d2;++j)
    printf("%g ",C->m[i][j]);
  printf("\n");
}

exit(1);

x=getvector(ddim1);
for (i=1;i<=ddim1;++i)
  x->v[i]=random1();
matprodvec0(A,x,&b1);
spmatprodvec(SA,x,&b2);
printf("Vector b1:\n");
printvectorline(b1);
printf("Vector b2:\n");
printvectorline(b2);
vectordif0(b1,b2,&u);
printf("Vector difference between the two product:\n");
printvectorline(u);


while (dcont)
{
  printf("Type (%g)            : ",dwhich); readdouble(&dwhich);
  printf("First dimension (%g) : ",ddim1); readdouble(&ddim1);
  printf("Second dimension (%g): ",ddim2); readdouble(&ddim2);
  printf("Places per line  (%g): ",dnum); readdouble(&dnum);
  printf("First parameter (%g) : ",dpar1); readdouble(&dpar1);
  printf("Second parameter (%g) : ",dpar2); readdouble(&dpar2);
  
  randmatsp0(ddim1,ddim2,dwhich,dnum,dpar1,dpar2,&A);
  printf("\n\n");
  printmatrixsptablinesimp(A);
  
  /*
  randmatsp0(ddim1,ddim2,dwhich,dnum,dpar1,dpar2,&B);
  matprod0(A,B,&C);
  printf("\nProduct of two sparse matrices:\n");
  printmatrixsptablinesimp(C);
  */
  
  printf("\nPerforming LDLT decomposition...\n");
  t1=cputime();
  LDLTdecomp0(A,&L,&L);
  t2=cputime();
  printf("CPU time: %g (t1=%g, t2=%g).\n",t2-t1,t1,t2);
  
  printf("\nPress <Enter> to continue!\n");  readdouble(&d);
  printf("\nLDLT decomposition of sparse matrix:\n");
  printmatrixsptablinesimp(L);

  /*
  LUdecomptol0(A,&L,&L,&it,&i,0);
  printf("\nLU decomposition of sparse matrix:\n");
  printmatrixsptablinesimp(L);
  */
  
  printf("\n\nContinue (0/1)?\n");  readdouble(&dcont);
  
  
}


exit(1);

timeinitrand();
it=newindtab(1,m);
it1=newindtab(1,m);

randindtabun(it,it1,1,3*m,m,0);



printf("\n"); printindtablinesimp(it1); printindtablinesimp(it); printf("\n");



printf("n=%i, m=%i\n",n,m);
printf("Priprava indeksne tabele:\n");
t1=cputime();
prepspmatindtab(&st,n,ex,al);
t2=cputime();
printf("CPU time: %g (t1=%g, t2=%g).\n",t2-t1,t1,t2);
printf("\nPress <Return>!\n"); readdouble(&e);

/*
printspmatindtab(st);
*/

printf("\nPolnjenje tabele\n\n");
t1=cputime();
for (i=1;i<=n;++i)
  for (j=1;j<=m;++j)
    /*
    d=(double)it->t[j];
    */
    setspmatindtabel(st,i,it->t[j]);
printf("\n\n");
t2=cputime();
printf("CPU time: %g (t1=%g, t2=%g).\n\n",t2-t1,t1,t2);

sortspmatindtab(st);

t3=cputime();

printf("CPU time: %g (sorting %g).\n",t3-t1,t3-t2);

printf("\nPress <Return>!\n"); readdouble(&e);


printf("Transferring data to NASA format...\n");
t1=cputime();
spmatindtabtoNASA(st,&i,&j,&ptrs,&cumptrs,&indxs,&coefs,&diag);
t2=cputime();
printf("Number of equations: %i, number of elements: %i\n",i,j);
printf("CPU time: %g (t1=%g, t2=%g).\n\n",t2-t1,t1,t2);
printf("\nPress <Return>!\n"); readdouble(&e);


printspmatindtab(st);




exit(1);


it=newindtab(2,0);

printf("Po kreaciji:\n");
printindtabline(it);

pushindtab(it,5);
pushindtab(it,10);
pushindtab(it,3);

printf("Po push:\n");
printindtabline(it);

i=popindtab(it);
printf("Zadnji indeks: %i\n",i);
printf("Po pop:\n");
printindtabline(it);

insindtab(it,11,2);
insindtab(it,2,2);
insindtab(it,25,4);
printf("Po ins:\n");
printindtabline(it);


qsortindtab(it);


printf("Po sortiranju:\n");
printindtabline(it);

printf("Iskanje indeksov:\n");
i=2;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=25;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=10;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=11;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=5;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=3;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=1;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=33;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);

printf("\nVrivanje indeksov na enolicen nacin:\n");
i=2;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=1;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=33;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=33;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=11;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=9;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=8;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

printf("\nVrivanje indeksov na neenolicen nacin:\n");
i=2;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

printf("Vrivanje indeksov na enolicen nacin:\n");
i=1;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=33;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=33;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=11;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=9;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=8;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=55;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=45;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=delindtab(it,3);
printf("\nTretji indeks je bil: %i\n",i);
printf("Po brisanju:\n");
printindtabline(it);

exit(1);


randmat0(n,n,0,500,600,&A);

t1=cputime();

LUdecomptol0(A,&L,&U,&it,&i,0);

t2=cputime();
printf("CPU time: %g (t1=%g, t2=%g).\n",t2-t1,t1,t2);
printf("\nPress <Return>!\n"); readdouble(&e);

printf("Matrix L:\n");
printmatrix(L);

printf("Matrix U:\n");
printmatrix(U);

printf("\nParity: %i\n",i);
printf("\nIndex table:\n");
printindtabline(it);

matprod0(L,U,&B);

printf("\nPress <Return>!\n"); readdouble(&e);

printf("Matrix A:\n");
printmatrix(A);

printf("Matrix B:\n");
printmatrix(B);

x=b=NULL;
randvec0(n,0,500,600,&b);
t1=cputime(); printf("\nBacksubstitution...\n\n");

solvLU0(L,U,it,b,&x);

t2=cputime();
printf("CPU time: %g (t1=%g, t2=%g).\n",t2-t1,t1,t2);
printf("\nPress <Return>!\n"); readdouble(&e);

matprodvec0(A,x,&b1);

printf("\nVector b:\n");
printvector(b);

printf("\nVector b1:\n");
printvector(b1);


exit(1);



randmat0(n,n,0,500,600,&A);
randmat0(n,n-1,0,1,1,&B);


matinvGS0(A,&C);

matprod0(A,C,&B);
printf("Matrix B:\n");
printmatrix(B);

exit(1);

printf("Solution of equations...\n");
t1=cputime();

solvmatGS0(A,B,&X);

t2=cputime();
printf("CPU time: %g (t1=%g, t2=%g).\n",t2-t1,t1,t2);
printf("\nPress <Return>!\n"); readdouble(&e);

matprod0(A,X,&B1);

printf("Matrix B:\n");
printmatrix(B);
printf("Matrix B1:\n");
printmatrix(B1);



randmat0(n,n,0,500,600,&V);

Q=copymatrix0(V,NULL);
A=copymatrix0(V,NULL);

/*
printf("Matrix V:\n");
printmatrix(V);
*/
/*
printf("Matrix Q:\n");
printmatrix(Q);
printf("Matrix A:\n");
printmatrix(A);
*/


printf("Orthogonalisation...\n");
t1=cputime();

GSortplain(V,Q,A);

t2=cputime();
printf("CPU time: %g (t1=%g, t2=%g).\n",t2-t1,t1,t2);
printf("\nPress <Return>!\n"); readdouble(&e);

printf("Matrix Q:\n");
printmatrix(Q);
printf("Matrix A:\n");
printmatrix(A);

matinvortplain(Q,A);

matprod0(Q,A,&B);

printf("Matrix B:\n");
printmatrix(B);



exit(1);



/* Test visjenivojske funkcije: */


B2=getmatrix(5,5);
A2=getmatrix(n,n);


GSort0(V,NULL,&A2);

printf("\n\nMatrix A:\n");
printmatrix(A);
printf("\nMatrix A2:\n");
printmatrix(A2);
printf("\n\nMatrix Q:\n");
printmatrix(Q);
printf("\nMatrix B2:\n");
printmatrix(B2);



printf("\n\nMatrix V:\n");
printmatrix(V);



printf("\nPress <Return>!\n"); readdouble(&e);


for (i=1;i<=Q->d2;++i)
  for (j=1;j<=Q->d2;++j)
  {
    d=0;
    for (k=1;k<=Q->d1;++k)
      d+=Q->m[k][i]*Q->m[k][j];
    printf("Scal. prod of %i. and %i. col. of Q: %g\n",i,j,d);
  }


printf("Matrix A:\n");
printmatrix(A);

matprod0(V,A,&B);

printf("Matrix Q:\n");
printmatrix(Q);

printf("Matrix B:\n");
printmatrix(B);


mattranspprodmat0(Q,Q,&B);
printf("Matrix B:\n");
printmatrix(B);


randmat0(n,2,0,500,600,&B1);
copymatrix0(B1,&X);

solvortmatplain(Q,B1,X);

matprod0(Q,X,&B2);

printf("Matrix X:\n");
printmatrix(X);

printf("Matrix B1:\n");
printmatrix(B1);

printf("Matrix B2:\n");
printmatrix(B2);




exit(1);


randmat0(2,3,0,500,600,&A);

printf("Matrix A:\n");
printmatrix(A);

matparttovec0(A,1,2,2,3,&b1);
matparttransptovec0(A,1,2,2,3,&b2);

printf("Vector b1:\n");
printvector(b1);
printf("Vector b2:\n");
printvector(b2);


matparttomat0(A,1,1,2,3,&B1);
matparttransptomat0(A,1,1,2,3,&B2);


printf("Matrix A:\n");
printmatrix(A);

printf("Matrix B1:\n");
printmatrix(B1);

printf("Matrix B2:\n");
printmatrix(B2);




exit(1);



A=getmatrix(1,2);
B=getmatrix(1,2);

A->m[1][1]=2;
A->m[1][2]=3;
B->m[1][1]=5;
B->m[1][2]=7;


B1=getmatrix(2,1);
B2=getmatrix(2,1);

B1=mattranspprodmat0(A,B,&B1);
B2=matprodmattransp0(A,B,&B2);

printf("Matrix A:\n");
printmatrix(A);
printf("Matrix B:\n");
printmatrix(B);
printf("\n\nMatrix B1:\n");
printmatrix(B1);
printf("Matrix B2:\n");
printmatrix(B2);



C=getmatrix(2,1);
C->m[1][1]=5;
C->m[2][1]=7;



A1=getmatrix(1,2);
A2=getmatrix(1,2);

mattranspprodmattransp0(A,C,&A1);
mattranspprodmattransp0(C,A,&A2);


printf("\n\nMatrix C:\n");
printmatrix(C);
printf("\n\nMatrix A1:\n");
printmatrix(A1);
printf("Matrix A2:\n");
printmatrix(A2);




randmat0(3,3,2,500,600,&A);
printf("Matrix A:\n");
printmatrix(A);
mattransp0(A,&A);
printf("Transposed matrix of A:\n");
printmatrix(A);

mattransp0(A,&A);




A1=constmat0(2,3,3.333333,&A1);
printmatrix(A);
printf("Matrix A1:\n");
printmatrix(A1);

randmat0(3,2,2,500,600,&A2);
printf("Matrix A2:\n");
printmatrix(A2);

B=getmatrix(A1->d1,A2->d2);
cprodmat(B,*A1,*A2);
printf("Matrix B:\n");
printmatrix(B);

matprod0(A1,A2,&A1);
/*
printf("Matrix B1:\n");
printmatrix(B1);
printf("Matrix A1:\n");
printmatrix(A1);
*/


printf("Matrix A2:\n");
printmatrix(A2);

B=mattransp0(A2,&B);
printf("Matrix B:\n");
printmatrix(B);

printf("\n\n==\n\n");
randmat0(4,4,2,500,600,&A);
printf("Matrix A:\n");
printmatrix(A);

matprod0(A,mattransp0(A,&B),&B);
printf("Matrix B (A*A^T):\n");
printmatrix(B);


if ((B=LDLTdecomp0(B,&B1,&B2))!=NULL)
  printf("LDLT decomposition successfull.\n");
else
  printf("LDLT decomposition not successful.\n");

printf("Matrix B1 (L fac. LDLT decomp (B)):\n");
printmatrix(B1);


printf("Matrix B2 (D fac. LDLT decomp (B)):\n");
printmatrix(B2);

matprod0(B1,B2,&B2);
matprod0(B2,mattransp0(B1,&B1),&B2);
printf("Matrix B2 (LDLT product):\n");
printmatrix(B2);



exit(1);



matprod0(A,mattransp0(A,&B),&B);
printf("Matrix B (A*A^T):\n");
printmatrix(B);


if ((LLTdecomp0(B,&B1))!=NULL)
  printf("LLT decomposition successfull.\n");
else
  printf("LLT decomposition not successful.\n");

printf("Matrix B1 (L fac. LLT decomp (B)):\n");
printmatrix(B1);


mattransp0(B1,&B2);
printf("Matrix B2 (L transp fac.):\n");
printmatrix(B2);

matprod0(B1,B2,&A1);
printf("Matrix A1 (LLT product):\n");
printmatrix(A1);





exit(1);

/*

getmat(&m1,3,3);
getmat(&m2,3,3);

m1.m[1][1]=123;
m1.m[1][2]=54;
m1.m[1][3]=3224;
m1.m[2][1]=32;
m1.m[2][2]=12;
m1.m[2][3]=43;
m1.m[3][1]=432;
m1.m[3][2]=3;
m1.m[3][3]=43;

m2.m[1][1]=1;
m2.m[1][2]=2;
m2.m[1][3]=3;
m2.m[2][1]=4;
m2.m[2][2]=5;
m2.m[2][3]=6;
m2.m[3][1]=9;
m2.m[3][2]=8;
m2.m[3][3]=7;





m4=cinvmat(&m4,cinvmat(&m4,m1));
printmat(m4);
dispmat(&m4);


m=n=100;
getmat(&m4,m,n);
timeinitrand();
for (i=1; i<=m; ++i)
  for (j=1; j<=n; ++j)
  {
    m4.m[i][j]=random();
  }
m5=cprodmat(&m4,m1,cinvmat(&m3,m4));
printmat(m5);



*/

}






































































