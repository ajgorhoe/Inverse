

#include <sysint.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <er.h>
#include <mtime.h>

static int danebopraznaizvornadatoteka(void)
{
return 0;
}

#ifdef WN16
int system(char *command)
{
  printf("Unable to run system commands in WN16\n");
  return -1;
}
#endif


static void manualsleep(int seconds)
    /* Replacement for sleep, checks ellapsed time in a loop by absolutetime().
    This function halts execution of a thread for at least seconds.
    $A Igor aug04; */
{
static int reported=0;
double t1,t2;
if (!reported)
{
  warnfunc1(1,"sleep");
  sprintf(ers(),"Function sleep() is not available on this system.\n");
  sprintf(ers(),"A loop is used instead; this differs from true sleep in using CPU time.\n");
  warnfunc2();
  reported=1;
}
if (seconds>0)
{
  if (!reported)
  {
    warnfunc1(1,"sleep");
    sprintf(ers(),"Function sleep() is not available on this system.\n");
    sprintf(ers(),"A loop is used instead; this differs from true sleep in using CPU time.\n");
    warnfunc2();
    reported=1;
  }
  t1=t2=absolutetime();
  while(t2<=t1+seconds)
  {
    t2=absolutetime();
  }
}
}

#ifdef VISUALC
  #ifdef ITK
    #include <itk.h>
    void sleep(int seconds)
    {
      Tcl_Sleep(1000*seconds);
    }
  #else
    void sleep(int seconds)
    {
      manualsleep(seconds);
    }
  #endif
#endif


#if 0
#ifdef CFSQP
#include "cfsqp/cfsqpusr.h"  /* header za rutino cfsqp */
#endif
#endif



/* Definition of memory allocatio functions for traceable allocation:
  These functions are defined only for the reason that macros can be defined
in sysint.h which prepend tracing functionality to calls to memory allocation
and deallocation functions. */


void *tr_malloc(int size)
{
return malloc(size);
}

void *tr_calloc(int nelem, int elsize)
{
return calloc(nelem,elsize);
}

void tr_free(void *ptr)
{
free(ptr);
}

void *tr_realloc(void *ptr, int size)
{
return realloc(ptr,size);
}


int tr_mark_mem(char *filename,int linenum,char *function,int size)
    /* Facilitates calling traceable versions of memory allocation and
    deallocation functions.
    $A Igor feb04; */
{
/*
TRDOPR(0,1,"?",function, 
  fprintf(trf(),"Before %s() (%i bytes), line %i of %s",function,size,
    linenum,filename);  fflush(trf());
)
*/
if (tracelockstate()==0)  /* Condition to prevent infinite recursion */
{
  extracecomfunc(NULL,filename,linenum);
  fprintf(trf(),"Before %s() (%i bytes), line %i of %s\n",function,size,
      linenum,filename); fflush(trf());
}
return 1;
}









