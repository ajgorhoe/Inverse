
  /* OPERATIOS ON STRINGS */


#include <sysint.h>

#include <stdlib.h>
/*
#include <string.h>
*/
#include <ctype.h>
#include <limits.h>
#include <stdarg.h>

#include <mtypes.h>
#include <er.h>
#include <rf.h>
#include <t_strop.h>

#include <strop.h>




void disppointer(void **p)
    /* Zbrise kazalec na objekt nesestavljenega tipa *p. Funkcija je napisana
    zato, da se lahko uporabi funkcije, ki imajo med svojimi argumenti tudi
    funkcijo za brisanje objektov, tudi pri enostavnih tipih, za katere taksna
    funkcija ni posebej definirana, saj lahko uporabimo kar free().
    $A Igor apr98; */
{
if (p!=NULL)
{
  if (*p!=NULL)
  {
    free(*p);
    *p=NULL;
  }
}
}


int pointerdatanotnull(void *p,int size)
    /* Returns 0 if memory block of size bytes pointed to by p contains 
    only zeros, or the position (counted from 1) of the first byte that
    is  not 0. This function is usually used for checking that 
    everything is deleted on structures.
    $A Igor aug05; */
{
char *pch;
int ret=0,i;
pch=p;
for (i=0;i<size && !ret; ++i)
{
  if (pch[i]!=0)
    ret=1+i;
}
return ret;
}

int imemchr(void *p,int c,size_t n)
    /* V delu spomina p velikosti n poisce znak c in vrne razliko (v bytih)
    med njegovo pozicijo in p. Ce znaka ne najde, vrne -1.
    $A Igor sep98; */
{
char *pc,*pos;
if (p==NULL)
  return -1;
else
{
  pc=p;
  pos=memchr(p,c,n);
  if (pos!=NULL)
  {
    return (pos-pc);
  } else
    return -1;
}
}


void *memnchr(char *p1,size_t l1,char *p2,size_t l2)
    /* V delu spomina dolzine l1, na katerega kae p1, najde 1. znak, ki je
    vsebovan v nizu p2 dolzine l2. */
{
int i=0,j;
char found=0;
char *ret=p1;
while (!found && i<(int) l1)
{
  j=0;
  while(j<(int) l2)
  {
    if (p2[j]==*ret) found=1;
    ++j;
  }
  ++ret;
  ++i;
}
if (!found)
  ret=NULL;
else
  --ret;
return ret;
}




int imemnchr(char *p1,size_t l1,char *p2,size_t l2)
    /* V delu spomina dolzine l1, na katerega kae p1, najde 1. znak, ki je
    vsebovan v nizu p2 dolzine l2. Vrne razliko med pozicijo tega znaka in p1,
    ce pa znaka ne najde, vrne -1.
    $A Igor sep98; */
{
char *pc,*pos;
pc=p1;
pos=memnchr(p1,l1,p2,l2);
if (pos!=NULL)
{
  return (pos-pc);
} else
  return -1;
}



void *memnotnchr(char *p1,size_t l1,char *p2,size_t l2)
     /* V delu spomina dolzine l1, na katerega kaze p1, najde 1. znak, ki ni
     vsebovan v nizu p2 dolzine l2. */
{
int i=0,j;
char found=0,present;
char *ret=p1;
while (!found && i<(int) l1)
{
  present=0;
  j=0;
  while(j< (int) l2)
  {
    if (p2[j]==*ret) present=1;
    ++j;
  }
  if (!present)
    found=1;
  ++ret;
  ++i;
}
if (!found)
  ret=NULL;
else
  --ret;
return ret;
}



int imemnotnchr(char *p1,size_t l1,char *p2,size_t l2)
     /* V delu spomina dolzine l1, na katerega kae p1, najde 1. znak, ki ni
     vsebovan v nizu p2 dolzine l2 in vrne razliko med pozicijo tega znaka in
     p1. Ce taksnega znaka ne najde, vrne -1.
     $A Igor sep98; */
{
char *pc,*pos;
pc=p1;
pos=memnotnchr(p1,l1,p2,l2);
if (pos!=NULL)
{
  return (pos-pc);
} else
  return -1;
}


char *memfind(char *p1, size_t l1, char *p2, size_t l2)
    /* Poisce 1. pojav spominskega niza p2 dolzine l2 v spominskem nizu p1
    dolzine l1. Vrne kazalec na ta del spomina ali NULL, ce niza ne najde. */
{
char *p,*ret,end=0,equal=0;
ret=NULL;
p=p1;
if (p1==NULL || p2==NULL)
  end=1;
else if( p-p1>  (int) l1- (int) l2 ||  (int) l2> (int) l1)
 end=1;
while (! end)
{
  equal=memcmp(p,p2,l2);
  if (equal==0)
  {
    end=1;
    ret=p;
  }
  ++p;
  if(p-p1> (int) l1- (int) l2)
    end=1;
}
return ret;
}


int imemfind(char *p1, size_t l1, char *p2, size_t l2)
    /* Poisce 1. pojav spominskega niza p2 dolzine l2 v spominskem nizu p1
    dolzine l1. Vrne razliko med pozicijo najdenega niza in p1 oziroma -1, ce
    niza ne najde.
    $A Igor sep98; */
{
char *pc,*pos;
pc=p1;
pos=memfind(p1,l1,p2,l2);
if (pos!=NULL)
{
  return (pos-pc);
} else
  return -1;
}



char *nmemfind(char *p1, size_t l1,stack strst,stack lengthst,int *which)
     /* Najde 1. pojav kateregakoli od nizov, ki so na skladu strst, v nizu p1
     dolzine l1. Glede znakov, ki jih vsebujejo nizi, ni omejitev. Na skladu
     lengthst morajo biti kazalci na dolzine ustreznih nizov na skladu strst,
     in sicer morajo biti te dolzine tipa int.
     funkcija vrne kazalec na 1. najdeni niz, v *which pa zapise, kateri po
     vrsti je ta niz na skladu strst. Ce funkcija ne najde nobenega od nizov,
     vrne NULL, *which pa postane -1.
     */
{
int i;
size_t lmom;
char found=0,*mom,*ret=NULL;
*which=-1;
mom=p1;
lmom=l1; /* Trenutna dolzina od zacetka mom do konza niza, v katerem iscemo */
if (p1!=NULL && strst!=NULL && lengthst!=NULL &&  l1>0)
  if (strst->n>0 && lengthst->n>=strst->n)
    while (lmom>0 && !found)
    {
      /* Za vsak znak v nizu p1 preverimo, ali ni niz znakov, ki se z njim zacne,
      morda enak kateremu od nizov na skladu strst (katerega dolzina je na skladu
      lengthst), */
      for (i=1; i<=strst->n; ++i)
      {
        if (lengthst->s[i]!=NULL && strst->s[i]!=NULL && !found)
          if ( * (int *) lengthst->s[i] > 0 && * (int *) lengthst->s[i] <= (int) lmom)
            if ( memcmp (mom, (char*) strst->s[i], * (int *) lengthst->s[i]) ==0 )
            {
              found=1;
              ret=mom;
              *which=i;
            }
      }
      ++mom;
      --lmom;
    }
return ret;
}



int inmemfind(char *p1, size_t l1,stack strst,stack lengthst,int *which)
    /* Najde 1. pojav kateregakoli od nizov, ki so na skladu strst, v nizu p1
    dolzine l1. Glede znakov, ki jih vsebujejo nizi, ni omejitev. Na skladu
    lengthst morajo biti kazalci na dolzine ustreznih nizov na skladu strst,
    in sicer morajo biti te dolzine tipa int.
    Funkcija vrne razliko med pozicijo najdenega niza in p1, v *which pa
    zapise, kateri po vrsti je ta niz na skladu strst. Ce funkcija ne najde
    nobenega od nizov, vrne -1, tudi *which pa postane -1.
    $A Igor sep98; */
{
char *pc,*pos;
pc=p1;
pos=nmemfind(p1,l1,strst,lengthst,which);
if (pos!=NULL)
{
  return (pos-pc);
} else
  return -1;
}

int memfindall(char *p1, size_t l1, char *p2, size_t l2, stack st)
     /* Poisce vse pojave spominskega niza p2 dolzine l2 v spominskem nizu
     p1 dolzine l1. Vrnestevilo najdenih pojav, hkrati pa na sklad st zaporedoma
     potisne kazalce na stevila tipa int, ki predstavljajo mesta pojav. mesta
     se stejejo od p1 zacensi z 0.
     */
{
char *p,end=0,equal=0;
int ret=0,*a;
p=p1;
if (p1==NULL || p2==NULL)
  end=1;
else if(p-p1> (int) l1- (int) l2 ||  (int) l2> (int) l1)
 end=1;
while (! end)
{
  equal=memcmp(p,p2,l2);
  if (equal==0)
  {
    ++ret;
    a=calloc(1,sizeof(*a));
    *a=p-p1;
    pushstack(st,a);
  }
  ++p;
  if(p-p1> (int) l1- (int) l2)
    end=1;
}
return ret;
}





    /* OPERACIJE S TEKSTOVNIMI NIZI */


int stringlength(char *s)
    /* Safe version of strlen; returns length of string s (i.e. numver of
    characters in *s before the first '\0') of 0 if s is NULL.
    $A Igor jan02; */
{
if (s!=NULL)
  return strlen(s);
else
  return 0;
}

char *makestring(int n)
     /* Rezervira prostor za niz dolzine n in vrne kazalec nanj. Taksen niz
     lahko brises z ukazom free! */
{
  char *ret;
  ret=calloc(n+1,sizeof(char));
  /*
  ret[n]='\0';
  */
  return ret;
}

int sizestring(char *s)
    /* Returns the size of the memory occupied by *s, in bytes.
    $A Igor nov03; */
{
if (s!=NULL)
  return (sizeof(*s)*(1+strlen(s)));
else
  return 0;
}

char *copystring(char *s1,char **s2)
    /* Returns a copy of s1. If s2 is different than NULL then s1 is
    copied to *s2 and *s2 returned, otherwise a dynamic copy of s1 is made
    and returned.
    $A Igor nov03; */
{
char *ret;
if (s2!=NULL)
{
  /* If s2!=NULL, then ss1 is copied to s2: */
  if (s1==NULL)
  {
    disppointer((void **) s2);
  } else
  {
    if (*s2!=NULL)
      disppointer((void **) s2);
    *s2=stringcopy(s1);
  }
  return *s2; /* since s2!=NULL. */
} else
{
  /* s2==NULL, a new object is created that is a copy of ls1 and returned */
  if (s1==NULL)
    return NULL;
  else
  {
    ret=stringcopy(s1);
    return ret;
  }
}
}


char *stringcopy(const char *s)
    /* Returns a dynamically allocated copy of a zero terminated string s.
    $A Igor <==; */
{
size_t l;
char *returned=NULL;
if (s!=NULL)
{
  l=strlen(s);
  ++l; /* Prostor mora biti tudi za zakljucni znak niza */
  returned=calloc(l,sizeof(char));
  strcpy(returned,s);
}
return returned;
}

char *stringncopy(char *s,int n)
     /* Ta funkcija alocira toliko spomina, da lahko nanj
     skopira niz n znakov niza s z zakljucnim znakom '\0' vred (torej n+1),
     skopira n znakov niza s na rezerviran spominski prostor in vrne
     kot rezultat kazalec na ta alociran spomin. Ce ima niz s manj kot
     n znakov, se alocira le toliko znakov, kolikor je potrebno za
     prepis niza. */
{
size_t l;
char *returned=NULL;
if (s!=NULL)
{
  if (s!=NULL)
    l=strlen(s);
  else
    l=0;
  if (n< (int) l)
    l=n;
  /* Prostor mora biti tudi za zakljucni znak niza */
  returned=calloc(l+1,sizeof(char));
  strncpy(returned,s,l);
}
return returned;
}


void stringappend(char **straddr,char *ext)
    /* Appends a zero terminated string pointed to by straddr by the contents
    of a zero terminated string ext. Nothing happens if straddr is NULL.
    $A Igor apr03; */
{
char *ptr;
int length,lengthext;
if (straddr!=NULL)
{
  if (ext!=NULL) if ((lengthext=strlen(ext))>0)
  {
    length=(*straddr==NULL)?0:strlen(*straddr);
    *straddr=realloc(*straddr,length+lengthext+1);
    ptr=(*straddr)+length;
    while(*ext!='\0')
    {
      /*
      *ptr++=*ext++;
      */
      *ptr=*ext;
      ++ ptr;
      ++ ext;
    }
    *ptr='\0';
  }
}
}


void stringinsert(char **straddr,char *ext,int place)
    /* Insert into a zero terminated string pointed to by straddr the content
    of the string ext, at location place (counted from zero). If place is a
    negative number or it is greater or equal than the length of *straddr, then
    the string ext is appended at the end of the string pointed to by straddr.
    Nothing happens if straddr is NULL, if ext is NULL or if ext is an empty
    string. Note that *straddr is usually changed.
      Note: if *addrstr is not null, it must be dynamically allocated!
    $A Igor apr03; */
{
char *ptr,*from,*ins;
int length,lengthext;
if (straddr!=NULL)
{
  if (ext!=NULL) if ((lengthext=strlen(ext))>0)
  {
    length=(*straddr==NULL)?0:strlen(*straddr);
    *straddr=realloc(*straddr,length+lengthext+1);
    if (place>length || place<0)
      place=length;
    /* Shift the part of *straddr after the insertion point to the end,
    including the derminating '\0': */
    ins=*straddr;
    ptr=ins+length+lengthext;  /* points to current character */
    from=ins+length;     /* points to character to copy */
    ins+=place;  /* insertion point */
    while (from>=ins)
    {
      *ptr=*from;
      --ptr;
      --from;
    }
    from=ext+lengthext-1;
    while (from>=ext)
    {
      *ptr=*from;
      --ptr;
      --from;
    }
  }
}
}


char *stringcat(char *s1,char*s2)
     /* Alocira toliko spomina, kot ej potrebno za zapis nizov s1 in s1, nato
     na ta prostor zapise zlepljen niz s1+s2 ter vrne kazalec na alociran
     prostor. niz lahko brises z ukazom free!
     */
{
size_t l1,l2,i;
char *cat;
if (s1!=NULL)
  l1=strlen(s1);
else
  l1=0;
if (s2!=NULL)
  l2=strlen(s2);
else
  l2=0;
cat=calloc(l1+l2+1,sizeof(char)); /* Prostora mora biti tudi za zakljuc. znak. */
if (l1>0) for (i=0;i<l1;++i)
  cat[i]=s1[i];
if (l2>0) for (i=0;i<l2;++i)
  cat[i+l1]=s2[i];
cat[l1+l2]='\0';
return(cat);
}


char *multstringcat(char *first,...)
    /* Zlepi vse argumente kot nize in vrne alociran zlepek zakljucen z '\0'.
    Zadnji argument mora biti NULL, drugace pa je lahko stevilo argumentov
    poljubno. Ce je skupna dolzina nizov enaka 0, vrne funkcija NULL, ceprav je
    kak niz razlicen od NULL (enak ""). NULL je lahko le zadnji argument.
    $A Igor jan02; */
{
int i,j,num=0,length=0;
char *arg=first,*ret=NULL,*ptr;
va_list ap;
va_start(ap,first);
arg=first;
while(arg!=NULL)
{
  num+=1;
  length+=strlen(arg);
  arg=va_arg(ap,char *);
}
if (length>0)
{
  ret=malloc(length+1); /* 1 char. for ending '\0' */
  ret[length]='\0';
  ptr=ret;
  va_start(ap,first);
  arg=first;
  for (i=1;i<=num;++i)
  {
    length=strlen(arg);
    for (j=0;j<length;++j)
    {
      *ptr=arg[j];
      ++ptr;
    }
    arg=va_arg(ap,char *);
  }
}
return ret;
}


char *multstringcatn(int num,char *first,...)
    /* Zlepi vseh n argumentov, ki sledijo num, kot nize in vrne alociran
    zlepek zakljucen z '\0'. Ce je skupna dolzina nizov enaka 0, vrne funkcija
    NULL, ceprav je kak niz razlicen od NULL (enak ""). Katerikoli niz med
    argumenti je lahko NULL, nizovnih arhumentov za num pa mora biti vsaj
    num. Niz, ki se vrne, je dinamicno alociran in se lahko brise s free().
    $A Igor dec02; */
{
int i,j,length=0;
char *arg=first,*ret=NULL,*ptr;
va_list ap;
va_start(ap,first);
arg=first;
for (i=1;i<=num;++i)
{
  if (arg!=NULL)
    length+=strlen(arg);
  arg=va_arg(ap,char *);
}
if (length>0)
{
  ret=malloc(length+1); /* 1 char. for ending '\0' */
  ret[length]='\0';
  ptr=ret;
  va_start(ap,first);
  arg=first;
  for (i=1;i<=num;++i)
  {
    if (arg!=NULL)
      length=strlen(arg);
    else
      length=0;
    for (j=0;j<length;++j)
    {
      *ptr=arg[j];
      ++ptr;
    }
    arg=va_arg(ap,char *);
  }
}
return ret;
}


int cmpstrings(const char *str1,const char *str2)
{
if (str1==NULL)
{
  if (str2==NULL)
    return 0;
  else
    return -1;
} else if (str2==NULL)
  return 1;
else return strcmp(str1,str2);
}

int cmpstrings0(char *str1,char *str2)
    /* Podobno kot standardna funkcija strcmp, le da deluje tudi, ce je kateri
    (ali oba) od nizov str1 in str2 enak NULL.
    $A Igor jan99; */
{
return cmpstrings(str1,str2);
}


int ncmpstrings(char *str1,char *str2,int n)
    /* Similar to the standard function nstrcmp, except that it functions
    properly if one or both strings are NULL.
    $A Igor jul03; */
{
if (str1==NULL)
{
  if (str2==NULL)
    return 0;
  else
    return -1;
} else if (str2==NULL)
  return 1;
else
{
  int i=0,ret=0;
  unsigned char *s1=str1,*s2=str2;
  while (i<n)
  {
    if (*s1<*s2)
      return -1;
    else if (s1>s2)
      return 1;
    ++s1; ++s2; ++i;
  }
  return 0;
}
}


int cmpstringtails(char *str1,char *str2,int n)
    /* Compares the last n characters of strings str1 and str2. It returns the
    same result as cmpstrings() would return on strings comosed of the last n
    characters of str1 and str2, provided that NULL is taken in n exceeds the
    number of characters in the corresponding string.
      The function is used for example for checking if the first file name is
    the same as the second except thet it does not contain the complete path.
    $A Igor jan03; */
{
char *ptr1=NULL,*ptr2=NULL;
int l;
if ((l=stringlength(str1))>=n)
  ptr1=str1+l-n;
if ((l=stringlength(str2))>=n)
  ptr2=str2+l-n;
return cmpstrings(ptr1,ptr2);
}



/* SPECIAL CHARACTER SEQUENCES */


char specialcharacter(char spec)
    /* Vrne znak, ki ustreza specifikaciji spec. Funkcija je narejena za
    pretvarjanje specifikacij posebnih znakov na tistih mestih, kjer ni mozno
    zapisati teh znakov direktno. Ce spec ni dogovorjena specifikacija za kak
    posebni znak, vrne funkcija '0'.
    $A Igor maj98; */
{
switch (spec)
{
  case '\'':
    return '\'';
    break;
  case 'q':
    return '\'';
    break;
  case '\"':
    return '"';
    break;
  case 'Q': case 'd':
    return '"';
    break;
  case '\\':
    return '\\';
    break;
  case '0':
    return '\0';
    break;
  case 'r':
    return '\r';
    break;
  case 'n':
    return '\n';
    break;
  case 't':
    return '\t';
    break;
  case 's':
    return ' ';
    break;
  case '#':
    return '#';
    break;
  case 'h':
    return '#';
    break;
  /* Oklepaji: */
  case '1':
    return '(';
    break;
  case '2':
    return ')';
    break;
  case '3':
    return '[';
    break;
  case '4':
    return ']';
    break;
  case '5':
    return '{';
    break;
  case '6':
    return '}';
    break;
  case '<':
    return '{';
    break;
  case '>':
    return '}';
    break;
  case '(':
    return '(';
  case ')':
    return ')';
  case '[':
    return '[';
  case ']':
    return ']';
  case '{':
    return '{';
  case '}':
    return '}';
    break;
  default:
    /* Ce spec ni dogovorjena specifikacija za kak posebni znak, vrne funkcija
    spec: */
    /* return 'spec'; */
    return spec;
    break;
}
}

int updatespecchar(char *str)
    /* V nizu str spremeni vse specifikacije posebnih znakov (te morajo slediti
    znaku '\') v ustrezne posebne znake. Ce se zaradi tega niz skrajsa, se ne
    alocira prostor zanj na novo. niz str mora biti terminiran z '\0'.
    $A Igor maj98; */
{
int shift=0,pos=0,length=0,ret=0;
char ch;
if (str!=NULL)
{
  length=strlen(str);
  while(pos<=length) /* tudi zakljucni '\0' se mora prepisati. */
  {
    ch=str[pos];
    if (ch=='\\')
    {
      ++pos;
      ch=specialcharacter(str[pos]);
      if (ch=='0')
      {
        /* Ce specifikacija ne pomeni posebnega znaka, se znak '\\' in
        specifikacija dobesedno prepiseta v niz na ustrezni mesti. */
        ret=-1;  /* V nizu je napacna specifikacija. */
        str[pos-shift-1]='\\';
        ch=str[pos];
      } else
        ++shift; /* Samo v primeru, da specifikacija res pomeni poseb. znak */
    }
    /* Prebrani znak prepisemo na (morebiti) premaknjeno pozicijo v str. */
    str[pos-shift]=ch;
    ++pos;
  }
}
return ret;
}



      /* BITWISE OPERATIONS */


    /* PRINTING MEMORY CONTENTS: */

int fprintdatahex(FILE *fp,void *p,int size)
    /* Prints a memory chunk of size bytes pointed to by p as a hexadecimal
    number. Returns the number of bytes written.
    $A Igor jul05; */
{
unsigned char *pbyte;
int length=0;
unsigned int val;
if (fp!=NULL && p!=NULL)
{
  pbyte=(unsigned char *) p;
  pbyte+=size-1;
  while ((void *) pbyte>=p)
  {
    val=*pbyte;
    length+=fprintf(fp,"%02X",val);
    if ((void *) pbyte>p)
    {
      length+=fprintf(fp," ");
    }
    --pbyte;
  }
  length+=fprintf(fp," hex");
}
return length;
}

int printdatahex(void *p,int size)
    /* Prints a memory chunk of size bytes pointed to by p as a hexadecimal
    number. Returns the number of bytes written.
    $A Igor jul05; */
{
return fprintdatahex(stdout,p,size);
}

int sprintdatahex(char *str,void *p,int size)
    /* Prints a memory chunk of size bytes pointed to by p as a hexadecimal
    number, to the string str. The output string str must be allocated with
    sufficient length (3 bytes for each byte + terminating 0 byte + 4 bytes).
      Function returns the length of output in bytes.
    $A Igor jul05; */
{
unsigned char *pbyte;
int length=0;
unsigned int val;
if (str!=NULL && p!=NULL)
{
  pbyte=(unsigned char *) p;
  pbyte+=size-1;
  while ((void *) pbyte>=p)
  {
    val=*pbyte;
    length+=sprintf(str+length,"%02X",val);
    if ((void *) pbyte>p)
    {
      length+=sprintf(str+length," ");
    }
    --pbyte;
  }
  length+=sprintf(str+length," hex");
}
return length;
}



int fprintdataoct(FILE *fp,void *p,int size)
    /* Prints a memory chunk of size bytes pointed to by p as a octal
    number. Returns the number of bytes written.
    $A Igor jul05; */
{
#define tabauxsizeoctbits 10
unsigned char *pbyte;
int length=0,longsize,num,i;
unsigned long *tab,*taballoc=NULL,tabaux[tabauxsizeoctbits];
longsize=sizeof(*tab);
if (fp!=NULL && p!=NULL && size>0)
{
  /* Minimal number of unsigned long numbers to cover size bytes: */
  num=size/longsize;
  if (size%longsize>0)
    ++num;
  if (num>tabauxsizeoctbits)
  {
    /* Auxiliary table tabaux is too small, we need to allocate the table: */
    tab=taballoc=calloc(num,longsize);
  } else
  {
    /* We can use auxiliary table, initialize to 0 (to zero excessive bits): */
    tab=tabaux;  
    for (i=0;i<num;++i)
      tab[i]=0;
  }
  pbyte=(unsigned char *) tab;
  memcpy(pbyte+(num*longsize-size),p,size);
  for (i=0;i<num;++i)
  {
    length+=fprintf(fp,"%Lo ",tab[i]);
  }
  length+=fprintf(fp,"oct");
}
disppointer(&taballoc);
return length;
#undef tabauxsizeoctbits
}

int printdataoct(void *p,int size)
    /* Prints a memory chunk of size bytes pointed to by p as a octal
    number. Returns the number of bytes written.
    $A Igor jul05; */
{
return fprintdatahex(stdout,p,size);
}

int sprintdataoct(char *str,void *p,int size)
    /* Prints a memory chunk of size bytes pointed to by p as a octal
    number, to the string str. The output string str must be allocated with
    sufficient length (4 bytes for each byte + terminating 0 byte + 4 bytes).
      Function returns the length of output in bytes.
    $A Igor jul05; */
{
#define tabauxsizeoctbits 10
unsigned char *pbyte;
int length=0,longsize,num,i;
unsigned long *tab,*taballoc=NULL,tabaux[tabauxsizeoctbits];
longsize=sizeof(*tab);
if (str!=NULL && p!=NULL && size>0)
{
  /* Minimal number of unsigned long numbers to cover size bytes: */
  num=size/longsize;
  if (size%longsize>0)
    ++num;
  if (num>tabauxsizeoctbits)
  {
    /* Auxiliary table tabaux is too small, we need to allocate the table: */
    tab=taballoc=calloc(num,longsize);
  } else
  {
    /* We can use auxiliary table, initialize to 0 (to zero excessive bits): */
    tab=tabaux;  
    for (i=0;i<num;++i)
      tab[i]=0;
  }
  pbyte=(unsigned char *) tab;
  memcpy(pbyte+(num*longsize-size),p,size);
  for (i=0;i<num;++i)
  {
    length+=sprintf(str+length,"%Lo ",tab[i]);
  }
  length+=sprintf(str+length,"oct");
}
disppointer(&taballoc);
return length;
#undef tabauxsizeoctbits
}



int fprintdatabits(FILE *fp,void *p,int size)
    /* Prints the state of all bits from the memory location pointed to by p
    of size bytes, to the file fp. Bits are printed from in the descending
    order of memory address, i.e. from the most to the least significant ones.
      Function returns the number of bytes written.
    $A Igor feb01 apr03; */
{
unsigned char *pbyte,mask,j;
int length=0;
if (fp!=NULL && p!=NULL)
{
  length+=fprintf(fp,"(");
  if (p!=NULL)
  {
    pbyte=(unsigned char *)p;
    pbyte+=size-1;
    while ((void *) pbyte>=p)
    {
      mask=1<<7;
      for (j=1;j<=8;++j)
      {
        length+=fprintf(fp,"%s",(*pbyte&mask)==0? "0": "1");
        mask>>=1;
      }
      if ((void *) pbyte>p)
      {
        length+=fprintf(fp," ");
      }
      --pbyte;
    }
  }
  length+=fprintf(fp,")");
}
return length;
}


int printdatabits(void *p,int size)
    /* Prints the state fo all bits from the memory location pointed to by p
    of size bytes. Bits are printed from in the descending order of memory
    address, i.e. from the most to the least significant ones.
      Function returns the number of bytes written.
    $A Igor feb01 apr03; */
{
return fprintdatabits(stdout,p,size);
}


int sprintdatabits(char *str,void *p,int size)
    /* Prints the state of all bits from the memory location pointed to by p
    of size bytes, to the string str. Bits are printed from in the descending
    order of memory address, i.e. from the most to the least significant ones.
      Function returns the length of output written to str in bytes.
    $A Igor feb01 apr03; */
{
unsigned char *pbyte,mask,j;
int length=0;
if (str!=NULL && p!=NULL)
{
  length+=sprintf(str+length,"(");
  if (p!=NULL)
  {
    pbyte=(unsigned char *)p;
    pbyte+=size-1;
    while ((void *) pbyte>=p)
    {
      mask=1<<7;
      for (j=1;j<=8;++j)
      {
        /*
        putchar((*pbyte&mask)==0? '0': '1');
        */
        length+=sprintf(str+length,"%s",(*pbyte&mask)==0? "0": "1");
        mask>>=1;
      }
      if ((void *) pbyte>p)
      {
        length+=sprintf(str+length," ");
      }
      --pbyte;
    }
  }
  length+=sprintf(str+length,")");
}
return length;
}


int fprintintflags(FILE *fp,int flags)
    /* Prints bit image of integer flags to the file fp.
    Returns the number of written bytes.
    $A Igor apr03; */
{
int length=0;
if (fp!=NULL)
{
  length+=fprintdatahex(fp,&flags,sizeof(flags));
  length+=fprintf(fp," ");
  length+=fprintdatabits(fp,&flags,sizeof(flags));
}
return length;
}


int printintflags(int flags)
    /* Prints bit image of integer flags to the standard output.
    Returns the number of written bytes.
    $A Igor apr03; */
{
return printdatabits(&flags,sizeof(flags));
}


int sprintintflags(char *str,int flags)
    /* Prints bit image of integer flags to the string str. Str must point to
    enough allocated space, normally this should be at least 2+9*sizeof(int)
    bytes.
    Returns the number of written bytes.
    $A Igor apr03; */
{
int length=0;
if (str!=NULL)
{
  length+=sprintdatahex(str+length,&flags,sizeof(flags));
  length+=sprintf(str+length," ");
  length+=sprintdatabits(str+length,&flags,sizeof(flags));
}
return length;
}


int fprintlongflags(FILE *fp,long flags)
    /* Prints bit image of long integer flags to the file fp.
    Returns the number of written bytes.
    $A Igor apr03; */
{
int length=0;
if (fp!=NULL)
{
  length+=fprintdatahex(fp,&flags,sizeof(flags));
  length+=fprintf(fp," ");
  length+=fprintdatabits(fp,&flags,sizeof(flags));
}
return length;
}


int printlongflags(long flags)
    /* Prints bit image of long integer flags to the standard output.
     Returns the number of written bytes.
    $A Igor apr03; */
{
return printdatabits(&flags,sizeof(flags));
}


int sprintlongflags(char *str,long flags)
    /* Prints bit image of long integer flags to the string str. Str must point to
    enough allocated space, normally this should be at least 2+9*sizeof(long)
    bytes. Returns the number of written bytes.
    $A Igor apr03; */
{
int length=0;
if (str!=NULL)
{
  length+=sprintdatahex(str+length,&flags,sizeof(flags));
  length+=sprintf(str+length," ");
  length+=sprintdatabits(str+length,&flags,sizeof(flags));
}
return length;
}


void setallbits(void *p,int size)
    /* Sets all bits in the memory region pointed to by p of size size bytes.
    $A Igor apr03; */
{
int i;
unsigned char *pbyte;
pbyte=p;
for (i=1;i<=size;++i)
{
  *pbyte=0xFF;
  ++pbyte;
}
}


    /* COMFORTABLE READING OF NUMBERS FROM STAND. INPUT */


/* Funkcija za izvrednotenje matematicnih izrazov: */
static double (*evaluateexpression) (char *exp) =NULL;
static void (*sendtocalc) (char *exp) =NULL;
static char *numtype=NULL;

void setstropevaluateexpression(double (*evalexp) (char *exp) )
    /* Nastavi lokalno funkcijo evaluateexpression(), ki se uporablja pri
    izvrednotenju izrazov v funkcijah za branje stevil. Ta funkcija se
    avtomatsko klice v initglobcalc() v simb.c.
    $A Igor jul01; */
{
evaluateexpression=evalexp;
}

void setstropsendtocalc(void (*sendtc) (char *exp) )
    /* Nastavi lokalno funkcijo sendtocalc(), ki se uporablja kot kalkulatorska
    lupina v funkcijah za branje stevil. Ta funkcija se avtomatsko klice v
    initglobcalc() v simb.c.
    $A Igor avg01; */
{
sendtocalc=sendtc;
}

static void proccalccom(char *com)
{
char runshell=0,end=0,*buf,*command;
int buflength=1000; /* Maksimalna dolzina vrstice */
if (sendtocalc==NULL)
{
  printf("Sorry, expression evaluator is not installed.\n");
  return;
}
if (com==NULL)
  runshell=1;
else if (com[0]=='\0')
  runshell=1;
if (runshell)
{
  printf("Type in commands or expressions; \"\\x\" or \"\\q\" for quit, \"\\?\" or \"\\h\" for help.\n\n");
  buf=malloc(buflength);
  while (!end)
  {
    printf("Calc> ");
    buf[0]='\0';
    gets(buf);
    command=memnotnchr(buf,strlen(buf)," ",1);
    if (command[0]=='\\' && (command[1]=='q' || command[1]=='x'))
      end=1;
    else
      sendtocalc(command);
  }
  if (buf!=NULL)
    free(buf);
  printf("\nNew value: ");
}
else
{
  sendtocalc(com);
  printf("\nNew value: ");
}
}

static void printhelpreadnum(void)
{
printf("\nYou are using a function for comfortable insertion of\n%s values.\n",numtype);
printf("Do not begin insertion by a space (\' \') unles you insert a numerical value!\n");
printf("Inserting \'?\' will print this help.\n");
printf("Inserting an alphabetical character will print the current value.\n");
printf("Inserting en empty string (i.e. pressing <Enter>) will keep the current value.\n");
printf("Inserting a new value will update the current value. Standard C forms for\n");
printf("  representing numerical constants can be used.\n");
printf("If a calculator is installed, you cane use mathematical expressions\n");
printf("  to insert a new value. You can insert \'$\' followed by calculator\n");
printf("  variable name (e.g. $a) or an expression in round brackets (e.g.\n");
printf("  (3*sin[(3/4)c_pi]) )\n");
printf("Inserting \"\\c\" will run the calculator shell where you can set new\n");
printf("  variables, expressions and functions or inspect the calculator state\n");
if (evaluateexpression==NULL)
  printf("The calculator is currently NOT INSTALLED.\n");
else
  printf("The calculator is installed, so you can use its functionality.\n");
printf("\nNew value: ");
}

int readdouble(double *a)
    /* Prebere realno stevilo s standardnega vhoda. Ce uporabnik vstavi niz "?"
    namesto stevila, se izpise trenutna vrednost stevila, branje pa se ponovi.
    Ce vstavi niz "", se ohrani stara vrednost. Ce vstavi $ in izraz ali izraz
    v oklepajih (), se izracuna izraz s funkcijo evaluateespression (ce je
    razlicna od NULL) in se njegova vrednost priredi *a.
    $A Igor  <== jul01 apr03; */
{
int buflength=100,ret=0;
char *buf=NULL,end=0;
numtype="long floating point (i.e. double)";
if (a==NULL)
  return -1;
buf=makestring(buflength);
buf[0]=0;
while (!end)
{
  gets(buf);
  if (cmpstrings(buf,"")==0)
  {
    printf("      = %lg\n",*a);
    end=1;
  } else if (buf[0]=='?')
    printhelpreadnum();
  else if (buf[0]=='\\')
  {
    if (buf[1]=='c' || buf[1]=='C')
    {
      proccalccom(buf+2);
    }
  } else if (buf[0]=='$' || buf[0]=='(')
  {
    if (evaluateexpression==NULL)
    {
      printf("Sorry, expression evaluator is not installed; input numerical value!.\n(now %lg): ",*a);
    } else
    {
      if (buf[0]=='$')
        *a=evaluateexpression(buf+1);
      else
        *a=evaluateexpression(buf);
      printf("      = %lg\n",*a);
      end=1;
      ret=strlen(buf);
    }
  } else if (isalpha(buf[0]))
    printf("(now %lg): ",*a);
  else
  {
    char *endptr=NULL;
    double d;
    d=strtod(buf,&endptr);
    if (endptr==NULL)
      endptr=buf;  /* because of the condition that follows */
    if (endptr<=buf || *endptr!='\0' || d==HUGE_VAL || d==-HUGE_VAL)
    {
      printhelpreadnum();
      if (d==HUGE_VAL)
        printf("Overflow (number too large to fit in double), insert the value again!\n");
      else if (d==-HUGE_VAL)
        printf("Overflow (neg. number too small to fit in double), insert the value again!\n");
      else
        printf("\nIncorrect format. Insert a double floating point value again!\n");
      printf("\n: ");
    } else
    {
      *a=d;
      end=1;
    }
  } 
}
if (buf!=NULL)
  free(buf);
return ret;
}


int readfloat(float *a)
    /* Prebere float *a s standardnega vhoda. Ce uporabnik vstavi niz "?"
    namesto stevila, se izpise trenutna vrednost stevila, branje pa se ponovi.
    Ce vstavi niz "", se ohrani stara vrednost. Ce vstavi $ in izraz ali izraz
    v oklepajih (), se izracuna izraz s funkcijo evaluateespression (ce je
    razlicna od NULL) in se njegova vrednost priredi *a.
    $A Igor <== feb01 jul01 apr03; */
{
int buflength=100,ret=0;
char *buf=NULL,end=0;
numtype="short floating point (i.e. float)";
if (a==NULL)
  return -1;
buf=makestring(buflength);
buf[0]=0;
while (!end)
{
  gets(buf);
  if (cmpstrings(buf,"")==0)
  {
    printf("      = %g\n",*a);
    end=1;
  } else if (buf[0]=='?')
    printhelpreadnum();
  else if (buf[0]=='\\')
  {
    if (buf[1]=='c' || buf[1]=='C')
    {
      proccalccom(buf+2);
    }
  } else if (buf[0]=='$' || buf[0]=='(')
  {
    if (evaluateexpression==NULL)
    {
      printf("Sorry, expression evaluator is not installed; input numerical value!.\n(now %g): ",*a);
    } else
    {
      if (buf[0]=='$')
        *a=(float) evaluateexpression(buf+1);
      else
        *a=(float) evaluateexpression(buf);
      printf("      = %g\n",*a);
      end=1;
      ret=strlen(buf);
    }
  } else if (isalpha(buf[0]))
    printf("(now %g): ",*a);
  else 
  {
    char *endptr=NULL;
    double d;
    d=strtod(buf,&endptr);
    if (endptr==NULL)
      endptr=buf;  /* because of the condition that follows */
    if (endptr<=buf || *endptr!='\0' || d>=FLT_MAX || d<=-FLT_MAX)
    {
      printhelpreadnum();
      if (d>=FLT_MAX)
        printf("Overflow (number too large to fir in float), insert the value again!\n");
      else if (d<=-FLT_MAX)
        printf("Overflow (neg. number too small for float), insert the value again!\n");
      else
        printf("\nIncorrect format. Insert a floating point value again!\n");
      printf("\n: ");
    } else
    {
      *a=(float) d;
      end=1;
    }
  }
}
if (buf!=NULL)
  free(buf);
return ret;
}



int readlong(long *a)
    /* Prebere stevilo tipa long s standardnega vhoda. Ce uporabnik vstavi niz "?"
    namesto stevila, se izpise trenutna vrednost stevila, branje pa se ponovi.
    Ce vstavi niz "", se ohrani stara vrednost. Ce vstavi $ in izraz ali izraz
    v oklepajih (), se izracuna izraz s funkcijo evaluateespression (ce je
    razlicna od NULL) in se njegova zaokrozena vrednost priredi *a.
    $A Igor <== jul01 apr03; */
{
int buflength=100,ret=0;
char *buf=NULL,end=0;
numtype="long integer (i.e. long)";
if (a==NULL)
  return -1;
buf=makestring(buflength);
buf[0]=0;
while (!end)
{
  gets(buf);
  if (cmpstrings(buf,"")==0)
  {
    printf("      = %li\n",*a);
    end=1;
  } else if (buf[0]=='?')
    printhelpreadnum();
  else if (buf[0]=='\\')
  {
    if (buf[1]=='c' || buf[1]=='C')
    {
      proccalccom(buf+2);
    }
  } else if (buf[0]=='$' || buf[0]=='(')
  {
    if (evaluateexpression==NULL)
    {
      printf("Sorry, expression evaluator is not installed; input numerical value!.\n(now %li): ",*a);
    } else
    {
      if (buf[0]=='$')
        *a=(long) round(evaluateexpression(buf+1));
      else
        *a=(long) round(evaluateexpression(buf));
      printf("      = %li\n",*a);
      end=1;
      ret=strlen(buf);
    }
  } else if (isalpha(buf[0]))
    printf("(now %li): ",*a);
  else 
  {
    char *endptr=NULL;
    long d;
    d=strtol(buf,&endptr,10);
    if (endptr==NULL)
      endptr=buf;  /* because of the condition that follows */
    if (endptr<=buf || *endptr!='\0' || d==LONG_MIN || d==LONG_MAX)
    {
      printhelpreadnum();
      if (d==LONG_MAX)
        printf("Overflow (number too large to fit in long int), insert the value again!\n");
      else if (d<=LONG_MIN)
        printf("Overflow (neg. number too small to fit in long int), insert the value again!\n");
      else
        printf("\nIncorrect format. Insert a long integer value again!\n");
      printf("\n: ");
    } else
    {
      *a=d;
      end=1;
    }
  } 
}
if (buf!=NULL)
  free(buf);
return ret;
}


int readint(int *a)
    /* Prebere celo stevilo s standardnega vhoda. Ce uporabnik vstavi niz "?"
    namesto stevila, se izpise trenutna vrednost stevila, branje pa se ponovi.
    Ce vstavi niz "", se ohrani stara vrednost. Ce vstavi $ in izraz ali izraz
    v oklepajih (), se izracuna izraz s funkcijo evaluateespression (ce je
    razlicna od NULL) in se njegova zaokrozena vrednost priredi *a.
    $A Igor <== feb01 jul01 apr03; */
{
int buflength=100,ret=0;
char *buf=NULL,end=0;
numtype="integer (i.e. int)";
if (a==NULL)
  return -1;
buf=makestring(buflength);
buf[0]=0;
while (!end)
{
  gets(buf);
  if (cmpstrings(buf,"")==0)
  {
    printf("      = %i\n",*a);
    end=1;
  } else if (buf[0]=='?')
    printhelpreadnum();
  else if (buf[0]=='\\')
  {
    if (buf[1]=='c' || buf[1]=='C')
    {
      proccalccom(buf+2);
    }
  } else if (buf[0]=='$' || buf[0]=='(')
  {
    if (evaluateexpression==NULL)
    {
      printf("Sorry, expression evaluator is not installed; input numerical value!.\n(now %i): ",*a);
    } else
    {
      if (buf[0]=='$')
        *a=(int) round(evaluateexpression(buf+1));
      else
        *a=(int) round(evaluateexpression(buf));
      printf("      = %i\n",*a);
      end=1;
      ret=strlen(buf);
    }
  }  else if (isalpha(buf[0]))
    printf("(now %i): ",*a);
  else 
  {
    char *endptr=NULL;
    long d;
    d=strtol(buf,&endptr,10);
    if (endptr==NULL)
      endptr=buf;  /* because of the condition that follows */
    if (endptr<=buf || *endptr!='\0' || d<=INT_MIN || d>=INT_MAX)
    {
      printhelpreadnum();
      if (d<=INT_MIN)
        printf("Overflow (neg. number too small to fit in int), insert the value again!\n");
      else if ( d>=INT_MAX)
        printf("Overflow (number too large to fit in int), insert the value again!\n");
      else
        printf("\nIncorrect format. Insert an integer value again!\n");
      printf("\n: ");
    } else
    {
      *a=d;
      end=1;
    }
  } 
}
if (buf!=NULL)
  free(buf);
return ret;
}


int readlongflags(long *pflags,long mask)
    /* The same as readintflags() (see below), except that flags are of type
    long rather than int. This should always be the case if more than 16 bits
    are needed, since int is 2 bytes long on some systems.
    $A Igor apr0l */
{
long set;
int numbits,i;
int buflength=100,ret=0;
char *buf=NULL,end=0;
numtype="integer flags";
if (pflags==NULL)
  return -1;
buf=makestring(buflength);
buf[0]=0;
if (! mask)
{
  numbits=sizeof(int)*8;
  mask=1;
  for (i=0;i<numbits;++i)
  {
    mask |= 1 << i;
  }
}
if (!(*pflags & mask))
  set=0;
else if ((*pflags & mask)==mask)
  set=1;
else
  set=-1;
while (!end)
{
  gets(buf);
  if (cmpstrings(buf,"")==0)
  {
    /* printf("      Keep "); */
    if ((*pflags & mask) == mask)
      printf("    = 1  (set) ");
    else if (! (*pflags & mask) )
      printf("    = 0  (unset) ");
    else
      printf("    =     partially set ");
    /* printdatabits(pflags,sizeof(*pflags)); */
    printf("\n");
    end=1;
    if (buf!=NULL)
      free(buf);
    buf=NULL;
  } else if (buf[0]=='?')
  {
    printf("\nInsert one of the following requests:\n   1 - set flags in mask\n   0 - unset flags in mask\n  -1 - keep flags unchanged.\n");
    printhelpreadnum();
  }
  else if (buf[0]=='\\')
  {
    if (buf[1]=='c' || buf[1]=='C')
    {
      proccalccom(buf+2);
    }
  } else if (buf[0]=='$' || buf[0]=='(')
  {
    if (evaluateexpression==NULL)
    {
      printf("Sorry, expression evaluator is not installed; input numerical value!.\n(now %li): ",set);
    } else
    {
      if (buf[0]=='$')
        set=(long) round(evaluateexpression(buf+1));
      else
        set=(long) round(evaluateexpression(buf));
      printf("      = %i\n",set);
      end=1;
      ret=strlen(buf);
    }
  } else if (isalpha(buf[0]))
  {
    printf("    Currently ");
    if ((*pflags & mask) == mask)
      printf("1 (set)\n");
    else if (! (*pflags & mask) )
      printf("0 (not set)\n");
    else
      printf("-1 (partially set)\n");
    /*
    printf("    Flags: ");
    printdatabits(pflags,sizeof(*pflags));
    printf("\n    Mask:  "); printdatabits(&mask,sizeof(mask));
    printf("\n: ");
    */
  } else 
  {
    char *endptr=NULL;
    long d;
    d=strtol(buf,&endptr,10);
    if (endptr==NULL)
      endptr=buf;  /* because of the condition that follows */
    if (endptr<=buf || *endptr!='\0')
    {
      printf("\nInsert one of the following requests:\n   1 - set flags in mask\n   0 - unset flags in mask\n  -1 - keep flags unchanged.\n");
      printhelpreadnum();
      printf("\nIncorrect format. Insert the request again!\n");
      printf("\n: ");
    } else
    {
      set=d;
      end=1;
    }
  } 
}
if (buf!=NULL)
  free(buf);
buf=NULL;
if (!set)
  *pflags &= ~mask;
else if (set>0)
  *pflags |= mask;
return 1;
}



int readintflags(int *pflags,int mask)
    /* Sets flags *pflags according to user input on stdin. mask defines the
    bits which are set or unset. User input is read by readint() where initial
    value is set according to whether all mask defined flags in *pflags are
    set (1), none of them is set (0) or some are set and some are not (-1).
    If user input is 0, all flags in *pflags for which bits in mask are 0 are
    unset, if it is 1, all flags are set, and if it is -1, *oflags  remains
    unchanged. In any case, those bits which are 0 in mask, are not changed.
      Function returns 1 if everything is OK or -1 if not (namely if pglags
    is NULL).
    	If the mask is specified as 0, all bits in *pflags are affected.
      Warning:
      Whenever more than 16 distinct bits are used for flags, these should be
    long int, since int is only 2 bytes long on some operating systems.
    $A Igor apr03; */
{
long set;
int numbits,i;
int buflength=100,ret=0;
char *buf=NULL,end=0;
numtype="integer flags";
if (pflags==NULL)
  return -1;
buf=makestring(buflength);
buf[0]=0;
if (! mask)
{
  numbits=sizeof(int)*8;
  mask=1;
  for (i=0;i<numbits;++i)
  {
    mask |= 1 << i;
  }
}
if (!(*pflags & mask))
  set=0;
else if ((*pflags & mask)==mask)
  set=1;
else
  set=-1;
while (!end)
{
  gets(buf);
  if (cmpstrings(buf,"")==0)
  {
    /* printf("      Keep "); */
    if ((*pflags & mask) == mask)
      printf("    = 1  (set) ");
    else if (! (*pflags & mask) )
      printf("    = 0  (unset) ");
    else
      printf("    =     partially set ");
    /* printdatabits(pflags,sizeof(*pflags)); */
    printf("\n");
    end=1;
    if (buf!=NULL)
      free(buf);
    buf=NULL;
  } else if (buf[0]=='?')
  {
    printf("\nInsert one of the following requests:\n   1 - set flags in mask\n   0 - unset flags in mask\n  -1 - keep flags unchanged.\n");
    printhelpreadnum();
  }
  else if (buf[0]=='\\')
  {
    if (buf[1]=='c' || buf[1]=='C')
    {
      proccalccom(buf+2);
    }
  } else if (buf[0]=='$' || buf[0]=='(')
  {
    if (evaluateexpression==NULL)
    {
      printf("Sorry, expression evaluator is not installed; input numerical value!.\n(now %li): ",set);
    } else
    {
      if (buf[0]=='$')
        set=(long) round(evaluateexpression(buf+1));
      else
        set=(long) round(evaluateexpression(buf));
      printf("      = %i\n",set);
      end=1;
      ret=strlen(buf);
    }
  } else if (isalpha(buf[0]))
  {
    printf("    Currently ");
    if ((*pflags & mask) == mask)
      printf("1 (set)\n");
    else if (! (*pflags & mask) )
      printf("0 (not set)\n");
    else
      printf("-1 (partially set)\n");
    /*
    printf("    Flags: ");
    printdatabits(pflags,sizeof(*pflags));
    printf("\n    Mask:  "); printdatabits(&mask,sizeof(mask));
    printf("\n: ");
    */
  } else 
  {
    char *endptr=NULL;
    long d;
    d=strtol(buf,&endptr,10);
    if (endptr==NULL)
      endptr=buf;  /* because of the condition that follows */
    if (endptr<=buf || *endptr!='\0')
    {
      printf("\nInsert one of the following requests:\n   1 - set flags in mask\n   0 - unset flags in mask\n  -1 - keep flags unchanged.\n");
      printhelpreadnum();
      printf("\nIncorrect format. Insert the request again!\n");
      printf("\n: ");
    } else
    {
      set=d;
      end=1;
    }
  } 
}
if (buf!=NULL)
  free(buf);
buf=NULL;
if (!set)
  *pflags &= ~mask;
else if (set>0)
  *pflags |= mask;
return 1;
}

void waituserresponse(void)
    /* Prompts user to press <Enter> and stops execution of the program, until
    <Enter> is pressed.
    $A Igor jul03; */
{
int i;
printf("\nPress <Return> to continue! "); readint(&i);
printf("\n");
}



    /* UDOBNO BRANJE NIZOV S STAND. VHODA */


int readstring(char **str)
    /* Prebere niz *str s standardnega vhoda. Ce vstavi niz "", se
    ohrani stara vrednost niza.  Ce je zadnji znak vstavljenega niza '\', pred
    njim pa ni tega znaka, se prebere se en niz, ki se prikljuci k prepranemu
    nizu brez zadnjega znaka '\' (to se lahko poljubno krat ponovi). Pri
    vstavljanju se lahko vstavi posebne sekvence, ki pomenijo navodila tej
    funkciji in se ne stejejo kot del vstavljenega niza.  Ce uporabnik vstavi
    niz "\", se izpise trenutna vrednost niza, branje se ponovi. Ce je
    vstavljen niz enak "a\", se prebrani niz prikljuci stari vsebini niza. Z
    ukazom "c\" odpovemo prikljucevanje staremu nizu. Ce je niz enak "e\",
    postane brani niz prazni niz "", ce pa je niz enak "n\", postane brani niz
    NULL. Ce je vstavljen niz enak "?", "?\" ali "h\", se izpise kratka pomoc
    za vstavljanje nizov.
    Prebrani niz lahko vsebuje posebne znake, ki se vstavijo s sekvenco, ki se
    zacne z znakom '\' (pravila so taksna, kot pri funkciji specialcharacter).
    V tem primeru se po branju zamenjajo sekvence, ki oznacujejo posebne znake,
    s funkcijo updatespecchat().
    Za *str se alocira tocno toliko prostora, kolikor je potrebno. Branje se
    izvede preko vmesnega pomnilnika buf, ki ima alociranih doloceno stevilo
    znakov (konstanda buflength v funkciji). Funkcija vrne dolzino prebranega
    niza ali -1, ce je str enak NULL.
      POZOR: znaka '\' v nizu se ne da vstaviti neposredno, ampak ga je treba
    vstaviti kot sekvenco za poseben znak "\\".
    $A Igor jan01 jan03; */
{
const int buflength=2000;
int ret=0,ordlength=0;
char *buf=NULL,*buf1=NULL,*buf2=NULL,end=0,join=0,multiline=0,*aux=NULL,*aux1=NULL;
if (str==NULL)
  return -1;
buf=makestring(buflength);
while (!end)
{
  buf[0]='\0';
  gets(buf);
  if (strcmp(buf,"")==0)  /* ohrani se stara vrednost */
  {
    if (!multiline)
    {
      join=1;
      printf("    = \"%s\"\n",*str);
    }
    end=1;
  } else if (strcmp(buf,"e\\")==0)  /* vrne se prazen niz */
  {
    end=1;
    join=0;
    multiline=0;
    *buf='\0';
  } else if (strcmp(buf,"n\\")==0)  /* vrne se NULL */
  {
    end=1;
    join=0;
    multiline=0;
    disppointer((void **) &buf);
  } else if (strcmp(buf,"d\\")==0)  /* zbrise se trenutno vstavljen niz */
  {
    *buf='\0';
    if (buf1!=NULL)
      *buf1='\0';
  } else if ( strcmp(buf,"a\\")==0 )  /* prebrano se prikljucu stari vsebini */
  {
    join=1;
    printf("  >> Appending is on (switch off by \"c\\\")\n");
  } else if ( strcmp(buf,"c\\")==0 )  /* prikljucevanje se odpove */
  {
    join=0; 
    printf("  >> Appending is off.\n");
  }  else if (strcmp(buf,"h\\")==0 || strcmp(buf,"?\\")==0 || strcmp(buf,"?")==0)
  {
    printf("\n  Comfortable reading of strings; available commands:\n");
    printf("\"\"  : keep the old value of the string.\n");
    printf("\"\\\" : print the current value of the string.\n");
    printf("\"a\\\": append the inserted string to the old one.\n");
    printf("\"e\\\": insert an empty string (no appending).\n");
    printf("\"n\\\": insert a NULL string, (no appending).\n");
    printf("\"d\\\": delete the currently inserted string, continue input.\n");
    printf("\"c\\\": cancel appending, only the inserted string is taken.\n");
    printf("\"?\", \"h\\\" or \"?\\\": This help.\n");
    printf("Use escape sequences for special characters:\n");
    printf("    \\n for newline,    \\r for carriage return,\n");
    printf("    \\t for tab,        \\v for vertical tab\n");
    printf("    \\b for backspace,  \\f for formfeed,\n");
    printf("    \\\\ for backslash,  \\c for ord. char. c,\n");
    printf("    \\x## hexadec. notation, \\d### decimal notation.\n");
    printf("      (# stands for a digit)\n");
    printf("You can insert a string in multiple lines by ending each line by \\ .\n");
    printf("Do not use multi-line input with less than 3 characters in a line.\n");
    printf("To insert e.g. \"?a\" followed by a newline, input \"\\?a\\n\", for \"a\\\" input \"a\\\\\",\n");
    printf("for \"?\", input \"\\?\".\n");
    if (join)
      printf("Appending is on.\n");
     else
       printf("Appending is off.\n");
     printf("\n");
  } else if (strcmp(buf,"\\")==0)
  {
    /* Izpis prejsnje vrednosti */
    #ifdef IGTEST
     printf("\nOld string: ");
     printstrspec(*str);
     printf("\n");
     printf("Current string: ");
     disppointer((void **) &aux);
     disppointer((void **) &aux1);
     if (join)
       aux=stringcat(*str,buf1);
     else
       aux=stringcopy(buf1);
     aux1=stringcopy (aux);
     ordinarystr(aux,&ordlength,&aux);
     printstrspec(aux);
     /* printf("\n(ordinary notation: \"%s\")",aux1); */
     printf("\n");
    #else
     printf("\nOld string: \"%s\"\n",*str);
     printf("Current string: \"");
     if (join && *str!=NULL)
       printf("%s",*str);
     if (multiline && buf1!=NULL)
       printf("%s",buf1);
     printf("\"");
    #endif
    if (join)
      printf("\nAppending is on.");
     else
       printf("\nAppending is off.");
    printf("\nInsert a new string or appended string:\n");
  } else if (stringlength(buf)>1 && buf[strlen(buf)-1]=='\\')
  {
    if (buf[strlen(buf)-2]!='\\')
    {
      /* Branje v vec vrsticah */
      multiline=1;
      buf[strlen(buf)-1]='\0';
      buf2=stringcat(buf1,buf);
      disppointer((void **) &buf1);
      buf1=buf2;
      buf2=NULL;
    } else
      end=1;
  } else
    end=1;
}
if (multiline)
{
  buf2=stringcat(buf1,buf);
  disppointer((void **) &buf1);
  disppointer((void **) &buf);
  buf=buf2;
  buf2=NULL;
}
#ifdef IGTEST
  if (buf!=NULL)
  {
    ordinarystr(buf,&ordlength,&aux);
    strcpy(buf,aux);
  }
#else
 updatespecchar(buf);
#endif
if (join)
{
  buf2=stringcat(*str,buf);
  disppointer((void **) str);
  *str=buf2;
  buf2=NULL;
} else /* if (buf[0]!='\0') */
{
  disppointer((void **) str);
  *str=stringcopy(buf);
}
ret=stringlength(*str);
disppointer((void **) &buf);
disppointer((void **) &buf1);
disppointer((void **) &buf2);
disppointer((void **) &aux);
disppointer((void **) &aux1);
return ret;
}



    /* CEKIRANJE IMEN SPREMENLJIVK: */


char legalvarname(char *name)
    /* Vrne 1, ce je name niz, ki ga lahko uporabimo za ime spremenljivke, in
    0, ce name ni tak niz (to je tudi v primeru, da je NULL).
    $A Igor sep01; */
{
int i,n;
if (name!=NULL)
  if (isalpha(name[0]) || name[0]=='_')
  {
    n=strlen(name);
    for (i=1;i<n;++i)
      if (!(isalnum(name[i]) || name[i]=='_'))
        return 0;
    return 1;
  }
return 0;
}



    
        /*************************/
        /*                       */
        /*  STRINGS AND NUMBERS  */
        /*                       */
        /*************************/



    /* PRINTING NUMBERS WITH 1000 SEPARATORS: */

/* Remark: IMPLEMENT THREAD COMPATIBILITY! */

/* Buffer for printing numbers with 1000 separators; it must store format
specification, original representation and representation with separators: */
static char *printsepbuf=NULL;
static int printsepbufsize=150; /* buffer size */


int fprintdoublesep(FILE *fp,double x,char sep, char *flags,int width,
                     int precision,char *type)
    /* Prints a double x with 1000 separators into fp. sep is separator (none
    if sep=='\0' || sep=='0'), flags are formatting flags like for printf(),
    e.g. "-" for left alignment (can be NULL or ""), width is field width
    (if <=0 then the default width is used), precision is number of signif.
    digits printed (if 0 then the default value is used), and type must be a
    valid format specification like for printf() (e.g. "lg" or "e"), but it can
    be NULL or "", in which case "lg" is used.
    The function prints the number x in the same way as fprintf(), except that
    it inserts signs sep as 1000 separators into the whole part of the number.
      Function returns the number of characters printed or a negative number
    in the case of error.
    $A Igor apr03; */
{
char *origptr,*sepptr,*ptrfrom,*ptrto;
int n,i;
if (printsepbuf==NULL)
  printsepbuf=malloc(printsepbufsize);
if (fp!=NULL)
{
  /* sprintf(printsepbuf,"\%"); */
  *printsepbuf='%';
  origptr=printsepbuf+1;
  if (flags!=NULL)   /* print flag, e.g. '-' for left alignment */
  {
    sprintf(origptr,"%s",flags);
    while(*origptr!='\0')
      ++origptr;
  }
  if (width>0)
  {
    sprintf(origptr,"%i",width);
    while(*origptr!='\0')
      ++origptr;
  }
  if (precision>0)
  {
    sprintf(origptr,".%i",precision);
    while(*origptr!='\0')
      ++origptr;
  }
  if (stringlength(type)>0)
    sprintf(origptr,"%s",type);
  else
    sprintf(origptr,"lg\0");
  while(*origptr!='\0')
    ++origptr;
  /*
  sprintf(origptr,"\\0\0");
  */
  /*
  sprintf(origptr,"\%c\0");
  */
  while(*origptr!='\0')
    ++origptr;
  ++origptr; /* leave terminating '\0' */
  /* Print the number according to the format specification: */
  sprintf(origptr,printsepbuf,x);
  if (sep!=0 && sep!='0')
  {
    /* Copy original representation to representation with separators: */
    sepptr=origptr;
    while(*sepptr!='\0')
      ++sepptr;
    ++sepptr;
    ptrfrom=origptr;
    ptrto=sepptr;
    /* Copy leading spaces, + or -: */
    while ((*ptrfrom=='-' || *ptrfrom=='+' || *ptrfrom=='0' || isspace(*ptrfrom))
            && *ptrfrom!='\0')
    {
      *ptrto=*ptrfrom;
      ++ptrfrom;
      ++ptrto;
    }
    /* Count digits before the decimal point: */
    n=0;
    while (isdigit(ptrfrom[n]))
      ++n;
    i=n%3;  /* nom. of digits before the first separator */
    if (i==0)
      i=3;
    n=0; /* will count separators */
    while (isdigit(*ptrfrom))
    {
      *ptrto=*ptrfrom;
      ++ptrfrom;
      ++ptrto;
      --i;
      if (i==0)
      {
        i=3;
        if (isdigit(*ptrfrom))
        {
          *ptrto=sep;
          ++n;
          ++ptrto;
        }
      }
    }
    /* Copy the rest part of the representation: */
    strcpy(ptrto,ptrfrom);
    /* Add terminating '\0': */
    ptrto[strlen(ptrfrom)]='\0';
    /* If possible, shorten the representation for the number of inserted
    characters: */
    while (n>0 && *sepptr!='\0' && (isspace(*sepptr) || 
                   *sepptr=='0' && (sepptr[1]=='0' || sepptr[1]=='.' )))
    {
      --n;
      ++sepptr;
    }
    if (n>0 && *sepptr!='\0')
    {
      ptrto=sepptr;
      while(*ptrto!='\0')
        ++ptrto;
      --ptrto;
      while (n>0 && ptrto>sepptr && isspace(*ptrto))
      {
        --n;
        *ptrto='\0';
        --ptrto;
      }
    }
    return fprintf(fp,sepptr);
  } else
  {
    sepptr=origptr;
    return fprintf(fp,origptr);
  }
  /*
  printf("\nSpec: \"%s\", orig.: \"%s\", sep.: \"%s\"\n\n",
    printsepbuf,origptr,sepptr);
  */
}
return -1;
}



int printdoublesep(double x,char sep, char *flags,int width,
                     int precision,char *type)
    /* The same as fprintdoublesep(), but prints the number to the standard
    output.
    $A Igor apr03; */
{
return fprintdoublesep(stdout,x,sep,flags,width,precision,type);
}


int sprintdoublesep(char *str,double x,char sep, char *flags,int width,
                     int precision,char *type)
    /* The same as fprintdoublesep(), but prints the number with separators
    to the string str and appends the terminating '\0' (which is not counted
    into the returned number of written bytes).
    $A Igor apr03; */
{
char *origptr,*sepptr,*ptrfrom,*ptrto;
int n,i;
if (printsepbuf==NULL)
  printsepbuf=malloc(printsepbufsize);
if (str!=NULL)
{
  /* sprintf(printsepbuf,"\%"); */
  *printsepbuf='%';
  origptr=printsepbuf+1;
  if (flags!=NULL)   /* print flag, e.g. '-' for left alignment */
  {
    sprintf(origptr,"%s",flags);
    while(*origptr!='\0')
      ++origptr;
  }
  if (width>0)
  {
    sprintf(origptr,"%i",width);
    while(*origptr!='\0')
      ++origptr;
  }
  if (precision>0)
  {
    sprintf(origptr,".%i",precision);
    while(*origptr!='\0')
      ++origptr;
  }
  if (stringlength(type)>0)
    sprintf(origptr,"%s",type);
  else
    sprintf(origptr,"lg\0");
  while(*origptr!='\0')
    ++origptr;
  /*
  sprintf(origptr,"\\0\0");
  */
  /*
  sprintf(origptr,"\%c\0");
  */
  while(*origptr!='\0')
    ++origptr;
  ++origptr; /* leave terminating '\0' */
  /* Print the number according to the format specification: */
  sprintf(origptr,printsepbuf,x);
  if (sep!=0 && sep!='0')
  {
    /* Copy original representation to representation with separators: */
    sepptr=origptr;
    while(*sepptr!='\0')
      ++sepptr;
    ++sepptr;
    ptrfrom=origptr;
    ptrto=sepptr;
    /* Copy leading spaces, + or -: */
    while ((*ptrfrom=='-' || *ptrfrom=='+' || *ptrfrom=='0' || isspace(*ptrfrom))
            && *ptrfrom!='\0')
    {
      *ptrto=*ptrfrom;
      ++ptrfrom;
      ++ptrto;
    }
    /* Count digits before the decimal point: */
    n=0;
    while (isdigit(ptrfrom[n]))
      ++n;
    i=n%3;  /* nom. of digits before the first separator */
    if (i==0)
      i=3;
    n=0; /* will count separators */
    while (isdigit(*ptrfrom))
    {
      *ptrto=*ptrfrom;
      ++ptrfrom;
      ++ptrto;
      --i;
      if (i==0)
      {
        i=3;
        if (isdigit(*ptrfrom))
        {
          *ptrto=sep;
          ++n;
          ++ptrto;
        }
      }
    }
    /* Copy the rest part of the representation: */
    strcpy(ptrto,ptrfrom);
    /* Add terminating '\0': */
    ptrto[strlen(ptrfrom)]='\0';
    /* If possible, shorten the representation for the number of inserted
    characters: */
    while (n>0 && *sepptr!='\0' && (isspace(*sepptr) || 
                   *sepptr=='0' && (sepptr[1]=='0' || sepptr[1]=='.' )))
    {
      --n;
      ++sepptr;
    }
    if (n>0 && *sepptr!='\0')
    {
      ptrto=sepptr;
      while(*ptrto!='\0')
        ++ptrto;
      --ptrto;
      while (n>0 && ptrto>sepptr && isspace(*ptrto))
      {
        --n;
        *ptrto='\0';
        --ptrto;
      }
    }
    return sprintf(str,sepptr);
  } else
  {
    sepptr=origptr;
    return sprintf(str,origptr);
  }
  /*
  printf("\nSpec: \"%s\", orig.: \"%s\", sep.: \"%s\"\n\n",
    printsepbuf,origptr,sepptr);
  */
}
return -1;
}



int fprintlongsep(FILE *fp,long x,char sep, char *flags,int width,
                  char *type)
    /* Prints a long int. x with 1000 separators into fp. sep is separator
    (none if sep=='\0' || sep=='0'), flags are formatting flags like for
    printf(), e.g. "-" for left alignment (can be NULL or ""), width is field
    width (if <=0 then the default width is used), and type must be a valid
    format specification like for printf() (e.g. "li" or "i"), but it can
    be NULL or "", in which case "li" is used.
    The function prints the number x in the same way as fprintf(), except that
    it inserts signs sep as 1000 separators into the number.
      Function returns the number of characters printed or a negative number
    in the case of error.
    $A Igor apr03; */
{
char *origptr,*sepptr,*ptrfrom,*ptrto;
int n,i;
if (printsepbuf==NULL)
  printsepbuf=malloc(printsepbufsize);
if (fp!=NULL)
{
  /* sprintf(printsepbuf,"\%"); */
  *printsepbuf='%';
  origptr=printsepbuf+1;
  if (flags!=NULL)   /* print flag, e.g. '-' for left alignment */
  {
    sprintf(origptr,"%s",flags);
    while(*origptr!='\0')
      ++origptr;
  }
  if (width>0)
  {
    sprintf(origptr,"%i",width);
    while(*origptr!='\0')
      ++origptr;
  }
  /*
  if (precision>0)
  {
    sprintf(origptr,".%i",precision);
    while(*origptr!='\0')
      ++origptr;
  }
  */
  if (stringlength(type)>0)
    sprintf(origptr,"%s",type);
  else
    sprintf(origptr,"li\0");
  while(*origptr!='\0')
    ++origptr;
  /*
  sprintf(origptr,"\\0\0");
  */
  /*
  sprintf(origptr,"\%c\0");
  */
  while(*origptr!='\0')
    ++origptr;
  ++origptr; /* leave terminating '\0' */
  /* Print the number according to the format specification: */
  sprintf(origptr,printsepbuf,x);
  if (sep!=0 && sep!='0')
  {
    /* Copy original representation to representation with separators: */
    sepptr=origptr;
    while(*sepptr!='\0')
      ++sepptr;
    ++sepptr;
    ptrfrom=origptr;
    ptrto=sepptr;
    /* Copy leading spaces, + or -: */
    while ((*ptrfrom=='-' || *ptrfrom=='+' || *ptrfrom=='0' || isspace(*ptrfrom))
            && *ptrfrom!='\0')
    {
      *ptrto=*ptrfrom;
      ++ptrfrom;
      ++ptrto;
    }
    /* Count digits before the decimal point: */
    n=0;
    while (isdigit(ptrfrom[n]))
      ++n;
    i=n%3;  /* nom. of digits before the first separator */
    if (i==0)
      i=3;
    n=0; /* will count separators */
    while (isdigit(*ptrfrom))
    {
      *ptrto=*ptrfrom;
      ++ptrfrom;
      ++ptrto;
      --i;
      if (i==0)
      {
        i=3;
        if (isdigit(*ptrfrom))
        {
          *ptrto=sep;
          ++n;
          ++ptrto;
        }
      }
    }
    /* Copy the rest part of the representation: */
    strcpy(ptrto,ptrfrom);
    /* Add terminating '\0': */
    ptrto[strlen(ptrfrom)]='\0';
    /* If possible, shorten the representation for the number of inserted
    characters: */
    while (n>0 && *sepptr!='\0' && (isspace(*sepptr) || 
                   *sepptr=='0' && (sepptr[1]=='0' )))
    {
      --n;
      ++sepptr;
    }
    if (n>0 && *sepptr!='\0')
    {
      ptrto=sepptr;
      while(*ptrto!='\0')
        ++ptrto;
      --ptrto;
      while (n>0 && ptrto>sepptr && isspace(*ptrto))
      {
        --n;
        *ptrto='\0';
        --ptrto;
      }
    }
    return fprintf(fp,sepptr);
  } else
  {
    sepptr=origptr;
    return fprintf(fp,origptr);
  }
  /*
  printf("\nSpec: \"%s\", orig.: \"%s\", sep.: \"%s\"\n\n",
    printsepbuf,origptr,sepptr);
  */
}
return -1;
}


int printlongsep(long x,char sep, char *flags,int width,
                     char *type)
    /* The same as fprintlongsep(), but prints the number to the standard
    output.
    $A Igor apr03; */
{
return fprintlongsep(stdout,x,sep,flags,width,type);
}




int sprintlongsep(char *str,long x,char sep, char *flags,int width,
                  char *type)
    /* The same as fprintlongsep, except that it prints the number with
    added separators to the string str and adds the terminating '\0' character,
    which is not kcounted in the returned number of written characters.
    $A Igor apr03; */
{
char *origptr,*sepptr,*ptrfrom,*ptrto;
int n,i;
if (printsepbuf==NULL)
  printsepbuf=malloc(printsepbufsize);
if (str!=NULL)
{
  /* sprintf(printsepbuf,"\%"); */
  *printsepbuf='%';
  origptr=printsepbuf+1;
  if (flags!=NULL)   /* print flag, e.g. '-' for left alignment */
  {
    sprintf(origptr,"%s",flags);
    while(*origptr!='\0')
      ++origptr;
  }
  if (width>0)
  {
    sprintf(origptr,"%i",width);
    while(*origptr!='\0')
      ++origptr;
  }
  /*
  if (precision>0)
  {
    sprintf(origptr,".%i",precision);
    while(*origptr!='\0')
      ++origptr;
  }
  */
  if (stringlength(type)>0)
    sprintf(origptr,"%s",type);
  else
    sprintf(origptr,"li\0");
  while(*origptr!='\0')
    ++origptr;
  /*
  sprintf(origptr,"\\0\0");
  */
  /*
  sprintf(origptr,"\%c\0");
  */
  while(*origptr!='\0')
    ++origptr;
  ++origptr; /* leave terminating '\0' */
  /* Print the number according to the format specification: */
  sprintf(origptr,printsepbuf,x);
  if (sep!=0 && sep!='0')
  {
    /* Copy original representation to representation with separators: */
    sepptr=origptr;
    while(*sepptr!='\0')
      ++sepptr;
    ++sepptr;
    ptrfrom=origptr;
    ptrto=sepptr;
    /* Copy leading spaces, + or -: */
    while ((*ptrfrom=='-' || *ptrfrom=='+' || *ptrfrom=='0' || isspace(*ptrfrom))
            && *ptrfrom!='\0')
    {
      *ptrto=*ptrfrom;
      ++ptrfrom;
      ++ptrto;
    }
    /* Count digits before the decimal point: */
    n=0;
    while (isdigit(ptrfrom[n]))
      ++n;
    i=n%3;  /* nom. of digits before the first separator */
    if (i==0)
      i=3;
    n=0; /* will count separators */
    while (isdigit(*ptrfrom))
    {
      *ptrto=*ptrfrom;
      ++ptrfrom;
      ++ptrto;
      --i;
      if (i==0)
      {
        i=3;
        if (isdigit(*ptrfrom))
        {
          *ptrto=sep;
          ++n;
          ++ptrto;
        }
      }
    }
    /* Copy the rest part of the representation: */
    strcpy(ptrto,ptrfrom);
    /* Add terminating '\0': */
    ptrto[strlen(ptrfrom)]='\0';
    /* If possible, shorten the representation for the number of inserted
    characters: */
    while (n>0 && *sepptr!='\0' && (isspace(*sepptr) || 
                   *sepptr=='0' && (sepptr[1]=='0' )))
    {
      --n;
      ++sepptr;
    }
    if (n>0 && *sepptr!='\0')
    {
      ptrto=sepptr;
      while(*ptrto!='\0')
        ++ptrto;
      --ptrto;
      while (n>0 && ptrto>sepptr && isspace(*ptrto))
      {
        --n;
        *ptrto='\0';
        --ptrto;
      }
    }
    return sprintf(str,sepptr);
  } else
  {
    sepptr=origptr;
    return sprintf(str,origptr);
  }
  /*
  printf("\nSpec: \"%s\", orig.: \"%s\", sep.: \"%s\"\n\n",
    printsepbuf,origptr,sepptr);
  */
}
return -1;
}








char *stringlong(long a)
     /* Vrne kazalec na niz, ki predstavlja stevilo a tipa long. Ta niz lahko
     brises s free. */
{
char *ref,*ret;
char maxlength=30;
ref=makestring(maxlength);
sprintf(ref,"%-li",a);
ret=stringcopy(ref);
free(ref);
return ret;
}


char *stringdouble(double a)
     /* Vrne kazalec na niz, ki predstavlja stevilo a tipa double. Ta niz lahko
     brises s free. */
{
char *ref,*ret;
char maxlength=40;
ref=makestring(maxlength);
sprintf(ref,"%-g",a);
ret=stringcopy(ref);
free(ref);
return ret;
}




char decdigit(char d)
     /* Vrne 1, ce znak predstavlja decimalno stevilko, drugace pa 0. */
{
if (d>='0'&&d<='9')
  return 1;
else
  return 0;
}

char sletter(char d)
     /* Vrne 1, ce znak predstavlja malo crko, drugace pa 0. */
{
if (d>='a'&&d<='z')
  return 1;
else
  return 0;
}

char bletter(char d)
     /* Vrne 1, ce znak predstavlja veliko crko, drugace pa 0. */
{
if (d>='A'&&d<='Z')
  return 1;
else
  return 0;
}

char letter(char d)
     /* Vrne 1, ce znak predstavlja crko (malo ali veliko), drugace pa 0. */
{
if (sletter(d)||bletter(d))
  return 1;
else
  return 0;
}


char alphanum(char d)
     /* Vrne 1, ce znak predstavlja a;fanumericen  znak, drugace pa 0. */
{
if (letter(d)||decdigit(d))
  return 1;
else
  return 0;
}




char isnumber(char *s)
     /* Vrne 1, ce zacetek niza *s predstavlja stevilo, drugace pa 0 */
{
char *end=NULL;
double x;
if (s==NULL)
  return 0;
else
{
  x=strtod(s,&end);
  if (end!=NULL && end>s)
    return 1;
}
return 0;
}




char isnumber1(char *s)
     /* Vrne 1, ce zacetek niza *s predstavlja stevilo, drugace pa 0 */
{
if (s==NULL)
  return 0;
else
{
  if (decdigit(s[0]))
    return 1;
  else if (s[0]=='.')
  {
    if (decdigit(s[1]))
      return 1;
    else
      return 0;
  }
  else if (s[0]=='+'||s[0]=='-')
  {
    if (decdigit(s[1]))
      return 1;
    else if (s[1]=='.')
    {
      if (decdigit(s[2]))
        return 1;
      else
        return 0;
    }
    else
      return 0;
  }
  else
    return 0;
}
}



int nstrnum(char *s)
     /* vrne stevilo znakov v nizu, ki predstavljajo stevilo. Ce zacetek
     niza sploh ne predstavlja stevila, vrne -1. */
{
char *end=NULL;
double x;
int dif;
if (s==NULL)
  return -1;
else
{
  x=strtod(s,&end);
  if (end!=NULL && end>s)
  {
    dif=end-s;
    return dif;
  }
}
return -1;
}





int nstrnum1(char *s)
     /* vrne stevilo znakov v nizu, ki predstavljajo stevilo. Ce zacetek
     niza sploh ne predstavlja stevila, vrne 0. */
{
int count=0;
char goon=1,sign=0,expo=0,expsign=0,dot=0,*ref;
ref=s;
if (s==NULL)
  return 0;
else if (!isnumber(s))
  return(0);
else
{
  while (goon)
  {
    if (ref[0]=='+'||ref[0]=='-')
    {
      if (count==0)
        sign=1;
      else if(ref[-1]=='e'||ref[-1]=='E')
        expsign=1;
      else
        goon=0;
    } else if (ref[0]=='e'||ref[0]=='E')
    {
      if (expo==0)
      {
        if (decdigit(ref[-1])||ref[-1]=='.')
        {
          if (isnumber(ref+1))
            expo=1;
          else
            goon=0;
        }
        else
          goon=0;
      } else
        goon=0;
    } else if (ref[0]=='.')
      {
        if (dot)
          goon=0;
        else
        {
          if (expo)
            goon=0;
          else
            sign=1;
        }
      }
      else if (decdigit(ref[0]))
      {
      } else
        goon=0;
    if (goon)
    {
      ++count;
      ++ ref;
    }
  }
  return count;
}
}




int floatstr(char *s)
     /* Vrne 1, ce niz s gotovo predstavlja necelo stevilo, drugace vrnr 0.
     Ce je stevilo zapisano v eksponentni obliki, potem se avtomatsko vzame,
     da je to necelo stevilo. */
{
char *end=NULL;
long a;
double x;
int dif1,dif2;
x=strtod(s,&end);
dif1=end-s;
a=strtol(s,&end,10);
dif2=end-s;
if (dif1==dif2)
  return 0;
else
  return 1;
}



int floatstr1(char *s)
     /* Vrne 1, ce niz s gotovo predstavlja necelo stevilo, drugace vrnr 0.
     Ce je stevilo zapisano v eksponentni obliki, potem se avtomatsko vzame,
     da je to necelo stevilo. */
{
int count=0;
char goon=1,sign=0,expo=0,expsign=0,dot=0,*ref;
ref=s;
if (!isnumber(s))
  return(0);
else
{
  while (goon)
  {
    if (ref[0]=='+'||ref[0]=='-')
    {
      if (count==0)
        sign=1;
      else if(ref[-1]=='e'||ref[-1]=='E')
        expsign=1;
      else
        goon=0;
    } else if (ref[0]=='e'||ref[0]=='E')
    {
      if (expo==0)
      {
        if (decdigit(ref[-1])||ref[-1]=='.')
        {
          if (isnumber(ref+1))
            expo=1;
          else
            goon=0;
        }
        else
          goon=0;
      } else
        goon=0;
    } else if (ref[0]=='.')
      {
        if (dot)
          goon=0;
        else
        {
          if (expo)
            goon=0;
          else
            sign=1;
        }
      }
      else if (decdigit(ref[0]))
      {
      } else
        goon=0;
    if (goon)
    {
      ++count;
      ++ ref;
    }
  }
  if (dot || expo)
    return(1);
  else
    return 0;
  /* return count; */
}
}




    /* PARSING FACILITIES */



void cutstringtowords(char *str,char *separators,stack words)
    /* Finds words in string str and put dynamically allocated words to the
	  stack st. If st already contains some elements, these are not deleted.
    $A Igor apr04; */
{
int p1,p2,numsep;
if (words==NULL)
{
  errfunc0("");
  sprintf(ers(),"Stack for storing words not specified.\n");
  errfunc2();
} else if (stringlength(str)>0)
{
  if ( (numsep=stringlength(separators))==0 )
    pushstack(words,stringcopy(str));
  else
  {
    p1=0;
    while (str[p1]!='\0')
    {
      while (imemnchr(separators,numsep,str+p1,1)>=0 && str[p1]!='\0' )
        ++p1;
      p2=p1;
      while (imemnchr(separators,numsep,str+p2,1)<0  && str[p2]!='\0' )
        ++p2;
      if (p2>p1)
        pushstack(words,stringncopy(str+p1,p2-p1));
      p1=p2;
    }
  }
}
}




























































































