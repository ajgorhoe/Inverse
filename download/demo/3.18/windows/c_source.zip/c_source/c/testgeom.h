#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>



#include <mtypes.h>
#include <er.h>
#include <vec.h>
#include <mat.h>
#include <st.h>
#include <rf.h>
#include <matrixop.h>
#include <mtime.h>
#include <geom.h>
#include <rand.h>
#include <strop.h>
#include <varop.h>
#include <rand.h>


static double fidentity(double x)
{
return x;
}

static double fexp(double x)
{
return exp(x);
}


static double fcos(double x)
{
return cos(x);
}


double (*func)(double)=fexp;


static double stepder=1e-8;

static double funcder(double x)
{
return(func(x+stepder)-func(x-stepder))/(2*stepder);
}

void testsplines(void)
{
double x0,h,hsens,dx,t1,t2,t3,t4,d,k1,kn;
int np,ndiv,i,isens;
vector x=NULL,y=NULL,vval=NULL,vsens=NULL,vsens1=NULL,vsens2=NULL,vsens3=NULL;
stack s1=NULL,s2=NULL;

x0=0;
np=100;
ndiv=5;
isens=3; hsens=1.0e-3;
h=1*pi()/((double) np-1.0);
x=getvector(np);
y=getvector(np);

printf("\nTocke:\n");
for (i=1;i<=np;++i)
{
  x->v[i]=x0+(i-1)*h;
  /* Z nakljucni premikom poskrbimo, da tocke niso ekvidistantne: */
  if (1)
    x->v[i]+=h*0.3*random1();
  y->v[i]=func(x->v[i]);
  printf("%2i %-10g %-10g\n",i,x->v[i],y->v[i]);
}
k1=funcder(x->v[1]);
kn=funcder(x->v[x->d]);
printf("\n\n");

/* Definicija zlepka in izracun ene vrednosti: */
t1=cputime();
setcubsplglob(x,y,k1,kn);
dx=cubsplglobval(x0);
t2=cputime();
printf("\nCPU time needed for defining the spline and first evaluation: %.4g s.\n\n",
  t2-t1);

printf("\nTest of values in equidistant points:\n");
printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","spline","func","dif");
for (i=1;i<=ndiv*np-1;++i)
{
  dx=x0+(i-1)*h/ndiv;
  printf("%-2i %-10g %-10g %-10g %-10g\n",i,dx,cubsplglobval(dx),func(dx),cubsplglobval(dx)-func(dx));
}
printf("\nTest of vlaues in nodes:\n");
printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","spline","func","dif");
for (i=1;i<=np-1;++i)
{
  dx=x->v[i];
  printf("%-2i %-10g %-10g %-10g %-10g\n",i,dx,cubsplglobval(dx),func(dx),cubsplglobval(dx)-func(dx));
}


printcubsplsysdata(0); /* Izpis podatkov o zlepku: */

/* Priprava vektorjev: */
vval=getvector(ndiv*np-1);
vsens=getvector(ndiv*np-1);
vsens1=getvector(ndiv*np-1);
vsens2=getvector(ndiv*np-1);
vsens3=getvector(ndiv*np-1);

/* Obcutljivosti glede na y koordinate vozlisc: */
printf("\nTest of sensitivities with respect to y_%i in equidistant points:\n",isens);
printf("\nPress <Enter> to continue!\n");  readdouble(&d);
printf("%-2s %-10s %-10s\n","No","x","sens");
for (i=1;i<=ndiv*np-1;++i)
{
  dx=x0+(i-1)*h/ndiv;
  printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsensy(isens,dx));
  vval->v[i]=cubsplglobval(dx);
  vsens->v[i]=cubsplglobsensy(isens,dx);
}
printf("\nTest of sensitivities with respect to y_%i in nodes:\n",isens);
printf("%-2s %-10s %-10s\n","No","x","sens");
for (i=1;i<=np-1;++i)
{
  dx=x->v[i];
  printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsensy(isens,dx));
}

if (1)
{
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  y->v[isens]+=hsens;
  setcubsplglob(x,y,k1,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens1->v[i]=cubsplglobval(dx);
    vsens1->v[i]-=vval->v[i];
    vsens1->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
            i,dx,vsens->v[i],vsens1->v[i],vsens->v[i]-vsens1->v[i]);
  }
  y->v[isens]-=hsens; /* s tem dosezemo prvotno stanje */

  hsens/=1000;
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  y->v[isens]+=hsens;
  setcubsplglob(x,y,k1,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens2->v[i]=cubsplglobval(dx);
    vsens2->v[i]-=vval->v[i];
    vsens2->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
           i,dx,vsens->v[i],vsens2->v[i],vsens->v[i]-vsens2->v[i]);
  }
  y->v[isens]-=hsens; /* s tem dosezemo prvotno stanje */

  hsens/=1000;
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  y->v[isens]+=hsens;
  setcubsplglob(x,y,k1,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens3->v[i]=cubsplglobval(dx);
    vsens3->v[i]-=vval->v[i];
    vsens3->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
           i,dx,vsens->v[i],vsens3->v[i],vsens->v[i]-vsens3->v[i]);
  }
  y->v[isens]-=hsens; /* s tem dosezemo prvotno stanje */
  hsens*=1000; hsens*=1000;

} /* if (0) - obcutljivosti na y koordinate vozlisc */

/* Obcutljivosti na x koordinate vozlisc: */
printf("\nTest of sensitivities with respect to x_%i in equidistant points:\n",isens);
printf("\nPress <Enter> to continue!\n");  readdouble(&d);
printf("%-2s %-10s %-10s\n","No","x","sens");
for (i=1;i<=ndiv*np-1;++i)
{
  dx=x0+(i-1)*h/ndiv;
  printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsensx(isens,dx) );
  vsens->v[i]=cubsplglobsensx(isens,dx);
  vval->v[i]=cubsplglobval(dx);
}

printf("\n\nVector of sensitivities vsens:\n");
printvector(vsens); printf("\n\n");

printf("\nTest of sensitivities with respect to x_%i in nodes:\n",isens);
printf("%-2s %-10s %-10s\n","No","x","sens");
for (i=1;i<=np-1;++i)
{
  dx=x->v[i];
  printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsensx(isens,dx));
}

if (1)
{
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  x->v[isens]+=hsens;
  setcubsplglob(x,y,k1,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens1->v[i]=cubsplglobval(dx);
    vsens1->v[i]-=vval->v[i];
    vsens1->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
            i,dx,vsens->v[i],vsens1->v[i],vsens->v[i]-vsens1->v[i]);
  }
  x->v[isens]-=hsens; /* s tem dosezemo prvotno stanje */

  hsens/=1000;
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  x->v[isens]+=hsens;
  setcubsplglob(x,y,k1,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens2->v[i]=cubsplglobval(dx);
    vsens2->v[i]-=vval->v[i];
    vsens2->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
           i,dx,vsens->v[i],vsens2->v[i],vsens->v[i]-vsens2->v[i]);
  }
  x->v[isens]-=hsens; /* s tem dosezemo prvotno stanje */

  hsens/=1000;
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  x->v[isens]+=hsens;
  setcubsplglob(x,y,k1,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens3->v[i]=cubsplglobval(dx);
    vsens3->v[i]-=vval->v[i];
    vsens3->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
           i,dx,vsens->v[i],vsens3->v[i],vsens->v[i]-vsens3->v[i]);
  }
  x->v[isens]-=hsens; /* s tem dosezemo prvotno stanje */
  hsens*=1000; hsens*=1000;
} /* if (0) - obcutljivosti na y koordinate vozlisc */


if (0) /* Zunanji if (0) */
{
  printf("\nTest of sensitivities with respect to k1 in equidistant points:\n");
  printf("\nPress <Enter> to continue!\n");  readdouble(&d);
  printf("%-2s %-10s %-10s\n","No","x","sens");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsensk1(dx) );
    vsens->v[i]=cubsplglobsensk1(dx);
    vval->v[i]=cubsplglobval(dx);
  }

  printf("\n\nVector of sensitivities vsens:\n");
  printvector(vsens); printf("\n\n");

  printf("\nTest of sensitivities with respect to k1 in nodes:\n");
  printf("%-2s %-10s %-10s\n","No","x","sens");
  for (i=1;i<=np-1;++i)
  {
    dx=x->v[i];
    printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsensk1(dx));
  }

  if (1)
  {
    hsens*=1000*1000*1000;

    printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
    setcubsplglob(x,y,k1+hsens,kn);
    printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
    for (i=1;i<=ndiv*np-1;++i)
    {
      dx=x0+(i-1)*h/ndiv;
      vsens1->v[i]=cubsplglobval(dx);
      vsens1->v[i]-=vval->v[i];
      vsens1->v[i]/=hsens;
      printf("%-2i %-10g %-10g %-10g %-10g\n",
              i,dx,vsens->v[i],vsens1->v[i],vsens->v[i]-vsens1->v[i]);
    }

    hsens/=1000;
    printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
    setcubsplglob(x,y,k1+hsens,kn);
    printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
    for (i=1;i<=ndiv*np-1;++i)
    {
      dx=x0+(i-1)*h/ndiv;
      vsens2->v[i]=cubsplglobval(dx);
      vsens2->v[i]-=vval->v[i];
      vsens2->v[i]/=hsens;
      printf("%-2i %-10g %-10g %-10g %-10g\n",
             i,dx,vsens->v[i],vsens2->v[i],vsens->v[i]-vsens2->v[i]);
    }

    hsens/=1000;
    printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
    setcubsplglob(x,y,k1+hsens,kn);
    printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
    for (i=1;i<=ndiv*np-1;++i)
    {
      dx=x0+(i-1)*h/ndiv;
      vsens3->v[i]=cubsplglobval(dx);
      vsens3->v[i]-=vval->v[i];
      vsens3->v[i]/=hsens;
      printf("%-2i %-10g %-10g %-10g %-10g\n",
             i,dx,vsens->v[i],vsens3->v[i],vsens->v[i]-vsens3->v[i]);
    }
    hsens*=1000; hsens*=1000;
  } /* if (0) */
} /* Zunanji if (0) */

t1=cputime();
setcubsplglob(x,y,k1,kn);
dx=cubsplglobval(x0);
t2=cputime();

/* Obcutljivosti glede na k1: */
printf("\nTest of sensitivities with respect to k1 in equidistant points:\n");
printf("\nPress <Enter> to continue!\n");  readdouble(&d);
printf("%-2s %-10s %-10s\n","No","x","sens");
for (i=1;i<=ndiv*np-1;++i)
{
  dx=x0+(i-1)*h/ndiv;
  printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsensk1(dx) );
  vsens->v[i]=cubsplglobsensk1(dx);
  vval->v[i]=cubsplglobval(dx);
}

printf("\n\nVector of sensitivities vsens:\n");
printvector(vsens); printf("\n\n");

printf("\nTest of sensitivities with respect to k1 in nodes:\n");
printf("%-2s %-10s %-10s\n","No","x","sens");
for (i=1;i<=np-1;++i)
{
  dx=x->v[i];
  printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsensk1(dx));
}

if (1)
{
  /* Opazka: za numericne senzitivnosti po kn je potrebno vzeti zelo velik
  korak. */

  hsens*=1000;

  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  setcubsplglob(x,y,k1+hsens,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens1->v[i]=cubsplglobval(dx);
    vsens1->v[i]-=vval->v[i];
    vsens1->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
            i,dx,vsens->v[i],vsens1->v[i],vsens->v[i]-vsens1->v[i]);
  }

  hsens/=1000;
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  setcubsplglob(x,y,k1+hsens,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens2->v[i]=cubsplglobval(dx);
    vsens2->v[i]-=vval->v[i];
    vsens2->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
           i,dx,vsens->v[i],vsens2->v[i],vsens->v[i]-vsens2->v[i]);
  }

  hsens/=1000;
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  setcubsplglob(x,y,k1+hsens,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens3->v[i]=cubsplglobval(dx);
    vsens3->v[i]-=vval->v[i];
    vsens3->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
           i,dx,vsens->v[i],vsens3->v[i],vsens->v[i]-vsens3->v[i]);
  }

  hsens*=1000; hsens*=1000;

} /* if (0) */

/* Obcutljivosti glede na kn: */
printf("\nTest of sensitivities with respect to kn in equidistant points:\n");
printf("\nPress <Enter> to continue!\n");  readdouble(&d);
printf("%-2s %-10s %-10s\n","No","x","sens");
for (i=1;i<=ndiv*np-1;++i)
{
  dx=x0+(i-1)*h/ndiv;
  printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsenskn(dx) );
  vsens->v[i]=cubsplglobsenskn(dx);
  vval->v[i]=cubsplglobval(dx);
}

printf("\n\nVector of sensitivities vsens:\n");
printvector(vsens); printf("\n\n");

printf("\nTest of sensitivities with respect to kn in nodes:\n");
printf("%-2s %-10s %-10s\n","No","x","sens");
for (i=1;i<=np-1;++i)
{
  dx=x->v[i];
  printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsenskn(dx));
}

if (1)
{
  /* Opazka: za numericne senzitivnosti po kn je potrebno vzeti velik
  korak. */

  hsens*=1000;

  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  setcubsplglob(x,y,k1,kn+hsens);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens1->v[i]=cubsplglobval(dx);
    vsens1->v[i]-=vval->v[i];
    vsens1->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
            i,dx,vsens->v[i],vsens1->v[i],vsens->v[i]-vsens1->v[i]);
  }

  hsens/=1000;
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  setcubsplglob(x,y,k1,kn+hsens);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens2->v[i]=cubsplglobval(dx);
    vsens2->v[i]-=vval->v[i];
    vsens2->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
           i,dx,vsens->v[i],vsens2->v[i],vsens->v[i]-vsens2->v[i]);
  }

  hsens/=1000;
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  setcubsplglob(x,y,k1,kn+hsens);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens3->v[i]=cubsplglobval(dx);
    vsens3->v[i]-=vval->v[i];
    vsens3->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
           i,dx,vsens->v[i],vsens3->v[i],vsens->v[i]-vsens3->v[i]);
  }

  hsens*=1000; hsens*=1000;

} /* if (0) */


if (0) /* Outer if (0) */
{

printf("\nTest of sensitivities with respect to k1 in equidistant points:\n");
printf("\nPress <Enter> to continue!\n");  readdouble(&d);
printf("%-2s %-10s %-10s\n","No","x","sens");
for (i=1;i<=ndiv*np-1;++i)
{
  dx=x0+(i-1)*h/ndiv;
  printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsensk1(dx) );
  vsens->v[i]=cubsplglobsensk1(dx);
  vval->v[i]=cubsplglobval(dx);
}

printf("\n\nVector of sensitivities vsens:\n");
printvector(vsens); printf("\n\n");

printf("\nTest of sensitivities with respect to k1 in nodes:\n");
printf("%-2s %-10s %-10s\n","No","x","sens");
for (i=1;i<=np-1;++i)
{
  dx=x->v[i];
  printf("%-2i %-10g %-10g\n",i,dx,cubsplglobsensk1(dx));
}

if (1)
{
  /* Opazka: za numericne senzitivnosti po k1 je potrebno vzeti velik
  korak (?). */

  hsens*=1000;

  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  setcubsplglob(x,y,k1+hsens,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens1->v[i]=cubsplglobval(dx);
    vsens1->v[i]-=vval->v[i];
    vsens1->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
            i,dx,vsens->v[i],vsens1->v[i],vsens->v[i]-vsens1->v[i]);
  }

  hsens/=1000;
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  setcubsplglob(x,y,k1+hsens,kn);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens2->v[i]=cubsplglobval(dx);
    vsens2->v[i]-=vval->v[i];
    vsens2->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
           i,dx,vsens->v[i],vsens2->v[i],vsens->v[i]-vsens2->v[i]);
  }

  hsens/=1000;
  printf("\nComparing numerical sensitivities, hsens=%g:\n",hsens);
  setcubsplglob(x,y,k1+hsens,kn+hsens);
  printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","sens","num. sens","difference");
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    vsens3->v[i]=cubsplglobval(dx);
    vsens3->v[i]-=vval->v[i];
    vsens3->v[i]/=hsens;
    printf("%-2i %-10g %-10g %-10g %-10g\n",
           i,dx,vsens->v[i],vsens3->v[i],vsens->v[i]-vsens3->v[i]);
  }

  hsens*=1000; hsens*=1000;

} /* if (0) */

} /* Outer if (0) */


printf("\nTest of functions for manipulating the spline system:\n");
printf("\nPress <Enter> to continue!\n");  readdouble(&d);

printf("\n\nCubic spline system before deletion:\n");

printcubsplglobstate();

copycubsplid(0,11);

printf("\n\nCopy of cubic spline:\n");
printcubsplstateid(11);


dispcubsplglobvar();

printf("\n\nCopy of cubic spline after deletion of the original:\n");
printcubsplstateid(11);
printf("\n\n");


printf("\nCubic spline system before restoration:\n");
printcubsplglobstate();
printf("\nRestoring the initial definition of the spline from stored data:\n");
/* Definicija zlepka in izracun ene vrednosti: */
t1=cputime();
copycubsplid(11,0);
/*
prepcubsplglobval();
prepcubsplglobsensyall();
dispcubsplglobintvar();
dx=cubsplglobval(x0);
*/
t2=cputime();
printf("\nCubic spline system after restoration:\n");
printcubsplglobstate();
printf("\nCPU time needed for resetting the spline and first evaluation: %.4g s.\n\n",
  t2-t1);

printf("\nTest of values in equidistant points:\n");
printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","spline","func","dif");
for (i=1;i<=ndiv*np-1;++i)
{
  dx=x0+(i-1)*h/ndiv;
  printf("%-2i %-10g %-10g %-10g %-10g\n",i,dx,cubsplglobval(dx),func(dx),cubsplglobval(dx)-func(dx));
}
printf("\nTest of vlaues in nodes:\n");
printf("%-2s %-10s %-10s %-10s %-10s\n","No","x","spline","func","dif");
for (i=1;i<=np-1;++i)
{
  dx=x->v[i];
  printf("%-2i %-10g %-10g %-10g %-10g\n",i,dx,cubsplglobval(dx),func(dx),cubsplglobval(dx)-func(dx));
}

if (0)
{
  /* Testiranje casovne zahtevnosti: */
  ndiv=1000;
  t3=cputime();
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    dx=cubsplglobval(dx);
  }
  t4=cputime();
  printf("\nCPU time needed for defining the spline and first evaluation: %.4g s.\n\n",
    t2-t1);
  printf("\nCPU time needed for %i evaluations: %.4g s.\n\n",i,t4-t3);
  t3=cputime();
  for (i=1;i<=ndiv*np-1;++i)
  {
    dx=x0+(i-1)*h/ndiv;
    dx=dx;
  }
  t4=cputime();
  printf("\nControl CPU time needed for %i iterations of empty loop: %.4g s.\n\n",i,t4-t3);
}
dispvector(&vval);
dispvector(&vsens);
dispvector(&vsens1);
dispvector(&vsens2);
dispvector(&vsens3);
}


















main()
{

timeinitrand();

if (0)
{
  testcubtr();
  exit(1);
}

if (0)
{
  testgeom3d();
  exit(1);
}

if (0)
{
  testvartypemanipulation();
  exit(1);
}

if (1)
{
testsplines();
}

/*  printf("Konstanta e: %.30lg\n\n",exp(1));  */








}
