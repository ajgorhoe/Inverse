# include <sysint.h>

# include <stdlib.h>
# include <stdio.h>
# include <string.h>
# include <stddef.h>
# include <math.h>

# include <mtypes.h>
# include <rf.h>
# include <st.h>
# include <vec.h>
# include <strop.h>
# include <fop.h>
# include <fld.h>



static int /* outdig=8, */   /* St. dec. mest pri izpisovanju stevil */
           outchar=1;  /* Min. st. mest pri izpisovanju stevil */

int fldgetoutdig(void)
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu fld.c.
    $A Igor mar99; */
{
return m_outdig;
}

int fldgetoutchar(void)
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu fld.c.
    $A Igor mar99; */
{
return outchar;
}

void fldsetoutdig(int num)
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu fld.c.
    $A Igor mar99; */
{
if (m_outdig>0)
  m_outdig=num;
}

void fldsetoutchar(int num)
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu fld.c.
    $A Igor mar99; */
{
if (outchar>0)
  outchar=num;
}



field getfield(int lin,int col)
    /* Rezervira prostor za polje z lin vrsticami in col stolpci ter vrne
    kazalec na ta prostor. Ce sta argumenta enaka 0, funkcija ne alocira
    prostora za posamezne vektorje.
    polja.
    $A Damjan jun98; */
{
int i;
field ret=NULL;

if(lin>=0 && col>=0)
{
  ret=malloc(sizeof(*ret));
  if(lin==0 && col==0)
  {
    ret->lin=0;
    ret->col=0;
    ret->st=newstack(10);
  }
  else
  {
    ret->lin=lin;
    ret->col=col;
    ret->st=newstack(lin);
    for(i=1;i<=lin;i++)
      pushstack(ret->st,getvector(col));
  }
}
return ret;
}


void dispfield(field *fld)
    /* Zbrise polje *fld s celotno vsebino in njegovo vrednost postavi na NULL.
    $A Damjan jun98; */
{

if(*fld!=NULL)
{
  (*fld)->lin=0;
  (*fld)->col=0;
  if((*fld)->st!=NULL)
  {
    dispstackvalspec((*fld)->st,(void(*)(void **))dispvector);
    dispstack(&((*fld)->st));
  }
  free(*fld);
  *fld=NULL;
}
}


field fieldcopy(field f)
    /* Vrne kopijo polja f.
    $A Damjan jun98; */
{
field ret=NULL;

if (f!=NULL)
{
  ret=getfield(2,2);
  if (f->col && f->lin)
  {
    int i;
    for (i=1;f->lin;++i)
      copyvector0( (vector)f->st->s[i],(vector *) &(ret->st->s[i]) );
  }
}
return ret;
}


field copyfield(field f1,field *f2)
    /* Vrne kopijo polja f1. Ce je f2 razlicen od NULL, skopira polje f1 v
    *f2 in vrne *f2.
    $A Damjan jun98; */
{
field f;
int i;

if(f2!=NULL)
{
  if(f1==NULL)
  {
    dispfield(f2);
  }
  else
  {
    if(*f2!=NULL)
      if((*f2)->col!=f1->col || (*f2)->lin!=f1->lin)
        dispfield(f2);
    if(*f2==NULL)
      *f2=getfield(f1->lin,f1->col);
    f=*f2;
    if(f1->col>0 && f1->lin>0)
      for(i=1;i<=f1->lin;++i)
        copyvector0( (vector)f1->st->s[i],(vector *) &(f->st->s[i]) );;
  }
  return *f2;
}
else
{
  if(f1==NULL)
    return NULL;
  else
  {
    f=getfield(f1->lin,f1->col);
    if(f1->col>0 && f1->lin>0)
      for(i=1;i<=f1->lin;++i)
        f->st->s[i]=f1->st->s[i];
    return f;
  }
}
}


field movefield(field *f1, field *f2)
    /* Premakne *f1 v *f2 in vrne *f2. Po izvedbi je vedno *f1==NULL. Ce je
    f2==NULL, samo vrne *f1 (ce je f1==NULL, vrne NULL).
    $A Damjan jun98; */
{
field f;

if (f1!=NULL)
{
  if (f2!=NULL)
  {
    /* Ce je f2!=NULL, se *f1 premakne v *f2: */
    dispfield(f2);
    *f2=*f1;
    *f1=NULL;
    return *f2;
  }
  else
  {
    f=*f1;
    *f1=NULL;
    return f;
  }
}
else
{
  /* Ce je f1 NULL, se zbrise f2 in vrne NULL. */
  if (f2!=NULL)
    dispfield(f2);
  return NULL;
}
}


void fprintfield(FILE *fp, field f)
     /* Izpise polje f v datoteko fp.
     $A Damjan jun98; */
{
int i,j;

if (fp!=NULL)
{
  if(f==NULL)
    fprintf(fp,"NULL FIELD.\n");
  else
  {
    if (f->col!=0 && f->lin!=0 && f->st!=NULL)
    {
      fprintf(fp,"Dimension: %i*%i\n",f->lin,f->col);
      fprintf(fp,"Elements:\n\n");
      for(i=1; i<=f->lin; ++i)
      {
        for (j=1; j<=f->col; ++j)
          fprintf(fp,"%-*.*g ",outchar,m_outdig,((vector)(f->st->s[i]))->v[j]);
        fprintf(fp,"\n");
      }
    }
    else
      fprintf(fp,"EMPTY FIELD.\n");
  }
}
else
  printf("ERROR: NULL FIELD.\n");
}


void printfield(field fld)
     /* Izpise polje f na standardni izhod.
     $A Damjan jun98; */
{
fprintfield(stdout,fld);
}


void fprintfieldline(FILE *fp,field fld)
    /* V datoteko fp zapise polje fld, pri cemer vrstice izpise v eni vrsti.
    $A Igor sep97; Damjan jul98 */
{
int i,j;
if (fp!=NULL)
{
  if (fld==NULL)
    fprintf(fp,"NULL FIELD.\n");
  else
    if (fld->lin!=0 && fld->col!=0)
    {
      for (i=1;i<=fld->lin;++i)
      {
        for (j=1;j<=fld->col;++j)
        {
          fprintf(fp,"f[%i][%i]=%-*.*g",i,j,outchar,m_outdig,((vector)(fld->st->s[i]))->v[j]);
          if (j<fld->col)
            fprintf(fp,", ");
        }
        fprintf(fp,"\n");
      }
    }
    else
      fprintf(fp,"EMPTY FIELD.\n");
}
else
  printf("ERROR: NULL FILE.\n");
}


void printfieldline(field fld)
    /* Na standardni izhod zapise polje fld, pri cemer vrstice izpise v eni vrsti.
    $A Igor sep97; Damjan jul98 */
{
  fprintfieldline(stdout,fld);
}


/*** Iskanje n-tega polja ***/

long ffindnthfield(FILE *fp,char *keystr,int n)
    /* Funkcija poisce zacetek polja z imenom keystr, ki je n-to po vrsti
    v datoteki fp. Funkcija vrne pozicijo zacetka imena iskanega polja.
    Ce polja z imenom keystr ni, vrne -1. Ce je polj z imenom keystr manj
    od n, vrne negativno vrednost stevila vseh polj z imenom keystr v
    datoteki fp.
    $A Damjan jun98; */
{
int i=0,buf=20;
long pos=0,ret=-1;

if(fp!=NULL)
{
  while(i<n && pos>=0)
  {
    pos=filestring(fp,keystr,pos+1,buf);
    if(pos>0)
      ++i;
  }
  if(pos>0)
  {
    if(i==n)
      ret=pos;
    else
      ret=-i;
  }
}

return(ret);
}



/*** Splosno branje polj ***/


long freadfieldheader(FILE *fp,char *fieldname,long from,int *lin,int *col)
    /* V datoteki fp najde polje z imenom fieldname od pozicije from naprej
    in prebere dimenzije polja (lin x col). Ce dimenzije ne najde postavi
    lin in col na 0. Funkcija vrne pozicijo zacetka bloka polja, ce pa polja
    z navedenim imenom ne najde vrne -1.
    $A Damjan maj98; */
{
int x,buflength=1000,length;
double r;
long pos,pos1,start,ret=-1;

if(fp!=NULL && fieldname!=NULL && from>0)
{
  pos=filestring(fp,fieldname,from,buflength);
  if (pos>0)
  {
    pos=filechar(fp,"{",1,pos,20);
    pos1=filechar(fp,"\n",1,pos,20);
    pos=filenotchar(fp,"{ \n\r\t\0",6,pos+1,20);
    ret=pos1;
    if(pos<=pos1)
    {
      r=filenum(fp,pos,10,&start,&length);
	  x=(int) round(r);
      while((start>pos) && (start<=pos1))
      {
        pos=filechar(fp," \n\r\t\0",5,pos+1,20);
        pos=filenotchar(fp,"{ \n\r\t\0",6,pos+1,20);
      }
      if((start==pos) && (start<=pos1))
      {
        *col=x;
      }
      else
        *col=1;
      pos=filechar(fp," \n\r\t\0",5,pos,20);
      if(pos>=pos1)
        *lin=1;
      else
      {
        pos=filenotchar(fp,"{ \n\r\t\0",6,pos+1,20);
        if(pos<=pos1)
        {
          r=filenum(fp,pos,10,&start,&length);
          x=(int) round(r);
          while((start>pos) && (start<=pos1))
          {
            pos=filechar(fp," \n\r\t\0",5,pos+1,20);
            pos=filenotchar(fp,"{ \n\r\t\0",6,pos+1,20);
          }
          if(start==pos)
          {
            *lin=x;
          }
          else
            *lin=1;
        }
        else
          *lin=1;
      }
    }
    else
      *col=*lin=0;
  }
}
return(ret);
}

long freadfieldcomp(FILE *fp,long pos,field *fld,int lin,int col)
    /* Iz datoteke fp prebere tabelo stevil (lin x col) od mesta
    pos naprej. Vektorje sestavljene iz stevil v vrsticah tabele nalozi
    na sklad st podatkovne strukture tipa field. Ce stevila vrstic in
    stolpcev (lin, col) ne poznamo vnaprej, postavimo argumenta lin in
    col na 0. V tem primeru funkcija kreira ogrodje strukture in nanj po
    vrsti nalaga vrstice polja, dokler ne naleti na konec polja. V primeru
    napake pri branju dobi polje fld vrednost NULL. Funkcija vrne pozicijo 
    konca polja. V primeru napake vrne -1.
    $A Damjan maj98; */
{
int i,j,cl,temp=0;
long curpos,startpos,endpos,ret=-1;
double x;
vector vect;


if(fp!=NULL)
{
  if(col==0 && lin==0)
  {
    if(*fld!=NULL)
      dispfield(fld);
    startpos=filenotchar(fp,"{ \n\r\t\0",6,pos,20);
    endpos=filestr(fp,"\n",1,startpos,10);
    if(endpos-startpos>0)
    {
      fseek(fp,startpos-1,SEEK_SET);
      cl=0;
      do
      {
        temp=fscanf(fp,"%lg",&x);
        curpos=ftell(fp)+1;
        cl++;
      } while(temp>0 && curpos<=endpos);
      cl--;
      if(cl>0)
      {
        fseek(fp,startpos-1,SEEK_SET);
        i=1;
        *fld=getfield(0,0);
        do
        {
          j=1;
          vect=getvector(cl);
		  /* Reading line */
          do
          {
            temp=fscanf(fp,"%lg",&(vect->v[j]));
            ++j;
          } while((j<=cl) && temp>0);
          if(temp!=0)
          {
            pushstack((*fld)->st,vect);
            ++i;
          }
        } while(temp>0);
        (*fld)->lin=i-1;
        (*fld)->col=cl;
        ret=ftell(fp)+1;
      } else
      {
        dispfield(fld);
        fld=NULL;
      }
    }
  } else
    if(col>0 && lin>0)
    {
      if(*fld!=NULL)
        dispfield(fld);
      *fld=getfield(lin,col);
      fseek(fp,pos-1,SEEK_SET);
      i=1;
      do
      {
        vect=getvector(col);
        j=1;
        do
        {
          temp=fscanf(fp,"%lg",&(vect->v[j]));
          ++j;
        } while((j<=col) && temp>0);
        (*fld)->st->s[i]=vect;
        ++i;
      } while((i<=lin) && (temp>0));
      if(temp==0)
      {
        dispfield(fld);
        fld=NULL;
      } else
        ret=ftell(fp)+1;
    }
}
else
  printf("ERROR: NULL FILE.\n");
return(ret);
}


void fwritefieldcomp(FILE *fp, field f)
     /* Izpise komponente polja f v datoteko fp od trenutne pozicije naprej.
     $A Damjan jun98; */
{
int i,j,lin,col;

if (fp!=NULL)
{
  if (f==NULL)
    fprintf(fp,"NULL FIELD.\n");
  else
  {
    lin=f->lin;
    col=f->col;
    if (col!=0 && lin!=0 && f->st!=NULL)
    {
      for(i=1; i<=lin; ++i)
      {
        for (j=1; j<=col; ++j)
        {
          fprintf(fp,"%-*.*g",outchar,m_outdig,((vector)(f->st->s[i]))->v[j]);
          if(j<col)
            fprintf(fp," ");
        }
        if(i<lin)
          fprintf(fp,"\n");
      }
    }
    else
      printf("EMPTY FIELD.\n");
  }
}
else
  printf("ERROR: NULL FILE.\n");
}


# include "ioelfen.h"
