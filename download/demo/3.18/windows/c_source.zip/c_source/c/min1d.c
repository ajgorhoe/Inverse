/* OPOZORILO! Pazi na funkcijo "absolutnas vrednost" !!! Ime preddefinirane
funkcije za realna stevila je fabs! (double fabs(double)) */

#include <sysint.h>

#include <stdio.h>
#include <math.h>

#include <er.h>

#include <min1d.h>


double funk(double x)
{
return (x*x);
}




double odvod1(double x,double h,double funk(double))
{
return (funk(x+h)-funk(x-h))/(2*h);
}


double odvod(double x,double *h,double funk(double))
{
  double od2,h0/*,hpom*/,f1,f2,f3;
  int i;
  /* hpom=*h+x; */
  for (i=1;i<=1;i++)
  {
    od2=5;
    f1=funk(x+*h); f2=funk(x); f3=funk(x-*h);
    od2=f1-2*f2+f3;
    od2/=(*h * *h);
    od2=(funk(x+*h)-2*funk(x)+funk(x-*h))/(*h* *h);
    if (od2!=0 && funk(x)!=0)
    {
      h0=fabs(1.0e-9*funk(x)/(*h*od2));  /*Konstanta je racunalnikova natancnost*/
      if (*h/h0>5 || *h/h0<1/5) *h=h0;
    }
  }
  return odvod1(x,*h,funk);
}



/*   OBJEMIMIN   */
double objemimin(double *a, double *b, double *c,double funk(double))
/* Minimum funkcije objame z eksponentnim sirjenjem
   intervala*/
{
double zlati=2-3.8196601125e-1;
double d,fa,fb,fc,fd;
fa=funk(*a); fb=funk(*b);
if (fb>fa)
{
  d=*a; *a=*b; *b=d;
  fd=fa; fa=fb; fb=fd;
}
*c=*b+(*b-*a)*zlati;
fc=funk(*c);
while (fc<fb)
{
  *a=*b; *b=*c;
  fa=fb; fb=fc;
  *c=*c+(*b-*a)*zlati;
  fc=funk(*c);
}
if (*a>*c)
{
  d=*c; *c=*a; *a=d;
  fd=fc; fc=fa; fa=fd;
}
return 0;
}




/*   OZIM1D   */
void ozim1d(double *a, double *b, double *c,
              double *fa, double *fb, double *fc,double funk(double))
{
double d,fd;
double zlati=3.8196601125e-1;
if (*b-*a>=*c-*b)
{
  d=*b-(*b-*a)*zlati;
  fd=funk(d);
  if (fd<=*fb)
  {
    *c=*b; *fc=*fb;
    *b=d; *fb=fd;
  } else
  {
    *a=d; *fa=fd;
  }
} else
{
  d=*b+(*c-*b)*zlati;
  fd=funk(d);
  if (fd>=*fb)
  {
    *c=d; *fc=fd;
  }  else
  {
    *a=*b; *fa=*fb;
    *b=d; *fb=fd;
  }
}
}

/*   MIN1D   */
double min1d(double *a, double *b, double *c,
             double tolx, double toly,double funk(double))
{
extern int errordetect[10];
double fa,fb,fc;
/*countan=0;*/
/* POZOR, PAZI NA TA POGOJ! PREMISLI, ALI BOS UPORABIL
   && ALI || ALI KAK BOLJ KOMPLICIRAN POGOJ!  */
fa=funk(*a); fb=funk(*b); fc=funk(*c);
if (*b-*a<=0 || *c-*b<=0)
{
  errfunc0("min1d");
  sprintf(ers(),"Abscisas are in wrong order!\n\n");
  errfunc2();
  goto exitmin1d;
}
if (fb>=fa || fb >=fc)
{
  errfunc0("min1d");
  sprintf(ers(),"It is not necessary that minimum is bracketed!\n\n");
  errfunc2();
  goto exitmin1d;
}
while (fabs(*c-*a)>tolx || fabs(fc-fb)>toly)
{
  ozim1d(a,b,c,&fa,&fb,&fc,funk);
  /*++countan;*/
}
exitmin1d: {}
return *b;
}




/*   BRENT   */
void brent(double *a, double *b, double *c,
           double *fa, double *fb, double *fc,
           double tol, int * it, int maxit,
           double funk(double), int connection(int), FILE *fp)
/* Izolira minimum funkcije funk in ga vrne v b.
   a, b in c so zacetne abscise, biti mora fun(b)<funk(a),
   funk(b)<funk(c). fb je na izhodu vrednost funkcije v b.
   connection je funkcija, ki znotraj te funkcije
   izvede to, kar zahteva zunanje okolje. izvede se pred iterativno
   zanko s parametrom 0, na koncu vsake iteracije s parametrom
   1 in na koncu funkcije s parametrom 2. fp je datoteka, v katero
   se izpisujejo rezultati, it je stevilo iteracij, maxit pa je
   najvecje dovoljeno stevilo iteracij.
   POZOR! Biti mora tol>0!
*/
{
double zlati=0.3819660;
double mali=1.0e-10;
char konec=0;
double d, fd, x, x1, x2, x3, f1, f2, f3, q, r;
double korak, korak1, korak2;
/*
   x1: tocka, kjer ima funkcija funk do sedaj najnizjo vrednost,
   x2: tocka, kjer ima 2. najnizjo vrednost itd.
*/
if (fp!=NULL)
  fprintf(fp,"  Function brent:\n\n");
*it=0;
/* bprej=*b; */
korak=korak1=korak2=0;
x1=*b; f1=*fb;   /* tocka z najnizjo vrednostjo funkcije */
if (*fa<*fc)
{
  x2=*a; f2=*fa; /* tocka z 2. najnizjo vrednostjo funkcije */
  x3=*c; f3=*fc;
} else
{
  x2=*c; f2=*fc;
  x3=*a; f3=*fa;
}
connection(1);
while (! (konec))   /*galvna zanka*/
{
  /*Parabolicna interpolacija minimuma u*/
  r=(x1-x2)*(f1-f3);
  q=(x1-x3)*(f1-f2);
  x=2*(q-r);
  if (fabs(x)>1.0e-20)
    d=x1-((x1-x3)*q-(x1-x2)*r)/x;
  else
  {
    if (x<0)
      d=x1-((x1-x3)*q-(x1-x2)*r)/(-1.0e-20);
    else
      d=x1-((x1-x3)*q-(x1-x2)*r)/(-1.0e-20);
  }
  korak=fabs(*b-d);
  if (d>*a && d<*c && korak<0.8*korak2 && d!=*b)
  /* Parabolicno interpolacijo lahko uporabimo kot novo tocko*/
  {
    fd=funk(d);
  } else
  /* d postane nova tocka po zlatem rezu*/
  {
    if (*b-*a>=*c-*b)
    {
      d=*b-(*b-*a)*zlati;
      if (*c-*b>0)
        if ((*b-*a)/(*c-*b)>4)
          d=*b-2*(*c-*b);
    } else
    {
      d=*b+(*c-*b)*zlati;
      if (*b-*a>0)
        if ((*c-*b)/(*b-*a)>4)
          d=*b+2*(*b-*a);
    }
    fd=funk(d);
    korak=fabs(d-*b);
  }
  if (d<*b)
  {
    /*
    if (fabs((*fa-fd)/(mali+fabs(fd)))<tol &&
     fabs((fd-*fb)/(mali+fabs(fd)))<tol)
      konec=1;
    */
    if (fd<=*fb)
    {
      *c=*b; *fc=*fb;
      *b=d; *fb=fd;
    } else
    {
      *a=d; *fa=fd;
    }
  } else /*d>=b*/
  {
    /*
    if (fabs((*fb-fd)/(mali+fabs(fd)))<tol &&
     fabs((fd-*fc)/(mali+fabs(fd)))<tol)
      konec=1;
    */
    if (fd>*fb)
    {
      *c=d; *fc=fd;
    } else
    {
      *a=*b; *fa=*fb;
      *b=d; *fb=fd;
    }
  }
  if (fd<f1)
  {
    x3=x2; f3=f2;
    x2=x1; f2=f1;
    x1=d; f1=fd;
  } else if (fd<f2)
  {
    x3=x2; f3=f2;
    x2=d; f2=fd;
  } else if (fd<f3)
  {
    x3=d; f3=fd;
  }
  korak2=korak1;
  korak1=korak;
  if (*it>=maxit)
    konec=1;
  ++ *it;
  connection(2);
  if (fp!=NULL)
  {
    fprintf(fp,"a: %20.15g,    fa: %20.15g\n",*a,*fa);
    fprintf(fp,"b: %20.15g,    fb: %20.15g\n",*b,*fb);
    fprintf(fp,"c: %20.15g,    fc: %20.15g\n\n",*c,*fc);
  }
  /*
  if ( fabs((*fa-*fb)/(mali+fabs(*fa)+fabs(*fb)))<=tol &&
       fabs((*fc-*fb)/(mali+fabs(*fc)+fabs(*fb)))<=tol) konec=1;
   */
  if ( fabs(*fa-*fb)<=tol*(mali+fabs(*fa)+fabs(*fb)) &&
       fabs(*fc-*fb)<=tol*(mali+fabs(*fc)+fabs(*fb))  ) konec=1;
}
connection(3);
if (fp!=NULL)
  fprintf(fp,"\n\n");
}






/*   BRENTABS   */
void brentabs(double *a, double *b, double *c,
           double *fa, double *fb, double *fc,
           double tol, int * it, int maxit,
           double funk(double), int connection(int), FILE *fp)
/* Izolira minimum funkcije funk in ga vrne v b.
   a, b in c so zacetne abscise, biti mora fun(b)<funk(a),
   funk(b)<funk(c). fb je na izhodu vrednost funkcije v b.
   connection je funkcija, ki znotraj te funkcije
   izvede to, kar zahteva zunanje okolje. izvede se pred iterativno
   zanko s parametrom 0, na koncu vsake iteracije s parametrom
   1 in na koncu funkcije s parametrom 2. fp je datoteka, v katero
   se izpisujejo rezultati, it je stevilo iteracij, maxit pa je
   najvecje dovoljeno stevilo iteracij.
   POZOR! Biti mora tol>0!
     Ta funkcija je podobna funkciji brent, le konvergencni kriterij je
     drugacen. Konvergenca je dosezena, ko je najvecja absolutna vrednost
     razliki funkcijskih vrednosti manjsa ali enaka tol.
*/
{
double zlati=0.3819660;
/* double mali=1.0e-10; */
char konec=0;
double d, fd, x, x1, x2, x3, f1, f2, f3, q, r;
double korak, korak1, korak2;
/*
   x1: tocka, kjer ima funkcija funk do sedaj najnizjo vrednost,
   x2: tocka, kjer ima 2. najnizjo vrednost itd.
*/
if (fp!=NULL)
  fprintf(fp,"  Function brent:\n\n");
*it=0;
/* bprej=*b; */
korak=korak1=korak2=0;
x1=*b; f1=*fb;   /* tocka z najnizjo vrednostjo funkcije */
if (*fa<*fc)
{
  x2=*a; f2=*fa; /* tocka z 2. najnizjo vrednostjo funkcije */
  x3=*c; f3=*fc;
} else
{
  x2=*c; f2=*fc;
  x3=*a; f3=*fa;
}
connection(1);
while (! (konec))   /*galvna zanka*/
{
  /*Parabolicna interpolacija minimuma u*/
  r=(x1-x2)*(f1-f3);
  q=(x1-x3)*(f1-f2);
  x=2*(q-r);
  if (fabs(x)>1.0e-20)
    d=x1-((x1-x3)*q-(x1-x2)*r)/x;
  else
  {
    if (x<0)
      d=x1-((x1-x3)*q-(x1-x2)*r)/(-1.0e-20);
    else
      d=x1-((x1-x3)*q-(x1-x2)*r)/(-1.0e-20);
  }
  korak=fabs(*b-d);
  if (d>*a && d<*c && korak<0.8*korak2 && d!=*b)
  /* Parabolicno interpolacijo lahko uporabimo kot novo tocko*/
  {
    fd=funk(d);
  } else
  /* d postane nova tocka po zlatem rezu*/
  {
    if (*b-*a>=*c-*b)
    {
      d=*b-(*b-*a)*zlati;
      if (*c-*b>0)
        if ((*b-*a)/(*c-*b)>4)
          d=*b-2*(*c-*b);
    } else
    {
      d=*b+(*c-*b)*zlati;
      if (*b-*a>0)
        if ((*c-*b)/(*b-*a)>4)
          d=*b+2*(*b-*a);
    }
    fd=funk(d);
    korak=fabs(d-*b);
  }
  if (d<*b)
  {
    /*
    if (fabs((*fa-fd)/(mali+fabs(fd)))<tol &&
     fabs((fd-*fb)/(mali+fabs(fd)))<tol)
      konec=1;
    */
    if (fd<=*fb)
    {
      *c=*b; *fc=*fb;
      *b=d; *fb=fd;
    } else
    {
      *a=d; *fa=fd;
    }
  } else /*d>=b*/
  {
    /*
    if (fabs((*fb-fd)/(mali+fabs(fd)))<tol &&
     fabs((fd-*fc)/(mali+fabs(fd)))<tol)
      konec=1;
    */
    if (fd>*fb)
    {
      *c=d; *fc=fd;
    } else
    {
      *a=*b; *fa=*fb;
      *b=d; *fb=fd;
    }
  }
  if (fd<f1)
  {
    x3=x2; f3=f2;
    x2=x1; f2=f1;
    x1=d; f1=fd;
  } else if (fd<f2)
  {
    x3=x2; f3=f2;
    x2=d; f2=fd;
  } else if (fd<f3)
  {
    x3=d; f3=fd;
  }
  korak2=korak1;
  korak1=korak;
  if (*it>=maxit)
    konec=1;
  ++ *it;
  connection(2);
  if (fp!=NULL)
  {
    fprintf(fp,"a: %20.15g,    fa: %20.15g\n",*a,*fa);
    fprintf(fp,"b: %20.15g,    fb: %20.15g\n",*b,*fb);
    fprintf(fp,"c: %20.15g,    fc: %20.15g\n\n",*c,*fc);
  }
  /*
  if ( fabs((*fa-*fb)/(mali+fabs(*fa)+fabs(*fb)))<=tol &&
       fabs((*fc-*fb)/(mali+fabs(*fc)+fabs(*fb)))<=tol) konec=1;
  */
  if ( fabs(*fa-*fb)<=tol &&
       fabs(*fc-*fb)<=tol  ) konec=1;
}
connection(3);
if (fp!=NULL)
  fprintf(fp,"\n\n");
}




/*   BRAKMIN   */
void brakmin(double *a, double *b, double *c,
             double *fa, double *fb, double *fc,
             int *it, int maxit,
             double funk(double), int connection(int), FILE *fp)
/* Minimum funkcije objame z eksponentnim sirjenjem
   intervala, pomaga pa si tudi s parabolicno
   interpolacijo. connection je funkcija, ki znotraj te funkcije
   izvede to, kar zahteva zunanje okolje. izvede se pred iterativno
   zanko s parametrom 0, na koncu vsake iteracije s parametrom
   1 in na koncu funkcije s parametrom 2.
   fa in fb morata ze na zacetku vsebovati vrednost funkcije funk
   v tockah a in b. Po izvedbi funkcije so v fa, fb in fc vrednosti
   funkcije funk v tockah a, b in c.
   */
{
double zlati=2-0.38196601125;
double umeja=100.0; /*zgor. meja za (u-b)/(c-b), u je
                   teme parabole*/
double u,fu;
double r,q,x;
char konec=0;
if (fp!=NULL)
  fprintf(fp,"  Function brakmin:\n\n");
*it=0;
/* Zagotovi se, da sta tocki a in b ustrezni za zacetek postopka */
if (*a==*b)
{
  *b*=1.001;
  if(*a==0)
    *b=1.0e-5;
  *fb=funk(*b);
}
if (*fa==*fb)
{
  *b*=1.0001;
  *fb=funk(*b);
}
while (*fa==*fb)
{
  if(*b==0)
    *b=1.0e-5;
  *b*=2;
  *fb=funk(*b);
}
if (*fb>*fa)
{
  x=*b; *b=*a; *a=x;
  x=*fb; *fb=*fa; *fa=x;
}
*c=*b+(*b-*a)*zlati;
*fc=funk(*c);
connection(0);
do
{
  if (*fc>*fb)
    konec=1;
  else /*Poskusimo s temenom parabole skozi a,b in c*/
  /*V tem bloku je *fc<*fb*/
  {
    r=(*b-*a)*(*fb-*fc);
    q=(*b-*c)*(*fb-*fa);
    x=2*(q-r);
    if (fabs(x)>1.0e-20)
      u=*b-((*b-*c)*q-(*b-*a)*r)/x;
    else if (x>=0)
      u=*b-((*b-*c)*q-(*b-*a)*r)/1.0e-20;
    else if (x<0)
      u=*b-((*b-*c)*q-(*b-*a)*r)/(-1.0e-20);
    if (fabs((u-*a)/(*c-*a))>umeja)
      u=*c+umeja*(*c-*a);
    /*Preizkusanje temena parabole glede na njegovo lego: */
    if ((*b-u)*(u-*c)>0) /* u med b in c */
    {
      fu=funk(u);
      if (fu<*fc) /* Minimum je med b in c */
      {
        *a=*b; *fa=*fb;
        *b=u; *fb=fu;
        konec=1;
      }  else if (fu>*fb) /* Minimum je med a in c */
      {
        *c=u; *fc=fu;
        konec=1;
      } else /* Z u si ne moremo pomagati */
      {
        *a=*b; *fa=*fb;
        *b=*c; *fb=*fc;
        *c=*b+(*b-*a)*zlati;
        *fc=funk(*c);
      }
    } else if ((u-*b)/(*c-*b)>zlati)  /* u>c */
    {
      fu=funk(u);
      if (fu>*fc)
      {
        *a=*b; *fa=*fb;
        *b=*c; *fb=*fc;
        *c=u; *fc=fu;
        konec=1;
      } else
      {
        *a=*c; *fa=*fc;
        *b=u; *fb=fu;
        *c=*b+(*b-*a)*zlati;
        *fc=funk(*c);
      }
    } else
    {
      *a=*b; *fa=*fb;
      *b=*c; *fb=*fc;
      *c=*b+(*b-*a)*zlati;
      *fc=funk(*c);
    }
  }
  connection(1);

  if (fp!=NULL)
  {
    fprintf(fp,"a: %20.15g,    fa: %20.15g\n",*a,*fa);
    fprintf(fp,"b: %20.15g,    fb: %20.15g\n",*b,*fb);
    fprintf(fp,"c: %20.15g,    fc: %20.15g\n\n",*c,*fc);
  }
  
  ++ *it;
  if (*it>=maxit) konec=1;
} while (! konec);
if (*a>*c)
{
  x=*c; *c=*a; *a=x;
  x=*fc; *fc=*fa; *fa=x;
}
connection(2);
if (fp!=NULL)
  fprintf(fp,"\n\n");
}
















































