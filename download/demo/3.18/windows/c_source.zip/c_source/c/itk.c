
      /* THE ITK SYSTEM (Tcl/Tk extension) */

#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>

#include <mtypes.h>
#include <er.h>
#include <vec.h>
#include <mat.h>
#include <st.h>
#include <rf.h>
#include <mtime.h>
#include <strop.h>
#include <fop.h>
#include <globut.h>


#include <itk.h>



#ifdef ITK



/* static Tcl_ThreadId mainthread=0; */  /* Thread ID of the main thread */
static int mainthread=0;
static int mainthreadobtained=0;

/* Auxiliary interpreter fo Tcl commands in the main thread: */
static Tcl_Interp *tclinterp=NULL;
/* Request data for ITK server, only for the main thread: */
static itkrequest itkserverrequest=NULL;
/* Data for the thread procedure implementing the ITK and IEK server: */
static itkthreaddata itkthread=NULL,iekthread=NULL;
static int tclin=0,itkin=0,iekin=0;  /* initialization flags */
static int tclrec=0,iekrec=0; /* init. recursion prevention */
/* Sleeping parameters for loading command requests: */
static int loadrequestsleep=1,manycommands=900,comstex=1000;
static Tcl_Condition *mutexptr=NULL;





    /* AUXILIARY UTILITIES FOR USE OF ITK: */


double tcl_absolutetime(void)
    /* Returns the absolute time in seconds. Milliseconds are also
    returned as a decimal part of the return value.
    $A Igor apr03, jun03; */
{
#ifdef ITK
  char *reschar=NULL;
  static char difobtained=0;
  static double difference=0;
  double ret=0;
  /*
  Tcl_Time ts;
  Tcl_GetTime(&ts);
  ret=ts.sec+(double) ts.usec/1000000;
  */
  /* return absolutetime(); */  /* POPRAVI, ko bo na voljo Tcl_GetTime! */
  reschar=tcl_interpretcp("clock clicks -milliseconds",NULL);
  ret=atof(reschar)/1000;
  if (!difobtained)
  {
    /* We equal Tcl's absolute time with the standard library's one (within
    its accuricy of 1 second): */
    difference=stdabsolutetime();
    difference=ret-difference;
    difobtained=1;
  }
  ret-=difference;
  disppointer((void **) &reschar);
  return ret;
#else
  return absolutetime();
#endif
}


void tcl_sleep(double sec)
    /* Sleeps (pauses the process) for a given number of seconds.
    $A Igor jun03; */
{
#ifdef ITK
  Tcl_Sleep((int) round(1000.0*sec));
#else
  int intsec=0;
  intsec=(int) round(sec);
  if (sec>0 && intsec==0)
    intsec=1
  sleep(intsec);
#endif
}


int tcl_processallevents(void)
    /* Processes all events in the queu; used for example to block until
    all user response is processed, windows are refreshed etc. Returns the
    number of events that were processed.
    $A Igor jun03; */
{
int proc=1,ret=0;
while (proc!=0)
{
  proc=Tcl_DoOneEvent(TCL_DONT_WAIT | TCL_ALL_EVENTS);
  ret+=proc;
}
return ret;
}


int tcl_processquickevents(void)
    /* Processes all events in the queu that can usually be processed quickly;
    used for example to enable close to normal GUI behavior during a time
    consuming operations such as drawing, but without disturbing the operation
    too much.
    $A Igor jun03; */
{
int proc=1,ret=0;
while (proc!=0)
{
  proc=Tcl_DoOneEvent(TCL_DONT_WAIT | TCL_TIMER_EVENTS | TCL_WINDOW_EVENTS 
    | TCL_FILE_EVENTS );
  ret+=proc;
  /*
  if (proc)
    printf("*");
  */
}
return ret;
}


int getthreadid(void)
    /* Returns the identification number of the current thread. Tcl returns
    the identification which is a pointer, but this pointer is unique (since
    it is not dynamically allocated) and constant for each thread, so it can
    be converted to an integer used for identification.
    $A Igor apr03; */
{
if (!tclin)
  tcl_initialize();
return (int) Tcl_GetCurrentThread();
}


int getmainthreadid(void)
    /* Return the identification number of the main program thread.
    $A Igor apr03; */
{
if (!tclin)
  tcl_initialize();
return mainthread;
}


int ismainthread(void)
    /* Returns 1 if the current thread is the main program thread, 0 otherwise.
    $A Igor apr03; */
{
if (!tclin)
  tcl_initialize();
if ((int) Tcl_GetCurrentThread()!=mainthread)
  return 0;
else
  return 1;
}


int getitkthreadid(void)
    /* Return the identification number of the ITK server thread.
    $A Igor apr03; */
{
if (!itkin)
  itk_initialize();
return itkthread->thread;
}



static int launchthread=0, /* Thread launching lock */
           launchthreadid=-1,  /* ID of the launching thread */
           numlaunchedthreads=0,   /* Number of launched threads */
           numthreads=0,  /* Number of running threads (besides the main one) */
           testthreadid=-1, /* ID of the test thread */
           nothreads=0;    /* 1 indicates that threads are not supported */
/* Indicator for giving the prev. launched thread additional time to call the
main proc. $$
static int shouldwait=0;
*/
/* The main procedure for the thread to be launched: */
static void (*threadproc)(void *ptr)=NULL;

#ifdef MAC_TCL
  static pascal void *(threadprocarg) _ANSI_ARGS_((ClientData ptr))
#elif defined __WIN32__
  static unsigned (__stdcall threadprocarg) _ANSI_ARGS_((ClientData ptr))
#else
  static void (threadprocarg) _ANSI_ARGS_((ClientData ptr))
#endif
    /* The main procedure of the ITK thread.
    $A Igor apr04; */
{
void (*localthreadproc)(void *ptr)=threadproc;
/* $$ --launchthread;  /* Release the additional safety lock */
m_threadunlock(launchthread); /* Release the lock set in createthread() */
localthreadproc(ptr);
--numthreads; /* thread proc. finished, one less active thread */

#ifdef MAC_TCL
  return 0;
#elif defined __WIN32__
  return 0;
#else
  return;
#endif
}

static void testthreadproc(void *ptr)
    /* A dummy thread procedure used as an argument to createthread() for the
    first thread launch; The first thread is launched with this empty
    procedure in order that it returns immediately and finds out whether 
    threads are really supported or not.
    $A Igor feb03; */
{
  testthreadid=getthreadid();
}


int createthread(void procmain(void *),void *data)
    /* Creates a new thread and returns its identification number. procmain
    is the main procedure for the new thread and data is an argument to this
    procedure.
    A special mechanism ensures that every thread calls the appropriate
    procedure which was passed as the procmain argument to this function.
    Bodies of this function are serialised, therefore thefunction is thread
    safe and can even be called recursively in procmain.
    $A Igor apr03; */
{
int ret=-1,currentthreadid;
Tcl_ThreadId id;
double t0,timeout=1.0;
currentthreadid=getthreadid();
if (numlaunchedthreads==0)
{
  ++numlaunchedthreads; /* avoie infinite recursion */
  createthread(testthreadproc,NULL);
  --numlaunchedthreads; /* compensate previous recursion */
  /* --numlaunchedthreads; don't cout this as the first launch; it will be
    registered at the end of the function */
  t0=absolutetime();
  /* Wait until test thread procedure finishes in order to ensure that it
  writes its thread ID to testthreadid, or timeout occurs */
  while (numthreads && absolutetime()-t0<timeout)
    ;
  if (numthreads)
  {
    /* Timeout occured before the test thread procedure was executed */
    warnfunc1(1,"createthread");
    sprintf(ers(),"Timeout occured while waiting for test thread procedure to execute.\n");
    sprintf(ers(),"It is possible that threads are not supported on this system.\n");
    warnfunc2();
    printf("\n\nA thread was lounchet but a timeout occured when waiting for it to\n");
    printf("execute.\n");
    printf("Input an additional time in seconds to wait for the thread or 0\n");
    printf("if you don't want to wait anymore:  ");
    readdouble(&timeout);
    t0=absolutetime();
    while (numthreads && absolutetime()-t0<timeout)
      ;
    if (numthreads)
    {
      testthreadid=currentthreadid;
      numthreads=0;
      m_threadunlock(launchthread);
    } else
    {
      printf("\n\nThread has been finally launched.\n\n");
    }
  }
  if (currentthreadid==testthreadid)
  {
    nothreads=1;
    errfunc0("createthread");
    sprintf(ers(),"Threads are not available.\n");
    sprintf(ers(),"Either the system does not allow multiple threads per process\n");
    sprintf(ers(),"or the Tcl/Tk library was linked without thread support functionality.\n");
    errfunc2();
  }
}
/* $$
if (launchthread>0)
  shouldwait=1;  * previously launched thread has not yet launched its main procedure *
else
  shouldwait=0; */
if (nothreads /* launchthread>0 && launchthreadid==currentthreadid */)
{
  warnfunc1(1,"createthread");
  sprintf(ers(),"Attempt to launch a thread while threads are not available.\n");
  sprintf(ers(),"The procedure will be run in the main thread, however this can cause\n");
  sprintf(ers(),"the program to hang if the thread is synchronized with other threads\n");
  sprintf(ers(),"at some point.\n");
  errfunc2();
  procmain(data);
} else
{
  m_threadlocksleep(launchthread,1);  /* lock thread launching */
  launchthreadid=currentthreadid;  /* set ID of the launching thread */
  /* $$ ++launchthread;  Additional safety lock for launching the right procedure,
  decremented back in threadprocarg() after picking the thread proceadure from
  threadproc */
  if (!tclin)
    tcl_initialize();
  /* $$
  Give thread additional time to start its main procedure (before setting
  the threadproc to a new procedure): *
  if (shouldwait)
    Tcl_Sleep(1);
  */
  threadproc=procmain;
  Tcl_CreateThread(&id,threadprocarg,data,TCL_THREAD_STACK_DEFAULT,TCL_THREAD_NOFLAGS);
  ret=(int) id;
  /* $$
  m_threadunlock(launchthread);
  */
}
++numlaunchedthreads;
++numthreads;
return ret;
}



void tcl_appendarg (char **comaddr,char *arg)
    /* Appends argument arg to the tcl list *comaddr. It converts arg in such a
    way that it is a proper tcl list element, and avoids putting strings in
    curly brackets.
      Warning:
      Even if arg is NULL, function appends it as an empty argument. Therefore,
    if anyhow arh should not appended to the list, this must be arranged by not
    calling this kfunction.
    $A Igor apr04; */
{
int length,flags;
char *res;
if (comaddr!=NULL)
{
  length=Tcl_ScanElement(arg,&flags);
  res=malloc(length+2);
  *res=' ';
  length=Tcl_ConvertElement(arg,res+1,flags | TCL_DONT_USE_BRACES);
  stringappend(comaddr,res);
  disppointer((void **) &res);
}
}


void tcl_appendargbrac (char **comaddr,char *arg)
    /* Appends argument arg to the tcl list com. It converts arg in such a way
    that it is a proper tcl list element. As opposed to tcl_appendarg, this
    function often embeds a string in curly brackets.
      Warning:
      Even if arg is NULL, function appends it as an empty argument. Therefore,
    if anyhow arh should not appended to the list, this must be arranged by not
    calling this kfunction.
    $A Igor apr04; */
{
int length,flags;
char *res;
if (comaddr!=NULL)
{
  length=Tcl_ScanElement(arg,&flags);
  res=malloc(length+2);
  *res=' ';
  length=Tcl_ConvertElement(arg,res+1,flags);
  stringappend(comaddr,res);
  disppointer((void **) &res);
}
}




char *tcl_listelsubst(char *str)
    /* Returns a copy of the string str, which is modified in such a way
    that it can be a list element, but still allows all substitutions when
    used as command arguments. The string is enclosed in double 1uotes if
    possible and necessary.
    $A Igor apr04; */
{
int length,flags;
char *res=NULL;
length=Tcl_ScanElement(str,&flags);
res=malloc(length+1);
length=Tcl_ConvertElement(str,res,flags | TCL_DONT_USE_BRACES);
return res;
}




char *tcl_stcomsubst(stack list)
    /* Forms a valid Tcl command from a set of strings which are on the stack
    list. The first string on the stack must be the procedure name while the
    subsequent strings are argument. Function converts elements of the stack to
    valid list elements and merges them with separating spaces inserted. The
    returned string is dynamically allocated and can be relesed by free().
    The command must be obtained by using this or a similar function when
    the procedure name or its arguments contain spaces or special characters
    or when they are DOS-like file names.
      Warning:
      The command is such that no string substitution can be done on proc.
    arguments.
    $A Igor apr04; */
{
char *ret=NULL,*cur=NULL,*el=NULL;
int i;
for (i=1;i<=list->n;++i)
{
  el=tcl_listelsubst(list->s[i]);
  ret=multstringcat(cur," ",el,NULL);
  disppointer((void **) &cur);
  cur=ret;
  disppointer((void **) &el);
}
return ret;
}


char *tcl_multstrcomsubst(char *first,...)
    /* Forms a valid Tcl command from a set of strings which are arguments of
    this function. The first argument must be the procedure name while the
    subsequent strings are arguments. Function converts elements of the stack to
    valid list elements and merges them with separating spaces inserted. The
    returned string is dynamically allocated and can be relesed by free().
    The command must be obtained by using this or a similar function when
    the procedure name or its arguments contain spaces or special characters
    or when they are DOS-like file names.
      WARNING:
      The last argument must be NULL to terminate the string list! Take care
    that none of the strings intended as arguments is NULL, since such an
    argument will terminate the list and would not be treated as an argument
    itself. If the situation is not clear, use multiple calls to tcl_appendarg.
      The command is such that no string substitution can be done on proc.
    arguments.
      Each non-NULL argument must be an individual argument of a Tcl procedure
    (or its name - the first arg.).
    $A Igor apr04; */
{
int i,j,num=0,length=0;
char *arg=first,*ret=NULL,*ptr,*el;
stack st;
va_list ap;
va_start(ap,first);
st=newstack(5);
arg=first;
while(arg!=NULL)
{
  num+=1;
  el=tcl_listelsubst(arg);
  length+=stringlength(el)+1; /* 1 for separating space */
  /*
  disppointer((void **) &el);
  */
  pushstack(st,el);
  arg=va_arg(ap,char *);
}
if (length>0)
{
  ret=malloc(length+1); /* 1 char. for ending '\0' */
  ret[length]='\0';
  ptr=ret;
  va_start(ap,first);
  arg=first;
  for (i=1;i<=num;++i)
  {
    /*
    el=tcl_listelsubst(arg);
    */
    el=st->s[i];
    length=stringlength(el);
    for (j=0;j<length;++j)
    {
      *ptr=el[j];
      ++ptr;
    }
    if (i<num)
      *ptr=' ';   /* separating space */
    else
      *ptr='\0';
    ++ptr;
    disppointer((void **) &el);
    arg=va_arg(ap,char *);
  }
}
dispstack(&st);
return ret;
}





char *tcl_stcom(stack list)
    /* Forms a valid Tcl command from a set of strings which are on the stack
    list. The first string on the stack must be the procedure name while the
    subsequent strings are argument. Function converts elements of the stack to
    valid list elements and merges them with separating spaces inserted. The
    returned string is dynamically allocated and can be relesed by free().
    The command must be obtained by using this or a similar function when
    the procedure name or its arguments contain spaces or special characters
    or when they are DOS-like file names.
      Warning:
      The command is such that no string substitution can be done on proc.
    arguments.
    $A Igor apr04; */
{
char *ret=NULL,*cur=NULL,*el=NULL;
int i;
for (i=1;i<=list->n;++i)
{
  el=Tcl_Merge(1,(const char **) &(list->s[i]));
  ret=multstringcat(cur," ",el,NULL);
  disppointer((void **) &cur);
  cur=ret;
  Tcl_Free(el);
}
return ret;
}


char *tcl_multstrcom(char *first,...)
    /* Forms a valid Tcl command from a set of strings which are arguments of
    this function. The first argument must be the procedure name while the
    subsequent strings are argument. Function converts elements of the stack to
    valid list elements and merges them with separating spaces inserted. The
    returned string is dynamically allocated and can be relesed by free().
    The command must be obtained by using this or a similar function when
    the procedure name or its arguments contain spaces or special characters
    or when they are DOS-like file names.
      WARNING:
      The last argument must be NULL to terminate the string list!
      The command is such that no string substitution can be done on proc.
    arguments.
    $A Igor apr04; */
{
int i,j,num=0,length=0;
char *arg=first,*ret=NULL,*ptr,*el;
va_list ap;
va_start(ap,first);
arg=first;
while(arg!=NULL)
{
  num+=1;
  el=Tcl_Merge(1,(const char **) &arg);
  length+=stringlength(el)+1; /* 1 for separating space */
  Tcl_Free(el);
  arg=va_arg(ap,char *);
}
if (length>0)
{
  ret=malloc(length+1); /* 1 char. for ending '\0' */
  ret[length]='\0';
  ptr=ret;
  va_start(ap,first);
  arg=first;
  for (i=1;i<=num;++i)
  {
    el=Tcl_Merge(1,(const char **) &arg);
    length=stringlength(el);
    for (j=0;j<length;++j)
    {
      *ptr=el[j];
      ++ptr;
    }
    if (i<num)
      *ptr=' ';   /* separating space */
    else
      *ptr='\0';
    ++ptr;
    Tcl_Free(el);
    arg=va_arg(ap,char *);
  }
}
return ret;
}


int tcl_okcode(int retcode)
    /* Returns 0 if the Tcl interpretation return code retcode indicates an
    error, 1 otherwise.
    $A Igor jul03; */
{
if (retcode==TCL_OK)
  return 1;
else
  return 0;
}



   /* INITIALIZATION OF INTERPRETERS */


char *globutighomeprimitive(void);

void tcl_init(Tcl_Interp **interpaddr)
    /* Creates the Tcl interpreter if not yet created and performs the Tcl
    initialisation on the interpreter.
    $A Igor apr03; */
{
Tcl_Interp *tclint=NULL;
char *ighome=NULL,*initfile=NULL,*initdir=NULL,*com=NULL;
int code;
double x=1;
if (interpaddr==NULL)
{
  errfunc0("tcl_init");
  sprintf(ers(),"Interpreter address is NULL.\n");
  errfunc2();
  return;
} else if (*interpaddr!=NULL)
{
  warnfunc1(1,"tcl_init");
  sprintf(ers(),"The interpreter has already been initialized.\n");
  warnfunc2();
} else
{
  *interpaddr=Tcl_CreateInterp();
  if (!mainthreadobtained)
  {
    mainthread=getthreadid();
    mainthreadobtained=1;
  }
  else
  {
    /* PREVERI, zakaj se mora to ponoviti! Pri tem se obicajno zgodi, da mainthread
    postane ID od threada ITK interpreterja!! */
    /*mainthread=*/getthreadid();
  }
  tclint=*interpaddr;
  /* 
  (int) Tcl_GetCurrentThread();
  */
#if 0
  /* This was an attempt to avoid errors in Tcl initializatin. However, the 
  error was obviously in the Tcl library, not in inconsistent logics of this
  initialization function (it seemed first that conflicts arise because file
  operations, which must be performed for determiing the software directories,
  call Tcl interpreter, which is in turn not yet initialized. I will however
  leave this segment of code here since it might be useful for some testing.*/
  
  /* WARNING: It seems there is something wrong with this code!!! There is a
  crash, which does not appear when this segment is switched off (#if 0).
    Strange observation: crash does not occur when the code is run in the
  debugger! While run outside the debugger, crash occured at the first 
  function that triggered the Tcl initialization, in the particular case
  this was a call to ismainthread(). Even when the program was just run through
  in the debugger (run without any breakpoints) it did not crach, but when run
  our of the debugger it crashes immediately.
    Remark: found error in calling multdirplusfile, it was called without the last
  argument NULL, maybe this was the problem.

  */
  if (!tclin)
  {
    /*  For Provisional initialization; full initialization can not be done at
    this moment because the software directories are not known, and knowing
    them requires use of this Tcl interpreter (for file operations), which is
    not yet initialized. So only a provisional initialization is made in order
    to enable the final initialization later */
    ighome=globutighomeprimitive();
    initfile=multdirplusfile(ighome,"itk/tcltk/tcl","init.tcl",NULL);
    if (!fileexistsprimitive(initfile))
    {
      warnfunc1(1,"tcl_init");
      sprintf(ers(),"Tcl initialisation script \"%s\" \ndoes not exist.\n",initfile);
      sprintf(ers(),"Please provide the correct path to the software initialization script!\n");
      warnfunc2();
      printf("\n\nInput the correct path of a valid Tcl initialization script init.tcl!\n");
      readstring(&initfile);
      if (!fileexistsprimitive(initfile))
      {
        errfunc0("tcl_init");
        sprintf(ers(),"Tcl initialisation script \"%s\" \ndoes not exist.\n",initfile);
        errfunc2();
        exit(1);
      }
    }


    /* Now initialize the interpreter: */
    initdir=parentdir(initfile);
    changepathseparators(initdir,'/');
    com=stringcat("set tcl_library ",initdir);
    /*
    printf("Tcl initialization file: %s.\n",initfile);
    printf("Tcl library: %s.\n",initdir);
    printf("Library initialization command: %s\n",com);
    */
    code=Tcl_Eval(tclint,com);
    if (code!=TCL_OK)
    {
      errfunc0("tcl_init");
      sprintf(ers(),"Error while interpreting \"%s\".\nTcl error report:\n",com);
      sprintf(ers(),"%s",tclint->result);
      errfunc2();
    }
    disppointer((void **) &initfile);
    disppointer((void **) &initdir);
    disppointer((void **) &com);
    if (Tcl_Init(tclint)==TCL_ERROR)
    {
      errfunc0("tcl_init");
      sprintf(ers(),"Tcl_Init failed.\nTcl error report:\n");
      sprintf(ers(),"%s",tclint->result);
      errfunc2();
    }
    return;
  }
#endif
  /* Retreives the software home if not yet retrieved */
  ighome=globutgetighome();
  /* Try to establish the Tcl version in order to determine which directory to use
  for initialization: */
  com=stringcopy("set tcl_version");
  code=Tcl_Eval(*interpaddr,com);
  if (code!=TCL_OK)
  {
    errfunc0("tcl_init");
    sprintf(ers(),"Error while interpreting \"%s\".\nTcl error report:\n",com);
    sprintf(ers(),"%s",(*interpaddr)->result);
    errfunc2();
    /*
    printf("\n\nInsert a number to continue! "); readdouble(&x);
    printf("\n");
    */
  } else
  {
    disppointer((void **) &com);
    com=stringcopy((*interpaddr)->result);
    initdir=stringcat("itk/tcltk/tcl",com);
    initfile=globuthomefindfirst(initdir,NULL,"init.tcl",NULL);
    if (initfile==NULL)
    {
      warnfunc1(3,"tcl_init");
      sprintf(ers(),"Tcl initialization scripts for version %s not found.\n",com);
      sprintf(ers(),"Trying to locate general scripts, error will be reported if not found.\n");
      warnfunc2();
    }
  }
  disppointer((void **) &com);
  disppointer((void **) &initdir);
  if (initfile==NULL)
    initfile=globuthomefindfirst("itk/tcltk/tcl",NULL,"init.tcl",NULL);
  if (initfile==NULL)
  {
    errfunc0("tcl_init");
    sprintf(ers(),"Tcl initialization scripts like init.tcl not found.\n");
    sprintf(ers(),"Check the itk/tcltk/tcl sub-directory of the directory %s.\n",ighome);
    errfunc2();
  } else
  {
    initdir=parentdir(initfile);
    changepathseparators(initdir,'/');
    com=stringcat("set tcl_library ",initdir);
    /*
    printf("Tcl initialization file: %s.\n",initfile);
    printf("Tcl library: %s.\n",initdir);
    printf("Library initialization command: %s\n",com);
    */
    code=Tcl_Eval(tclint,com);
    if (code!=TCL_OK)
    {
      errfunc0("tcl_init");
      sprintf(ers(),"Error while interpreting \"%s\".\nTcl error report:\n",com);
      sprintf(ers(),"%s",tclint->result);
      errfunc2();
    }
  }
  disppointer((void **) &initfile);
  disppointer((void **) &initdir);
  disppointer((void **) &com);
  if (Tcl_Init(tclint)==TCL_ERROR)
  {
    errfunc0("tcl_init");
    sprintf(ers(),"Tcl_Init failed.\nTcl error report:\n");
    sprintf(ers(),"%s",tclint->result);
    errfunc2();
  }

}
}


void tk_init(Tcl_Interp **interpaddr)
    /* Creates the Tcl interpreter if not yet created and performs the Tk
    initialisation on the interpreter.
    $A Igor apr03; */
{
Tcl_Interp *tclint=NULL;
char *ighome=NULL,*initfile=NULL,*initdir=NULL,*com=NULL;
int code;
if (interpaddr==NULL)
{
  errfunc0("tk_init");
  sprintf(ers(),"Interpreter address is NULL.\n");
  errfunc2();
  return;
}
if (*interpaddr!=NULL)
{
  warnfunc1(1,"tk_init");
  sprintf(ers(),"Interpreter is already created.\n");
  sprintf(ers(),"Continuing the Tk initialization.\n");
  warnfunc2();
} else
{
  tcl_init(interpaddr);
}
tclint=*interpaddr;
if (tclint==NULL)
{
  errfunc0("tk_init");
  sprintf(ers(),"Creation of the interpreter failed.\n");
  errfunc2();
  return;
}
ighome=globutgetighome();

/* Try to establish the Tcl version in order to determine which directory to use
for initialization of Tk (since Tk version information is not available before
initialization): */
com=stringcopy("set tcl_version");
code=Tcl_Eval(*interpaddr,com);
if (code!=TCL_OK)
{
  errfunc0("tcl_init");
  sprintf(ers(),"Error while interpreting \"%s\".\nTcl error report:\n",com);
  sprintf(ers(),"%s",(*interpaddr)->result);
  errfunc2();
  /*
  printf("\n\nInsert a number to continue! "); readdouble(&x);
  printf("\n");
  */
} else
{
  disppointer((void **) &com);
  com=stringcopy((*interpaddr)->result);
  initdir=stringcat("itk/tcltk/tk",com);
  initfile=globuthomefindfirst(initdir,NULL,"tk.tcl",NULL);
  if (initfile==NULL)
  {
    warnfunc1(3,"tk_init");
    sprintf(ers(),"Tk initialization scripts for version %s not found.\n",com);
    sprintf(ers(),"Trying to locate general scripts, error will be reported if not found.\n");
    warnfunc2();
  }
}
disppointer((void **) &com);
disppointer((void **) &initdir);
if (initfile==NULL)
  initfile=globuthomefindfirst("itk/tcltk/tk",NULL,"tk.tcl",NULL);
if (initfile==NULL)
{
  errfunc0("tk_init");
  sprintf(ers(),"Tk initialization scripts like tk.tcl not found.\n");
  sprintf(ers(),"Check the itk/tcltk/tk sub-directory of the directory %s.\n",ighome);
  errfunc2();
} else
{
  initdir=parentdir(initfile);
  changepathseparators(initdir,'/');
  com=stringcat("set tk_library ",initdir);
  code=Tcl_Eval(tclint,com);
  if (code!=TCL_OK)
  {
    errfunc0("tk_init");
    sprintf(ers(),"Error while interpreting \"%s\".\nTcl error report:\n",com);
    sprintf(ers(),"%s",tclint->result);
    errfunc2();
  }
}
disppointer((void **) &initfile);
disppointer((void **) &initdir);
disppointer((void **) &com);
if (Tk_Init(tclint)==TCL_ERROR)
{
  errfunc0("tk_init");
  sprintf(ers(),"Tk_Init failed.\nTcl error report:\n");
  sprintf(ers(),"%s",tclint->result);
  errfunc2();
}
}


void itk_init(Tcl_Interp **interpaddr)
    /* Creates the Tcl interpreter if not yet created and performs the ITK
    initialisation on the interpreter. This includes the Tcl and Tk
    initialization.
    $A Igor apr03; */
{
Tcl_Interp *tclint=NULL;
char *ighome=NULL,*initfile=NULL,*initdir=NULL,*com=NULL;
int code;
if (interpaddr==NULL)
{
  errfunc0("itk_init");
  sprintf(ers(),"Interpreter address is NULL.\n");
  errfunc2();
  return;
} else if (*interpaddr!=NULL)
{
  warnfunc1(1,"itk_init");
  sprintf(ers(),"Interpreter is already initialised.\n");
  warnfunc2();
} else
{
  tk_init(interpaddr);
  tclint=*interpaddr;
  if (tclint==NULL)
  {
    errfunc0("itk_init");
    sprintf(ers(),"Creation of the interpreter failed.\n");
    errfunc2();
    return;
  }

  ighome=stringcopy(globutgetighome());
  initfile=globuthomefindfirst("itk/",NULL,"itk.tcl",NULL);
  if (initfile==NULL)
  {
    errfunc0("itk_init");
    sprintf(ers(),"ITK initialization scripts like itk.tcl not found.\n");
    sprintf(ers(),"Check the itk sub-directory of the directory %s.\n",ighome);
    errfunc2();
  } else
  {
    initdir=parentdir(initfile);
    changepathseparators(initdir,'/');
    com=stringcat("lappend auto_path ",initdir);
    code=Tcl_Eval(tclint,com);
    if (code!=TCL_OK)
    {
      errfunc0("itk_init");
      sprintf(ers(),"Error while interpreting \"%s\".\nTcl error report:\n",com);
      sprintf(ers(),"%s",tclint->result);
      errfunc2();
    }
  }
  disppointer((void **) &initfile);
  disppointer((void **) &initdir);
  disppointer((void **) &com);
  com=stringcopy("wm withdraw .");
  code=Tcl_Eval(tclint,com);
  if (code!=TCL_OK)
  {
    errfunc0("itk_init");
    sprintf(ers(),"Error while interpreting \"%s\".\nTcl error report:\n",com);
    sprintf(ers(),"%s",tclint->result);
    errfunc2();
  }
  disppointer((void **) &com);
  if (stringlength(ighome)>0)
  {
    changepathseparators(ighome,'/');
    com=multstringcat("itk_initialize ",ighome," ",globutgetprog()," ",
      globutgetversionstr()," ",globutgetsubversionstr(),NULL);
    code=Tcl_Eval(tclint,com);
    if (code!=TCL_OK)
    {
      errfunc0("itk_init");
      sprintf(ers(),"Error while interpreting \"%s\".\nTcl error report:\n",com);
      sprintf(ers(),"%s",tclint->result);
      errfunc2();
    }
  }
  disppointer((void **) &com);
  disppointer((void **) &ighome);

  /* Make available commands of the Tcl written ITK system: */
}
}




    /* BARE TCL INTERPRETER FOR ACCESSING THE TCL FUNCTIONALITY.
    
  Use this interpreter exclusively fot evaluating built-in Tcl functions because
it has separate var. space from the ITK server; provided for sped. */


void tcl_initialize(void)
    /* Initializes the bare Tcl interpreter. It is not necessary to call this
    function explicitly because it is implicitly called by other functions
    for accessing the ITK functionality.
    $A Igor apr04; */
{
++tclrec;
if (tclrec==1) /* prevent recursion */
{
  if (tclinterp==NULL)
    tcl_init(&tclinterp);
  tclin=1; /* set initialization flag */
}
--tclrec;
}

int tcl_initialized(void)
    /* Returns 1 if the bare Tcl interpreter is already initialized and 0
    otherwise.
    $A Igor apr04; */
{
return tclin;
}



Tcl_Interp *tcl_interp(void)
    /* Returns the Tcl interpreter for the Tcl system so that its state can be
    checked, new commands installed, etc.
      WARNING!
    Make sure that you are in the main thread when using the Tcl interpreter
    directly!
    $A Igor apr04; */
{
if (tclinterp==NULL)
  tcl_initialize();
return tclinterp; 
}





void tcl_sendcom(char *com)
    /* Sends the command com to the Tcl interpreter for execution. com must be
    such that writing on it is enabled, for example dynamically allocated
    (in that case it must be freed after call to this function).
    $A Igor apr03; */
{
static int reported=0;
if (tclinterp==NULL)
  tcl_initialize();
if (getthreadid() !=mainthread)
{
  if (!itkin)
    itk_initialize();
  if (itkin)
  {
    if (!reported)
    {
      warnfunc1(1,"tcl_sendcom");
      sprintf(ers(),"This is not the main thread, ITK interpreter will be used instead of Tcl.\n");
      sprintf(ers(),"Further messeges of this kind will be surpressed.\n");
      ++reported;
      warnfunc2();
    }
    itk_sendcom(com);
    return;
  }
  /* Can not use ITK since it is obviously in the middle of innitialization,
  exceptionally use the Tcl interp. within the ITK thread (proceed after loop): */
}
Tcl_Eval(tclinterp,com);
}

void tcl_sendcomcp(char *com)
    /* Sends the command com to the Tcl interpreter for execution. com does
    not need to be dynamically allocated because a dynamically allocated copy
    of it i screated internally and released after use.
    $A Igor apr03; */
{
static int reported=0;
char *command;
if (tclinterp==NULL)
  tcl_initialize();
if (/* Tcl_GetCurrentThread() */ getthreadid()!=mainthread)
{
  if (!itkin)
    itk_initialize();
  if (itkin)
  {
    if (!reported)
    {
      warnfunc1(1,"tcl_sendcomcp");
      sprintf(ers(),"This is not the main thread, ITK interpreter will be used instead of Tcl.\n");
      sprintf(ers(),"Further messeges of this kind will be surpressed.\n");
      ++reported;
      warnfunc2();
    }
    itk_sendcomcp(com);
    return;
  }
  /* Can not use ITK since it is obviously in the middle of innitialization,
  exceptionally use the Tcl interp. within the ITK thread (proceed after loop): */
}
command=stringcopy(com);
Tcl_Eval(tclinterp,command);
if (command!=NULL)
  free(command);
}

char *tcl_interpret(char *com,int *code)
    /* Interprets the command com in the auxiliary Tcl interpreter and returns
    the dynamically allocated result, which must be deallocated (e.g. by
    free()). If code is not NULL, the return code of evaluation is written to
    *code. If it is not TCL_OK, this indicates an error.
      com must be such that writing on it is possible, it is the best if it is
    dynamically allocated.
    This function can only be called in the main thread. Its aim is to execute
    Tcl commands bypassing the threaded ITK server. This is quicker, however
    only the basic Tcl commands are available. Also both interpreters have
    separate variable spaces.
    $A Igor apr03; */
{
static int reported=0;
if (tclinterp==NULL)
  tcl_initialize();
if (/* Tcl_GetCurrentThread() */ getthreadid()!=mainthread)
{
  if (!itkin)
    itk_initialize();
  if (itkin)
  {
    if (!reported)
    {
      warnfunc1(1,"tcl_interpret");
      sprintf(ers(),"This is not the main thread, ITK interpreter will be used instead of Tcl.\n");
      sprintf(ers(),"Further messeges of this kind will be surpressed.\n");
      ++reported;
      warnfunc2();
    }
    return itk_interpret(com,code);
  }
  /* Can not use ITK since it is obviously in the middle of innitialization,
  exceptionally use the Tcl interp. within the ITK thread (proceed after loop): */
}
if (code!=NULL)
  *code=Tcl_RecordAndEval(tclinterp,com,TCL_EVAL_GLOBAL);
else
  Tcl_RecordAndEval(tclinterp,com,TCL_EVAL_GLOBAL);
return stringcopy(tclinterp->result);
}


char *tcl_interpretcp(char *com,int *code)
    /* Interprets the command com in the auxiliary Tcl interpreter and returns
    the dynamically allocated result, which must be deallocated (e.g. by
    free()). If code is not NULL, the return code of evaluation is written to
    *code. If it is not TCL_OK, this indicates an error.
      Command com does not need to be dynamically allocated because a temporary
    dynamic copy of com is created internally.
    This function can only be called in the main thread. Its aim is to execute
    Tcl commands bypassing the threaded ITK server. This is quicker, however
    only the basic Tcl commands are available. Also both interpreters have
    separate variable spaces.
    $A Igor apr03; */
{
static int reported=0;
char *command;
if (tclinterp==NULL)
  tcl_initialize();
if (/* Tcl_GetCurrentThread() */ /* getthreadid()!=mainthread */!ismainthread())
{
  if (!itkin)
    itk_initialize();
  if (itkin)
  {
    if (!reported)
    {
      warnfunc1(1,"tcl_interpretcp");
      sprintf(ers(),"This is not the main thread, ITK interpreter will be used instead of Tcl.\n");
      sprintf(ers(),"Further messeges of this kind will be surpressed.\n");
      ++reported;
      warnfunc2();
    }
    return itk_interpretcp(com,code);
  }
  /* Can not use ITK since it is obviously in the middle of innitialization,
  exceptionally use the Tcl interp. within the ITK thread (proceed after loop): */
}
command=stringcopy(com);
if (code!=NULL)
  *code=Tcl_RecordAndEval(tclinterp,command,TCL_EVAL_GLOBAL);
else
  Tcl_RecordAndEval(tclinterp,command,TCL_EVAL_GLOBAL);
if (command!=NULL)
  free(command);
return stringcopy(tclinterp->result);
}


void tcl_shell(void)
    /* A simple shell where useer can evaluate commands in the auxiliary tcl
    interpreter and see the results.
    $A Igor apr03; */
{
char *line=NULL,*res=NULL,*aux,*line1=NULL;
int code,incomplete=0;
int emptystrings=0;
printf("\nInput Tcl commands; 2* empty string to finish!\n");
while (emptystrings<2)
{
  line=NULL;
  if (line1==NULL)
    printf("Tcl> ");
  readstring(&line);
  if (stringlength(line)==0)
    ++emptystrings;
  else
    emptystrings=0;
  if (line1!=NULL)
  {
    aux=line;
    line=multstringcat(line1,"\n",line,NULL);
    disppointer((void **) &aux);
    disppointer((void **) &line1);
  }
  if (Tcl_CommandComplete(line))
  {
    res=tcl_interpret(line,&code);
    if (code!=TCL_OK)
      printf ("    Error %i: %s\n",code,res);
    else
      printf("    \"%s\"\n",res);
    disppointer((void **) &res);
    disppointer((void **) &line);
  } else
  {
    line1=line;
    line=NULL;
  }
}
}





    /* THE ITK SYSTEM.

Enables evaluating Tcl commands extended by Tk and ITK within the main thread,
event loop implemented in a parallel thread (currently also the command
serviceing). */



static void sleepiflocked(int countidle)
    /* Sleeping procedure to be executed when waiting the request lock of the
    server thread to be released.
    $A Igor apr04; */
{
int i,stime=0;
double x;
if (countidle>=2)
{
  if (countidle<=5)
    stime=1;
  else if (countidle<=10)
    stime=2;
  else if (countidle<=20)
    stime=4;
  else if (countidle<=50)
    stime=6;
  else if (countidle<=100)
    stime=10;
  else
    stime=20;
}
if (0)
{
  if (stime)
  {
    /*  */
    Tcl_Sleep(stime);
  }
} else
{
  /*
  printf("ITK, sleepiflocked: Performing operations while waitinf.\n");
  */
  for (i=1;i<=stime;++i)
    x=(double) stime * (double) stime;  
}
}


static void waitrequestlock(itkthreaddata data)
    /* Wait until request lock of data is released. After this function, it must
    be checked again if the lock is released!
    $A Igor apr03; */
{
int i;
i=0;
while (data->requestlock)
{
  sleepiflocked(i);
  ++i;
}
}


static void waitthreaddatalock(itkthreaddata data)
    /* Waits until the threaddata data gets unlocked.
    $A Igor feb03; */
{
int i;
i=0;
while (data->lock)
{
  sleepiflocked(i);
  ++i;
}
}



static void sleepifidle(int countidle)
    /* Pauses execution according to the number of times when no acton
    was performed (countidle)
    $A Igor feb03; */
{
int i,stime=0;
double x;
if (countidle>2)
{
  if (countidle<=50)
    stime=1;
  else if (countidle<=200)
    stime=2;
  else if (countidle<=600)
    stime=5;
  else if (countidle<=1000)
    stime=10;
  else if (countidle<=1500)
    stime=20;
  else
    stime=20;
}
if (1 && stime)
{
  if (0 && stime>=50)
  {
  if (stime<100)
    printf(".");
  else if (stime<200)
    printf(":");
  else
    printf("!");
  }
  Tcl_Sleep(stime);
} else for (i=1;i<=stime;++i)
  x=(double) stime * (double) stime;
}




static void waituntilidle(itkthreaddata data)
    /* Waits until the server thread whise data structure is data is idle, i.e.
    it contains no unserved requests or commands and the lock and request lock
    are both released.
    $A Igor apr04; */
{
int num=0;
while(data->lock || data->requestlock || data->commands->n || data->requests->n)
{
  ++num;
  /*
  sleepifidle(num);
  */
  sleepiflocked(num);
}
}



static itkrequest getnextrequest(itkthreaddata data)
    /* Returns the next request on the stack to be served by the thread.
    While retreiving the request data, procedure waits until the request
    mechanism is locked, ant safely retreives the data without interfering
    with other the threads trying to load requests (Therefore, multiple
    threads can use the ITK request server).
    $A Igor mar03; */
{
itkrequest request;
char done=0;
while (done==0)
{
  /*
  waitrequestlock(data);
  ++data->requestlock;
  if (data->requestlock=1)
  {
  */
  request=delstack(data->requests,1);
    done=1;
  /*
  }
  --data->requestlock;
  */
}
return request;
}




static char *nextcommand0(stack commands)
    /* Returns the next command from the stack commands. If no command
    is available then NULL is returned and commands->n is set to 0. This
    function can be used ONLY FOR 1 STACK of commands!
    $A Igor apr03; */
{
char *ret=NULL;
static int current=1;
if (current<1)
  current=1;
if (current<=commands->n)
{
  while(commands->s[current]==NULL &&
   current<=commands->n)
    ++current;
}
if (current<=commands->n)
{
  ret=commands->s[current];
  commands->s[current]=NULL;
  ++current;
}
if (current>commands->n)
{
  current=1;
  commands->n=0;
}
return ret;
}

static char *nextcommand(itkthreaddata data)
    /* Returns the next command from the stack data->commands. If no
    command is available then NULL is returned and data->commands->n is
    set to 0. Retreiving commands in the same order as they were sent to
    data is much quicker by using this function as by delstack(). The mark
    data->current defines the current command to be retreived. The element
    of the stack data->commands which is retreived is set to NULL.
    $A Igor apr03; */
{
char *ret=NULL;
if (data->current<1)
  data->current=1;
if (data->current<=data->commands->n)
{
  while(data->commands->s[data->current]==NULL &&
   data->current<=data->commands->n)
    ++data->current;
}
if (data->current<=data->commands->n)
{
  ret=data->commands->s[data->current];
  data->commands->s[data->current]=NULL;
  ++data->current;
}
if (data->current>data->commands->n)
{
  data->current=1;
  data->commands->n=0;
}
return ret;
}


static char *getnextcommand(itkthreaddata data)
    /* Returns the next command on the stack to be served by the thread.
    While retreiving the command, procedure waits until the request
    mechanism is locked, ant safely retreives the data without interfering
    with other the threads trying to load requests or commands (Therefore,
    multiple threads can use the Tcl request server).
    $A Igor mar03; */
{
char *command;
char done=0;
while (!done)
{
  waitrequestlock(data);
  ++data->requestlock;
  if (data->requestlock==1)
  {
    command=nextcommand(data);
    done=1;
  }
  --data->requestlock;
}
return command;
}




#ifdef MAC_TCL
  static pascal void *(itkthreadmain) _ANSI_ARGS_((ClientData ptr))
#elif defined __WIN32__
  static unsigned (__stdcall itkthreadmain) _ANSI_ARGS_((ClientData ptr))
#else
  static void (itkthreadmain) _ANSI_ARGS_((ClientData ptr))
#endif
    /* The main procedure of the ITK thread.
    Remark: Macro definitions are from tcl.h (included in itk.h)
    $A Igor apr04; */
{
itkthreaddata data=(itkthreaddata) ptr;
itkrequest request;
int i=0,procevent=1,countidle=-10,countevents=10,counteval,cantlock=0,
    noevents=0;
/*
printf("\n\nITK Thread Main has started.\n");
*/
itk_init(&(data->interp));
/*
printf("ITK TM: 1 (after itk_init, before getthreadid)\n");
*/
data->thread=getthreadid();
/*
printf("ITK TM: 1 (before releasing lock and requestlock)\n");
*/
data->lock=0;
data->requestlock=0;
/*
printf("ITK TM: 1 (before initialization flag)\n");
*/
itkin=1;  /* initialization flag */
/*
printf("ITK TM: 1 (right before the loop)\n");
*/
while (1)
{
  ++ countidle;
  if (0)
    printf("<%i:L%iR%in%i>",i,data->lock,data->requestlock,data->commands->n);
  if (!data->lock && (countidle>1 || noevents>2))
  {
    /* Is it necessary to skip event loop x times (noevents>x)?) */
    ++data->lock;
    if (data->lock==1)
    {
      noevents=0;
      countevents=0;
      while ((procevent=Tcl_DoOneEvent(TCL_DONT_WAIT | TCL_ALL_EVENTS)))
        ++countevents;
      if (countevents)
        countidle=-1;
    } else
    {
      ++cantlock;
    }
    --data->lock;
    if (cantlock>4)
    {
      /* We let only a couple of loups without handling pending evends because
      the interpreter is used by another thread, after this we wait until the
      lock is released: */
      m_threadlocksleep(data->lock,1);
      noevents=0;
      countevents=0;
      while ((procevent=Tcl_DoOneEvent(TCL_DONT_WAIT | TCL_ALL_EVENTS)))
        ++countevents;
      if (countevents)
        countidle=-1;
      m_threadunlock(data->lock);
    }
    /*
    if (countevents)
    {
      countidle=-1;
      printf("<%i>",countevents);
    } else
      printf(".");
    */
  } else
    ++ noevents;
  if (!data->requests->n && !data->commands->n)
    sleepifidle(countidle);
  /* Process commands on the stack: */
  if (data->procall)
  {
    /* Process all pending requests (luck the thread and request loading until
    done): */
    m_threadlocksleep(data->lock,0);
    m_threadlocksleep(data->requestlock,0);
    while (data->requests->n)
    {
      request=getnextrequest(data);
      if (request->com!=NULL)
      {
        request->code=Tcl_RecordAndEval(data->interp,request->com,TCL_EVAL_GLOBAL);
        request->res=stringcopy(data->interp->result);
      }
      if (request->func!=NULL)
        request->func(request->data);
      request->done=1;
    }
    while(data->commands->n)
    {
      ++counteval;
      disppointer((void **) &(data->command));
      data->command=nextcommand(data);
      Tcl_RecordAndEval(data->interp,data->command,TCL_EVAL_GLOBAL);
    }
    /* Is it good to process also the events or is it better that events are
    processed at some other time? */
    while ((procevent=Tcl_DoOneEvent(TCL_DONT_WAIT | TCL_ALL_EVENTS)))
      ;
    m_threadunlock(data->requestlock);
    m_threadunlock(data->lock);
    data->procall=0;  /* notify the requesting thread that processing is finished */
  }
  if (!data->lock)
  {
    if (data->requests->n)
    {   
      countidle=-1;
      m_threadlocksleep(data->lock,0);
      while (data->requests->n)
      {
        /* Handle all blocking requests: */
        m_threadlocksleep(data->requestlock,0);
        request=getnextrequest(data);
        m_threadunlock(data->requestlock);
        if (request->com!=NULL)
        {
          request->code=Tcl_RecordAndEval(data->interp,request->com,TCL_EVAL_GLOBAL);
          request->res=stringcopy(data->interp->result);
        }
        if (request->func!=NULL)
          request->func(request->data);
        request->done=1;
      }
      m_threadunlock(data->lock);
    }
    if(data->commands->n>500)
    {
      countidle=-1;
      counteval=0;
      m_threadlocksleep(data->lock,1);
      /*
      if (data->commands->n%10==0)
        printf("data->commands: %i.\n",data->commands->n);    
      */
      while(data->commands->n && counteval<1000)
      {
        ++counteval;
        disppointer((void **) &(data->command));
        m_threadlocksleep(data->requestlock,0);
        data->command=nextcommand(data);
        m_threadunlock(data->requestlock);
        Tcl_RecordAndEval(data->interp,data->command,TCL_EVAL_GLOBAL);
      }
      m_threadunlock(data->lock);
    } else
      Tcl_Sleep(10);
  }
  /*
  Tcl_MutexUnlock(mutexptr);
  */

  if (0)
  {
    procevent=Tcl_DoOneEvent(TCL_DONT_WAIT | TCL_ALL_EVENTS);
    printf("<!>");
  }
  ++i;
  /*
  printf("\n<<<Thread %i, %i. execution of the loop.>>>\n",Tcl_GetCurrentThread,i);
  */
}
printf("\n\nEnd of ITK event loop.\n\n");
/*
Tcl_ExitThread(0);
*/
dispstackall(&(data->commands));
dispstackall(&(data->requests));
#ifdef MAC_TCL
  return 0;
#elif defined __WIN32__
  return 0;
#else
  return;
#endif
}


static void createitkthread(void)
    /* Creaces the thread and sets up the ITK server in this thread.
    $A Igor apr04; */
{
if (itkthread!=NULL)
{
  warnfunc1(1,"createitkthread");
  sprintf(ers(),"A thread for ITK interpretation server has already been created.\n");
  warnfunc2();
  return;
} else
{
  /* WARNING: A tcl interpreter must be created if we want to call
  Tcl_CreateThread(): */
  if (tclinterp==NULL)
    tcl_initialize();
  itkthread=calloc(1,sizeof(*itkthread));
  /*
  itk_init(&(tclinterp));
  */
  itkthread->commands=newstack(comstex);
  itkthread->requests=newstack(5);
  itkthread->lock=1;
  itkthread->requestlock=1;
  itkthread->interp=NULL;
  itkthread->procall=0;
  /*
  pushstack(itkthread->commands,stringcopy("wm withdraw ."));
  pushstack(itkthread->commands,stringcopy("itk_initialize"));
  */
  /*
  printf("Before creating the thread...\n");
  */

  printf("Right before launching the ITK thread:\n");
  Tcl_CreateThread(&(itkthread->id),itkthreadmain,(int *) itkthread,TCL_THREAD_STACK_DEFAULT,TCL_THREAD_NOFLAGS);
  printf("Right after launching the ITK thread, waiting for idle state:\n");
  waituntilidle(itkthread);
}
/* itkin=1;  /* - this was moved into itkthreadmain; set initialization flag */
}




void itk_initialize(void)
    /* Initializes the ITK server (creates the thread and sets up the server)
    if it has not been initialised yet. It is not necessary to call this
    function exprlicitly because it is implicitly called by other functions
    for accessing the ITK functionality.
    $A Igor apr04; */
{
static int initialized=0;
if (!initialized) /* allow only one execution */
{
  initialized=1;
  if (itkin==0)
    createitkthread();
}
}


int itk_initialized(void)
    /* Returns 1 if the ITK server is already initialized and 0
    otherwise.
    $A Igor apr04; */
{
return itkin;
}


void itk_lockinterp(void)
    /* If necessary, waits until the Tcl interpreter of the ITK server thread
    is unlocked, and locks it so that other threads can not access it. After
    this function returns, the interpreter can be accessed, e.g. for installing
    new procedures. This function must aways be called in pair with the
    itk_unlockinterp(), which unlocks the interpreter after use so that the
    ITK server can continue serving requests.
      WARNING: When calling this procedure you should eventually check that you
    are not in the ITK thread. The code within the ITK thread is executed in a 
    block where thread is acces locked, so trying to lock it again would block
    the execution of the thread forever.
    $A Igor apr04; */
{
char done=0;
if (itkin==0)
  itk_initialize();
while (!done)
{
  waitthreaddatalock(itkthread);
  ++itkthread->lock;
  if (itkthread->lock==1)
    done=1;
  else
    --itkthread->lock;
}
}

void itk_unlockinterp(void)
    /* Unlock the ITK's Tcl interpreter so that it can be used by another
    threads. This function must be used after the itk_lockinterp().
    $A Igor apr03; */
{
if (itkin==0)
{
  itk_initialize();
  errfunc0("itk_unlockinterp");
  sprintf(ers(),"The ITK interpreter is not initialized.\n");
  sprintf(ers(),"This function should be called only when the ITK server is initialized.\n");
  sprintf(ers(),"Probably itk_lockinterp() was not called where it should be.\n");
  errfunc2();
} else
  --itkthread->lock;
}


Tcl_Interp *itk_interp(void)
    /* Returns the Tcl interpreter for the ITK system so that its state can be
    checked, new commands installed, etc. The portions of code in which the
    the returned interpreter is used should be ALWAYS EMBEDDED within the calls
    to itk_lockinterp() and itk_unlockinterp(). This ensures that the
    interpreter is accessed simultaneously only by one single thread.
    $A Igor apr04; */
{
if (itkin==0)
  itk_initialize();
return itkthread->interp; 
}


void itk_sendcom(char *com)
    /* Sends the command com to the ITK server for execution. com must be
    dynamically allocated; It must not be be freed or modified after execution
    of this command.
      The function is asynchroneous. it returns immediately, usually before the
    command is actually executed by the Tcl interpreter in the ITK thread. The
    sequnece of execution is preserved: If one command is passed before another
    by the itk_sendcom or itk_sendcomcp (e.g. within the same thread), then
    this command will be executed by the ITK server before another command.
    $A Igor apr03; */
{
if (itkin==0)
  itk_initialize();
if (itkthread->commands->n>manycommands)
  Tcl_Sleep(loadrequestsleep);
/*
while (itkthread->commands->n>manycommands)
  Tcl_Sleep(1);
*/
if (getthreadid()!=itkthread->thread)
{
  m_threadlocksleep(itkthread->requestlock,0)
  pushstack(itkthread->commands,com);
  m_threadunlock(itkthread->requestlock);
} else
  Tcl_Eval(itkthread->interp,com);
}


void itk_sendcomcp(char *com)
    /* Sends a copy of the command com to the ITK server for execution. com
    does not need to be dynamically allocated because the function creates
    its dynamic copy internally.
      The function is asynchroneous. it returns immediately, usually before the
    command is actually executed by the Tcl interpreter in the ITK thread. The
    sequnece of execution is preserved: If one command is passed before another
    by the itk_sendcom or itk_sendcomcp (e.g. within the same thread), then
    this command will be executed by the ITK server before another command.
    $A Igor apr03; */
{
if (itkin==0)
  itk_initialize();
if (itkthread->commands->n>manycommands)
  Tcl_Sleep(loadrequestsleep);
/*
while (itkthread->commands->n>manycommands)
  Tcl_Sleep(1);
*/
if (getthreadid()!=itkthread->thread)
{
  m_threadlocksleep(itkthread->requestlock,0)
  pushstack(itkthread->commands,stringcopy(com));
  m_threadunlock(itkthread->requestlock);
} else
{
  char *command;
  command=stringcopy(com);
  Tcl_Eval(itkthread->interp,command);
  if (command!=NULL)
    free(command);
}
}




char *itk_interpret(char *com,int *code)
    /* Sends a Tcl command com to the ITK server, waits its interpretation
    and returns a dynamically allocated copy of the result of interpretation.
    If code is not NULL, the return code is stored in *code. The returned value
    must be deallocated when not needed anymore. com must be dynamically
    allocated (because it is deallocated by the server by using free()) and may
    not be modified after this function is called.
    $A Igor apr03; */
{
if (itkserverrequest==NULL)
{
  itkserverrequest=calloc(1,sizeof(*itkserverrequest));
  itkserverrequest->lock=0;
}
if (itkin==0)
  itk_initialize();
if (getthreadid()!=itkthread->thread)
{
  m_threadlocksleep(itkserverrequest->lock,0);
  itkserverrequest->res=NULL;
  itkserverrequest->com=com;
  itkserverrequest->func=itkserverrequest->data=NULL;
  itkserverrequest->done=0;
  m_threadlocksleep(itkthread->requestlock,1);
  pushstack(itkthread->requests,itkserverrequest);
  m_threadunlock(itkthread->requestlock);
  m_threadwaitnotvalsleep(itkserverrequest->done,0,0);
  if (code!=NULL)
    *code=itkserverrequest->code;
  m_threadunlock(itkserverrequest->lock);
  return itkserverrequest->res;
} else
{
  if (code!=NULL)
    *code=Tcl_RecordAndEval(itkthread->interp,com,TCL_EVAL_GLOBAL);
  else
    Tcl_RecordAndEval(itkthread->interp,com,TCL_EVAL_GLOBAL);
  return stringcopy(itkthread->interp->result);
}
}


char *itk_interpretcp(char *com,int *code)
    /* Sends a Tcl command com to the ITK server, waits its interpretation
    and returns a dynamically allocated copy of the result of interpretation.
    If code is not NULL, the return code is stored in *code. The returned value
    must be deallocated when not needed anymore.
      com does not need to be dynamically allocated because the function
    creates its dynamic copy internally.
    $A Igor apr03; */
{
if (itkserverrequest==NULL)
{
  itkserverrequest=calloc(1,sizeof(*itkserverrequest));
  itkserverrequest->lock=0;
}
if (itkin==0)
  itk_initialize();
if (getthreadid()!=itkthread->thread)
{
  m_threadlocksleep(itkserverrequest->lock,0);
  itkserverrequest->res=NULL;
  itkserverrequest->com=stringcopy(com);
  itkserverrequest->func=itkserverrequest->data=NULL;
  itkserverrequest->done=0;
  m_threadlocksleep(itkthread->requestlock,1);
  pushstack(itkthread->requests,itkserverrequest);
  m_threadunlock(itkthread->requestlock);
  m_threadwaitnotvalsleep(itkserverrequest->done,0,0)
  if (code!=NULL)
    *code=itkserverrequest->code;
  m_threadunlock(itkserverrequest->lock);
  return itkserverrequest->res;
} else
{
  char *command;
  command=stringcopy(com);
  if (code!=NULL)
    *code=Tcl_RecordAndEval(itkthread->interp,command,TCL_EVAL_GLOBAL);
  else
    Tcl_RecordAndEval(itkthread->interp,command,TCL_EVAL_GLOBAL);
  if (command!=NULL)
    free(command);
  return stringcopy(itkthread->interp->result);
}
}



static int requeststacklock=0;
static stack requeststack=NULL;
static int manyrequests=30;

static itkrequest obtainrequeststruct(void)
    /* Finds an unused data structure of the type itkrequest or creates a new
    one, returns its pointer. It LOCKS THE STRUCTURE, which may therefore NOT BE
    LOCKED INSIDE THE CALLING FUNCTION, but must be unlocked there.
      On the returned structure, the functionn deletes the fields com and res,
    field lock is set to 1 and done is set to 0, the fields func and data are
    set to NULL, therefore the calling function
    does not need to tace care of this.
      The function is thread safe and can be simultaneously called from several
    threads.
    $A Igor sep03; */
{
itkrequest request=NULL,delrequest=NULL;
int i,j;
m_threadlocksleep(requeststacklock,0);
if (requeststack==NULL)
  requeststack=newstack(10);
i=1;
/* Try to find an unused request structure on the stack requeststack without
blocking: */
while(i<=requeststack->n && request==NULL)
{
  if (requeststack->s[i]!=NULL)
  {
    request=requeststack->s[i];
    /* If the strucure is unlocked, take it (break the loop) and lock it: */
    if (!request->lock && request->done)
    {
      ++request->lock;
      if (request->lock>1)
      {
        --request->lock;
        request=NULL;
      }
    }
  }
  ++i;
}
if (request==NULL && requeststack->n>manyrequests)
{
  /* We haven't found the available request structure, but the number of
  processed request is high. We try to obtain a free request structure again
  and impose sleeping between successive trials: */
  i=1;
  while(i<=requeststack->n && request==NULL)
  {
    j=0;
    if (requeststack->s[i]!=NULL)
      while (request==NULL && j<=(requeststack->n)/manyrequests)
      {
        while (request==NULL)
        request=requeststack->s[i];
        /* If the strucure is unlocked, take it (break the loop) and lock it: */
        if (!request->lock && request->done)
        {
          ++request->lock;
          if (request->lock>1)
          {
            --request->lock;
            request=NULL;
          }
        }
        ++j;
        Tcl_Sleep(1);
      }
    ++i;
  } 
}
if (request!=NULL && requeststack->n>(int) ((double) manyrequests*1.5)
       && i<=requeststack->n/2)
{
  /* There are too many data structures on the stack, try to delete one of
  them to release memory; search from the end of the stack and don't decrement
  till thee beginning in order to save CPU time: */
  i=requeststack->n;
  while (i>requeststack->n)
  {
    if (requeststack->s[i]!=NULL)
    {
      delrequest=requeststack->s[i];
      ++delrequest->lock;
      if (delrequest->lock==1 && delrequest->done==0)
      {
        /* Take the unused requests from the stack, delete it and exit the loop: */
        delstack(requeststack,i);
        if (delrequest->res!=NULL)
          free(delrequest->res);
        if (delrequest->com!=NULL)
          free(delrequest->com);
        break;
      } else
        --delrequest->lock;
    }
    --i;
  }
}
if (request==NULL)
{
  /* An unused request was not found, create a new one, lock it and add it to
  the stack so that it can be re-used after it serves its purpose: */
  request=calloc(1,sizeof(*request));
  request->lock=1;
  request->done=0;
  pushstack(requeststack,request);
}
m_threadunlock(request->lock);
if (request->res!=NULL)
{
  free(request->res);
  request->res=NULL;
}
if (request->com!=NULL)
{
  free(request->com);
  request->com=NULL;
}
request->func=request->data=NULL;
m_threadunlock(requeststacklock);
return request;
}



void itk_sendfunc(void (*func)(void *),void *ptr)
    /* Arranges for the function func to be called in the ITK interpreter. The
    request for the call is posted in the same way as the request for
    interpretation by the itk_sendcom(). The ptr will be passed to the function
    as argument when it is executed. The function will be executed when CPU
    time is available in the thread, but this function returns immediately
    withaut waiting for execution of func.
      The function execution will have higher priority with respect to commands
    that are sent to the ITK interpreter, since it is loaded on the 
    (...)->requests field of the thread structure.
    $A Igor sep03; */
{
itkrequest request;
if (itkin==0)
  itk_initialize();
if (getthreadid()!=itkthread->thread)
{
  /* Obtain an available request object. obtainrequeststruct() locks the
  returned structure, therefoe we don't need to lock it here. Set the data and
  post the request: */
   request=obtainrequeststruct();
  request->func=func;
  request->data=ptr;
  request->done=0;
  /* Post the request, but don't wait until it is handled: */
  m_threadlocksleep(itkthread->requestlock,1);
  pushstack(itkthread->requests,request);
  m_threadunlock(itkthread->requestlock);
  m_threadunlock(request->lock);  /* unlock, so that the request struct.
       can be re-used when the flag (...)->done is set by the server (the
       request was locked by the obtainrequeststruct()). */
  return;
} else
{
  func(ptr);
}
}



void itk_callfunc(void (*func)(void *),void *ptr)
    /* Arranges for the function func to be called in the ITK interpreter and
    waits until the function returns. The ptr will be passed to the function
    as argument when it is executed. The function will be executed when CPU
    time is available in the thread, with the seme priority as the code
    interpreted by itk_interpret().
    $A Igor sep03; */
{
if (itkserverrequest==NULL)
{
  itkserverrequest=calloc(1,sizeof(*itkserverrequest));
  itkserverrequest->lock=0;
}
if (itkin==0)
  itk_initialize();
if (getthreadid()!=itkthread->thread)
{
  m_threadlocksleep(itkserverrequest->lock,0);
  itkserverrequest->res=NULL;
  itkserverrequest->com=NULL;
  itkserverrequest->func=func;
  itkserverrequest->data=ptr;
  itkserverrequest->done=0;
  /* Post the itkserverrequest, then wait until it is handled: */
  m_threadlocksleep(itkthread->requestlock,1);
  pushstack(itkthread->requests,itkserverrequest);
  m_threadunlock(itkthread->requestlock);
  m_threadunlock(itkserverrequest->lock);
  m_threadwaitnotvalsleep(itkserverrequest->done,0,0);
  return;
} else
{
  func(ptr);
}
}


void itk_procallrequests(void)
    /* Takes care that all requests are processed by the ITK server, blocks until
    this is done (unless if called in the ITK thread, in which case the function
    has no effect).
    $A Igor apr03; */
{
static int reported=0;
if (itkin==0)
  itk_initialize();
if (getthreadid()!=itkthread->thread)
{
  m_threadlocksleep(itkthread->procall,1);
  m_threadwaitvalsleep(itkthread->procall,0,0);
} else if (!reported)
{
  warnfunc1(1,"itk_procallrequests");
  sprintf(ers(),"Function called within the ITK server thread.\n");
  sprintf(ers(),"The effect will be retarded and the function will not block.\n");
  sprintf(ers(),"Further messages of this kind will be surpressed.\n");
  errfunc2();
  itkthread->procall=1;
}
}



void itk_shell(void)
    /* The shell in which user can execute Tcl commands by the ITK server and
    view results; Uses standart input and output, executed serially.
    $A Igor apr04; */
{
char *line=NULL,*res=NULL,*aux,*line1=NULL;
int code,emptystrings=0;
if (itkin==0)
  itk_initialize();
printf("\nInput ITK/Tcl/Tk commands; 2* empty string to finish!\n");
while (emptystrings<2)
{
  line=NULL;
  if (line1==NULL)
    printf("ITK> ");
  readstring(&line);
  if (stringlength(line)==0)
    ++emptystrings;
  else
    emptystrings=0;
  if (line1!=NULL)
  {
    /* Append the read string to the previous lines: */
    aux=line;
    line=multstringcat(line1,"\n",line,NULL);
    disppointer((void **) &aux);
    disppointer((void **) &line1);
  }
  if (Tcl_CommandComplete(line))
  {
    /* Execute command: */
    res=itk_interpret(line,&code);
    if (code!=TCL_OK)
      printf ("    Error %i: %s\n",code,res);
    else
      printf("    \"%s\"\n",res);
    disppointer((void **) &line);
    disppointer((void **) &res);
  } else
  {
    /* Command not complete, add a new line */
    itk_sendcomcp("itk_notice . {} 500 \"Command not complete,\\n append completion!\"");
    line1=line;
    line=NULL;
  }
}
}





    /* IEK: TESTS FOR INTERPRETER IN THE MAIN THREAD, LOCKING EVENT LOOP IN
    ANOTHER ONE;
    
This is the IEK system - E stands for event loop. The system is quicker that ITK,
but is not stable due to incompatibility of the Tcl interpretation on threads. */



#ifdef MAC_TCL
  pascal void *(iekthreadmain) _ANSI_ARGS_((ClientData ptr))
#elif defined __WIN32__
  unsigned (__stdcall iekthreadmain) _ANSI_ARGS_((ClientData ptr))
#else
  void (iekthreadmain) _ANSI_ARGS_((ClientData ptr))
#endif
    /* Tha main procedure for the IEK thread.
    $A Igor apr04; */
{
itkthreaddata data=(itkthreaddata) ptr;
itkrequest request;
int i=0,procevent=1,countidle=-10,countevents=10,counteval;
data->lock=0;
data->requestlock=0;
while (1)
{
  ++ countidle;
  if (0)
    printf("<%i:L%iR%in%i>",i,data->lock,data->requestlock,data->commands->n);
  /* Event loop: */
  if (!data->lock && !data->requestlock)
  {
    ++data->lock;
    ++data->requestlock;
    Tcl_Sleep(10);
    if (data->lock==1 && data->requestlock==1)
    {
      countevents=0;
      while ((procevent=Tcl_DoOneEvent(TCL_DONT_WAIT | TCL_ALL_EVENTS)))
        ++countevents;
      if (countevents)
        countidle=-1;
      /*
      if (countevents)
      {
        countidle=-1;
        printf("<%i> ",countevents);
      } else
        printf(".");
      */
    }
    Tcl_Sleep(5);
    --data->requestlock;
    --data->lock;
    Tcl_Sleep(5);
  }
  if (1 || ( !data->requests->n && !data->commands->n  ) )
    sleepifidle(countidle);
  /* Process commands on the stack: */
  if (0 && !data->lock)
  {
    printf("This portion of code should not be executed!\n");
    if (data->requests->n)
    {
      ++data->lock;
      if (data->lock==1)
      {
        countidle=-1;
        request=getnextrequest(data);
        request->code=Tcl_RecordAndEval(data->interp,request->com,TCL_EVAL_GLOBAL);
        request->res=stringcopy(data->interp->result);
        request->done=1;
      }
      --data->lock;
    } else if(data->commands->n)
    {
      printf(":");
      ++data->lock;
      if (data->lock==1)
      {
        countidle=-1;
        waitrequestlock(data);
        ++data->requestlock;
        if (data->requestlock==1)
        {
          counteval=0;

          printf("|",data->commands->n);

          while(data->commands->n)
          {
            ++counteval;
            disppointer((void **) &(data->command));
            /*
            data->command=delstack(data->commands,1);
            */
            data->command=nextcommand(data);
            /*
            data->command=data->commands->s[data->commands->n];
            --data->commands->n;
            */
            Tcl_RecordAndEval(data->interp,data->command,TCL_EVAL_GLOBAL);
          }
          printf("> ");
        }
        --data->requestlock;
      }
      --data->lock;
      /*
      printf("\nITK server: %i evaluations\n\n",counteval);
      */
    }
  }
  /*
  Tcl_MutexUnlock(mutexptr);
  */
  ++i;
  /*
  printf("\n<<<Thread %i, %i. execution of the loop.>>>\n",Tcl_GetCurrentThread,i);
  */
}
printf("\n\nEnd of ITK event loop.\n\n");
/*
Tcl_ExitThread(0);
*/
dispstackall(&(data->commands));
dispstackall(&(data->requests));
#ifdef MAC_TCL
  return 0;
#elif defined __WIN32__
  return 0;
#else
  return;
#endif
}


static void createiekthread(void)
    /* Creates the IEK thread and sets up the Tk event loop that runs in this
    thread.
    $A Igor apr04; */
{
if (iekthread!=NULL)
{
  warnfunc1(1,"createiekthread");
  sprintf(ers(),"A thread for server Tcl interpreter has already been created.\n");
  warnfunc2();
  return;
} else
{
  /* WARNING: A tcl interpreter must be created if we want to call
  Tcl_CreateThread(): */
  if (tclinterp==NULL)
    tcl_initialize();
  iekthread=calloc(1,sizeof(*iekthread));
  /*
  itk_init(&(tclinterp));
  */
  iekthread->commands=newstack(comstex);
  iekthread->requests=newstack(5);
  iekthread->lock=1;
  iekthread->requestlock=1;
  iekthread->interp=NULL;

  /*
  pushstack(iekthread->commands,stringcopy("wm withdraw ."));
  pushstack(iekthread->commands,stringcopy("itk_initialize"));
  */
  /*
  printf("Before creating the thread...\n");
  */
  
  itk_init(&(iekthread->interp));
  /*
  Tcl_Eval(iekthread->interp,"wm withdraw .");
  Tcl_Eval(iekthread->interp,"itk_initialize");
  */

  Tcl_CreateThread(&(iekthread->id),iekthreadmain,(int *) iekthread,TCL_THREAD_STACK_DEFAULT,TCL_THREAD_NOFLAGS);
  waituntilidle(iekthread);
}
iekin=1;  /* set initialization thread */
}




void iek_initialize(void)
    /* Initializes the IEK server (creates the thread and sets up the server)
    if it has not been initialised yet. It is not necessary to call this
    function exprlicitly because it is implicitly called by other functions
    for accessing the IEK functionality.
    $A Igor apr04; */
{
++iekrec;
if (iekrec==1) /* prevent recursion */
{
  if (iekthread==NULL)
    createiekthread();
}
--iekrec;
}

int iek_initialized(void)
    /* Returns 1 if the bare Tcl interpreter is already initialized and 0
    otherwise.
    $A Igor apr04; */
{
return iekin;
}


void iek_lockinterp(void)
    /* If necessary, waits until the Tcl interpreter of the IEK server thread
    is unlocked, and locks it so that other threads can not access it. After
    this function returns, the interpreter can be accessed, e.g. for installing
    new procedures. This function must aways be called in pair with the
    iek_unlockinterp(), which unlocks the interpreter after use so that the
    IEK server can continue serving requests.
    $A Igor apr04; */
{
char done=0;
if (iekthread==NULL)
  iek_initialize();
while (!done)
{
  waitthreaddatalock(iekthread);
  ++iekthread->lock;
  if (iekthread->lock==1)
    done=1;
  else
    --iekthread->lock;
}
}


void iek_unlockinterp(void)
    /* Unlock the IEK's Tcl interpreter so that it can be used by another
    threads. This function must be used after the iek_lockinterp().
    $A Igor apr03; */
{
if (iekthread==NULL)
  iek_initialize();
--iekthread->lock;
}


Tcl_Interp *iek_interp(void)
    /* Returns the Tcl interpreter fo the IEK system so that its state can be
    checked, new commands installed, etc. The portions of code in which the
    the returned interpreter is used should be ALWAYS EMBEDDED within the calls
    to iek_lockinterp() and iek_unlockinterp(). This ensures that the
    interpreter is accessed simultaneously only by one single thread.
    $A Igor apr04; */
{
if (iekthread==NULL)
  iek_initialize();
return iekthread->interp; 
}


void iek_sendcom(char *com)
    /* Sends the command com to the ITK server for execution. com must be
    dynamically allocated; It must not be be freed or modified after execution
    of this command.
    $A Igor apr03; */
{
char done=0;
if (iekthread==NULL)
  iek_initialize();
while (!done)
{
  waitrequestlock(iekthread);
  ++iekthread->requestlock;
  if (iekthread->requestlock==1)
  {
    Tcl_Eval(iekthread->interp,com);
    if (com!=NULL)
      free(com);
    done=1;
  }
  --iekthread->requestlock;
}
}

void iek_sendcomcp(char *com)
    /* Sends a copy of the command com to the IEK server for execution. com
    does not need to be dynamically allocated because the function creates
    its dynamic copy internally.
    $A Igor apr03; */
{
char done=0;
char *command;
if (iekthread==NULL)
  iek_initialize();
while (!done)
{
  waitrequestlock(iekthread);
  ++iekthread->requestlock;
  if (iekthread->requestlock==1)
  {
    command=stringcopy(com);
    Tcl_Eval(iekthread->interp,command);
    disppointer((void **) &command);
    done=1;
  }
  --iekthread->requestlock;
}
}


char *iek_interpret(char *com,int *code)
    /* Sends a Tcl command com to the IEK server, waits its interpretation
    and returns a dynamically allocated copy of the result of interpretation.
    If code is not NULL, the return code is stored in *code. The returned value
    must be deallocated when not needed anymore. com must be dynamically
    allocated (because it is deallocated by the server by using free()) and may
    not be modified after this function is called.
    $A Igor apr03; */
{
char done=0;
Tcl_Event *event=NULL;
char *ret=NULL;
if (iekthread==NULL)
  iek_initialize();
while (!done)
{
  waitrequestlock(iekthread);
  ++iekthread->requestlock;
  if (iekthread->requestlock==1)
  {
    if (code!=NULL)
      *code=Tcl_RecordAndEval(iekthread->interp,com,TCL_EVAL_GLOBAL);
    else
      Tcl_RecordAndEval(iekthread->interp,com,TCL_EVAL_GLOBAL);
    ret=stringcopy(iekthread->interp->result);
    done=1;
  }
  --iekthread->requestlock;
}
return ret;
}


char *iek_interpretcp(char *com,int *code)
    /* Sends a Tcl command com to the IEK server, waits its interpretation
    and returns a dynamically allocated copy of the result of interpretation.
    If code is not NULL, the return code is stored in *code. The returned value
    must be deallocated when not needed anymore.
      com does not need to be3 dynamically allocated because the function
    creates its dynamic copy internally.
    $A Igor apr03; */
{
char done=0;
char *ret=NULL,*command;

if (iekthread==NULL)
  iek_initialize();
while (!done)
{
  waitrequestlock(iekthread);
  ++iekthread->requestlock;
  if (iekthread->requestlock==1)
  {
    command=stringcopy(com);
    if (code!=NULL)
      *code=Tcl_RecordAndEval(iekthread->interp,com,TCL_EVAL_GLOBAL);
    else
      Tcl_RecordAndEval(iekthread->interp,com,TCL_EVAL_GLOBAL);
    ret=stringcopy(iekthread->interp->result);
      done=1;
    disppointer((void **) &command);
  }
  --iekthread->requestlock;
}
return ret;
}



void iek_shell(void)
    /* The shell in which user can execute Tcl commands by the IEK server and
    view results; Uses standart input and output, executed serially.
    $A Igor apr04; */
{
char *line=NULL,*res=NULL,*aux,*line1=NULL;
int code,emptystrings=0;
if (iekthread==NULL)
  iek_initialize();
printf("\nInput iek/Tcl/Tk commands; 2* empty string to finish!\n");
while (emptystrings<2)
{
  line=NULL;
  if (line1==NULL)
    printf("IEK> ");
  readstring(&line);
  if (stringlength(line)==0)
    ++emptystrings;
  else
    emptystrings=0;
  if (line1!=NULL)
  {
    /* Append the read string to the previous lines: */
    aux=line;
    line=multstringcat(line1,"\n",line,NULL);
    disppointer((void **) &aux);
    disppointer((void **) &line1);
  }
  if (Tcl_CommandComplete(line))
  {
    /* Execute command: */
    res=iek_interpret(line,&code);
    if (code!=TCL_OK)
      printf ("    Error %i: %s\n",code,res);
    else
      printf("    \"%s\"\n",res);
    disppointer((void **) &line);
    disppointer((void **) &res);
  } else
  {
    /* Command not complete, add a new line */
    /*
    iek_sendcomcp("itk_notice . {} 500 \"Command not complete,\\n append completion!\"");
    */
    line1=line;
    line=NULL;
  }
}
}











void testitk(void)
    /* Tests the performance of ITK server.
    $A Igor apr04; */
{
int i,n=1000,cont=1,shell=0;
double t1,t2,t3,t4,ct1,ct2,ct3,ct4;
stack commands=NULL;
char *command=NULL,*com=NULL;
commands=newstack(comstex);
while (cont)
{
  printf("Set sleeping parameters!\n manycommands: ");
  readint(&manycommands);
  printf("loadrequestsleep: ");
  readint(&loadrequestsleep);
  printf("Insert some commands (0/1)? "); readint(&shell);
  if (shell)
  {
    itk_shell();
    iek_shell();
  }
  printf("\nCommand: ");
  readstring(&command);
  printf("Number of evaluations: ");
  readint(&n);
  t1=absolutetime();
  ct1=cputime();
  printf("Evaluating the command by the Tcl interpreter...");
  for (i=1;i<=n;++i)
  {
    tcl_sendcomcp(command);

    /*
    pushstack(commands,stringcopy(command));
    if (commands->n>=manycommands)
    {
      while(commands->n)
      {
        disppointer((void **) &com);
        com=nextcommand0(commands);
        tcl_sendcom(command);
      }
    }
    */
  }
  t2=absolutetime();
  ct2=cputime();
  printf("\nTime spent: %g seconds (CPU: %g seconds).\n\n",t2-t1,ct2-ct1);
  printf("Evaluating the command by the ITK server...");
  for (i=1;i<=n;++i)
  {
    /*
    itk_sendcomcp(command);
    */
  }
  t3=absolutetime();
  ct3=cputime();
  printf("\nTime spent: %g seconds (CPU: %g seconds).\n\n",t3-t2,ct3-ct2);
  printf("Waiting until server is idle...\n");
  waituntilidle(itkthread);
  t3=absolutetime();
  ct3=cputime();
  printf("\nTime spent: %g seconds (CPU: %g seconds).\n\n",t3-t2,ct3-ct2);
  
  printf("Evaluating the command by the iek interpreter/n  (main thread, event loop in parallel thread)...");
  for (i=1;i<=n;++i)
  {
    iek_sendcomcp(command);
  }
  t4=absolutetime();
  ct4=cputime();
  printf("\nTime spent: %g seconds (CPU: %g seconds).\n\n",t4-t3,ct4-ct3);
  
  printf("Continue (0/1)? ");
  readint(&cont);
}
}



#else  /* ! defined ITK */

    /* EMPTY DEFINITIONS OF SOME ITK FUNCTIONS:
  These functions are defined in the case that ITK is not present, but 
without any functionality. The sole purpose of this is that some standard
functionality such as tracking in er.c can be defined in the same way (e.g.
parts that examin the thread info). */


#define funcdef(dec) dec {err0(); \
  sprintf(ers(),"ITK not present.\n"); err2();}
  
  funcdef(
    void itk_shell(void)
  )

int getthreadid(void)
    /* Returns the identification number of the current thread. Tcl returns
    the identification which is a pointer, but this pointer is unique (since
    it is not dynamically allocated) and constant for each thread, so it can
    be converted to an integer used for identification.
    $A Igor apr03; */
{
errfunc0("getthreadid");
sprintf(ers(),"ITK not present.\n");
errfunc2();
return 0;
}
  

int getmainthreadid(void)
    /* Return the identification number of the main program thread.
    $A Igor apr03; */
{
errfunc0("getmainthreadid");
sprintf(ers(),"ITK not present.\n");
errfunc2();
return 0;
}

int ismainthread(void)
    /* Returns 1 if the current thread is the main program thread, 0 otherwise.
    $A Igor apr03; */
{
errfunc0("ismainthread");
sprintf(ers(),"ITK not present.\n");
errfunc2();
return 1;
}

int getitkthreadid(void)
    /* Return the identification number of the ITK server thread.
    $A Igor apr03; */
{
errfunc0("getitkthreadid");
sprintf(ers(),"ITK not present.\n");
errfunc2();
return 0;
}

int createthread(void procmain(void *),void *data)
    /* Creates a new thread and returns its identification number. procmain
    is the main procedure for the new thread and data is an argument to this
    procedure.
    A special mechanism ensures that every thread calls the appropriate
    procedure which was passed as the procmain argument to this function.
    Bodies of this function are serialised, therefore thefunction is thread
    safe and can even be called recursively in procmain.
    $A Igor apr03; */
{
errfunc0("createthread");
sprintf(ers(),"ITK not present.\n");
sprintf(ers(),"The thread procedure will be run sequentially.\n");
errfunc2();
return 0;
}


void tcl_sleep(double sec)
    /* Sleeps (pauses the process) for a given number of seconds.
    $A Igor jun03; */
{
errfunc0("tcl_sleep");
sprintf(ers(),"ITK not present.\n");
errfunc2();
}



# endif   /* not defined ITK */





