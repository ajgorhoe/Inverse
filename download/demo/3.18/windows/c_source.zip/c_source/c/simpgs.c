
#include <sysint.h>

#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <math.h>
#include <mtypes.h>
#include <er.h>
#include <strop.h>
#include <rf.h>
#include <st.h>
#include <fop.h>
#include <vec.h>
#include <lint.h>
#include <simb.h>
#include <grint.h>

#include <sg_obj.h>





               /**********************************/
               /*                                */
               /*    Osnovni sistem za SimpGR    */
               /*                                */
               /**********************************/



typedef struct {
    licom lint;
    stack groups,
          actgroups;
    frame3d frame;
    stack windows;
    golinesettings ls1,ls2,ls3;
    gofillsettings fs1,fs2,fs3;
    gotextsettings ts1,ts2,ts3;
}  _simpgscom;

typedef _simpgscom *simpgscom;

static simpgscom gcom=NULL;



static void lintsignal(void *ptrcom)
    /* Izpise znak, ki pove uporabniku, da je v debuggerju. Ta funkcija se
    naj izvrsi pred branjem vsakega ukaza v vrsticnem interpreterju, zato jo
    instaliramo na vrsticni interpreter datotecnega interpreterja.
    $A Igor apr98; */
{
printf("SGS> ");
}






