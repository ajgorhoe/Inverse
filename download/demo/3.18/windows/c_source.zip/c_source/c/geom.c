
                    /****************************/
                    /*                          */
                    /*  GEOMETRIJSKE OPERACIJE  */
                    /*                          */
                    /****************************/


#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>



#include <mtypes.h>
#include <er.h>
#include <vec.h>
#include <mat.h>
#include <st.h>
#include <matrixop.h>
#include <rf.h>
#include <rand.h>
#include <strop.h>
#include <mtime.h>

#include <geom.h>



static char prn=1;




                    /*******************/
                    /*                 */
                    /*  CUBIC SPLINES  */
                    /*                 */
                    /*******************/



static int repspl=1;  /* Doloca, ali naj se zlepek popravi z obrnjenimi podatki */


#define P2(x) ((x)*(x))
#define P3(x) ((x)*(x)*(x))
#define c_d(i) (1/(cs->x->v[i+1]-cs->x->v[i]))
#define c_x(i) (cs->x->v[i])
#define c_y(i) (cs->y->v[i])
#define c_u(i) (cs->u->v[i])
#define c_dA(i,j) (cs->dA->m[i][j])
#define c_db(i) (cs->db->v[i])
#define c_du(i) (cs->du->v[i])



/* FUNKCIJE ZA MANIPULACIJO S TIPOM cubspldata: */

cubspldata newcubspldata(void)
    /* Naredi nov objekt tipa cubspldata in ga vrne, kazalce na objektu pa pred
    tem postavi na NULL.
    $A Igor avg01; */
{
cubspldata ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
return ret;
}

void dispcubsplauxvar(cubspldata cs)
    /* Zbrise pomozne alocirane podatke na *cs, torej vse razen cs->x in
    cs->y. Ustrezne kazalce postavi na NULL.
    $A Igor avg01; */
{
if (cs!=NULL)
{
  dispvector(&cs->u);
  dispvector(&cs->b);
  dispvector(&cs->dudk1);
  dispvector(&cs->dudkn);
  dispvector(&cs->db);
  cs->du=NULL; /* ker se ta pomozni vektor uporablja le kot kazalec in se nikoli
    ne alocira */
  dispstackallspec(&cs->dudx,(void (*)(void **)) dispvector);
  dispstackallspec(&cs->dudy,(void (*)(void **)) dispvector);
  dispmatrix(&cs->A);
  dispmatrix(&cs->Adec);
  dispmatrix(&cs->dA);
  dispindtab(&cs->Aind);
}
}


void dispcubsplintvar(cubspldata cs)
    /* Zbrise vse tiste pomozne spremenljivke kubicnega zlepka cs, ki jih
    rabimo za vmesne rezultate, niso pa potrebni pri samem racunanju, ko imamo
    ze izracunane potrebne pomozne spremenljivke (t.j. vektor odvodov v
    notranjih vozliscih in njegovi odvodi po parametrih, glede na katere bomo
    racunali obcutljivosti). To funkcijo lahko uporabimo, da prihranimo
    prostor, ki bi ga drugace cs po nepotrebnem zasedel, vendar deluje le,
    ce pred njenim klicem pripravimo vse potrebne podatke za izracune vrednosti
    in senzitivnosti kubicnega zlepka, ki bodo sledili. To iz vedemo s pomocjo
    funkcij prepcubsplval(), prepcubsplsensy() in podobnih.
    $A Igor avg01; */
{
dispvector(&cs->b);
dispvector(&cs->db);
cs->du=NULL; /* ker se ta pomozni vektor uporablja le kot kazalec in se nikoli
  ne alocira */
dispmatrix(&cs->A);
dispmatrix(&cs->Adec);
dispmatrix(&cs->dA);
dispindtab(&cs->Aind);
}


void dispcubsplvar(cubspldata cs)
    /* Zbrise vse podatke na cs.
    $A Igor avg01; */
{
if (cs!=NULL)
{
  dispcubspldata(&(cs->reverse));  /* $$ */
  dispcubsplauxvar(cs);
  dispvector(&cs->x);
  dispvector(&cs->y);
  cs->n=0;
}
}

void dispcubspldata(cubspldata *pcs)
    /* Sprosti prostor za podatke o kubicnem zlepku, na katerega kaze **pcs, in
    postavi *pcs na NULL.
    $A Igor avg01; */
{
if (pcs!=NULL)
  if (*pcs!=NULL)
  {
    dispcubsplvar(*pcs);
    free(*pcs);
    *pcs=NULL;
  }
}



cubspldata copycubspldata(cubspldata cs1,cubspldata *cs2)
    /* Vrne kopijo cs1. Ce je cs2 razlicen od NULL, skopira cs1 v *cs2 in vrne
    *cs2. Funkcija je konstruirana podobno kot recimo copyvector0().
    $A Igor avg01; */
{
cubspldata cs;
int i;
if (cs2!=NULL)
{
  /* Ce je cs2!=NULL, se v1 skopira v *cs2: */
  if (cs1==NULL)
  {
    dispcubspldata(cs2);
  } else
  {
    /* Ce je *cs2==NULL, tvorimo *cs2 na novo: */
    if (*cs2==NULL)
      *cs2=newcubspldata();
    cs=*cs2;
    /* Kopiranje vrednosti: */
    copycubspldata(cs1->reverse,&(cs1->reverse));  /* $$ */
    cs->k1=cs1->k1;
    cs->kn=cs1->kn;
    cs->n=cs1->n;
    copyvector0(cs1->x,&(cs->x));
    copyvector0(cs1->y,&(cs->y));
    copyvector0(cs1->u,&(cs->u));
    copymatrix0(cs1->A,&(cs->A));
    copyvector0(cs1->b,&(cs->b));
    copyindtab(cs1->Aind,&(cs->Aind));
    if (cs1->dudx==NULL)
      dispstackallspec(&cs->dudx,(void (*)(void **)) dispvector);
    else if (cs1->dudx->n==0)
    {
      dispstackvalspec(cs->dudx,(void (*)(void **)) dispvector);
      if (cs->dudx==NULL)
        cs->dudx=newstack(cs1->dudx->ex);
    } else
    {
      for (i=1;i<=cs1->dudx->n;++i)
      {
        /* Kopiranje vektorjev s sklada cs1->dudx; Ce ima sklad cs->dudx, na
        katerega kopiramo, manj elementov kot i, porinemo nanj dodaten kazalec
        NULL: */
        if (cs->dudx->n<i)
          pushstack(cs->dudx,NULL);
        copyvector0(cs1->dudx->s[i],(vector *) &(cs->dudx->s[i]));
      }
      for (i=cs->dudx->n;i>cs1->dudx->n;--i)
      {
        /* Brisanje morebitnih odvecnih elementov sklada cs->dudx, na katerega
        kopiramo: */
        dispvector((vector *) &(cs->dudx->s[i]));
        popstack(cs->dudx);
      }
    }
    if (cs1->dudy==NULL)
      dispstackallspec(&cs->dudy,(void (*)(void **)) dispvector);
    else if (cs1->dudy->n==0)
    {
      dispstackvalspec(cs->dudy,(void (*)(void **)) dispvector);
      if (cs->dudy==NULL)
        cs->dudy=newstack(cs1->dudy->ex);
    } else
    {
      for (i=1;i<=cs1->dudy->n;++i)
      {
        /* Kopiranje vektorjev s sklada cs1->dudy; Ce ima sklad cs->dudy, na
        katerega kopiramo, manj elementov kot i, porinemo nanj dodaten kazalec
        NULL: */
        if (cs->dudy->n<i)
          pushstack(cs->dudy,NULL);
        copyvector0(cs1->dudy->s[i],(vector *) &(cs->dudy->s[i]));
      }
      for (i=cs->dudy->n;i>cs1->dudy->n;--i)
      {
        /* Brisanje morebitnih odvecnih elementov sklada cs->dudy, na katerega
        kopiramo: */
        dispvector((vector *) &(cs->dudy->s[i]));
        popstack(cs->dudy);
      }
    }
    copyvector0(cs1->dudk1,&(cs->dudk1));
    copyvector0(cs1->dudkn,&(cs->dudkn));
    copymatrix0(cs1->dA,&(cs->dA));
    copyvector0(cs->db,&(cs->db));
    cs->du=NULL;
  }
  return *cs2; /* Ker je bil cs2!=NULL, se vrne *cs2. */
} else
{
  /* v2==NULL, naredi se nov vektor, ki je kopija cs1, vrne se njegov kazalec: */
  if (cs1==NULL)
    return NULL;
  else
  {
    cubspldata blind=NULL;
    return copycubspldata(cs1,&blind);
  }
}
}


void fprintcubsplstate(FILE *fp,cubspldata cs)
    /* V datoteko fp izpise stanje sistema za racunanje kubicnih zlepkov.
    $A Igor avg01; */
{
int i;
fprintf(fp,"State of the data for cubic cpline data:\n");
if (cs->x==NULL)
{
  fprintf(fp,"Vector of x coordinates is NULL.\n");
  if  (cs->y==NULL)
    fprintf(fp,"Vector of y coordinates is NULL.\n");
}
else if (cs->y==NULL)
  fprintf(fp,"Vector of y coordinates is NULL.\n");
else
{
  fprintf(fp,"Nodes of the spline:\n%4s %-12s %-12s %-12s\n",
   "Pt.","x coord.","y coord","derivative");
  if (cs->x->d>0)
  {
    fprintf(fp,"%4i %-12g %-12g %-12g (prescribed)\n",
     1,cs->x->v[1],cs->y->v[1],cs->k1);
    for (i=2;i<cs->x->d;++i)
    {
      fprintf(fp,"%4i %-12g %-12g",i,cs->x->v[i],cs->y->v[i]);
      if (cs->u!=NULL)
        fprintf(fp," %-12g\n",cs->u->v[i-1]);
      else
        fprintf(fp," %-12s\n","------");
    }
    fprintf(fp,"%4i %-12g %-12g %-12g (prescribed)\n",
     i,cs->x->v[i],cs->y->v[i],cs->kn);
  }
  if (cs->u==NULL)
    fprintf(fp,"Vector of derivatives in nodes is NULL.\n");
  else
    fprintf(fp,"Vector of derivatives in nodes is calculated, dim. %i.\n",cs->u->d);
  if (cs->A==NULL)
    fprintf(fp,"Matrix of the system A is NULL.\n");
  else
    fprintf(fp,"Matrix of the system is allocated, dim. %i*%i.\n",cs->A->d1,cs->A->d1);
  if (cs->Adec==NULL)
    fprintf(fp,"Decomposed matrix of the system is NULL.\n");
  else
    fprintf(fp,"Decomposed matrix of the system is allocated, dim. %i*%i.\n",cs->Adec->d1,cs->Adec->d1);
  if (cs->Aind==NULL)
    fprintf(fp,"Permutation table of decomposition is NULL.\n");
  else
    fprintf(fp,"Permutation table of decomposition is allocated, dim. %i.\n",cs->Aind->n);
  if (cs->b==NULL)
    fprintf(fp,"Vector of the right side of the system is NULL.\n");
  else
    fprintf(fp,"Vector of the right side of the system is evaluated, dim. %i.\n",cs->b->d);
  if (cs->dudx==NULL)
    fprintf(fp,"Stack of derivatives of u with respect to nodal x-coordinates is NULL.\n");
  else if (cs->dudx->n<1)
    fprintf(fp,"Stack of derivatives of u with respect to nodal x-coordinates has no elements.\n");
  else
  {
    fprintf(fp,"Vectors of derivatives of u with respect to x coordinates of nodes:\n");
    for (i=1;i<=cs->dudx->n;++i)
    {
      fprintf(fp,"%i: ",i);
      if (cs->dudx->s[i]==NULL)
        fprintf(fp,"NULL      ");
      else
        fprintf(fp,"dim.%-4i ",((vector) cs->dudx->s[i])->d);
    }
    fprintf(fp,"\n");
  }
  if (cs->dudy==NULL)
    fprintf(fp,"Stack of derivatives of u with respect to nodal y-coordinates is NULL.\n");
  else if (cs->dudy->n<1)
    fprintf(fp,"Stack of derivatives of u with respect to nodal y-coordinates has no elements.\n");
  else
  {
    fprintf(fp,"Vectors of derivatives of u with respect to y coordinates of nodes:\n");
    for (i=1;i<=cs->dudy->n;++i)
    {
      fprintf(fp,"%i: ",i);
      if (cs->dudy->s[i]==NULL)
        fprintf(fp,"NULL      ");
      else
        fprintf(fp,"dim.%-4i ",((vector) cs->dudy->s[i])->d);
    }
    fprintf(fp,"\n");
  }
  if (cs->dudk1==NULL)
    fprintf(fp,"Vector of derivatives of u with respect k1 is NULL.\n");
  else
    fprintf(fp,"Vector of derivatives of u with respect to k1 is calculated (dim. %i).\n",cs->dudk1->d);
  if (cs->dudk1==NULL)
    fprintf(fp,"Vector of derivatives of u with respect k1 is NULL.\n");
  else
    fprintf(fp,"Vector of derivatives of u with respect to k1 is calculated (dim. %i).\n",cs->dudkn->d);
  if (cs->dA==NULL)
    fprintf(fp,"Auxiliary matrix for calculating derivatives of A is NULL.\n");
  else
    fprintf(fp,"Auxiliary matrix for calculating derivatives of A is allocated (dim. %i*%i).\n",cs->dA->d1,cs->dA->d2);
  if (cs->db==NULL)
    fprintf(fp,"Auxiliary vector for calculating derivatives of b is NULL.\n");
  else
    fprintf(fp,"Auxiliary vector for calculating derivatives of b is allocated (dim. %i*%i).\n",cs->db->d);
}
if (cs->reverse!=NULL)  /* $$ */
{
  fprintf(fp,"\n\nReverse ordered cubic spline:\n");
  fprintcubsplstate(fp,(cubspldata) cs->reverse);
}
}

void printcubsplstate(cubspldata cs)
    /* Na standardni izhod izpise stanje sistema za racunanje kubicnih zlepkov.
    $A Igor avg01; */
{
fprintcubsplstate(stdout,cs);
}




/* FUNKCIJE ZA NASTAVITEV KUBICNEHA ZLEPKA: */



static void cubsplprepreverse(cubspldata ret)
    /* Prepares the cubic spline with reverse ordering of points on the ret
    if repspl is not 0. This function is used for correction of cubic spline
    calculation which for now gives some unexplained results.
    $A Igor feb03; */
{
if (ret!=NULL && repspl && !ret->rep)
{
  if (ret->x!=NULL)
  {
    vector xrev,yrev,x,y;
    int i;
    x=ret->x;
    y=ret->y;
    ret->reverse=newcubspldata();
    ret->reverse->rep=1;  /* Prevent infinite recursion in setcubspl() */
    setcubspl(&(ret->reverse),ret->x,ret->y,ret->kn,ret->k1);
    xrev=ret->reverse->x;
    yrev=ret->reverse->y;
    for (i=1;i<=x->d;++i)
    {
      xrev->v[i]=x->v[x->d-i+1];
      yrev->v[i]=y->v[y->d-i+1];
    }
  }
}
}

cubspldata setcubspl(cubspldata *csp,vector x,vector y,double k1,double kn)
    /* Nastavi definicijo kubicnega zlepka. V vektorju x so abscise, v vektorju
    y pa ordinate vozlisc zlepka, v k1 in kn pa predpisani vrednosti odvoda v
    skrajnih vozliscih. Ce sta x in y NULL, se zbrise trenutna definicija
    zlepka. Vektorja morata imeti enaki dimenziji. Ta funkcija nicesar ne
    izracuna, temvec le postavi podatke na **csp, ki definirajo zlepek.
    Funkcija vrne *csp. Ce je csp NULL, se objekt, ki ga funkcija vrne, tvori
    na novo (ce je seveda situacija taksna, da lahko vrne funkcija kazalec
    razlicen od NULL).
     Ce pride do napake (npr. ce je eden od vektorjev x in y NULL ali ce imata
    razlicno dimenzijo), se *csp (ce obstaja) zbrise in postavi na NULL, javi
    se napaka in funkcija vrne NULL. Ce sta x in y enaka NULL, funkcija ne javi
    napake, ker je to predvidena situacija.
    $A Igor avg01; */
{
cubspldata ret=NULL;
if (x==NULL)
{
  if (y==NULL)
  {
    /* Ce sta oba vektorja NULL, se zbrise definicija kubicnega zlepka, ce ze
    obstaja: */
    dispcubspldata(csp);
    return ret;
  } else
  {
    errfunc0("setcubspl");
    fprintf(erf(),"Vector of x coordinates of nodes is NULL.\n");
    errfunc2();
    dispcubspldata(csp);
    return ret;
  }
} else if (y==NULL)
{
  errfunc0("setcubspl");
  fprintf(erf(),"Vector of y coordinates of nodes is NULL.\n");
  errfunc2();
  dispcubspldata(csp);
  return ret;
} else if (x->d<2)
{
  errfunc0("setcubspl");
  fprintf(erf(),"Less than 2 nodes specified.\n");
  errfunc2();
  dispcubspldata(csp);
  return ret;
} else if (x->d!=y->d)
{
  errfunc0("setcubspl");
  fprintf(erf(),"Dimensions of vectors x and y coordinates are not compatible (%i vs. %i).\n",
   x->d,y->d);
  errfunc2();
  dispcubspldata(csp);
  return ret;
} else
{
  int i;
  /* Preverimo, ce so abscise kubicnega zlepka urejene po narascajocem vrstnem
  redu in tako, da ni podvojenih tock: */
  for (i=1;i<x->d;++i)
    if (x->v[i+1]<=x->v[i])
      i=x->d+1;
  if (i==x->d+1)
  {
    errfunc0("setcubspl");
    fprintf(erf(),"x coordinates of nodes not orderd properly or not unique.\n");
    errfunc2();
    dispcubspldata(csp);
    return ret;
  }
  if (csp!=NULL)
  {
    if (*csp!=NULL)
      dispcubsplauxvar(*csp);
    else
      *csp=newcubspldata();
    ret=*csp;
  } else
    ret=newcubspldata();
  copyvector0(x,&ret->x);
  copyvector0(y,&ret->y);
  ret->k1=k1;
  ret->kn=kn;
  ret->n=x->d;
  if (repspl) cubsplprepreverse(ret); /* $$ */
}
return ret;
}



cubspldata setcubspldir(cubspldata *csp,vector x,vector y,double k1,double kn)
    /* Nastavi definicijo kubicnega zlepka. Funkcija deluje podobno kot
    setcubspl(), le da se vektorja abscis in ordinat vozlisc postavita DIREKTNO
    na x in y in se ne kopirata. Ce sta v sistemu ustrezna vektorja abscis in
    ordinat vozlisc ze alocirana, se ta vektorja zbriseta. To funkcijo
    uporabljamo namesto obicajne le izjemoma, predvsem takrat, ko hocemo
    prihraniti cas za kopiranje.
    $A Igor avg01; */
{
cubspldata ret=NULL;
if (x==NULL)
{
  if (y==NULL)
  {
    /* Ce sta oba vektorja NULL, se zbrise definicija kubicnega zlepka, ce ze
    obstaja: */
    dispcubspldata(csp);
    return ret;
  } else
  {
    errfunc0("setcubspl");
    fprintf(erf(),"Vector of x coordinates of nodes is NULL.\n");
    errfunc2();
    dispcubspldata(csp);
    dispvector(&x); dispvector(&y);
    return ret;
  }
} else if (y==NULL)
{
  errfunc0("setcubspl");
  fprintf(erf(),"Vector of y coordinates of nodes is NULL.\n");
  errfunc2();
  dispcubspldata(csp);
  dispvector(&x); dispvector(&y);
  return ret;
} else if (x->d<2)
{
  errfunc0("setcubspl");
  fprintf(erf(),"Less than 2 nodes specified.\n");
  errfunc2();
  dispcubspldata(csp);
  dispvector(&x); dispvector(&y);
  return ret;
} else if (x->d!=y->d)
{
  errfunc0("setcubspl");
  fprintf(erf(),"Dimensions of vectors x and y coordinates are not compatible (%i vs. %i).\n",
   x->d,y->d);
  errfunc2();
  dispcubspldata(csp);
  dispvector(&x); dispvector(&y);
  return ret;
} else
{
  int i;
  /* Preverimo, ce so abscise kubicnega zlepka urejene po narascajocem vrstnem
  redu in tako, da ni podvojenih tock: */
  for (i=1;i<x->d;++i)
    if (x->v[i+1]<=x->v[i])
      i=x->d+1;
  if (i==x->d+1)
  {
    errfunc0("setcubspl");
    fprintf(erf(),"x coordinates of nodes not orderd properly or not unique.\n");
    errfunc2();
    dispcubspldata(csp);
    return ret;
  }
  if (csp!=NULL)
  {
    if (*csp!=NULL)
      dispcubsplvar(*csp);
    else
      *csp=newcubspldata();
    ret=*csp;
  } else
    ret=newcubspldata();
  ret->x=x;
  ret->y=y;
  ret->k1=k1;
  ret->kn=kn;
  ret->n=x->d;
  if (repspl) cubsplprepreverse(ret); /* $$ */
}
return ret;
}




/* FUNKCIJE ZA IZRACUN VMESNIH REZULTATOV PO POTREBI (ce se niso izracunani): */


static void cubsplcalcA(cubspldata cs)
    /* Ce se ni izracunana, izracuna matriko linearnega sistema za izracun
    odvodov v notranjih vozliscnih tockah kubicnega zlepka cs. Funkcija izracuna
    vse potrebne vmesne rezultate, ki se niso izracunani, pri cemer se opira
    na podatke na *cs.
    $A Igor avg01; */
{
int i;
if (cs->A==NULL && cs->n>2)
{
  zeromat0(cs->n-2,cs->n-2,&cs->A);
  /* Diagonalni elementi matrike: */
  for (i=1;i<=cs->n-2;++i)
    cs->A->m[i][i]=2*(c_d(i)+c_d(i+1));
  /* Poddiagonalni elementi matrike: */
  for (i=2;i<=cs->n-2;++i)
    cs->A->m[i][i-1]=c_d(i);
  /* Naddiagonalni elementi matrike: */
  for (i=1;i<=cs->n-3;++i)
    cs->A->m[i][i+1]=c_d(i+1);
}
}




static void cubsplcalcAdec(cubspldata cs)
    /* Ce se ni izracunana, izracuna LU dekompozicijo matrike sistema za izracun
    odvodov kubicnega zlepka cs v notranjih vozliscnih tockah. Funkcija izracuna
    vse potrebne vmesne rezultate, ki se niso izracunani, pri cemer se opira na
    podatke na cs.
    $A Igor avg01; */
{
int i;
if (cs->Adec==NULL)
{
  cubsplcalcA(cs);
  if (cs->A!=NULL)
  {
    /* Izracunamo LU dekompozicijo, ki jo shranemo kar v cs->A: */
    LUdecomptol0(cs->A,&cs->A,&cs->A,&cs->Aind,&i,0);
    /* Dekompozicijo prestavimo v cs->Adec in postavimo cs->A na NULL: */
    cs->Adec=cs->A;
    cs->A=NULL;
  }
}
}

static void cubsplcalcb(cubspldata cs)
    /* Ce se ni izracunan, izracuna vektor desnih strani sistema za izracun
    odvodov kubicnega zlepka cs v notranjih vozliscnih tockah. Funkcija
    izracuna vse potrebne vmesne rezultate, ki se niso izracunani, pri cemer
    se opira na podatke na cs.
    $A Igor avg01; */
{
int i;
if (cs->A==NULL && cs->n>2)
{
  zerovec0(cs->n-2,&cs->b);
  for (i=1;i<=cs->n-2;++i)
  {
    cs->b->v[i]=3*( P2(c_d(i))*(c_y(i+1)-c_y(i))+P2(c_d(i+1))*(c_y(i+2)-c_y(i+1)) );
    /* Pri prvem in zadnjem elementu imamo dodaten clen: */
    cs->b->v[1]-=c_d(1)*cs->k1;
    cs->b->v[cs->n-2]-=c_d(cs->n-1)*cs->kn;
  }
}
}

static void cubsplcalcu(cubspldata cs)
    /* Ce se ni izracunan, izracuna vektor odvodov v notranjih vozliscnih
    tockah kubicnega zlepka cs z resitvijo sistema enacb. Funkcija izracuna
    vse potrebne vmesne rezultate, ki se niso izracunani, pri cemer se opira
    na podatke na cs.
    $A Igor avg01; */
{
if (cs->u==NULL)
{
  cubsplcalcAdec(cs);
  cubsplcalcb(cs);
  if (cs->Adec!=NULL)
    solvLU0(cs->Adec,cs->Adec,cs->Aind,cs->b,&cs->u);
  if (repspl && !cs->rep)  /* $$ */
  {
    vector u,urev;
    int j;
    cubsplprepreverse(cs);
    cubsplcalcu(cs->reverse);
    u=cs->u;  urev=cs->reverse->u;
    for (j=1;j<=u->d/2;++j)
      u->v[j]=urev->v[u->d-j+1];
  }
}
}

static void cubsplcalcdudy(cubspldata cs,int i)
    /* Ce se ni izracunan, izracuna odvod vektorja odvodov v notranjih
    vozliscnih tockah kubicnega zlepka cs po ordinati i-tega vozlisca. Funkcija
    izracuna vse potrebne vmesne rezultate, ki se niso izracunani, pri cemer se
    opira na podatke na cs.
    $A Igor avg01; */
{
/* Ce ne obstaja sklad, kjer se hranijo odvodi vektorja u po posameznih
ordinatah, ga naredimo: */
if (cs->dudy==NULL)
{
  /* int i; */
  cs->dudy=newstackrn(1,cs->n);
  /*
  cs->dudy=newstack(2);
  for (i=1;i<=cs->n;++i)
    pushstack(cs->dudy,NULL);
  */
}
if (i<1 || i>cs->n)
{
  errfunc0("cubsplcalcdudy");
  fprintf(erf(),"Sensitivity index (i.e. node number) out of range (%i, should be from 1 to %i).\n",
   i,cs->n);
  errfunc2();
} else if (cs->dudy->s[i]==NULL)
{
  /* Ce odvod vektorja u po ordinati i. tocke se ni bil izracunan, ga
  izracunamo; najprej izracunamo vektor desnih strani, ki je enak odvodu
  vektorja b po i. ordinati, saj je odvod matrike A enak 0: */
  zerovec0(cs->n-2,&cs->db);
  if (i<=cs->n-2)
    cs->db->v[i]=-3*P2(c_d(i));
  if (i<=cs->n-1 && i>1)
    cs->db->v[i-1]=3*(P2(c_d(i-1))-P2(c_d(i)));
  if (i>2)
    cs->db->v[i-2]=3*P2(c_d(i-1));
  /* Ce je se nismo, izracunamo LU dekompozicijo matrike sistema: */
  cubsplcalcAdec(cs);
  /* Resimo sistem za odvod vektorja u po i. ordinati tocke: */
  if (cs->Adec!=NULL)
    solvLU0(cs->Adec,cs->Adec,cs->Aind,cs->db,(vector *) &(cs->dudy->s[i]));
  if (repspl && !cs->rep)  /* $$ */
  {
    vector u,urev;
    int j;
    cubsplprepreverse(cs);
    cubsplcalcdudy(cs->reverse,cs->dudy->n-i+1);
    u=cs->dudy->s[i];  urev=cs->reverse->dudy->s[cs->dudy->n-i+1];
    for (j=1;j<=u->d/2;++j)
      u->v[j]=urev->v[u->d-j+1];
  }
}
}

static void cubsplcalcdudkn(cubspldata cs);

static void cubsplcalcdudk1(cubspldata cs)
    /* Ce se ni izracunan, izracuna odvod vektorja odvodov v notranjih
    vozliscnih tockah kubicnega zlepka po predpisanem odvodu v 1. vozliscu k1.
    Funkcija izracuna vse potrebne vmesne rezultate, ki se niso izracunani,
    pri cemer se opira na podatke na cs.
    $A Igor avg01; */
{
if (cs->n>2 && cs->dudk1==NULL)
{
  /* Ce odvod vektorja u po k1 se ni bil izracunan, ga izracunamo; najprej
  izracunamo vektor desnih strani, ki je enak odvodu vektorja b po k1, saj
  je odvod matrike A po k1 enak 0: */
  zerovec0(cs->n-2,&cs->db);
  cs->db->v[1]=-c_d(1); /* samo 1. komponenta je razlicna od 0 */
  /* Ce je se nismo, izracunamo LU dekompozicijo matrike sistema: */
  
  if (1)
  {
  int k;
  matrix A=NULL;
  vector b=NULL;
  cubsplcalcA(cs);
  copymatrix0(cs->A,&A);
  
  cubsplcalcAdec(cs);
  /* Resimo sistem za odvod vektorja u po k1: */
  if (cs->Adec!=NULL)
    solvLU0(cs->Adec,cs->Adec,cs->Aind,cs->db,(vector *) &(cs->dudk1));
  
  matprodvec0(A,cs->dudk1,&b);
  printf("\n\nPreizkus izracuna cs->dudk1:\nA*cs->dudk1 /cs->db\n");
  for (k=1;k<=b->d;++k)
    printf("%10g  %10g\n",b->v[k],cs->db->v[k]);
  }
  
  if (repspl && !cs->rep)  /* $$ */
  {
    vector u,urev;
    int j;
    cubsplprepreverse(cs);
    cubsplcalcdudkn(cs->reverse);
    u=cs->dudk1;  urev=cs->reverse->dudkn;
    for (j=1;j<=u->d/2;++j)
      u->v[j]=urev->v[u->d-j+1];
  }
}
}


static void cubsplcalcdudkn(cubspldata cs)
    /* Ce se ni izracunan, izracuna odvod vektorja odvodov v notranjih
    vozliscnih tockah kubicnega zlepka cs po predpisanem odvodu v zadnjem
    vozliscu kn. Funkcija izracuna vse potrebne vmesne rezultate, ki se niso
    izracunani, pri cemer se opira na podatke na cs.
    $A Igor avg01; */
{
if (cs->n>2 && cs->dudkn==NULL)
{
  /* Ce odvod vektorja u po kn se ni bil izracunan, ga izracunamo; najprej
  izracunamo vektor desnih strani, ki je enak odvodu vektorja b po kn, saj
  je odvod matrike A po kn enak 0: */
  zerovec0(cs->n-2,&cs->db);
  cs->db->v[cs->n-2]=-c_d(cs->n-1); /* samo zadnja komponenta je razlicna od 0 */
  /* Ce je se nismo, izracunamo LU dekompozicijo matrike sistema: */
  cubsplcalcAdec(cs);
  /* Resimo sistem za odvod vektorja u po kn: */
  if (cs->Adec!=NULL)
    solvLU0(cs->Adec,cs->Adec,cs->Aind,cs->db,(vector *) &(cs->dudkn));
  if (repspl && !cs->rep)  /* $$ */
  {
    vector u,urev;
    int j;
    cubsplprepreverse(cs);
    cubsplcalcdudk1(cs->reverse);
    u=cs->dudkn;  urev=cs->reverse->dudk1;
    for (j=1;j<=u->d/2;++j)
      u->v[j]=urev->v[u->d-j+1];
  }
}
}


static void cubsplcalcdudx(cubspldata cs,int i)
    /* Ce se ni izracunan, izracuna odvod vektorja odvodov v notranjih
    vozliscnih tockah kubicnega zlepka cs po abscisi i-tega vozlisca. Funkcija
    izracuna vse potrebne vmesne rezultate, ki se niso izracunani, pri cemer se
    opira na podatke na cs.
    $A Igor avg01; */
{
/* Ce ne obstaja sklad, kjer se hranijo odvodi vektorja u po posameznih
abscisah, ga naredimo: */
if (cs->dudx==NULL)
  cs->dudx=newstackrn(1,cs->n);
if (i<1 || i>cs->n)
{
  errfunc0("cubsplcalcdudx");
  fprintf(erf(),"Sensitivity index (i.e. node number) out of range (%i, should be from 1 to %i).\n",
   i,cs->n);
  errfunc2();
} else if (cs->dudx->s[i]==NULL)
{
  /* Ce odvod vektorja u po abscisi i. tocke se ni bil izracunan, ga
  izracunamo; najprej izracunamo vektor desnih strani, od tega pa najprej
  odvod vektorja b: */
  zerovec0(cs->n-2,&cs->db);
  if (i<=cs->n-2)
    cs->db->v[i]=6*P3(c_d(i))*(c_y(i+1)-c_y(i));
  if (i>=2 && i<=cs->n-1)
    cs->db->v[i-1]=6*( -P3(c_d(i-1)) * (c_y(i)-c_y(i-1)) +
     P3(c_d(i)) * (c_y(i+1)-c_y(i)) );
  if (i>=3)
    cs->db->v[i-2]=-6*P3(c_d(i-1)) * (c_y(i)-c_y(i-1));
  /* Potem izracunamo odvod matrike sistema A: */
  zeromat0(cs->n-2,cs->n-2,&cs->dA);
  if (i<=cs->n-2)
    cs->dA->m[i][i]=2*P2(c_d(i));
  if (i>=2 && i<=cs->n-1)
    cs->dA->m[i-1][i-1]=2*(P2(c_d(i))-P2(c_d(i-1)));
  if (i>=3 && i<=cs->n)
    cs->dA->m[i-2][i-2]=-2*P2(c_d(i-1));
  if (i>=2 && i<=cs->n-2)
    cs->dA->m[i][i-1]=P2(c_d(i));
  if (i>=3 && i<=cs->n-1)
    cs->dA->m[i-1][i-2]=-P2(c_d(i-1));
  if (i>=2 && i<=cs->n-2)
    cs->dA->m[i-1][i]=P2(c_d(i));
  if (i>=3 && i<=cs->n-1)
    cs->dA->m[i-2][i-1]=-P2(c_d(i-1));
  /* Sedaj izracunamo produkt odvoda matrike A in vektorja u; Ce vektor u se
  ne obstaja, ga izracunamo. Produkt shranemo v cs->du, ki ga tvorimo na novo
  in ga bomo pozneje dali na sklad:  */
  cubsplcalcu(cs);
  cs->du=NULL;
  matprodvec0(cs->dA,cs->u,&(cs->du));
  /* Od vektorja cs->db odstejemo ta produkt, tako vektor b postane vektor desnih
  strani: */
  vecdif0(cs->db,cs->du,&cs->db);
  /* Ce je se nismo, izracunamo LU dekompozicijo matrike sistema: */
  cubsplcalcAdec(cs);
  /* Resimo sistem za odvod vektorja u po i. abscisi tocke in resitev postavimo
  na ustrezno mesto: */
  solvLU0(cs->Adec,cs->Adec,cs->Aind,cs->db,(vector *) &cs->du);
  cs->dudx->s[i]=cs->du; cs->du=NULL;
  if (repspl && !cs->rep)  /* $$ */
  {
    vector u,urev;
    int j;
    cubsplprepreverse(cs);
    cubsplcalcdudx(cs->reverse,cs->dudx->n-i+1);
    u=cs->dudx->s[i];  urev=cs->reverse->dudx->s[cs->dudx->n-i+1];
    for (j=1;j<=u->d/2;++j)
      u->v[j]=urev->v[u->d-j+1];
  }
}
}



static int cubsplgetseg(cubspldata cs,double x)
    /* Vrne indeks segmenta kubicnega zlepka cs, v katerem je tocka z absciso
    x. Funkcija ne preverja, ce je zlepek pravilno definiran.
    $A Igor avg01; */
{
int i=2;
while(i<cs->n && x>c_x(i))
  ++i;
return (i-1);
}



/* KONCNE FUNKCIJE ZA RACUNANJE KUBICNIH ZLEPKOV IN ODVODOV PO PARAMETRIH: */


double cubsplval(cubspldata cs,double x)
    /* Izracuna vrednost kubicnega zlepka cs v tocki x. Podatki na cs, ki
    dolocajo zlepek, so morali biti nastavljeni pred klicem te funkcije npr.
    s funkcijo setcubspline().
    Funkcija samodejno izracuna vmesne rezultete, ki se niso bili izracunani,
    in uporabi tiste, ki so bili.
    $A Igor avg01; */
{
int j;
double ret=0;
if (cs->n>=2)
{
  /* Ce tega se nismo naredili, resimo sistem enacb za odvode v notranjih
  vozlih: */
  cubsplcalcu(cs);
  /* Potem dobimo indeks segmenta, v katerem je x: */
  j=cubsplgetseg(cs,x);
  /* Izracunamo vrednost ustrez. kubicnega polinoma, najprej clene, ki ne
  vsebujejo odvodov v vozliscih: */
  ret=c_y(j)*P2(c_d(j))*P2(x-c_x(j+1))*(1+2*c_d(j)*(x-c_x(j)))
     +c_y(j+1)*P2(c_d(j))*P2(x-c_x(j))*(1-2*c_d(j)*(x-c_x(j+1)));
  /* Spodaj upostevamo, da so k-ji (tj. odvodi) za vmesne tocke spravljeni v
  izracunanem vektorju u in da so indeksi pri komponentah u za eno manjsi od
  indeksov k-jev. Upostevamo tudi, da sta odvoda v robnih vozlih vhodna podatka
  in ne izracunana ter ju dobimo v lokalnih cs->k1 in cs->kn. */
  if (j==1)
    ret+=cs->k1*P2(c_d(j))*(x-c_x(j))*P2(x-c_x(j+1));
  else
    ret+=c_u(j-1)*P2(c_d(j))*(x-c_x(j))*P2(x-c_x(j+1));
  if (j==cs->n-1)
    ret+=cs->kn*P2(c_d(j))*P2(x-c_x(j))*(x-c_x(j+1));
  else
    ret+=c_u(j)*P2(c_d(j))*P2(x-c_x(j))*(x-c_x(j+1));
}
return ret;
}


double cubsplsensy(cubspldata cs,int i,double x)
    /* Vrne odvod vrednost kubicnega zlepka cs v tocki x po ordinati i-tega
    vozlisca, ki doloca zlepek. Podatki, ki dolocajokubicni zlepek, so morali
    biti nastavljeni pred klicem te funkcije npr. s funkcijo setcubspline().
    Funkcija samodejno izracuna vmesne rezultete, ki se niso bili izracunani,
    in uporabi tiste, ki so bili.
    $A Igor avg01; */
{
int j;
double ret=0;
if (i<1 || i>cs->n)
{
  errfunc0("cubsplsensy");
  fprintf(erf(),"Sensitivity index (i.e. node number) out of range (%i, should be from 1 to %i).\n",
   i,cs->n);
  errfunc2();
} else if (cs->n>=2)
{
  /* Ce tega se nismo naredili, resimo sistem enacb za odvode v notranjih
  vozlih: */
  cubsplcalcu(cs);
  /* Potem dobimo indeks segmenta, v katerem je x: */
  j=cubsplgetseg(cs,x);
  /* Ce tega se nismo naredili, izracunamo odvod vektorja u (tj. vektorja
  izracunanih odvodov zlepka v notranjih vozliscih) po ordinati i. vozlisca: */
  cubsplcalcdudy(cs,i);
  if (cs->dudy!=NULL)
    if (cs->dudy->n>=i)
    {
      /* Vektor cs->du postavimo na ta vektor, da bomo lahko uporabljali
      ustrezen makro za dostop do komponent, t.j. c_du: */
      cs->du=cs->dudy->s[i];
      /* Koncno lahko izracunamo odvod. Najprej poracunamo eksplicitne clene: */
      if (i==j)
        ret=P2(c_d(j))*P2(x-c_x(j+1))*(1+2*c_d(j)*(x-c_x(j)));
      else if (i==j+1)
        ret=P2(c_d(j))*P2(x-c_x(j))*(1-2*c_d(j)*(x-c_x(j+1)));
      /* Dodamo implicitne clene, ki vsebujejo odvode odvodov v vozlih;
      upostevamo, da so indeksi pri komponentah u za eno manjsi kot tisti pri
      komponentah k: */
      if (j>1)
        ret+=c_du(j-1)*P2(c_d(j))*(x-c_x(j))*P2(x-c_x(j+1));
      if (j<cs->n-1)
        ret+=c_du(j)*P2(c_d(j))*P2(x-c_x(j))*(x-c_x(j+1));
  }
}
return ret;
}


double cubsplsensk1(cubspldata cs,double x)
    /* Vrne odvod vrednost kubicnega zlepka cs v tocki x po predpisanem odvodu
    v prvem vozliscu k1. Podatki, ki dolocajo kubicni zlepek, so morali biti
    nastavljeni pred klicem te funkcije npr. s funkcijo setcubspline().
    Funkcija samodejno izracuna vmesne rezultete, ki se niso bili izracunani,
    in uporabi tiste, ki so bili.
    $A Igor avg01; */
{
int j;
double ret=0;
if (cs->n<2)
{
  errfunc0("cubsplsensk1");
  fprintf(erf(),"Spline nodes not defined properly.\n");
  errfunc2();
} else if (cs->n>=2)
{
  /* Ce tega se nismo naredili, resimo sistem enacb za odvode v notranjih
  vozlih: */
  cubsplcalcu(cs);
  /* Potem dobimo indeks segmenta, v katerem je x: */
  j=cubsplgetseg(cs,x);
  /* Ce tega se nismo naredili, izracunamo odvod vektorja u (tj. vektorja
  izracunanih odvodov zlepka v notranjih vozliscih) po k1: */
  cubsplcalcdudk1(cs);
  if (cs->dudk1!=NULL)
  {
    /* Vektor cs->du postavimo na ta vektor, da bomo lahko uporabljali
    ustrezen makro za dostop do komponent, t.j. c_du: */
    cs->du=cs->dudk1;
    /* Koncno lahko izracunamo odvod. Najprej poracunamo eksplicitne clene: */
    if (j==1)
      ret=P2(c_d(1))*(x-c_x(1))*P2(x-c_x(2));
    /* Dodamo implicitne clene, ki vsebujejo odvode odvodov v vozlih po k1;
    upostevamo, da so indeksi pri komponentah u za eno manjsi kot tisti pri
    komponentah k: */
    if (j>1)
      ret+=c_du(j-1)*P2(c_d(j))*(x-c_x(j))*P2(x-c_x(j+1));
    if (j<cs->n-1)
      ret+=c_du(j)*P2(c_d(j))*P2(x-c_x(j))*(x-c_x(j+1));
  }
}
return ret;
}


double cubsplsenskn(cubspldata cs,double x)
    /* Vrne odvod vrednost kubicnega zlepka cs v tocki x po predpisanem odvodu
    v zadnjem vozliscu kn. Podatki, ki dolocajo kubicni zlepek, so morali biti
    nastavljeni pred klicem te funkcije npr. s funkcijo setcubspline().
    Funkcija samodejno izracuna vmesne rezultete, ki se niso bili izracunani,
    in uporabi tiste, ki so bili.
    $A Igor avg01; */
{
int j;
double ret=0;
if (cs->n<2)
{
  errfunc0("cubsplsenskn");
  fprintf(erf(),"Spline nodes not defined properly.\n");
  errfunc2();
} else if (cs->n>=2)
{
  /* Ce tega se nismo naredili, resimo sistem enacb za odvode v notranjih
  vozlih: */
  cubsplcalcu(cs);
  /* Potem dobimo indeks segmenta, v katerem je x: */
  j=cubsplgetseg(cs,x);
  /* Ce tega se nismo naredili, izracunamo odvod vektorja u (tj. vektorja
  izracunanih odvodov zlepka v notranjih vozliscih) po kn: */
  cubsplcalcdudkn(cs);
  if (cs->dudkn!=NULL)
  {
    /* Vektor cs->du postavimo na ta vektor, da bomo lahko uporabljali
    ustrezen makro za dostop do komponent, t.j. c_du: */
    cs->du=cs->dudkn;
    /* Koncno lahko izracunamo odvod. Najprej poracunamo eksplicitne clene: */
    if (j==cs->n-1)
      ret=P2(c_d(cs->n-1))*P2(x-c_x(cs->n-1))*(x-c_x(cs->n));
    /* Dodamo implicitne clene, ki vsebujejo odvode odvodov v vozlih po kn;
    upostevamo, da so indeksi pri komponentah u za eno manjsi kot tisti pri
    komponentah k: */
    if (j>1)
      ret+=c_du(j-1)*P2(c_d(j))*(x-c_x(j))*P2(x-c_x(j+1));
    if (j<cs->n-1)
      ret+=c_du(j)*P2(c_d(j))*P2(x-c_x(j))*(x-c_x(j+1));
  }
}
return ret;
}



double cubsplsensx(cubspldata cs,int i,double x)
    /* Vrne odvod vrednost kubicnega zlepka cs v tocki x po abscisi i-tega
    vozlisca, ki doloca zlepek. Podatki, ki dolocajokubicni zlepek, so morali
    biti nastavljeni pred klicem te funkcije npr. s funkcijo setcubspline().
    Funkcija samodejno izracuna vmesne rezultete, ki se niso bili izracunani,
    in uporabi tiste, ki so bili.
    $A Igor avg01; */
{
int j;
double ret=0;
if (i<1 || i>cs->n)
{
  errfunc0("cubsplsensx");
  fprintf(erf(),"Sensitivity index (i.e. node number) out of range (%i, should be from 1 to %i).\n",
   i,cs->n);
  errfunc2();
} else if (cs->n>=2)
{
  /* Ce tega se nismo naredili, resimo sistem enacb za odvode v notranjih
  vozlih: */
  cubsplcalcu(cs);
  /* Potem dobimo indeks segmenta, v katerem je x: */
  j=cubsplgetseg(cs,x);
  /* Ce tega se nismo naredili, izracunamo odvod vektorja u (tj. vektorja
  izracunanih odvodov zlepka v notranjih vozliscih) po ordinati i. vozlisca: */
  cubsplcalcdudx(cs,i);
  if (cs->dudx!=NULL)
    if (cs->dudx->n>=i)
    {
      /* Vektor cs->du postavimo na ta vektor, da bomo lahko uporabljali
      ustrezen makro za dostop do komponent, t.j. c_du: */
      cs->du=cs->dudx->s[i];
      /* Koncno lahko izracunamo odvod. Najprej poracunamo eksplicitne clene: */
      
      if (i==j)
      {
        ret=2*c_y(j)*P3(c_d(j))*P2(x-c_x(j+1))*(1+2*c_d(j)*(x-c_x(j)))
          +c_y(j)*P2(c_d(j))*P2(x-c_x(j+1))*(2*P2(c_d(j))*(x-c_x(j))-2*c_d(j))
          +2*c_y(j+1)*P3(c_d(j))*P2(x-c_x(j))*(1-2*c_d(j)*(x-c_x(j+1)))
          -2*c_y(j+1)*P2(c_d(j))*(x-c_x(j))*(1-2*c_d(j)*(x-c_x(j+1)))
          +c_y(j+1)*P2(c_d(j))*P2(x-c_x(j))*(-2*P2(c_d(j))*(x-c_x(j+1)));
        /* Posebej poracunamo tiste clene, kjer nastopajo k-ji, saj sta dva
        od teh vhodna podatka, ostale pa hranimo v vektorju cs->u: */
        if (j==1)
          ret+=cs->k1* ( 2*P3(c_d(j))*(x-c_x(j))*P2(x-c_x(j+1))
                         -P2(c_d(j))*P2(x-c_x(j+1)) );
        else
          ret+=c_u(j-1)* ( 2*P3(c_d(j))*(x-c_x(j))*P2(x-c_x(j+1))
                            -P2(c_d(j))*P2(x-c_x(j+1)) );
        if (j==cs->n-1)
          ret+=2*cs->kn* ( P3(c_d(j))*P2(x-c_x(j))*(x-c_x(j+1))
                         -P2(c_d(j))*(x-c_x(j))*(x-c_x(j+1)) );
        else
          ret+=2*c_u(j)* ( P3(c_d(j))*P2(x-c_x(j))*(x-c_x(j+1))
                          -P2(c_d(j))*(x-c_x(j))*(x-c_x(j+1)) );
        
        
      } else if (i==j+1)
      {
        ret=-2*c_y(j) * P3(c_d(j))* P2(x-c_x(j+1)) * ( 1+2*c_d(j)*(x-c_x(j)) )
          -2*c_y(j) * P2(c_d(j)) * (x-c_x(j+1)) * ( 1+2*c_d(j)*(x-c_x(j)) )
          +c_y(j) * P2(c_d(j))*P2(x-c_x(j+1)) * ( -2*P2(c_d(j))*(x-c_x(j)) )
          -2*c_y(j+1) * P3(c_d(j)) * P2(x-c_x(j)) * ( 1-2*c_d(j)*(x-c_x(j+1)) )
          +c_y(j+1)*P2(c_d(j))*P2(x-c_x(j))* (2*P2(c_d(j))*(x-c_x(j+1))+2*c_d(j));
          
        if (j==1)
          ret-=2*cs->k1* ( P3(c_d(j))*(x-c_x(j))*P2(x-c_x(j+1))
                         +P2(c_d(j))*(x-c_x(j))*(x-c_x(j+1)) );
        else
          ret-=2*c_u(j-1)* ( P3(c_d(j))*(x-c_x(j))*P2(x-c_x(j+1))
                            +P2(c_d(j))*(x-c_x(j))*(x-c_x(j+1)) );
        if (j==cs->n-1)
          ret-=cs->kn*( 2*P3(c_d(j))*P2(x-c_x(j))*(x-c_x(j+1))
                        +P2(c_d(j))*P2(x-c_x(j)) );
        else
          ret-=c_u(j)*( 2*P3(c_d(j))*P2(x-c_x(j))*(x-c_x(j+1))
                         +P2(c_d(j))*P2(x-c_x(j)) );
      }
      /* Dodamo implicitne clene, ki vsebujejo odvode odvodov v vozlih;
      upostevamo, da so indeksi pri komponentah u za eno manjsi kot tisti
      pri komponentah k: */
      if (j>1)
        ret+=c_du(j-1)*P2(c_d(j))*(x-c_x(j))*P2(x-c_x(j+1));
      if (j<cs->n-1)
        ret+=c_du(j)*P2(c_d(j))*P2(x-c_x(j))*(x-c_x(j+1));
  }
}
return ret;
}




/* FUNKCIJE ZA SPROZEN IZRACUN DOLOCENIH VMESNIH VREDNOSTI: */


void prepcubsplval(cubspldata cs)
    /* Pripravi vse potrebno za racunanje vrednosti kubicnega zlepka cs. To se
    sicer samodejno naredi, ko prvic klicemo funkcijo za izracun vrednosti,
    vendar hocemo vcasih to narediti eksplicitno, ker lahko tako takoj po
    pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplintvar()
    in tako prihranimo prostor.
    $A Igor avg01; */
{
cubsplcalcu(cs);
}

void prepcubsplsensy(cubspldata cs,int i)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka cs
    po ordinati i-tega vozlisca. To se sicer samodejno naredi, ko prvic klicemo
    funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to narediti
    eksplicitno, ker lahko tako takoj po pripravi za racunanje vrednosti in
    senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse vmesne rezultate
    s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */
{
cubsplcalcu(cs);
cubsplcalcdudy(cs,i);
}

void prepcubsplsensyall(cubspldata cs)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka cs
    po ordinati kateregakoli vozlisca. To se sicer samodejno naredi, ko prvic
    klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to
    narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */
{
int i;
cubsplcalcu(cs);
for (i=1;i<=cs->n;++i)
  cubsplcalcdudy(cs,i);
}

void prepcubsplsensk1(cubspldata cs)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka po
    predpisanem odvodu v prvem vozliscu. To se sicer samodejno naredi, ko prvic
    klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to
    narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */
{
cubsplcalcu(cs);
cubsplcalcdudk1(cs);
}

void prepcubsplsenskn(cubspldata cs)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka cs
    po predpisanem odvodu v zadnjem vozliscu. To se sicer samodejno naredi, ko
    prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to
    narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */
{
cubsplcalcu(cs);
cubsplcalcdudkn(cs);
}


void prepcubsplsensx(cubspldata cs,int i)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka cs
    po abscisi i-tega vozlisca. To se sicer samodejno naredi, ko prvic klicemo
    funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to narediti
    eksplicitno, ker lahko tako takoj po pripravi za racunanje vrednosti in
    senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse vmesne rezultate
    s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */
{
cubsplcalcu(cs);
cubsplcalcdudx(cs,i);
}

void prepcubsplsensxall(cubspldata cs)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka
    po abscisi kateregakoli vozlisca. To se sicer samodejno naredi, ko prvic
    klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih to
    narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvar() in tako prihranimo prostor.
    $A Igor avg01; */
{
int i;
cubsplcalcu(cs);
for (i=1;i<=cs->n;++i)
  cubsplcalcdudx(cs,i);
}



#undef P2
#undef P3
#undef c_d
#undef c_x
#undef c_y
#undef c_u
#undef c_dA
#undef c_db
#undef c_du





    /* SISTEM KUBICNIH ZLEPKOV, DO KATERIH DOSTOPAMO Z ID. STEVILKAMI: */


/* OPIS SISTEMA: 
Do kubicnih zlepkov na skladu cubsplsys dostopamo preko njihovih
identifikacijskih stevilk, ki so zaporedne stevilke zlepkov na tem skladu. Na
skladu so zlepki nalozeni kot kazalci tipa cubspldata. Funkcije sistema, ki
tvorijo nov kubicni zlepek, zato vedno vrnejo njegovo identifikacijsko stevilko,
ki jo doloci sam sistem. Prav tako moramo v funkcijah, ki izvajajo kalkulacije
s kubicnim zlepkom, navesti identifikacijsko stevilko. Eden od zlepkov je
priviligiran ("globalni"), to je tisti z identifikacijsko stevilko globcubsplid.
Po dogovoru vse funkcije delujejo tako, da se identifikacijska stevilka 0 vedno
razume kot globcubsplid, torej identifikacijska stevilka globalnega kubicnega
zlepka.
OPOZORILO ZA PROGRAMIRANJE:
Ce je dolocen element NULL, se smatra, da ustrezen kubicni zlepek ne obstaja
in je ustrezna identifikacijska stevilka prosta, torej se lahko zasede pri
klicih funkcij, ki naredijo nov zlepek.
*/


/* Sklad za kubicne zlepke, ki jih dostopamo preko identifikacijskih stevilk: */
static stack cubsplsys=NULL;
/* Identifikacijska stevilka zlepka za globalne funkcije, ki se nanasajo na
specificni kubicni zlepek: */
static int globcubsplid=0;


/* POMOZNE FUNKCIJE: */

static cubspldata getcubspl(int id)
    /* Vrne kazalec na podatkovno strukturo kubicnega zlepka z identifikacijsko
    stevilko id oz. NULL, ce ta ne obstaja.
    $A Igor avg01; */
{
if (cubsplsys==NULL)
  return NULL;
else if (id>cubsplsys->n)
  return NULL;
else
{
  if (id<1)
    id=globcubsplid;
  if (id<1 || id>cubsplsys->n)
    return NULL;
  else
    return (cubspldata) cubsplsys->s[id];
}
}

static cubspldata *getcubspladdr(int id)
    /* Vrne naslov kazalca na podatkovno strukturo kubicnega zlepka z
    identifikacijsko stevilko id oz. NULL, ce ta ne obstaja.
    $A Igor avg01; */
{
if (cubsplsys==NULL)
  return NULL;
else if (id>cubsplsys->n)
  return NULL;
else
{
  if (id<1)
    id=globcubsplid;
  if (id<1 || id>cubsplsys->n)
    return NULL;
  else
    return (cubspldata *) &(cubsplsys->s[id]);
}
}

static int newcubspl(void)
    /* Instalira nov kubicni zlepek v sistem kubicnih zlepkov in vrne njegovo
    identifikacijsko stevilko.
    $A Igor avg01; */
{
int i,id=0;
if (cubsplsys==NULL)
  cubsplsys=newstack(5);
for (i=1;i<=cubsplsys->n && !id;++i)
  if (cubsplsys->s[i]==NULL)
  {
    id=i;
    cubsplsys->s[i]=(void *) newcubspldata();
  }
if (!id)
{
  pushstack(cubsplsys,(void *) newcubspldata());
  id=cubsplsys->n;
}
return id;
}


void fprintcubsplsysdata(FILE *fp,int id)
    /* V datoteko fp izpise podatke o sistemu kubicnih zlepkov, na katere se
    sklicjemo s pomocjo identifikacijskih stevilk, ce je id manj od 0. Ce je id
    0, se izpisejo le podatki o globalnem kubicnem zlepku, ce pa je id vec od 0,
    se izpisejo le podatki o kubicnem zlepku z ident. st. id.
    $A Igor sep01; */
{
int i,n=0;
cubspldata cs;
if (id==0)
{
  if ((cs=getcubspl(id))==NULL)
    fprintf(fp,"\n\nGlobal cubic spline is not defined.\n\n");
  else
  {
    fprintf(fp,"\n\nGlobal cubic spline (current identification number %i):\n",globcubsplid);
    fprintcubsplstate(fp,cs);
    fprintf(fp,"\n\n");
  }
} else if (id>0)
{
  if ((cs=getcubspl(id))==NULL)
    fprintf(fp,"\n\nCubic spline No. %i is not defined.\n\n",id);
  else
  {
    fprintf(fp,"\n\nCbic spline No. %i:\n",id);
    fprintcubsplstate(fp,cs);
    fprintf(fp,"\n\n");
  }

} else /* id<0 */
{
fprintf(fp,"\n\nInformation about defined cubic splines:\n");
if (cubsplsys==NULL)
  fprintf(fp,"No splines defined.\n");
else if (cubsplsys->n==0)
  fprintf(fp,"No splines defined.\n");
else
{
  for (i=1;i<=cubsplsys->n;++i)
    if (cubsplsys->s[i]!=NULL)
      ++n;
  if (n==0)
    fprintf(fp,"No splines defined.\n");
  else
  {
    if (globcubsplid>0 && cubsplsys->n>=globcubsplid)
      fprintf(fp,"\nIdentification number of global spline is %i.\n",globcubsplid);
    else
      fprintf(fp,"\nThe global spline is not defined.\n");
    for (i=1;i<=cubsplsys->n;++i)
      if ((cs=cubsplsys->s[i])!=NULL)
      {
        if (i==globcubsplid)
          fprintf(fp,"\nSpline No. %i (the global spline):\n",i);
        else
          fprintf(fp,"\nSpline No. %i:\n",i);
        fprintcubsplstate(fp,cs);
      }
  }
}
fprintf(fp,"\n\n");
}
}

void printcubsplsysdata(int id)
    /* Na stand. izhod izpise podatke o sistemu kubicnih zlepkov, na katere se
    sklicjemo s pomocjo identifikacijskih stevilk. Ce je id 0, se izpisejo le
    podatki o globalnem kubicnem zlepku, ce pa je id vec od 0, se izpisejo le
    podatki o kubicnem zlepku z ident. st. id.
    $A Igor sep01; */
{
fprintcubsplsysdata(stdout,id);
}


  /* FUNKCIJE ZA DEFINICIJO KUBICNIH ZLEPKOV SISTEMA: */


int setnewcubspl(vector x,vector y,double k1,double kn)
    /* V sistemu kubicnih zlepkov definira nov kubicni zlepek z vektorjema
    abscis in ordinat kontrolnih tock x in y ter z robnima odvodoma k1 in kn.
    $A Igor avg01; */
{
int id;
cubspldata *pcs;
id=newcubspl();
pcs=getcubspladdr(id);
setcubspl(pcs,x,y,k1,kn);
return id;
}

void setcubsplid(int id,vector x,vector y,double k1,double kn)
    /* Kubicni zlepek z identifikacijsko stevilko id definira na novo s podatki
    x, y, k1 in kn. Ce ta zlepek ne obstaja, ga naredi, ce le id ni prevelik
    glede na najvisko obstojeco ident. stevilko v sistemu.
    $A Igor avg01; */
{
cubspldata *pcs;
if (cubsplsys==NULL)
  cubsplsys=newstack(5);
if ((pcs=getcubspladdr(id))==NULL)
{
  if (id<1)  /* Ukaz se nanasa na globalni kubicni zlepek */
    id=globcubsplid=newcubspl();
  else
  {
    if (id-cubsplsys->n>500)
    {
      errfunc0("setnewcubsplid");
      fprintf(erf(),"PANIC!\nCubic spline id (%i) is much greater than maximum currently existent id (%i).\n",
       id,cubsplsys->n);
      fprintf(erf(),"This can cause unpredicted program behavior.\n");
      errfunc2();
    }
    if (id-cubsplsys->n<20000)
      while(id>cubsplsys->n)
        pushstack(cubsplsys,NULL);
  }
  pcs=getcubspladdr(id);
}
if (pcs==NULL)
{
  errfunc0("setnewcubsplid");
  fprintf(erf(),"Unable to access or define cubic spline with id %i (probably too great).\n",
   id);
  fprintf(erf(),"All calculations of this spline will be invalid.\n");
  errfunc2();
} else
  setcubspl(pcs,x,y,k1,kn);
}

int setcubsplglob(vector x,vector y,double k1,double kn)
    /* Definira globalni zlepek z vektorjema abscis in ordinat x in y ter
    robnima odvodoma k1 in kn. Funkcija vrne identifikacijsko stevilko
    globalnega zlepka.
    $A Igor avg01; */
{
cubspldata *pcs;
if ((pcs=getcubspladdr(0))==NULL)
{
  globcubsplid=newcubspl();
  pcs=getcubspladdr(0);
}
setcubspl(pcs,x,y,k1,kn);
return globcubsplid;
}


/* DIREKTNA DEFINICIJA BREZ KOPIRANJA VEKTOREV: */

static int setnewcubspldir(vector x,vector y,double k1,double kn)
    /* V sistemu kubicnih zlepkov definira nov kubicni zlepek z vektorjema
    abscis in ordinat kontrolnih tock x in y ter z robnima odvodoma k1 in kn.
    Funkcija spravi na podatke o zlepku direktno vektorja x in y in ne njunih
    kopij, tako da po izvedbi funkcije vektorjev x in y, s katerima smo klicali
    funkcijo, ne smemo eksplicitno brisati.
    $A Igor avg01; */
{
int id;
cubspldata *pcs;
id=newcubspl();
pcs=getcubspladdr(id);
setcubspldir(pcs,x,y,k1,kn);
}

void setcubspldirid(int id,vector x,vector y,double k1,double kn)
    /* Kubicni zlepek z identifikacijsko stevilko id definira na novo s podatki
    x, y, k1 in kn. Ce ta zlepek ne obstaja, ga naredi, ce le id ni prevelik
    glede na najvisko obstojeco ident. stevilko v sistemu.
    Funkcija spravi na podatke o zlepku direktno vektorja x in y in ne njunih
    kopij, tako da po izvedbi funkcije vektorjev x in y, s katerima smo klicali
    funkcijo, ne smemo eksplicitno brisati.
    $A Igor avg01; */
{
cubspldata *pcs;
if (cubsplsys==NULL)
  cubsplsys=newstack(5);
if ((pcs=getcubspladdr(id))==NULL)
{
  if (id<1)  /* Ukaz se nanasa na globalni kubicni zlepek */
    id=globcubsplid=newcubspl();
  else
  {
    if (id-cubsplsys->n>500)
    {
      errfunc0("setnewcubsplid");
      fprintf(erf(),"PANIC!\nCubic spline id (%i) is much greater than maximum currently existent id (%i).\n",
       id,cubsplsys->n);
      fprintf(erf(),"This can cause unpredicted program behavior.\n");
      errfunc2();
    }
    if (id-cubsplsys->n<20000)
      while(id>cubsplsys->n)
        pushstack(cubsplsys,NULL);
  }
  pcs=getcubspladdr(0);
}
if (pcs==NULL)
{
  errfunc0("setnewcubsplid");
  fprintf(erf(),"Unable to access or define cubic spline with id %i (probably too great).\n",
   id);
  fprintf(erf(),"All calculations of this spline will be invalid.\n");
  errfunc2();
} else
  setcubspldir(pcs,x,y,k1,kn);
}

int setcubsplglobdir(vector x,vector y,double k1,double kn)
    /* Definira globalni zlepek z vektorjema abscis in ordinat x in y ter
    robnima odvodoma k1 in kn. Funkcija vrne identifikacijsko stevilko
    globalnega zlepka.
    Funkcija spravi na podatke o zlepku direktno vektorja x in y in ne njunih
    kopij, tako da po izvedbi funkcije vektorjev x in y, s katerima smo klicali
    funkcijo, ne smemo eksplicitno brisati.
    $A Igor avg01; */
{
cubspldata *pcs;
if ((pcs=getcubspladdr(0))==NULL)
{
  globcubsplid=newcubspl();
  pcs=getcubspladdr(0);
}
setcubspldir(pcs,x,y,k1,kn);
return globcubsplid;
}



    /* RACUNANJE Z ZLEPKI, NA KATERE SE SKLICUJEMO Z IDENTIFIKACIJSKIMI
    STEVILKAMI, IN Z GLOBALNIM ZLEPKOM: */


double cubsplvalid(int id,double x)
    /* Izracuna vrednost kubicnega zlepka z identifikac. st. id v tocki x.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("cubsplvalid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
  return 0;
} else
  return cubsplval(cs,x);
}

double cubsplglobval(double x)
    /* Izracuna vrednost globalnega kubicnega zlepka v tocki x.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("cubsplglobval");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
  return 0;
} else
  return cubsplval(cs,x);
}


double cubsplsensyid(int id,int i,double x)
    /* Vrne odvod vrednost kubicnega zlepka z id. st. id v tocki x po ordinati
    i-tega vozlisca, ki doloca zlepek.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("cubsplsensyid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
  return 0;
} else
  return cubsplsensy(cs,i,x);
}

double cubsplglobsensy(int i,double x)
    /* Vrne odvod vrednost globalnega kubicnega zlepka v tocki x po ordinati
    i-tega vozlisca, ki doloca zlepek.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("cubsplglobsensy");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
  return 0;
} else
  return cubsplsensy(cs,i,x);
}


double cubsplsensk1id(int id,double x)
    /* Vrne odvod vrednost kubicnega zlepka z id. st. id v tocki x po
    predpisanem odvodu v prvem vozliscu.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("cubsplsensk1id");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
  return 0;
} else
  return cubsplsensk1(cs,x);
}

double cubsplglobsensk1(double x)
    /* Vrne odvod vrednost globalnega kubicnega zlepka v tocki x po predpisanem
    odvodu v prvem vozliscu.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("cubsplglobsensk1");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
  return 0;
} else
  return cubsplsensk1(cs,x);
}


double cubsplsensknid(int id,double x)
    /* Vrne odvod vrednost kubicnega zlepka z id. st. id v tocki x po
    predpisanem odvodu v zadnjem vozliscu.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("cubsplsensknid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
  return 0;
} else
  return cubsplsenskn(cs,x);
}

double cubsplglobsenskn(double x)
    /* Vrne odvod vrednost globalnega kubicnega zlepka v tocki x po predpisanem
    odvodu v zadnjem vozliscu.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("cubsplglobsenskn");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
  return 0;
} else
  return cubsplsenskn(cs,x);
}


double cubsplsensxid(int id,int i,double x)
    /* Vrne odvod vrednost kubicnega zlepka z id. st. id v tocki x po abscisi
    i-tega vozlisca, ki doloca zlepek.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("cubsplsensxid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
  return 0;
} else
  return cubsplsensx(cs,i,x);
}

double cubsplglobsensx(int i,double x)
    /* Vrne odvod vrednost globalnega kubicnega zlepka v tocki x po abscisi
    i-tega vozlisca, ki doloca zlepek.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("cubsplglobsensx");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
  return 0;
} else
  return cubsplsensx(cs,i,x);
}



/* SPROZENA PRIPRAVA VMESNIH REZULTATOV: */


void prepcubsplvalid(int id)
    /* Pripravi vse potrebno za racunanje vrednosti kubicnega zlepka st. id.
    To se sicer samodejno naredi, ko prvic klicemo funkcijo za izracun
    vrednosti, vendar hocemo vcasih to narediti eksplicitno, ker lahko tako
    takoj po pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplintvarid()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("prepcubsplvalid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  prepcubsplval(cs);
}

void prepcubsplglobval(void)
    /* Pripravi vse potrebno za racunanje vrednosti globalnega kubicnega zlepka.
    To se sicer samodejno naredi, ko prvic klicemo funkcijo za izracun
    vrednosti, vendar hocemo vcasih to narediti eksplicitno, ker lahko tako
    takoj po pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplglobintvar()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("prepcubsplglobval");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  prepcubsplval(cs);
}


void prepcubsplsensyid(int id,int i)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po ordinati i-tega vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvarid() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("prepcubsplsensyid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  prepcubsplsensy(cs,i);
}

void prepcubsplglobsensy(int i)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po ordinati i-tega vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("prepcubsplglobsensy");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  prepcubsplsensy(cs,i);
}


void prepcubsplsensyallid(int id)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka z
    id. st. id po ordinati kateregakoli vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("prepcubsplsensyallid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  prepcubsplsensyall(cs);
}

void prepcubsplglobsensyall(void)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po ordinati kateregakoli vozlisca. To se sicer samodejno
    naredi, ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo
    vcasih to narediti eksplicitno, ker lahko tako takoj po pripravi za
    racunanje vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo
    vse vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("prepcubsplglobsensyall");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  prepcubsplsensyall(cs);
}


void prepcubsplsensk1id(int id)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka z
    idendifikacijsko st. id po predpisanem odvodu v prvem vozliscu. To se sicer
    samodejno naredi, ko prvic klicemo funkcijo za izracun taksnega odvoda,
    vendar hocemo vcasih to narediti eksplicitno, ker lahko tako takoj po
    pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplintvarid()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("prepcubsplsensk1id");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  prepcubsplsensk1(cs);
}

void prepcubsplglobsensk1(void)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po predpisanem odvodu v prvem vozliscu. To se sicer
    samodejno naredi, ko prvic klicemo funkcijo za izracun taksnega odvoda,
    vendar hocemo vcasih to narediti eksplicitno, ker lahko tako takoj po
    pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplglobintvar()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("prepcubsplglobsensk1");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  prepcubsplsensk1(cs);
}


void prepcubsplsensknid(int id)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka z
    idendifikacijsko st. id po predpisanem odvodu v zadnjem vozliscu. To se
    sicer samodejno naredi, ko prvic klicemo funkcijo za izracun taksnega
    odvoda, vendar hocemo vcasih to narediti eksplicitno, ker lahko tako takoj
    po pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplintvarid()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("prepcubsplsensknid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  prepcubsplsenskn(cs);
}

void prepcubsplglobsenskn(void)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po predpisanem odvodu v zadnjem vozliscu. To se sicer
    samodejno naredi, ko prvic klicemo funkcijo za izracun taksnega odvoda,
    vendar hocemo vcasih to narediti eksplicitno, ker lahko tako takoj po
    pripravi za racunanje vrednosti in senzitivnosti, ki bi jih lahko
    potrebovali, zbrisemo vse vmesne rezultate s funkcijo remcubsplglobintvar()
    in tako prihranimo prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("prepcubsplglobsenskn");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  prepcubsplsenskn(cs);
}


void prepcubsplsensxid(int id,int i)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po abscisi i-tega vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplintvarid() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("prepcubsplsensxid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  prepcubsplsensx(cs,i);
}

void prepcubsplglobsensx(int i)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po abscisi i-tega vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("prepcubsplglobsensx");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  prepcubsplsensx(cs,i);
}


void prepcubsplsensxallid(int id)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti kubicnega zlepka z
    id. st. id po abscisi kateregakoli vozlisca. To se sicer samodejno naredi,
    ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo vcasih
    to narediti eksplicitno, ker lahko tako takoj po pripravi za racunanje
    vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo vse
    vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("prepcubsplsensxallid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  prepcubsplsensxall(cs);
}

void prepcubsplglobsensxall(void)
    /* Pripravi vse potrebno za racunanje odvodov vrednosti globalnega
    kubicnega zlepka po abscisi kateregakoli vozlisca. To se sicer samodejno
    naredi, ko prvic klicemo funkcijo za izracun taksnega odvoda, vendar hocemo
    vcasih to narediti eksplicitno, ker lahko tako takoj po pripravi za
    racunanje vrednosti in senzitivnosti, ki bi jih lahko potrebovali, zbrisemo
    vse vmesne rezultate s funkcijo remcubsplglobintvar() in tako prihranimo
    prostor.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("prepcubsplglobsensxall");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  prepcubsplsensxall(cs);
}



/* BRISANJE DEFINICIJ: */


void dispcubsplid(int id)
    /* Zbrise definicijo kub. zlepka z identifikacijo id; po klicu te funkcije
    lahko stevilko id prevzamejo na novo definirani zlepki.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("dispcubsplid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  dispcubspldata(&cs);
}

void dispcubsplglob(void)
    /* Zbrise definicijo globalnega kub. zlepka. Sprosti se ves spominski
    prostor povezan s tem zlepkom.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("dispcubsplglob");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  dispcubspldata(&cs);
}


void dispcubsplintvarid(int id)
    /* Zbrise vse tiste pomozne spremenljivke kubicnega zlepka st. id, ki
    jih rabimo za vmesne rezultate, niso pa potrebni pri samem racunanju, ko
    imamo ze izracunane potrebne pomozne spremenljivke (t.j. vektor odvodov v
    notranjih vozliscih in njegovi odvodi po parametrih, glede na katere bomo
    racunali obcutljivosti). To funkcijo lahko uporabimo, da prihranimo prostor,
    ki bi ga drugace sistem po nepotrebnem zasedel, vendar deluje le, ce pred
    njenim klicem pripravimo vse potrebne podatke za izracune vrednosti in
    senzitivnosti kubicnega zlepka, ki bodo sledili. To iz vedemo s pomocjo
    funkcij prepcubsplglobval(), prepcubsplglobsensy() in podobnih.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("dispcubsplid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  dispcubsplintvar(cs);
}

void dispcubsplglobintvar(void)
    /* Zbrise vse tiste pomozne spremenljivke globalnega kubicnega zlepka, ki
    jih rabimo za vmesne rezultate, niso pa potrebni pri samem racunanju, ko
    imamo ze izracunane potrebne pomozne spremenljivke (t.j. vektor odvodov v
    notranjih vozliscih in njegovi odvodi po parametrih, glede na katere bomo
    racunali obcutljivosti). To funkcijo lahko uporabimo, da prihranimo prostor,
    ki bi ga drugace sistem po nepotrebnem zasedel, vendar deluje le, ce pred
    njenim klicem pripravimo vse potrebne podatke za izracune vrednosti in
    senzitivnosti kubicnega zlepka, ki bodo sledili. To iz vedemo s pomocjo
    funkcij prepcubsplglobval(), prepcubsplglobsensy() in podobnih.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("dispcubsplglobintvar");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  dispcubsplintvar(cs);
}


void dispcubsplvarid(int id)
    /* Zbrise vse pomozne spremenljivke kubicnega zlepka st. id. Ne zbrise
    tistih spremenljivk sistema, ki definirajo zlepek, t.j. (..)->x, (...)->y,
    (...)->k1, (...)->kn in (...)->n.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("dispcubsplid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  dispcubsplvar(cs);
}

void dispcubsplglobvar(void)
    /* Zbrise vse pomozne spremenljivke globalnega kubicnega zlepka. Ne zbrise
    tistih spremenljivk sistema, ki definirajo zlepek, t.j. (..)->x, (...)->y,
    (...)->k1, (...)->kn in (...)->n.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("dispcubsplglobintvar");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  dispcubsplvar(cs);
}


void copycubsplid(int id1,int id2)
    /* Skopira kubicni zlepek z identifikacijsko stevilko id1 na zlepek z
    identifikacijsko stevilko id2 (ce ta se ne obstaja, se ga poskusi tvoriti
    na novo)
    $A Igor avg01; */
{
cubspldata cs1,*pcs2;
if ((cs1=getcubspl(id1))==NULL)
{
  errfunc0("copycubsplid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id1);
  errfunc2();
} else
{
  if ((pcs2=getcubspladdr(id2))==NULL)
  {
    if (id2<1)  /* Ukaz se nanasa na globalni kubicni zlepek */
      id2=globcubsplid=newcubspl();
    else
    {
      if (id2-cubsplsys->n>500)
      {
        errfunc0("copycubsplid");
        fprintf(erf(),"PANIC!\nCubic spline id (%i) is much greater than maximum currently existent id (%i).\n",
         id2,cubsplsys->n);
        fprintf(erf(),"This can cause unpredicted program behavior.\n");
        errfunc2();
      }
      if (id2-cubsplsys->n<20000)
        while(id2>cubsplsys->n)
          pushstack(cubsplsys,NULL);
    }
    pcs2=getcubspladdr(id2);
  }
  if (pcs2==NULL)
  {
    errfunc0("copycubsplid");
    fprintf(erf(),"Unable to access or define cubic spline with id %i (probably too great).\n",
     id2);
    fprintf(erf(),"All calculations of this spline will be invalid.\n");
    errfunc2();
  } else
    copycubspldata(cs1,pcs2);
}
}


void printcubsplstateid(int id)
    /* Na standardni izhod izpise podatke o podatkovni strukturi kubicnega
    zlepka z identifikac. st. id.
    $A Igor avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("printcubsplstateid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  printcubsplstate(cs);
}

void printcubsplglobstate(void)
    /* Na standardni izhod izpise podatke o podatkovni strukturi globalnega
    kubicnega zlepka.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("printcubsplglobstate");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  printcubsplstate(cs);
}


void fprintcubsplstateid(FILE *fp,int id)
    /* V datoteko fp izpise podatke o podatkovni strukturi kubicnega
    zlepka z identifikac. st. id.
    $A Igor avg01; */
{
cubspldata cs;
if ((cs=getcubspl(id))==NULL)
{
  errfunc0("fprintcubsplstateid");
  fprintf(erf(),"Cubic spline (id=%i) is not defined.\n",id);
  errfunc2();
} else
  fprintcubsplstate(fp,cs);
}

void fprintcubsplglobstate(FILE *fp)
    /* V datoteko fp izpise podatke o podatkovni strukturi globalnega
    kubicnega zlepka.
    $A Igor nov00 avg01; */
{
cubspldata cs;
if ((cs=getcubspl(0))==NULL)
{
  errfunc0("fprintcubsplglobstate");
  fprintf(erf(),"Global cubic spline is not defined.\n");
  errfunc2();
} else
  fprintcubsplstate(fp,cs);
}





            /****************************/
            /*                          */
            /*  3D VEKTORJI IN MATRIKE  */
            /*                          */
            /****************************/




vec3d getvec3d(void)
    /* Alocira in vrne 3D vektor, komponente postavi na 0.
    $A Igor okt01; */
{
vec3d ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
return ret;
}

mat3d getmat3d(void)
    /* Alocira in vrne 3D matriko, komponente postavi na 0.
    $A Igor okt01; */
{
mat3d ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
return ret;
}


vec3d getvec3dval(double x,double y,double z)
    /* Alocira in vrne 3D vektor, komponente postavi na vrednosti argumentov po
    vrsti.
    $A Igor okt01; */
{
vec3d ret;
ret=getvec3d();
ret->x=x; ret->y=y; ret->z=z;
return ret;
}

mat3d getmat3dval(double xx,double xy,double xz,
                    double yx,double yy,double yz,
                    double zx,double zy,double zz)
    /* Alocira in vrne 3D matriko, komponente postavi na vrednosti argumentov po
    vrsti.
    $A Igor okt01; */
{
mat3d ret;
ret=getmat3d();
ret->x.x=xx; ret->x.y=xy; ret->x.z=xz;
ret->y.x=yx; ret->y.y=yy; ret->y.z=yz;
ret->z.x=zx; ret->z.y=zy; ret->z.z=zz;
return ret;
}

vec3d getvec3drand(void)
    /* Alocira in vrne 3D vektor, katerega komponente postavi na nakljucne
    vrednosti med 0 in 1.
    $A Igor okt01; */
{
vec3d ret;
ret=getvec3d();
ret->x=random1(); ret->y=random1(); ret->z=random1();
return ret;
}

mat3d getmat3drand(void)
    /* Alocira in vrne 3D matriko, katere komponente postavi na nakljucne
    argumentov med 0 in 1.
    $A Igor okt01; */
{
mat3d ret;
ret=getmat3d();
ret->x.x=random1(); ret->x.y=random1(); ret->x.z=random1();
ret->y.x=random1(); ret->y.y=random1(); ret->y.z=random1();
ret->z.x=random1(); ret->z.y=random1(); ret->z.z=random1();
return ret;
}


void fprintvec3d(FILE *fp,vec3d v)
    /* Izpise komponente vektorja v vdatoteko fp v eni vrstici.
    $A Igor okt01; */
{
if (v==NULL)
  fprintf(fp,"NULL\n");
else
  fprintf(fp,"  %15g %15g %15g\n",v->x,v->y,v->z);
}

void printvec3d(vec3d v)
    /* Izpise komponente vektorja v na stand. izhod v eni vrstici.
    $A Igor okt01; */
{
fprintvec3d(stdout,v);
}


void fprintmat3d (FILE *fp,mat3d m)
    /* Izpise komponente matrike m vdatoteko fp v treh vrsticah.
    $A Igor okt01; */
{
if (m==NULL)
  fprintf(fp,"NULL\n");
else
{
  fprintvec3d(fp,&(m->x));
  fprintvec3d(fp,&(m->y));
  fprintvec3d(fp,&(m->z));
}
}

void printmat3d (mat3d m)
    /* Izpise komponente matrike m na stand. izhod v treh vrsticah.
    $A Igor okt01; */
{
fprintmat3d(stdout,m);
}


void readvec3d(vec3d v)
    /* Prebere komponente vektorja v s standardnega vhoda. Za branje komponent
    uporabi funkcijo readdouble().
    $A Igor okt01; */
{
if (v!=NULL)
{
  printf("Cur. vlaue:\n"); printvec3d(v);
  printf("comp. x: "); readdouble(&(v->x));
  printf("comp. y: "); readdouble(&(v->y));
  printf("comp. z: "); readdouble(&(v->z));
}
}


void readmat3d(mat3d m)
    /* Prebere komponente matrike m s standardnega vhoda. Za branje komponent
    uporabi funkcijo readdouble().
    $A Igor okt01; */
{
if (m!=NULL)
{
  printf("Cur. vlaue:\n"); printmat3d(m);
  printf("comp. x-x: "); readdouble(&(m->x.x));
  printf("comp. x-y: "); readdouble(&(m->x.y));
  printf("comp. x-z: "); readdouble(&(m->x.z));
  printf("comp. y-x: "); readdouble(&(m->y.x));
  printf("comp. y-y: "); readdouble(&(m->y.y));
  printf("comp. y-z: "); readdouble(&(m->y.z));
  printf("comp. z-x: "); readdouble(&(m->z.x));
  printf("comp. z-y: "); readdouble(&(m->z.y));
  printf("comp. z-z: "); readdouble(&(m->z.z));
}
}



void zerovec3d(vec3d v)
    /* Komponente 3D vektorja v postavi na 0.
    $A Igor okt01; */
{
if (v!=NULL)
  memset(v,0,sizeof(*v));
}

void zeromat3d(mat3d m)
    /* Komponente 3D matrike m postavi na 0.
    $A Igor okt01; */
{
if (m!=NULL)
  memset(m,0,sizeof(*m));
}



double vec3dcomp(vec3d v,int i)
    /* Vrne i-to komponento vektorja v (ce je v NULL ali indeks i ni med 1 in 3,
    vrne 0).
    $A Igor okt01; */
{
if (v!=NULL)
  switch(i)
  {
    case 1:
      return v->x;
    case 2:
      return v->y;
    case 3:
      return v->z;
  }
return 0;
}


double mat3dcomp(mat3d m,int i,int j)
    /* Vrne (i,j)-to komponento matrike m (ce je m NULL ali indeksa nista
     med 1 in 3, vrne 0).
    $A Igor okt01; */
{
if (m!=NULL)
  switch(i)
  {
    case 1:
      return vec3dcomp(&(m->x),j);
    case 2:
      return vec3dcomp(&(m->y),j);
    case 3:
      return vec3dcomp(&(m->z),j);
  }
return 0;
}


void setvec3dcomp(vec3d v,int i,double val)
    /* i-to komponento vektorja v postavi na val; Ce je v NULL ali indeks i
    ni med 1 in 3, ne naredi nicesar.
    $A Igor okt01; */ 
{
if (v!=NULL)
  switch(i)
  {
    case 1:
      v->x=val;
      break;
    case 2:
      v->y=val;
      break;
    case 3:
      v->z=val;
      break;
  }
}


void setmat3dcomp(mat3d m,int i,int j,double val)
    /* (i,j)-to komponento vektorja v postavi na val; Ce je v NULL ali indeks i
    ni med 1 in 3, ne naredi nicesar.
    $A Igor okt01; */ 
{
if (m!=NULL)
  switch (i)
  {
    case 1:
      setvec3dcomp(&(m->x),j,val);
      break;
    case 2:
      setvec3dcomp(&(m->y),j,val);
      break;
    case 3:
      setvec3dcomp(&(m->z),j,val);
      break;
  }
}


void setvec3d(vec3d v,double x,double y,double z)
    /* Komponente vektorja v postavi na x, y in z.
    $A Igor okt01; */ 
{
if (v!=NULL)
{
  v->x=x;
  v->y=y;
  v->z=z;
}
}


void setmat3d(mat3d m,
              double xx,double xy,double xz,
              double yx,double yy,double yz,
              double zx,double zy,double zz)
    /* Komponente matrike m postavi na vrednosti, kot jih po vrsti dolocajo
    argumenti xx, xy, ..., zz.
    $A Igor okt01; */ 
{
if (m!=NULL)
{
  m->x.x=xx; m->x.y=xy; m->x.z=xz;
  m->y.x=yx; m->y.y=yy; m->y.z=yz;
  m->z.x=zx; m->z.y=zy; m->z.z=zz;
}
}



void mat3dcol(mat3d a,vec3d col,int i)
    /* V vektor col zapise i-ti stolpec matrike a.
    $A Igor okt01; */
{
if (a!=NULL && col!=NULL)
{
  switch(i)
  {
    case 1:
      col->x=a->x.x;
      col->y=a->y.x;
      col->z=a->z.x;
      break;
    case 2:
      col->x=a->x.y;
      col->y=a->y.y;
      col->z=a->z.y;
      break;
    case 3:
      col->x=a->x.z;
      col->y=a->y.z;
      col->z=a->z.z;
      break;
    default:
      zerovec3d(col);
  }
}
}


void multscalvec3d(vec3d a,double c,vec3d prod)
    /* V prod zapise vektor a pomnozen s skalarjem c.
    $A Igor okt01; */
{
if (a!=NULL && prod!=NULL)
{
  prod->x=c*a->x;
  prod->y=c*a->y;
  prod->z=c*a->z;
}
}


void lincombvec3d(double a1,vec3d v1,double a2,vec3d v2,vec3d comb)
    /* V vektor comb zapise linearno kombinacijo vektorjev v1 in v2 s
    koeficientoma a1 in a2.
    $A Igor okt01; */
{
if (v1!=NULL && v2!=NULL && comb!=NULL)
{
  comb->x=a1*v1->x+a2*v2->x;
  comb->y=a1*v1->y+a2*v2->y;
  comb->z=a1*v1->z+a2*v2->z;
}
}


void multscalmat3d(mat3d a,double c,mat3d prod)
    /* V prod zapise matriko a pomnozeno s skalarjem c.
    $A Igor okt01; */
{
if (a!=NULL && prod!=NULL)
{
  multscalvec3d(&(a->x),c,&(prod->x));
  multscalvec3d(&(a->y),c,&(prod->y));
  multscalvec3d(&(a->z),c,&(prod->z));
}
}


double scalprod3d(vec3d v1,vec3d v2)
    /* Vrne skalarni produkt vektorjev v1 in v2.
    $A Igor okt01; */
{
if (v1!=NULL && v2!=NULL)
  return v1->x*v2->x+v1->y*v2->y+v1->z*v2->z;
else
  return 0;
}


void vecprod3d(vec3d a,vec3d b,vec3d prod)
    /* V vektor prod zapise vektorski produkt vektorjev a in b.
    $A Igor okt01; */
{
_vec3d ref;
if (a!=NULL && b!=NULL && prod!=NULL)
{
  ref.x=a->y*b->z-a->z*b->y;
  ref.y=a->z*b->x-a->x*b->z;
  ref.z=a->x*b->y-a->y*b->x;
  *prod=ref;
}
}


double mixprod3d(vec3d a,vec3d b,vec3d c)
    /* Vrne mesani produkt vektorjev a, b in c, ki predstavlja volumen, ki ga
    ti trije vektorji predstavljajo: (a,b,c)=(axb)*c
    $A Igor okt01; */
{
if (a!=NULL && b!=NULL && c!=NULL)
  return a->y*b->z*c->x + a->z*b->x*c->y + a->x*b->y*c->z
       - a->z*b->y*c->x - a->x*b->z*c->y - a->y*b->x*c->z;
else
  return 0;
}


void vecsum3d(vec3d a,vec3d b,vec3d sum)
    /* V vektor sum zapise vsoto vektorjev a in b. sum lahko kaze na isto mesto
    kot a ali b.
    $A Igor okt01; */
{
if (a!=NULL && b!=NULL && sum!=NULL)
{
  sum->x=a->x+b->x;
  sum->y=a->y+b->y;
  sum->z=a->z+b->z;
}
}


void vecdif3d(vec3d a,vec3d b,vec3d dif)
    /* V vektor dif zapise razliko vektorjev a in b. dif lahko kaze na isto mesto
    kot a ali b.
    $A Igor okt01; */
{
if (a!=NULL && b!=NULL && dif!=NULL)
{
  dif->x=a->x-b->x;
  dif->y=a->y-b->y;
  dif->z=a->z-b->z;
}
}



void matsum3d(mat3d a,mat3d b,mat3d sum)
    /* V matriko sum zapise vsoto matrik a in b. sum lahko kaze na isto mesto
    kot a in b.
    $A Igor okt01; */
{
if (a!=NULL && b!=NULL && sum!=NULL)
{
  vecsum3d(&(a->x),&(b->x),&(sum->x));
  vecsum3d(&(a->y),&(b->y),&(sum->y));
  vecsum3d(&(a->z),&(b->z),&(sum->z));
}
}

void matdif3d(mat3d a,mat3d b,mat3d dif)
    /* V Matriko dif zapise razliko matrik a in b. dif lahko kaze na isto mesto
    kot a in b.
    $A Igor okt01; */
{
if (a!=NULL && b!=NULL && dif!=NULL)
{
  vecdif3d(&(a->x),&(b->x),&(dif->x));
  vecdif3d(&(a->y),&(b->y),&(dif->y));
  vecdif3d(&(a->z),&(b->z),&(dif->z));
}
}


void matprod3d(mat3d a,mat3d b,mat3d prod)
    /* V matriko prod zapise produkt matrik a in b. prod lahko kaze na isto
    mesto kot a ali b ali oba.
    $A Igor okt01; */
{
_mat3d ref;
_vec3d col;
if (a!=NULL && b!=NULL && prod!=NULL)
{
  ref=*a;
  /* Izracun 1. stolpca produkta: */
  mat3dcol(b,&col,1);
  prod->x.x=scalprod3d(&(ref.x),&col);
  prod->y.x=scalprod3d(&(ref.y),&col);
  prod->z.x=scalprod3d(&(ref.z),&col);
  /* Izracun 2. stolpca produkta: */
  mat3dcol(b,&col,2);
  prod->x.y=scalprod3d(&(ref.x),&col);
  prod->y.y=scalprod3d(&(ref.y),&col);
  prod->z.y=scalprod3d(&(ref.z),&col);
  /* Izracun 1. stolpca produkta: */
  mat3dcol(b,&col,3);
  prod->x.z=scalprod3d(&(ref.x),&col);
  prod->y.z=scalprod3d(&(ref.y),&col);
  prod->z.z=scalprod3d(&(ref.z),&col);
}
}

void matprodvec3d(mat3d a,vec3d b,vec3d prod)
    /* V vektor prod zapise produkt matrike a in vektorja b. prod lahko kaze na
   isto mesto kot b.
    $A Igor okt01; */
{
_vec3d col;
if (a!=NULL && b!=NULL && prod!=NULL)
{
  col=*b;
  prod->x=scalprod3d(&(a->x),&col);
  prod->y=scalprod3d(&(a->y),&col);
  prod->z=scalprod3d(&(a->z),&col);
}
}


double vecnorm3d(vec3d v)
    /* Vrne evklidsko normo vektorja v. 
    $A Igor okt01; */
{
if (v==NULL)
  return 0;
else
  return sqrt(m_sqr(v->x)+m_sqr(v->y)+m_sqr(v->z));
}


void normvec3d(vec3d v)
    /* Normira vektor v.
    $A Igor okt01; */
{
double n;
n=vecnorm3d(v);
if (n>0)
{
  v->x/=n;
  v->y/=n;
  v->z/=n;
}
}


double detmat2d(mat3d a)
    /* Vrne determinanto 2D matrike a (ce je a NULL, vrne 0).
    $A Igor okt01; */
{
if (a!=NULL)
return a->x.x*a->y.y - a->x.y*a->y.x;
else
  return 0;
}


double detmat3d(mat3d a)
    /* Vrne determinanto 3D matrike a (ce je a NULL, vrne 0).
    $A Igor okt01; */
{
if (a!=NULL)
  return a->x.x*a->y.y*a->z.z + a->x.y*a->y.z*a->z.x + a->x.z*a->y.x*a->z.y
       - a->x.z*a->y.y*a->z.x - a->x.x*a->y.z*a->z.y - a->x.y*a->y.x*a->z.z ;
else
  return 0;
}


void transpmat3d(mat3d a,mat3d transp)
    /* Transponirano matriko matrike a zapise v matriko transp. a in transp
    lahko kazeta na isto matriko.
    $A Igor okt01; */
{
double s;
if (a!=NULL && transp!=NULL)
{
  transp->x.x=a->x.x;
  s=a->x.y;  transp->x.y=a->y.x;  transp->y.x=s;
  s=a->x.z;  transp->x.z=a->z.x;  transp->z.x=s;
  transp->y.y=a->y.y;
  s=a->y.z;  transp->y.z=a->z.y;  transp->z.y=s;
  transp->z.z=a->z.z;
}
}

double invmat2d(mat3d a,mat3d inv)
    /* V inv zapise inverzno matriko 2D matrike a in vrne determinanto a.
    inv lahko kaze na isto matriko kot transp.
    $A Igor okt01; */
{
double d=0;
_mat3d mref;
if (a!=NULL && inv!=NULL)
{
  d=detmat2d(a);
  if (d!=0)
  {
    mref.x.x=a->y.y/d;
    mref.x.y=-a->x.y/d;
    mref.y.x=-a->y.x/d;
    mref.y.y=a->x.x/d;
    inv->x.x=mref.x.x; inv->x.y=mref.x.y; inv->x.z=0;
    inv->y.x=mref.y.x; inv->y.y=mref.y.y; inv->y.z=0;
    inv->z.x=0; inv->z.y=0; inv->z.z=0;
    
  } else
    zeromat3d(inv);
}
return d;
}


double invmat3d(mat3d a,mat3d inv)
    /* V 3D matriko inv zapise inverz matrike a. inv lahko kaze na isti prostor
    kot a. Funkcija vrne determinanto a.
    $A Igor okt01; */
{
double d=0;
_mat3d ref,ref1;
if (a!=NULL && inv!=NULL)
{
  d=detmat3d(a);
  if (d!=0)
  {
    /* V ref1 zapisemo transponirane poddeterminante matrike a */
    transpmat3d(a,&ref);
    ref1.x.x =  ref.y.y*ref.z.z-ref.y.z*ref.z.y;
    ref1.x.y =-(ref.y.x*ref.z.z-ref.y.z*ref.z.x);
    ref1.x.z =  ref.y.x*ref.z.y-ref.y.y*ref.z.x;
    ref1.y.x =-(ref.x.y*ref.z.z-ref.x.z*ref.z.y);
    ref1.y.y =  ref.x.x*ref.z.z-ref.x.z*ref.z.x;
    ref1.y.z =-(ref.x.x*ref.z.y-ref.x.y*ref.z.x);
    ref1.z.x =  ref.x.y*ref.y.z-ref.x.z*ref.y.y;
    ref1.z.y =-(ref.x.x*ref.y.z-ref.x.z*ref.y.x);
    ref1.z.z =  ref.x.x*ref.y.y-ref.x.y*ref.y.x;
    inv->x.x = ref1.x.x/d;
    inv->x.y = ref1.x.y/d;
    inv->x.z = ref1.x.z/d;
    inv->y.x = ref1.y.x/d;
    inv->y.y = ref1.y.y/d;
    inv->y.z = ref1.y.z/d;
    inv->z.x = ref1.z.x/d;
    inv->z.y = ref1.z.y/d;
    inv->z.z = ref1.z.z/d;
  } else
    zeromat3d(inv);
}
return d;
}


double solve2d(mat3d a,vec3d b,vec3d x)
    /* V x zapise resitev sistema dveh enacb z dvema neznankama, kjer so
    koeficienti enacbe v zgornjem levem kotu matrike a, desne strani pa v
    zgornjem delu vektorja b. Funkcija vrne determinanto matrike sistema.
    $A Igor okt01; */
{
double ret=0;
_mat3d inv;
if (a!=NULL && b!=NULL && x!=NULL)
{
  ret=invmat2d(a,&inv);
  matprodvec3d(&inv,b,x);
}
return ret;
}

double solve3d(mat3d a,vec3d b,vec3d x)
    /* V x zapise resitev sistema treh enacb s tremi neznankami, kjer so
    koeficienti enacbe v a, desne strani pa v  vektorju b. Funkcija vrne
    determinanto matrike sistema.
    $A Igor okt01; */
{
double ret=0;
_mat3d inv;
if (a!=NULL && b!=NULL && x!=NULL)
{
  ret=invmat3d(a,&inv);
  matprodvec3d(&inv,b,x);
}
return ret;
}


int eigensystem2d(mat3d a,mat3d eigenvec,vec3d eigenval)
    /* Calculates eigenvectors and eigenvalues of a 2x2 matrix a and stores
    eigenvectors to lines of eigenvec and eigenvalues to eigenval. eigenvec
    can be the same matrix as a. The number of different real eigenvalues is
    returned.
      Ref.: linalg.nb
    Not tested yet!
    $A Igor nov03; */
{
int ret=0;
double axx,axy,ayx,ayy,d;
axx=a->x.x;  axy=a->x.y;  ayx=a->y.x;  ayy=a->y.y;
d=axx*axx+4*axy*ayx-2*axx*ayy+ayy*ayy;
if (d<0)
{
  /* The eigensystem has no real solutions: */
  zeromat3d(eigenvec);
  zerovec3d(eigenval);
  return 0;
} else
{
  eigenvec->x.z=eigenvec->y.z=eigenvec->z.z=eigenvec->z.x=eigenvec->z.y=
    eigenval->z=0;
  d=sqrt(d);
  if (d>1e-10*fabs(axx+ayy))
  {
    /* We have two real eigenvalues: */
    if (fabs(ayx)/(fabs(axx)+fabs(ayy)+fabs(d))>1e-20)
    {
      eigenval->x=(axx + ayy - d)/2;
      eigenvec->x.x=-(-axx + ayy + d)/(2*ayx);
      eigenvec->x.y=1;
      eigenval->y=(axx + ayy + d)/2;
      eigenvec->y.x=-(-axx + ayy - d)/(2*ayx);
      eigenvec->y.y=1;
    } else
    {
      /* When ayx==0 we must adopt another formula: */
      eigenval->x=axx;
      eigenvec->x.x=1;
      eigenvec->x.y=0;
      eigenval->y=ayy;
      if (fabs(axx-ayy)>1e-20)
      {
        eigenvec->y.x=-(axy/(axx - ayy));
        eigenvec->y.y=1;
      } else
      {
        /* To ni striktno, velja pa za simetricne matrike (zaradi ortog. last.
        vektorjev): */
        eigenvec->y.x=0;
        eigenvec->y.y=1;
      }
    }
    return 2;
    normvec3d(&(eigenvec->x));
    normvec3d(&(eigenvec->y));
  } else
  {
    /* We have only one (double) eigenvalue: */
    if (fabs(ayx)/(fabs(axx)+fabs(ayy)+fabs(d))>1e-20)
    {
      eigenval->x=(axx + ayy - d)/2;
      eigenvec->x.x=-(-axx + ayy + d)/(2*ayx);
      eigenvec->x.y=1;
      eigenval->y=(axx + ayy + d)/2;
      /* We set the second eigenvector orthogonal to the first one (this is OK
      for symmetric matrices): */
      eigenvec->y.x=-eigenvec->x.y;
      eigenvec->y.y=eigenvec->x.x;
    } else
    {
      /* When ayx==0 we must adopt another formula: */
      eigenval->x=axx;
      eigenvec->x.x=1;
      eigenvec->x.y=0;
      eigenval->y=ayy;
      eigenvec->y.x=0;
      eigenvec->y.y=1;
    }
    normvec3d(&(eigenvec->x));
    normvec3d(&(eigenvec->y));
    return 1;
  }
}
}



            /******************************/
            /*                            */
            /*  3D ANALITICNA GEOMETRIJA  */
            /*                            */
            /******************************/



double distpt3d(vec3d p1,vec3d p2)
    /* Vrne razdaljo med tockama p1 in p2. Ce je kateri od kazalcev p1 oz. p2
    NULL, vrne 0.
    $A Igor okt01; */
{
if (p1!=NULL && p2!=NULL)
  return sqrt(m_sqr(p2->x-p1->x)+m_sqr(p2->y-p1->y)+m_sqr(p2->z-p1->z));
else
    return 0;
}


double directioncos3d(vec3d s1,vec3d s2)
    /* Vrne kosinus kota med smerema s1 in s2 (smerni kosinus).
    $A Igor okt01; */
{
return scalprod3d(s1,s2)/(scalprod3d(s1,s1)*scalprod3d(s2,s2));
}


double ortprojptline3d(vec3d pt,vec3d r,vec3d s,vec3d proj)
    /* Izracuna ortogonalno projekcijo tocke pt na premico podano s tocko na
    premici r in smernim vektorjem s. Rezultat zapise v proj. Funkcija vrne
    se pozicijo tocke proj na premici izrazeno s koeficientom (c) pri smernem
    vektorju, tako da je proj=r+c*s.
    Formula: proj = r+((pt-r)*s/(s*s)) s
    $A Igor okt01; */
{
double k=0;
if (pt!=NULL && r!=NULL && s!=NULL)
{
  vecdif3d(pt,r,proj);  /* proj=pt-r */
  k=scalprod3d(proj,s)/scalprod3d(s,s); /* k=((pt-r)*s/(s*s)) */
  multscalvec3d(s,k,proj);  /* proj=((pt-r)*s/(s*s)) s */
  vecsum3d(r,proj,proj);
}
return k;
}




double distptline3d(vec3d pt,vec3d r,vec3d s)
    /* Vrne oddaljenost tocke pt od premice podane s tocko na premici r in s
    smernim vektorjem s.
    Formula: d= || (pt-r) x s || / ||s||
    $A Igor okt01; */
{
_vec3d ref;
if (pt!=NULL && r!=NULL && s!=NULL)
{
  vecdif3d(pt,r,&ref);  /* ref=pt-r */
  vecprod3d(&ref,s,&ref);  /* ref=(pt-r) x s */
  return vecnorm3d(&ref)/vecnorm3d(s);
}
return 0;
}


double nearestptlines3d(vec3d r1,vec3d s1,vec3d r2,vec3d s2,vec3d pt1,vec3d pt2)
    /*  V pr1 zapise tocko na 1. premici, ki je najblizje 2. premici, v pr2
    pa tocko na 2, premici, ki je najblizje 1. premici, ter vrne razdaljo med
    obema tockama (t.j. razdaljo med premicama). 1. premica je podana s tocko
    na premici r1 in smefnim vektorjem s1, 2. premica pa s tocko na premici r2
    in smer. vektorjem s2.
     Resitev:
    Resujemo p1=r1+k1*s1, p2=r2+k2*s2, k1,k2:min || p1-p2 ||^2;
    k1 in k2 dobimo dako, da odvod ||...||^2  izenacimo z 0, dobimo
    k1=-(r1*s2)/(s1*s2) in k2=-(r2*s1)/(s1*s2), izracunamo p1 in p2.
     POZOR!
     Problemi so lahko pri vzporednih premicah, ker numericni algoritem premic
    ne prepozna za vzporedne zaradi numericnih napak in vrne neko veliko
    razdaljo med dvema premicama, saj sta ort. projekciji cisto narobe
    izracunani.
    $A Igor okt01; */
{
double ret=0,k1,k2;
_mat3d A;
_vec3d b,x;
if (r1!=NULL && s1!=NULL && r2!=NULL && s2!=NULL && pt1!=NULL && pt2!=NULL)
{
  if (fabs(directioncos3d(s1,s2))-1==0)
  {
    /* Premici sta vzporedni, pt1 postane r1, pt2 pa prav. proj. r1 na 2.
    premico, vrne se razdalja med premicama */
    *pt1=*r1;
    ortprojptline3d(r1,r2,s2,pt2);
    ret=distpt3d(pt1,pt2);
  } else
  {
    /* Koeficienti enacbe za izracun k1 in kv, ki dolocata najbljizji tocki: */
    zeromat3d(&A); zerovec3d(&b);
    A.x.x=-scalprod3d(s1,s1);
    A.x.y= scalprod3d(s1,s2);
    A.y.x= scalprod3d(s1,s2);
    A.y.y=-scalprod3d(s2,s2);
    b.x=scalprod3d(r1,s1)-scalprod3d(s1,r2);
    b.y=scalprod3d(r2,s2)-scalprod3d(r1,s2);;
    solve2d(&A,&b,&x);
    k1=x.x; k2=x.y;
    multscalvec3d(s1,k1,pt1);  vecsum3d(r1,pt1,pt1);
    multscalvec3d(s2,k2,pt2);  vecsum3d(r2,pt2,pt2);
    ret=distpt3d(pt1,pt2);
    if (ret>distptline3d(r1, r2,s2))
    {
      /* Ce je izracunana razdalja med premicama manjsa od razdalje med r1 in 2.
      premico, je nekaj narobe (najverjetneje vzporednost ali numericne napake),
      v tem primeru pt1 postane r1, pt2 pravokot. projekcija r1 na 2. premico,
      vrne pa se razdalja med r1 in pravokot. proj. r1 na r2: */
      *pt1=*r1;
      ortprojptline3d(r1,r2,s2,pt2);
      ret=distpt3d(pt1,pt2);
    }
  }
}
return ret;
}


double nearestptlinescoef3d(vec3d r1,vec3d s1,vec3d r2,vec3d s2,
       vec3d pt1,double *c1,vec3d pt2,double *c2)
    /*  V pr1 zapise tocko na 1. premici, ki je najblizje 2. premici, v pr2
    pa tocko na 2, premici, ki je najblizje 1. premici, ter vrne razdaljo med
    obema tockama (t.j. razdaljo med premicama). 1. premica je podana s tocko
    na premici r1 in smefnim vektorjem s1, 2. premica pa s tocko na premici r2
    in smer. vektorjem s2. Funkcija vrne v *c1 in *c2 tudi koeficienta, ki na
    obeh premicah dolocata najbljizji tocki, tako da je pt1=r1+c1*s1 in
    pt2=r2+c2*s2.
     Resitev:
    Resujemo p1=r1+k1*s1, p2=r2+k2*s2, k1,k2:min || p1-p2 ||^2;
    k1 in k2 dobimo dako, da odvod ||...||^2  izenacimo z 0, dobimo
    k1=-(r1*s2)/(s1*s2) in k2=-(r2*s1)/(s1*s2), izracunamo p1 in p2.
     POZOR!
     Problemi so lahko pri vzporednih premicah, ker numericni algoritem premic
    ne prepozna za vzporedne zaradi numericnih napak in vrne neko veliko
    razdaljo med dvema premicama, saj sta ort. projekciji cisto narobe
    izracunani.
    $A Igor okt01; */
{
double ret=0,k1,k2;
_mat3d A;
_vec3d b,x;
if (r1!=NULL && s1!=NULL && r2!=NULL && s2!=NULL && pt1!=NULL && pt2!=NULL)
{
  if (fabs(directioncos3d(s1,s2))-1==0)
  {
    /* Premici sta vzporedni, pt1 postane r1, pt2 pa prav. proj. r1 na 2.
    premico, vrne se razdalja med premicama */
    *pt1=*r1; *c1=0;
    *c2=ortprojptline3d(r1,r2,s2,pt2);
    ret=distpt3d(pt1,pt2);
  } else
  {
    /* Koeficienti enacbe za izracun k1 in kv, ki dolocata najbljizji tocki: */
    zeromat3d(&A); zerovec3d(&b);
    A.x.x=-scalprod3d(s1,s1);
    A.x.y= scalprod3d(s1,s2);
    A.y.x= scalprod3d(s1,s2);
    A.y.y=-scalprod3d(s2,s2);
    b.x=scalprod3d(r1,s1)-scalprod3d(s1,r2);
    b.y=scalprod3d(r2,s2)-scalprod3d(r1,s2);;
    solve2d(&A,&b,&x);
    k1=x.x; k2=x.y;
    multscalvec3d(s1,k1,pt1);  vecsum3d(r1,pt1,pt1);
    multscalvec3d(s2,k2,pt2);  vecsum3d(r2,pt2,pt2);
    *c1=k1; *c2=k2;
    ret=distpt3d(pt1,pt2);
    if (ret>distptline3d(r1, r2,s2))
    {
      /* Ce je izracunana razdalja med premicama manjsa od razdalje med r1 in 2.
      premico, je nekaj narobe (najverjetneje vzporednost ali numericne napake),
      v tem primeru pt1 postane r1, pt2 pravokot. projekcija r1 na 2. premico,
      vrne pa se razdalja med r1 in pravokot. proj. r1 na r2: */
      *pt1=*r1; *c1=0;
      *c2=ortprojptline3d(r1,r2,s2,pt2);
      ret=distpt3d(pt1,pt2);
    }
  }
}
return ret;
}


void ortprojptplane3d(vec3d pt,vec3d r,vec3d n,vec3d proj)
    /* Izracuna ortogonal. projekcijo tocke pt na ravnino, ki je podana s tocko
    na ravnini r in normalo ravnine n. Rezultat zapise v proj.
    Formula: proj = pt+((r-pt)*n) n / n*n
    $A Igor okt01; */
{
double k;
if (pt!=NULL && r!=NULL && n!=NULL)
{
  vecdif3d(r,pt,proj);  /* proj = r-pt */
  k=scalprod3d(proj,n)/scalprod3d(n,n);  /* k = ((r-pt)*n) / n*n */
  multscalvec3d(n,k,proj);   /* proj =  ((r-pt)*n) n / n*n */
  vecsum3d(pt,proj,proj);
}
}


void ortprojlineplane3d(vec3d r1,vec3d s1,vec3d r2,vec3d n2,vec3d rpr,vec3d spr)
    /* Izracuna premico, ki je pravokotna projekcija premice podane s tocko na
    premici r1 in smernim vektorjem s1, na ravnino, ki je podana s tocko na
    ravnini r2 in normalo n2. V vektor rpr zapise tocko na projekciji, v vektor
    spr pa smerni vektor projekcije. Projekcijo se dobi enostavno tako, da se
    na ravnino posebej projicirata tocka na premici in njen smerni vektor.
    Funkcija ne obravnava posebej primera, ko je premica pravokotna na ravnino
    - to se lahko preveri tako, da se pogleda, ce so vse tri komponente vektorja
    spr enake 0.
    $A Igor okt01; */
{
ortprojptplane3d(r1,r2,n2,rpr);
ortprojptplane3d(s1,r2,n2,rpr);
}


double signdistptplane3d(vec3d pt,vec3d r,vec3d n)
    /* Vrne razdaljo tocke pt od ravnine, ki je podana s tocko na ravnini r in
    normalo ravnine n. Razdalja je negativna, ce je pt na nasprotni strani
    ravnine, kot je tista, v katero kaze normala n, in pozitivno, ce je tocka na
    isti strani.
    Formula: d= (pt-r)*n / ||n||
    $A Igor okt01; */
{
_vec3d ref;
vecdif3d(pt,r,&ref);  /* ref=pt-r */
return (scalprod3d(&ref,n)/vecnorm3d(n));
}


double distptplane3d(vec3d pt,vec3d r,vec3d n)
    /* Vrne absolutno razdaljo  tocke pt od ravnine, ki je podana s tocko na
    ravnini r in normalo ravnine n, ki je vedno pozitivno stevilo.
    $A Igor okt01; */
{
return fabs(signdistptplane3d(pt,r,n));
}


double intsectlineplane3d(vec3d r1,vec3d s1,vec3d r2,vec3d n2,vec3d sect)
    /* V sect zapise presecisce med premico, podano s tocko na premici r1 in
    smernim vektorjem s1, in ravnino podano s tocko na ravnini r2 in normalo
    n2. Ce presecisce obstaja, vrne funkcija 0, drugace vrne predznaceno
    razdaljo med premico in ravnino (to je v primeru, ko sta ravnina in premica
    vzporedni).
    Formula: sect=r1+((r2*n2-r1*n2)/(s1*n2)) s1
    $A Igor okt01; */
{
double ret=0,k;
if (r1!=NULL && s1!=NULL && r2!=NULL && n2!=NULL)
{
  if ((k=scalprod3d(s1,n2))!=0)
  {
    multscalvec3d(s1,
     (scalprod3d(r2,n2)-scalprod3d(r1,n2))/k /* s1*n2 */ ,
     sect);  /* sect = ((r2*n2-r1*n2)/(s1*n2)) s1 */
    vecsum3d(r1,sect,sect);
  } else
  {
    ret=signdistptplane3d(r1,r2,n2);
    *sect=*r1;
  }
}
return ret;
}


double intsectplanes3d(vec3d r1,vec3d n1,vec3d r2,vec3d n2,vec3d r,vec3d s)
    /* Najde premico, ki je PRESECISCE RAVNIN, od katerih je 1. dolocena z
    vektorjem r1 in normalo n1, 2. pa z vektorjem r2 in normalo n2. V r zapise
    tocko na tej premici, v s pa njen smerni vektor. Ce sta ravnini vzporedni,
    vrne funkcija razdaljo med ravninama (v r pa se zapise r1), drugace pa vrne
    0.
     POSTOPEK:
    Smerni vektor premice je n1xn2 (vekt. produkt normal). Rabimo se tocko na
    premici, to dobimo tako, da vzamemo presecisce premice, ki gre skozi r1
    ter je pravokotna na n1*n2 in na n1 (torej lezi v 1. ravnini) z 2. ravnino.
    $A Igor okt01; */
{
double ret=0;
if (r1!=NULL && n1!=NULL && r2!=NULL && n2!=NULL && r!=NULL && s!=NULL)
{
  vecprod3d(n1,n2,s); /* Smer. vektor premice, ki predstavlja presecisce */
  if (fabs(directioncos3d(n1,n2))-1==0)
  {
    /* Ravnini sta vzporedni, zato r postane r1, vrne se razdaljo med r1 in 2.
    ravnino: */
    *r=*r1;
    ret=distptplane3d(r1,r2,n2);
  } else
  {
    vecprod3d(n1,s,r);  /* r postane smer. vektor, pravokoten na n1 in n1xn2 */
    if (intsectlineplane3d(r1,r,r2,n2,r))
    {
      /* Presecisca med premico na 1. ravnini in med 2. ravnino ni (kljub temu,
      da se je abs. vred. smer. kosinusa med normalama prej izkazala za
      razlicne od 1, a je ocitno slo za numer. napake), zato r postane r1, vrne
      se razdaljo med r1 in 2. ravnino: */
      *r=*r1;
      ret=distptplane3d(r1,r2,n2);
    }
  }
}
return ret;
}




    /* TRANSFORMACIJE KOORDINAT. SIST. IN KOORDINAT (VRTENJA, TRANSLAC.) */


/* TRANSFORMACIJE KOORDINAT V DESNOSUC. ENOTSKIH KARTEZ. SISTEMIH */



/*  DOGOVORI IN OPOMBE:
  TRANSF. KOORD. SIST.:
  Vektor r naj ima v desnosucnem ortonormir. sist. (enotski in ortogonalni enot.
vektorji, e1xe2=e3) koordinate r=(x, y, z). V koordinatnem sistemu z baznimi
vektorji e1', e2' in e3' ima isti vektor koordinate r'=(x', y' in z'). Direktna
transformacijska matrika potem recemo matriki Q, ki pretvori koordinate r' v r,
torej r=Qr'. Inverzna transformacijska matrika pretvori koordinate v starem
koordinatnem sistemu v koordinate v novem, dorej r'=Q-1 r.
  Transformacijaka matrika Q tudi pretvori bazne vektorje starega koordinatnega
sistema v bazne vektorje novega sist., kar pomeni, da je e1'=Qe1, e2'=Qe2 in
e3'=Qe3.
Stolpci matrie Q so koordinate baznih vektorjev novega sistema (e1', e2' in
e3') v starem koordinatnem sistemu z ortonorm. baz. vektorji e1, e2 in e3.
  Ce so bazni vektorji e1', e2' in e3' paroma ortogonalni in normirani, je
Q-1=QT (Inverz Q je kar njena transponirana matrika). V tem primeru je
determinanta Q enaka 1, ce tvorijo e1', e2' in e3' desnosucni koordinatni
sistem, in -1, ce tvorijo levosucnega.
  Transformacija linearnih operatorjev:
Ce je A matrika linearnega operatorja v starem sistemu, potem dobimo matriko
linearnega operatorja v novem koordinatnem sistemu A' kot A'=Q-1 A Q . Iz
zapisa operatorja v novem sistemu dobimo zapis v starem sistemu na naslednji
nacin: A=Q A Q-1.
*/



void invtransfmat3dortnormbas(vec3d xnew,vec3d ynew,mat3d transfinv)
    /* Naredi inverzno transformacijsko matriko iz desnosucnega ortonormiranega
    koordinatnega sistema v novi desnosucni ortonormiran sistem, katerega 1.
    bazni vektor je normiran xnew, drugi pa je ortonormiran glede na prvega in
    lezi v podprostoru, ki ga razpenjata xnew in ynew. Matriko shrani v
    transfinv; ce s to matriko pomnozimo koordinate vektorja v starem
    koordinatnem sistemu, dobimo koordinate vektorja v novem sistemu. xnew mora
    biti razlicen od NULL in nenicelen vektor, medtem ko je lahko ynew tudi
    neustrezen vektor - lahko je NULL ali kolinearen oz. skoraj kolinearen z
    xnew. Ce je ynew neustrezen, funkcija sama izbere drugi bazni vektor;
    tretji bazni vektor je vektorski produkt prvih dveh.
    $A Igor okt01; */
{
_vec3d x,y,z;
double sp,norm1,norm2,tol=1e-10;
if (ynew==NULL)
{
  y.x=y.y=y.z=0;
  ynew=&y;
}
if (xnew!=NULL && transfinv!=NULL)
{
  if ((norm1=vecnorm3d(xnew))>0)
  {
    /* x postane normiran xnew: */
    multscalvec3d(xnew,1/norm1,&x);
    /* Ortogonalizacija ynew glede na x in normiranje */
    if (sp=scalprod3d(&x,ynew)!=0)
      lincombvec3d(1,ynew,-sp,&x,&y);
    else (y=*ynew);
    if ((norm2=vecnorm3d(&y))<=tol*norm1)
    {
      /* Ce je bila norma ynew veliko manjsa od norme xnew oz. ce je bil ynew
      skoraj kolinearen z xnew, se za ynew izbere drug vektor, ki je bolj
      ustrezen: */
      setvec3d(ynew,1,0,0);
      if (1-fabs(sp=scalprod3d(&x,ynew))<0.1)
      {
        setvec3d(ynew,0,1,0);
        sp=scalprod3d(&x,ynew);
      }
      lincombvec3d(1,ynew,-sp,&x,&y);
    }
    normvec3d(&y);
    vecprod3d(&x,&y,&z);
    transfinv->x=x;
    transfinv->y=y;
    transfinv->z=z;
  } else
  {
    errfunc0("(inv)transfmat3dortnormbas");
      fprintf(erf(),"Norm of the first vector of the new coordinate basis is 0.\n");
    errfunc2();
  }
} else
{
  errfunc0("(inv)transfmat3dortnormbas");
  fprintf(erf(),"One or more of the function arguments are NULL.\n");
  errfunc2();
}
}


void transfmat3dortnormbas(vec3d xnew,vec3d ynew,mat3d transf)
    /* Naredi transformacijsko matriko iz desnosucnega ortonormiranega
    koordinatnega sistema v novi desnosucni ortonormiran sistem, katerega 1.
    bazni vektor je normiran xnew, drugi pa je ortonormiran glede na prvega in
    lezi v podprostoru, ki ga razpenjata xnew in ynew. Matriko shrani v transf;
    ce s to matriko pomnozimo koordinate vektorja v novem koordinatnem sistemu,
    dobimo koordinate vektorja v starem sistemu. xnew mora biti razlicen od NULL
    in nenicelen vektor, medtem ko je lahko ynew tudi neustrezen vektor - lahko
    je NULL ali kolinearen oz. skoraj kolinearen z xnew. Ce je ynew neustrezen,
    funkcija sama izbere drugi bazni vektor; tretji bazni vektor je vektorski
    produkt prvih dveh.
    $A Igor okt01; */
{
invtransfmat3dortnormbas(xnew,ynew,transf);
transpmat3d(transf,transf);
}



void transfmat3d(vec3d xnew,vec3d ynew,vec3d znew,mat3d transf)
    /* Naredi direktno transformacijsko matriko iz desnosucnega ortonormiranega
    sistema v novi koordinatni sistem z baznimi vektorji xnew, ynew in znew.
    Pri tem ni potrebno, da so novi bazni vektorji ortogonalni ali normirani.
    Transformacijsko matriko zapise v transf. Kordinate vektorja v starem
    koordinatnem sistemu dobimo tako, da mnozimo zapis vektorja v novem sistemu
    s to matriko.
    $A Igor okt01; */
{
if (xnew!=NULL && ynew!=NULL && znew!=NULL && transf!=NULL)
{
  transf->x.x=xnew->x;
  transf->y.x=xnew->y;
  transf->z.x=xnew->z;
  transf->x.y=ynew->x;
  transf->y.y=ynew->y;
  transf->z.y=ynew->z;
  transf->x.z=znew->x;
  transf->y.z=znew->y;
  transf->z.z=znew->z;
}
}

void invtransfmat3d(vec3d xnew,vec3d ynew,vec3d znew,mat3d invtransf)
    /* Naredi inverzno transformacijsko matriko iz desnosucnega ortonormiranega
    sistema v novi koordinatni sistem z baznimi vektorji xnew, ynew in znew.
    Pri tem ni potrebno, da so novi bazni vektorji ortogonalni ali normirani.
    Inv. transf.matriko zapise v invtransf. Kordinate vektorja v novem
    koordinatnem sistemu dobimo tako, da mnozimo zapis vektorja v starem
    sistemu s to matriko.
    $A Igor okt01; */
{
if (xnew!=NULL && ynew!=NULL && znew!=NULL && invtransf!=NULL)
{
  invtransf->x.x=xnew->x;
  invtransf->y.x=xnew->y;
  invtransf->z.x=xnew->z;
  invtransf->x.y=ynew->x;
  invtransf->y.y=ynew->y;
  invtransf->z.y=ynew->z;
  invtransf->x.z=znew->x;
  invtransf->y.z=znew->y;
  invtransf->z.z=znew->z;
  invmat3d(invtransf,invtransf);
}
}


void eulertransfmat3d(double theta,double psi,double fi,mat3d transf)
    /* Naredi direktno transformacijsko matriko za zasuk koordinatnega sistema
    v nov koordinatni sistem z Eulerjevimi koti fi, theta in psi.
    Ref: Mat. prir. str. 178; S. Pahor: Uvod v analit. meh., str. 32
    $A Igor okt01; */
{
double c1,c2,c3,s1,s2,s3;
if (transf!=NULL)
{
  c1=cos(theta);  c2=cos(psi);  c3=cos(fi);
  s1=sin(theta);  s2=sin(psi);  s3=sin(fi);
  transf->x.x= c2*c3-c1*s2*s3 ;
  transf->x.y= -c2*s3-c1*s2*c3 ;
  transf->x.z= s1*s2 ;
  transf->y.x= s2*c3+c1*c2*s3 ;
  transf->y.y= -s2*s3+c1*c2*c3 ;
  transf->y.z= -s1*c2 ;
  transf->z.x= s1*s3 ;
  transf->z.y= s1*c3 ;
  transf->z.z= c1 ;
}
}


void eulerinvtransfmat3d(double theta,double psi,double fi,mat3d invtransf)
    /* Naredi inverzno transformacijsko matriko za zasuk koordinatnega sistema
    v nov koordinatni sistem z Eulerjevimi koti fi, theta in psi.
    Ref: Mat. prir. str. 178; S. Pahor: Uvod v analit. meh., str. 32
    $A Igor okt01; */
{
double c1,c2,c3,s1,s2,s3;
if (invtransf!=NULL)
{
  c1=cos(theta);  c2=cos(psi);  c3=cos(fi);
  s1=sin(theta);  s2=sin(psi);  s3=sin(fi);
  invtransf->x.x= c2*c3-c1*s2*s3 ;
  invtransf->y.x= -c2*s3-c1*s2*c3 ;
  invtransf->z.x= s1*s2 ;
  invtransf->x.y= s2*c3+c1*c2*s3 ;
  invtransf->y.y= -s2*s3+c1*c2*c3 ;
  invtransf->z.y= -s1*c2 ;
  invtransf->x.z= s1*s3 ;
  invtransf->y.z= s1*c3 ;
  invtransf->z.z= c1 ;
}
}


void rotvectransfmat3d(vec3d c,double fi,mat3d transf)
    /* Naredi direktno transformacijsko matriko za zasuk koordinatnega sistema
    v nov koordinatni sisem okrog vektorja c za kot fi in jo zapise v transf.
    Zasuk je v pozitivni smeri, ce se gleda z vrha vektorja v.
     POSTOPEK:
    Matriko najprej tvorimo v sistemu, v katerem je os x vzporedna z vektorjem
    c, nato pa to matriko pretransformiramo v zacetni sistem. Ce je R rotacijska
    matrika v sistemu, kjer je os x vzporedna s c, Q pa direktna
    transformacijska matrika iz zacetnega sistema v ta sistem, potem je matrika,
    ki jo iscemo, enaka transf = Q R QT .
    $A Igor nov01; */
{
_mat3d R,Q;
double ds,dc;
if (c!=NULL && transf!=NULL)
{
  ds=sin(fi);
  dc=cos(fi);
  R.x.x= 1 ;
  R.x.y= 0 ;
  R.x.z= 0 ;
  R.y.x= 0 ;
  R.y.y= dc ;
  R.y.z= -ds ;
  R.z.x= 0 ;
  R.z.y= ds ;
  R.z.z= dc ;
  transfmat3dortnormbas(c,NULL,&Q);
  matprod3d(&Q,&R,transf);
  transpmat3d(&Q,&Q);
  matprod3d(transf,&Q,transf);
}
}


void rotvecinvtransfmat3d(vec3d c,double fi,mat3d invtransf)
    /* Naredi inverzno transformacijsko matriko za zasuk koordinatnega sistema
    v nov koordinatni sisem okrog vektorja c za kot fi in jo zapise v invtransf.
    Zasuk je v pozitivni smeri, ce se gleda z vrha vektorja v.
    $A Igor nov01; */
{
if (c!=NULL && invtransf!=NULL)
{
  rotvectransfmat3d(c,fi,invtransf);
  transpmat3d(invtransf,invtransf);
}
}




    /* PODAJANJE PREMIC IN RAVNIN NA RAZLICNE NACINE: */


void line3dp1p2(vec3d p1,vec3d p2,vec3d r,vec3d s)
    /* Izracuna tocko na premici r in smer. vektor premice s iz dveh tock na
    premici p1 in p2.
    $A Igor okt01; */
{
if (p1!=NULL && p2!=NULL && r!=NULL && s!=NULL)
{
  *r=*p1;
  vecdif3d(p2,p1,s);
}
}

void line3p1dn1n2(vec3d p1,vec3d n1,vec3d n2,vec3d r,vec3d s)
    /* Izracuna tocko na premici r in smer. vektor premice s iz tocke na
    premici p1 in in normal na premico n1 in n2.
    $A Igor okt01; */
{
if (p1!=NULL && n1!=NULL && n2!=NULL && r!=NULL && s!=NULL)
{
  *r=*p1;
  vecprod3d(n1,n2,s);
}
}


void plane3dn1d(vec3d n1,double d1,vec3d r,vec3d n)
    /* Izracuna tocko na ravnini r in normalo ravnine n iz normale ravnine n1
    in oddaljenostjo ravnine od izhodisca d1.
    $A Igor okt01; */
{
if (n1!=NULL && r!=NULL && n!=NULL)
{
  multscalvec3d(n1,d1/scalprod3d(n1,n1),r);
  *n=*n1;
}
}


void plane3dp1p2p3(vec3d p1,vec3d p2,vec3d p3,vec3d r,vec3d n)
    /* Izracuna tocko na ravnini r in normalo ravnine n iz treh tock na ravnini
    p1, p2 in p3.
    $A Igor okt01; */
{
if (p1!=NULL && p2!=NULL && p3!=NULL && r!=NULL && n!=NULL)
{
  vecdif3d(p2,p1,r);
  vecdif3d(p3,p1,n);
  vecprod3d(r,n,n);
  *r=*p1;
}
}


void plane3dp1s1s2(vec3d p,vec3d s1,vec3d s2,vec3d r,vec3d n)
    /* Izracuna tocko na ravnini r in normalo ravnine n iz tocke na ravnini p
    ter iz dveh smernih vektorjev premic na ravnini s1 in s2.
    $A Igor okt01; */
{
if (p!=NULL && s1!=NULL && s2!=NULL && r!=NULL && n!=NULL)
{
  vecprod3d(s1,s2,n);
  *r=*p;
}
}



    /* TESTIRANJE FUNKCIJ ZA ANALITICNO GEOMETRIJO V 3D: */


void testgeom3d(void)
    /* Test funkcij za analiticno 3D geometrijo.
    $A Igor okt01; */
{
vec3d p1=NULL,p2=NULL,p3=NULL,p4=NULL,
      r1=NULL,r2=NULL,r3=NULL,r4=NULL,r5=NULL,
      s1=NULL,s2=NULL,s3=NULL,s4=NULL,s5=NULL,
      n1=NULL,n2=NULL,n3=NULL,n4=NULL;
_vec3d x1,x2;
double d1=0,d2=0,d3=0,d4=0;
/* 1. premica: */
r1=getvec3dval(3.5,1.5,0);  s1=getvec3dval(3,1,0);
/* 2. premica: */
r2=getvec3dval(0,5,0);  s2=getvec3dval(1,-2,0);
/* 1. tocka: */
p1=getvec3dval(5,7,0);
/* 2. tocka: */
p2=getvec3dval(3,6,0);
/* Ort. proj. tocke na premico in razdalja med tocko in premico: */
d1=distptline3d(p1,r1,s1);
ortprojptline3d(p1,r1,s1,&x1);
printf("\nDistance between line 1 and point p1: %g\n",d1);
printf("Orthogonal projection of p1 to line 1:\n");
printvec3d(&x1);
printf("\n");
d2=distptline3d(p2,r1,s1);
ortprojptline3d(p2,r1,s1,&x2);
printf("\nDistance between line 1 and point p2: %g\n",d2);
printf("Orthogonal projection of p2 to line 1:\n");
printvec3d(&x2);
printf("\n");
/* Izracun secisca premice in ravnine: */
n1=getvec3dval(-1,3,0);  /* Pravokotnica na s1 - 1. ravnino izpeljemo iz 1. premice */
intsectlineplane3d(r2,s2,r1,n1,&x1);
printf("\nIntersection between line 2 and plane 1:\n");
printvec3d(&x1);
/* Ort. projekcija premice na ravnino: */
ortprojlineplane3d(r2,s2,r1,n1,&x1,&x2);
printf("\nOrt. projection of line 2 on plane 1:\nPoint on projection:\n");
printvec3d(&x1);
printf("Direction vector:\n");
printvec3d(&x2);
/* Ort. projekcija tocke na ravnino: */
p3=getvec3d(); *p3=*p1; p3->z=5;
ortprojptplane3d(p3,r1,n1,&x1);
printf("\nOrt. proj. of point p3 to a plane:\n");
printvec3d(&x1);
/* Razdalja med tocko in ravnino: */
d1=distptplane3d(p3,r1,n1);
printf("Distance between point p3 and plane 1: %g\n",d1);
/* Naredimo ravnino iz 2. premice komp. z r2 premaknemo, norm. je prav. na s1): */
r3=getvec3d(); *r3=*r2; r3->z=7;
n3=getvec3dval(2,1,0);
/* Secisce dveh ravnin: */
d1=intsectplanes3d(r1,n1,r3,n3,&x1,&x2);
printf("\nIntersection between plane 3 and plane 1:\nPoint on intersection:\n");
printvec3d(&x1);
printf("Direction vector of intersecting line:\n");
printvec3d(&x2);
printf("Distance between planes: %g\n",d1);
/* Razdalja in najbljizje tocke pri mimobecnicah: */
/* Naredimo premico, ki je 2. premica zamaknjena za 2 navzgor: */
r4=getvec3d(); *r4=*r2; r4->z=2;
s4=getvec3d(); *s4=*s2;
d1=nearestptlines3d(r1,s1,r4,s4,&x1,&x2);
printf("\nLine 1:\nr:\n");
printvec3d(r1);
printf("s:\n");
printvec3d(s1);
printf("Line4:\nr:\n");
printvec3d(r4);
printf("s:\n");
printvec3d(s4);
printf("\nClosest points on two non-intersecting lines:\nOn line 1:\n");
printvec3d(&x1);
printf("On line 4:\n");
printvec3d(&x2);
printf("Distance between lines: %g\n",d1);
/* Razdalja in najbljizje tocke pri premicah, ki se seceta: */
d1=nearestptlines3d(r1,s1,r2,s2,&x1,&x2);
printf("\nLine 1:\nr:\n");
printvec3d(r1);
printf("s:\n");
printvec3d(s1);
printf("Line2:\nr:\n");
printvec3d(r2);
printf("s:\n");
printvec3d(s2);
printf("\nClosest points on two intersecting lines:\nOn line 1:\n");
printvec3d(&x1);
printf("On line 2:\n");
printvec3d(&x2);
printf("Distance between lines: %g\n",d1);
/* Premici, katerih smerna vektorja sta pravokotna: */
s5=getvec3dval(0,0,10);
r5=getvec3d(); *r5=*p1; r5->z=123;
d1=nearestptlines3d(r1,s1,r5,s5,&x1,&x2);
printf("\nLine 1:\nr:\n");
printvec3d(r1);
printf("s:\n");
printvec3d(s1);
printf("Line5:\nr:\n");
printvec3d(r5);
printf("s:\n");
printvec3d(s5);
printf("\nClosest points on two nonintersecting orthog. lines:\nOn line 1:\n");
printvec3d(&x1);
printf("On line 2:\n");
printvec3d(&x2);
printf("Distance between lines: %g\n",d1);


if (0)
{
  vec3d a,b,c;
  mat3d A,B;
  _vec3d pr1;
  double d1,d2;
  printf("\n\n\n\n");
  printf("Test of mixed product:\n");
  a=getvec3drand(); b=getvec3drand(); c=getvec3drand();
  printf("Vectors a, b and c:\n");
  printvec3d(a); printvec3d(b); printvec3d(c);
  printf("\n");
  vecprod3d(a,b,&pr1);
  d1=scalprod3d(&pr1,c);
  d2=mixprod3d(a,b,c);
  printf("(a x b)*c = %g\n",d1);
  printf("(a,b,c)   = %g\n\n",d2);
  
  printf("\n\n");
  s3=getvec3dval(-2,2,0);
  s4=getvec3dval(2,2,0);
  vecprod3d(s3,s4,s4);
  printf("\nVector product between (-2,2,0) and (2,2,0):\n");
  printvec3d(s4);

  s3=getvec3dval(-2,2,0);
  s4=getvec3dval(0,2,0);
  vecprod3d(s3,s4,s4);
  printf("\nVector product between (-2,2,0) and (2,0,0):\n");
  printvec3d(s4);

  s3=getvec3dval(-2,7,11);
  printf("\nNorm of vector (-2,7,11) is %g.\n",
   vecnorm3d(s3));
   
  /* Testiranje resevanja sistema 2 enacb z 2 neznankama: */
  A=getmat3dval(5,2,222,  3,1,432,  643,6436,654);
  b=getvec3dval(16,9,64365);
  solve2d(A,b,&pr1);
  printf("System of equations:\nSystem matrix:\n");
  printmat3d(A);
  printf("Right-hand vector:\n");
  printvec3d(b);
  printf("Solution:\n");
  printvec3d(&pr1);
  printf("2D Determinant: %g.\n",detmat2d(A));
  /* Testiranje inverz. matrik v 2d: */
  A=getmat3drand();
  B=getmat3d();
  invmat2d(A,B);
  printf("\n2D Inverse:\n");
  printmat3d(B);
  matprod3d(A,B,B);
  printf("\nOriginal matrix:\n");
  printmat3d(A);
  printf("\nProduct of orig. matrix by its 2D inverse:\n");
  printmat3d(B);
  /* Testiranje inverz. matrik v 3d: */
  A=getmat3drand();
  invmat3d(A,B);
  matprod3d(A,B,B);
  printf("\nOriginal matrix:\n");
  printmat3d(A);
  printf("\nProduct of orig. matrix by its 3D inverse:\n");
  printmat3d(B);
}
}


            /****************************/
            /*                          */
            /*  CO-ORDINATE TRANSFORMS  */
            /*                          */
            /****************************/



void polarcoord(double x,double y,double *r,double *fi)
    /* Converts cartesian co-ordinates (x,y) to polar co-ordinates (*r,*fi).
    $A Igor feb03; */
{
*r=sqrt(x*x+y*y);
if (x>0)
  *fi=arctg(y/x);
else if (x<0)
  *fi=ConstPi+arctg(y/x);
else if (y==0)
  *fi=0;
else if (y>0)
  *fi=ConstPi/2;
else if (y<0)
  *fi=3*ConstPi/2;
}

void polartocartescoord(double r,double fi,double *x,double *y)
    /* Converts polar co-ordinates (r,fi) to cartesian co-ordinates (*x,*y).
    $A Igor feb03; */
{
*x=r*cos(fi);
*y=r*sin(fi);
}




            /****************************/
            /*                          */
            /*  1. FAZA TRANSFORMACIJE  */
            /*  (HIERARH. CUB. TRANSF.) */
            /*                          */
            /****************************/







void calccoefcubtr2d(cubtrdata2d tr)
    /* Izracuna koeficiente 2 dim. kubicne transformacije
    $A Igor okt01; */
{
if (tr!=NULL)
{
  tr->calctransfcoef=1;
  tr->a0=tr->r1;
  tr->a1=tr->r2; vecdif3d(&(tr->a1),&(tr->r1),&(tr->a1));
  tr->a2=tr->r4; vecdif3d(&(tr->a2),&(tr->r1),&(tr->a2));
  tr->a12=tr->r1;
   vecsum3d(&(tr->a12),&(tr->r3),&(tr->a12));
   vecdif3d(&(tr->a12),&(tr->r2),&(tr->a12));
   vecdif3d(&(tr->a12),&(tr->r4),&(tr->a12));
  if (prn)
  {
    printf("Transform coefficients:\n");
    printf("a0:  "); printvec3d(&(tr->a0));
    printf("a1:  "); printvec3d(&(tr->a1));
    printf("a2:  "); printvec3d(&(tr->a2));
    printf("a12: "); printvec3d(&(tr->a12));
    printf("----\n");
  }
}
}


void cubtr2d(cubtrdata2d tr,vec3d ro,vec3d r)
    /* Vektor ro v ref. koord. pretransformira v vektor r v fizicnih
    koordinatah z 2D transf. enotske kocke podano s tr. Po potrebi izracuna
    koeficiente transformacije.
    $A Igor okt01; */
{
_vec3d ref;
if (tr!=NULL && ro!=NULL && r!=NULL)
{
  if (! tr->calctransfcoef)
    calccoefcubtr2d(tr);
  *r=tr->a0;
  multscalvec3d(&(tr->a1),ro->x,&ref); vecsum3d(r,&ref,r);
  multscalvec3d(&(tr->a2),ro->y,&ref); vecsum3d(r,&ref,r);
  multscalvec3d(&(tr->a12),ro->x*ro->y,&ref); vecsum3d(r,&ref,r);
}
}



int invcubtr2d(cubtrdata2d tr,vec3d r,vec3d ro1,vec3d ro2)
    /* Vektor r v fizicnem prostoru inverzno preslika z dvodimenzionalno
    preslikavo enotske kocke v ravnini v referencni prostor. Funkcija vrne
    stevilo resitev (0, 1 ali 2), v ro1 in ro2 pa zapise sliki r v referencnem
    sistemu.
    $A Igor okt01; */
{
_vec3d a0,a1,a2,a12;
double A,B,C,D,count1,count2,denom1,denom2,ro1y,ro2y,tolzero=1e-8;
int ret=0;
if (tr!=NULL && ro1!=NULL && ro2!=NULL && r!=NULL)
{
  if (! tr->calctransfcoef)
    calccoefcubtr2d(tr);
  vecdif3d(&(tr->r1),r,&a0);
  a1=tr->a1; a2=tr->a2; a12=tr->a12;
  A=a2.y*a12.x-a12.y*a2.x;
  B=a0.y*a12.x+a1.y*a2.x+a2.y*a1.x-a12.y*a0.x;
  C=a0.y*a1.x-a1.y*a0.x;
  D=B*B-4*A*C;
  if (prn)
    printf("\nSquare equation:\nA=%g, B=%g, C=%g, D=%g, ",A,B,C,D);
  /* Upostevamo toleranco za negativno diskriminanto: */
  /* if (D<0) */
    if (fabs(D/B)<tolzero)
      D=0;
  if (D==0)
  {
    ret=1;
    ro1y=-0.5*B/A;
    count1=-(a0.x+a2.x*ro1y);
    denom1=a1.x+a12.x*ro1y;
    if (fabs(denom1)<=tolzero*fabs(count1)) /* varovalka za nicelni imenovalec */
    {
      --ret;
    } else
    {
      ro1->x=count1/denom1;
      ro1->y=ro1y;
      ro1->z=0;
    }
    /*
    ro1->x=-(a0.x+a2.x*ro1->y)/(a1.x+a12.x*ro1->y);
    */
    if (prn)
      printf("counter=%g, denom.=%g.\n",count1,denom1);
  } else if (D>0)
  {
    ret=2;
    ro1y=0.5*(-B+sqrt(D))/A;
    count1=-(a0.x+a2.x*ro1y);
    denom1=a1.x+a12.x*ro1y;
    
    ro2y=0.5*(-B-sqrt(D))/A;
    count2=-(a0.x+a2.x*ro2y);
    denom2=a1.x+a12.x*ro2y;
    
    if (fabs(denom1)<=tolzero*fabs(count1)) /* varovalka za nicelni imenovalec */
    {
      --ret;
      if (fabs(denom2)<=tolzero*fabs(count2)) /* varovalka za nicelni imenovalec */
      {
        --ret;
      } else
      {
        /* Samo druga resitev kvad. en. da pravi inverz, zapise se v ro1: */
        ro1->x=count2/denom2;
        ro1->y=ro2y;
        ro1->z=0;
      }
    } else
    {
      /* 1. resitev kvad. en. dat pravi inverz, zapiseta se v ro1: */
      ro1->x=count1/denom1;
      ro1->y=ro1y;
      ro1->z=0;
      if (fabs(denom2)<=tolzero*fabs(count2)) /* varovalka za nicelni imenovalec */
      {
        /* 2. resitev kvad. en. ne da pravega inverza: */
        --ret;
      } else
      {
        /* Tudi 2. resitev kvad. en. da pravi inverz, zapise se v ro2: */
        ro2->x=count2/denom2;
        ro2->y=ro2y;
        ro2->z=0;
      }
    }
    /*
    ro1->y=0.5*(-B+sqrt(D))/A;
    ro1->x=-(a0.x+a2.x*ro1->y)/(a1.x+a12.x*ro1->y);
    ro1->z=0;
    ro2->y=0.5*(-B-sqrt(D))/A;
    ro2->x=-(a0.x+a2.x*ro2->y)/(a1.x+a12.x*ro2->y);
    ro2->z=0;
    */
    if (prn)
      printf("counter1=%g, denom.1=%g, counter2=%g, denom.2=%g.\n",
       count1,denom1,count2,denom2);
  }
}
if (prn)
{
  if (!ret)
    printf("No solutions.\n");
  else if (ret==1)
  {
    printf("Unique solution:\n");
    printvec3d(ro1);
  } else
  {
    printf("Two solutions:\n");
    printvec3d(ro1); printvec3d(ro2);
  }
  printf("\n");
}
return ret;
}


void cubtr2dcoordvec(cubtrdata2d tr,vec3d ro,int i,vec3d cv)
    /* V vektor cv zapise i-ti koordinatni vektor preslikave 2D enot. kocke
    pri sliki vektorja ro, t.j. d r(ro) / d ro_i , kjer je r slika ro,
    to_i pa i-t koordinata v referencnem prostoru.
    $A Igor okt01; */
{
if (tr!=NULL && ro!=NULL && cv!=NULL)
{
  if (! tr->calctransfcoef)
    calccoefcubtr2d(tr);
  switch(i)
  {
    case 1:
      lincombvec3d(1,&(tr->a1),ro->y,&(tr->a12),cv);
      return;
    case 2:
      lincombvec3d(1,&(tr->a2),ro->x,&(tr->a12),cv);
      return;
    default:
      errfunc0("cubtr2dcoordvec");
      fprintf(erf(),"Coordinate index %i is out of range (should be 1 or 2).\n",i);
      errfunc2();
      return;
  }
}
}


double invcubtr2dsimp(cubtrdata2d tr,vec3d r,vec3d start,double tol,vec3d ro)
{
_vec3d roprev,rocur,rprev,rcur,rlin,difr,cv1,cv2,cor,corfact;
_mat3d A;
double dist=1.e30,erlin,factor,tollin=0.2;
int i=0,j,maxit=20;
if (tr!=NULL && r!=NULL && start!=NULL && ro!=NULL)
{
  rocur=*start;
  cubtr2d(tr,&rocur,&rcur);
  dist=2*tol;
  while (dist>tol && i<=maxit)
  {
    ++i;
    j=0;
    factor=1;
    roprev=rocur;
    rprev=rcur;
    /* Izracunamo koordinatna vektorja in resimo sistem enacb, ki da linearno
    kombinacijo koordinat, vektorjev, ki ustreza tocki r: */
    cubtr2dcoordvec(tr,&roprev,1,&cv1); /* koordinat. vektor */
    cubtr2dcoordvec(tr,&roprev,2,&cv2);
    vecdif3d(r,&rprev,&difr); /* razlika med r in zadnjim priblizkom */
    A.x=cv1;
    A.y=cv2;
    cor.z=0;
    transpmat3d(&A,&A);
    solve2d(&A,&difr,&cor);
    multscalvec3d(&cor,factor,&corfact); /* korekcija ro */
    /* Izracun popravljenega ro in r: */
    lincombvec3d(1,&roprev,factor,&cor,&rocur);
    vecsum3d(&roprev,&corfact,&rocur);
    cubtr2d(tr,&rocur,&rcur);
    /* Linearno popravljen r in razlika s popravljenim r: */
    lincombvec3d(1,&rprev,factor,&difr,&rlin);
    erlin=distpt3d(&rcur,&rlin)/(factor*vecnorm3d(&difr));
    /* Opomba: erlin je linearno odvisen od factor (tj. absolutna razlika med
    dejanskim novim r in linearno predvidenim je kvadraticn odvisna od factor)
    - to so pokazali rezultati in je treba preveriti se za 3D! */
    dist=distpt3d(&rcur,r);
    if (prn)
    {
      printf("\n\nIteration %i:\n",i);
      printf(" ro_%i: ",i-1,j); printvec3d(&roprev);
      printf("  r_%i: ",i-1,j); printvec3d(&rprev);
      printf("Coordinate vectors:\n");
      printvec3d(&cv1); printvec3d(&cv2);
      printf("Predicted and shortened cor. in ref. sys. (factor %g):\n",factor);
      printvec3d(&cor);
      printvec3d(&corfact); printf("\n");
      printf(" ro_%i_%i: ",i,j); printvec3d(&rocur);
      printf("  r_%i_%i: ",i,j); printvec3d(&rcur);
      printf("Rel. lin. er.: %20g, distance: %15g.\n",erlin,dist);
      
      vecdif3d(&rcur,&rlin,&corfact);
      printf("Difference between linear prediction and actual r:\n");
      printvec3d(&corfact);
      
      if (erlin<=tollin)
        printf("-----------------------------------------------------------");
    }
    while (erlin>tollin && j<=maxit)
    {
      /* Razmerje med razdaljo med linearno napovedanim novim r in dejanskim ter
      med premikom je vecje od tollin, zato zmanjsamo korak in izracunamo novi
      priblizek: */
      ++j;
      factor*=0.5;
       factor=0.99*tollin/erlin; /* Izkoristimo linear. odvisnost erlin od factor */
      multscalvec3d(&cor,factor,&corfact); /* korekcija ro */
      /* Izracun popravljenega ro in r: */
      lincombvec3d(1,&roprev,factor,&cor,&rocur);
      vecsum3d(&roprev,&corfact,&rocur);
      cubtr2d(tr,&rocur,&rcur);
      /* Linearno popravljen r in razlika s popravljenim r: */
      lincombvec3d(1,&rprev,factor,&difr,&rlin);
      erlin=distpt3d(&rcur,&rlin)/(factor*vecnorm3d(&difr));
      dist=distpt3d(&rcur,r);
      if (prn)
      {
        printf("\n\nIteration %i, sub-iteration %i:\n",i,j);
        printf(" ro_%i: ",i-1,j); printvec3d(&roprev);
        printf("  r_%i: ",i-1,j); printvec3d(&rprev);
        printf("Coordinate vectors:\n");
        printvec3d(&cv1); printvec3d(&cv2);
        printf("Predicted and shortened cor. in ref. sys. (factor %g):\n",factor);
        printvec3d(&cor);
        printvec3d(&corfact); printf("\n");
        printf(" ro_%i_%i: ",i,j); printvec3d(&rocur);
        printf("  r_%i_%i: ",i,j); printvec3d(&rcur);
        printf("Rel. lin. er.: %20g, distance: %15g.\n",erlin,dist);

        vecdif3d(&rcur,&rlin,&corfact);
        printf("Difference between linear prediction and actual r:\n");
        printvec3d(&corfact);

        if (erlin<=tollin)
          printf("-----------------------------------------------------------");
      }
    }
  }
  *ro=rocur;
}
return dist;
}






void testfunc(void)
{
}




void testcubtr(void)
    /* Testiranje transformacij enotske kocke
    $A Igor okt01; */
{
_vec3d ro1,ro2,ro3,r1,r2,r3;
_cubtrdata2d tr={0};
int i,n,cont=1;
double d;

if (0)
{
  /* Testiranje transformacij koordinatnega sistema: */
  /* Vrtenje koordinatnega sistema: */
  _vec3d c,a,atr,r,r1,r2,n,p,p1;
  _mat3d transf;
  double fi;
  fi=rad(30);
  setvec3d(&c,0,1,0);
  rotvectransfmat3d(&c,fi,&transf);
  printf("sin(fi): %g\ncos(fi): %g\n",sin(fi),cos(fi));
  printf("\n\nRotation of points for angle %g (%g deg.) around vector:\n",
   fi,st(fi));
  printvec3d(&c);
  printf("\nTransformation matrix:\n");
  printmat3d(&transf);
  
  setvec3d(&a,1,0,0);
  matprodvec3d(&transf,&a,&atr);
  printf("\n\nOriginal vector:\n");
  printvec3d(&a);
  printf("Transformed vector:\n");
  printvec3d(&atr);
  
  setvec3d(&a,0,1,0);
  matprodvec3d(&transf,&a,&atr);
  printf("\n\nOriginal vector:\n");
  printvec3d(&a);
  printf("Transformed vector:\n");
  printvec3d(&atr);
  
  setvec3d(&a,0,0,1);
  matprodvec3d(&transf,&a,&atr);
  printf("\n\nOriginal vector:\n");
  printvec3d(&a);
  printf("Transformed vector:\n");
  printvec3d(&atr);
  
  /* Pravokotna projekcija na ravnino: */
  setvec3d(&r,5,15,20);
  setvec3d(&r1,7.77,2.22,3.33);
  setvec3d(&r2,1.11,8.88,7.77);
  setvec3d(&p,1,2,3);
  vecprod3d(&r1,&r2,&n);
  printf("\n\nOrthogonal projection to a plane in terms of plane def. vectors:\n");
  printf("\nPlane definition:\nPoint on the plane:\n");  printvec3d(&r);
  printf("Direction vectors:\nr1: "); printvec3d(&r1); printf("r2: "); printvec3d(&r2);
  printf("Normal:\n"); printvec3d(&n);
  printf("\nProjected point:\n");  printvec3d(&p);
  p1=p;
  invtransfmat3d(&r1,&r2,&r,&transf);
  matprodvec3d(&transf,&p1,&p1);
  printf("\nPoint in terms of r1, r2 and r:\n"); printvec3d(&p1);
  lincombvec3d(p1.x,&r1,p1.y,&r2,&c);
  lincombvec3d(1,&c,p1.z,&r,&c);
  printf("Test: point in basic coordinate system:\n"); printvec3d(&c);
  p1=p;
  /* Test ortogonalne projekcije s pomocjo transformacije koordinat v sistem, ki
  ga dolocajo bazni vektorji r1, r2 in n=r1xr2 (ki niso ortonormirani): */
  invtransfmat3d(&r1,&r2,&n,&transf);
  vecdif3d(&p1,&r,&p1);
  matprodvec3d(&transf,&p1,&p1);
  printf("\np-r in terms of r1, r2 and n\n"); printvec3d(&p1);
  lincombvec3d(p1.x,&r1,p1.y,&r2,&c);
  vecsum3d(&c,&r,&c);
  printf("Orthogonal projection in basic coordinate system:\n"); printvec3d(&c);
  lincombvec3d(p1.z,&n,1,&c,&c);
  printf("Test: Original point obtained by changing p-r to normal coord. and adding r:\n");
  printvec3d(&c);
  
  ortprojptplane3d(&p,&r,&n,&c);
  printf("\nTest: projection by the projction function:\n");
  printvec3d(&c);
  
  exit(1);
}

while (cont)
{
  /* Definicija preslikave v 2d: */
  setvec3d(&(tr.r1), 0,0,0);
  setvec3d(&(tr.r2), 6,0,0);
  setvec3d(&(tr.r3), 5,6,0);
  setvec3d(&(tr.r4), 2,3,0);

  printf("\n\n\n2D transform:\n");
  printf("\nr1: "); printvec3d(&(tr.r1));
  printf("\nr2: "); printvec3d(&(tr.r2));
  printf("\nr3: "); printvec3d(&(tr.r3));
  printf("\nr4: "); printvec3d(&(tr.r4));


  if (0)
  {
    /* Testiranje preslikave v 2D: */
    setvec3d(&ro1,0,0,0);
    cubtr2d(&tr,&ro1,&r1);
    printf("\nro:\n");
    printvec3d(&ro1);
    printf("r:\n");
    printvec3d(&r1);

    setvec3d(&ro1,1,0,0);
    cubtr2d(&tr,&ro1,&r1);
    printf("\nro:\n");
    printvec3d(&ro1);
    printf("r:\n");
    printvec3d(&r1);

    setvec3d(&ro1,1,1,0);
    cubtr2d(&tr,&ro1,&r1);
    printf("\nro:\n");
    printvec3d(&ro1);
    printf("r:\n");
    printvec3d(&r1);

    setvec3d(&ro1,0,1,0);
    cubtr2d(&tr,&ro1,&r1);
    printf("\nro:\n");
    printvec3d(&ro1);
    printf("r:\n");
    printvec3d(&r1);

    printf("\n------\n");

    setvec3d(&ro1,1,0.5,0);
    cubtr2d(&tr,&ro1,&r1);
    printf("\nro:\n");
    printvec3d(&ro1);
    printf("r:\n");
    printvec3d(&r1);
  }

  if (0)
  {
    /* Testiranje analiticne preslikave v 2D */
    printf("\nInverse transforms - analytical:\n");
    prn=1;

    setvec3d(&r1,0,0,0);
    n=invcubtr2d(&tr,&r1,&ro1,&ro2);
    printf("\nr:\n");
    printvec3d(&r1);
    if (n==0)
      printf("Inverse not defined in this point.\n");
    else if (n==1)
    {
      printf("Unique solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
    } else
    {
      printf("First solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
      printf("Second solution:\n"); printvec3d(&ro2);
      cubtr2d(&tr,&ro2,&r2);
      printf("Tr. of inv.: "); printvec3d(&r2);
    }
    printf("=================================\n");

    setvec3d(&r1,6,0,0);
    n=invcubtr2d(&tr,&r1,&ro1,&ro2);
    printf("\nr:\n");
    printvec3d(&r1);
    if (n==0)
      printf("Inverse not defined in this point.\n");
    else if (n==1)
    {
      printf("Unique solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
    } else
    {
      printf("First solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
      printf("Second solution:\n"); printvec3d(&ro2);
      cubtr2d(&tr,&ro2,&r2);
      printf("Tr. of inv.: "); printvec3d(&r2);
    }
    printf("=================================\n");

    setvec3d(&r1,5,6,0);
    n=invcubtr2d(&tr,&r1,&ro1,&ro2);
    printf("\nr:\n");
    printvec3d(&r1);
    if (n==0)
      printf("Inverse not defined in this point.\n");
    else if (n==1)
    {
      printf("Unique solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
    } else
    {
      printf("First solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
      printf("Second solution:\n"); printvec3d(&ro2);
      cubtr2d(&tr,&ro2,&r2);
      printf("Tr. of inv.: "); printvec3d(&r2);
    }
    printf("=================================\n");

    setvec3d(&r1,2,3,0);
    n=invcubtr2d(&tr,&r1,&ro1,&ro2);
    printf("\nr:\n");
    printvec3d(&r1);
    if (n==0)
      printf("Inverse not defined in this point.\n");
    else if (n==1)
    {
      printf("Unique solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
    } else
    {
      printf("First solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
      printf("Second solution:\n"); printvec3d(&ro2);
      cubtr2d(&tr,&ro2,&r2);
      printf("Tr. of inv.: "); printvec3d(&r2);
    }
    printf("=================================\n");

    setvec3d(&r1,4,2,0);
    n=invcubtr2d(&tr,&r1,&ro1,&ro2);
    printf("\nr:\n");
    printvec3d(&r1);
    if (n==0)
      printf("Inverse not defined in this point.\n");
    else if (n==1)
    {
      printf("Unique solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
    } else
    {
      printf("First solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
      printf("Second solution:\n"); printvec3d(&ro2);
      cubtr2d(&tr,&ro2,&r2);
      printf("Tr. of inv.: "); printvec3d(&r2);
    }
    printf("=================================\n");

    setvec3d(&r1,2,1,0);
    n=invcubtr2d(&tr,&r1,&ro1,&ro2);
    printf("\nr:\n");
    printvec3d(&r1);
    if (n==0)
      printf("Inverse not defined in this point.\n");
    else if (n==1)
    {
      printf("Unique solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
    } else
    {
      printf("First solution:\n"); printvec3d(&ro1);
      cubtr2d(&tr,&ro1,&r1);
      printf("Tr. of inv.: "); printvec3d(&r1);
      printf("Second solution:\n"); printvec3d(&ro2);
      cubtr2d(&tr,&ro2,&r2);
      printf("Tr. of inv.: "); printvec3d(&r2);
    }
    printf("=================================\n");

  }


  if (0)
  {
    printf("\n\n\nINVERSE transforms - NUMERICAL:\n");

    setvec3d(&r1,0,0,0);
    setvec3d(&ro1,0.5,0.5,0);
    d=invcubtr2dsimp(&tr,&r1,&ro1,1e-8,&ro1);
    printf("\n\nr:\n");
    printvec3d(&r1);
    printf("Inverse ( distance = %g ):\n",d);
    printvec3d(&ro1);
    cubtr2d(&tr,&ro1,&r1);
    printf("Tr. of inv.: "); printvec3d(&r1);
    printf("=================================\n");

    setvec3d(&r1,6,0,0);
    setvec3d(&ro1,0.5,0.5,0);
    d=invcubtr2dsimp(&tr,&r1,&ro1,1e-8,&ro1);
    printf("\n\nr:\n");
    printvec3d(&r1);
    printf("Inverse ( distance = %g ):\n",d);
    printvec3d(&ro1);
    cubtr2d(&tr,&ro1,&r1);
    printf("Tr. of inv.: "); printvec3d(&r1);
    printf("=================================\n");

    setvec3d(&r1,5,6,0);
    setvec3d(&ro1,0.5,0.5,0);
    d=invcubtr2dsimp(&tr,&r1,&ro1,1e-8,&ro1);
    printf("\n\nr:\n");
    printvec3d(&r1);
    printf("Inverse ( distance = %g ):\n",d);
    printvec3d(&ro1);
    cubtr2d(&tr,&ro1,&r1);
    printf("Tr. of inv.: "); printvec3d(&r1);
    printf("=================================\n");

    setvec3d(&r1,2,3,0);
    setvec3d(&ro1,0.5,0.5,0);
    d=invcubtr2dsimp(&tr,&r1,&ro1,1e-8,&ro1);
    printf("\n\nr:\n");
    printvec3d(&r1);
    printf("Inverse ( distance = %g ):\n",d);
    printvec3d(&ro1);
    cubtr2d(&tr,&ro1,&r1);
    printf("Tr. of inv.: "); printvec3d(&r1);
    printf("=================================\n");

    setvec3d(&r1,5,5,0);
    setvec3d(&ro1,0.5,0.5,0);
    d=invcubtr2dsimp(&tr,&r1,&ro1,1e-8,&ro1);
    printf("\n\nr:\n");
    printvec3d(&r1);
    printf("Inverse ( distance = %g ):\n",d);
    printvec3d(&ro1);
    cubtr2d(&tr,&ro1,&r1);
    printf("Tr. of inv.: "); printvec3d(&r1);
    printf("=================================\n");
  }

  if (0)
  {
    /* Testiranje inverzne transformacije na izbrani premici v fizicnem
    prostoru: */
    _vec3d rfrom,rto,rdif;
    int num,i;
    num=10;
    setvec3d(&rfrom,4,4,0);
    setvec3d(&rto,4,8.5,0);
    vecdif3d(&rto,&rfrom,&rdif);
    for (i=0;i<num;++i)
    {
      /* Izracun naslednje tocke, pri kateri se izracuna inverzna
      transformacija: */
      lincombvec3d(1,&rfrom,(double) i/((double)(num-1)),&rdif,&r1);
      if (1)
      {
        prn=0;
        /* Analiticen izracun inverzne transformacije: */
        n=invcubtr2d(&tr,&r1,&ro1,&ro2);
        printf("\nr:\n");
        printvec3d(&r1);
        printf("\n\nInverse transform - analytical:\n");
        if (n==0)
          printf("Inverse not defined in this point.\n");
        else if (n==1)
        {
          printf("Unique solution:\n>>>>"); printvec3d(&ro1);
          /*
          cubtr2d(&tr,&ro1,&r2);
          printf("Tr. of inv.: "); printvec3d(&r2);
          */
        } else
        {
          printf("First solution:\n>>>>"); printvec3d(&ro1);
          /*
          cubtr2d(&tr,&ro1,&r2);
          printf("Tr. of inv.: "); printvec3d(&r2);
          */
          printf("Second solution:\n>>>>"); printvec3d(&ro2);
          /*
          cubtr2d(&tr,&ro2,&r2);
          printf("Tr. of inv.: "); printvec3d(&r2);
          */
        }
      }
      if (1)
      {
        prn=0;
        /* Numericen izracun inverzne transformacije: */
        setvec3d(&ro1,0.5,0.5,0);
        d=invcubtr2dsimp(&tr,&r1,&ro1,1e-8,&ro1);
        printf("\nInverse transform - numerical:\n");
        printf("r:\n");
        printvec3d(&r1);
        printf("Inverse ( distance = %g ):\n>>>>",d);
        printvec3d(&ro1);
        cubtr2d(&tr,&ro1,&r2);
        printf("Tr. of inv.: "); printvec3d(&r2);
      }
        printf("=================================\n");
    }
  }


  if (0)
  {
    /* Testiranje inverzne transformacije na dvodimenzionalni mrezi v fizicnem
    prostoru: */
    _vec3d rfrom,rto1,rto2,rdif1,rdif2;
    int num1,num2,i,j;
    num1=10;
    num2=17;
    setvec3d(&rfrom,-1,-1,0);
    setvec3d(&rto1,8,-1,0);
    setvec3d(&rto2,-1,15,0);
    vecdif3d(&rto1,&rfrom,&rdif1);
    vecdif3d(&rto2,&rfrom,&rdif2);
    for (i=0;i<num1;++i)
    {
      printf("\n############################# Row %i/%i of 2D table of results\n",i,num1);
      for (j=0;j<num2;++j)
      {
        /* Izracun naslednje tocke, pri kateri se izracuna inverzna
        transformacija: */
        lincombvec3d(1,&rfrom,(double) i/((double)(num1-1)),&rdif1,&r1);
        lincombvec3d(1,&r1,(double) j/((double)(num2-1)),&rdif2,&r1);
        if (1)
        {
          prn=0;
          /* Analiticen izracun inverzne transformacije: */
          n=invcubtr2d(&tr,&r1,&ro1,&ro2);
          printf("\nr:\n");
          printvec3d(&r1);
          printf("\n\nInverse transform - analytical:\n");
          if (n==0)
            printf("Inverse not defined in this point.\n");
          else if (n==1)
          {
            printf("Unique solution:\n>>>>"); printvec3d(&ro1);
            /*
            cubtr2d(&tr,&ro1,&r2);
            printf("Tr. of inv.: "); printvec3d(&r2);
            */
          } else
          {
            printf("First solution:\n>>>>"); printvec3d(&ro1);
            /*
            cubtr2d(&tr,&ro1,&r2);
            printf("Tr. of inv.: "); printvec3d(&r2);
            */
            printf("Second solution:\n>>>>"); printvec3d(&ro2);
            /*
            cubtr2d(&tr,&ro2,&r2);
            printf("Tr. of inv.: "); printvec3d(&r2);
            */
          }
        }
        if (1)
        {
          prn=0;
          /* Numericen izracun inverzne transformacije: */
          setvec3d(&ro1,0.5,0.5,0);
          d=invcubtr2dsimp(&tr,&r1,&ro1,1e-8,&ro1);
          printf("\nInverse transform - numerical:\n");
          printf("r:\n");
          printvec3d(&r1);
          printf("Inverse ( distance = %g ):\n>>>>",d);
          printvec3d(&ro1);
          cubtr2d(&tr,&ro1,&r2);
          printf("Tr. of inv.: "); printvec3d(&r2);
        }
          printf("=================================\n");
      }
    }
  }



  if (1)
  {
    /* Testiranje inverzne transformacije na izbrani daljici v referencnem
    prostoru: */
    _vec3d rofrom,roto,rodif,ro,ro0,r;
    int num,i;
    double tol=1e-8,tolsol=1e3*tol;
    num=21;
    setvec3d(&rofrom,0.5,0,0);
    setvec3d(&roto,0.5,2,0);
    printf("\n\nTest of inverse 2d unit cube transforms on a line in the reference space:\n");
    if (1)
    {
      /* Interaktivno branje parametrov: */
      printf("\nInput the starting vector in ref. space!\n");
      readvec3d(&rofrom);
      printf("\nInput the end vector in ref. space!\n");
      readvec3d(&roto);
      printf("\nNumber of points: "); readint(&num);
    }
    vecdif3d(&roto,&rofrom,&rodif);
    for (i=0;i<num;++i)
    {
      /* Izracun naslednje tocke, pri kateri se izracuna inverzna
      transformacija: */
      lincombvec3d(1,&rofrom,(double) i/((double)(num-1)),&rodif,&ro);
      cubtr2d(&tr,&ro,&r);
      printf("\nro: ");
      printvec3d(&ro);
      printf("\nr:  ");
      printvec3d(&r);
      if (1)
      {
        prn=1;
        /* Analiticen izracun inverzne transformacije: */
        n=invcubtr2d(&tr,&r,&ro1,&ro2);
        printf("\n\nInverse transform - analytical:\n");
        if (n==0)
          printf("Inverse not defined in this point.\n");
        else if (n==1)
        {
          printf("Unique solution:\n>>>>"); printvec3d(&ro1);
          /*
          cubtr2d(&tr,&ro1,&r2);
          printf("Tr. of inv.: "); printvec3d(&r2);
          */
        } else
        {
          printf("First solution:\n>>>>"); printvec3d(&ro1);
          /*
          cubtr2d(&tr,&ro1,&r2);
          printf("Tr. of inv.: "); printvec3d(&r2);
          */
          printf("Second solution:\n>>>>"); printvec3d(&ro2);
          /*
          cubtr2d(&tr,&ro2,&r2);
          printf("Tr. of inv.: "); printvec3d(&r2);
          */
        }
      }
      if (1)
      {
        prn=0;
        /* Numericen izracun inverzne transformacije: */
        setvec3d(&ro0,0.5,0.5,0); /* zacet. prib. */
        d=invcubtr2dsimp(&tr,&r,&ro0,tol,&ro3);
        printf("\nInverse transform - numerical:\n");
        /*
        printf("r:    ");
        printvec3d(&r);
        */
        printf("Inverse ( distance = %g ):\n>>>>",d);
        printvec3d(&ro3);
        cubtr2d(&tr,&ro3,&r3);
        printf("Tr. of inv.: "); printvec3d(&r3);
        if ((d=distpt3d(&ro3,&ro1))>tolsol)
          printf("\nWARNING: distance between 1. analyt. and num. sol. (%g) is more than %g.\n",
           d,tolsol);
        if ((d=distpt3d(&ro3,&ro))>tolsol)
          printf("\nERROR: distance between real and num. sol. (%g) is more than %g.\n",
           d,tolsol);
      }
        printf("\n%i =================================\n",i);
    }
  }


  if (0)
  {
    /* Testiranje inverzne transformacije na dvodimenzionalni mrezi v referencnem
    prostoru: */
    _vec3d rofrom,roto1,roto2,rodif1,rodif2,ro,ro0,r;
    int num1,num2,i,j;
    double tol=1e-8,tolsol=1e3*tol;
    num1=10;
    num2=17;
    setvec3d(&rofrom,-1,-1,0);
    setvec3d(&roto1,1,-1,0);
    setvec3d(&roto2,-1,1,0);
    if (1)
    {
      /* Interaktivno branje parametrov: */
      printf("\nInput the starting vector in ref. space!\n");
      readvec3d(&rofrom);
      printf("\nInput the first end vector in ref. space!\n");
      readvec3d(&roto1);
      printf("\nInput the second end vector in ref. space!\n");
      readvec3d(&roto2);
      printf("\nNumber of points in 1. dir.: "); readint(&num1);
      printf("\nNumber of points in 2. dir.: "); readint(&num2);
    }
    vecdif3d(&roto1,&rofrom,&rodif1);
    vecdif3d(&roto2,&rofrom,&rodif2);
    for (i=0;i<num1;++i)
    {
      printf("\n############################# Row %i/%i of 2D table of results\n",
       i,num1);
      for (j=0;j<num2;++j)
      {
        /* Izracun naslednje tocke, pri kateri se izracuna inverzna
        transformacija: */
        lincombvec3d(1,&rofrom,(double) i/((double)(num1-1)),&rodif1,&ro);
        lincombvec3d(1,&ro,(double) j/((double)(num2-1)),&rodif2,&ro);
         cubtr2d(&tr,&ro,&r);
        printf("\nro:\n");
        printvec3d(&ro);
        printf("\nr:\n");
        printvec3d(&r);
        if (1)
        {
          prn=0;
          /* Analiticen izracun inverzne transformacije: */
          n=invcubtr2d(&tr,&r,&ro1,&ro2);
          printf("\n\nInverse transform - analytical:\n");
          if (n==0)
            printf("Inverse not defined in this point.\n");
          else if (n==1)
          {
            printf("Unique solution:\n>>>>"); printvec3d(&ro1);
            /*
            cubtr2d(&tr,&ro1,&r2);
            printf("Tr. of inv.: "); printvec3d(&r2);
            */
          } else
          {
            printf("First solution:\n>>>>"); printvec3d(&ro1);
            /*
            cubtr2d(&tr,&ro1,&r2);
            printf("Tr. of inv.: "); printvec3d(&r2);
            */
            printf("Second solution:\n>>>>"); printvec3d(&ro2);
            /*
            cubtr2d(&tr,&ro2,&r2);
            printf("Tr. of inv.: "); printvec3d(&r2);
            */
          }
        }
        if (1)
        {
          prn=0;
          /* Numericen izracun inverzne transformacije: */
          setvec3d(&ro0,0.5,0.5,0);
          d=invcubtr2dsimp(&tr,&r,&ro0,tol,&ro3);
          printf("\nInverse transform - numerical:\n");
          printf("r:\n");
          printvec3d(&r);
          printf("Inverse ( distance = %g ):\n>>>>",d);
          printvec3d(&ro3);
          cubtr2d(&tr,&ro3,&r3);
          printf("Tr. of inv.: "); printvec3d(&r3);
          if ((d=distpt3d(&ro3,&ro1))>tolsol)
            printf("\nWARNING: distance between 1. analyt. and num. sol. (%g) is more than %g.\n",
             d,tolsol);
          if ((d=distpt3d(&ro3,&ro))>tolsol)
            printf("\nERROR: distance between real and num. sol. (%g) is more than %g.\n",
             d,tolsol);
        }
          printf("\n(%i,%i) =================================\n",i,j);
      }
    }
  }
  
  
  if (0)
  {
    /* Casovni testi: */
    double t1,t2,ct1,ct2;
    int num=100000;
    printf("\n\n\nSpeed test:\n");
    t1=absolutetime();
    ct1=cputime();
    prn=0;
    for (i=1;i<=num;++i)
    {
      if (0)
      {
      setvec3d(&r1,5,5,0);
      setvec3d(&ro1,0.5,0.5,0);
      d=invcubtr2dsimp(&tr,&r1,&ro1,1e-8,&ro1);
      /*
      n=invcubtr2d(&tr,&r1,&ro1,&ro2); d=0;
      */
      cubtr2d(&tr,&ro1,&r2);
      }
    }
    t2=absolutetime();
    ct2=cputime();
    printf("\n\nr:\n");
    printvec3d(&r1);
    printf("Inverse ( distance = %g ):\n",d);
    printvec3d(&ro1);
    printf("Tr. of inv.: "); printvec3d(&r2);

    printf("\nTime necessary for %i inverse transforms is %g s (CPU time %g s).\n\n\n",
     num,t2-t1,ct2-ct1);
  }
  
  
  printf("\n\n\n\nOnce more (0/1)? "); readint(&cont);
}
}












