/* Switch on execution tracing:
#define EXTRACE  
*/

#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>



#include <mtypes.h>
#include <er.h>
#include <vec.h>
#include <mat.h>
#include <st.h>
#include <rf.h>
#include <matrixop.h>
#include <mtime.h>
#include <geom.h>
#include <varop.h>
#include <rand.h>
#include <strop.h>
#include <st.h>
#include <fop.h>
#include <globut.h>
#include <optbas.h>

#include <itk.h>

#include <invfeap.h>

#include <invfeap.h>


#include <optbas.h>
#include <optpt.h>
#include <optminbas.h>
#include <opttest.h>


unsigned long binomialint0(int n,int k);
unsigned long binomialint(int n,int k);


double doublefactorial(int n);
double doublemultifactorial(int n,int m);
double doublebinomial(int n,int k);
double doublebinomial0(int n,int k);
double gammacoef(int n);
double doublerisingfactorial(double x,int n);
double doublefallingfactorial(double x,int n);
double num_k_cycles_permgrp(int r,int n,int k);
double gamma(double z);
double bigamma(double z);
double trigamma(double z);
double polygamma(double z,int r);

double bernoullinum(int n);
double lngammaplus(double z);
double dergamma(double z);
double digamma(double z);
double der2gamma(double z);
double digamma(double z);



void testfactorial(void)
{
int i,k=0,m=0,n=0,num=0;
double t0=0,t1=0,t2=0,t3=0,ct0=0,ct1=0,ct2=0,ct3=0;
unsigned long facul;
printf("\nMax. unsigned long int.: %lu.\n",ULONG_MAX);
if (0)
{
  for (i=1;i<=15;++i)
  {
    facul=factorialint0(i);
    printf("%i ! = %lu.\n",i,facul);
  }
  for (i=1;i<=40;++i)
  {
    printf("%i ! = %lu (= %.15g).\n",i,factorialint0(i),doublefactorial(i));
  }
}
if (0) 
{
  for (m=1;m<=4;++m)
  {
    printf("\n%i-th multifactirials:\n",m);
    for (i=1;i<=30;++i)
      printf("!(%i,%i) = %lu.\n",i,m,multifactorialint0(i,m));
  }
  m=2;
  for (i=1;i<=40;++i)
      printf("!(%i,%i) = %lu (= %.15g).\n",i,m,
        multifactorialint0(i,m),doublemultifactorial(i,m));
}
if (0)
{
  int num; double x=0.;
  printf("Binomial coefficients:\n");
  printf("Pascal's triangle:\n");
  num=12;
  for (n=0;n<=num;++n)
  {
    printf("%5i: %*s",n,2*(num-n),"");
    for (k=0;k<=n;++k)
      printf("%-4i",binomialint(n,k));
    printf("\n");
  }
  n=10;
  printf("Binomial coefficients C(%i,k): \n",n);
  for (k=0;k<=n;++k)
    printf("%i:%lu ",k,binomialint0(n,k));
  printf("\n\n");
  n=-1; k=0;
  printf("C(%i,%i) = %lu.\n",n,k,binomialint(n,k));
  /* Test of larger binomial coefficients: */
  /*
  printf("Input n and k to calculate Binom. coef. C(n,k) ((1,1) to exit)!\n");
  Printf("Input (1,1) to exit!\n");
  n=k=1;
  do 
  {
    printf("n: "); readint(&n);
    printf("k: "); readint(&k);
    printf("C(%i,%i): %li ; = %.15g\n",n,k,binomialint(n,k),doublebinomial(n,k));
  } while (n!=1 || k!=1);
  */
  n=10;
  for (k=10;k<=16;++k)
    printf("C(%i,%i) = %lu.\n",n,k,binomialint(n,k));
  for (k=0;k<=n;++k)
    printf("C(%i,%i) = %lu ( = %.15g ), er.: %g\n",
      n,k,binomialint0(n,k),doublebinomial(n,k),
         doublebinomial(n,k)-round(doublebinomial0(n,k)));
  /* Speed test: */
  num=1000;
  /* n=20; assume n from before */
  printf("\n\nSpeed tests:\n");
  printf("Calculation of INTEGER binomial coef. (%i,k) %i times:\n",n,num);
  t0=absolutetime();  ct0=cputime();
  for (i=1;i<=num;++i)
    for (k=0;k<=n;++k)
      x=binomialint0(n,k);
  t1=absolutetime();  ct1=cputime();
  printf("Time: %g (CPU: %g).\n",t1-t0,ct1-ct0);
  
  printf("\n\nSpeed tests:\n");
  printf("Calculation of binomial coef. (%i,k) %i times:\n",n,num);
  printf("\nDouble precision calculation of factorials:\n");
  t0=absolutetime();  ct0=cputime();
  for (i=1;i<=num;++i)
    for (k=0;k<=n;++k)
      x=doublebinomial(n,k);
  t1=absolutetime();  ct1=cputime();
  printf("Time: %g (CPU: %g).\n",t1-t0,ct1-ct0);
}
if (1)
{
  /* Tests for the Gamma function: */
  int r,k,n,i,j;
  double x=0.0,res;
  if (0)
  {
    printf("Falling factorial:\n");
    for (i=-2;i<=5;++i)
    {
      printf("\nFalling factorials of %i:\n",i);
      for (j=-4;j<=i+5;++j)
        printf("f.f.(%i,%i): %g \n",i,j,doublefallingfactorial(i,j));
      printf("\n");
    }
    printf("\n\n\nRising factorial:\n");
    for (i=-2;i<=5;++i)
    {
      printf("\nRising factorials of %i:\n",i);
      for (j=-4;j<=i+5;++j)
        printf("r.f.(%i,%i): %g \n",i,j,doublerisingfactorial(i,j));
      printf("\n");
    }
  }
  
  if (0)
  {
    printf("\n");
    printf("Num. permutation cycles:\n");
    for (r=1;r<=5;++r)
    {
      for (n=1;n<=10;++n)
      {
        printf("(r=%i,n=%i):\n",r,n);
        for (k=1;k<=10;++k)
          printf("%g ",num_k_cycles_permgrp(r,n,k));
        printf("\n");
      }
      printf("\n\n");
    }
    printf("\nReciprocials of Gamma coefficients: \n");
    for(i=0;i<=5;++i)
      printf("%i: %g  ",i,1/gammacoef(i));
    printf("\nGamma coefficients: \n");
    for(i=0;i<=5;++i)
      printf("%i: %g  ",i,(gammacoef(i)));
    printf("\n\n");
    /*
    for (i=1;i<=3;++i)
    {
      x=0.5+i;
      printf("gammma(%g): %g.\n",x,gamma(x));
    }
    */
    printf("\n\nBernoulli numbers:\n");
    for (i=0;i<=40;++i)
      printf("B(%i) = %g .\n",i,bernoullinum(i));
    /*
    for (i=0;i<=70;++i)
      printf("B(%i) = %g .\n",i,bernoullinum(i));
    */

    for (i=1;i<=10;++i)
    {
      x=lngammaplus(i);
      printf("gamma(%i): %g, dif. fact.: %g\n",
        i,exp(x),exp(x)-doublefactorial(i-1));
    }
    i=20;
    x=lngammaplus(i);
    printf("gamma(%i): %g, dif. fact.: %g\n",
    i,exp(x),exp(x)-doublefactorial(i-1));
    i=30;
    x=lngammaplus(i);
    printf("gamma(%i): %g, dif. fact.: %g\n",
    i,exp(x),exp(x)-doublefactorial(i-1));
    i=50;
    x=lngammaplus(i);
    printf("gamma(%i): %g, dif. fact.: %g\n",
    i,exp(x),exp(x)-doublefactorial(i-1));
  }

  /* Test of gamma functions: */
  printf("Input x and to calculate Gamma(x) and its derivative (0 to exit)!\n");
  printf("Input 0 to exit!\n");
  n=k=1;
  do 
  {
    printf("x: "); readdouble(&x);
    printf("Gamma(%g) = %.10g, der. = %g\n",x,gamma(x),dergamma(x));
  } while (x!=0);
  if (1)
  {
    printf("Table of the polygamma function: \n");
    for (i=1;i<=120;i=i+1)
    {
      x=-1.01 + 0.1*i;
      printf("x: %g, PG(x,1) = %g, PG(x,2) = %g, PG(x,3) = %g\n",
        x,polygamma(x,1),polygamma(x,2),polygamma(x,3));
    }
  }
  if (0)
  {
    printf("Table of the gamma function and its derivatives: \n");
    for (i=1;i<=100;i=i+1)
    {
      x=-1.01 + 0.1*i;
      printf("x: %g, G(x) = %g, dG/dx = %g, d^2G/dx^2 = %g\n",
        x,gamma(x),dergamma(x),der2gamma(x));
    }
  }
  
  /* Speed test: */
  num=10000;
  x=0.1;
  printf("\n\nSpeed tests:\n");
  printf("Calculation of Gamma(%g) %i times:\n",x,num);
  t0=absolutetime();  ct0=cputime();
  for (i=1;i<=num;++i)
    for (k=0;k<=n;++k)
      res=gamma(x);
  t1=absolutetime();  ct1=cputime();
  printf("Time: %g (CPU: %g).\n",t1-t0,ct1-ct0);
  printf("Calculation of derivative of Gamma(%g) %i times:\n",x,num);
  t0=absolutetime();  ct0=cputime();
  for (i=1;i<=num;++i)
    for (k=0;k<=n;++k)
      res=dergamma(x);
  t1=absolutetime();  ct1=cputime();
  printf("Time: %g (CPU: %g).\n",t1-t0,ct1-ct0);

}
}


void recighomeloc(stack list);
void recighomemarkloc(stack list);
char *readighomelocmark(char *filename);
void markighomeid(char *path);
void markighomeloc(char *path,int num);
char * locateighomefrommarks();
char *locateighomeonfilesys(void);


static int i0=0,i10,i20,i30,i1,i2,i3,num=0;

void proc0(void *ptr)
{
TRIN(0,1,"proc0","Beginning of proc0")
TRDOPR(0,1,NULL,NULL,
  fprintf(trf(),"Thread ID for proc0: %i.\n",getthreadid); fflush(trf()); )
printf("i0: %i\n",i0);
++num;
if (num<=5)
  i0=createthread(proc0,"T0");
tcl_sleep(30);
printf("This is the 0. thread, arg=%s, ID=%i.\n\n",ptr,getthreadid());
tcl_sleep(5000);
printf("This is the 0. thread, ID=%i.\n\n",getthreadid());
TROUT(0,1,"proc0","End of proc0")
}

void proc10(void *ptr)
{
TRIN(10,1,"proc10","Beginning of proc10")
TRDOPR(10,1,NULL,NULL,
  fprintf(trf(),"Thread ID for proc10: %i.\n",getthreadid); fflush(trf()); )
tcl_sleep(40);
printf("This is the 10. thread, arg=%s, ID=%i.\n\n",ptr,getthreadid());
tcl_sleep(5000);
printf("This is the 10. thread, ID=%i.\n\n",getthreadid());
TROUT(10,1,"proc10","End of proc10")
}

void proc20(void *ptr)
{
TRIN(20,1,"proc20","Beginning of proc20")
TRDOPR(20,1,NULL,NULL,
  fprintf(trf(),"Thread ID for proc20: %i.\n",getthreadid); fflush(trf()); )
tcl_sleep(40);
printf("This is the 20. thread, arg=%s, ID=%i.\n\n",ptr,getthreadid());
tcl_sleep(5000);
printf("This is the 20. thread, ID=%i.\n\n",getthreadid());
TROUT(20,1,"proc20","End of proc20")
}

void proc30(void *ptr)
{
TRIN(30,1,"proc30","Beginning of proc30")
TRDOPR(30,1,NULL,NULL,
  fprintf(trf(),"Thread ID for proc30: %i.\n",getthreadid); fflush(trf()); )
tcl_sleep(40);
printf("This is the 30. thread, arg=%s, ID=%i.\n\n",ptr,getthreadid());
tcl_sleep(5000);
printf("This is the 30. thread, ID=%i.\n\n",getthreadid());
TROUT(30,1,"proc30","End of proc30")
}

void proc1(void *ptr)
{
TRIN(1,1,"proc1","beginning of proc1")
TRDOPR(1,1,NULL,NULL,
  fprintf(trf(),"Thread ID for proc1: %i.\n",getthreadid); fflush(trf()); )
i0=createthread(proc0,"T0");
TRPT(1,2,"proc1","after creating thread with proc0")
i10=createthread(proc10,"T10");
TRPT(1,3,"proc1","after creating thread with proc10, before sleep(70)")
tcl_sleep(70);
TRPT(1,4,"proc1","after sleep(70)")
printf("This is the 1. thread, arg=%s, ID=%i.\n\n",ptr,getthreadid());
tcl_sleep(5000);
TRPT(1,5,"proc1","after sleep(5000)")
printf("This is the 1. thread, ID=%i.\n\n",getthreadid());
TROUT(1,1,"proc1","end of proc1")
}


void proc2(void *ptr)
{
TRIN(2,1,"proc2","beginning of proc2")
TRDOPR(2,1,NULL,NULL,
  fprintf(trf(),"Thread ID for proc2: %i.\n",getthreadid); fflush(trf()); )
i20=createthread(proc20,"T20");
TRPT(2,2,"proc2","after creating thread with proc20")
tcl_sleep(80);
TRPT(2,2,"proc2","after tcl_sleep(80)")
printf("This is the 2. thread, arg=%s, ID=%i.\n\n",ptr,getthreadid());
tcl_sleep(5000);
TRPT(2,4,"proc2","after tcl_sleep(500)")
printf("This is the 2. thread, ID=%i.\n\n",getthreadid());
TROUT(2,1,"proc2","end of proc2")
}


void proc3(void *ptr)
{
TRIN(3,1,"proc3","Beginning of proc3")
TRDOPR(3,1,NULL,NULL,
  fprintf(trf(),"Thread ID for proc3: %i.\n",getthreadid); fflush(trf()); )
i30=createthread(proc30,"T30");
tcl_sleep(90);
TRPT(3,2,"proc3","After tcl_sleep(90)")
printf("This is the 3. thread, arg=%s, ID=%i.\n\n",ptr,getthreadid());
tcl_sleep(5000);
TRPT(3,2,"proc3","After tcl_sleep(5000)")
printf("This is the 3. thread, ID=%i.\n\n",getthreadid());
TROUT(3,1,"proc3","End of proc3")
}


/*
#undef FEAPINT
*/


void ttt(void)
{

  struct complex {
    double re;
    double im;
  } c1, c2;

  struct complex *ptr1,*ptr2;
  double x1,y1,x2,y2;

  c1.re=1.1;
  c1.im=1.2;
  c2.re=2.1;
  c2.im=2.2;

  ptr1=&c1;
  ptr2=&c2;

  x1=c1.re;
  y1=ptr1->im;
  x2=(*ptr2).re;
  y2=ptr2->im;

  printf("\n\nx1=%g, y1=%g, x2=%g, y2=%g\n\n",x1,y1,x2,y2);


}



main()
{


#if 0
  if (1)
  {
    testoptminbas();
    if (0) testancombpenalty();
    if (0) testancomb();
    exit(0);
  }

  if (0)
  {
    testopttest();
    exit(0);
  }

  if (0)
  {
    testoptpt();
    exit(0);
  }
#endif





if (0)
{
  testoptbas();
  exit(0);
}

if (0)
{
  testfactorial();
  exit(0);
}

if (0)
{
  testrand();
  exit(0);
}

#ifdef FEAPINT
if (0)
{
  int npar=3,nres=1,ngrad=3;
  vector param=NULL,res=NULL,grad=NULL;

  param=getvector(npar); res=getvector(nres); grad=getvector(ngrad);
  param->v[1]=1.1; param->v[2]=2.2; param->v[3]=3.3;

  feapanalyse_(&npar,(param->v)+1,&nres,(res->v)+1,&ngrad,(grad->v)+1);

  printf("Parameters:\n");
  printvector(param);
  printf("Results:\n");
  printvector(res);
  printf("Gradients:\n");
  printvector(grad);

  /*
  exit(0);
  */
}
#endif



#ifdef ITK
if (1)
{
  double x=1.2;
  int i=0,cont,n;
  char *line=NULL,*str=NULL,*str1=NULL,*path=NULL,*spec=NULL;
  double t1=0,t2=0,ct1=0,ct2=0;
  long flags=F_LISTMASK,setsortflags=1,setlistflags=1;

  stack words=NULL;


  ct1=1;

  printf("Before tcl_sleep:\n");
  tcl_sleep(300);
  printf("After tcl_sleep:\n");


  printf("Creating threads...\n");


  TRIN(0,1,"main","Launching thread with proc1, arg. T1")
  i1=createthread(proc1,"T1");
  TROUT(0,1,"main","After launching thread 1")
  TRIN(0,2,"main","Launching thread with proc2, arg. T2")
  i2=createthread(proc2,"T2");
  TROUT(0,2,"main","After launching thread 2")
  TRIN(0,3,"main","Launching thread with proc3, arg. T3")
  i3=createthread(proc3,"T3");
  TROUT(0,3,"main","After launching thread 3")

  printf("All threads launched: %i, %i, %i\n",i1,i2,i3);

  TRPT(0,4,"main","Before tcl_sleep(1000)")
  tcl_sleep(1000);

  printf("Begin to sleep...\n");

  printf("Theread: %i\n",getthreadid());
  printf("Theread: %i\n",getthreadid());

  TRDOPR(0,4,NULL,NULL,
    fprintf(trf(),"Main thread ID: %i.\n",getthreadid); fflush(trf()); )
  TRPT(0,5,"main","Before absolutetime()")
  t1=tcl_absolutetime();
  TRPT(0,6,"main","Before tcl_sleep((int) ct1*1000)")
  tcl_sleep((int) ct1*1000);
  TRPT(0,7,"main","Before tcl_sleep((int) ct1*1000)")
  t2=tcl_absolutetime();

  printf("\nSleeping for %g s, actual time: %g s.\n\n",ct1,t2-t1);

  printf("Theread: %i\n",getthreadid());
  printf("Main theread: %i\n",getmainthreadid());
  printf("Is main theread: %i\n",ismainthread());

  tcl_sleep(15000);

  exit(1);

  /*
  words=newstack(10);
  recighomeloc(words);
  printf("\nRecomended locations for Software home dir.:\n");
  for (i=1;i<=words->n;++i)
    printf("%4i: \"%s\"\n",i,words->s[i]);
  dispstackval(words);
  recighomemarkloc(words);
  printf("\nRecomended locations for Software home marks:\n");
  for (i=1;i<=words->n;++i)
    printf("%4i: \"%s\"\n",i,words->s[i]);
  dispstackval(words);
  */


  markighomeloc("c:/users/igor/ighome",0);

  /*
  markighomeid("c:/users/igor/c/test/ighome");
  */


  str=locateighomefrommarks();
  printf("\nThe identified software home: \"%s\"\n",str);

  printf("\n\nSearching for software home on the file system....\n\n\n");
  str=locateighomeonfilesys();
  printf("\nThe identified software home: \"%s\"\n",str);

  exit(1);




  if (0)
  {
    t1=1234567.0987; path=stringcopy("'"); str=NULL; i=14; n=10; 
    spec=stringcopy("li");
    do   /* Printing numbers with 1000 separators */
    {
      printf("Number: "); readint(&cont);
      printf("Separator: "); readstring(&path);
      printf("Format flags: ");  readstring(&str);
      printf("Width: "); readint(&i);
      printf("Type spec.: ");  readstring(&spec);

      printf("\n\nRepresentation with sep.: \"");
      fprintlongsep(stdout,cont,path[0],str,i,spec);
      printf("\"\n\n");
    } while (t1!=0);
  }






  /*
  wchar_t *wstr=L"Igor Gre�ovnik";

  printf("Test: izpis naslova\n%p\n\n",wstr);
  wprintf(L"Izpis konstant. niza; L'�'L'�'�蚞\n'",wstr);
  wprintf(L"Wide character string: \"%s\"\n",wstr);
  printf("Print by characters:\n");
  for (i=0;i<wcslen(wstr);++i)
    printf("%C",wstr[i]);
  printf("\n");
  exit(1);
  */

  /*
  str=stringcopy("abcd");

  stringinsert(&str,"IGOR",1000);
  printf("New string: \"%s\"\n\n",str);

  printf("File or directory name: "); readstring(&str);
  path=stringcopy(str);
  pathtoarg(&path);
  printf("\n\nAbsolute path of the file \"%s\": \"%s\".\n\n",
         str,path);

  exit(1);
  */



  globutbrowse("../wwww/index.html",0);




  /* POZOR!
  NA WINDOWSIH JE PRI TESTIRANJU FUNKCJ ZA MANIPULACIJO Z DATOTECNIM
  SISTEMOM TREBA BITI POZOREN NA DELOVANJE Z IMENI, KI VSEBUJEJO PRESLEDKE!
  */

  if (1)
  {
    testfilesysop();

    printf("\n\n\n\n\n\n\n\n\n\n\nAfter the test function.\n\n\n\n\n\n\n\n\n\n\n");

  }

  exit(1);




  /*  TEST QSORTLIM:
  int from, to;
  words=newstack(5);
  pushstack(words,";lkl;k");
  pushstack(words,"gdsgd");
  pushstack(words,NULL);
  pushstack(words,"jdsklg");
  pushstack(words,"ojfgr");
  pushstack(words,"09754");
  pushstack(words,"klhht");
  pushstack(words,"86440");
  pushstack(words,"rgrrr");
  pushstack(words,"fvewer");
  pushstack(words,"jyyyyjyu");
  pushstack(words,"iuytw");

  printf("Unsorted stack:\n\n");
  for (i=1;i<=words->n;++i)
    printf("%i: %s\n",i,words->s[i]);

  printf("\nSort from: "); readint(&from);
  printf("Sort to:   "); readint(&to);
  qsortstacklim(words,from,to,cmpstrings);
  printf("\nPartially sorted stack (from %i to %i):\n\n",from,to);
  for (i=1;i<=words->n;++i)
    printf("%i: %s\n",i,words->s[i]);
  printf("\n\n");
  */





  system("pwd");
  system("cd \\users");
  system("pwd");



  words=newstack(10);
  if (0)
  {
    str="a b cde f\tg eh  ";
    cutstringtowords(str," ",words);
    printf("Cut the string \"%s\":\n",str);
    if (words->n==0)
      printf("No words in the string.\n");
    else for (i=1;i<=words->n;++i)
      printf("%i: \"%s\"\n",i,words->s[i]);
    printf("\n\n");
  }

  path=NULL; spec=stringcopy("");

  cont=1;
  n=1;
  while (cont)
  {
    /* chdir("\\users\\igor"); */

  }

  /*
  globutupdateprogdir();
  */

  itk_shell();

  testitk();


  /*
  itk_com0("set a 10");
  itk_com0("puts \"a: [set a]\"");
  */

  /*
  itk_interpret(stringcopy("set a 22"),NULL);
  */


  itk_sendcomcp("set b 33");
  itk_sendcomcp("set c 44");

  /*
  itk_shell();
  tcl_shell();
  */


  /*
  itk_interpret("itk_shell");
  itk_interpret("itk_shell");
  */

  /*
  printf("Enter to continue!\n");
  readdouble(&x);
  */

}
#endif  /* defined ITK */



}






