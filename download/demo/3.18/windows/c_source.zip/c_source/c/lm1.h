#include <sysint.h>

#include <math.h>
#include <stdio.h>




#include <er.h>

#include <mtypes.h>
#include <mat.h>
#include <vec.h>






double chi2func(_vector meas, _vector calc, _vector sigma)
       /* Izracuna funkcijo hi-kvadrat iz izmerkov meas, izracunanih vrednosti 
          calc in standardnih deviacij izmerkov sigma. */
{
double c=0;
int i;
for (i=1; i<=meas.d; ++i)
  c+=(meas.v[i]-calc.v[i])*(meas.v[i]-calc.v[i])/(sigma.v[i]*sigma.v[i]);
return(c);
}








void levmarq(_vector meas, _vector sigma, _vector * a, _vector * meascalc,
             double * chi2, _matrix *covar,
             void func(_vector, _vector *), 
             double dfunc(_vector, int, int,void basfunc(_vector,_vector *) ), 
             double tol,
             int *it, int maxit, int connection(int), FILE *fp)
             
      /* Levenberg-Marquardtova metoda. Izracuna nabor parametrov
      modela a, pri katerih se izracunane vrednosti po modelu najbolje 
          ujemajo z izmerjenimi vednostmi(po kruteriju hi-kvadrat). 
      meas: vektor izmerjenih vrednosti; vhodni podatek.
      sigma: vektor napak izmerkov; vhodni podatek.
      a: vektor parametrov; na vhodu mora biti enak zacetnemu priblizku 
          za parametre. Na izhodu zavzame vrednost najboljsih najdenih 
          parametrov.
      meascalc: vektor izracunanih vrednosti po izvedbi parametrov.
      chi2: vrednost hi-kvadrat na koncu.
      covar: Kovariancna matrika parametrov
      it: stevilo iteracij. Po izvedbi funkcije se poveca za stevilo 
          izvedenih iteracij.
      maxit: najvecje dovoljeno stevilo iteracij.
      connection: funkcija za povezavo z glavnim programom.
      fp: datoteka, kamor se zapisujejo sprotni podatki in obvestila.
      func : fukcija, ki izracuna izracunane vrednosti pri danih parametrih.
          1. parameter je vektor parametrov (vhodni podatek), 2. pa vektor 
          izracunanih vrednosti (izhodni podatek).
      dfunc: funkcija, ki izracuna odvode izracunanih vrednosti pri danih 
          parametrih. 1. parameter funkcije je vektor parametrov, 2. pove,
          katero izracunano vrednost odvajamo, 3. pa, po katerem parametru
          jo odvajamo. 4. parameter je funkcija, ki izracuna vrednosti pri danih
          parametrih. Funkcija vrne zahtevani odvod.
             
      */
{
_matrix alpha={0},dmat={0},beta={0},invalpha={0},correction={0};
_vector anew={0},meascalcprev={0};
double lambda=1.0,chi2mom,chi2prev,chi2preprev;
double w1,w2,w3;
int dimmeas,dimpar,i,j,k,l,itlocal=0,countfail=0;
char end=0;
/* Inicializacija: */
dimmeas=meas.d;
dimpar=a->d;
if (meascalc==NULL) getvec(meascalc,dimmeas);
else if (meascalc->d!=dimmeas)
{
  dispvec(meascalc);
  getvec(meascalc,dimmeas);
}
if (covar!=NULL) dispmat(covar);
copyvec(&anew,a);
getmat(&alpha,dimpar,dimpar);
getmat(&dmat,dimmeas,dimpar);
getmat(&beta,dimpar,1);
getmat(&correction,dimpar,1);
/* Izracun izracunanih vrednosti in hi-kvadrat v zacetnem prilbizku */
func(*a,meascalc);
chi2mom=chi2func(meas,* meascalc,sigma);
chi2preprev=chi2mom; /* Da ni izpolnjen konvergencni kriterij */
chi2prev=chi2mom;
/* Kontrolni izpis */
printf("Kontrolni izpis pred glavno canko:\n\nChi Square: %g\n",chi2mom);
printvecname(meas,"meritev");
printvecname(sigma,"napaka");
printvecname(*a,"parameter");
printvecname(*meascalc,"izrac. meritev");
do   /* Izvajanje iteracije */
{
  ++ itlocal;
  if (itlocal >=maxit) end=1;
  printf("%i. iteracija: Hi-kvadrat = %g",itlocal,chi2mom);
  /* Najprej izracunamo matriko odvodov, tako da je dmat.m[i][j] odvod i.
  izracunane vrednosti po j. parametru: */
  for (i=1; i<=dimmeas; ++i)
    for (j=1; j<=dimpar; ++j)
      dmat.m[i][j]=dfunc(*a,i,j,func);
  /* Racunanje popravka parametrov */
  /* Racunanje vektorja beta */
  for (i=1; i<=dimpar; ++i)
  {
    beta.m[i][1]=0;
    for (j=1; j<=dimmeas; ++j)
    {
      beta.m[i][1]-=dmat.m[j][i]
       *(meascalc->v[i]-meas.v[i])/(sigma.v[i]*sigma.v[i]);
    }
  }
  /* Racunanja matrike alfa' */
  for (k=1; k<=dimpar; ++k)
  {
    for (l=1; l<=dimpar; ++l)
    {
      alpha.m[k][l]=0;
      for (i=1; i<=dimmeas; ++i)
      {
        alpha.m[k][l]+=dmat.m[i][k]*dmat.m[i][l]/(sigma.v[i]*sigma.v[i]);
      }
      if (k==l) alpha.m[k][l]*=1+lambda;
    }
  }
  /* Resevanje sistema enacb alfa' popravek = beta */
  
  dispmat(&invalpha);
  dispmat(&correction);
  
  invalpha=invmat(alpha);
  correction=prodmat(invalpha,beta);
  /* Popravek: */
  for (i=1; i<=dimpar; ++i)
    anew.v[i]+=correction.m[i][1];
  func(anew,meascalc);
  w3=chi2preprev;
  w2=chi2prev; 
  w1=chi2mom;
  printf("chi2mom: %g",chi2mom);
  printf("chi2prev: %g",chi2prev);
  printf("chi2preprev: %g",chi2preprev);
  chi2mom=chi2func(meas,* meascalc,sigma);
  printf("chi2mom: %g",chi2mom);
  if (chi2mom<w1)
  {
    countfail=0;
    lambda/=10;
    copyvec(a,&anew);
    copyvec(&meascalcprev,meascalc);
    chi2prev=w1;
    chi2preprev=w2;
    /* Konvergencni kriterij: */
    if (fabs(chi2preprev-chi2mom)<tol)
      end=1;
  } else
  {
    ++ countfail;
    lambda*=10;
    copyvec(&anew,a);
    copyvec(meascalc,&meascalcprev);
    chi2mom=w1;
    if (lambda>1.0e15) end=1;
    if (countfail>=2) lambda*=10;
    if (countfail>=4) lambda*=10;
  }
} while (! end);
* it+=itlocal;
/* Racunanja matrike alfa */
for (k=1; k<=dimpar; ++k)
{
  for (l=1; l<=dimpar; ++l)
  {
    alpha.m[k][l]=0;
    for (i=1; i<=dimmeas; ++i)
    {
      alpha.m[k][l]+=dmat.m[i][k]*dmat.m[i][l]/(sigma.v[i]*sigma.v[i]);
    }
  }
}
*covar=invmat(alpha);
*chi2=chi2mom;
dispmat(&alpha);
dispmat(&dmat);
dispmat(&beta);
dispmat(&invalpha);
dispmat(&correction);
dispvec(&anew);
dispvec(&meascalcprev);
}
















































































































































