

          /*********************************************/
          /*   SGS PLOTTING INTERFACE FOR PostScript   */
          /*********************************************/



# include <stddef.h>
# include <stdio.h>
# include <stdlib.h>
# include <ctype.h>

#include <sysint.h>
# include <strop.h>
# include <rf.h>
# include <er.h>
# include <itk.h>
#include <gro.h>

#include <sg_obj.h>
#include <sg_draw.h>
#include <sg_ploto.h>
#include <sg_obj.h>

#include <sg_intfc.h>






typedef struct {
  int id;         /* SGS ID */
  sg_window base; /* pointer to base structure containing general data */
  char *file;     /* name of the output file */
  FILE *fp;
} _ps_windata;

typedef _ps_windata *ps_windata;



typedef struct {
  int id;            /* SGS ID */
  sg_font base;      /* pointer to base structure containing general data */
  char *psname;     /* installation string for the font in Ps */
  char installedps; /* indicates whether the font has been installed in the
        ps. */
  /* The following indicates the windows in which the font has already been
  installed: */
  indtab filewins;
} _ps_fontdata;

typedef _ps_fontdata *ps_fontdata;

ps_windata newps_windata(void)
    /* Creates a new object of the type ps_windata.
    $A Igor sep03; */
{
ps_windata ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
return ret;
}


void dispps_windata(ps_windata *addr)
    /* Deallocates an object pointet to by addr and sets *addr to NULL.
    $A Igor sep03; */
{
ps_windata data;
if (addr!=NULL)
{
  data=*addr;
  if (data!=NULL)
  {
    if (data->file!=NULL)
      free(data->file);
    if (data->fp!=NULL)
    {
      fclose(data->fp);
      data->fp=NULL;
    }

  }
  free(data);
  *addr=NULL;
}
}

ps_fontdata newps_fontdata(void)
    /* Creates a new object of the type ps_fontdata.
    $A Igor sep03; */
{
ps_fontdata ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
return ret;
}


void dispps_fontdata(ps_fontdata *addr)
    /* Deallocates an object pointet to by addr and sets *addr to NULL.
    $A Igor sep03; */
{
ps_fontdata data;
if (addr!=NULL)
{
  data=*addr;
  if (data!=NULL)
  {
    if (data->psname!=NULL)
      free(data->psname);
    if (data->filewins!=NULL)
      dispindtab(&(data->filewins));
  }
  free(data);
  *addr=NULL;
}
}


    /* AUXILIARY VARIABLES: */

static FILE *fp=NULL;

static _coord3d p1,p2,p3,p4,p5;
static int nofilereported=0;

static void reportnofile(char *funcname)
    /* Reports that the output file is not open. The report is launched at
    most once after each each activation of the PostScript plotting interface.
    $A Igor sep03; */
{
if (!nofilereported)
{
  nofilereported=1;
  errfunc0(funcname);
  sprintf(ers(),"The PostScript output file is not open.\n");
  if (sg_interfaceid!=SG_PLOT_PS)
  {
    sprintf(ers(),"This function can be used only when the PostScript interface is active.\n");
    sprintf(ers(),"Current plotting interface ID is %i (PostSctipt: %i).\n",
      sg_interfaceid,SG_PLOT_PS);
  } else
  {
    int namedef=0;
    sg_window win;
    ps_windata windata;
    if (sg_windows!=NULL)
      if ((win=stackel(sg_windows,sg_currentwindow))!=NULL)
        if ((windata=win->intfcdata)!=NULL)
          if (windata->file!=NULL)
          {
            namedef=1;
            sprintf(ers(),"Output PostScript file name is set to: %s\n",
              windata->file);
          }
    if (!namedef)
      sprintf(ers(),"Output file name is not defined.\n");
  }
  sprintf(ers(),"Further messages of this type will be skipped until the PS interface\n");
  sprintf(ers(),"is re-activated.\n");
  errfunc2();
}
}




                     /********************************/
                     /*  SETTINGS FOR THE PS FORMAT  */
                     /********************************/




static int psiprecision=6;  /* St. decimalk pri zapisovanju realnih stevil */

static char shortoperators=1; /* Ce je 1, se uporabi krajsi zapis operatorjev;
                                 pri tem se definirajo krajsa imena. */

static char psiepsformat=1;   /* Ce je 1, se v datoteke dodajo glave za eps. */

    /* NIZI, KI PREDSTAVLJAJO OPERATORJE V PostScriptu (uvedeni so kot
       spremenljivke zaradi moznosti predefiniranja oz. zamenjave s krajsimi
       nizi: */

static char *movetostr0="moveto";
static char *linetostr0="lineto";
static char *newpathstr0="newpath";
static char *closepathstr0="closepath";
static char *strokestr0="stroke";
static char *fillstr0="fill";
static char *showstr0="show";
static char *setlinewidthstr0="setlinewidth";
static char *setgraystr0="setgray";
static char *setrgbcolorstr0="setrgbcolor";
static char *findfontstr0="findfont";
static char *setfontstr0="setfont";
static char *scalefontstr0="scalefont";
static char *defstr0="def";

static char *movetostr1="Mt";
static char *linetostr1="Lt";
static char *newpathstr1="Np";
static char *closepathstr1="Cp";
static char *strokestr1="St";
static char *fillstr1="Fl";
static char *showstr1="Sh";
static char *setlinewidthstr1="Slw";
static char *setgraystr1="Sg";
static char *setrgbcolorstr1="Sc";
static char *findfontstr1="Ff";
static char *setfontstr1="Sf";
static char *scalefontstr1="Scf";
static char *defstr1="def";

static char *movetostr="moveto";
static char *linetostr="lineto";
static char *newpathstr="newpath";
static char *closepathstr="closepath";
static char *strokestr="stroke";
static char *fillstr="fill";
static char *showstr="show";
static char *setlinewidthstr="setlinewidth";
static char *setgraystr="setgray";
static char *setrgbcolorstr="setrgbcolor";
static char *findfontstr="findfont";
static char *setfontstr="setfont";
static char *scalefontstr="scalefont";
static char *defstr="def";



static void psisetshortoperators(void)
    /* V uporabo postavi kratka imena operatorjev: nastavi ustrezne nize, ki
    predstavljajo operatorje v formatu PostScript in postavi shortoperators
    na 1.
    $A Igor <== apr97; */
{
shortoperators=1;
movetostr=movetostr1;
linetostr=linetostr1;
newpathstr=newpathstr1;
closepathstr=closepathstr1;
strokestr=strokestr1;
fillstr=fillstr1;
showstr=showstr1;
setlinewidthstr=setlinewidthstr1;
setgraystr=setgraystr1;
setrgbcolorstr=setrgbcolorstr1;
findfontstr=findfontstr1;
setfontstr=setfontstr1;
scalefontstr=scalefontstr1;
}


static void psisetlongoperators(void)
    /* V uporabo postavi dolga imena operatorjev: nastavi ustrezne nize, ki
    predstavljajo operatorje v formatu PostScript in postavi shortoperators
    na 0.
    $A Igor <== apr97; */
{
shortoperators=0;
movetostr=movetostr0;
linetostr=linetostr0;
newpathstr=newpathstr0;
closepathstr=closepathstr0;
strokestr=strokestr0;
fillstr=fillstr0;
showstr=showstr0;
setlinewidthstr=setlinewidthstr0;
setgraystr=setgraystr0;
setrgbcolorstr=setrgbcolorstr0;
findfontstr=findfontstr0;
setfontstr=setfontstr0;
scalefontstr=scalefontstr0;
}

static void psifwriteshortdef(FILE *fp)
    /* V datoteko fp, v katero nameravamo zapisati risbo v formatu PostScript,
    zapise definicije, ki omogocajo uporabo kratkih imen operatorjev.
    $A Igor <== apr97; */
{
fprintf(fp,"/%s {%s} %s\n",movetostr1,movetostr0,defstr);
fprintf(fp,"/%s {%s} %s\n",linetostr1,linetostr0,defstr);
fprintf(fp,"/%s {%s} %s\n",newpathstr1,newpathstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",closepathstr1,closepathstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",strokestr1,strokestr0,defstr);
fprintf(fp,"/%s {%s} %s\n",fillstr1,fillstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",showstr1,showstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",setlinewidthstr1,setlinewidthstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",setgraystr1,setgraystr0,defstr);
fprintf(fp,"/%s {%s} %s\n",setrgbcolorstr1,setrgbcolorstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",findfontstr1,findfontstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",setfontstr1,setfontstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",scalefontstr1,scalefontstr0,defstr);
fprintf(fp,"\n\n");
}


  /* ZAPISOVANJE BARV (POZOR, funkcije ne zapisujejo presledkov pred in po): */


static char psinopalette=0,    /* crno-bela risba */
            psigraypalette=0,  /* risba z odtenki sive */
            psirgbpalette=1;   /* barvna risba */


static void psifprintcolor(FILE *fp,float red,float green,float blue)
    /* Zapis barve s komponentami red, green in blue v datoteko fp. Glede
    na vrednosti spremenljivk psinopalette, psigraypalette in psirgbpalette se
    doloci, kako naj se ta barva interpretira. Ta funkcija se uporablja v
    funkcijah psifprintlinecolor(), psifprintfillcolor() in psifprinttextcolor().
    $A Igor <== apr97; */
{
double gr;
if (psirgbpalette)
{
  fprintf(fp,"%.*g %.*g %.*g %s",
  psiprecision,red,psiprecision,green,psiprecision,blue,setrgbcolorstr);
} else if (psigraypalette)
{
  gr=(red+green+blue)/3;
  fprintf(fp,"%.*g %s",psiprecision,gr,setgraystr);
}
else if (psinopalette)
{
}
}

static void psifprintlinecolor(FILE *fp)
    /* Zapis barve za risanje crt v datoteko fp
    $A Igor <== apr97; */
{
float red,green,blue;
sg_getlinecolor(&red,&green,&blue);
psifprintcolor(fp,red,green,blue);
}

static void psifprintfillcolor(FILE *fp)
    /* Zapis barve za polnjenje v datoteko fp
    $A Igor <== apr97; */
{
float red,green,blue;
sg_getfillcolor(&red,&green,&blue);
psifprintcolor(fp,red,green,blue);

}

static void psifprinttextcolor(FILE *fp)
    /* Zapis barve za risanje teksta v datoteko fp
    $A Igor <== apr97; */
{
float red,green,blue;
sg_gettextcolor(&red,&green,&blue);
psifprintcolor(fp,red,green,blue);
}



  /* ZAPISOVANJE OSTALIH NASTAVITEV (POZOR, funkcije ne zapisujejo presledkov
  pred in po): */


static void psifprintlinewidth(FILE *fp)
    /* Zapis debeline crt
    $A Igor <== apr97; */
{
int width;
width=(int) sg_getlinewidth();
if (width>0) width-=1;  /* kompatibilnost med PostScriptom in risanjem na zaslon */
fprintf(fp,"%i %s",width,setlinewidthstr);
}



  /* FONTI: */


static char psifontshortcuts=0;  /* Ce je 1, se pri zapisu uporabljajo krajsave
                                imen fontov */
static stack psifontnames=NULL;  /* Imena fontov */
static char *psidefaultfontname="Times-Roman";
static char *psishortfontstr="Ft";

static void psiinstallfont(int num,char *name)
    /* Doda novo ime fonta, ki se uporablja pri risanju v formatu Postscript.
    num je zaporedna stevilka, pod katero se instalira font, name pa ime fonta.
    Ime fonta se nalozi na sklad psifontnames, ki se uporablja pri prireditvi
    imena fonta zaporedni stevilki pri zapisu v formatu PostScript. Zaporedne
    stevilke za fonte uporabljajo graficni objekti.
    $A Igor <== apr97; */
{
int i;
if (num<1) num=1;
if (psifontnames==NULL)
  psifontnames=newstack(5);
if (psifontnames->n<num)
  for (i=psifontnames->n+1;i<=num;++i)
    pushstack(psifontnames,NULL);
psifontnames->s[num]=stringcopy(name);
}


static void psiinitfontnames1(void)
    /* Funkcija se uporablja za instalacijo nekaterih imen fontov za zapis v
    formatu PostScript v primeru, ce ob klicu ni bil instaliran se noben font.
    $A Igor <== apr97; */
{
psiinstallfont(1,"Times-Roman");
psiinstallfont(2,"Courier");
psiinstallfont(3,"Helvetica");
psiinstallfont(4,"Arial");
psiinstallfont(5,"Courier-New");
psiinstallfont(6,"Symbol");
psiinstallfont(7,"Swiss");
psiinstallfont(8,"Italic");
psiinstallfont(9,"Bold");
psiinstallfont(10,"Bold-Italic");
psiinstallfont(11,"Modern");
psiinstallfont(12,"Script");
psiinstallfont(13,"Times-New-Roman");
psiinstallfont(14,"Greek");
psiinstallfont(15,"New-Roman");
psiinstallfont(16,"Gothic");
psiinstallfont(17,"Serif");
psiinstallfont(18,"San-Serif");
psiinstallfont(19,"Terminal");
psiinstallfont(20,"Dutch");
}


static void psifwritefonts(FILE *fp)
    /* V datoteko fp zapise definicije kratkih imen za fonte; Izkazalo se je, da
    do v PostScriptu ne dela, ker se operator def lahko uporablja za definicije
    novih operatorjev, ne pa na splosno za definicije katerihkoli imen (vsaj po
    tem, kar mi je do sedaj znanega).
    $A Igor <== apr97; */
{
int font;
char *fontname;
char done=0;
fprintf(fp,"\n");
if (psifontnames!=NULL)
{
  if (psifontnames->n>0)
  {
    for (font=1;font<=psifontnames->n;++font)
    {
      fontname=psifontnames->s[font];
      if (fontname==NULL)
        fontname=psidefaultfontname;
      fprintf(fp,"/%s%i {%s} %s\n",psishortfontstr,font,fontname,defstr);
    }
    done=1;
  }
}
if (!done)
  fprintf(fp,"/%s1 {%s} %s\n",psishortfontstr,psidefaultfontname,defstr);
fprintf(fp,"\n");
}



  /* SKALIRANJE KOORDINAT PRI ZAPISU V FORMATU PS: */





static char psiscalecoordinates=1; /* Ce je 1, se koordinate skalirajo kot pri
              risanju grafov, drugace se zapisejo naravne koordinate. */
/* Okno, v katerega se izrise slika: */
static double psistartx=0,   /* koordinata x leve strani okna */
              psistarty=0,   /* koordinata y spodnje strani okna */
              psisizex=500,  /* sirina okna */
              psisizey=500;  /* visina okna */


static void psinaturalwindowcoord(float x,float y,coord3d p)
    /* Pri transformaciji koordinat objektov v njihove okenske koordinate
    se pusti kar naravne koordinate.
    $A Igor apr97; */
{
p->x=x; p->y; p->z=0;
}


static void psigpwindowcoord(float x,float y,coord3d p)
    /* Normalni okenski koordinati (ki gresta v obeh smereh od 0 do 1 s
    koordinatnim izhodiscem v spodnjem levem kotu) se pretvorita v okenski
    koordinati za format PostScript.
    $A Igor apr97; */
{
p->x=psistartx+x*psisizex;
p->y=psistarty+y*psisizey;
p->z=0;
}



static void (*psiwindowcoord) (float,float,coord3d) = psigpwindowcoord;




static void psisetscaling(char scaling)
    /* Doloci skaliranje koordinat pri zapisu graficnih objektov v formatu PS.
    ce je scaling==0, postane funkcija psiwindowcoord() za skaliranje koordinat
    kar funkcija psinaturalwindowcoord(), ki ohranja naravne koordinate objektov,
    drugace pa to postane funkcija psigpwindowcoord(), ki skalira koordinati x
    in y tako, kot se to naredi pri risanju na zaslon, koordinato z pa poskusa
    skalirati na podoben nacin.
    $A Igor <== apr97; */
{
psiscalecoordinates=scaling;
if (psiscalecoordinates==0)
  psiwindowcoord=psinaturalwindowcoord;
else psiwindowcoord=psigpwindowcoord;
}


static void psisetwindowsize(double width,double height)
    /* Postavi sirino postscript-ovega okna, v katerem se izrise graf iz
    datoteke, na width, in visino na height. Ce je eden ali drugi 0, se
    ohrani ustrezna dimenzija, ki je trenutno nastavljena.
    $A Igor maj01; */
{
if (width>0)
{
  psisizex=height;
}
if (height>0)
{
  psisizey=height;
}
}


static double psigetwindowwidth(void)
    /* Vrne sirino trenutnega Tcl-ovega okna v pixlih.
    $A Igor maj01;  */
{
return fabs(psisizex);
}

static double psigetwindowheight(void)
    /* Vrne visino trenutnega Tcl-ovega okna v pixlih.
    $A Igor maj01;  */
{
return fabs(psisizey);
}





static void psiprinthead(void)
    /* Izpise glavo datoteke v formatu PostScript. Datoteka, v katero se glava
    zapise, je dolocena z lokalno spremanljivko fp.
    $A Igor apr97; */
{
if (fp!=NULL)
{
  if (psifontnames==NULL) /* Ce ni instaliran noben font, se izvede stand. instalacija */
    psiinitfontnames1();
  /* izbira zapisa operatorjev (dolg ali kratek nacin): */
  if (shortoperators)
    psisetshortoperators();
  else
    psisetlongoperators();
  /* Izpis glave datoteke */
  if (psiepsformat)
  {
    fprintf(fp,"%c!PS-Adobe-3.0 EPSF-3.0 \n",'%');
    fprintf(fp,"%c%cBoundingBox: 0 0 500 500 \n",'%','%');
    fprintf(fp,"%c%cCreator: SGS (by Igor Gresovnik)\n",'%','%');
    /*
    fprintf(fp,"%c%cOrientation: Portrait \n",'%','%');
    */
    fprintf(fp,"%c%cEndComments \n",'%','%');
  } else
  {
    fprintf(fp,"%c!\n",'%');
  }
  fprintf(fp,"\n%c BEGINNING OF GRAPHIC PART \n\n",'%');
  if (shortoperators) /* definicije krajsih imen operatorjev: */
    psifwriteshortdef(fp);
  if (psifontshortcuts) /* definicije krajsih imen za fonte: */
    psifwritefonts(fp);
  /* izris ozadja: */
  /*
  if (psibackground)
    psifprintbackground(fp);
  */
}
}



static void psiprinttail(void)
    /* Zapise rep datoteke v formatu PostScript. Datoteka, v katero se rep
    zapise, je dolocena z lokalno spremanljivko fp.
    $A Igor apr97; */
{
if (fp==NULL)
{
  /* Izpis repa datoteke: */
  fprintf(fp,"\n%c END OF GRAPHIC PART \n\n",'%');
  fprintf(fp,"showpage\n");
}
}






static int sg_ps_setwindow(int id);

static int sg_ps_openwindow(void)
    /* Opens a new virtual PostScript window, which also becomes the current
    plotting window of SGS. The window establishes a connection to a PoScript
    file to which output is plotted (the file is created anew).
      Returns the identification number of the opened whindow, through
    which the window can be accessed e.g. for closing, activating, etc.
      sg_windowwidth and sg_windowheight are used to determine the size while
    the position of the window can not be adjusted. 
    $A Igor sep03; */
{
int id=0,serial=0;
sg_window psw;
ps_windata windata;
id=sg_openwindow_default();
psw=stackel(sg_windows,id);
windata=psw->intfcdata=newps_windata();
serial=psw->serial;
/* Save opening settings: */
psw->title=stringcopy(sg_windowtitle);
if (1)
{
  windata->file=sg_obtainplotfile(".eps");
  fp=windata->fp=fopen(windata->file,"wb");
  /* Print the head: */
  psiprinthead();
  psw->width=sg_iwindowwidth;
  psw->height=sg_iwindowheight;

}/* The following takes care of variables related to the current window */
sg_ps_setwindow(id);
return id;
}



static int sg_ps_setwindow(int id)
    /* Sets the PS window identified by id as the current plotting window.
    Returns 0 if for any reason the window identified by ID can not set to
    the current window (e.g. it does not exist).
    $A Igor sep03; */
{
int ret=0,code=0;
static int reclev=0; /* recursion counter */
char *ptr=NULL,*res=NULL;
sg_window psw;
ps_windata windata=NULL;
++reclev;
if (fp!=NULL)
  fflush(fp);
if (reclev==5)  /* prevent infinite recursion */
{
  errfunc0("sg_ps_setwindow");
  sprintf(ers(),"Infinite recursion when trying to activate window %i.\n",id);
  /*
  sprintf(ers(),"The attempt is given up, current window (%i) will be used.\n",locpswin);
  */
  errfunc2();
  return 0;
}
/*
if (sg_windows==NULL)
  sg_windows=newstack(5);
*/
if (id<0)
{
  errfunc0("sg_ps_setwindow");
  sprintf(ers(),"Non-positive window ID (%i) passed. Must be a positive integer.\n",id);
  errfunc2();
} else if (sg_windows->n<id)
{
  errfunc0("sg_ps_setwindow");
  sprintf(ers(),"There is no window identified by %i.\n",id);
  errfunc2();
} else
{
  if ((psw=stackel(sg_windows,id))==NULL)
  {
    errfunc0("sg_ps_setwindow");
    sprintf(ers(),"There is no window identified by %i.\n",id);
    sprintf(ers(),"The corresponding data structure is NULL.\n");
    errfunc2();
  } else
  {
    /* Window structure with a specific id exists: */
    if (psw->intfc!=SG_PLOT_PS)
    {
      errfunc0("sg_ps_setwindow");
      sprintf(ers(),"The window with ID %i does not belong to the Tcl file plotting\n",id);
      sprintf(ers(),"graphic interface.\n");
      errfunc2();
      return 0;
    }
    windata=psw->intfcdata;
    /* Update local variable for accessing the window: */
    /* locwindowstr=windata->tkid; */
    fp=windata->fp;
    psisizex=psw->width;
    psisizey=psw->height;
    sg_currentwindow=psw->id;
  }
}
--reclev;
return ret;
}




static void sg_ps_clearwindow(void)
     /* Does nothing under the PostScript file plotting interface.
    $A Igor sep03; */
{
static int reported=0;
if (fp==NULL)
if (!reported)
{
  reported=1;
  warnfunc1(1,"sg_ps_clearwindow");
  sprintf(ers(),"Clearing window content is not available in the SGS PostScript\n");
  sprintf(ers(),"plotting interface (intfc. id.: SG_PLOT_PS = %i)",SG_PLOT_PS);
  warnfunc2();
}
}



static void sg_ps_resetwindow(void)
    /* Does nothing under the PostScript file plotting interface.
    $A Igor sep03; */
{
static int reported=0;
if (!reported)
{
  reported=1;
  warnfunc1(1,"sg_ps_resetwindow");
  sprintf(ers(),"Resetting windows is not available in the SGS PostScript\n");
  sprintf(ers(),"plotting interface (intfc. id.: SG_PLOT_PS = %i)",SG_PLOT_PS);
  warnfunc2();
}
}



static void sg_ps_closewindow(void)
     /* Closes the current (active) virtual windeow (e.g. closes the PostScript
     file associated with the window and does other administrative tasks).
     $A Igor sep03; */
{
sg_window itkwin;
ps_windata windata;
if (sg_currentwindow>0 && sg_windows!=NULL)
  if (sg_windows->n>=sg_currentwindow)
  {
    if (sg_currentwindow>0 && sg_currentwindow<=sg_windows->n)
      itkwin=sg_windows->s[sg_currentwindow];
    if (itkwin!=NULL)
    {
      windata=itkwin->intfcdata;
      if (windata!=NULL)
        if (windata->fp!=NULL)
        {
          psiprinttail();
          fclose(windata->fp);
          windata->fp=NULL;
        }
      dispsg_window(&itkwin);
    }
    fp=NULL;
    sg_currentwindow=0;
  }
sg_currentwindow=0;
}



static void sg_ps_raisewindow(void)
    /* Empty function. */
{
static int reported=0;
if (fp==NULL)
if (!reported)
{
  reported=1;
  warnfunc1(1,"sg_ps_raisewindow");
  sprintf(ers(),"Raising windows is not available in the SGS PostScript\n");
  sprintf(ers(),"plotting interface (intfc. id.: SG_PLOT_PS = %i)",SG_PLOT_PS);
  warnfunc2();
}
}



static void sg_itk_flushdisplay(void)
     /* Empty function. */
{
static int reported=0;
}




  /* OSNOVNE FUNKCIJE ZA ZAPIS V FORMATU PS: */


static void sg_ps_line(float x1,float y1,float x2,float y2)
    /* $A Igor <== apr97; */
{
if (fp==NULL)
{
  reportnofile("sg_ps_line");
  return ;
}
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
fprintf(fp,"%s ",newpathstr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
psifprintlinecolor(fp); fprintf(fp," ");
psifprintlinewidth(fp); fprintf(fp," ");
fprintf(fp,"%s\n",strokestr);
}


static void sg_ps_triangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* $A Igor <== apr97; */
{
if (fp==NULL)
{
  reportnofile("sg_ps_triangle");
  return ;
}
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
psiwindowcoord(x3,y3,&p3);
fprintf(fp,"%s ",newpathstr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p3.x,psiprecision,p3.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,linetostr);
psifprintlinecolor(fp); fprintf(fp," ");
psifprintlinewidth(fp); fprintf(fp," ");
fprintf(fp,"%s\n",strokestr);
}


static void sg_ps_fourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* $A Igor <== apr97; */
{
if (fp==NULL)
{
  reportnofile("sg_ps_fourangle");
  return ;
}
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
psiwindowcoord(x3,y3,&p3);
psiwindowcoord(x4,y4,&p4);
fprintf(fp,"%s ",newpathstr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p3.x,psiprecision,p3.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p4.x,psiprecision,p4.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,linetostr);
psifprintlinecolor(fp); fprintf(fp," ");
psifprintlinewidth(fp); fprintf(fp," ");
fprintf(fp,"%s\n",strokestr);
}


static void sg_ps_filltriangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* $A Igor <== apr97; */
{
if (fp==NULL)
{
  reportnofile("sg_ps_filltriangle");
  return ;
}
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
psiwindowcoord(x3,y3,&p3);
fprintf(fp,"%s ",newpathstr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p3.x,psiprecision,p3.y,linetostr);
psifprintfillcolor(fp); fprintf(fp," ");
fprintf(fp,"%s\n",fillstr);
}


static void sg_ps_fillfourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* $A Igor <== apr97; */
{
if (fp==NULL)
{
  reportnofile("sg_ps_fillfourangle");
  return ;
}
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
psiwindowcoord(x3,y3,&p3);
psiwindowcoord(x4,y4,&p4);
fprintf(fp,"%s ",newpathstr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p3.x,psiprecision,p3.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p4.x,psiprecision,p4.y,linetostr);
psifprintfillcolor(fp); fprintf(fp," ");
fprintf(fp,"%s\n",fillstr);
}







static void psimarktextpos(char *str,float x,float y,char mark,char box)
    /* Oznaci pozicijo teksta, ki naj bi se izpisal s funkcijo psitext. str je
    niz, ki naj bi se izpisal, x in y pa sta koordinati, pri katerih naj bi
    se niz izpisal. Ce je mark razlicen od 0, se izrise puscica na poziciji
    (x1,y1), ce pa je box 1, se izrise okvir okrog mej, s katerimi naj bi bil
    tekst omejen.
    $A Igor apr97; */
{
float marklength=(float) 0.03;
float xratio=/* 1.9332 */ (float) 1.5;
float yratio=(float) 1.514;
float x1,y1,x2,y2,height,dx,dy,xalign=0,yalign=0,red,green,blue;
if (fp==NULL)
{
  reportnofile("psimarktextpos");
  return ;
}
if (mark || box)
{
  sg_setlinewidth(1);
  sg_setlinetype(2);
  sg_gettextcolor(&red,&green,&blue);
  sg_setlinecolor(1-red,1-green,1-blue);
  if (mark)
  {
    x1=x-marklength;
    y1=y+(float) 0.3*marklength;
    x2=x1;
    y2=y-(float) 0.3*marklength;
    sg_line(x,y,x1,y1); 
    sg_line(x,y,x2,y2);
  }
  if (box)
  {  
    sg_setlinecolor(red,green,blue);
    height=sg_gettextheight();
    xalign=(float) sg_gettextxalignment();
    yalign=(float) sg_gettextyalignment();
    /* Nastavitev poravnavanja teksta: */
    dy=height;    /* celotna visina teksta */
    dx=strlen(str)*height/xratio;    /* celotna sirina teksta */
    x1=x; y1=y;   /* (x,y) je spodnja leva tocka boksa. */
    /* poravnavanje v vodoravni smeri: */
    if (xalign==0)
      x1-=dx*(float) 0.5;
    else if (xalign==1)
      x1-=dx;
    if (yalign==0)
      y1-=dy*(float) 0.5;
    else if (yalign==1)
      y1-=dy;
    x2=x1+dx;
    y2=y1+dy;
    sg_fourangle(x1,y1,x2,y1,x2,y2,x1,y2);
  }
}
}



static char *currentpsfontname(void)
    /* Returns PostScript name of the current font.
    $A Igor spe03; */
{
char buf[500],*ptr;
sg_font font=NULL;
buf[0]='\0';
if (sg_fonts!=NULL)
  if (sg_currentfont>0 && sg_currentfont<=sg_fonts->n)
    font=sg_fonts->s[sg_currentfont];
if (font!=NULL)
  if (stringlength(font->family)>0)
  {
    ptr=buf;
    ptr+=sprintf(ptr,"%s",font->family);
    if (font->bold)
      ptr+=sprintf(ptr,"-Bold");
    if (font->italic)
      ptr+=sprintf(ptr,"-Italic");
    /* Put the first first letter to upper case and replace spaces with dashes: */
    ptr=buf;
    *ptr=toupper(*ptr);
    while (*ptr!='\0')
    {
      if (*ptr==' ')
      {
        *ptr='-';
        if (ptr[1]!='\0' && ptr[1]!='-' && ptr[1]!=' ')
          ptr[1]=toupper(ptr[1]);
      }
      ++ptr;
    }
    return stringcopy(buf);
  }
return stringcopy("Courier");
}


static void sg_ps_text(char *str,float x1,float y1)
    /* Draws a text string str with che current color, allignment and font,
    at co-ordinates x1 and y1.
    $A Igor <== sep03;; */
{
float psitextscalingfactor=(float) fabs(psisizey);
char *psfontname=NULL;
_coord3d p;
float height=(float) 0.;
int xalign=1,yalign=1,underline=0,overstrike=0;
char buf[500],*ptr;
sg_font font=NULL;
buf[0]='\0';
if (fp==NULL)
{
  reportnofile("sg_ps_text");
  return ;
}
if (str!=NULL)
{
  /* Calculate window co-ordinates: */
  psiwindowcoord(x1,y1,&p);
  height=sg_gettextheight()*psitextscalingfactor;
  xalign=sg_gettextxalignment();
  yalign=sg_gettextyalignment();
  /* Alignment in vertical direction: */
  if (yalign==0)
    p.y-=height*0.5;
  else if (yalign==-1)
    p.y-=height;

  /* Compose PostScript name of the font: */
  if (sg_fonts!=NULL)
    if (sg_currentfont>0 && sg_currentfont<=sg_fonts->n)
      font=sg_fonts->s[sg_currentfont];
  if (font!=NULL)
  {
    underline=font->underline;
    overstrike=font->overstrike;
    if (stringlength(font->family)>0)
    {
      ptr=buf;
      ptr+=sprintf(ptr,"%s",font->family);
      if (font->bold)
        ptr+=sprintf(ptr,"-Bold");
      if (font->italic)
        ptr+=sprintf(ptr,"-Italic");
      /* Put the first first letter to upper case and replace spaces with dashes: */
      ptr=buf;
      *ptr=toupper(*ptr);
      while (*ptr!='\0')
      {
        if (*ptr==' ')
        {
          *ptr='-';
          if (ptr[1]!='\0' && ptr[1]!='-' && ptr[1]!=' ')
            ptr[1]=toupper(ptr[1]);
        }
        ++ptr;
      }
      psfontname=stringcopy(buf);
    }
  }
  if (psfontname==NULL)
    psfontname=stringcopy("Courier");
  fprintf(fp,"/%s %s ",psfontname,findfontstr);
  disppointer((void **) &psfontname);
  fprintf(fp,"%.*g %s ",psiprecision,height,scalefontstr);
  fprintf(fp,"%s ",setfontstr);
  
  
  
  /* New way of getting the PostScript font name: */
  /*
  psfontname=currentpsfontname();
  fprintf(fp,"/%s %s ",psfontname,findfontstr);
  disppointer((void **) &psfontname);
  */
  if (underline)
  {
    /* fprintf(fp,"\n %s ",newpathstr); */
    fprintf(fp,"%s ",newpathstr);
    fprintf(fp,"%.*g %.*g %s ",psiprecision,p.x,psiprecision,p.y,movetostr);
    /* Ensure proper allignment in x direction (this code must be the same as
    below before the text is shown: */
    if (xalign==0)
    {
      fprintf(fp,"\n(%s) stringwidth pop ",str);
      fprintf(fp,"-0.5 mul 0 rmoveto ");
    } else
    if (xalign==-1)
    {
      fprintf(fp,"\n(%s) stringwidth pop ",str);
      fprintf(fp,"-1 mul 0 rmoveto ");
    }
    if (underline)
    {
      fprintf(fp,"0 %.*g -0.1 mul rmoveto",psiprecision,height);
    }
    fprintf(fp,"\n(%s) stringwidth pop ",str);
    fprintf(fp,"0 rlineto ");
    fprintf(fp,"%s\n",strokestr);
  }
  if (overstrike)
  {
    /* fprintf(fp,"\n %s ",newpathstr); */
    fprintf(fp,"%s ",newpathstr);
    fprintf(fp,"%.*g %.*g %s ",psiprecision,p.x,psiprecision,p.y,movetostr);
    /* Ensure proper allignment in x direction (this code must be the same as
    below before the text is shown: */
    if (xalign==0)
    {
      fprintf(fp,"\n(%s) stringwidth pop ",str);
      fprintf(fp,"-0.5 mul 0 rmoveto ");
    } else
    if (xalign==-1)
    {
      fprintf(fp,"\n(%s) stringwidth pop ",str);
      fprintf(fp,"-1 mul 0 rmoveto ");
    }
    if (overstrike)
    {
      fprintf(fp,"0 %.*g 0.3 mul rmoveto",psiprecision,height);
    }
    fprintf(fp,"\n(%s) stringwidth pop ",str);
    fprintf(fp,"0 rlineto ");
    fprintf(fp,"%s\n",strokestr);
  }

  fprintf(fp,"%.*g %.*g %s ",psiprecision,p.x,psiprecision,p.y,movetostr);
  /* Ensure proper allignment in x direction: */
  if (xalign==0)
  {
    fprintf(fp,"\n(%s) stringwidth pop ",str);
    fprintf(fp,"-0.5 mul 0 rmoveto ");
  } else
  if (xalign==-1)
  {
    fprintf(fp,"\n(%s) stringwidth pop ",str);
    fprintf(fp,"-1 mul 0 rmoveto ");
  }
  psifprinttextcolor(fp); fprintf(fp," ");
  fprintf(fp,"(%s) %s \n",str,showstr);

  /* Draw borders for control of text position: */
  /*
  psimarktextpos(str,x1,y1,1,1); 
  */
}
}

static void sg_ps_line1(float x1,float y1,float x2,float y2)
    /* $A Igor <== apr97; */
{
if (fp==NULL)
{
  reportnofile("sg_ps_line");
  return ;
}
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
fprintf(fp,"%s ",newpathstr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
psifprintlinecolor(fp); fprintf(fp," ");
psifprintlinewidth(fp); fprintf(fp," ");
fprintf(fp,"%s\n",strokestr);
}















    /* INSTALLING THE PostScript DRAWING INTERFACE FOR SGS */



void sg_ps_interface(void)
    /* Activates the plotting interface for plotting into PostScript files.
    $A Igor sep03; */
{
sg_initintbas();  /* must be called at the beginning of every interface 
                     activation function */
/* First switch to default (empty) interface to override any active interface,
just to prevent mixing of functions in the case that any function is not
implemented and installed in this interface: */
sg_interface(SG_PLOT_DEFAULT);
/* Mark the active interface: */
sg_interfaceid=SG_PLOT_PS;
if (sg_windows==NULL)
  sg_windows=newstack(10);
if (sg_fonts==NULL)
  sg_fonts=newstack(5);
/* We need to register the interface houskeeping functions: */
sg_register_dispwin((void (*)(void **)) dispps_windata); /* for deletion of intfc. specific win. data */
sg_register_dispfont((void (*)(void **)) dispps_fontdata); /* deletion of intfc. specific font data */
/* INSTALL INTERFACE SPECIFIC PLOTTING FUNCTIONS: */
/* WINDOW (and graphic context) HNADLING: */
sg_openwindow = sg_ps_openwindow;
sg_setwindow = sg_ps_setwindow;
sg_clearwindow = sg_ps_clearwindow;
sg_resetwindow = sg_ps_resetwindow;
sg_closewindow = sg_ps_closewindow;
sg_raisewindow = sg_ps_raisewindow;
sg_installfont=sg_installfont_default;  /* THIS SHOULD BE CHANGED! */
sg_installfontstr = sg_installfontstr_default;  /* THIS SHOULD BE CHANGED! */
sg_setcoloring = sg_setcoloring;
sg_setnumshades = sg_setnumshades;
sg_colortabsize = sg_colortabsize;
sg_preindexcolors = sg_preindexcolors;
sg_setwindowtitle = sg_setwindowtitle;
sg_getwindowtitle = sg_getwindowtitle;
sg_setwindowxpos = sg_setwindowxpos;
sg_getwindowxpos = sg_getwindowxpos;
sg_setwindowypos = sg_setwindowypos;
sg_getwindowypos = sg_getwindowypos;
sg_setwindowwidth = sg_setwindowwidth;
sg_getwindowwidth = sg_getwindowwidth;
sg_setwindowheight = sg_setwindowheight;
sg_getwindowheight = sg_getwindowheight;
sg_nsetwindowxpos = sg_nsetwindowxpos;
sg_ngetwindowxpos = sg_ngetwindowxpos;
sg_nsetwindowypos = sg_nsetwindowypos;
sg_ngetwindowypos = sg_ngetwindowypos;
sg_nsetwindowwidth = sg_nsetwindowwidth;
sg_ngetwindowwidth = sg_ngetwindowwidth;
sg_nsetwindowheight = sg_nsetwindowheight;
sg_ngetwindowheight = sg_ngetwindowheight;
sg_setpointsize = sg_setpointsize;
sg_getpointsize = sg_getpointsize;
sg_setcurvepoints = sg_setcurvepoints;
sg_getcurvepoints = sg_getcurvepoints;
/* SETTING COLORS: */
sg_setlinecolor= sg_setlinecolor;
sg_getlinecolor = sg_getlinecolor;
sg_setfillcolor = sg_setfillcolor;
sg_getfillcolor = sg_getfillcolor;
sg_settextcolor = sg_settextcolor;
sg_gettextcolor = sg_gettextcolor;
/* LINE SETTINGS */
sg_setlinewidth = sg_setlinewidth;
sg_getlinewidth = sg_getlinewidth;
sg_setlinetype = sg_setlinetype;
sg_getlinetype = sg_getlinetype;
/* TEXT SETTINGS: */
sg_settextfont = sg_settextfont;
sg_gettextfont = sg_gettextfont;
sg_settextheight = sg_settextheight;
sg_gettextheight = sg_gettextheight;
sg_settextxalignment = sg_settextxalignment;
sg_gettextxalignment = sg_gettextxalignment;
sg_settextyalignment = sg_settextyalignment;
sg_gettextyalignment = sg_gettextyalignment;
sg_settextalignment = sg_settextalignment;
sg_gettextalignment = sg_gettextalignment;
/* BASIC DRAWING FUNCTIONS: */
sg_line = sg_ps_line;
sg_triangle = sg_ps_triangle;
sg_fourangle = sg_ps_fourangle;
sg_filltriangle = sg_ps_filltriangle;
sg_fillfourangle = sg_ps_fillfourangle;
sg_text = sg_ps_text;
/* BASIC GRAPHIC ELEMENTS THAT ARE DRAWN BY OTHER DRAWING FUNCTIONS: */
sg_rectangle = sg_rectangle_default;
sg_circle = sg_circle_default;
sg_circlearc = sg_circlearc_default;
sg_ellipse = sg_ellipse_default;
sg_ellipsearc = sg_ellipsearc_default;
sg_fillrectangle = sg_fillrectangle_default;
sg_point = sg_point_default;
sg_fillcircle = sg_fillcircle_default;
sg_fillcirclearc = sg_fillcirclearc_default;
sg_fillellipse = sg_fillellipse_default;
sg_fillellipsearc = sg_fillellipsearc_default;
/* FUNCTIONS FOR DRAWING MARKERS (=points) AND ARROWS (vectors) : */
sg_marker = sg_marker_default;
sg_registermarker = sg_registermarker_default;
sg_arrow = sg_arrow_default;
/* DRAWING STACKS (or better lists) OF GRAPHIC PRIMITIVES: */
sg_godrawstack = sg_godrawstack;

/* RESET LOCAL VARIABLES (especially those that concern windows, since windows
are treated independently by different graphic interfaces: */
fp=NULL;
nofilereported=0;
}

