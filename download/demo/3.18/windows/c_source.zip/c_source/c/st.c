

             /*********************************/
             /*                               */
             /*    STACKS AND INDEX TABLES    */
             /*                               */
             /*********************************/


/*
#define EXTRACE
#define EXTRACEMEM
*/

#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>

#include <er.h>

#include <mtypes.h>
#include <rf.h>
#include <rand.h>
#include <itk.h>

#include <st.h>


#ifndef INCLUDED_strop
static void disppointer(void **p)
    /* Function for releasing pointers, otherwise defined in strop.c.
    $A Igor apr98; */
{
if (p!=NULL)
{
  if (*p!=NULL)
  {
    free(*p);
    *p=NULL;
  }
}
}
#endif

/* Definition for macros m_threadlock and m_threadunlock: */
#ifndef ITK
static void Tcl_Sleep(int ms)
{
  int i,j,k;
  for (k=1;k<=ms;++k)
  {
    for (i=1;i<=1000;++i)
      j=2*i;
  }
}
#endif




/* 
void initstack(stack st,int excess)
      Inicializira sklad. Vrednost excess se priredi polju ex in pove, koliko
     dodatnega spomina se rezervira pri potiskanju na sklad v primeru, da je
     rezerviran prostor ze zapolnjen.
{
if (excess<0)
  excess=0;
st->n=0;
st->r=0;
st->ex=excess;
st->s=NULL;
}
 */



#define initstack(st,e) {int ex=(e); if (ex<0) ex=0; (st)->n=0; (st)->r=0; (st)->ex=ex; (st)->s=NULL; }


stack newstack(int excess)
      /* Alocira prostor za spremenljivko tipa _stack, spremenljivko
      inicializira z vrednostjo excess in vrne kazalec nanjo. */
{
stack ret;
if (excess<1)
  excess=1;
/*
ret=calloc(1,sizeof(_stack));
*/
ret=malloc(sizeof(*ret));
initstack(ret,excess);
return ret;
}


stack newstackr(int excess,int r)
    /* Alocira prostor za spremenljivko tipa _stack, pri cemer spremenljivko
    inicializira z vrednostjo excess in rezerviranim prostorom za r kazalcev,
    ki jih postavi na NULL, ter vrne kazalec na alociran prostor. Polje n na
    skladu postavi na 0.
    $A Igor nov00;  */
{
int i;
stack ret;
if (excess<1)
  excess=1;
if (r<0)
  r=0;
ret=malloc(sizeof(*ret));
initstack(ret,excess);
ret->r=r;
ret->n=0;
if (r>0)
{
  ret->s=malloc(r*sizeof(void *));
  --ret->s;
  for (i=1;i<=r;++i)
    ret->s[i]=NULL;
}
return ret;
}

stack newstackrn(int excess,int r)
    /* Alocira prostor za spremenljivko tipa stack, pri cemer spremenljivko
    inicializira z vrednostjo excess in rezerviranim prostorom za r kazalcev,
    ki jih postavi na NULL, ter vrne kazalec na alociran prostor. Polje n na
    skladu postavi kar na r.
    $A Igor jul01;  */
{
int i;
stack ret;
if (excess<1)
  excess=1;
if (r<0)
  r=0;
ret=malloc(sizeof(*ret));
initstack(ret,excess);
ret->r=ret->n=r;
if (r>0)
{
  ret->s=malloc(r*sizeof(void *));
  --ret->s;
  for (i=1;i<=r;++i)
    ret->s[i]=NULL;
}
return ret;
}


void resizestack(stack *addrst,int excess,int n,void (*disp)(void **))
    /* Resizes the stack *addrst so that it contains n elements after operation.
    excess is the value of *addrst->ex; if it is less than 1 then it is set
    automatically according to n. n is the requested number of elements of the
    stack after the operation. disp is the function for deletion of stack
    elements, if it is NULL then simply dispppointer is used.
      Eventual redundant elements on the stack are deleted. If there are too
    few elements on the stack then NULL pointers are added. 
    $A Igor oct04; */
{
stack st;
int i;
if (addrst!=NULL)
{
  if (n<0)
    n=0;
  if (*addrst==NULL)
  {
    if (excess<1)
    {
      excess=n/4;
      if (excess<5)
        excess=5;
    }
    *addrst=newstackrn(excess,n);
  } else
  {
    st=*addrst;
    if (disp==NULL)
      disp=disppointer;
    if (excess>0)
      st->ex=excess;
    if (st->n<n)
    {
      /* There ae too few elements on the stack, we add NULL pointers to filll
      the necessary places; first allocate additional memory if necessary: */
      if (st->r<n)
      {
        st->r=n;
        if (st->s!=NULL)
          ++st->s;
        st->s=realloc(st->s,st->r*sizeof(void *));
        --st->s;
      }
      for (i=st->n+1;i<=n;++i)
        st->s[i]=NULL;  /* fill missing places with NULL */
      st->n=n;
    } else if (st->n>n)
    {
      for (i=n+1;i<=st->n;++i)
      {
        disppointer(&(st->s[i]));
        st->s[i]=NULL;
      }
      st->n=n;
      if (st->r>st->n+st->ex*2)
      {
        st->r=n+st->ex;
        if (st->s!=NULL)
          ++st->s;
        st->s=realloc(st->s,st->r*sizeof(void *));
        --st->s;
      }
    }
  }
}
}

void dispstack(stack *st)
     /* Sprosti spomin za spremenljivko tipa stack*. Ce stack vsebuje tabelo
     kazalcev, sprosti najprej to tabelo.
     */
{
if (st!=NULL)
  if (*st!=NULL)
  {
    if ((*st)->s!=NULL /* && (*st)->r!=0 $$$! */ )
      free(++(*st)->s);
    free(*st);
    *st=NULL;
  }
}


void dispstackval(stack st)
     /* Sprosti vse spominske lokacije, na katere kazejo elementi sklada st */
{
int i;
if (st!=NULL)
  if (st->s!=NULL && st->n>0)
  {
    for (i=1; i<=st->n; ++i)
    {
      if (st->s[i]!=NULL)
      {
        free(st->s[i]);
        st->s[i]=NULL;
      }
    }
    st->n=0;
  }
}


void dispstackvalspec(stack st,void (*disp) (void **))
    /* Zbrise vse elemente, na katere kazejo kazalci, nalozeni na sklad st,
    pri cemer se za brisanje posameznih elementov uporabi funkcija disp, ki
    vzame za argument naslov kazalca, ki kaze na element, ki ga je treba
    brisati. Ce je disp enak NULL, se elementi brisejo s funkcijo free().
    $A Igor avg97; */
{
int i;
if (st!=NULL)
  if (st->s!=NULL && st->n>0)
  {
    for (i=1; i<=st->n; ++i)
    {
      if (st->s[i]!=NULL)
      {
        if (disp!=NULL)
          disp(&(st->s[i]));
        else
        {
          free(st->s[i]);
          st->s[i]=NULL;
        }
      }
    }
    st->n=0;
  }
}


void dispstackall(stack *st)
    /* Sprosti vse spominske lokacije, na katere kazejo elementi sklada *st,
    in zbrise sam sklad ter postavi *st na NULL. Za brisanje elementov sklada
    uporabi sistemsko funkcijo free().
    $A Igor nov00; */
{
if (st!=NULL)
{
  dispstackval(*st);
  if (*st!=NULL)
  {
    if ((*st)->s!=NULL /* && (*st)->r!=0 $$$! */ )
      free(++(*st)->s);
    free(*st);
    *st=NULL;
  }
}
}

void dispstackallspec(stack *st,void (*disp) (void **))
    /* Sprosti vse spominske lokacije, na katere kazejo elementi sklada *st,
    in zbrise sam sklad ter postavi *st na NULL. Za brisanje elementov sklada
    uporabi funkcijo disp(). Ce je disp enak NULL, se elementi brisejo s
    sistemsko funkcijo free().
    $A Igor nov00; */
{
if (st!=NULL)
{
  if (disp!=NULL)
    dispstackvalspec(*st,disp);
  else
    dispstackval(*st);
  if (*st!=NULL)
  {
    if ((*st)->s!=NULL)
      free(++(*st)->s);
    free(*st);
    *st=NULL;
  }
}
}


void fprintstack(FILE *fp,stack st,void (*fprintel) (FILE *fp,void *el))
    /* Prints the stack st and its elements to the file fp. fprintel() is 
    called to print each individual element on the stack. If fprintel is NULL
    then elements are not printed, but 0 is printed for each element if it is
    NULL and 1 if it is not NULL.
    $A Igor mar05; */
{
int i;
if (fp!=NULL)
{
  if (st==NULL)
    fprintf(fp,"Stack is NULL.\n");
  else
  {
    fprintf(fp,"Stack:\n");
    fprintf(fp,"Number of elements:     %i\n",st->n);
    fprintf(fp,"Allocated space:        %i pointers\n",st->r);
    fprintf(fp,"Excess at reallocation: %i\n",st->ex);
    if (st->s==NULL)
      fprintf(fp,"Table of elements is NULL.\n");
    else if (st->n>0)
    {
      fprintf(fp,"Elements on the stack:\n");
      if (fprintel==NULL)
      {
        for (i=1;i<=st->n;++i)
        {
          if (st->s[i]==NULL)
            fprintf(fp,"0 ");
          else
            fprintf(fp,"1 ");
        }
        fprintf(fp,"\n");
      } else
      {
        for (i=1;i<=st->n;++i)
        {
          fprintf(fp,"Element %i:\n",i);
          fprintel(fp,st->s[i]);
          fprintf(fp,"\n");
        }
      }
    }
  }
}
}

void printstack(stack st,void (*fprintel) (FILE *fp,void *el))
    /* The same as fprintstack(), but prints to the standard output rather to
    a particular file.
    $A Igor mar05; */
{
fprintstack(stdout,st,fprintel);
}


void fprintstacklist(FILE *fp,stack st,void (*fprintel) (FILE *fp,void *el))
    /* Prints elements of stack st to file fp as a list of objects, listed in
    curly brackets { } and dliminated by commas. fprintel() is called to print
    each individual element on the stack.
    A single newline is printed after the last curly bracket.
    $A Igor mar05; */
{
int i;
if (fp!=NULL)
{
  if (st==NULL)
    fprintf(fp,"NULL\n");
  else if (st->n<1)
    fprintf(fp,"{ }\n");
  else
  {
    fprintf(fp,"{ \n  ");
    for (i=1;i<=st->n;++i)
    {
      if (fprintel==NULL)
        fprintf(fp,"?");
      else
        fprintel(fp,st->s[i]);
      if (i<st->n)
        fprintf(fp,",\n  ");
      /*
      else
        fprintf(fp,"");
      */
    }
    fprintf(fp,"\n}\n");
  }
}
}

void printstacklist(stack st,void (*fprintel)(FILE *fp,void *el))
    /* The same as fprintstacklist(), but prints to the standard output rather
    to a specified file.
    $A Igor mar05; */
{
fprintstacklist(stdout,st,fprintel);
}


void fprintstacklistline(FILE *fp,stack st,void (*fprintel) (FILE *fp,void *el))
    /* The same as fprintstacklist(), but it prints stack elements in a single
    line. Therefore, if function fprintel() does not add any newlines, then 
    output does not contain newlines.
    $A Igor mar05; */
{
int i;
if (fp!=NULL)
{
  if (st==NULL)
    fprintf(fp,"NULL\n");
  else if (st->n<1)
    fprintf(fp,"{ }");
  else
  {
    fprintf(fp,"{ ");
    for (i=1;i<=st->n;++i)
    {
      if (fprintel==NULL)
        fprintf(fp,"?");
      else
        fprintel(fp,st->s[i]);
      if (i<st->n)
        fprintf(fp,",  ");
      /*
      else
        fprintf(fp,"");
      */
    }
    fprintf(fp," }");
  }
}
}

void printstacklistline(stack st,void (*fprintel)(FILE *fp,void *el))
    /* The same as fprintstacklistline(), but prints to the standard output
    rather to a specified file.
    $A Igor mar05; */
{
fprintstacklistline(stdout,st,fprintel);
}

int sizestack0(stack st)
    /* Returns the size of the memory occupied by st without its elements.
    $A Igor nov03; */
{
int ret=0;
if (st!=NULL)
{
  ret+=sizeof(*st);
  if (st->r>0 && st->s!=NULL)
    ret+=st->r*sizeof(*(st->s));
}
return ret;
}


int sizestack(stack st,int sizeel(void *))
    /* Returns the size of the memory occupied by st including its elements.
    sizeel must be a function that calculates and returns a size of an
    individual element.
    $A Igor nov03; */
{
int ret=0,i;
void *el;
if (st!=NULL)
{
  ret+=sizestack0(st);
  if (sizeel!=NULL && st->n>0)
    for (i=1;i<=st->n;++i)
    {
      if ((el=st->s[i])!=NULL)
        ret+=sizeel(el);
    }
}
return ret;
}


stack copystack(stack st1,stack *st2)
    /* Copies the stack st1 to *st2 and returns the pointer to the copy. If
    st2==NULL then a copy of st1 is created anew and its pointer returned.
      WARNING!
      The elements of the stack are copied by simply copying their pointers!
    Therefore, this function may not be used if *st2 contains any elements
    and pointers loaded on it are the only handles of these elements.
    $A Igor nov03; */
{
stack ret;
int i;
if (st2!=NULL)
{
  /* If st2!=NULL, then st1 is copied to st2: */
  if (st1==NULL)
  {
    dispstack(st2);
  } else
  {
    if (*st2!=NULL)
      dispstack(st2);
    /* Allocate *st2: */
    *st2=newstackrn(st1->ex,st1->n);
    ret=*st2;
    /* Copying - only pointers are copied, not the contents: */
    for (i=1;i<=st1->n;++i)
      ret->s[i]=st1->s[i];
  }
  return *st2; /* since st2!=NULL. */
} else
{
  /* st2==NULL, a new object is created that is a copy of st1 and returned */
  if (st1==NULL)
    return NULL;
  else
  {
    ret=newstackrn(st1->ex,st1->n);
    /* Copying elements - only pointers are copied, not the contents: */
    for (i=1;i<=st1->n;++i)
      ret->s[i]=st1->s[i];
    return ret;
  }
}
}



stack copystackspec(stack st1,stack *st2,void dispel(void **),
                    void *copyel (void *,void **) )
    /* Copies the stack st1 to *st2 and returns the pointer to the copy. If
    st2==NULL then a copy of st1 is created anew and its pointer returned.
      By dispel we must specify a function for deletion of eventual elements
    that existed on *st2, while with copyel we must specify the function for
    copying individual elements from the original stack st1 to the copy.
      WARNING!
      dispel and copyel should normally be different than NULL. If dispel or
    copyel are NULL, then these functions are simply not executed on those
    elements on which they should. Instead of copying elements, elements on
    the resulting stack are SET TO NULL. This may be useful in some cases
    (e.g. when the resulting stack exists but its elements are also stored
    somewhere else, so they should not be released here, and we don't want
    to copy elements, but just set elements on the resulting stack to NULL).
    $A Igor nov03; */
{
stack ret;
void *el;
int i;
if (dispel==NULL || copyel==NULL)
{
  errfunc0("copystackspec");
  sprintf(ers(),"Functions for deleting and copying stack elements not specified!");
  errfunc2();
}
if (st2!=NULL)
{
  /* If st2!=NULL, then st1 is copied to st2: */
  if (st1==NULL)
  {
    if (dispel==NULL)
      dispstack(st2);
    else
      dispstackallspec(st2,dispel);
  } else
  {
    if (*st2!=NULL)
    {
      /* Delete the excessive elements: */
      while ((*st2)->n>st1->n)
      {
        el=popstack(*st2);
        if (el!=NULL && dispel!=NULL)
          dispel(&el);
      }
    }
    /* Allocate *st2 if necessary: */
    if (*st2==NULL)
      *st2=newstackrn(st1->ex,st1->n);
    ret=*st2;
    while (ret->n<st1->n)
      pushstack(ret,NULL);
    /* Copying - only pointers are copied, not the contents: */
    for (i=1;i<=st1->n;++i)
    {
      if (copyel!=NULL)
        copyel(st1->s[i],&(ret->s[i]));
      else if (dispel!=NULL)
        dispel(&(ret->s[i]));
      else
      {
        if (ret->s[i]!=NULL)
        {
          /*
          free(ret->s[i]);
          */
          ret->s[i]=NULL;
        }
      }
    }
  }
  return *st2; /* since st2!=NULL. */
} else
{
  /* st2==NULL, a new object is created that is a copy of st1 and returned */
  if (st1==NULL)
    return NULL;
  else
  {
    ret=newstackrn(st1->ex,st1->n);
    /* Copying elements - only pointers are copied, not the contents: */
    for (i=1;i<=st1->n;++i)
    {
      if (st1->s[i]!=NULL && copyel!=NULL)
        copyel(st1->s[i],&(ret->s[i]));
    }
    return ret;
  }
}
}


void pushstack(stack st, void *el)
     /* Doda element el na konec sklada. Ce je potrebno, predhodno razsiri
     sklad. */
{
if (st!=NULL)
{
  if (st->n>=st->r)
  {
    if (st->ex<1)
      st->ex=1;  
    st->r=st->r+st->ex+1;
    if (st->s!=NULL)
      ++ st->s;
    st->s=realloc(st->s,st->r*sizeof(void*));
    -- st->s;  
  }
  ++ st->n;
  st->s[st->n]=el;
}
}



void insstack(stack st,void *el,int place)
     /* V skladu st vrine na mesto place element el. Ostali elementi se
     pomaknejo za eno mesto navzgor. Ce je place vecji od stevila elementov
     sklada st->n, se vrzeli zapolnijo s kazalci NULL. */
{
int i;
if (st!=NULL)
{
  while (place>st->n+1)
    pushstack(st,NULL);
    
  if (place==st->n+1)
    pushstack(st,el);
  else if (place>=1 && place<=st->n)
  {
    if (st->r<=st->n)
    /* Alocira se nov spominski prostor, ce je to potrebno: */
    {
      if (st->ex<1)
        st->ex=1;
      st->r=st->r+st->ex+1;
      if (st->s!=NULL)
        ++ st->s;
      st->s=realloc(st->s,st->r*sizeof(void*));
      --(st->s);
    }
    /* Elementi sklada od mesta place naprej se pomaknejo za eno mesto navzgor: */
    for (i=st->n+1; i>place;--i)
      st->s[i]=st->s[i-1];
    /* Mesto place zavzame vrinjeni element: */
    st->s[place]=el;
    ++(st->n);
  }
}
}





void * setstack(stack st,void *el,int place)
     /* Sets the element at position place on the stack st to el. If the stack
     contains less than place elements, NULL pointers are pushed to stack first
     until it contains  place elements. The function returns the element that
     was on the position place before its execution, so we caan for example
     delete it. If the stack is NULL, the function just returns NULL.
     $A Igor sep03; */
{
void *ret=NULL;
if (st!=NULL && place>0)
{
  while (place>st->n)
    pushstack(st,NULL);  /* fill until position place if necessary */
  /* Store element at place for return, then set it to el: */
  ret=st->s[place];
  st->s[place]=el;
}
return ret;
}





void *popstack(stack st)
     /* Vzame zadnji element s stacka, hkrati pa vrne njegovo vrednost.
     Ce s tem postane velikost stacka za vec kot excess vecja od stevila
     elementov v njem, se velikost skrci na trenutno stevilo elementov.
     Ce je stack prazen, je vrnjena vrednost NULL. */
{
void **new;
void *ret=NULL;
if (st!=NULL)
{
  /*
  if (st->n<1)
    ret=NULL;
  else
  */
  if (st->n>0)
  {
    ret=st->s[st->n];
    -- st->n;
    if (st->n==0)
    {
      st->r=0;
      ++ st->s;
      free(st->s);
      st->s=NULL;
    } else if (st->r-st->n>st->ex)
    {
      st->r=st->n;
      new=calloc(st->r,sizeof(void*));
      ++ st->s;
      memcpy(new,st->s,st->r*sizeof(void*));
      free(st->s);
      if (st->r>0 && new!=NULL)
      {
        -- new;
        st->s=new;
      }
    }
  }
}
return ret;
}



void *delstack(stack st,int place)
     /* v skladu st odstrani element place na mestu place. Poznejsi elementi se
     pomaknejo za eno mesto navzdol. Funkcija vrne element (tipa void*!), ki je
     bil prej na mestu place. Z objektom, na katerega kaze ta element, se ne
     zgodi nic.*/
{
char t=0;
int i;
void *ret;
if (place>=1 && place<=st->n)
{
  ret=st->s[place];
  t=1;
}
if (place>=1 && place<st->n)
  for (i=place;i<=st->n-1;++i)
    st->s[i]=st->s[i+1];
if (t)
  popstack(st);
return ret;
}






void npopstack(stack st,int n)
     /* S sklada pobere n elementov. Ne vrne nobene vrednosti. */
{
int i;
if (n>0)
{
  for (i=1; i<=n; ++i)
    popstack(st);
}
}





void popstackall(stack st)
     /* S sklada pobere vse elemente. Ne vrne nobene vrednosti. */
{
/*
marker("popstackall",'1');
*/
if (st!=NULL)
{
  if (st->s!=NULL && st->r!=0)
    free(++(st)->s);
  st->n=0;
  st->r=0;
  st->s=NULL;
}
/*
deler("popstackall");
*/
}







void *stackel(stack st,int n)
     /* Vrne n-ti zaporedni element na skladu st. Ce ni zahtevanega elementa,
     vrne NULL. Stetje se zacne z 1.
     $A Igor <== avg97; */
{
if (st!=NULL)
{
  if (n<=st->n && n>0)
    return st->s[n];
  else
    return NULL;
} else return NULL;
}






void *nstack(stack st, int n)
     /* Vrne n-ti element sklada st od zadaj naprej. Ce ni zahtevanega 
     elementa, vrne NULL. Stetje se zacne z 1.
     $A Igor <== avg97; */
{
if (st!=NULL)
{
  if (n<=st->n && n>0)
    return st->s[st->n+1-n];
  else
    return NULL;
} else return NULL;
}










int findstack(stack st,void *ptr,int from, int to,int cmp(void *p1,void *p2))
    /* Na skladu st najde 1. taksen kazalec med from in to, da je objekt, na
    katerega kaze, enak objektu, na katerega kaze kazalec ptr. Kriterij za
    enakost je funkcija cmp, ki mora vrniti vrednost 0, ce sta objekta, na
    katera kazeta kazalca p1 in p2, enaka, ter katerokoli drugo vrednost, ce
    nista. funkcija vrne mesto, na katerem je ta kazalec. Ce taksnega mesta ne
    najde, vrne 0.
      Ce je from enako 0, funkcija isce od 1. elementa sklada naprej, ce pa je
    to enoko 0, isce funkcija do zadnjega elementa slada.
    VAZNA OPOMBA: 1. argument, ki se nalozi funkciji cmp, je vedno ptr !!!
    Zato mora biti tudi funkcija cmp narejena tako, da vzame ptr kot 1. arg.
    */
{
int i,ret=0,found=0;
if (st!=NULL)
{
  if (from<=0)
    from=1;
  if (to<=0)
    to=st->n;
  i=from;
  while (i<=to && !found && i<=st->n)
  {
    if (cmp(ptr,st->s[i])==0)
    {
      ret=i;
      found=1;
    }
    ++i;
  }
}
return ret;
}





void qsortstack0(stack st,int cmp(const void *p1,const void *p2))
     /* Sorts elements of the stack st in such a way that they are ordered in
     increasing order according to the function cmp. cmp must return -1 if the
     first argument (i.e. the object pointed to by this argument) is smaller 
     than the second, 0 if they are equal and 1 if the first element is larger
     than the second element.
       Function uses the standard function qsort.
     $A Igor jul05; */
{
/* Prevent asynchroneous modification of cmpfunction by parallel threads: */
if (st!=NULL) if (st->n>0 && cmp!=NULL)
  qsort(st->s+1,st->n,sizeof(void *),cmp);
}


void qsortstacklim0(stack st,int from,int to,
                    int cmp(const void *p1,const void *p2))
    /* Similar to qsortstack, except that it sorts only elements between
    from and to inclusively.
    $A Igor jul05; */
{
if (st!=NULL)
{
  if (from<=0)
    from=1;
  if (to<=0)
    to=st->n;
  else if (to>st->n)
    to=st->n;
  if (from<to)
    qsort(st->s+from,to-from+1,sizeof(void *),cmp);
}
}



static int sortlock=0;  /* For multiple thread compatibility */
static int (*cmpfunction) (void *,void *); /* Auxiliary for qsortstack. */

static int comparefunction (const void *t1,const void *t2)
    /* Auxiliary function for qsortstack() and qsortstacklim(). introduced for
    casting from int(void *,void*) to int(const void *, const void *) */
{
void *p1,*p2;
p1=* (void **) t1; p2=* (void **) t2;
return cmpfunction(p1,p2);
}



void qsortstack(stack st,int cmp(void *p1,void *p2))
     /* Funkcija presortira elemente sklada st tako, da si sledijo v
     narascajocem vrstnem redu. To je misljeno pravzaprav za objekte, na katere
     kazejo kazalci, ki so na tem skladu. Funkcija cmp mora biti taksna, da vrne
     -1, ce je element, na katerega kaze p1, manjsi od elementa, na katerega
     kaze p2, 0, ce sta enaka, drugace pa 1.
       Funkcija uporablja standardno funkcijo qsort, ki pa je namenjena za
     sortiranje tabel, v katerih so ze elementi, ki jih sortiramo, ne pa kazalci
     nanje. Zato funkcija qsortstack uporablja funkcijo comparefunction kot
     vmesnik. */
{
/* Prevent asynchroneous modification of cmpfunction by parallel threads: */
m_threadlocksleep(sortlock,1);
/* Perform sorting: */
cmpfunction=cmp;
if (st!=NULL && st->n>0)
  qsort(st->s+1,st->n,sizeof(void *),comparefunction);
m_threadunlock(sortlock);
}


void qsortstacklim(stack st,int from,int to,int cmp(void *p1,void *p2))
    /* Similar to qsortstack, except that it sorts only elements between
    from and to inclusively.
    $A Igor apr04; */
{
/* Prevent asynchroneous modification of cmpfunction by parallel threads: */
m_threadlocksleep(sortlock,1); 
/* Perform sorting: */
cmpfunction=cmp;
if (st!=NULL)
{
  if (from<=0)
    from=1;
  if (to<=0)
    to=st->n;
  else if (to>st->n)
    to=st->n;
  if (from<to)
    qsort(st->s+from,to-from+1,sizeof(void *),comparefunction);
    /*
    To ne dela:
    qsort(st->s+from,to-from+1,sizeof(void *),
      ( int (*)(const void *, const void * ) ) cmp);
    */
}
m_threadunlock(sortlock);
}






void qsortstackold(stack st,int cmp(void *p1,void *p2))
     /* Funkcija presortira elemente sklada st tako, da si sledijo v
     narascajocem vrstnem redu. To je misljeno pravzaprav za objekte, na katere
     kazejo kazalci, ki so na tem skladu. Funkcija cmp mora biti taksna, da vrne
     -1, ce je element, na katerega kaze p1, manjsi od elementa, na katerega
     kaze p2, 0, ce sta enaka, drugace pa 1.
       Funkcija uporablja standardno funkcijo qsort, ki pa je namenjena za
     sortiranje tabel, v katerih so ze elementi, ki jih sortiramo, ne pa kazalci
     nanje. Zato funkcija qsortstack uporablja funkcijo comparefunction kot
     vmesnik. */
{
char end=0;
while(!end)
{
  while (sortlock)
  {
    /* If another sorting goes on, wait until finished: */
#ifdef ITK
    Tcl_Sleep(1);
#else
    sleep(1);
#endif
  }
  /* No other sorting from parallel threads, set lock, check and proceed: */
  ++sortlock;
  if (sortlock==1)
  {
    end=1;
    /* Perform sorting: */
    cmpfunction=cmp;
    if (st!=NULL && st->n>0)
      qsort(st->s+1,st->n,sizeof(void *),comparefunction);
  }
  --sortlock;
}
}


void qsortstacklimold(stack st,int from,int to,int cmp(void *p1,void *p2))
    /* Similar to qsortstack, except that it sorts only elements between
    from and to inclusively.
    $A Igor apr04; */
{
char end=0;
while(!end)
{
  while (sortlock)
  {
    /* If another sorting goes on, wait until finished: */
#ifdef ITK
    Tcl_Sleep(1);
#else
    sleep(1);
#endif
  }
  /* No other sorting from parallel threads, set lock, check and proceed: */
  ++sortlock;
  if (sortlock==1)
  {
    end=1;
    /* Perform sorting: */
    cmpfunction=cmp;
    if (st!=NULL)
    {
      if (from<=0)
        from=1;
      if (to<=0)
        to=st->n;
      else if (to>st->n)
        to=st->n;
      if (from<to)
        qsort(st->s+from,to-from+1,sizeof(void *),comparefunction);
        /*
        To ne dela:
        qsort(st->s+from,to-from+1,sizeof(void *),
          ( int (*)(const void *, const void * ) ) cmp);
        */
    }
  }
  --sortlock;
}
}


int findsortstack(stack st,void *ptr,int from, int to,
                  int cmp(void *p1,void *p2))
    /* Na skladu st najde 1. taksen kazalec med from in to, da je objekt, na
    katerega kaze, enak objektu, na katerega kaze kazalec ptr. Kriterij za
    enakost je funkcija cmp, ki mora vrniti vrednost 0, ce sta objekta, na
    katera kazeta kazalca p1 in p2, enaka, negativno vrednost, ce je prvi
    objekt manjsi in pozitivno vrednost, ce je 1. objekt vecji.
    Funkcija vrne mesto, na katerem je ta kazalec. Ce taksnega mesta ne
    najde, vrne 0. Sklad st mora biti sortiran glede na funkcijo cmp v
    narascajocem vrstnem redu.
      Ce je from enako 0, funkcija isce od 1. elementa sklada naprej, ce pa je
    to enoko 0, isce funkcija do zadnjega elementa slada.
    VAZNA OPOMBA: 1. argument, ki se nalozi funkciji cmp, je vedno ptr !!!
    Zato mora biti tudi funkcija cmp narejena tako, da vzame ptr kot 1. arg.
    $A Igor dec97; */
{
int ret=0,left=0,right=0,middle=0,resmiddle;
if (st!=NULL)
  if (st->n>0)
  {
    if (from<=0)
      from=1;
    if (to<=0)
      to=st->n;
    if (to>st->n)
      to=st->n;
    if (from<=to)
    {
      middle=from-1+(int) round((1.1+(double) to-(double) from)*0.5);
      resmiddle=cmp(ptr,st->s[middle]);
      if (resmiddle==0)
        ret=middle;
      /* Ce je iskani element vecji od 1. poskusa, se isce interval, ki vsebuje
      element, s pomikanjem navzgor po skladu: */
      if (resmiddle>0)
      {
        while (resmiddle>0 && ret<1 && middle<to)
        {
          left=middle;
          middle=left+ (int) round(0.1+(to-left)*0.5);
          resmiddle=cmp(ptr,st->s[middle]);
          if (resmiddle<0)
            right=middle;
          else if (resmiddle==0)
            ret=middle;
        }
      }
      else if (resmiddle<0)
      {
        while (resmiddle<0 && ret<1 && middle>from)
        {
          right=middle;
          middle=right-(int) round(0.1+(right-from)*0.5);
          resmiddle=cmp(ptr,st->s[middle]);
          if (resmiddle>0)
            left=middle;
          else if (resmiddle==0)
            ret=middle;
        }
      }
      if (left>0 && right>0)
        while (ret<1 && right-left>1)
        {
          middle=(int) round((right+left)*0.5);
          resmiddle=cmp(ptr,st->s[middle]);
          if (resmiddle<0)
            right=middle;
          else if (resmiddle>0)
            left=middle;
          else
            ret=middle;
        }
      /* Zagotoviti je treba, da se res vrne prvi pojav kazalca , ki je glede
      na funkcijo cmp enak kazalcu ptr (samo v primeru, ce je ret>from): */
      if (ret>from)
        resmiddle=0;
      else
        resmiddle=1;
      while (!resmiddle)
      {
        if ( (resmiddle=cmp(ptr,st->s[ret-1])) ==0)
        {
          /* ret zmanjsamo za 1, ker je tudi element na mestu ret-1 enak ptr: */
          --ret;
          if (ret<2)
            resmiddle=1; /* Ce je ret ze enak 1, bomo prenehali z zmanjsevanjem */
        }
      }
    }
  }
return ret;
}


void *ptrfindsortstack(stack st,void *ptr,int from, int to,
                       int cmp(void *p1,void *p2))
    /* Na skladu st najde 1. taksen kazalec med from in to, da je objekt, na
    katerega kaze, enak objektu, na katerega kaze kazalec ptr. Kriterij za
    enakost je funkcija cmp, ki mora vrniti vrednost 0, ce sta objekta, na
    katera kazeta kazalca p1 in p2, enaka, negativno vrednost, ce je prvi
    objekt manjsi in pozitivno vrednost, ce je 1. objekt vecji.
    Funkcija vrne ta kazalec. Ce ga ne najde, vrne NULL. Sklad st mora biti
    sortiran glede na funkcijo cmp v narascajocem vrstnem redu.
      Ce je from enako 0, funkcija isce od 1. elementa sklada naprej, ce pa je
    to enoko 0, isce funkcija do zadnjega elementa slada.
    VAZNA OPOMBA: 1. argument, ki se nalozi funkciji cmp, je vedno ptr !!!
    Zato mora biti tudi funkcija cmp narejena tako, da vzame ptr kot 1. arg.
    $A Igor dec97; */
{
int place;
place=findsortstack(st,ptr,from,to,cmp);
if (place>0)
  return st->s[place];
else return NULL;
}




static void *pleft,*pright;
static int (*cmpaux) (void *p1,void *p2);

static int cmplim(void *p1,void *p2)
    /* Pomozna funkcija za findsortstacklim. p1 je slepi argument, dejansko se
    primerja p2 (kazalec, ki se ga vzame s sklada) s kazalcema pleft in pright
    s primerjalno funkcijo cmpaux.
    $A Igor apr01; */
{
int r;
if ((r=cmpaux(pleft,p2))>0)
  return r;
else if ((r=cmpaux(pright,p2))<0)
  return r;
else
  return 0;
}

int findsortstacklim(stack st,void *left,void *right,int from, int to,
                  int cmp(void *p1,void *p2))
    /* Vrne mesto, na katerem najde 1. element na st, ki je glede na primerjalno
    funkcijo cmp() med elementoma pleft in pright (oziroma je kateremu od teh
    elementov enak). Funkcija cmp mora biti taksna, da vrne stevilo manjse od
    0, ce je 1. argument manjsi, stevilo vecje od 0, ce je prvi argument vecji,
    in 0, ce sta enaka. Funkcija vrne 0, ce na skladu ne najde ustreznega
    argumenta. Ni nujno, da je pleft glede na cmp() manjsi ali enak pright,
    ker ju funkcija sama uredi po velikosti!
    $A Igor apr01; */
{
cmpaux=cmp;
if (cmp(left,right)>0)
{
  /* Zamenjamo pleft in pright, da je pleft manjsi: */
  void *p;
  p=left; left=right; right=p;
}
pleft=left;
pright=right;
cmpaux=cmp;
return findsortstack(st,NULL,from,to,cmplim);
}

void *ptrfindsortstacklim(stack st,void *left,void *right,int from, int to,
                       int cmp(void *p1,void *p2))
    /* Na skladu st najde 1. taksen kazalec na st med from in to, da je objekt, na
    katerega kaze, glede na funkcijo cmp() med objektoma, na katera kazeta
    primerjalna left in right. Vrne kazalec na najden objekt oz. NULL, ce
    objekta ne najde. Za iskanje uporabi funkcijo findsortstacklim().
    $A Igor apr01;; */
{
int place;
place=findsortstacklim(st,left,right,from,to,cmp);
if (place>0)
  return st->s[place];
else return NULL;
}


int placesortstackint(stack st,void *ptr,int from, int to,
                      int cmp(void *p1,void *p2))
    /* Na skladu st, ki mora biti urejen v narascajocem vrstnem redu, najde
    mesto, kamor spada po velikosti objekt, na katerega kaza ptr. Pri tem se
    obravnava le odsek sklada med from in to. Funkcija vrne to mesto. Ce je
    ptr manjsi od vseh elementov sklada (glede na funkcijo cmp), vrne funkcija
    vrednost 1, ce pa je vecji od vseh elementov, vrne st->n+1 (za ena vec
    kot je stevilo elementov na skladu). Ce je na skladu vec elementov, ki so
    glede na funkcijo cmp enaki ptr, vrne funkcija mesto prvega med njimi.
     Funkcija cmp mora biti taksna, da vrne 0, ce sta objekta, na kstea kazeta
    p1 in p2, po vlikosti enaka, manj kot 0, ce je 1. objekt manjsi, in vec
    kot kot 0, ce je 1. objekt vecji od drugega. Sklad st mora biti urejen
    po vleikosti glede na funkcijo cmp.
     Funkcija vrne 0, ce je st enak NULL.
     Ce je from enak 0, je zacetek obmocja, ki se obravnava, 1, ce pa je to
    enak 0, je konec obmocja, ki se obravnava, enak st->n.
    $A Igor dec97; */
{
int ret=0,left=0,right=0,middle=0,resmiddle;
if (st!=NULL)
  if (st->n>0)
  {
    if (from<=0)
      from=1;
    if (to<=0)
      to=st->n;
    if (to>st->n)
      to=st->n;
    if (from<=to)
    {
      middle=from-1+ (int) round((1.1+to-from)*0.5);
      resmiddle=cmp(ptr,st->s[middle]);
      if (resmiddle==0)
        ret=middle;
      /* Ce je iskani element vecji od 1. poskusa, se isce interval, ki vsebuje
      element, s pomikanjem navzgor po skladu: */
      if (resmiddle>0)
      {
        while (resmiddle>0 && ret<1 && middle<to)
        {
          left=middle;
          middle=left+ (int) round(0.1+(to-left)*0.5);
          resmiddle=cmp(ptr,st->s[middle]);
          if (resmiddle<0)
            right=middle;
          else if (resmiddle==0)
            ret=middle;
        }
        /* Ce nismo nasli desne meje intervala za bisekcijo, to pomeni, da je
        ptr vecji od vseh elementov na skladu med from in to, zato se vrne
        to+1 (novemu elementu je mesto na koncu): */
        if (right<1 && ret<1)
          ret=to+1;
      }
      else if (resmiddle<0)
      {
        while (resmiddle<0 && ret<1 && middle>from)
        {
          right=middle;
          middle=right- (int) round(0.1+(right-from)*0.5);
          resmiddle=cmp(ptr,st->s[middle]);
          if (resmiddle>0)
            left=middle;
          else if (resmiddle==0)
            ret=middle;
        }
        /* Ce nismo nasli leve meje intervala za bisekcijo, to pomeni, da je 
        ptr manjsi od vseh elemendov sklada med from in to, zato se vrne
        from (novemu elementu je mesto na zacetku sklada) */
        if (left<1 && ret<1)
          ret=from;
      }
      if (left>0 && right>0)
      {
        /* Nasli smo interval za bisekcijo, interval ozimo, dokler ne najdemo
        elementa sklada, ki je enak ptr, oz. dokler ni razlika med right in
        left samo se 1: */
        while (ret<1 && right-left>1)
        {
          middle=(int)round((right+left)*0.5);
          resmiddle=cmp(ptr,st->s[middle]);
          if (resmiddle<0)
            right=middle;
          else if (resmiddle>0)
            left=middle;
          else
            ret=middle;
        }
        /* Ce nismo nasli elementa, ki bi bil enak ptr, je mesto elementu
        ptr na skladu st pri right (ptr naj izpodrine 1. element, ki je vecji
        od njega): */
        if (ret<1)
          ret=right;
      }
      /* Zagotoviti je treba, da se res vrne prvi pojav kazalca , ki je glede
      na funkcijo cmp enak kazalcu ptr (samo v primeru, ce je ret>from): */
      if (ret>from)
        resmiddle=0;
      else
        resmiddle=1;
      while (!resmiddle)
      {
        if ( (resmiddle=cmp(ptr,st->s[ret-1])) ==0)
        {
          /* ret zmanjsamo za 1, ker je tudi element na mestu ret-1 enak ptr: */
          --ret;
          if (ret<2)
            resmiddle=1; /* Ce je ret ze enak 1, bomo prenehali z zmanjsevanjem */
        }
      }
    }
  } else if (st->n<1)
    ret=1;
return ret;
}


int placesortstack(stack st,void *ptr,int cmp(void *p1,void *p2))
    /* Na skladu st, ki mora biti urejen v narascajocem vrstnem redu, najde
    mesto, kamor spada po velikosti objekt, na katerega kaza ptr. Funkcija vrne
    to mesto. Ce je ptr manjsi od vseh elementov sklada (glede na funkcijo
    cmp), vrne funkcija vrednost 1, ce pa je vecji od vseh elementov, vrne
    st->n+1 (za ena vec kot je stevilo elementov na skladu). Ce je na skladu
    vec elementov, ki so glede na funkcijo cmp enaki ptr, vrne funkcija mesto
    prvega med njimi.
     Funkcija cmp mora biti taksna, da vrne 0, ce sta objekta, na kstea kazeta
    p1 in p2, po vlikosti enaka, manj kot 0, ce je 1. objekt manjsi, in vec
    kot kot 0, ce je 1. objekt vecji od drugega. Sklad st mora biti urejen
    po vleikosti glede na funkcijo cmp.
    $A Igor dec97;*/
{
return placesortstackint(st,ptr,0,0,cmp);
}


int inssortstack(stack st,void *ptr,int cmp(void *p1,void *p2))
    /* Na sklad st, katerega elementi morajo biti sortirani v narascajocem
    vrstnem redu glede na funkcijo cmp, vrine element ptr tako, da sklad ostane
    sortiran. Funkcija vrne mesto na skladu, na katerega vrine element.
    $A Igor dec97; */
{
int place;
place=placesortstack(st,ptr,cmp);
if (place>0)
  insstack(st,ptr,place);
return place;
}



#undef initstack




            /*************************/
            /*                       */
            /*    INDEKSNE TABELE    */
            /*                       */
            /*************************/




indtab newindtab(int excess,int r)
    /* Naredi in vrne indeksno tabelo z r alociranimi mesti in vrednostjo polja
    ex excess. Polje ex pove, koliksen presezek se alocira, ko postane alociran
    prostor premali.
    $A Igor avg00; */
{
indtab ret;
if (excess<0)
  excess=1;
ret=malloc(sizeof(*ret));
ret->n=0;
ret->ex=excess;
if (r<1)
{
  ret->r=0;
  ret->t=NULL;
} else
{
  ret->r=r;
  ret->t=malloc(sizeof(*(ret->t))*r);
  /*
  memset(ret->t,0,sizeof(*(ret->t))*r);
  */
  --ret->t;
}
return ret;
}


indtab newindtabrn(int excess,int r)
    /* Allocates and returns a new index table with (...)->ex set to excess
    and with r elements, which are not initialized. Both (...)->r and (...)->n
    are set to r.
    $A Igor dec03; */
{
indtab ret;
if (excess<0)
  excess=1;
ret=malloc(sizeof(*ret));
ret->n=0;
ret->ex=excess;
if (r<1)
{
  ret->r=0;
  ret->t=NULL;
} else
{
  ret->r=r;
  ret->t=malloc(sizeof(*(ret->t))*r);
  /*
  memset(ret->t,0,sizeof(*(ret->t))*r);
  */
  --ret->t;
}
ret->n=r;
return ret;
}


void dispindtab(indtab *it)
    /* Zbrise indeksno tabelo ind.
    $A Igor avg00; */
{
if (it!=NULL)
  if (*it!=NULL)
  {
    if ((*it)->t!=NULL)
      free((*it)->t+1);
    free(*it);
    *it=NULL;
  }
}


int sizeindtab(indtab it)
    /* Returns the total size of the memory, in bytes, occupied by it.
    $A Igor nov03; */
{
int ret=0;
if (it!=NULL)
{
  ret+=sizeof(*it);
  if (it->r>0 && it->t!=NULL)
    ret+=it->r*sizeof(*(it->t));
}
return ret;
}


indtab copyindtab(indtab it1,indtab *it2)
    /* Vrne kopijo indeksne tabele it1. Ce je it2 razlicen od NULL, skopira
    indeksno tabelo it1 v *it2 in vrne *it2. Funkcija deluje po podobnem nacelu
    kot copyvector0().
    $A Igor avg01; */
{
indtab it;
int i;
if (it2!=NULL)
{
  /* Ce je it2!=NULL, se it1 skopira v *it2: */
  if (it1==NULL)
    dispindtab(it2);
  else
  {
    /* Preverimo stevilo rezerviranih mest v *it2, ce ni ustrezna, zbrisemo
    *it2: */
    if (*it2!=NULL)
      if ((*it2)->r<it1->n)
        dispindtab(it2);
    /* Ce je *it2==NULL, tvorimo *it2 na novo: */
    if (*it2==NULL)
      *it2=newindtab(it1->ex,it1->n);
    it=*it2;
    /* Kopiranje vrednosti: */
    it->n=it1->n;
    it->ex=it1->ex;
    if (it1->n>0)
      for (i=1;i<=it1->n;++i)
        it->t[i]=it1->t[i];
  }
  return *it2; /* Ker je bil it2!=NULL, se vrne *it2. */
} else
{
  /* it2==NULL, naredi se nov objekt, ki je kopija it1, vrne se njegov kazalec: */
  if (it1==NULL)
    return NULL;
  else
  {
    it=newindtab(it1->ex,it1->n);
    it->n=it1->n;
    if (it1->n>0)
      for (i=1;i<=it1->n;++i)
        it->t[i]=it1->t[i];
    return it;
  }
}
}



stack copyindtabtostack(indtab it1,stack *st2)
    /* Vrne kopijo indeksne tabele it1 v obliki sklada, na katerem so indeksi
    nalozeni kot kazalci na tip int. Ce je it2 razlicen od NULL, skopira indeksno
    tabelo it1 v *it2 in vrne *it2. Funkcija deluje po podobnem nacelu kot
    copyvector0(). Pri skladu se tudi polje (...)->ex postavi na isto vrednost
    kot pri tabeli.
    $A Igor avg02; */
{
stack st;
int i,*ip;
if (st2!=NULL)
{
  /* Ce je sklad st2!=NULL, se it1 skopira v *it2: */
  if (it1==NULL)
    dispstackall(st2);
  else
  {
    /* Preverimo stevilo rezerviranih mest v *st2, ce ni ustrezno, popravimo
    *st2: */
    /* Ce je *st2==NULL, tvorimo *st2 na novo: */
    if (*st2==NULL)
      *st2=newstackr(it1->ex,it1->n);
    else
      (*st2)->ex=it1->ex;
    while ((*st2)->n<it1->n)
      pushstack(*st2,malloc(sizeof(int)));
    while ((*st2)->n>it1->n)
    {
      ip=popstack(*st2);
      if (ip!=NULL)
        free(ip);
    }
    /* Kopiranje vrednosti: */
    for (i=1;i<=it1->n;++i)
    {
      ip=(*st2)->s[i];
      if (ip==NULL)
      {
        ip=malloc(sizeof(int));
        (*st2)->s[i]=ip;
      }
      *ip=it1->t[i];
    }
  }
  return *st2; /* Ker je bil st2!=NULL, se vrne *st2. */
} else
{
  /* st2==NULL, naredi se nov objekt, ki je kopija it1, vrne se njegov kazalec: */
  if (it1==NULL)
    return NULL;
  else
  {
    st=newstackr(it1->ex,it1->n);
    for (i=1;i<=it1->n;++i)
    {
      ip=malloc(sizeof(int));
      *ip=it1->t[i];
      pushstack(st,ip);
    }
    return st;
  }
}
}


indtab copystacktoindtab(stack st1,indtab *it2)
    /* Vrne indeksno tabelo, ki je kopija sklada st1, na katerem so indeksi
    nalozeni kot kazalci na tip int. Ce je it2 razlicen od NULL, skopira
    indekse na skladu st1 v *it2 in vrne *it2. Funkcija deluje po podobnem nacelu
    kot copyvector0(). Pri indeksin tabeli se tudi polje (...)->ex postavi na isto
    vrednost kot pri skladu.
    $A Igor avg01; */
{
indtab it;
int i,*ip;
if (it2!=NULL)
{
  /* Ce je it2!=NULL, se indeksi na st1 skopirajo v *it2: */
  if (st1==NULL)
    dispindtab(it2);
  else
  {
    /* Preverimo stevilo rezerviranih mest v *it2, ce ni ustrezna, popravimo
    *it2: */
    if (*it2==NULL)
      *it2=newindtab(st1->ex,st1->n);
    if ((*it2)->n!=st1->n)
      resizeindtab(it2,st1->ex,0,st1->n);
    /* Kopiranje vrednosti: */
    (*it2)->ex=st1->ex;
    if (st1->n>0)
      for (i=1;i<=st1->n;++i)
      {
        ip=st1->s[i];
        if (ip==NULL)
          (*it2)->t[i]=0;
        else
        (*it2)->t[i]=*ip;
      }
  }
  return *it2; /* Ker je bil it2!=NULL, se vrne *it2. */
} else
{
  /* it2==NULL, naredi se nov objekt, ki je kopija it1, vrne se njegov kazalec: */
  if (st1==NULL)
    return NULL;
  else
  {
    it=newindtab(st1->ex,st1->n);
    it->n=st1->n;
    for (i=1;i<=st1->n;++i)
    {
      ip=st1->s[i];
      if (ip==NULL)
        it->t[i]=0;
      else
        it->t[i]=*ip;
    }
    return it;
  }
}
}


indtab resizeindtab(indtab *pit,int ex,int r,int n)
    /* Po potrebi popravi velikost alociranega prostora v indeksni tabeli
    *pit. Ce je r vecji od 0, se poskrbi, da je alociranega prostora natancno
    za r elementov. Ce je v tem primeru n vecji od r, se najprej r postavi na
    n. Ce je n vecji od 0, se stevilo elementov (*pit)->n postavi na n, po
    potrebi se poveca stevilo alociranih mest (ce jih je manj kot n), se pa to
    ne zmanjsa. Ce je n enak 0, se stevilo elementov spremeni (zmanjsa) le, ce
    postane stevilo alociranih mest manjse od stavila elementov - v tem primeru
    se stevilo elementov postavi na stevilo alociranih mest. Ce je ex vecji od
    0, se (*pvec)->it->ex postavi na ex.
      Razlicne moznosti so:
    n>0, r=0: Stevilo elementov se postavi na n, stevilo alociranih mest se
      poveca, ce je to potrebno (ce je trenutno manj kot n), v nobenem primeru
      pa se ne zmanjsa.
    n>0, r>0: Stevilo elementov se postavi na n, stevilo alociranih mest pa na
      r (torej se po potrebi spremeni). Ce bi bil r<n, se r najprej postavi na
      n.
    n=0, r>0: Stevilo alociranih mest se postavi na r. Stevilo elementov se po
      potrebi zmanjsa (ce je vecje od r, se postavi na r).
    n=0,r=0: Stevilo elementov postane 0, v nobenem primeru se ne spremeni
      stevilo alociranih mest.
      Funkcija vrne spremenjeno indeksno tabelo. Ce je pit NULL, potem se
    indeksna tabela naredi na novo in vrne.
    $A Igor avg00 nov03; */
{
indtab it=NULL;
if (pit==NULL)
  pit=&it;
if (*pit==NULL)
{
  /* pit kaze na nealocirano tabelo, alocirati je treba prostor in to je
  vse: */
  if (n<0)
    n=0;
  if (r<n)
    r=n;
  *pit=newindtab(ex,r);
  (*pit)->n=n;
  return *pit;
} else
  it=*pit;
if (it!=NULL) /* treba je preveriti potrebo po realokaciji */
{
  if (n<0)
    n=0;
  if (*pit==NULL)
  {
    (*pit)=newindtab(ex,0);
    it=*pit;
  }
  if (ex>0)
    it->ex=ex;
  if (n>0)
    it->n=n;
  if (r>0) /* dolocena je velikost alociranega prostora */
  {
    if (r<n)
      r=n;
    if (it->r!=r)
    {
      /* Treba je realocirati spomin: */
      it->r=r;
      /* Moznost zmanjsanja st. aloc. mest pod it->n pri realokaciji: */
      if (it->n>it->r)
        it->n=it->r;
      if (it->t!=NULL)
        ++it->t;
      it->t=realloc(it->t,it->r*sizeof(*(it->t)));
      --it->t;
    }
  } else if (n>0)
  {
    if (it->r<n)
    {
      /* Stevilo alociranih mest je manjse od n, potrebna je realokacija: */
      it->r=n;
      if (it->t!=NULL)
        ++it->t;
      it->t=realloc(it->t,it->r*sizeof(*(it->t)));
      --it->t;
    }
  } else
    /* (*pit) */ it->n=0;
}
return it;
}


void fprintindtab(FILE *fp,indtab it)
    /* Prints data about indec table it to file fp. Elements are printed 
    in a column.
    $A Igor mar05; */
{
int i;
if (fp!=NULL)
{
  if (it==NULL)
    fprintf(fp,"NULL.\n");
  else
  {
    fprintf(fp,"n=%i, r=%i, ex=%i\n",it->n,it->r,it->ex);
    if (it->n>0)
      for (i=1;i<=it->n;++i)
        fprintf(fp,"%i: %i\n",i,it->t[i]);
  }
}
}

void printindtab(indtab it)
    /* Prints data about indec table it to the standard output. Elements 
    are printed in a column.
    $A Igor mar05; */
{
fprintindtab(stdout,it);
}



void fprintindtabline(FILE *fp,indtab it)
    /* Prints data about index table it to the file fp. Elements are
    printed in a line.
    $A Igor mar05; */
{
int i;
if (fp!=NULL)
{
  if (it==NULL)
  fprintf(fp,"NULL.\n");
  else
  {
    fprintf(fp,"n=%i, r=%i, ex=%i\n",it->n,it->r,it->ex);
    if (it->n>0)
    {
      for (i=1;i<=it->n;++i)
        fprintf(fp,"%i: %-5i ",i,it->t[i]);
      fprintf(fp,"\n");
    }
  }
}
}

void printindtabline(indtab it)
    /* Prints data about index table it to the standard output. Elements are
    printed in a line.
    $A Igor mar05; */
{
fprintindtabline(stdout,it);
}


void fprintindtablinesimp(FILE *fp,indtab it)
    /* Prints data about index table it to the file fp. Elements are
    printed in a line and without sequential numbers.
    $A Igor mar05; */
{
int i;
if (fp!=NULL)
{
  if (it==NULL)
    fprintf(fp,"NULL.\n");
  else
  {
    fprintf(fp,"n=%i, r=%i, ex=%i\n",it->n,it->r,it->ex);
    if (it->n>0)
    {
      for (i=1;i<=it->n;++i)
        fprintf(fp,"%i ",it->t[i]);
    }
    fprintf(fp,"\n");
  }
}
}

void printindtablinesimp(indtab it)
    /* Prints data about index table it to thestandard output. Elements are
    printed in a line and without sequential numbers.
    $A Igor mar05; */
{
fprintindtablinesimp(stdout,it);
}


void fprintindtablist(FILE *fp,indtab it)
    /* Prints index table it to the file fp in a list form as used by 
    Mathematica.
    $A Igor mar05; */
{
int i;
if (fp!=NULL)
{
  fprintf(fp,"{");
  if (it!=NULL) if (it->n>0)
  {
    for (i=1;i<it->n;++i)
      fprintf(fp,"%i, ",it->t[i]);
    fprintf(fp,"%i",it->t[i]);
  }
  fprintf(fp,"}");
}
}

void printindtablist(indtab it)
    /* Prints index table it to the standard output in a list form as used by 
    Mathematica.
    $A Igor mar05; */
{
fprintindtablist(stdout,it);
}



void pushindtab(indtab it,int el)
    /* Doda indeks el na konec indeksne tabele. Ce je potrebno, predhodno
    poveca alociran prostor.
    $A Igor avg00; */
{
if (it!=NULL)
{
  ++it->n;
  if (it->n>it->r)
  {
    /* treba je povecati alociran prostor */
    it->r=it->n+it->ex;
    if (it->t!=NULL)
      ++it->t;
    it->t=realloc(it->t,it->r*sizeof(int));
    --it->t;
  }
  it->t[it->n]=el;
}
}


void insindtab(indtab it,int el,int place)
    /* V indeksni tabeli it vrine na mesto place element el. Ostali elementi se
    pomaknejo za eno mesto navzgor. Ce je place vecji od  it->n+1, se vrzeli
    zapolnijo z 0.
    $A Igor avg00; */
{
int i;
if (it!=NULL && place>=1)
{
  /* Ce je place vecji od 1+st. el., se vrzeli zapolnijo z 0: */
  while (place>it->n+1)
    pushindtab(it,0);
  ++it->n;
  if (it->n>it->r)
  {
    /* treba je povecati alociran prostor */
    it->r=it->n+it->ex;
    if (it->t!=NULL)
      ++it->t;
    it->t=realloc(it->t,it->r*sizeof(int));
    --it->t;
  }
  /* Elementi tabele od mesta place naprej se pomaknejo za eno mesto navzgor: */
  for (i=it->n;i>place;--i)
    it->t[i]=it->t[i-1];
  it->t[place]=el;
}
}



int setindtab(indtab it,int val,int place)
     /* Sets the element at position place on the index table it to val. If the
     index table contains less than place elements, then zeros are pushed to the
     index table until it contains  place elements. The function returns the
     element that was on the position place before its execution. If the it is
     NULL, the function just returns 0.
     $A Igor sep03; */
{
int ret=0;
if (it!=NULL && place>0)
{
  while (place>it->n)
    pushindtab(it,0);  /* fill until position place if necessary */
  /* Store element at place for return, then set it to el: */
  ret=it->t[place];
  it->t[place]=val;
}
return ret;
}

int popindtab(indtab it)
    /* Pobere zadnji element z indeksne tabele it in ga vrne. Ce je alociranega
    spomina vec kot za 2*it->ex vec kot zasedenaga, se spomin realocira tako,
    da ostane it->ex prostih mest.
    $A Igor avg00; */
{
int ret=0;
if (it!=NULL)
  if (it->n>0)
  {
    ret=it->t[it->n];
    --it->n;
    if (it->r-it->n>2*it->ex)
    {
      /* treba je pomanjsati alociran prostor */
      it->r=it->n+it->ex;
      if (it->r>0)
      {
        if (it->t!=NULL)
          ++it->t;
        it->t=realloc(it->t,it->r*sizeof(int));
        --it->t;
      } else
      {
        if (it->t!=NULL)
          free(++it->t);
        it->t=NULL;
      }
    }
  }
return ret;
}


int delindtab(indtab it,int place)
    /* Z indeksne tabele it zbrise indeks na mestu place in ga vrne. Vrzel se
    zapolni tako, da se indeksi za zbrisanim pomaknejo za eno mesto naprej.
    Ce tako nastane presezek alociranega spomina za vec kot 2*it->ex, se spomin
    realocira tako, da ostane presezek samo it->ex.
    $A Igor avg00; */
{
int ret=0,i;
if (it!=NULL)
  if (place>0 && place<=it->n)
  {
    ret=it->t[place];
    /* Pomik indeksov za place za eno mesto naprej: */
    for (i=place;i<it->n;++i)
      it->t[i]=it->t[i+1];
    --it->n;
    /* Realokacija (zmanjsanje) spomina po potrebi: */
    if (it->r-it->n>2*it->ex)
    {
      it->r=it->n+it->ex;
      if (it->r>0)
      {
        if (it->t!=NULL)
          ++it->t;
        it->t=realloc(it->t,it->r*sizeof(int));
        --it->t;
      } else
      {
        if (it->t!=NULL)
        {
          free(++it->t);
          it->t=NULL;
        }
      }
    }
  }
return ret;
}


int findindtab(indtab it, int ind,int from,int to)
    /* Najde prvi indeks, ki je enak ind, na indeksni tabeli it od masta from
    do mesta to, in vrne njegovo pozicijo. Ce indeksa ne najde, vrne 0. Ce je
    from 0, postane 1; ce je to 0 ali vecje od stevila elemntov tabele, postane
    enak stevilu elementov.
    $A Igor avg00; */
{
int i,ret=0;
if (it!=NULL)
{
  if (from<=0)
    from=1;
  if (to<=0)
    to=it->n;
  else if (to>it->n)
    to=it->n;
  for (i=from;i<=to && !ret;++i)
    if (it->t[i]==ind)
      ret=i;
}
return ret;
}



/* Definicije za mergesortindtab: */

static void mergetabint(int *a,int m,int *b,int n,int *c)
    /* Zdruzi sortirani tabeli celih stevil a in b v sortirano tabelo c, kjer
    je m stevilo elementov a, n pa stevilo elementov b. Stevili elementov se
    morata ujemati z dejansko alociranim prostorom za a in b, prav tako pa
    mora biti za c alociranega dovolj prostora, da lahko drzi obe tabeli.
    $A Igor avg00; */
{
int i=0,j=0,k=0;
while(i<m && j<n)
  if (a[i]<=b[j])
    c[k++]=a[i++];
  else
    c[k++]=b[j++];
  while(i<m)
    c[k++]=a[i++];
  while(j<n)
    c[k++]=b[j++];
}

static void mergesortint(int *tab,int n,int *buf)
    /* Sortira tabelo celih stevil tab dolzine n po metodi "mergesort". buf je
    lahko NULL, ce pa je razlicen od NULL, mora kazati na alociran prostor, ki
    je dovolj velik za n celih stevil.
    Ref. Kelley: Book on C, p.p.207.
    $A Igor avg00; */
{
int j,k,i;
char albuf=0;
if (n>1)
{
  if (buf==NULL)
  {
    buf=malloc(n*sizeof(int));
    albuf=1;
  }
  for (k=1;2*k<=n;k*=2)
  {
    for (j=0;j+2*k<=n;j+=2*k)
      mergetabint(tab+j,k,tab+j+k,k,buf+j);
    for (i=0;i<j;++i)
      tab[i]=buf[i];
    if (j<n)
    {
      mergesortint(tab+j,n-j,buf+j);
      mergetabint(tab+j-2*k,2*k,tab+j,n-j,buf+j-2*k);
      for (i=j-2*k;i<n;++i)
        tab[i]=buf[i];
    }
  }
  if (albuf)
    free(buf);
}
}


void mergesortindtab(indtab it)
    /* Sortira indekse na indeksni tabeli it po narascajocem vrstnem redu po
    metodi mergesort.
    $A Igor avg00; */
{
if (it!=NULL)
  mergesortint(it->t+1,it->n,NULL);
}



/* Definicije za qsortindtab: */

static int t;

#define swap(x,y) {t=x; x=y; y=t;}
#define order(x,y) if (x>y) swap(x,y);
#define ord2(x,y) order(x,y)
#define ord3(x,y,z) ord2(x,y); ord2(x,z); ord2(y,z);

static char findpivot(int *left,int *right,int *pivotptr)
    /* Pomozna funkcija za quicksortint. Izmed treh elementov tabele (skrajno
    levega, skrajno desnega in sredinskega) izbere srednjega po velikosti kot
    pivot za particijo tabele.
    $A Igor avg00; */
{
int a,b,c,*p;
a=*left; /* levi element */
b=*(left+(right-left)/2); /* sredinski element */
c=*right; /* desni element */
ord3(a,b,c); /* sortiranje teh elementov - glej def. makrojev */
if (a<b)
{
  *pivotptr=c;
  return 1;
}
for (p=left+1;p<=right;++p)
  if (*p!=*left)
  {
    *pivotptr=(*p<*left)? *left: *p;
    return 1;
  }
return 0;
}

static int *partition(int *left,int *right,int pivot)
    /* Pomozna funkcija za quicksortint. Izvede particijo tabele.
    $A Igor avg00; */
{
while(left<=right)
{
  while (*left<pivot)
    ++left;
  while (*right>=pivot)
    --right;
  if (left<right)
  {
    swap(*left,*right);
    ++left;
    --right;
  }
}
return left;
}

static void quicksortint(int *left,int *right)
    /* Pomozna funkcija za quicksortint. Izvede sortiranje tabele celih stevil,
    left kaze na 1. element, right pa na zadnjega.
    $A Igor avg00; */
{
int *p,pivot;
if (findpivot(left,right,&pivot))
{
  p=partition(left,right,pivot);
  quicksortint(left,p-1);
  quicksortint(p,right);
}
}

void qsortindtab(indtab it)
    /* Sortira indekse na indeksni tabeli it po narascajocem vrstnem redu po
    metodi quicksort.
    $A Igor avg00; */
{
if (it!=NULL)
  if (it->n>1)
    quicksortint(it->t+1,it->t+it->n);
}



void ordsortindtab(indtab it)
    /* Sortira indekse na indeksni tabeli it po narascajocem vrstnem redu.
    Metoda gre po vrsti po elementih tabele tako, da so vsi predhodnji elementi
    elementa v obdelavi ze sortirani. Potem se s primerjanjem elementa s
    prejsnjimi elementi od zadnjega proti prvemu ugotovi, kam ta element spada
    in se ga vrine na to mesto ter preskoci na naslednji element.
    POZOR! Metoda sortiranja ni najbolj efektivna.
    $A Igor avg00; */
{
int i,j,val,place;
if (it!=NULL)
  if (it->n>1)
    for (i=2;i<=it->n;++i)
    {
      /* Elementi od 1 do i-1 so ze posortirani. */
      val=it->t[i];
      place=0;
      /* Najde se zadnji element pred mestom i, ki je manjsi ali enak val,
      njegovo mesto se spravi v place: */
      for (j=i-1;j>0 && !place;--j)
        if (it->t[j]<val)
          place=j;
      if (place<i-1)
      {
        /* element je potrebno vriniti na mesto place+1, najprej se izvede
        premik predhodnih elementov za eno naprej: */
        for (j=i-1;j>place;--j)
          it->t[j+1]=it->t[j];
        it->t[place+1]=val;
      }
    }
}


void bubsortindtab(indtab it)
    /* Sortira indekse na indeksni tabeli it po narascajocem vrstnem redu z
    metodo bubble sort.
    POZOR! Metoda sortiranja je ZELO POCASNA.
    $A Igor avg00; */
{
int i,j,val;
if (it!=NULL)
  if (it->n>1)
    for (i=1;i<it->n;++i)
      for (j=it->n;j>i;--j)
        if (it->t[j-1]>it->t[j])
        {
          /* Zamenjava j-1. in j. elementa: */
          val=it->t[j];
          it->t[j]=it->t[j-1];
          it->t[j-1]=val;
          
        }
}




void sortindtab(indtab it)
    /* Sortira indekse na indeksni tabeli it po narascajocem vrstnem redu.
    $A Igor avg00; */
{
int nel;
if (it!=NULL)
  if ((nel=it->n)>45)
    qsortindtab(it);
  else if (nel>30)
    mergesortindtab(it);
  else
    ordsortindtab(it);
}



int findsortindtab(indtab it,int index,int from,int to)
    /* Poisce indeks index v sortirani indeksni tabeli it med from in to in
    vrne njegovo pozicijo oz. 0, ce indeksa ne najde. Ce je from 0, postane 1;
    ce je to 0 ali vecje od stevila elemntov tabele, postane enak stevilu
    elementov.
    $A Igor avg00; */
{
int ret=0,left=0,right=0,middle=0,indleft,indright,indmiddle;
if (it!=NULL)
{
  if (it->n==0) /* Ce ni elementov na skladu, je mesto enako 0: */
    return 0;
  if (from<=0)
    from=1;
  if (to<=0)
    to=it->n;
  else if (to>it->n)
    to=it->n;
  if (to>0 && from<=to)
  {
    /* Najprej se preveri skrajno levi element: */
    left=from;
    if ((indleft=it->t[left])>index)
      return 0;
    else if (indleft==index)
      return left;
    else if (to==from)
        return 0;
    else do /* Objemanje intervala, na katerem je iskani indeks: */
    {
      middle=left+(to-left)/2;
      if ((indmiddle=it->t[middle])<index)
      {
        left=middle;
        indleft=indmiddle;
      } else
      {
        right=middle;
        indright=indmiddle;
      }
    } while (!right && middle<to-1);
    if (indmiddle==index) /* ce smo ze nasli element */
      return middle;
    else if (!right)
    {
      /* Objemanje je slo neuspesno do konca (do predzad. el.), edina moznost
      je se zadnji element: */
      indright=it->t[middle+1];
      if (indright==index)
        return middle+1;
      else
        return 0;
    } else while (indmiddle!=index && right-left>1)
    {
      /* Bisekcija intervala, na katerem je iskani indeks: */
      middle=left+(right-left)/2;
      if ((indmiddle=it->t[middle])<index)
      {
        left=middle;
        indleft=indmiddle;
      } else if (indmiddle>index)
      {
        right=middle;
        indright=indmiddle;
      } else /* index=indmiddle */
        return middle;
    }
    return 0;
  }
}
return ret;
}


int placesortindtab(indtab it,int index,int from,int to)
    /* V sortirani indeksni tabeli it poisce in vrne mesto med from in to,
    kamor lahko vrine indeks index in vrne njegovo pozicijo oz. 0, ce taksnega
    mesta ne najde (kar je le v primeru, ce je it enak NULL). Ce je from 0,
    postane 1; ce je to 0 ali vecje od stevila elemntov tabele, postane enak
    stevilu elementov.
     POZOR: Ce je indeks index ze v tabeli indeksov med from in t, vrne njegovo
    mesto!!!
    $A Igor avg00; */
{
int ret=0,left=0,right=0,middle=0,indleft,indright,indmiddle;
if (it!=NULL)
{
  if (it->n==0) /* Ce ni elementov na skladu, je mesto avtomatsko enako 1: */
    if (from<=1)
      return 1;
  if (from<=0)
    from=1;
  if (to<=0)
    to=it->n;
  else if (to>it->n)
    to=it->n;
  if (to>0 && from<=to)
  {
    /* Najprej se preveri skrajno levi element: */
    left=from;
    if ((indleft=it->t[left])>index)
      return left; /* $ */
    else if (indleft==index)
      return left;
    else if (to==from)
      return left+1;
    else do /* Objemanje intervala, na katerem je iskani indeks: */
    {
      middle=left+(to-left)/2;
      if ((indmiddle=it->t[middle])<index)
      {
        left=middle;
        indleft=indmiddle;
      } else
      {
        right=middle;
        indright=indmiddle;
      }
    } while (!right && middle<to-1);
    if (indmiddle==index) /* ce smo ze nasli element */
      return middle;
    else if (!right)
    {
      /* Objemanje je slo neuspesno do konca (do predzad. el.), edina moznost
      je se zadnji element: */
      indright=it->t[middle+1];
      if (indright>=index)
        return middle+1;
      else
        return middle+2; /* $ */
    } else while (indmiddle!=index && right-left>1)
    {
      /* Bisekcija intervala, na katerem je iskani indeks: */
      middle=left+(right-left)/2;
      if ((indmiddle=it->t[middle])<index)
      {
        left=middle;
        indleft=indmiddle;
      } else if (indmiddle>index)
      {
        right=middle;
        indright=indmiddle;
      } else /* index=indmiddle */
        return middle;
    }
    return right; /* $ */
  } else
    return 1;  /* ce ja tabela prazna */
}
return ret;
}


int inssortindtab(indtab it,int index,int from,int to)
    /* Vrine indeks index na pravo mesto v sortirani indeksni tabeli it med
    mestoma from in to. Funkcija vrne mesto, kamor se je vrinil indeks.
     POZOR: Pri uporabi te funkcije lahko dobimo vec enakih indeksov v tabeli,
     ker se indeks vrine tudi, ce ze obstaja v tabeli!
    $A avg00; */
{
int place;
place=placesortindtab(it,index,from,to);
if (place)
  insindtab(it,index,place);
return place;
}


int placesortindtabinfo(indtab it,int index,int from,int to)
    /* V sortirani indeksni tabeli it poisce med from in to mesto, kamor lahko
    vrine indeks index in vrne njegovo pozicijo, ce tega indeksa se ni v tem
    odseku tabele, minus pozicijo indeksa, ce indeks ze obstaja, ali 0, ce
    je it enak NULL. Ce je from 0, postane 1; ce je to 0 ali vecje od stevila
    elemntov tabele, postane enak stevilu elementov.
     POZOR: Ce je indeks index ze v tabeli indeksov med from in t, vrne njegovo
    mesto!!!
    $A Igor avg00; */
{
int ret=0,left=0,right=0,middle=0,indleft,indright,indmiddle;
if (it!=NULL)
{
  if (it->n==0) /* Ce ni elementov na skladu, je mesto avtomatsko enako 1: */
    if (from<=1)
      return 1;
  if (from<=0)
    from=1;
  if (to<=0)
    to=it->n;
  else if (to>it->n)
    to=it->n;
  if (to>0 && from<=to)
  {
    /* Najprej se preveri skrajno levi element: */
    left=from;
    if ((indleft=it->t[left])>index)
      return left; /* $ */
    else if (indleft==index)
      return -left;
    else if (to==from)
        return left+1;
    else do /* Objemanje intervala, na katerem je iskani indeks: */
    {
      middle=left+(to-left)/2;
      if ((indmiddle=it->t[middle])<index)
      {
        left=middle;
        indleft=indmiddle;
      } else
      {
        right=middle;
        indright=indmiddle;
      }
    } while (!right && middle<to-1);
    if (indmiddle==index) /* ce smo ze nasli element */
      return -middle; /* $ */
    else if (!right)
    {
      /* Objemanje je slo neuspesno do konca (do predzad. el.), edina moznost
      je se zadnji element: */
      indright=it->t[middle+1];
      if (indright==index)
        return -(middle+1); /* $ */
      else if (indright>index)
        return middle+1;
      else
        return middle+2; /* $ */
    } else while (indmiddle!=index && right-left>1)
    {
      /* Bisekcija intervala, na katerem je iskani indeks: */
      middle=left+(right-left)/2;
      if ((indmiddle=it->t[middle])<index)
      {
        left=middle;
        indleft=indmiddle;
      } else if (indmiddle>index)
      {
        right=middle;
        indright=indmiddle;
      } else /* index=indmiddle */
        return -middle; /* $ */
    }
    return right; /* $ */
  } else
    return 1;  /* ce ja tabela prazna */
}
return ret;
}


int placesortindtabinfo1(indtab it,int index,int from,int to)
    /* V sortirani indeksni tabeli it poisce med from in to mesto, kamor lahko
    vrine indeks index in vrne njegovo pozicijo, ce tega indeksa se ni v tem
    odseku tabele, minus pozicijo indeksa, ce indeks ze obstaja, ali 0, ce
    je it enak NULL. Ce je from 0, postane 1; ce je to 0 ali vecje od stevila
    elemntov tabele, postane enak stevilu elementov.
     POZOR: Ce je indeks index ze v tabeli indeksov med from in t, vrne njegovo
    mesto!!!
     OPOMBA: To je verzija funkcije, ki ne dela objemanja intervala, ampak kar
    najprej preveri prvi in zadnji indeks, kar je v mnogo primerih bolj
    efektivno zato, ker je velika verjetnost, da indeks, ki ga primerjamo, pade
    izven obsega tabele. /////// Z uporabo te funkcije se bistveno ne profitira.
    $A Igor avg00; */
{
int ret=0,left=0,right=0,middle=0,indleft,indright,indmiddle;
if (it!=NULL)
{
  if (it->n==0) /* Ce ni elementov na skladu, je mesto avtomatsko enako 1: */
    if (from<=1)
      return 1;
  if (from<=0)
    from=1;
  if (to<=0)
    to=it->n;
  else if (to>it->n)
    to=it->n;
  if (to>0 && from<=to)
  {
    /* Najprej se preveri skrajno levi element: */
    left=from;
    if ((indleft=it->t[left])>index)
      return left; /* $ */
    if (indleft==index)
      return -left;
    if (to==from)
        return left+1;
    /* Potem se preveri skrajno desni element: */
    right=to;
    if ((indright=it->t[right])<index)
      return right+1;
    if (indright==index)
      return -right;
    if (to==from+1) /* imamo samo 2 elementa, indeks pa je vecji od 1. in */
      return right; /* manjsi od 2. */
    indmiddle=index+1; /* zato, da ni enak indeksu, kar je pogoj v zanki */
    while (indmiddle!=index && right-left>1)
    {
      /* Bisekcija intervala, na katerem je iskani indeks: */
      middle=left+(right-left)/2;
      if ((indmiddle=it->t[middle])<index)
      {
        left=middle;
        indleft=indmiddle;
      } else if (indmiddle>index)
      {
        right=middle;
        indright=indmiddle;
      } else /* index=indmiddle */
        return -middle; /* $ */
    }
    return right; /* $ */
  } else
    return 1;  /* ce ja tabela prazna */
}
return ret;
}

int inssortindtabun(indtab it,int index,int from,int to)
    /* Vrine indeks index na pravo mesto v sortirani indeksni tabeli it med
    mestoma from in to, ce indeks na tem odseku se NE OBSTAJA. Funkcija vrne
    mesto, kamor se je vrinil indeks, oziroma minus mesto, na katerem je ze
    indeks, oziroma 0, ce je kaj narobe.
      Pri uporabi te funkcije ne dobimo vec enakih indeksov v tabeli.
    $A avg00; */
{
int place;
place=placesortindtabinfo1(it,index,from,to);
if (place>0)
  insindtab(it,index,place);
return place;
}


int addindtabun(indtab it,int index,int from,int to)
    /* Doda indeks index na konec indeksne tabele it, ce ta indeks se ne
    obstaja v tabeli med mestoma from in to.
    $A Igor avg00; */
{
int place;
place=findindtab(it,index,from,to);
if (place<1)
  pushindtab(it,index);
return place;
}



    /*  NAKLJUCNE INDEKSNE TABELE  */


void randindtabun(indtab it,indtab itsort,int from,int to,int n,char inc)
    /* Na indeksno tabelo it postavi n nakljucno izbranih indeksov z
    vrednostmi med from in to (vkljucno) v nakljucnem vrstnem redu, tako da
    so indeksi enolicni. Ce je med from in to manj kot n celih stevil, postavi
    na tabelo toliko indeksov, kot je mozno. Indeksna tabela indsort je pomozna
    indeksna tabela, s pomocjo katere funkcija zagotavlja enolicnost indeksov.
    Obe indeksni tabeli morata biti alocirani. Ce je inc razlicen od 0 (kar je
    PRIPOROCLJIVO), je dovoljeno poiskati nov indeks z inkrementiranjem ali
    dekrementiranjem od nakljucno izbranega naprej, ce ta ze obstaja v tabeli
    (v tem primeru se nakljucna generacija indeksa izvede le n-krat).
    $A Igor avg00; */
{
int ind,i,place;
double x;
if (it!=NULL && itsort!=NULL)
{
  it->n=itsort->n=0;
  if (to>=from)
  {
    if (n>to-from+1)
      n=to-from+1;
    while(itsort->n<n)
    {
      x=from+trunc((to-from+1)*random1());
      ind=(int) x;
      if (ind>to)
        ind=to; /* varovalka zaradi funkcije random1 */
      if ((place=inssortindtabun(itsort,ind,0,0))>0)
        pushindtab(it,ind);
      else if (inc)
      {
        for (i=ind+1;i<=to && place<=0;++i)
          if ((place=inssortindtabun(itsort,i,0,0))>0)
            pushindtab(it,i);
        for (i=ind-1;i>=from && place<=0;--i)
          if ((place=inssortindtabun(itsort,i,0,0))>0)
            pushindtab(it,i);
      }
    }
  }
}
}


void randindtabsortun(indtab it,int from,int to,int n,char inc)
    /* Na indeksno tabelo it postavi n nakljucno izbranih sortiranih indeksov z
    vrednostmi med from in to (vkljucno) tako, da so indeksi enolicni. Ce je
    med from in to manj kot n celih stevil, postavi na tabelo toliko indeksov,
    kot je mozno. Indeksna tabela it mora biti ze alocirana, ni pa vazno, ali
    je na njej kaj elementov. Ce je inc razlicen od 0 (kar je PRIPOROCLJIVO),
    je dovoljeno poiskati nov indeks z inkrementiranjem ali dekrementiranjem od
    nakljucno izbranega naprej, ce ta ze obstaja v tabeli (v tem primeru se
    nakljucna generacija indeksa izvede le n-krat).
    $A Igor avg00; */
{
int ind,i,place;
double x;
if (it!=NULL)
{
  it->n=0;
  if (to>=from)
  {
    if (n>to-from+1)
      n=to-from+1;
    if (n<2+5*(to-from+1)/8 || n<10) /* kriterij za uporabo komplementar. post. */
    {
      while(it->n<n)
      {
        x=from+trunc((to-from+1)*random1());
        ind=(int) x;
        if (ind>to)
          ind=to; /* varovalka zaradi funkcije random1 */
        if ((place=inssortindtabun(it,ind,0,0))<=0 && inc)
        {
          /* Elementa nismo dali na sklad, ker ze obstaja; Ce je inc razlicen
          od NULL, zacnemo iskati prvi neobstojeci element z inkrementacijo in
          dekrementacijo indeksov. */
          for (i=ind+1;i<=to && place<=0;++i)
            place=inssortindtabun(it,i,0,0);
          for (i=ind-1;i>=from && place<=0;--i)
            place=inssortindtabun(it,i,0,0);
        }
      }
    } else
    {
      indtab itaux;
      int j;
      /* Skrajsan postopek za tiste n, ki so precej vecji od polovice moznih
      vrednosti. Postopek se izvede obratno, najprej se dobi tabelo za n manj
      od stevila moznih vrednosti (ki je to-from+1) nakljucnih elementov, nato
      pa se gre po moznih vrednostih in se mece v pravo tabelo samo tiste, ki
      niso v tako generirani tabeli: */
      itaux=newindtab(1,to-from+1-n);
      randindtabsortun(itaux,from,to,to-from+1-n,inc);
      j=1;
      for (i=from;i<=to;++i)
      {
        if (j>itaux->n)
          pushindtab(it,i);
        else if (i!=itaux->t[j])
          pushindtab(it,i);
        else
          ++j;
      }
      dispindtab(&itaux);
    }
  }
}
}





    /*  PODPORA ZA INDEKSIRANJE RAZPRSENIH MATRIK  */



void prepspmatindtab(stack *st,int dim1,int excess,int numalloc)
    /* Pripravi sklad indeksnih tabel, kamor se lahko zapisujejo indeksi
    zapolnjenih mest v razprseni matriki. Na sklad *st vrze indeksne tabele,
    ki so alocirane s poljem ex enakemu excess in imajo numalloc ze alociranih
    mest za indekse. Tiste indeksne tabele na skladu, ki so morebiti ze
    alocirane, pusti taksne kot so, samo polje ex postavi na excess. dim1 je
    stevilo vrstic matrike.
    $A Igor avg00; */ 
{
stack table;
indtab it;
int i;
if (st!=NULL)
{
  /* Alokacija sklada po potrebi: */
  if (*st==NULL)
    *st=newstack(0);
  table=*st;
  while(table->n>dim1)
  {
    it=popstack(table);
    dispindtab(&it);
  }
  if (table->r!=dim1)
  {
    table->r=dim1;
    if (table->s!=NULL)
      ++table->s;
    table->s=realloc(table->s,table->r*sizeof(void*));
    --table->s;
  }
  for (i=1;i<=table->n;++i)
    if ((it=table->s[i])==NULL)
      table->s[i]=newindtab(excess,numalloc);
    else
      it->ex=excess;
  for (i=table->n+1;i<=table->r;++i)
    table->s[i]=newindtab(excess,numalloc);
  table->n=dim1;
}
}


int setspmatindtabel(stack st,int line,int col)
    /* Na tabelo zapolnjenih mest razprsene matrike, ki jo predstavlja sklad
    st, vrine indeks novega elementa matrike, katerega vrstica je line in
    stolpec col. Funkcija vrne mesto v vrstici, na katero se je vrinil indeks
    stolpca, kot ga vrne funkcija addindtabun(). Ta funkcija generira
    tabelo, na kateri indeksi NISO SORTIRANI.
     POZOR: Funkcija ne preverja, ce je sklad alociran in ce ima pravilno
    stevilo elementov.
    $A Igor avg00; */
{
return addindtabun((indtab) st->s[line],col,0,0);
}

int setspmatindtabelsort(stack st,int line,int col)
    /* Na tabelo zapolnjenih mest razprsene matrike, ki jo predstavlja sklad
    st, vrine indeks novega elementa matrike, katerega vrstica je line in
    stolpec col. Funkcija vrne mesto v vrstici, na katero se je vrinil indeks
    stolpca, kot ga vrne funkcija inssortindtabun(). Ta funkcija generira
    tabelo, na kateri so indeksi SORTIRANI.
     POZOR: Funkcija ne preverja, ce je sklad alociran in ce ima pravilno
    stevilo elementov.
    $A Igor avg00; */
{
return inssortindtabun((indtab) st->s[line],col,0,0);
}


void sortspmatindtab(stack st)
    /* Sortira tabelo zapolnjenih mest razprsene matrike, ki jo predstavlja
    sklad st.
    $A Igor avg00; */
{
int i;
if (st!=NULL)
  for (i=1;i<=st->n;++i)
   sortindtab(st->s[i]);
}

void printspmatindtab(stack st)
    /* Izpise tabelo zapolnjenih mest razprsene matrike, ki jo predstavlja
    sklad st.
    $A Igor avg00; */
{
int i,n=0;
indtab it;
if (st!=NULL)
{
  for (i=1;i<=st->n;++i)
  {
    printf("%i. LINE:            ",i);
    printindtablinesimp(it=st->s[i]);
    n+=it->n;
  }
  printf("Total number of elements: %i.\n",n);
} else
  printf("NULL stack.\n");
}

void spmatindtabtoNASA(stack st,int *neq,int *nel,int **ptrs,int **cumptrs,
        int **indxs, double **coefs,double **diag)
    /* Glede na indeksno tabelo zapolnjenih mest razprsene matrike, ki je na
    st, po potrebi alocira in inicializira polja, ki so input za solver
    NASA. Ce so kazalci *ptrs, *cumptrs, *indxs, *coefs in *diag enaki
    NULL, se prostor zanje alocira. Ce je kateri od kazalcev nanje (npr. coefs)
    enak NULL, se ustrezno polje ignorira. V *eq mora biti pri klicu stevilo
    vrstic matrike, v *nel pa stevilo nenicelnih elementov (brez diagonalnih!).
    Ce se ta podatka ne ujemata z dejanskimi podatki, ki jih funkcija dobi s
    sklada st, se vsa polja na novo alocirajo, funkcija pa v *neq in
    *nel vrne prava podatka glede na strukturo na st. neq in nel ne smeta biti
    NULL! Funkcija tudi inicializira elementa polj coefs in diag!
    $A Igor avg00; */
{
int i,j,n=0,*Pptrs=NULL,*Pcumptrs=NULL,*Pindxs=NULL;
double *Pcoefs=NULL,*Pdiag=NULL;
char wrongdim=0;
indtab it;
if (st==NULL)
{
  *neq=*nel=0;
  wrongdim=0;
} else
{
  /* Najprej se razbere stevilo elementov in vrstic */
  for (i=1;i<=st->n;++i)
    if ((it=st->s[i])!=NULL)
      n+=it->n;
  if (n!=*nel)
  {
    wrongdim=1;
    *nel=n;
  } 
  if (st->n!=*neq)
  {
    wrongdim=1;
    *neq=st->n;
  }
}
/* Alokacija polj po potrebi: */
if (ptrs!=NULL)
{
   if (*ptrs!=NULL && wrongdim)
    { free(*ptrs);  *ptrs=NULL; }
  if (*ptrs==NULL)
    *ptrs=malloc(*neq*sizeof(**ptrs));
  Pptrs=*ptrs;
  for (i=0;i<*neq;++i)
    Pptrs[i]=0;
}
if (cumptrs!=NULL)
{
  if (*cumptrs!=NULL && wrongdim)
    { free(*cumptrs);  *cumptrs=NULL; }
  if (*cumptrs==NULL)
    *cumptrs=malloc(*neq*sizeof(**cumptrs));
  Pcumptrs=*cumptrs;
  for (i=0;i<*neq;++i)
    Pcumptrs[i]=0;
}
if (indxs!=NULL)
{
  if (*indxs!=NULL && wrongdim)
    { free(*indxs);  *indxs=NULL; }
  if (*indxs==NULL)
    *indxs=malloc(*nel*sizeof(**indxs));
  Pindxs=*indxs;
}
if (coefs!=NULL)
{
  if (*coefs!=NULL && wrongdim)
    { free(*coefs);  *coefs=NULL; }
  if (*coefs==NULL)
    *coefs=malloc(*nel*sizeof(**coefs));
  Pcoefs=*coefs;
  for (i=0;i<*nel;++i)
    Pcoefs[i]=0;
}
if (diag!=NULL)
{
  if (*diag!=NULL && wrongdim)
    { free(*diag);  *diag=NULL; }
  if (*diag==NULL)
    *diag=malloc(*neq*sizeof(**diag));
  Pdiag=*diag;
  for (i=0;i<*neq;++i)
    (*diag)[i]=0;
}
if (wrongdim)
  printf("\n\nFunction spmatindtabtoNASA: Wrong dimensions, reallocation performed.\n\n");
n=1; /* Stevilka trenutnega indeksa */
if (st!=NULL)
  for (i=1;i<=st->n;++i)
  {
    it=st->s[i];
    if (it!=NULL)
    {
      if (ptrs!=NULL)
        Pptrs[i-1]=it->n;
      if (cumptrs!=NULL)
        Pcumptrs[i-1]=n;
      if (indxs!=NULL)
        for (j=1;j<=it->n;++j)
        {
          Pindxs[n-1]=it->t[j];
          ++n;
        }
    }
  }
}







            /****************************/
            /*                          */
            /*    SPOMINSKI BUFFERJI    */
            /*                          */
            /****************************/



membuf newmembuf(int r)
    /* Naredi in vrne spominski buffer, ki mu alocira spomina za r bytov. Ce je
    r manjsi ali enak 0, buffer nima alociranega spomina. polje p postavi na 0.
    $A Igor okt01; */ 
{
membuf ret;
ret=malloc(sizeof(*ret));
ret->p=0;
if (r>0)
{
  ret->b=malloc(r);
  ret->r=r;
} else
{
  ret->b=NULL;
  ret->r=0;
}
return ret;
}


void dispmembuf(membuf *pb)
    /* Zbrise spominski buffer *pb in postavi *pb na NULL.
    $A Igor okt01; */
{
if (pb!=NULL)
  if (*pb!=NULL)
  {
    if ((*pb)->b!=NULL)
      free((*pb)->b);
    free(*pb);
    *pb=NULL;
  }
}


void resizemembuf(membuf buf,int r)
    /* Kolicino alociranega spomina v spominskem bufferju buf spremeni na r.
    Ce pozicija buf->p pade izven novega stevila alociranih mest, se postavi
    na 0. Vsebina alociranega spomina ostane ista v moznem obsegu.
    $A Igor okt01; */
{
if (buf!=NULL)
  if (buf->r!=r)
  {
    buf->b=realloc(buf->b,r);
    buf->r=r;
    if (buf->p>=buf->r)
      buf->p=0;
  }
}


void increasemembuf(membuf buf,int r)
    /* Ce ima buffer buf manj kot r bytov alociranega spomina, se alociran
    prostor poveca na r bytov, drugace pa se ne spremeni. Vsebina alociranega
    spomina ostane ista v moznem obsegu.
    $A Igor okt01; */
{
if (buf!=NULL && r>=0)
  if (buf->r<r)
  {
    buf->b=realloc(buf->b,r);
    buf->r=r;
  }
}




void decreasemembuf(membuf buf,int r)
    /* Ce ima buffer buf vec kot r bytov alociranega spomina, se alociran
    prostor zmanjsa na r bytov, drugace pa se ne spremeni. Vsebina alociranega
    spomina ostane ista v moznem obsegu.
    $A Igor okt01; */
{
if (buf!=NULL && r>=0)
  if (buf->r>r)
  {
    buf->b=realloc(buf->b,r);
    buf->r=r;
  }
}


void increasemembufex(membuf buf,int r,int ex)
    /* Ce ima buffer buf manj kot r bytov alociranega spomina, se alociran
    prostor poveca na r+ex bytov, drugace pa se ne spremeni. Vsebina alociranega
    spomina ostane ista v moznem obsegu.
    $A Igor okt01; */
{
if (buf!=NULL && r>=0)
{
  if (ex<0)
    ex=0;
  if (buf->r<r)
  {
    r+=ex;
    buf->b=realloc(buf->b,r);
    buf->r=r;
  }
}
}




void decreasemembufex(membuf buf,int r,int ex)
    /* Ce ima buffer buf vec kot r+2*ex bytov alociranega spomina, se alociran
    prostor zmanjsa na r bytov, drugace pa se ne spremeni. Vsebina alociranega
    spomina ostane ista v moznem obsegu.
    $A Igor okt01; */
{
if (buf!=NULL && r>=0)
{
  if (ex<0)
    ex=0;
  if (buf->r>r+2*ex)
  {
    buf->b=realloc(buf->b,r);
    buf->r=r;
  }
}
}





            /*********************************/
            /*                               */
            /*    GLOBALNI POMOZNI BUFFER    */
            /*                               */
            /*********************************/



static membuf globbuf=NULL;  /* Globalni pomozni pomnilnik *
/* Najmanjsa dopustna dolzina globalnega pomnilnika: */
#define minglobbuf 50


char *tmpstringbuf(void)
    /* Vrne alociran niz za zacasni spominski buffer z zagotovljeno dolzino
    50 znakov (to je definirano v makroju minglobbuf). Vrnjenega bufferja se ne 
    sme brisati ali realoci rati.
    $A Igor jan02; */
{
if (globbuf==NULL)
  globbuf=newmembuf(minglobbuf);
return globbuf->b;
}

char *tmpstringbufmin(int minlength)
    /* Vrne alociran niz za zacasni spominski buffer in poskrbi, da je dolzina
    bufferja vsaj minlength. Vrnjenega bufferja se ne sme brisati ali realoci-
    rati.
    $A jan02; */
{
if (globbuf==NULL)
  globbuf=newmembuf(minlength);
if (minlength>globbuf->r)
 increasemembuf( globbuf,minlength);
return globbuf->b;
}

void decreasetmpstringbuf(int size)
    /* Poskrbi, da alocirana dolzina niza, ki se uporablja za zacasni buffer,
    ni vecja kot size.
    $A Igor jan02; */
{
if (globbuf!=NULL)
{
  if (size<minglobbuf)
    size=minglobbuf;
  decreasemembuf(globbuf,size);
}
}


#undef minglobbuf

