
#include <sysint.h>

#include <stdlib.h>
#include <stddef.h>
#include <math.h>

#include <mtypes.h>
#include <rf.h>
#include <st.h>
#include <vec.h>
#include <strop.h>

#include <sg_obj.h>
#include <grint.h>
#include <gro.h>
#include <sg_graph.h>
#include <grdxf.h>
#include <grps.h>


#include <time.h>



/* $$ DEFINICIJE RAZNIH FUNKCIJ, KI SE UPORABIJO PRI RISANJU: */


double fxy(double x,double y)
{
  return (sin(x)*sin(y));
}

double fxy1(double x,double y)
{
  return 0.5*(x*x+0.5*y*y)-1;
}

double fxy2(double x,double y)
{
  return x+y+0.1*x*y;
}



static double R=1.3;


double parx(double fi,double theta)
{
  return R*cos(theta)*cos(fi);
}

double pary(double fi,double theta)
{
  return R*cos(theta)*sin(fi);
}

double parz(double fi,double theta)
{
  return R*sin(theta);
}


double fx(double fi)
{
  return R*cos(fi) +R*sin(60*fi)/30;
}

double fy(double fi)
{
  return R*sin(fi) +R*cos(60*fi)/30;
}

double fz(double fi)
{
  return R*sin(10*fi)/2;
}



double fspher1(double fi,double theta)
{
return 2+0.2*sin(theta)* (sin(6*fi)*cos(8*theta)) ;
}

double fspher2(double fi,double theta)
{
return 2+0.2*sin(theta)* (sin(6*fi)+cos(3*theta)) ;
}

double fspher(double fi,double theta)
{
return 2+0.2*sin(theta)* (sin(6*fi)+1.5*cos(8*theta)) ;
}

double fspher4(double fi,double theta)
{
return 2+0.2*sin(theta)* (sin(6*fi+8*theta)) ;
}

double fspher5(double fi,double theta)
{
return 2*sin(2*theta);
}


double fcyl(double r,double fi)
{
return 0.02*r+1*fi;
}

double fbottle(double z,double fi)
{
return ( 3*exp(-z*z/16)*(1+0.1*cos(2*z+10*fi)) );
}



/* $$ PRIMER ZLAGANJA OBJEKTOV NA ROKE */



gogroup testgofwrite(void)
{
_coord3d p1,p2,p3,p4;
gogroup ret=NULL,pom=NULL;
goprimitive prim=NULL;
golinesettings ls1;
gofillsettings fs1;
gotextsettings ts1;
goprimitive p;
ret=newgogroupst(2,3,1);
pom=newgogroupst(0,0,1);
pom->name=stringcopy("Podskupina");
pushstack(ret->groups,NULL);
pushstack(ret->groups,(void *) pom);
/*
ret->name=stringcopy("frame3d");
ret->primitives=newstack(5);
ret->groups=newstack(1);
*/
/* Nastavitve za risanje crt: */
ret->ls1=malloc(sizeof(*ret->ls1));
ret->ls1->color.red=1; ret->ls1->color.green=0; ret->ls1->color.blue=0;
ret->ls1->linewidth=2;
ret->ls1->linetype=3;
ret->ls1->extra=NULL;
/* Nastavitve za risanje ploskev: */
ret->fs1=malloc(sizeof(*ret->fs1));
ret->fs1->color.red=0; ret->fs1->color.green=1; ret->fs1->color.blue=0;
ret->fs1->extra=NULL;
/* Nastavitve za risanje teksta: */
ret->ts1=malloc(sizeof(*ret->ts1));
ret->ts1->color.red=0; ret->ts1->color.green=0; ret->ts1->color.blue=1;
ret->ts1->font=1;
ret->ts1->height=0.03;
ret->ts1->spacing=0;
ret->ts1->expansion=1;
ret->ts1->xalignment=0;
ret->ts1->yalignment=0;
ret->ts1->extra=NULL;
/* Nekaj crt: */
p1.x=-1; p1.y=-1; p1.z=-1;
p2.x=1; p2.y=1; p2.z=1;
goaddline(&p1,&p2,ret->primitives,ret);
p1.x=1; p1.y=-1; p1.z=-1;
p2.x=-1; p2.y=1; p2.z=1;
goaddline(&p1,&p2,ret->primitives,ret);
p1.x=-1; p1.y=1; p1.z=-1;
p2.x=1; p2.y=-1; p2.z=1;
goaddline(&p1,&p2,ret->primitives,ret);
p1.x=-1; p1.y=-1; p1.z=1;
p2.x=1; p2.y=1; p2.z=-1;
prim=goaddline(&p1,&p2,ret->primitives,ret);
/* Posebne nastavitve za risanje crt za zadnjo crto: */
ls1=malloc(sizeof(*ls1));
ls1->color.red=1; ls1->color.green=0.5; ls1->color.blue=0;
ls1->linewidth=2;
ls1->linetype=3;
ls1->extra=NULL;
prim->props1=ls1;
/* Nekaj ploskev: */
p1.x=-0.3;   p1.y=-0.3;  p1.z=-0.3;
p2.x=0.3;   p2.y=-0.3;  p2.z=-0.3;
p3.x=0.3;   p3.y=0.3;  p3.z=-0.3;
p4.x=-0.3;   p4.y=0.3;  p4.z=-0.3;
p=goaddpartbordfourangle(&p1,&p2,&p3,&p4,1,0,0,1,ret->primitives,ret);
p->after=newstack(3);
pushstack(p->after,goaddline(&p1,&p3,ret->extraprimitives,ret));
pushstack(pom->extraprimitives,NULL);
pushstack(p->after,goaddline(&p2,&p4,pom->extraprimitives,pom));
pushstack(pom->extraprimitives,NULL);
pom->ls1=malloc(sizeof(*pom->ls1));
*pom->ls1=*ls1;
p1.x=-0.3;   p1.y=-0.3;  p1.z=0.7;
p2.x=0.3;   p2.y=-0.3;  p2.z=0.9;
p3.x=0.3;   p3.y=0.3;  p3.z=0.9;
p4.x=-0.3;   p4.y=0.3;  p4.z=0.7;
goaddpartbordfourangle(&p1,&p2,&p3,&p4,1,0,0,1,ret->primitives,ret);
p1.x=0.6;   p1.y=0.4;  p1.z=0.2;
p2.x=1.1;   p2.y=0.4;  p2.z=0.2;
p3.x=1.1;   p3.y=-0.4;  p3.z=0.2;
p4.x=0.6;   p4.y=-0.4;  p4.z=0.2;
prim=goaddpartbordfourangle(&p1,&p2,&p3,&p4,1,0,1,0,ret->primitives,ret);
/* Posebne nastavitve za barvanje ploskev za zadnjo ploskec: */
fs1=malloc(sizeof(*fs1));
fs1->color.red=0; fs1->color.green=1; fs1->color.blue=1;
fs1->extra=NULL;
prim->props1=fs1;
p1.x=0;   p1.y=0;  p1.z=-0.1;
goaddtext("gfjdlkFSAGI",&p1,ret->primitives,ret);



ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->height=0.025;
ts1->font=2;
p1.z=0.9; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 2",&p1,ret->primitives,ret);
prim->props2=ts1;

/*

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=3;
p1.z=0.8; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 3",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=4;
p1.z=0.7; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 4",&p1,ret->primitives,ret);
prim->props2=ts1;

*/

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=5;
p1.z=0.6; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 5",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1->xalignment=-1;
ts1->yalignment=0;


/*

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=6;
p1.z=0.5; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 6",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=7;
p1.z=0.4; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 7",&p1,ret->primitives,ret);
prim->props2=ts1;

*/

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=8;
p1.z=0.3; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 8",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1->xalignment=1;
ts1->yalignment=0;


/*

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=9;
p1.z=0.2; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 9",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=10;
p1.z=0.1; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 10",&p1,ret->primitives,ret);
prim->props2=ts1;

*/

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=11;
p1.z=0.0; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 11",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1->xalignment=0;
ts1->yalignment=-1;


/*

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=12;
p1.z=-0.1; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 12",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=13;
p1.z=-0.2; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 13",&p1,ret->primitives,ret);
prim->props2=ts1;

*/

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=14;
p1.z=-0.3; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 14",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1->xalignment=0;
ts1->yalignment=1;


/*

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=15;
p1.z=-0.4; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 15",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=16;
p1.z=-0.5; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 16",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=17;
p1.z=-0.6; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 17",&p1,ret->primitives,ret);
prim->props2=ts1;

*/

ts1=malloc(sizeof(*ts1));
*ts1=*(ret->ts1);
ts1->height=0.025;
ts1->color.blue=0.1; ts1->color.red=0; ts1->color.green=0;
ts1->font=18;
p1.z=-0.7; p1.x=0.1; p1.y=0.1;
prim=goaddtext("Font 18",&p1,ret->primitives,ret);
prim->props2=ts1;

ts1->xalignment=0;
ts1->yalignment=0;


return ret;
}




stack pst=NULL;

void redraw(void)
{
giresetwindow();
godrawstackscreen(pst);
}




void main(void)
{


double fi,theta,hfi,htheta,fi1,theta1,hfi1,htheta1,maxlength,maxlength1,x;
int numx,numy,divx,divy,numx1,numy1,divx1,divy1;
int win,win1,win2;
stack st,st1;
clock_t t1,t2;
int i,j,k,iloop=0;
frame3d winlimits=NULL,frame=NULL,winlimits1=NULL,frame1=NULL,framepar=NULL;
stack gost=NULL,gost1=NULL,fst=NULL,testst=NULL;
gogroup gg=NULL,gg1=NULL,gg2=NULL,gg3=NULL,gg4=NULL,gg5=NULL,gg6=NULL,gg7=NULL,
     gg8=NULL,gg9=NULL,gg10=NULL,
     ggg=NULL,ggg1=NULL,ggg2=NULL,ggg3=NULL,ggg4=NULL,gtest=NULL,gtest1=NULL,gtest2=NULL;
gofillsettings fs=NULL;
golinesettings ls=NULL,ls1=NULL,ls2=NULL;
gotextsettings ts=NULL;
_truecolor col;

fs=malloc(sizeof(*fs));
ls=malloc(sizeof(*ls));



godolighting(0);

gicoloring(1);
ginumshades(8);

/* $$ ODPRTJE DVEH GRAFICNIH OKEN: */

giinitdisplay();
gisetwindowtitle("okno");
ginsetwindowxpos(20); ginsetwindowypos(10);
ginsetwindowwidth(200); ginsetwindowheight(200);
win=giopenwindow();    giinitgraph();
gisetwindowxpos(0.5); gisetwindowypos(0);
gisetwindowtitle("okno 1");
win1=win;   giinitgraph();


/* $$ TEST FUNKCIJ IZ GRAFICNEGA VMESNIKA (grint.c) */

gisetlinewidth(1);
gisetlinetype(1);
giline(0,0,2,1);
giflushdisplay();

/* Test funkcije za dolocanje barve kontur: */
j=0;
for (i=1;i<=10;++i)
{
  gisetlinewidth(i);
  x=(double) i/10; calccontourcolor(x,0,1,&col);
   gisetlinecolor(col.red,col.green,col.blue);
  giline(0,x,1,x); giflushdisplay();
  ++j;
  if (j>=10)
  {
    printf("x=%-5.3g, R=%-6.3g, G=%-6.3g, B=%-6.3g\n",x,col.red,col.green,col.blue);
    j=0;
  }
}




/* $$ DOLOCITEV RESOLUCIJE 3D RISB (to je namerno zbrano na enem mestu) */

numx=11; divx=4; numy=11; divy=4;
numx1=15; divx1=1; numy1=15; divy1=1;
fi=0;     theta=15;
hfi=13; htheta=3;
fi1=30;     theta1=15;
hfi1=20; htheta1=8;




/* $$ SESTAVA OBJEKTOV ZA 1. OKNO: */



/* Okvir v oknu, v katerega naj pade 1. graf: */
winlimits=malloc(sizeof(*winlimits));
frame=malloc(sizeof(*frame));
winlimits->min.x=0; winlimits->min.y=0.0; winlimits->max.x=1; winlimits->max.y=1;
/* Geometrijske meje graf. objekta v 1. oknu: */
frame->min.x=-3.5;    frame->min.y=-3.5;    frame->min.z=-2;
frame->max.x=3.5;     frame->max.y=3.5;     frame->max.z=2;
/* GRAFICNI OBJEKTI ZA 1. OKNO: */
printf("Making graphic objects.\n");
t1=t2=clock();

/* Nastavitve za risanje ploskev: */
fs->color.red=0; fs->color.green=0; fs->color.blue=1;

/* Nastavitve za risanje crt: */
ls->color.red=0; ls->color.green=0.7; ls->color.blue=0.4;
ls->linewidth=6;
ls->linetype=1;
ls1=malloc(sizeof(*ls1)); ls2=malloc(sizeof(*ls2));
ls->color.red=0; ls->color.green=0; ls->color.blue=0.8;
ls->linewidth=1;
ls->linetype=1;
ls1->color.red=0; ls1->color.green=1; ls1->color.blue=0;
ls1->linewidth=3;
ls1->linetype=2;
ls2->color.red=1; ls2->color.green=0; ls2->color.blue=0;
ls2->linewidth=1;
ls2->linetype=1;

/* Nastavitve za risanje teksta: */
ts=malloc(sizeof(*ts));
ts->color.red=0.5; ts->color.green=0.1; ts->color.blue=0.7;
ts->font=1;
ts->height=0.025;
ts->expansion=1;
ts->xalignment=0;
ts->yalignment=0;


ls->color.red=0;  ls->color.green=0;  ls->color.blue=1; ls->linewidth=1;
fs->color.red=0;  fs->color.green=1;  fs->color.blue=1;
gg6=gosurfaceplot(fxy,numx,divx,numy,divy,frame,fs,ls,7,2);



ls->color.red=1;  ls->color.green=1;  ls->color.blue=0; ls->linewidth=2;
fs->color.red=0.5;  fs->color.green=0.5;  fs->color.blue=1;
gg5=gosurfaceplot(fxy,numx,divx,numy,divy,frame,fs,ls,4,2);

ls->linewidth=1;


gg7=gocontourplotsimp(fxy1,-1,10,20,10,20,frame,ls,1,0.0);


fs->color.red=1;  fs->color.green=1;  fs->color.blue=0;
ls->color.red=1; ls->color.green=0; ls->color.blue=0;
ls->linewidth=1;
ls->linetype=1;
gg8=gosurfaceplot(fxy2,numx,divx,numy,divy,frame,fs,ls,28,2);




/* Stvari, ki se ticejo okvirja: */
gg=gomakerulertext3d(frame,ts,6,10,3,0.1);
ls1->color.red=0;  ls->color.green=1;  ls->color.blue=0;  ls1->linewidth=1;
ls->color.red=1;  ls->color.green=0;  ls->color.blue=0;
gg1=gomakeframe3d(frame,ls,ls1,numx*divx+numy*divy,numx*divx+numy*divy,
                 numx*divx+numy*divy);
gg2=gomakerulers3d(frame,ls,ls1,ls1,10,0.02,0.03,0.06);
gg3=gomakeendaxeslabels3d(frame,"X","Y","Z",ts,0.1);
/*
gg4=gomakegridbascorner3d(frame,ls,ls1,ls2,10);
*/

/* $$ NALAGANJE GRAFICNIH OBJEKTOV NA SKLAD */

gost=newstack(100);
/*
goloadtostack(gg,gost);
*/
goloadtostack(gg1,gost);

goloadtostack(gg2,gost);
/*
goloadtostack(gg3,gost);
goloadtostack(gg4,gost);
*/
goloadtostack(gg5,gost);
/*
goloadtostack(gg6,gost);
goloadtostack(gg7,gost);
goloadtostack(gg8,gost);
*/

/*
gtest=testgofwrite();
gofilewritegroup("00",gtest,0,1);
goloadtostack(gtest,gost);
fi+=hfi; theta+=htheta;
gisetwindow(win);
preparegraph3dbas(frame,winlimits);
gosettransfsimp(rad(fi),rad(theta));
godolighting(0);
gotransfgroup(gtest);
godrawstackscreen(gost);
gost=NULL;
giflushdisplay();
getchar();
*/
/* Branje iz datotek: */
/*
testst=newstack(10);

printf("Reading graph. files:\n");

filereadgofile("003",&testst);
filereadgofile("004",&testst);

printf("GRAPH. FILE READ.\n");


gtest=(gogroup) testst->s[1];
gtest1=(gogroup) testst->s[2];

gofilewritegroup("0",gtest,0,2);
gofilewritegroup("0a",gtest1,0,2);

printf("GRAPH. FILE WRITTEN.\n");

*/


/*
if (testst->n>0)
{
  int i;
  for (i=1;i<=testst->n;++i)
  {
    goloadtostack((gogroup)testst->s[i],gost);
  }
}
*/









/* SESTAVA GRAFICNIH OBJEKTOV ZA 2. OKNO: */


/* Okvir v oknu, v katerega naj pade 2. graf: */
framepar=malloc(sizeof(*framepar));  /* Za parametricno podane ploskve */
winlimits1=malloc(sizeof(*winlimits));
frame1=malloc(sizeof(*frame));
/* okenske meje: */
winlimits1->min.x=0; winlimits1->min.y=0; winlimits1->max.x=1;
 winlimits1->max.y=1;
/* Geometrijske meje graf. objekta v 2. oknu: */
frame1->min.x=-3;    frame1->min.y=-3;    frame1->min.z=-2;
frame1->max.x=3;     frame1->max.y=3;     frame1->max.z=2;
/* Meje za parametricni graf: */
framepar->min.x=0; framepar->max.x=rad(360);
 framepar->min.y=rad(0); framepar->max.y=rad(180);

/* GRAFICNI OBJEKTI ZA 2. OKNO: */

ls->linewidth=1;
ls->linetype=1;
ggg=gomakeframe3d(frame,ls,ls1,numx1*divx1+numy1*divy1,numx1*divx1+numy1*divy1,
                 numx1*divx1+numy1*divy1);

ls->color.red=0.0;  ls->color.green=0.6;  ls->color.blue=1;
fs->color.red=1;  fs->color.green=1;  fs->color.blue=1;
ggg1=gosurfaceplot(fxy,numx1,divx1,numy1,divy1,frame1,fs,ls,8,0);


ggg2=gosurfaceplotpar(parx,pary,parz,numx1,divx1,numy1,divy1,framepar,fs,ls,0,0);


ggg3=gosurfaceplotbottle(fbottle,numx1,divx1,numy1,divy1,framepar,fs,ls,4,0);


ls->linewidth=2;
ls->color.red=0.8; ls->color.green=0.0; ls->color.blue=0.0;
ggg4=gocurveplot3dpar(fx,fy,fz,1000,1,0,rad(360),ls);


/* Nalaganje graficnih objektov na sklad: */
gost1=newstack(100);
goloadtostack(ggg,gost1);
goloadtostack(ggg1,gost1);
goloadtostack(ggg2,gost1);
goloadtostack(ggg3,gost1);
goloadtostack(ggg4,gost1);


/* Zapis v datoteke: */
/*
printf("\n\nWriting groups to files:\n");
gofilewritegroup("001",ggg,0,2);
gofilewritegroup("002",ggg1,0,2);
gofilewritegroup("003",ggg2,0,2);
gofilewritegroup("004",ggg3,0,2);
printf("End writing.\n");
*/




/* $$ DEFINICIJE VIROV SVETLOBE: */
/*
goremovelights();
*/
gosetdifuselight(0.2,0.3,0);
gosetfarlight(0,0.3,0, 0,0,1);
gosetfarlight(1,0.2,0,-1,-0.9,0.2);
gosetfarlight(0,0.2,1,0.8,1,0.2);
gosetfarlight(0,0,1,2,0,-1);
gosetfarlight(0.7,0.8,0.2,0,1,-1);
gosetpowfarlighting(0);
/* goupdatelightfactor(2.5); */
goupdatelightfactor(0.5);
godolighting(0);

getchar();
gisetwindow(win); giresetwindow();
gisetwindow(win1); giresetwindow();


iloop=0;


while(1)
{
  ++iloop;
  fi+=hfi; theta+=htheta;
  fi1+=hfi1; theta1+=htheta1;
  ++i;

  /* $$ IZRIS GRAFA V 1. OKNU: */
  
  printf("Risanje v 1. oknu; iloop = %i\n",iloop);
  
  gisetwindow(win);

  preparegraph3dbas(frame,winlimits);
  gosetdistancefactor(2);
  gosettransfscalingfactors(1,1,0.4);
  gosettransfeyesimpscale(rad(fi),rad(theta));
  /* godolighting(1); */
  
  gotransfstack(gost);
  gosortstack(gost);

  /*
  if (i>5)
  {

    giclearwindow();
    giresetwindow();

  }
  */
  
  /* Brisanje zaslona */
  giclearwindow();
  
  /* Izris: */
  godrawstackscreen(gost);
  giflushdisplay();
  sleep(2);
  /*
  psfiledrawstack("0.ps",gost);
  tclfiledrawstack("0.tcl",gost);
  */



  /* $$ IZRIS GRAFA V 2. OKNU: */
  
  
if (iloop!=1)
  printf("Parent; iloop=%i; fork se ne izvrsi\n.");
else
if (fork()==0)
if (1)
{
  
  giinitdisplay();
  gisetwindowtitle("blabla");
  gisetwindowxpos(0.5); gisetwindowypos(0);
  win2=giopenwindow();
  giinitgraph();

  printf("Risanje v 2. oknu; iloop = %i\n",iloop);
  gisetwindow(win2);
  preparegraph3dbas(frame1,winlimits1);
  gosettransfsimpscale(rad(fi1),rad(theta1));
  /* godolighting(1); */
  gotransfgroup(ggg);
  gotransfgroup(ggg1);
  gotransfgroup(ggg2);
  gotransfgroup(ggg3);
  gotransfgroup(ggg4);
  gosortstack(gost1);
  if (i>5)
  {

    giclearwindow();
    giresetwindow();

  }

  /* Brisanje zaslona */
  gisetfillcolor(1,1,1);
  gifillrectangle(0,0,1,1);

  /* Izris: */
  /*
  godrawstackscreen(gost1);
  */
  
  pst=gost1;
  gidrawloop(redraw);
  
  exit(0);
  
  giflushdisplay();
  /*
  psfiledrawstack("0.ps",gost1);
  */

  /* Zapis v datoteko v DXF in PS formatu: */
  /*
  printf("Writing transformed objects to DXF file.\n");
  dxffiledrawstack("0.dxf",gost1);
  psfiledrawstack("0.dxf",gost1);
  */
  
} 


  
  
  
  
  if (i>5) i=0;
}


}



