
 
#if 0
  /* Definitions that allow not to change sysint.h when using emulation of
  Elfen interface; 
    Attention: Don't forget to switch off when not needed! */
  #define EMELFINT
  #define OTHERMAIN
#endif


#include "testitk.h"


/*

#include "invan.h"



#include "testitk.h"

#include "testfem.h"


#include "sgs_test.h"
#include "sg_grt0.h"


#include "grt0.h"
#include "grt2d.h"

#include "invan.h"


Meschach functionality:
#include "meschach/tutorial.h"

#include "pm.h"

*/

/*
    5   10    5   20    5   30    5   40    5    50   5   60    5   70    5   80
*/




