
#include <sg_obj.h>


          /**************************************************/
          /*   GRAFICNI VMESNIK ZA FORMATE PS, DXF IN TCL   */
          /**************************************************/


   /* TA DATOTEKA JE VKLUCENA V DATOTEKO grint.c z #include "grfint.h". */


static FILE *fp=NULL;

static _coord3d p1,p2,p3,p4,p5;






                     /**************************/
                     /*       FORMAT PS        */
                     /**************************/



static int psiprecision=6;  /* St. decimalk pri zapisovanju realnih stevil */

static char shortoperators=1; /* Ce je 1, se uporabi krajsi zapis operatorjev;
                                 pri tem se definirajo krajsa imena. */

static char psiepsformat=1;   /* Ce je 1, se v datoteke dodajo glave za eps. */

    /* NIZI, KI PREDSTAVLJAJO OPERATORJE V PostScriptu (uvedeni so kot
       spremenljivke zaradi moznosti predefiniranja oz. zamenjave s krajsimi
       nizi: */

static char *movetostr0="moveto";
static char *linetostr0="lineto";
static char *newpathstr0="newpath";
static char *closepathstr0="closepath";
static char *strokestr0="stroke";
static char *fillstr0="fill";
static char *showstr0="show";
static char *setlinewidthstr0="setlinewidth";
static char *setgraystr0="setgray";
static char *setrgbcolorstr0="setrgbcolor";
static char *findfontstr0="findfont";
static char *setfontstr0="setfont";
static char *scalefontstr0="scalefont";
static char *defstr0="def";

static char *movetostr1="Mt";
static char *linetostr1="Lt";
static char *newpathstr1="Np";
static char *closepathstr1="Cp";
static char *strokestr1="St";
static char *fillstr1="Fl";
static char *showstr1="Sh";
static char *setlinewidthstr1="Slw";
static char *setgraystr1="Sg";
static char *setrgbcolorstr1="Sc";
static char *findfontstr1="Ff";
static char *setfontstr1="Sf";
static char *scalefontstr1="Scf";
static char *defstr1="def";

static char *movetostr="moveto";
static char *linetostr="lineto";
static char *newpathstr="newpath";
static char *closepathstr="closepath";
static char *strokestr="stroke";
static char *fillstr="fill";
static char *showstr="show";
static char *setlinewidthstr="setlinewidth";
static char *setgraystr="setgray";
static char *setrgbcolorstr="setrgbcolor";
static char *findfontstr="findfont";
static char *setfontstr="setfont";
static char *scalefontstr="scalefont";
static char *defstr="def";



void psisetshortoperators(void)
    /* V uporabo postavi kratka imena operatorjev: nastavi ustrezne nize, ki
    predstavljajo operatorje v formatu PostScript in postavi shortoperators
    na 1.
    $A Igor <== apr97; */
{
shortoperators=1;
movetostr=movetostr1;
linetostr=linetostr1;
newpathstr=newpathstr1;
closepathstr=closepathstr1;
strokestr=strokestr1;
fillstr=fillstr1;
showstr=showstr1;
setlinewidthstr=setlinewidthstr1;
setgraystr=setgraystr1;
setrgbcolorstr=setrgbcolorstr1;
findfontstr=findfontstr1;
setfontstr=setfontstr1;
scalefontstr=scalefontstr1;
}


void psisetlongoperators(void)
    /* V uporabo postavi dolga imena operatorjev: nastavi ustrezne nize, ki
    predstavljajo operatorje v formatu PostScript in postavi shortoperators
    na 0.
    $A Igor <== apr97; */
{
shortoperators=0;
movetostr=movetostr0;
linetostr=linetostr0;
newpathstr=newpathstr0;
closepathstr=closepathstr0;
strokestr=strokestr0;
fillstr=fillstr0;
showstr=showstr0;
setlinewidthstr=setlinewidthstr0;
setgraystr=setgraystr0;
setrgbcolorstr=setrgbcolorstr0;
findfontstr=findfontstr0;
setfontstr=setfontstr0;
scalefontstr=scalefontstr0;
}

static void psifwriteshortdef(FILE *fp)
    /* V datoteko fp, v katero nameravamo zapisati risbo v formatu PostScript,
    zapise definicije, ki omogocajo uporabo kratkih imen operatorjev.
    $A Igor <== apr97; */
{
fprintf(fp,"/%s {%s} %s\n",movetostr1,movetostr0,defstr);
fprintf(fp,"/%s {%s} %s\n",linetostr1,linetostr0,defstr);
fprintf(fp,"/%s {%s} %s\n",newpathstr1,newpathstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",closepathstr1,closepathstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",strokestr1,strokestr0,defstr);
fprintf(fp,"/%s {%s} %s\n",fillstr1,fillstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",showstr1,showstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",setlinewidthstr1,setlinewidthstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",setgraystr1,setgraystr0,defstr);
fprintf(fp,"/%s {%s} %s\n",setrgbcolorstr1,setrgbcolorstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",findfontstr1,findfontstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",setfontstr1,setfontstr0,defstr);
fprintf(fp,"/%s {%s} %s\n",scalefontstr1,scalefontstr0,defstr);
fprintf(fp,"\n\n");
}


  /* ZAPISOVANJE BARV (POZOR, funkcije ne zapisujejo presledkov pred in po): */


static char psinopalette=0,    /* crno-bela risba */
            psigraypalette=0,  /* risba z odtenki sive */
            psirgbpalette=1;   /* barvna risba */


static void psifprintcolor(FILE *fp,float red,float green,float blue)
    /* Zapis barve s komponentami red, green in blue v datoteko fp. Glede
    na vrednosti spremenljivk psinopalette, psigraypalette in psirgbpalette se
    doloci, kako naj se ta barva interpretira. Ta funkcija se uporablja v
    funkcijah psifprintlinecolor(), psifprintfillcolor() in psifprinttextcolor().
    $A Igor <== apr97; */
{
double gr;
if (psirgbpalette)
{
  fprintf(fp,"%.*g %.*g %.*g %s",
  psiprecision,red,psiprecision,green,psiprecision,blue,setrgbcolorstr);
} else if (psigraypalette)
{
  gr=(red+green+blue)/3;
  fprintf(fp,"%.*g %s",psiprecision,gr,setgraystr);
}
else if (psinopalette)
{
}
}

static void psifprintlinecolor(FILE *fp)
    /* Zapis barve za risanje crt v datoteko fp
    $A Igor <== apr97; */
{
float red,green,blue;
gigetlinecolor(&red,&green,&blue);
psifprintcolor(fp,red,green,blue);
}

static void psifprintfillcolor(FILE *fp)
    /* Zapis barve za polnjenje v datoteko fp
    $A Igor <== apr97; */
{
float red,green,blue;
gigetfillcolor(&red,&green,&blue);
psifprintcolor(fp,red,green,blue);

}

static void psifprinttextcolor(FILE *fp)
    /* Zapis barve za risanje teksta v datoteko fp
    $A Igor <== apr97; */
{
float red,green,blue;
gigettextcolor(&red,&green,&blue);
psifprintcolor(fp,red,green,blue);
}



  /* ZAPISOVANJE OSTALIH NASTAVITEV (POZOR, funkcije ne zapisujejo presledkov
  pred in po): */


static void psifprintlinewidth(FILE *fp)
    /* Zapis debeline crt
    $A Igor <== apr97; */
{
int width;
width=(int) gigetlinewidth();
if (width>0) width-=1;  /* kompatibilnost med PostScriptom in risanjem na zaslon */
fprintf(fp,"%i %s",width,setlinewidthstr);
}



  /* FONTI: */


static char psifontshortcuts=0;  /* Ce je 1, se pri zapisu uporabljajo krajsave
                                imen fontov */
static stack psifontnames=NULL;  /* Imena fontov */
static char *psidefaultfontname="Times-Roman";
static char *psishortfontstr="Ft";

static void psiinstallfont(int num,char *name)
    /* Doda novo ime fonta, ki se uporablja pri risanju v formatu Postscript.
    num je zaporedna stevilka, pod katero se instalira font, name pa ime fonta.
    Ime fonta se nalozi na sklad psifontnames, ki se uporablja pri prireditvi
    imena fonta zaporedni stevilki pri zapisu v formatu PostScript. Zaporedne
    stevilke za fonte uporabljajo graficni objekti.
    $A Igor <== apr97; */
{
int i;
if (num<1) num=1;
if (psifontnames==NULL)
  psifontnames=newstack(5);
if (psifontnames->n<num)
  for (i=psifontnames->n+1;i<=num;++i)
    pushstack(psifontnames,NULL);
psifontnames->s[num]=stringcopy(name);
}


static void psiinitfontnames1(void)
    /* Funkcija se uporablja za instalacijo nekaterih imen fontov za zapis v
    formatu PostScript v primeru, ce ob klicu ni bil instaliran se noben font.
    $A Igor <== apr97; */
{
psiinstallfont(1,"Times-Roman");
psiinstallfont(2,"Courier");
psiinstallfont(3,"Helvetica");
psiinstallfont(4,"Arial");
psiinstallfont(5,"Courier-New");
psiinstallfont(6,"Symbol");
psiinstallfont(7,"Swiss");
psiinstallfont(8,"Italic");
psiinstallfont(9,"Bold");
psiinstallfont(10,"Bold-Italic");
psiinstallfont(11,"Modern");
psiinstallfont(12,"Script");
psiinstallfont(13,"Times-New-Roman");
psiinstallfont(14,"Greek");
psiinstallfont(15,"New-Roman");
psiinstallfont(16,"Gothic");
psiinstallfont(17,"Serif");
psiinstallfont(18,"San-Serif");
psiinstallfont(19,"Terminal");
psiinstallfont(20,"Dutch");
}


static void psifwritefonts(FILE *fp)
    /* V datoteko fp zapise definicije kratkih imen za fonte; Izkazalo se je, da
    do v PostScriptu ne dela, ker se operator def lahko uporablja za definicije
    novih operatorjev, ne pa na splosno za definicije katerihkoli imen (vsaj po
    tem, kar mi je do sedaj znanega).
    $A Igor <== apr97; */
{
int font;
char *fontname;
char done=0;
fprintf(fp,"\n");
if (psifontnames!=NULL)
{
  if (psifontnames->n>0)
  {
    for (font=1;font<=psifontnames->n;++font)
    {
      fontname=psifontnames->s[font];
      if (fontname==NULL)
        fontname=psidefaultfontname;
      fprintf(fp,"/%s%i {%s} %s\n",psishortfontstr,font,fontname,defstr);
    }
    done=1;
  }
}
if (!done)
  fprintf(fp,"/%s1 {%s} %s\n",psishortfontstr,psidefaultfontname,defstr);
fprintf(fp,"\n");
}



  /* SKALIRANJE KOORDINAT PRI ZAPISU V FORMATU PS: */





static char psiscalecoordinates=1; /* Ce je 1, se koordinate skalirajo kot pri
              risanju grafov, drugace se zapisejo naravne koordinate. */
/* Okno, v katerega se izrise slika: */
static double psistartx=0,   /* koordinata x leve strani okna */
              psistarty=0,   /* koordinata y spodnje strani okna */
              psisizex=500,  /* sirina okna */
              psisizey=500;  /* visina okna */


static void psinaturalwindowcoord(float x,float y,coord3d p)
    /* Pri transformaciji koordinat objektov v njihove okenske koordinate
    se pusti kar naravne koordinate.
    $A Igor apr97; */
{
p->x=x; p->y; p->z=0;
}


static void psigpwindowcoord(float x,float y,coord3d p)
    /* Normalni okenski koordinati (ki gresta v obeh smereh od 0 do 1 s
    koordinatnim izhodiscem v spodnjem levem kotu) se pretvorita v okenski
    koordinati za format PostScript.
    $A Igor apr97; */
{
p->x=psistartx+x*psisizex;
p->y=psistarty+y*psisizey;
p->z=0;
}



static void (*psiwindowcoord) (float,float,coord3d) = psigpwindowcoord;




void psisetscaling(char scaling)
    /* Doloci skaliranje koordinat pri zapisu graficnih objektov v formatu PS.
    ce je scaling==0, postane funkcija psiwindowcoord() za skaliranje koordinat
    kar funkcija psinaturalwindowcoord(), ki ohranja naravne koordinate objektov,
    drugace pa to postane funkcija psigpwindowcoord(), ki skalira koordinati x
    in y tako, kot se to naredi pri risanju na zaslon, koordinato z pa poskusa
    skalirati na podoben nacin.
    $A Igor <== apr97; */
{
psiscalecoordinates=scaling;
if (psiscalecoordinates==0)
  psiwindowcoord=psinaturalwindowcoord;
else psiwindowcoord=psigpwindowcoord;
}


static void psisetwindowsize(double width,double height)
    /* Postavi sirino postscript-ovega okna, v katerem se izrise graf iz
    datoteke, na width, in visino na height. Ce je eden ali drugi 0, se
    ohrani ustrezna dimenzija, ki je trenutno nastavljena.
    $A Igor maj01; */
{
if (width>0)
{
  psisizex=height;
}
if (height>0)
{
  psisizey=height;
}
}


static double psigetwindowwidth(void)
    /* Vrne sirino trenutnega Tcl-ovega okna v pixlih.
    $A Igor maj01;  */
{
return fabs(psisizex);
}

static double psigetwindowheight(void)
    /* Vrne visino trenutnega Tcl-ovega okna v pixlih.
    $A Igor maj01;  */
{
return fabs(psisizey);
}




  /* OSNOVNE FUNKCIJE ZA ZAPIS V FORMATU PS: */


static void psiline(float x1,float y1,float x2,float y2)
    /* $A Igor <== apr97; */
{
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
psifprintlinecolor(fp); fprintf(fp," ");
psifprintlinewidth(fp); fprintf(fp," ");
fprintf(fp,"%s\n",strokestr);
}


static void psitriangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* $A Igor <== apr97; */
{
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
psiwindowcoord(x3,y3,&p3);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p3.x,psiprecision,p3.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,linetostr);
psifprintlinecolor(fp); fprintf(fp," ");
psifprintlinewidth(fp); fprintf(fp," ");
fprintf(fp,"%s\n",strokestr);
}


static void psifourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* $A Igor <== apr97; */
{
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
psiwindowcoord(x3,y3,&p3);
psiwindowcoord(x4,y4,&p4);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p3.x,psiprecision,p3.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p4.x,psiprecision,p4.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,linetostr);
psifprintlinecolor(fp); fprintf(fp," ");
psifprintlinewidth(fp); fprintf(fp," ");
fprintf(fp,"%s\n",strokestr);
}


static void psifilltriangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* $A Igor <== apr97; */
{
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
psiwindowcoord(x3,y3,&p3);
fprintf(fp,"%s ",newpathstr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p3.x,psiprecision,p3.y,linetostr);
psifprintfillcolor(fp); fprintf(fp," ");
fprintf(fp,"%s\n",fillstr);
}


static void psifillfourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* $A Igor <== apr97; */
{
psiwindowcoord(x1,y1,&p1);
psiwindowcoord(x2,y2,&p2);
psiwindowcoord(x3,y3,&p3);
psiwindowcoord(x4,y4,&p4);
fprintf(fp,"%s ",newpathstr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p1.x,psiprecision,p1.y,movetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p2.x,psiprecision,p2.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p3.x,psiprecision,p3.y,linetostr);
fprintf(fp,"%.*g %.*g %s ",psiprecision,p4.x,psiprecision,p4.y,linetostr);
psifprintfillcolor(fp); fprintf(fp," ");
fprintf(fp,"%s\n",fillstr);
}







static void psimarktextpos(char *str,float x,float y,char mark,char box)
    /* Oznaci pozicijo teksta, ki naj bi se izpisal s funkcijo psitext. str je
    niz, ki naj bi se izpisal, x in y pa sta koordinati, pri katerih naj bi
    se niz izpisal. Ce je mark razlicen od 0, se izrise puscica na poziciji
    (x1,y1), ce pa je box 1, se izrise okvir okrog mej, s katerimi naj bi bil
    tekst omejen.
    $A Igor apr97; */
{
float marklength=(float) 0.03;
float xratio=/* 1.9332 */ (float) 1.5;
float yratio=(float) 1.514;
float x1,y1,x2,y2,height,dx,dy,xalign=0,yalign=0,red,green,blue;

if (mark || box)
{
  gisetlinewidth(1);
  gisetlinetype(2);
  gigettextcolor(&red,&green,&blue);
  gisetlinecolor(1-red,1-green,1-blue);
  if (mark)
  {
    x1=x-marklength;
    y1=y+(float) 0.3*marklength;
    x2=x1;
    y2=y-(float) 0.3*marklength;
    psiline(x,y,x1,y1); 
    psiline(x,y,x2,y2);
  }
  if (box)
  {  
    gisetlinecolor(red,green,blue);
    height=gigettextheight();
    xalign=(float) gigettextxalignment();
    yalign=(float) gigettextyalignment();
    /* Nastavitev poravnavanja teksta: */
    dy=height;    /* celotna visina teksta */
    dx=strlen(str)*height/xratio;    /* celotna sirina teksta */
    x1=x; y1=y;   /* (x,y) je spodnja leva tocka boksa. */
    /* poravnavanje v vodoravni smeri: */
    if (xalign==0)
      x1-=dx*(float) 0.5;
    else if (xalign==1)
      x1-=dx;
    if (yalign==0)
      y1-=dy*(float) 0.5;
    else if (yalign==1)
      y1-=dy;
    x2=x1+dx;
    y2=y1+dy;
    psifourangle(x1,y1,x2,y1,x2,y2,x1,y2);
  }
}
}





static void psitext(char *str,float x1,float y1)
    /* $A Igor <== apr97; */
{
float psitextscalingfactor=(float) fabs(psisizey);
int font=1;
char *fontname=NULL;
_coord3d p;
float xratio=(float) 1.9332;  /* razmerje med height in sirino crk */
float yratio=(float) 1.514;  /* razmerje med height in visino */
/* Zgornji razmerji sta doloceni za font Times-Roman za niz, ki vsebuje vse
znake na tipkovnici. */
float height=(float) 0.1;
float dx,dy; /* sirina in visina teksta */
int xalign=1,yalign=1;
psiwindowcoord(x1,y1,&p1);
height=gigettextheight()*psitextscalingfactor;
xalign=gigettextxalignment();
yalign=gigettextyalignment();
if (str!=NULL)
{
  /* Nastavitev poravnavanja teksta: */
  dy=height/yratio;  /* celotna visina teksta */
  dx=strlen(str)*height/xratio;  /* celotna sirina teksta */
  p.x=p1.x;
  p.y=p1.y;
  /* poravnavanje v vodoravni smeri: */
  if (xalign==0)
    p.x-=dx*0.5;
  else if (xalign==1)
    p.x-=dx;
  /* posavnavanje v navpicni smeri: */
  if (yalign==0)
    p.y-=dy*0.5;
  else if (yalign==1)
    p.y-=dy;
  /* definicija fonta (najprej se najde ime fonta, ki ustreza zap. st. fonta): */
  font=gigettextfont();
  if (psifontshortcuts)   /* porabi se okrajsava za font */
  {
    if (font<1 || font>psifontnames->n)
      font=1;
    fprintf(fp,"/%s%i %s ",psishortfontstr,font,findfontstr);
  } else  /* uporabi se polno ime fonta */
  {
    if (font<1) font=1;
    if (psifontnames!=NULL)
      if (font>0 && font<=psifontnames->n)
        fontname=psifontnames->s[font];
    if (fontname==NULL)
      fontname=psidefaultfontname;
    fprintf(fp,"/%s %s ",fontname,findfontstr);
  }
  fprintf(fp,"%.*g %s ",psiprecision,height,scalefontstr);
  fprintf(fp,"%s ",setfontstr);
  fprintf(fp,"%.*g %.*g %s ",psiprecision,p.x,psiprecision,p.y,movetostr);
  psifprinttextcolor(fp); fprintf(fp," ");
  fprintf(fp,"(%s) %s \n",str,showstr);
  /* Za kontrolo pozicije teksta: */
  /* psimarktextpos(str,x1,y1,1,1); */
}
}



static void giprinthead(void)
{
}

static void giprinttail(void)
{
}


static void psiprinthead(void)
    /* Izpise glavo datoteke v formatu PostScript. Datoteka, v katero se glava
    zapise, je dolocena z lokalno spremanljivko fp.
    $A Igor apr97; */
{
if (fp!=NULL)
{
  if (psifontnames==NULL) /* Ce ni instaliran noben font, se izvede stand. instalacija */
    psiinitfontnames1();
  /* izbira zapisa operatorjev (dolg ali kratek nacin): */
  if (shortoperators)
    psisetshortoperators();
  else
    psisetlongoperators();
  /* Izpis glave datoteke */
  if (psiepsformat)
  {
    fprintf(fp,"%c!PS-Adobe-3.0 EPSF-3.0 \n",'%');
    fprintf(fp,"%c%cBoundingBox: 0 0 500 500 \n",'%','%');
    fprintf(fp,"%c%cCreator: Igor G.'s graphic system \n",'%','%');
    /*
    fprintf(fp,"%c%cOrientation: Portrait \n",'%','%');
    */
    fprintf(fp,"%c%cEndComments \n",'%','%');
  } else
  {
    fprintf(fp,"%c!\n",'%');
  }
  fprintf(fp,"\n%c BEGINNING OF GRAPHIC PART \n\n",'%');
  if (shortoperators) /* definicije krajsih imen operatorjev: */
    psifwriteshortdef(fp);
  if (psifontshortcuts) /* definicije krajsih imen za fonte: */
    psifwritefonts(fp);
  /* izris ozadja: */
  /*
  if (psibackground)
    psifprintbackground(fp);
  */
}
}



static void psiprinttail(void)
    /* Zapise rep datoteke v formatu PostScript. Datoteka, v katero se rep
    zapise, je dolocena z lokalno spremanljivko fp.
    $A Igor apr97; */
{
if (fp!=NULL)
{
  /* Izpis repa datoteke: */
  fprintf(fp,"\n%c END OF GRAPHIC PART \n\n",'%');
  fprintf(fp,"showpage\n");
}
}






                     /**************************/
                     /*       FORMAT TCL       */
                     /**************************/







static char tclioldwish=0; /* Ce je 1, se naredi datoteka tcli za wish verzij
                          manj kot 8.0. */


/* Definicije za Tcl-ov shell: */
static char *tclishellstr="#!/usr/bin/wish -f";
static char *tcliwindowtitle="IGS - Tcl window";

static int tclwindowwidth=600; /* Sirina okna, kamor se bo izrisala datoteka */
static int tclwindowheight=600; /* Visina okna */

/*
static double tcltextscalingfactor=600;
*/


  /* SKALIRANJE KOORDINAT PRI ZAPISU V FORMATU Tcl: */


static int tcliprecision=6;
static char tcliscalecoordinates=1; /* Ce je 1, se koordinate skalirajo kot pri
              risanju grafov, drugace se zapisejo naravne koordinate. */


/* Okno, v katerega se izrise slika: */
static double tclistartx=0,   /* koordinata x leve strani okna */
              tclistarty=600,   /* koordinata y spodnje strani okna */
              tclisizex=600,  /* sirina okna */
              tclisizey=-600;  /* visina okna */




/* Nizi, ki predstavljajo lastnosti graficnih objektov v datoteki formata Tcl: */
static char *tclifillcolorstr="fillcolor";
static char *tclilinecolorstr="linecolor";
static char *tclilinewidthstr="linewidth";
static char *tclitextcolorstr="textcolor";
static char *tclitextfontstr="textfont";
static char *tclitextanchorstr="textanchor";

/* Imena procedur za izris graficnih objektov v datoteki formata Tcl: */
static char *tclilinestr="tcliline";
static char *tclitrianglestr="tclitriangle";
static char *tclifouranglestr="tclifourangle";
static char *tclifilltrianglestr="tclifilltriangle";
static char *tclifillfouranglestr="tclifillfourangle";
static char *tclitextstr="tclitext";

/*
static char *="";
static char *="";
static char *="";
static char *="";
static char *="";
static char *="";
static char *="";
static char *="";
*/

static char alloctclipsoutfile=0; /* Ce je 1, se tcliepsoutfile lahko brise s
                                 free(). */
static char *tcliepsoutfile="0.eps"; /* Ime datoteke v formatu eps, v katero naj
    Tcl-ov interpreter zapise sliko. Ce je NULL, se v datoteke v formatu tcli ne
    zapisejo navodila interpreterju, naj izpise sliko v formatu eps. */


/* Nastavitve za risanje: */
static _truecolor tclifillcolor={(float) 0.8,(float) 0.8,(float) 0};
static _truecolor tclilinecolor={(float) 0,(float) 0,(float) 1};
static int tclilinewidth=1;
static _truecolor tclitextcolor={(float) 1,(float) 0,(float) 0};

/* FONTI: */
static char *tclidefaultfontpre="times";
static char *tclidefaultfontpost="bold italic";
static stack tclifontpre=NULL,tclifontpost=NULL;


void tclisetepsoutfile(char *name)
    /* Nastavi ime datoteke, v katero bo lupina wish ob interpretaciji datotek
    generiranih s pomocjo tega modula zapisala slike v formatu eps, na name. Ce
    je name NULL, se v datoteke v formatu Tcl ne bo izpisalo navodilo za izpis
    v formatu eps. Ce je tclioldwish razlicno od 0, bi moral biti name pri klicu
    te funkcije enak NULL. name se skopira s stringcopy() v lokalno
    spremenljivko tcliepsoutfile.
    $A Igor <== apr97; */
{
if (alloctclipsoutfile)
  free(tcliepsoutfile);
tcliepsoutfile=stringcopy(name);
alloctclipsoutfile=1;
}

void tclisetoldwish(int oldwish)
    /* Ce je oldwish 0, se datoteke zapisujejo v formatu, ki ga zna prebrati
    wish verzije 8.0 ali poznejse.
    $A Igor <== apr97; */
{
if (oldwish)
  tclioldwish=1;
else
  tclioldwish=0;
}


static void tclideinstallfont(int num)
    /* Odinstalira font z zaporedno stevilko num
    $A Igor <== apr97; */
{
if (tclifontpre!=NULL)
  if (tclifontpre->n>=num)
    if (tclifontpre->s[num]!=NULL)
    {
      free(tclifontpre->s[num]);
      tclifontpre->s[num]=NULL;
    }
if (tclifontpost!=NULL)
  if (tclifontpost->n>=num)
    if (tclifontpost->s[num]!=NULL)
    {
      free(tclifontpost->s[num]);
      tclifontpost->s[num]=NULL;
    }
}



void tcliinstallfont(int num,char *font,char bold,char italic)
    /* Instalira font z zaporedno stevilko num v sistem fontov, ki se uporablja
    pri risanju v formatu tcli. font je ime (vrsta) fonta, bold in italic pa
    povesta, ali je font krebko tiskan oz. ali je nagnjen.
    $A Igor <== apr97; */
{
int i;
char *str1=NULL,*str2=NULL;
if (font==NULL)
  font="";
/* Ce prostor za sklada tclifontpre in tclifontpost ni alociran, se alocira: */
if (tclifontpre==NULL)
  tclifontpre=newstack(5);
if (tclifontpost==NULL)
  tclifontpost=newstack(5);
/* Stevilo elementov na skladu mora biti vsaj num. Ce je manjse, se do mesta
num (vkljucno) sklad napolni z nicelnimi kazalci: */
if (tclifontpre->n<num)
  for (i=tclifontpre->n+1;i<=num;++i)
    pushstack(tclifontpre,NULL);
if (tclifontpost->n<num)
  for (i=tclifontpost->n+1;i<=num;++i)
    pushstack(tclifontpost,NULL);
/* Ce je font z zaporedno stevilko num ze instaliran, se odinstalira: */
if (tclifontpre->s[num]!=NULL || tclifontpost->s[num]!=NULL)
 tclideinstallfont(num);
/* Instalacija fonta: na sklad tclifontpre se naloci niz, ki predstavlja font,
na tclifontpost pa niz, ki pove, ali naj bo font krebko tiskan ali naknjen
oziroma oboje ali nic od tega: */
tclifontpre->s[num]=stringcopy(font);
if (bold)
  str1="bold";
if (italic)
{
  if (str1!=NULL)
    str2=" italic";
  else str2="italic";
}
tclifontpost->s[num]=stringcat(str1,str2);
}



void tcliinstallfontstr(int num,char *pre,char *post)
    /* Instalira font z zaporedno stevilko num v sistem fontov, ki se uporablja
    pri risanju v formatu tcli. Od funkcije tcliinstallfont se razlikuje po tem,
    da se zadnji del imena fonta poda direktno in ne z dvema celima argumentoma,
    ki povesta, ali je font krepko tiskan oz. nagnjen. funkcija je bolj primerna
    za instaliranje fontov, ce uporabljamo stari wish; v tem primeru je treba
    postaviti lokalno spremenljivko tclioldwish na 1 s klicem tclisetoldwish(1).
    Pri instalaciji fonta mora biti potem pre 1. del imena (kot v X) do nicle,
    ki pomeni, da ima font prilagodljivo velikost, post pa 2. del od te nicle
    naprej. Pri nastavitvi imena fonta se najprej zapise 1. del fonta, nato
    velikost in nato 2. del brez vmesnih presledkov.
    $A Igor <== apr97; */
{
int i;
if (pre==NULL)
  pre="";
if (post==NULL)
  post="";
/* Ce prostor za sklada tclifontpre in tclifontpost ni alociran, se alocira: */
if (tclifontpre==NULL)
  tclifontpre=newstack(5);
if (tclifontpost==NULL)
  tclifontpost=newstack(5);
/* Stevilo elementov na skladu mora biti vsaj num. Ce je manjse, se do mesta
num (vkljucno) sklad napolni z nicelnimi kazalci: */
if (tclifontpre->n<num)
  for (i=tclifontpre->n+1;i<=num;++i)
    pushstack(tclifontpre,NULL);
if (tclifontpost->n<num)
  for (i=tclifontpost->n+1;i<=num;++i)
    pushstack(tclifontpost,NULL);
/* Ce je font z zaporedno stevilko num ze instaliran, se odinstalira: */
if (tclifontpre->s[num]!=NULL || tclifontpost->s[num]!=NULL)
 tclideinstallfont(num);
/* Instalacija fonta: */
tclifontpre->s[num]=stringcopy(pre);
tclifontpost->s[num]=stringcopy(post);
}


void tcliinstalldefaultfonts(void)
    /* $A Igor <== apr97; */
{
if (tclioldwish)
{
  tclidefaultfontpre="*times*";
  tclidefaultfontpost="";
  tcliinstallfontstr(1,"-adobe-courier-bold-r-normal--","-0-75-75-m-0-iso8859-1");
  tcliinstallfontstr(2,"-adobe-helvetica-bold-r-normal--","-0-75-75-p-0-iso8859-1");
  tcliinstallfontstr(3,"-adobe-new century schoolbook-bold-r-normal--","-0-75-75-p-0-iso8859-1");
  tcliinstallfontstr(4,"-adobe-times-bold-r-normal--","-0-75-75-p-0-iso8859-1");
  tcliinstallfontstr(5,"-b&h-lucidabright-demibold-r-normal--","-0-75-75-p-0-iso8859-1");
  tcliinstallfontstr(6,"-bitstream-charter-bold-r-normal--","-0-75-75-p-0-iso8859-1");
  tcliinstallfontstr(7,"-dec-terminal-bold-r-normal--","-0-75-75-c-0-iso8859-1");
  tcliinstallfontstr(8,"-hp-hp system-bold-r-normal--","-0-85-85-p-0-iso8859-9");
  tcliinstallfontstr(9,"-hp-hp user-medium-r-normal--","-0-85-85-m-0-iso8859-9");
  tcliinstallfontstr(10,"-sony-fixed-medium-r-normal--","-0-100-100-c-0-jisx0201.1976-0");
} else
{
  tclidefaultfontpre="times";
  tclidefaultfontpost="bold italic";
  tcliinstallfont(1,"times",1,0);
  tcliinstallfont(2,"courier",1,0);
  tcliinstallfont(3,"helvetica",1,0);
  tcliinstallfont(4,"new century schoolbook",1,0);
  tcliinstallfont(5,"lucida",1,0);
  tcliinstallfont(6,"lucidabright",1,0);
  tcliinstallfont(7,"ucidatypewriter",1,0);
  tcliinstallfont(8,"",1,0);
  tcliinstallfont(9,"",1,0);
  tcliinstallfont(10,"symbol",1,0);
}
}




static void tclinaturalwindowcoord(float x,float y,coord3d p)
    /* Pri transformaciji koordinat objektov v njihove okenske koordinate
    se pusti kar naravne koordinate.
    $A Igor apr97; */
{
p->x=x; p->y; p->z=0;
}


static void tcligpwindowcoord(float x,float y,coord3d p)
    /* Normalni okenski koordinati (ki gresta v obeh smereh od 0 do 1 s
    koordinatnim izhodiscem v spodnjem levem kotu) se pretvorita v okenski
    koordinati za format Tcl.
    $A Igor apr97; */
{
p->x=tclistartx+x*tclisizex;
p->y=tclistarty+y*tclisizey;
p->z=0;
}



static void (*tcliwindowcoord) (float,float,coord3d) = tcligpwindowcoord;



void tclisetscaling(char scaling)
    /* Doloci skaliranje koordinat pri zapisu graficnih objektov v formatu Tcl.
    ce je scaling==0, postane funkcija tcliwindowcoord() za skaliranje koordinat
    kar funkcija tclinaturalwindowcoord(), ki ohranja naravne koordinate objektov,
    drugace pa to postane funkcija tcligpwindowcoord(), ki skalira koordinati x
    in y tako, kot se to naredi pri risanju na zaslon, koordinato z pa poskusa
    skalirati na podoben nacin.
    $A Igor <== apr97; */
{
tcliscalecoordinates=scaling;
if (tcliscalecoordinates==0)
  tcliwindowcoord=tclinaturalwindowcoord;
else tcliwindowcoord=tcligpwindowcoord;
}




void tclsetwindowsize(int width,int height)
    /* Postavi sirino tcl-ovega okna, v katerem se izrise graf iz tcl-ove
    datoteke, na width, in visino na height. Ce je eden ali drugi 0, se
    ohranita dimenziji, ki sta trenutno nastavljeni.
    $A Igor maj01; */
{
if (width>0)
{
  tclwindowwidth=width;
  tclisizex=tclwindowwidth;
}
if (height>0)
{
  tclwindowheight=height;
  tclistarty=tclwindowheight;
  tclisizey=-tclwindowheight;
}
}


static void tclisetwindowsize(double width,double height)
    /* Postavi sirino tcl-ovega okna, v katerem se izrise graf iz tcl-ove
    datoteke, na width, in visino na height. Ce je eden ali drugi 0, se
    ohranita dimenziji, ki sta trenutno nastavljeni.
    $A Igor maj01; */
{
if (width>0)
{
  tclwindowwidth=(int) width;
  tclisizex=tclwindowwidth;
}
if (height>0)
{
  tclwindowheight=(int) height;
  tclistarty=tclwindowheight;
  tclisizey=-tclwindowheight;
}
}


static double tcligetwindowwidth(void)
    /* Vrne sirino trenutnega Tcl-ovega okna oz. skalirni faktor v smeri x.
    $A Igor maj01; */
{
return fabs(tclisizex);
}

static double tcligetwindowheight(void)
    /* Vrne visino trenutnega Tcl-ovega okna oz. skalirni faktor v smeri y.
    $A Igor maj01; */
{
return fabs(tclisizey);
}



/* FUNKCIJE ZA ZAPIS BARV v formatu Tcl: */

static void fwritehexdigit(FILE *fp,int digit)
    /* V datoteko fp zapise heksadecimalno stevilko digit. digit mora biti
    celo stevilo od 0 do 15.
    $A Igor <== apr97; */
{
if (digit<0) digit=0;
if (digit>15) digit=15;
if (digit<10)
  fprintf(fp,"%c",digit+'0');
else
  fprintf(fp,"%c",digit-10+'A');
}

static void fwritehex2dig(FILE *fp,int num)
    /* V datoteko fp zapise celo stevilo num v sestnajstiski obliki. Num mora
    biti nenegativno celo stevilo manjse od 256.
    $A Igor <== apr97; */
{
div_t res;
if (num<0) num=0;
if (num>255) num=255;
res=div(num,16);
fwritehexdigit(fp,res.quot);
fwritehexdigit(fp,res.rem);
}

static void fwritehexcolor(FILE *fp,float red,float green,float blue)
    /* V datoteko fp zapise barvo s komponentami red, green in blue v formatu,
    ki je razpoznaven za X windowse ( #rrggbb , kjer za vsako komponento
    stojita dve heksadecimalni stevilki).
    $A Igor <== apr97; */
{
fprintf(fp,"#");
fwritehex2dig(fp,(int) (red*255));
fwritehex2dig(fp,(int) (green*255));
fwritehex2dig(fp,(int) (blue*255));
}







  /* OSNOVNE FUNKCIJE ZA ZAPIS V FORMATU Tcl: */



static void tcliline(float x1,float y1,float x2,float y2)
    /* $A Igor <== apr97; */
{
float red,green,blue;
tcliwindowcoord(x1,y1,&p1);
tcliwindowcoord(x2,y2,&p2);
/* Nastavitev barve: */
gigetlinecolor(&red,&green,&blue);
fprintf(fp,"set %s ",tclilinecolorstr);
fwritehexcolor(fp,red,green,blue);
fprintf(fp,"\n");
/* Nastavitev debeline: */
fprintf(fp,"set %s %i\n",tclilinewidthstr,(int) gigetlinewidth());
fprintf(fp,"%s %i %i %i %i\n",tclilinestr,
        (int) p1.x,(int) p1.y,(int) p2.x,(int) p2.y);
}


static void tclitriangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* $A Igor <== apr97; */
{
float red,green,blue;
tcliwindowcoord(x1,y1,&p1);
tcliwindowcoord(x2,y2,&p2);
tcliwindowcoord(x3,y3,&p3);
/* Nastavitev barve: */
gigetlinecolor(&red,&green,&blue);
fprintf(fp,"set %s ",tclilinecolorstr);
fwritehexcolor(fp,red,green,blue);
fprintf(fp,"\n");
/* Nastavitev debeline: */
fprintf(fp,"set %s %i\n",tclilinewidthstr,(int) gigetlinewidth());
fprintf(fp,"%s %i %i %i %i %i %i\n",tclitrianglestr,
    (int) p1.x,(int) p1.y,(int) p2.x,(int) p2.y,(int) p3.x,(int) p3.y);
}


static void tclifourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* $A Igor <== apr97; */
{
float red,green,blue;
tcliwindowcoord(x1,y1,&p1);
tcliwindowcoord(x2,y2,&p2);
tcliwindowcoord(x3,y3,&p3);
tcliwindowcoord(x4,y4,&p4);
/* Nastavitev barve: */
gigetlinecolor(&red,&green,&blue);
fprintf(fp,"set %s ",tclilinecolorstr);
fwritehexcolor(fp,red,green,blue);
fprintf(fp,"\n");
/* Nastavitev debeline: */
fprintf(fp,"set %s %i\n",tclilinewidthstr,(int) gigetlinewidth());
fprintf(fp,"%s %i %i %i %i %i %i %i %i\n",tclifouranglestr,(int) p1.x,(int) p1.y,
    (int) p2.x,(int) p2.y,(int) p3.x,(int) p3.y,(int) p4.x,(int) p4.y);
}


static void tclifilltriangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* $A Igor <== apr97; */
{
float red,green,blue;
tcliwindowcoord(x1,y1,&p1);
tcliwindowcoord(x2,y2,&p2);
tcliwindowcoord(x3,y3,&p3);
/* Nastavitev barve: */
gigetfillcolor(&red,&green,&blue);
fprintf(fp,"set %s ",tclifillcolorstr);
fwritehexcolor(fp,red,green,blue);
fprintf(fp,"\n");
/* Izris: */
fprintf(fp,"%s %i %i %i %i %i %i\n",tclifilltrianglestr,
    (int) p1.x,(int) p1.y,(int) p2.x,(int) p2.y,(int) p3.x,(int) p3.y);
}


static void tclifillfourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* $A Igor <== apr97; */
{
float red,green,blue;
tcliwindowcoord(x1,y1,&p1);
tcliwindowcoord(x2,y2,&p2);
tcliwindowcoord(x3,y3,&p3);
tcliwindowcoord(x4,y4,&p4);
/* Nastavitev barve: */
gigetfillcolor(&red,&green,&blue);
fprintf(fp,"set %s ",tclifillcolorstr);
fwritehexcolor(fp,red,green,blue);
fprintf(fp,"\n");
/* Izris: */
fprintf(fp,"%s %i %i %i %i %i %i %i %i\n",tclifillfouranglestr,(int) p1.x,(int) p1.y,
    (int) p2.x,(int) p2.y,(int) p3.x,(int) p3.y,(int) p4.x,(int) p4.y);
}








static void tclimarktextpos(char *str,float x,float y,char mark,char box)
    /* Oznaci pozicijo teksta, ki naj bi se izpisal s funkcijo tclitext. str je
    niz, ki naj bi se izpisal, x in y pa sta koordinati, pri katerih naj bi
    se niz izpisal. Ce je mark razlicen od 0, se izrise puscica na poziciji
    (x1,y1), ce pa je box 1, se izrise okvir okrog mej, s katerimi naj bi bil
    tekst omejen.
    $A Igor apr97; */
{
float marklength=(float) 0.03;
float xratio=/* 1.9332 */ (float) 1.5;
float yratio=(float) 1.514;
float x1,y1,x2,y2,height,dx,dy,xalign=0,yalign=0,red,green,blue;

if (mark || box)
{
  gisetlinewidth(1);
  gisetlinetype(2);
  gigettextcolor(&red,&green,&blue);
  gisetlinecolor(1-red,1-green,1-blue);
  if (mark)
  {
    x1=x-marklength;
    y1=y+(float) 0.3*marklength;
    x2=x1;
    y2=y-(float) 0.3*marklength;
    tcliline(x,y,x1,y1); 
    tcliline(x,y,x2,y2);
  }
  if (box)
  {  
    gisetlinecolor(red,green,blue);
    height=gigettextheight();
    xalign=(float) gigettextxalignment();
    yalign=(float) gigettextyalignment();
    /* Nastavitev poravnavanja teksta: */
    dy=height;    /* celotna visina teksta */
    dx=strlen(str)*height/xratio;    /* celotna sirina teksta */
    x1=x; y1=y;   /* (x,y) je spodnja leva tocka boksa. */
    /* poravnavanje v vodoravni smeri: */
    if (xalign==0)
      x1-=dx*(float) 0.5;
    else if (xalign==1)
      x1-=dx;
    if (yalign==0)
      y1-=dy*(float) 0.5;
    else if (yalign==1)
      y1-=dy;
    x2=x1+dx;
    y2=y1+dy;
    tclifourangle(x1,y1,x2,y1,x2,y2,x1,y2);
  }
}
}





static void tclitext(char *str,float x1,float y1)
    /* $A Igor <== apr97; */
{
float tclitextscalingfactor=(float) fabs(tclisizey);
char *anchorstr=NULL,*fontprestr=NULL,*fontpoststr=NULL;
float red,green,blue;
double height=0.1;
int xalign=1,yalign=1,gixalign,giyalign,font;
_coord3d p;
double xratio=1.9332;
double yratio=1.514;
double dx,dy;
tcliwindowcoord(x1,y1,&p1);
height=gigettextheight()*tclitextscalingfactor;
gixalign=gigettextxalignment();
giyalign=gigettextyalignment();
font=gigettextfont();
/*
if (gixalign==-1)
  xalign=0;
else if (gixalign==0)
  xalign=1;
else if (gixalign==1)
  xalign=2;
else
  xalign=1;
if (giyalign==-1)
  yalign=1;
else if (giyalign==0)
  yalign=2;
else if (giyalign==1)
  yalign=3;
else
  yalign=2;
*/
/* Nastavitve za poravnavanje: */
p=p1;
dy=height/yratio;  /* celotna visina teksta */
dx=strlen(str)*height/xratio;  /* celotna sirina teksta */
/* poravnavanje v vodoravni smeri: */
/*
if (gixalign==0)
  p.x-=dx*0.5;
else if (gixalign==1)
  p.x-=dx;
*/
/* poravnavanje v navpicni smeri: */
/*
if (giyalign==0)
  p.y-=dy*0.5;
else if (giyalign==1)
  p.y-=dy;
*/

if (str!=NULL)
{
  gixalign=gigettextxalignment();
  giyalign=gigettextyalignment();
  /* Nastavitev poravnavanja: */
  if (gixalign==-1)
  {
    if (giyalign==-1)
      anchorstr="sw";
    else if (giyalign==0)
      anchorstr="w";
    else if (giyalign==1)
      anchorstr="nw";
  } else if (gixalign==0)
  {
    if (giyalign==-1)
      anchorstr="s";
    else if (giyalign==0)
      anchorstr="center";
    else if (giyalign==1)
      anchorstr="n";
  } else
  {
    if (giyalign==-1)
      anchorstr="se";
    else if (giyalign==0)
      anchorstr="e";
    else if (giyalign==1)
      anchorstr="ne";
  }
  fprintf(fp,"set %s %s\n",tclitextanchorstr,anchorstr);
  /* Nastavitev fonta in velikosti: */
  font=gigettextfont();
  height=gigettextheight()*tclitextscalingfactor;
  if (font>0)
    if (tclifontpre!=NULL && tclifontpost!=NULL)
    {
      if (font>tclifontpre->n ||font>tclifontpost->n )
        font=0;
      if (font>0)
      {
        fontprestr=tclifontpre->s[font];
        fontpoststr=tclifontpost->s[font];
      }
    }
  if (fontprestr==NULL)
    fontprestr=tclidefaultfontpre;
  if (fontpoststr==NULL)
    fontpoststr=tclidefaultfontpost;
  /*
  fprintf(fp,"set %s {{%s} %i {%s}}\n",tclitextfontstr,fontprestr,(int) height,fontpoststr);
  */
  if (tclioldwish)
  {
    if (fontprestr==tclidefaultfontpre&&fontpoststr==tclidefaultfontpost)
      /* Ce moramo uporabiti default font, se ne izpise visina fonta. */
      fprintf(fp,"set %s {%s%s}\n",
       tclitextfontstr,fontprestr,fontpoststr);
    else
      fprintf(fp,"set %s {%s%i%s}\n",
       tclitextfontstr,fontprestr,(int) height,fontpoststr);
  }
  else
    fprintf(fp,"set %s {{%s} %i {%s}}\n",
     tclitextfontstr,fontprestr,(int) height,fontpoststr);
  /* Nastavitev barve: */
  gigettextcolor(&red,&green,&blue);
  fprintf(fp,"set %s ",tclitextcolorstr);
  fwritehexcolor(fp,red,green,blue);
  fprintf(fp,"\n");
  /* Izris: */
  fprintf(fp,"%s %i %i {%s}\n",tclitextstr,(int) p1.x,(int) p1.y, str);
  
  tclimarktextpos(str,x1,y1,0,0);
}

}





static void tcliprinthead(void)
    /* V datoteko formata tcli izpise glavo, ki omogoca risanje. V glavi so
    definicija lupine, ki jo uporabimo za prikaz oken, nastavitve za risanje in
    definicije procedur za risanje osnovnih graficnih objektov.
    $A Igor apr97; */
{
if (fp!=NULL)
{
  /* Klic lipine wish: */
  fprintf(fp,"%s\n",tclishellstr);

  fprintf(fp,"bind . <Button-3> {quit 1}\n");     /* S 3. gumbom unicimo okno */
  fprintf(fp,"wm title . {%s}\n",tcliwindowtitle); /* Naslov glavnega okna */ 
  fprintf(fp,"set epsfilename %s\n",tcliepsoutfile);
  /* Definicija platna: */
  fprintf(fp,"canvas .c -width %i -height %i -bd 0\n",tclwindowwidth,tclwindowheight);
  fprintf(fp,"pack .c -side top -fill both -expand 1\n");
  fprintf(fp,".c config -bg #EEEEEE\n");
  /* Spodnje okno za sporocilo, gumba in vstavljanje: */
  fprintf(fp,"frame .fmes -bd 3 -relief sunken\n");
  fprintf(fp,"pack .fmes -side top -fill both\n");
  /* Sporocilo: */
  fprintf(fp,"message .fmes.m -text {Press <Quit> to destroy window or <Print> to write\\\n");
  fprintf(fp,"the canvas to a file in eps format. Pressing the third mouse button in\\\n");
  fprintf(fp,"the window also quits.} -width 550 -anchor center -bd 6\n");
  fprintf(fp,"pack .fmes.m -side top -fill both\n");
  /* Okvir za gumbe: */
  fprintf(fp,"frame .fmes.bot -bd 5\n");
  fprintf(fp,"pack .fmes.bot -side top -fill both\n");
  fprintf(fp,"button .fmes.bot.print -text Print -command {printeps $epsfilename}\n");
  fprintf(fp,"button .fmes.bot.quit -text Quit -command {quit 0}\n");
  fprintf(fp,"label .fmes.bot.lab -text {Name of the eps file:}\n");
  fprintf(fp,"entry .fmes.bot.eps -textvariable epsfilename\n");
  fprintf(fp,"pack .fmes.bot.quit  -side left -expand 1\n");
  fprintf(fp,"pack .fmes.bot.print -side left -expand 1\n");
  fprintf(fp,"pack  .fmes.bot.eps .fmes.bot.lab -side right -expand 1\n");
  fprintf(fp,"bind .fmes.bot.eps <FocusIn> {%cW select from 0 ; %cW select to end}\n",'%','%');
  fprintf(fp,"proc printeps x {\n");
  fprintf(fp,"global .c\n");
  fprintf(fp,".c postscript -file $x\n");
  fprintf(fp,"}\n");
  fprintf(fp,"proc quit x {\n");
  fprintf(fp,"global .\n");
  fprintf(fp,"destroy .\n");
  fprintf(fp,"}\n");
  fprintf(fp,"\n");
  
  if (0)
  {
  /* Naslov okna: */
  fprintf(fp,"wm title . {%s}\n",tcliwindowtitle);
  /* Sirina in visina okna: */
  fprintf(fp,"wm geometry . %ix%i\n",tclisizex,tclisizey);
  /* Definicija platna: */
  fprintf(fp,"canvas .c\n");
  /* Omogoci se spreminjanje velikosti platna: */
  fprintf(fp,"pack .c -side top -fill both -expand 1\n");
  }

  
  /* Nastavitve za risanje: */
  fprintf(fp,"set %s ",tclifillcolorstr);
   fwritehexcolor(fp,tclifillcolor.red,tclifillcolor.green,tclifillcolor.blue);
   fprintf(fp,"\n");
  
  fprintf(fp,"set %s ",tclilinecolorstr);
   fwritehexcolor(fp,tclilinecolor.red,tclilinecolor.green,tclilinecolor.blue);
   fprintf(fp,"\n");

  fprintf(fp,"set %s %i\n",tclilinewidthstr,tclilinewidth);
  
  fprintf(fp,"set %s ",tclitextcolorstr);
   fwritehexcolor(fp,tclitextcolor.red,tclitextcolor.green,tclitextcolor.blue);
   fprintf(fp,"\n");
  
  fprintf(fp,"set %s {times 10}\n",tclitextfontstr);
  
  fprintf(fp,"set %s center\n",tclitextanchorstr);
  
  /* Definicije procedur za risanje osnovnih objektov: */
  /* Procedura za risanje crt: */
  fprintf(fp,"\n");
  fprintf(fp,"proc %s {x1 y1 x2 y2} {\n",tclilinestr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclilinecolorstr);
  fprintf(fp," global %s\n",tclilinewidthstr);
  fprintf(fp," .c create line $x1 $y1 $x2 $y2 -fill $%s -width $%s\n",tclilinecolorstr,tclilinewidthstr);
  fprintf(fp,"}\n\n");
  /* Procedura za risanje trikotnikov iz crt: */
  fprintf(fp,"proc %s {x1 y1 x2 y2 x3 y3} {\n",tclitrianglestr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclilinecolorstr);
  fprintf(fp," global %s\n",tclilinewidthstr);
  fprintf(fp," .c create line $x1 $y1 $x2 $y2 $x3 $y3 $x1 $y1 -fill $%s -width $%s\n",tclilinecolorstr,tclilinewidthstr);
  fprintf(fp,"}\n\n");
  /* Procedura za risanje stirikotnikov iz crt: */
  fprintf(fp,"proc %s {x1 y1 x2 y2 x3 y3 x4 y4} {\n",tclifouranglestr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclilinecolorstr);
  fprintf(fp," global %s\n",tclilinewidthstr);
  fprintf(fp," .c create line $x1 $y1 $x2 $y2 $x3 $y3 $x4 $y4 $x1 $y1 -fill $%s -width $%s\n",tclilinecolorstr,tclilinewidthstr);
  fprintf(fp,"}\n\n");
  /* Procedura za risanje polnih trikotnikov: */
  fprintf(fp,"proc %s {x1 y1 x2 y2 x3 y3} {\n",tclifilltrianglestr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclifillcolorstr);
  fprintf(fp," .c create polygon $x1 $y1 $x2 $y2 $x3 $y3 -fill $%s\n",tclifillcolorstr);
  fprintf(fp,"}\n\n");
  /* Procedura za risanje polnih stirikotnikov: */
  fprintf(fp,"proc %s {x1 y1 x2 y2 x3 y3 x4 y4} {\n",tclifillfouranglestr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclifillcolorstr);
  fprintf(fp," .c create polygon $x1 $y1 $x2 $y2 $x3 $y3 $x4 $y4 -fill $%s\n",tclifillcolorstr);
  fprintf(fp,"}\n\n");
  /* Procedura za risanje teksta: */
  fprintf(fp,"proc %s {x1 y1 str} {\n",tclitextstr);
  fprintf(fp," global .c\n");
  fprintf(fp," global %s\n",tclitextcolorstr);
  fprintf(fp," global %s\n",tclitextfontstr);
  fprintf(fp," global %s\n",tclitextanchorstr);
  fprintf(fp," .c create text $x1 $y1 -text $str -fill $%s -font $%s -anchor $%s\n",
   tclitextcolorstr,tclitextfontstr,tclitextanchorstr);
  fprintf(fp,"}\n\n");

  /* Ce ni instaliran nobena pisava, se instalirajo preddefinirane pisave: */
  if (tclifontpre==NULL || tclifontpost==NULL)
  {
    tcliinstalldefaultfonts();
  }
  fprintf(fp,"\n# ZACETEK RISBE:\n\n");
}
}



static void tcliprinttail(void)
    /* $A Igor apr97; */
{
if (fp!=NULL)
{
  fprintf(fp,"\n# KONEC RISBE.\n\n");
  /* Ukaz za izpis v formatu eps: */
  if (tcliepsoutfile!=NULL)
    fprintf(fp,"update\n");
}
}










                     /**************************/
                     /*       FORMAT DXF       */
                     /**************************/




  /* SKALIRANJE KOORDINAT PRI ZAPISU V FORMATU DXF: */

static int dxfiprecision=6;
static float dxfiwidthfactor=(float) 0.02;
static char dxfiscalecoordinates=1; /* Ce je 1, se koordinate skalirajo kot pri
              risanju grafov, drugace se zapisejo naravne koordinate. */



/* Okno, v katerega se izrise slika: */
static double dxfistartx=0,   /* koordinata x leve strani okna */
              dxfistarty=0,   /* koordinata y spodnje strani okna */
              dxfisizex=10,   /* sirina okna */
              dxfisizey=10;   /* visina okna */


static void dxfinaturalwindowcoord(float x,float y,coord3d p)
    /* Pri transformaciji koordinat objektov v njihove okenske koordinate
    se pusti kar naravne koordinate.
    $A Igor apr97; */
{
p->x=x; p->y; p->z=0;
}


static void dxfigpwindowcoord(float x,float y,coord3d p)
    /* Normalni okenski koordinati (ki gresta v obeh smereh od 0 do 1 s
    koordinatnim izhodiscem v spodnjem levem kotu) se pretvorita v okenski
    koordinati za format DXF.
    $A Igor apr97; */
{
p->x=dxfistartx+x*dxfisizex;
p->y=dxfistarty+y*dxfisizey;
p->z=0;
}




static void (*dxfiwindowcoord) (float,float,coord3d) = dxfigpwindowcoord;



void dxfisetscaling(char scaling)
    /* Doloci skaliranje koordinat pri zapisu graficnih objektov v formatu DXF.
    ce je scaling==0, postane funkcija dxfiwindowcoord() za skaliranje koordinat
    kar funkcija dxfinaturalwindowcoord(), ki ohranja naravne koordinate objektov,
    drugace pa to postane funkcija dxfigpwindowcoord(), ki skalira koordinati x
    in y tako, kot se to naredi pri risanju na zaslon, koordinato z pa poskusa
    skalirati na podoben nacin.
    $A Igor <== apr97; */
{
dxfiscalecoordinates=scaling;
if (dxfiscalecoordinates==0)
  dxfiwindowcoord=dxfinaturalwindowcoord;
else dxfiwindowcoord=dxfigpwindowcoord;
}


static void dxfisetwindowsize(double width,double height)
    /* Postavi sirino dxf-ovega okna, v katerem se izrise graf iz tcl-ove
    datoteke, na width, in visino na height. Ce je eden ali drugi 0, se
    ohrani ustrezna dimenzija, ki je trenutno nastavljena.
    $A Igor maj01; */
{
if (width>0)
{
  dxfisizex=height;
}
if (height>0)
{
  dxfisizey=height;
}
}


static double dxfigetwindowwidth(void)
    /* Vrne sirino trenutnega Tcl-ovega okna v pixlih.
    $A Igor maj01; */
{
return fabs(dxfisizex);
}

static double dxfigetwindowheight(void)
    /* Vrne visino trenutnega Tcl-ovega okna v pixlih.
    $A Igor maj01; */
{
return fabs(dxfisizey);
}



  /* OSNOVNE FUNKCIJE ZA ZAPIS V FORMATU DXF: */


static void dxfiline(float x1,float y1,float x2,float y2)
    /* V datoteko fp narise crto med tockama s koordinatama p1 in p2 v formatu
    DXF.
    $A Igor <== apr97; Damjan mar97; */
{
dxfiwindowcoord(x1,y1,&p1);
dxfiwindowcoord(x2,y2,&p2);
if (1)
{
  fprintf(fp," 0\nPOLYLINE\n 8\n0\n");
  /* Barva: */
  fprintf(fp," 62\n162\n");
  fprintf(fp," 66\n    1\n");
  fprintf(fp," 10\n0.0\n 20\n0.0\n 30\n0.0\n");
  /* Debelina: */
  fprintf(fp," 40\n%.*g\n",dxfiprecision,gigetlinewidth()*dxfiwidthfactor);
  fprintf(fp," 41\n%.*g\n",dxfiprecision,gigetlinewidth()*dxfiwidthfactor);
  fprintf(fp," 0\nVERTEX\n");
  fprintf(fp," 8\n0\n");
  /* Koordinate 1. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p1.x,dxfiprecision,p1.y,dxfiprecision,p1.z);
  fprintf(fp," 0\nVERTEX\n");
  fprintf(fp," 8\n0\n");
  /* Koordinate 2. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p2.x,dxfiprecision,p2.y,dxfiprecision,p2.z);
  fprintf(fp," 0\nSEQEND\n");
}
else
{
  fprintf(fp," 0\nLINE\n 8\n0\n");
  /* Barva: */
  fprintf(fp," 62\n162\n");
  /* Koordinate 1. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p1.x,dxfiprecision,p1.y,dxfiprecision,p1.z);
  /* Koordinate 2. tocke: */
  fprintf(fp," 11\n%.*g\n 21\n%.*g\n 31\n%.*g\n",
  dxfiprecision,p2.x,dxfiprecision,p2.y,dxfiprecision,p2.z);
}
}



static void dxfitriangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* V datoteko fp narise trikotnik med tockami s koordinatami p1, p2 in p3
    v formatu DXF.
    $A Igor <== apr97; Damjan mar97; */
{
dxfiwindowcoord(x1,y1,&p1);
dxfiwindowcoord(x2,y2,&p2);
dxfiwindowcoord(x3,y3,&p3);
if (1)
{
  fprintf(fp," 0\nPOLYLINE\n 8\n0\n");
  /* Barva: */
  fprintf(fp," 62\n162\n");
  fprintf(fp," 66\n    1\n");
  fprintf(fp," 10\n0.0\n 20\n0.0\n 30\n0.0\n");
  /* Zakljucenost */
  fprintf(fp," 70\n    1\n");
  /* Debelina: */
  fprintf(fp," 40\n%.*g\n",dxfiprecision,gigetlinewidth()*dxfiwidthfactor);
  fprintf(fp," 41\n%.*g\n",dxfiprecision,gigetlinewidth()*dxfiwidthfactor);
  fprintf(fp," 0\nVERTEX\n");
  fprintf(fp," 8\n0\n");
  /* Koordinate 1. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p1.x,dxfiprecision,p1.y,dxfiprecision,p1.z);
  fprintf(fp," 0\nVERTEX\n");
  fprintf(fp," 8\n0\n");
  /* Koordinate 2. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p2.x,dxfiprecision,p2.y,dxfiprecision,p2.z);
  fprintf(fp," 0\nVERTEX\n");
  fprintf(fp," 8\n0\n");
  /* Koordinate 3. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p3.x,dxfiprecision,p3.y,dxfiprecision,p3.z);
  fprintf(fp," 0\nSEQEND\n");
}
else
{
  fprintf(fp," 0\n3DFACE\n 8\n0\n");
  /* Barva: */
  fprintf(fp," 62\n162\n");
  /* Koordinate 1. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p1.x,dxfiprecision,p1.y,dxfiprecision,p1.z);
  /* Koordinate 2. tocke: */
  fprintf(fp," 11\n%.*g\n 21\n%.*g\n 31\n%.*g\n",
  dxfiprecision,p2.x,dxfiprecision,p2.y,dxfiprecision,p2.z);
  /* Koordinate 3. tocke: */
  fprintf(fp," 12\n%.*g\n 22\n%.*g\n 32\n%.*g\n",
  dxfiprecision,p3.x,dxfiprecision,p3.y,dxfiprecision,p3.z);
  /* Koordinate 3. tocke: */
  fprintf(fp," 13\n%.*g\n 23\n%.*g\n 33\n%.*g\n",
  dxfiprecision,p3.x,dxfiprecision,p3.y,dxfiprecision,p3.z);
  /*
  dxfiline(fp,p1,p2);
  dxfiline(fp,p2,p3);
  dxfiline(fp,p3,p1);
  */
}
}



static void dxfifourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* V datoteko fp narise stirikotnik med tockami s koordinatami p1, p2, p3
    in p4 v formatu DXF.
    $A Igor <== apr97; Damjan mar97; */
{
dxfiwindowcoord(x1,y1,&p1);
dxfiwindowcoord(x2,y2,&p2);
dxfiwindowcoord(x3,y3,&p3);
dxfiwindowcoord(x4,y4,&p4);
if (1)
{
  fprintf(fp," 0\nPOLYLINE\n 8\n0\n");
  /* Barva: */
  fprintf(fp," 62\n162\n");
  fprintf(fp," 66\n    1\n");
  fprintf(fp," 10\n0.0\n 20\n0.0\n 30\n0.0\n");
  /* Zakljucenost */
  fprintf(fp," 70\n    1\n");
  /* Debelina: */
  fprintf(fp," 40\n%.*g\n",dxfiprecision,gigetlinewidth()*dxfiwidthfactor);
  fprintf(fp," 41\n%.*g\n",dxfiprecision,gigetlinewidth()*dxfiwidthfactor);
  fprintf(fp," 0\nVERTEX\n");
  fprintf(fp," 8\n0\n");
  /* Koordinate 1. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p1.x,dxfiprecision,p1.y,dxfiprecision,p1.z);
  fprintf(fp," 0\nVERTEX\n");
  fprintf(fp," 8\n0\n");
  /* Koordinate 2. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p2.x,dxfiprecision,p2.y,dxfiprecision,p2.z);
  fprintf(fp," 0\nVERTEX\n");
  fprintf(fp," 8\n0\n");
  /* Koordinate 3. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p3.x,dxfiprecision,p3.y,dxfiprecision,p3.z);
  fprintf(fp," 0\nVERTEX\n");
  fprintf(fp," 8\n0\n");
  /* Koordinate 4. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p4.x,dxfiprecision,p4.y,dxfiprecision,p4.z);
  fprintf(fp," 0\nSEQEND\n");
}
else
{
  fprintf(fp," 0\n3DFACE\n 8\n0\n");
  /* Barva: */
  fprintf(fp," 62\n162\n");
  /* Koordinate 1. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
  dxfiprecision,p1.x,dxfiprecision,p1.y,dxfiprecision,p1.z);
  /* Koordinate 2. tocke: */
  fprintf(fp," 11\n%.*g\n 21\n%.*g\n 31\n%.*g\n",
  dxfiprecision,p2.x,dxfiprecision,p2.y,dxfiprecision,p2.z);
  /* Koordinate 3. tocke: */
  fprintf(fp," 12\n%.*g\n 22\n%.*g\n 32\n%.*g\n",
  dxfiprecision,p3.x,dxfiprecision,p3.y,dxfiprecision,p3.z);
  /* Koordinate 4. tocke: */
  fprintf(fp," 13\n%.*g\n 23\n%.*g\n 33\n%.*g\n",
  dxfiprecision,p4.x,dxfiprecision,p4.y,dxfiprecision,p4.z);
  /*
  dxfiline(fp,p1,p2);
  dxfiline(fp,p2,p3);
  dxfiline(fp,p3,p4);
  dxfiline(fp,p4,p1);
  */
}
}


static void dxfifilltriangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* $A Igor <== apr97; */
{
dxfiwindowcoord(x1,y1,&p1);
dxfiwindowcoord(x2,y2,&p2);
dxfiwindowcoord(x3,y3,&p3);
fprintf(fp," 0\nSOLID\n 8\n0\n");
/* Barva: */
fprintf(fp," 62\n130\n");
/*
fprintf(fp," 5\nB\n");
*/
/* Koordinate 1. tocke: */
fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
 dxfiprecision,p1.x,dxfiprecision,p1.y,dxfiprecision,p1.z);
/* Koordinate 2. tocke: */
fprintf(fp," 11\n%.*g\n 21\n%.*g\n 31\n%.*g\n",
 dxfiprecision,p2.x,dxfiprecision,p2.y,dxfiprecision,p2.z);
/* Koordinate 3. tocke: */
fprintf(fp," 12\n%.*g\n 22\n%.*g\n 32\n%.*g\n",
 dxfiprecision,p3.x,dxfiprecision,p3.y,dxfiprecision,p3.z);
/* Koordinate 3. tocke: */
fprintf(fp," 13\n%.*g\n 23\n%.*g\n 33\n%.*g\n",
 dxfiprecision,p3.x,dxfiprecision,p3.y,dxfiprecision,p3.z);
}


static void dxfifillfourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* $A Igor <== apr97; */
{
dxfiwindowcoord(x1,y1,&p1);
dxfiwindowcoord(x2,y2,&p2);
dxfiwindowcoord(x3,y3,&p3);
dxfiwindowcoord(x4,y4,&p4);
fprintf(fp," 0\nSOLID\n 8\n0\n");
/* Barva: */
fprintf(fp," 62\n130\n");
/*
fprintf(fp," 5\nB\n");
*/
/* Koordinate 1. tocke: */
fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
 dxfiprecision,p1.x,dxfiprecision,p1.y,dxfiprecision,p1.z);
/* Koordinate 2. tocke: */
fprintf(fp," 11\n%.*g\n 21\n%.*g\n 31\n%.*g\n",
 dxfiprecision,p2.x,dxfiprecision,p2.y,dxfiprecision,p2.z);
/* Koordinate 3. tocke: */
fprintf(fp," 12\n%.*g\n 22\n%.*g\n 32\n%.*g\n",
 dxfiprecision,p4.x,dxfiprecision,p4.y,dxfiprecision,p4.z);
/* Koordinate 4. tocke: */
fprintf(fp," 13\n%.*g\n 23\n%.*g\n 33\n%.*g\n",
 dxfiprecision,p3.x,dxfiprecision,p3.y,dxfiprecision,p3.z);
/*
dxfifilltriangle(fp,p1,p2,p3);
dxfifilltriangle(fp,p3,p4,p1);
*/
}





static void dxfimarktextpos(char *str,float x,float y,char mark,char box)
    /* Oznaci pozicijo teksta, ki naj bi se izpisal s funkcijo dxfitext. str je
    niz, ki naj bi se izpisal, x in y pa sta koordinati, pri katerih naj bi
    se niz izpisal. Ce je mark razlicen od 0, se izrise puscica na poziciji
    (x1,y1), ce pa je box 1, se izrise okvir okrog mej, s katerimi naj bi bil
    tekst omejen.
    $A Igor apr97; */
{
float marklength=(float) 0.03;
float xratio=/* 1.9332 */ (float) 1.5;
float yratio=(float) 1.514;
float x1,y1,x2,y2,height,dx,dy,xalign=0,yalign=0,red,green,blue;

if (mark || box)
{
  gisetlinewidth(1);
  gisetlinetype(2);
  gigettextcolor(&red,&green,&blue);
  gisetlinecolor(1-red,1-green,1-blue);
  if (mark)
  {
    x1=x-marklength;
    y1=y+(float) 0.3*marklength;
    x2=x1;
    y2=y-(float) 0.3*marklength;
    dxfiline(x,y,x1,y1);
    dxfiline(x,y,x2,y2);
  }
  if (box)
  {
    gisetlinecolor(red,green,blue);
    height=gigettextheight();
    xalign=(float) gigettextxalignment();
    yalign=(float) gigettextyalignment();
    /* Nastavitev poravnavanja teksta: */
    dy=height;    /* celotna visina teksta */
    dx=strlen(str)*height/xratio;    /* celotna sirina teksta */
    x1=x; y1=y;   /* (x,y) je spodnja leva tocka boksa. */
    /* poravnavanje v vodoravni smeri: */
    if (xalign==0)
      x1-=dx*(float) 0.5;
    else if (xalign==1)
      x1-=dx;
    if (yalign==0)
      y1-=dy*(float) 0.5;
    else if (yalign==1)
      y1-=dy;
    x2=x1+dx;
    y2=y1+dy;
    dxfifourangle(x1,y1,x2,y1,x2,y2,x1,y2);
  }
}
}





static void dxfitext(char *str,float x1,float y1)
    /* $A Igor <== apr97; */
{
float dxfitextscalingfactor=(float) (0.9*fabs(dxfisizey));
double height=0.1;
int xalign=1,yalign=1,gixalign,giyalign,font;
_coord3d p;
double xratio=1.9332;
double yratio=1.514;
double dx,dy;
dxfiwindowcoord(x1,y1,&p1);
height=gigettextheight()*dxfitextscalingfactor;
gixalign=gigettextxalignment();
giyalign=gigettextyalignment();
font=gigettextfont();
if (gixalign==-1)
  xalign=0;
else if (gixalign==0)
  xalign=1;
else if (gixalign==1)
  xalign=2;
else
  xalign=1;
if (giyalign==-1)
  yalign=1;
else if (giyalign==0)
  yalign=2;
else if (giyalign==1)
  yalign=3;
else
  yalign=2;

/* Nastavitve za poravnavanje: */
p=p1;
dy=height/yratio;  /* celotna visina teksta */
dx=strlen(str)*height/xratio;  /* celotna sirina teksta */
/* poravnavanje v vodoravni smeri: */
if (gixalign==0)
  p.x-=dx*0.5;
else if (gixalign==1)
  p.x-=dx;
/* poravnavanje v navpicni smeri: */
if (giyalign==0)
  p.y-=dy*0.5;
else if (giyalign==1)
  p.y-=dy;


if (str!=NULL)
{
  fprintf(fp," 0\nTEXT\n 8\n0\n");
  /* Barva: */
  fprintf(fp," 62\n12\n");
  /* Koordinate 1. tocke: */
  fprintf(fp," 10\n%.*g\n 20\n%.*g\n 30\n%.*g\n",
   dxfiprecision,p.x,dxfiprecision,p.y,dxfiprecision,p.z);
  /* Visina: */
  fprintf(fp," 40\n%.*g\n",dxfiprecision,height);
  /* Niz: */
  fprintf(fp," 1\n%s\n",str);
  /* Font: */
  fprintf(fp," 7\nSTYLE%i\n",font);
  /* Poravnavanje: */
  fprintf(fp," 72\n%i\n",0);
  fprintf(fp," 73\n%i\n",0);

  /* Za kontrolo pozicije teksta: */
  tclimarktextpos(str,x1,y1,0,0);
}
}






static char *dxfheadfile="0head.dxf";

void dxfiprinthead(void)
    /* $A Igor apr97; */
{
FILE *fphead=NULL;
long transfered=0,transfered1=0,buflength=500;
void *buf;
if (fp!=NULL)
{
  /* Ce obstaja datoteka, v kateri je glava za format dxf, se ta datoteka prepise
  v datoteko z imenom name in se potem pri pisanju v formatu dxf dodaja na konec
  te datoteke: */

  fphead=fopen(dxfheadfile,"rb");
  if (fphead!=NULL)
  {
    buf=malloc(buflength);
    while ( (transfered=fread(buf,1,buflength,fphead))>0)
    {
      transfered1=fwrite(buf,1,transfered,fp);
    }


    fclose(fphead);
  }

  /* Izpis obvezne glave za zacetek objektov */
  fprintf(fp," 0\nSECTION\n 2\nENTITIES\n");
}
}


void dxfiprinttail(void)
    /* $A Igor apr97; */
{
if (fp!=NULL)
{
  /* Izpis obveznega repa datoteke: */
  fprintf(fp," 0\nENDSEC\n 0\nEOF\n");
}
}








          /************************************************************/
         /*          POSPLOSENE FUNKCIJE GRAFICNEGA VMESNIKA:        */
        /************************************************************/


double (*grigetwindowwidth) (void) =tcligetwindowwidth;

double (*grigetwindowheight) (void) =tcligetwindowheight;


void (*griline) (float,float,float,float)
             = giline;

void (*gritriangle) (float,float,float,float,float,float)
             = gitriangle;

void (*grifourangle) (float,float,float,float,float,float,float,float)
             = gifourangle;

void (*grifilltriangle) (float,float,float,float,float,float)
             = gifilltriangle;

void (*grifillfourangle) (float,float,float,float,float,float,float,float)
             = gifillfourangle;

void (*gritext) (char *,float,float)
             = gitext;






/* ENOTE, KI SE NARISEJO S PoMOCJO DRUGIH FUNKCIJ ZA IZRIS: */



void grirectangle0(float x1,float y1,float x2,float y2)
     /* Narise pravokotnik iz crt z nasprotileznima ogliscema (x1,y1) in
     (x2,y2). */
{
grifourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}


void gricircle0(float x,float y,float r)
     /* Narise krog iz curvepoints crt s srediscem (x,y) in radijem r. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=(float) (4*asin(1)/(curvepoints));
x1=x+r;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+r*cos(fi));
  y2=(float) (y+r*sin(fi));
  griline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gricirclearc0(float x,float y,float r,float fi1,float fi2)
     /* Narise krozni lok iz curvepoints crt s srediscem (x,y), radijem r ter
     z zacetnim kotom fi1 in s koncnim kotom fi2. Koti so v radianih. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(float) ((fi2-fi1)/(curvepoints));
x1=(float) (x+r*cos(fi));
y1=(float) (y+r*sin(fi));
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+r*cos(fi));
  y2=(float) (y+r*sin(fi));
  griline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void griellipse0(float x,float y,float a,float b)
     /* Narise elipso iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=(float) (4*asin(1)/(curvepoints));
x1=x+a;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+a*cos(fi));
  y2=(float) (y+b*sin(fi));
  griline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void griellipsearc0(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise elipsin lok iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri ter z zacetnim kotom fi1 in
     s koncnim kotom fi2. Koti so v radianih. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(float) ((fi2-fi1)/(curvepoints));
x1=(float) (x+a*cos(fi));
y1=(float) (y+b*sin(fi));
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+a*cos(fi));
  y2=(float) (y+b*sin(fi));
  griline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void grifillrectangle0(float x1,float y1,float x2,float y2)
     /* Narise zapolnjen pravokotnik s protileznima ogliscema (x1,y1) in
     (x2,y2). */
{
grifillfourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}




void grifillcircle0(float x,float y,float r)
     /* Narise zapolnjen krog s srediscem v (x,y) in polmerom r iz curvepoints
     zapolnjenih trikotnikov. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=(float) (4*asin(1)/(curvepoints));
x1=x+r;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+r*cos(fi));
  y2=(float) (y+r*sin(fi));
  grifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void grifillcirclearc0(float x,float y,float r,float fi1,float fi2)
     /* Narise zapolnjen krozni lok s srediscem (x,y), polmerom r ter zacetnim
     kotom fi1 in koncnim kotom fi2 zi curvepoints zapolnjenih trikotnikov. Koti
     so v radianih. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(float) ((fi2-fi1)/(curvepoints));
x1=(float) (x+r*cos(fi));
y1=(float) (y+r*sin(fi));
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+r*cos(fi));
  y2=(float) (y+r*sin(fi));
  grifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void grifillellipse0(float x,float y,float a,float b)
     /* Narise zapolnjeno elipso s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b iz curvepoints zapolnjenih trikornikov. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=(float) ( 4*asin(1)/(curvepoints) );
x1=x+a;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) ( x+a*cos(fi) );
  y2=(float) ( y+b*sin(fi) );
  grifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void grifillellipsearc0(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise zapolnjen elipsin lok s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b ter zacetnim kotom fi1 in koncnim fi2 iz curvepoints
     zapolnjenih trikornikov. Koti so v radianih. */
{
float x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(float) ( (fi2-fi1)/curvepoints );
x1=(float) (x+a*cos(fi));
y1=(float) (y+b*sin(fi));
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=(float) (x+a*cos(fi));
  y2=(float) (y+b*sin(fi));
  grifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}






/* FUNKCIJE ZA RISANJE MARKERJEV: */


static void grimarker1(float x,float y,float size)
  /* Vodoravni kriz */
{
float step=size/2;
griline(x-step,y,x+step,y);
griline(x,y+step,x,y-step);
}

static void grimarker2(float x,float y,float size)
  /* Posevni kriz */
{
float step=size*sin45/2;
griline(x-step,y-step,x+step,y+step);
griline(x-step,y+step,x+step,y-step);
}

static void grimarker3(float x,float y,float size)
{
}

static void grimarker4(float x,float y,float size)
{
}

static void grimarker5(float x,float y,float size)
{
}

static void grimarker6(float x,float y,float size)
{
}

static void grimarker7(float x,float y,float size)
{
}

static void grimarker8(float x,float y,float size)
{
}

static void grimarker9(float x,float y,float size)
{
}

static void grimarker10(float x,float y,float size)
{
}

static void grimarker11(float x,float y,float size)
{
}


static void (*gridefaultmarker) (float x,float y,float size) = grimarker1;
static stack grimarkerstack=NULL;

static void griinitmarkerstack(void)
{
grimarkerstack=newstack(5);
pushstack(grimarkerstack,(void *) grimarker1);
pushstack(grimarkerstack,(void *) grimarker2);
/*
pushstack(grimarkerstack,(void *) grimarker3);
pushstack(grimarkerstack,(void *) grimarker4);
pushstack(grimarkerstack,(void *) grimarker5);
pushstack(grimarkerstack,(void *) grimarker6);
pushstack(grimarkerstack,(void *) grimarker7);
pushstack(grimarkerstack,(void *) grimarker8);
pushstack(grimarkerstack,(void *) grimarker9);
pushstack(grimarkerstack,(void *) grimarker10);
pushstack(grimarkerstack,(void *) grimarker11);
pushstack(grimarkerstack,(void *) grimarker12);
pushstack(grimarkerstack,(void *) grimarker13);
pushstack(grimarkerstack,(void *) grimarker14);
pushstack(grimarkerstack,(void *) grimarker15);
pushstack(grimarkerstack,(void *) grimarker16);
pushstack(grimarkerstack,(void *) grimarker17);
*/
}

void grimarker0(float x,float y,float size,int kind)
    /* Narise marker velikosti size in vrste kind pri koordinatah (x,y). */
{
void (*marker) (float x,float y,float size)=gridefaultmarker;
/* Ce je potrebno, se na sklad markerstack nalozijo funkcije za izris
markerjev: */
if (grimarkerstack==NULL)
  griinitmarkerstack();
/* S sklada markerstack se vzame ustrezna funkcija. Ce funkcije za zahtevano
vrsto markerja ni na skladu, ostane ta funkcija defaultmarker. */
if (kind>0 && kind<=grimarkerstack->n)
  if (grimarkerstack->s[kind]!=NULL)
    marker= (void(*)(float,float,float)) grimarkerstack->s[kind];
marker(x,y,size);
}



void griarrow0(float x1,float y1,float x2,float y2,float size,float angle,
            char l,char f,char kind)
  /* Narise puscico od (x1,y1) do (x2,y2) z velikostjo glave size in korom
  puscice angle. line doloca izris linijske stresice, fill pa zapolnjene
  trikotne glave (0 - se ne izrise, 1 - se izrise)
  $A Igor maj01; */
{
float cosfi,sinfi,wcosfi,wsinfi,length,cx,cy,px1,py1,px2,py2,width,height,
       aspectratio;
griline(x1,y1,x2,y2);
if (l!='0' && l!=0 || f!='0' && f!=0)
{
  /* Da lahko narisemo puscice v nepopaceni obliki, rabimo razmerje med visino
  in sirino okna: */
  width=(float) grigetwindowwidth();
  height=(float) grigetwindowheight();
  aspectratio=height/width;
  /* Kosinus in sinus kota, ki ga oklepa crta z vodoravnico, v realnih
  koordinatah (od 0.0 do 1.1): */
  cosfi=(float) ( (x2-x1)/(length=(float) sqrt(sqr(x2-x1)+sqr(y2-y1))) );
  sinfi=(y2-y1)/length;
  /* Kosinus in sinus kota, ki ga oklepa crta z vodoravnico, v okenskih
  (t.j. celih) koordinatah: */
  wcosfi=(float) ( (x2-x1)/(length=(float) sqrt(sqr(x2-x1)+sqr(aspectratio*(y2-y1)))) );
  wsinfi=aspectratio*(y2-y1)/length;
  /* Velikost moramo skalirati tako, da bo absolutna velikost glave pri vseh
  kotih, ki jih puscica oklepa z vodoravnico, enaka v okenskih koord; velikost
  se skalira glede na visino okna in ne glede na sirino (faktor aspectratio): */
  size*=(float) ( aspectratio/sqrt(sqr(sinfi)+sqr(cosfi/aspectratio)) );
  if (kind=='r' || kind=='R')
    size*=length;
  /* Tocka, kjer glava seka crto: */
  cx=x2-size*cosfi; cy=y2-size*sinfi;
  /* Za izracun pravokotnice rabimo naklonski kot v okenskih koordinatah,
  realne x koordinate pa moramo mnoziti z aspectratio, da se ohranijo koti (tj.
  razmerja med x in y) v okenskih koordinatah: */
  /* Prvi in drugi vogal puscice (simetricno na (cx,xy)) : */
  size*=angle;
  px1=cx-aspectratio*size*wsinfi;   py1=cy+size*wcosfi;
  px2=cx+aspectratio*size*wsinfi;   py2=cy-size*wcosfi;
  if (f!='0' && f!=0)
  {
    /* Izris zapolnjene glave: */
    grifilltriangle(px1,py1,px2,py2,x2,y2);
  }
  if (l=='T' || l=='t')
  {
    /* Izris glave kot trikotnika iz crt: */
    gritriangle(px1,py1,px2,py2,x2,y2);
  } else if (l!='0' && l!=0)
  {
    /* Izris puscice iz crt */
    griline(px1,py1,x2,y2);
    griline(px2,py2,x2,y2);
  }
}
}



void (*grirectangle) (float,float,float,float)
             = girectangle;

void (*gricircle) (float x,float y,float r)
             = gicircle;

void (*gricirclearc) (float x,float y,float r,float fi1,float fi2)
            =  gicirclearc;

void (*griellipse) (float x,float y,float a,float b)
            = giellipse;

void (*griellipsearc) (float x,float y,float a,float b,float fi1,float fi2)
            =  giellipsearc;

void (*grifillrectangle) (float x1,float y1,float x2,float y2)
            =  gifillrectangle;

void (*grifillcircle) (float x,float y,float r)
            =  gifillcircle;

void (*grifillcirclearc) (float x,float y,float r,float fi1,float fi2)
            =  gifillcirclearc;

void (*grifillellipse) (float x,float y,float a,float b)
            =  gifillellipse;

void (*grifillellipsearc) (float x,float y,float a,float b,float fi1,float fi2)
            =  gifillellipsearc;

void (*grimarker) (float,float,float,int)
             = gimarker;

void (*griarrow) (float x1,float y1,float x2,float y2,float size,float angle,
                  char l,char f,char kind)
             = giarrow;







/* FUNKCIJE ZA IZPIS GLAVE IN REPA V DATOTECNIH FORMATIH: */

void (*griprinthead) (void)=giprinthead;

void (*griprinttail) (void)=giprinttail;






/* FUNKCIJE ZA NASTAVITEV VMESNIKA OZ. FORMATA: */

stack grifuncstack=NULL;

static void * grintfunc[24]={0};
/* Hranilnik, kamor se shranejo vrednosti posplosenih funkcij graficnega
vmsnika pri klicu funkcije grisavefunc() oziroma iz katerega se te vrednosti
restavrirajo pri klicu funkcije grirestorefunc(). */


void grisavefunc(void)
    /* Shrane trenutne vrednosti kazalcev na funkcije vmesnika.
    POZOR: Paziti je treba, da ima tabela grintfunc dovolj elementov! Ce se
    dodajajo nove funkcije, ki se lahko shranejo s to funkcijo in restavrirajo
    z grirestorefunc(), je hkrati treba povecati dimenzijo tabele grintfunc.
    $A Igor apr97; */
{
grintfunc[0]=(void *) griline;
grintfunc[1]=(void *) gritriangle;
grintfunc[2]=(void *) grifourangle;
grintfunc[3]=(void *) grifilltriangle;
grintfunc[4]=(void *) grifillfourangle;
grintfunc[5]=(void *) gritext;

grintfunc[6]=(void *) grirectangle;
grintfunc[7]=(void *) gricircle;
grintfunc[8]=(void *) gricirclearc;
grintfunc[9]=(void *) griellipse;
grintfunc[10]=(void *) griellipsearc;
grintfunc[11]=(void *) grifillrectangle;
grintfunc[12]=(void *) grifillcircle;
grintfunc[13]=(void *) grifillcirclearc;
grintfunc[14]=(void *) grifillellipse;
grintfunc[15]=(void *) grifillellipsearc;
grintfunc[16]=(void *) grimarker;
grintfunc[17]=(void *) griarrow;

grintfunc[18]=(void *) griprinthead;
grintfunc[19]=(void *) griprinttail;

grintfunc[20]=(void *) grigetwindowwidth;
grintfunc[21]=(void *) grigetwindowheight;

}


void grirestorefunc(void)
    /* Restavrira vrednosti kazalcev na funkcije vmesnika, kakrsne je shranila
    funkcija grisavefunc().
    $A Igor apr97; */
{
griline= (void (*) (float,float,float,float))
        grintfunc[0];
gritriangle= (void (*) (float,float,float,float,float,float))
            grintfunc[1];
grifourangle= (void (*) (float,float,float,float,float,float,float,float))
             grintfunc[2];
grifilltriangle= (void (*) (float,float,float,float,float,float))
                grintfunc[3];
grifillfourangle= (void (*) (float,float,float,float,float,float,float,float))
                 grintfunc[4];
gritext= (void (*) (char *,float,float))
        grintfunc[5];

grirectangle= (void (*) (float,float,float,float))
          grintfunc[6];
gricircle= (void (*) (float,float,float))
          grintfunc[7];
gricirclearc= (void (*) (float,float,float,float,float))
          grintfunc[8];
griellipse= (void (*) (float,float,float,float))
          grintfunc[9];
griellipsearc= (void (*) (float,float,float,float,float,float))
          grintfunc[10];
grifillrectangle= (void (*) (float,float,float,float))
          grintfunc[11];
grifillcircle= (void (*) (float,float,float))
          grintfunc[12];
grifillcirclearc= (void (*) (float,float,float,float,float))
          grintfunc[13];
grifillellipse= (void (*) (float,float,float,float))
          grintfunc[14];
grifillellipsearc= (void (*) (float,float,float,float,float,float))
          grintfunc[15];

grimarker= (void (*) (float,float,float,int))
          grintfunc[16];
griarrow=  (void (*) (float,float,float,float,float,float,char,char,char))
          grintfunc[17];

griprinthead= (void (*) (void))
             grintfunc[18];
griprinttail= (void (*) (void))
             grintfunc[19];

grigetwindowwidth=(double (*)(void))
             grintfunc[20];
grigetwindowheight=(double (*)(void))
             grintfunc[21];
}

void grisavefunc1(void)
    /* Shrane trenutne vrednosti kazalcev na funkcije vmesnika.
    $A Igor apr97; */
{
if (grifuncstack==NULL)
  grifuncstack=newstack(4);
pushstack(grifuncstack,(void *) griline);
pushstack(grifuncstack,(void *) gritriangle);
pushstack(grifuncstack,(void *) grifourangle);
pushstack(grifuncstack,(void *) grifilltriangle);
pushstack(grifuncstack,(void *) grifillfourangle);
pushstack(grifuncstack,(void *) gritext);
pushstack(grifuncstack,(void *) grimarker);
}

void grirestorefunc1(void)
    /* Restavrira vrednosti kazalcev na funkcije vmesnika, kakrsne je shranila
    funkcija grisavefunc().
    $A Igor apr97; */
{
if (grifuncstack!=NULL)
{
grimarker= (void (*) (float,float,float,int)) popstack(grifuncstack);
gritext= (void (*) (char *,float,float)) popstack(grifuncstack);
grifillfourangle= (void (*) (float,float,float,float,float,float,float,float)) popstack(grifuncstack);
grifilltriangle= (void (*) (float,float,float,float,float,float)) popstack(grifuncstack);
grifourangle= (void (*) (float,float,float,float,float,float,float,float)) popstack(grifuncstack);
gritriangle= (void (*) (float,float,float,float,float,float)) popstack(grifuncstack);
griline= (void (*) (float,float,float,float)) popstack(grifuncstack);
}
}


void setgrintdisp(void)
    /* $A Igor apr97; */
{
fp=NULL;
griline=giline;
gritriangle=gitriangle;
grifourangle=gifourangle;
grifilltriangle=gifilltriangle;
grifourangle=gifillfourangle;
gritext=gitext;

grirectangle=girectangle;
gricircle=gicircle;
gricirclearc=gicirclearc;
griellipse=giellipse;
griellipsearc=giellipsearc;
grifillrectangle=gifillrectangle;
grifillcircle=gifillcircle;
grifillcirclearc=gifillcirclearc;
grifillellipse=gifillellipse;
grifillellipsearc=gifillellipsearc;

grimarker=gimarker;

griprinthead=giprinthead;
griprinttail=giprinttail;
}



void setgrintps(FILE *outfile)
    /* $A Igor apr97; */
{
fp=outfile;
if (fp==NULL)
  printf("Error in module grfint: output graphic file not open.\n");
grigetwindowwidth=psigetwindowwidth;
grigetwindowheight=psigetwindowheight;

griline=psiline;
gritriangle=psitriangle;
grifourangle=psifourangle;
grifilltriangle=psifilltriangle;
grifillfourangle=psifillfourangle;
gritext=psitext;

grirectangle=grirectangle0;
gricircle=gricircle0;
gricirclearc=gricirclearc0;
griellipse=griellipse0;
griellipsearc=griellipsearc0;
grifillrectangle=grifillrectangle0;
grifillcircle=grifillcircle0;
grifillcirclearc=grifillcirclearc0;
grifillellipse=grifillellipse0;
grifillellipsearc=grifillellipsearc0;

grimarker=grimarker0;
griarrow=griarrow0;

griprinthead=psiprinthead;
griprinttail=psiprinttail;
}



void setgrinttcl(FILE *outfile)
    /* $A Igor apr97; */
{
fp=outfile;
if (fp==NULL)
  printf("Error in module grfint: output graphic file not open.\n");
grigetwindowwidth=tcligetwindowwidth;
grigetwindowheight=tcligetwindowheight;

griline=tcliline;
gritriangle=tclitriangle;
grifourangle=tclifourangle;
grifilltriangle=tclifilltriangle;
grifillfourangle=tclifillfourangle;
gritext=tclitext;

grimarker=grimarker0;
griarrow=griarrow0;

grirectangle=grirectangle0;
gricircle=gricircle0;
gricirclearc=gricirclearc0;
griellipse=griellipse0;
griellipsearc=griellipsearc0;
grifillrectangle=grifillrectangle0;
grifillcircle=grifillcircle0;
grifillcirclearc=grifillcirclearc0;
grifillellipse=grifillellipse0;
grifillellipsearc=grifillellipsearc0;

griprinthead=tcliprinthead;
griprinttail=tcliprinttail;
}


void setgrintdxf(FILE *outfile)
    /* $A Igor apr97; */
{
fp=outfile;
if (fp==NULL)
  printf("Error in module grfint: output graphic file not open.\n");
grigetwindowwidth=dxfigetwindowwidth;
grigetwindowheight=dxfigetwindowheight;

griline=dxfiline;
gritriangle=dxfitriangle;
grifourangle=dxfifourangle;
grifilltriangle=dxfifilltriangle;
grifillfourangle=dxfifillfourangle;
gritext=dxfitext;

grirectangle=grirectangle0;
gricircle=gricircle0;
gricirclearc=gricirclearc0;
griellipse=griellipse0;
griellipsearc=griellipsearc0;
grifillrectangle=grifillrectangle0;
grifillcircle=grifillcircle0;
grifillcirclearc=grifillcirclearc0;
grifillellipse=grifillellipse0;
grifillellipsearc=grifillellipsearc0;

grimarker=grimarker0;
griarrow=griarrow0;

griprinthead=dxfiprinthead;
griprinttail=dxfiprinttail;
}




