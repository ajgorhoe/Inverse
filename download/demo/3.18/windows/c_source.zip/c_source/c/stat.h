#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include <er.h>




int freadline(FILE *fp, char*s)
    /* Prebere vrstico iz datoteke fp in jo zapuse v niz s 
       (znak za konec vrstice nadomesti z '\0'). */
{
int c,i=0;
while ((c=fgetc(fp))!=EOF 
 && c!='\n' && c!='\r' && i<800)
{
s[i]=c;
++i;
}
s[i]='\0';
return(i);
}





main(int numargs, char *argv[])
{
char s[100],*name;
FILE *fp,*fres;
int st,i,j,k,l,m,n;
double c1[1000],c2[1000];
double a1,a2,sigma1,average1,sigma2,average2;

/* Odprtje datoteke */
name="/ucs/igor/dip/a1";
if (numargs>1) name=argv[1];
printf("\nIme datoteke: %s",name);
fres=fopen("stat.res","ab");
fprintf(fres,"\nIme datoteke: %s",name);
fp=fopen(name,"rb");
if (numargs<3)
  printf("\n  Podatki:\n");
/* Branje vrstic datoteke */
st=0;
while (!feof(fp))
{
  freadline(fp,s);
  i=sscanf(s,"%lg%lg",&a1,&a2);
  if (i>0)
  {
    ++st;
    c1[st]=a1; c2[st]=a2;
    if (numargs<3)
      printf("%i: %g    %g\n",st,c1[st],c2[st]);
  }
}
fclose(fp);

/* Statisteka: */

/* Povprecje: */
average1=0;
average2=0;
for (i=1; i<=st; ++i)
{
  average1+=c1[i];
  average2+=c2[i];
}
average1/=(double)st;
average2/=(double)st;

/* Sigma: */
sigma1=0;
sigma2=0;
for (i=1; i<=st; ++i)
{
  sigma1+=(c1[i]-average1)*(c1[i]-average1);
  sigma2+=(c2[i]-average2)*(c2[i]-average2);
}
sigma1/=(double) (st-1);
sigma2/=(double) (st-1);
sigma1=sqrt(sigma1);
sigma2=sqrt(sigma2);


/* Izpis izracunanih podatkov */
printf("\n\n  1. serija: \n");
printf("povprecje: %g, disperzija: %g\n",average1,sigma1);
printf("  2. serija: \n");
printf("povprecje: %g, disperzija: %g\n",average2,sigma2);
printf("\n");

fprintf(fres,"\n\n  1. serija: \n");
fprintf(fres,"povprecje: %g, disperzija: %g\n",average1,sigma1);
fprintf(fres,"  2. serija: \n");
fprintf(fres,"povprecje: %g, disperzija: %g\n",average2,sigma2);
fprintf(fres,"\n");
fclose(fres);
}
