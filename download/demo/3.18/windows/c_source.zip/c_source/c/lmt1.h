/* TESTNI PROGRAM ZA LEVENBERG-MARQUARDTOVO METODO */
/* Posploseno metodo testiramo tako, da priredimo funkcije za normalno metodo. 
   Racunamo parametre, pri katerih se izbrana funkcija ene sremenljivke najbolje
   ujema z meritvami, zbranimi v tabeli. Merimo vrednosti te funkcije v izbranih
   vzorcnih tockah. Zato definiramo tudi tabelo vzorcnih tock spoints.*/

#include <sysint.h>

#include <math.h>
#include <stdio.h>



#include <er.h>

#include <mtypes.h>
#include <mat.h>
#include <vec.h>
#include <rand.h>
#include <lm.h>



_matrix covar={0};
_vector meas={0},sigma={0},a={0},meascalc={0};
double chi2={0},tol={0},factsig=0;
int it=0,maxit=0;
FILE *fp;


int numpar=2;         /* Stevilo parametrov */
int nummeas=5;        /* Stevilo vzorcnih tock oziroma meritev */
_vector spoints={0};   /* Tabela vzorcnih tock */







void setspoints(void)
{
getvec(&spoints,nummeas);
if (nummeas>=1) spoints.v[1]=0;
if (nummeas>=2) spoints.v[2]=1;
if (nummeas>=3) spoints.v[3]=2;
if (nummeas>=4) spoints.v[4]=3;
if (nummeas>=5) spoints.v[5]=4;
}


double parfunc(_vector a,double x)
       /* Funkcija ene spremenljivke, odvisna se od parametrov a.
          POZOR! Ce spreminjas to funkcijo, potem moras spremeniti tudi funkcijo 
          dparfunc! */
{
return(a.v[1]*exp(a.v[2]*x));
}


double dparfunc(_vector a,double x)
       /* Odvod funkcije parfunc po spremenljivki x */
{
return(a.v[1]*a.v[2]*exp(a.v[2]*x));
}


void lmfunc(_vector param,_vector *meas)
     /* Funkcija, ki pri vhodnih parametrih param izracuna merjene vrednosti
     za Levenberg-Marquardtovo metodo. */
{
int i;
if (meas->v==NULL || meas->d!=spoints.d)
{
  dispvec(meas);
  getvec(meas,spoints.d);
}
for (i=1; i<=spoints.d; ++i)
meas->v[i]=parfunc(param,spoints.v[i]);
}



double lmdfunc(_vector a,int whichmeas,int whichpar, void lmfunc(_vector,_vector *))
     /* Funkcija, ki pri vhodnih parametrih a izracuna odvode merjenie vrednosti
        whichmeas po parametru whichpar za Levenberg-Marquardtovo metodo. */
{
if (whichmeas<=nummeas && whichpar<=numpar)
{
  if (whichpar==1)
  {
    return(exp(a.v[2]*spoints.v[whichmeas]));
  } else if (whichpar==2)
  {
    return(a.v[1]*spoints.v[whichmeas]*exp(a.v[2]*spoints.v[whichmeas]));
  }
}
}






int connection(int a)
{
return(a);
}






main()
{
int i,j;
double rn;
char c;
fp=fopen("inv.pom","wb");
timeinitrand();
for (i=1;i<=20;++i)
{
  rn=normdist();
  printf("\n%g",rn);
}
/* c=getchar(); */
setspoints();
getvec(&a,numpar);
getvec(&meas,nummeas);
getvec(&sigma,nummeas);
/* Pravi parametri: */
a.v[1]=5;
a.v[2]=3;
printf("\n\n\nVEKTOR PRAVIH PARAMETROV: \n");
printvecname(a,"a");
/* Vzorcne tocke: */
printf("\n\n\nVZORCNE TOCKE: \n");
printvecname(spoints,"vzorec");
/* Natancne meritve: */
for (i=1; i<=nummeas; ++i)
  meas.v[i]=parfunc(a,spoints.v[i]);
printf("\n\n\nVEKTOR NATANCNIH MERITEV: \n");
printvecname(meas,"measexact");
factsig=0;
/* Napake meritev: */
factsig=0.001;
for (i=1;i<=nummeas; ++i)
  sigma.v[i]=fabs(meas.v[i]*factsig);
printf("\n\n\nVEKTOR NAPAK MERITEV: \n");
printvecname(sigma,"sigma");
/* Meritve, obremenjene z napakami: */
for (i=1;i<=nummeas; ++i)
  meas.v[i]+=sigma.v[i]*normdist();
printf("\n\n\nVEKTOR MERITEV: \n");
printvecname(meas,"izmerek");

/* Poskusni parametri: */
a.v[1]=5.0;
a.v[2]=3.01;
printf("\n\n\nVEKTOR PRAVIH PARAMETROV: \n");

tol=0.1;
it=0;
maxit=50;

levmarq(meas, sigma, &a, &meascalc,
             &chi2, &covar,
             lmfunc,
             lmdfunc,
             tol,
             &it, maxit, connection, fp);

printvecname(a,"a");


fclose(fp);
}



































































































