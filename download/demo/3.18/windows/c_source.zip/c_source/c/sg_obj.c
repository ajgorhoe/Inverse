

        /************************************/
        /*                                  */
        /*   MANIPULATING GRAPHIC OBJECTS   */
        /*                                  */
        /************************************/



#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <math.h>

#include <sysint.h>

#include <strop.h>
#include <rf.h>
#include <st.h>
#include <er.h>
#include <grint.h>
#include <gro.h>

#include <sg_obj.h>
#include <sg_draw.h>
#include <sg_ploto.h>
#include <sg_obj.h>



    /* BASIC GRAPHIC TYPES: ALLOCATION, DEALLOCATION, COPYING... */

  /* COORDINATES, FRAMES: */

coord3d newcoord3d(void)
    /* Creates a new object of type coord3d and returns it.
    $A Igor nov03; */
{
return (coord3d) calloc(1,sizeof(coord3d *));
}

void dispcoord3d(coord3d *coord)
    /* Deallocates space occupied by *coord and sets *coord to NULL.
    $A Igor nov03; */
{
disppointer((void **) coord);
}


int sizecoord3d(coord3d coord)
    /* Returns the size of memory occupied by coord, in bytes.
    $A Igor nov03; */
{
return m_sizepointer(coord,coord3d);
}


coord3d copycoord3d(coord3d c1,coord3d *c2)
    /* Returns a copy of the c1. If c2 is different than NULL then c1 is
    copied to *c2 and *c2 returned, otherwise a dynamic copy of c1 is made
    and returned.
    $A Igor nov03; */
{
coord3d ret;
m_copypointer(c1,c2,ret)
return ret;
}


frame3d newframe3d(void)
    /* Creates a new object of type frame3d and returns it.
    $A Igor nov03; */
{
return (frame3d) calloc(1,sizeof(frame3d *));
}

void dispframe3d(frame3d *frame)
    /* Deallocates space occupied by *frame and sets *frame to NULL.
    $A Igor nov03; */
{
disppointer((void **) frame);
}

int sizeframe3d(frame3d frame)
    /* Returns the size of memory occupied by frame, in bytes.
    $A Igor nov03; */
{
return m_sizepointer(frame,frame3d);
}

frame3d copyframe3d(frame3d f1,frame3d *f2)
    /* Returns a copy of f1. If f2 is different than NULL then f1 is
    copied to *f2 and *f2 returned, otherwise a dynamic copy of f1 is made
    and returned.
    $A Igor nov03; */
{
frame3d ret;
m_copypointer(f1,f2,ret)
return ret;
}


  /* COLOR STRUCTURE: */


truecolor newtruecolor(void)
    /* Creates a new object of type truecolor and returns it.
    $A Igor nov03; */
{
return (truecolor) calloc(1,sizeof(truecolor *));
}

void disptruecolor(truecolor *coord)
    /* Deallocates space occupied by *coord and sets *coord to NULL.
    $A Igor nov03; */
{
disppointer((void **) coord);
}

int sizetruecolor(truecolor coord)
    /* Returns the size of memory occupied by coord, in bytes.
    $A Igor nov03; */
{
return m_sizepointer(coord,truecolor);
}

truecolor copytruecolor(truecolor c1,truecolor *c2)
    /* Returns a copy of the c1. If c2 is different than NULL then c1 is
    copied to *c2 and *c2 returned, otherwise a dynamic copy of c1 is made
    and returned.
    $A Igor nov03; */
{
truecolor ret;
m_copypointer(c1,c2,ret)
return ret;
}


  /* LINE SETTINGS: */

golinesettings newgolinesettings(void)
    /* Returns a newly allocated object of type golinesettings with default
    values of fields.
    $A Igor nov03; */
{
golinesettings ret;
(void *) ret=calloc(1,sizeof(*ret));
ret->color.red=0; ret->color.green=0; ret->color.blue=0.7f;
ret->linewidth=0.0;
ret->linetype=0;
return ret;
}

void dispgolinesettings(golinesettings *addr)
    /* Deallocates the space for *addr and sets *addr to NULL.
    $A Igor nov03; */
{
disppointer((void **) addr);
}

int sizegolinesettings(golinesettings ls)
    /* Returns the total space occupied by the object ls of the type
    golinesettings.
    $A Igor nov03; */
{
int ret=0;
if (ls!=NULL)
{
  ret+=sizeof(*ls);
}
return ret;
}

golinesettings copygolinesettings0(golinesettings ls1,golinesettings ls2)
    /* Copy the contents of ls1 to ls2 if BOTH ls1 and ls2 are DIFFERENT THAN
    NULL. ls2 is returned if copying has been performed.
    $A Igor nov03; */
{
if (ls1!=NULL && ls2!=NULL)
{
  *ls2=*ls1;
  return ls2;
} else
  return NULL;
}

golinesettings copygolinesettings(golinesettings ls1,golinesettings *ls2)
    /* Returns a copy of the ls1. If ls2 is different than NULL then ls1 is
    copied to *ls2 and *ls2 returned, otherwise a dynamic copy of ls1 is made
    and returned.
    $A Igor nov03; */
{
golinesettings ret;
if (ls2!=NULL)
{
  /* If ls2!=NULL, then ls1 is copied to ls2: */
  if (ls1==NULL)
  {
    dispgolinesettings(ls2);
  } else
  {
    /* If *ls2==NULL, we allocate it: */
    if (*ls2==NULL)
      *ls2=newgolinesettings();
    /* Copying contents: */
    copygolinesettings0(ls1,*ls2);
  }
  return *ls2; /* since ls2!=NULL. */
} else
{
  /* ls2==NULL, a new object is created that is a copy of ls1 and returned */
  if (ls1==NULL)
    return NULL;
  else
  {
    ret=newgolinesettings();
    copygolinesettings0(ls1,ret);
    return ret;
  }
}
}


  /* FILL SETTINGS: */

gofillsettings newgofillsettings(void)
    /* Returns a newly allocated object of type gofillsettings with default
    values of fields.
    $A Igor nov03; */
{
gofillsettings ret;
(void *) ret=calloc(1,sizeof(*ret));
ret->color.red=1; ret->color.green=1; ret->color.blue=0.5f;
return ret;
}

void dispgofillsettings(gofillsettings *addr)
    /* Deallocates the space for *addr and sets *addr to NULL.
    $A Igor nov03; */
{
disppointer((void **) addr);
}

int sizegofillsettings(gofillsettings fs)
    /* Returns the total space occupied by the object fs of the type
    gofillsettings.
    $A Igor nov03; */
{
int ret=0;
if (fs!=NULL)
{
  ret+=sizeof(*fs);
}
return ret;
}

gofillsettings copygofillsettings0(gofillsettings fs1,gofillsettings fs2)
    /* Copy the contents of fs1 to fs2 if BOTH fs1 and fs2 are DIFFERENT THAN
    NULL. fs2 is returned if copying has been performed.
    $A Igor nov03; */
{
if (fs1!=NULL && fs2!=NULL)
{
  *fs2=*fs1;
  return fs2;
} else
  return NULL;
}

gofillsettings copygofillsettings(gofillsettings fs1,gofillsettings *fs2)
    /* Returns a copy of the fs1. If fs2 is different than NULL then fs1 is
    copied to *fs2 and *fs2 returned, otherwise a dynamic copy of fs1 is made
    and returned.
    $A Igor nov03; */
{
gofillsettings ret;
if (fs2!=NULL)
{
  /* If fs2!=NULL, then fs1 is copied to fs2: */
  if (fs1==NULL)
  {
    dispgofillsettings(fs2);
  } else
  {
    /* If *fs2==NULL, we allocate it: */
    if (*fs2==NULL)
      *fs2=newgofillsettings();
    /* Copying contents: */
    copygofillsettings0(fs1,*fs2);
  }
  return *fs2; /* since fs2!=NULL. */
} else
{
  /* fs2==NULL, a new object is created that is a copy of fs1 and returned */
  if (fs1==NULL)
    return NULL;
  else
  {
    ret=newgofillsettings();
    copygofillsettings0(fs1,ret);
    return ret;
  }
}
}


  /* TEXT SETTINGS: */

gotextsettings newgotextsettings(void)
    /* Returns a newly allocated object of type gotextsettings with default
    values of fields.
    $A Igor nov03; */
{
gotextsettings ret;
(void *) ret=calloc(1,sizeof(*ret));
ret->color.red=1; ret->color.green=0.2f; ret->color.blue=0.2f;
ret->font=1;
ret->height=0.03;
ret->xalignment=0;
ret->yalignment=0;
return ret;
}

void dispgotextsettings(gotextsettings *addr)
    /* Deallocates the space for *addr and sets *addr to NULL.
    $A Igor nov03; */
{
disppointer((void **) addr);
}

int sizegotextsettings(gotextsettings ts)
    /* Returns the total space occupied by the object ts of the type
    gotextsettings.
    $A Igor nov03; */
{
int ret=0;
if (ts!=NULL)
{
  ret+=sizeof(*ts);
}
return ret;
}

gotextsettings copygotextsettings0(gotextsettings ts1,gotextsettings ts2)
    /* Copy the contents of ts1 to ts2 if BOTH ts1 and ts2 are DIFFERENT THAN
    NULL. ts2 is returned if copying has been performed.
    $A Igor nov03; */
{
if (ts1!=NULL && ts2!=NULL)
{
  *ts2=*ts1;
  return ts2;
} else
  return NULL;
}

gotextsettings copygotextsettings(gotextsettings ts1,gotextsettings *ts2)
    /* Returns a copy of the fs1. If fs2 is different than NULL then fs1 is
    copied to *fs2 and *fs2 returned, otherwise a dynamic copy of fs1 is made
    and returned.
    $A Igor nov03; */
{
gotextsettings ret;
if (ts2!=NULL)
{
  /* If ts2!=NULL, then fs1 is copied to ts2: */
  if (ts1==NULL)
  {
    dispgotextsettings(ts2);
  } else
  {
    /* If *ts2==NULL, we allocate it: */
    if (*ts2==NULL)
      *ts2=newgotextsettings();
    /* Copying contents: */
    copygotextsettings0(ts1,*ts2);
  }
  return *ts2; /* since ts2!=NULL. */
} else
{
  /* ts2==NULL, a new object is created that is a copy of fs1 and returned */
  if (ts1==NULL)
    return NULL;
  else
  {
    ret=newgotextsettings();
    copygotextsettings0(ts1,ret);
    return ret;
  }
}
}



  /* GRAPHIC PRIMITIVES: */

goprimitive newgoprimitive(void)
    /* Allocates space for an object of the type goprimitive and returns its
    pointer.
    $A Igor <== sep03; */
{
goprimitive ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));;
ret->clear=NULL;
/*
ret->i1=ret->i2=ret->i3='0';
*/
ret->type=SG_PR_UNDEF;
ret->dp=NULL;
/*
ret->geo=NULL;
*/
ret->coord=NULL;
ret->transfcoord=NULL;
ret->before=NULL;
ret->after=NULL;
ret->props1=ret->props2=ret->props3=ret->props4=NULL;
ret->grp=NULL;
return ret;
}


void dispgoprimitive(goprimitive *p)
    /* Releases memory used by **p and sets *p to NULL.
    $A Igor <== sep03; */
{
goprimitive gp;
static int repinval=0;
if (p==NULL)
  return;
if (*p==NULL)
  return;
gp=*p;
/* Call to a function for deletion of non-standard parts of the structure: */
if (gp->clear!=NULL)
  gp->clear((void *) gp);
if (gp->dp!=NULL)
  free(gp->dp);
/*
if (gp->geo!=NULL)
{
  free(gp->geo);
}
*/
if (gp->coord!=NULL)
{
  if (gp->coord->n!=0)
    dispstackval(gp->coord);
  dispstack(&(gp->coord));
}
if (gp->transfcoord!=NULL)
{
  if (gp->transfcoord->n!=0)
    dispstackval(gp->transfcoord);
  dispstack(&(gp->transfcoord));
}
switch (gp->type)
{
  case SG_PR_UNDEF:
    break;
  case SG_PR_LINE:
    dispgolinesettings((golinesettings *) &(gp->props1));
    break;
  case SG_PR_TRI:
    dispgolinesettings((golinesettings *) &(gp->props1));
    break;
  case SG_PR_F_TRI:
    dispgofillsettings((gofillsettings *) &(gp->props1));
    break;
  case SG_PR_FB_TRI:
    dispgofillsettings((gofillsettings *) &(gp->props1));
    dispgolinesettings((golinesettings *) &(gp->props2));
    break;
  case SG_PR_FP_TRI:
    dispgofillsettings((gofillsettings *) &(gp->props1));
    dispgolinesettings((golinesettings *) &(gp->props2));
    disppointer((void **) &(gp->props3));
    break;
  case SG_PR_FOUR:
    dispgolinesettings((golinesettings *) &(gp->props1));
    break;
  case SG_PR_F_FOUR:
    dispgofillsettings((gofillsettings *) &(gp->props1));
    break;
  case SG_PR_FB_FOUR:
    dispgofillsettings((gofillsettings *) &(gp->props1));
    dispgolinesettings((golinesettings *) &(gp->props2));
    break;
  case SG_PR_FP_FOUR:
    dispgofillsettings((gofillsettings *) &(gp->props1));
    dispgolinesettings((golinesettings *) &(gp->props2));
    disppointer((void **) &(gp->props3));
    break;
  case SG_PR_TEXT:
    disppointer((void **) &(gp->props1));
    dispgotextsettings((gotextsettings *) &(gp->props2));
    break;
  case SG_PR_MARK:
    dispgofillsettings((gofillsettings *) &(gp->props1));
    dispgolinesettings((golinesettings *) &(gp->props2));
    disppointer((void **) &(gp->props3));
    disppointer((void **) &(gp->props4));
    break;
  case SG_PR_ARROW:
    dispgofillsettings((gofillsettings *) &(gp->props1));
    dispgolinesettings((golinesettings *) &(gp->props2));
    disppointer((void **) &(gp->props3));
    disppointer((void **) &(gp->props4));
    break;
  default:
    if (!repinval)
    {
      warnfunc1(1,"dispgoprimitive");
      sprintf(ers(),"A graphic primitive of invalid type (%i) encountered",
        gp->type);
      sprintf(ers(),"Further messages of this type will be surpressed.\n");
      warnfunc2();
      ++repinval;
    }
}
if (gp->before!=NULL)
  dispstack(&(gp->before));
if (gp->after!=NULL)
  dispstack(&(gp->after));
if (gp->props1!=NULL)
  free(gp->props1);
if (gp->props2!=NULL)
  free(gp->props2);
if (gp->props3!=NULL)
  free(gp->props3);
if (gp->props4!=NULL)
  free(gp->props4);
gp->grp=NULL;
free(gp);
*p=NULL;
}



int sizegoprimitive(goprimitive gp)
    /* Returns the total amount of memory, in bytes, occupied by gp.
    $A Igor nov03; */
{
int ret=0;
static int repinval=0;
if (gp!=NULL)
{
  ret+=sizeof(*gp);
  if (gp->dp!=NULL)
    ret+=sizeof(*(gp->dp));
  if (gp->coord!=NULL)
    ret+=sizestack(gp->coord,(int (*)(void *)) sizecoord3d);
  if (gp->transfcoord!=NULL)
    ret+=sizestack(gp->transfcoord,(int (*)(void *)) sizecoord3d);
  if (gp->before!=NULL)
    ret+=sizestack0(gp->before);
  if (gp->after!=NULL)
    ret+=sizestack0(gp->after);
  switch (gp->type)
  {
    case SG_PR_UNDEF:
      break;
    case SG_PR_LINE:
      if (gp->props1!=NULL)
        ret+=sizegolinesettings((golinesettings) gp->props1);
      break;
    case SG_PR_TRI:
      if (gp->props1!=NULL)
        ret+=sizegolinesettings((golinesettings) gp->props1);
      break;
    case SG_PR_F_TRI:
      if (gp->props1!=NULL)
        ret+=sizegofillsettings((gofillsettings) gp->props1);
      break;
    case SG_PR_FB_TRI:
      if (gp->props1!=NULL)
        ret+=sizegofillsettings((gofillsettings) gp->props1);
      if (gp->props2!=NULL)
        ret+=sizegolinesettings((golinesettings) gp->props2);
      break;
    case SG_PR_FP_TRI:
      if (gp->props1!=NULL)
        ret+=sizegofillsettings((gofillsettings) gp->props1);
      if (gp->props2!=NULL)
        ret+=sizegolinesettings((golinesettings) gp->props2);
      if (gp->props3!=NULL)
        ret+=3*sizeof(char);
      break;
    case SG_PR_FOUR:
      if (gp->props1!=NULL)
        ret+=sizegolinesettings((golinesettings) gp->props1);
      break;
    case SG_PR_F_FOUR:
      if (gp->props1!=NULL)
        ret+=sizegofillsettings((gofillsettings) gp->props1);
      break;
    case SG_PR_FB_FOUR:
      if (gp->props1!=NULL)
        ret+=sizegofillsettings((gofillsettings) gp->props1);
      if (gp->props2!=NULL)
        ret+=sizegolinesettings((golinesettings) gp->props2);
      break;
    case SG_PR_FP_FOUR:
      if (gp->props1!=NULL)
        ret+=sizegofillsettings((gofillsettings) gp->props1);
      if (gp->props2!=NULL)
        ret+=sizegolinesettings((golinesettings) gp->props2);
      if (gp->props3!=NULL)
        ret+=4*sizeof(char);
      break;
    case SG_PR_TEXT:
      if (gp->props1!=NULL)
        ret+=sizestring((char *) gp->props1);
      if (gp->props2!=NULL)
        ret+=sizegotextsettings((gotextsettings ) gp->props2);
      break;
    case SG_PR_MARK:
      if (gp->props1!=NULL)
        ret+=sizegofillsettings((gofillsettings) gp->props1);
      if (gp->props2!=NULL)
        ret+=sizegolinesettings((golinesettings) gp->props2);
      if (gp->props3!=NULL)
        ret+=sizeof(double);
      if (gp->props4!=NULL)
        ret+=sizeof(int);
      break;
    case SG_PR_ARROW:
      if (gp->props1!=NULL)
        ret+=sizegofillsettings((gofillsettings) gp->props1);
      if (gp->props2!=NULL)
        ret+=sizegolinesettings((golinesettings) gp->props2);
      if (gp->props3!=NULL)
        ret+=2*sizeof(double);
      if (gp->props4!=NULL)
        ret+=sizeof(int);
      break;
    default:
      if (!repinval)
      {
        warnfunc1(1,"sizegoprimitive");
        sprintf(ers(),"A graphic primitive of invalid type (%i) encountered",
          gp->type);
        sprintf(ers(),"Further messages of this type will be surpressed.\n");
        warnfunc2();
        ++repinval;
      }
  }
}
return ret;
}


goprimitive copygoprimitive0(goprimitive gp1,goprimitive gp2)
    /* Copies the contents of gp1 to gp2 if BOTH gp1 and gp2 are DIFFERENT THAN
    NULL. gp2 is returned if copying has been performed. Pointers on stacks
    before and after are NOT copied.
    $A Igor nov03; */
{
if (gp1!=NULL && gp2!=NULL)
{
  void *p;
  static int repinval=0;
  if (gp1->type!=gp2->type)
  {
    /* If the types do not match, then we first delete the contents of gp2.
    This must be done because types of the pointers (...)->props1 to
    (...)->props4 do not match.  We do this by dynamically allocating a graphic
    primitive, copy contents of gp2 to this primitive and delete it (since we
    may not deallocate gp2 itself, otherwise the original pointer would be
    invalid!): */
    goprimitive gp;
    gp=malloc(sizeof(*gp));
    *gp=*gp2;
    dispgoprimitive(&gp);
    memset(gp2,0,sizeof(*gp2));
  }
  gp2->type=gp1->type;
  m_copypointer(gp1->dp,&(gp2->dp),(double *) p);
  copystackspec(gp1->coord,&(gp2->coord),(void (*) (void **))dispcoord3d,
                (void * (*) (void *,void **)) copycoord3d);
  copystackspec(gp1->transfcoord,&(gp2->transfcoord),
                (void (*) (void **))dispcoord3d,
                (void * (*) (void *,void **)) copycoord3d);
  /* We copy stacks gp1->before and gp1->after, but without copying elements (we
  just ser elements on gp2 to NULL while the stacks will have the same number
  of elements than those on gp1). */
  copystackspec(gp1->before,&(gp2->before),NULL,NULL);
  copystackspec(gp1->after,&(gp2->after),NULL,NULL);
  gp2->grp=NULL;
  switch (gp1->type)
  {
    case SG_PR_UNDEF:
      break;
    case SG_PR_LINE:
      copygolinesettings((golinesettings) gp1->props1,
                         (golinesettings *) &(gp2->props1));
      break;
    case SG_PR_TRI:
      copygolinesettings((golinesettings) gp1->props1,
                         (golinesettings *) &(gp2->props1));
      break;
    case SG_PR_F_TRI:
      copygofillsettings((gofillsettings) gp1->props1,
                         (gofillsettings *) &(gp2->props1));
      break;
    case SG_PR_FB_TRI:
      copygofillsettings((gofillsettings) gp1->props1,
                         (gofillsettings *) &(gp2->props1));
      copygolinesettings((golinesettings) gp1->props2,
                         (golinesettings *) &(gp2->props2));
      break;
    case SG_PR_FP_TRI:
      copygofillsettings((gofillsettings) gp1->props1,
                         (gofillsettings *) &(gp2->props1));
      copygolinesettings((golinesettings) gp1->props2,
                           (golinesettings *) &(gp2->props2));
      if (gp1->props3!=NULL)
      {
        if (gp2->props3==NULL)
          gp2->props3=malloc(3*sizeof(char));
        memcpy(gp2->props3,gp1->props3,3*sizeof(char));
      } else
        disppointer((void **) &(gp2->props3));
      break;
    case SG_PR_FOUR:
      copygolinesettings((golinesettings) gp1->props1,
                           (golinesettings *) &(gp2->props1));
      break;
    case SG_PR_F_FOUR:
      copygofillsettings((gofillsettings) gp1->props1,
                         (gofillsettings *) &(gp2->props1));
      break;
    case SG_PR_FB_FOUR:
      copygofillsettings((gofillsettings) gp1->props1,
                         (gofillsettings *) &(gp2->props1));
      copygolinesettings((golinesettings) gp1->props2,
                         (golinesettings *) &(gp2->props2));
      break;
    case SG_PR_FP_FOUR:
      copygofillsettings((gofillsettings) gp1->props1,
                         (gofillsettings *) &(gp2->props1));
      copygolinesettings((golinesettings) gp1->props2,
                           (golinesettings *) &(gp2->props2));
      if (gp1->props3!=NULL)
      {
        if (gp2->props3==NULL)
          (void *) gp2->props3=malloc(4*sizeof(char));
        memcpy(gp2->props3,gp1->props3,4*sizeof(char));
      } else
        disppointer((void **) &(gp2->props3));
      break;
    case SG_PR_TEXT:
      copystring((char *) gp1->props1,
                 (char **) &(gp2->props1));
      copygotextsettings((gotextsettings) gp1->props2,
                           (gotextsettings *) &(gp2->props2));
      break;
    case SG_PR_MARK:
      copygofillsettings((gofillsettings) gp1->props1,
                         (gofillsettings *) &(gp2->props1));
      copygolinesettings((golinesettings) gp1->props2,
                           (golinesettings *) &(gp2->props2));
      m_copypointer((double *) gp1->props3,(double **) &(gp2->props3),
                    (double *) p);
      m_copypointer((int *) gp1->props4,(int **) &(gp2->props4),
                    (int *) p);
    case SG_PR_ARROW:
      copygofillsettings((gofillsettings) gp1->props1,
                         (gofillsettings *) &(gp2->props1));
      copygolinesettings((golinesettings) gp1->props2,
                           (golinesettings *) &(gp2->props2));
      if (gp1->props3!=NULL)
      {
        if (gp2->props3==NULL)
          gp2->props3=malloc(2*sizeof(double));
        memcpy(gp2->props3,gp1->props3,2*sizeof(double));
      } else
        disppointer((void **) &(gp2->props3));
      m_copypointer((int *) gp1->props4,(int **) &(gp2->props4),
                    (int *) p);
      break;
    default:
      if (!repinval)
      {
        warnfunc1(1,"copygoprimitive0");
        sprintf(ers(),"A graphic primitive of invalid type (%i) encountered",
          gp1->type);
        sprintf(ers(),"Further messages of this type will be surpressed.\n");
        warnfunc2();
        ++repinval;
      }
  }
  return gp2;
} else
  return NULL;
}


goprimitive copygoprimitive(goprimitive gp1,goprimitive *gp2)
    /* Returns a copy of the gp1. If gp2 is different than NULL then gp1 is
    copied to *gp2 and *gp2 returned, otherwise a dynamic copy of gp1 is made
    and returned. Pointers on the stacks gp1->before and gp1->after are not
    copied!
    $A Igor nov03; */
{
goprimitive ret;
if (gp2!=NULL)
{
  /* If gp2!=NULL, then gp1 is copied to *gp2: */
  if (gp1==NULL)
  {
    dispgoprimitive(gp2);
  } else
  {
    /* If *gp2==NULL, we allocate it: */
    if (*gp2==NULL)
      *gp2=newgoprimitive();
    /* Copying contents: */
    copygoprimitive0(gp1,*gp2);
  }
  return *gp2; /* since gp2!=NULL. */
} else
{
  /* gp2==NULL, a new object is created that is a copy of gp1 and returned */
  if (gp1==NULL)
    return NULL;
  else
  {
    ret=newgoprimitive();
    copygoprimitive0(gp1,ret);
    return ret;
  }
}
}



gogroup newgogroup(void)
    /* Allocates space for a new object of type gogroup and returns its pointer.
    Space for stack members (...)->groups, (...)->primitives and
    (...)->primitives is not allocated.
    $A Igor <== sep03; */
{
gogroup ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
ret->clear=NULL;
ret->id=1;
ret->name=NULL;
ret->limitsset=0;
ret->transflimitsset=0;
ret->min=NULL;
ret->max=NULL;
ret->mintransf=NULL;
ret->maxtransf=NULL;
ret->ls1=NULL;
ret->ls2=NULL;
ret->fs1=NULL;
ret->fs2=NULL;
ret->ts1=NULL;
ret->ts2=NULL;
ret->groups=NULL;
ret->primitives=NULL;
ret->extraprimitives=NULL;
ret->grp=NULL;
return ret;
}




gogroup newgogroupst(int ngroups,int nprimitives,int nextraprimitives)
    /* Allocates space for a new object of the type gogroup and returns its
    pointer. The space members  (...)->groups, (...)->primitives and
    (...)->primitives (which are stacks) are also initialized where the (...)->ex
    fields are set to ngroups, nprimitives and nextraprimitives, respectively. If
    any of these numbers is less than 1 then space for the corresponding stack is
    not allocated.
    $A Igor <== sep03; */
{
gogroup ret;
ret=newgogroup();
if (ngroups<1)
  ngroups=1;
if (nprimitives<1)
  nprimitives=1;
if (nextraprimitives<1)
  nextraprimitives=1;
if (ngroups>0)
  ret->groups=newstack(ngroups);
if (nprimitives>0)
  ret->primitives=newstack(nprimitives);
if (nextraprimitives>0)
  ret->extraprimitives=newstack(nextraprimitives);
return ret;
}


void dispgogroup(gogroup *p)
    /* Releases the memory space occupied by **p and sets *p to NULL. The space
    that is occupied by the member objects of **p is released first. Sub-groups
    are released recursively.
    $A Igor <== sep03; */
{
if (p!=NULL)
{
  gogroup gg=*p;
  /* Call first functions for deletion of non-standard parts of the structure: */
  if (gg!=NULL)
  {
    if (gg->clear!=NULL)
      gg->clear(gg);
    if (gg->name!=NULL)
      free(gg->name);
    if (gg->min!=NULL)
      free(gg->min);
    if (gg->max!=NULL)
      free(gg->max);
    if (gg->mintransf!=NULL)
      free(gg->mintransf);
    if (gg->ls1!=NULL)
      free(gg->ls1);
    if (gg->ls2!=NULL)
      free(gg->ls2);
    if (gg->fs1!=NULL)
      free(gg->fs1);
    if (gg->fs2!=NULL)
      free(gg->fs2);
    if (gg->ts1!=NULL)
      free(gg->ts1);
    if (gg->ts2!=NULL)
      free(gg->ts2);
    if (gg->primitives!=NULL)
      dispstackallspec(&(gg->primitives),(void (*) (void **)) dispgoprimitive);
    if (gg->extraprimitives!=NULL)
      dispstackallspec(&(gg->extraprimitives),(void (*) (void **)) dispgoprimitive);
    if (gg->groups!=NULL)
      dispstackallspec(&(gg->groups),(void (*) (void **)) dispgogroup);
    gg->grp=NULL;
    free(gg);
  }
  *p=NULL;
}
}


#if 0
void dispgogrouptree(gogroup *p)
    /* Recursively releases a whole tree structure of graphic objects with the
    roo pointer *p and sets *p to NULL.
    $A Damjan mar97 Igor sep03; */
{
int i;
gogroup gg=*p;
if(gg!=NULL)
{
  /* Deletion of primitives from the stack (*p)->primitives: */
  if(gg->primitives!=NULL)
    if(gg->primitives->n>0)
      for(i=1;i<=gg->primitives->n;++i)
	dispgoprimitive((goprimitive *)(&(gg->primitives->s[i])));
  /* Deletion of primitives from the stack (*p)->extraprimitives: */
  if(gg->extraprimitives!=NULL)
    if(gg->extraprimitives->n>0)
      for(i=1;i<=gg->extraprimitives->n;++i)
	dispgoprimitive((goprimitive *)(&(gg->extraprimitives->s[i])));
  /* Recursive deletion of sub-groups on the stack (*p)->groups: */
  if(gg->groups!=NULL)
    if(gg->groups->n>0)  
    {
      for(i=1;i<=gg->groups->n;++i)
	dispgogrouptree((gogroup *)(&(gg->groups->s[i])));
    }
  /* Deletio of *p idself: */
  dispgogroup(p);
}
}
#endif


int sizegogroup(gogroup gg)
    /* Returns the total memory space in bytes occupied by gg.
    $A Ikgor nov03; */
{
int ret=0;
if (gg!=NULL)
{
  ret+=sizeof(*gg);
  if (gg->name!=NULL)
    ret+=sizestring(gg->name);
  if (gg->min!=NULL)
    ret+=sizecoord3d(gg->min);
  if (gg->max!=NULL)
    ret+=sizecoord3d(gg->max);
  if (gg->mintransf!=NULL)
    ret+=sizecoord3d(gg->mintransf);
  if (gg->maxtransf!=NULL)
    ret+=sizecoord3d(gg->maxtransf);
  if (gg->ls1!=NULL)
    ret+=sizegolinesettings(gg->ls1);
  if (gg->ls2!=NULL)
    ret+=sizegolinesettings(gg->ls2);
  if (gg->fs1!=NULL)
    ret+=sizegofillsettings(gg->fs1);
  if (gg->fs2!=NULL)
    ret+=sizegofillsettings(gg->fs2);
  if (gg->ts1!=NULL)
    ret+=sizegotextsettings(gg->ts1);
  if (gg->primitives!=NULL)
    ret+=sizestack(gg->primitives,(int (*)(void *)) sizegoprimitive);
  if (gg->extraprimitives!=NULL)
    ret+=sizestack(gg->extraprimitives,(int (*)(void *)) sizegoprimitive);
  if (gg->groups!=NULL)
    ret+=sizestack(gg->groups,(int (*)(void *)) sizegogroup);
}
return ret;
}



gogroup copygogroup0(gogroup gg1,gogroup gg2)
    /* Copies the contents of gg1 to gg2 if BOTH gg1 and gg2 are DIFFERENT THAN
    NULL. gg2 is returned if copying has been performed, otherwise NULL is
    returned. Pointers on stacks before and after are NOT copied.
    $A Igor nov03; */
{
if (gg1!=NULL && gg2!=NULL)
{
  gogroup gg;
  goprimitive gp;
  int i;
  gg2->id=gg1->id;
  copystring(gg1->name,&(gg2->name));
  gg2->limitsset=gg1->limitsset;
  gg2->transflimitsset=gg1->transflimitsset;
  copycoord3d(gg1->min,&(gg2->min));
  copycoord3d(gg1->max,&(gg2->max));
  copycoord3d(gg1->mintransf,&(gg2->mintransf));
  copycoord3d(gg1->maxtransf,&(gg2->maxtransf));
  copygolinesettings(gg1->ls1,&(gg2->ls1));
  copygolinesettings(gg1->ls2,&(gg2->ls2));
  copygofillsettings(gg1->fs1,&(gg2->fs1));
  copygofillsettings(gg1->fs2,&(gg2->fs2));
  copygotextsettings(gg1->ts1,&(gg2->ts1));
  copygotextsettings(gg1->ts2,&(gg2->ts2));
  /* Copy graphic primitives from stacks (...)->primitives and
  (...)->extraprimitives: */
  copystackspec(gg1->primitives,&(gg2->primitives),
                (void (*) (void **)) dispgoprimitive,
                (void *(*) (void *,void **)) copygoprimitive);
  copystackspec(gg1->extraprimitives,&(gg2->extraprimitives),
                (void (*) (void **)) dispgoprimitive,
                (void *(*) (void *,void **)) copygoprimitive);
  /* Copy the contained groups: */
  copystackspec(gg1->groups,&(gg2->groups),
                (void (*) (void **)) dispgogroup,
                (void *(*) (void *,void **)) copygogroup);
  /* Arrange that pointers (...)->grp on the contained groups and primitives
  point to gg2: */
  if (gg2->groups!=NULL)
    for (i=1;i<=gg2->groups->n;++i)
    {
      gg=gg2->groups->s[i];
      gg->grp=gg2;
    }
  if (gg2->primitives!=NULL)
    for (i=1;i<=gg2->primitives->n;++i)
    {
      gp=gg2->primitives->s[i];
      gp->grp=gg2;
    }
  if (gg2->extraprimitives!=NULL)
    for (i=1;i<=gg2->extraprimitives->n;++i)
    {
      gp=gg2->extraprimitives->s[i];
      gp->grp=gg2;
    }
  gg2->grp=NULL;

  /* To be implemented:
  Set pointers on the stacks (...)->before and (...)->after of the contained
  primitives! */
  return gg2;
} else
  return NULL;
}



gogroup copygogroup(gogroup gg1,gogroup *gg2)
    /* Returns a copy of the gg1. If gg2 is different than NULL then gg1 is
    copied to *gg2 and *gg2 returned, otherwise a dynamic copy of gg1 is made
    and returned.
    $A Igor nov03; */
{
gogroup ret;
if (gg2!=NULL)
{
  /* If gg2!=NULL, then gg1 is copied to *gg2: */
  if (gg1==NULL)
  {
    dispgogroup(gg2);
  } else
  {
    /* If *gg2==NULL, we allocate it: */
    if (*gg2==NULL)
      *gg2=newgogroup();
    /* Copying contents: */
    copygogroup0(gg1,*gg2);
  }
  return *gg2; /* since gg2!=NULL. */
} else
{
  /* gg2==NULL, a new object is created that is a copy of gg1 and returned */
  if (gg1==NULL)
    return NULL;
  else
  {
    ret=newgogroup();
    copygogroup0(gg1,ret);
    return ret;
  }
}
}


    /* LIMITS OF GRAPHIC GROUPS: */

void printframe3d(frame3d frame)
    /* Prints limits in x, y and z direction that are stored in frame.
    $A Igor avg01 sep03; */
{
if (frame==NULL)
  printf("Frame is NULL.\n");
else
{
  printf ("Interval spans in X from %-10lg to %-10lg\n",frame->min.x,frame->max.x);
  printf ("Interval spans in Y from %-10lg to %-10lg\n",frame->min.y,frame->max.y);
  printf ("Interval spans in Z from %-10lg to %-10lg\n",frame->min.z,frame->max.z);
}
}


void calcgogroupframe0(gogroup gg,frame3d frame)
    /* Extends the limits stored in frame so that they include co-ordinates of all
    graphic objects that are loaded on the group gg and all its sub-groups. Non-
    tansformed co-ordinates are taken into account.
    $A Igor avg01 sep03; */
{
static coord3d coord;
static goprimitive gp;
int i,j;
if (frame==NULL)
{
  errfunc0("calcgogroupframe0");
  fprintf(erf(),"Frame pointer is NULL.\n");
  errfunc2();
  return;
}
if (gg!=NULL)
{
  /* printf("\nPrimitives:\n"); */
  if (gg->primitives!=NULL)
  {
    for (i=1;i<=gg->primitives->n;++i)
    {
      if ((gp=gg->primitives->s[i])!=NULL)
        if (gp->coord!=NULL)
        {
          for (j=1;j<=gp->coord->n;++j)
            if ((coord=gp->coord->s[j])!=NULL)
            {
              /* printf("."); */
              if (coord->x<frame->min.x)
                frame->min.x=coord->x;
              if (coord->x>frame->max.x)
                frame->max.x=coord->x;
              if (coord->y<frame->min.y)
                frame->min.y=coord->y;
              if (coord->y>frame->max.y)
                frame->max.y=coord->y;
              if (coord->z<frame->min.z)
                frame->min.z=coord->z;
              if (coord->z>frame->max.z)
                frame->max.z=coord->z;
            }
        }
    }
  }
  /* printf("\nExtra primitives:\n"); */
  if (gg->extraprimitives!=NULL)
  {
    for (i=1;i<=gg->extraprimitives->n;++i)
    {
      if ((gp=gg->extraprimitives->s[i])!=NULL)
        if (gp->coord!=NULL)
        {
          for (j=1;j<=gp->coord->n;++j)
          {
            if ((coord=gp->coord->s[j])!=NULL)
            {
              /* printf("."); */
              if (coord->x<frame->min.x)
                frame->min.x=coord->x;
              if (coord->x>frame->max.x)
                frame->max.x=coord->x;
              if (coord->y<frame->min.y)
                frame->min.y=coord->y;
              if (coord->y>frame->max.y)
                frame->max.y=coord->y;
              if (coord->z<frame->min.z)
                frame->min.z=coord->z;
              if (coord->z>frame->max.z)
                frame->max.z=coord->z;
            }
          }
        }
    }
  }
  /* printf("\n"); */
  if (gg->groups!=NULL)
    for (i=1;i<=gg->groups->n;++i)
      calcgogroupframe0(gg->groups->s[i],frame);
}
}



void calcgogroupframe(gogroup gg,frame3d frame)
    /* Calculates limits of coordinates of all graphic objects contained in the
    graphic group gg and its sub-groups and stores them in frame (which must point
    to appropriate allocated memory space).
      If the lower and the upper limits of the frame are all 0 then first the
    lower limits are set to to positive and upper limits to negative numbers with
    very large absolute value. Then calcgogroupframe0() is called. Non-transformed
    co-ordinates of graphic objects are taken into account.
    $A Igor avg01 sep03; */
{
if (frame==NULL)
{
  errfunc0("calcgogroupframe");
  fprintf(erf(),"Frame pointer is NULL.\n");
  errfunc2();
} else
{
  if (frame->min.x==frame->max.x && frame->min.y==frame->max.y && frame->min.z==frame->max.z )
  {
    /* If limits are not yet set then set them to some initial value: */
    frame->min.x=frame->min.y=frame->min.z=DBL_MAX/3.0;
    frame->max.x=frame->max.y=frame->max.z=-(DBL_MAX/3.0);
  }
  /* printf("Frame before calculation:\n"); printframe3d(frame); */
  calcgogroupframe0(gg,frame);
  if (frame->max.x<frame->min.x)
    frame->min.x=frame->min.y=frame->min.z=
     frame->max.x=frame->max.y=frame->max.z=0;
}
}








               /***********************************/
               /* CONSTRUCTION OF GRAPHIC OBJECTS */
               /***********************************/



void goupdatelimits(coord3d p,gogroup gg)
    /* If necessary, extends the limits on gg (gg->min in gg->max) in such a way
    that also the point with the co-ordinates p falls within the limits.
     $A Igor <== avg01 sp03; */
{
if (p!=NULL)
{
  if (gg->min==NULL || gg->max==NULL)
  {
    if (gg->min!=NULL)
      free(gg->min);
    gg->min=malloc(sizeof(*gg->min));
    if (gg->max!=NULL)
      free(gg->max);
    gg->max=malloc(sizeof(*gg->max));
    gg->min->x=gg->max->x=p->x;
    gg->min->y=gg->max->y=p->y;
    gg->min->z=gg->max->z=p->z;
  } else
  {
    if (p->x<gg->min->x)
      gg->min->x=p->x;
    else if (p->x>gg->max->x)
      gg->max->x=p->x;
    if (p->y<gg->min->y)
      gg->min->y=p->y;
    else if (p->y>gg->max->y)
      gg->max->y=p->y;
    if (p->z<gg->min->z)
      gg->min->z=p->z;
    else if (p->z>gg->max->z)
      gg->max->z=p->z;
  }
}
}


void goupdatetransflimits(coord3d p,gogroup gg)
    /* If necessary, extends the limits of transformed co-ordinates of the group
    gg (gg->mintransf in gg->maxtransf) in such a way that also the point with
    the transformed co-ordinates p falls within the limits.
    $A Igor apr97 sep03; */
{
if (p!=NULL)
{
  if (gg->mintransf==NULL || gg->maxtransf==NULL)
  {
    if (gg->mintransf!=NULL)
      free(gg->mintransf);
    gg->mintransf=malloc(sizeof(*gg->mintransf));
    if (gg->maxtransf!=NULL)
      free(gg->maxtransf);
    gg->maxtransf=malloc(sizeof(*gg->maxtransf));
    gg->mintransf->x=gg->maxtransf->x=p->x;
    gg->mintransf->y=gg->maxtransf->y=p->y;
    gg->mintransf->z=gg->maxtransf->z=p->z;
  } else
  {
    if (p->x<gg->mintransf->x)
      gg->mintransf->x=p->x;
    else if (p->x>gg->maxtransf->x)
      gg->maxtransf->x=p->x;
    if (p->y<gg->mintransf->y)
      gg->mintransf->y=p->y;
    else if (p->y>gg->maxtransf->y)
      gg->maxtransf->y=p->y;
    if (p->z<gg->mintransf->z)
      gg->mintransf->z=p->z;
    else if (p->z>gg->maxtransf->z)
      gg->maxtransf->z=p->z;
  }
}
}



void goupdatelimitsgrouptree(gogroup gg)
    /* Recursively extends limits on gg in such a way that new limits include
    all sub-groups of graphic objects on gg.
    $A Igor apr97 sep03; */
{
gogroup ref;
int i;
if (gg!=NULL)
{
  if (gg->groups!=NULL)
    if (gg->groups->n>0)
      for (i=1;i<=gg->groups->n;++i)
      {
        ref=(gogroup) gg->groups->s[i];
        if (ref!=NULL)
        {
          goupdatelimitsgrouptree(ref);
          goupdatelimits(ref->min,gg);
          goupdatelimits(ref->max,gg);
        }
      }
  gg->limitsset=1;
}
}



goprimitive goaddline(coord3d p1,coord3d p2,stack st,gogroup grp)
    /* Adds a graphic primitive that represents a line from the point with
    co-ordinates p1 to the point with co-ordinates p2 to the stack st. The
    containing group of the primitive is set to grp.
    $A Igor <== sep03; */
{
coord3d p=NULL;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='l';
*/
ret->type=SG_PR_LINE;
ret->coord=newstack(2);
p=malloc(sizeof(*p)); *p=*p1; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p2; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
goupdatelimits(p2,grp);
ret->grp=grp;
pushstack(st,ret);
return ret;
}



goprimitive goaddlinediv(coord3d p1,coord3d p2,stack st,gogroup grp,int num)
    /* Adds a line from the point with co-ordinates p1 to the point with co-
    ordinates p2 composed from num smaller lines (graphical primitives) to
    the stack st. The containing group of the primitives is set to grp.
    $A Igor <== sep03; */
{
_coord3d step,point1,point2;
goprimitive ret=NULL;
int i;
if (num<1)
  num=1;
step.x=(p2->x-p1->x)/((double) num);
step.y=(p2->y-p1->y)/((double) num);
step.z=(p2->z-p1->z)/((double) num);
point2=*p1;
for (i=1;i<=num;++i)
{
  point1=point2;
  point2.x=p1->x+((double)i)*step.x;
  point2.y=p1->y+((double)i)*step.y;
  point2.z=p1->z+((double)i)*step.z;
  ret=goaddline(&point1,&point2,st,grp);
}
return ret;
}


goprimitive goaddtriangle(coord3d p1,coord3d p2,coord3d p3,stack st,gogroup grp)
    /* Adds a graphic primitive that represents a triangle made of lines with
    apices p1, p2 and p3, to the stack st. The containing group of the
    primitive is set to grp.
    $A Igor <== sep03; */
{
coord3d p=NULL;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='3';
*/
ret->type=SG_PR_TRI;
ret->coord=newstack(2);
p=malloc(sizeof(*p)); *p=*p1; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p2; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p3; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
goupdatelimits(p2,grp);
goupdatelimits(p3,grp);
ret->grp=grp;
pushstack(st,ret);
return ret;
}



goprimitive goaddfilltriangle(coord3d p1,coord3d p2,coord3d p3,stack st,gogroup grp)
    /* Adds a graphic primitive that represents a filled triangle  with apices
    p1, p2 and p3, to the stack st. The containing group of the primitive is
    set to grp.
    $A Igor <== sep03; */
{
coord3d p=NULL;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='3';
ret->i2='f';
*/
ret->type=SG_PR_F_TRI;
ret->coord=newstack(2);
p=malloc(sizeof(*p)); *p=*p1; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p2; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p3; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
goupdatelimits(p2,grp);
goupdatelimits(p3,grp);
ret->grp=grp;
pushstack(st,ret);
return ret;
}



goprimitive goaddbordtriangle(coord3d p1,coord3d p2,coord3d p3,stack st,gogroup grp)
    /* Adds a graphic primitive that represents a filled and bordered triangle
    with apices p1, p2 and p3, to the stack st. The containing group of the
    primitive is set to grp.
    $A Igor <== sep03; */
{
coord3d p=NULL;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='3';
ret->i2='b';
*/
ret->type=SG_PR_FB_TRI;
ret->coord=newstack(2);
p=malloc(sizeof(*p)); *p=*p1; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p2; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p3; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
goupdatelimits(p2,grp);
goupdatelimits(p3,grp);
ret->grp=grp;
pushstack(st,ret);
return ret;
}



goprimitive goaddpartbordtriangle(coord3d p1,coord3d p2,coord3d p3,
            char b1,char b2, char b3,stack st,gogroup grp)
    /* Adds a graphic primitive that represents a filled and partially
    bordered triangle  with apices p1, p2 and p3, to the stack st. b1, b2 and
    b3 indicate whether the corresponding border lines will be drawn (they are
    copied to a string of characters (...)->props3, if at least one of them is
    different than 0, otherwise (...)->props3 remains NULL.
    $A Igor <== sep03; */
{
coord3d p=NULL;
char *bordflags=NULL;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='3';
ret->i2='p';
*/
ret->type=SG_PR_FP_TRI;
ret->coord=newstack(2);
p=malloc(sizeof(*p)); *p=*p1; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p2; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p3; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
goupdatelimits(p2,grp);
goupdatelimits(p3,grp);
ret->grp=grp;
if (b1 || b2 || b3)
{
  bordflags=malloc(3*sizeof(b1));
  bordflags[0]=b1; bordflags[1]=b2; bordflags[2]=b3;
  ret->props3=bordflags;
}
pushstack(st,ret);
return ret;
}



goprimitive goaddfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                           stack st,gogroup grp)

    /* Adds a graphic primitive that represents a fourangle compoded of lines
    with apices
    p1, p2, p3 and p4, to the stack st. The containing group of the primitive
    is set to grp.
    $A Igor <== sep03; */
{
coord3d p=NULL;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='4';
*/
ret->type=SG_PR_FOUR;
ret->coord=newstack(2);
p=malloc(sizeof(*p)); *p=*p1; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p2; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p3; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p4; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
goupdatelimits(p2,grp);
goupdatelimits(p3,grp);
goupdatelimits(p4,grp);
ret->grp=grp;
pushstack(st,ret);
return ret;
}



goprimitive goaddfillfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                           stack st,gogroup grp)
    /* Adds a graphic primitive that represents a filled fourangle  with apices
    p1, p2 and p3 and p4, to the stack st. The containing group of the
    primitive is set to grp.
    $A Igor <== sep03; */
{
coord3d p=NULL;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='4';
ret->i2='f';
*/
ret->type=SG_PR_F_FOUR;
ret->coord=newstack(2);
p=malloc(sizeof(*p)); *p=*p1; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p2; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p3; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p4; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
goupdatelimits(p2,grp);
goupdatelimits(p3,grp);
goupdatelimits(p4,grp);
ret->grp=grp;
pushstack(st,ret);
return ret;
}



goprimitive goaddbordfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                           stack st,gogroup grp)
    /* Adds a graphic primitive that represents a filled and bordered fourangle
    with apices p1, p2 and p3 and p4, to the stack st. The containing group of
    the primitive is set to grp.
    $A Igor <== sep03; */
{
coord3d p=NULL;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='4';
ret->i2='b';
*/
ret->type=SG_PR_FB_FOUR;
ret->coord=newstack(2);
p=malloc(sizeof(*p)); *p=*p1; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p2; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p3; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p4; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
goupdatelimits(p2,grp);
goupdatelimits(p3,grp);
goupdatelimits(p4,grp);
ret->grp=grp;
pushstack(st,ret);
return ret;
}



goprimitive goaddpartbordfourangle(coord3d p1,coord3d p2,coord3d p3,coord3d p4,
                         char b1,char b2, char b3,char b4,stack st,gogroup grp)
    /* Adds a graphic primitive that represents a filled and partially
    bordered fourangle  with apices p1, p2, p3 and p4, to the stack st. b1, b2,
    b3 and b4 indicate whether the corresponding border lines will be drawn
    (they are copied to a string of characters (...)->props3, if at least one
    of them is differentthan 0, otherwise (...)->props3 remains NULL.
    $A Igor <== sep03; */
{
coord3d p=NULL;
char *bordflags=NULL;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='4';
ret->i2='p';
*/
ret->type=SG_PR_FP_FOUR;
ret->coord=newstack(2);
p=malloc(sizeof(*p)); *p=*p1; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p2; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p3; pushstack(ret->coord,p);
p=malloc(sizeof(*p)); *p=*p4; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
goupdatelimits(p2,grp);
goupdatelimits(p3,grp);
goupdatelimits(p4,grp);
ret->grp=grp;
if (b1 || b2 || b3 || b4)
{
  bordflags=malloc(4*sizeof(b1));
  bordflags[0]=b1; bordflags[1]=b2; bordflags[2]=b3; bordflags[3]=b4;
  ret->props3=bordflags;
}
pushstack(st,ret);
return ret;
}



goprimitive goaddmarker(coord3d p1,double size,int kind,stack st,gogroup grp)
    /* Adds a graphic primitive that represents a marker at co-ordinates p1,
    to the stack st. size is the requested size and kind the requested type
    of the marker.
    $A Igor <== sep03; */
{
coord3d p;
double *markersize;
int *markerkind;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='m';
*/
ret->type=SG_PR_MARK;
ret->coord=newstack(1);
p=malloc(sizeof(*p));  *p=*p1; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
ret->grp=grp;
markersize=malloc(sizeof(*markersize));
*markersize=size;
ret->props3=markersize;
markerkind=malloc(sizeof(*markerkind));
*markerkind=kind;
ret->props4=markerkind;
pushstack(st,ret);
return ret;
}



goprimitive goaddarrow(coord3d p1,coord3d p2,double size,
                       double tgangle,int attr,
                       stack st,gogroup grp)
    /* Adds a graphic primitive that represents an arrow from the point p1 to
    the point p2, to the stack stck st. Gtoup of the containing primitive is
    set to grp. size must be the size of the head (either relative to the size
    of the graph or relative to the size of the arrow, dependent on attr),
    tgangle is the tangens of a half-angle between the head and the basic
    line, and attr must contain line attributes understood by sg_arrow().
    $A igor sep03; */
{
coord3d p;
double *psize;
int *pattr;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='a';
ret->i2='0';
ret->i3='0';
ret->i4='0';
*/
ret->type=SG_PR_ARROW;
ret->coord=newstack(2);
p=malloc(sizeof(*p));  *p=*p1; pushstack(ret->coord,p);
p=malloc(sizeof(*p));  *p=*p2; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
ret->grp=grp;
psize=malloc(2*sizeof(*psize));
psize[0]=size;
psize[1]=tgangle;
ret->props3=psize;
pattr=malloc(sizeof(*pattr));
*pattr=attr;
ret->props4=pattr;
pushstack(st,ret);
return ret;
}


goprimitive goaddtext(char *str,coord3d p1,stack st,gogroup grp)
    /* Adds a graphic primitive that represent a text string str at
    co-ordinates p2, to the stack st. The containing grou of the primitive is
    set to grp.
    $A Igor <== sep03; */
{
coord3d p=NULL;
goprimitive ret=NULL;
ret=newgoprimitive();
/*
ret->i1='t';
*/
ret->type=SG_PR_TEXT;
ret->coord=newstack(1);
ret->props1=stringcopy(str);
p=malloc(sizeof(*p)); *p=*p1; pushstack(ret->coord,p);
goupdatelimits(p1,grp);
ret->grp=grp;
pushstack(st,ret);
return ret;
}



void goloadtostack(gogroup gg,stack st)
    /* Loads the graphic object or group of graphic objects pointed to by gg,
    to the stack st. All primitives that are on the stacks  gg->primitives
    of gg and all its sub-trees are loaded to st.
    $A Igor <== sep03; */
{
int i;
if (st!=NULL && gg!=NULL)
{
  if (gg->groups!=NULL)
    if (gg->groups->n>0)
      for (i=1;i<=gg->groups->n;++i)
        goloadtostack((gogroup) gg->groups->s[i],st);
  if (gg->primitives!=NULL)
    if (gg->primitives->n>0)
      for (i=1;i<=gg->primitives->n;++i)
        pushstack(st,gg->primitives->s[i]);
}
}



