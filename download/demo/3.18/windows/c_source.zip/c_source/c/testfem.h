/* MANIPULACIJA Z UPORABNISKO DEFINIRANIMI SPREMENLJIVKAMI */





#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <stddef.h>

#include <mtypes.h>
#include <rf.h>
#include <st.h>
#include <vec.h>
#include <mat.h>
#include <matrixop.h>
#include <strop.h>
#include <er.h>
#include <rf.h>
#include <globut.h>
#include <mtime.h>
#include <itk.h>

#include <fem.h>
#include <limfunc.h>
#include <approx.h>
#include <invfeap.h>  /* For mesh transformed were moved there */

#include <sg_draw.h>
#include <sg_obj.h>
#include <sg_graph.h>




double fxy(double x,double y)
{
  return (sin(x)*sin(y));
}


main()
{
  FILE *fp=NULL;
  femesh fmcell=NULL,fm=NULL;

if (0)
{
  tesmatrixop();
  exit(0);
}

if (1)
{
  testapprox();
  exit(0);
}



if (0)   /* BRANJE MREZ KONCNIH ELEMENTOV */
{
  double t0=0,t1=0,t2=0,t3=0,t4=0,t5=0,t6=0,ct0=0,ct1=0,ct2=0,ct3=0,ct4=0,ct5=0,ct6=0;
  t0=absolutetime();  ct0=cputime();
 
  /*
  fp=fopen("../pr/dam/d/mikrounstr.dat","rb");
  fp=fopen("../pr/dam/micro_coarse.dat","rb");
  */
  fp=fopen("../pr/dam/mreza_coarse.dat","rb");
  system("pwd");
  freadelfmesh(fp,&fmcell);
  printf("\n\n\n");
  
  t1=absolutetime(); ct1=cputime();
  printf("\n\nReading mesh.: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);
  
    
  /*
  fp=fopen("d/mreza_unstr.dat","rb");
  fp=fopen("d/ravne.dat","rb");
  printf("\n\nMesh after reading:\n\n");
  printf("Printing is skipped.\n");
  */
  
  
  readelsurftopgrpsafe("../pr/dam/d/",NULL,fmcell);

  
  plotmesh(fmcell,30,60,NULL,NULL,0);
  printf("Press <Enter> to continue!\n");
  getchar();


  /*
  femcalcelnuminv(fmcell);
  femcalceltopinv(fmcell);
  */

  t3=absolutetime(); ct3=cputime();
  printf("\n\nCalc. inv. elnum and topol.: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t3-t0,ct3-ct0,t3-t2,ct3-ct2);

  femcalcoutsurf(fmcell,0);

  
  t4=absolutetime(); ct4=cputime();
  printf("\n\nCalc. out. surf.: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t4-t0,ct4-ct0,t4-t3,ct4-ct3);

  printf("\n\n\n");
  /*
  printelgrp(fmcell,fmcell->elgrp->s[3]);
  identifyfemeshsurfgrp(fmcell);
  printfemesh(fmcell);
  printelsurftopgrp(fmcell);
  */

  if (fmcell==NULL)
  {
    errfunc0("main");
    sprintf(ers(),"The mesh cell was not read correctly, exit the program.\n");
    errfunc2();
    exit(-1);
  } else
    copymatrix(fmcell->nodcoord,&(fmcell->origcoord));
  

}




if (0)  /* TEST OF LIMITING FUNCTIONS: */
{
  double min,max,d,h,x,y;
  int i,div;
  min=2;
  max=5;
  d=0.4;
  div=100;
  h=(max-min-2*d)/(div);
  printf("min = %g\nmax=%g \nd=%g\n",min,max,d);
  printf("%10s %10s %10s %10s\n","x","lim","der lim","inv(lim)");
  for (i=-10;i<=div+10;++i)
  {
    x=min+d+h*(double) i;
    y=limfuncexpid(x,min,max,d);
    printf("%10g %10g %10g %10g\n",x,y,derlimfuncexpid(x,min,max,d),
      invlimfuncexpid(y,min,max,d));
  }
  printf("At min-2*d:\n");
  x=min-2*d;
  y=limfuncexpid(x,min,max,d);
  printf("%10g %10g %10g %10g\n",x,y,derlimfuncexpid(x,min,max,d),
    invlimfuncexpid(y,min,max,d));
  printf("At min-d:\n");
  x=min-d;
  y=limfuncexpid(x,min,max,d);
  printf("%10g %10g %10g %10g\n",x,y,derlimfuncexpid(x,min,max,d),
    invlimfuncexpid(y,min,max,d));
  printf("At min:\n");
  x=min;
  y=limfuncexpid(x,min,max,d);
  printf("%10g %10g %10g %10g\n",x,y,derlimfuncexpid(x,min,max,d),
    invlimfuncexpid(y,min,max,d));
  printf("At min+d:\n");
  x=min+d;
  y=limfuncexpid(x,min,max,d);
  printf("%10g %10g %10g %10g\n",x,y,derlimfuncexpid(x,min,max,d),
    invlimfuncexpid(y,min,max,d));
  printf("At max-d:\n");
  x=max-d;
  y=limfuncexpid(x,min,max,d);
  printf("%10g %10g %10g %10g\n",x,y,derlimfuncexpid(x,min,max,d),
    invlimfuncexpid(y,min,max,d));
  printf("At max:\n");
  x=max;
  y=limfuncexpid(x,min,max,d);
  printf("%10g %10g %10g %10g\n",x,y,derlimfuncexpid(x,min,max,d),
    invlimfuncexpid(y,min,max,d));
  printf("At max+d:\n");
  x=max+d;
  y=limfuncexpid(x,min,max,d);
  printf("%10g %10g %10g %10g\n",x,y,derlimfuncexpid(x,min,max,d),
    invlimfuncexpid(y,min,max,d));
  printf("At max+2*d:\n");
  x=max+2*d;
  y=limfuncexpid(x,min,max,d);
  printf("%10g %10g %10g %10g\n",x,y,derlimfuncexpid(x,min,max,d),
    invlimfuncexpid(y,min,max,d));
  exit(0);
}






printf("Press <Enter> to continue!\n");
getchar();




/* PLOTTING FE MESHES */
if (1)
{
  double fi=30,theta=15,hfi=5,htheta=2;
  double t0=0,t1=0,t2=0,t3=0,t4=0,t5=0,t6=0,ct0=0,ct1=0,ct2=0,ct3=0,ct4=0,ct5=0,ct6=0;
  int win,win1,numx=20,divx=5; int numy=20,divy=5;
  int i=0,j=0,k=0,l=0;
  frame3d winlimits=NULL,frame=NULL;
  golinesettings ls;
  gofillsettings fs;
  gotextsettings ts;
  gogroup g1=NULL,g2=NULL,g3=NULL,g4=NULL,g5=NULL;
  stack st=NULL;

  vector param=NULL,transparam=NULL,
    mincoord=NULL,maxcoord=NULL
    /* ,
    mincoord1=NULL,maxcoord1=NULL,maxsmall=NULL,maxlarge=NULL */
    ;
  double relphase,phase,whichwin;


  int id1=1,id2=2;
  char *res=NULL;
  int code=0;



  sg_interface(SG_PLOT_BASIC);



  t0=absolutetime(); ct0=cputime();  /* Time measurement: */
  printf("\n\n");



  /* Odprtje okna: */
  /* giinitdisplay();  */
  sg_setwindowtitle("Mreza");
  sg_setwindowxpos(0.35f); sg_setwindowypos(0.f);
  sg_setwindowwidth((float) 0.75f); sg_setwindowheight((float) 1.0f);
  win=sg_openwindow();
  sg_setwindowtitle("SGS 1");
  win1=sg_openwindow();


  /*
  giinitgraph();
  */

  /* Locljivost grafa: */
  numx=10; divx=1; numy=10; divy=1;

  /* Okvir v oknu, v katerega naj pade graf: */
  winlimits=malloc(sizeof(*winlimits));
  winlimits->min.x=0.1; winlimits->min.y=0.0; winlimits->max.x=0.7; winlimits->max.y=0.8;
  /* Geometrijske meje grafa: */
  frame=malloc(sizeof(*frame));
  frame->min.x=-1.3;    frame->min.y=-1.3;    frame->min.z=-1.3;
  frame->max.x=1.3;     frame->max.y=1.3;     frame->max.z=1.3;


  /* Nastavitve za risanje crt: */
  ls=malloc(sizeof(*ls));
  ls->color.red=(float) 0; ls->color.green=(float) 0.7; ls->color.blue=(float) 0.4;
  ls->linewidth=1;
  ls->linetype=1;

  /* Nastavitve za risanje ploskev: */
  fs=malloc(sizeof(*fs));
  fs->color.red=0; fs->color.green=0; fs->color.blue=1;

  /* Nastavitve za risanje teksta: */
  ts=malloc(sizeof(*ts));
  ts->color.red=(float) 0.5; ts->color.green=(float) 0.1; ts->color.blue=(float) 0.7;
  ts->font=1;
  ts->height=0.01;
  ts->expansion=1;
  ts->xalignment=0;
  ts->yalignment=0;


  t1=absolutetime(); ct1=cputime();
  printf("Preparation: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);


  /* Sestava Graficnih objektov: */
  /* Okvir in ravnila: */
  /*
  g1=gomakeframe3d(frame,ls,ls,numx*divx+numy*divy,numx*divx+numy*divy,
                   numx*divx+numy*divy);
  g2=gomakerulers3d(frame,ls,ls,ls,10,0.02,0.06,0.1);
  g3=gomakerulertext3d(frame,ts,6,10,3,0.1);
  */

  /* Surface plot:
  g4=gosurfaceplot(fxy,numx,divx,numy,divy,frame,fs,ls,3,2);
  */

  
  t2=absolutetime(); ct2=cputime();
  printf("Rulers etc.: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t2-t0,ct2-ct0,t2-t1,ct2-ct1);
  
  /*
  param=getvector(4);
  param->v[1]=0.0; param->v[2]=0.2; param->v[3]=0.1;  param->v[4]=0.2;
  transffemesh(fmcell,0,param,transform1);
  */

  prepcelldata(fmcell,0);
  
  t3=absolutetime(); ct3=cputime();
  printf("\n\nGraphs:      %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t3-t0,ct3-ct0,t3-t2,ct3-ct2);

  g5=NULL;

  st=newstack(100);

  goloadtostack(g1,st);
  goloadtostack(g2,st);
  goloadtostack(g3,st);
  /*
  goloadtostack(g4,st);
  goloadtostack(g5,st);
  */
  

  t4=absolutetime(); ct4=cputime();
  printf("Loading:     %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t4-t0,ct4-ct0,t4-t3,ct4-ct3);


  /* Plotting: */
  whichwin=0;
  i=-1;
  while (i<500)
  {
    
    ++i;     relphase=(double) i/30;  phase=relphase*2*ConstPi;
    printf("\n\n");

    

    /*
    rpfunc=rpsin;
    dispvector(&param);
    param=getvector(6);
    param->v[1]=phase;
    param->v[2]=0.05+0.9*(0.5-0.5*sin(0.5*phase*1.6));
    param->v[3]=0.5-0.5*sin(0.5*phase*0.8);
    param->v[4]=0.5-0.5*sin(0.5*phase*1.5);
    param->v[5]=0.5-0.5*sin(0.5*phase);
    param->v[6]=0.5-0.5*sin(0.5*phase*1.25);
    if (0)
    {
      printf("\n\n\ni: %i,relphase: %g, phase: %g\nParameters:\n",
        i,relphase,phase);
      printvector(param);
      printf("\n\n");
    }
    */
    t0=absolutetime();  ct0=cputime();

    rpfunc=rpellipse;
    dispvector(&param);
    param=getvector(3);
    param->v[1]=0.5-0.5*sin(0.5*phase*0.8); 
    param->v[2]=0.5-0.5*sin(0.5*phase*1.25);
    param->v[1]=limfuncexpid(param->v[1],0.1,0.8,0.1);
    param->v[2]=limfuncexpid(param->v[2],0.1,0.8,0.1);
    param->v[2]=limfuncexpid(param->v[2],
      0.4*param->v[1],2.2*param->v[1],0.1*fabs(param->v[1]));
    param->v[3]=phase;
    
    transffemesh(fmcell,0,0,param,transfcellradstrech);
    
    t1=absolutetime();  ct1=cputime();
    printf("Transf. mesh cell:      %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t1-t0,ct1-ct0,t1-t0,ct1-ct0);


    if (1)
    {
      fm=fmcell;
    } else
    {
      if (1)
      {
        dispfemesh(&fm);
        addfemesh(fmcell,&fm,0,-10.);
        /* Set-up translation parameter: */
        dispvector(&transparam);
        transparam=getvector(2);
        transparam->v[1]=2 /* cell_d */;    transparam->v[2]=0.;
        transffemesh(fmcell,0,0,transparam,translationtransform);
      
        addfemesh(fmcell,&fm,0,-1.e-6);
      
      } else
      {
        /* 
        fm=fmcell; 
        */
        dispfemesh(&fm);
        femgrid(fmcell,&fm,0,1.0e-6,2,2,1,NULL,NULL);
      }
    }
    


    t2=absolutetime();  ct2=cputime();
    printf("\nCreating grid of cells:  %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t2-t0,ct2-ct0,t2-t1,ct2-ct1);

    /* Write the mesh for FEAP: */
    filewritemeshfeap("0FEAP.txt",fm);



    t3=absolutetime();  ct3=cputime();
    printf("\nFEAP output:  %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t3-t0,ct3-ct0,t3-t2,ct3-ct2);

    /* Mesh plot: */
    st->n=0;
    dispgogroup(&g2);
    dispgogroup(&g3);
    ts->height=0.008;
    if (0)
    {
      /* Plot only two groups of the mesh: */
      g2=gofemeshplotbas(fm,1,
            0,1,0,0,
            0,0,0,
            /*
            fs,ls,
            ts,ts,
            ls,
            */
            NULL,NULL,ts,NULL,NULL,
            2,0);
    
    fs->color.red=0.8f; fs->color.green=1; fs->color.blue=1;
    g3=gofemeshplotbas(fm,2,
            0,1,0,0,
            0,0,0,
            /*
            fs,ls,
            ts,ts,
            ls,
            */
            fs,NULL,ts,NULL,NULL,
            2,0);
    } else
    {
      /* Plot only two groups of the mesh: */
      g2=gofemeshplotbas(fm,0,
            0,1,0,0,
            0,0,0,
            /*
            fs,ls,
            ts,ts,
            ls,
            */
            NULL,NULL,ts,NULL,NULL,
            2,0);
    }


    t4=absolutetime();  ct4=cputime();
    printf("\nCreating graph:  %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t4-t0,ct4-ct0,t4-t3,ct4-ct3);



    if (1)
    {
      /* Add a text describing parameter values to the graph: */
      int i;
      char buf[100],*pos=buf;
      _coord3d pp1={0};
      vector mincoord=NULL,maxcoord=NULL;
      gotextsettings ts;
      pos+=sprintf(pos,"p = { ");
      if (param!=NULL)
        for (i=1;i<=param->d;++i)
        {
          pos+=sprintf(pos,"%g",param->v[i]);
          if (i<param->d)
            pos+=sprintf(pos,", ");
          else
            pos+=sprintf(pos," }");
        }
      
      if (g2!=NULL)
        /*
        if (g2->groups!=NULL)
          if (g2->groups->n>0)
          */
          {
            if (g2->ts1==NULL)
            {
              /* Text settings: */
              ts=malloc(sizeof(*ts));
              ts->color.red=(float) 0.5; ts->color.green=(float) 0.1; ts->color.blue=(float) 0.7;
              ts->font=1;
              ts->height=0.01;
              ts->expansion=1;
              ts->xalignment=0;
              ts->yalignment=0;
              g2->ts1=ts;
              ts=NULL;
            }
            /* Calc. mesh co-ordinate limits: */
            femcalcgrplimits(fm,0,&mincoord,&maxcoord);
            pp1.x=(mincoord->v[1]+maxcoord->v[1])/2;
            if (mincoord->d==2)
              pp1.y=maxcoord->v[2]+0.08*(maxcoord->v[2]-mincoord->v[2]);
            else
              pp1.y=(mincoord->v[2]+maxcoord->v[2])/2;
            if (mincoord->d>2)
              pp1.z=maxcoord->v[3]+0.08*(maxcoord->v[3]-mincoord->v[3]);
            else
              pp1.z=0;
            if (g2->primitives==NULL)
              g2->primitives=newstack(100);
            goaddtext(buf,&pp1,g2->primitives,g2);
          }
      dispvector(&mincoord);
      dispvector(&maxcoord);   
    }
    if (0)
    {
      _coord3d pp1={0},pp2={0};
      gogroup gg1;
      /* Add co-ordinate axes, shorter is in y direction: */
      gg1=g2->groups->s[1];
      pp2.x=6;
      /*
      p1=malloc(sizeof(*p1));
      p2=malloc(sizeof(*p2));
      *p1=pp1;
      *p2=pp2;
      */
      goaddline(&pp1,&pp2,g2->primitives,g2);
      pp2.x=0;
      pp2.y=4;
      /*
      p1=malloc(sizeof(*p1));
      p2=malloc(sizeof(*p2));
      *p1=pp1;
      *p2=pp2;
      */
      goaddline(&pp1,&pp2,g2->primitives,g2);
    }

    calcgogroupframe(g2,frame);
    calcgogroupframe0(g3,frame);
    goloadtostack(g2,st);
    goloadtostack(g3,st);


    t0=absolutetime();  ct0=cputime();
    fi+=hfi; theta+=htheta; /* Nov pogled */
    /* Naatavitev pretvorb iz koordinat objekta v okenske koordinate: */
    preparegraph3dbas(frame,NULL /* winlimits */);
    if (femel2d( femgroup(fm,1), 1) )
      gosettransfsimp(rad(-90),rad(90));
    else
      gosettransfsimp(rad(fi),rad(theta));
  
    t1=absolutetime();  ct1=cputime();
  
    /* Transformacija primitivov na skladu st: */
    gotransfstack(st);
  
    t2=absolutetime();  ct2=cputime();
    printf("Transforming: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t2-t0,ct2-ct0,t2-t1,ct2-ct1);
  
    gosortstack(st);
  
    t3=absolutetime();  ct3=cputime();
    printf("Sorting:      %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t3-t0,ct3-ct0,t3-t2,ct3-ct2);
  
    
    /* Izris: */
    sg_interface(SG_PLOT_BASIC);
    ++whichwin;
    if (whichwin==1)
      sg_setwindow(win);
    else
    {
      sg_setwindow(win1);
      whichwin=0;
    }
    sg_resetwindow();

    t4=absolutetime();  ct4=cputime();
    printf("Reset:        %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t4-t0,ct4-ct0,t4-t3,ct4-ct3);
  
    sg_godrawstack(st);
    sg_raisewindow();

    t5=absolutetime();  ct5=cputime();
    printf("Drawing:      %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t5-t0,ct5-ct0,t5-t4,ct5-ct4);
    

    /*
    sg_interface(SG_PLOT_PS);
    sg_openwindow();
    sg_godrawstack(st);
    sg_closewindow();
    */
    
    /*
    sg_interface(SG_PLOT_TCL);
    sg_openwindow();
    sg_godrawstack(st);
    sg_closewindow();
    */

    t6=absolutetime();  ct6=cputime();
    printf("Drawing to Tcl file: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t6-t0,ct6-ct0,t6-t5,ct6-ct5);

  
    /*
    giflushdisplay();
    */
    /*
    godxffiledrawstack("0.dxf",st);
    printf("Writing finished.\n");
    printf("Writing a Tcl file.\n");
    gotclfiledrawstack("0.tcl",st);
    printf("Writing finished.\n");
    printf("Writing a PostScript file.\n");
    gopsfiledrawstack("0.eps",st);
    printf("Writing finished.\n");
    */

    /*
    sleep(0);
    printf("\nSleep ... ");
    tcl_sleep(0.00);
    printf("... do not sleep any more.\n\n");
    */

  }
}   /* Plotting FE meshes */


printf("\n\nPress <Enter>!\n");
getchar();


}



