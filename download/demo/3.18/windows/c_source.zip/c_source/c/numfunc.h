#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>



#include <mtypes.h>
#include <er.h>
#include <st.h>
#include <vec.h>
#include <mat.h>
#include <rf.h>
#include <rand.h>
#include <numut.h>
#include <strop.h>






/* #include "numrec/lib/dfridr.c" */  /* Funk. za odvajanje v NumRec */
float dfridr(float (*func)(float), float x, float h, float *err);


typedef struct
{
  double x,f,h,x1,f1,x2,f2,er1,er2,
         der,der1,der2,erder,erderprev,erderpost,erdertot,
         sec,sec1,sec2,ersec,ersecprev,ersecpost,ersectot;
} _dertype1;

typedef _dertype1 * dertype1;



void numder12optbas(double x,double f,double h0,double factor,double hmin,
                double (*func)(double),stack *derst0)
    /*
    
    $A Igor jun00; */
{
dertype1 d=NULL,dprev=NULL,dpost=NULL,dprevprev=NULL,dpostpost=NULL;
stack st;
double h,er,erder,f1,f2,h1,h2;
int i,iopt,j;
char reduce=1,end=0,expand=0;


/* Spremenljivke za ortogonalne aproksimacije: */
vector pt3=NULL,pt5=NULL,pt7=NULL,pt9=NULL; /* Vektorji abscis */
vector val3=NULL,val5=NULL,val7=NULL,val9=NULL; /* Vektorji vrednosti funkcije */
matrix ortval3=NULL,ortval5=NULL,ortval7=NULL,ortval9=NULL; /* Vrednosti ort. pol. na tockah */
matrix ortc3=NULL,ortc5=NULL,ortc7=NULL; /* Koeficienti ort. pol. */
vector polort3=NULL,polort4=NULL,polort5=NULL,polort6=NULL,polort7=NULL;  /* Koeficienti lin. komb. ort. pol. (pomozni pod.) */
vector pol3=NULL,pol4=NULL,pol5=NULL,pol6=NULL,pol7=NULL;  /* Koeficienti polinom. aproks. */

pt3=getvector(3); val3=getvector(3);
pt5=getvector(5); pt7=getvector(7); pt9=getvector(9);
val5=getvector(5); val7=getvector(7); val9=getvector(9);


if (factor<=1)
  factor=2;
if (h0<0)
  h=-h0;
else if (h0==0)
  h=0.1;
else
  h=h0;
if (derst0!=NULL)
{
  if (*derst0!=NULL)
    dispstackval(*derst0);
  else
    *derst0=newstack(5);
  st=*derst0;
  pushstack(st,(d=malloc(sizeof(*d))) );
  
  
  d->x=x; d->f=f; d->h=h; d->x1=d->x-d->h; d->x2=d->x+d->h;
  d->f1=func(d->x1); d->f2=func(d->x2);
  d->der1=(d->f-d->f1)/h; d->der2=(d->f2-d->f)/h; d->der=0.5*(d->der1+d->der2);
  d->erder=fabs(d->der1-d->der2);
  d->sec=(d->der2-d->der1)/h;
  
  /*
  printf("x    = %-15.8g f(x)  = %-15.8g h = %-15.8g\n",d->x,d->f,d->h);
  printf("x1   = %-15.8g f(x1) = %-15.8g\n",d->x1,d->f1);
  printf("x2   = %-15.8g f(x2) = %-15.8g\n",d->x2,d->f2);
  printf("der1 = %-15.8g der2  = %-15.8g\n",d->der1,d->der2);
  printf("der  = %-15.8g erder = %-15.8g\n",d->der,d->erder);
  printf("sec  = %-15.8g erder = %-15.8g\n",d->sec,d->erder);
  */
  
  printf("x    = %-15.8g f(x)  = %-15.8g h = %-15.8g\n",d->x,d->f,d->h);
  printf("x1   = %-15.8g f(x1) = %-15.8g\n",d->x1,d->f1);
  printf("x2   = %-15.8g f(x2) = %-15.8g\n",d->x2,d->f2);
  printf("der1 = %-15.8g der2  = %-15.8g\n",d->der1,d->der2);
  printf("der  = %-15.8g erder = %-15.8g\n erderprev = %-15.8g\n",d->der,d->erder,d->erderprev);
  printf("sec  = %-15.8g erder = %-15.8g\n",d->sec,d->erder);
  
  
  
  printf("\n\n");
  end=0;
  /* Krcenje intervala: */
  if (!end)
    printf("Interval shrinkage:\n");
  while(!end)
  {
    h/=factor;
    pushstack(st,(d=malloc(sizeof(*d))) );
    memset(d,0,sizeof(*d));
    if (st->n>1)
    {
      dprev=nstack(st,2);
      if (st->n>2)
        dprevprev=nstack(st,2);
    }
    dpost=dpostpost=NULL;

      
    
    
    printf("\n\n");
    printf("i = %i h = %g\n",st->n,h);
      
    
    d->x=x; d->f=f; d->h=h; d->x1=d->x-d->h; d->x2=d->x+d->h;
    d->f1=func(d->x1); d->f2=func(d->x2);
    d->der1=(d->f-d->f1)/h; d->der2=(d->f2-d->f)/h; d->der=0.5*(d->der1+d->der2);
    d->erder=fabs(d->der1-d->der2);
    if (dprev!=NULL)
    {
      d->erderprev=fabs(d->der-dprev->der);
      dprev->erderpost=d->erderprev;
      if (st->n>=3)
      {
        dprev->erdertot=dprev->erderprev+dprev->erderpost+dprev->erder;
      }
    }
    d->sec=(d->der2-d->der1)/h;
  
    printf("x    = %-15.8g f(x)  = %-15.8g h = %-15.8g\n",d->x,d->f,d->h);
    printf("x1   = %-15.8g f(x1) = %-15.8g\n",d->x1,d->f1);
    printf("x2   = %-15.8g f(x2) = %-15.8g\n",d->x2,d->f2);
    printf("der1 = %-15.8g der2  = %-15.8g\n",d->der1,d->der2);
    printf("der  = %-15.8g erder = %-15.8g  prev=%g\n",d->der,d->erder,d->erdertot);
    printf("(prev= %-15.8g,  prevtot = %.8g)\n",d->erderprev,dprev->erdertot);
    printf("sec  = %-15.8g erder = %-15.8g\n",d->sec,d->erder);
    
    if (dprev!=NULL && dprevprev!=NULL)
      if (d->erder>dprev->erder && d->erderprev>dprev->erderprev)
        end=1;
    
    if (h<hmin)
      end=1;
      
  }
  
  /* Iskanje optimalnega odvoda glede na skupno ocenjeno napako in
  preverjanje, ce je potrebna siritev intervalov: */
  if (st->n>=3)
  {
    iopt=st->n-1;
    d=st->s[iopt];
    erder=d->erdertot; /* d->erder+d->erderprev+d->erderpost */ ;
    printf("\nSearching for the best derivative approximation after shrinking:\n");
    printf("i = %i, er = %10g.\n",iopt,erder);
    for (i=st->n-2;i>1;--i)
    {
      d=st->s[i];
      er=d->erdertot /* d->erder+d->erderprev+d->erderpost */ ;
      
      printf("i = %i, er = %10g, der = %g.\n",i,er,d->der);
    
      if (er<erder)
      {
        erder=er;
        iopt=i;
      }
      
    }
    d=st->s[iopt];
    printf("iopt = %4i, erder = %10g, der = %g, h = %g.\n",iopt,erder,d->der,d->h);
    
    /* Preverimo, ce ni morda potrebno iti se v siritev intervalov: */
    if (iopt<=4)
    {
      end=0;
      /* Ce se napaka d->erder poveca s 3. na 1. (oziroma z 2. na 1.), nam ni
      treba iti v sirjenje intervalov, ker se napaka s sirjenjem lahko le veca: */
      if (iopt>2)
      {
        d=st->s[3];
        dprev=st->s[1];
        if (dprev->erder>d->erder)
          end=1;
      } else if (st->n>1)
      {
        d=st->s[2];
        dprev=st->s[1];
        if (dprev->erder>d->erder)
          end=1;
      }
    }
    
    /*
    end=0;
    for (i=iopt; i>1 && !end; --i)
    {
      d=st->s[i];
      dprev=st->s[i-1];
      if (d->erderpost>dprev->erderpost)
        end=1;
    }
    */
    
    
  } else end=0;
  
  
  
  if (!end)
  {
    printf("Expansion of intervals:\n");
    expand=1;
    i=1;
    d=st->s[1];
    h=d->h;
  }
  while (!end)
  {
    /* Sirjenje intervalov: */
    ++i;
    h*=factor;
    insstack(st,(d=malloc(sizeof(*d))) ,1 );
    if (st->n>1)
    {
      dpost=st->s[2];
      if (st->n>2)
        dpostpost=st->s[3];
    }
    dprev=dprevprev=NULL;
  
    
    printf("\n\n");
    printf("i = %i h = %g\n",st->n,h);
      
    
    d->x=x; d->f=f; d->h=h; d->x1=d->x-d->h; d->x2=d->x+d->h;
    d->f1=func(d->x1); d->f2=func(d->x2);
    d->der1=(d->f-d->f1)/h; d->der2=(d->f2-d->f)/h; d->der=0.5*(d->der1+d->der2);
    d->erder=fabs(d->der1-d->der2);
    
    if (dpost!=NULL)
    {
      d->erderpost=fabs(d->der-dpost->der);
      dpost->erderprev=d->erderpost;
      if (st->n>=3)
      {
        dpost->erdertot=dpost->erderprev+dpost->erderpost+dpost->erder;
      }
    }
    
    d->sec=(d->der2-d->der1)/h;
  
    printf("x    = %-15.8g f(x)  = %-15.8g h = %-15.8g\n",d->x,d->f,d->h);
    printf("x1   = %-15.8g f(x1) = %-15.8g\n",d->x1,d->f1);
    printf("x2   = %-15.8g f(x2) = %-15.8g\n",d->x2,d->f2);
    printf("der1 = %-15.8g der2  = %-15.8g\n",d->der1,d->der2);
    printf("der  = %-15.8g erder = %-15.8g  prev=%g\n",d->der,d->erder,d->erdertot);
    printf("(post= %-15.5g,  posttot = %.5g, postposttot = %.5g)\n",d->erderpost,dpost->erdertot,dpostpost->erdertot);
    printf("sec  = %-15.8g erder = %-15.8g\n",d->sec,d->erder);
    
    /*
    if (dpost!=NULL && dpostpost!=NULL && i>2)
      if (d->erder>dpost->erder || d->erderpost>dpost->erderpost)
        end=1;
    */
    if (st->n>3)
      if (dpost->erdertot>dpostpost->erdertot)
        end=1;
    if (i>20) /* Varovalka pred neskoncnim sirjenjem pri linearnih funkcijah: */
      end=1;
  }
  
  /* Iskanje optimalnega odvoda glede na skupno ocenjeno napako: */
  if (st->n>=3 && expand)
  {
    i=iopt=st->n-1;
    d=st->s[iopt];
    er=erder=d->erdertot; /* d->erder+d->erderprev+d->erderpost */ ;
    printf("\nSearching for the best derivative approximation after expansion:\n");
    printf("i = %i, er = %10g, der = %g.\n",i,er,d->der);
    for (i=st->n-2;i>1;--i)
    {
      d=st->s[i];
      er=d->erdertot /* d->erder+d->erderprev+d->erderpost */ ;
      
      printf("i = %i, er = %10g, der = %g.\n",i,er,d->der);
    
      if (er<erder)
      {
        erder=er;
        iopt=i;
      }
      
    }
    d=st->s[iopt];
    printf("iopt = %4i, erder = %10g, der = %g, h = %g.\n",iopt,erder,d->der,d->h);
  }
    
  if (1)
  {
    printf("\nEvaluation of the second derivative:\n");
    for (i=2;i<st->n;++i)
    {
      d=st->s[i]; dprev=st->s[i-1]; dpost=st->s[i+1];
      f1=d->f1; h1=d->h; f2=dprev->f1; h2=dprev->h;
      d->sec1=2*((f-f1)/h1-(f1-f2)/(h2-h1))/h2;
      /*
      printf("Left:  der1 = %-10.5g, der2 = %-10.5g.\n",(f1-f2)/(h2-h1),(f-f1)/h1);
      */
      f1=d->f2; f2=dprev->f2;
      d->sec2=2*((f2-f1)/(h2-h1)-(f1-f)/h1)/h2;
      /*
      printf("Right: der1 = %-10.5g, der2 = %-10.5g.\n",(f1-f)/h1,(f2-f1)/(h2-h1));
      */
      d->ersec=fabs(d->sec2-d->sec1);
      d->ersecprev=fabs(d->sec-dprev->sec);
      d->ersecpost=fabs(d->sec-dpost->sec);
      d->ersectot=d->ersec+d->ersecpost+d->ersecprev;
      printf("i = %-2i h = %-10.5g sec1 = %-10.6g sec2 = %-10.6g.\n",
       i,d->h,d->sec1,d->sec2);
      printf("  ersec = %-10.5g ertot = %-10.5g sec = %-10g.\n",
       d->ersec,d->ersectot,d->sec);
    }
  }
    


/* Spremenljivke za ortogonalne aproksimacije: 
vector pt5=NULL,pt7=NULL,pt9=NULL; /* Vektorji abscis 
vector val5=NULL,val7=NULL,val9=NULL; /* Vektorji vrednosti funkcije 
matrix ortval5=NULL,ortval7=NULL,ortval9=NULL; /* Vrednosti ort. pol. na tockah 
matrix ortc5=NULL; /* Koeficienti ort. pol. 
vector polort3=NULL,polort4=NULL,polort5=NULL;  /* Koeficienti lin. komb. ort. pol. (pomozni pod.) 
vector pol3=NULL,pol4=NULL,pol5=NULL;  /* Koeficienti polinom. aproks. 
*/


  if (2)
  {
    dprevprev=NULL;
    printf("\nEvaluation of approximations:\n");
    for (i=2;i<st->n;++i)
    {
      d=st->s[i]; dprev=st->s[i-1]; 
      if (i>2)
        dprevprev=st->s[i-2]; 
      printf("  >>>> i = %-3i h = %-.4g\n",i,d->h);
      
      
      /* zapis abscis in ordinat tock relativno na (d->x,d->f): */
      /*
      pt3->v[1]=-d->h;      val3->v[1]=d->f1-d->f;
      pt3->v[2]=0;          val3->v[2]=0;
      pt3->v[3]=d->h;       val3->v[3]=d->f2-d->f;
      
      ortpol(pt3,3,&ortval3,&ortc3);
      
      aportpol(val3,3,ortval3,ortc3,&polort3,&pol3,&er);
      printf("ap. 3/3 er = %-8.3g erh = %-8.3g der = %-11.6g sec = %-.5g d=%i\n",
      er,er/d->h,derpol(pol3,0,1),derpol(pol3,0,2),pol3->d);
      */
      
      
      /* zapis abscis in ordinat tock relativno na (d->x,d->f): */
      
      pt5->v[1]=-dprev->h;  val5->v[1]=dprev->f1-d->f;
      pt5->v[2]=-d->h;      val5->v[2]=d->f1-d->f;
      pt5->v[3]=0;          val5->v[3]=0;
      pt5->v[4]=d->h;       val5->v[4]=d->f2-d->f;
      pt5->v[5]=dprev->h;   val5->v[5]=dprev->f2-d->f;
      
      ortpol(pt5,5,&ortval5,&ortc5);
      
      
      aportpol(val5,3,ortval5,ortc5,&polort3,&pol3,&er);
      printf("\nap. 5/3 er = %-8.3g erh = %-8.3g der = %-11.6g sec = %-.5g d=%i\n",
      er,er/(2*dprev->h),derpol(pol3,0,1),derpol(pol3,0,2),pol3->d);
      
      
      aportpol(val5,4,ortval5,ortc5,&polort4,&pol4,&er);
      printf("ap. 5/4 er = %-8.3g erh = %-8.3g der = %-11.6g sec = %-.5g d=%i\n",
      er,er/dprev->h,derpol(pol4,0,1),derpol(pol4,0,2),pol4->d);
      
      /*
      aportpol(val5,5,ortval5,ortc5,&polort5,&pol5,&er);
      printf("ap. 5/5 er = %-8.3g erh = %-8.3g der = %-11.6g sec = %-.5g d=%i\n",
      er,er/dprev->h,derpol(pol5,0,1),derpol(pol5,0,2),pol5->d);
      */
      
      /*
      printf("pt5, val5, ap3, ap5:\n");
      for (j=1;j<=pt5->d;++j)
      {
        printf("%-11.4g %-11.4g %-11.4g %-11.4g \n",pt5->v[j],val5->v[j],
        valpol(pol3,pt5->v[j]-d->f),valpol(pol5,pt5->v[j]-d->f));
      }
      */
      
      if (dprevprev!=NULL)
      {
        
        pt7->v[1]=-dprevprev->h;  val7->v[1]=dprevprev->f1-d->f;
        pt7->v[2]=-dprev->h;      val7->v[2]=dprev->f1-d->f;
        pt7->v[3]=-d->h;          val7->v[3]=d->f1-d->f;
        pt7->v[4]=0;              val7->v[4]=0;
        pt7->v[5]=d->h;           val7->v[5]=d->f2-d->f;
        pt7->v[6]=dprev->h;       val7->v[6]=dprev->f2-d->f;
        pt7->v[7]=dprevprev->h;   val7->v[7]=dprevprev->f2-d->f;
        
        ortpol(pt7,7,&ortval7,&ortc7);
        
        /*
        aportpol(val7,3,ortval7,ortc7,&polort3,&pol3,&er);
        printf("\nap. 7/3 er = %-8.3g erh = %-8.3g der = %-11.6g sec = %-.5g d=%i\n",
        er,er/(4*dprevprev->h),derpol(pol3,0,1),derpol(pol3,0,2),pol3->d);
        */
        
        aportpol(val7,4,ortval7,ortc7,&polort4,&pol4,&er);
        printf("ap. 7/4 er = %-8.3g erh = %-8.3g der = %-11.6g sec = %-.5g d=%i\n",
        er,er/(3*dprevprev->h),derpol(pol4,0,1),derpol(pol4,0,2),pol4->d);
        
        aportpol(val7,5,ortval7,ortc7,&polort5,&pol5,&er);
        printf("ap. 7/5 er = %-8.3g erh = %-8.3g der = %-11.6g sec = %-.5g d=%i\n",
        er,er/(2*dprevprev->h),derpol(pol5,0,1),derpol(pol5,0,2),pol5->d);
        
        /*
        aportpol(val7,6,ortval7,ortc7,&polort6,&pol6,&er);
        printf("ap. 7/6 er = %-8.3g erh = %-8.3g der = %-11.6g sec = %-.5g d=%i\n",
        er,er/dprevprev->h,derpol(pol6,0,1),derpol(pol6,0,2),pol5->d);
        
        aportpol(val7,7,ortval7,ortc7,&polort7,&pol7,&er);
        printf("ap. 7/7 er = %-8.3g erh = %-8.3g der = %-11.6g sec = %-.5g d=%i\n",
        er,er/dprevprev->h,derpol(pol7,0,1),derpol(pol7,0,2),pol5->d);
        */
        
        
        /*
        printf("pt7, val7, ap3, ap5:\n");
        for (j=1;j<=pt5->d;++j)
        {
          printf("%-11.4g %-11.4g %-11.4g %-11.4g \n",pt5->v[j],val5->v[j],
          valpol(pol3,pt5->v[j]-d->f),valpol(pol5,pt5->v[j]-d->f));
        }
        */
        
      }
      
    }
  }
  
}
}



static void checkder1(double x,double f,double h0,double factor,double hmin,
            double(*func)(double))
{
double x1,x2,f1,f2,der,sec;
if (factor<=1)
  factor=2;
if (hmin<=0)
  hmin=1.0e-6;
printf("Testing derivatives:\n");
while (h0>=hmin)
{
  x1=x-h0; x2=x+h0; f1=func(x1); f2=func(x2);
  der=0.5*(f2-f1)/h0;
  sec=(f1+f2-2*f)/(h0*h0);
  printf("h = %-10.5g der = %-14.8g sec=%-.8g\n",h0,der,sec);
  h0/=factor;
}
}




double eramp=0.01;

static double exprand(double x)
{
return exp(x)+random1()*eramp;
}

static double linrand(double x)
{
return x+random1()*eramp;
}

static double quadrand(double x)
{
return x*x+random1()*eramp;
}

static double cuberand(double x)
{
return x*x*x+random1()*eramp;
}

static double fourthrand(double x)
{
return x*x*x*x+random1()*eramp;
}

static double fifthrand(double x)
{
return x*x*x*x*x+random1()*eramp;
}


static float exprandf(float x) {return exprand(x);}
static float linrandf(float x) {return linrand(x);}
static float quadrandf(float x) {return quadrand(x);}
static float cuberandf(float x) {return cuberand(x);}
static float fourthrandf(float x) {return fourthrand(x);}


static int numfunc=0;
static double (*func) (double)=cuberand;
static double dfunc(double x)
{
++numfunc;
return func(x);
}
static float ffunc(float x)
{
++numfunc; printf("*");
return func(x);
}





main()
{
stack st=NULL;
double factor=4,x=1,h0=5,hmin=0,der,xx;
char ch;
float ferr;

vector points=NULL,y=NULL,lin=NULL,polort=NULL,pol=NULL,yval=NULL,ypol=NULL;
matrix val=NULL;
matrix coef=NULL,ortc=NULL;
double prod,error,goon=1,yes=1,performcheck=1;
int i,j,k,m=15,n=15;



/*
testaportpol();
exit(1);
*/

while (goon)
{
  printf("\n\n");
  printf("factor:     %g\n",factor); 
  printf("eramp:      %g\n",eramp); 
  printf("h0:         %g\n",h0); 
  printf("x:          %g\n\n",x); 
  printf("factor: "); readdouble(&factor);
  printf("eramp:  "); readdouble(&eramp);
  printf("h0:     "); readdouble(&h0);
  printf("x:      "); readdouble(&x);
  
  printf("\n\ncuberand? "); readdouble(&yes);
  if (yes)
  {
    func=cuberand;  st=NULL;
    numfunc=0;
    numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
    printf("Function evaluations: %i.\n",numfunc);
    
    numfunc=0;
    der=dfridr(ffunc,x,h0,&ferr); 
    printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    printf("Function evaluations: %i.\n",numfunc);
    
    printf("\n\nPerform check? "); readdouble(&performcheck);
    if (performcheck)
    {
      checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
      numfunc=0;
      der=dfridr(ffunc,x,h0,&ferr); 
      printf("Function evaluations: %i.\n",numfunc);
      printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    }
  }
  
  printf("\n\nexprand? "); readdouble(&yes);
  if (yes)
  {
    func=exprand;  st=NULL;
    numfunc=0;
    numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
    printf("Function evaluations: %i.\n",numfunc);
    
    numfunc=0;
    der=dfridr(ffunc,x,h0,&ferr); 
    printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    printf("Function evaluations: %i.\n",numfunc);
    
    printf("\n\nPerform check? "); readdouble(&performcheck);
    if (performcheck)
    {
      checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
      numfunc=0;
      der=dfridr(ffunc,x,h0,&ferr); 
      printf("Function evaluations: %i.\n",numfunc);
      printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    }
  }
  
  printf("\n\nlinrand? "); readdouble(&yes);
  if (yes)
  {
    func=linrand;  st=NULL;
    numfunc=0;
    numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
    
    numfunc=0;
    der=dfridr(ffunc,x,h0,&ferr); 
    printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    printf("Function evaluations: %i.\n",numfunc);
    
    printf("\n\nPerform check? "); readdouble(&performcheck);
    if (performcheck)
    {
      checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
      numfunc=0;
      der=dfridr(ffunc,x,h0,&ferr); 
      printf("Function evaluations: %i.\n",numfunc);
      printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    }
  }
  
  printf("\n\nquadrand? "); readdouble(&yes);
  if (yes)
  {
    func=quadrand;  st=NULL;
    numfunc=0;
    numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
    
    numfunc=0;
    der=dfridr(ffunc,x,h0,&ferr); 
    printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    printf("Function evaluations: %i.\n",numfunc);
    
    printf("\n\nPerform check? "); readdouble(&performcheck);
    if (performcheck)
    {
      checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
      numfunc=0;
      der=dfridr(ffunc,x,h0,&ferr); 
      printf("Function evaluations: %i.\n",numfunc);
      printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    }
  }
  
  printf("\n\nfourthrand? "); readdouble(&yes);
  if (yes)
  {
    func=fourthrand;  st=NULL;
    numfunc=0;
    numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
    
    numfunc=0;
    der=dfridr(ffunc,x,h0,&ferr); 
    printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    printf("Function evaluations: %i.\n",numfunc);
    
    printf("\n\nPerform check? "); readdouble(&performcheck);
    if (performcheck)
    {
      checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
      numfunc=0;
      der=dfridr(ffunc,x,h0,&ferr); 
      printf("Function evaluations: %i.\n",numfunc);
      printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    }
  }
  
  printf("\n\nfifthrand? "); readdouble(&yes);
  if (yes)
  {
    func=fifthrand;  st=NULL;
    numfunc=0;
    numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
    
    numfunc=0;
    der=dfridr(ffunc,x,h0,&ferr); 
    printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    printf("Function evaluations: %i.\n",numfunc);
    
    printf("\n\nPerform check? "); readdouble(&performcheck);
    if (performcheck)
    {
      checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
      numfunc=0;
      der=dfridr(ffunc,x,h0,&ferr); 
      printf("Function evaluations: %i.\n",numfunc);
      printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
    }
  }
 
  printf("goon?"); readdouble(&goon);
}

exit(1);

printf("factor: "); scanf("%lg",&factor);
printf("eramp: "); scanf("%lg",&eramp); printf("\n\n");

printf("\n\nFUNC = cuberand\n");
func=cuberand;
numfunc=0;
numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
printf("Function evaluations: %i.\n",numfunc);
printf("\nPress <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
numfunc=0;
der=dfridr(ffunc,x,h0,&ferr); 
printf("Function evaluations: %i.\n",numfunc);
printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);


xx=x; x=0;
printf("\n\n\n\nFUNC = exprand; Press <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
func=exprand;  st=NULL;
numfunc=0;
numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
printf("Function evaluations: %i.\n",numfunc);
printf("\nPress <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
numfunc=0;
der=dfridr(ffunc,x,h0,&ferr); 
printf("Function evaluations: %i.\n",numfunc);
printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);
x=xx;


printf("\n\n\n\nFUNC = linrand; Press <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
func=linrand;  st=NULL;
numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
printf("\nPress <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
numfunc=0;
der=dfridr(ffunc,x,h0,&ferr); 
printf("Function evaluations: %i.\n",numfunc);
printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);

printf("\n\n\n\nFUNC = quadrand; Press <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
func=quadrand;  st=NULL;
numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
printf("\nPress <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
numfunc=0;
der=dfridr(ffunc,x,h0,&ferr); 
printf("Function evaluations: %i.\n",numfunc);
printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);

printf("\n\n\n\nFUNC = fourthrand; Press <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
func=fourthrand;  st=NULL;
numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
printf("\nPress <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
numfunc=0;
der=dfridr(ffunc,x,h0,&ferr); 
printf("Function evaluations: %i.\n",numfunc);
printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);

printf("\n\n\n\nFUNC = fifthrand; Press <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
func=fifthrand;  st=NULL;
numder12optbas(x,dfunc(x),h0,factor,hmin,dfunc,&st);
printf("\nPress <Return> to goon! "); scanf("%c",&ch); scanf("%c",&ch);
checkder1(x,dfunc(x),h0*factor*factor*factor*factor,pow(factor,1),hmin,dfunc);
numfunc=0;
der=dfridr(ffunc,x,h0,&ferr); 
printf("Function evaluations: %i.\n",numfunc);
printf("Odvod iz NumRec: der = %g, err = %g.\n",der,ferr);


}






































































