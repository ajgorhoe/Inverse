
/* ZELO ZAHRBTNA NAPAKA

je najbrz v groio1.h (modul za branje graficnih objektov).

Obnasanje:

Pri branju graf. objektov javi "memory fault". To se v nekaterih primerih
(tudi pri zelo dolgih, npr. pri 3 megabyta dolgih datotekah) ne zgodi, ce
izljucis funkcijo fgrinextraprimitives (oziroma namesto te funkcije zapises
prazno funkcijo. Podoben vpliv ima izkljucitev funkcije fgrinprimitive, vendar
je izkljucitev te funkcije manj zazelena pri iskanju napake, ker v tem primeru
ne moremo videti nobeneg graficnega prikaza tega, kar je prebrano iz datoteke.

Ceprav se ve, da izkljucitev omenjenih funkcij pozitivno vpliva na delovanje,
se ni dokazano, da je napaka povezana s tema dvema funkcijama oziroma, da je
napaka sploh v datoteki groio1.h. Do prekinitve programa z izpisom "memory fault"
pride navadno v funciji nfilestringto(...) ali v nekem nivoju funkcij, ki so
klicane iz te funkcije (vcasih pri izvedbi free v eni teh funkcij, ceprav je
bila pred ukazom free alokacija ustrezne spremenljivke cisto primerno izvedena).

Nasvet za nadaljnje iskanje napake:
	Mogoce je napaka kje v glavnem programu ("grtest.h" - morda pri dinamicni
alokaciji prostora za kaksno spremenljivko), zato bi bilo dobro preizkusiti samo
branje datoteke z graficnimi objekti v posebnem zelo kratkem programu (to bi iz-
kljucilo morebitne napake v samem glavnem programu). Pri tem morata biti seveda
vkljuceni funkciji fgrinextraprimitives(). in fgrinprimitive().

Napake ni bilo vec, ko sem v datoteki fop.c v funkciji nfindfrelto() povecal
midlength za 7 ali vec.

*/




