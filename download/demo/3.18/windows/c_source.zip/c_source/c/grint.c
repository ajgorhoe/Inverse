

#ifdef IGS   /* This belongs to the IGS! */



        /***************************************************/
        /*                                                 */
        /*   DEFINES FUNCTIONS FOR DRAWING ON THE SCREEN   */
        /*                                                 */
        /***************************************************/


/* Dependent on the graphical library in use, this module defines a set of
   functions for drawing on the screen. Only one graphical library can be used
   at a time in this classical interface of IGS. In contrary, several
   different formats for drawing in files can be used at a time (see grfint.c).
*/

#include <stdio.h>

#include <sysint.h>
#include <strop.h>
#include <rf.h>
#include <st.h>
#include <grint.h>
#include <gro.h>


#ifdef GRX
  #include "grx.h"
#elif defined(GRPEX)
  #include "grpex.h"
#elif defined(GRBGI)
  #include "grbc.h"
#elif defined(GRITK)
  static int curvepoints;
  #include "gritk.h"
#else
  #include "gr0.h"
#endif


#ifndef GRX
 void giinstallfont(int num,char *name){}
 #ifndef GRITK
  void gicoloring(int yes){}
  void ginumshades(int num){}
  void gicolortabsize(int size){}
  void gipreindexcolors(int yes){}
 #endif
#endif





/* FUNKCIJE ZA RISANJE MARKERJEV: */

static float sin45=(float) 0.707107;
static float cos45=(float) 0.707107;
static float sin30=(float) 0.5;
static float cos30=(float) 0.866025;


static void marker1(float x,float y,float size)
  /* Vodoravni kriz */
{
float step=size/2;
giline(x-step,y,x+step,y);
giline(x,y+step,x,y-step);
}

static void marker2(float x,float y,float size)
  /* Posevni kriz */
{
float step=size*sin45/2;
giline(x-step,y-step,x+step,y+step);
giline(x-step,y+step,x+step,y-step);
}

static void marker3(float x,float y,float size)
{
}

static void marker4(float x,float y,float size)
{
}

static void marker5(float x,float y,float size)
{
}

static void marker6(float x,float y,float size)
{
}

static void marker7(float x,float y,float size)
{
}

static void marker8(float x,float y,float size)
{
}

static void marker9(float x,float y,float size)
{
}

static void marker10(float x,float y,float size)
{
}

static void marker11(float x,float y,float size)
{
}


static void (*defaultmarker) (float x,float y,float size) = marker1;
static stack markerstack=NULL;

static void initmarkerstack(void)
{
markerstack=newstack(5);
pushstack(markerstack,(void *) marker1);
pushstack(markerstack,(void *) marker2);
/*
pushstack(markerstack,(void *) marker3);
pushstack(markerstack,(void *) marker4);
pushstack(markerstack,(void *) marker5);
pushstack(markerstack,(void *) marker6);
pushstack(markerstack,(void *) marker7);
pushstack(markerstack,(void *) marker8);
pushstack(markerstack,(void *) marker9);
pushstack(markerstack,(void *) marker10);
pushstack(markerstack,(void *) marker11);
pushstack(markerstack,(void *) marker12);
pushstack(markerstack,(void *) marker13);
pushstack(markerstack,(void *) marker14);
pushstack(markerstack,(void *) marker15);
pushstack(markerstack,(void *) marker16);
pushstack(markerstack,(void *) marker17);
*/
}



void gimarker(float x,float y,float size,int kind)
    /* Narise marker velikosti size in vrste kind pri koordinatah (x,y). */
{
void (*marker) (float x,float y,float size)=defaultmarker;
/* Ce je potrebno, se na sklad markerstack nalozijo funkcije za izris
markerjev: */
if (markerstack==NULL)
  initmarkerstack();
/* S sklada markerstack se vzame ustrezna funkcija. Ce funkcije za zahtevano
vrsto markerja ni na skladu, se vzame funkcija defaultmarker. */
if (kind>0 && kind<=markerstack->n)
  if (markerstack->s[kind]!=NULL)
    marker= (void(*)(float,float,float)) markerstack->s[kind];
marker(x,y,size);
}



void giarrow(float x1,float y1,float x2,float y2,float size,float angle,
            char l,char f,char kind)
  /* Narise puscico od (x1,y1) do (x2,y2) z velikostjo glave size in korom
  puscice angle. line doloca izris linijske stresice, fill pa zapolnjene
  trikotne glave (0 - se ne izrise, 1 - se izrise)
  $A Igor maj01; */
{
float cosfi,sinfi,wcosfi,wsinfi,length,cx,cy,px1,py1,px2,py2,width,height,
       aspectratio;
giline(x1,y1,x2,y2);
if (l!='0' && l!=0 || f!='0' && f!=0)
{
  /* Da lahko narisemo puscice v nepopaceni obliki, rabimo razmerje med visino
  in sirino okna: */
  width=gigetwindowwidth();
  height=gigetwindowheight();
  aspectratio=height/width;
  /* Kosinus in sinus kota, ki ga oklepa crta z vodoravnico, v realnih
  koordinatah (od 0.0 do 1.1): */
  cosfi=(x2-x1)/(length=(float) sqrt(sqr(x2-x1)+sqr(y2-y1)));
  sinfi=(y2-y1)/length;
  /* Kosinus in sinus kota, ki ga oklepa crta z vodoravnico, v okenskih
  (t.j. celih) koordinatah: */
  wcosfi=(x2-x1)/(length=(float) sqrt(sqr(x2-x1)+sqr(aspectratio*(y2-y1))));
  wsinfi=aspectratio*(y2-y1)/length;
  /* Velikost moramo skalirati tako, da bo absolutna velikost glave pri vseh
  kotih, ki jih puscica oklepa z vodoravnico, enaka v okenskih koord; velikost
  se skalira glede na visino okna in ne glede na sirino (faktor aspectratio): */
  size*=aspectratio/(float) sqrt(sqr(sinfi)+sqr(cosfi/aspectratio));
  if (kind=='r' || kind=='R')
    size*=length;
  /* Tocka, kjer glava seka crto: */
  cx=x2-size*cosfi; cy=y2-size*sinfi;
  /* Za izracun pravokotnice rabimo naklonski kot v okenskih koordinatah,
  realne x koordinate pa moramo mnoziti z aspectratio, da se ohranijo koti (tj.
  razmerja med x in y) v okenskih koordinatah: */
  /* Prvi in drugi vogal puscice (simetricno na (cx,xy)) : */
  size*=angle;
  px1=cx-aspectratio*size*wsinfi;   py1=cy+size*wcosfi;
  px2=cx+aspectratio*size*wsinfi;   py2=cy-size*wcosfi;
  if (f!='0' && f!=0)
  {
    /* Izris zapolnjene glave: */
    gifilltriangle(px1,py1,px2,py2,x2,y2);
  }
  if (l=='T' || l=='t')
  {
    /* Izris glave kot trikotnika iz crt: */
    gitriangle(px1,py1,px2,py2,x2,y2);
  } else if (l!='0' && l!=0)
  {
    /* Izris puscice iz crt */
    giline(px1,py1,x2,y2);
    giline(px2,py2,x2,y2);
  }
}
}




#include "grfint.h"











#endif /* if defined (IGS) */
