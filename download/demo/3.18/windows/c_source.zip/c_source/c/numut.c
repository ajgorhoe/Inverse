#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>

#include <mtypes.h>
#include <er.h>
#include <st.h>
#include <vec.h>
#include <mat.h>
#include <rf.h>
#include <strop.h>

#include <numut.h>

/* Index: 
BASIC NUMERICAL OPERATIONS
1D LINEAR, QUADRATIC AND CUBIC POLYNOMIALS
SOLUTION OF EQUATIONS IN 1D
NUMERICAL INTEGRATION
POLYNOMIALS
POLYNOMIAL APPROXIMATION
  ORTHOGONAL POLYNOMIALS ON A SET OF POINTS
PLOTTING OF FUNCTIONS (IN TEXT MODE)
CONVERSION TO LOWER NUMBER OF BITS

*/





             /****************************************/
             /*                                      */
             /*      BASIC NUMERICAL OPERATIONS      */
             /*                                      */
             /****************************************/




           /************************************************/
           /*                                              */
           /*  1D LINEAR, QUADRATIC AND CUBIC POLYNOMIALS  */
           /*                                              */
           /************************************************/




#define fsqr(x) a0+a1*(x)+a2*m_sqr(x)
#define dsqr(x) a1+2*a2*(x)
#define d2sqr(x) 2*a2
#define fcub(x) a0+a1*(x)+a2*m_sqr(x)+a3*(x)*m_sqr(x)
#define dcub(x) a1+2*a2*(x)+3*a3*m_sqr(x)
#define d2cub(x) 2*a2+6*a3*(x)

/* About the module for 1st, 2nd and 3rd order polynomials:
  On the beginning there are functions that calculate the coefficients of the
polynomial for prescribed values or/and derivatives in given points. For
example, sqrcoef...val calculates the coefficients of the quadratic parabola
when values in three points are specified, while sqrcoef...valder calculates
the coefficients when two points with their derivatives are specified.
  Each of these functions has two versions. If "rel" stands instead of ... in
function name (e.g. sqrcoefrelval), then coefficient of the polynomial through
shifted points such that the first point is (0,0) are calculated. Where there
is nothing in place of ..., the coefficients of the polynomial through the
specified points are calculated. Calculation is usually much easier with points
shifted in such a way that the first one is the origin of the co-ordinate
system.
  Any of these function has a variant that stores the coefficients to a vector;
the higher order coefficients are stored in higher copmponents. This vector
can be used e.g. with the function for calculation of values of a polynomial
valpol() or with the functio for calculatio of its derivatives derpol().
  Follow the functions for calculation of zeros and extrema for a given type
of polynomial with specified coefficient. The last are functions for testing
of these functions.

  O tem, kako je sestavljen odsek za kvadratne (in kubicne) polinome:
  Na zacetku so funkcije, ki izracunajo koeficiente polinoma, ce so predpisane
tocke na polinomu ali tocke z odvodi. Npr. sqrcoef...val izracuna koeficiente
kvad. parabole skozi tri tocke, sqrcoef...valder pa koeficiente parabole, kjer
sta podani dve tocki in njuna odvoda. Vsaka od teh funkcij ima dve verziji:
tam, kjer je namesto treh pikic "rel" (npr. sqrcoefrelval), se izracunajo
koeficienti polinoma skozi tako premaknjene tocke, da je prva tocka (0,0),
kjer pa ni namesto ... nic, se izracunajo absolutni koeficienti polinoma skozi
nepremaknjene tocke (izracun koeficientov skozi tako premaknjene tocke, da je
prva v izhodiscu koordinatnega sistema, je veliko lazji).
  Vsaka od funkcij za izracun koeficientov ima svojo razlicico, ki izracunane
koeficiente spravi v vektor (visjega reda v visje komponente). Ta vektor se
lahko uporabi npr. s funkcijo za izracun vrednosti poljubnega polinoma valpol()
ali s funkcijo za izracun odvodov polinomov derpol().
Sledijo funkcije za izracun nicel in ekstremov kvadrat. (oz. kubicnega)
polinoma, ce so podani koeficienti. Na koncu so se funkcije za testiranje teh
funkcij.
*/



    /* LINEAR POLYNOMIALS: */

int linzero(double a1,double a0,double *x1)
    /* Calculates a zaro of the 1th order equation a1*x+a0==0. It returns 1
    if the zero exists and 0 if not. If the zero exists, it is written to *x1.

    ** Izracuna niclo enacbe 1. stopnje a1*x+a0==0. Vrne 1, ce nicla obstaja,
    in 0, ce ne, in zapise niclo v *x1, ce obstaja.
    $A Igor mar01; */
{
if (a1==0)
  return 0;
*x1=-a0/a1;
return 1;
}

void lincoefrelval(double x1,double y1,double x2,double y2,double *a1,double *a0)
    /* calculates the coefficients of the shifted 1st defree polinomyal
    (a1*x+a0) through the points (0,0) and (x2-x1,y2-y1), and writes them to
    *a1 and *a0.

    ** Izracuna koeficienta premaknjenega polinoma prve stopnje (a1*x+a0) skozi tocki
    (0,0) in (x2-x1,y2-y1) ter ju zapise v *a1 in *a0.
    $A Igor mar01; */ 
{
*a1=(y2-y1)/(x2-x1);
*a0=0;
}

void lincoefval(double x1,double y1,double x2,double y2,double *a1,double *a0)
    /* Calculates the coefficients of the 1st degree polynomial (a1*x+a0)
    through the points (x1,y1) and (x2,y2) and stores them in *a1 and *a2.
    ** Izracuna koeficienta polinoma prve stopnje (a1*x+a0) skozi tocki
    (x1,y1) in (x2,y2) ter ju zapise v *a1 in *a0.
    $A Igor mar01; */ 
{
*a1=(y2-y1)/(x2-x1);
*a0=y1-x1*(y2-y1)/(x2-x1);
}

void lincoefrelvalder(double x1,double y1,double d1,double *a1,double *a0)
    /* Calculates the coefficients of the 1st degree polynomial (a1*x+a0)
    through the shifted point (0,0) with the derivative d1 in this point, and
    writes them to *a1 and *a0 (arguments x1 and y1 are not used).

    ** Izracuna koeficienta polinoma prve stopnje (a1*x+a0) skozi premaknjeno
    tocko (0,0) in z odvodom d1 ter ju zapise v *a1 in *a0.
    $A Igor mar01; */ 
{
*a1=d1;
*a0=0;
}

void lincoefvalder(double x1,double y1,double d1,double *a1,double *a0)
    /* Calculates the coefficients of the 1st order polynomial (a1*x+a0)
    through (x1,y1) with derivative d1 in this point, and writes them in *a1
    and *a0.

    ** Izracuna koeficienta polinoma prve stopnje (a1*x+a0) skozi tocko
    (x1,y1) in z odvodom d1 ter ju zapise v *a1 in *a0.
    $A Igor mar01; */ 
{
*a1=d1;
*a0=y1-x1*d1;
}


    /*  QUADRATIC POLYNOMIALS:  */

void sqrcoefrelval(double x1,double y1,double x2,double y2,double x3,double y3,
     double *a2,double *a1,double *a0)
    /* Calculates coefficients of a quadratic parabola that goes through (0,0),
    (x2-x1,y2-y1) and (x3-x1,y3-y1), and writes them to *a2, *a1 and *a0 (the
    formula of the parabola being a2*x^2+a1*x+a0). The abscicas of points can
    be in arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).

    ** Izracuna koeficiente kvadratne parabole, ki gre skozi tocke (0,0),
    (x2-x1,y2-y1) in (x3-x1,y3-y1) ter jih zapise v *a2, *a1 in *a0 (formula
    parabole je a2*x^2+a1*x+a0). Tocke so lahko navedene v poljubnem vrstnem
    redu.
     POZOR:
    Funkcija ne preverja, ce je kaj narobe z vhodnimi podatki (npr. ce se dve
    abscisi ujemata).
    $A Igor mar01; */
{
x2-=x1; x3-=x1;
y2-=y1; y3-=y1;
x1=y1=0;
*a0=0;
*a1=(m_sqr(x3)*y2-m_sqr(x2)*y3)/(x2*(m_sqr(x3)-x2*x3));
*a2=(x3*y2-x2*y3)/(m_sqr(x2)*x3-x2*m_sqr(x3));
}

void sqrcoefval(double x1,double y1,double x2,double y2,double x3,double y3,
     double *a2,double *a1,double *a0)
    /* Calculates coefficients of a quadratic parabola throough points (x1,y1),
    (x2,y2) in (x3,y3) and writes them to *a2, *a1 and *a0 (where formula of
    the parabola is a2*x^2+a1*x+a0)
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).

    ** Izracuna koeficiente kvadratne parabole, ki gre skozi tocke (x1,y1),
    (x2,y2) in (x3,y3) ter jih zapise v *a2, *a1 in *a0 (formula parabole je
    a2*x^2+a1*x+a0). Tocke so lahko navedene v poljubnem vrstnem redu.
     POZOR:
    Funkcija ne preverja, ce je kaj narobe z vhodnimi podatki (npr. ce se dve
    abscisi ujemata).
    $A Igor mar01; */
{
sqrcoefrelval(x1,y1,x2,y2,x3,y3,a2,a1,a0);
*a0+=y1+(*a2)*m_sqr(x1)-(*a1)*x1;
*a1-=2*(*a2)*x1;
}


void sqrcoefrelvalder1(double x1,double y1,double d1,double x2,double y2,
     double *a2,double *a1,double *a0)
    /* Calculates coefficients of the quadratic parabola through (0,0) and
    (x2-x1,y2-y1) with the derivatives d1 in the first point. Coefficients are
    stored to *a2, *a1 and *a0 (where the formula of the parabola is
    a2*x^2+a1*x+a0). Points can be stated in an arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor nov03; */
{
x2-=x1;
y2-=y1;
x1=y1=0;
*a0=0;
*a1=d1; *a2=(y2-d1*x2)/m_sqr(x2);
}


void sqrcoefvalder1(double x1,double y1,double d1,double x2,double y2,
     double *a2,double *a1,double *a0)
    /* Calculates coefficients of the quadratic parabola that goes through
    (x1,y1) and (x2,y2) with the derivative d1 in the first point. Coefficients
    are stored in *a2, *a1 and *a0, where the formula of the
    parabola is a2*x^2+a1*x+a0). Points may be stated in an arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).
    $A Igor nov03; */
{
sqrcoefrelvalder1(x1,y1,d1,x2,y2,a2,a1,a0);
*a0+=y1+(*a2)*m_sqr(x1)-(*a1)*x1;
*a1-=2*(*a2)*x1;
}



void sqrcoefrelvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,double *a2,double *a1,double *a0)
    /* Calculates coefficients of the quadratic parabola through (0,0) and
    (x2-x1,y2-y1) with approximate derivatives d1 in the first and d2 in the
    second point. The parabola is calculated as an average between the one
    which has the derivative d1 in the first point and that with the derivative
    d2 in the second. Coefficients are written to *a2, *a1 and *a0 (where the
    formula of the parabola is a2*x^2+a1*x+a0). Points can be stated in an
    arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).

    ** Izracuna koeficiente kvadratne parabole, ki gre skozi tocki (0,0),
    in (x2-x1,y2-y1) in ima v 0 odvod priblizno d1, v x2-x1 pa d2. Parabolo
    izracuna kot srednjo vrednost med tisto, ki gre skozi navedeni tocki in
    ima v 0 odvod d1 ter tisto, ki gre skozi navedeni tocki in ima v x2-x1
    odvod d2. Koeficiente zapise v *a2, *a1 in *a0 (formula parabole je
    a2*x^2+a1*x+a0). Tocke so lahko navedene v poljubnem vrstnem redu.
     POZOR:
    Funkcija ne preverja, ce je kaj narobe z vhodnimi podatki (npr. ce se dve
    abscisi ujemata).
    $A Igor mar01; */
{
double a12,a11,a22,a21,denom;
x2-=x1;
y2-=y1;
x1=y1=0;
denom=m_sqr(x2);
/* Koeficienti parabole, ce upostevamo odvod v prvi tocki: */
a11=d1; a12=(y2-d1*x2)/denom;
/* Koeficienti parabole, ce upostevamo odvod v drugi tocki: */
a21=(2*x2*y2-d2*m_sqr(x2))/denom; a22=(d2*x2-y2)/denom;
*a0=0;
*a1=0.5*(a11+a21);
*a2=0.5*(a12+a22);
}

void sqrcoefvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,double *a2,double *a1,double *a0)
    /* Calculates coefficients of the quadratic parabola that goes through
    (x1,y1) and (x2,y2) with the derivative approximately d1 in the first and
    d2 in the second point. The parabola is calculated as an average of the one
    with the derivative d1 in the first and d2 in the second point.
    Coefficients are stored in *a2, *a1 and *a0, where the formula of the
    parabola is a2*x^2+a1*x+a0). Points may be stated in an arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).

    ** Izracuna koeficiente kvadratne parabole, ki gre skozi tocki (x1,y1),
    in (x2,y2) in ima v x1 odvod priblizno d1, v x2 pa d2. Parabolo izracuna
    kot srednjo vrednost med tisto, ki gre skozi navedeni tocki in ima v x1
    odvod d1 ter tisto, ki gre skozi navedeni tocki in ima v x2 odvod d2.
    Koeficiente zapise v *a2, *a1 in *a0 (formula parabole je a2*x^2+a1*x+a0).
    Tocke so lahko navedene v poljubnem vrstnem redu.
     POZOR:
    Funkcija ne preverja, ce je kaj narobe z vhodnimi podatki (npr. ce se dve
    abscisi ujemata).
    $A Igor mar01; */
{
sqrcoefrelvalder(x1,y1,d1,x2,y2,d2,a2,a1,a0);
*a0+=y1+(*a2)*m_sqr(x1)-(*a1)*x1;
*a1-=2*(*a2)*x1;
}


void sqrpolrelval(double x1,double y1,double x2,double y2,double x3,double y3,
     vector *coef)
    /* Stores coefficient of the quadratic parabola as calculated by
    sqrcoefrelval(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.

    ** V vektor coef zapise koeficiente kvadratne parabole, ki jih izracuna
    funkcija sqrcoefrelval(), na nacin kompatibilen z valpol().
    $A Igor mar01; */
{
if (coef!=NULL)
{
  if (*coef!=NULL)
    if ((*coef)->d!=3)
      dispvector(coef);
  if (*coef==NULL)
    *coef=getvector(3);
  sqrcoefrelval(x1,y1,x2,y2,x3,y3,&((*coef)->v[3]),&((*coef)->v[2]),
   &((*coef)->v[1]) );
}
}

void sqrpolval(double x1,double y1,double x2,double y2,double x3,double y3,
     vector *coef)
    /* Stores coefficients of the quadratic parabola as calculated by
    sqrcoefval(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.

    ** V vektor coef zapise koeficiente kvadratne parabole, ki jih izracuna
    funkcija sqrcoefval(), na nacin kompatibilen z valpol().
    $A Igor mar01; */
{
if (coef!=NULL)
{
  if (*coef!=NULL)
    if ((*coef)->d!=3)
      dispvector(coef);
  if (*coef==NULL)
    *coef=getvector(3);
  sqrcoefval(x1,y1,x2,y2,x3,y3,&((*coef)->v[3]),&((*coef)->v[2]),
   &((*coef)->v[1]) );
}
}



void sqrpolrelvalder1(double x1,double y1,double d1,double x2,double y2,
     vector *coef)
    /* Stores coefficients of the quadratic parabola as calculated by
    sqrcoefrelvalder1(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.
    $A Igor nov03; */
{
if (coef!=NULL)
{
  if (*coef!=NULL)
    if ((*coef)->d!=3)
      dispvector(coef);
  if (*coef==NULL)
    *coef=getvector(3);
  sqrcoefrelvalder1(x1,y1,d1,x2,y2,&((*coef)->v[3]),&((*coef)->v[2]),
   &((*coef)->v[1]) );
}
}

void sqrpolvalder1(double x1,double y1,double d1,double x2,double y2,
     vector *coef)
    /* Stores coefficients of the quadratic parabola as calculated by
    sqrcoefvalder1(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.
    $A Igor nov03; */
{
if (coef!=NULL)
{
  if (*coef!=NULL)
    if ((*coef)->d!=3)
      dispvector(coef);
  if (*coef==NULL)
    *coef=getvector(3);
  sqrcoefvalder1(x1,y1,d1,x2,y2,&((*coef)->v[3]),&((*coef)->v[2]),
   &((*coef)->v[1]) );
}
}



void sqrpolrelvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,vector *coef)
    /* Stores coefficients of the quadratic parabola as calculated by
    sqrcoefrelvalder(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.

    ** V vektor coef zapise koeficiente kvadratne parabole, ki jih izracuna
    funkcija sqrcoefrelvalder(), na nacin kompatibilen z valpol().
    $A Igor mar01; */
{
if (coef!=NULL)
{
  if (*coef!=NULL)
    if ((*coef)->d!=3)
      dispvector(coef);
  if (*coef==NULL)
    *coef=getvector(3);
  sqrcoefrelvalder(x1,y1,d1,x2,y2,d2,&((*coef)->v[3]),&((*coef)->v[2]),
   &((*coef)->v[1]) );
}
}

void sqrpolvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,vector *coef)
    /* Stores coefficients of the quadratic parabola as calculated by
    sqrcoefvalder(), to *coef in the way compatible with valpol(). If
    necessary, *coef is allocated or reallocated.

    ** V vektor coef zapise koeficiente kvadratne parabole, ki jih izracuna
    funkcija sqrcoefvalder(), na nacin kompatibilen z valpol().
    $A Igor mar01; */
{
if (coef!=NULL)
{
  if (*coef!=NULL)
    if ((*coef)->d!=3)
      dispvector(coef);
  if (*coef==NULL)
    *coef=getvector(3);
  sqrcoefvalder(x1,y1,d1,x2,y2,d2,&((*coef)->v[3]),&((*coef)->v[2]),
   &((*coef)->v[1]) );
}
}


int sqrzeros(double a2,double a1,double a0,double *x1,double *x2)
    /* Calculates the real roots of the quadratic equation a2*x^2+a1*x+a0==0.
    It returns the number of solutions and stores the smaller one in *x1 and
    the larger one in *x2 (if the solution is one, it is stored to *x1).

    ** Izracuna realne korene kvadratne enacbe a2*x^2+a1*x+a0==0. Vrne stevilo
    realnih korenov, v *x1 zapise manjo niclo, v *x2 pa vecjo (ce je ena sama,
    se zapise v *x1).
    $A Igor mar01; */
{
double dis;
if (a2==0)  /* premica namesto parabole */
{
  if (a1==0)
    return 0;
  else
  {
    *x1=*x2=-a0/a1;
    return 1;
  }
} else if ((dis=m_sqr(a1)-4*a2*a0)<0)
  return 0;
else if (dis==0)
{
  *x1=*x2=-a1/(2*a2);
  return 1;
} else  /* dis>0 */
{
  if (a2>0)
  {
    *x1=(-a1-sqrt(dis))/(2*a2);
    *x2=(-a1+sqrt(dis))/(2*a2);
  } else
  {
    *x2=(-a1-sqrt(dis))/(2*a2);
    *x1=(-a1+sqrt(dis))/(2*a2);
  }
  return 2;
}
}


double sqrextreme(double a2,double a1,double a0,double *x,double *y)
    /* Calculates the extreme of kthe quadratic parabola a2*x^2+a1*x+a0. It
    returns the value of the second derivative in this point or 0 if there is
    no extreme (if the parabola is degenerated to a line). Abscissa of the
    extremal point is stored to *x and the ordinate of *y.

    ** Izracuna teme (ekstrem) kvadratne parabole a2*x^2+a1*x+a0. Vrne 
    vrednost 2. odvoda v temenu oz. 0, ce temena ni (ce je parabola izrojena
    v premico). Abscisa temena se zapise v *x, vrednost v temenu pa v *y.
    $A Igor mar01; */
{
if (a2==0)
  return 0;
else
{
  *x=-a1/(2*a2);
  *y=fsqr(*x);
  return 2*a2;
}
}

int sqrmin(double a2,double a1,double a0,double *x,double *y)
    /* Calculates the minimum of the quadratic parabola a2*x^2+a1*x+a0. It
    returns 1 if the minimimum exists and 0 if not. The abscisse of the minimum
    is stored to *x and the value in the minimum to *y.

    ** Izracuna minimum kvadratne parabole a2*x^2+a1*x+a0. Vrne 1, ce
    minimum obstaja in 0, ce ne. Abscisa minimuma se zapise v *x, vrednost v
    minimumu pa v *y.
    $A Igor mar01; */
{
if (a2==0)
  return 0;
else
{
  if (a2>0)
  {
    *x=-a1/(2*a2);
    *y=fsqr(*x);
    return 1;
  } else
    return 0;
}
}

int sqrmax(double a2,double a1,double a0,double *x,double *y)
    /* Calculates the maximum of the quadratic parabola a2*x^2+a1*x+a0. It
    returns 1 if the maximum exists and 0 if not. The abscisse of the minimum
    is stored to *x and the value in the minimum to *y.

    ** Izracuna maksimum kvadratne parabole a2*x^2+a1*x+a0==0. Vrne 1, ce
    maksimum obstaja in 0, ce ne. Abscisa maksimuma se zapise v *x, vrednost v
    maksimumu pa v *y.
    $A Igor mar01; */
{
if (a2==0)
  return 0;
else
{
  if (a2<0)
  {
    *x=-a1/(2*a2);
    *y=fsqr(*x);
    return 1;
  } else
    return 0;
}
}



    /*  CUBIC POLYNOMIALS:  */

void cubcoefrelval(double x1,double y1,double x2,double y2,double x3,double y3,
     double x4,double y4,double *a3,double *a2,double *a1,double *a0)
    /* Calculates the coefficients of the cubic polynomial through the points
    (0,0),(x2-x1,y2-y1), (x3-x1,y3-y1) and (x4-x1,y4-y1), and stores them to
    *a3, *a2, *a1 and *a0 (formula of the polynomial being a3*x^3+a2*x^2+a1*x+a0).
    The points can be stated in an arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).

    ** Izracuna koeficiente kubicne parabole, ki gre skozi tocke (0,0),
    (x2-x1,y2-y1), (x3-x1,y3-y1) in (x4-x1,y4-y1) ter jih zapise v *a3 *a2,
    *a1 in *a0 (formula parabole je a3*x^3+a2*x^2+a1*x+a0). Tocke so lahko
    navedene v poljubnem vrstnem redu.
     POZOR:
    Funkcija ne preverja, ce je kaj narobe z vhodnimi podatki (npr. ce se dve
    abscisi ujemata).
    $A Igor mar01; */
{
double denom;
x2-=x1; x3-=x1; x4-=x1;
y2-=y1; y3-=y1; y4-=y1;
x1=y1=0;
*a0=0;
*a1=  m_sqr(x2)*m_sqr(x4)*(x4-x2)*y3+
     x3*m_sqr(x3)*(m_sqr(x4)*y2-m_sqr(x2)*y4)+
     m_sqr(x3)*(x2*m_sqr(x2)*y4-x4*m_sqr(x4)*y2) ;
*a2=  x2*x4*(m_sqr(x2)-m_sqr(x4))*y3+
     x3*m_sqr(x3)*(x2*y4-x4*y2)+
     x3*(x4*m_sqr(x4)*y2-x2*m_sqr(x2)*y4)  ;
*a3=  x2*x4*(x4-x2)*y3+m_sqr(x3)*(x4*y2-x2*y4)+x3*(m_sqr(x2)*y4-m_sqr(x4)*y2)  ;
denom=x2*(x2-x3)*x3*(x2-x4)*(x3-x4)*x4 ;
*a1/=denom; *a2/=denom; *a3/=denom;
}

void cubcoefval(double x1,double y1,double x2,double y2,double x3,double y3,
     double x4,double y4,double *a3,double *a2,double *a1,double *a0)
    /* Calculates the coefficients of the cubic polynomial through the points
    (x1,y1), (x2,y2), (x3,y3) and (x4,y4), and writes them to *a3 *a2, *a1 and
    *a0 (formula of the polynomial being a3*x^3+a2*x^2+a1*x+a0). The points can
    be stated in an arbitrary order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).

    ** Izracuna koeficiente kubicne parabole, ki gre skozi tocke (x1,y1),
    (x2,y2), (x3,y3) in (x4,y4) ter jih zapise v *a3 *a2, *a1 in *a0 (formula
    parabole je a3*x^3+a2*x^2+a1*x+a0). Tocke so lahko navedene v poljubnem
    vrstnem redu.
     POZOR:
    Funkcija ne preverja, ce je kaj narobe z vhodnimi podatki (npr. ce se dve
    abscisi ujemata).
    $A Igor mar01; */
{
cubcoefrelval(x1,y1,x2,y2,x3,y3,x4,y4,a3,a2,a1,a0);
*a0+=y1-(*a1)*x1+(*a2)*m_sqr(x1)-(*a3)*x1*m_sqr(x1);
*a1+=3*(*a3)*m_sqr(x1)-2*(*a2)*x1;
*a2-=3*(*a3)*x1;
}


void cubcoefrelvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,double *a3,double *a2,double *a1,double *a0)
    /* Calculates the coefficients of a cubic polynimial through the points
    (0,0) and (x2-x1,y2-y1) and has the derivative d1 in 0 and d2 in x2-x1.
    Coefficients are stored in *a3 *a2, *a1 and *a0 (formula of the polynomial
    being a3*x^3+a2*x^2+a1*x+a0). The points can be stated in an arbitrary
    order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).

    ** Izracuna koeficiente kubicne parabole, ki gre skozi tocki (0,0) in
    (x2-x1,y2-y1) ter ima v 0 odvod d1, v x2-x1 pa d2. Koeficiente zapise v
    *a3 *a2, *a1 in *a0 (formula parabole je a3*x^3+a2*x^2+a1*x+a0). Tocke so
    lahko navedene v poljubnem vrstnem redu.
     POZOR:
    Funkcija ne preverja, ce je kaj narobe z vhodnimi podatki (npr. ce se dve
    abscisi ujemata).
    $A Igor mar01; */
{
double denom;
x2-=x1;
y2-=y1;
x1=y1=0;
denom=m_sqr(x2);
*a0=0;
*a1=d1;
*a2=(3*y2-d2*x2-2*d1*x2)/denom;
*a3=(d1*x2+d2*x2-2*y2)/(x2*denom);
}

void cubcoefvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,double *a3,double *a2,double *a1,double *a0)
    /* Calculates the coefficients of a cubic polynimial through the points
    (x1,y1) and (x2,y2) and has the derivative d1 in x1 and d2 in x2.
    Coefficients are stored in *a3 *a2, *a1 and *a0 (formula of the polynomial
    being a3*x^3+a2*x^2+a1*x+a0). The points can be stated in an arbitrary
    order.
      WARNING:
      Function does not check whwther the input data is not regular (e.g. two
    points with the same abscissas).

    ** Izracuna koeficiente kubicne parabole, ki gre skozi tocki (x1,y1) in
    (x2,y2) ter ima v x1 odvod d1, v x2 pa d2. Koeficiente zapise v *a3 *a2,
    *a1 in *a0 (formula parabole je a3*x^3+a2*x^2+a1*x+a0). Tocke so lahko
    navedene v poljubnem vrstnem redu.
     POZOR:
    Funkcija ne preverja, ce je kaj narobe z vhodnimi podatki (npr. ce se dve
    abscisi ujemata).
    $A Igor mar01; */
{
cubcoefrelvalder(x1,y1,d1,x2,y2,d2,a3,a2,a1,a0);
*a0+=y1-(*a1)*x1+(*a2)*m_sqr(x1)-(*a3)*x1*m_sqr(x1);
*a1+=3*(*a3)*m_sqr(x1)-2*(*a2)*x1;
*a2-=3*(*a3)*x1;
}


void cubpolrelval(double x1,double y1,double x2,double y2,double x3,double y3,
     double x4,double y4,vector *coef)
    /* Stores coefficients of the cubic polynomial, as calculated by the
    cubcoefrelval(), to *coef in the way compatible with valpol() (low order
    coefficients first). *coef is allocated or reallocated if necessary.
    
    ** V vektor coef zapise koeficiente kubicnega polinoma, ki jih izracuna
    funkcija cubcoefrelval(), na nacin kompatibilen z valpol().
    $A Igor mar01; */
{
if (coef!=NULL)
{
  if (*coef!=NULL)
    if ((*coef)->d!=4)
      dispvector(coef);
  if (*coef==NULL)
    *coef=getvector(4);
  cubcoefrelval(x1,y1,x2,y2,x3,y3,x4,y4,&((*coef)->v[4]),&((*coef)->v[3]),
   &((*coef)->v[2]),&((*coef)->v[1]) );
}
}

void cubpolval(double x1,double y1,double x2,double y2,double x3,double y3,
     double x4,double y4,vector *coef)
    /* Stores coefficients of the cubic polynomial, as calculated by the
    cubcoefval(), to *coef in the way compatible with valpol() (low order
    coefficients first). *coef is allocated or reallocated if necessary.
    
    ** V vektor coef zapise koeficiente kubicnega polinoma, ki jih izracuna
    funkcija cubcoefval(), na nacin kompatibilen z valpol().
    $A Igor mar01; */
{
if (coef!=NULL)
{
  if (*coef!=NULL)
    if ((*coef)->d!=4)
      dispvector(coef);
  if (*coef==NULL)
    *coef=getvector(4);
  cubcoefval(x1,y1,x2,y2,x3,y3,x4,y4,&((*coef)->v[4]),&((*coef)->v[3]),
   &((*coef)->v[2]),&((*coef)->v[1]) );
}
}

void cubpolrelvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,vector *coef)
    /* Stores coefficients of the cubic polynomial, as calculated by the
    cubcoefrelvalder(), to *coef in the way compatible with valpol() (low order
    coefficients first). *coef is allocated or reallocated if necessary.
    
    ** V vektor coef zapise koeficiente kubicnega polinoma, ki jih izracuna
    funkcija cubcoefrelvalder(), na nacin kompatibilen z valpol().
    $A Igor mar01; */
{
if (coef!=NULL)
{
  if (*coef!=NULL)
    if ((*coef)->d!=4)
      dispvector(coef);
  if (*coef==NULL)
    *coef=getvector(4);
  cubcoefrelvalder(x1,y1,d1,x2,y2,d2,&((*coef)->v[4]),&((*coef)->v[3]),
   &((*coef)->v[2]),&((*coef)->v[1]) );
}
}

void cubpolvalder(double x1,double y1,double d1,double x2,double y2,
     double d2,vector *coef)
    /* Stores coefficients of the cubic polynomial, as calculated by the
    cubcoefvalder(), to *coef in the way compatible with valpol() (low order
    coefficients first). *coef is allocated or reallocated if necessary.
    
    ** V vektor coef zapise koeficiente kubicnega polinoma, ki jih izracuna
    funkcija cubcoefvalder(), na nacin kompatibilen z valpol().
    $A Igor mar01; */
{
if (coef!=NULL)
{
  if (*coef!=NULL)
    if ((*coef)->d!=4)
      dispvector(coef);
  if (*coef==NULL)
    *coef=getvector(4);
  cubcoefvalder(x1,y1,d1,x2,y2,d2,&((*coef)->v[4]),&((*coef)->v[3]),
   &((*coef)->v[2]),&((*coef)->v[1]) );
}
}



int cubzeros(double a3,double a2,double a1,double a0,double *x1,double *x2,
             double *x3)
    /* Calculates the real roots of the cubic equation a3*x^3+a2*x^2+a1*x+a0==0.
    It returns the number of real roots and writes the roots to *x1, *x2 and
    *x3 (if there is only one, it is written to *x1). Zeros are sorted by size.
      Ref.: Bronstein, Smendjajev,...: Mat. prir., p.p. 28,29.
    
    ** Izracuna realne korene kubicne enacbe a3*x^3+a2*x^2+a1*x+a0==0. Vrne
    stevilo realnih korenov, v *x1, *x2 in *x3 pa zapise nicle (ce obstaja
    samo ena, se zapise v *x1). Nicle sortira po velikosti.
    Ref. Matemat. prir., p.p. 28,29
    $A Igor mar01; */
{
int i,pr=0;
double p,q,r,d,s,fi,t1,t2,t3,t;
if (a3==0)  /* kvadratna namesto kubicne parabole */
{
  if (pr) printf("\ncubzeros: square degen.\n");
  i=sqrzeros(a2,a1,a0,x1,x2);
  *x3=*x1;
  return i;
} else
{
  s=-a2/(3*a3);  /* premik zaradi uvedbe nove spremenljivke */
  p=(3*a3*a1-m_sqr(a2))/(9*m_sqr(a3));
  q=0.5*( ( 2*m_cube(a2)/(27*m_cube(a3)) ) - ( a2*a1/(3*m_sqr(a3)) ) + (a0/a3) );
  r=sqrt(fabs(p));    if (q<0) r=-r;
  if (p==0)
  {
    if (pr) printf("\ncubzeros: p=0\n");
    *x1=*x1=*x3==pow(-2*q,1/3)+s;
    return 1;
  } else if (p>=0)
  {
    if (pr) printf("\ncubzeros: p>0\n");
    /* Obstaja le ena realna nicla; */
    fi=arsh( q/m_cube(r));
    *x1=*x2=*x3=-2*r*sh(fi/3)+s;
    return 1;
  } else
  {
    /* p<0 */
    if ( (d=m_sqr(q)+m_cube(p)) >0)
    {
      if (pr) printf("\ncubzeros: p<0,d>0\n");
      /* diskriminanda vecja od 0, ena ali dve realni resitvi: */
      fi=arch(q/m_cube(r));
      if (r!=0 && fi==0)
      {
        /* dve realni resitvi: */
        t1=-2*r*ch(fi/3)+s;
        t2=r*ch(fi/3)+s;
        if (t1>t2) /* urejanje po velikosti */
        {
          t=t1; t1=t2; t2=t;
        }
        *x2=t1; *x2=*x3=t2;
        return 2;
      } else
      {
        /* ena realna resitev: */
        *x1=*x2=*x3=-2*r*ch(fi/3)+s;
        return 1;
      }
    } else
    {
      if (pr) printf("\ncubzeros: p<0,d<=0\n");
      /* diskriminanta manjsa od 0, obstajajo tri realne nicle: */
      fi=arccos(q/m_cube(r));
      t1=-2*r*cos(fi/3)+s;
      t2=2*r*cos(rad(60)-fi/3)+s;
      t3=2*r*cos(rad(60)+fi/3)+s;
      /* Sortiranje po velikosti: */
      if (t1>t3)
      {
        t=t1; t1=t3; t3=t;
      }
      if (t1>t2)
      {
        t=t1; t1=t2; t2=t;
      } else if (t2>t3)
      {
        t=t2; t2=t3; t3=t;
      }
      if (t1==t2) /*degenerirani primeri */
      {
        if (t2==t3)
        {
          *x1=*x2=*x3=t1; return 1;
        } else
        {
          *x1=t1; *x2=*x3=t3; return 2;
        }
      } else if (t2==t3)
      {
        *x1=t1; *x2=*x3=t3; return 2;
      } else /*nedegeneriran primer */
      {
        *x1=t1; *x2=t2; *x3=t3; return 3;
      }
    }
  }
}
}



int cubextremes(double a3,double a2,double a1,double a0,double *x1,double *y1,
    double *d1,double *x2,double *y2,double *d2)
    /* Calculates extremes of the cubic polynomial a3*x^3+a2*x^2+a1*x+a0. It
    returns the number of extremes (which can be 2, 1 if the polynomial is
    degenerated to quadratic pol., or 0). Abscisas of the extremes are written
    to *x1 and *x2, extremal values to *y1 and *y2 and second derivatives in
    these points to *d1 and *d2 (if there is only one extreme, the data is
    stored to *x1, *y1 and *d1). Extremes are sorted by the abscissas.
    
    ** Izracuna ekstrema kubicne parabole a3*x^3+a2*x^2+a1*x+a0. Vrne 
    stevilo ekstremov (ki je lahko 2, 1, ce je polinom izrojen v kvadratno
    parabolo, ali 0). Abscisi ekstremov se zapiseta v *x1 in *x2, vrednosti v
    teh tockah v *y1 in *y2, vrednosti drugih odvodov pa v *d1 in v *d2 (Ce
    je polinom izrojen in ima samo en ekstrem, se podatki zapisejo le v *x1,
    *y1 in *d1). Ekstrema uredi po narascajoci abscisi.
    $A Igor mar01; */
{
double dis;
if (a3==0) /* degeneriran primer (kvadrat. parabola) */
{
  if (a2==0)
    return 0;
  else
  {
    *d1=*d2=sqrextreme(a2,a1,a0,x1,y1);
    *x2=*x1; *y2=*y1;
    return 1;
  }
} else
{
  if ((dis=m_sqr(a2)-3*a1*a3)<0)
    return 0;
  else if (dis==0)
  {
    /* To se sicer ne sme zgoditi */
    *x1=*x2=-a2/(3*a3);
    *y1=*y2=fcub(*x1);
    *d1=*d2=2*a2+6*a3*(*x1);
    return 1;
  } else
  {
    if (a3>0)
    {
      *x1=(-a2-sqrt(dis))/(3*a3);
      *x2=(-a2+sqrt(dis))/(3*a3);
    } else
    {
      *x2=(-a2-sqrt(dis))/(3*a3);
      *x1=(-a2+sqrt(dis))/(3*a3);
    }
    *y1=fcub(*x1);
    *d1=2*a2+6*a3*(*x1);
    *y2=fcub(*x2);
    *d2=2*a2+6*a3*(*x2);
    return 2;
  }
}
}


int cubmin(double a3,double a2,double a1,double a0,double *x,double *y)
    /* Calculates the minimum of the cubic polynomial a3*x^3+a2*x^2+a1*x+a0.
    It returns 1 if the minimum exsists or 0 if it does not (i.e. if the
    polynomial is degenerated to an lower order one). The abscissa of the
    minimum is stored to *x while the value of the polynomial in this point
    is stored to *y if the minimum exists.

    ** Izracuna minimum kubicne parabole a3*x^3+a2*x^2+a1*x+a0. Vrne 
    1, ce minimum obstaja, in 0, ce ne. Abscisa minimuma se zapiseta v *x,
    vrednosti kubicne parabole v tej tocki pa v *y, ce minimum obstaja.
    $A Igor mar01; */
{
double dis;
if (a3==0) /* degeneriran primer (kvadrat. parabola) */
{
  if (a2==0)
    return 0;
  else
    return sqrmin(a2,a1,a0,x,y);
} else
{
  if ((dis=m_sqr(a2)-3*a1*a3)<0)
    return 0;
  else if (dis==0)
  {
    /* To se sicer ne sme zgoditi */
    *x=-a2/(3*a3);
    *y=fcub(*x);
    if (2*a2+6*a3*(*x)>0) /* 2. odvod */
      return 1;
    else
      return 0;
  } else
  {
    *x=(-a2-sqrt(dis))/(3*a3);
    if (2*a2+6*a3*(*x)>0)
    {
      *y=fcub(*x);
      return 1;
    }
    *x=(-a2+sqrt(dis))/(3*a3);
    if (2*a2+6*a3*(*x)>0)
    {
      *y=fcub(*x);
      return 1;
    }
    return 0;
  }
}
}

int cubmax(double a3,double a2,double a1,double a0,double *x,double *y)
    /* Calculates the maximum of the cubic polynomial a3*x^3+a2*x^2+a1*x+a0.
    It returns 1 if the maximum exsists or 0 if it does not (i.e. if the
    polynomial is degenerated to an lower order one). The abscissa of the
    maximum is stored to *x while the value of the polynomial in this point
    is stored to *y if the maximum exists.
    
    ** Izracuna maksimum kubicne parabole a3*x^3+a2*x^2+a1*x+a0. Vrne 
    1, ce maksimum obstaja, in 0, ce ne. Abscisa maksimuma se zapiseta v *x,
    vrednosti kubicne parabole v tej tocki pa v *y, ce maksimum obstaja.
    $A Igor mar01; */
{
double dis;
if (a3==0) /* degeneriran primer (kvadrat. parabola) */
{
  if (a2==0)
    return 0;
  else
    return sqrmax(a2,a1,a0,x,y);
} else
{
  if ((dis=m_sqr(a2)-3*a1*a3)<0)
    return 0;
  else if (dis==0)
  {
    /* To se sicer ne sme zgoditi */
    *x=-a2/(3*a3);
    *y=fcub(*x);
    if (2*a2+6*a3*(*x)<0) /* 2. odvod */
      return 1;
    else
      return 0;
  } else
  {
    *x=(-a2-sqrt(dis))/(3*a3);
    if (2*a2+6*a3*(*x)<0)
    {
      *y=fcub(*x);
      return 1;
    }
    *x=(-a2+sqrt(dis))/(3*a3);
    if (2*a2+6*a3*(*x)<0)
    {
      *y=fcub(*x);
      return 1;
    }
    return 0;
  }
}
}


    /* INSPECTING POLYNOMIALS WITH GIVEN DATA: */

void inspsqrval(double x1,double y1,double x2,double y2,
            double x3,double y3)
    /* Calculates the coefficients of the quadratic polynomial through points
    (x1,y1), (x2,y2) and (x3,y3), shifted for (-x1,-x2), and prints the data
    about this polynomial.
    
    ** Izracuna koeficiente kvadratne parabole skozi tocke (x1,y1), (x2,y2) in
    (x3,y3), premaknjene za (-x1,-y1), ter izpise podatke o tej paraboli.
    $A Igor mar01; */
{
double a0,a1,a2,dx,dy;
int i,ndiv=5,nex=3;
double h;
vector p=NULL,prel=NULL;
printf("\n\nInspecting square parabola through the following points:\n");
printf("( %-12g,%12g )\n",x1,y1);
printf("( %-12g,%12g )\n",x2,y2);
printf("( %-12g,%12g )\n",x3,y3);
sqrcoefrelval(x1,y1,x2,y2,x3,y3,&a2,&a1,&a0);
sqrpolrelval(x1,y1,x2,y2,x3,y3,&prel);
sqrpolval(x1,y1,x2,y2,x3,y3,&p);
dx=x1; dy=y1;
x1=y1=0;
x2-=dx; x3-=dx;
y2-=dy; y3-=dy;
/*
a0=0;
a1=(m_sqr(x3)*y2-m_sqr(x2)*y3)/(x2*(m_sqr(x3)-x2*x3));
a2=(x3*y2-x2*y3)/(m_sqr(x2)*x3-x2*m_sqr(x3));
*/
printf("\nCoefficients:\n  a2=%g,\n  a1=%g,\n  a0=%g\n",a2,a1,a0);
printf("\nMoved square curve through moved points:\n");
printf("y1: %-12g, f(x1): %-12g, x1 (orig.): %g\n",y1,fsqr(x1),x1+dx);
printf("y2: %-12g, f(x2): %-12g, x2 (orig.): %g\n",y2,fsqr(x2),x2+dx);
printf("y3: %-12g, f(x3): %-12g, x3 (orig.): %g\n",y3,fsqr(x3),x3+dx);
x1+=dx; x2+=dx; x3+=dx;
y1+=dy; y2+=dy; y3+=dy;
printf("\nTest of vector coefficients:\n");
printf("Test of relative coefficients:\n");
printf("y1: %-12g, f(x1): %-12g \n",y1,y1+valpol(prel,x1-x1));
printf("y2: %-12g, f(x2): %-12g \n",y2,y1+valpol(prel,x2-x1));
printf("y3: %-12g, f(x3): %-12g \n",y3,y1+valpol(prel,x3-x1));
printf("Test of absolute coefficients:\n");
printf("y1: %-12g, f(x1): %-12g \n",y1,valpol(p,x1));
printf("y2: %-12g, f(x2): %-12g \n",y2,valpol(p,x2));
printf("y3: %-12g, f(x3): %-12g \n",y3,valpol(p,x3));
printf("\nOriginal square curve through given points:\n");
printf("y1: %-12g, f(x1): %-12g, f(x1)-y1: %g\n",y1,dy+fsqr(x1-dx),dy+fsqr(x1-dx)-y1);
printf("y2: %-12g, f(x2): %-12g, f(x2)-y2: %g\n",y2,dy+fsqr(x2-dx),dy+fsqr(x2-dx)-y2);
printf("y3: %-12g, f(x3): %-12g, f(x3)-y3: %g\n",y3,dy+fsqr(x3-dx),dy+fsqr(x3-dx)-y3);
printf("\nTable of values:\n%-15s %15s\n","x","m_sqr(x)");
h=(x3-x1)/(ndiv-1);
for (i=-nex;i<ndiv+nex;++i)
  printf("%-15g %15g\n",i*h+dx,dy+fsqr(i*h));
printf("\nZeros:\n");
i=sqrzeros(a2,a1,a0+y1,&x1,&x2);
if (!i)
  printf("No zeros.\n");
else if (i==1)
  printf("Double zero at x = %g .\n",x1+dx);
else if (i==2)
  printf("First zero:  %g\nSecond zero: %g\n",x1+dx,x2+dx);
printf("\nExtremes:\n");
h=sqrextreme(a2,a1,a0,&x1,&y1);
if (!h)
  printf("No extremes.\n");
else if (h>0)
  printf("Minimum at x = %g,  y = %g .\n",x1+dx,y1+dy);
else
  printf("Maximum at x = %g,  y = %g .\n",x1+dx,y1+dy);
printf("\nMinima:\n");
i=sqrmin(a2,a1,a0,&x1,&y1);
if (!i)
  printf("No minima.\n");
else
  printf("Minimum at x = %g,  y = %g .\n",x1+dx,y1+dy);
printf("\nMaxima:\n");
i=sqrmax(a2,a1,a0,&x1,&y1);
if (!i)
  printf("No maxima.\n");
else
  printf("Maximum at x = %g,  y = %g .\n",x1+dx,y1+dy);
dispvector(&p); dispvector(&prel); 
}

void inspsqrvalder(double x1,double y1,double d1,double x2,double y2,
            double d2)
    /* Calculates coefficients of a quadratic polynomial throug points (x1,y1)
    and (x2,y2) with the derivative d2 in (x2,y2), shifted for (-x1,-y1) and
    prints the relevant data about this parabola.
    
    ** Izracuna koeficiente kvadratne parabole skozi tocke (x1,y1), (x2,y2) in
    (x3,y3), premaknjene za (-x1,-y1), ter izpise podatke o tej paraboli.
    $A Igor mar01; */
{
double a0,a1,a2,dx,dy;
int i,ndiv=5,nex=3;
double h;
vector p=NULL,prel=NULL;
printf("\n\nInspecting square parabola through the following points (and derivatives):\n");
printf("( %-12g, %12g, %12g )\n",x1,y1,d1);
printf("( %-12g, %12g, %12g )\n",x2,y2,d2);
sqrcoefrelvalder(x1,y1,d1,x2,y2,d2,&a2,&a1,&a0);
sqrpolrelvalder(x1,y1,d1,x2,y2,d2,&prel);
sqrpolvalder(x1,y1,d1,x2,y2,d2,&p);
dx=x1; dy=y1;
x1=y1=0;
x2-=dx;
y2-=dy;
/*
a0=0;
a1=(m_sqr(x3)*y2-m_sqr(x2)*y3)/(x2*(m_sqr(x3)-x2*x3));
a2=(x3*y2-x2*y3)/(m_sqr(x2)*x3-x2*m_sqr(x3));
*/
printf("\nCoefficients:\n  a2=%g,\n  a1=%g,\n  a0=%g\n",a2,a1,a0);
printf("\nMoved square curve through moved points:\n");
printf("y1: %-12g, f(x1): %-12g, x1 (orig.): %g\n",y1,fsqr(x1),x1+dx);
printf("y2: %-12g, f(x2): %-12g, x2 (orig.): %g\n",y2,fsqr(x2),x2+dx);
x1+=dx; x2+=dx; 
y1+=dy; y2+=dy; 
printf("\nTest of vector coefficients:\n");
printf("Test of relative coefficients:\n");
printf("y1: %-12g, f(x1): %-12g, d1: %-12g, f'(x1): %-12g \n",
 y1,y1+valpol(prel,x1-x1),d1,derpol(prel,x1-x1,1));
printf("y2: %-12g, f(x2): %-12g, d2: %-12g, f'(x2): %-12g \n",
 y2,y1+valpol(prel,x2-x1),d2,derpol(prel,x2-x1,1));
printf("Test of absolute coefficients:\n");
printf("y1: %-12g, f(x1): %-12g, d1: %-12g, f'(x1): %-12g \n",
 y1,valpol(p,x1),d1,derpol(p,x1,1));
printf("y2: %-12g, f(x2): %-12g, d2: %-12g, f'(x2): %-12g \n",
 y2,valpol(p,x2),d2,derpol(p,x2,1));
printf("\nOriginal square curve through given points:\n");
printf("y1: %-12g, f(x1): %-12g, f(x1)-y1: %g\n",y1,dy+fsqr(x1-dx),dy+fsqr(x1-dx)-y1);
printf("y2: %-12g, f(x2): %-12g, f(x2)-y2: %g\n",y2,dy+fsqr(x2-dx),dy+fsqr(x2-dx)-y2);
printf("\nTable of values:\n%-15s %15s\n","x","m_sqr(x)");
h=(x2-x1)/(ndiv-1);
for (i=-nex;i<ndiv+nex;++i)
  printf("%-15g %15g\n",i*h+dx,dy+fsqr(i*h));
printf("\nZeros:\n");
i=sqrzeros(a2,a1,a0+y1,&x1,&x2);
if (!i)
  printf("No zeros.\n");
else if (i==1)
  printf("Double zero at x = %g .\n",x1+dx);
else if (i==2)
  printf("First zero:  %g\nSecond zero: %g\n",x1+dx,x2+dx);
printf("\nExtremes:\n");
h=sqrextreme(a2,a1,a0,&x1,&y1);
if (!h)
  printf("No extremes.\n");
else if (h>0)
  printf("Minimum at x = %g,  y = %g .\n",x1+dx,y1+dy);
else
  printf("Maximum at x = %g,  y = %g .\n",x1+dx,y1+dy);
printf("\nMinima:\n");
i=sqrmin(a2,a1,a0,&x1,&y1);
if (!i)
  printf("No minima.\n");
else
  printf("Minimum at x = %g,  y = %g .\n",x1+dx,y1+dy);
printf("\nMaxima:\n");
i=sqrmax(a2,a1,a0,&x1,&y1);
if (!i)
  printf("No maxima.\n");
else
  printf("Maximum at x = %g,  y = %g .\n",x1+dx,y1+dy);
dispvector(&p); dispvector(&prel); 
}



void inspcubval(double x1,double y1,double x2,double y2,
            double x3,double y3,double x4,double y4)
    /* Calculates the coefficients of the cubic polynomial through the points
    (x1,y1), (x2,y2), (x3,y3) and (x4,y4), shifted for (-x1,-y1), and prints
    the data about this polynomial.
    
    ** Izracuna koeficiente kubicne parabole skozi tocke (x1,y1), (x2,y2),
    (x3,y3) in (x4,y4), premaknjene za (-x1,-y1), ter izpise podatke o tej
    paraboli.
    $A Igor mar01; */
{
double a0,a1,a2,a3,dx,dy;
int i,ndiv=5,nex=3;
double h;
vector p=NULL,prel=NULL;
printf("\n\nInspecting cubic parabola through the following points:\n");
printf("( %-12g,%12g )\n",x1,y1);
printf("( %-12g,%12g )\n",x2,y2);
printf("( %-12g,%12g )\n",x3,y3);
printf("( %-12g,%12g )\n",x4,y4);
cubcoefrelval(x1,y1,x2,y2,x3,y3,x4,y4,&a3,&a2,&a1,&a0);
cubpolrelval(x1,y1,x2,y2,x3,y3,x4,y4,&prel);
cubpolval(x1,y1,x2,y2,x3,y3,x4,y4,&p);
dx=x1; dy=y1;
x1=y1=0;
x2-=dx; x3-=dx; x4-=dx;
y2-=dy; y3-=dy; y4-=dy;
/*
a0=0;
a1=  m_sqr(x2)*m_sqr(x4)*(x4-x2)*y3+
     x3*m_sqr(x3)*(m_sqr(x4)*y2-m_sqr(x2)*y4)+
     m_sqr(x3)*(x2*m_sqr(x2)*y4-x4*m_sqr(x4)*y2) ;
a2=  x2*x4*(m_sqr(x2)-m_sqr(x4))*y3+
     x3*m_sqr(x3)*(x2*y4-x4*y2)+
     x3*(x4*m_sqr(x4)*y2-x2*m_sqr(x2)*y4)  ;
a3=  x2*x4*(x4-x2)*y3+m_sqr(x3)*(x4*y2-x2*y4)+x3*(m_sqr(x2)*y4-m_sqr(x4)*y2)  ;
denom=x2*(x2-x3)*x3*(x2-x4)*(x3-x4)*x4 ;
a1/=denom; a2/=denom; a3/=denom;
*/
printf("\nCoefficients:\n  a3=%g,\n  a2=%g,\n  a1=%g,\n  a0=%g\n",a3,a2,a1,a0);
printf("\nMoved cubic curve through moved points:\n");
printf("y1: %-12g, f(x1): %-12g, x1 (orig.): %g\n",y1,fcub(x1),x1+dx);
printf("y2: %-12g, f(x2): %-12g, x2 (orig.): %g\n",y2,fcub(x2),x2+dx);
printf("y3: %-12g, f(x3): %-12g, x3 (orig.): %g\n",y3,fcub(x3),x3+dx);
printf("y4: %-12g, f(x4): %-12g, x4 (orig.): %g\n",y4,fcub(x4),x4+dx);
x1+=dx; x2+=dx; x3+=dx; x4+=dx;
y1+=dy; y2+=dy; y3+=dy; y4+=dy;
printf("\nTest of vector coefficients:\n");
printf("Test of relative coefficients:\n");
printf("y1: %-12g, f(x1): %-12g \n",y1,y1+valpol(prel,x1-x1));
printf("y2: %-12g, f(x2): %-12g \n",y2,y1+valpol(prel,x2-x1));
printf("y3: %-12g, f(x3): %-12g \n",y3,y1+valpol(prel,x3-x1));
printf("y4: %-12g, f(x4): %-12g \n",y4,y1+valpol(prel,x4-x1));
printf("Test of absolute coefficients:\n");
printf("y1: %-12g, f(x1): %-12g \n",y1,valpol(p,x1));
printf("y2: %-12g, f(x2): %-12g \n",y2,valpol(p,x2));
printf("y3: %-12g, f(x3): %-12g \n",y3,valpol(p,x3));
printf("y4: %-12g, f(x4): %-12g \n",y4,valpol(p,x4));
printf("\nOriginal cubic curve through given points:\n");
printf("y1: %-12g, f(x1): %-12g, f(x1)-y1: %g\n",y1,dy+fcub(x1-dx),dy+fcub(x1-dx)-y1);
printf("y2: %-12g, f(x2): %-12g, f(x2)-y2: %g\n",y2,dy+fcub(x2-dx),dy+fcub(x2-dx)-y2);
printf("y3: %-12g, f(x3): %-12g, f(x3)-y3: %g\n",y3,dy+fcub(x3-dx),dy+fcub(x3-dx)-y3);
printf("y4: %-12g, f(x4): %-12g, f(x4)-y4: %g\n",y4,dy+fcub(x4-dx),dy+fcub(x4-dx)-y4);
printf("\nTable of values:\n%-15s %15s\n","x","cub(x)");
h=(x4-x1)/(ndiv-1);
for (i=-nex;i<ndiv+nex;++i)
  printf("%-15g %15g\n",i*h+dx,dy+fcub(i*h));
printf("\nZeros:\n");
i=cubzeros(a3,a2,a1,a0+y1,&x1,&x2,&x3);
if (!i)
  printf("No real zeros.\n");
else
{
  printf("Zero at x = %g .\n",x1+dx);
  if (i>1)
    printf("Zero at x = %g .\n",x2+dx);
  if (i>2)
    printf("Zero at x = %g .\n",x3+dx);
}
printf("\nExtremes:\n");
i=cubextremes(a3,a2,a1,a0,&x1,&y1,&y3,&x2,&y2,&y4);
if (i==0)
  printf("No extremes.\n");
else if (i==1)
{
  if (y3>0)
    printf("Minimum at x = %g,  y = %g .\n",x1+dx,y1+dy);
  else if (y3<0)
    printf("Maximum at x = %g,  y = %g .\n",x1+dx,y1+dy);
  else
    printf("Saddle point at x = %g,  y = %g .\n",x1+dx,y1+dy);
} else
{
  if (y3>0)
  {
    printf("Minimum at x = %g,  y = %g .\n",x1+dx,y1+dy);
    printf("Maximum at x = %g,  y = %g .\n",x2+dx,y2+dy);
  } else
  {
    printf("Maximum at x = %g,  y = %g .\n",x1+dx,y1+dy);
    printf("Minimum at x = %g,  y = %g .\n",x2+dx,y2+dy);
  }
}
printf("\nMinima:\n");
i=cubmin(a3,a2,a1,a0,&x1,&y1);
if (!i)
  printf("No minima.\n");
else
  printf("Minimum at x = %g,  y = %g .\n",x1+dx,y1+dy);
printf("\nMaxima:\n");
i=cubmax(a3,a2,a1,a0,&x1,&y1);
if (!i)
  printf("No maxima.\n");
else
  printf("Maximum at x = %g,  y = %g .\n",x1+dx,y1+dy);
dispvector(&p); dispvector(&prel); 
}


void inspcubvalder(double x1,double y1,double d1,double x2,double y2,
            double d2)
    /* Calculates the coefficients of a cubic polynomial through (x1,y1) and
    (x2,y2) with derivatives d1 and d2 in these points, shifted by (-x1,-y1),
    and prints the basic data about this polynomial.
    
    ** Izracuna koeficiente kubicne parabole skozi tocki (x1,y1) in (x2,y2) z
    odvodoma v teh tockah d1 in d2, premaknjene za (-x1,-y1), ter izpise
    podatke o tej paraboli.
    $A Igor mar01; */
{
double a0,a1,a2,a3,dx,dy;
int i,ndiv=5,nex=3;
double h;
vector p=NULL,prel=NULL;
printf("\n\nInspecting cubic parabola through the following points (with derivatives):\n");
printf("( %-12g,%12g, %12g )\n",x1,y1,d1);
printf("( %-12g,%12g, %12g )\n",x2,y2,d2);
cubcoefrelvalder(x1,y1,d1,x2,y2,d2,&a3,&a2,&a1,&a0);
cubpolrelvalder(x1,y1,d1,x2,y2,d2,&prel);
cubpolvalder(x1,y1,d1,x2,y2,d2,&p);
dx=x1; dy=y1;
x1=y1=0;
x2-=dx; 
y2-=dy; 
printf("\nCoefficients:\n  a3=%g,\n  a2=%g,\n  a1=%g,\n  a0=%g\n",a3,a2,a1,a0);
printf("\nMoved cubic curve through moved points:\n");
printf("y1: %-12g, f(x1): %-12g, x1 (orig.): %g\n",y1,fcub(x1),x1+dx);
printf("y2: %-12g, f(x2): %-12g, x2 (orig.): %g\n",y2,fcub(x2),x2+dx);
x1+=dx; x2+=dx;
y1+=dy; y2+=dy;
printf("\nTest of vector coefficients:\n");
printf("Test of relative coefficients:\n");
printf("y1: %-12g, f(x1): %-12g, d1: %-12g, f'(x1): %-12g \n",
 y1,y1+valpol(prel,x1-x1),d1,derpol(prel,x1-x1,1));
printf("y2: %-12g, f(x2): %-12g, d2: %-12g, f'(x2): %-12g \n",
 y2,y1+valpol(prel,x2-x1),d2,derpol(prel,x2-x1,1));
printf("Test of absolute coefficients:\n");
printf("y1: %-12g, f(x1): %-12g, d1: %-12g, f'(x1): %-12g \n",
 y1,valpol(p,x1),d1,derpol(p,x1,1));
printf("y2: %-12g, f(x2): %-12g, d2: %-12g, f'(x2): %-12g \n",
 y2,valpol(p,x2),d2,derpol(p,x2,1));
printf("\nOriginal cubic curve through given points:\n");
printf("y1: %-12g, f(x1): %-12g, f(x1)-y1: %g\n",y1,dy+fcub(x1-dx),dy+fcub(x1-dx)-y1);
printf("y2: %-12g, f(x2): %-12g, f(x2)-y2: %g\n",y2,dy+fcub(x2-dx),dy+fcub(x2-dx)-y2);
printf("\nTable of values:\n%-15s %15s\n","x","cub(x)");
h=(x2-x1)/(ndiv-1);
for (i=-nex;i<ndiv+nex;++i)
  printf("%-15g %15g\n",i*h+dx,dy+fcub(i*h));
printf("\nZeros:\n");
i=cubzeros(a3,a2,a1,a0+y1,&x1,&x2,&d2);
if (!i)
  printf("No real zeros.\n");
else
{
  printf("Zero at x = %g .\n",x1+dx);
  if (i>1)
    printf("Zero at x = %g .\n",x2+dx);
  if (i>2)
    printf("Zero at x = %g .\n",d2+dx);
}
printf("\nExtremes:\n");
i=cubextremes(a3,a2,a1,a0,&x1,&y1,&d1,&x2,&y2,&d2);
if (i==0)
  printf("No extremes.\n");
else if (i==1)
{
  if (d1>0)
    printf("Minimum at x = %g,  y = %g .\n",x1+dx,y1+dy);
  else if (d1<0)
    printf("Maximum at x = %g,  y = %g .\n",x1+dx,y1+dy);
  else
    printf("Saddle point at x = %g,  y = %g .\n",x1+dx,y1+dy);
} else
{
  if (d1>0)
  {
    printf("Minimum at x = %g,  y = %g .\n",x1+dx,y1+dy);
    printf("Maximum at x = %g,  y = %g .\n",x2+dx,y2+dy);
  } else
  {
    printf("Maximum at x = %g,  y = %g .\n",x1+dx,y1+dy);
    printf("Minimum at x = %g,  y = %g .\n",x2+dx,y2+dy);
  }
}
printf("\nMinima:\n");
i=cubmin(a3,a2,a1,a0,&x1,&y1);
if (!i)
  printf("No minima.\n");
else
  printf("Minimum at x = %g,  y = %g .\n",x1+dx,y1+dy);
printf("\nMaxima:\n");
i=cubmax(a3,a2,a1,a0,&x1,&y1);
if (!i)
  printf("No maxima.\n");
else
  printf("Maximum at x = %g,  y = %g .\n",x1+dx,y1+dy);
dispvector(&p); dispvector(&prel); 
}


#undef fsqr
#undef dsqr
#undef d2sqr
#undef fcub
#undef dcub
#undef d2cub





           /*************************************/
           /*                                   */
           /*    SOLUTION OF EQUATIONS IN 1D    */
           /*                                   */
           /*************************************/



#define m_swap1(x1,x2,aux) {aux=x1; x1=x2; x2=aux;}
#define m_swap2(x1,y1,x2,y2,aux) {m_swap1(x1,x2,aux) m_swap1(y1,y2,aux)}
#define m_swap3(x1,y1,z1,x2,y2,z2,aux) {m_swap1(x1,x2,aux) \
           m_swap1(y1,y2,aux) m_swap1(z1,z2,aux)}

static void printitzf(int numit,double x1,double f1,double x2,double f2,
                      double x3,double f3)
{
  /*
printf("It. %i: {%g, %4g}, {%g, %4g}, x3=%g, f3=%g\n",
       numit,x1,f1,x2,f2,x3,f3);
*/
printf("It. %i: {%g, %4g}, {%g, %4g}, x3=%g\n",
       numit,x1,f1,x2,f2,x3,f3);
}


/* TO IMPLEMENT: BRACKETING INTERVAL THAT CONTAINS A SIMPLE ZERO, SWITCH
TO MINIMUM FINDING & CHECKING IF BRACKETING IS NOT SUCCESSFUL (there are
two options: minimizing square of the function which should automatically 
yield a zero if there is one (think about possible negative effects in terms
of efficiency), or just minimizing (in case that its values are
positive) or maximizing the function, and check if minimum is of opposite sign
as values (which yields bracketed interval which was missed by a "long shut"),
zero (which means a complex zero that is also an extreme) or extreme is of
the same sign, which means that the function turns away from zero and the
algorithm will report that no local solution could be found from a given 
guess. */

int zerofunc1dsimpint0(double func(double,void *),void *clientdata,
          double x1,double x2, double tolx,double tolf,int maxit,
          double *xzero,double *fzero,int *niter)
    /* Calculates an approximation of simple zero of function func,
    beginning with interval [x1,x2], which must be such that the function
    does not have the same sign at x1 and x2.
      func is used to evaluate function, and clientdata is passed to
    func when evaluating (this allows to use specification data for the
    function and therefore combine functions in a thread safe way).
      tolx and tolf are tolerances on the size of the interval which
    for sure contains zero and for function value, respectively. One of
    them can be 0 (which means unspecified), and convergence is achieved
    when both convergence criteria - on interval length and function value
    - are satisfied. 
      maxit limits the maximum number of iterations and is set internally
    if the provided value is less than .1
      The approximate zero of the function is written to *xzero and value
    of the function in this point is written to *fzero. If one or both of
    these are NULL then no error is reported, just the values are not
    returned.
      If niter is not NULL then number of iterations is written to *niter.
    This corresponds to the number of function evaluations.
      Returns 0 if successful, -1 if not (e.g. max. num. iterations
    exceeded).
      WARNINGS:
    ONLY FOR SIMPLE ZEROS!!! Convenient for monotone functions.
    The sign of f1 anf f2 must be the opposite!
    $A Igor mar05; */
{
double x3,f1,f2,f3,aux,aux2,intratio;
int numit=0,numeval=0,converged=0,convf,convx,ret=0,sqrit,dobisection;
double fmin,fmin1,fmin2,dx,dx1,dx2,minint,minint1,minint2,a2,a1,a0,zerq1,zerq2;
/* it. where square approximation wasn't good: */
int sqrfail=-100,sqrfail1=-100,sqrfail2=-100,numzer;
int clust=-100,clust1=-100,clust2=-100,  /* Iterates with clustering is present */
    badclust=-100,badclust1=-100,badclust2=-100;  /* iterates with bad clustering */
static int reported=0;
int prn=0;  /* set this to 1 for testinf! */
f1=func(x1,clientdata); f2=func(x2,clientdata);
if (f1>f2)
  m_swap2(x1,f1,x2,f2,aux)
if (maxit<1)
  maxit=1000;
tolx=fabs(tolx); tolf=fabs(tolf);
if (tolx<=0 && tolf<=0)
  tolx=1e-10;
x3=x1; f3=f1;
if (prn) {
  printf("zerofunc1dint0: maxit=%i, tolx=%g, toly=%g\n",maxit,tolx,tolf);
  printitzf(numit,x1,f1,x2,f2,x3,f3); }
if (f1*f2>0)
{
  errfunc0("");
  sprintf(ers(),"The function does not have opposite sign in initial interval ends:\n");
  sprintf(ers(),"f(x1) = %.3g, f(x2) = %.3g. [x1,x2]=[%.5g,%.5g] \n",f1,f2,x1,x2);
  errfunc2();
}
fmin=fmin1=fmin2=fabs(f1)+fabs(f2);
dx=fabs(x2-x1);  dx1=20.*dx; dx2=50.*dx1;
minint=dx;  minint1=dx1;  minint2=dx2;
sqrit=0;
while(!converged)
{
  /* Remark: x1 and x2 are arranged so that f1<=0 & f2>=0 (i.e. they bracket
  function zero). Note: After an iteration, [x1,x2] include the last
  calculated point, and x3 is not internal point of the treated interval.
  x1 and x2 are not sorted by increasing order, the rule is f1<=0 & f2>=0 */
  ++numit;
  if (numit==1 || numit-sqrfail<=1) /* number of bisections after failure of 
          square interpolation */
    dobisection=1;  /* bisection foreseen in this iteration */
  else
    dobisection=0;  /* quadratic interpolation foreseen */
  if (   /* 0&&    */
         (dobisection && clust==numit-1)
      || (!dobisection && ( clust==numit-1 && clust1==numit-2 ))  ) 
  /* Perform anticlustering iteration if bisection is foreseen and clustering
  condition has been satisfied in the last iteration, or if square 
  interpolation step is foreseen and clustering has been observed in last
  two iterations. */
  {
    /* Undertake a step to prevent clustering: */
    sqrit=0;
    if (prn)
      printf("Anticlustering, clust. iter: %i, %i, %i, dobisect.: %i\n",
        clust,clust1,clust2,dobisection);
    if (fabs(x3-x1)<fabs(x3-x2))
    {
      aux=x1; /* x1 is clustered with x3 (and is therefore the midpoint) */
      aux2=x2;
    } else
    {
      aux=x2; /* x2 is clustered with x3 */
      aux2=x1;
    }
    x3=aux+0.2*(aux2-aux);
    /* Comment: it turns safer to move endpoint of the larger interval towards 
    the internal point rather than reflect the clustered external point. */
    /* Reflect x3 over mid-point, extend reflection for safety (to extend
    reflection interval if reflection must be repeated in the next iter.: 
    x3=aux+(aux-x3)*3.0;  /* extension factor, at least 2 recommended */
    if ( (x3>=x1 && x3>=x2) || (x3<=x1 && x3<=x2) )
    {
      /* Reflected x3 falled outside [x1,x2]; This should not happen, but
      if it does, we perform bisection: */
      if (prn)
        printf("FAILURE in anticlustering: x3 = %g fell outside [x1,x2], perform bisection:\n\n\n\n",x3);
      x3=0.5*(x1+x2);
    }
    f3=func(x3,clientdata);
    /* IMPLEMENT action & put else after this code block! */
  } else
  if (dobisection) /* number of bisections after failure of 
          square interpolation */
  {
    /* Perform a bisection step: */
    sqrit=0;
    /* Step to prevent clustering of points on one side of interval: */
    /* if (fabs(x1-x2)/minint=1;) */
    
    x3=0.5*(x1+x2);
    f3=func(x3,clientdata);
  } else
  {
    /* Perform a square interpolation step */ 
    sqrit=1;
    sqrcoefval(x1,f1,x3,f3,x2,f2,&a2,&a1,&a0);
    numzer=sqrzeros(a2,a1,a0,&zerq1,&zerq2);
    if (1 && prn)
    {
      if (numzer<1)
        printf("\nNo zeros of square interpolation.\n");
      else if (numzer==1)
      {
        printf("Square interp.: rel. zero = %g.12, orig. zero %g.12 \n",
          zerq1,zerq1+x1);
      } else if (numzer>1)
        printf("Square interp.: zero 1 = %g.12, zero 2 = %g.12 \n",
          zerq1,zerq2);
    }
    if (numzer<1)
    {
      sqrit=0;
      /* Finding zeros of interpolated quad. parabola failed, 
      perform bisection: */
      x3=0.5*(x1+x2);
    } else
    {
      x3=zerq1 /* +x1 */ ; /* because coefficients were calculated relatively for 
      a shift such that (x1,f1) is moved to (0,0) */
      if ( (x3>=x1 && x3>=x2) || (x3<=x1 && x3<=x2) )
      {
        /* 1st zero of interpolated parabola outside bracketing [x1,x2]: */
        if (numzer<2)
          sqrit=0;
        else  /* there were two zeros, try another one */
        {
          x3=zerq2 /* +x1 */ ; /* because coefficients were calculated relatively for 
          a shift such that (x1,f1) is moved to (0,0) */
          if ( (x3>=x1 && x3>=x2) || (x3<=x1 && x3<=x2) )
            sqrit=0; /* second zero also outside [x1,x2] */
        }
      }
      if (!sqrit)
      {
        /* Calculated zero is outside the interval [x1,x2], perform bisection: */
        if (prn)
        {
          if (numzer<1)
            printf("Square interp. ERROR: NO ZEROS\n");
          else
            printf("Square interp. ERROR: %ith zero (%g) falls outside [x1,x2],\n\n",
                   numzer,x3);
        }
        x3=0.5*(x1+x2);
      }
    }
    f3=func(x3,clientdata);
  }
  /* Put (x3,f3) in place of the point with the same sign: */
  if (f3<0)
  {
    m_swap2(x1,f1,x3,f3,aux)
  } else
  {
    m_swap2(x2,f2,x3,f3,aux)
  }
  if (f1==0 || f2==0)
  {
    /* We hit zero value (exact convergence), return results */
    converged=1;
    if (f2==0)
    {
      m_swap2(x1,f1,x2,f2,aux);
    }
    if (xzero!=NULL)
      *xzero=x1;
    if (fzero!=NULL)
      *fzero=f1;
  } else
  {
    fmin2=fmin1; fmin1=fmin;
    fmin=m_minval(fabs(f1),fabs(f2));   /* smallest absolute value of f */
    dx2=dx1; dx1=dx;
    dx=fabs(x2-x1);   /* length of current bracketing interval */
    minint2=minint1;  minint1=minint;
    minint=m_minval3(fabs(x1-x2), fabs(x1-x3), fabs(x3-x1));
    convf=(tolx<=0 || dx<=tolx);
    convx=(tolf<=0 || fmin<=tolf);
    converged=convf && convx;
    if (!converged && numit==maxit)
    {
      /* Exceeded max. num. of iterations */
      if (!reported)
      {
        errfunc0("");
        sprintf(ers(),"Max. number of iteration %i reached without convergence.\n",
          maxit);
        errfunc2();
      }
      converged=1; ret=-1; ++reported;
    }
    if (converged)
    {
      if (fabs(f2)<fabs(f1))
      {
        m_swap2(x1,f1,x2,f2,aux);
      }
      if (xzero!=NULL)
        *xzero=x1;
      if (fzero!=NULL)
        *fzero=f1;
    }
  }
  if (!converged)
  {
    /* Estimate if square interpolation step was not successful enough and
    therefore some bisections should be performed: */
    if (!converged && sqrit)
      if (minint2/minint<5 || fmin2/fmin<5)
      {
        sqrfail2=sqrfail1; sqrfail1=sqrfail;
        sqrfail=numit;
      }
    /* Anti-clustering measure: If [x1,x2] is very small it is not critical
    because this is the interval that will be sected this iteration. It is
    critical when [x3,x1] or [x3,x2] is small with respect to [x1,x2]. We
    calculate the ratio between the non-sected and sected interval, and take
    measures if sected interval is large in comparison with non-sected: */
    intratio=m_minval(fabs(x3-x1),fabs(x3-x2))/fabs(x1-x2);
    if (intratio<0.025)  /* max. allowed clustering ratio */
    {
      clust2=clust1;  clust1=clust;
      clust=numit;
      if (intratio<0.0001)
        badclust2=clust1;  badclust1=clust;
        badclust=numit;
    }
  }
  if (prn) 
  {
    if (numit==sqrfail)
      printf("Sqrfail: %i, %i, %i.\n\n",sqrfail2,sqrfail1,sqrfail);
    printitzf(numit,x1,f1,x2,f2,x3,f3);
  }
}
if (niter!=NULL)
  *niter=numit;
return ret;
}





















           /***********************************/
           /*                                 */
           /*      NUMERICAL INTEGRATION      */
           /*                                 */
           /***********************************/



double inttrap0(double (*func)(double, void *),void *clientdata,
                double from,double to,int n)
    /* Calculates the definite integral of function of one variable calculated 
    by func on the interval [from,to], by the trapesian formula, using n points.
    Function func takes a pointer to definition data, and this function passes
    the clientdata to the function as definition data.
    If n is less than 1 then it is set to 1 again.
    $A Igor mar05; */
{
double sum=0,h;
int i;
if (n<1)
  n=1;
h=(to-from)/n;
sum+=0.5*func(from,clientdata);
for (i=1;i<n;++i)
  sum+=func(from+i*h,clientdata);
sum+=0.5*func(to,clientdata);
return h*sum;
}


double inttrapbas(double (*func)(double),double from,double to,int n)
    /* Izracuna dolocen integral funkcije func od from to to po trapezni
    formuli, pri cemer se fnkcija n+1 krat ovrednoti (interval [from,to] se
    razdeli na n podintervalov). Ce je n manj od 1, ga funkcija postavi na 1.
    $A Igor jan01; */
{
double sum=0,h;
int i;
if (n<1)
  n=1;
h=(to-from)/n;
sum+=0.5*func(from);
for (i=1;i<n;++i)
  sum+=func(from+i*h);
sum+=0.5*func(to);
return h*sum;
}


double inttraptab(double *tab,int n,double h)
    /* Izracuna dolocen integral funkcije tabelirane v tab po trapezni
    formuli. Funkcija mora biti tabelirana z n vrednostmi, ki so izracunane
    v enakomernih razmikih h. Ce je n manj od 2, se javi napaka. Kazalec tab
    mora biti taksen, da je prva vrednost funkcije v tab[0]. Pozor: pri
    inttrapbas() je n st. intervalov, tu pa je n st. tock, torej za ena vec.
    $A Igor jan01; */
{
double sum=0;
int i;
if (n<2)
{
  errfunc0("inttraptab");
  fprintf(erf(),"Number of values (%i) is not greater than 1.\n",n);
  errfunc2();
  return 0;
}
sum+=0.5*tab[0];
for (i=1;i<n-1;++i)
  sum+=tab[i];
sum+=0.5*tab[n-1];
return h*sum;
}

double inttrapvec(vector v,double h)
    /* Izracuna dolocen integral funkcije tabelirane v vec po trapezni
    formuli. Funkcija mora biti tabelirana z vec->d vrednostmi, ki so
    izracunane v enakomernih razmikih h. Ce je stevilo vrednosti manj od 2,
    se javi napaka. Za izracun uporabi funkcijo inttraptab().
    $A Igor jan01; */
{
if (v==NULL)
{
  errfunc0("inttrapvec");
  fprintf(erf(),"Vector of function values is NULL.\n");
  errfunc2();
  return 0;
} else
  return inttraptab(v->v+1,v->d,h);
}


double intsimp0(double (*func)(double, void *),void *clientdata,
                double from,double to,int n)
    /* Calculates the definite integral of function of one variable calculated 
    by func on the interval [from,to], by the Simpson formula, using n points.
    Function func takes a pointer to definition data, and this function passes
    the clientdata to the function as definition data.
    If n is less than 2 or odd then it is corrected.
    $A Igor mar05; */
{
double sum=0,h;
int i;
char even=1;
/* Najprej se poskrbi, da ja n sod in vecji od 1: */
if (n<2)
  n=2;
else if (n%2)
  ++n;
h=(to-from)/n;
sum+=func(from,clientdata);
for (i=1;i<n;++i)
{
  if (even)
  {
    sum+=4*func(from+i*h,clientdata);
    even=0;
  } else
  {
    sum+=2*func(from+i*h,clientdata);
    even=1;
  }
}
sum+=func(to,clientdata);
return h*sum/3;
}


double intsimpsbas(double (*func)(double),double from,double to,int n)
    /* Izracuna dolocen integral funkcije func od from to to po Simpsonovi
    formuli, pri cemer se fnkcija n+1 krat ovrednoti (interval [from,to] se
    razdeli na n podintervalov). n mora biti sodo stevilo vecje od 1, ce ni,
    ga funkcija sama popravi (ce je vecji od 1, ga inkrementira).
    $A Igor jan01; */
{
double sum=0,h;
int i;
char even=1;
/* Najprej se poskrbi, da ja n sod in vecji od 1: */
if (n<2)
  n=2;
else if (n%2)
  ++n;
h=(to-from)/n;
sum+=func(from);
for (i=1;i<n;++i)
{
  if (even)
  {
    sum+=4*func(from+i*h);
    even=0;
  } else
  {
    sum+=2*func(from+i*h);
    even=1;
  }
}
sum+=func(to);
return h*sum/3;
}

double intsimptab(double *tab,int n,double h)
    /* Izracuna dolocen integral funkcije tabelirane v tab po simpsonovi
    formuli. Funkcija mora biti tabelirana z n vrednostmi, ki so izracunane
    v enakomernih razmikih h. Ce je n sodo stevilo ali manj od 3, se javi
    napaka. Kazalec tab mora biti taksen, da je prva vrednost funkcije v
    tab[0]. Pozor: pri intsimpbas() je n st. intervalov, tu pa je n st. tock,
    torej za eno vec.
    $A Igor jan01; */
{
double sum=0;
int i;
char even=1;
/* Najprej se preveri, ali je n lih in vecji od 2: */
if (n<3 || !(n%2))
{
  errfunc0("intsimptab");
  fprintf(erf(),"Number of values (%i) is not odd and greater than 2.\n",n);
  errfunc2();
  return 0;
}
sum+=tab[0];
for (i=1;i<n-1;++i)
{
  if (even)
  {
    sum+=4*tab[i];
    even=0;
  } else
  {
    sum+=2*tab[i];
    even=1;
  }
}
sum+=tab[n-1];
return h*sum/3;
}

double intsimpvec(vector v,double h)
    /* Izracuna dolocen integral funkcije tabelirane v vec po simpsonovi
    formuli. Funkcija mora biti tabelirana z vec->d vrednostmi, ki so
    izracunane v enakomernih razmikih h. Ce je stevilo vrednosti liho ali
    manj od 4, se javi napaka. Za izracun uporabi funkcijo intsimptab().
    $A Igor jan01; */
{
if (v==NULL)
{
  errfunc0("intsimpvec");
  fprintf(erf(),"Vector of function values is NULL.\n");
  errfunc2();
  return 0;
} else
  return intsimptab(v->v+1,v->d,h);
}

double intsimptabsafe(double *tab,int n,double h)
    /* Izracuna dolocen integral funkcije tabelirane v tab po simpsonovi
    formuli. Funkcija mora biti tabelirana z n vrednostmi, ki so izracunane
    v enakomernih razmikih h. Ce je n manj od 3 izracuna integral po trapezni
    formuli. Ce je n sod, se izracunz integral prvega intervala po trapezni
    formuli, integral ostalega dela pa po Simpsonovi. Le, ce je n manj od 1,
    se javi napaka. Kazalec tab mora biti taksen, da je prva vrednost funkcije
    v tab[0]. Pozor: pri intsimpbas() je n st. intervalov, tu pa je n st. tock,
    torej za eno vec.
    $A Igor jan01; */
{
if (n<1)
{
  errfunc0("ntsimptabsafe");
  fprintf(erf(),"Number of values (%i) is less than 1.\n",n);
  errfunc2();
  return 0;
} else if (n==1)
  return h*tab[0];
else if (n==2)
  return inttraptab(tab,n,h);
else if ( !(n%2) )
  return inttraptab(tab,2,h)+intsimptab(tab+1,n-1,h);
else
  return intsimptab(tab,n,h);
}

double intsimpvecsafe(vector v,double h)
    /* Izracuna dolocen integral funkcije tabelirane v vec po simpsonovi
    formuli. Funkcija mora biti tabelirana z vec->d vrednostmi, ki so
    izracunane v enakomernih razmikih h. Ce vec->d ni ustrezno stevilo, si
    pomaga s trapezno formulo. Za izracun uporabi funkcijo intsimptabsafe().
    $A Igor jan01; */
{
if (v==NULL)
{
  errfunc0("intsimpvecsafe");
  fprintf(erf(),"Vector of function values is NULL.\n");
  errfunc2();
  return 0;
} else
  return intsimptabsafe(v->v+1,v->d,h);
}




           /*********************************/
           /*                               */
           /*         POLYNOMIALS           */
           /*                               */
           /*********************************/



    /* CALCULATION OF VALUES AND DERIVATIVES OF POLYNOMIAL: */

double valpol(vector v,double x)
    /* Vrne vrednost polinoma, katerega koeficienti so v vektorju v, v tocki
    x.
    $A Igor jul00; */
{
double ret=0;
int i;
if (v==NULL)
  ;
else
  for (i=1;i<=v->d;++i)
    ret+=v->v[i]*intpow(x,i-1);
return ret;
}

double derpol(vector v,double x,int order)
    /* Vrne vrednost odvoda reda order polinoma, katerega koeficienti so v
    vektorju v, v tocki x.
    $A Igor jul00; */
{
double ret=0;
int i,j,coef;
if (v==NULL)
  ;
else if (v->d<1)
  ;
else
  for (i=1+order;i<=v->d;++i)
  {
    coef=1;
    for (j=1;j<=order;++j)
      coef*=i-j;
    ret+=coef*v->v[i]*intpow(x,i-1-order);
  }
return ret;
}




           /************************************/
           /*                                  */
           /*     POLYNOMIAL APPROXIMATION     */
           /*                                  */
           /************************************/



    /* CALCULATION OF ORTHOGONAL POLYNOMIALS ON A SET OF POINTS: */


void ortnormpolbas(vector x,int n,matrix *val0,matrix *coef0,char norm)
    /* Konstruira n ortogonalnih polinomov na tockah, katerih abscise so v
    vektorju x. V matriko *val0 zapise vrednosti posam. polinomov v tockah
    vektorja x (po vrsticah), v matriko *coef0 pa zapise koeficiente polinomov
    (tudi po vrsticah). Sistem ortogonalnih polinomov je uporaben predvsem za
    aproksimacijo s polinomi po metodi najmanjsih kvadratov.
    Ce je norm razlicen od 0, potem polinome tudi normira.
      val0 in coef0 sta lahko enaki NULL, v tem primeru se ustrezni matriki ne
    izracunata.
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
    Ref. Bohte, Num. Met., pp. 86.
    $A Igor jul00; */
{
int i,j,m;
double alpha,beta;
matrix val=NULL,coef=NULL;
double u,v,z,v1;
if (x==NULL)
{
  errfunc0("orthpolbas");
  fprintf(erf(),"Vector of points is NULL.\n");
  errfunc2();
} else if (n>x->d)
{
  errfunc0("orthpolbas");
  fprintf(erf(),"More polinomials than points.\n");
  errfunc2();
} else if (val0==NULL && coef0==NULL)
{
  errfunc0("orthpolbas");
  fprintf(erf(),"Results storage not specified.\n");
  errfunc2();
} else
{
  m=x->d; /* stevilo tock */
  if (val0!=NULL)
    val=*val0;
  if (val!=NULL)
    if (val->d1!=n || val->d2!=m)
      dispmatrix(&val);
  if (val==NULL)
    val=getmatrix(n,m);
  if (val0!=NULL)
    *val0=val;
  if (coef0!=NULL)
  {
    /* Ce je coef0 enak NULL, lahko coef ostane NULL in se koef. ne bo racunalo */
    coef=*coef0;
    if (coef!=NULL)
      if (coef->d1!=n || coef->d2!=n)
        dispmatrix(&coef);
    if (coef==NULL)
      coef=getmatrix(n,n);
    *coef0=coef;
  }
  for (i=1;i<=m;++i)
    val->m[1][i]=1;
  if (coef!=NULL)
  {
    
    for (i=1;i<=coef->d1;++i)
      for (j=1;j<=coef->d2;++j)
        coef->m[i][j]=0;
    
    coef->m[1][1]=1;
    for (i=2;i<=n;++i)
      coef->m[1][i]=0;
  }
  for (i=2;i<=n;++i)
  {
    /* Izracun vrednosti po tockah in koeficientov za i. polinom: */
    /* Izracun clenov za alfa in beta: */
    u=v=0;
    for (j=1;j<=m;++j)
    {
      z=val->m[i-1][j]*val->m[i-1][j];
      u+=x->v[j]*z; /* clen vsote pri stevcu za alfa */
      v+=z;         /* clen vsote pri imenovalcu za alfa in stevcu za beta */
    }
    alpha=u/v;
    /* Prispevek k vrednostim i. polinoma v tockah brez koeficienta beta: */
    for (j=1;j<=m;++j)
      val->m[i][j]=(x->v[j]-alpha)*val->m[i-1][j];
    /* Prispevek k koeficientom i. polinoma brez koeficienta beta: */
    if (coef!=NULL)
    {
      for (j=1;j<i;++j)
        coef->m[i][j]=-alpha*coef->m[i-1][j];
      for (j=i;j<=n;++j)
        coef->m[i][j]=0;
      for (j=1;j<i;++j)
        coef->m[i][j+1]+=coef->m[i-1][j];
    }
    if (i>2)
    {
      beta=v/v1;
      /* Prispevek pri koeficientu beta k tvrednostim i. polinoma: */
      for (j=1;j<=m;++j)
        val->m[i][j]-=beta*val->m[i-2][j];
      /* Prispevek pri koeficientu beta k koeficientom i. polinoma: */
      if (coef!=NULL)
        for (j=1;j<=i-2;++j)
          coef->m[i][j]-=beta*coef->m[i-2][j];
    }
    v1=v; /* prejsnja vsota, ki jo bomo rabili za nasled. beta */
  }
  /* normiranje polinomov: */
  if (norm)
  {
    for (i=1;i<=n;++i)
    {
      u=0;
      for (j=1;j<=m;++j)
        u+=val->m[i][j]*val->m[i][j];
      v=1/sqrt(u);
      for (j=1;j<=m;++j)
        val->m[i][j]*=v;
      if (coef!=NULL)
        for (j=1;j<=n;++j)
          coef->m[i][j]*=v;
    }
  }
  if (val0==NULL)
    dispmatrix(&val);
}
}


void ortpol(vector x,int n,matrix *val,matrix *coef)
    /* Konstruira n ortogonalnih polinomov na tockah, katerih abscise so v
    vektorju x. V matriko *val0 zapise vrednosti posam. polinomov v tockah
    vektorja x (po vrsticah), v matriko *coef0 pa zapise koeficiente polinomov
    (tudi po vrsticah). Sistem ortogonalnih polinomov je uporaben predvsem za
    aproksimacijo s polinomi po metodi najmanjsih kvadratov.
      val0 in coef0 sta lahko enaki NULL, v tem primeru se ustrezni matriki ne
    izracunata.
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
    Ref. Bohte, Num. Met., pp. 86.
    $A Igor jul00; */
{
ortnormpolbas(x,n,val,coef,0);
}

void ortnormpol(vector x,int n,matrix *val,matrix *coef)
    /* Konstruira n ortonormalnih polinomov na tockah, katerih abscise so v
    vektorju x. V matriko *val0 zapise vrednosti posam. polinomov v tockah
    vektorja x (po vrsticah), v matriko *coef0 pa zapise koeficiente polinomov
    (tudi po vrsticah). Sistem ortogonalnih polinomov je uporaben predvsem za
    aproksimacijo s polinomi po metodi najmanjsih kvadratov.
      val0 in coef0 sta lahko enaki NULL, v tem primeru se ustrezni matriki ne
    izracunata.
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
    Ref. Bohte, Num. Met., pp. 86.
    $A Igor jul00; */
{
ortnormpolbas(x,n,val,coef,1);
}



    /* IZRACUN POLINOMSKE APROKSIMACIJE TABELE VREDNOSTI
    S POMOCJO ORTOGONALNIH POLINOMOV NA TABELI TOCK: */


void aportnormpolbas(vector y,int n,matrix val,matrix ortpol,vector *coef0,
    vector *pol0,double *error,char norm)
    /* Izracuna koeficiente lin. aproksimacije tabele vrednosti y z n ortogonalnimi
    polinomi, katerih vrednosti v tockah, na katerih je izracunana tabela, so
    podane v matriki val. Vrstice v tej matriki morajo vsebovati vrednosti
    posameznih polinomov v tockah, na katerih je bila narejena tabela y. V
    vektor coef0 se zapisejo koeficienti aproksimacije pri ortogonalnih
    polinomih, v *pol0 pa kar koeficienti aproksimativnega polinoma (V tem
    primeru MORA biti podana matrika ortpol, ki vsebuje koeficiente
    ortogonalnih polinomov). V *error se zapise napaka aproksimacije, ki se
    izracuna kot koren iz vsote kvadratov odstopanj po tockah, deljen s
    stevilom tock (t.j. povprecni kvadrat odstopanj).
      Ce je norm razlicen od 0, so ortogonalni polinomi v matriki val tudi
    normirani. error je lahko NULL, v tem primeru funkcija ne izracuna napake.
    Tudi edenod argumentov coef0 ali pol0 je lahko NULL, ce katerega od teh
    podatkov ne rabimo (ne pa oba!!!).
      Vhod. parametri:
     y   - vrednosti funkcije, ki jo aproks., v tockah
     n   - stevilo uporabljenih aproksimac. polinomov
     val - matrika vrednosti ort. polinomov v vzorcnih tockah, nad katerimi je
           izracunana tabela y - obvezen podatek!
     ortpol - koeficienti ortogonal. polinomov pri potencah neodvis. sprem.,
           podani morajo biti le, ce je pol0 razlicen od NULL
     norm - mora biti 0, ce ort. polinomi niso normirani
       Izhod. parametri:
     coef0 - koeficienti lin. kombinacije ort. polinomov, ki aproksimira tabelo
          y. Lahko je NULL, ce je pol0 razlic. od NULL.
     pol0  - koeficienti potenc aproksimacijskega polinoma. Lahko je NULL, ce
          je coef0 razlic. od NULL, v tem primeru mora biti tudi ortpol enaka
          NULL. Ce je razlicen od NULL, mora biti ortpol obvezno podan.
     error - napaka aproksimacije (koren iz vsote kvadratov odstopanj, deljen
          s stevilom tock). Lahko je NULL, ce nocemo izracuna koeficientov.
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
      Matrika val vrednosti ort. polinomov v tockah, nad katerimi je
    vzorcena tabela y, mora biti nujno podana in predhodno pravilno izracunana
    (t.j. polinomi morajo biti res ortogonalni na danih tockah in ce je norm
    razlicen od 0, tudi normirani). Podobno velja za matriko koeficientov
    polinomov val v primeru, da hocemo izracunati tudi koeficienta ap polinoma.
    Vsi ti podatki naj bi se izracunali s funkcijo ortpol() ali ortnormpol()!
    $A Igor jul00; */
{
int i,j;
double nf;
vector coef,pol;
if (y==NULL)
{
  errfunc0("linapproxnormpolbas");
  fprintf(erf(),"Vector of values to approximate is NULL.\n");
  errfunc2();
} else if (val==NULL)
{
  errfunc0("linapproxnormpolbas");
  fprintf(erf(),"Value matrix of polinomials is NULL.\n");
  errfunc2();
} else if (y->d<n || n>val->d1 || n<1 || y->d!=val->d2)
{
  errfunc0("linapproxnormpolbas");
  fprintf(erf(),"Dimensions do not match.\n");
  errfunc2();
} else if (coef0==NULL && pol0==NULL)
{
  errfunc0("linapproxnormpolbas");
  fprintf(erf(),"Storage for results not specified.\n");
  errfunc2();
} else
{
  if (ortpol!=NULL)
  {
    if (pol0==NULL)
    {
      errfunc0("linapproxnormpolbas");
      fprintf(erf(),"Storage for polinomial coefficients not specified.\n");
      errfunc2();
    } else if (ortpol->d1<n || ortpol->d1!=ortpol->d2)
    {
      errfunc0("linapproxnormpolbas");
      fprintf(erf(),"Incorrect dimensions of matrix of ort. pol. coefficients.\n");
      errfunc2();
      dispvector(pol0);
    } else
    {
      pol=*pol0;
      if (pol!=NULL)
        if (pol->d!=n)
          dispvector(&pol);
      if (pol==NULL)
        pol=getvector(n);
      *pol0=pol;
    }
  }
  if (coef0!=NULL)
    coef=*coef0;
  if (coef!=NULL)
    if (coef->d!=n)
      dispvector(&coef);
  if (coef==NULL)
    coef=getvector(n);
  /* Izracun koeficientov approksimacijskega polinoma izrazenega z
  ortogonalnimi polinomi: */
  for (i=1;i<=n;++i)
  {
    coef->v[i]=0;
    if (norm)
    {
      for (j=1;j<=y->d;++j)
        coef->v[i]+=y->v[j]*val->m[i][j];
    } else
    {
      nf=0;
      for (j=1;j<=y->d;++j)
        nf+=val->m[i][j]*val->m[i][j];
      nf=1/nf;
      for (j=1;j<=y->d;++j)
        coef->v[i]+=y->v[j]*val->m[i][j]*nf;
    }
  }
  if (pol!=NULL)
  {
    /* Izracun koeficientov aproksimacijskega polinoma pri potencah x: */
    for (i=1;i<=n;++i)
    {
      pol->v[i]=0;
      for (j=i;j<=n;++j)
        pol->v[i]+=coef->v[j]*ortpol->m[j][i];
    }
  }
  if (error!=NULL)
  {
    /* Izracun napake aproksimac. polinoma: */
    *error=0;
    for (i=1;i<=y->d;++i)
    {
      nf=0; /* vrednost ap. pol. v i. tocki */
      for (j=1;j<=n;++j)
        nf+=val->m[j][i]*coef->v[j];
      /*  printf("i = %i, nf=%g.\n",i,nf);  */
      *error+=(nf-y->v[i])*(nf-y->v[i]);
    }
    *error=sqrt(*error)/y->d;
  }
  if (coef0!=NULL)
    *coef0=coef;
  else
    dispvector(&coef);
}
}


void aportpol(vector y,int n,matrix val,matrix ortpol,vector *coef,
    vector *pol,double *error)
    /* Izracuna koeficiente lin. aproksimacije tabele vrednosti y z n
    ortogonalnimi polinomi, katerih vrednosti v tockah, na katerih je
    izracunana tabela y, so podane v matriki val. Za razlago argumentov in
    ostala pojasnila glej funkcijo aportnormpolbas(). Uporablja se v glavnem
    v kombinaciji s  ortpol() z ortnormpol().
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
    $A Igor jul00; */
{
aportnormpolbas(y,n,val,ortpol,coef,pol,error,0);
}

void aportnormpol(vector y,int n,matrix val,matrix ortpol,vector *coef,
    vector *pol,double *error)
    /* Izracuna koeficiente lin. aproksimacije tabele vrednosti y z n
    ORTONORMIRANIMI polinomi, katerih vrednosti v tockah, na katerih je
    izracunana tabela y, so podane v matriki val. Za razlago argumentov in
    ostala pojasnila glej funkcijo aportnormpolbas(). Uporablja se v glavnem
    v kombinaciji z ortnormpol().
      POZOR: pri n>15 postaja racunanje zelo nestabilno!!!
    $A Igor jul00; */
{
aportnormpolbas(y,n,val,ortpol,coef,pol,error,1);
}





void testaportpol(void)
    /* Funkcija za testiranje ortogonalne aproksimacije polinomov.
    $A Igor jul00; */
{
stack st=NULL;
double factor=2,x=0,h0=0.1,hmin=0;
vector points=NULL,y=NULL,lin=NULL,polort=NULL,pol=NULL,yval=NULL,ypol=NULL;
matrix val=NULL;
matrix coef=NULL,ortc=NULL;
double prod,error;
int i,j,k,m=7,n=7;
/* Preizkus funkcij za izracun polinomov in njegovih odvodov: */
/*
y=getvector(4);
y->v[1]=3;
y->v[2]=2;
y->v[3]=1;
y->v[4]=4;
for (i=0;i<=5;++i)
{
  x=i;
  printf("\n\nx = %g:\n",x);
  printf("pol=%g, der0=%g, der1=%g, der2=%g, der3=%g, der4=%g.\n",
  valpol(y,x),derpol(y,x,0),derpol(y,x,1),derpol(y,x,2),derpol(y,x,3),derpol(y,x,4));
}
*/

points=getvector(m);
y=getvector(m);
for (i=1;i<=points->d;++i)
{
  points->v[i]=((double)i-1)/10;
  y->v[i]=exp(points->v[i]);
}

/*
points->v[1]=-0.4;
points->v[2]=-0.2;
points->v[3]=-0.1;
points->v[4]=0;
points->v[5]=0.1;
points->v[6]=0.2;
points->v[7]=0.4;

for (i=1;i<=points->d;++i)
{
  y->v[i]=exp(points->v[i]);
}
*/


printf("Vector of points:\n");
printvector(points);
/* Izracun ortogonalnih polinomov: */
ortpol(points,n,&val,&ortc);
printf("Matrika vrednosti polinomov v tockah:\n");
printmatrix(val);
printf("Matrika koeficientov polinomov:\n");
printmatrix(ortc);
for (i=1;i<=n;++i)
  for (j=1;j<=n;++j)
  {
    prod=0;
    for (k=1;k<=points->d;++k)
      prod+=val->m[i][k]*val->m[j][k];
    printf("prod(%i,%i): %g\n",i,j,prod);
  }
/* Testni izracun matrike vrednosti iz koeficientov: */
dispmatrix(&val); val=getmatrix(n,m);
for (i=1;i<=n;++i)
{
  for (j=1;j<=m;++j)
  {
    val->m[i][j]=0;
    prod=1; /* potenca x v dani tocki */
    for (k=1;k<=n;++k)
    {
      val->m[i][j]+=prod*ortc->m[i][k];
      prod*=points->v[j];
    }
  }
}
printf("Matrika vrednosti po kontrolnem izracunu:\n");
printmatrix(val);

aportpol(y,n,val,ortc,&polort,&pol,&error);
printf("\nn = %i, error = %g\n",n,error);
printf("Abscise, vrednosti tabele in vrednosti aproksimac. pol.:\n");
for (i=1;i<=points->d;++i)
{
  printf("%-9.5g %-14.8g %-14.8g\n",points->v[i],y->v[i],valpol(pol,points->v[i]));
}

--n;
aportpol(y,n,val,ortc,&polort,&pol,&error);
printf("\nn = %i, error = %g\n",n,error);
printf("Abscise, vrednosti tabele in vrednosti aproksimac. pol.:\n");
for (i=1;i<=points->d;++i)
{
  printf("%-9.5g %-14.8g %-14.8g\n",points->v[i],y->v[i],valpol(pol,points->v[i]));
}

/*
--n;
aportpol(y,n,val,ortc,&polort,&pol,&error);
printf("\nn = %i, error = %g\n",n,error);
printf("Abscise, vrednosti tabele in vrednosti aproksimac. pol.:\n");
for (i=1;i<=points->d;++i)
{
  printf("%-9.5g %-14.8g %-14.8g\n",points->v[i],y->v[i],valpol(pol,points->v[i]));
}
*/

}





           /*************************************/
           /*                                   */
           /*      PLOTTING OF FUNCTIONS        */
           /*          IN TEXT MODE             */
           /*                                   */
           /*************************************/




void drawfuncprim(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n,char
     drawxaxis,double level1,double level2,char drawyaxis,double pole1,
     double pole2,int screenwidth,char printcoord,FILE *fp)
    /* Enostavna funkcija za izris funkcij ene spremenljivke na tekstovnem
    zaslonu. func1, func2 in func3 so funkcije, ki jih ta funkcija izrise.
    Katerakoli od teh funkcij je lahko NULL. from in to sta meji intervala,
    na katerem se rise. drawxaxis, drawyaxis in printcoord povejo, ali naj se
    izriseta os x in y ter ali naj se izpisujejo koordinate (0 pomeni ne, 1 pa
    da). Koordinate se izpisujejo na levi ali desni strani, ce je dovolj
    prostora in ce je coord razlicen od 0. Ce je dovolj prostora, se izpiseta
    koordinata x in vrednost funkcije func1, ce pa je prostora manj, se izpise
    samo koordinata x. screenwidth je sirina tekstovnega zaslona v znakih.
    Ce sta level1 in level2 razlicna od 0, se pri njunih vrednostih izriseta
    nivojnici vzporedni z osjo x. Ce sta pole1 in pole2 razlicna od 0, se
    izriseta pola vzporedna z osjo y pri njunih vrednostih.
      Za izris 1. funkcije se uporabi znak *, za izris druge znak +, za izris
    tretje pa znak #. Za izris koordinatnih osi se uporabita znaka - in |, za
    izris polov pa znaka ~ in !. Ce je fp!=NULL, se grafi zapisejo tudi v
    datoteko fp.
    $A Igor jan00; */
{
int i,j,ilevel1,ilevel2,ixaxis,ival,ivalaux,imin,imax;
char spacechar,*line=NULL,*buf=NULL;
double h=0,min,max,x;
vector val1=NULL,val2=NULL,val3=NULL;
if (screenwidth==0)
  screenwidth=78;
line=makestring(screenwidth+1); 
line[screenwidth]='\n';
buf=makestring(50);
if (n<2)
  n=10;
if (func1!=NULL)
  val1=getvector(n);
if (func2!=NULL)
  val2=getvector(n);
if (func3!=NULL)
  val3=getvector(n);
h=(to-from)/(n-1);
x=from;
/* Vrednost v prvi tocki: */
if (func1!=NULL)
  min=max=val1->v[1]=func1(x);
if (func2!=NULL)
  min=max=val2->v[1]=func2(x);
if (func3!=NULL)
  min=max=val3->v[1]=func3(x);
if (func2!=NULL)
{
  if (val2->v[1]<min)
    min=val2->v[1];
  if (val2->v[1]>max)
    max=val2->v[1];
}
if (func1!=NULL)
{
  if (val1->v[1]<min)
    min=val1->v[1];
  if (val1->v[1]>max)
    max=val1->v[1];
}
for (i=2;i<=n;++i)
{
  x+=h;
  if (func1!=NULL)
  {
    val1->v[i]=func1(x);
    if (val1->v[i]>max)
      max=val1->v[i];
    if (val1->v[i]<min)
      min=val1->v[i];
  }
  if (func2!=NULL)
  {
    val2->v[i]=func2(x);
    if (val2->v[i]>max)
      max=val2->v[i];
    if (val2->v[i]<min)
      min=val2->v[i];
  }
  if (func3!=NULL)
  {
    val3->v[i]=func3(x);
    if (val3->v[i]>max)
      max=val3->v[i];
    if (val3->v[i]<min)
      min=val3->v[i];
  }
}
max+=(max-min)/(screenwidth);
/* Nastavitev celih koordinat za os x in razlicne nivoje: */
if (drawxaxis)
  ixaxis=(int) ( 1+round(screenwidth*(0-min)/(max-min)) );
else ixaxis=screenwidth+1;
if (level1!=0)
  ilevel1=(int) ( 1+round(screenwidth*(level1-min)/(max-min)) );
else ilevel1=screenwidth+1;
if (level2!=0)
  ilevel2=(int) ( 1+round(screenwidth*(level2-min)/(max-min)) );
else ilevel2=screenwidth+1;
printf("\n\n\nPlotting from %g to %g, range %g to %g.\n\n",from,to,min,max);
if (fp!=NULL)
  fprintf(fp,"\n\n\nPlotting from %g to %g, range %g to %g.\n\n",from,to,min,max);
x=from;
for (i=1;i<=n;++i)
{
  imin=screenwidth; imax=1;
  if (drawyaxis && x/h>=-0.5 && x/h<0.5)  /* na tem y je os y! */
    spacechar='-';
  else if (pole1!=0 &&  (x-pole1)/h>=-0.5 && (x-pole1)/h<0.5)  /* na tem x je 1. pol */
    spacechar='~';
  else if (pole2!=0 &&  (x-pole2)/h>=-0.5 && (x-pole2)/h<0.5)  /* na tem mestu je 2. pol */
    spacechar='~';
  else
    spacechar=' ';
  for (j=0;j<screenwidth;++j)
    line[j]=spacechar;
  /* Izracunamo, pri katerih celih koordinatah po vrsti se izpisejo znamenja: */
  if (ilevel1<=screenwidth)
  {
    line[ilevel1-1]='!';
    if (ilevel1<imin)
      imin=ilevel1;
    if (ilevel1>imax)
      imax=ilevel1;
  }
  if (ilevel2<=screenwidth)
  {
    line[ilevel2-1]='!';
    if (ilevel2<imin)
      imin=ilevel2;
    if (ilevel2>imax)
      imax=ilevel2;
  }
  if (ixaxis<=screenwidth)
  {
    line[ixaxis-1]='|';
    if (ixaxis<imin)
      imin=ixaxis;
    if (ixaxis>imax)
      imax=ixaxis;
  }
  if (func3!=NULL)
  {
    ival=(int) ( 1+round(screenwidth*(val3->v[i]-min)/(max-min)) );
    if (ival<imin)
      imin=ival;
    if (ival>imax)
      imax=ival;
    if (ival<=screenwidth)
      line[ival-1]='#';
    if (i>1)  /* Povezava s prejsnjo tocko: */
    {
      ivalaux=(int) ( 1+round(screenwidth*(val3->v[i-1]-min)/(max-min)) );
      if (ivalaux<imin)
        imin=ivalaux;
      if (ivalaux>imax)
        imax=ivalaux;
      ivalaux=(ivalaux-ival)/2;
      if (ivalaux<0)
      {
        for (j=-1;j>=ivalaux;--j)
          line[ival+j-1]='#';
      } else if (ivalaux>0)
        for (j=1;j<=ivalaux;++j)
          line[ival+j-1]='#';
    }
    if (i<n)
    {
      ivalaux=(int) ( 1+round(screenwidth*(val3->v[i+1]-min)/(max-min)) );
      if (ivalaux<imin)
        imin=ivalaux;
      if (ivalaux>imax)
        imax=ivalaux;
      ivalaux=(ivalaux-ival)/2;
      if (ivalaux<0)
      {
        for (j=-1;j>ivalaux;--j)
          line[ival+j-1]='#';
      } else if (ivalaux>0)
        for (j=1;j<ivalaux;++j)
          line[ival+j-1]='#';
    }
  }
  if (func2!=NULL)
  {
    ival=(int) ( 1+round(screenwidth*(val2->v[i]-min)/(max-min)) );
    if (ival<imin)
      imin=ival;
    if (ival>imax)
      imax=ival;
    if (ival<=screenwidth)
      line[ival-1]='+';
    if (i>1)  /* Povezava s prejsnjo tocko: */
    {
      ivalaux=(int) ( 1+round(screenwidth*(val2->v[i-1]-min)/(max-min)) );
      if (ivalaux<imin)
        imin=ivalaux;
      if (ivalaux>imax)
        imax=ivalaux;
      ivalaux=(ivalaux-ival)/2;
      if (ivalaux<0)
      {
        for (j=-1;j>=ivalaux;--j)
          line[ival+j-1]='+';
      } else if (ivalaux>0)
        for (j=1;j<=ivalaux;++j)
          line[ival+j-1]='+';
    }
    if (i<n)
    {
      ivalaux=(int) ( 1+round(screenwidth*(val2->v[i+1]-min)/(max-min)) );
      if (ivalaux<imin)
        imin=ivalaux;
      if (ivalaux>imax)
        imax=ivalaux;
      ivalaux=(ivalaux-ival)/2;
      if (ivalaux<0)
      {
        for (j=-1;j>ivalaux;--j)
          line[ival+j-1]='+';
      } else if (ivalaux>0)
        for (j=1;j<ivalaux;++j)
          line[ival+j-1]='+';
    }
  }
  if (func1!=NULL)
  {
    ival=(int) ( 1+round(screenwidth*(val1->v[i]-min)/(max-min)) );
    if (ival<imin)
      imin=ival;
    if (ival>imax)
      imax=ival;
    if (ival<=screenwidth)
      line[ival-1]='X';
    if (i>1)  /* Povezava s prejsnjo tocko: */
    {
      ivalaux=(int) ( 1+round(screenwidth*(val1->v[i-1]-min)/(max-min)) );
      if (ivalaux<imin)
        imin=ivalaux;
      if (ivalaux>imax)
        imax=ivalaux;
      ivalaux=(ivalaux-ival)/2;
      if (ivalaux<0)
      {
        for (j=-1;j>=ivalaux;--j)
          line[ival+j-1]='*';
      } else if (ivalaux>0)
        for (j=1;j<=ivalaux;++j)
          line[ival+j-1]='*';
    }
    if (i<n)
    {
      ivalaux=(int) ( 1+round(screenwidth*(val1->v[i+1]-min)/(max-min)) );
      if (ivalaux<imin)
        imin=ivalaux;
      if (ivalaux>imax)
        imax=ivalaux;
      ivalaux=(ivalaux-ival)/2;
      if (ivalaux<0)
      {
        for (j=-1;j>ivalaux;--j)
          line[ival+j-1]='*';
      } else if (ivalaux>0)
        for (j=1;j<ivalaux;++j)
          line[ival+j-1]='*';
    }
  }
  /* Izpis koordinat za func1, ce ta ni enaka NULL: */
  if (printcoord && func1!=NULL)
  {
    if (imin-1>30 && screenwidth>30)
    {
      sprintf(buf,"(%g,%g)\0",x,val1->v[i]);
      if (strlen(buf)<=30)
        for (j=0;j< (int) strlen(buf);++j)
          line[j]=buf[j];
    } else if (screenwidth-imax>30)
    {
      sprintf(buf,"(%g,%g)\0",x,val1->v[i]);
      if (strlen(buf)<=30)
        for (j=0;j< (int) strlen(buf);++j)
          line[screenwidth-1-strlen(buf)+j]=buf[j];
    } else if (imin-1>15 && screenwidth>30)
    {
      sprintf(buf,"%g\0",x);
      if (strlen(buf)<=15)
        for (j=0;j< (int) strlen(buf);++j)
          line[j]=buf[j];
    } else if (screenwidth-imax>15)
    {
      sprintf(buf,"%g\0",x);
      if (strlen(buf)<=15)
        for (j=0;j< (int) strlen(buf);++j)
          line[screenwidth-1-strlen(buf)+j]=buf[j];
    }
  }
  printf("%s",line);
  if (fp!=NULL)
    fprintf(fp,"%s",line);
  x+=h;
}
printf("Plotting from %g to %g, range %g to %g.\n\n\n",from,to,min,max);
if (fp!=NULL)
  fprintf(fp,"Plotting from %g to %g, range %g to %g.\n\n\n",from,to,min,max);
dispvector(&val1);
dispvector(&val2);
dispvector(&val3);
disppointer((void **) &line);
disppointer((void **) &buf);
}     





void drawfuncprimint(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n,char
     drawxaxis,double level1,double level2,char drawyaxis,double pole1,
     double pole2,int screenwidth,char printcoord,FILE *fp)
    /* Enostavna funkcija za interaktiven izris funkcij ene spremenljivke na
    tekstovnem zaslonu. Za izris se uporablja funkcija drawfuncprim(),
    uporabnik pa lahko v tej funkciji interaktivno spreminja vse parametre
    razen funkcij, ki se izrisejo. Ce je fp!=NULL, se grafi izrisejo tudi v
    datoteko fp.
    $A Igor jan01; */
{
double cont=1,dn=n,ddrawxaxis=drawxaxis,ddrawyaxis=drawyaxis,
       dscreenwidth=screenwidth,dprintcoord=printcoord;
while (cont)
{
  drawfuncprim(func1,func2,func3,from,to,n,drawxaxis,level1,level2,drawyaxis,
    pole1,pole2,screenwidth,printcoord,fp);
  printf("Plot once more (0/1)? ");
  readdouble(&cont);
  if (cont)
  {
    printf("\n\nLeft  limit (now %14g): ",from);
    readdouble(&from);
    printf("Right limit (now %14g): ",to);
    readdouble(&to);
    printf("Number of points (now %i): ",(int) dn);
    readdouble(&dn); n= (int) dn;
    printf("Draw the x axis (0/1, nov %i)? ",(int) ddrawxaxis);
    readdouble(&ddrawxaxis);  drawxaxis= (char) ddrawxaxis;
    printf("Draw the y axis (0/1, nov %i)? ",(int) ddrawyaxis);
    readdouble(&ddrawyaxis);  drawyaxis= (char) ddrawyaxis;
    printf("Print coordinates (0/1, nov %i)? ",(int) ddrawxaxis);
    readdouble(&dprintcoord);  printcoord= (char) dprintcoord;
    printf("Enter levels and poles to draw (zero means not to draw that pole or level).\n");
    printf("First level  (now %14g): ",level1); readdouble(&level1);
    printf("Second level (now %14g): ",level2); readdouble(&level2);
    printf("First pole  (now %14g): ",pole1); readdouble(&pole1);
    printf("Second pole (now %14g): ",pole2); readdouble(&pole2);
    printf("Screen width (now %i): ",(int) dscreenwidth);
    readdouble(&dscreenwidth); screenwidth= (int) dscreenwidth;
  }
}
}

void drawfuncprimintaddr(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double *from,double *to,int *n,char
     *drawxaxis,double *level1,double *level2,char *drawyaxis,double *pole1,
     double *pole2,int *screenwidth,char *printcoord,FILE *fp)
    /* Enostavna funkcija za interaktiven izris funkcij ene spremenljivke na
    tekstovnem zaslonu. Za izris se uporablja funkcija drawfuncprim(),
    uporabnik pa lahko v tej funkciji interaktivno spreminja vse parametre
    razen funkcij, ki se izrisejo. Parametri so isti kot pri drawfuncprim(),
    le da ta funkcija vecinoma vzame naslove parametrov, da si lahko zapomnimo
    spremenjene parametre. Ce je fp!=NULL, se grafi izrisejo tudi v
    datoteko fp.
    $A Igor jan01; */
{
double cont=1,dn=*n,ddrawxaxis=*drawxaxis,ddrawyaxis=*drawyaxis,
       dscreenwidth=*screenwidth,dprintcoord=*printcoord;
while (cont)
{
  drawfuncprim(func1,func2,func3,*from,*to,*n,*drawxaxis,*level1,*level2,
    *drawyaxis,*pole1,*pole2,*screenwidth,*printcoord,fp);
  printf("Plot once more (0/1)? ");
  readdouble(&cont);
  if (cont)
  {
    printf("\n\nLeft  limit (now %14g): ",*from);
    readdouble(from);
    printf("Right limit (now %14g): ",*to);
    readdouble(to);
    printf("Number of points (now %i): ",(int) dn);
    readdouble(&dn); *n= (int) dn;
    printf("Draw the x axis (0/1, nov %i)? ",(int) ddrawxaxis);
    readdouble(&ddrawxaxis);  *drawxaxis= (char) ddrawxaxis;
    printf("Draw the y axis (0/1, nov %i)? ",(int) ddrawyaxis);
    readdouble(&ddrawyaxis);  *drawyaxis= (char) ddrawyaxis;
    printf("Print coordinates (0/1, nov %i)? ",(int) dprintcoord);
    readdouble(&dprintcoord);  *printcoord= (char) dprintcoord;
    printf("Enter levels and poles to draw (zero means not to draw that pole or level).\n");
    printf("First level  (now %14g): ",*level1); readdouble(level1);
    printf("Second level (now %14g): ",*level2); readdouble(level2);
    printf("First pole  (now %14g): ",*pole1); readdouble(pole1);
    printf("Second pole (now %14g): ",*pole2); readdouble(pole2);
    printf("Screen width (now %i): ",(int) dscreenwidth);
    readdouble(&dscreenwidth); *screenwidth= (int) dscreenwidth;
  }
}
}


void drawfuncsimp(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n)
    /* Narise grafe funkcij func1, func2 in func3 od from do to z n tockami.
    $A Igor jan01; */
{
char drawxaxis=1;
double level1=0,level2=0;
char drawyaxis=1;
double pole1=0,pole2=0;
int screenwidth=78;
char printcoord=1;
FILE *fp=NULL;
drawfuncprimint(func1,func2,func3,from,to,n,drawxaxis,level1,level2,drawyaxis,
 pole1,pole2,screenwidth,printcoord,fp);
}


void fdrawfuncsimp(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n,FILE *fp)
    /* Narise grafe funkcij func1, func2 in func3 od from do to z n tockami.
    Ce je fp razlicen od NULL, se izrisejo funkcije tudi v datoteko.
    $A Igor jan01; */
{
char drawxaxis=1;
double level1=0,level2=0;
char drawyaxis=1;
double pole1=0,pole2=0;
int screenwidth=78;
char printcoord=1;
drawfuncprimint(func1,func2,func3,from,to,n,drawxaxis,level1,level2,drawyaxis,
 pole1,pole2,screenwidth,printcoord,fp);
}


void  drawfuncsimpcont(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n)
    /* Narise grafe funkcij func1, func2 in func3 od from do to z n tockami.
    FUNKCIJA NE DELA INTERAKTIVNO.
    $A Igor mar01; */
{
char drawxaxis=1;
double level1=0,level2=0;
char drawyaxis=1;
double pole1=0,pole2=0;
int screenwidth=78;
char printcoord=1;
FILE *fp=NULL;
drawfuncprim(func1,func2,func3,from,to,n,drawxaxis,level1,level2,drawyaxis,
 pole1,pole2,screenwidth,printcoord,fp);
}

void fdrawfuncsimpcont(double (*func1) (double x),double (*func2) (double x),
     double (*func3) (double x),double from,double to,int n,FILE *fp)
    /* Narise grafe funkcij func1, func2 in func3 od from do to z n tockami.
    Ce je fp razlicen od NULL, se izrisejo funkcije tudi v datoteko.
    FUNKCIJA NE DELA INTERAKTIVNO.
    $A Igor mar01; */
{
char drawxaxis=1;
double level1=0,level2=0;
char drawyaxis=1;
double pole1=0,pole2=0;
int screenwidth=78;
char printcoord=1;
drawfuncprim(func1,func2,func3,from,to,n,drawxaxis,level1,level2,drawyaxis,
 pole1,pole2,screenwidth,printcoord,fp);
}


static vector pv1=NULL,pv2=NULL,pv3=NULL;

static double pv1val(double ind)
    /* Pomozna funkcija za plotvec */
{
int i;
if (pv1==NULL)
  return 0;
else
{
  i= (int) round(ind);
  if(i<1 || i>pv1->d)
    return 0;
  else
    return pv1->v[i];
}
}

static double pv2val(double ind)
    /* Pomozna funkcija za plotvec */
{
int i;
if (pv2==NULL)
  return 0;
else
{
  i= (int) round(ind);
  if(i<1 || i>pv2->d)
    return 0;
  else
    return pv2->v[i];
}
}

static double pv3val(double ind)
    /* Pomozna funkcija za plotvec */
{
int i;
if (pv3==NULL)
  return 0;
else
{
  i= (int) round(ind);
  if(i<1 || i>pv3->d)
    return 0;
  else
    return pv3->v[i];
}
}

void plotvector(vector v1,vector v2,vector v3,int forcen,FILE *fp)
    /* Izrise komponente vektorja v v odvisnosti od indeksa s pomocjo funkcije
    drawfuncprimintaddr. Ce je forcen vecji od 0, se na zacetku izrise forcen
    tock, drugace se na zacetku izrise toliko tock, kolikor je dimenzija
    vektorja. V vsakem primeru je zacetni interval od 1 do dimenzije vektorja.
    Ce je fp!=NULL, se grafi izrisejo tudi v datoteko fp.
    $A Igor jan01; */
{
int n;
char drawxaxis=0,drawyaxis=0;
double from,to;
double level1=0,level2=0;
double pole1=0,pole2=0;
int screenwidth=79;
double (*func1)(double)=NULL;
double (*func2)(double)=NULL;
double (*func3)(double)=NULL;
char printcoord=1;
pv1=v1; pv2=v2;pv3=v3;
if (v1!=NULL) func1=pv1val; if (v2!=NULL) func2=pv2val; if (v3!=NULL) func3=pv3val;
from=1; to=0;
if (v1!=NULL) to=v1->d;
if (v2!=NULL) if (v2->d>to) to=v2->d;
if (v3!=NULL) if (v3->d>to) to=v3->d;
if (to>0)
{
  if (forcen>0)
    n=forcen;
  else
    n=(int) (to-from+1);
  drawfuncprimintaddr(pv1val,pv2val,pv3val,&from,&to,&n,&drawxaxis,
     &level1,&level2,&drawyaxis,&pole1,&pole2,&screenwidth,&printcoord,fp);
}
}

void plotvec(vector v,int forcen,FILE *fp)
    /* Izrise komponente vektorja v v odvisnosti od indeksa s pomocjo funkcije
    drawfuncprimintaddr. Ce je forcen vecji od 0, se na zacetku izrise forcen
    tock, drugace se na zacetku izrise toliko tock, kolikor je dimenzija
    vektorja. V vsakem primeru je zacetni interval od 1 do dimenzije vektorja.
    Ce je fp!=NULL, se grafi izrisejo tudi v datoteko fp.
    $A Igor jan01; */
{
int n;
char drawxaxis=0,drawyaxis=0;
double from,to;
double level1=0,level2=0;
double pole1=0,pole2=0;
int screenwidth=79;
char printcoord=1;
pv1=v;
if (v!=NULL)
{
  from=1; to=v->d;
  if (forcen>0)
    n=forcen;
  else
    n=v->d;
  drawfuncprimintaddr(pv1val,NULL,NULL,&from,&to,&n,&drawxaxis,
     &level1,&level2,&drawyaxis,&pole1,&pole2,&screenwidth,&printcoord,fp);
}
}


void plotvectorcont(vector v1,vector v2,vector v3,int forcen,FILE *fp)
    /* Izrise komponente vektorja v v odvisnosti od indeksa s pomocjo funkcije
    drawfuncprimintaddr. Ce je forcen vecji od 0, se na zacetku izrise forcen
    tock, drugace se na zacetku izrise toliko tock, kolikor je dimenzija
    vektorja. V vsakem primeru je zacetni interval od 1 do dimenzije vektorja.
    Ce je fp!=NULL, se grafi izrisejo tudi v datoteko fp.
    FUNKCIJA NE DELA INTERAKTIVNO.
    $A Igor mar01; */
{
int n;
char drawxaxis=0,drawyaxis=0;
double from,to;
double level1=0,level2=0;
double pole1=0,pole2=0;
int screenwidth=79;
double (*func1)(double)=NULL;
double (*func2)(double)=NULL;
double (*func3)(double)=NULL;
char printcoord=1;
pv1=v1; pv2=v2;pv3=v3;
if (v1!=NULL) func1=pv1val; if (v2!=NULL) func2=pv2val; if (v3!=NULL) func3=pv3val;
from=1; to=0;
if (v1!=NULL) to=v1->d;
if (v2!=NULL) if (v2->d>to) to=v2->d;
if (v3!=NULL) if (v3->d>to) to=v3->d;
if (to>0)
{
  if (forcen>0)
    n=forcen;
  else
    n=(int) (to-from+1);
  drawfuncprim(pv1val,pv2val,pv3val,from,to,n,drawxaxis,
     level1,level2,drawyaxis,pole1,pole2,screenwidth,printcoord,fp);
}
}

void plotveccont(vector v,int forcen,FILE *fp)
    /* Izrise komponente vektorja v v odvisnosti od indeksa s pomocjo funkcije
    drawfuncprimintaddr. Ce je forcen vecji od 0, se na zacetku izrise forcen
    tock, drugace se na zacetku izrise toliko tock, kolikor je dimenzija
    vektorja. V vsakem primeru je zacetni interval od 1 do dimenzije vektorja.
    Ce je fp!=NULL, se grafi izrisejo tudi v datoteko fp.
    FUNKCIJA NE DELA INTERAKTIVNO.
    $A Igor mar01; */
{
int n;
char drawxaxis=0,drawyaxis=0;
double from,to;
double level1=0,level2=0;
double pole1=0,pole2=0;
int screenwidth=79;
char printcoord=1;
pv1=v;
if (v!=NULL)
{
  from=1; to=v->d;
  if (forcen>0)
    n=forcen;
  else
    n=v->d;
  drawfuncprim(pv1val,NULL,NULL,from,to,n,drawxaxis,
     level1,level2,drawyaxis,pole1,pole2,screenwidth,printcoord,fp);
}
}


static matrix pm=NULL;

static double pmval(double x)
    /* Pomozna funkcija za plotmat2 */
{
int i,n;
double from,to;
if (pm==NULL)
  return 0;
else if (pm->d1!=2)
  return 0;
else
{
  n=pm->d2;
  from=pm->m[1][1];
  to=pm->m[1][n];
  i= (int) round(1+(n-1)*(x-from)/(to-from));
  if(i<1 || i>pm->d2)
    return 0;
  else
    return pm->m[2][i];
}
}

void plotmat2(matrix m,int forcen,FILE *fp)
    /* Izrise komponente 2. vrstice matrike m v odvisnosti od komponente 1.
    vrstice, ki mora linearno narascati, s pomocjo funkcije
    drawfuncprimintaddr. Ce je forcen vecji od 0, se na zacetku izrise
    forcen tock, drugace se na zacetku izrise toliko tock, kolikor je 2.
    dimenzija matrike. V vsakem primeru je zacetni interval od 1 do 2.
    dimenzije matrike. Ce je fp!=NULL, se grafi izrisejo tudi v datoteko fp.
    $A Igor jan01; */
{
int n;
char drawxaxis=1,drawyaxis=1;
double from,to;
double level1=0,level2=0;
double pole1=0,pole2=0;
int screenwidth=79;
char printcoord=1;
pm=m;
if (m!=NULL)
{
  from=m->m[1][1]; to=m->m[1][m->d2];
  if (forcen>0)
    n=forcen;
  else
    n=m->d2;
  drawfuncprimintaddr(pmval,NULL,NULL,&from,&to,&n,&drawxaxis,
     &level1,&level2,&drawyaxis,&pole1,&pole2,&screenwidth,&printcoord,fp);
}
}






           /************************************************/
           /*                                              */
           /*      CONVERSION TO LOWER NUMBER OF BITS      */
           /*                                              */
           /************************************************/


void emptyrounddouble(double *x)
    /* Z *x ne naredi nic. */
{
;
}
void emptyroundfloat(float *x)
    /* Z *x ne naredi nic. */
{
;
}
void emptyroundlong(long *x)
    /* Z *x ne naredi nic. */
{
;
}

static long underflow=0,overflow=0;

/* Funkcije za zaokrozevanje stevil: */
static void (*prounddouble) (double *x) = emptyrounddouble;
static void (*proundfloat) (float *x) = emptyroundfloat;
static void (*proundlong) (long *x) = emptyroundlong;

void rounddouble (double *x)
    /* Zaokrozi stevilo tipa double *x po sistemu zaokrozevanja, ki je trenutno
    v veljavi.
    $A Igor feb01; */
{
prounddouble(x);
}

void roundfloat (float *x)
    /* Zaokrozi stevilo tipa long *x po sistemu zaokrozevanja, ki je trenutno
    v veljavi.
    $A Igor feb01; */
{
proundfloat(x);
}

void roundlong (long *x)
    /* Zaokrozi stevilo tipa float *x po sistemu zaokrozevanja, ki je trenutno
    v veljavi.
    $A Igor feb01; */
{
proundlong(x);
}


void resetoverflowcount(void)
    /* Stevce overflowov in underflowov postavi na 0.
    $A Igor feb01;  */
{
underflow=overflow=0;
}

void resetrounding(void)
    /* Sistem postavi nazaj v stanje brez zaokrozevanj. Resetira tudi stevce
    underflowov in overflowov.
    $A Igor feb01; */
{
prounddouble = emptyrounddouble;
proundfloat = emptyroundfloat;
proundlong = emptyroundlong;
resetoverflowcount();
}

long getunderflowcount(void)
    /* Vrne vrednost stevca underflowov.
    $A Igor feb01; */
{
return underflow;
}

long getoverflowcount(void)
    /* Vrne vrednost stevca underflowov.
    $A Igor feb01; */
{
return overflow;
}

/* Celostevilska aritmetika s predznakom: */

static double roundrange=1;
static long roundmaxnum=32768; /* 16 bit, signed */

static void signedfixedpointrounddouble(double *x)
    /* Zaokrozi stevilo tipa double po signed fixed point sistemu. Uporablja
    lokalni spremenljivki roundrange in roundmaxnum.
    $A Igor feb01; */
{
long l;
l=(long) round((*x/roundrange)*roundmaxnum);
if (l>roundmaxnum)
{
  ++overflow;
  l=roundmaxnum;
} else if (l<-roundmaxnum)
{
  ++underflow;
  l=-roundmaxnum;
}
*x=roundrange*((double) l/(double) roundmaxnum);
}

static void signedfixedpointroundfloat(float *x)
    /* Zaokrozi stevilo tipa float po signed fixed point sistemu. Uporablja
    lokalni spremenljivki roundrange in roundmaxnum.
    $A Igor feb01; */
{
long l;
l=(long) round((*x/roundrange)*roundmaxnum);
if (l>roundmaxnum)
{
  ++overflow;
  l=roundmaxnum;
} else if (l<-roundmaxnum)
{
  ++underflow;
  l=-roundmaxnum;
}
*x=(float) ( roundrange*((double) l/(double) roundmaxnum) );
}

static void signedfixedpointroundlong(long *x)
    /* Zaokrozi stevilo tipa long po signed fixed point sistemu. Uporablja
    lokalni spremenljivki roundrange in roundmaxnum.
    $A Igor feb01; */
{
long l;
l=(long) round((*x/roundrange)*roundmaxnum);
if (l>roundmaxnum)
{
  ++overflow;
  l=roundmaxnum;
} else if (l<-roundmaxnum)
{
  ++underflow;
  l=-roundmaxnum;
}
*x=(long) round( roundrange*((double) l/(double) roundmaxnum) );
}



void setroundsignfixbit(double range,int numbits)
    /* Postavi zaokrozevanje na signed fixed point z numbits bitno
    reprezentacijo in obsegom range. Funkcija resetira stevec underflowov in
    overflowov. En bit v reprezentaciji je rezerviran za predznak.
    $A Igor feb01; */
{
if (numbits<2)
{
  errfunc0("setroundsignfixbit");
  fprintf(erf(),"Number of bits (%i) is less than 2.\n",numbits);
  errfunc2();
} else if (range<=0)
{
  errfunc0("setroundsignfixbit");
  fprintf(erf(),"Range (%g) is less than0.\n",range);
  errfunc2();
} else if (numbits>8*sizeof(long))
{
  errfunc0("setroundsignfixbit");
  fprintf(erf(),"Unable to represent %i bits. Only %i bits can be presented.\n",
   numbits,8*sizeof(long));
  errfunc2();
}
roundrange=range;
roundmaxnum=1;
if (numbits-1>0) /* En bit se porabi za predznak */
  roundmaxnum<<=(numbits-1);
/* Postavijo se funkcije za zaokrozevanje: */
prounddouble = signedfixedpointrounddouble;
proundfloat = signedfixedpointroundfloat;
proundlong = signedfixedpointroundlong;
resetoverflowcount();
printf("\nRounding set to fixed point; resolution=%li, range=%g.\n\n",
 roundmaxnum,roundrange); 
}


void setroundsignfixnum(double range,long maxnum)
    /* Postavi zaokrozevanje na signed fixed point z resolucijo maxnum v
    plus in minus in obsegom range. Funkcija resetira stevec underflowov in
    overflowov. Funkcija je podobna setroundsignfixbit(), le da se namesto
    stevila bitov direktno postavi najvecje predstavljivo pozitivno celo
    stevilo (locljivost).
    $A Igor feb01; */
{
if (maxnum<1)
{
  errfunc0("setroundsignfixbit");
  fprintf(erf(),"Resolution (%i) is less than 1.\n",maxnum);
  errfunc2();
} else if (range<=0)
{
  errfunc0("setroundsignfixbit");
  fprintf(erf(),"Range (%g) is less than0.\n",range);
  errfunc2();
}
roundrange=range;
roundmaxnum=maxnum;
/* Postavijo se funkcije za zaokrozevanje: */
prounddouble = signedfixedpointrounddouble;
proundfloat = signedfixedpointroundfloat;
proundlong = signedfixedpointroundlong;
resetoverflowcount();
printf("\nRounding set to fixed point; resolution=%li, range=%g.\n\n",
 roundmaxnum,roundrange); 
}










    /* TEST FUNCTION FOR THIS MODULE: */


static double funcsin(double x,void *ptr)
   /* Test function */
{
return sin(x-0.);
}

static double funcexp(double x,void *ptr)
   /* Test function */
{
return exp(x)-1;
}


static double funcpow(double x,void *ptr)
   /* Test function */
{
return pow(x,7)-1.;
}


void testnumut(void)
    /* A set of tests for numut.c. Switch individual tests on or off by
    setting conditions to 0 or 1.
    $A Igor mar05; */
{
if (1)
{
  /* Test for numerical calculation of a simple zero of 1D function  */
  double from=-20.;
  double to=42.;
  double tolx=1e-6,tolf=1e-7;
  double xzero,fzero;
  int ret,niter,maxit=100;
  double (*func) (double,void *)=funcpow;

  /* function declaration, should be removed later */
  int zerofunc1dsimpint0(double func(double,void *),void *clientdata,
          double x1,double x2, double tolx,double tolf,int maxit,
          double *xzero,double *fzero,int *niter);
  
  printf("Algorithm for finding a simple bracketed zero:\n");
  printf("[x1,x2]=[%g, %g], tolx=%g, tolf=%g, maxit=%i \n\nCalculating... ",
      from,to,tolx,tolf,maxit);

  ret=zerofunc1dsimpint0(func,NULL,from,to,tolx,tolf,maxit,
            &xzero,&fzero,&niter);

  printf("  Done.\n\n");
  printf("Num. it.: %i, x = %g, f = %g.\n\n",niter,xzero,fzero);

  if (0)   /* Test of quadratic interpolation */
  {
    double aux,
      x1=-0.5,
      x2=0.1,
      x3=0.2,
      f1=3.,
      f2=2.,
      f3=4.,
      zero1=0,zero2=0,a2,a1,a0;
    int numzeros=0;

    printf("\nTEST OF SQUARE INTERPOLATION\n");
    sqrcoefval(x1,f1,x3,f3,x2,f2,&a2,&a1,&a0);    
    printf("\nData: (%.3g, %.3g), (%.3g, %.3g), (%.3g, %.3g)\n",
           x1,f1,x2,f2,x3,f3);
    printf("Parabola: %.3g x^2 + %.3g x + %.3g\n",a2,a1,a0);

    m_swap2(x1,f1,x2,f2,aux);  printf("\n\nx1 and x2 swapped.\n");
    sqrcoefval(x1,f1,x3,f3,x2,f2,&a2,&a1,&a0);    
    printf("\nData: (%.3g, %.3g), (%.3g, %.3g), (%.3g, %.3g)\n",
           x1,f1,x2,f2,x3,f3);
    printf("Parabola: %.3g x^2 + %.3g x + %.3g\n",a2,a1,a0);

    m_swap2(x3,f3,x1,f1,aux);  printf("\n\nx3 and x1 swapped.\n");
    sqrcoefval(x1,f1,x3,f3,x2,f2,&a2,&a1,&a0);    
    printf("\nData: (%.3g, %.3g), (%.3g, %.3g), (%.3g, %.3g)\n",
           x1,f1,x2,f2,x3,f3);
    printf("Parabola: %.3g x^2 + %.3g x + %.3g\n",a2,a1,a0);

    m_swap2(x1,f1,x2,f2,aux);  printf("\n\nx1 and x2 swapped.\n");
    sqrcoefval(x1,f1,x3,f3,x2,f2,&a2,&a1,&a0);    
    printf("\nData: (%.3g, %.3g), (%.3g, %.3g), (%.3g, %.3g)\n",
           x1,f1,x2,f2,x3,f3);
    printf("Parabola: %.3g x^2 + %.3g x + %.3g\n",a2,a1,a0);

    m_swap2(x1,f1,x2,f2,aux);  printf("\n\nx1 and x2 swapped.\n");
    m_swap2(x2,f2,x3,f3,aux);  printf("\nx2 and x3 swapped.\n");
    sqrcoefval(x1,f1,x3,f3,x2,f2,&a2,&a1,&a0);    
    printf("\nData: (%.3g, %.3g), (%.3g, %.3g), (%.3g, %.3g)\n",
           x1,f1,x2,f2,x3,f3);
    printf("Parabola: %.3g x^2 + %.3g x + %.3g\n",a2,a1,a0);

  }
}


}




