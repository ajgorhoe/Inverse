

              /**********************************/
              /*                                */
              /*  BASIC OPEN INTERFACE LIBRARY  */
              /*                                */
              /**********************************/

/* THIS MODULE PROVIDES AN OPEN INTERFACE UTILITIES FOR ACCESSING PROGRAM
CALCULATOR, FILE INTERPRETER AND VARIABLE SYSTEM. */



#include <stdlib.h>

#include <sysint.h>
#include <mtypes.h>
#include <st.h>
#include <strop.h>
#include <fop.h>
#include <er.h>
#include <varop.h>
#include <fint.h>


#include <invvar.h>

#include <invoplib.h>

#include <inv.h>


#ifndef INVCLOSED


/* Datotecni interpreter: */

static ficom curinterp=NULL;

static stack
  strvarst=NULL,       /* Sklad, na katerega se spravijo definirani nizi */
  countvarst=NULL,     /* Sklad, na katerega se spravijo definirani stevci */
  scalvarst=NULL,      /* Sklad, na katerega se spravijo definirani skalarji */
  vecvarst=NULL,       /* Sklad, na katerega se spravijo definirani vektorji */
  matvarst=NULL,       /* Sklad, na katerega se shranejo uporabnisko definirane matrike */
  vfivarst=NULL,       /* Datotecne spremenljivke */
  fldvarst=NULL;       /* Spremenljivke, ki nosijo polja */





              /*********************************************/
              /*                                           */
              /*  BRANJE ARGUMENTOV FUNKCIJ INTERPRETERJA  */
              /*                                           */
              /*********************************************/



FILE *getinterpfile(void)
    /* Vrne datoteko, ki se jo trenutno interpretira.
    $A Igor jul99; */
{
return com.fcom->fp;
}

long getargblockbegin(void)
    /* Vrne zacetno pozicijo argumentnega bloka funkcije, ki se jo trenutno
    interpretira.
    $A Igor jul99; */
{
return com.fcom->begin+1;
}

long getargblockend(void)
    /* Vrne koncno pozicijo argumentnega bloka funkcije, ki se jo trenutno
    interpretira.
    $A Igor jul99; */
{
return com.fcom->end-1;
}

long getargblockpos(void)
    /* Vrne trenutno pozicijo v argumentnem bloku funkcije, ki se jo trenutno
    interpretira.
    $A Igor okt99; */
{
if (com.fcom->argpos>com.fcom->begin && com.fcom->argpos<com.fcom->end)
  return com.fcom->argpos;
else
  return -1;
}

void setargblockpos(long pos)
    /* Postavi trenutno pozicijo v argumentnem bloku funkcije, ki se jo
    trenutno interpretira, na pos.
    $A Igor okt99; */
{
com.fcom->argpos=pos;
}


/* FUNKCIJE ZA BRANJE ARGUMENTOV FUNKCIJ DATOTECNEGA INTERPRETERJA
S PODANO DATOTEKO IN POZICIJAMI: */

/* Spodnje funkcije so namenjene za branje argumentov funkcij datotecnega
interpreterja v programu Inverse. Za argumente zahtevajo datoteko, ki se
interpretira (fp) in obmocje, v katerem naj iscejo argumente (of from do to),
naslova, kamor naj zapisejo sacetno pozicijo najdenih argumentov in pozicijo
1. znaka za prebranimi argumenti (start in next) , naslov, kamor naj zapisejo
prebrane argumente in morebitne dodatne parametre. Funkcije vrnejo kodo, ki
pove, ce je bilo branje argumentov uspesno (negativna vrednost pomeni neuspeh;
funkcije za branje vec argumentov hkrati vrnejo stevilo uspesno prebranih
argumentov). Ostale potrebne podatke (npr. sistem za ovrednotenje izrazov in
sklade, na katerih so spremenljivke) dobijo funkcije iz globalnih spremenljivk
programa. */ 


int getvalarg(FILE *fp,long from,long to,double *val,long *start,long *next)
    /* Prebere stevilcni argument in ga zapise v *val.
    $A Igor jul99; */
{
return freadnumarg(fp,val,from,to,com.fcom->syst,start,next);
}

int getvalargs(FILE *fp,long from,long to,int maxnum,stack *valst,
               long *start,long *next)
    /* Prebere najvec maxnum stevilcnih argumentov in njihove vrednosti polozi
    na sklad *valst kot kazalce na tip double. Vrne stevilo prebranih
    argumentov oz. -1, ce je kaj narobe.
    $A Igor jul99; */
{
return freadnumargs(fp,from,to,maxnum,com.fcom->syst,valst,start,next);
}

int getcountarg(FILE *fp,long from,long to,counter *cnt,long *start,long *next)
    /* Prebere stevcni argument in ga zapise v *cnt.
    $A Igor jul99; */
{
return freadcountarg(fp,cnt,from,to,com.count,com.str,com.fcom->syst,
       start,next);
}

int getscalarg(FILE *fp,long from,long to,scalar *scal,long *start,long *next)
    /* Prebere skalarni argument in ga zapise v *scal.
    $A Igor jul99; */
{
return freadscalarg(fp,scal,from,to,com.scal,com.str,com.fcom->syst,
       start,next);
}

int getvecarg(FILE *fp,long from,long to,vector *vec,long *start,long *next)
    /* Prebere vektorski argument in ga zapise v *vec.
    $A Igor jul99; */
{
return freadvecarg(fp,vec,'{','}',from,to,com.vec,com.str,com.fcom->syst,
       start,next);
}

int getmatarg(FILE *fp,long from,long to,matrix *mat,long *start,long *next)
    /* Prebere matricni argument in ga zapise v *mat.
    $A Igor jul99; */
{
return freadmatarg(fp,mat,'{','}',':',from,to,com.mat,com.str,com.fcom->syst,
       start,next);
}

int getfldarg(FILE *fp,long from,long to,field *fld,long *start,long *next)
    /* Prebere poljski argument in ga zapise v *fld.
    $A Igor jul99; */
{
return freadfldarg(fp,fld,'{','}',':',from,to,com.fld,com.str,com.fcom->syst,
       start,next);
}

int getstrarg(FILE *fp,long from,long to,string *str,long *start,long *next)
    /* Prebere nizovni argument in ga zapise v *str.
    $A Igor jul99; */
{
return freadstrarg(fp,str,from,to,com.str,com.fcom->syst,
       start,next);
}

int getstrargs(FILE *fp,long from,long to,int maxnum,stack *st,
               long *start,long *next)
    /* Prebere najvec maxnum nizovnih argumentov in jih nalozi na sklad *st
    kot kazalce tipa char *. Ce je maxnum 0, stevilo argumentov ni omejeno.
    $A Igor jul99; */
{
return freadstrargs(fp,from,to,maxnum,com.str,com.fcom->syst,st,
       start,next);
}

int getvarspecarg(FILE *fp,long from,long to,char **name,stack *indst,
               long *start,long *next)
    /* Prebere specifikacijo elementa ali podtabele spremanljivke. Ime shrane
    v *name, indekse pa nalozi na sklad *indst kot kazalce na int.
    $A Igor jul99; */
{
return freadvarspec(fp,from,to,com.fcom->syst,name,indst,start,next);
}


/* ENOSTAVNE FUNKCIJE ZA BRANJE ARGUMENTOV FUNKCIJ DATOTECNEGA INTERPRETERJA
BREZ PODANE DATOTEKE IN POZICIJ: */

/* Naslednje funkcije imajo za argument le naslov, kamor naj shranjo prebrane
vrednosti, in po moznosti se kak dodaten argument. Ostale podatke dobijo od
datotecnega interpreterja. Ko preberemo argument s taksno funkcijo, se postavi
pozicija iskanja naslednjega argumenta. To se ne zgodi pri uporabi drugih
funkcij (zgoraj), zato lahko spodnje funkcije upporabljamo le v kombinaciji s
podobnimi funkciji. Zacetno pozicijo iskanja za 1. argument funkcije
interpreterja postavi sam interpreter. */


int getvalargsimp(double *val)
    /* Prebere stevilcni argument in ga zapise v *val.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=getvalarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   val,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int getvalargssimp(int maxnum,stack *valst)
    /* Prebere najvec maxnum stevilcnih argumentov in njihove vrednosti polozi
    na sklad *valst kot kazalce na tip double. Vrne stevilo prebranih
    argumentov oz. -1, ce je kaj narobe.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=getvalargs(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   maxnum,valst,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int getcountargsimp(counter *cnt)
    /* Prebere stevcni argument in ga zapise v *cnt.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=getcountarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   cnt,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int getscalargsimp(scalar *scal)
    /* Prebere skalarni argument in ga zapise v *scal.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=getscalarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   scal,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int getvecargsimp(vector *vec)
    /* Prebere vektorski argument in ga zapise v *vec.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=getvecarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   vec,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int getmatargsimp(matrix *mat)
    /* Prebere matricni argument in ga zapise v *mat.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=getmatarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   mat,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int getfldargsimp(field *fld)
    /* Prebere poljski argument in ga zapise v *fld.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=getfldarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   fld,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int getstrargsimp(string *str)
    /* Prebere nizovni argument in ga zapise v *str.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=getstrarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   str,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int getstrargssimp(int maxnum,stack *st)
    /* Prebere najvec maxnum nizovnih argumentov in jih nalozi na sklad *st
    kot kazalce tipa char *. Ce je maxnum 0, stevilo argumentov ni omejeno.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=getstrargs(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   maxnum,st,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int getvarspecargsimp(char **name,stack *indst)
    /* Prebere specifikacijo elementa ali podtabele spremanljivke. Ime shrane
    v *name, indekse pa nalozi na sklad *indst kot kazalce na int.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=getvarspecarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   name,indst,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}




           /**************************************************/
           /*                                                */
           /*  MANIPULACIJA Z UPORABNISKIMI SPREMENLJIVKAMI  */
           /*                                                */
           /**************************************************/



/* POMOZNE FUNKCIJE ZA MANIPULACIJO S SPREMENLJIVKAMI */


stack getvariablestack(char *spec)
    /* Vrne sklad, na katerem so spremenljivke, katerih tip ustreza
    specifikaciji spec. spec je dogovorjen niz, ki doloca tip spremenljivk.
    $A Igor jul99; */
{
if ( cmpstrings(spec,"count")==0 || cmpstrings(spec,"counter")==0 )
  return com.count;
else if ( cmpstrings(spec,"scal")==0 || cmpstrings(spec,"scalar")==0 )
  return com.scal;
if ( cmpstrings(spec,"vec")==0 || cmpstrings(spec,"vector")==0 )
  return com.vec;
if ( cmpstrings(spec,"mat")==0 || cmpstrings(spec,"matrix")==0 )
  return com.mat;
if ( cmpstrings(spec,"fld")==0 || cmpstrings(spec,"field")==0 )
  return com.fld;
if ( cmpstrings(spec,"str")==0 || cmpstrings(spec,"string")==0 )
  return com.str;
if ( cmpstrings(spec,"vfi")==0 || cmpstrings(spec,"vfile")==0 )
  return com.vfi;
return NULL;  /* Ce ni prepoznana nobena specifikacija. */
}



static int createvar0(stack varst,char *name,stack dim,void (*dispel)
       (void **))
    /* Naredi spremenljivko z imenom name in dimenzijami dim na skladu varst.
    Ce spremenljivka s tem imenom na skladu ze obstaja, se jo najprej zbrise
    z elementi vred. dispel() je funkcija za brisanje posameznih elementov.
    Dimenzije na skladu dim morajo biti tipa int *. Funkcija vrne mesto na
    skladu varst, na katerega vrine nosilec spremenljivke, oziroma 0, ce
    spremenljivke ne naredi.
    $A Igor avg99; */
{
int place=0;
place=findsortstackvar(varst,name,0,0);
if (place>0)
{
  dispwholevarspec((varholder *)&(varst->s[place]),
   (void (*)(void **)) dispel);
  varst->s[place]=newvarholdernamest(name,dim);
} else
{
  place=inssortstackvar(varst,newvarholdernamest(name,dim));
}
return place;
}



static int vardimension0(stack varst,char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije spremenljivke z imenom name na skladu
    varst. Nalozene dimenzije so tipa int *. Vrne mesto na skladu varst, na
    katerem se nahaja spremenljivka (ce je to manj ali enako 0, spremenljivka
    ne obstaja).
    $A Igor avg99; */
{
int place;
place=findsortstackvar(varst,name,0,0);
if (place>0)
  getvardimst(varst->s[place],dim);
else
{
  dispstackval(*dim);
  dispstack(dim);
}
return place;
}


static int varexists0(stack varst,char *name)
    /* Vrne 0, ce spremenljivka z imenom name ne obstaja na skladu varst,
    drugace vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke
    na skladu.
    $A Igor avg99; */
{
int place;
place=findsortstackvar(varst,name,0,0);
if (place<=0)
  place=0;
return place;
}




/* FUNKCIJE, KI NAREDIJO NOVO SPREMENLJIVKO (ce spremenljivka z danim imenom
ze obstaja, se jo najprej zbrise z elementi vred): */


varholder updatecountdata(char *name,int place);
varholder updatescaldata(char *name,int place);
varholder updatevecdata(char *name,int place);
varholder updatematdata(char *name,int place);
varholder updateflddata(char *name,int place);
varholder updatestrdata(char *name,int place);
varholder updatevfidata(char *name,int place);

void dispvfile(vfile *vfp);

int createvar(char *spec,char *name,stack dim)
    /* Naredi spremenljivko z imenom name in dimenzijami dim, katere tip je
    dolocen s spec. spec mora biti specifikacija, ki je razumnljiva funkciji
    getvariablestack(). Ce spremenljivka z imenom name ze obstaja, se jo
    najprej zbrise z elementi vred.
    $A Igor avg99; */
{
int place=0;
stack varst;
varst=getvariablestack(spec);
if (place!=0)
{
  if (varst==com.count)
  {
    place=createvar0(varst,name,dim, (void (*)(void **)) disppointer);
    updatecountdata(name,place);
  } else if (varst==com.scal)
  {
    place=createvar0(varst,name,dim, (void (*)(void **)) disppointer);
    updatescaldata(name,place);
  } else if (varst==com.vec)
  {
    place=createvar0(varst,name,dim, (void (*)(void **)) dispvector);
    updatevecdata(name,place);
  } else if (varst==com.mat)
  {
    place=createvar0(varst,name,dim, (void (*)(void **)) dispmatrix);
    updatematdata(name,place);
  } else if (varst==com.fld)
  {
    place=createvar0(varst,name,dim, (void (*)(void **)) dispfield);
    updateflddata(name,place);
  } else if (varst==com.str)
  {
    place=createvar0(varst,name,dim, (void (*)(void **)) disppointer);
    updatestrdata(name,place);
  } else if (varst==com.vfi)
  {
    place=createvar0(varst,name,dim, (void (*)(void **)) dispvfile);
    updatevfidata(name,place);
  }
}
return place;
}


int createcountvar(char *name,stack dim)
    /* Naredi stevcno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=createvar0(com.count,name,dim, (void (*)(void **)) disppointer);
updatecountdata(name,place);
return place;
}


int createscalvar(char *name,stack dim)
    /* Naredi skalarno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=createvar0(com.scal,name,dim, (void (*)(void **)) disppointer);
updatescaldata(name,place);
return place;
}


int createvecvar(char *name,stack dim)
    /* Naredi vektorsko spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=createvar0(com.vec,name,dim, (void (*)(void **)) disppointer);
updatevecdata(name,place);
return place;
}


int creatematvar(char *name,stack dim)
    /* Naredi matricno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=createvar0(com.mat,name,dim, (void (*)(void **)) disppointer);
updatematdata(name,place);
return place;
}


int createfldvar(char *name,stack dim)
    /* Naredi poljsko spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=createvar0(com.fld,name,dim, (void (*)(void **)) disppointer);
updateflddata(name,place);
return place;
}


int createstrvar(char *name,stack dim)
    /* Naredi nizovno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=createvar0(com.str,name,dim, (void (*)(void **)) disppointer);
updatestrdata(name,place);
return place;
}


int createvfivar(char *name,stack dim)
    /* Naredi datotecno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=createvar0(com.vfi,name,dim, (void (*)(void **)) disppointer);
updatevfidata(name,place);
return place;
}




/* FUNKCIJE, KI VRACAJO NASLOVE ELEMENTOV SPREMENLJIVK: */


void **getvareladdr(char *spec,char *name,stack indst)
    /* Vrne naslov elementa spremenljivke, katere tip je dolocen s spec, imena
    name in z indeksno specifikacijo indst. Specifikacija tipa spremenljivke
    spec mora biti taksna, kot jo dovoljuje funkcija getvariablestack().
    $A Igor jul99; */
{
stack varst;
int place;
varst=getvariablestack(spec);
place=findsortstackvar(varst,name,0,0);
if (place==0)
  return NULL;
else
  return vareladdrst(varst->s[place],indst);
}

counter *getcounteladdr(char *name,stack indst)
    /* Vrne naslov elementa stevcne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.count,name,0,0);
if (place==0)
  return NULL;
else
  return (counter *) vareladdrst(com.count->s[place],indst);
}

scalar *getscaleladdr(char *name,stack indst)
    /* Vrne naslov elementa skalarne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.scal,name,0,0);
if (place==0)
  return NULL;
else
  return (scalar *) vareladdrst(com.scal->s[place],indst);
}

vector *getveceladdr(char *name,stack indst)
    /* Vrne naslov elementa vektorske spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.vec,name,0,0);
if (place==0)
  return NULL;
else
  return (vector *) vareladdrst(com.vec->s[place],indst);
}

matrix *getmateladdr(char *name,stack indst)
    /* Vrne naslov elementa matricne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.mat,name,0,0);
if (place==0)
  return NULL;
else
  return (matrix *) vareladdrst(com.mat->s[place],indst);
}

field *getfldeladdr(char *name,stack indst)
    /* Vrne naslov elementa poljske spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.fld,name,0,0);
if (place==0)
  return NULL;
else
  return (field *) vareladdrst(com.fld->s[place],indst);
}

string *getstreladdr(char *name,stack indst)
    /* Vrne naslov elementa nizovne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.str,name,0,0);
if (place==0)
  return NULL;
else
  return (string *) vareladdrst(com.str->s[place],indst);
}

vfile *getvfieladdr(char *name,stack indst)
    /* Vrne naslov elementa datotecne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.vfi,name,0,0);
if (place==0)
  return NULL;
else
  return (vfile *) vareladdrst(com.vfi->s[place],indst);
}





/* FUNKCIJE, KI VRACAJO ELEMENTE SPREMENLJIVK: */


void *getvarel(char *spec,char *name,stack indst)
    /* Vrne element spremenljivke, katere tip je dolocen s spec, imena
    name in z indeksno specifikacijo indst. Specifikacija tipa spremenljivke
    spec mora biti taksna, kot jo dovoljuje funkcija getvariablestack().
    $A Igor jul99; */
{
stack varst;
int place;
varst=getvariablestack(spec);
place=findsortstackvar(varst,name,0,0);
if (place==0)
  return NULL;
else
  return varelst(varst->s[place],indst);
}

counter getcountel(char *name,stack indst)
    /* Vrne element stevcne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.count,name,0,0);
if (place==0)
  return NULL;
else
  return varelst(com.count->s[place],indst);
}

scalar getscalel(char *name,stack indst)
    /* Vrne element skalarne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.scal,name,0,0);
if (place==0)
  return NULL;
else
  return varelst(com.scal->s[place],indst);
}

vector getvecel(char *name,stack indst)
    /* Vrne element vektorske spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.vec,name,0,0);
if (place==0)
  return NULL;
else
  return varelst(com.vec->s[place],indst);
}

matrix getmatel(char *name,stack indst)
    /* Vrne element matricne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.mat,name,0,0);
if (place==0)
  return NULL;
else
  return varelst(com.mat->s[place],indst);
}

field getfldel(char *name,stack indst)
    /* Vrne element poljske spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.fld,name,0,0);
if (place==0)
  return NULL;
else
  return varelst(com.fld->s[place],indst);
}

string getstrel(char *name,stack indst)
    /* Vrne element nizovne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.str,name,0,0);
if (place==0)
  return NULL;
else
  return varelst(com.str->s[place],indst);
}

vfile getvfiel(char *name,stack indst)
    /* Vrne element datotecne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
int place;
place=findsortstackvar(com.vfi,name,0,0);
if (place==0)
  return NULL;
else
  return varelst(com.vfi->s[place],indst);
}



/* FUNKCIJE, KI VRNEJO DIMENZIJE SPREMENLJIVK: */


int vardimension(char *spec,char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije spremenljivke z imenom name in tipa, ki
    ga doloca spec (ime tipa mora biti prepoznavno za funkcijo
    getvariablestack). Nalozene dimenzije so tipa int *. Vrne mesto na skladu,
    na katerem se nahaja spremenljivka.
    $A Igor avg99; */
{
stack varst;
varst=getvariablestack(spec);
return vardimension0(varst,name,dim);
}

int countvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije stevcne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return vardimension0(com.count,name,dim);
}

int scalvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije skalarne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return vardimension0(com.scal,name,dim);
}

int vecvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije vektorske spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return vardimension0(com.vec,name,dim);
}

int matvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije matricne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return vardimension0(com.mat,name,dim);
}

int fldvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije poljske spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return vardimension0(com.fld,name,dim);
}

int strvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije nizovne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return vardimension0(com.str,name,dim);
}

int vfivardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije datotecne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return vardimension0(com.vfi,name,dim);
}



/* FUNKCIJE, KI TESTIRAJO OBSTOJ SPREMENLJIVK: */


int varexists(char *spec, char *name)
{
stack varst;
varst=getvariablestack(spec);
return varexists0(varst,name);
}


int countvarexists0(char *name)
    /* Vrne 0, ce stevcna spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
int place;
place=findsortstackvar(com.count,name,0,0);
if (place<=0)
  place=0;
return place;
}

int scalvarexists0(char *name)
    /* Vrne 0, ce skalarna spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
int place;
place=findsortstackvar(com.scal,name,0,0);
if (place<=0)
  place=0;
return place;
}

int vecvarexists0(char *name)
    /* Vrne 0, ce vektorska spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
int place;
place=findsortstackvar(com.vec,name,0,0);
if (place<=0)
  place=0;
return place;
}

int matvarexists0(char *name)
    /* Vrne 0, ce matricna spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
int place;
place=findsortstackvar(com.mat,name,0,0);
if (place<=0)
  place=0;
return place;
}

int fldvarexists0(char *name)
    /* Vrne 0, ce poljska spremenljivka z imenom name ne obstaja, drugace vrne
    pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
int place;
place=findsortstackvar(com.fld,name,0,0);
if (place<=0)
  place=0;
return place;
}

int strvarexists0(char *name)
    /* Vrne 0, ce nizovna spremenljivka z imenom name ne obstaja, drugace vrne
    pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
int place;
place=findsortstackvar(com.str,name,0,0);
if (place<=0)
  place=0;
return place;
}

int vfivarexists0(char *name)
    /* Vrne 0, ce datotecna spremenljivka z imenom name ne obstaja, drugace vrne
    pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
int place;
place=findsortstackvar(com.vfi,name,0,0);
if (place<=0)
  place=0;
return place;
}




/* OPERACIJE NAD PODTABELAMI ELEMENTOV SPREMENLJIVK: */


int varopsimple(char *spec,char *name,stack which,
                void operation(void *operand))
    /* Izvede operacijo operation nad elementi podtabele spremenljivke z imenom
    name in tipa, ki ga doloca specifikacija spec. Ta mora biti prepoznavna za
    fnkcijo getvariablestack(). Podtabelo elementov doloca indeksna
    specifkacija which.
    $A Igor avg99; */
{
return simpvaropnamesortst(getvariablestack(spec),name,which,operation);
}


int varopunary(char *spec,char *name,stack which,
               char *specres,char *nameres,stack whichres,
               void *operation(void *operand1,void **res),void disp(void **))
    /* Izvede operacijo operation nad enakoleznimi pari elementov podtabel
    spremenljivk, ki ju dolocata specifikaciji tipa spremenljivke spec in
    specres, imeni spremenljivk name in nameres ter specifikaciji tabele which
    in whichres. operation je unarna operacija, ki se izvede na enem objektu,
    rezultat pa
    shrane v drugega.
    $A avg99; */
{
return unvaropnamesortst(getvariablestack(spec),name,which,
                getvariablestack(specres),nameres,whichres,
                operation,NULL);
}


int varopbinary(char *spec1,char *name1,stack which1,
                char *spec2,char *name2,stack which2,
                char *specres,char *nameres,stack whichres,
                void *operation(void *operand1,void *operand2,void **res))
    /* Izvede operacijo operation nad istoleznimi trojicami elementov podtabel
    spremenljivk, ki jih dolocajo specifikacije tipa spremenljivk spec1, spec2
    in specres, imena spremenljivk name1, name2 in nameres ter specifikacije
    tabele which, which1 in whichres. operation je binarna operacija, ki se
    izvede na dveh, rezultat pa shrane v tretjegs.
    $A avg99; */
{
return binvaropnamesort(getvariablestack(spec1),name1,which1,
                getvariablestack(spec2),name2,which2,
                getvariablestack(specres),nameres,whichres,
                operation,NULL);
}





/* TESTI FUNKCIJ ZA BRANJE ARGUMENTOV: */



/* FUNKCIJE ZA DELO S KALKULATORJEM */


void assigncalcvar(char *name,double val)
    /* Spremenljivki kalkulatorja z imenom name priredi vrednost val. Ce taksna
    spremenljivka se ne obstaja, se naredi na novo.
    $A Igor jul99; */
{
assigndouble(com.fcom->syst,name,val);
}


double getnumcalcargs(void)
    /* Vrne stevilo argumentov, s katerim je klicana funkcija kalkulatorja, ki
    se trenutno vrednoti.
    */
{
return 0;  /* POPRAVI!!! */
}

double getcalcargument(int i,int *kind,char **str)
    /* Vrne vrednost i-tega argumenta funkcije kalkulatorja, ki se trenutno
    vrednoti. V kind se zapise, ali je to stevilo (v tem primeru se njegova
    vrednost vrne) ali niz (v tem primeru se njegova vrednost zapise v *str).
    */
{
return 0;  /* POPRAVI!!! */
}


#endif /* ifndef INVCLOSED */


