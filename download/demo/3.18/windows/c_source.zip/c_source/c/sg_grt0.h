
#include <sysint.h>

#include <stdlib.h>
#include <stddef.h>
#include <math.h>
#include <stdarg.h>

#include <mtypes.h>
#include <rf.h>
#include <st.h>
#include <vec.h>
#include <strop.h>
#include <er.h>
#include <rf.h>
#include <rand.h>
#include <mtime.h>
#include <itk.h>
#include <globut.h>

#include <sg_obj.h>
#include <grint.h>
#include <gro.h>
#include <sg_graph.h>

#include <sg_draw.h>
#include <sg_intfc.h>
#include <sg_ploto.h>





double fxy(double x,double y)
{
  return (sin(x)*sin(y));
}


/*
char *sg_psfontspec(sg_font font)
{
char buf[500],*ptr;
if (font==NULL)
  return NULL;
ptr+=sprintf(buf,font->family);
}
*/


int godrawstackitk(stack st);

void giraisewindow(void);
int gigetwindow(void);



int main()
{
double fi=30,theta=15,hfi=5,htheta=2;
double t0=0,t1=0,t2=0,t3=0,t4=0,t5=0,t6=0,ct0=0,ct1=0,ct2=0,ct3=0,ct4=0,ct5=0,ct6=0;
int win,win1,numx=20,divx=5; int numy=20,divy=5;
int i=0,j=0,k=0,l=0;
frame3d winlimits=NULL,frame=NULL;
golinesettings ls;
gofillsettings fs;
gotextsettings ts;
gogroup g1=NULL,g2=NULL,g3=NULL,g4=NULL,g5=NULL;
stack st=NULL;

int id1=1,id2=2;
char *res=NULL;
int code=0;



printf("Main thread: %i.\n\n",ismainthread());





/*
*/

sg_nsetwindowwidth(800);
sg_nsetwindowheight(400);
if (1)
{
  for (i=1;i<=1;++i)
  {
    test_sg_intfc(0,1,"0_SGS_test",3, 1,2,3,4,5,6,7,8,9,10,   0);
  }
}


sg_interface(SG_PLOT_BASIC);





/* Open an itk shell */
res=itk_interpretcp("itk_shellbas {SGS} {This is an ITK aux. shell.} {SGS> } {} {}",
                    &code);
if (!tcl_okcode(code))
{
  errfunc0("main");
  sprintf(ers(),"ITK error:\n%s",res);
  errfunc2();
}


printf("Main thread po init. ITK: %i.\n\n",ismainthread());




/*
waituserresponse();
*/

/* Test of windows: */

sg_setwindowheight(0.2f);
sg_setwindowwidth(0.3f);
sg_setwindowxpos(0.f);
sg_setwindowypos(0.f);

id1=sg_openwindow();
printf("Window %i opened.\n",id1);
sg_setwindowxpos(0.5f);
sg_setwindowypos(0.2f);
id2=sg_openwindow();
printf("Window %i opened.\n",id2);
sg_setwindow(id1);
printf("Window %i activated.\n",id1);

/*
waituserresponse();
*/




/* Test menujev: */
st=newstack(5);
j=0;
while (j==1)
{
  globutmessagesimp("This is a test of messages, menues and dialogs.");
  st->n=0;
  pushstack(st,"Red");
  pushstack(st,"Green");
  pushstack(st,"Blue");
  pushstack(st,"Yellow");
  pushstack(st,"Magenta");
  pushstack(st,"Violet");
  pushstack(st,"Purple");
  j=globutmenusimp("Please choose a color!",st);
  if (j>0)
    printf("You have chosen %i (%s).\n",j,st->s[j]);
  else
    printf("You have made no choice.\n");
  st->n=0;
  pushstack(st,"Continue");
  pushstack(st,"Stop");
  j=globutdialogsimp("Continue testing?",st);
  if (j>0)
    printf("You have chosen %i (%s).\n",j,st->s[j]);
  else
    printf("You have made no choice.\n");
}




t0=absolutetime(); ct0=cputime();  /* Time measurement: */
t0=absolutetime(); ct0=cputime();  /* Time measurement: */
printf("\n\n");



/* Odprtje okna: */
/* giinitdisplay();  */
sg_setwindowtitle("SGS");
sg_setwindowxpos(0.6f); sg_setwindowypos(0.f);
sg_setwindowwidth((float) 0.3); sg_setwindowheight((float) 0.4);
win=sg_openwindow();
sg_setwindowtitle("SGS 1");
win1=sg_openwindow();


/*
giinitgraph();
*/

/* Locljivost grafa: */
numx=10; divx=1; numy=10; divy=1;

/* Okvir v oknu, v katerega naj pade graf: */
winlimits=malloc(sizeof(*winlimits));
winlimits->min.x=0.1; winlimits->min.y=0.0; winlimits->max.x=0.7; winlimits->max.y=0.8;
/* Geometrijske meje grafa: */
frame=malloc(sizeof(*frame));
frame->min.x=-1.3;    frame->min.y=-1.3;    frame->min.z=-1.3;
frame->max.x=1.3;     frame->max.y=1.3;     frame->max.z=1.3;


/* Nastavitve za risanje crt: */
ls=malloc(sizeof(*ls));
ls->color.red=(float) 0; ls->color.green=(float) 0.7; ls->color.blue=(float) 0.4;
ls->linewidth=1;
ls->linetype=1;

/* Nastavitve za risanje ploskev: */
fs=malloc(sizeof(*fs));
fs->color.red=0; fs->color.green=0; fs->color.blue=1;

/* Nastavitve za risanje teksta: */
ts=malloc(sizeof(*ts));
ts->color.red=(float) 0.5; ts->color.green=(float) 0.1; ts->color.blue=(float) 0.7;
ts->font=1;
ts->height=0.025;
ts->expansion=1;
ts->xalignment=0;
ts->yalignment=0;


t1=absolutetime(); ct1=cputime();
printf("Preparation: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
  t1-t0,ct1-ct0,t1-t0,ct1-ct0);


/* Sestava Graficnih objektov: */
/* Okvir in ravnila: */
g1=gomakeframe3d(frame,ls,ls,numx*divx+numy*divy,numx*divx+numy*divy,
                 numx*divx+numy*divy);
g2=gomakerulers3d(frame,ls,ls,ls,10,0.02,0.06,0.1);
g3=gomakerulertext3d(frame,ts,6,10,3,0.1);


t2=absolutetime(); ct2=cputime();
printf("Rulers etc.: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
  t2-t0,ct2-ct0,t2-t1,ct2-ct1);


/* Graf: */
g4=gosurfaceplot(fxy,numx,divx,numy,divy,frame,fs,ls,3,2);
g5=NULL;

t3=absolutetime(); ct3=cputime();
printf("Graphs:      %g s (CPU %g s), pure: %g s (CPU %g s)\n",
  t3-t0,ct3-ct0,t3-t2,ct3-ct2);



st=newstack(50);
goloadtostack(g1,st);
goloadtostack(g2,st);
goloadtostack(g3,st);
goloadtostack(g4,st);
goloadtostack(g5,st);

t4=absolutetime(); ct4=cputime();
printf("Loading:     %g s (CPU %g s), pure: %g s (CPU %g s)\n",
  t4-t0,ct4-ct0,t4-t3,ct4-ct3);


/*
while(1)
{
  sg_setwindow(id1);
  sg_raisewindow();
  sg_setwindow(id2);
  sg_raisewindow();
  sg_setwindow(win);
  sg_raisewindow();
}
*/


printf("\n\n");
t0=absolutetime();
ct0=cputime();
t1=absolutetime();
ct1=cputime();
printf("Acquisition: %g s,  t = %g s\n",ct1-ct0,t1-t0);
t2=absolutetime();
ct2=cputime();
printf("Acquisition: %g s,  t = %g s\n",ct2-ct0,t2-t0);
t3=absolutetime();
ct3=cputime();
printf("Acquisition: %g s,  t = %g s\n",ct3-ct0,t3-t0);
t4=absolutetime();
ct4=cputime();
printf("Acquisition: %g s,  t = %g s\n",ct4-ct0,t4-t0);
t0=t1=t3=t3=t4=0;


/* Risanje: */
i=1;
while (1)
{
  ++i;
  printf("\n\n");
  
  t0=absolutetime();  ct0=cputime();
  fi+=hfi; theta+=htheta; /* Nov pogled */
  /* Naatavitev pretvorb iz koordinat objekta v okenske koordinate: */
  preparegraph3dbas(frame,winlimits);
  gosettransfsimp(rad(fi),rad(theta));
  
  t1=absolutetime();  ct1=cputime();
  
  /* Transformacija primitivov na skladu st: */
  gotransfstack(st);
  
  t2=absolutetime();  ct2=cputime();
  printf("Transforming: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t2-t0,ct2-ct0,t2-t1,ct2-ct1);
  
  gosortstack(st);
  
  t3=absolutetime();  ct3=cputime();
  printf("Sorting:      %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t3-t0,ct3-ct0,t3-t2,ct3-ct2);
  
  /* Izris: */
  if (i==1)
    sg_setwindow(win);
  else
  {
    sg_setwindow(win1);
    i=0;
  }
  sg_resetwindow();

  t4=absolutetime();  ct4=cputime();
  printf("Reset:        %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t4-t0,ct4-ct0,t4-t3,ct4-ct3);
  
  sg_godrawstack(st);
  sg_raisewindow();

  t5=absolutetime();  ct5=cputime();
  printf("Drawing:      %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t5-t0,ct5-ct0,t5-t4,ct5-ct4);
  
  sg_interface(SG_PLOT_PS);
  sg_openwindow();
  sg_godrawstack(st);
  sg_closewindow();
  sg_interface(SG_PLOT_ITK);

  t6=absolutetime();  ct6=cputime();
  printf("Drawing to Tcl file: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t6-t0,ct6-ct0,t6-t5,ct6-ct5);

  
  /*
  giflushdisplay();
  */
  /*
  godxffiledrawstack("0.dxf",st);
  printf("Writing finished.\n");
  printf("Writing a Tcl file.\n");
  gotclfiledrawstack("0.tcl",st);
  printf("Writing finished.\n");
  printf("Writing a PostScript file.\n");
  gopsfiledrawstack("0.eps",st);
  printf("Writing finished.\n");
  */

  /*
  sleep(0);
  printf("\nSleep ... ");
  tcl_sleep(0.00);
  printf("... do not sleep any more.\n\n");
  */

}
}
