

#define EXTRACE   /* Switch on tracing */

#ifdef EXTRACE
  #undef EXTRACE    /* Switch off tracing */
#endif


#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>



#include <er.h>

#include <mtypes.h>
#include <mat.h>
#include <vec.h>
#include <min1d.h>

#include <minnd.h>


#if 0
#ifdef CFSQP

/* Funkcije za algoritem CFSQP; naslednjih dveh ukazov "include" ne sme biti
pred "include <stdlib.h>!!!! */
#include "cfsqp/qld.c"
#include "cfsqp/cfsqp.c"

void setcfsqpout(FILE *fp)
  /* Postavi datoteko, na katero se bodo izpisovali izpisi funkcije cfsqp.
  $A Igor feb99; */
{
/*
if (fp==NULL)
  glob_prnt.out=stdout;
else
*/
  glob_prnt.out=fp;
}

/*************************************************************************

       KOMENTARJI PRI VKLJUCITVI CFSQP V minnd.c

  Pri vkljucitvi je potrebno nekoliko spremeniti datoteko cfsqp.c in sicer na
sledeci nacin:

1. Pri deklaraciji strukture glob_prnt je potrebno dodati polje FILE *out !
2. Pri vsakem stavku fprintf(glob_prnt.io, ... ) je treba dodati stavek
if (glob_prnt.out!=NULL) fprintf(glob_prnt.out, ... ), tako da se hkrati na
datoteko glob_prnt.out izpisuje vse, kar se izpise na datoteko glob_prnt.io.

Pri klicu funkcije cfsqp() je treba vedno paziti, da s funkcijo setcfsqpout()
dolocimo datoteko, kamor bo funkcija cfsqp zapisovala rezultate in vmesne
podatke.

**************************************************************************/

#else /* not defined CFSQP */

void ext_cfsqp(int nparam,int nf,int nfsr,int nineqn,int nineq,int neqn,
      int neq,int ncsrl,int ncsrn,int *mesh_pts,
      int mode,int iprint,int miter,int *inform,double bigbnd,
      double eps,double epseqn,double udelta,double *bl,double *bu,
      double *x,double *f,double *g,double *lambda,
      void (*obj)(int, int, double *, double *,void *),
      void (*constr)(int,int,double *,double *,void *),
      void (*gradob)(int,int,double *,double *, 
                     void (*)(int,int,double *,double *,void *),void *),
      void (*gradcn)(int,int,double *,double *, 
                     void (*)(int,int,double *,double *,void *),void *),
      void *cd)
{
printf("\n\n\nError: The routine cfsqp is not available!\n\n\n");
}

void grobfd(int nparam,int j,double *x,double *gradf,
            void (*obj)(int,int,double *,double *,void *),void *cd)
{
printf("\n\n\nError: The routine cfsqp is not available!\n\n\n");
}
	       
void grcnfd(int nparam,int j,double *x,double *gradg,
            void (*constr)(int,int,double *,double *,void *),void *cd)
{
printf("\n\n\nError: The routine cfsqp is not available!\n\n\n");
}

void setcfsqpout(FILE *fp)
{
printf("\n\n\nError: The routine cfsqp is not available!\n\n\n");
}

#endif /* not defined CFSQP */

#endif  /* #if 0 */



int minndemptycon (int i)
{
return i;
}



void getsimp(matrix simp, int n)
     /* Naredi simpleks v n dimenzijah. */
{
getmat(simp,n+1,n);
}

void dispsimp(matrix simp, int n)
     /* Sprosti spomin, ki ga zaseda simpleks */
{
dispmat(simp);
}








void printsimp(struct _matrix simp)
     /* Izpise ogljisca simpleksa. */
{
int i,j;
for (i=1; i<=simp.d1; ++i)
{
  printf("\n");
  for (j=1; j<=simp.d2; ++j)
  {
    printf("  x%i[%i] = %g",i,j,simp.m[i][j]);
  }
}
printf("\n");
}





void getsimpcenter(struct _matrix simp, vector vec)
     /* V vektor vec zapise sredisce simpleksa simp. */
{
int i,j;
if (vec->d!=simp.d2 || vec->v==NULL)
{
  dispvec(vec);
  getvec(vec,simp.d2);
}
for (i=1; i<=simp.d2;++i)
{
  vec->v[i]=0;
  for (j=1; j<=simp.d1; ++j)
    vec->v[i]+=simp.m[j][i];
  vec->v[i]/=simp.d1;
}
}





/*
double vfunc(vector x)
       /* Skalarna funkcija vektorske spremenljivke *
{
return(1+x.v[1]*x.v[1]+x.v[2]*x.v[2]);
}
*/





/* OPOMBA: ZELO PRIMERNO BI BILO SPREMENITI PROCEDURO TAKO, DA BI TOLERANCA
   OMEJILA ABSOLUTNO RAZLIKO MED NAJVISJO IN NAJNIZJO TOCKO. POTEM BI LAHKO
   NAPISAL PROCEDURO, KI LAHKO VECKRAT ZAPOREDOMA IZVEDE MINSIMP, TAKO DA
   JE VHOD VSAKE IZVEDBE IZHOD PREJSNJE. POTEM SE LAHKO GLEDE NA VREDNOSTI
   ODLOCI. ALI JE TREBA ZMANJSATI TOLERANCO ALI NE.
   PRI RESNIH EKSPERIMENTIH BOS V TO FUNKCIJO VSEKAKOR MORAL VKLJUCITI OMEJITVE
   GLEDE PARAMETROV!
*/



void minsimp(matrix simp, vector y, vector centre,
             double tol, int *it, int maxit,
             double func(vector x), int connection(int), FILE *fp)
     /* Poisce minimum vektorske funkcije funkc s simpleksno metodo.
        simp je zacetni priblizek (matrika, katere vrstice so
        oglisca simpleksa v vecdimenzionalnem vektorskem  prostoru).
        y je tabela vrednosti funkcije v ustreznih ogljiscih simpleksa
        simp. tol je toleranca - najvecje dovoljeno razmerje med razliko
        in vsoto najvecje in najmanjse vrednosti funkcije v ogljiscih
        simpleksa. */
{
const double a=1, b=0.5, c=2, lit=1.0e-5;
int i,j;
int dim;
int imin, imax, imax2;
/* Indeksi tock, kjer ima funkcija func najmanjso, najvecjo in drugo
   najvecjo vrednost */
char konec=0;
struct _vector sred, nova, nova1;
double ynova, ynova1;
dim=simp->d2;
getvec(&sred,dim);
getvec(&nova,dim);
getvec(&nova1,dim);
*it=0; konec=0;
connection(0);
while (! konec)
{
  /* Ugotovi se najnizja, najvisja in druga najvisja tocka */
  imin=1;
  imax=1;
  for (i=2; i<=dim+1; ++i)
  {
    if (y->v[i]<y->v[imin])
      imin=i;
    else if (y->v[i]>y->v[imax])
    {
      imax2=imax;
      imax=i;
    }
  }
  imax2=imin;
  for (i=1; i<=dim+1; ++i)
    if (y->v[i]>y->v[imax2] && i!=imax)
      imax2=i;
  if (*it>=maxit) konec=1;
  /*
  else if ((y->v[imax]-y->v[imin])/(lit+fabs(y->v[imax])+fabs(y->v[imin]))<tol)
    konec=1;
  */
  /* $$$ Sprememba relativnega v absolutni kriterij: */
  else if (y->v[imax]-y->v[imin] <tol)
    konec=1;
  else
  {
    ++ (*it);
    /* Sredisce ploskve, ki ja nasprotna tocki z najvisjo
       vrednostjo funkcije */
    for (j=1; j<=dim; ++j)
      sred.v[j]=0;
    for (i=1; i<=dim+1; ++i)
      if (i!=imax)
      {
        for (j=1; j<=dim; ++j)
          sred.v[j]+=simp->m[i][j];
      }
    for (j=1; j<=dim; ++j)
    {
      sred.v[j]/=dim;  /* Povprecenje koordinat */
      /* Zrcaljenje najvisje tocke cez nasprotno ploskev: */
      nova.v[j]=(1+a)*sred.v[j]-a*simp->m[imax][j];
    }
    ynova=func(&nova);   /* Vred. func. v zrcaljeni tocki */
    if (ynova<=y->v[imin])
    /* Vrednost funkcije v zrcaljeni tocki je manjsa kot
    dosedanja najnizja, zato poskusimo z ekstrapolacijo za
    faktor 2. */
    {
      for (j=1; j<=dim; ++j)
        /* Ekstrapolirana tocka: */
        nova1.v[j]=c*nova.v[j]+(1-c)*sred.v[j];
      ynova1=func(&nova1);
      if (ynova1<y->v[imin])
      /* Najvisjo tocko zamenjamo z ekstrapolirano, ker je nizja od
         do sedaj najnizje */
      {
        for (j=1; j<=dim; ++j)
          simp->m[imax][j]=nova1.v[j];
        y->v[imax]=ynova1;
      } else
      /* Ekstrapolacija ni bila uspesna, zato uporabimo zrcaljeno
         tocko */
      {
        for (j=1; j<=dim; ++j)
          simp->m[imax][j]=nova.v[j];
        y->v[imax]=ynova;
      }
    } else if (ynova>=y->v[imax2])
    /* Zrcaljena tocka je visja kot druga najvisja. Ce je nizja kot
       najvisja, jo zamenja. */
    {
      if (ynova<=y->v[imax])
      {
        for (j=1; j<=dim; ++j)
          simp->m[imax][j]=nova.v[j];
        y->v[imax]=ynova;
      }
      /* Poskusimo tudi s krcenjem simpleksa od najvisje tocke
         proti srediscu nasprotne ploskve :*/
      for (j=1; j<=dim; ++j)
        nova1.v[j]=b*simp->m[imax][j]+(1-b)*sred.v[j];
      ynova1=func(&nova1);
      if (ynova1<y->v[imax])
      /* Skrcenje je dalo nizjo tocko od najvisje, zato le-to
         zamenjamo */
      {
        for (j=1; j<=dim; ++j)
          simp->m[imax][j]=nova1.v[j];
        y->v[imax]=ynova1;
      } else
      /* Ker se nismo mogli znebiti najvisje tocke, skrcimo simpleks
         proti najnizji. */
      {
        for (i=1; i<=dim+1; ++i) if (i!=imin)
        {
          for (j=1; j<=dim; ++j)
          {
            nova.v[j]=0.5*(simp->m[i][j]+simp->m[imin][j]);
            simp->m[i][j]=nova.v[j];
          }
          y->v[i]=func(&nova);
        }
      }
    } else
    /* Zrcaljenje je dalo nekaj vmesnega; najvisjo tocko
       zamenjamo z zrcaljeno */
    {
      for (j=1; j<=dim;++j)
        simp->m[imax][j]=nova.v[j];
      y->v[imax]=ynova;
    }
  }
  connection(1);
  if (fp!=NULL)
  {
    fprintf(fp,"  Simplex (%i. iteration):\n",*it);
    fprintmat(fp,*simp);
    fprintmatrixlist(fp,simp);  fprintf(fp,"\n");
    fprintf(fp,"  Function values at apeces:\n");
    fprintvec(fp,*y);
    fprintvectorlist(fp,y);  fprintf(fp,"\n");
    fprintf(fp,"\n");
  }
}
connection(2);
if (centre->d!=simp->d2 || centre->v==NULL)
{
  dispvec(centre);
  getvec(centre,simp->d2);
}
getsimpcenter(*simp,centre);
}



static int voidconnection(int i)
{
return 0;
}

double minsimpshort1(double func(vector x),vector start,vector step,double tol,
int maxit)
    /* Poenostavljena funkcja za minimizacijo funkcije func po simpleksni
    metodi. Start je vektor zacetnih priblizkov, step je korak, po katerem
    se tvorijo drugi zacetni priblizki, tol je toleranca, maxit pa je maks.
    st. iteracij. Po izvedbi optimizacije se v vektor start zapisejo komponente
    srediscnega vektorja koncnega simpleksa, v step p afunkcijske vrednosti.
    Funkcija vrne  povprecno vrednost namenske funkcije func v ogliscih.
    $A Igor feb00; */
{
matrix simp=NULL;
vector val=NULL,centre;
int i,j;
double ret=0;
if (start==NULL)
{
  errfunc0("minsimpshort1");
  fprintf(erf(),"Starting guess vector is NULL.\n");
  errfunc2();
  return ret;
} else if (step==NULL)
{
  errfunc0("minsimpshort1");
  fprintf(erf(),"Step vector is NULL.\n");
  errfunc2();
  return ret;
} else if (start->d!=step->d)
{
  errfunc0("minsimpshort1");
  fprintf(erf(),"Dimensions of the starting guess and step vector is do not match (%i vs. %i).\n",
   start->d,step->d);
  errfunc2();
  return ret;
}
simp=getmatrix(start->d+1,start->d);
val=getvector(start->d+1);
centre=getvector(start->d);
for (i=1;i<=start->d+1;++i)
{
  for (j=1;j<=start->d;++j)
    simp->m[i][j]=start->v[j];
  if (i>1)
    simp->m[i][i-1]+=step->v[i-1];
} 
/* Izracun vrednosti v vrsticah matrike simp: */
for (i=1;i<=start->d+1;++i)
{
  for (j=1;j<=start->d;++j)
    centre->v[j]=simp->m[i][j];
  val->v[i]=func(centre);
}
minsimp(simp,val,centre,tol,&i,maxit,func,voidconnection,NULL);
copyvector0(centre,&start);
copyvector0(val,&step);
for (i=1;i<=step->d;++i)
  ret+=step->v[i];
ret/=(double)step->d;
dispmatrix(&simp);
dispvector(&val);
dispvector(&centre);
printf("\n\nResults of minimisation by the simplex algorithm:\n");
printf("Optimal parameters:\n");
printvector(start);
printvectorlist(start); printf("\n");
printf("Value of the objective function: %g\n\n\n",ret);
return ret;
}

double minsimpshort0(double func(vector x),vector start,double step,double tol,
                     int maxit)
    /* Podobno kot minsimpshort1, le da je korak podan s skalarjem step,
    vektorski korak pa ima vse komponente enake step. V start se zapisejo
    komponente sredisca koncnegs simpleksa, funkcija pa vrne povprecno vrednost
    namenske funkcije v ogliscih.
    $A Igor feb00; */
    
{
vector vstep=NULL;
int i;
double ret=0;
vstep=getvector(start->d);
for (i=1;i<=vstep->d;++i)
  vstep->v[i]=step;
ret=minsimpshort1(func,start,vstep,tol,maxit);
dispvector(&vstep);
return ret;
}




static double (* basevecfunc)(vector); /* Kazalec na funkcijo tipa double ...(vector) */

vector linestart=NULL, linedir=NULL;         /* Zunanji spremenljivki za linefunc */

/*
double vecfunc(vector v,double func(vector))
{
return (func(v));
}
*/

double linefunc(double x)
    /* Vrne vrednost funkcije basevecfunc() pri vektorju linestart+x*linedir.
    $A Igor <== jul97 */
{
int i;
struct _vector xvec;
double a=0;
if (linestart!=NULL && linedir!=NULL)
  if (linestart->d>0 && linestart->d==linedir->d)
  {
    getvec(&xvec,linestart->d);
    for (i=1; i<=linestart->d; ++i)
      xvec.v[i]=linestart->v[i]+x*linedir->v[i];
    a=basevecfunc (&xvec);
    dispvec(&xvec);
    return(a);
  }
return a; /* samo zaradi prevajalnika */
}




void linemin(vector pointmin, double *fmin, matrix mdir, int direction,
             vector hbrak, vector factorbrak, int *itbrak, int maxitbrak,
             double *tolbrent, int *itbrent, int maxitbrent,
             double *a, double *b, double *c,
             double *fa, double *fb, double *fc)
      /* Linijska minimizacije funkcije vec spremenljivk v doloceni smeri.
         pointmin - zacetna tocka, na izhodu minimum v nasi smeri.
         fmin - vrednost funkcije v pointmin.
         mdir - matrika, katere vrstice so mozne smeri minimizacije.
         direction - stevilka vrstice v matriki mdir, ki predstavlja naso
         smer.
         hbrak - vektor zacetnih korakov v vseh moznih smereh za funkcijo
         brakmin, ki objame minimum v dani smeri.
         factbrak - vektor koeficientov, s katerimi pomnozimo zacetne korake
         za funkcijo brakmin.
         itbrak - stevilo iteracij funkcije brakmin.
         maxbrak - najvecje dopustno stevilo korakov za funkcijo brakmin.
         tolbrent - toleranc za funkcijo brent.
         itbrent - stevilo iteracij funkcije brent.
         maxitbrent - najvecje dopustno stevilo iteracij funkcije brent.
         b - priblizni linijski minimum.
         a,c -meji intervala, na katerem lezi linijski minimum.
         fa,fb,fc - vrednosti linijske funkcije v tockah a, b in c.
         Funkcija, ki jo ta funkcija minimizira, je
         f(x)=fvec(pointmin+x*mdir[direction]).
           Ta funkcija se uporablja le v funkcijah za minimizacijo funkcij
         vec spremenljivk, ki v svojih algoritmih vkljucujejo minimizacije
         v dolocenih smereh.
      */
{
int j,dim;
double smallnum=1.0e-20;
dim=pointmin->d;
/* Zacetna tocka in smer: */
for (j=1; j<=dim; ++j)
{
  linestart->v[j]=pointmin->v[j];
  linedir->v[j]=mdir->m[direction][j];
}
*a=0; *b=hbrak->v[direction]*factorbrak->v[direction]+smallnum;
*fa=*fmin;   *fb=linefunc(*b);
while (*fa==*fb)
{
  *b*=30;
  *fb=linefunc(*b);
}
*itbrak=0; *itbrent=0;
brakmin(a,b,c,fa,fb,fc, itbrak, maxitbrak, linefunc, minndemptycon, stdout);
if (*itbrak==1) factorbrak->v[direction]/=2;
if (*itbrak>4) factorbrak->v[direction]*=10;
if (*itbrak>16) factorbrak->v[direction]*=5;
if (*itbrak>64) factorbrak->v[direction]*=5;
brent(a,b,c,fa,fb,fc, *tolbrent, itbrent, maxitbrent,
      linefunc, minndemptycon, stdout);
hbrak->v[direction]=(*b-*a);
/* Zacetni korak za funkcijo brakmin v doloceni smeri je prejsnja sirina
intervala po linijski minimizaciji v tej smeri krat ustrezni faktor.
Ta faktor se po vsaki iteraciji prilagaja in skrbi hkrati za to, da je
za objem minimuma v dani smeri potrebno cim manj iteracij in da ni
zacetni interval za linijsko minimizacijo prevelik. */
for (j=1; j<=dim; ++j)  /* Minimum po tej linijski minimizaciji: */
  pointmin->v[j]=linestart->v[j]+ *b*linedir->v[j];
*fmin=*fb;  /* vrednost funkcije v pointmin */
}





typedef struct{
        double x;  /* koordinata x */
        double a,b,c,fa,fb,fc;  /* priblizki za minimum s funkc. vrednostmi */
        double accuracy;  /* natancnost funkcijske vrednosti v mimimumu */
        } pointmintype;

struct _vector globalrvec;
double (*baserecfunc)(vector)=NULL;

double fconstx(double y)
       /* Vrne vrednost funkcije dveh spremenljivk, katere naslov je v
          baserecfunc, v tocki, katere komponenta x je globalrvec.v[1],
          komponenta y pa je argument y funkcije fconstx. */
{
globalrvec.v[2]=y;
return(baserecfunc(&globalrvec));
}

void miny(pointmintype *xx)
     /* Minimizira funkcijo dveh spremenljivk pri danem x v smeri y. */
{

}


void improveaccuracy(pointmintype *xx, double tol, int *itbrent, int maxitbrent)
     /* Poveca natancnost minimuma v smeri y. tol je zahtevana absolutna
        natancnost funkcijske vrednosti v minimumu. */
{
double a,b;
if (xx->accuracy>=tol)
{
  globalrvec.v[1]=xx->x;
  *itbrent=0;
  brentabs(&xx->a, &xx->b, &xx->c,
           &xx->fa, &xx->fb, &xx->fc,
           tol/2, itbrent, maxitbrent,
           fconstx, minndemptycon, stdout);
  a=fabs(xx->fa-xx->fb);
  b=fabs(xx->fc-xx->fb);
  if (a>b)
    xx->accuracy=2*a;
  else
    xx->accuracy=2*b;
}
}



void findpoint(pointmintype *xx, double tol, int *itbrak, int maxitbrak,
                int *itbrent, int maxitbrent)
     /* Najde minimum funkcije basevecfunc v smeri y pri dolocenem x.
        v xx.a, xx.b, xx.fa in xx.fb morajo imeti ob klicu te funkcije ze
        postavljene vrednosti. */
{
double a,b;
globalrvec.v[1]=xx->x;
*itbrak=0;  *itbrent=0;
brakmin(&xx->a, &xx->b, &xx->c,
        &xx->fa, &xx->fb, &xx->fc,
        itbrak, maxitbrak,
        fconstx, minndemptycon, stdout);
brentabs(&xx->a, &xx->b, &xx->c,
         &xx->fa, &xx->fb, &xx->fc,
         tol/2, itbrent, maxitbrent,
         fconstx, minndemptycon, stdout);
a=fabs(xx->fa-xx->fb);
b=fabs(xx->fc-xx->fb);
if (a>b)
  xx->accuracy=2*a;
else
  xx->accuracy=2*b;
}


void findpointrough(pointmintype *xx, int *itbrak, int maxitbrak)
     /* Podobno kot funkcija findpoint, le da minimuma v smeri y ne poisce
        do dolocene natancnosti, ampak ga le objame. */
{
double a,b;
globalrvec.v[1]=xx->x;
*itbrak=0;
brakmin(&xx->a, &xx->b, &xx->c,
        &xx->fa, &xx->fb, &xx->fc,
        itbrak, maxitbrak,
        fconstx, minndemptycon, stdout);
a=fabs(xx->fa-xx->fb);
b=fabs(xx->fc-xx->fb);
if (a>b)
  xx->accuracy=2*a;
else
  xx->accuracy=2*b;
}




int derivaccur(pointmintype a, pointmintype b, pointmintype c,
               double *derf1, double *derf2, double *derf3, /* odvodi */
               double *d1, double *d2, double *d3  /* napake odvodov */)
     /* izracuna odvode temena parabole skozi tocke a, b in c po funkcijskih
        vrednostih v teh tockah. Vrne najvecje mozne odvode glede na
        negotovost funkcijskih vrednosti. Vrne tudi celo stevilo, ki je:
          0, ce je vse v redu.
          1, ce so lahko odvodi tudi neskoncni.
          2, ce so napake odvodov priblizno tako velike kot odvodi sami.
     */
{
double ix1,ix3,if1,if3,dif1,dif3,denom,num,ddenom,dnum;
double derf1min, derf2min, derf3min, derf1max, derf2max, derf3max;
double aa,bb1,bb2,bb3,cc1,cc2,cc3;
int retval=0;
/* Uvedba novih spremenljivk: */
/* Razlike sosednjih koordinat in funkcijskih vrednosti: */
ix1=b.x-a.x;                  ix3=b.x-c.x;
if1=b.fb-a.fb;                if3=b.fb-c.fb;
dif1=b.accuracy+a.accuracy;   dif3=b.accuracy+c.accuracy;
/* Imenovalec in stevec izraza za teme parabole ter njuni napaki */
denom=ix1*if3-ix3*if1;
num=ix1*ix1*if3-ix3*ix3*if1;
ddenom=fabs(ix1*dif3)+fabs(ix3*dif1);
dnum=fabs(ix1*ix1*dif3)+fabs(ix3*ix3*dif1);
if ( ddenom>=0.999*fabs(denom) ) /* Odvodi so lahko tudi neskoncni */
{
  retval=1;
  *d1=*d2=*d3=*derf1=*derf2=*derf3=1.0e20;
}  else
{
  retval=0;
  /* Absolutne vrednosti stevcev izrazov za odvode: */
  bb2=fabs( (ix1*ix1-ix3*ix3)*denom-(ix1-ix3)*num );
  bb1=fabs(ix3*ix3*denom-ix3*num);
  bb3=fabs(-ix1*ix1*denom+ix1*num);
  /* Napake stevcev izrazov za odvode: */
  cc2=fabs(ix1*ix1-ix3*ix3)*ddenom+fabs(ix1-ix3)*dnum;
  cc1=ix3*ix3*ddenom+fabs(ix3)*dnum;
  cc3=ix1*ix1*ddenom+fabs(ix1)*dnum;
  /* Imenovalec izrazov za najvecje mozne absolut. vred. odvodov: */
  aa=(fabs(denom)-ddenom);
  aa*=aa;
  /* Najvecje mozne absolutne vrednosti odvodov: */
  derf2max=0.5*(bb2+cc2)/aa;
  derf1max=0.5*(bb1+cc1)/aa;
  derf3max=0.5*(bb3+cc3)/aa;
  /* Imenovalec izrazov za najmanjse mozne absolut. vred. odvodov: */
  aa=(fabs(denom)+ddenom);
  aa*=aa;
  /* Najmanjse mozne absolutne vrednosti odvodov: */
  derf2min=0.5*(bb2-cc2)/aa;
  derf1min=0.5*(bb1-cc1)/aa;
  derf3min=0.5*(bb3-cc3)/aa;
  if (cc2>=bb2) derf2min=0;
  if (cc1>=bb1) derf1min=0;
  if (cc3>=bb3) derf3min=0;
  *derf1=derf1max;
  *derf2=derf2max;
  *derf3=derf3max;
  *d1=derf1max-derf1min;
  *d2=derf2max-derf2min;
  *d3=derf3max-derf3min;
  if (*d1>=0.5* *derf1 || *d2>=0.5* *derf2 || *d3>=0.5* *derf3 )
    retval=2;
}
return(retval);
}





void ensureaccuracy(pointmintype *a, pointmintype *b, int *itbrent, int maxitbrent)
     /* Zagotovi, da sta vrednosti funkcije v tockah a in b dovolj natancni,
        da lahko z zanesljivostjo recemo, katera je vecja. */
{
while (a->accuracy>0.25*fabs(a->fb-b->fb) || b->accuracy>0.25*fabs(a->fb-b->fb))
{
  if (a->accuracy>0.25*fabs(a->fb-b->fb))
    improveaccuracy(a, 0.2*fabs(a->fb-b->fb), itbrent, maxitbrent);
  if (b->accuracy>0.25*fabs(a->fb-b->fb))
    improveaccuracy(b, 0.2*fabs(a->fb-b->fb), itbrent, maxitbrent);
}
}



void copypointmin(pointmintype *a, pointmintype *b)
{
if (a!=NULL && b!=NULL)
  memcpy((void *) a, (void *) b, sizeof(pointmintype));
}



void brentrec(pointmintype *a, pointmintype *b, pointmintype *c,
           double tol, int *it, int maxit,
           int * itbrent, int maxitbrent,  int * itbrak, int maxitbrak)
/* Izolira minimum funkcije v smeri x in ga vrne v b. */
{
const double zlati=0.3819660;
/* const double mali=1.0e-20; */
const double accx=0.1;  /* na toliki del intervala mora biti natancna parabol.
int. */
char konec=0,end1=0,doparab=0,ok=0;
/* double d, fd, x, x1, x2, x3, f1, f2, f3; */
double q, r,x,aa;
double derf1, derf2, derf3, d1,d2,d3;
pointmintype *d=NULL, *x1=NULL, *x2=NULL, *x3=NULL;
/* double bprej, bpredprej, korak, korak1, korak2; */
pointmintype *bprej;
double korak, korak1, korak2;
double tol1,tol2,tol3;
int count,signal;
/*
   x1: tocka, kjer ima funkcija funk do sedaj najnizjo vrednost,
   x2: tocka, kjer ima 2. najnizjo vrednost itd.
*/

if (errorfile()!=NULL)
{
  fprintf(errorfile(),"\n\n\n\n\n");
  fprintf(errorfile(),"Zacetek funkcije brentrec:\n");
  fprintf(errorfile(),"\n\n\n");
}
printf("\n\n\n\n\n");
printf("Zacetek funkcije brentrec:\n");
printf("\n\n\n");

*it=0;
x1=(pointmintype *)calloc(1,sizeof(pointmintype));
x2=(pointmintype *)calloc(1,sizeof(pointmintype));
x3=(pointmintype *)calloc(1,sizeof(pointmintype));
/* Zagotovi se zadostna natancnost, da lahko z gotovostjo povemo za vsak par
tock a, b in c, kje je vrednost funkcije vecja: */
ensureaccuracy(a, b, itbrent, maxitbrent);
ensureaccuracy(a, c, itbrent, maxitbrent);
ensureaccuracy(b, c, itbrent, maxitbrent);
bprej=b;
korak=korak1=korak2=0;
/* Povecanje natancnosti, ce je potrebno */
copypointmin(x1,b);   /* tocka z najnizjo vrednostjo funkcije doslej */
if (a->fb<c->fb)
{
  copypointmin(x2,a);         /* tocka z 2. najnizjo vrednost funkcije do zdaj*/
  copypointmin(x3,c);
} else
{
  copypointmin(x2,c);
  copypointmin(x3,a);
}
while (! (konec))   /*galvna zanka*/
{

  if (errorfile()!=NULL)
  {
    fprintf(errorfile(),"\n\n\n\n");
    fprintf(errorfile(),"%i. ITERACIJA:\n\n\n\n",*it);
  }

  d=(pointmintype *)calloc(1,sizeof(pointmintype));  /* Na zacetku vsake iteracije je
  potrebno rezervirati spomin za d. Med iteracijo ena od prejsnjih tock postane
  d, zato se prostora v spominu, ki je rezerviran za d, ne brise. Brise pa se
  prostor, rezerviran za tocko, ki postane d, in to vedno tik pred
  prireditvijo. */
  /* Parabolicna interpolacija minimuma u */
  end1=0;
  count=0;
  doparab=1;
  /* Izracunajo se odvodi temena po funkc. vrednostih: */
  signal=derivaccur(*x1,*x2,*x3,&derf1,&derf2,&derf3,&d1,&d2,&d3);
  while (! end1)
  /* Zagotovi se zadostna natancnost za parabolicno interpolacijo */
  {
    ++ count;
    if (count>6) ++end1;  /* Ce ne uspe v 6 poskusih, odneha */
    if (signal==1 || signal==2)
    /* Natancnost je premala, da bi se lahko izracunali odvodi, zato se
    natancnost vseh tock podeseteri */
    {
      if (end1)    /* Poskusov je bilo ze prevec, */
        doparab=0; /* zato ne bomo izvedli interpolacije. */
      else
      {
        improveaccuracy(x1, 0.1*x1->accuracy, itbrent, maxitbrent);
        improveaccuracy(x2, 0.1*x2->accuracy, itbrent, maxitbrent);
        improveaccuracy(x2, 0.1*x2->accuracy, itbrent, maxitbrent);
        /* Izracunajo se odvodi temena po funkc. vrednostih: */
        signal=derivaccur(*x1,*x2,*x3,&derf1,&derf2,&derf3,&d1,&d2,&d3);
      }
    } else if (signal==0)
    {
      /*
      if (x2->x-x1->x>x3->x-x2->x)
      {
        aa=fabs(x2->x-x1->x); / vecji od obeh intervalov /
        bb=fabs(x3->x-x2->x); /manjsi od obeh intervalov /
      } else
      {
        bb=fabs(x2->x-x1->x); / manjsi od obeh intervalov /
        aa=fabs(x3->x-x2->x); / vecji od obeh intervalov /
      }
      / Zahtevana natancnost za polozaj temena parabole; zahtevamo, da je
      napaka hkrati manjsa od polovice manjsega intervala in od accx krat
      vecji interval. /
      if (accx*aa<0.5*bb)
        aa=accx*aa;
      else
        aa=0.5*bb;
      */
      aa=accx*fabs(c->x-a->x);
      tol1=aa/derf1;
      tol2=aa/derf2;
      tol3=aa/derf2;
      /* Ce je potrebno, se izboljsa natancnost posameznih tock */
      ok=1;
      if (tol1<x1->accuracy)
        { improveaccuracy(x1, 0.5*tol1, itbrent, maxitbrent);  ok=0; }
      if (tol2<x2->accuracy)
        { improveaccuracy(x2, 0.5*tol2, itbrent, maxitbrent);  ok=0; }
      if (tol3<x3->accuracy)
        { improveaccuracy(x3, 0.5*tol3, itbrent, maxitbrent);  ok=0; }
      if (ok) end1=1;
      else
        signal=derivaccur(*x1,*x2,*x3,&derf1,&derf2,&derf3,&d1,&d2,&d3);
    }
  }
  if (doparab)
  {
    r=(x1->x-x2->x)*(x1->fb-x3->fb);
    q=(x1->x-x3->x)*(x1->fb-x2->fb);
    x=2*(q-r);
    if (fabs(x)>1.0e-20)
      d->x=x1->x-((x1->x-x3->x)*q-(x1->x-x2->x)*r)/x;
    else
    {
      if (x<0)
        d->x=x1->x-((x1->x-x3->x)*q-(x1->x-x2->x)*r)/(-1.0e-20);
      else
        d->x=x1->x-((x1->x-x3->x)*q-(x1->x-x2->x)*r)/(-1.0e-20);
    }
  } else
  {
    d->x=a->x+(a->x-b->x);
   /* Na ta nacin se zagotovi, da bo ta tocka zavrzena. */
  }
  korak=fabs(b->x-d->x);
  if (d->x>a->x && d->x<c->x && korak<0.8*korak2 && d->x!=b->x
   && d->x!=b->x)
  /* Parabolicno interpolacijo lahko uporabimo kot novo tocko*/
  {
    /* Zacetne koordinate v smeri y za tocko de se izracunajo z linearno
    interpolacijo koordinat x1 in x3: */
    d->a= x1->c + (x3->c-x1->c) * ( (d->x-x1->x)/(x3->x-x1->x) );
    d->b= x1->c + (x3->c-x1->c) * ( (d->x-x1->x)/(x3->x-x1->x) );
    /* Vrednosti funkcije, ki jo minimiziramo, v novih koordinatah: */
    globalrvec.v[1]=d->x;  /* priprava za izracun funkcije */
    d->fa=fconstx(d->a);
    d->fb=fconstx(d->b);
    findpointrough(d, itbrak, maxitbrak); /* Najde tri tocke, ki omejujejo
    minimum v smeri y za tocko d. */
  } else
  /* d postane nova tocka po zlatem rezu*/
  {
    if (b->x-a->x>=c->x-b->x)
    {
      d->x=b->x-(b->x-a->x)*zlati;
      if (c->x-b->x>0)
        if ((b->x-a->x)/(c->x-b->x)>4) /* Prepreci se kopicenje tock */
          d->x=b->x-2*(c->x-b->x);
    } else
    {
      d->x=b->x+(c->x-b->x)*zlati;
      if (b->x-a->x>0)
        if ((c->x-b->x)/(b->x-a->x)>4)
          d->x=b->x+2*(b->x-a->x);
    }
    /* Zacetne koordinate v smeri y za tocko d se izracunajo z linearno
    interpolacijo koordinat a in c: */
    d->a= a->a + (c->a-a->a) * ( (d->x-a->x)/(c->x-a->x) );
    d->b= a->c + (c->c-a->c) * ( (d->x-a->x)/(c->x-a->x) );
    /* Vrednosti funkcije, ki jo minimiziramo, v novih koordinatah: */
    globalrvec.v[1]=d->x;  /* priprava za izracun funkcije */
    d->fa=fconstx(d->a);
    d->fb=fconstx(d->b);
    findpointrough(d, itbrak, maxitbrak); /* Najde tri tocke, ki omejujejo
    minimum v smeri y za tocko d. */
    korak=fabs(d->x-b->x);
  }
  /* Koordinata x nove tocke je sedaj dokoncno dolocena. Poskrbeti je treba za
  to, da je minimum v smeri y dovolj natancno izracunan, da lahko ugotovimo,
  ali je nova tocka visja ali nizja od tock a, b in c: */
  ensureaccuracy(a, d, itbrent, maxitbrent);
  ensureaccuracy(b, d, itbrent, maxitbrent);
  ensureaccuracy(c, d, itbrent, maxitbrent);
  if (d->x<b->x)
  {
    if (d->fb<=b->fb)
    {
      copypointmin(c,b);
      copypointmin(b,d);
    } else
    {
      copypointmin(a,d);
    }
  } else /*d>=b*/
  {
    if (d->fb>b->fb)
    {
      copypointmin(c,d);
    } else
    {
      copypointmin(a,b);
      copypointmin(b,d);
    }
  }
  if (d->fb<x1->fb)
  {
    copypointmin(x3,x2);
    copypointmin(x2,x1);
    copypointmin(x1,d);
  } else if (d->fb<x2->fb)
  {
    copypointmin(x3,x2);
    copypointmin(x2,d);
  } else if (d->fb<x3->fb)
  {
    copypointmin(x3,d);
  }
  korak2=korak1;
  korak1=korak;
  if (*it>=maxit)
    konec=1;
  ++ *it;
  if ( fabs(a->fb-b->fb)<=tol*(fabs(a->fb)+fabs(b->fb)) &&
       fabs(c->fb-b->fb)<=tol*(fabs(c->fb)+fabs(b->fb))  ) konec=1;


  if (errorfile()!=NULL)
  {
    fprintf(errorfile(),"\n");
    fprintf(errorfile(),"TOCKE:\n");
    fprintf(errorfile(),"a:\n");
    fprintf(errorfile(),"x: %g,   fb: %g,   accuracy: %g\n",a->x,a->fb,a->accuracy);
    fprintf(errorfile(),"b:\n");
    fprintf(errorfile(),"x: %g,   fb: %g,   accuracy: %g\n",b->x,b->fb,b->accuracy);
    fprintf(errorfile(),"b:\n");
    fprintf(errorfile(),"x: %g,   fb: %g,   accuracy: %g\n",c->x,c->fb,c->accuracy);
    fflush(errorfile());
    }

}
free(x1);  free(x2);  free(x3);
}




/*   BRAKMIN   */
void brakminrec(pointmintype *a, pointmintype *b, pointmintype *c,
             int *it, int maxit,
             int * itbrent, int maxitbrent,  int * itbrak, int maxitbrak)
  /* Minimum funkcije v smeri x objame z eksponentnim sirjenjem
     intervala, pomaga pa si tudi s parabolicno  interpolacijo.
  */
{
const double zlati=2-0.38196601125;
const double umeja=100.0; /*zgor. meja za (u-b)/(c-b), u je
                   teme parabole*/
const double accx=0.1;  /* parabol. interpolacija */
pointmintype *u =NULL, *x1=NULL, *x2=NULL, *x3=NULL;
double r,q,x,aa,tol1,tol2,tol3;
double derf1, derf2, derf3, d1,d2,d3;
char konec=0,end1=0,doparab=0,ok=0;
int count,signal;
u=(pointmintype *)calloc(1,sizeof(pointmintype));
if (errorfile()!=NULL)
{
  fprintf(errorfile(),"\n\n\n\n\n");
  fprintf(errorfile(),"Zacetek funkcije BRAKMINREC:\n");
  fprintf(errorfile(),"\n\n\n");
}
printf("\n\n\n\n\n");
printf("Zacetek funkcije brentrec:\n");
printf("\n\n\n");




*it=0;
/* Zagotovi se zadostna natancnost, da lahko z gotovostjo povemo za
tocki  a in b, kje je vrednost funkcije vecja: */
ensureaccuracy(a, b, itbrent, maxitbrent);
if (b->fb>a->fb)
{
  copypointmin(u,b);
  copypointmin(b,a);
  copypointmin(a,u);
}
c->x=b->x+(b->x-a->x)*zlati;
/* Zacetne koordinate v smeri y za tocko c se izracunajo z linearno
ekstrapolacijo koordinat a in b: */
c->a= a->a + (b->a-a->a) * ( (c->x-a->x)/(b->x-a->x) );
c->b= a->c + (b->c-a->c) * ( (c->x-a->x)/(b->x-a->x) );
/* Vrednosti funkcije, ki jo minimiziramo, v novih koordinatah: */
globalrvec.v[1]=c->x;  /* priprava za izracun funkcije */
c->fa=fconstx(c->a);
c->fb=fconstx(c->b);
findpointrough(c, itbrak, maxitbrak); /* Najde tri tocke, ki omejujejo
minimum v smeri y za tocko d. */
ensureaccuracy(a, c, itbrent, maxitbrent);
ensureaccuracy(b, c, itbrent, maxitbrent);

do
{
  /* u=(pointmin*)calloc(1,sizeof(pointmin)); */
  if (c->fb>b->fb)
  {
    konec=1; end1=1;
  } else /*Poskusimo s temenom parabole skozi a,b in c*/
  {
    /*V tem bloku je vrednost funkcije v c manjsa kot v b. */
    /*Parabolicna interpolacija minimuma u*/
    end1=0;
    count=0;
    doparab=1;
    x1=a; x2=b; x3=c;
    /* Izracunajo se odvodi temena po funkc. vrednostih: */
    signal=derivaccur(*x1,*x2,*x3,&derf1,&derf2,&derf3,&d1,&d2,&d3);
    while (! end1)
    /* Zagotovi se zadostna natancnost za parabolicno interpolacijo */
    {
      ++ count;
      if (count>6) ++end1;  /* Ce ne uspe v 6 poskusih, odneha */
      if (signal==1 || signal==2)
      /* Natancnost je premala, da bi se lahko sploh izracunali odvodi, zato se
      natancnost vseh tock podeseteri */
      {
        if (end1)    /* Poskusov je bilo ze prevec, */
          doparab=0; /* zato ne bomo izvedli interpolacije. */
        else
        {
          if (x1->accuracy>0)
            improveaccuracy(x1, 0.1*x1->accuracy, itbrent, maxitbrent);
          if (x2->accuracy>0)
            improveaccuracy(x2, 0.1*x2->accuracy, itbrent, maxitbrent);
          if (x2->accuracy>0)
            improveaccuracy(x3, 0.1*x3->accuracy, itbrent, maxitbrent);
          /* Izracunajo se odvodi temena po funkc. vrednostih: */
          signal=derivaccur(*x1,*x2,*x3,&derf1,&derf2,&derf3,&d1,&d2,&d3);
        }
      } else if (signal==0)
      {
        /* Izracuna se teme parabole iz trenutnih podatkov. To se bo uporabilo
        za dolocanje natancnosti tock. */
        r=(b->x-a->x)*(b->fb-c->fb);
        q=(b->x-c->x)*(b->fb-a->fb);
        x=2*(q-r);
        if (fabs(x)>1.0e-20)
          u->x=b->x-((b->x-c->x)*q-(b->x-a->x)*r)/x;
        else if (x>=0)
          u->x=b->x-((b->x-c->x)*q-(b->x-a->x)*r)/1.0e-20;
        else if (x<0)
          u->x=b->x-((b->x-c->x)*q-(b->x-a->x)*r)/(-1.0e-20);
        /*
        if (fabs((u->x-*a)/(*c-*a))>umeja)
          u->x=*c+umeja*(*c-*a);
        */

        /*
        if (x2->x-x1->x>x3->x-x2->x)
        {
          aa=fabs(x2->x-x1->x); / vecji od obeh intervalov /
          bb=fabs(x3->x-x2->x); / manjsi od obeh intervalov /
        } else
        {
          bb=fabs(x2->x-x1->x); / manjsi od obeh intervalov /
          aa=fabs(x3->x-x2->x); / vecji od obeh intervalov /
        }
        */
        /* Zahtevana natancnost za polozaj temena parabole; zahtevamo, da je
        hkrati manjsa kot accx krat interval [b,u]. */
        aa=accx*fabs(u->x-b->x);
        tol1=aa/derf1;
        tol2=aa/derf2;
        tol3=aa/derf2;
        /* Ce je potrebno, se izboljsa natancnost posameznih tock */
        ok=1;
        if (tol1<x1->accuracy)
          { improveaccuracy(x1, 0.5*tol1, itbrent, maxitbrent);  ok=0; }
        if (tol2<x2->accuracy)
          { improveaccuracy(x2, 0.5*tol2, itbrent, maxitbrent);  ok=0; }
        if (tol3<x3->accuracy)
          { improveaccuracy(x3, 0.5*tol3, itbrent, maxitbrent);  ok=0; }
        if (ok) end1=1;
        else
          signal=derivaccur(*x1,*x2,*x3,&derf1,&derf2,&derf3,&d1,&d2,&d3);
      }
    }
    if (doparab)
    {
      r=(b->x-a->x)*(b->fb-c->fb);
      q=(b->x-c->x)*(b->fb-a->fb);
      x=2*(q-r);
      if (fabs(x)>1.0e-20)
        u->x=b->x-((b->x-c->x)*q-(b->x-a->x)*r)/x;
      else if (x>=0)
        u->x=b->x-((b->x-c->x)*q-(b->x-a->x)*r)/1.0e-20;
      else if (x<0)
        u->x=b->x-((b->x-c->x)*q-(b->x-a->x)*r)/(-1.0e-20);
      if (fabs((u->x-a->x)/(c->x-a->x))>umeja)
        u->x=c->x+umeja*(c->x-a->x);
    /*}*/
      /*Preizkusanje temena parabole glede na njegovo lego: */
      if ((b->x-u->x)*(u->x-c->x)>0)    /* u med b in c */
      {
        /* Zacetne koordinate v smeri y za tocko u se izracunajo z linearno
        ekstrapolacijo koordinat a in b: */
        u->a= a->a + (b->a-a->a) * ( (u->x-a->x)/(b->x-a->x) );
        u->b= a->c + (b->c-a->c) * ( (u->x-a->x)/(b->x-a->x) );
        /* Vrednosti funkcije, ki jo minimiziramo, v novih koordinatah: */
        globalrvec.v[1]=u->x;  /* priprava za izracun funkcije */
        u->fa=fconstx(u->a);
        u->fb=fconstx(u->b);
        findpointrough(u, itbrak, maxitbrak); /* Najde tri tocke, ki omejujejo
        minimum v smeri y za tocko d. */
        ensureaccuracy(a, u, itbrent, maxitbrent);
        ensureaccuracy(b, u, itbrent, maxitbrent);
        ensureaccuracy(c, u, itbrent, maxitbrent);
        if (u->fb<c->fb) /* Minimum je med b in c */
        {
          copypointmin(a,b);
          copypointmin(b,u);
          konec=1;
        }  else if (u->fb>b->fb) /* Minimum je med a in u */
        {
          copypointmin(c,u);
          konec=1;
        } else /* Z u si ne moremo pomagati. uporabimo zlati rez. */
        {
          u->x=c->x+(c->x-a->x)*zlati;
          /* Zacetne koordinate v smeri y za tocko u se izracunajo z linearno
          ekstrapolacijo koordinat b in c: */
          u->a= b->a + (c->a-b->a) * ( (u->x-b->x)/(c->x-b->x) );
          u->b= b->c + (c->c-b->c) * ( (u->x-b->x)/(c->x-b->x) );
          /* Vrednosti funkcije, ki jo minimiziramo, v novih koordinatah: */
          globalrvec.v[1]=u->x;  /* priprava za izracun funkcije */
          u->fa=fconstx(u->a);
          u->fb=fconstx(u->b);
          findpointrough(u, itbrak, maxitbrak); /* Najde tri tocke, ki omejujejo
          minimum v smeri y za tocko d. */
          ensureaccuracy(b, u, itbrent, maxitbrent);
          ensureaccuracy(c, u, itbrent, maxitbrent);
          copypointmin(a,b);
          copypointmin(b,c);
          copypointmin(c,u);
        }
      } else if ((u->x-b->x)/(c->x-b->x)>zlati)  /* u>c */
      {
        /* Zacetne koordinate v smeri y za tocko u se izracunajo z linearno
        ekstrapolacijo koordinat a in b: */
        u->a= a->a + (b->a-a->a) * ( (u->x-a->x)/(b->x-a->x) );
        u->b= a->c + (b->c-a->c) * ( (u->x-a->x)/(b->x-a->x) );
        /* Vrednosti funkcije, ki jo minimiziramo, v novih koordinatah: */
        globalrvec.v[1]=u->x;  /* priprava za izracun funkcije */
        u->fa=fconstx(u->a);
        u->fb=fconstx(u->b);
        findpointrough(u, itbrak, maxitbrak); /* Najde tri tocke, ki omejujejo
        minimum v smeri y za tocko d. */
        ensureaccuracy(a, u, itbrent, maxitbrent);
        ensureaccuracy(b, u, itbrent, maxitbrent);
        ensureaccuracy(c, u, itbrent, maxitbrent);
        if (u->fb>c->fb)
        {
          copypointmin(a,b);
          copypointmin(b,c);
          copypointmin(c,u);
          konec=1;
        } else
        {
          copypointmin(a,c);
          copypointmin(b,u);
          c->x=b->x+(b->x-a->x)*zlati;
          /* Zacetne koordinate v smeri y za tocko c se izracunajo z linearno
          ekstrapolacijo koordinat a in b: */
          c->a= a->a + (b->a-a->a) * ( (c->x-a->x)/(b->x-a->x) );
          c->b= a->c + (b->c-a->c) * ( (c->x-a->x)/(b->x-a->x) );
          /* Vrednosti funkcije, ki jo minimiziramo, v novih koordinatah: */
          globalrvec.v[1]=c->x;  /* priprava za izracun funkcije */
          c->fa=fconstx(c->a);
          c->fb=fconstx(c->b);
          findpointrough(c, itbrak, maxitbrak); /* Najde tri tocke, ki omejujejo
          minimum v smeri y za tocko d. */
          ensureaccuracy(a, c, itbrent, maxitbrent);
          ensureaccuracy(b, c, itbrent, maxitbrent);
        }
      } else
      {
        copypointmin(a,b);
        copypointmin(b,c);
        u->x=b->x+(b->x-a->x)*zlati;
        /* Zacetne koordinate v smeri y za tocko u se izracunajo z linearno
        ekstrapolacijo koordinat a in b: */
        u->a= a->a + (b->a-a->a) * ( (u->x-a->x)/(b->x-a->x) );
        u->b= a->c + (b->c-a->c) * ( (u->x-a->x)/(b->x-a->x) );
        /* Vrednosti funkcije, ki jo minimiziramo, v novih koordinatah: */
        globalrvec.v[1]=u->x;  /* priprava za izracun funkcije */
        u->fa=fconstx(u->a);
        u->fb=fconstx(u->b);
        findpointrough(u, itbrak, maxitbrak); /* Najde tri tocke, ki omejujejo
        minimum v smeri y za tocko d. */
        ensureaccuracy(a, u, itbrent, maxitbrent);
        ensureaccuracy(b, u, itbrent, maxitbrent);
        ensureaccuracy(c, u, itbrent, maxitbrent);
        copypointmin(c,u);
      }
    } else
    {
      copypointmin(a,b);
      copypointmin(b,c);
      u->x=b->x+(b->x-a->x)*zlati;
      /* Zacetne koordinate v smeri y za tocko u se izracunajo z linearno
      ekstrapolacijo koordinat a in b: */
      u->a= a->a + (b->a-a->a) * ( (u->x-a->x)/(b->x-a->x) );
      u->b= a->c + (b->c-a->c) * ( (u->x-a->x)/(b->x-a->x) );
      /* Vrednosti funkcije, ki jo minimiziramo, v novih koordinatah: */
      globalrvec.v[1]=u->x;  /* priprava za izracun funkcije */
      u->fa=fconstx(u->a);
      u->fb=fconstx(u->b);
      findpointrough(u, itbrak, maxitbrak); /* Najde tri tocke, ki omejujejo
      minimum v smeri y za tocko d. */
      ensureaccuracy(a, u, itbrent, maxitbrent);
      ensureaccuracy(b, u, itbrent, maxitbrent);
      ensureaccuracy(c, u, itbrent, maxitbrent);
      copypointmin(c,u);
    }
  }
  ++ *it;
  if (*it>=maxit) konec=1;



  if (errorfile()!=NULL)
  {
    fprintf(errorfile(),"\n");
    fprintf(errorfile(),"TOCKE:\n");
    fprintf(errorfile(),"a:\n");
    fprintf(errorfile(),"x: %g,   fb: %g,   accuracy: %g\n",a->x,a->fb,a->accuracy);
    fprintf(errorfile(),"b:\n");
    fprintf(errorfile(),"x: %g,   fb: %g,   accuracy: %g\n",b->x,b->fb,b->accuracy);
    fprintf(errorfile(),"b:\n");
    fprintf(errorfile(),"x: %g,   fb: %g,   accuracy: %g\n",c->x,c->fb,c->accuracy);
    fflush(errorfile());
  }


} while (! konec);
if (a->x>c->x)
{
  copypointmin(u,c);
  copypointmin(c,a);
  copypointmin(a,u);
}
free(u);
}







void minrec2d(vector pmin, double *fmin, vector h0, double tol,
              int *it, int maxit,
              double func(vector), int connection(int), FILE *fp)
     /* Najde minimum funkcije dveh spremenljivk func. pmin je zacetni
        priblizek, fmin pa vrednost funkcije v pmin, ki mora biti ob klicu
        funkcije ze izracunana. h0 je vektor zacetnih korakov za objemanje
        minimuma, tol je relativna toleranca, it stevilo iteracij, maxit pa
        najvecje dovoljeno stevilo iteracij.
     */
{
int itbrent=0,maxitbrent=100,itbrak=0,maxitbrak=100;
pointmintype a,b,c;
char end=0 /*, end1=0 */ ;
/* Nastavitev zunanjih spremenljivk: */
getvec(&globalrvec,pmin->d);
baserecfunc=func;
/* Najprej poskusa objeti minimum funkcije v smeri x: */
/* Zacetni tocki, a in b: */
a.x=pmin->v[1];  a.a=pmin->v[2];  a.fa=*fmin;
a.b=a.a+h0->v[2];
globalrvec.v[1]=a.x;  a.fb=fconstx(a.b);
findpointrough(&a, &itbrak, maxitbrak);
b.x=a.x+h0->v[1];  b.a=a.a;  b.b=a.b;
globalrvec.v[1]=b.x;  b.fa=fconstx(b.a);  b.fb=fconstx(b.b);
findpointrough(&b, &itbrak, maxitbrak);
/* Objetmanje minimuma funkcije v smeri x: */
brakminrec(&a,&b,&c,it,maxit,
         &itbrent,maxitbrent,
         &itbrak,maxitbrak);
/* Minimum v smeri x: */
*it=0;
brentrec(&a,&b,&c,tol,it,maxit,
         &itbrent,maxitbrent,
         &itbrak,maxitbrak);
/* Izhodne vrednosti: */
pmin->v[1]=b.x;
pmin->v[2]=b.b;
*fmin=b.fb;
}





void powellinitdir(vector pointmin, double *fmin, matrix mdir,
            double tol, int *it, int maxit,
            vector hbrak, double *tolbrent, int maxitbrent,
            double func(vector x), int connection(int), FILE *fp)
            /* Minimizira skalarno funkcijo vektorske spremenljivke func.
               pointmin je priblizek za minimum funkcije, fmin pa vrednost
               funkcije v pointmin. Na vhodu morata imeti obe spremenljivki
               ustrezne zacetne vrednosti. mdir je matrika, katere vrstice
               dolocajo smeri linijskih minimizacij. Dobro je, da so smeri
               na zacetku normirane. tol je relativna toleranca za razliko
               vrednosti funkcije v minimumu pred in po zadnji iteraciji.
               it je stevilo iteracij, maxit pa najvecje dovoljeno stevilo
               iteracij. hbrak je vektor zacetnih korakov v smereh minimizacij
               za funkcijo, ki objame minimum. tolbrent je vektor relativnih
               toleranc za linijske minimizacije v razlicnih smereh.
               func je funkcija, ki jo minimiziramo, connection je funkcija za
               zvezo z zunanjim okoljem, fp pa je izhodna datoteka.
               Ta funkcija uporablja funkcijo v dani smeri linefunc in zato
               tudi zunanje spremenljivke basevecfunc, linestart in linedir, ki
               so s to funkcijo povezane.
               tolbrent se med izvajanjem funkcije ne spreminja !
               Ta funkcija po dim iteracijah, kjer je dim stevilo spremenljivk,
               na novo postavi nabor smeri.
             */
               /* POZOR!
                  Premisliti je treba se o najboljsem nacinu za preverjanje
                  konvergence! */
{
char end=0;
int dim,i,j,count,itbrak=0,itbrent=0,igreatdec=0;
struct _vector point0={0}, pointext={0}, factorbrak={0};
double f0,f00,greatdec=0,smalldec=0,smallnum=1.0e-40;
double a,b,c,fa,fb,fc;

dim=pointmin->d;
getvec(&point0,dim);  getvec(&pointext,dim);  getvec(&factorbrak,dim);
linestart=getvector(dim);  linedir=getvector(dim);
basevecfunc=func;
for (i=1; i<=dim; ++i)
  factorbrak.v[i]=1;
linemin(pointmin, fmin, mdir, dim /* smer */,
        hbrak, &factorbrak, &itbrak, 100/*maxitbrak*/,
        tolbrent, &itbrent, maxitbrent,
        &a, &b, &c,
        &fa, &fb, &fc);
connection(0);
do
{
  f00=*fmin;
  for (count=1; count<=dim; ++count) if (!end)
  /* Skupina iteracij z istim naborom smeri */
  {
    ++ *it; if (*it>=maxit) ++end;
    for (j=1; j<=dim; ++j)  /* Zacet. tocka za to iteracijo: */
      point0.v[j]=pointmin->v[j];
    f0=*fmin;   /* Vrednost funkcije v zacetni tocki. */
    /* Minimizacija po vseh smereh iz nabora smeri: */
    for (i=1; i<=dim; ++i)
    {
      linemin(pointmin, fmin, mdir, i /*smer*/,
              hbrak, &factorbrak, &itbrak, 100/*maxitbrak*/,
              tolbrent, &itbrent, maxitbrent,
              &a, &b, &c,
              &fa, &fb, &fc);
    }
    /* Povprecna smer zamenja prvo: */
    for (i=1; i<=dim-1; ++i)  /* Ciklicni pomik smer. vektorjev */
      for (j=1; j<=dim; ++j)
        mdir->m[i][j]=mdir->m[i+1][j];
    for (j=1; j<=dim; ++j)
      linedir->v[j]=pointmin->v[j]-point0.v[j];
    normvec1(linedir);
    for (j=1; j<=dim; ++j)
      mdir->m[dim][j]=linedir->v[j];
    /* Minimizacija v povprecni smeri: */
    linemin(pointmin, fmin, mdir, i /*smer*/,
            hbrak, &factorbrak, &itbrak, 100/*maxitbrak*/,
            tolbrent, &itbrent, maxitbrent,
            &a, &b, &c,
            &fa, &fb, &fc);
    /* Konvergencni pogoj: */
    if ( fabs(*fmin-f0)<=tol*(fabs(*fmin)+fabs(f0)+smallnum) )
      ++end;
    connection(1);
  }
  /* Nova postavitev smeri: */

  /*
  dispmat(mdir);
  *mdir=identitymat(dim);
  */

  for (i=1; i<=dim; ++i)
    for (j=1; j<=dim; ++j)
    {
      if (i==j)
        mdir->m[i][j]=1;
      else
        mdir->m[i][j]=0;
    }
  linemin(pointmin, fmin, mdir, dim /* smer */,
          hbrak, &factorbrak, &itbrak, 100/*maxitbrak*/,
          tolbrent, &itbrent, maxitbrent,
          &a, &b, &c,
          &fa, &fb, &fc);
}  while (!end);
connection(2);
dispvec(&point0);  dispvec(&pointext);  dispvec(&factorbrak);
dispvector(&linestart);  dispvector(&linedir);
basevecfunc=NULL;
}



















void powell(vector pointmin, double *fmin, matrix mdir,
            double tol, int *it, int maxit,
            vector hbrak, double *tolbrent, int maxitbrent,
            double func(vector x), int connection(int), FILE *fp)
            /* Minimizira skalarno funkcijo vektorske spremenljivke func.
               pointmin je priblizek za minimum funkcije, fmin pa vrednost
               funkcije v pointmin. Na vhodu morata imeti obe spremenljivki
               ustrezne zacetne vrednosti. mdir je matrika, katere vrstice
               dolocajo smeri linijskih minimizacij. Dobro je, da so smeri
               na zacetku normirane. tol je relativna toleranca za razliko
               vrednosti funkcije v minimumu pred in po zadnji iteraciji.
               it je stevilo iteracij, maxit pa najvecje dovoljeno stevilo
               iteracij. hbrak je vektor zacetnih korakov v smereh minimizacij
               za funkcijo, ki objame minimum. tolbrent je vektor relativnih
               toleranc za linijske minimizacije v razlicnih smereh.
               func je funkcija, ki jo minimiziramo, connection je funkcija za
               zvezo z zunanjim okoljem, fp pa je izhodna datoteka.
               Ta funkcija uporablja funkcijo v dani smeri linefunc in zato
               tudi zunanje spremenljivke basevecfunc, linestart in linedir, ki
               so s to funkcijo povezane.
               tolbrent se med izvajanjem funkcije ne spreminja !
               smallbrak je vektor najmanjsih zacetnih korakov za vunkcijo
               brakmin. */
               /* POZOR!
                  Premisliti je treba se o najboljsem nacinu za preverjanje
                  konvergence! */
{
char end=0;
int dim,i,itbrak=0,itbrent=0,igreatdec=0;
struct _vector point0={0}, pointext={0}, factorbrak={0};
double f0,f00,fext,greatdec=0,smalldec=0,f0mom,xch,smallnum=1.0e-40;
double a,b,c,fa,fb,fc;

dim=pointmin->d;
getvec(&point0,dim);  getvec(&pointext,dim);  getvec(&factorbrak,dim);
linestart=getvector(dim);  linedir=getvector(dim);
basevecfunc=func;
for (i=1; i<=dim; ++i)
  factorbrak.v[i]=1;
connection(0);
do
{
  ++ *it;
  if (*it>=maxit) ++end;
  for (i=1; i<=dim; ++i)
    point0.v[i]=pointmin->v[i];  /* priblizek za min. na zacetku iteracije */
  f0=*fmin;
  f00=*fmin;
  igreatdec=1;  /* indeks smeri najvec. padca funkcije v tej iteraciji */
  greatdec=0;   /* najvecji padec funkcije v tej iteraciji */
  smalldec=1.0e30;   /* najmanjsi padec funkcije v tej iteraciji */
  /* Linijske minimizacije v vseh smereh v naboru: */
  for (i=1; i<=dim; ++i)
  {
    f0mom=*fmin;
    linemin(pointmin, fmin, mdir, i /* smer */,
             hbrak, &factorbrak, &itbrak, 100/*maxitbrak*/,
             tolbrent, &itbrent, maxitbrent,
             &a, &b, &c,
             &fa, &fb, &fc);
    /* Skopirata se smer in zacetna tocka: *@/
    for (j=1; j<=dim; ++j)
    {
      linestart.v[j]=pointmin->v[j];
      linedir.v[j]=mdir->m[i][j];
    }
    a=0; b=hbrak->v[i]*factorbrak.v[i]+smallnum;
    fa=linefunc(a);   fb=linefunc(b);
    while (fa==fb)
    {
      b*=30;
      fb=linefunc(b);
    }
    itbrak=0; itbrent=0;
    brakmin(&a,&b,&c,&fa,&fb,&fc, &itbrak,50, linefunc, minndemptycon, stdout);
    if (itbrak==1) factorbrak.v[i]/=2;
    if (itbrak>4) factorbrak.v[i]*=10;
    if (itbrak>16) factorbrak.v[i]*=5;
    if (itbrak>64) factorbrak.v[i]*=5;
    brent(&a,&b,&c,&fa,&fb,&fc, *tolbrent,&itbrent,maxitbrent,
          linefunc, minndemptycon, stdout);
    hbrak->v[i]=(b-a);
    /* Zacetni korak za funkcijo brakmin v doloceni smeri je prejsnja sirina
    intervala po linijski minimizaciji v tej smeri krat ustrezni faktor.
    Ta faktor se po vsaki iteraciji prilagaja in skrbi hkrati za to, da je
    za objem minimuma v dani smeri potrebno cim manj iteracij in da ni
    zacetni interval za linijsko minimizacijo prevelik. *@/
    for (j=1; j<=dim; ++j)  /* Minimum po tej linijski minimizaciji: *@/
      pointmin->v[j]=linestart.v[j]+b*linedir.v[j];
    *fmin=fb;  /* vrednost funkcije v pointmin *@/
    */
    /* Izbira smiselne tolerance za funkcijo brent */
    if (fabs(*fmin-f0mom)>greatdec)
    {
      greatdec=fabs(*fmin-f0mom);
      igreatdec=i;
    }
    if (fabs(*fmin-f0mom)<smalldec)
      smalldec=fabs(*fmin-f0mom);
    if (1)
    {
      if (fp!=NULL)
      {
        fprintf(fp,"  F. v.: %g;\n  Dir.:\n",*fmin);
        fprintvector(fp,linedir);
        fprintf(fp,"\n");
      }
    }
  }
  /*
  *tolbrent=0.001*fabs(smalldec)/(fabs(f0mom)+fabs(*fmin)+smallnum);
  */
  /* Konvergencni kriterij: */
  /*
  if (fabs(fabs(*fmin)-fabs(f0))<=tol*(fabs(*fmin)+fabs(f0)))
    ++ end;
  */
  /* Povprecna smer in ekstrapolirana tocka: */
  for (i=1; i<=dim; ++i)
  {
    linedir->v[i]=pointmin->v[i]-point0.v[i];
    pointext.v[i]=2*pointmin->v[i]-point0.v[i];
  }
  /* Vrednost funkcije v ekstrapolirani tocki: */
  fext=func(&pointext);
  /* Kriteriji za zamenjavo smeri najvecjega padca: */
  xch=2*(f0-2* *fmin+fext)*(f0-*fmin-greatdec)*(f0-*fmin-greatdec)
   -greatdec*(f0-fext)*(f0-fext);
  if (!(xch>=0 && fext>=f0))
  {
    /* Povprecna smer te iteracije zamenja smer najvecjega padca */
    normvec1(linedir);
    for (i=1; i<=dim; ++i)
      mdir->m[igreatdec][i]=linedir->v[i];
    /* Izvede se se minimizacija v novi smeri: */
    i=igreatdec;
    linemin(pointmin, fmin, mdir, igreatdec /* smer */,
             hbrak, &factorbrak, &itbrak, 100/*maxitbrak*/,
             tolbrent, &itbrent, maxitbrent,
             &a, &b, &c,
             &fa, &fb, &fc);
    /*
    for (j=1; j<=dim; ++j)
      linestart.v[j]=pointmin->v[j];
    a=0; b=hbrak->v[i]*factorbrak.v[i]+smallnum;
    fa=linefunc(a);   fb=linefunc(b);
    while (fa==fb)
    {
      b*=30;
      fb=linefunc(b);
    }
    itbrak=0;  itbrent=0;
    brakmin(&a,&b,&c,&fa,&fb,&fc, &itbrak,50, linefunc, minndemptycon, stdout);
    if (itbrak==1) factorbrak.v[i]/=2;
    if (itbrak>4) factorbrak.v[i]*=10;
    if (itbrak>16) factorbrak.v[i]*=5;
    brent(&a,&b,&c,&fa,&fb,&fc, *tolbrent,&itbrent,maxitbrent,
          linefunc, minndemptycon, stdout);
    hbrak->v[i]=(b-a);
    for (j=1; j<=dim; ++j)  /* Minimum po tej linijski minimizaciji: *@/
      pointmin->v[j]=linestart.v[j]+b*linedir.v[j];
    *fmin=fb;  /* vrednost funkcije v pointmin *@/
    */
  }
  /* Konvergencni kriterij: */
  if (fabs(*fmin-f00)<=tol*0.5*(fabs(*fmin)+fabs(f00)+smallnum))
    ++ end;
  connection(1);
  if (fp!=NULL)
  {
    fprintf(fp,"  Function value:  %g\n",*fmin);
    fprintf(fp,"in point:\n");
    fprintvec(fp,*pointmin);
  }
  if (1)
  {
    if (fp!=NULL)
    {
      fprintf(fp,"\n  Directions:\n");
      fprintmat(fp,*mdir);
    }
  }
  if (fp!=NULL)
    fprintf(fp,"\n\n");
} while (! end);
connection(2);
dispvec(&point0);  dispvec(&pointext);  dispvec(&factorbrak);
dispvector(&linestart);  dispvector(&linedir);
basevecfunc=NULL;
}


















void powell1(vector pointmin, double *fmin, matrix mdir,
            double tol, int *it, int maxit,
            vector hbrak, double *tolbrent, int maxitbrent,
            double func(vector x), int connection(int), FILE *fp)
            /* Minimizira skalarno funkcijo vektorske spremenljivke func.
            Ta funkcija je ekvivalent funkcije powell, le da je narejena
            po vzorcu iz Numerical recipes.
            */
{
char end=0;
int dim,i,itbrak=0,itbrent=0,igreatdec=0;
struct _vector point0={0}, pointext={0}, factorbrak={0};
double f0,f00,fext,greatdec=0,smalldec=0,f0mom,xch,smallnum=1.0e-40;
double a,b,c,fa,fb,fc;
dim=pointmin->d;
getvec(&point0,dim);  getvec(&pointext,dim);  getvec(&factorbrak,dim);
linestart=getvector(dim);   linedir=getvector(dim);
basevecfunc=func;
for (i=1; i<=dim; ++i)
  factorbrak.v[i]=1;
connection(0);
do
{
  ++ *it;
  if (*it>=maxit) ++end;
  /*
  for (i=1; i<=dim; ++i)
    point0.v[i]=pointmin->v[i];  /* priblizek za min. na zacetku iteracije */
  f0=*fmin;
  f00=*fmin;
  igreatdec=1;  /* indeks smeri najvec. padca funkcije v tej iteraciji */
  greatdec=0;   /* najvecji padec funkcije v tej iteraciji */
  smalldec=1.0e30;   /* najmanjsi padec funkcije v tej iteraciji */
  /* Linijske minimizacije v vseh smereh v naboru: */
  for (i=1; i<=dim; ++i)
  {
    f0mom=*fmin;
linemin(pointmin, fmin, mdir, i /* smer */,
             hbrak, &factorbrak, &itbrak, 100/*maxitbrak*/,
             tolbrent, &itbrent, maxitbrent,
             &a, &b, &c,
             &fa, &fb, &fc);
    /* Izbira smiselne tolerance za funkcijo brent */
    if (fabs(*fmin-f0mom)>greatdec)
    {
      greatdec=fabs(*fmin-f0mom);
      igreatdec=i;
    }
    if (fabs(*fmin-f0mom)<smalldec)
      smalldec=fabs(*fmin-f0mom);
    if (1)
    {
      if (fp!=NULL)
      {
        fprintf(fp,"  F. v.: %g;\n  Dir.:\n",*fmin);
        fprintvector(fp,linedir);
        fprintf(fp,"\n");
      }
    }
  }
  /*
  *tolbrent=0.001*fabs(smalldec)/(fabs(f0mom)+fabs(*fmin)+smallnum);
  */
  /* Konvergencni kriterij: */
  /*
  if (fabs(fabs(*fmin)-fabs(f0))<=tol*(fabs(*fmin)+fabs(f0)))
    ++ end;
  */
  /* Povprecna smer in ekstrapolirana tocka: */
  for (i=1; i<=dim; ++i)
  {
    linedir->v[i]=pointmin->v[i]-point0.v[i];
    pointext.v[i]=2*pointmin->v[i]-point0.v[i];
  }
  for (i=1; i<=dim; ++i)
    point0.v[i]=pointmin->v[i];  /* priblizek za min. na zacetku iteracije */
  /* Vrednost funkcije v ekstrapolirani tocki: */
  fext=func(&pointext);
  /* Kriteriji za zamenjavo smeri najvecjega padca: */
  xch=2*(f0-2* *fmin+fext)*(f0-*fmin-greatdec)*(f0-*fmin-greatdec)
   -greatdec*(f0-fext)*(f0-fext);
  if (!(xch>=0 && fext>=f0))
  {
    /* Povprecna smer te iteracije zamenja smer najvecjega padca */
    normvec1(linedir);
    for (i=1; i<=dim; ++i)
      mdir->m[igreatdec][i]=linedir->v[i];
    /* Izvede se se minimizacija v novi smeri: */
    i=igreatdec;
linemin(pointmin, fmin, mdir, igreatdec /* smer */,
             hbrak, &factorbrak, &itbrak, 100/*maxitbrak*/,
             tolbrent, &itbrent, maxitbrent,
             &a, &b, &c,
             &fa, &fb, &fc);
  }
  /* Konvergencni kriterij: */
  if (fabs(*fmin-f00)<=tol*0.5*(fabs(*fmin)+fabs(f00)+smallnum))
    ++ end;
  connection(1);
  if (fp!=NULL)
  {
    fprintf(fp,"  Function value:  %g\n",*fmin);
    fprintf(fp,"in point:\n");
    fprintvec(fp,*pointmin);
  }
  if (1)
  {
    if (fp!=NULL)
    {
      fprintf(fp,"\n  Directions:\n");
      fprintmat(fp,*mdir);
    }
  }
  if (fp!=NULL)
    fprintf(fp,"\n\n");
} while (! end);
connection(2);
dispvec(&point0);  dispvec(&pointext);  dispvec(&factorbrak);
dispvector(&linestart);  dispvector(&linedir);
basevecfunc=NULL;
}












































































































































