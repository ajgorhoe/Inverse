/* LUPINA DATOTECNEGA INTERPRETERJA */


#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>


#include <mtypes.h>
#include <rf.h>
#include <fop.h>
#include <st.h>
#include <strop.h>
#include <simb.h>
#include <lint.h>
#include <iotool.h>
#include <globut.h>
#include <er.h>
#include <fint.h>

/*
#include <inv.h>
#include <invoplib.h>
*/








static int /* outdig=8, */   /* St. dec. mest pri izpisovanju stevil */
           outchar=1;  /* Min. st. mest pri izpisovanju stevil */

int fintgetoutdig(void)
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu fint.c.
    $A Igor mar99; */
{
return m_outdig;
}

int fintgetoutchar(void)
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu fint.c.
    $A Igor mar99; */
{
return outchar;
}

void fintsetoutdig(int num)
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu fint.c.
    $A Igor mar99; */
{
if (m_outdig>0)
  m_outdig=num;
}

void fintsetoutchar(int num)
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu fint.c.
    $A Igor mar99; */
{
if (outchar>0)
  outchar=num;
}



static int cmpip(void *p1,void *p2)
    /* Primerja kazalca na int po vrednosti stevil, na kateri kazeta. Ce sta
    oba kazalca NULL, vrne 0, ce je le p1 NULL, vrne 2 (v tem primeru se
    smatra, da je p1 vecji od p2), ce pa je le p2 NULL, vrne -2. Ce sta oba
    razlicna od NULL, vrne funkcija -1, ce je *p1<*p2, 0, ce je *p1==*p2 in
    1, ce je *p1>*p2.
    $A Igor apr98; */
{
int *ip1,*ip2;
ip1=p1; ip2=p2;
if (ip1!=NULL && ip2!=NULL)
{
  if (*ip1<*ip2)
    return -1;
  else if (*ip1==*ip2)
    return 0;
  else
    return 1;
} else if (ip1==NULL)
{
  if (ip2==NULL)
    return 0;
  else
    return 2;
} else if (ip2==NULL)
  return -2;
else return -2;  /* samo zaradi prevajalnika */
}


static int cmpfifuncdata(void *p1,void *p2)
    /* Primerja kazalca p1 in p2 tipa fifuncdata po (...)->name. Ce sta p1 in
    p2 razlicna od NULL, vrne funkcija kar cmpstrings(p1->name,p2->name), ce sta
    oba NULL, vrne 0, ce je le p1 NULL, vrne 2 (v tem primeru se smatra, da je
    p1 vecji od p2), ce pa je le p2 NULL, vrne -2.
    $A Igor dec97; */
{
fifuncdata u1,u2;
u1=p1; u2=p2;
if (u1!=NULL && u2!=NULL)
  return cmpstrings(u1->name,u2->name);
else if (u1==NULL)
{
  if (u2==NULL)
    return 0;
  else
    return 2;
} else if (u2==NULL)
  return -2;
else return -2; /* samo zaradi prevajalnika */
}


static int cmpfifunction(void *p1,void *p2)
    /* Primerja kazalca p1 in p2 tipa fifunction po (...)->name. Ce sta p1 in
    p2 razlicna od NULL, vrne funkcija kar cmpstrings(p1->name,p2->name), ce sta
    oba NULL, vrne 0, ce je le p1 NULL, vrne 2 (v tem primeru se smatra, da je
    p1 vecji od p2), ce pa je le p2 NULL, vrne -2.
    $A Igor mar98; */
{
fifunction func1,func2;
func1=p1; func2=p2;
if (func1!=NULL && func2!=NULL)
  return cmpstrings(func1->name,func2->name);
else if (func1==NULL)
{
  if (func2==NULL)
    return 0;
  else
    return 2;
} else if (func2==NULL)
  return -2;
else
  return -2;  /* samo zaradi prevajalnika */
}



static int cmpfifunctionstr(void *pname,void *pfunc)
    /* Primerja pname in pfunc->name s funkcijo cmpstrings; Ce je pfunc enak NULL,
    vrne -2, drugace pa tisto, kar vrne funkcija cmpstrings(pname,pfunc->name).
    $A Igor mar98; */
{
char *name;
fifunction func;
name=pname; func=pfunc;
if (func!=NULL)
  return cmpstrings(name,func->name);
else
  return -2;
}



/*
static void printfifuncdata(fifuncdata data)
{
printf("\n");
if (data==NULL)
  printf("Error: data for function definition is NULL.\n");
else
{
  printf("Function \"%s\":\n",data->name);
  printf("Definition in file \"%s\".\n",data->filename);
  printf("Function block from position %i to position %i.\n",data->begin,data->end);
  if (data->argnames==NULL)
    printf("No arguments.\n");
  else
  {
    int i;
    if (data->argnames->n>0)
      for (i=1;i<=data->argnames->n;++i)
        printf("  %i. argument: \"%s\"\n",i,data->argnames->s[i]);
  }
}
printf("\n");
}
*/


/*
static void printuserfunc(ssyst syst)
{
if (1)
if (syst!=NULL)
  if (syst->user!=NULL)
    if (syst->user->n>0)
    {
      int i;
      for (i=1;i<=syst->user->n;++i)
      {
        userfunc usf=syst->user->s[i];
        if (usf!=NULL)
          printf("%s ",usf->name);
      }
      printf("\n");
    }
}
*/


fifunction newfifunction(void)
    /* Alocira prostor za objekt tipa fifunction in vrne kazalec nanj; Vsa
    polja objekta postavi na NULL.
    $A Igor mar98; */
{
fifunction ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
ret->name=NULL;
ret->action=ret->checkaction=NULL;
return ret;
}

void dispfifunction(fifunction *func)
    /* Zbrise objekt tipa fifunction *func in ga postavi na NULL. Zbrise tudi
    (*func)->name.
    $A Igor mar98; */
{
if (func!=NULL)
{
  if ((*func)->name==NULL)
    free((*func)->name);
  free(*func);
  *func=NULL;
}
}


static FILE *defaultoutfile(ficom com)
    /* Default function for accessing interpreter outpur file, it just returns
    the file com->outfl. Field com->outfile is set to this function when the 
    interpreter structure is allocated, and can later be substituted by the
    software that uses the interpreter (e.g. by Inverse).
    $A Igor aug04; */
{
return com->outfl;
}


ficom newficom(void)
    /* Vrne kazalec na objekt tipa _ficom, za katerega alocira prostor. Vsa
    polja strukture postavi na 0, razen obeh skaldov, za katera se tudi
    alocira prostor.
    $A Igor <== jun97; */
{
ficom com;
com=malloc(sizeof(*com));
memset(com,0,sizeof(*com));
com->brac1='{';
com->brac2='}';
com->endchar='\0';
com->expbrac1='('; com->expbrac2=')';
com->blockbrac1='['; com->blockbrac2=']';
com->stopint=0;
com->level=0;
com->exitlevels=0;
com->labelstr=stringcopy("label");
com->gotolabel=NULL;
com->functions=newstack(5);
com->fp=NULL;
com->filename=NULL;
com->origfilename=NULL;
com->from=com->to=com->pos=com->begin=com->end=com->beginpos=com->origpos=0;
com->temp=NULL;
com->tempname=NULL;
com->temppos=0;
com->in=NULL;
com->outfl=NULL;
com->outfile=defaultoutfile;
com->syst=NULL;
/* Za funkcije simbolnega kalkulatorja, ki so definirane v ukazni datoteki: */
com->args=NULL;
com->numargs=0;
com->doubleret=0;	
com->funcdefstack=newstack(2);
/* Sklad definicij funkcij interpreterja: */
com->functionstack=newstack(5);
com->debug=com->check=0;
/* Sledenje funkcijskim klicem: */
com->callst=NULL;
com->trace=0;
/* Spremenljivke za preverjanje sintakse in debugiranje: */
com->lint=NULL;
com->linespre=3; com->linespost=7;
com->stop=1;
com->stepover=0;
com->numexec=0;
com->stoplevel=-1;
com->watch=0;
com->watchst=NULL;
com->dfname=NULL;
com->sball=0;
com->sb=com->ab=NULL;
return com;
}





void dispficom(ficom *fi)
    /* Sprosti spomin za spremenljivko **fi. Zbrise tudi sklada (**fi).actions
    in (**fi).commands, s tem da pri skladu (**fi).commands zbrise tudi vse
    nize, ki so na tem skladu (?). Sprosti se tudi spomin za (**fi).filename.
    $A Igor <== jun97; */
{
ficom com;
fifuncdata calcfunc;
int i;
if (fi!=NULL)
{
  com=*fi;
  if (com!=NULL)
  {
    dispstackvalspec(com->functions,(void (*) (void **)) dispfifunction);
    dispstack(&(com->functions));
    if (com->filename!=NULL)
      free(com->filename);
    if (com->labelstr!=NULL)
      free(com->labelstr);
    if (com->temp!=NULL)
      fclose(com->temp);
    disppointer((void **) &(com->tempname));
    if (com->funcdefstack!=NULL)
    {
      if (com->funcdefstack->n>0)
        for (i=1;i<=com->funcdefstack->n;++i)
        {
          /* Pri definicijah funkcij kalkulatorja, ki so bile definirane med
          interpretacijo, ki ji pripada spremenljivka fi, je treba prepreciti, da
          bi se poskusile izvesti v primeru, da je sistem kalkulatorja, v katerem
          zdaj obstajajo definicije teh funkcij, uporabljen se kje drugje: */
          calcfunc=com->funcdefstack->s[i];
          if (calcfunc!=NULL)
          {
            calcfunc->fcom=NULL;
            if (calcfunc->filename!=NULL)
            {
              free(calcfunc->filename);
              calcfunc->filename=NULL;
            }
            calcfunc->begin=calcfunc->end=0;
          }
        }
      dispstack(&com->funcdefstack);
    }
    if (com->functionstack!=NULL)
    {
      dispstack(&com->functionstack);
    }
    if (com->callst!=NULL)
      dispstack(&(com->callst));
    if (com->lint!=NULL)
      displicom(&(com->lint));
    if (com->watch!=0)
    {
      dispstackval(com->watchst);
      dispstack(&(com->watchst));
    }
    if (com->dfname!=NULL)
      free(com->dfname);
    dispstackval(com->sb);
    dispstack(&(com->sb));
    dispstackval(com->ab);
    dispstack(&(com->ab));
    free(com);
  }
  *fi=NULL;
}
}





void printficom(ficom com)
    /* Izpise vrednosti polj spremenljivke *com.
    $A Igor <== mar98; */
{
int i;
fifunction func;
printf("  Brackets:\n");
printf("brac1:      %c\n",com->brac1);
printf("brac2:      %c\n",com->brac2);
printf("endchar:    %c\n",com->endchar);
printf("expbrac1:   %c\n",com->expbrac1);
printf("expbrac2:   %c\n",com->expbrac2);
printf("blockbrac1: %c\n",com->blockbrac1);
printf("blockbrac2: %c\n",com->blockbrac2);
printf("  stopint: ");
if (com->stopint) printf("TRUE\n"); else printf("FALSE\n");
printf("  Level:          %i\n",com->level);
printf("  Levels to exit: %i\n",com->exitlevels);
if (com->gotolabel==NULL)  printf("  Label empty.\n");
else printf("  Label: \"%s\".\n",com->gotolabel);
if (com->filename==NULL)
  printf("  Name of the file is not given.\n");
else printf("  Name of the file: \"%s\".\n",com->filename);
if (com->fp==NULL) printf("  FILE IS NOT OPEN!\n");
if (com->outfile(com)==NULL) printf("  Output file not open.\n");
if (com->syst==NULL) printf("  INTERPRETER NOT INSTALLED!\n");
if (com->functions==NULL)
  printf(  "No functions installed.\n");
else if (com->functions->n<=0)
  printf(  "No functions installed.\n");
else
{
  printf("  Functions:\n");
  for (i=1; i<=com->functions->n; ++i)
  {
    if ((func=com->functions->s[i])!=NULL)
    {
      if (func->action==NULL)
        printf("UNDEFINED ACTION FOR FUNCTION \"%s\".\n",func->name);
      printf("%i. function: %s\n",i,func->name);
    }
  }
}
}


void fintpreparetemp(ficom fcom)
    /* Pripravi zacasno datoteko fcom->temp za uporabo: ce ni odprta, jo odpre
    (po potrebi tudi doloci zacasno ime), ce je datoteka v rabi, pa pozicijo
    postavi na prvo pozicijo za delom datoteke, ki je v rabi.
    $A Igor apr99; */
{
char *str=NULL;
if (fcom!=NULL)
{
  if (fcom->temp==NULL && fcom->tempname==NULL)
  {
    /* Pomozna datoteka se ne obstaja, zato se tvori na novo */
    fcom->temppos=0;
    str=tmpnam(NULL);
    if (str!=NULL)
    {
      fcom->tempname=stringcopy(str);
      fcom->temp=fopen(fcom->tempname,"wb+");
      if (fcom->temp==NULL)
      {
        /* Ce datoteke ne uspemo odpreti, zbrisemo tudi ime: */
        disppointer((void **) &(fcom->tempname));
      }
    }
    if (fcom->temp==NULL)
    {
      /* Nismo uspeli odpreti datoteke z danim zacasnim imenom, zato poskusimo
      s funkcijo tmpfile(): */
      fcom->temp=tmpfile();
    }
  } else
  {
    if (fcom->temp==NULL)
    {
      /* Pomozna ocitno ze obstaja, saj je definirano njeno ime, vendar je
      bila vmes zaprta. Poskusimo jo ponovno odpreti: */
      fcom->temp=fopen(fcom->tempname,"ab+");
    }
  }
  if (fcom->temp==NULL)
  {
    errfunc0("fintpreparetemp");
    fprintf(erf(),"File interpreter: Temporary file can not be opened.\n");
    errfunc2();
  } else
  {
    /* Na koncu se postavimo pozicijo na ustrezno mesto: */
    if (fcom->temppos<=0)
    {
      fseek(fcom->temp,0,SEEK_SET);
    } else if (fcom->temppos-1>flength(fcom->temp))
    {
      /* fcom->temppos je vecji kot dolzina datoteke, pozicijo postavimo na
      konec datoteke in javimo napako: */
      
      errfunc0("fintpreparetemp");
      fprintf(erf(),"File interpreter: Temporary file is shorter than expected.\n");
      errfunc2();
      fseek(fcom->temp,0,SEEK_END);
    } else if  (fcom->temppos-1==flength(fcom->temp))
    {
      fseek(fcom->temp,0,SEEK_END);
    } else
    {
      fseek(fcom->temp,fcom->temppos-1,SEEK_SET);
    }
  }
}
}



void fintclosetemp(ficom fcom)
    /* Ce je mozno, zapre zacasno datoteko fcom->temp, ce datoteka ni v rabi,
    zbrise tudi povezano fizicno datoteko, ce ta obstaja.
    $A Igor apr99; */
{
if (fcom!=NULL)
{
  if (fcom->temppos>0)
  {
    if (fcom->temp!=NULL)
    {
      if (fcom->tempname!=NULL)
      {
        fclose(fcom->temp);
        fcom->temp=NULL;
      } else
      {
        /* Datoteka fcom->temp je se v uporabi, poleg tega je to datoteka, ki
        smo jo naredili s funkcijo tmpfile() in ne poznamo njenega imena (torej
        je po zaprtju ne bi mogli ponovno odpreti), zato je ne smemo zapreti: */
        
        errfunc0("fintclosetemp");
        fprintf(erf(),"File interpreter: Temporary file can not be closed - still in use.\n");
        errfunc2();
      }
    }
  } else
  {
    if (fcom->temp!=NULL)
    {
      fclose(fcom->temp);
      fcom->temp=NULL;
    }
    /* Zacasna datoteka ni vec v rabi, zato lahko tudi fizicno datoteko
    zbrisemo: */
    if (fcom->tempname!=NULL)
      remove(fcom->tempname);
    disppointer((void **) &(fcom->tempname));
  }
}
}


void fintpos(ficom fcom,char **functionname,char **originalfilename,
             int *originalline,char **filename,int *line)
    /* Vrne trenutno pozicijo v datotecnem interpreterju fcom. V *functionname
    zapise kazalec na ime funkcije, ki se trenutno izvaja, v *filename ime
    datoteke, ki se interpretira, v *line vrstico v tej datoteki, kjer je
    trenutna pozicija interpretacije, v originalfilename ime originalne
    datoteke, iz katere izvira koda, ki se trenutno interpretira, v
    *originalline pa stevilko vrstice v tej datoteki, kjer se nahaja trenutno
    interpretirana koda. Ce je interpretirana koda ze tako v originalni
    datoteki, vrne v *filename NULL.
     Argumenti functionname, filename in originalfiilename so lahko NULL, v tem
    primeru se ne zapisejo ustrezni podatki. Kazalcev, na katere ti kazajo po
    izhodu iz funkcije, se ne sme brisati s free, ker se zanje v funkciji ne
    alocira prostor!
    $A Igor apr99; */
{
fifunction func=NULL;
FILE *fp;
long pos;
int col;
if (functionname!=NULL)
  *functionname=NULL;
if (originalfilename!=NULL)
  *originalfilename=NULL;
if (filename!=NULL)
  *filename=NULL;
*originalline=*line=0;
if (fcom!=NULL)
{
  if (fcom->which>0)
    func=fcom->functions->s[fcom->which];
  if (func!=NULL && functionname!=NULL)
    *functionname=func->name;
  if (fcom->origfilename==NULL)
  {
    /* Trenutno interpretirana koda je v originalni datoteki: */
    if (originalfilename!=NULL)
      *originalfilename=fcom->filename;
    if (fcom->fp!=NULL)
      filelinepos(fcom->fp,fcom->pos,originalline,&col);
  } else
  {
    /* Trenutno interpretirana koda je v zacasni, ne originalni datoteki: */
    if (originalfilename!=NULL)
      *originalfilename=fcom->origfilename;
    if (filename!=NULL)
      *filename=fcom->filename;
    if (fcom->fp!=NULL)  /* Pozicija v interpretirani (zacasni) datoteki: */
      filelinepos(fcom->fp,fcom->pos,line,&col);
    pos=fcom->origpos+(fcom->pos-fcom->beginpos);
    fp=fopen(fcom->origfilename,"rb");
    if (fp!=NULL)
    {
      filelinepos(fp,pos,originalline,&col); /* pozicija v originalni datoteki */
      fclose(fp);
    }
  }
}
}



void fprintficallstack(FILE *fp,ficom com)
    /* V datoteko fp zapise klicno zaporedje funkcij, ki se v trenutku klica
    te funkcije izvajajo v datotecnem interpreterju com.
    $A Igor mar99; */
{
if (fp!=NULL)
  if (com!=NULL)
    if (com->callst!=NULL)
      if (com->callst->n>0)
      {
        int i;
        for (i=1;i<=com->callst->n;++i)
        {
          fprintf(fp,"%s",com->callst->s[i]);
          if (i<com->callst->n)
            fprintf(fp,"->");
        }
      }
}

void printficallstack(ficom com)
    /* Na standardni izhod fp zapise klicno zaporedje funkcij, ki se v trenutku
    klica te funkcije izvajajo v datotecnem interpreterju com.
    $A Igor mar99; */
{
fprintficallstack(stdout,com);
}

 /* NEKAJ POMOZNIH FUNKCIJ IN SPREMENLJIVK: */


/* Vmesni pomnilnik za branje imena funkcije: */
#define MAXNAME 50
char functionname[MAXNAME+1];

/* Podatki o interpretaciji, na katero se nanasa razhroscevanje: */
static ficom fint=NULL;
static int codeshift=0;


static void fprintcodedebug(FILE *fp,ficom com)
    /* Ta funkcija izpise del ukazne datoteke okrog pozicije com->pos
    (com->linespre pred pos0 in com->linespost za pos0) v datoteko fp.
    Uporablja se za izpis odsekov kode pri razhroscevanju ukazne datoteke okrog
    mest, kjer se ustavi interpretacija in preda kontrola uporabniku. Na com so
    podatki o interpretaciji datoteke.
    $A Igor apr98 apr99; */
{
char *originalfile,*file;
int originalline,line;
if (fp!=NULL)
{
  fprintf(fp,"\n==============================================================\n");
  line=fprintfewfilelines(fp,com->fp,com->pos,com->linespre,com->linespost,"==> ");
  fintpos(com,NULL,&originalfile,&originalline,&file,&line);
  if (file==NULL)
    fprintf(fp,"=================== file \"%s\", line %i ==\n",
            originalfile,originalline);
  else
    fprintf(fp,"======== file \"%s\", line %i (\"%s\", line %i) ==\n",
            originalfile,originalline,file,line);
}
}


static void fprintcodedebugshift(FILE *fp,ficom com,int shift)
    /* Ta funkcija izpise del ukazne datoteke okrog pozicije com->pos
    (com->linespre pred pos0 in com->linespost za pos0) v datoteko fp.
    Uporablja se za izpis odsekov kode pri razhroscevanju ukazne datoteke okrog
    mest, kjer se ustavi interpretacija in preda kontrola uporabniku. Na com so
    podatki o interpretaciji datoteke.
    $A Igor apr98; */
{
int centerline,line,column;
long centerpos;
if (fp!=NULL)
{
  filelinepos(com->fp,com->pos,&line,&column);
  centerline=line+shift;
  centerpos=fileabspos(com->fp,centerline,1);
  fprintf(fp,"\n==============================================================\n");
  /* Ce ni zamika med vrstico, v kateri je trenutna pozicija com->pos in med
  srediscno vrstico tega izpisa, se za oznacevanje srediscne vrstice uporabi isti
  niz kot v funkciji fprintcodedebug(), drugace se uporabi drug znak: */
  if (shift)
    line=fprintfewfilelines(fp,com->fp,centerpos,com->linespre,com->linespost,">>");
  else
    line=fprintfewfilelines(fp,com->fp,centerpos,com->linespre,com->linespost,"==> ");
  fprintf(fp,"=================== file \"%s\", line %i (shift = %i) ==\n",
          com->filename,line,shift);
}
}


static void fprintcodecheck(FILE *fp,ficom com,long pos0)
    /* Ta funkcija izpise del ukazne datoteke okrog pozicije pos0
    (com->linespre pred pos0 in com->linespost za pos0) v datoteko fp.
    Uporablja se za izpis odsekov kode pri preglejevanju ukazne datoteke okrog
    mest, kjer se odkrijejo napake. Na com so podatki o interpretaciji
    datoteke. Funkcija se uporablja v funkcijah fiwaituser in fiwaituserout.
    $A Igor apr98; */
{
int line;
if (fp!=NULL)
{
  fprintf(fp,"\n==============================================================\n");
  line=fprintfewfilelines(fp,com->fp,pos0,com->linespre,com->linespost,"==> ");
  fprintf(fp,"========================================= file \"%s\", line %i\n",
          com->filename,line);
}
}


void fiwaituser(ficom com)
    /* Izpise podatke o datoteki, ki se interpretira, in mestu interpretacije
    ter caka, dokler uporabnik ne pritisne tipke <Return>. Funkcija se
    uporablja znotraj funkcij, ki preverjajo sintakso funkcij, instaliranih na
    datotecni interpreter. Ta funkcija se razlikuje od fiwaituserout po tem, da
    ne uporablja lokalne spremenljivke functionname, ampak le podatke, ki so na
    com.
    $A Igor apr1998; */
{
int line,column;
fifunction func;
char *name=NULL,ch;
func=com->func;
if (func!=NULL)
  name=func->name;
filelinepos(com->fp,com->funcpos,&line,&column);
printf("\n>>>>>> Function \"%s\" in file \"%s\", line %i, column %i.\n",
 name,com->filename,line,column);
if (com->outfile(com)!=NULL)
  fprintf(com->outfile(com),"\n>>>>>> Function \"%s\" in file \"%s\", line %i, column %i.\n",
   name,com->filename,line,column);
fprintcodecheck(stdout,com,com->funcpos);
printf("Press <Return> (or insert 'x' to exit)!\n");
ch=getchar();
if (ch=='x')
  com->stopint=1;
}


static void fiwaituserout(ficom com)
    /* Izpise podatke o datoteki, ki se interpretira, in mestu interpretacije
    ter caka, dokler uporabnik ne pritisne tipke <Return>. Funkcija se
    uporablja znotraj funkcij, ki preverjajo sintakso funkcij, instaliranih na
    datotecni interpreter.
    $A Igor apr1998; */
{
int line,column;
fifunction func;
char *name=NULL,ch;
func=com->func;
if (func!=NULL)
  name=func->name;
filelinepos(com->fp,com->funcpos,&line,&column);
printf("\n>>>>>> Function \"%s\" in file \"%s\", line %i, column %i.\nAfter \"%s\".\n",
 functionname,com->filename,line,column,name);
if (com->outfile(com)!=NULL)
{
  fprintf(com->outfile(com),"\n>>>>>> Function \"%s\" in file \"%s\", line %i, column %i.\nAfter \"%s\".\n",
   functionname,com->filename,line,column,name);
}
fprintcodecheck(stdout,com,com->funcpos);
printf("Press <Return> (or insert 'x' to exit)!\n");
ch=getchar();
if (ch=='x')
  com->stopint=1;
/*
system("clear");
*/
}




/* FUNKCIJE VRSTICNEGA INTERPRETERJA: */


static void printwatchval(void);

static void debugbefore(void *ptrcom)
{
codeshift=0;  /* resetiranje zamika izpisane kode */
fprintcodedebug(stdout,fint); /* izpis odseka kode okrog trenutne pozicije */
if (fint->watch)
  printwatchval();  /* izpis vrednosti izrazov na skladu fint->watchst */
}

static void debugsignal(void *ptrcom)
    /* Izpise znak, ki pove uporabniku, da je v debuggerju. Ta funkcija se
    naj izvrsi pred branjem vsakega ukaza v vrsticnem interpreterju, zato jo
    instaliramo na vrsticni interpreter datotecnega interpreterja.
    $A Igor apr98; */
{
printf("DEBUG >");
}

static char *lastcommand=NULL, *lastparam=NULL;
static char *paramrun=NULL;

static void debugpreaction(void * ptrcom)
    /* Funkcija, ki se izvede pred izvedbo vsakega ukaza v vrsticnem
    interpreterju. Ce je bil vstavljen ukaz, se ta shrane v spremenljivko
    lastcommand, njegovi parametri pa v lastparam. Ce pa je uporabnik vstavil
    prazno vrstico, se trenutni ukaz zamenja z lastcommand, trenuten niz
    parametrov pa z lastparam. S tem povzrocimo ponovitev zadnjega ukaza v
    primeru, da je uporabnik vstavil namesto ukaza prazno vrstico.
    $A Igor apr98 sep99; */
{
licom lcom;
char fintcom=0,*comstr;
lcom=(void *) ptrcom;
if (lcom->com==NULL || cmpstrings(lcom->com,"")==0)
{
  /* Ce uporabnik vstavi prazno vrstico, se ponovi zadnji vstavljeni ukaz: */
  if (lcom->com!=NULL)
    free(lcom->com);
  lcom->com=stringcopy(lastcommand);
  lcom->param=lastparam;
} else
{
  /* Zapomni se zadnji vstavljeni ukaz s parametri: */
  if (lastcommand!=NULL)
    free(lastcommand);
  lastcommand=stringcopy(lcom->com);
  if (lastparam!=NULL)
    free(lastparam);
  lastparam=stringcopy(lcom->param);
}
if (lcom->com!=NULL)
{
  if (strchr(lcom->com,'{')!=NULL)
    fintcom=1;
  else if (lcom->param!=NULL)
    if (strchr(lcom->param,'{')!=NULL && cmpstrings(lcom->com,"r") && 
     cmpstrings(lcom->com,"run") )
      fintcom=1;
}
if (fintcom)
{
  /* Ce nastopa v ukazu zaviti oklepaj, se izvede ukaz datotecnega
  interpreterja, ki ga tvorita skupaj ukaz in vrstica parametrov: */
  disppointer((void **) &paramrun);
  comstr=stringcat(lcom->com," ");
  paramrun=stringcat(comstr,lcom->param);
  disppointer((void **) &comstr);
  lcom->param=paramrun;
  disppointer((void **) &(lcom->com));
  lcom->com=stringcopy("r");
  disppointer((void **)&lastcommand);
  disppointer((void **)&lastparam);
}
}


static void li_system(licom lcom)
     /* Pozene se intepreter, ki vse ukaze razen nekaterih specificnih poslje
     sistemu. Ce ima ustrezen ukaz kak argument, se le ta argument poslje
     sistemu v izvrsitev.
     $A Igor apr98; */
{
int buflength=500; /* Maksimalna dolzina vrstice */
char end=0,*buf=NULL,*pos=NULL,*command,*cm;
/* Ce ima ukaz argumente, se izvrsi le vrstica od zacetka 1. argumenta naprej: */
if (lcom->param!=NULL)
{
  /* printf("\n"); */
  /*
  puttohistory(lcom->param);
  */
  system(lcom->param);
  /* printf("\n"); */
  /*
  printf("\n  <System command executed.>\n");
  */
}
else
{
  printf("Type in system commands; \"x\" or \"q\" for quit.\n\n");
  /*
  statusline();
  */
  buf=malloc(buflength);
  while (!end)
  {
    printf("System >");
    buf[0]='\0';
    gets(buf);
    cm=NULL;
    command=memnotnchr(buf,strlen(buf)," ",1);
    if (command!=NULL)
    {
      pos=(void *) memnchr(command,strlen(command)," ",1);
      if (pos!=NULL)
        cm=stringncopy(command,pos-command);
      else
        cm=stringcopy(command);
      if (cmpstrings(cm,"x")==0 || cmpstrings(cm,"q")==0)
      {
        if (pos==NULL)
          end=1;
        else
          command=pos;
      }
      if (!end)
      {
        /*
        puttohistory(command);
        */
        system(command);
      }
      if (cm!=NULL)
        free(cm);
    }
  }
  if (buf!=NULL)
    free(buf);
  printf("\n");
}
}


static void li_quit(licom lcom)
    /* Funkcija, ki sprozi izhod iz vrsticnega interpreterja.
    $A Igor apr98 mar99; */
{
lcom->end=1;
if (fint->outfile(fint)!=NULL)
{
  fprintf(fint->outfile(fint),"\n\nExiting debugging session on user's command.\n\n");
}
printf("\n\nExiting debugging session on user's command.\n\n");
fint->exitlevels=fint->level;
fint->stopint=1;
}


static void li_exit(licom lcom)
    /* Funkcija, ki sprozi izhod iz vrsticnega interpreterja in konec
    interpretacije (oz. razhroscevanja) datoteke.
    $A Igor apr98 mar99; */
{
int cont=0,num;
if (lcom->param!=NULL)
{
  /* Ce ima ukaz argument, se iz le-tega poskusi prebrati stevilo: */
  cont=sscanf(lcom->param,"%i",&num);
}
if (cont<1)
  num=1;
lcom->end=1;
fint->stop=fint->stepover=0;
fint->stoplevel=fint->level-num;
}


static void li_step(licom lcom)
    /*  fint->stop postavi na 1, fint->stepover pa na 0 ter povzroci izhod iz
    vrsticnega interpreterja. To povzroci izvedbo do naslednega ukaza v
    datotecnem interpreterju. Interpretacija se ustavi tudi, ce je naslednji
    ukaz znotraj argumentnega bloka ukaza, ki se izvrsi.
    $A Igor apr98; */
{
lcom->end=1;
fint->stop=1; fint->stepover=0;
}

static void li_stepover(licom lcom)
    /* fint->stepover postavi na 1, fi_stop pa na 0 ter povzroci izhod iz
    vrsticnega interpreterja. To povzroci izvedbo naslednega ukaza v datotecnem
    interpreterju, pri cemer se morebitni bloki ukazov znotraj argumentnega
    bloka tega ukaza izvrsijo kot en ukaz (torej se pri njih interpretacija
    ne ustavi, razen ce se naleti na ukaz "bp" ali ce fint->numexec pade
    s pozitivne vrednosti na 0.
      OPOZORILO:
      Pri tistih funkcijah, pri katerih hocemo, da se njihovi morebitni notranji
    bloki izvrsijo kot en ukaz, moramo pred izvedbo teh blokov postaviti
    lcom->stepover na 0, da se ne po izvedbi prve notranje funkcije lcom->stop
    postavi na 1!
    $A Igor apr98; */
{
lcom->end=1;
fint->stepover=1; fint->stop=0;
}

static void li_continue(licom lcom)
    /* fint->stop in fint->stepover postavi na 0 in hkrati povzroci izhod iz
    vrsticnega interpreterja. To povzroci interpretacijo datoteke do prvega
    ukaza "bp" ali do konca ali dokler se ne izvede fint->numexec ukazov.
    $A Igor apr98; */
{
lcom->end=1;
fint->stop=fint->stepover=0;
fint->stoplevel=-1;
}

static void li_nstep(licom lcom)
    /* Prebere stevilo ukazov datotecnega interpreterja, ki naj se izvrsijo,
    preden se kontrola preda uporabniku (fint->numexec). Hkrati povzroci izhod
    iz vrsticnega interpreterja. Stevilo ukazov je lahko argument ukaza v
    vrsticnem interpreterju, ce pa ni, se od uporabnika zahteva, naj sam vstavi
    to stevilo. Ce v tem primeru namesto stevila pritisne le tipko <Return>, ta
    funkcija nima efekta.
    $A Igor apr98; */
{
int cont,num,buflength=100;
char *buf=NULL;
if (lcom->param!=NULL)
{
  /* Ce ima ukaz argument, se iz le-tega poskusi prebrati stevilo: */
  cont=sscanf(lcom->param,"%i",&num);
} else
{
  /* Ce vrsticni ukaz ni imel argumenta, poskusimo prebrati stevilo s stand.
  vhoda; Pri tem se izpise trenutna vrednost fint->numexec: */
  buf=malloc(buflength);
  printf("Number of commands to execute (now %i): ",fint->numexec);
  gets(buf);
  cont=sscanf(buf,"%i",&num);
}
if (cont>0 && num>0)
{
  /* Ce smo uspeli prebrati novo vrednost in ce je vecja od 0, postavimo
  fint->numexec na to vrednost in zapustimo vrsticni interpreter: */
  lcom->end=1;
  fint->numexec=num;
  fint->stoplevel=-1;
  fint->stop=0;
  fint->stepover=0;
}
if (buf!=NULL)
  free(buf);
}

static void li_nstepover(licom lcom)
    /* Prebere stevilo ukazov datotecnega interpreterja, ki naj se izvrsijo,
    preden se kontrola preda uporabniku (fint->numexec). Hkrati povzroci izhod
    iz vrsticnega interpreterja. Stevilo ukazov je lahko argument ukaza v
    vrsticnem interpreterju, ce pa ni, se od uporabnika zahteva, naj sam vstavi
    to stevilo. Ce v tem primeru namesto stevila pritisne le tipko <Return>, ta
    funkcija nima efekta. 
    Pri interpretaciji se ne stejejo ukazi, ki so v blokih visjih nivojev, kot
    je nivo, kjer je bil ukaz klican. Ce se nivo interpretacije zniza, se preda
    kontrolo uporabniku.
    $A Igor mar99; */
{
int cont,num,buflength=100;
char *buf=NULL;
if (lcom->param!=NULL)
{
  /* Ce ima ukaz argument, se iz le-tega poskusi prebrati stevilo: */
  cont=sscanf(lcom->param,"%i",&num);
} else
{
  /* Ce vrsticni ukaz ni imel argumenta, poskusimo prebrati stevilo s stand.
  vhoda; Pri tem se izpise trenutna vrednost fint->numexec: */
  buf=malloc(buflength);
  printf("Number of commands to execute (now %i): ",fint->numexec);
  gets(buf);
  cont=sscanf(buf,"%i",&num);
}
if (cont>0 && num>0)
{
  /* Ce smo uspeli prebrati novo vrednost in ce je vecja od 0, postavimo
  fint->numexec na to vrednost in zapustimo vrsticni interpreter: */
  lcom->end=1;
  fint->numexec=num;
  fint->stoplevel=fint->level-1;
  fint->stop=0;
  fint->stepover=0;
}
if (buf!=NULL)
  free(buf);
}


static void li_view(licom lcom)
    /* Relativni zamik pri izpisu kode (v vrsticah) se poveca za argument tega
    ukaza. Ce je bil ukaz dan brez argumentov, se postavi na 0. Izpise se
    odsek kode okrog premaknjene trenutne pozicije (stevilo vrstic zamika je v
    lokalni spremenljivki codeshift).
    $A Igor apr98; */
{
int cont=0,num,buflength=100;
char *buf=NULL;
if (lcom->param!=NULL)
{
  /* Ce ima ukaz argument, se iz le-tega poskusi prebrati stevilo: */
  cont=sscanf(lcom->param,"%i",&num);
  /* Ce argument ne predstavlja celega stevila, se uporabniku sugerira, naj se
  enkrat vstavi stevilo prek standardnega vhoda: */
  if (cont<1)
  {
    buf=malloc(buflength);
    printf("Shift increase/decrease was not specified properly! Input an integer!\n");
    printf("Shift increase/decrease for centerline (shift is now %i): ",codeshift);
    gets(buf);
    cont=sscanf(buf,"%i",&num);
  }
  /* Ce je uporabnik podal stevilo, se spremenljivki codeshift pristeje to
  stevilo: */
  if (cont==1)
    codeshift+=num;
} else /* Ce je ukaz brez argumenta, se zamik postavi na 0: */
  codeshift=0;
/* Izpis nekaj vrstic kode okrog vrstice, zamaknjene za codeshift: */
fprintcodedebugshift(stdout,fint,codeshift);
if (buf!=NULL)
  free(buf);
}


static void li_viewrel(licom lcom)
    /* Relativni zamik pri izpisu kode (v vrsticah) se postavi na argument tega
    ukaza. Ce je bil ukaz dan brez argumentov, se ne spremeni. Izpise se
    odsek kode okrog premaknjene trenutne pozicije (stevilo vrstic zamika je v
    lokalni spremenljivki codeshift).
    $A Igor apr98; */
{
int cont=0,num,buflength=100;
char *buf=NULL;
if (lcom->param!=NULL)
{
  /* Ce ima ukaz argument, se iz le-tega poskusi prebrati stevilo: */
  cont=sscanf(lcom->param,"%i",&num);
  /* Ce argument ne predstavlja celega stevila, se uporabniku sugerira, naj se
  enkrat vstavi stevilo prek standardnega vhoda: */
  if (cont<1)
  {
    buf=malloc(buflength);
    printf("Shift was not specified properly! Input an integer!\n");
    printf("Shift of the centerline according to the current position (now %i): ",codeshift);
    gets(buf);
    cont=sscanf(buf,"%i",&num);
  }
  /* Ce je uporabnik podal stevilo, postane codeshift to stevilo: */
  if (cont==1)
    codeshift=num;
} else /* Ce je ukaz brez argumenta, se zamik ne spremeni: */
  ;
/* Izpis nekaj vrstic kode okrog vrstice, zamaknjene za codeshift: */
fprintcodedebugshift(stdout,fint,codeshift);
if (buf!=NULL)
  free(buf);
}


static void li_viewabs(licom lcom)
    /* Izpise se odsek kode okrog vrstice, katere zaporedna stevilka je
    argument tega ukaza. Ustrezno se spremeni lokalna spremenljivka codeshift,
    tako da podana vrstica sovpada z za codeshift premaknjeno vrstico trenutne
    pozicije fint->pos. Ce je bil ukaz vstavljen brez argumentov, se codeshift
    ne spremeni.
    $A Igor apr98; */
{
int cont=0,num,buflength=100,line,column;
char *buf=NULL;
if (lcom->param!=NULL)
{
  /* Ce ima ukaz argument, se iz le-tega poskusi prebrati stevilo: */
  cont=sscanf(lcom->param,"%i",&num);
  /* Ce argument ne predstavlja celega stevila, se uporabniku sugerira, naj se
  enkrat vstavi stevilo prek standardnega vhoda: */
  if (cont<1)
  {
    buf=malloc(buflength);
    printf("Line number was not specified properly! Input an integer!\n");
    printf("Line number of the center position (shift is now %i): ",codeshift);
    gets(buf);
    cont=sscanf(buf,"%i",&num);
  }
  /* Ce je uporabnik podal stevilo, postane codeshift tak, da se bo izpisala
  koda okrog vrstice, ki jo je podal uporabnik: */
  if (cont==1)
  {
    filelinepos(fint->fp,fint->pos,&line,&column);
    codeshift=num-line;
  }
} else /* Ce je ukaz brez argumenta, se zamik ne spremeni: */
  ;
/* Izpis nekaj vrstic kode okrog vrstice, zamaknjene za codeshift: */
fprintcodedebugshift(stdout,fint,codeshift);
if (buf!=NULL)
  free(buf);
}


static void li_nview(licom lcom)
    /* Nastavljanje spremenljivk fint->linespre in fint->linespost, ki
    dolocata, koliko vrstic kode pred in po srediscni vrstici naj se izpisuje
    ob izpisu kode. Obe stevili sta lahko podani kot argumenta ukaza, pri cemer
    se pozitivno stevilo prepise v fint->linespost, negativno ali 0 pa v
    fint->linespre. Ce je ukaz vnesen brez argumentov, se od uporabnika
    zahtevata obe stevili.
    $A Igor apr98; */
{
int cont=0,num1,num2,buflength=100;
char *buf=NULL;
if (lcom->param!=NULL)
{
  /* Ce ima ukaz argument, se iz le-tega poskusi prebrati stevilo: */
  cont=sscanf(lcom->param,"%i %i",&num1,&num2);
  if (cont>0)
  {
    if (num1<=0)
      fint->linespre=-num1;
    else
      fint->linespost=num1;
    if (cont>1)
      if (num2<=0)
        fint->linespre=-num2;
      else
        fint->linespost=num2;
  } else
  {
    /* Ce argument ne predstavlja celega stevila, se uporabniku sugerira, naj se
    enkrat vstavi stevilo prek standardnega vhoda: */
    buf=malloc(buflength);
    printf("Number of codelines to print was not specified properly! Input integers!\n");
    printf("Number of lines before the centerline (now %i): ",fint->linespre);
    gets(buf);
    cont=sscanf(buf,"%i",&num1);
    if (cont>0)
      if (num1<0)
        fint->linespre=-num1;
      else
        fint->linespre=num1;
    printf("Number of lines after the centerline (now %i): ",fint->linespost);
    gets(buf);
    cont=sscanf(buf,"%i",&num1);
    if (cont>0)
      if (num1<1)
        fint->linespost=-num1;
      else
        fint->linespost=num1;
  }
} else /* Ce je ukaz brez argumenta, se od uporabnika zahtevajo vrednosti: */
{
    buf=malloc(buflength);
    printf("Number of codelines to print was not specified! Input integers!\n");
    printf("Number of lines before the centerline (now %i): ",fint->linespre);
    gets(buf);
    cont=sscanf(buf,"%i",&num1);
    if (cont>0)
      if (num1<0)
        fint->linespre=-num1;
      else
        fint->linespre=num1;
    printf("Number of lines after the centerline (now %i): ",fint->linespost);
    gets(buf);
    cont=sscanf(buf,"%i",&num1);
    if (cont>0)
      if (num1<1)
        fint->linespost=-num1;
      else
        fint->linespost=num1;
}
if (buf!=NULL)
  free(buf);
}



static void sendtocalc(char *command)
    /* Ovrednoti izraz command v sistemu fint->syst in izpise njegovo vrednost.
    $A Igor apr98; */
{
ssyst syst;
int i,num,lines=55,columns=155,elines=100,ecolumns=1000;
stack list;
object t;
char *name;
int jj,kk;
char autoevaluate;
char *helpfile=NULL,*cm=NULL;
syst=fint->syst;
if (command!=NULL)
{
if (command[0]=='\\') /* Ukaz za specificno akcijo */
{
  if (command[1]=='h' || command[1]=='?')
  {

  }
  if (command[1]=='S' || command[1]=='s') /* Izpis preb. niza */
  {
    if (command[2]=='L' || command[2]=='l') /* Zadnji */
    {
      if (syst->strings->n>0)
        printf("\"%s\"", (char *) (syst->strings->s[syst->strings->n]) );
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')  /* vsi */
    {
      if (syst->strings->n>0)
      {
        printf("  Input strings:\n");
        for (i=1; i<=syst->strings->n; ++i)
        {
          printf("%i: ",i);
          printf("\"%s\"", (char *) (syst->strings->s[i]) );
          printf("\n");
        }
        printf("\n");
      }
    } else if (command[2]=='N' || command[2]=='n')  /* dolocen */
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->strings->n >=num)
        {
          printf("%i. inp. string:\n",num);
          printf("\"%s\"", (char *) (syst->strings->s[num]) );
          printf("\n\n");
        }
    }
  } else if (command[1]=='C' || command[1]=='c') /* Izpis v linearizirani obliki */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->cuts->n>0)
        printtabobj((stack) syst->cuts->s[syst->cuts->n]);
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->cuts->n>0)
        for (i=1; i<=syst->cuts->n; ++i)
        {
          printf("%i. cut:\n",i);
          printtabobj((stack) (syst->cuts->s[i]) );
          printf("\n\n");
        }
      printf("\n");

    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->cuts->n >=num)
        {
          printf("%i. cut:\n",num);
          printtabobj((stack) (syst->cuts->s[num]) );
          printf("\n\n");
        }
    }
  } else if (command[1]=='L' || command[1]=='l') /* Izpis v linearizirani obliki */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
        printlin((object) syst->def->s[syst->def->n]);
        printf("\n\n");

    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->def->n>0)
        for (i=1; i<=syst->def->n; ++i)
        {
          printf("%i. def:\n",i);
          printlin((object) (syst->def->s[i]) );
          printf("\n\n");
        }
      printf("\n");

    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          printf("%i. def:\n",num);
          printlin((object) (syst->def->s[num]) );
          printf("\n\n");
        }
    } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
    {
      jj=3;
      while (command[jj]==' ') ++jj;
      kk=jj;
      while (command[kk]!=' ' && command[kk]!='\0') ++kk;
      if (kk>jj)
      {
        name=stringncopy(command+jj,kk-jj);
        t=findobjname(syst->def,name);
        printf("\"%s\" :\n",name);
        printlin(t);
        printf("\n\n");
        free(name);
      }
    }
  } else if (command[1]=='T' || command[1]=='t' /* Izpisi drevo v okrnjeni obliki */
    || command[1]=='F' || command[1]=='f'  /* Izpisi drevo v polni obliki */
    || command[1]=='P' || command[1]=='p')  /* Izpisi drevo v delno polni obliki */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
        if (command[1]=='t') /* okrnjena oblika */
          printtree((object) syst->def->s[syst->def->n],lines,columns);
        else if(command[1]=='T') /* okrnjena oblika, izpis v editorju */
          printtree((object) syst->def->s[syst->def->n],lines,columns);
          /*
          edprinttree((object) syst->def->s[syst->def->n],elines,ecolumns);
          */
        else if(command[1]=='f') /* polna oblika */
          printtreefull((object) syst->def->s[syst->def->n],lines,columns);
        else if(command[1]=='F') /* polna oblika, izpis v editorju */
          printtreefull((object) syst->def->s[syst->def->n],lines,columns);
          /*
          edprinttreefull((object) syst->def->s[syst->def->n],elines,ecolumns);
          */
        else if (command[1]=='p')  /* delno okrnjena oblika */
          printtreepart((object) syst->def->s[syst->def->n],lines,columns);
        else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
          printtreepart((object) syst->def->s[syst->def->n],lines,columns);
          /*
          edprinttreepart((object) syst->def->s[syst->def->n],elines,ecolumns);
          */
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      FILE *fp;
      char *temp=NULL;
      if (command[1]=='T' || command[1]=='F' || command[1]=='P')
      {
        fp=stdout; /* fopen(com.tempfile,"wb"); */
      }
      if (syst->def->n>0)
        for (i=1; i<=syst->def->n; ++i)
          if (fp!=NULL)
          {
            if (command[1]=='T' || command[1]=='F' || command[1]=='P')
              fprintf(fp,"%i. def:\n",i);
            else
              printf("%i. def:\n",i);
            if (command[1]=='t') /* okrnjena oblika */
              printtree((object) (syst->def->s[i]) ,lines,columns);
            else if (command[1]=='T') /* okrnjena oblika, izpis v editorju */
              fprinttree(fp, (object) (syst->def->s[i]) ,elines,ecolumns);
            else if(command[1]=='f') /* polna oblika */
              printtreefull((object) (syst->def->s[i]) ,lines,columns);
            else if(command[1]=='F') /* polna oblika, izpis v editorju */
              fprinttreefull(fp, (object) (syst->def->s[i]) ,elines,ecolumns);
            else if (command[1]=='p')  /* delno okrnjena oblika */
              printtreepart((object) (syst->def->s[i]) ,lines,columns);
            else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
              fprinttreepart(fp, (object) (syst->def->s[i]) ,elines,ecolumns);
            if (command[1]=='T' || command[1]=='F' || command[1]=='P')
              fprintf(fp,"\n\n");
            else
              printf("\n\n");
          }
      printf("\n");
      if (command[1]=='T' || command[1]=='F' || command[1]=='P')
      {

      }
    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          printf("%i. def:\n",num);
          if (command[1]=='t') /* okrnjena oblika */
            printtree((object) (syst->def->s[num]) ,lines,columns);
          else if (command[1]=='T') /* okrnjena oblika, izpis v editorju */
            printtree((object) (syst->def->s[num]) ,lines,columns);
            /*
            edprinttree((object) (syst->def->s[num]) ,elines,ecolumns);
            */
          else if(command[1]=='f') /* polna oblika */
            printtreefull((object) (syst->def->s[num]) ,lines,columns);
          else if(command[1]=='F') /* polna oblika, izpis v editorju */
            printtreefull((object) (syst->def->s[num]) ,lines,columns);
            /*
            edprinttreefull((object) (syst->def->s[num]) ,elines,ecolumns);
            */
          else if (command[1]=='p')  /* delno okrnjena oblika */
            printtreepart((object) (syst->def->s[num]) ,lines,columns);
          else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
            /*
            edprinttreepart((object) (syst->def->s[num]) ,elines,ecolumns);
            */
          printf("\n\n");
        }
    } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
    {
      jj=3;
      while (command[jj]==' ') ++jj;
      kk=jj;
      while (command[kk]!=' ' && command[kk]!='\0') ++kk;
      if (kk>jj)
      {
        name=stringncopy(command+jj,kk-jj);
        t=findobjname((stack) syst->def,name);
        printf("\"%s\" :\n",name);
        if (command[1]=='t') /* okrnjena oblika */
          printtree(t,lines,columns);
        else if (command[1]=='T') /* okrnjena oblika, izpis v editorju */
          printtree(t,lines,columns);
          /*
          edprinttree(t,elines,ecolumns);
          */
        else if(command[1]=='f') /* polna oblika */
          printtreefull(t,lines,columns);
        else if(command[1]=='F') /* polna oblika, izpis v editorju */
          printtreefull(t,lines,columns);
          /*
          edprinttreefull(t,elines,ecolumns);
          */
        else if (command[1]=='p')  /* delno okrnjena oblika */
          printtreepart(t,lines,columns);
        else if (command[1]=='P')  /* delno okrnjena oblika, izpis v editorju */
          printtreepart(t,lines,columns);
          /*
          edprinttreepart(t,elines,ecolumns);
          */
        printf("\n\n");
        free(name);
      }
    }
  } else if (command[1]=='E' || command[1]=='e') /* Ovrednotenje dreves */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
      {
        t=syst->def->s[syst->def->n];
        printf("Vrednost spremenljivke \"%s\" :\n",t->name);
        if (t->subkind=='V')
          printf("%.10g",doubleval(t,syst->fst,syst->user));
        else printf("ni spremenljivka.");
        printf("\n\n");
      } else printf("Na skladu ni definicij.\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->def->n>0)
      {
        for (i=1; i<=syst->def->n; ++i)
        {
          t=syst->def->s[i];
          printf("Vrednost %i. spremenljivke (\"%s\") : ",i,t->name);
          if (t->subkind=='V')
            printf("%.10g",doubleval(t,syst->fst,syst->user));
          else printf("ni spremenljivka.");
          printf("\n");
        }
      } else printf("Na skladu ni definicij.\n\n");
      printf("\n\n");
    } else if (command[2]=='N' || command[2]=='n')
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          t=syst->def->s[num];
          printf("Vrednost %i. spremenljivke (\"%s\") : ",num,t->name);
          if (t->subkind=='V')
            printf("%.10g",doubleval(t,syst->fst,syst->user));
          else printf("ni spremenljivka.");
          printf("\n");
        } else printf("Na skladu ni definicij.\n\n");
    } else if (command[2]=='V' || command[2]=='v') /* Sprem. z doloc. imenom */
    {
      jj=3;
      while (command[jj]==' ') ++jj;
      kk=jj;
      while (command[kk]!=' ' && command[kk]!='\0') ++kk;
      if (kk>jj)
      {
        name=stringncopy(command+jj,kk-jj);
        t=findobjname((stack) syst->def,name);
        printf("Vrednost spremenljivke \"%s\" :\n",name);
        if (t->subkind=='V')
          printf("%.10g",doubleval(t,syst->fst,syst->user));
        else printf("ni spremenljivka.");
        printf("\n\n");
        free(name);
      }
    }
  } else if (command[1]=='V' || command[1]=='v') /* Imena spremenljivk in
  definiranih funkcij */
  {
    if (command[2]=='L' || command[2]=='l')
    {
      if (syst->def->n>0)
        printf("Name of the last object in main list: \"%s\"\n",
         ((object) syst->def->s[syst->def->n])->name );
        printf("\n\n");
    } else if (command[2]=='A' || command[2]=='a')
    {
      if (syst->def->n>0)
        for (i=1; i<=syst->def->n; ++i)
        {
          /* printf("%i. def:\n",i); */
          printf("Name of %i. object in main list: \"%s\"\n", i,
           ((object) syst->def->s[i])->name );
          /* printf("\n\n"); */
        }
      printf("\n");
    } else if (command[2]=='N' || command[2]=='n')  /* Sprem. z doloc. zap. st. */
    {
      i=sscanf(command+3,"%i",&num);
      if (i==1)
        if (syst->def->n >=num)
        {
          printf("%i. def:\n",num);
          printf("Name of %i. object in main list: \"%s\"\n",num,
           ((object) syst->def->s[num])->name );

          printf("\n\n");
        }
    }
  } else if (command[1]=='R' || command[1]=='r') /* Pogon sistem. ukaza */
  {
    system(command+3);
  } else if (command[1]=='X' || command[1]=='x') /* Ponovitev ukaza z dano zap. st. */
  {
    i=sscanf(command+3,"%i",&num);
    if (i==1)
      if (syst->strings->n >= num)
        sendtocalc(stringcopy(syst->strings->s[num]));
  } else if (command[1]=='*' || command[1]=='*') /* Komentar */
  {

    printf("%s\n",command+2);
  }
} else if (command!=NULL) if (command[0]!='\0')
{
  char *point=NULL;
  double x=0;
  int start,end;
  point=strchr(command,':');
  if (point!=NULL)
  {
    ++point;
    /* Ce v izrazu nastopa "::", gre za prireditev vrednosti izraza na desni
    strani dvojnega dvopicja spremenljivki z imenom na levi strani dvojnega
    dvopicja: */
    if (point[0]==':')
      ++point;
    else
      point=command;
  } else
    point=command;
  list=cutexpression(point,syst->syst);
  arrangelistobj(list);
  t=NULL;
  t=maketree(list);
  if (t->name[0]==':' && t->name[1]=='\0' && t->kind=='2')
    autoevaluate=0;
  else
    autoevaluate=1;
  /*
  printtree(t,lines,columns);
  */
  /*
  pushstack(syst->strings,stringcopy(command));
  pushstack(syst->cuts,list);
  pushstack((stack) syst->trees,t);
  */
  puttreetolist(t,& (syst->def), & (syst->trash), syst->user);
  displistobj(&list);
  if (autoevaluate)
    printf(" = %.10g\n",doubleval(t,syst->fst,syst->user));
  if (point!=command)
  {
    /* Prireditev vrednosti izraza, ki je na desni strani dvojnega dvopicja v
    command, spremenljivki z imanom, ki je na levi strani dvojnega dvopicja: */
    start=0;
    while (command[start]==' ')
      ++start;
    end=start;
    while (command[end]!=' ' && command[end]!=':')
      ++end;
    point=stringncopy(command+start,end-start);
    x=doubleval(t,syst->fst,syst->user);
    assigndouble(syst,point,x);
    free(point); point=NULL;
  }
  /*
  printtreefull(t,lines,columns);
  */
}
}
}



static void li_calc(licom lcom)
    /* Ce je bil ukaz vstavljen z argumentom, se poklice funkcija sendtocalc
    s tem argumentom. Ta funkcija izracuna in izpise vrednost izraza (ki je
    argument ukaza). Ce je ukaz vstavljen brez argumentov, se pozene
    kalkulator, v katerem lahko izracnavamo razlicne izraze in definiramo nove
    spremenljivke ali funkcije v sistemu fint->simb.
    $A Igor apr98; */
{
int buflength=1000; /* Maksimalna dolzina vrstice */
char end=0,*buf=NULL,*command;
/* Ce ima ukaz argumente, se izvrsi le vrstica od zacetka 1. argumenta naprej: */
if (lcom->param!=NULL)
{
  printf("          ");
  sendtocalc(lcom->param);
}
else
{
  printf("Type in commands or expressions; \"\\x\" or \"\\q\" for quit, \"\\?\" or \"\\h\" for help.\n\n");
  /* statusline(); */
  buf=malloc(buflength);
  while (!end)
  {
    printf("Calc >");
    buf[0]='\0';
    gets(buf);
    command=memnotnchr(buf,strlen(buf)," ",1);
    /*
    if (command!=NULL)
    {
      pos=(void *) memnchr(command,strlen(command)," ",1);
      if (pos!=NULL)
        cm=stringncopy(command,pos-command);
      else
        cm=stringcopy(command);
    }
    */
    if (command[0]=='\\' && (command[1]=='q' || command[1]=='x'))
      end=1;
    else
    {
      printf("          ");
      sendtocalc(command);
    }
  }
  if (buf!=NULL)
    free(buf);
  printf("\n");
}
}

static void printwatchexpr(void)
{
int i;
if (fint->watchst==NULL)
  printf("\nNo watch table.\n\n");
else if (fint->watchst->n==0)
  printf("\nNo expressions in watch table.\n\n");
else
{
  printf("\n Watch table:\n\n");
  for (i=1;i<=fint->watchst->n;++i)
    printf("%2i: %s\n",i,fint->watchst->s[i]);
  printf("\n");
}
}

static void printwatchval(void)
{
int i;
char *expr;
if (fint->watchst==NULL)
  printf("\nNo watch table.\n\n");
else if (fint->watchst->n<=0)
  printf("\nNo expressions in watch table.\n\n");
else
{
  printf("Watch:\n");
  for (i=1;i<=fint->watchst->n;++i)
  {
    expr=fint->watchst->s[i];
    printf("%3i: %s",i,expr);
    sendtocalc(expr);
  }
}
}

static void li_watch(licom lcom)
    /* Ce je bil ukaz vnesen brez argumentov, se izpisejo vrednosti izrazov na
    skladu fint->watchst v sistemu fint->syst. Drugace se k izrazom na tem
    skladu doda izraz, ki je argument ukaza.
    $A Igor apr98; */
{
/* Ce fint->watchst se ne obstaja, se mora tvoriti na novo: */
if (fint->watchst==NULL)
  fint->watchst=newstack(5);
if (lcom->param!=NULL)
{
  /* Ce je bil ukaz klican s parametrom, se kopija tega parametra da na sklad
  fint->watchst. */
  if (cmpstrings(lcom->param,"")!=0)
    pushstack(fint->watchst,stringcopy(lcom->param));
} else
{
  /* Izpis vseh izrazov na skladu fint->watch in njihovih vrednosti v sistemu
  fint->syst: */
  printwatchval();
}
}

static void li_deletewatch(licom lcom)
    /* S sklada fint->watchst odstrani izraz, katerega zaporedna stevilka je
    argument ukaza v vrsticnem interpreterju, ki mu ustreza ta funkcije. Ce je
    1. znak argumenta '*', odstrani vse izraze s tega sklada. Ce je bil ukaz
    vnesen brez argumentov, se izpisejo izrazi na skladu in se od uporabnika
    zahteva, naj doloci izraz, ki naj se odstrani.
    $A Igor apr98; */
{
int cont=0,num,buflength=100;
char *buf=NULL,*expr;
/* Ce fint->watchst se ne obstaja, se mora tvoriti na novo: */
if (fint->watchst==NULL)
  fint->watchst=newstack(5);
if (lcom->param!=NULL)
{
  if (lcom->param[0]=='*')
  {
    /* Ce je 1. znak parametra enak '*', se zbrise vse nize na fint->watchst: */
    while(fint->watchst->n>0)
    {
      expr=popstack(fint->watchst);
      if (expr!=NULL)
        free(expr);
    }
  } else
  {
    /* Ce parameter ukaza predstavlja stevilo, se zbrise ustrezni izraz na
    fint->watchst: */
    cont=sscanf(lcom->param,"%i",&num);
    /* Ce argument ne predstavlja celega stevila, se uporabniku sugerira, naj se
    enkrat vstavi stevilo prek standardnega vhoda: */
    if (cont<1)
    {
      buf=malloc(buflength);
      printwatchexpr();
      printf("Number was not specified properly! Input an integer or '*' for all!\n");
      printf("Number of expression to delete: ");
      gets(buf);
      if (buf[0]=='*')
      {
        /* Ce je 1. znak parametra enak '*', se zbrise vse nize na fint->watchst: */
        while(fint->watchst->n>0)
        {
          expr=popstack(fint->watchst);
          if (expr!=NULL)
            free(expr);
        }
      } else
        cont=sscanf(buf,"%i",&num);
    }
    /* Ce je uporabnik podal stevilo, se odstrani ustrezni izraz: */
    if (cont==1)
    {
      if (num>0 && num<=fint->watchst->n)
      {
        expr=delstack(fint->watchst,num);
        if (expr!=NULL)
          free(expr);
      } else
        printf("\nNumber %i is not in the range of watch table.\n\n");
    }
  }
} else
{
  buf=malloc(buflength);
  printwatchexpr();
  printf("Number was not specified properly! Input an integer or '*' for all!\n");
  printf("Number of expression to delete: ");
  gets(buf);
  if (buf[0]=='*')
  {
    /* Ce je 1. znak parametra enak '*', se zbrise vse nize na fint->watchst: */
    while(fint->watchst->n>0)
    {
      expr=popstack(fint->watchst);
      if (expr!=NULL)
        free(expr);
    }
  } else
  {
    cont=sscanf(buf,"%i",&num);
      /* Ce je uporabnik podal stevilo, se odstrani ustrezni izraz: */
    if (cont==1)
    {
      if (num>0 && num<=fint->watchst->n)
      {
        expr=delstack(fint->watchst,num);
        if (expr!=NULL)
          free(expr);
      } else
        printf("\nNumber %i is not in the range of watch table.\n\n");
    }
  }

}
if (buf!=NULL)
  free(buf);
}


static void li_autowatch(licom lcom)
    /* Ce je ukaz vstavljen s stevilcnim argumentom, postavi fint->watch na
    vrednost tega argumenta, drugace zahteva ud uporabnika, naj vstavi stevilo
    in postavi fint->watch na vstavljeno stevilcno vrednost. Ce je fint->watch
    razlicen od 0, se izpisejo vrednosti izrazov na skladu fint->watch vsakic,
    ko se vstopi v vrsticni interpreter (ko se kontrola preda uporabniku).
    $A Igor apr98; */
{
int cont=0,num,buflength=100;
char *buf=NULL;
if (lcom->param!=NULL)
{
  /* Ce ima ukaz argument, se iz le-tega poskusi prebrati stevilo: */
  cont=sscanf(lcom->param,"%i",&num);
  /* Ce argument ne predstavlja celega stevila, se uporabniku sugerira, naj se
  enkrat vstavi stevilo prek standardnega vhoda: */
  if (cont<1)
  {
    buf=malloc(buflength);
    printf("Switch was not specified properly! Input 0 or 1!\n");
    printf("Automatically report values of watched expressions (0/1, now %i): ",fint->watch);
    gets(buf);
    cont=sscanf(buf,"%i",&num);
  }
  /* Ce je uporabnik podal stevilo, postane codeshift to stevilo: */
  if (cont==1)
   fint->watch=num;
} else /* Ce je ukaz brez argumenta, se zamik ne spremeni: */
{
  buf=malloc(buflength);
  printf("Switch was not specified properly! Input 0 or 1!\n");
  printf("Automatically report values of watched expressions (0/1, now %i): ",fint->watch);
  gets(buf);
  cont=sscanf(buf,"%i",&num);
  if (cont==1)
   fint->watch=num;
}
if (buf!=NULL)
  free(buf);
}


static void li_printwatches(licom lcom)
    /* Izpisejo se vsi izrazi na skladu fint->watchst.
    $A Igor apr98; */
{
printwatchexpr();
}


void fintfileblock(ficom com,char *name,long from, long to);




static void li_run(licom lcom)
  /* Izvedejo se ukazi, ki jih je vstavil uporabnik, v datotecnem
  interpreterju. Ce je bil k tej funkciji pripadajoci ukaz vstavljen s
  parametri, se izvedejo ti, drugace se od uporabnika zahteva, da po vrsti
  vstavlja ukaze, ki se naj izvedejo.
  $A Igor apr98; */
{
int buflength=200,oldnumexec;
long from,to;
char *buf=NULL,olddebug,oldstop,oldstepover,oldstoplevel;
FILE *fp;
if (fint->dfname==NULL)
  fint->dfname=stringcopy("0debug.cm");
fp=fopen(fint->dfname,"ab+");
if (fp!=NULL)
{
  /* Zapis ukazov v datoteko: */
  from=flength(fp); /* oznacimo zacetek aktualnega zapisa */
  fprintf(fp,"\n\n");
  /* Ce je bil ukaz vnesen s parametrom, se v datoteko zapise le-ta: */
  if (lcom->param!=NULL)
    fprintf(fp,"%s\n",lcom->param);
  else
  {
    buf=malloc(buflength);
    /* Ce je bil ukaz vnesen brez parametrov, se ukazi za interpretacijo berejo
    s standardnega vhoda in sproti zapisejo v datoteko: */
    printf("\nInput commands! When finished, input an empty line (press <Return>)!\n");
    do
    {
      gets(buf);
      fprintf(fp,"%s\n",buf);
    } while (buf[0]!='\0');
  }
  fprintf(fp,"\n");
  to=flength(fp); /* oznacimo konec aktualnega zapisa */
  fclose(fp);
  /* Interpretacija ukazov, ki jih je vstavil uporabnik: */
  /* Najprej se shranejo nekateri parametri interpretacije, pomembni za
  razhroscevanje, ker se le-ti tik pred interpretacijo spremenijo: */
  olddebug=fint->debug; fint->debug=0;
  oldstop=fint->stop; fint->stop=0;
  oldstepover=fint->stepover; fint->stepover=0;
  oldnumexec=fint->numexec; fint->numexec=0;
  oldstoplevel=fint->stoplevel; fint->stoplevel=-1;
  fintfileblock(fint,fint->dfname,from,to); /* interpretacija */
  /* Rastavracija parametrov: */
  fint->debug=olddebug;
  fint->stop=oldstop;
  fint->stepover=oldstepover;
  fint->numexec=oldnumexec;
  fint->stoplevel=oldstoplevel;
} else
{
  printf("\nError: Can't open file \"%s\".\n\nPress <Return> to continue!\n",
         fint->dfname);
  *buf=getchar();
}
if (buf!=NULL)
  free(buf);
}


static void li_rundebug(licom lcom)
  /* Izvedejo se ukazi, ki jih je vstavil uporabnik, v datotecnem
  interpreterju. Ce je bil k tej funkciji pripadajoci ukaz vstavljen s
  parametri, se izvedejo ti, drugace se od uporabnika zahteva, da po vrsti
  vstavlja ukaze, ki se naj izvedejo. Razlika med to funkcijo in li_run je v
  tem, da se izvedba ukazov v tej funkciji tudi razgroscuje.
  $A Igor apr98; */
{
int buflength=200;
long from,to;
char *buf=NULL;
FILE *fp;
if (fint->dfname==NULL)
  fint->dfname=stringcopy("0debug.cm");
fp=fopen(fint->dfname,"ab+");
if (fp!=NULL)
{
  /* Zapis ukazov v datoteko: */
  from=flength(fp); /* oznacimo zacetek aktualnega zapisa */
  fprintf(fp,"\n\n");
  /* Ce je bil ukaz vnesen s parametrom, se v datoteko zapise le-ta: */
  if (lcom->param!=NULL)
    fprintf(fp,"%s\n",lcom->param);
  else
  {
    buf=malloc(buflength);
    /* Ce je bil ukaz vnesen brez parametrov, se ukazi za interpretacijo berejo
    s standardnega vhoda in sproti zapisejo v datoteko: */
    printf("\nInput commands! When finished, input an empty line (press <Return>)!\n");
    do
    {
      gets(buf);
      fprintf(fp,"%s\n",buf);
    } while (buf[0]!='\0');
  }
  fprintf(fp,"\n");
  to=flength(fp); /* oznacimo konec aktualnega zapisa */
  fclose(fp);
  /* Interpretacija ukazov, ki jih je vstavil uporabnik: */
  fintfileblock(fint,fint->dfname,from,to);
} else
{
  printf("\nError: Can't open file \"%s\".\n\nPress <Return> to continue!\n",
         fint->dfname);
  *buf=getchar();
}
if (buf!=NULL)
  free(buf);
}


static void li_runfilename(licom lcom)
  /* Ime datoteke, kamor se zapisujejo uporabnikovi ukazi za interpretacijo v
  datotecnem interpreterju (fint->dfname), se postavi na argument tega ukaza.
  Ce je bil ukaz vstavljen brez argumentov, se od uporabnika zahteva, naj
  vstavi ime datoteke.
  $A Igor apr98; */
{
int buflength=100;
char *buf=NULL,*name=NULL;
if (lcom->param!=NULL)
  name=stringcopy(lcom->param);
else
{
  buf=malloc(buflength);
  printf("\nFile into which commands for interpretation will be written was not specified.\n");
  printf("File name (now \"%s\"): ",
         fint->dfname);
  gets(buf);
  if (buf[0]!='\0')
    name=stringcopy(buf);
}
if (name!=NULL)
{
  if (fint->dfname!=NULL)
    free(fint->dfname);
  fint->dfname=name;
  name=NULL;
}
if (buf!=NULL)
  free(buf);
}


static char activebreak(ficom com,int id)
    /* Vrne 1, ce so break-i z identifikacijsko stevilko id v datotecnem
    interpreterju com aktivni, in 0, ce niso. break je aktiven, ce je
    com->sball enak 0 in njegove identifikacijske stevilke ni na skladu
    com->sb, ali ce je com->sball razlicen od 0 in je njegova identifikacijska
    stevilka na skladu com->ab.
    $A Igor apr98; */
{
char active=0;
if (com->sball)
{
  if (findsortstack(com->ab,&id,0,0,cmpip))
    active=1;
  /*
  active=0;
  if (com->ab!=NULL)
    if (com->ab->n>0)
      for (i=1;i<=com->ab->n;++i)
      {
        ip=com->ab->s[i];
        if (ip!=NULL)
          if (*ip==id)
            active=1;
      }
  */
} else
{
  if (!findsortstack(com->sb,&id,0,0,cmpip))
    active=1;
  /*
  active=1;
  if (com->sb!=NULL)
    if (com->sb->n>0)
      for (i=1;i<=com->sb->n;++i)
      {
        ip=com->sb->s[i];
        if (ip!=NULL)
          if (*ip==id)
            active=0;
      }
  */
}
return active;
}



static void li_printbreakstatus(licom lcom)
    /* Na standardni izhod izpise, kateri break-i so v interpreterju fint
    aktivni oziroma pasivni.
    $A Igor apr98; */
{
int i,*ip;

if (fint->sb!=NULL)
  printf("sb->n = %i.\n",fint->sb->n);
if (fint->ab!=NULL)
  printf("ab->n = %i.\n",fint->ab->n);
printf("\n  Break status:\n");
if (fint->sball)
{
  if (fint->ab==NULL)
    printf("All brakes are suspended.\n");
  else if (fint->ab->n<=0)
    printf("All brakes are suspended.\n");
  else
  {
    printf("Only brakes with following identity numbers are active:\n ");
    for (i=1;i<=fint->ab->n;++i)
    {
      ip=fint->ab->s[i];
      if (ip!=NULL)
      {
        printf(" %i",*ip);
        if (i==fint->ab->n)
          printf(".\n");
        else
          printf(",");
      }
    }
  }
} else
{
  if (fint->sb==NULL)
    printf("All brakes are active.\n");
  else if (fint->sb->n<=0)
    printf("All brakes are active.\n");
  else
  {
    printf("Only brakes with following identity numbers are suspended:\n ");
    for (i=1;i<=fint->sb->n;++i)
    {
      ip=fint->sb->s[i];
      if (ip!=NULL)
      {
        printf(" %i",*ip);
        if (i==fint->sb->n)
          printf(".\n");
        else
          printf(",");
      }
    }
  }
}
printf("\n");
}


static void li_tellbreak(licom lcom)
    /* Izpise, ali so break-i, katerih identifikacijska stevilka je argument
    pripadajocega ukaza, aktivni. Ce je argument ukaza "*" ali ce je ukaz
    vstavljen brez argumentov, pove to za vse break-e.
    $A Igor apr98; */
{
int cont=0,num,buflength=100;
char *buf=NULL;
if (lcom->param!=NULL)
{
  /* Iz argumentov ukaza razberemo, za kateri break naj se izpise podatek: */
  if (lcom->param[0]=='*')
  {
    /* Ce je parameter '*', se izpisejo podatki za  vse break-e: */
    li_printbreakstatus(lcom);
  } else
  {
    cont=sscanf(lcom->param,"%i",&num);
    /* Ce argument ne predstavlja celega stevila, se uporabniku sugerira, naj se
    enkrat vstavi stevilo prek standardnega vhoda: */
    if (cont<1)
    {
      buf=malloc(buflength);
      li_printbreakstatus(lcom);
      printf("Number was not specified properly! Input an integer!\n");
      printf("Report status of break: ");
      gets(buf);
      cont=sscanf(buf,"%i",&num);
    }
    if (cont==1)
    {
      if (activebreak(fint,num))
        printf("Breaks with identification number %i are active.\n\n",num);
      else
        printf("Breaks with identification number %i are pasive.\n\n",num);
    }
  }
} else
{
  /* Ce je ukaz brez argumenta, se od uporabnika zahteva odgovor: */
  buf=malloc(buflength);
  printf("Break was not specified! Input an integer!\n");
  printf("Report status of break ('*' for all): ");
  gets(buf);
  cont=sscanf(buf,"%i",&num);
  if (buf[0]=='*')
  {
    li_printbreakstatus(lcom);
  } else
  {
    cont=sscanf(lcom->param,"%i",&num);
    if (cont==1)
    {
      if (activebreak(fint,num))
        printf("Breaks with identification number %i are active.\n\n",num);
      else
        printf("Breaks with identification number %i are pasive.\n\n",num);
    }
  }
}
if (buf!=NULL)
  free(buf);
}



static void li_suspendbreak(licom lcom)
    /* Suspendira break, katerega identifikacijska stevilka je podana z
    argumentom pripadajocega ukaza. Ce je argument "*", suspendira vse break-e.
    Ce je bil ukaz vstavljen brez argumentov ali napacno, se od uporabnika
    zahteva, naj vstavi break, ki naj se suspendira.
    $A Igor apr98; */
{
int cont=0,num,buflength=100,i,*ip;
char *buf=NULL,*ptr=NULL;
if (lcom->param!=NULL)
{
  ptr=lcom->param;
  /* Iz argumentov ukaza razberemo, katere breake naj se suspendira: */
  cont=0;
  if (lcom->param[0]=='*')
  {
    /* Ce je parameter '*', se suspendirajo vsi break-i: */
    fint->sball=1;
    dispstackval(fint->sb);   popstackall(fint->sb);
    dispstackval(fint->ab);   popstackall(fint->ab);
  } else
  {
    cont=sscanf(lcom->param,"%i",&num);
    /* Ce argument ne predstavlja celega stevila, se uporabniku sugerira, naj se
    enkrat vstavi stevilo prek standardnega vhoda: */
    if (cont<1)
    {
      buf=malloc(buflength);
      ptr=buf;
      li_printbreakstatus(lcom);
      printf("Number was not specified properly! Input an integer!\n");
      printf("Suspend break: ");
      gets(buf);
      cont=sscanf(buf,"%i",&num);
    }
    /* Ce je uporabnik podal stevilo: */
    if (cont==1)
    {
      if (fint->sball)
      {
        /* Break je treba brisati s sklada aktiviranih break-ov: */
        if (fint->ab!=NULL)
          if (fint->ab->n>0)
            for (i=fint->ab->n;i>=1;--i) /* navzdol, da lahko uporabimo delstak() */
            {
              /* Navzdol stejemo, da lahko uporabimo delstak() */
              ip=fint->ab->s[i];
              if (ip!=NULL)
                if (*ip==num)
                {
                  free(ip);
                  delstack(fint->ab,i);
                }
            }
      } else
      {
        /* Break je treba dodati na sklad suspendiranih break-ov: */
        if (fint->sb==NULL)
          fint->sb=newstack(5);
        if (!findsortstack(fint->sb,&num,0,0,cmpip))
        {
          ip=malloc(sizeof(*ip));
          *ip=num;
          inssortstack(fint->sb,ip,cmpip);
        } else printf("Breaks with identification %i already suspended.\n",num);
      }
      /* Ce je bilo z argumenti podanih se vec stevil, se tudi ta obdelajo: */
      do
      {
        cont=0;
        ptr=memnotnchr(ptr,strlen(ptr)+1," \n\r\t",4);
        if (*ptr!='\0')
        {
          ptr=memnchr(ptr,strlen(ptr)+1," \n\r\t\0",5);
          if (*ptr!='\0')
          {
            cont=sscanf(ptr,"%i",&num);
            /* Prebrali smo nstevilko naslednje prekinitve, izvedejo se
            ustrezne peracije: */
            if (cont==1)
            {
              if (fint->sball)
              {
                /* Break je treba brisati s sklada aktiviranih break-ov: */
                if (fint->ab!=NULL)
                  if (fint->ab->n>0)
                    for (i=fint->ab->n;i>=1;--i) /*navzdol, da lahko uporabimo delstak() */
                    {
                      /* Navzdol stejemo, da lahko uporabimo delstak() */
                      ip=fint->ab->s[i];
                      if (ip!=NULL)
                        if (*ip==num)
                        {
                          free(ip);
                          delstack(fint->ab,i);
                        }
                    }
              } else
              {
                /* Break je treba dodati na sklad suspendiranih break-ov: */
                if (!findsortstack(fint->sb,&num,0,0,cmpip))
                {
                  ip=malloc(sizeof(*ip));
                  *ip=num;
                  inssortstack(fint->sb,ip,cmpip);
                } else printf("Breaks with identification %i already suspended.\n",num);
              }
            }
          }
        }
      } while (cont!=0);
    }
  }
} else
{
  /* Ce je ukaz brez argumenta, se od uporabnika zahteva odgovor: */
  buf=malloc(buflength);
  ptr=buf;
  li_printbreakstatus(lcom);
  printf("Break to suspend was not specified! Input an integer!\n");
  printf("Suspend break(s) ('*' for all): ");
  gets(buf);
  cont=sscanf(buf,"%i",&num);
  cont=0;
  if (buf[0]=='*')
  {
    /* Ce uporabnik vstavi '*', se suspendirajo vsi break-i: */
    fint->sball=1;
    dispstackval(fint->sb);   popstackall(fint->sb);
    dispstackval(fint->ab);   popstackall(fint->ab);
  } else
  {
    cont=sscanf(buf,"%i",&num);
    if (cont==1)
    {
      if (fint->sball)
      {
        /* Break je treba brisati s sklada aktiviranih break-ov: */
        if (fint->ab!=NULL)
          if (fint->ab->n>0)
            for (i=fint->ab->n;i>=1;--i) /*navzdol, da lahko uporabimo delstak() */
            {
              /* Navzdol stejemo, da lahko uporabimo delstak() */
              ip=fint->ab->s[i];
              if (ip!=NULL)
                if (*ip==num)
                {
                  free(ip);
                  delstack(fint->ab,i);
                }
            }
      } else
      {
        /* Break je treba dodati na sklad suspendiranih break-ov: */
        if (fint->sb==NULL)
          fint->sb=newstack(5);
        if (!findsortstack(fint->sb,&num,0,0,cmpip))
        {
          ip=malloc(sizeof(*ip));
          *ip=num;
          inssortstack(fint->sb,ip,cmpip);
        } else printf("Breaks with identification %i already suspended.\n",num);
      }
      /* Ce je bilo z argumenti podanih se vec stevil, se tudi ta obdelajo: */
      do
      {
        cont=0;
        ptr=memnotnchr(ptr,strlen(ptr)+1," \n\r\t",4);
        if (*ptr!='\0')
        {
          ptr=memnchr(ptr,strlen(ptr)+1," \n\r\t\0",5);
          if (*ptr!='\0')
          {
            cont=sscanf(ptr,"%i",&num);
            /* Prebrali smo nstevilko naslednje prekinitve, izvedejo se
            ustrezne peracije: */
            if (cont==1)
            {
              if (fint->sball)
              {
                /* Break je treba brisati s sklada aktiviranih break-ov: */
                if (fint->ab!=NULL)
                  if (fint->ab->n>0)
                    for (i=fint->ab->n;i>=1;--i) /*navzdol, da lahko uporabimo delstak() */
                    {
                      /* Navzdol stejemo, da lahko uporabimo delstak() */
                      ip=fint->ab->s[i];
                      if (ip!=NULL)
                        if (*ip==num)
                        {
                          free(ip);
                          delstack(fint->ab,i);
                        }
                    }
              } else
              {
                /* Break je treba dodati na sklad suspendiranih break-ov: */
                if (!findsortstack(fint->sb,&num,0,0,cmpip))
                {
                  ip=malloc(sizeof(*ip));
                  *ip=num;
                  inssortstack(fint->sb,ip,cmpip);
                } else printf("Breaks with identification %i already suspended.\n",num);
              }
            }
          }
        }
      } while (cont!=0);
    }
  }
}
if (buf!=NULL)
  free(buf);

}


static void li_activatebreak(licom lcom)
    /* Aktivira break, katerega identifikacijska stevilka je podana z
    argumentom pripadajocega ukaza. Ce je argument "*", suspendira vse break-e.
    Ce je bil ukaz vstavljen brez argumentov ali napacno, se od uporabnika
    zahteva, naj vstavi break, ki naj se suspendira.
    $A Igor apr98; */
{
int cont=0,num,buflength=100,i,*ip;
char *buf=NULL,*ptr;
if (lcom->param!=NULL)
{
  ptr=lcom->param;
  /* Iz argumentov ukaza razberemo, katere breake naj se aktivira: */
  cont=0;
  if (lcom->param[0]=='*')
  {
    /* Ce je parameter '*', se aktivirajo vsi break-i: */
    fint->sball=0;
    dispstackval(fint->sb);   popstackall(fint->sb);
    dispstackval(fint->ab);   popstackall(fint->ab);
  } else
  {
    cont=sscanf(lcom->param,"%i",&num);
    /* Ce argument ne predstavlja celega stevila, se uporabniku sugerira, naj
    se enkrat vstavi stevilo prek standardnega vhoda: */
    if (cont<1)
    {
      buf=malloc(buflength);
      ptr=buf;
      li_printbreakstatus(lcom);
      printf("Number was not specified properly! Input an integer!\n");
      printf("Activate break: ");
      gets(buf);
      cont=sscanf(buf,"%i",&num);
    }
    if (cont==1)
    {
      if (!fint->sball)
      {
        /* Break je treba brisati s sklada suspendiranih break-ov: */
        if (fint->sb!=NULL)
          if (fint->sb->n>0)
            for (i=fint->sb->n;i>=1;--i) /*navzdol, da lahko uporabimo delstak() */
            {
              /* Navzdol stejemo, da lahko uporabimo delstak() */
              ip=fint->sb->s[i];
              if (ip!=NULL)
                if (*ip==num)
                {
                  free(ip);
                  delstack(fint->sb,i);
                }
            }
      } else /* fint->sball!=0 */
      {
        /* Break je treba dodati na sklad aktiviranih break-ov: */
        if (fint->ab==NULL)
          fint->ab=newstack(5);
        if (!findsortstack(fint->ab,&num,0,0,cmpip))
        {
          ip=malloc(sizeof(*ip));
          *ip=num;
          inssortstack(fint->ab,ip,cmpip);
        } else printf("Breaks with identification %i already active.\n",num);
      }
      /* Ce je bilo z argumenti podanih se vec stevil, se tudi ta obdelajo: */
      do
      {
        cont=0;
        ptr=memnotnchr(ptr,strlen(ptr)+1," \n\r\t",4);
        if (*ptr!='\0')
        {
          ptr=memnchr(ptr,strlen(ptr)+1," \n\r\t\0",5);
          if (*ptr!='\0')
          {
            cont=sscanf(ptr,"%i",&num);
            /* Prebrali smo nstevilko naslednje prekinitve, izvedejo se
            ustrezne peracije: */
            if (cont==1)
            {
              if (!fint->sball)
              {
                /* Break je treba brisati s sklada suspendiranih break-ov: */
                if (fint->sb!=NULL)
                  if (fint->sb->n>0)
                    for (i=fint->sb->n;i>=1;--i) /*navzdol, da lahko uporabimo delstak() */
                    {
                      /* Navzdol stejemo, da lahko uporabimo delstak() */
                      ip=fint->sb->s[i];
                      if (ip!=NULL)
                        if (*ip==num)
                        {
                          free(ip);
                          delstack(fint->sb,i);
                        }
                    }
              } else /* fint->sball!=0 */
              {
                /* Break je treba dodati na sklad aktiviranih break-ov: */
                if (!findsortstack(fint->ab,&num,0,0,cmpip))
                {
                  ip=malloc(sizeof(*ip));
                  *ip=num;
                  inssortstack(fint->ab,ip,cmpip);
                } else printf("Breaks with identification %i already active.\n",num);
              }
            }
          }
        }
      } while (cont!=0);
    }
  }
} else
{
  /* Ce je ukaz brez argumenta, se od uporabnika zahteva odgovor: */
  buf=malloc(buflength);
  ptr=buf;
  li_printbreakstatus(lcom);
  printf("Break to activate was not specified! Input an integer!\n");
  printf("Activate break(s) ('*' for all): ");
  gets(buf);
  cont=sscanf(buf,"%i",&num);
  cont=0;
  if (buf[0]=='*')
  {
    /* Ce uporabnik vstavi '*', se aktivirajo vsi break-i: */
    fint->sball=0;
    dispstackval(fint->sb);   popstackall(fint->sb);
    dispstackval(fint->ab);   popstackall(fint->ab);
  } else
  {
    cont=sscanf(buf,"%i",&num);
    if (cont==1)
    {
      if (!fint->sball)
      {
        /* Break je treba brisati s sklada suspendiranih break-ov: */
        if (fint->sb!=NULL)
          if (fint->sb->n>0)
            for (i=fint->sb->n;i>=1;--i) /*navzdol, da lahko uporabimo delstak() */
            {
              /* Navzdol stejemo, da lahko uporabimo delstak() */
              ip=fint->sb->s[i];
              if (ip!=NULL)
                if (*ip==num)
                {
                  free(ip);
                  delstack(fint->sb,i);
                }
            }
      } else  /* fint->sball!=0 */
      {
        /* Break je treba dodati na sklad aktiviranih break-ov: */
        if (fint->ab==NULL)
          fint->ab=newstack(5);
        if (!findsortstack(fint->ab,&num,0,0,cmpip))
        {
          ip=malloc(sizeof(*ip));
          *ip=num;
          inssortstack(fint->ab,ip,cmpip);
        } else printf("Breaks with identification %i already active.\n",num);
      }
      /* Ce je bilo z argumenti podanih se vec stevil, se tudi ta obdelajo: */
      do
      {
        cont=0;
        ptr=memnotnchr(ptr,strlen(ptr)+1," \n\r\t",4);
        if (*ptr!='\0')
        {
          ptr=memnchr(ptr,strlen(ptr)+1," \n\r\t\0",5);
          if (*ptr!='\0')
          {
            cont=sscanf(ptr,"%i",&num);
            /* Prebrali smo nstevilko naslednje prekinitve, izvedejo se
            ustrezne peracije: */
            if (cont==1)
            {
              if (!fint->sball)
              {
                /* Break je treba brisati s sklada suspendiranih break-ov: */
                if (fint->sb!=NULL)
                  if (fint->sb->n>0)
                    for (i=fint->sb->n;i>=1;--i) /*navzdol, da lahko uporabimo delstak() */
                    {
                      /* Navzdol stejemo, da lahko uporabimo delstak() */
                      ip=fint->sb->s[i];
                      if (ip!=NULL)
                        if (*ip==num)
                        {
                          free(ip);
                          delstack(fint->sb,i);
                        }
                    }
              } else /* fint->sball!=0 */
              {
                /* Break je treba dodati na sklad aktiviranih break-ov: */
                if (!findsortstack(fint->ab,&num,0,0,cmpip))
                {
                  ip=malloc(sizeof(*ip));
                  *ip=num;
                  inssortstack(fint->ab,ip,cmpip);
                } else printf("Breaks with identification %i already active.\n",num);
              }
            }
          }
        }
      } while (cont!=0);
    }
  }
}
if (buf!=NULL)
  free(buf);

}



static void li_help(licom lcom)
    /* Funkcija, ki izpise pomoc za vrsticni interpreter debuggerja.
    $A Igor apr98; */
{
printf("\n  Help for defugger - list of commands:\n\n");
printf("?,  h         - Shows this help.\n");
printf("!, system     - Execution of system commands.\n");
printf("q, quit       - Exits debugging session.\n");
printf("x, exit       - Interprets until x levels higher, x argument (default 1).\n");
printf("s, step       - Executes the next file interpreter command.\n");
printf("S, stepover   - Executes the next file interpreter command, including its\n");
printf("                sub-blocks.\n");
printf("c, continue   - Continues execution till the next bp command.\n");
printf("N, nstepover  - Steps over the next x commands, x command argument.\n");
printf("n, nstep      - Executes the next x commands, x command argument.\n");
printf("v, view       - Prints a segment of code shifted for next x lines, where x is an\n");
printf("                argument of this command. If command is input without arguments,\n");
printf("                shift becomes zero and a segment of code around the current\n");
printf("Press <Return> to continue!"); getchar();

printf("                position is printed.\n");
printf("vr, viewrel   - Prints a segment of code shifted for x lines from the current\n");
printf("                position, where x is an argument of this command. If command is\n");
printf("                input without arguments, shift retains its previous value.\n");
printf("va, viewabs   - Prints a segment of code around the x-th line in the currently\n");
printf("                interpreted file, where x is an argument of this command. Shift\n");
printf("                changes accordingly. If command is input without arguments,\n");
printf("                shift retains its previous value.\n");
printf("nv, nview     - Sets the number of codelines to view. Negative arguments\n");
printf("                sets number of lines before the centerline and positive after\n");
printf("                the centerline. If the command is input vithowt arguments,\n");
printf("                user is requested to input the numbers.\n");
printf("e, calc       - Evaluates expression which is the argument of the command. If\n");
printf("                the command is input without arguments, runs a calculator.\n");
printf("w, watch      - Adds the expression which is an argument of this command to the\n");
printf("Press <Return> to continue!"); getchar();

printf("                watch table. If the command is input without arguments, values\n");
printf("                of the expressions in watch table are printed.\n");
printf("dw, delwatch  - Delete specified expressions from watch table.\n");
printf("aw, autwatch  - Switches automatic watching of expressions on or off (arg. 1/0).\n");
printf("pw, prwatch   - Prints expressions in the watch table.\n");
printf("r, run        - Runs commands input by user in file interpreter. If the command\n");
printf("                is input with parameters, they are exesuted, else the user is\n");
printf("                requested to input commands.\n");
printf("rd, rundebug  - The same as \"r\", except that the input commands are debugged.\n");
printf("rf, runfile   - Sets the file into which user's commands for interpretation will\n");
printf("                be written. Name can be an argument of this command, otherwise\n");
printf("                the user is requested to input the name;\n");
printf("pb, prbreak   - Prints information about active break\n");
printf("tb, tellbreak - Prints information about specific break\n");
printf("sb, suspbreak - Suspends breaks with given identification number\n");
printf("Press <Return> to continue!"); getchar();
printf("ab, actbreak  - Activates breaks with given identification number\n");

printf("Press <Return> to continue!"); getchar();
}

static void instfidebug(ficom com)
{
licom lcom;
if (com->lint==NULL)
{
  com->lint=newlicom(300);
}
lcom=com->lint;
lcom->before=debugbefore;
lcom->signal=debugsignal;
lcom->preaction=debugpreaction;
instlicom(lcom,"?",li_help);
instlicom(lcom,"h",li_help);
instlicom(lcom,"help",li_help);
instlicom(lcom,"!",li_system);
instlicom(lcom,"system",li_system);
instlicom(lcom,"q",li_quit);
instlicom(lcom,"quit",li_quit);
instlicom(lcom,"x",li_exit);
instlicom(lcom,"exit",li_exit);
instlicom(lcom,"s",li_step);
instlicom(lcom,"step",li_step);
instlicom(lcom,"S",li_stepover);
instlicom(lcom,"stepover",li_stepover);
instlicom(lcom,"c",li_continue);
instlicom(lcom,"continue",li_continue);
instlicom(lcom,"n",li_nstep);
instlicom(lcom,"nstep",li_nstep);
instlicom(lcom,"N",li_nstepover);
instlicom(lcom,"nstepover",li_nstepover);
instlicom(lcom,"v",li_view);
instlicom(lcom,"view",li_view);
instlicom(lcom,"vr",li_viewrel);
instlicom(lcom,"viewrel",li_viewrel);
instlicom(lcom,"va",li_viewabs);
instlicom(lcom,"viewabs",li_viewabs);
instlicom(lcom,"nv",li_nview);
instlicom(lcom,"nview",li_nview);
instlicom(lcom,"e",li_calc);
instlicom(lcom,"calc",li_calc);
instlicom(lcom,"w",li_watch);
instlicom(lcom,"watch",li_watch);
instlicom(lcom,"dw",li_deletewatch);
instlicom(lcom,"delwatch",li_deletewatch);
instlicom(lcom,"aw",li_autowatch);
instlicom(lcom,"autwatch",li_autowatch);
instlicom(lcom,"pw",li_printwatches);
instlicom(lcom,"prwatch",li_printwatches);
instlicom(lcom,"r",li_run);
instlicom(lcom,"run",li_run);
instlicom(lcom,"rf",li_runfilename);
instlicom(lcom,"runfile",li_runfilename);
instlicom(lcom,"pb",li_printbreakstatus);
instlicom(lcom,"prbreak",li_printbreakstatus);
instlicom(lcom,"tb",li_tellbreak);
instlicom(lcom,"tellbreak",li_tellbreak);
instlicom(lcom,"sb",li_suspendbreak);
instlicom(lcom,"suspbreak",li_suspendbreak);
instlicom(lcom,"ab",li_activatebreak);
instlicom(lcom,"actbreak",li_activatebreak);

/*
instlicom(lcom,"",li_);
instlicom(lcom,"",li_);
instlicom(lcom,"",li_);
*/
}


/* KONEC FUNKCIJ VRSTICNEGA INTERPRETERJA */

static void figoto(ficom com)
{
int length,buflength=1000;
char end=0,found=0, * labelname=NULL;
long pos,pos0,pos1;
/* Ce se nismo v osnovnem nivoju, se samo zniza nivo, drugace pa se tudi skoci
na ustrezno mesto: */
if (com->level>1)
  com->stopint=1;
else
{
  pos=com->from;
  while (!end)
  {
    /* Poisce se niz, ki oznacuje mesto za preskoke: */
    pos=filestringto(com->fp,com->labelstr,pos,com->to,buflength);
    if (pos<=0)
      end=1;
    else
    {
      /* Prebere se ime oznake za skok: */
      pos0=filenotcharto(com->fp,"{ \n\r\t\0",6,pos+strlen(com->labelstr),com->to,buflength);
      pos1=filecharto(com->fp,"}: \n\r\t\0",7,pos0,com->to,buflength);
      /* Dolzina imena: */
      if (pos1>0 && pos0>0)
        length=pos1-pos0;
      else
        length=0;
      if (length>=0)
      {
        labelname=malloc(length+1);
        fileread(labelname,sizeof(char),length,com->fp,pos0);
        labelname[length]='\0';
        /* Preveri se, ali smo nasli pravo oznako: */
        if (cmpstrings(com->gotolabel,labelname)==0)
        {
          /* Ce smo nasli pravo oznako, premaknemo pozicijo interpreterja za
          njo: */
          end=1;
          found=1;
          com->pos=pos0+length;
          pos=filecharto(com->fp,"{",1,pos+strlen(com->labelstr),pos0,buflength);
          if (pos0>0)
          {
            filebrac(com->fp,com->brac1,com->brac2,pos,30,&pos0,&pos1);
            if (pos0>0 && pos1>0)
              com->pos=pos1+1;
          }
          pos=com->pos;
        }
        free(labelname);
      }
      pos=pos0;
    }
  }
  if (!found)
  {
    errfunc0("figoto");
    fprintf(erf(),"FILE INTERPRETER: Label %s is missing.\n",com->gotolabel);
    errfunc2();
  }
  free(com->gotolabel);
  com->gotolabel=NULL;
}
}



void fileinterpret(ficom com)
    /* Interpretira ukaze v datoteki com->fp. Vsa navodila za interpretacijo so
    zbrana v com. Funkcija deluje tako, da v datoteki isce ukaze, to je nize,
    nalozene na com->commands, in ko najde taksen niz, izvrsi pripadajoco mu
    funkcijo. Te funkcije so nalozene na skladu com->functions.
    $A Igor <== dec97 mar99; */
{
fifunction func;
int minbuf=20; /* Dolzina pomoznega pomnilnika pri iskanju nizov v datotekah */
int which,length,n;
long pos;
char *str,*ref="\n\n \n\r\tR";
str=stringcopy(ref);
str[strlen(str)-1]='\0';
fint=com;  /* Podatek za vrsticni interpreter pri razhroscevanju */
++ com->level;
com->stopint=0;
if (com->fp==NULL)
{
  errfunc0("fileinterpret");
  fprintf(erf(),"FILE INTERPRETER: File to interpret is not open.\n");
  errfunc2();
} else if ( (com->brac1=='\0' || com->brac2=='\0') && com->endchar=='\0')
{
  errfunc0("fileinterpret");
  fprintf(erf(),"FILE INTERPRETER: Brackets are not specified.\n");
  errfunc2();
} else if (com->functions==NULL)
{
  errfunc0("fileinterpret");
  fprintf(erf(),"FILE INTERPRETER: Function list is missing.\n");
  errfunc2();
} else if (com->functions->n<=0)
{
  errfunc0("fileinterpret");
  fprintf(erf(),"FILE INTERPRETER: Function list is missing.\n");
  errfunc2();
} else
{
  if (com->from<=0)
    com->from=1;
  if (com->to<=0)
    com->to=flength(com->fp);
  if (com->pos<=0)
    com->pos=com->from;
  str[0]=com->brac1;
  str[1]=com->brac2;
  while (!com->stopint)
  {
    com->pos=filenotcharto(com->fp,str,strlen(str)+1/*tudi znak '\0' je zraven*/
                           ,com->pos,com->to,minbuf);
    if (com->pos<=0)
      com->stopint=1;
    else
    {
      com->funcpos=com->pos;   /* Pozicija imena funkcije */
      pos=filecharto(com->fp,str,strlen(str)+1,com->pos,com->to,minbuf);
      if (pos<1)
        pos=com->to+1;
      length=pos-com->pos;
      if (length>MAXNAME)
        length=MAXNAME;
      length=fileread(functionname,1,length,com->fp,com->pos);
      functionname[length]='\0';
      com->pos+=length;
      which=findsortstack(com->functions,functionname,0,0,
                      (int (*)(void *,void *)) cmpfifunctionstr);
      if (which<1)
      {
        char c1,c2;
        errfunc0("fileinterpret");
        fprintf(erf(),"FILE INTERPRETER: Unknown function \"%s\".\n",functionname);
        errfunc2();
        if (com->check)
          fiwaituserout(com);
        /* Preverimo, ce ima nedefinirana funkcija argumentni blok, v tem
        primeru postavimo com->pos za konec argumentnega bloka: */
        c1=str[0]; c2=str[1];  /* Shranimo 1. znaka za poznejso restavracijo */
        str[0]=' '; str[1]=' ';  /* Oklepajev sedaj ne bomo izpuscali */
        pos=filenotcharto(com->fp,str,strlen(str)+1,com->pos,com->to,minbuf);
        if (pos>0)
        {
          fileread(str,1,1,com->fp,pos);
          if (str[0]==com->brac1)
          {
            /* Nedefinirana funkcija ima res argumentni blok, najdemo ga in
            preskocimo: */
            filebracto(com->fp,com->brac1,com->brac2,pos,com->to,
                       minbuf,& com->begin,& com->end );
            if (com->begin>0 && com->end>0)
            {
              com->pos=com->end+1;
              com->argpos=com->begin+1;
            } else
            {
              errfunc0("fileinterpret");
              fprintf(erf(),"FILE INTERPRETER: Unknown function \"%s\" has unclosed brackets.\n",functionname);
              errfunc2();
              if (com->check)
                fiwaituserout(com);
              com->pos=com->to+1;
            }
          }
        }
        str[0]=c1; str[1]=c2; /* restavracija niza str */
      } else
      {
        com->which=which;
        func=com->functions->s[which];
        com->func=func;
        if (com->brac1!='\0' && com->brac2!='\0')
        {
          /* Ce sta com->brac1 in com->brac2 razlicna od '\0', velja oklepajna
          sintaksa. */
          /*
          com->pos+=strlen( (char *) com->commands->s[which] );
          */
          filebracto(com->fp,com->brac1,com->brac2,com->pos,com->to,
           minbuf,& com->begin,& com->end );
          if (com->begin<=0 || com->end <=0)
          {
            com->stopint=1;
            errfunc0("fileinterpret");
            fprintf(erf(),"FILE INTERPRETER: Unclosed brackets at command \"%s\".\n",
             func->name);
            errfunc2();
            if (com->check)
              fiwaituserout(com);
          } else
          {
            com->argpos=com->begin+1;
            /* To je dodano na novo: */
            /* Preveri se, ce so med imenom funkcije in oklepajem, ki oznacuje
            zacetek argumentnega bloka, le presledki (drugace je to napaka): */
            if (com->begin>pos)
              if (filenotcharto(com->fp," \n\r\t\0",5,com->pos,com->begin-1,6)>0)
              {
                errfunc0("fileinterpret");
                fprintf(erf(),"FILE INTERPRETER: Word(s) between command \"%s\" and its argument block.\n",
                 func->name);
                errfunc2();
                if (com->check)
                  fiwaituserout(com);
              }
          }
        } else
        {
          /* Stavkovna sintaksa, stavki so loceni z locilom com->endchar. */
          com->begin=com->pos;
          com->end=filecharto(com->fp,&com->endchar,1,com->pos,com->to,minbuf);
          if (com->end<=0)
          {
            com->stopint=1;
            errfunc0("fileinterpret");
            fprintf(erf(),"FILE INTERPRETER: Command \"%s\" is not closed.\n",
             func->name);
            errfunc2();
            if (com->check)
              fiwaituserout(com);
          }
        }
        if (!com->stopint)
        {
          if (func!=NULL)
          {
            if (com->check || com->debug)
            {
              printf("\n||**>> Function \"%s\": ",func->name);
              n=printcheckfilebracto0(com->fp,com->begin,com->end,80);
              if (com->trace)
              {
                printf("  >>");
                printficallstack(com);
              }
              /* printf("\n"); */
              if (com->outfile(com)!=NULL)
              {
                fprintf(com->outfile(com),"\n||**>> Function \"%s\": ",func->name);
                fprintcheckfilebracto0(com->outfile(com),com->fp,com->begin,com->end,80);
                if (com->trace)
                {
                  fprintf(com->outfile(com),"  >>");
                  fprintficallstack(com->outfile(com),com);
                }
                /* fprintf(com->outfile(com),"\n"); */
              }
              if (n)
              {
                errfunc0("fileinterpret");
                fprintf(erf(),"FILE INTERPRETER: Command \"%s\" contains %i missmatched brackets.\n",
                 func->name,n);
                errfunc2();
                if (com->check)
                  fiwaituserout(com);
              }
              if (com->check)
              {
                /* Ce je com->check razlicen od 0, se izvede se funkcija za
                pregled sintakse funkcije, ki se bo izvrsila: */
                if (com->trace)
                {
                  if (com->callst==NULL)
                    com->callst=newstack(20);
                  pushstack(com->callst,func->name);
                  if (func->checkaction!=NULL)
                    func->checkaction(com);
                  popstack(com->callst);
                } else
                {
                  if (func->checkaction!=NULL)
                    func->checkaction(com);
                }
              }
              if (com->debug)
              {
                /* Ce razhroscevalnik se ni instaliran, se to naredi: */
                if (com->lint==NULL)
                {
                  instfidebug(com);
                  com->stop=1;
                }
                if (com->numexec>0)
                  if (com->stoplevel>0)
                    if (com->level<com->stoplevel)
                    {
                      com->stop=1;
                      com->numexec=0;
                    }
                if (com->stop)
                {
                  /* fprintcodedebug(stdout,com); */
                  if (com->lint!=NULL)
                    com->lint->end=0;
                  com->stoplevel=-1;
                  lineinterpret(com->lint);
                }
                /* Izvedba naslednje funkcije: */
                if (func->action!=NULL && !(com->stopint))
                {
                  if (com->trace)
                  {
                    if (com->callst==NULL)
                      com->callst=newstack(20);
                    pushstack(com->callst,func->name);
                    func->action(com);
                    popstack(com->callst);
                  } else
                    func->action(com);
                }
                if (com->stepover && !com->stop)
                {
                  com->stepover=0;
                  com->stop=1;
                }
                if (com->level<=com->stoplevel && com->numexec<=0)
                {
                  com->stop=1;
                  com->stoplevel=-1;
                }
                if (com->numexec>0)
                {
                  if (com->stoplevel<0)
                    --(com->numexec);
                  else
                  {
                    if (com->level==com->stoplevel)
                      --(com->numexec);
                    if (com->level<com->stoplevel)
                    {
                      com->stop=1;
                      com->numexec=0;
                    }
                  }
                  if (com->numexec<=0)
                    com->stop=1;
                }
              }
            } else
            {
              if (func->action!=NULL)
              {
                if (com->trace)
                {
                  if (com->callst==NULL)
                    com->callst=newstack(20);
                  pushstack(com->callst,func->name);
                  func->action(com);
                  popstack(com->callst);
                } else
                  func->action(com);
              }
            }
          }
          com->pos=com->end+1;
          /* POZOR: Pri pisanju telesa funkcije func->action moras vedno
          upostevati, da je v com->start pozicija zacetnega oklepaja in com->end
          pozicija koncnega oklepaja, ki pripada trenutnemu ukazu. To pomeni, da
          se argumenti ukaza zacnejo eno mesto pozneje in koncajo mesto prej. */
        }
      }
    }
    /* Ce je bil trenutni ukaz goto, je postavil niz com->gotolabel. Zato je
    potrebno izvrsiti funkcijo figoto. Ta postavi fi->stopint na 1, ce se nismo
    v 1. (osnovnem) nivoju. Ce smo ze v 1. nivoju, pa ta funkcija povzroci
    preskok na mesto v datoteki com->fp, kjer je ustrezna oznaka. */
    if (com->gotolabel!=NULL)
    {
      figoto(com);
    }
    /* Lahko se zgodi, da je ravnokar izvrseni ukaz zahteval izhod iz
    dolocenega stevila nivojev, torej, da je com->exitlevels postavil na
    vrednost, razlicno od 0 (taksna ukaza sta na primer exit in goto). V tem
    primeru prekinemo interpretacijo na trenutnem nivoju (com->stopint postavimo
    na 1) ter zmanjsamo stevilo nivojev, iz katerih je treba se priti, za -1. */
    if (com->exitlevels>0)
    {
      com->stopint=1;
    }
  }
}
free(str);
-- com->level;
-- com->exitlevels;
}



fifunction instficom(ficom com,char * command,void action(ficom))
    /* Na ukazno spremenljivko com, ki doloca nacin interpretacije datoteke,
    instalira nov ukaz command, ki mu pripada izvrsitev akcije action. Funkcija
    vrne objekt tipa fifunction, kamor nalozi podtke o funkciji (ta objekt da
    tudi na sklad com->functions). Ce funkcija ne uspe instalirati ukaza, vrne
    NULL.
    $A Igor <== dec97 apr98; */
{
fifunction func=NULL;
if (com==NULL)
{
  errfunc0("instficom");
  fprintf(erf(),"File interpreter not defined.\n");
  errfunc2();
} else
{
  func=newfifunction();
  func->name=stringcopy(command);
  func->action=action;
  if (com->functions==NULL)
    com->functions=newstack(10);
  inssortstack(com->functions,func,cmpfifunction);
}
return func;
}

fifunction instficomall(ficom com,char * command,void action(ficom),
                  void checkaction(ficom))
    /* Na ukazno spremenljivko com, ki doloca nacin interpretacije datoteke,
    instalira nov ukaz command, ki mu pripadata izvrsitvena funkcija action
    in kontrolna funkcija checkaction. checkaction je funkcija za preverjanje
    sintakse funkcije. Funkcija vrne objekt tipa fifunction, kamor nalozi
    podtke o funkciji (ta objekt da tudi na sklad com->functions). Ce funkcija
    ne uspe instalirati ukaza, vrne NULL.
    $A Igor apr98; */
{
fifunction func=NULL;
if (com==NULL)
{
  errfunc0("instficomall");
  fprintf(erf(),"File interpreter not defined.\n");
  errfunc2();
} else
{
  func=newfifunction();
  func->name=stringcopy(command);
  func->action=action;
  func->checkaction=checkaction;
  if (com->functions==NULL)
    com->functions=newstack(10);
  inssortstack(com->functions,func,cmpfifunction);
}
return func;
}

fifunction setficomcheck(ficom com,char *command,void checkaction(ficom))
    /* Za kontrolno funkcijo, ki kontrolira sintakso funkcije z imenom command
    v datotecnem interpreterju com, postavi funkcijo checkaction. Funkcija
    najprej poisce podatke o ukazu command na skladu com->functions in nastavi
    polje (...)->checkaction pri ustreznem ukazu. Ce je uspesna, vrne objekt
    tipa fifunction, na katerem je nastavila kontrolno funkcijo, drugace vrne
    NULL.
    $A Igor apr98; */
{
fifunction func=NULL;
if (com!=NULL)
  if (com->functions!=NULL)
  {
    func= (fifunction) ptrfindsortstack(com->functions,command,0,0,
                      (int (*)(void *,void *)) cmpfifunctionstr);

    if (func!=NULL)
      func->checkaction=checkaction;
  }
return func;
}




void fintblock(ficom com,long from, long to)
    /* Izvrsi interpretacijo bloka v datoteki od from do to. Ko konca
    interpretacijo tega dela, Postavi com->stopint, com->from, com->to in
    com->pos na stare vrednosti.
    OPOZORILO: Pred interpretaijo bloka se com->from postavi kar na from in
    ne na from+1, enako se com->to postavi kar na to.
    $A Igor <== jun97; */
{
long oldfrom,oldto,oldpos,oldbegin,oldend;
void *oldfunc;
char oldstopint;
oldfrom=com->from;
oldto=com->to;
oldpos=com->pos;
oldbegin=com->begin;
oldend=com->end;
oldstopint=com->stopint;
oldfunc=com->func;
com->from=from;
com->to=to;
com->pos=from;
fileinterpret(com);
com->from=oldfrom;
com->to=oldto;
com->pos=oldpos;
com->begin=oldbegin;
com->end=oldend;
com->stopint=oldstopint;
com->func=oldfunc;
}


void fintfblock111(ficom com,FILE *fp,char *filename,long from,long to)
    /* Izvrsi interpretacijo bloka v datoteki fp od from do to.
    Ko konca interpretacijo tega dela, postavi com->fp in com->filename na
    stare vrednosti, com->stopint, com->from, com->to in com->pos pa se
    postavijo na stare vrednosti ze v funkciji fintblock(), ki jo ta funkcija
    klice.
    Ce je from enek 0, se datoteka interpretira od zacetka. Ce je to enak 0, se
    datoteka interpretira do konca.
    OPOZORILO: Pred interpretaijo bloka se com->from postavi kar na from in
    ne na from+1, enako se com->to postavi kar na to.
     Datoteka fp mora biti pri klicu obvezno odprta za branje, drugace funkcija
    javi napako. Niza filename se v funkciji ne alocira na novo, ampak se
    uporabi kar ta kazalec.
    $A Igor sep98; */
{
char *oldfilename;
FILE *oldfp;
if (com!=NULL)
{
  /* fclose(oldfp); */ /* To omogoci poljubno globoko rekurzijo, ker v splosnem ni
  mozno imeti naenkrat odprtega velikega stevila datotek */
  /* Nastavijo se podatki za interpretacijo nove datoteke: */
  /*
  com->filename=stringcopy(filename);
  */
  com->filename=filename;
  /*
  com->fp=fopen(com->filename,"rb");
  */
  
  
  /* Shranijo se nekateri podatki o trenutnem stanju interpretacije: */
  oldfilename=com->filename;
  oldfp=com->fp;
  com->filename=filename;
  com->fp=fp;
  if (com->fp!=NULL)
  {
    if (from==0)
      from=1;
    if (to==0)
      to=flength(com->fp);
    fintblock(com,from,to);
  } else
  {
    errfunc0("fintfblock111");
    fprintf(erf(),"File \"%s\" can not be opened file .\n",com->filename);
    errfunc2();
  }
  /* Restavrirajo se nekateri podatki o trenutnem stanju interpretacije: */
  com->filename=oldfilename;
  /* oldfp=fopen(oldfilename,"rb"); */ /* Ponovno odprtje stare datoteke. */
  com->fp=oldfp;
  
  /* Brisanje imena in zaprtje datoteke: */
  /*
  if (com->filename!=NULL)
    free(com->filename);
  */
  /*
  if (com->fp!=NULL)
    fclose(com->fp);
  */
}
}


void fintfblock(ficom com,FILE *fp,char *filename,long from,long to)
    /* Izvrsi interpretacijo bloka v datoteki fp od from do to.
    Ko konca interpretacijo tega dela, postavi com->fp in com->filename na
    stare vrednosti, com->stopint, com->from, com->to in com->pos pa se
    postavijo na stare vrednosti ze v funkciji fintblock(), ki jo ta funkcija
    klice. filename mora kazati na ime datoteke fp.
    Ce je from enek 0, se datoteka interpretira od zacetka. Ce je to enak 0, se
    datoteka interpretira do konca.
    OPOZORILO: Pred interpretaijo bloka se com->from postavi kar na from in
    ne na from+1, enako se com->to postavi kar na to.
     Datoteka fp mora biti pri klicu obvezno odprta za branje, drugace funkcija
    javi napako. Niza filename se v funkciji ne alocira na novo, ampak se
    uporabi kar ta kazalec.
    $A Igor sep98 apr99; */
{
char *oldfilename;
FILE *oldfp;
if (com!=NULL)
{
  /* Shranijo se nekateri podatki o trenutnem stanju interpretacije: */
  oldfilename=com->filename;
  oldfp=com->fp;
  com->filename=filename;
  com->fp=fp;
  if (com->fp!=NULL)
  {
    if (from==0)
      from=1;
    if (to==0)
      to=flength(com->fp);
    fintblock(com,from,to);
  } else
  {
    errfunc0("fintfblock");
    fprintf(erf(),"File \"%s\" can not be opened.\n",com->filename);
    errfunc2();
  }
  /* Restavrirajo se nekateri podatki o trenutnem stanju interpretacije: */
  com->filename=oldfilename;
  com->fp=oldfp;
}
}



void fintfileblock(ficom com,char *name,long from, long to)
    /* Izvrsi interpretacijo bloka v datoteki z imenom name od from do to.
    Ko konca interpretacijo tega dela, postavi com->fp in com->filename na
    stare vrednosti, com->stopint, com->from, com->to in com->pos pa se
    postavijo na stare vrednosti ze v funkciji fintblock(), ki jo ta funkcija
    klice.
    Ce je from enek 0, se datoteka interpretira od zacetka. Ce je to enak 0, se
    datoteka interpretira do konca.
    OPOZORILO: Pred interpretaijo bloka se com->from postavi kar na from in
    ne na from+1, enako se com->to postavi kar na to.
    $A Igor jun97 sep98 apr99; */
{
char *filename=NULL;
FILE *fp=NULL;
if (com!=NULL)
{
  /*
  if (com->fp!=NULL)
    fclose(com->fp);
  com->fp=NULL;
  */
  
  filename=stringcopy(name);
  fp=fopen(filename,"rb");
  fintfblock(com,fp,filename,from,to);
  if (filename!=NULL)
    free(filename);
  if (fp!=NULL)
    fclose(fp);
  
  /*
  if (com->fp==NULL)
    com->fp=fopen(com->filename,"rb");
  */
}
}




void fintfileblockold(ficom com,char *name,long from, long to)
    /* Izvrsi interpretacijo bloka v datoteki z imenom name od from do to.
    Ko konca interpretacijo tega dela, postavi com->fp in com->filename na
    stare vrednosti, com->stopint, com->from, com->to in com->pos pa se
    postavijo na stare vrednosti ze v funkciji fintblock(), ki jo ta funkcija
    klice.
    Ce je from enek 0, se datoteka interpretira od zacetka. Ce je to enak 0, se
    datoteka interpretira do konca.
    OPOZORILO: Pred interpretaijo bloka se com->from postavi kar na from in
    ne na from+1, enako se com->to postavi kar na to.
    $A Igor jun97; */
{
char *oldfilename;
FILE *oldfp;
if (com!=NULL)
{
  /* Shranijo se nekateri podatki o trenutnem stanju interpretacije: */
  oldfilename=com->filename;
  oldfp=com->fp;
  fclose(oldfp);  /* To omogoci poljubno globoko rekurzijo, ker v splosnem ni
  mozno imeti naenkrat odprtega velikega stevila datotek */
  /* Nastavijo se podatki za interpretacijo nove datoteke: */
  com->filename=stringcopy(name);
  com->fp=fopen(com->filename,"rb");
  if (com->fp!=NULL)
  {
    if (from==0)
      from=1;
    if (to==0)
      to=flength(com->fp);
    fintblock(com,from,to);
  } else
  {
    errfunc0("fintfileblock");
    fprintf(erf(),"File \"%s\" can not be opened.\n");
    errfunc2();
  }
  /* Brisanje imena in zaprtje datoteke: */
  if (com->filename!=NULL)
    free(com->filename);
  if (com->fp!=NULL)
    fclose(com->fp);
  /* Restavrirajo se nekateri podatki o trenutnem stanju interpretacije: */
  com->filename=oldfilename;
  oldfp=fopen(oldfilename,"rb"); /* Ponovno odprtje stare datoteke. */
  com->fp=oldfp;
}
}




static void fintfile(ficom com,char *name)
    /* Izvrsi interpretacijo celotne datoteke z imenom name. Ko konca
    interpretacijo, postavi com->fp, com->filename, com->stopint, com->from,
    com->to in com->pos na stare vrednosti (to naredita v bistvu funkciji
    fintfileblock() in fintblock(), ki sta klicani ob izvedbi te funkcije).
    $A Igor jun97; */
{
fintfileblock(com,name,0,0);
}



/* NABOR FUNKCIJ ZA INSTALACIJO INTERPRETERJA S PODPORO SIMBOLNEGA RACUNANJA */



static void fi_comment(ficom com)
       /* Ta prazna funkcija se poklice pri interpretaciji datoteke, ko naletimo
       na komentar. */
{
}

static void fi_exit(ficom com)
       /* Ta akcija povzroci prenehanje interpretacije datoteke na tekocem
       nivoju. Interpretacija se nadaljuje toliko nivojev nizje, kolikor je
       vrednost 1. stevilskega parametra. Ce stevilskega parametra ni, se
       prekine intepretacija na sploh, nivo se postavi na 0. */
{
long start;
int length;
double x;
int minbuf=20;
x=filenumto(com->fp,com->begin+1,com->end-1,minbuf,&start,&length);
if (start>0 && length>0)
  com->exitlevels= (long) x;
else
  com->exitlevels=com->level;
}


static void fi_goto(ficom com)
       /* Prebere ime nalepke, h kateri je treba skociti, in to ime zapise v
       com->gotolabel. */
{
int length,buflength=20;
long pos,pos1;
char *labelname=NULL;
/* Prebere se ime oznake za skok: */
pos=filenotcharto(com->fp," \n\r",3,com->begin+1,com->end-1,buflength);
pos1=filecharto(com->fp," \n\r:",4,pos,com->end-1,buflength);
/* Ce slucajno nismo pustili presledka za imenom oznake: */
if (pos>0 && pos1<=0)
  pos1=com->end;
/* Dolzina imena: */
if (pos1>0 && pos>0)
  length=pos1-pos;
else
  length=0;
if (length>=0)
{
  labelname=malloc(length+1);
  fileread(labelname,sizeof(char),length,com->fp,pos);
  labelname[length]='\0';
  com->gotolabel=labelname;
}
}




static void ficheck_block(ficom com)
    /* Kontrolna funkcija za funkcijo fi_block.
    $A Igor apr98;  */
{
int buflength=1000;
long begin,end;
filebracto(com->fp,com->blockbrac1,com->blockbrac2,com->begin+1,com->end-1,
 buflength,&begin,&end);
if (begin<=0 || end<=0)
{
  err0();
  fprintf(erf(),"Block not defined.\n");
  err2();
  fiwaituser(com);
} else
  fintblock(com,begin+1,end-1);
}

static void fi_block(ficom com)
    /* Izvrsi blok, ki je med oklepajema com->blockbrac1 in com->blockbrac2.
    blok mora biti v datoteki com->fp med com->begin in com->end.
    $A Igor <== apr98; */
{
int buflength=1000;
long begin,end;
filebracto(com->fp,com->blockbrac1,com->blockbrac2,com->begin+1,com->end-1,
 buflength,&begin,&end);
if (begin<=0 || end<=0)
{
  err0();
  fprintf(erf(),"Block not defined.\n");
  err2();
} else
  fintblock(com,begin+1,end-1);
}





static void ficheck_if(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_if.
    $A Igor apr98; */
{
long begin,end;
int buflength1=30,buflength2=2000,buflength;
buflength=flength(com->fp)/10;
if (buflength>0 && buflength<buflength2)
  buflength2=buflength;
/* Najprej se prebere izraz, ki pomeni pogoj za izvrsitev bloka: */
filebracto(com->fp,com->expbrac1,com->expbrac2,com->begin+1,com->end-1,
 buflength1,&begin,&end);
if (begin<=0 || end<=0 || end<=begin+1)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Undefined condition in if statement.\n");
  err2();
  fiwaituser(com);
} else
{
  /* Najde se 1. blok in se interpretira; ce ne obstaja, je to napaka: */
  filebracto(com->fp,com->blockbrac1,com->blockbrac2,end+1,com->end-1,
   buflength2,&begin,&end);
  if (begin<=0 || end<=0)
  {
    err0();
    fprintf(erf(),"FILE INTERPRETER: Undefined first block in if statement.\n");
    err2();
    fiwaituser(com);
  } else
  {
    fintblock(com,begin+1,end-1);
    /* Poisce se se drugi blok in se interpretira, ce obstaja: */
    filebracto(com->fp,com->blockbrac1,com->blockbrac2,end+1,com->end-1,
     buflength2,&begin,&end);
    if (begin>0 && end>0)
    {
      fintblock(com,begin+1,end-1);
    }
  }
}
}


static void fi_if(ficom com)
    /* Izvrsi blok, ki je med oklepajema com->blockbrac1 in com->blockbrac2,
    ce je izpolnjen pogoj, ki ga predstavlja izraz pred tem blokom, ki je
    med oklepajema com->expbrac1 in com->expbrac2. Vrednost pogojnega izraza
    se ovrednoti v podpornem sistemu za simbolno racunanje com->syst. Pogojni
    izraz in izvrseni (interpretirani) blok sta v datoteki com->fp med
    com->begin in com->end.
    Ce pogoj ni izpolnjen, se uresnici drugi blok med oklepajema
    com->blockbrac1 in com->blockbrac2, ce ta obstaja. Ce ne obstaja, se
    izvajanje zanke if konca.
    OPOMBA: Ce sta med com->begin in com->end dva bloka, je med njima
    dovoljeno napisati besedo else, da je sintaksa bolj podobna sintaksi
    programskih jezikov.
    $A Igor <== apr98 mar99; */
{
long begin,end,length;
double x;
char *exp=NULL;
int buflength1=30,buflength2=1000,buflength,oldstepover;
buflength=flength(com->fp)/10;
if (buflength>1000)
  buflength=1000;
if (buflength>0 && buflength<buflength2)
  buflength2=buflength;
/* Najprej se prebere izraz, ki pomeni pogoj za izvrsitev bloka: */
filebracto(com->fp,com->expbrac1,com->expbrac2,com->begin+1,com->end-1,
 buflength1,&begin,&end);
if (begin<=0 || end<=0 || end<=begin+1)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Undefined condition in if statement.\n");
  err2();
} else
{
  length=end-begin-1;
  exp=malloc(length+1);
  fileread(exp,sizeof(char),length+1,com->fp,begin+1);
  exp[length]='\0';
  /* Prebrani izraz se ovrednoti: */
  x=evaluateexp(com->syst,exp);
  disppointer((void **) &exp);
  /* Ce je vrednost izraza razlicna od 0, se izvrsi blok: */
  if (x!=0)
  {
    filebracto(com->fp,com->blockbrac1,com->blockbrac2,end+1,com->end-1,
     buflength2,&begin,&end);
    if (begin<=0 && end<=0)
    {
      err0();
      fprintf(erf(),"FILE INTERPRETER: Undefined first block in if statement.\n");
      err2();
    } else
    {
      if (com->exitlevels<=0)
        com->exitlevels=-1;
      if (com->stepover)
        com->stop=1;
      oldstepover=com->stepover;
      com->stepover=0;
      fintblock(com,begin+1,end-1);
      com->stepover=oldstepover;
    }
  }
  else
  {
    filebracto(com->fp,com->blockbrac1,com->blockbrac2,end+1,com->end-1,
     buflength2,&begin,&end);
    filebracto(com->fp,com->blockbrac1,com->blockbrac2,end+1,com->end-1,
     buflength2,&begin,&end);
    if (begin<=0 || end<=0)
    {
    } else
    {
      if (com->exitlevels<=0)
        com->exitlevels=-1;
      if (com->stepover)
        com->stop=1;
      oldstepover=com->stepover;
      com->stepover=0;
      fintblock(com,begin+1,end-1);
      com->stepover=oldstepover;
    }
  }
}
}



static void ficheck_while(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_while v ukazni
    datoteki.
    $A Igor apr98; */
{
long beginexp,endexp,beginblock,endblock;
int buflength1=30,buflength2=10000,buflength;
buflength=flength(com->fp)/10;
if (buflength>0 && buflength<buflength2)
  buflength2=buflength;
/* Najprej se prebere izraz, ki pomeni pogoj za izvrsitev bloka: */
filebracto(com->fp,com->expbrac1,com->expbrac2,com->begin+1,com->end-1,
 buflength1,&beginexp,&endexp);
if (beginexp<=0 || endexp<=0 || endexp<=beginexp+1)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Undefined condition in while loop.\n");
  err2();
  fiwaituser(com);
} else
{
  /* Poisce se obmocje izvrsnega bloka: */
  filebracto(com->fp,com->blockbrac1,com->blockbrac2,endexp+1,com->end-1,
   buflength2,&beginblock,&endblock);
  if (beginblock<=0 && endblock<=0 && endblock<=beginblock+1)
  {
    err0();
    fprintf(erf(),"FILE INTERPRETER: Undefined execution block in while loop.\n");
    err2();
    fiwaituser(com);
  }
}
}




static void fi_while(ficom com)
    /* Dokler je izpolnjen pogoj med okleajema com->expbrac1 in
    com->expbrac2, se interpretira blok, ki sledi temu pogoju in je med
    oklepajema com->blockbrac1 in com->blockbrac2. Vrednost pogojnega izraza
    se ovrednoti v podpornem sistemu za simbolno racunanje com->syst. Pogojni
    izraz in izvrseni (interpretirani) blok sta v datoteki com->fp med
    com->begin in com->end.
    $A Igor <== apr98 mar99; */
{
long beginexp,endexp,beginblock,endblock,length;
double x;
int buflength1=30,buflength2=500,buflength;
char *exp=NULL;
int oldstepover;
buflength=flength(com->fp)/10;
if (buflength>1000)
  buflength=1000;
if (buflength>0 && buflength<buflength2)
  buflength2=buflength;
/* Najprej se prebere izraz, ki pomeni pogoj za izvrsitev bloka: */

/*
printf("\nPRED filebracto:\n");
getchar();
*/

filebracto(com->fp,com->expbrac1,com->expbrac2,com->begin+1,com->end-1,
 buflength1,&beginexp,&endexp);

/*
printf("\nPO filebracto:\n");
getchar();
*/


if (beginexp<=0 || endexp<=0 || endexp<=beginexp+1)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Undefined condition in while loop.\n");
  err2();
} else
{
  length=endexp-beginexp-1;
  exp=malloc(length+1);
  fileread(exp,sizeof(char),length+1,com->fp,beginexp+1);
  exp[length]='\0';
  /* Poisce se obmocje bloka: */
  
  
/*
  printf("\nPRED DRUGIM filebracto:\n");
  getchar();
*/

  
  filebracto(com->fp,com->blockbrac1,com->blockbrac2,endexp+1,com->end-1,
   buflength2,&beginblock,&endblock);
  
 
/*
  printf("\nPO DRUGEM filebracto:\n");
  getchar();
*/

  
  if (beginblock<=0 && endblock<=0 && endblock<=beginblock+1)
  {
    err0();
    fprintf(erf(),"FILE INTERPRETER: Undefined execution block in while loop.\n");
    err2();
  } else
  {
    /* Pri zankah je treba paziti, da exit pravilno deluje. Izvajanje zanke je
    potrebno ustaviti, ce smo z ukazom exit sli ven iz bloka, ki se izvaja v
    zanki. Z izvajanjem bloka (za to skrbi funkcija fileinterpret()) prenehamo,
    ce je com->stopint razlicen od 0, vendar tega kriterija ne moremo uporabiti
    za ustavitev izvajanja zanke, ker se takoj po izhodu iz bloka com->stopint
    postavi nazaj na 1. Namesto tega uporabimo com->exitlevels, ki se ne
    postavi na staro vrednost po izhodu iz bloka, temvec se ob izhodu iz bloka
    dekrementira in sicer ne glede na to, ce je ze tako ali tako manjsi ali
    enak 0. Pri delovanju funkcije exit izkoristimo to na naslednji nacin:
     Ce je izhod iz bloka, ki se izvaja v zanki, normalen (konec bloka), je ze
    pred izhodom com->exitlevels najvec 0, pri izhodu pa se se dekrementira. To
    pomeni, da ce je po izhodu com->exitlevels vecji ali enak 0, je bil izhod
    iz bloka gotovo induciran, kar pomeni, da se mora tudi izvajanje zanke
    prekiniti. Zanko torej prekinemo, ce com->exitlevels ni manjsi od 0, zaradi
    tega pa moramo ze pred izvedbo zanke (ker jo izvajamo z while, ne z do)
    com->exitlevels postaviti na nekaj, kar je manjse od 0: */
    if (com->exitlevels<=0)
      com->exitlevels=-1;
    if (com->stepover)
      com->stop=1;
    oldstepover=com->stepover;
    com->stepover=0;
    while ( com->exitlevels<0 && (x=evaluateexp(com->syst,exp)) !=0 )
      fintblock(com,beginblock+1,endblock-1);
    com->stepover=oldstepover;
  }
}
disppointer((void **) &exp);

/*
printf("\nKONEC fi_while :\n");
getchar();
*/

}



static void ficheck_do(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_do v ukazni
    datoteki.
    $A Igor apr98; */
{
long beginexp,endexp,beginblock,endblock;
int buflength1=30,buflength2=10000,buflength;
buflength=flength(com->fp)/10;
if (buflength>0 && buflength<buflength2)
  buflength2=buflength;
/* Poisce se obmocje bloka: */
filebracto(com->fp,com->blockbrac1,com->blockbrac2,com->begin+1,com->end-1,
 buflength2,&beginblock,&endblock);
if (beginblock<=0 || endblock<=0 || endblock<=beginblock+1)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Undefined execution block in do loop.\n");
  err2();
  fiwaituser(com);
} else
{
  /* Prebere se izraz, ki pomeni pogoj za izvrsitev bloka: */
  filebracto(com->fp,com->expbrac1,com->expbrac2,endblock+1,com->end-1,
   buflength1,&beginexp,&endexp);
  if (beginexp<=0 || endexp<=0 && endexp<=beginexp+1)
  {
    err0();
    fprintf(erf(),"FILE INTERPRETER: Undefined condition in do loop.\n");
    err2();
    fiwaituser(com);
  }
}
}




static void fi_do(ficom com)
    /* Dokler ne postane neizpolnjen pogoj med okleajema com->expbrac1 in
    com->expbrac2, se interpretira blok pred tem  pogojem  med
    oklepajema com->blockbrac1 in com->blockbrac2. Vrednost pogojnega izraza
    se ovrednoti v podpornem sistemu za simbolno racunanje com->syst. Pogojni
    izraz in izvrseni (interpretirani) blok sta v datoteki com->fp med
    com->begin in com->end. Od fi_while se ta funkcija razlikuje po tem,
    da izvrsi blok vsaj enkrat tudi, ce na zacetku pogoj ni izpolnjen, in po
    tem, da pogojni izraz stoji za interpretiranim blokom.
    OPOMBA: Da je sintaksa bloj podobna sintaksi jezika C, je dovoljeno med
    blokom in pogojem vriniti besedo "while", ki pa ni obvezna in se
    ignorira.
    $A Igor <== apr98; */
{
long beginexp,endexp,beginblock,endblock,length;
double x;
char *exp=NULL;
int buflength1=30,buflength2=1000,buflength,oldstepover;
buflength=flength(com->fp)/10;
if (buflength>1000)
  buflength=1000;
if (buflength>0 && buflength<buflength2)
  buflength2=buflength;
/* Poisce se obmocje bloka: */
filebracto(com->fp,com->blockbrac1,com->blockbrac2,com->begin+1,com->end-1,
 buflength2,&beginblock,&endblock);
if (beginblock<=0 || endblock<=0 || endblock<=beginblock+1)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Undefined execution block in do loop.\n");
  err2();
} else
{
  /* Prebere se izraz, ki pomeni pogoj za izvrsitev bloka: */
  filebracto(com->fp,com->expbrac1,com->expbrac2,endblock+1,com->end-1,
   buflength1,&beginexp,&endexp);
  if (beginexp<=0 || endexp<=0 && endexp<=beginexp+1)
  {
    err0();
    fprintf(erf(),"FILE INTERPRETER: Undefined condition in do loop.\n");
    err2();
  } else
  {
    length=endexp-beginexp-1;
    exp=malloc(length+1);
    fileread(exp,sizeof(char),length+1,com->fp,beginexp+1);
    exp[length]='\0';
    /* Pri zankah je treba paziti, da exit pravilno deluje. Izvajanje zanke je
    potrebno ustaviti, ce smo z ukazom exit sli ven iz bloka, ki se izvaja v
    zanki. Z izvajanjem bloka (za to skrbi funkcija fileinterpret()) prenehamo,
    ce je com->stopint razlicen od 0, vendar tega kriterija ne moremo uporabiti
    za ustavitev izvajanja zanke, ker se takoj po izhodu iz bloka com->stopint
    postavi nazaj na 1. Namesto tega uporabimo com->exitlevels, ki se ne
    postavi na staro vrednost po izhodu iz bloka, temvec se ob izhodu iz bloka
    dekrementira in sicer ne glede na to, ce je ze tako ali tako manjsi ali
    enak 0. Pri delovanju funkcije exit izkoristimo to na naslednji nacin:
     Ce je izhod iz bloka, ki se izvaja v zanki, normalen (konec bloka), je ze
    pred izhodom com->exitlevels najvec 0, pri izhodu pa se se dekrementira. To
    pomeni, da ce je po izhodu com->exitlevels vecji ali enak 0, je bil izhod
    iz bloka gotovo induciran, kar pomeni, da se mora tudi izvajanje zanke
    prekiniti. Zanko torej prekinemo, ce com->exitlevels ni manjsi od 0: */
    if (com->exitlevels<=0)
      com->exitlevels=-1;
    if (com->stepover)
      com->stop=1;
    oldstepover=com->stepover;
    com->stepover=0;
    do
      fintblock(com,beginblock+1,endblock-1);
    while ( com->exitlevels<0 &&  (x=evaluateexp(com->syst,exp)) !=0 );
    com->stepover=oldstepover;
    disppointer((void **)&exp);
  }
}
}



static void ficheck_defvar(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_defvar v ukazni
    datoteki.
    $A Igor apr98; */
{
int length;
length=com->end-com->begin-1; /* Dolzina izraza */
if (length<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Undefined expression.\n");
  err2();
  fiwaituser(com);
}
}

static void fi_defvar(ficom com)
       /* Sistemu za simbolno racunanje, s katerim je podprta interpretacija
       datoteke, se doda definicija spremenljivke. */
{
char *expression=NULL;
int length;
length=com->end-com->begin-1; /* Dolzina izraza */
if (length<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Undefined expression.\n");
  err2();
} else
{
  /* Najprej se prebere izraz, ki ga potem vkljucimo v sist. za simbol.
  racunanje: */
  expression=malloc(length+1); /* En byte je za zakljucni znak '\0'. */
  fileread(expression,sizeof(char),length,com->fp,com->begin+1);
  expression[length]='\0'; /* Ker se steje od 0 */
  /* Nato se izraz vkljuci v sistem za simbolno racunanje: */
  includeexp(com->syst,expression);
  if (expression!=NULL)
    free(expression);
}
}




static void ficheck_assignval(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_defvar v ukazni
    datoteki.
    $A Igor apr98; */
{
int length=0,namelength=0,buflength=20;
long begin1,pos1,pos2;
/* Lega dvopicja: */
begin1=filecharto(com->fp,":",1,com->begin+1,com->to-1,buflength);
if (begin1>0)
  /* Dolzina izraza: */
  length=com->end-begin1-1; /* Dolzina izraza */
/* Dolzina imena spremenljivke: */
pos1=filenotcharto(com->fp," \n\r",3,com->begin+1,com->to-1,buflength);
pos2=filecharto(com->fp," :\n\r",4,pos1,com->to-1,buflength);
if (pos1>0 && pos2>0)
  namelength=pos2-pos1;
if (begin1<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Colon is missing.\n");
  err2();
  fiwaituser(com);
} else if (length<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Variable or function name not specified.\n");
  err2();
  fiwaituser(com);
} else if (namelength<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Definition is missing.\n");
  err2();
  fiwaituser(com);
}
}


static void fi_assignval(ficom com)
    /* Spremenljivki z imenom, ki je navedeno pred dvopicjem, priredi realno
    vrednost, ki pripada izrazu, ki sledi dvopicju. Drevo, ki pripada temu
    izrazu, se na koncu brise. Ce definicija spremenljivke s tem imenom ze
    obstaja v sistemu com->syst, se ta definicija potisne na sklad
    com->syst->trash, ustrezni spremenljivki pa priredimo novo vrednost. */
{
double val;
char *expression=NULL,*name=NULL;
int length=0,namelength=0,buflength=20;
long begin1,pos1,pos2;
/* Lega dvopicja: */
begin1=filecharto(com->fp,":",1,com->begin+1,com->to-1,buflength);
if (begin1>0)
  /* Dolzina izraza: */
  length=com->end-begin1-1; /* Dolzina izraza */
/* Dolzina imena spremenljivke: */
pos1=filenotcharto(com->fp," \n\r",3,com->begin+1,com->to-1,buflength);
pos2=filecharto(com->fp," :\n\r",4,pos1,com->to-1,buflength);
if (pos1>0 && pos2>0)
  namelength=pos2-pos1;
if (begin1<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Colon is missing .\n");
  err2();
} else if (length<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Variable or function name not specified.\n");
  err2();
} else if (namelength<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Definition is missing.\n");
  err2();
}
if (namelength>0 && length>0)
{
  /* Najprej se prebere ime spremenljivke, ki ji priredimo vrednost: */
  name=malloc(namelength+1); /* En byte je za zakljucni znak '\0'. */
  fileread(name,sizeof(char),namelength,com->fp,pos1);
  name[namelength]='\0'; /* Ker se steje od 0 */
  /* Potem se prebere izraz, ki ga potem ovrednotimo v okviru sistema za
  simbolno racunanje: */
  expression=malloc(length+1); /* En byte je za zakljucni znak '\0'. */
  fileread(expression,sizeof(char),length,com->fp,begin1+1);
  expression[length]='\0'; /* Ker se steje od 0 */
  /* Nato se izraz ovrednoti glede na sistem za simbol. racunanje: */
  val=evaluateexp(com->syst,expression);
  /* Sedaj se priredimo izracunano vrednost spremenljivki z danim imenom: */
  assigndouble(com->syst,name,val);
  /* Na koncu se pobrisemo pomozni spomin, ki smo ga alocirali: */
  if (name!=NULL)
    free(name);
  if (expression !=NULL)
    free(expression);
}
}



static void ficheck_read1(ficom com)
    /* Kontrolna funkcija za preverjanje sintakse funkcij read in fread v
    ukazni datoteki.
    $A Igor japr98; */
{
long pos,pos1;
int length,buflength=15;
char *name=NULL;
/* Prebere se ime spremenljivke: */
pos=filenotcharto(com->fp," \n\r",3,com->begin+1,com->end-1,buflength);
pos1=filecharto(com->fp," \n\r",3,pos,com->end-1,buflength);
/* Ce slucajno nismo pustili presledka za imenom oznake: */
if (pos>0 && pos1<=0)
  pos1=com->end;
/* Dolzina imena: */
if (pos1>0 && pos>0)
  length=pos1-pos;
else
  length=0;
if (length<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Undefined variable name.\n");
  err2();
  fiwaituser(com);
}
}


static void fi_read1(FILE *fp,ficom com)
       /* Funkcija za branje, ki jo uporabljata fi_read in fi_fread. Iz datoteke
       fp se pri trenutni poziciji prebere realna vrednost in se priredi
       spremenljivki, katere ime je navedeno kot parameter. Ime spremenljivke ne
       sme biti v narekovajih. */
{
double val;
long pos,pos1;
int length,buflength=15;
char *name=NULL;
/* Prebere se ime spremenljivke: */
pos=filenotcharto(com->fp," \n\r",3,com->begin+1,com->end-1,buflength);
pos1=filecharto(com->fp," \n\r",3,pos,com->end-1,buflength);
/* Ce slucajno nismo pustili presledka za imenom oznake: */
if (pos>0 && pos1<=0)
  pos1=com->end;
/* Dolzina imena: */
if (pos1>0 && pos>0)
  length=pos1-pos;
else
  length=0;
if (length<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Undefined variable name.\n");
  err2();
} else
{
  name=malloc(length+1);
  fileread(name,sizeof(char),length,com->fp,pos);
  name[length]='\0';
  fscanf(fp,"%lg",&val);
  assigndouble(com->syst,name,val);
}
}


static void fi_read(ficom com)
{
fi_read1(stdin,com);
}


static void fi_fread(ficom com)
{
if (com->in!=NULL)
  fi_read1(com->in,com);
}



static void ficheck_write1default(char *funcname,long from,long to,ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_write1 v ukazni
    datoteki. From in to sta zacetna in koncna pozicija odseka v ukazni
    datoteki, kjer so zapisana navodila za to, kaj naj se izpise.
    $A Igor apr98 sep99; */
{
long pos,pos1,pos2;
char ch,*str,*expression;
int buflength=20;
int length;
pos=from;
while (pos>0)
{
  /* Najprej se poisce enega od znakov '$', '\\' ali '\"' :*/
  pos1=pos;
  pos=filecharto(com->fp,"\"$\\",3,pos1,to,buflength);
  pos2=filenotcharto(com->fp," \n\r\t\0",5,pos1,to,buflength);
  if ((pos<=0 && pos2>0) || (pos>0 && pos2>0 && pos2<pos))
  {
    pos1=pos2;
    if (pos<=0)
    {
      pos2=to+1;
      pos=pos2;
    }
    else
      pos2=pos;
    length=pos2-pos1;
    if (length>0)
    {
      /* Niz pred katerim od znakov, ki kaj pomenijo oz. ukazujejo, je napaka: */
      str=malloc(length+1);
      fileread(str, sizeof(char),length,com->fp,pos1);
      str[length]='\0';
      errfunc0(funcname);
      fprintf(erf(),"Undefined sequence \"%s\".\n",str);
      errfunc2();
      fiwaituser(com);
      free(str);
    }
  }
  /* Potem se ta znak prebere v ch: */
  if (pos>0)
  {
    fileread(&ch, sizeof(char),1,com->fp,pos);
    switch (ch)
    {
      case '\"':
        /* Izpis niza med dvojnima narekovajema */
        ++ pos;
        pos1=filecharto(com->fp,"\"",1,pos,to,buflength);
        /* Za primer, ce manjka zakljucni narekovaj niza: */
        if (pos1<=0)
        {
          pos1=to+1;
          errfunc0(funcname);
          fprintf(erf(),"\" is missing at the end of string.\n");
          errfunc2();
          fiwaituser(com);
        }
        length=pos1-pos;
        if (length>0)
        {
          /*
          str=malloc(length+1);
          fileread(str, sizeof(char),length,com->fp,pos);
          str[length]='\0';
          fprintf(fp,"%s",str);
          free(str); str=NULL;
          */
          pos=pos1+1;
        } else
          pos=-1;
        break;
      case '\\':
        /* Izpis posebnega znaka; doloca ga znak, ki sledi znaku '\\' . */
        ++ pos;
        if (pos>=to+1)
        {
          errfunc0(funcname);
          fprintf(erf(),"Character specification is missing after the \\ control.\n");
          errfunc2();
          fiwaituser(com);
        } else
        {
          /* Preverjanje, ce je specifikacija posebnega znaka definirana: */
          fileread(&ch, sizeof(char),1,com->fp,pos);
          if(specialcharacter(ch)=='0')
          {
            errfunc0(funcname);
            fprintf(erf(),"Unknown character specification \'%c\'.\n",ch);
            errfunc2();
            fiwaituser(com);
          }
        }
        ++ pos;
        break;
      case '$':
        pos=filenotcharto(com->fp," \n\r\t\0",5,pos+1,to,buflength);
        fileread(&ch, sizeof(char),1,com->fp,pos);
        switch (ch)
        {
          case '{':
            expression=NULL;
            filebracto(com->fp,'{','}',pos,to,30,&pos1,&pos2);
            if (pos1<=0 || pos2<=pos1+1)
            {
              errfunc0(funcname);
              fprintf(erf(),"Expression is missing after the \"${\" sequence.\n");
              errfunc2();
              fiwaituser(com);
            } else
            {
              /* Prebere se izraz, ki ga potem ovrednotimo v okviru sistema za
              simbolno racunanje: */
              /*
              length=pos2-pos1-1;
              expression=malloc(length+1);
              fileread(expression,sizeof(char),length,com->fp,pos1+1);
              expression[length]='\0';
              if (expression!=NULL)
              {
                val=evaluateexp(com->syst,expression);
                fprintf(fp,"%*.*g",outchar,m_outdig,val);
                free(expression);
              }
              */
            }
            if (pos1>0 && pos2>0)
              pos=pos2+1;
            break;
          case '\\':
            fileread(&ch,sizeof(char),1,com->fp,pos+1);
            pos+=2;
            pos=filenotcharto(com->fp," \n\r\t\0",5,pos,to,buflength);
            pos1=filecharto(com->fp," $\"\n\r\t\0",7,pos,to,buflength);
            if (pos>0)
            {
              if (pos1>pos)
                length=pos1-pos;
              else
                length=to+1-pos;
            } else
              length=0;
            if (length>0)
            {
              /* Prebere se ime spremenljivke: */
              /*
              str=malloc(length+1);
              fileread(str,sizeof(char),length,com->fp,pos);
              str[length]='\0';
              t=findobjname( (stack) com->syst->def,str);
              */
              pos+=length;
              /*
              if (t==NULL)
              {
                errfunc0(funcname);
                fprintf(erf(),"Variable \"%s\" not defined.\n",str);
                errfunc2();
              }
              */
              {
                switch(ch)
                {
                  case 't':
                    /*
                    fprintf(fp,"\n");
                    fprinttree(fp,t,60,130);
                    fprintf(fp,"\n");
                    */
                    break;
                  case 'f':
                    /*
                    fprintf(fp,"\n");
                    fprinttreefull(fp,t,60,200);
                    fprintf(fp,"\n");
                    */
                    break;
                  case 'p':
                    /*
                    fprintf(fp,"\n");
                    fprinttreepart(fp,t,60,300);
                    fprintf(fp,"\n");
                    */
                    break;
                  case 'l':
                    /*
                    fprintf(fp,"\n");
                    fprintlin(fp,t);
                    fprintf(fp,"\n");
                    */
                    break;
                  default:
                    errfunc0(funcname);
                    fprintf(erf(),"Unknown expression form \'%c\' after the \"$\\\" sequence.\n",ch);
                    errfunc2();
                    fiwaituser(com);
                    break;
                }
              }
            } else
            {
              errfunc0(funcname);
              fprintf(erf(),"Variable name not specified.\n");
              errfunc2();
              fiwaituser(com);
            }
            break;
          default:
            /* Izpis vrednosti spremenljivke; Najprej se prebere ime
            spremenljivke: */
            /* Dolzina imena spremenljivke: */
            pos1=filecharto(com->fp," $\"\n\r\t\0",7,pos,to,buflength);
            if (pos>0)
            {
              if (pos1>pos)
                length=pos1-pos;
              else
                length=to+1-pos;
            } else
              length=0;
            if (length<=0)
            {
              errfunc0(funcname);
              fprintf(erf(),"Variable name not specified after the \'$\' sign.\n");
              errfunc2();
              fiwaituser(com);
            } else
            {
              /* Prebere se ime spremenljivke, ki se izpise: */
              /*
              str=malloc(length+1);
              fileread(str,sizeof(char),length,com->fp,pos);
              str[length]='\0';
              t=findobjname( (stack) com->syst->def,str);
              */
              pos+=length;
              /*
              if (t!=NULL)
              {
                x=doubleval(t,com->syst->fst,com->syst->user);
                fprintf(fp,"%*.*g",outchar,m_outdig,x);
              }
              */
            }
            break;
        }
      }
    }
}
}



void fi_write1default(char *funcname,FILE *fp,long from,long to,ficom com)
    /* Funkcija za izpis, ki jo uporabljata fi_write in fi_fwrite. V datoteko
    fp se zapisejo stvari, kot je zapisano v interpretirani datoteki com->fp
    med pozicijama from in to. Posamezni izpisi morajo biti loceni
    z vejicami ali presledki (lahko tudi z znakom za novo vrstico), presledek
    je obvezen tudi za zadnjim izpisom !!! Niz znakov, ki je med znakoma "",
    se izpise dobesedno. Znak, ki sledi znaku '\', pomeni izpis posebnega
    znaka, in sicer pomeni \" izpis dvoj. narekovaja, \n izpis znaka newline
    \r izpis znaka carriage return, \0 izpis nictega znaka.
      Znak '$' ukazuje izpis spremenljivke ali vrednosti izraza iz sistema za
    ovrednotenje izrazov, s katerim je podprt interpreter. Ce temu znaku sledi
    znak '{', se izpise trenutna vrednost izraza, ki je v zavitih oklepajih
    (oklepaj mora biti v tem primeru zakljucen, v njem pa izraz). Ce znaku '$'
    sledi znak '\', mora le-temu slediti se crka, ki je specifikacija formata,
    nato pa se ime spremenljivke. V tem primeru se izpise definicija
    spremenljivke sistema za ovrednotenje izrazov v formatu, ki ga narekuje
    specifikacija. Ce je specifikacija 't', se izpise definicija v okrnjeni
    drevesni obliki, ce je 'f', se izpise v neokrnjeni drevesni obliki, ce je
    'p', se izpise v delno okrnjeni drevesni obliki, ce je 'l' se izpise
    linijsko. Ce znaku '$' sledi znak, ki ni enak '{' ali '\', se izpise vrednost
    spremenljivke, katere ime sledi znaku '$'. V vseh primerih se presledki
    ignorirajo.
      Primer: Ce imamo v datoteki com->fp ukaz
    write{"Spremenljivka a1: " & a1 \n } in ima spremenljivka a1 tedaj vrednost
    12.3, se v datoteko fp zapise "Spremenljivka a1: 12.3\n" .
    $A Igor <== jun97 apr98 sep99; */
{
long pos,pos1,pos2;
char ch,ch1,*str,*expression;
int buflength=20;
int length;
double x,val;
object t;
if(fp!=NULL)
{
  pos=from;
  while (pos>0)
  {
    /* Najprej se poisce eneha od znakov '$', '\\' ali '\"' :*/
    pos1=pos;
    pos=filecharto(com->fp,"\"$\\",3,pos1,to,buflength);
    pos2=filenotcharto(com->fp," \n\r\t\0",5,pos1,to,buflength);
    if ((pos<=0 && pos2>0) || (pos>0 && pos2>0 && pos2<pos))
    {
      pos1=pos2;
      if (pos<=0)
      {
        pos2=to+1;
        pos=pos2;
      }
      else
        pos2=pos;
      length=pos2-pos1;
      if (length>0)
      {
        str=makestring(length);
        fileread(str, sizeof(char),length,com->fp,pos1);
        str[length]='\0';
        errfunc0(funcname);
        fprintf(erf(),"Undefined sequence \"%s\".\n",str);
        errfunc2();
        free(str);
      }
    }
    /* Potem se ta znak prebere v ch: */
    if (pos>0)
    {
      fileread(&ch, sizeof(char),1,com->fp,pos);
      switch (ch)
      {
        case '\"':
          /* Izpis niza med dvojnima narekovajema */
          ++ pos;
          pos1=filecharto(com->fp,"\"",1,pos,to,buflength);
          /* Za primer, ce manjka zakljucni narekovaj niza: */
          if (pos1<=0)
          {
            pos1=to+1;
            errfunc0(funcname);
            fprintf(erf(),"\" is missing at the end of string.\n");
            errfunc2();
          }
          length=pos1-pos;
          if (length>0)
          {
            str=malloc(length+1);
            fileread(str, sizeof(char),length,com->fp,pos);
            str[length]='\0';
            updatespecchar(str);
            fprintf(fp,"%s",str);
            free(str); str=NULL;
            pos=pos1+1;
          } else
            pos=-1;
          break;
        case '\\':
          /* Izpis posebnega znaka; doloca ga znak, ki sledi znaku '\\' . */
          ++ pos;
          if (pos>=to+1)
          {
            errfunc0(funcname);
            fprintf(erf()," Character specification is missing after the \\ control.\n");
            errfunc2();
          } else
          {
            fileread(&ch, sizeof(char),1,com->fp,pos);
            ch1=specialcharacter(ch);
            if (ch1=='0')
            {
              /* Napaka: specifikacija ne predstavlja posebnega znaka */
              errfunc0(funcname);
              fprintf(erf(),"Unknown character specification \'%c\'.\n",ch);
              errfunc2();
            } else
              fprintf(fp,"%c",ch1);  /* Ustrezen poseb. znak izpisemo v fp: */
          }
          ++ pos;
          break;
        case '$':
          pos=filenotcharto(com->fp," \n\r\t\0",5,pos+1,to,buflength);
          fileread(&ch, sizeof(char),1,com->fp,pos);
          switch (ch)
          {
            case '{':
              expression=NULL;
              filebracto(com->fp,'{','}',pos,to,30,&pos1,&pos2);
              if (pos1<=0 || pos2<=pos1+1)
              {
                errfunc0(funcname);
                fprintf(erf(),"Error in function %s: Expression is missing after the \"${\" sequence.\n");
                errfunc2();
              } else
              {
                /* Prebere se izraz, ki ga potem ovrednotimo v okviru sistema za
                simbolno racunanje: */
                length=pos2-pos1-1;
                expression=malloc(length+1); /* En byte je za zakljucni znak '\0'. */
                fileread(expression,sizeof(char),length,com->fp,pos1+1);
                expression[length]='\0'; /* Ker se steje od 0 */
                /* Nato se izraz ovrednoti glede na sistem za simbol. racunanje: */
                if (expression!=NULL)
                {
                  val=evaluateexp(com->syst,expression);
                  if (m_avoidexp)
                    fprintf(fp,"%-*.*f",outchar,m_outdig,val);
                  else
                    fprintf(fp,"%-*.*g",outchar,m_outdig,val);
                  free(expression);
                }
              }
              if (pos1>0 && pos2>0)
                pos=pos2+1;
              break;
            case '\\':
              fileread(&ch,sizeof(char),1,com->fp,pos+1);
              pos+=2;
              pos=filenotcharto(com->fp," \n\r\t\0",5,pos,to,buflength);
              pos1=filecharto(com->fp," $\"\\\n\r\t\0",8,pos,to,buflength);
              if (pos>0)
              {
                if (pos1>pos)
                  length=pos1-pos;
                else
                  length=to+1-pos;
              } else
                length=0;
              if (length>0)
              {
                /* Prebere se ime spremenljivke: */
                str=malloc(length+1); /* En byte je za zakljucni znak '\0'. */
                fileread(str,sizeof(char),length,com->fp,pos);
                str[length]='\0'; /* Ker se steje od 0 */
                t=findobjname( (stack) com->syst->def,str);
                pos+=length;
                if (t==NULL)
                {
                  errfunc0(funcname);
                  fprintf(erf(),"Variable \"%s\" not defined.\n",str);
                  errfunc2();
                }
                {
                  switch(ch)
                  {
                    case 't':
                      fprintf(fp,"\n");
                      fprinttree(fp,t,60,130);
                      fprintf(fp,"\n");
                      break;
                    case 'f':
                      fprintf(fp,"\n");
                      fprinttreefull(fp,t,60,200);
                      fprintf(fp,"\n");
                      break;
                    case 'p':
                      fprintf(fp,"\n");
                      fprinttreepart(fp,t,60,300);
                      fprintf(fp,"\n");
                      break;
                    case 'l':
                      fprintf(fp,"\n");
                      fprintlin(fp,t);
                      fprintf(fp,"\n");
                      break;
                    default:
                      errfunc0(funcname);
                      fprintf(erf(),"Unknown expression form \'%c\' after the \"$\\\" sequence.\n",ch);
                      errfunc2();
                      break;
                  }
                }
              } else
              {
                errfunc0(funcname);
                fprintf(erf(),"Variable name not specified.\n");
                errfunc2();
              }
              break;
            default:
              /* Izpis vrednosti spremenljivke; Najprej se prebere ime
              spremenljivke: */
              /* Dolzina imena spremenljivke: */
              pos1=filecharto(com->fp," $\"\\\n\r\t\0",8,pos,to,buflength);
              if (pos>0)
              {
                if (pos1>pos)
                  length=pos1-pos;
                else
                  length=to+1-pos;
              } else
                length=0;
              if (length<=0)
              {
                errfunc0(funcname);
                fprintf(erf(),"Variable name not specified after the \'$\' sign.\n");
                errfunc2();
              } else
              {
                /* Prebere se ime spremenljivke, ki se izpise: */
                str=malloc(length+1); /* En byte je za zakljucni znak '\0'. */
                fileread(str,sizeof(char),length,com->fp,pos);
                str[length]='\0'; /* Ker se steje od 0 */
                t=findobjname( (stack) com->syst->def,str);
                pos+=length;
                if (t!=NULL)
                {
                  /* Izpis vrednosti spremenljivke */
                  x=doubleval(t,com->syst->fst,com->syst->user);

                  if (m_avoidexp)
                    fprintf(fp,"%-*.*f",outchar,m_outdig,x);
                  else
                    fprintf(fp,"%-*.*g",outchar,m_outdig,x);
                }
              }
              break;
          }
        }
      }
  }
  fflush(fp);
}
}




/* Pomozne spremenljivke in funkcije za nastavitev funkcij ficheck_write1 in
fi_write1: */

static void (*ficheck_write1ptr) (char *funcname,long from,long to,ficom com)
           = ficheck_write1default;

static void (*fi_write1ptr) (char *funcname,FILE *fp,long from,long to,ficom com)
            = fi_write1default;


void setficheck_write1(void (*func) (char *funcname,long from,long to,ficom com))
    /* Postavi funkcijo, ki se klice v ficheck_write1, na func.
    $A Igor nov99; */
{
ficheck_write1ptr=func;
}

void setfi_write1(void (*func) (char *funcname,FILE *fp,long from,long to,ficom com))
    /* Postavi funkcijo, ki se klice v fi_write1, na func.
    $A Igor nov99; */
{
fi_write1ptr=func;
}

void ficheck_write1(char *funcname,long from,long to,ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_write1 v ukazni
    datoteki. From in to sta zacetna in koncna pozicija odseka v ukazni
    datoteki, kjer so zapisana navodila za to, kaj naj se izpise.
    Funkcija klice funkcijo, na katero kaze fi_write1ptr, ta pa originalno kaze
    na fi_write1defaunlt, kar se lahko spremeni s funkcijo setfi_write1.
    $A Igor nov99; */
{
ficheck_write1ptr(funcname,from,to,com);
}

void fi_write1(char *funcname,FILE *fp,long from,long to,ficom com)
    /* Funkcija za izpis, ki jo uporabljata fi_write in fi_fwrite. V datoteko
    fp se zapisejo stvari, kot je zapisano v interpretirani datoteki com->fp
    med pozicijama from in to.
    Funkcija klice funkcijo, na katero kaze fi_write1ptr, ta pa originalno kaze
    na fi_write1defaunlt, kar se lahko spremeni s funkcijo setfi_write1.
    $A Igor nov99; */
{
fi_write1ptr(funcname,fp,from,to,com);
}



static void ficheck_fwrite(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_fwrite v ukazni
    datoteki.
    $A Igor sep99; */
{
  ficheck_write1("fi_fwrite",com->begin+1,com->end-1,com);
}


static void fi_fwrite(ficom com)
       /* Izpis na datoteko com->outfile(com) s funkcijo fi_write1 */
{
if (com->outfile(com)!=NULL)
  fi_write1("fi_fwrite",com->outfile(com),com->begin+1,com->end-1,com);
}


static void ficheck_write(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_write v ukazni
    datoteki.
    $A Igor jul98 sep99; */
{
  ficheck_write1("fi_write",com->begin+1,com->end-1,com);
}

static void fi_write(ficom com)
       /* Izpis na stanadardni izhod s funkcijo fi_write1 */
{
fi_write1("fi_write",stdout,com->begin+1,com->end-1,com);
}


static void ficheck_dwrite(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_dwrite v ukazni
    datoteki.
    $A Igor sep99; */
{
  ficheck_write1("fi_dwrite",com->begin+1,com->end-1,com);
}

static void fi_dwrite(ficom com)
       /* Hkratni izpis na datoteko com->outfile(com) in na standardni izhod s funkcijo
       fi_write1
       $A Igor jul98; */
{
if (com->outfile(com)!=NULL)
  fi_write1("fi_dwrite",com->outfile(com),com->begin+1,com->end-1,com);
fi_write1("fi_dwrite",stdout,com->begin+1,com->end-1,com);
}



static void ficheck_fileappend(ficom com)
       /* Izpis na datoteko z imenom, ki je podano v narekovajih takoj na
       zacetku navedbe parametrov, s funkcijo fi_write1 */
{
int buflength=20;
long pos1,pos2;
pos1=filecharto(com->fp,"\"",1,com->begin+1,com->end-1,buflength);
pos2=filecharto(com->fp,"\"",1,pos1+1,com->end-1,buflength);
if (pos1<=0 || pos2<=0 || pos2<=pos1+1)
{
  err0();
  fprintf(erf(),"File name not defined.\n");
  err2();
  fiwaituser(com);
} else
{
  com->begin=pos2;
  ficheck_write1("fi_fileappend",com->begin+1,com->end-1,com);
}
}

static void fi_fileappend(ficom com)
       /* Izpis na datoteko z imenom, ki je podano v narekovajih takoj na
       zacetku navedbe parametrov, s funkcijo fi_write1 */
{
int buflength=20;
long pos1=0,pos2=0;
int length=0;
char *str;
FILE *fp;
pos1=filecharto(com->fp,"\"",1,com->begin+1,com->end-1,buflength);
pos2=filecharto(com->fp,"\"",1,pos1+1,com->end-1,buflength);
if (pos1<=0 || pos2<=0 || pos2<=pos1+1)
{
  errfunc0("fi_fileappend");
  fprintf(erf(),"File name not defined.\n");
  err2();
} else
{
  length=pos2-pos1-1;
  str=malloc(length+1);
  fileread(str, sizeof(char),length,com->fp,pos1+1);
  str[length]='\0';
  fp=fopen(str,"ab+");
  disppointer((void **) &str);
  if (fp!=NULL)
  {
    com->begin=pos2;
    fi_write1("fi_fileappend",fp,com->begin+1,com->end-1,com);
    fclose(fp);
  }
}
}


static void ficheck_waituser(ficom fcom)
    /* Preveri sintakso argumentov pri fi_waituser.
    $A Igor sep99; */
{
long pos;
pos=filenotcharto(fcom->fp," \n\r\t\0",5,fcom->begin+1,fcom->end-1,10);
if (pos>0)
{
  printf("\n\nWarning in function fi_waituser: Function takes no arguments.\n\n");
  if (fcom->outfile(fcom)!=NULL)
    fprintf(fcom->outfile(fcom),"\n\nWarning in function fi_waituser: Function takes no arguments.\n\n");
}
}

static void fi_waituser(ficom fcom)
    /* Preveri sintakso argumentov pri fi_waituser.
    $A Igor sep99; */
{
printf("\n<< Press return to continue! >>\n\n");
getchar();
}


static void ficheck_waitusernote(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_waitusernote v ukazni
    datoteki.
    $A Igor sep99; */
{
  ficheck_write1("fi_waitusernote",com->begin+1,com->end-1,com);
}

static void fi_waitusernote(ficom fcom)
    /* Izpise sporocilo za uporabnika in pocaka, da ta pritisne return.
    Kot sporocilo se izpise to, kar narekujejo argumenti ustrezne funkcije
    interpreterja. Razlika glede na fi_usernote je v tem, da se ne doda
    navodilo, da je potrebno za nadaljevanje izvajanja programa pritisniti
    enter (pricakuje se, da je to del sporocila).
    $A Igor sep99; */
{
fi_write1("fi_waitusernote",stdout,fcom->begin+1,fcom->end-1,fcom);
getchar();
}



static void ficheck_usernote(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_usernote v ukazni
    datoteki.
    $A Igor sep99; */
{
  ficheck_write1("fi_usernote",com->begin+1,com->end-1,com);
}

static void fi_usernote(ficom fcom)
    /* Izpise sporocilo za uporabnika in pocaka, da ta pritisne return.
    Kot sporocilo se izpise to, kar narekujejo argumenti ustrezne funkcije
    interpreterja, pri cemer se doda navodilo, da je potrebno za nadaljevanje
    izvajanja programa pritisniti enter. Pred izpisom sporocila se se doda
    dve prazni vrstici.
    $A Igor sep99; */
{
printf("\n\n");
fi_write1("fi_usernote",stdout,fcom->begin+1,fcom->end-1,fcom);
printf("fi_usernote","\n<< Press return to continue! >>\n\n");
getchar();
}



static void ficheck_system(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_system ali
    fi_systempar v ukazni datoteki.
    $A Igor apr98; */
{
long pos1,pos2;
int buflength=20;
int length=0;
pos1=filecharto(com->fp,"\"",1,com->begin+1,com->end-1,buflength);
if (pos1>0)
  pos2=filecharto(com->fp,"\"",1,pos1+1,com->end-1,buflength);
if (pos1>0 && pos2>pos1+1)
{
  /* Ce sta med com->begin in com->end vsaj dva dvojna narekovaja, potem je
  ukaz niz med tema dvema narekovajema: */
  ++ pos1;
  length=pos2-pos1;
} else
{
  pos1=com->begin+1;
  length=com->end-pos1;
}
if (pos1<=0 || length<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Execution string not defined for system command\n");
  err2();
  fiwaituser(com);
}
}


static void fi_system(ficom com)
    /* Izvrsi sistemski ukaz, ki je zapisan v datoteki com->fp med com->begin
    in com->end. Ni nujno, da je ukaz v narekovajih. Ce pa je, potem se kot
    ukaz smatra le tisto, kar je med dvojnima narekovajema.*/
{
long pos1,pos2;
int buflength=20;
int length=0;
char *command;
pos1=filecharto(com->fp,"\"",1,com->begin+1,com->end-1,buflength);
if (pos1>0)
  pos2=filecharto(com->fp,"\"",1,pos1+1,com->end-1,buflength);
if (pos1>0 && pos2>pos1+1)
{
  /* Ce sta med com->begin in com->end vsaj dva dvojna narekovaja, potem je
  ukaz niz med tema dvema narekovajema: */
  ++ pos1;
  length=pos2-pos1;
} else
{
  pos1=com->begin+1;
  length=com->end-pos1;
}
if (pos1<=0 || length<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Execution string not defined for system command\n");
  err2();
} else
{
  command=makestring(length);
  fileread( (void *) command,1,length,com->fp,pos1);
  command[length]='\0';
  system(command);
  free(command);
}
}






static void fi_systempar(ficom com)
    /* V samostojnem oknu vzporedno s tekocim programom izvrsi sistemski
    ukaz, ki je zapisan v datoteki com->fp med com->begin in com->end. Ni
    nujno, da je ukaz v narekovajih. Ce pa je, potem se kot ukaz smatra le
    tisto, kar je med dvojnima narekovajema.*/
{
long pos1,pos2;
int buflength=20;
int length=0;
char *command,*cm1=NULL,*cm2=NULL;
pos1=filecharto(com->fp,"\"",1,com->begin+1,com->end-1,buflength);
if (pos1>0)
  pos2=filecharto(com->fp,"\"",1,pos1+1,com->end-1,buflength);
if (pos1>0 && pos2>pos1+1)
{
  /* Ce sta med com->begin in com->end vsaj dva dvojna narekovaja, potem je
  ukaz niz med tema dvema narekovajema: */
  ++ pos1;
  length=pos2-pos1;
} else
{
  pos1=com->begin+1;
  length=com->end-pos1;
}
if (pos1<=0 || length<=0)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Execution string not defined for system command\n");
  err2();
} else
{
  command=makestring(length);
  fileread( (void *) command,1,length,com->fp,pos1);
  command[length]='\0';
  globutsystempar(command);
  /*
  cm1=stringcat("xterm -title SystemPar -sb -bg black -fg green -cr red -e ",
   command);
  cm2=stringcat(cm1," &");
  system(cm2);
  free(cm1);
  free(cm2);
  */
  free(command);
}
}



static void ficheck_returndouble(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije return v ukazni
    datoteki.
    $A Igor apr98; */
{
if (com!=NULL)
{
  if (com->fp==NULL || com->begin<=0 || com->end<=com->begin+1)
  {
    err0();
    fprintf(erf(),"FILE INTERPRETER: Expression not defined.\n");
    err2();
    fiwaituser(com);
  }
}
}

static void fi_returndouble(ficom com)
    /* V com->ret zapise vrednost matematicneka izraza, ki je argument
    funkcije. Funkcija se uporablja pri definiciji funkcij kalkulatorja s
    pomocjo datotecnega interpreterja.
    $A Igor jun97; */
{
int length;
char *expression=NULL;
if (com!=NULL)
{
  if (com->fp==NULL || com->begin<=0 || com->end<=com->begin+1)
  {
    err0();
    fprintf(erf(),"FILE INTERPRETER: Expression not defined.\n");
    err2();
  } else
  {
    length=com->end-com->begin-1;
    expression=makestring(length);
    fileread(expression,1,length,com->fp,com->begin+1);
    com->doubleret=evaluateexp(com->syst,expression);
    if (expression!=NULL)
      free(expression);
  }
}
}



static double userfinumargs(object obj,stack st,stack user,int numargs,
              void *ptr)
    /* Vrne stevilo argumentov funkcije kalkulatorja, ki je bila definirana s
    pomocjo datotecnega interpreterja. Ta podatek dobi prek ptr, ki je kazalec
    tipa ficom in kaze na strukturo, ki dooca interpretacijo datoteke (to je
    treba zagotoviti pri instalaciji te funkcije v sistem datotecnega
    interpreterja z installuserfunc(). Funkcija se v sistemu kalkulatorja klice
    brez argumentov. Koncepti definicije funkcij kalkulatorja, ki so definirane
    prek ukazne datoteke interpreterja, zagotavljajo, da je med interpretacijo
    definicije stevilo argumentov v ptr->numargs postavljeno na pravo vrednost.
    $A Igor jun97; */
{
ficom com;
if (ptr!=NULL)
{
  com=ptr;
  return com->numargs;
} else
  return 0;
}


static double userfiarg(object obj,stack st,stack user,int numargs,void *ptr)
    /* Vrne vrednost zahtevanega argumenta funkcije kalkulatorja, ki je
    definirana prek interpreterja. Klic te funkcije je smiselen le znotraj
    interpretacije bloka, ki definira teksno funkcijo, torej med izvajanjem
    ovrednotenja te funkcije. Pri klicu mora biti edini argument zaporedna
    stevilka argumenta funkcije, definirane v ukazni datoteki interpreterja.
    $A Igor jun97; */
{
object oo=NULL;
ficom com;
stack args;
double xx,ret=0;
int num=0;
/* Ta funkcija je bila klicana z vsaj enim argumentom; Ovrednoti se njen
1. argument, ki pomeni zaporedno stevilko argumenta na skladu ptr->args,
katerega vrednost mora funkcija vrniti: */
if (numargs>0)
  oo=nstack((stack)st, 1 );
if (oo!=NULL)
  xx=doubleval(oo,st,user);
num=(int) xx;
if (ptr!=NULL)
{
  if (numargs>0)
  {
    /* Ovrednoti se zahtevani argument na skladu ptr->args, na katerem morajo
    biti argumenti funkcije kalkulatorja, ki je definirana prek interpreterja: */
    if (num>0)
    {
      com=ptr;
      args=com->args;
      if (args!=NULL)
        if (args->n>=num)
        {
          oo=nstack(st,num+numargs); /* +num zato, da preskocimo argumente te
           funkcije same. */
          ret=doubleval(oo,st,user);
        } else ret=infinity();
    } else ret=infinity();
  } else ret=infinity();
} else ret=infinity();
/*
printf("Vrednost %i. argumenta je %g.\n",num,ret);
*/
return ret;
}



static double userfideffunc(object obj,stack st,stack user,int numargs,
              void *ptr)
    /* Funkcija, ki se izvede pri klicu funkcije kalkulatorja, ki je definirana
    v ukazni datoteki interpreterja. Glavni del izvedbe funkcije je
    interpretacija ustreznega bloka v ukazni datoteki, ki vsebuje definicijo
    klicane funkcije. Podatki o tem bloku so v ptr.
    $A Igor jun97 mar99; */
{
fifuncdata data;
ficom fcom;
char oldstepover;
double ret=0;
if (ptr!=NULL)
{
  data=ptr;
  if (data->fcom!=NULL)
  {
    stack args0;
    int numargs0;
    fcom=data->fcom;
    /* Najprej se shraneta stari sklad in stevilo argumentov: */
    args0=fcom->args;  numargs0=fcom->numargs;
    /* Sklad arg. in st. argumentov se postavita na st in numargs: */
    fcom->args=st; fcom->numargs=numargs;
    /* Interpretira se definicija funkcije: */
    oldstepover=fcom->stepover;
    fcom->stepover=0;
    if (fcom->trace)
    {
      if (fcom->callst==NULL)
        fcom->callst=newstack(20);
      pushstack(fcom->callst,"*Calc");
      pushstack(fcom->callst,data->name);
      fintfileblock(fcom,data->filename,data->begin+1,data->end-1);
      popstack(fcom->callst);
      popstack(fcom->callst);
    } else
    {
      fintfileblock(fcom,data->filename,data->begin+1,data->end-1);
    }
    fcom->stepover=oldstepover;
    ret=fcom->doubleret; /* to mora biti nastavljeno v definiciji funkcije */
    /* Restavrirata se prvotni sklad in stevilo argumentov na fcom: */
    fcom->args=args0; fcom->numargs=numargs0;
  } else ret=infinity();
} else ret=infinity();
return ret;
}






static void ficheck_userfunc(ficom com)
    /* Funkcija, ki preveri sintakso funkcije fi_userfunc v ukazni datoteki
    datotecnega interpreterja.
    $A Igor apr98; */
{
long begin,end,length,pos;
int buflength1=30,buflength2=1000,buflength;
buflength=flength(com->fp)/10;
if (buflength>0 && buflength<buflength2)
  buflength2=buflength;
/* Najprej se prebere ime funkcije, ki jo definiramo v datoteki: */
pos=filenotcharto(com->fp," \n\r\t\"\0",6,com->begin+1,com->end-1,5);
begin=0;
if (pos>0)
  filebracto(com->fp,com->expbrac1,com->expbrac2,com->begin+1,com->end-1,
   buflength1,&begin,&end);
if (pos>0 && pos!=begin)
{
  /* Ime ni v okroglih oklepajih: */
  begin=pos;
  end=filecharto(com->fp," \n\r\t\"\0",6,begin,com->end-1,buflength1);
  if (end<1)
    end=com->end;
} else if (begin>0)
{
  /* Ime je v okroglih oklepajih: */
  begin=filenotcharto(com->fp," \n\r\t\"\0",6,begin+1,end-1,5);
  if (begin>0)
  {
    pos=filecharto(com->fp," \n\r\t\"\0",6,begin,end-1,5);
    if (pos>0)
      end=pos;
  }
}
if (begin<=0 || end<=begin)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Unspecified function name in the evaluator function definition.\n");
  err2();
  fiwaituser(com);
} else
{
  length=end-begin;
  if (1)
  {
    filebracto(com->fp,com->blockbrac1,com->blockbrac2,end+1,com->end-1,
     buflength2,&begin,&end); /* polozaj definicijskega bloka */
    if (begin<=0 || end<=0)
    {
      err0();
      fprintf(erf(),"FILE INTERPRETER: No execution block in the evaluator function definition.\n");
      err2();
      fiwaituser(com);
    } else
    {
      /* Preveriti je treba tudi izvrsni blok definicije: */
      fintblock(com,begin+1,end-1);
    }
  }
}
}


static void fi_userfunc(ficom com)
    /* Funkcija datotecnega interpreterja, ki prek interpreterja definira novo
    funkcijo kalkulatorja. Pri klicu funkcije v interpreterju mora biti v
    argumentnem bloku funkcije najprej v okroglem oklepaju navedeno ime
    funkcije, nato pa v oglatih oklepajih blok, ki vsebuje definicijo funkcije.
    Ta blok se interpretira pri vsakem klicu funkcije. Obvezno mora biti na
    koncu tega bloka klic funkcije "return", ki doloca, kaj bo funkcija vrnila
    ob klicu (argumentni blok funkcije "return" mora biti izraz, katerega
    vrednost bo funkcija vrnila). Vrednosti argumentov funkcije ob njenem klicu
    lahko dobimo znotraj definicijskega bloka s funkcijo kalkulatorja "arg",
    katere edini argument je zaporedna stevilka argumenta, stevilo argumentov
    pa dobimo s funkcijo kalkulatorja "numargs", ki nima argumentov.
    PRIMER definicije funkcije kalkulatorja v ukazni datoteki interpreterja:
      definefunction{ sumargs
      [
        ={i:1} ={ret:0}
        while { (i<=numargs[]) [ ={ret:ret+arg[i]} ={i:i+1} ] }
        return {ret}
      ]}
    Pri tej definiciji ima recimo izraz
      sumargs(12,4,8)
    vrednost 12+4+8=24.
    $A Igor jun97 dec97; */
{
fifuncdata data=NULL;
long begin,end,length,pos;
char *name=NULL;
int buflength1=30,buflength2=1000,buflength;
buflength=flength(com->fp)/10;
if (buflength>0 && buflength<buflength2)
  buflength2=buflength;
/* Najprej se prebere ime funkcije, ki jo definiramo v datoteki: */
pos=filenotcharto(com->fp," \n\r\t\"\0",6,com->begin+1,com->end-1,5);
begin=0;
if (pos>0)
  filebracto(com->fp,com->expbrac1,com->expbrac2,com->begin+1,com->end-1,
   buflength1,&begin,&end);
if (pos>0 && pos!=begin)
{
  /* Ime ni v okroglih oklepajih: */
  begin=pos;
  end=filecharto(com->fp," \n\r\t\"\0",6,begin,com->end-1,buflength1);
  if (end<1)
    end=com->end;
} else if (begin>0)
{
  /* Ime je v okroglih oklepajih: */
  begin=filenotcharto(com->fp," \n\r\t\"\0",6,begin+1,end-1,5);
  if (begin>0)
  {
    pos=filecharto(com->fp," \n\r\t\"\0",6,begin,end-1,5);
    if (pos>0)
      end=pos;
  }
}
if (begin<=0 || end<=begin)
{
  err0();
  fprintf(erf(),"FILE INTERPRETER: Unspecified function name in the evaluator function definition.\n");
  err2();
} else
{
  length=end-begin;
  name=malloc(length+1);
  fileread(name,sizeof(char),length,com->fp,begin);
  name[length]='\0';
  if (name!=NULL)
  {
    filebracto(com->fp,com->blockbrac1,com->blockbrac2,end+1,com->end-1,
     buflength2,&begin,&end); /* polozaj definicijskega bloka */
    if (begin<=0 || end<=0)
    {
      err0();
      fprintf(erf(),"FILE INTERPRETER: No execution block in the evaluator function definition.\n");
      err2();
    } else
    {
      /* Instalacija definirane funkcije; Tvori se podatkovna struktura, v
      kateri so kazalec na com ter zacetek in konec definicijskega bloka.
      Instalacija v sistem kalkulatorja se izvede s klicem installuserfunc(),
      kjer je 3. argument funkcija userfideffunc(), 4. pa kazalec na tvorjeno
      podatkovno strukturo. Nova struktura tipa fifuncdata, ki se tvori,
      se da tudi na sklad com->funcdefstack, da se lahko definirana funkcija
      deaktivira, ce zapremo interpretacijo datoteke, ki ji pripada com: */
      data=malloc(sizeof(*data));
      /*
      data->name=NULL;
      */
      data->name=stringcopy(name);
      data->argnames=NULL;
      data->fcom=com;
      data->filename=stringcopy(com->filename);
      data->begin=begin;
      data->end=end;
      /*
      pushstack(com->funcdefstack,data);
      */
      inssortstack(com->funcdefstack,data,cmpfifuncdata);
      if (com->syst!=NULL)
      {
        installuserfunc(com->syst,name,userfideffunc,data,NULL,NULL);
      }
    }
  }
}
if (name!=NULL)
  free (name);
}




static void ficheck_interpretfile(ficom com)
    /* Kontrolna funkcija, ki preveri sintakso funkcije fi_interpretfile
    v ukazni datoteki.
    $A Igor apr98; */
{
long pos1,pos2;
int length;
if (com->begin<=0 && com->end<=com->begin+1)
{
  errfunc0("ficheck_interpretfile");
  fprintf(erf(),"File not specified.\n");
  err2();
  fiwaituser(com);
} else
{
  pos1=filenotcharto(com->fp," \n\r\t\"",5,com->begin+1,com->end-1,5);
  if (pos1<=0)
    pos1=com->begin+1;
  pos2=filecharto(com->fp," \n\r\t\"",5,pos1+1,com->end-1,12);
  if (pos2<=0)
    pos2=com->end;
  length=pos2-pos1;
  if (length<=0)
  {
    errfunc0("ficheck_interpretfile");
    fprintf(erf(),"File not specified properly.\n");
    err2();
    fiwaituser(com);
  }
}
}


static void fi_interpretfile(ficom com)
    /* Interpretacija datoteke, katere ime je argument funkcije datotecnega
    interpreterja. */
{
long pos1,pos2;
int length;
char *name=NULL,oldstepover,*origfilename;
if (com->begin<=0 && com->end<=com->begin+1)
{
  errfunc0("fi_interpretfile");
  fprintf(erf(),"File not specified.\n");
  err2();
} else
{
  pos1=filenotcharto(com->fp," \n\r\t\"",5,com->begin+1,com->end-1,5);
  if (pos1<=0)
    pos1=com->begin+1;
  pos2=filecharto(com->fp," \n\r\t\"",5,pos1+1,com->end-1,12);
  if (pos2<=0)
    pos2=com->end;
  length=pos2-pos1;
  if (length<=0)
  {
    errfunc0("fi_interpretfile");
    fprintf(erf(),"File not specified properly.\n");
    err2();
  } else
  {
    name=makestring(length);
    fileread(name,sizeof(char),length,com->fp,pos1);
    name[length]='\0';
    /* Ime originalne datoteke shranemo za poznejso restavracijo in ga
    postavimo na NULL, ker bo sedaj interpretirana koda gotovo v originalni
    datoteki: */
    origfilename=com->origfilename;
    com->origfilename=NULL;
    /* Interpretacija datoteke: */
    oldstepover=com->stepover;
    com->stepover=0;
    fintfile(com,name);
    com->stepover=oldstepover;
    com->origfilename=origfilename;
    if (name!=NULL)
      free(name);
  }
}
}


/* Pomozni podatki za delovanju uporabnisko definiranih funkcij datotecnega
interpreterja: */
static char *deffuncname=NULL;
static stack deffuncargs=NULL;


static void fi_function(ficom com)
    /* Izvedba funkcije datotecnega interpreterja, ki je bila definirana v
    interpreterju s funkcijo "function" (ustrezna funkcija v kodi je
    fi_funcdef).
    $A Igor jun97 maj98 apr99; */
{
stack arguments=NULL,argnames=NULL,oldfuncargs;
fifuncdata ref,data=NULL;
long pos1,pos2,lengthfp1,posbegin,origpos,beginpos,temppos;
int which,i,length=0;
char ok,ch,*argstr,*str=NULL,argmark1='#',argmark2='$',
      *funcname=NULL,*origfilename,
     *oldfuncname,oldstepover;
FILE *fp1=NULL;
fifunction func=NULL;
if (com!=NULL)
{
  temppos=com->temppos; /* shranemo pozicijo konca uporabnega dela com->temp */
  /* Iskanje podatkov o funkciji: */
  if (com->functions!=NULL)
    if (com->functions->n>=com->which)
    {
      func=com->functions->s[com->which];
      if (func!=NULL)
        funcname=func->name;
    }
  if (com->functionstack!=NULL)
    if (com->functionstack->n>0)
    {
      i=1;
      while(i<=com->functionstack->n && data==NULL)
      {
        ref=com->functionstack->s[i];
        if (ref!=NULL)
          if (cmpstrings(ref->name,funcname)==0)
            data=ref;
        ++i;
      }
    }
  if (data==NULL)
  {
    err0();
    fprintf(erf(),"Can't find definition of function %s.\n",funcname);
    err2();
  } else
  {
    /* Branje argumentov: */
    arguments=newstack(10);
    pos1=com->begin+1;
    while(pos1>0)
    {
      /* Najdemo 1. znak, ki ni presledek ali locilo: */
      pos1=filenotcharto(com->fp,", \n\r\t",5,pos1,com->end-1,5);
      if (pos1>0)
      {
        /* Preverimo, ali je najdeni znak morda '{' */
        fileread(&ch,sizeof(char),1,com->fp,pos1);
        if (ch=='{')
        {
          /* Argument je v zavitih oklepajih */
          filebracto(com->fp,'{','}',pos1,com->end-1,1000,&pos1,&pos2);
          ++pos1;
        } else
          pos2=filecharto(com->fp,", \n\r\t",5,pos1,com->end-1,16);
        if (pos2<=0)
          pos2=com->end;
        length=pos2-pos1; /* dolzina niza, ki predstavlja argument */
        if (length>0)
        {
          /* Prebere se niz, ki predstavlja argument, in se polozi na sklad: */
          argstr=makestring(length);
          fileread(argstr,sizeof(char),length,com->fp,pos1);
          argstr[length]='\0';
          pushstack(arguments,argstr);
        }
        if (ch=='{')
          pos1=pos2+1;
        else pos1=pos2;
      }
    }
    /* Izpis sklada argumentov: */
    /*
    if (1)
    {
      printf("\nFunction %s:\n",com->commands->s[com->which]);
      if (arguments==NULL)
        printf("  No arguments.\n");
      else
      {
        int i;
        if (arguments->n>0)
          for (i=1;i<=arguments->n;++i)
            printf("  %i. argument: \"%s\"\n",i,arguments->s[i]);
      }
      printf("\n");
    }
    */
    argnames=data->argnames;  /* Imena argumentov v definiciji funkcije */
    if (arguments!=NULL && argnames!=NULL)
      if (arguments->n<argnames->n)
      {
        err0();
        fprintf(erf(),"Function \"%s\" called with %i arguments (at least %i required).",
          funcname,arguments->n,argnames->n);
        err2();
      }
    /* Popravijo se podatki o tem, katera je originalna datoteka s kodo in o
    pozicijah kode v originalni datoteki: */
    /* Kopiranje definicijskega bloka funkcije v datoteko, pri cemer se
    zamenjajo imena argumentov funkcije z dejanskimi argumenti: */
    fp1=fopen(data->filename,"rb");
    /* fp2=fopen(tempname,"wb"); */
    fintpreparetemp(com);
    if (fp1!=NULL && com->temp!=NULL)
    {
      lengthfp1=flength(fp1);
      pos1=data->begin+1;
      fprintf(com->temp,"\n\n\n\n\n");
      posbegin=ftell(com->temp)+1;
      while (pos1>0 && pos1<data->end && pos1<=lengthfp1)
      {
        /* Poisce se naslednje ime argumenta v definicijskem bloku funkcije: */
        ch=' '; pos2=pos1;
        while ((ch!=argmark1 && ch!=argmark2) && pos2>0 && pos2<data->end)
        {
          pos2=nfilestringto(fp1,argnames,pos2,data->end-1,100,&which);
          if (pos2>0 && which>0)
            ch=filereadchar(fp1,pos2-1); /* 1. znak pred najdenim imenom */
          if (ch!=argmark1 && ch!=argmark2)
            ++pos2;
        }
        /* Ce smo nasli ime argumenta, pred katerim stoji oznaka argmark1 ali argmark2,
        se skopira del datoteke fp1 od pos1 do tega argumenta, namesto
        argumenta pa se vrine niz, ki predstavlja resnicni argument: */
        if (ch==argmark1 || ch==argmark2)
        {
          fcopyfilepart(fp1,pos1,pos2-2,com->temp,100); /* skopira se del do argumenta */
          pos1=pos2+strlen(argnames->s[which]);
          ok=0;
          if (arguments!=NULL) /* vrine se pravi argument  */
            if (arguments->n>=which)
              if (arguments->s[which]!=NULL)
              {
                ok=1;
                fwrite(arguments->s[which],1,strlen(arguments->s[which]),com->temp);
              }
          if (!ok)
          {
            err0();
            fprintf(erf(),"%i. argument not specified.\n",which);
            err2();
          }
        } else
        {
          pos2=data->end;
          fcopyfilepart(fp1,pos1,pos2-1,com->temp,100);
          pos1=pos2;
        }
      }
      fprintf(com->temp,"\n\n\n\n\n");
      com->temppos=ftell(com->temp)+1;
    } else
    {
      if (fp1==NULL)
      {
        err0();
        fprintf(erf(),"Can not open file \"%s\".\n",data->filename);
        err2();
      }
      if (com->temp==NULL)
      {
        err0();
        fprintf(erf(),"Can not open a temporary file.\n");
        err2();
      }
    }
    fclose(fp1);
    /* Najprej shranemo obstojece podatke o imenu in argumentih uporabnisko
    definirane funkcije in jih zamenjamo s podatki o funkciji, ki jo bomo
    izvedli; te podatke rabi funkcija usernumfuncargs, ki vrne stevilo
    argumentov, ter funkcija fi_update, ki izvrsi zapoznelo zamenjavo dejanskih
    argumentv funkcije. */
    oldfuncname=deffuncname;
    oldfuncargs=deffuncargs;
    deffuncname=funcname;
    deffuncargs=arguments;
    /* Postavimo podatke o originalni datoteki, poziciji zacetka bloka v tej
    datoteki in poziciji zacetka bloka v novi datteki; najprej shranemo stare
    podatke: */
    origfilename=com->origfilename;
    origpos=com->origpos;
    beginpos=com->beginpos;
    com->origfilename=data->filename;
    com->origpos=data->begin+1;
    com->beginpos=posbegin;
    /* Interpretacija prepisanega telesa definicije funkcije: */
    oldstepover=com->stepover;
    com->stepover=0;
    /* fintfile(com,tempname); */
    fintfblock(com,com->temp,com->tempname,com->beginpos,com->temppos-1);
    com->stepover=oldstepover;
    /* Restavriramo podatke o originalni datoteki in pozicijah: */
    com->origfilename=origfilename;
    com->origpos=origpos;
    com->beginpos=beginpos;
    /* Po interpretaciji restavriramo prejsnje podatke o uporabnisko definirani
    funkciji in pocistimo za sabo: */
    deffuncname=oldfuncname;
    deffuncargs=oldfuncargs;
  }
  com->temppos=temppos;
}
if (arguments!=NULL)
{
  dispstackval(arguments);
  dispstack(&arguments);
}
}


static void fi_functionold(ficom com)
    /* Izvedba funkcije datotecnega interpreterja, ki je bila definirana v
    interpreterju s funkcijo "function" (ustrezna funkcija v kodi je
    fi_funcdef).
    $A Igor jun97 maj98; */
{
stack arguments=NULL,argnames=NULL,oldfuncargs;
fifuncdata ref,data=NULL;
long pos1,pos2,lengthfp1,posbegin,origpos,beginpos;
int which,i,length=0;
char ok,ch,*argstr,*str=NULL,*tempname=NULL,argmark1='#',argmark2='$',
      *funcname=NULL,*origfilename,
     *oldfuncname,oldstepover;
FILE *fp1=NULL,*fp2=NULL;
fifunction func=NULL;
if (com!=NULL)
{
  /* Iskanje podatkov o funkciji: */
  if (com->functions!=NULL)
    if (com->functions->n>=com->which)
    {
      func=com->functions->s[com->which];
      if (func!=NULL)
        funcname=func->name;
    }
  if (com->functionstack!=NULL)
    if (com->functionstack->n>0)
    {
      i=1;
      while(i<=com->functionstack->n && data==NULL)
      {
        ref=com->functionstack->s[i];
        if (ref!=NULL)
          if (cmpstrings(ref->name,funcname)==0)
            data=ref;
        ++i;
      }
    }
  if (data==NULL)
  {
    err0();
    fprintf(erf(),"Can't find the definition of function %s.\n",funcname);
    err2();
  } else
  {
    /* Branje argumentov: */
    arguments=newstack(10);
    pos1=com->begin+1;
    while(pos1>0)
    {
      /* Najdemo 1. znak, ki ni presledek ali locilo: */
      pos1=filenotcharto(com->fp,", \n\r\t",5,pos1,com->end-1,5);
      if (pos1>0)
      {
        /* Preverimo, ali je najdeni znak morda '{' */
        fileread(&ch,sizeof(char),1,com->fp,pos1);
        if (ch=='{')
        {
          /* Argument je v zavitih oklepajih */
          filebracto(com->fp,'{','}',pos1,com->end-1,1000,&pos1,&pos2);
          ++pos1;
        } else
          pos2=filecharto(com->fp,", \n\r\t",5,pos1,com->end-1,16);
        if (pos2<=0)
          pos2=com->end;
        length=pos2-pos1; /* dolzina niza, ki predstavlja argument */
        if (length>0)
        {
          /* Prebere se niz, ki predstavlja argument, in se polozi na sklad: */
          argstr=makestring(length);
          fileread(argstr,sizeof(char),length,com->fp,pos1);
          argstr[length]='\0';
          pushstack(arguments,argstr);
        }
        if (ch=='{')
          pos1=pos2+1;
        else pos1=pos2;
      }
    }
    /* Izpis sklada argumentov: */
    /*
    if (1)
    {
      printf("\nFunction %s:\n",com->commands->s[com->which]);
      if (arguments==NULL)
        printf("  No arguments.\n");
      else
      {
        int i;
        if (arguments->n>0)
          for (i=1;i<=arguments->n;++i)
            printf("  %i. argument: \"%s\"\n",i,arguments->s[i]);
      }
      printf("\n");
    }
    */
    argnames=data->argnames;  /* Imena argumentov v definiciji funkcije */
    if (arguments!=NULL && argnames!=NULL)
      if (arguments->n<argnames->n)
      {
        errfunc0("");
        fprintf(erf(),"Function \"%s\" called with %i arguments (at least %i required).\n",
         arguments->n,argnames->n);
        errfunc2();
      }
    /* Popravijo se podatki o tem, katera je originalna datoteka s kodo in o
    pozicijah kode v originalni datoteki: */
    /* Kopiranje definicijskega bloka funkcije v datoteko, pri cemer se
    zamenjajo imena argumentov funkcije z dejanskimi argumenti: */
    /*
    str=makestring(256);
    str=tmpnam(str);
    tempname=stringcopy(str);
    if (str!=NULL)
      free(str);
    */
    str=tmpnam(NULL);
    tempname=stringcopy(str);
    str=NULL;
    fp1=fopen(data->filename,"rb");
    fp2=fopen(tempname,"wb");
    if (fp1!=NULL && fp2!=NULL)
    {
      lengthfp1=flength(fp1);
      pos1=data->begin+1;
      fprintf(fp2,"\n\n\n\n\n");
      posbegin=ftell(fp2)+1;
      while (pos1>0 && pos1<data->end && pos1<=lengthfp1)
      {
        /* Poisce se naslednje ime argumenta v definicijskem bloku funkcije: */
        ch=' '; pos2=pos1;
        while ((ch!=argmark1 && ch!=argmark2) && pos2>0 && pos2<data->end)
        {
          pos2=nfilestringto(fp1,argnames,pos2,data->end-1,100,&which);
          if (pos2>0 && which>0)
            ch=filereadchar(fp1,pos2-1); /* 1. znak pred najdenim imenom */
          if (ch!=argmark1 && ch!=argmark2)
            ++pos2;
        }
        /* Ce smo nasli ime argumenta, pred katerim stoji oznaka argmark1 ali argmark2,
        se skopira del datoteke fp1 od pos1 do tega argumenta, namesto
        argumenta pa se vrine niz, ki predstavlja resnicni argument: */
        if (ch==argmark1 || ch==argmark2)
        {
          fcopyfilepart(fp1,pos1,pos2-2,fp2,100); /* skopira se del do argumenta */
          pos1=pos2+strlen(argnames->s[which]);
          ok=0;
          if (arguments!=NULL) /* vrine se pravi argument  */
            if (arguments->n>=which)
              if (arguments->s[which]!=NULL)
              {
                ok=1;
                fwrite(arguments->s[which],1,strlen(arguments->s[which]),fp2);
              }
          if (!ok)
          {
            err0();
            fprintf(erf(),"%i. argument not specified.\n",which);
            err2();
          }
        } else
        {
          pos2=data->end;
          fcopyfilepart(fp1,pos1,pos2-1,fp2,100);
          pos1=pos2;
        }
      }
      fprintf(fp2,"\n\n\n\n\n");
    } else
    {
      if (fp1==NULL)
      {
        err0();
        fprintf(erf(),"Can not open file \"%s\".\n",data->filename);
        err2();
      }
      if (fp2==NULL)
      {
        err0();
        fprintf(erf(),"Can not open a temporary file.\n");
        err2();
      }
    }
    fclose(fp1);
    fclose(fp2);
    /*
    printf("Ime zacasne datoteke: \"%s\".\n",tempname);
    */
    /* Najprej shranemo obstojece podatke o imenu in argumentih uporabnisko
    definirane funkcije in jih zamenjamo s podatki o funkciji, ki jo bomo
    izvedli; te podatke rabi funkcija usernumfuncargs, ki vrne stevilo
    argumentov, ter funkcija fi_update, ki izvrsi zapoznelo zamenjavo dejanskih
    argumentv funkcije. */
    oldfuncname=deffuncname;
    oldfuncargs=deffuncargs;
    deffuncname=funcname;
    deffuncargs=arguments;
    /* Postavimo podatke o originalni datoteki, poziciji zacetka bloka v tej
    datoteki in poziciji zacetka bloka v novi datteki; najprej shranemo stare
    podatke: */
    origfilename=com->origfilename;
    origpos=com->origpos;
    beginpos=com->beginpos;
    com->origfilename=data->filename;
    com->origpos=data->begin+1;
    com->beginpos=posbegin;
    /* Interpretacija prepisanega telesa definicije funkcije: */
    oldstepover=com->stepover;
    com->stepover=0;
    fintfile(com,tempname);
    com->stepover=oldstepover;
    /* Restavriramo podatke o originalni datoteki in pozicijah: */
    com->origfilename=origfilename;
    com->origpos=origpos;
    com->beginpos=beginpos;
    /* Po interpretaciji restavriramo prejsnje podatke o uporabnisko definirani
    funkciji in pocistimo za sabo: */
    deffuncname=oldfuncname;
    deffuncargs=oldfuncargs;
    remove(tempname);
    disppointer((void **) &tempname);
  }
}
if (arguments!=NULL)
{
  dispstackval(arguments);
  dispstack(&arguments);
}
}



static double usernumfuncargs(object obj,stack st,stack user,int numargs,
              void *ptr)
    /* Vrne stevilo argumentov, s katerimi je bila klicana uporabnisko
    definirana funkcija interpreterja, ki se trenutno izvaja in je najvisje na
    skladu uporabnisko definiranih funkcij, ki so v izvajanju. Podatek razbere
    iz spremenljivke deffuncargs, kamor se pri klicu uporabnisko definiranih
    funkcij zapisejo podatki o argumentih.
    $A Igor maj98; */
{
if (deffuncargs!=NULL)
{
  if (deffuncargs->n<=0)
    return 0;
  else
    return deffuncargs->n;
} else
  return 0;
}

static void fi_update(ficom com)
    /* Ta funkcija v svojem argumentnem bloku zamenja oznake za argumente z
    dejanskimi argumenti najbolj notranje uporabnisko definirane funkcije, ki
    se trenutno izvaja, in pozene interpretacijo svojega argumentnega bloka
    po zamenjavi. Podatke o argumentih dobi s sklada deffuncargs. Zamenjava
    oznak z dejanskimi argumenti je na nivoju nizov. Oznake za argumente so
    oblike #{izraz} , kjer je izraz matematicni izraz, ki se ovrednoti tik
    pred zamenjavo in pomeni zaporedno stevilko argumenta, s katerim se zamenja
    oznaka.
    $A Igor maj98 apr99; */
{
char ch,*origfilename,oldstepover,*str=NULL;
int which;
double x;
long pos1,pos2,pos3,posbegin,origpos,beginpos,temppos,writepos;
temppos=com->temppos; /* shranemo pozicijo konca uporabnega dela com->temp */
fintpreparetemp(com);
if (com->temp!=NULL)
{
  pos1=com->begin+1;
  fprintf(com->temp,"\n\n\n\n\n");
  writepos=posbegin=ftell(com->temp)+1;
  /* Nadomescanje oznak z dejanskimi argumenti: */
  while(pos1>0)
  {
    /* Poisce se znak '#', ki najavlja oznako argumenta: */
    pos2=filecharto(com->fp,"#",1,pos1,com->end-1,200);
    if (pos2>0)
    {
      /* Ce najdemo znak '#', najprej preverimo, ce to res najavlja oznako
      argumenta (v tem primeru mora nizu slediti zaviti oklepaj, vmes pa so
      lahko samo presledki): */
      pos3=filenotcharto(com->fp," \n\r\t\0",5,pos2+1,com->end-1,5);
      ch='\0';
      if (pos3>0)
        ch=filereadchar(com->fp,pos3);
      if (ch=='#' && pos3-pos2==1)  /* Koda generirana z fi_write1 */
      {
        /* Nasli smo dvojni znak '#'; najprej preverimo, ce to res najavlja
        zamenjavo kode s tem, kar zapise funkcija write1 (v tem primeru mora
        nizu '##' slediti zaviti oklepaj, vmes pa so lahko samo presledki): */
        pos3=filenotcharto(com->fp," \n\r\t\0",5,pos3+1,com->end-1,5);
        ch='\0';
        if (pos3>0)
          ch=filereadchar(com->fp,pos3);
        if (ch=='{')
        {
          /* Niz '##' res zahteva zamenjavo kode, prebere in ovrednoti se
          izraz v zavitih oklepajih ter se zamenja oznako z ustreznim argumentom
          (njegovo zaporedno stevilko doloca vrednost izraza). */
          writepos=filecopyfilepart(com->fp,pos1,pos2-1,com->temp,writepos,pos2-pos1+2);
          filebracto(com->fp,'{','}',pos3,com->end-1,30,&pos1,&pos3);
          if (pos1>0)
          {
            ++pos1;
            if (pos3-pos1<1)
            {
              err0();
              fprintf(erf(),"Empty code write/update argument block.\n");
              err2();
            } else
            {
              /* Zapis kode s funkcijo fi_write1 glede na argumente oznake
              ## { ... } : */
              if (com->fp!=com->temp)
              {
                fseek(com->temp,writepos-1,SEEK_SET);
                fi_write1("fi_update",com->temp,pos1,pos3-1,com);
                writepos=1+ftell(com->temp);
              } else
              {
                /* Ce sta com->fp in com->temp isti datoteki, moramo izpis
                od fi_write1 usmeriti na drugo datoteko in potem to zapisati
                v com->temp, ker fi_write1 bere argumente iz com->fp in bi se
                zamesale pozicije: */
                char *str;
                FILE *fp;
                str=tmpnam(NULL);
                if (str==NULL)
                {
                  err0();
                  fprintf(erf(),"Can not get a temporary file name.\n");
                  err2();
                } else
                {
                  fp=fopen(str,"w");
                  if (fp==NULL)
                  {
                    err0();
                    fprintf(erf(),"Can not open a temporary file.\n");
                    err2();
                  } else
                  {
                    fi_write1("fi_update",fp,pos1,pos3-1,com);
                    fclose(fp);
                    fp=fopen(str,"r");
                    if (fp==NULL)
                    {
                      err0();
                      fprintf(erf(),"Can not read from a temporary file.\n");
                      err2();
                    } else
                    {
                      fseek(com->temp,writepos-1,SEEK_SET);
                      fcopyfilepart(fp,1,flength(fp),com->temp,flength(fp)+1);
                      writepos=1+ftell(com->temp);
                      fclose(fp);
                      remove(str);
                    }
                  }
                }
              }
            }
            pos1=pos3+1;
          } else
          {
            /* Oklepaj ni zaprt; javi se napako in se skopira se preostali del
            datoteke (kompleten, ne da bi se kaj izpustilo): */
            err0();
            fprintf(erf(),"Label bracket not closed.\n");
            err2();
            pos1=pos2;
            pos2=com->end;
            writepos=filecopyfilepart(com->fp,pos1,pos2-1,com->temp,writepos,pos2-pos1+2);
            pos1=0; /* to povzroci izhod iz zanke */
          }
        }        
      } else if (ch=='{')
      {
        /* Znak '#' res nakazuje oznako argumenta, prebere in ovrednoti se
        izraz v zavitih oklepajih ter se zamenja oznako z ustreznim argumentom
        (njegovo zaporedno stevilko doloca vrednost izraza). */
        writepos=filecopyfilepart(com->fp,pos1,pos2-1,com->temp,writepos,pos2-pos1+2);
        filebracto(com->fp,'{','}',pos3,com->end-1,30,&pos1,&pos3);
        if (pos1>0)
        {
          ++pos1;
          if (pos3-pos1<1)
          {
            err0();
            fprintf(erf(),"Empty expression in argument label.\n");
            err2();
          } else
          {
            str=makestring(pos3-pos1);
            fileread(str,1,pos3-pos1,com->fp,pos1);
            x=evaluateexp(com->syst,str);
            which=(int)round(x);
            free(str);
            if (which<1)
            {
              err0();
              fprintf(erf(),"Invalid argument number %i in argument label.\n",which);
              err2();
            } else if (deffuncargs==NULL)
            {
              err0();
              fprintf(erf(),"Can not replace argument No. %i, function %s was called with no arguments.\n",which,deffuncname);
              err2();
            } else if (deffuncargs->n<which)
            {
              err0();
              fprintf(erf(),"Can not replace argument No. %i, function %s was called with only %i arguments.\n",
                which,deffuncname,deffuncargs->n);
              err2();
            } else if (deffuncargs->s[which]!=NULL)
            {
              /* Ce je vse v redu, se v com->temp zapise argument: */
              writepos+=filewrite(deffuncargs->s[which],1,
               strlen((char *) deffuncargs->s[which]),com->temp,writepos);
            }
          }
          pos1=pos3+1;
        } else
        {
          /* Oklepaj ni zaprt; javi se napako in se skopira se preostali del
          datoteke (kompleten, ne da bi se kaj izpustilo): */
          err0();
          fprintf(erf(),"Label bracket not closed.\n");
          err2();
          pos1=pos2;
          pos2=com->end;
          writepos=filecopyfilepart(com->fp,pos1,pos2-1,com->temp,writepos,pos2-pos1+2);
          pos1=0; /* to povzroci izhod iz zanke */
        }
      } else 
      {
        /* Znak '#' ne nakazuje oznake argumenta, zato se skopira del datoteke
        od pos1 do pos2+1 ter se zacne nova iteracija brez kaksne zamenjave: */
        pos2+=2;
        writepos=filecopyfilepart(com->fp,pos1,pos2-1,com->temp,writepos,pos2-pos1+2);
        pos1=pos2;
      }
    } else
    {
      /* Ce niza ne najdemo, skopiramo se zadnji del argumentnega bloka
      funkcije update: */
      pos2=com->end;
      writepos=filecopyfilepart(com->fp,pos1,pos2-1,com->temp,writepos,pos2-pos1+2);
      pos1=0;
    }
  }
  fprintf(com->temp,"\n\n\n\n\n");
  fflush(com->temp);
  com->temppos=ftell(com->temp)+1;
  /* Datoteka je zapisana, izvede se interpretacija datoteke, sledi ciscenje: */
  /* Postavimo podatke o originalni datoteki, poziciji zacetka bloka v tej
  datoteki in poziciji zacetka bloka v novi datteki; najprej shranemo stare
  podatke: */
  origfilename=com->origfilename;
  origpos=com->origpos;
  beginpos=com->beginpos;
  com->origpos=com->begin+1;
  com->beginpos=posbegin;
  if (com->origfilename==NULL)
  {
    com->origfilename=com->filename;
  }
  else
  {
    /* Ze ukaz update ni v originalni datoteki; originalna datoteka torej kar
    ostane originalna datoteka, originalni poziciji pa se doda trenutna
    pozicija v trenutni datoteki: */
    com->origpos+=origpos-beginpos;
  }
  /* Interpretacija prepisanega telesa definicije funkcije: */
  oldstepover=com->stepover;
  com->stepover=0;
  /* fintfile(com,tempname); */
  fintfblock(com,com->temp,com->tempname,com->beginpos,com->temppos-1);
  com->stepover=oldstepover;
  /* Restavriramo podatke o originalni datoteki in pozicijah: */
  com->origfilename=origfilename;
  com->origpos=origpos;
  com->beginpos=beginpos;
} else
{
  err0();
  fprintf(erf(),"Unable to open a temporary file.\n");
  err2();
}
com->temppos=temppos;
}

static void fi_updateold(ficom com)
    /* Ta funkcija v svojem argumentnem bloku zamenja oznake za argumente z
    dejanskimi argumenti najbolj notranje uporabnisko definirane funkcije, ki
    se trenutno izvaja, in pozene interpretacijo svojega argumentnega bloka
    po zamenjavi. Podatke o argumentih dobi s sklada deffuncargs. Zamenjava
    oznak z dejanskimi argumenti je na nivoju nizov. Oznake za argumente so
    oblike #{izraz} , kjer je izraz matematicni izraz, ki se ovrednoti tik
    pred zamenjavo in pomeni zaporedno stevilko argumenta, s katerim se zamenja
    oznaka.
    $A Igor maj98; */
{
char ch,*str,*tempname,*origfilename,oldstepover;
int which;
double x;
long pos1,pos2,pos3,posbegin,origpos,beginpos;
FILE *fp;
/*
str=makestring(256);
str=tmpnam(str);
tempname=stringcopy(str);
if (str!=NULL)
  free(str);
*/
str=tmpnam(NULL);
tempname=stringcopy(str);
str=NULL;
fp=fopen(tempname,"wb");
if (fp!=NULL)
{
  pos1=com->begin+1;
  fprintf(fp,"\n\n\n\n\n");
  posbegin=ftell(fp)+1;
  /* Nadomescanje oznak z dejanskimi argumenti: */
  while(pos1>0)
  {
    /* Poisce se niz "#", ki najavlja oznako argumenta: */
    pos2=filestringto(com->fp,"#",pos1,com->end-1,200);
    if (pos2>0)
    {
      /* Ce najdemo niz "#", najprej preverimo, ce to res najavlja oznako
      argumenta (v tem primeru mora nizu slediti zaviti oklepaj, vmes pa so
      lahko samo presledki): */
      pos3=filenotcharto(com->fp," \n\r\t\0",5,pos2+strlen("#"),com->end-1,5);
      ch='\0';
      if (pos3>0)
        ch=filereadchar(com->fp,pos3);
      if (ch=='{')
      {
        /* Niz "#" res nakazuje oznako argumenta, prebere in ovrednoti se
        izraz v zavitih oklepajih ter se zamenja oznako z ustreznim argumentom
        (njegovo zaporedno stevilko doloca vrednost izraza). */
        fcopyfilepart(com->fp,pos1,pos2-1,fp,pos2-pos1+2);
        filebracto(com->fp,'{','}',pos3,com->end-1,30,&pos1,&pos3);
        if (pos1>0)
        {
          ++pos1;
          if (pos3-pos1<1)
          {
            err0();
            fprintf(erf(),"Empty expression in argument label.\n");
            err2();
          } else
          {
            str=makestring(pos3-pos1);
            fileread(str,1,pos3-pos1,com->fp,pos1);
            x=evaluateexp(com->syst,str);
            which=(int)round(x);
            free(str);
            if (which<1)
            {
              err0();
              fprintf(erf(),"Invalid argument number %i in argument label.\n",which);
              err2();
            } else if (deffuncargs==NULL)
            {
              err0();
              fprintf(erf(),"Can not replace argument No. %i in function %s, function was called with no arguments.\n",which,deffuncname);
              err2();
            } else if (deffuncargs->n<which)
            {
              err0();
              fprintf(erf(),"Can not replace argument No. %i in function %s, function was called with only %i arguments.\n",
                which,deffuncname,deffuncargs->n);
              err2();
            } else if (deffuncargs->s[which]!=NULL)
            {
              /* Ce je vse v redu, se v fp zapise argument: */
              fwrite(deffuncargs->s[which],1,
                     strlen((char *) deffuncargs->s[which]),fp);
            }
          }
          pos1=pos3+1;
        } else
        {
          /* Oklepaj ni zaprt; javi se napako in se skopira se preostali del
          datoteke (kompleten, ne da bi se kaj izpustilo): */
          err0();
          fprintf(erf(),"Label bracket not closed.\n");
          err2();
          pos1=pos2;
          pos2=com->end;
          fcopyfilepart(com->fp,pos1,pos2-1,fp,pos2-pos1+2);
          pos1=0; /* to povzroci izhod iz zanke */
        }
      } else
      {
        /* Niz "#" ne nakazuje oznake argumenta, zato se skopira del datoteke
        od pos1 do pos2+1 tes se zacne nova iteracija brez kaksne zamenjave: */
        pos2+=2;
        fcopyfilepart(com->fp,pos1,pos2-1,fp,pos2-pos1+2);
        pos1=pos2;
      }
    } else
    {
      /* Ce niza ne najdemo, skopiramo se zadnji del argumentnega bloka
      funkcije update: */
      pos2=com->end-1;
      fcopyfilepart(com->fp,pos1,pos2-1,fp,pos2-pos1+2);
      pos1=0;
    }
  }
  fprintf(fp,"\n\n\n\n\n");
  /* Datoteka je zapisana, izvede se interpretacija datoteke, sledi ciscenje: */
  fclose(fp);
  /* Postavimo podatke o originalni datoteki, poziciji zacetka bloka v tej
  datoteki in poziciji zacetka bloka v novi datteki; najprej shranemo stare
  podatke: */
  origfilename=com->origfilename;
  origpos=com->origpos;
  beginpos=com->beginpos;
  com->origpos=com->begin+1;
  com->beginpos=posbegin;
  if (com->origfilename==NULL)
  {
    com->origfilename=com->filename;
  }
  else
  {
    /* Ze ukaz update ni v originalni datoteki; originalna datoteka torej kar
    ostane originalna datoteka, originalni poziciji pa se doda trenutna
    pozicija v trenutni datoteki: */
    com->origpos+=origpos-beginpos;
  }
  /* Interpretacija prepisanega telesa definicije funkcije: */
  oldstepover=com->stepover;
  com->stepover=0;
  fintfile(com,tempname);
  com->stepover=oldstepover;
  /* Restavriramo podatke o originalni datoteki in pozicijah: */
  com->origfilename=origfilename;
  com->origpos=origpos;
  com->beginpos=beginpos;
  remove(tempname);
  disppointer((void **) &tempname);
} else
{
  err0();
  fprintf(erf(),"Unable to open a temporary file.\n");
  err2();
}
}


static void ficheck_funcdef(ficom com)
    /* Funkcija, ki preveri sintakso funkcije fi_funcdef v datotecnem
    interpreterju.
    $A Igor apr98; */
{
_fifuncdata d,*data;
long pos,pos1,pos2,begin,end;
int length=0;
char *name=NULL;
data=&d;
if (com!=NULL)
{
  /* Najprej poiscemo ime funkcije: */
  pos1=filenotcharto(com->fp," \n\r\t",4,com->begin+1,com->end-1,5);
  if (pos1>0)
    pos2=filecharto(com->fp," \n\r\t([",6,pos1,com->end-1,12);
  if (pos2<=0)
    pos2=com->end-1;
  length=pos2-pos1;
  if (pos1<=0 || length<=0)
  {
    err0();
    fprintf(erf(),"FILE INTERPRETER: Function name is missing in function definition.\n");
    err2();
    fiwaituser(com);
  } else
  {
    name=makestring(length);
    fileread(name,sizeof(char),length,com->fp,pos1);
    /* Instalacija funkcije v sistem interpreterja: */
    instficom(com,name,fi_function);
    data=malloc(sizeof(*data));
    data->name=name;
    data->fcom=com;
    data->filename=stringcopy(com->filename);
    data->begin=data->end=0;
    data->argnames=NULL;
    inssortstack(com->functionstack,data,cmpfifuncdata);
    /* Poisce se imena argumentov: */
    pos=pos2;  /* shrane se pozicija, od koder se starta */
    filebracto(com->fp,'(',')',pos2,com->end-1,50,&begin,&end);
    if (begin>0 && end>0) /* Funkcija ima argumente */
    {
      pos1=begin+1;
      while(pos1>0)
      {
        pos1=filenotcharto(com->fp,", \n\r\t",5,pos1,end-1,5);
        if (pos1>0)
        {
          pos2=filecharto(com->fp,", \n\r\t",5,pos1,end-1,14);
          if (pos2<=0)
            pos2=end;
          length=pos2-pos1;
          pos1=pos2;
        }
      }
      pos=end+1;
    }
    /* Poisce se zacetek in konec bloka, ki se interpretira: */
    filebracto(com->fp,com->blockbrac1,com->blockbrac2,pos,com->end-1,1000,
     &data->begin,&data->end);
    if (data->begin<=0 || data->end<=0)
    {
      err0();
      fprintf(erf(),"FILE INTERPRETER: Execution block is missing in function definition.\n");
      err2();
      fiwaituser(com);
    } else
    {
      /* Preveriti je treba tudi izvrsni blok definicije: */
      fintblock(com,data->begin+1,data->end-1);
    }
  }
}
}


static void fi_funcdef(ficom com)
    /* Definicija nove funkcije datotecnega interpreterja.
    Primer:
      function{ increment(x) [ ={$x:$x+1} ] }
    $A Igor jun97 dec97; */
{
fifuncdata data=NULL;
long pos,pos1,pos2,begin,end;
int length=0;
char *name=NULL,*argname;
if (com!=NULL)
{
  /* Najprej poiscemo ime funkcije: */
  pos1=filenotcharto(com->fp," \n\r\t",4,com->begin+1,com->end-1,5);
  if (pos1>0)
    pos2=filecharto(com->fp," \n\r\t([",6,pos1,com->end-1,12);
  if (pos2<=0)
    pos2=com->end-1;
  length=pos2-pos1;
  if (pos1<=0 || length<=0)
  {
    err0();
    fprintf(erf(),"FILE INTERPRETER: Function name is missing in function definition.\n");
    err2();
  } else
  {
    name=makestring(length);
    fileread(name,sizeof(char),length,com->fp,pos1);
    /* Instalacija funkcije v sistem interpreterja: */
    instficom(com,name,fi_function);
    data=malloc(sizeof(*data));
    data->name=name;
    data->fcom=com;
    data->filename=stringcopy(com->filename);
    data->begin=data->end=0;
    data->argnames=NULL;
    inssortstack(com->functionstack,data,cmpfifuncdata);
    /* Poisce se imena argumentov in jih polozi na sklad data->argnames: */
    pos=pos2;  /* shrane se pozicija, od koder se starta */
    filebracto(com->fp,'(',')',pos2,com->end-1,50,&begin,&end);
    if (begin>0 && end>0) /* Funkcija ima argumente */
    {
      data->argnames=newstack(1);
      pos1=begin+1;
      while(pos1>0)
      {
        pos1=filenotcharto(com->fp,", \n\r\t",5,pos1,end-1,5);
        if (pos1>0)
        {
          pos2=filecharto(com->fp,", \n\r\t",5,pos1,end-1,14);
          if (pos2<=0)
            pos2=end;
          length=pos2-pos1;
          if (length>0)
          {
            argname=makestring(length);
            fileread(argname,sizeof(char),length,com->fp,pos1);
            argname[length]='\0';
            pushstack(data->argnames,argname);
          }
          pos1=pos2;
        }
      }
      pos=end+1;
    }
    /* Poisce se zacetek in konec bloka, ki se interpretira: */
    filebracto(com->fp,com->blockbrac1,com->blockbrac2,pos,com->end-1,1000,
     &data->begin,&data->end);
    if (data->begin<=0 || data->end<=0)
    {
      err0();
      fprintf(erf(),"FILE INTERPRETER: Execution block is missing in function definition.\n");
      err2();
    }
  }
}
}




static void ficheck_break(ficom com)
    /* Pregleda sintakso funkcije fi_break v ukazni datoteki.
    $A Igor apr98; */
{
long pos,pos1,pos2;
double val;
int id=0,buflength1=15,buflength2=100,length;
char c,*str=NULL;
if (com->debug)
{
  pos1=filenotcharto(com->fp," \n\r\t\0",5,com->begin+1,com->end-1,buflength1);
  if (pos1>0)
  {
    pos=pos1;
    c=filereadchar(com->fp,pos1);
    if (c!='[')
    {
      /* Obstaja identifikacijska stevilka, ki jo preberemo: */
      if (c=='$')
      {
        /* Identifikacijska stevilka prekinitve je podana kot spremenljivka ali
        z matematicnim izrazom: */
        pos1=filenotcharto(com->fp," \n\r\t\0",5,pos1,com->end-1,buflength1);
        if (pos1<=0)
        {
          err0();
          fprintf(erf(),"FILE INTERPRETER: Expression or variable name is missing in break command.\n");
          err2();
          fiwaituser(com);
        } else
        {
          pos=pos1;
          c=filereadchar(com->fp,pos1);
          if (c=='{')
          {
            /* Identifikac. st. je vrednost izraza */
            str=NULL;
            filebracto(com->fp,'{','}',pos1,com->end-1,30,&pos1,&pos2);
            if (pos1<=0 || pos2<=pos1+1)
            {
              err0();
              fprintf(erf(),"FILE INTERPRETER: Expression is missing after the \"${\" sequence.\n");
              err2();
              fiwaituser(com);
            } else
            {
              pos=pos2+1;
              /* Prebere se izraz, ki ga potem ovrednotimo v okviru sistema za
              simbolno racunanje: */
              length=pos2-pos1-1;
              /*
              str=malloc(length+1);
              fileread(str,sizeof(char),length,com->fp,pos1+1);
              str[length]='\0';
              if (str!=NULL)
              {
                val=evaluateexp(com->syst,str);
                id=(int) val;
                free(str);
              }
              */
            }
            if (pos1>0 && pos2>0)
              pos=pos2+1;
          } else
          {
            /* Identifikac. stevilka je vrednost spremenljivke */
            /* Dolzina imena spremenljivke: */
            pos1=filecharto(com->fp," [\n\r\t\0",6,pos1,com->end-1,buflength1);
            if (pos>0)
            {
              if (pos1>pos)
                length=pos1-pos;
              else
                length=com->end-pos;
            } else
              length=0;
            if (length<=0)
            {
              err0();
              fprintf(erf(),"FILE INTERPRETER: Variable name not specified after the \'$\' sign.\n");
              err2();
              fiwaituser(com);
            } else
            {
              pos1=pos;
              pos+=length;
              /* Prebere se ime spremenljivke: */
              /*
              str=malloc(length+1);
              fileread(str,sizeof(char),length,com->fp,pos1);
              str[length]='\0';
              t=findobjname( (stack) com->syst->def,str);
              pos+=length;
              if (t!=NULL)
              {
                val=doubleval(t,com->syst->fst,com->syst->user);
                id=(int) val;
              }
              */
            }
          }
        }
      } else
      {
        /* Identifikacijska stevilka je podana kot stevilo: */
        val=filenumto(com->fp,pos1,com->end-1,buflength1,&pos2,&length);
        if (pos2!=pos1)
        {
          err0();
          fprintf(erf(),"FILE INTERPRETER: Identification number not given properly.\n");
          err2();
          fiwaituser(com);
        }
        if (pos2<=0 || length<=0)
        {
          err0();
          fprintf(erf(),"FILE INTERPRETER: Identification number not specified properly.\n");
          err2();
          fiwaituser(com);
        } else
        {
          pos=pos2+length;
          /* id=(int) val; */
        }
      }
    }
    pos1=filecharto(com->fp,"[",1,pos1,com->end-1,buflength1);
    if (pos1>0)
    {
      filebracto(com->fp,'[',']',pos1,com->end-1,buflength2,&pos1,&pos2);
      if (pos1<=0 || pos2<=0)
      {
        err0();
        fprintf(erf(),"FILE INTERPRETER: Unclosed execution block brackets.\n");
        err2();
        fiwaituser(com);
      } else
      {
        /*
        if (activebreak(com,id))
          fintblock(com,pos1+1,pos2-1);
        */
      }
    }
  }
}
if (str!=NULL)
  free(str);
}




static void fi_break(ficom com)
    /* Zacasna prekinitev izvajanja pri razhroscevanju. Pri razhroscevanju se
    pozene izvrsni blok v argumentnem bloku ustreznega ukaza, ce ta obstaja,
    nato pa se pozene vrsticni interpreter za razhroscevanje, tako se kontrola
    preda uporabniku. Opisano se ne naredi, ce je
    prekinitev suspendirana. seznam suspendiranih prekinitev je na com.
    Prekinitev se identificira s stevilko prekinitve, ki je takoj na zacetku
    argumentnega bloka. Biti mora celo stevilo in je lahko podano tudi z
    matematicnim izrazom (oblika ${izraz}) ali z imenom spremenljivke (oblika
    $ ime), ki se lahko ovrednoti v sistemu com->syst. Ce stevilka prekinitve
    manjka, se vzame, da je 0.
    $A Igor apr98; */
{
long pos,pos1,pos2;
double val;
int id=0,buflength1=15,buflength2=100,length;
char c,*str=NULL;
object t;
if (com->debug)
{
  pos1=filenotcharto(com->fp," \n\r\t\0",5,com->begin+1,com->end-1,buflength1);
  if (pos1>0)
  {
    pos=pos1;
    c=filereadchar(com->fp,pos1);
    if (c!='[')
    {
      /* Obstaja identifikacijska stevilka, ki jo preberemo: */
      if (c=='$')
      {
        /* Identifikacijska stevilka prekinitve je podana kot spremenljivka ali
        z matematicnim izrazom: */
        pos1=filenotcharto(com->fp," \n\r\t\0",5,pos1+1,com->end-1,buflength1);
        if (pos1<=0)
        {
          err0();
          fprintf(erf(),"FILE INTERPRETER: Expression or variable name is missing.\n");
          err2();
        } else
        {
          pos=pos1;
          c=filereadchar(com->fp,pos1);
          if (c=='{')
          {
            /* Identifikac. st. je vrednost izraza */
            str=NULL;
            filebracto(com->fp,'{','}',pos1,com->end-1,30,&pos1,&pos2);
            if (pos1<=0 || pos2<=pos1+1)
            {
              err0();
              fprintf(erf(),"FILE INTERPRETER: Expression is missing after the \"${\" sequence.\n");
              err2();
            } else
            {
              pos=pos2+1;
              /* Prebere se izraz, ki ga potem ovrednotimo v okviru sistema za
              simbolno racunanje: */
              length=pos2-pos1-1;
              str=malloc(length+1); /* En byte je za zakljucni znak '\0'. */
              fileread(str,sizeof(char),length,com->fp,pos1+1);
              str[length]='\0'; /* Ker se steje od 0 */
              /* Nato se izraz ovrednoti glede na sistem za simbol. racunanje: */
              if (str!=NULL)
              {
                val=evaluateexp(com->syst,str);
                id=(int) val;
                free(str);
              }
            }
            if (pos1>0 && pos2>0)
              pos=pos2+1;
          } else
          {
            /* Identifikac. stevilka je vrednost spremenljivke */
            /* Dolzina imena spremenljivke: */
            pos1=filecharto(com->fp," [\n\r\t\0",6,pos1,com->end-1,buflength1);
            if (pos>0)
            {
              if (pos1>pos)
                length=pos1-pos;
              else
                length=com->end-pos;
            } else
              length=0;
            if (length<=0)
            {
              err0();
              fprintf(erf(),"FILE INTERPRETER: Variable name not specified after the \'$\' sign.\n");
              err2();
            } else
            {
              pos1=pos;
              pos+=length;
              /* Prebere se ime spremenljivke: */
              str=malloc(length+1); /* En byte je za zakljucni znak '\0'. */
              fileread(str,sizeof(char),length,com->fp,pos1);
              str[length]='\0'; /* Ker se steje od 0 */
              t=findobjname( (stack) com->syst->def,str);
              if (t!=NULL)
              {
                val=doubleval(t,com->syst->fst,com->syst->user);
                id=(int) val;
              }
            }
          }
        }
      } else
      {
        /* Identifikacijska stevilka je podana kot stevilo: */
        val=filenumto(com->fp,pos1,com->end-1,buflength1,&pos2,&length);
        if (pos2!=pos1)
        {
          err0();
          fprintf(erf(),"FILE INTERPRETER: Identification number not given properly.\n");
          err2();
        }
        if (pos2<=0 || length<=0)
        {
          err0();
          fprintf(erf(),"FILE INTERPRETER: Identification number not given properly.\n");
          err2();
        } else
        {
          pos=pos2+length;
          id=(int) val;
        }
      }
    }
    pos1=filecharto(com->fp,"[",1,pos1,com->end-1,buflength1);
    if (pos1>0)
    {
      filebracto(com->fp,'[',']',pos1,com->end-1,buflength2,&pos1,&pos2);
      if (pos1<=0 || pos2<=0)
      {
        err0();
        fprintf(erf(),"FILE INTERPRETER: Unclosed execution block brackets.\n");
        err2();
      } else
      {
        if (activebreak(com,id))
        {
          fintblock(com,pos1+1,pos2-1);
        }
      }
    }
  }
  if (activebreak(com,id))
  {
    com->lint->end=0;
    printf("\n\nSTOP because of break, identity number = %i.\n",id);
    lineinterpret(com->lint);
  }
}
if (str!=NULL)
  free(str);
}


static void fi_trace(ficom com)
    /* com->trace postavi na 1, tako da se pri izvedbi funkcij imena nalozijo
    na sklad com->calst. Tako se lahko vedno ugotovi, v kaksnem zaporedju so
    bile klicane funkcije, ki so v izvajanju (katera je klicala katero). To
    informacijo lahko uporabljajo funkcije, ki javljajo napake v sistemih
    vezanih na interpreter.
    $A Igor mar99; */
{
com->trace=1;
}



void fimountbas(ficom com,FILE *outfile,ssyst syst)
    /* Na com osnovne ukaze, ki sluzijo za interpretacijo datoteke. outfile je
    izhodna datoteka, syst pa je sistem za simbolno racunanje, ki podpira
    interpretacijo.
    $A Igor <== jun97; */
{
com->outfl=outfile;
com->syst=syst;
instficom(com,"label",NULL);
instficom(com,"comment",fi_comment);
instficom(com,"*",fi_comment);
instficomall(com,"$",fi_defvar,ficheck_defvar);
instficomall(com,"=",fi_assignval,ficheck_assignval);
instficom(com,"goto",fi_goto);
instficom(com,"exit",fi_exit);
instficomall(com,"block",fi_block,ficheck_block);
instficomall(com,"if",fi_if,ficheck_if);
instficomall(com,"while",fi_while,ficheck_while);
instficomall(com,"do",fi_do,ficheck_do);
instficomall(com,"fread",fi_fread,ficheck_read1);
instficomall(com,"read",fi_read,ficheck_read1);
instficomall(com,"fwrite",fi_fwrite,ficheck_fwrite);
instficomall(com,"write",fi_write,ficheck_write);
instficomall(com,"dwrite",fi_dwrite,ficheck_dwrite);
instficomall(com,"fileappend",fi_fileappend,ficheck_fileappend);
instficomall(com,"waituser",fi_waituser,ficheck_waituser);
instficomall(com,"waitusernote",fi_waitusernote,ficheck_waitusernote);
instficomall(com,"usernote",fi_usernote,ficheck_usernote);
instficomall(com,"systempar",fi_systempar,ficheck_system);
instficomall(com,"executepar",fi_systempar,ficheck_system);
instficomall(com,"system",fi_system,ficheck_system);
instficomall(com,"execute",fi_system,ficheck_system);
instficomall(com,"interpret",fi_interpretfile,ficheck_interpretfile);
/* Za funkcije kalkulatorja, ki jih definiramo prek interpreterja: */
instficomall(com,"return",fi_returndouble,ficheck_returndouble);
instficomall(com,"definefunction",fi_userfunc,ficheck_userfunc);
/* Definicija nove funkcije interpreterja: */
instficomall(com,"function",fi_funcdef,ficheck_funcdef);
instficom(com,"update",fi_update);
instficomall(com,"break",fi_break,ficheck_break);
instficom(com,"trace",fi_trace);

/* Za funkcije kalkulatorja, ki jih definiramo prek interpreterja: */
installuserfunc(com->syst,"numargs",userfinumargs,com,NULL,NULL);
installuserfunc(com->syst,"argument",userfiarg,com,NULL,NULL);
/* Za funkcije interpreterja, ki jih definiramo prek interpreterja: */
installuserfunc(com->syst,"numfuncargs",usernumfuncargs,com,NULL,NULL);


/*
instficom(com,,);
instficom(com,,);
instficom(com,,);
instficom(com,,);
instficom(com,,);
*/
}




void fimountall(ficom com, FILE *outfile)
     /* Na com osnovne ukaze, ki sluzijo za interpretacijo datoteke. Poleg tega
     Tudi vzpostavi podporni sistem za simbolno racunanje. */
{
ssyst system=NULL;
stack syststack=NULL;
initsymbsyst(&syststack);
system=newssyst(syststack);
instbasuserfunc(system);
fimountbas(com,outfile,system);
}




/* FUNKCIJE ZA UPORABO INTERPRETERJA IZ PROGRAMA:

Interpreter lahko uporabimo na razlicne nacine:
  1. Z ukazom interpstring(fcom,string) neposredno interpretiramo niz string.
Ce smo ze prej kaj pisali v buffer za interpretacijo (recimo s funkcijo
addfintbuf(), se zinterpretira najprej to.
Primer: nterpstring(fcom,"copyvector{measmom meas0}");
  2. Z ukazi addtofintbuf(str) najprej napomnimo buffer s tem, kar zelimo
interpretirati, nato klicemo ukaz interpfintbuf(fcom).
Primer: addtofintbuf("copyvector{measmom meas0}");
sddtointbuf("copyvector{parammom param0}"); interpfintbuf(fcom);
  3. Buffer lahko napolnimo s katerokoli funkcijo za pisanje v datoteke, pri
cemer dobimo kazalec na buffer (ki se tvori, ce se ni narejen) s klicem
funkcije fintbuf().
Primer: fprintf(fintbuf(),"write{$%i}\n",name); interpfintbuf(fcom);
  Buffer za interpretacijo lahko polnimo na kateregakoli od opisanih nacinov,
vazno je le, da na koncu (ko ga hocemo interpretirati) izvedemo ali funkcijo
interpstring() ali interpfintbuf().
*/

static FILE *intfile=NULL;  /* buffer (zacas. datoteka), za interpretacijo */
static char *intfilename=NULL;  /* ime bufferja */

FILE *fintbuf(void)
    /* Vrne datoteko (buffer), kamor lahko pisemo ukaze za interpretacijo z
    datotecnim interpreterjem. Funkcija vedno vrne odprto datoteko (po potrebi
    jo sama odpre). V to datoteko lahko pisemo s katerokoli funkcijo za pisanje
    v datoteke, dokler ne klicemo katerega od ukazov, ki to datoteko zapre
    (interpfintbuf() ali interpstring()).
    $A Igor mar99; */
{
if (intfile==NULL)
{
  char *buf;
  if (intfilename!=NULL)
    free(intfilename);
  buf=tmpnam(NULL);
  intfilename=stringcopy(buf);
  intfile=fopen(intfilename,"wb");
}
if (intfile==NULL)
{
  errfunc0("fintbuf");
  fprintf(erf(),"Can not open the buffering file.\n");
  errfunc2();
  return stdout;
} else
  return intfile;
}

int addtofintbuf(char *str)
    /* Niz str zapise v datoteko (buffer), ki se pripravlja za interpretacijo
    z datotecnim interpreterjem. Datoteka se po potrebi odpre na novo.
    Interpretacijo lahko potem izvedemo z ukazom interpfintbuf() ali
    interpstring(), z izvedmo katerega od teh ukazov se buffer tudi zapre.
    $A Igor mar99; */
{
int ret=0;
if (intfile==NULL)
{
  char buf[500];
  if (intfilename!=NULL)
    free(intfilename);
  tmpnam(buf);
  intfilename=stringcopy(buf);
  intfile=fopen(intfilename,"wb");
}
if (intfile==NULL)
{
  errfunc0("addtofintbuf");
  fprintf(erf(),"Can not open the buffering file.\n");
  errfunc2();
  ret=-1;
} else
{
  fprintf(intfile,"%s",str);
}
return ret;
}

int interpfintbuf(ficom com)
    /* Pozene se interpretacija zacasne datoteke, v katero smo pisali ukaze za
    interpretacijo, v interpreterju com. datoteka se pred interpretacijo zapre,
    po interpretaciji pa se zbrise.
    $A Igor mar99; */
{
int ret=0;
char oldstepover,oldstop;
if (intfile!=NULL)
{
  fclose(intfile);
  intfile=NULL;
} else
{
  errfunc0("interpfintbuf");
  fprintf(erf(),"The buffering file is not open.\n");
  errfunc2();
}
oldstepover=com->stepover;
oldstop=com->stop;
com->stop=com->stepover=0;
fintfile(com,intfilename);
com->stepover=oldstepover;
com->stop=oldstop;
remove(intfilename);
disppointer((void **) &intfilename);
return ret;
}

int interpstring(ficom com,char *str)
    /* V datotecnem interpreterju com se interpretira niz str. Ce smo pred
    izvedmo te funkcije kaj napisali v zacasno datoteko za interpretacijo,
    se najprej zinterpretira to. Zacasna datoteka (buffer) se pred
    interpretacijo najprej zapre, po njej pa se zbrise.
    $A Igor mar99; */
{
int ret=0;
ret=addtofintbuf(str);
if (ret==0)
  ret=interpfintbuf(com);
return ret;
}










