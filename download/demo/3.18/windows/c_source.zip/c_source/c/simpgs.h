
#include <sysint.h>

#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <math.h>
#include <mtypes.h>
#include <er.h>
#include <strop.h>
#include <rf.h>
#include <st.h>
#include <fop.h>
#include <vec.h>
#include <lint.h>
#include <simb.h>
#include <grint.h>

#include <sg_obj.h>





               /*****************************************/
               /*                                       */
               /*    Preizkusanje si stema za SimpGS    */
               /*                                       */
               /*****************************************/





typedef struct {
    licom lint;
    stack groups,
          actgroups;
    frame3d frame;
    stack windows;
    golinesettings ls1,ls2,ls3;
    gofillsettings fs1,fs2,fs3;
    gotextsettings ts1,ts2,ts3;
}  _simpgscom;

typedef _simpgscom *simpgscom;

static simpgscom gcom=NULL;



static void lintsignal(void *ptrcom)
    /* Izpise znak, ki pove uporabniku, da je v debuggerju. Ta funkcija se
    naj izvrsi pred branjem vsakega ukaza v vrsticnem interpreterju, zato jo
    instaliramo na vrsticni interpreter datotecnega interpreterja.
    $A Igor apr98; */
{
printf("SGS> ");
}

static char *lastcommand=NULL, *lastparam=NULL;

static void lintpreaction(void * ptrcom)
    /* Funkcija, ki se izvede pred izvedbo vsakega ukaza v vrsticnem
    interpreterju. Ce je bil vstavljen ukaz, se ta shrane v spremenljivko
    lastcommand, njegovi parametri pa v lastparam. Ce pa je uporabnik vstavil
    prazno vrstico, se trenutni ukaz zamenja z lastcommand, trenuten niz
    parametrov pa z lastparam. S tem povzrocimo ponovitev zadnjega ukaza v
    primeru, da je uporabnik vstavil namesto ukaza prazno vrstico.
    $A Igor apr98 sep99; */
{
licom lcom;
char fintcom=0,*comstr;
lcom=(void *) ptrcom;
if (lcom->com==NULL || cmpstrings(lcom->com,"")==0)
{
  /* Ce uporabnik vstavi prazno vrstico, se ponovi zadnji vstavljeni ukaz: */
  if (lcom->com!=NULL)
    free(lcom->com);
  lcom->com=stringcopy(lastcommand);
  lcom->param=lastparam;
} else
{
  /* Zapomni se zadnji vstavljeni ukaz s parametri: */
  if (lastcommand!=NULL)
    free(lastcommand);
  lastcommand=stringcopy(lcom->com);
  if (lastparam!=NULL)
    free(lastparam);
  lastparam=stringcopy(lcom->param);
}
if (lcom->com!=NULL)
{
}
}


static void li_quit(licom lcom)
    /* Funkcija, ki sprozi izhod iz vrsticnega interpreterja.
    $A Igor apr98 mar99; */
{
lcom->end=1;
}


static void li_comment(licom lcom)
    /* Izpise argument na standardni izhod.
    $A Igor apr98 mar99; */
{
if (lcom->param!=NULL)
{
  printf("* %s\n",lcom->param);
} else
  printf("* %s\n");
}



static void li_system(licom lcom)
     /* Pozene se intepreter, ki vse ukaze razen nekaterih specificnih poslje
     sistemu. Ce ima ustrezen ukaz kak argument, se le ta argument poslje
     sistemu v izvrsitev.
     $A Igor apr98; */
{
int buflength=500; /* Maksimalna dolzina vrstice */
char end=0,*buf=NULL,*pos=NULL,*command,*cm;
/* Ce ima ukaz argumente, se izvrsi le vrstica od zacetka 1. argumenta naprej: */
if (lcom->param!=NULL)
{
  system(lcom->param);
}
else
{
  printf("Type in system commands; \"x\" or \"q\" for quit.\n\n");
  buf=malloc(buflength);
  while (!end)
  {
    printf("System> ");
    buf[0]='\0';
    gets(buf);
    cm=NULL;
    command=memnotnchr(buf,strlen(buf)," ",1);
    if (command!=NULL)
    {
      pos=(void *) memnchr(command,strlen(command)," ",1);
      if (pos!=NULL)
        cm=stringncopy(command,pos-command);
      else
        cm=stringcopy(command);
      if (cmpstrings(cm,"x")==0 || cmpstrings(cm,"q")==0)
      {
        if (pos==NULL)
          end=1;
        else
          command=pos;
      }
      if (!end)
      {
        system(command);
      }
      if (cm!=NULL)
        free(cm);
    }
  }
  if (buf!=NULL)
    free(buf);
  printf("\n");
}
}




static void li_calc(licom lcom)
    /* Izvede vrstico, ki je parameter ukaza v vrsticnem interpreterju, v
    kalkulatorju, pri cemer uporabi globalni kalkulator.
    $A Igor avg01; */
{
int buflength=1000; /* Maksimalna dolzina vrstice */
char end=0,*buf=NULL,*command;
/* Ce ima ukaz argumente, se izvrsi le vrstica od zacetka 1. argumenta naprej: */
if (lcom->param!=NULL)
{
  sendtoglobcalc(lcom->param);
}
else
{
  printf("Type in commands or expressions; \"\\x\" or \"\\q\" for quit, \"\\?\" or \"\\h\" for help.\n\n");
  buf=malloc(buflength);
  while (!end)
  {
    printf("Calc> ");
    buf[0]='\0';
    gets(buf);
    command=memnotnchr(buf,strlen(buf)," ",1);
    if (command[0]=='\\' && (command[1]=='q' || command[1]=='x'))
      end=1;
    else
      sendtoglobcalc(command);
  }
  if (buf!=NULL)
    free(buf);
  printf("\n");
}
}



static void li_help(licom lcom)
    /* Funkcija, ki izpise pomoc.
    $A Igor apr98 mar99; */
{
printf("\nYou are working in SGS line interpreter.\n");
printf("\nInput commands; q or quit for exit, ? for help.\n");
printf("If any command ends with \"\\\", it will be appended by the next input line.\n");
printf("\n  List of common commands:\n");
printf("comment, *: prints its argument.\n");
printf("system, !: executes the system commands.\n");
printf("calc, $: calculates expression or runs calculator shell.\n");
}



void instgrint(licom lcom)
{
instlicom(lcom,"q",li_quit);
instlicom(lcom,"quit",li_quit);
instlicom(lcom,"*",li_comment);
instlicom(lcom,"comment",li_comment);
instlicom(lcom,"!",li_system);
instlicom(lcom,"system",li_system);
instlicom(lcom,"$",li_calc);
instlicom(lcom,"calc",li_calc);
instlicom(lcom,"help",li_help);
instlicom(lcom,"?",li_help);
}



static char init=0;

void initsimpgs(void)
{
if (!init)
{
  init=1;
  
  gcom=malloc(sizeof(*gcom));
  
  
  gcom->lint=newlicom(300);
  gcom->lint->before=NULL;
  gcom->lint->signal=lintsignal;
  gcom->lint->preaction=lintpreaction;
  instgrint(gcom->lint);
  
}
}


void simpgsinterpret(void)
{
initsimpgs();
printf("\nInput commands; q or quit for exit, ? for help.\n");
lineinterpret(gcom->lint);
printf("\n");
}



int main(void)
{
initsimpgs();
simpgsinterpret();
}


