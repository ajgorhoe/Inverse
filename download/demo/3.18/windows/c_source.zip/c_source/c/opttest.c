

          /******************************************/
          /*                                        */
          /*  TESTS OF OPTIMIZATION PROBLEMS  */
          /*                                        */
          /******************************************/






/* Switch on tracing: */
/*
#define EXTRACE
*/

/* Switch off tracing */
#ifdef EXTRACE
  #undef EXTRACE    
#endif







#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>



#include <er.h>

#include <mtypes.h>
#include <mtime.h>
#include <strop.h>
#include <rf.h>
#include <vec.h>
#include <mat.h>
#include <matrixop.h>
#include <rand.h>
#include <minnd.h>

#include <optbas.h>

#include <opttest.h>



