

       LIST OF FILES in Igor's software directory & copyright information


BASIC INFORMATION

 This file contains a list of the main files in Igor's software directory and
copyright information. The directory contains source files mainly developed
by Igor Gresovnik.
 Beginning of the development goes back to 1994 when I was doing my graduate
thesis on inverse identification of plastic flow parameters from the tension
test. At that time I needed a software that controls execution of finite
element environment in the optimization loop. I took the software for linear
regression (LAF) that I had developed as a student for the Geological 
institute of Ljubljana and translated its libraris from Pascal to C (in
order to be more cross platform compatible).
 I have later used the library as a basis for various tools I have occasionally
needed, as well as for the optimization software Inverse developed for C3M,
and have been extending it and adding new functionality as turned necessary
in the course of time.
 In order to make use of derived tools easier (especially to enable debugging)
and perhaps to motivate co-operation in code development, the source code for
basic utility libraries is freely available. However, I am not able to
maintain a system for distributed development like CVS. You can therefore use
the code for debugging, correct bugs or extend it to match your needs. Any
suggestions for bug fixes should be sent to me in order to include them in
the code. You should put eventual personal extensions in separate files to
prevent them being overwritten when source files are updated, but you are
welcome to send them to me and suggest inclusion in the original code. In
this case, I will assign you an author's codename (listed in file authors.txt)
so you can mark authorship in function comments.
 The source files for the optimization program Inverse (these are all source
files starting with inv) are not publically available, except invoplib.c and
the header files. If you find these files in a source distribution available 
on the Internet or on any public location, please inform me because this is
by mistake. If you find a bug in your demo or licensed version of Inverse
and you feel the cause should be in one of these unavailable source files,
then please inform me about that, so I can try to find and correct the bug.


COPYRIGHT NOTICE:

This is Igor's software directory. Some of the files contained in this directory
and its subdirectories are currently not publically available (i.e. they are 
subjected to some restrictions with respect to their use). 

All files that begin with "inv" (e.g. inv.c, invan.h, invvar.c, etc.) are a 
constituent part of the optimization software "Inverse" that is copyright by 
Igor Gresovnik and C3M, and to use these files you must obtain written 
permission of either Igor Gresovnik (http://www2.arnes.si/~ljc3m2/igor/index.html) 
or the company 	(http://www.c3m.si/). More information about the optimization 
software "Inverse" can be found at (http://www.c3m.si/inverse/).

Other files (those that do not begin with "inv") are copyright by Igor Gresovnik
and are publically available (open source). You can use those files without 
asking for explicit permission, but you are obliged to keep this copyright 
notice with the files in such a way that it is unambiguously evident that the 
notice applies tose files. 

This copyright notice excludes the files that  are parts of external libraries,
which might be subjected to different terms of use. All such files are either 
in separate directories that include the appropriate original copyright and 
other notices, or corresponding copyright notices are included directly in the 
files.


HOW TO COMPILE AND LINK THE CODE:

 The basic library consists of the plain ANSI C code, so you should not have
any problems with compiling and linking the files on any popular C compiler.
Just compile everything to form object files and then link them to libraries
and programs. I did not put any effort to group the code to more independent
parts, therefore you should simply compile all the files.
 In the C directory, files that end with .h usually contain main programs.
You can include these files in main.c in order to produce different programs
(of course you can write your own main.c including the main() function). 

  For example, on UNIX like systems (such as Linux), you can go to the C 
directory and execute commands similar to this:
    
    cd $HOME/c
    gcc -ansi -c -g -I $HOME/c/h -I/usr/include/ *.c
    gcc -ansi -g -o a.exe *.o *.a -lm -I $HOME/c/h

This assumes that you have a Gnu C compiler (invoked by "gcc") and that the
source directory is put to $HOME/c . The second command compiles all source 
files and creates object files (.c) from them. The third command links the
created object files (and the library files eventually put in the source
directory) into the executable named a.exe. The option -ansi informs the
compiler that the standart ANSI syntx is used (with some UNIX compilers you
must omit this), the -g option creates debuggable objects and executable,
-c causes only compilation without linking, -I defines the include directory
where header files reside, -lm causes linking of standard mathematical
libraries, and the -o option defines the executable name.

 Note that the main() function should be included in the main.c. I utilize
the practice of including another file with a ".h" extension in main.c, in
order to avoid multiple definition of the main() function when compiling and
linking all .c files. You can simply replace the #include statement on the
top of main.c to define your own main, or comment it if you use main from
some library or other .c file.

  With Visual C++:

 If you use Visual Studio or some other development environment, you will 
have to create projects where you define the include directory and list all
the source files. For Visual Studio, you can get the projects from me. 
In my source distributions, Visual C project files are usually included in
the cz directory. You should copy (unpack) the c directory (containing basic 
library sources) and cz directory (containing precompiled libraries and Visual 
studio project files) to the same directory in order to preserve the vlaidity
of directory paths. 

  Compiling & linking of optimization program Inverse:

  Inverse libraries and appropriate projects are currently provided only for
linking with Visual C++. Use libraries and project files from the directory
cz and source files from the directory c to build inverse executable. You
can copy and extend/modify these projects to create your own applications.



FILES LISTED BY CONTENTS:

  - String operations
  - File operations
  - Vectors & matrices
  - 3D geometry
  - Graphics
  - Igor's general software module
  - Inverse files (copyright by Igor Gresovnik and C3M)


    > STRING OPERATIONS

  strop.c

    > FILE OPERATIONS

  fop.c





    > VECTORS & MATRICES

  vec.c
  mat.c
  matop.c


    > APPROXIMATION

  approx.c
	  - general weighted linear approximation
	  - approximation with lin. and quad. pol. in multiple dimensios


    > GENERAL NUMERIC TOOLS
  
	numut.c
	  - numerical integration
		- linear, quadratic & cubic polynomials: interpolation, zeros, extremes
		- polynomial approximation & orthogonal polynomials
		- drawing of 1D functions in text mode
		- conversion to lower number of bits
	test.h:
	  - global search for zeros and extrema (utilizing polynom. interpolation)


	limfunc.c
	  - limit functions for constraining parameter range
		- hat functions for limiting the support
		- weighrting functions for bounding influence range

    > 3D GEOMETRY

  geom.c
    3D analytical geometry:
      - Matrix and vector operations in 3D
	  - Rotations
	  - Projections
	  - Intersections of planes and planes with lines
	  - Closest points (line - line, plane-point...)


      > FINITE ELEMENTS (mainly mesh manipulation)
	
	fem.c


    > GRAPHICS

    > INVERSE FILES

  These files are the part of the program Inverse and may not be copied, 
distributed, compiled or used in any other way without the permition of
Igor Gresovnik or a deputy authorised by C3M.

  invan.h
    Inverse main.
  inv.c
    Main utilities for Inverse.
  invelf.c
    Elfen interface for Inverse
  invvarc.h
  invvard.h
  invvarf.h
  invvarf1.h
    Variable handling routines.
  invopt.c
	Optimisation utilities
  invpar.c
    Parallel interface
  invut.c
    Supplemental utilities, model file for adding new modules.
  invuser.c
    Files where other developers should include their utilities.
  


CONTACT INFORMATION:
Igor Gresovnik
Crnece 147
2370 Dravograd
Slovenia
http://www.c3m.si/igor ; igor@gmail.com



