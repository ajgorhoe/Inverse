
#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>


#include <mtypes.h>
#include <st.h>
#include <rand.h>
#include <vec.h>
#include <mat.h>
#include <spmat.h>



            /*******************************************/
            /*                                         */
            /*   OPERACIJE NAD RAZPRSENIMI MATRIKAMI   */
            /*                                         */
            /*******************************************/



smat getsmat(int d1,int d2,int ex,int r)
    /* Kreira in vrne razprseno matriko z dimenzijama d1 in d2, pri cemer
    alocira r mest in postavi na ex polje ex. Dimanziji morata biti vecji od
    0. Alocira se vedno vsaj d1 toliko mest.
    $A Igor okt00; */
{
smat m;
int i,l,p;
if (r<d1)
  r=d1;
if (ex<0)
  ex=0;
m=malloc(sizeof(*m));
m->d1=d1;  m->d2=d2;
m->ex=ex; m->r=r;
if (d1<1 || d2<1)
{
  m->l=m->n=NULL;
  m->m=NULL;
} else
{
  m->l=malloc((2*d1+1)*sizeof(*(m->l)) );
  --m->l;
  m->n=m->l+d1+1;
  if (r)
  {
    m->i=malloc(r*sizeof(*(m->i)));
    --m->i;
    m->m=malloc(r*sizeof(*(m->m)));
    --m->m;
    /* Zacetke vrstic razvrstimo v enakomernih razmikih: */
    l=r/i;
    p=1;
    for (i=1;i<=d1;++i)
    {
      m->l[i]=p;
      m->n[i]=1;
      p+=l;
    }
    /* Zacetek d1+1. vrstice postane za lazjo obravnavo prvi nealociran element: */
    m->l[d1+1]=r+1;
  } else
  {
    m->m=NULL;
    m->i=NULL;
    for (i=1;i<=d1;++i)
    {
      m->l[i]=0;
      m->n[i]=0;
    }
    m->l[d1]=0;
  }
}
return m;
}


smat getsmatindtab(int d1,int d2,int ex,indtab it,int firstgap,int plusgap)
    /* Alocira razprseno matriko, za katero it vsebuje stevilo elementov
    za vsako vrstico, firstgap doloca velikost praznine za 1. vrstico, plusgap
    pa prirastek praznine za vsako naslednjo vrstico (oboje je lahko 0). Tudi
    za zadnjo vrstico se pusti praznina, ce je firstgap ali plusgap vecji od 0.
    $A Igor okt00; */
{
int r=0,i,gap,ad;
smat m;
if (firstgap<0)
  firstgap=0;
else if (plusgap<0)
  plusgap=0;
gap=firstgap;
if (it!=NULL)
{
  for (i=1;i<=it->n;++i)
  {
    r+=it->t[i]+gap;
    if (it->t[i]+gap==0)
      ++r;
    gap+=plusgap;
  }
  for (;i<=d1;++i)
  {
    r+=gap;
    if (gap==0)
      r+=1;
    gap+=plusgap;
  }
  if (r<d1)
    r=d1;
  m=getsmat(d1,d2,ex,r);
  if (r>0)
  {
    gap=firstgap;
    ad=1;
    for (i=1;i<=it->n;++i)
    {
      m->l[i]=ad;
      m->n[i]=it->t[i];
      ad+=it->t[i]+gap;
      if (it->t[i]+gap==0)
        ++ad; /* preprecimo, da bi se 2 vrstici zaceli na istem mestu */
      gap+=plusgap;
    }
    for (;i<=d1;++i)
    {
      m->l[i]=ad;
      m->n[i]=0;
      ad+=gap;
      if (gap==0)
        ++ad; /* preprecimo, da bi se 2 vrstici zaceli na istem mestu */
      gap+=plusgap;
    }
    m->l[d1+1]=r;
  }
}
return m;
}


void dispsmat(smat *am)
    /* Zbrise razprseno matriko *am in jo postavi na NULL.
    $A Igor okt00; */
{
smat m;
if (am!=NULL)
{
  if ((m=*am)!=NULL)
  {
    if (m->l!=NULL)
      free(++m->l);
    if (m->i!=NULL)
      free(++m->i);
    if (m->m!=NULL)
      free(++m->m);
    free(m);
    *am=NULL;
  }
}
}


void printsmatline(smat m)
    /* Izpise razprseno matriko m. Nenicelne elemente vrstice zapise v eni
    vrstici.
    $A Igor okt00; */
{
int i,j,nel=0;
if (m==NULL)
  printf("NULL sp. matrix.\n");
else
{
  if (m->i==NULL)
    printf("d1 = %i, d2 = %i, value table not allocated.\n",m->d1,m->d2);
  else if (m->l==NULL)
    printf("d1 = %i, d2 = %i, index table not allocated.\n",m->d1,m->d2);
  else if (m->n==NULL)
    printf("d1 = %i, d2 = %i, number table not allocated.\n",m->d1,m->d2);
  else
  {
    for (i=1;i<=m->d1;++i)
      nel+=m->n[i];
    printf("d1 = %i, d2 = %i, r = %i, num. el. = %i.\n",m->d1,m->d2,nel);
    for (i=1;i<=m->d1;++i)
    {
      printf("  %i. row: num. el. = %i, start = %i\n",i,m->n[i],m->l[i]);
      for (j=0;j<m->n[i];++j)
        printf("%i:%g ",m->i[m->l[i]+j],m->m[m->l[i]+j]);
      printf("\n");
    }
  }
}
}


void printsmat(smat m)
    /* Izpise razprseno matriko m. Nenicelne elemente izpise vsakega v svoji
    vrstici.
    $A Igor okt00; */
{
int i,j,nel=0;
if (m==NULL)
  printf("NULL sp. matrix.\n");
else
{
  if (m->i==NULL)
    printf("d1 = %i, d2 = %i, value table not allocated.\n",m->d1,m->d2);
  else if (m->l==NULL)
    printf("d1 = %i, d2 = %i, index table not allocated.\n",m->d1,m->d2);
  else if (m->n==NULL)
    printf("d1 = %i, d2 = %i, number table not allocated.\n",m->d1,m->d2);
  else
  {
    for (i=1;i<=m->d1;++i)
      nel+=m->n[i];
    printf("d1 = %i, d2 = %i, r = %i, num. el. = %i.\n",m->d1,m->d2,nel);
    for (i=1;i<=m->d1;++i)
    {
      printf("  %i. row: num. el. = %i, start = %i\n",i,m->n[i],m->l[i]);
      for (j=0;j<m->n[i];++j)
        printf("%i:%g\n",m->i[m->l[i]+j],m->m[m->l[i]+j]);
      printf("\n");
    }
  }
}
}


void printsmatfull(smat mat)
    /* Izpise razprseno matriko m, kot da bi bila polna matrika, le da pri
    niclah, za katere tudi ni alociran prostor, izpise se crtico.
    $A Igor okt00; */
{
int i,j,k;
if (mat==NULL)
  printf("NULL sparse matrix.\n");
else
{
  printf("Dimension: %i*%i (sparse)\n",mat->d1,mat->d2);
  if (mat->d1>0 && mat->d2>0)
    if (mat->m==NULL)
      printf("NULL value table.\n");
    else for (i=1;i<=mat->d1;++i)
    {
      if (mat->n[i]<=0)
      {
        /* printf("EMPTY LINE!\n"); */
        for (j=1;j<=mat->d2;++j)
          printf("m[%i,%i]= 0 -\n",i,j);
      } else
      {
        /* k bo indeks 1. zasedenega elementa v vrstici, ki se se ni izpisal: */
        if (mat->n[i]>0)
          k=1;
        else
          k=0;
        for (j=1;j<=mat->d2;++j)
        {
          if (k)
          {
            if (mat->i[mat->l[i]+k-1]==j)
            {
              printf("m[%i,%i]= %g\n",i,j,mat->m[mat->l[i]+k-1]);
              ++k;
              if (k>mat->n[i])
                k=0;
            } else
              printf("m[%i,%i]= 0 -\n",i,j);
          } else
            printf("m[%i,%i]= 0 -\n",i,j);
        }
        if (k)
          printf("Warning: there are row elements whose index exceeds the second dimension.\n");
      }
      printf("\n");
    }
}
}



smat copymatrixtosmat(matrix m1,smat *m2)
    /* Polno matriko m1 skopira v razprseno matriko in jo vrne. Ce je m2
    razlicen od NULL, se m1 skopira v *m2 in se vrne *m2. Ce je treba razprdeno
    matriko alocirati na novo, se alocira natancno toliko prostora, da se lahko
    vanjo spravi vse elemente.
    $A Igor okt00; */
{
smat m;
int i,j,numel=0,ad;
if (m2!=NULL)
{
  /* Ce je *m2!=NULL, se m1 skopira v *m2: */
  if (m1==NULL)
  {
    dispsmat(m2);
  } else
  {
    /* Najprej prestejemo stevilo nenicelnih elementov v m1, da bomo lahko
    pravilno alocirali m2: */
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        if (m1->m[i][j]!=0)
          ++numel;
    if (numel==0)
      numel=1;
    /* Preverimo dimenziji *m2, ce nista ustrezni, zbrisemo *m2: */
    if (*m2!=NULL)
      if ((*m2)->d1!=m1->d1 || (*m2)->r<numel)
        dispsmat(m2);
    /* Ce je *m2==NULL, tvorimo *m2 z dimenzijama m1: */
    if (*m2==NULL)
        *m2=getsmat(m1->d1,m1->d2,1,numel);
    m=*m2;
    /* Kopiranje elementov */
    ad=1;
    if (m1->d1>0 && m1->d2>0)
    {
      for (i=1;i<=m1->d1;++i)
      {
        m->l[i]=ad;
        m->n[i]=0;
        for (j=1;j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
          {
            m->m[ad]=m1->m[i][j];
            m->i[ad]=j;
            ++m->n[i];
            ++ad;
          }
      }
    } else
      for (i=1;i<=m1->d1;++i)
        m->l[i]=m->n[i]=0;
  }
  return *m2; /* Ker je bil m2!=NULL, se vrne *m2. */
} else
{
  /* m2==NULL, naredi se nova matrika, ki je kopija m1, vrne se njen kazalec: */
  if (m1==NULL)
    return NULL;
  else
  {
    /* Najprej prestejemo stevilo nenicelnih elementov v m1, da bomo lahko
    pravilno alocirali m2: */
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        if (m1->m[i][j]!=0)
          ++numel;
    if (numel==0)
      numel=1;
    m=getsmat(m1->d1,m1->d2,0,numel);
    /* Kopiranje elementov */
    ad=1;
    if (m1->d1>0 && m1->d2>0)
    {
      for (i=1;i<=m1->d1;++i)
      {
        m->l[i]=ad;
        m->n[i]=0;
        for (j=1;j<=m1->d2;++j)
          if (m1->m[i][j]!=0)
          {
            m->m[ad]=m1->m[i][j];
            m->i[ad]=j;
            ++m->n[i];
            ++ad;
          }
      }
    } else
      for (i=1;i<=m1->d1;++i)
        m->l[i]=m->n[i]=0;
    return m;
  }
}
}


