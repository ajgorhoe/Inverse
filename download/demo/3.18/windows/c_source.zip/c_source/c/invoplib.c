

#ifndef DEBUG
  #define DEBUG
#endif

/*
#undef DEBUG
*/

#include <stdlib.h>

#include <sysint.h>
#include <mtypes.h>
#include <st.h>
#include <strop.h>
#include <fop.h>
#include <er.h>
#include <varop.h>

#include <invvar.h>

#include <invoplib.h>

#include <inv.h>


#ifdef INVCLOSED






              /*************************************/
              /*                                   */
              /*     SISTEM ZA JAVLJANJE NAPAK     */
              /*                                   */
              /*************************************/



static char erfilenfail=0;

FILE *inverrorfile(void)
    /* Returns the file into which error reports should be output beside the
    stendard error.
    $A Igor jul99 nov02; */
{
#ifndef OLDCODE
  return inv_outfile();
#else /* OLDCODE */
  FILE *ret=NULL;
  ret=stdout;
  /*
  if ((var=inv_vfioutfile())!=NULL)
    if (var->v!=NULL)
      if ((vf=(vfile) var->v[1])!=NULL)
        if (vf->fp!=NULL)
          ret=vf->fp;
  */
  if (com.erfile!=NULL)
    return com.erfile;
  return ret;
#endif  /* OLDCODE */
}

FILE * inverf(void)
    /* Returns an open file on which a part of the error report can be printed.
    Calls of this function and printing to the file which it returns should
    be performed between the calls to the appropriate error report initialisation
    and error report finalisation function.
    $A Igor jul99 nov02; */
{
#ifndef OLDCODE
return erfdefault();
#else /* OLDCODE */
FILE *ret=NULL;
if ((ret=errorfileextern())!=NULL)
  return ret;
else if (com.erfile!=NULL)
  return com.erfile;
else
  return stdout;
#endif  /* not defined OLDCODE */
}

char *invers(void)
    /* Returns a string on which a part of the error report can be printed.
    Calls of this function and printing to the string which it returns should
    be performed between the calls to the appropriate error report initialisation
    and error report finalisation function. The minimum amount of space available
    in the returned string is at least 2500 bytes (defined by the macro MINBUF
    in er.c).
    $A Igor nov02; */
{
return ersdefault();
}


static void fprinttrace(FILE *fp)
    /* V datoteko fp zapise klicno zaporedje funkcij datotecnega interpreterja,
    ki se izvajajo v trenutku klica te funkcije, ce je ta informacija na voljo.
    Fnkcija se uporablja pri izpisu obvestil o napakah.
    $A Igor mar99 nov02; */
{
if (com.fcom!=NULL)
  if (com.fcom->trace && com.fcom->callst!=NULL)
  {
    fprintf(fp,">> Calling sequence: *->");
    fprintficallstack(fp,com.fcom);
    fprintf(fp,"\n");
  }
}



void erinv1(int code,char *functionname)
    /* Funkcija, ki jo moramo izvesti pred izpisom opisa napake v vmesne
    pomnilnike v primeru, da gre za napako, ki se ne tice kaksne funkcije
    kalkulatorja ali interpreterja. functionname je ime funkcije, v kateri
    javimo napako, code pa je koda napake.
    $A Igor sep98 nov02; */
{
#ifndef OLDCODE
errfunc1default(code,functionname);
#else /* OLDCODE */

/* Najprej zapremo datoteko com.erfile, ce je odprta: */
if (com.erfile!=NULL)
{
  fclose(com.erfile);
  com.erfile=NULL;
}
/* Odpremo zacasno datoteko com.erfile, v katero bomo zapisali opis napake: */
com.erfile=tmpfile();
if (com.erfile!=NULL)
  erfilenfail=0;
else
{
  /* Ce nam ni uspelo odpreti zacasne datoteke, postavimo zacasno datoteko na
  inv_outfile() (ce je ta odprta) ali na standardni izhod. Hkrati indiciramo
  s spremenljivko erfilenfail, da datoteke nismo mogli odpreti: */
  erfilenfail=1;
  /*
  if (inv_outfile()!=NULL)
    com.erfile=inv_outfile();
  else
    com.erfile=stdout;
  */
  com.erfile=errorfileextern(); /* Ta funkcija vrne datoteko outfile, ce 
   obstaja in je odprta, drugace vrne stdout. */
  sprintf(invers(),"\n\nError: can not open temporary file for error report!\n\n");
}
/* Zapisemo glavo sporocila o napaki: */
sprintf(invers(),"\n\n<< Inv. ERROR! >>\n");
sprintf(invers(),"Error %i was detected in programme's function \"%s\".\n",
        code,functionname);
sprintf(invers(),"  ");
#endif
}


void erinv0(char *functionname)
    /*
    $A Igor  nov02; */
{
erinv1(0,functionname);
}

void erinv2(void)
    /* Funkcija, ki jo moramo izvesti po izpisu opisa napake v vmesne pomnilnike
    v primeru, da gre za napako, ki se ne tice kaksne funkcije
    kalkulatorja ali interpreterja.
    $A Igor sep98 apr99 nov02; */
{
#ifndef OLDCODE
  char *functionname,*originalfilename,*filename;
  int originalline,line;
  /* Zapisemo sporocilo o poziciji v interpreterju, kjer se je napaka pojavila: */
  fintpos(com.fcom,&functionname,&originalfilename,&originalline,&filename,&line);
  if (filename!=NULL)
  {
    fprintf(erf(),"<file interpreter: function \"%s\", file \"%s\", line %i (\"%s\", line %i).>\n",
            functionname,originalfilename,originalline,filename,line);
    fprinttrace(erf());
  }
  err2default();
#else /* OLDCODE */
  char *functionname,*originalfilename,*filename;
  int originalline,line;
  long length;
  /* Zapisemo sporocilo o poziciji v interpreterju, kjer se je napaka pojavila: */
  fintpos(com.fcom,&functionname,&originalfilename,&originalline,&filename,&line);
  if (filename==NULL)
    sprintf(invers(),"<file interpreter: function \"%s\", file \"%s\", line %i.>\n",
            functionname,originalfilename,originalline);
  else
    sprintf(invers(),"<file interpreter: function \"%s\", file \"%s\", line %i (\"%s\", line %i).>\n",
            functionname,originalfilename,originalline,filename,line);
  fprinttrace(com.erfile);
  sprintf(invers(),"\n\n");
  if (!erfilenfail)
  {
    /* Ce smo prej lahko odprli zacasno daatoteko, njeno vsebino prepisemo v
    inv_outfile() in na standardni izhod ter zapremo zacasno datoteko: */
    length=flength(com.erfile);
    if (length>0)
    {
      FILE *erfile=NULL;
      fcopyfilepart(com.erfile,1,length,stdout,200);
      /*
      if (inv_outfile()!=NULL)
      {
        fcopyfilepart(com.erfile,1,length,inv_outfile(),200);
      }
      */
      if ( (erfile=errorfileextern()) !=NULL)
      {
        fcopyfilepart(com.erfile,1,length,erfile,200);
      }
    }
    fclose(com.erfile);
  }
  /* na koncu postavimo zacasno datoteko na NULL: */
  com.erfile=NULL;
#endif /* OLDCODE */
}


void erfintinv1(int code,char *funcname)
    /* Funkcija, ki jo moramo izvesti pred izpisom opisa napake v vmesne
    pomnilnike v primeru, da gre za napako, ki se tice funkcije datotecnega
    interpreterja. code je koda napake.
    $A Igor sep98 nov02; */
{
#ifndef OLDCODE
  char *functionname,*originalfilename,*filename;
  int originalline,line;
  if (funcname==NULL)
    funcname="\n";
  /* Call default error message initialisation function: */
#ifdef DEBUG
  errfunc1default(code,funcname);
#else
  err1default(code);
#endif
  /* Get interpreter position: */
  fintpos(com.fcom,&functionname,&originalfilename,&originalline,&filename,&line);
  /* Add Position data to error message: */
  sprintf(ers(),">> Interp. func. \"%s\", file \"%s\", line %i\n",
          functionname,originalfilename,originalline);
#else /* OLDCODE */
  char *functionname,*originalfilename,*filename;
  int originalline,line;
  /* Najprej zapremo datoteko com.erfile, ce je odprta: */
  if (com.erfile!=NULL)
  {
    fclose(com.erfile);
    com.erfile=NULL;
  }
  /* Nato dobimo pozicijo v interpreterju, kjer se je napaka pojavila: */
  fintpos(com.fcom,&functionname,&originalfilename,&originalline,&filename,&line);
  /* Odpremo zacasno datoteko com.erfile, v katero bomo zapisali opis napake: */
  com.erfile=tmpfile();
  if (com.erfile!=NULL)
    erfilenfail=0;
  else
  {
    /* Ce nam ni uspelo odpreti zacasne datoteke, postavimo zacasno datoteko na
    inv_outfile() (ce je ta odprta) ali na standardni izhod. Hkrati indiciramo
    s spremenljivko erfilenfail, da datoteke nismo mogli odpreti: */
    erfilenfail=1;
    /*
    if (inv_outfile()!=NULL)
      com.erfile=inv_outfile();
    else
      com.erfile=stdout;
    */
    com.erfile=errorfileextern(); /* Ta funkcija vrne datoteko outfile, ce 
     obstaja in je odprta, drugace vrne stdout. */
    sprintf(invers(),"\n\nError: can not open temporary file for error report!\n\n");
  }
  /* Zapisemo glavo sporocila o napaki: */
  sprintf(invers(),"\n\n<< Interp. ERROR! >>\n");
  sprintf(invers(),"Error %i in file interpreter function \"%s\",\n",
          code,functionname);
  if (filename==NULL)
    sprintf(invers(),"file \"%s\", line %i:\n",originalfilename,originalline);
  else
    sprintf(invers(),"file \"%s\", line %i (\"%s\", line %i):\n",
           originalfilename,originalline, filename,line);
  sprintf(invers(),"  ");
#endif /* not defined OLDCODE */
}

void erfintinv0(void)
{
erfintinv1(0,"\"\"");
}

void erfintinv2(void)
    /* Funkcija, ki jo moramo izvesti po izpisu opisa napake v vmesne
    pomnilnike v primeru, da gre za napako, ki se tice funkcije datotecnega
    interpreterja.
    $A Igor sep98 nov02; */
{
#ifndef OLDCODE
  err2default();
#else /* OLDCODE */
  long length;
  fprinttrace(com.erfile);
  sprintf(invers(),"\n\n\n");
  if (!erfilenfail)
  {
    /* Ce smo prej lahko odprli zacasno daatoteko, njeno vsebino prepisemo v
    inv_outfile() in na standardni izhod ter zapremo zacasno datoteko: */
    length=flength(com.erfile);
    if (length>0)
    {
      FILE *erfile;
      fcopyfilepart(com.erfile,1,length,stdout,200);
      /*
      if (inv_outfile()!=NULL)
      {
        fcopyfilepart(com.erfile,1,length,inv_outfile(),200);
      }
      */
      if ((erfile=errorfileextern()) !=NULL)
      {
        fcopyfilepart(com.erfile,1,length,erfile,200);
      }
    }
    fclose(com.erfile);
  }
  /* na koncu postavimo zacasno datoteko na NULL: */
  com.erfile=NULL;
#endif /* not defined OLDCODE */
}


void ercalcinv1(int code,char *funcname)
    /* Funkcija, ki jo moramo izvesti pred izpisom opisa napake v vmesne
    pomnilnike v primeru, da gre za napako, ki se tice funkcije kalkulatorja.
    code je koda napake.
    $A Igor sep98 nov02; */
{
#ifndef OLDCODE
  userfunc func;
  char *functionname;
  /* Call the default error message initialisation function: */
#ifdef DEBUG
  errfunc1default(code,funcname);
#else
  err1default(code);
#endif
  /* Get information about currently evaluated calculator function: */
  func=getcurrentuserfunc();
  if (func!=NULL)
    functionname=func->name;
  /* Add calculator related information to the report: */
  sprintf(ers(),">> Calc. func. \"%s\"\n",functionname);
#else /* OLDCODE */
  userfunc func;
  char *functionname=NULL;
  /* Najprej zapremo datoteko com.erfile, ce je odprta: */
  if (com.erfile!=NULL)
  {
    fclose(com.erfile);
    com.erfile=NULL;
  }
  /* Odpremo zacasno datoteko com.erfile, v katero bomo zapisali opis napake: */
  com.erfile=tmpfile();
  if (com.erfile!=NULL)
    erfilenfail=0;
  else
  {
    /* Ce nam ni uspelo odpreti zacasne datoteke, postavimo zacasno datoteko na
    inv_outfile() (ce je ta odprta) ali na standardni izhod. Hkrati indiciramo
    s spremenljivko erfilenfail, da datoteke nismo mogli odpreti: */
    erfilenfail=1;
    /*
    if (inv_outfile()!=NULL)
      com.erfile=inv_outfile();
    else
      com.erfile=stdout;
    */
    com.erfile=errorfileextern(); /* Ta funkcija vrne datoteko outfile, ce 
     obstaja in je odprta, drugace vrne stdout. */
    sprintf(invers(),"\n\nError: can not open temporary file for error report!\n\n");
  }
  /* dobimo podatke o uporabniski funkciji kalkulatorja, ki se trenutno vrednoti: */
  func=getcurrentuserfunc();
  if (func!=NULL)
    functionname=func->name;
  /* Zapisemo glavo sporocila o napaki: */
  sprintf(invers(),"\n\n<< Calc. ERROR! >>\n");
  sprintf(invers(),"Error %i in expression evaluator function \"%s\":\n",
          code,functionname);
  sprintf(invers(),"  ");
#endif /* OLDCODE */
}

void ercalcinv0(void)
{
ercalcinv1(0,"\"\"");
}

void ercalcinv2(void)
    /* Funkcija, ki jo moramo izvesti po izpisu opisa napake v vmesne
    pomnilnike v primeru, da gre za napako, ki se tice funkcije kalkulatorja .
    $A Igor sep98 nov02; */
{
#ifndef OLDCODE
  err2default();
#else /* OLDCODE */
  char *functionname=NULL,*originalfilename,*filename;
  int originalline,line;
  long length;
  /* Zapisemo sporocilo o poziciji v interpreterju, kjer se je napaka pojavila: */
  fintpos(com.fcom,&functionname,&originalfilename,&originalline,&filename,&line);
  if (filename==NULL)
    sprintf(invers(),"<file interpreter: function \"%s\", file \"%s\", line %i.>\n",
            functionname,originalfilename,originalline);
  else
    sprintf(invers(),"<file interpreter: function \"%s\", file \"%s\", line %i (\"%s\", line %i).>\n",
            functionname,originalfilename,originalline,filename,line);
  fprinttrace(com.erfile);
  sprintf(invers(),"\n\n");
  if (!erfilenfail)
  {
    /* Ce smo prej lahko odprli zacasno daatoteko, njeno vsebino prepisemo v
    inv_outfile() in na standardni izhod ter zapremo zacasno datoteko: */
    length=flength(com.erfile);
    if (length>0)
    {
      FILE *erfile;
      fcopyfilepart(com.erfile,1,length,stdout,200);
      /*
      if (inv_outfile()!=NULL)
      {
        fcopyfilepart(com.erfile,1,length,inv_outfile(),200);
      }
      */
      if ( (erfile=errorfileextern() )!=NULL)
      {
        fcopyfilepart(com.erfile,1,length,erfile,200);
      }
    }
    fclose(com.erfile);
  }
  /* na koncu postavimo zacasno datoteko na NULL: */
  com.erfile=NULL;
#endif /* OLDCODE */
}






              /******************************************/
              /*                                        */
              /*  FUNKCIJE, KI SE TICEJO INTERPRETERJA  */
              /*                                        */
              /******************************************/



    /*  POGON DIREKTNE ANALIZE  */


void invanalyse(void);
    /* Izvede direktno numericno analizo z vhodnimi parametri com.parammom ter
    zapise rezultate analize v dogovorjene spremenljivke. Funkcija je
    definirana v invopt.c.
    $A Igor <== jun97; */


    /*  INTERPRETACIJA KODE V SPOMINU:  */

int invinterpstring(char *str)
    /* V datotecnem interpreterju programa Inverse se interpretira niz str.
    $A Igor okt01; */
{
return interpstring(com.fcom,str);
}


char *invgetargblocksimp(void)
    /* Naredi in vrne niz, v katerega dobesedno prepise vsebino trenutnega
    argumentnega blokainterpreterja, ki je v obdelavi, in sicer od trenutne
    pozicije pri branju argumentov (ki je na zacetku postavljena na zacetek
    argument. bloka) do konca argumentnega bloka. To funkcijjo navadno
    uporabljamo skupaj s funkcijo invinterpstring, kadar definiramo funkcijo
    interpreterja, ki naj del argumentnega bloka zinterpretira.
    $A Igor okt01; */
{
char *ret=NULL;
ficom fcom=com.fcom;
long read=0;
if (fcom->argpos>0 && fcom->end>fcom->argpos)
{
  ret=malloc(fcom->end-fcom->argpos);
  read=fileread(ret,1,fcom->end-fcom->argpos-1,fcom->fp,fcom->argpos);
  ret[read]='\0';
}
return ret;
}


    /* VGNEZDENI ARGUMENTNI BLOKI: */


static stack nestblocks=NULL;


int inventernestblocksimp(void)
    /* Pri interpretaciji argumentov funkcije interpreterja lupine Inverse
    povzroci vhod v vgnezden argumentni blok. Na interpreterju lupine com.fcom
    pripravi podatke tako, da postane argumentni blok vsebina zavitih oklepajev,
   ki sledijo trenutni poziciji v argumentnem bloku (vmes je lahko le prazen
   prostor in vejice). Hkrati se shranejo podatki, ki omogocijo pravilno
   restavracijo pozicij za branje argumentov po izhodu iz vgnezdenega
   argumentnega bloka s funkcijo invexitnestblocksimp.
     Vgnezdeni argumentni bloki se uporabljajo npr. za navedbo blokov kode, ki
    naj se zinterpretira v interpreterju, kot del vsebine argumentnega bloka
    funkcije, ki ima ob klicu se druge podatkovne argumente, ali za grupiranje
    skupin argumentov funkcije, ki so povezani po pomenu in imajo lahko
    variabilno stevilo argumentov (taksne situacije je namrec tezje obvladovati
    brez uporabe vgnezdenih argumentnih blokov)
     Ce je vse OK, vrne pozitivno stevilo, ki je za eno vecje od dolzine
     vsebine vgnezdenega bloka, drugace pa 0.
     POZOR:
     Paziti je treba, da ima vsak vhod v vgnezden blok svoj izhod s klicem
    invexitnestblocksimp, ampak le v primeru, ce je bil vhod uspesen, torej
    ce je funkcija pri klicu vrnila pozitivno stevilo (neuspesen klic namrec
    ne postavi lokalnih podatkov in bi se pri klicu izhodne funkcije
    restavrirali podatki, ki ne pripadajo pravemu vgnezdenemu bloku.
    $A Igor okt01; */
{
int ret=0;
long pos1,pos2,*begin=NULL,*end=NULL,*arg=NULL;
char ch;
ficom fcom=com.fcom;
if (nestblocks==NULL)
  nestblocks=newstack(10);
pos1=filenotchartoret(fcom->fp," \n\r\t,\0",6,fcom->argpos,fcom->end-1,20,&ch);
if (pos1>0 && ch=='{')
{
  filebracto(fcom->fp,'{','}',pos1,fcom->end-1,100,&pos1,&pos2);
  if (pos1>0)
  {
    /* Shranjevanje pozicij vezanih na interpretacijo, kakrsne bodo po izhodu
    iz vgnezdenega bloka: */
    begin=malloc(sizeof(*begin));
    end=malloc(sizeof(*end));
    arg=malloc(sizeof(*arg));
    *begin=fcom->begin;
    *end=fcom->end;
    *arg=pos2+1;
    pushstack(nestblocks,begin);
    pushstack(nestblocks,end);
    pushstack(nestblocks,arg);
    /* Popravljanje pozicij vezanih na interpretacijo na vrednosti, ki veljejo
    znotraj vgnezdenega bloka: */
    fcom->begin=fcom->argpos=pos1;
    fcom->end=pos2;
    ++fcom->argpos;
    ret=(int)(pos2-pos1);
  }
}
return ret;
}


int invexitnestblocksimp(void)
    /* Pri interpretaciji argumentov funkcije interpreterja lupine Inverse
    povzroci izhod iz vgnezdenega argumentnega bloka, v katerega smo sli s
    klicem funkcije inventernestblocksimp. Pri tem restavrira ob vhodu v blok
    shranjene podatke interpreterja ob vhodu v blok tako, da se interpretacija
    argumentov normalno nadaljuje takoj za vgnezdenim blokom.
     Ce je vse OK, vrne pozitivno stevilo, drugace pa 0.
    $A Igor okt01; */
{
long *begin,*end,*arg;
int ret=0;
ficom fcom=com.fcom;
if (nestblocks!=NULL)
  if (nestblocks->n>0 && nestblocks->n%3==0);
  {
    arg=popstack(nestblocks);
    end=popstack(nestblocks);
    begin=popstack(nestblocks);
    fcom->begin=*begin;
    fcom->end=*end;
    fcom->argpos=*arg;
    disppointer((void **) &begin);
    disppointer((void **) &end);
    disppointer((void **) &arg);
  }
return ret;
}



    /* TESTIRANJE, CE OBSTAJAJO NADALJNJI ARGUMENTI: */



char invunreadargsimp(void)
    /* Vrne znak, ki je razlicen od \0, ce so v argumentnem bloku se neprebrani
    argumenti. V tem primeru je vrnjeni znak enak znaku, s katerim se zacne
    naslednji neprebrani argument.
    $A Igor okt01; */
{
long pos1;
char ch;
ficom fcom=com.fcom;
if (nestblocks==NULL)
  nestblocks=newstack(10);
pos1=filenotchartoret(fcom->fp," \n\r\t,\0",6,fcom->argpos,fcom->end-1,20,&ch);
if (pos1>0)
  return ch;
return '\0';
}



    /* INSTALACIJA FUNKCIJ INTERPRETERJA: */


void instfintinv(char *name,void intfunc (ficom fcom))
    /* V datotecni interpreter instalira funkcijo intfunc pod imenom name.
    $A igor avg01; */
{
instficom(com.fcom,name,intfunc);
}



              /*********************************************/
              /*                                           */
              /*  BRANJE ARGUMENTOV FUNKCIJ INTERPRETERJA  */
              /*                                           */
              /*********************************************/




FILE *invgetinterpfile(void)
    /* Vrne datoteko, ki se jo trenutno interpretira.
    $A Igor jul99; */
{
return com.fcom->fp;
}

long invgetargblockbegin(void)
    /* Vrne zacetno pozicijo argumentnega bloka funkcije, ki se jo trenutno
    interpretira.
    $A Igor jul99; */
{
return com.fcom->begin+1;
}

long invgetargblockend(void)
    /* Vrne koncno pozicijo argumentnega bloka funkcije, ki se jo trenutno
    interpretira.
    $A Igor jul99; */
{
return com.fcom->end-1;
}

long invgetargblockpos(void)
    /* Vrne trenutno pozicijo v argumentnem bloku funkcije, ki se jo trenutno
    interpretira.
    $A Igor okt99; */
{
if (com.fcom->argpos>com.fcom->begin && com.fcom->argpos<com.fcom->end)
  return com.fcom->argpos;
else
  return -1;
}

void invsetargblockpos(long pos)
    /* Postavi trenutno pozicijo v argumentnem bloku funkcije, ki se jo
    trenutno interpretira, na pos.
    $A Igor okt99; */
{
com.fcom->argpos=pos;
}


/* FUNKCIJE ZA BRANJE ARGUMENTOV FUNKCIJ DATOTECNEGA INTERPRETERJA
S PODANO DATOTEKO IN POZICIJAMI: */

/* Spodnje funkcije so namenjene za branje argumentov funkcij datotecnega
interpreterja v programu Inverse. Za argumente zahtevajo datoteko, ki se
interpretira (fp) in obmocje, v katerem naj iscejo argumente (of from do to),
naslova, kamor naj zapisejo zacetno pozicijo najdenih argumentov in pozicijo
1. znaka za prebranimi argumenti (start in next) , naslov, kamor naj zapisejo
prebrane argumente in morebitne dodatne parametre. Funkcije vrnejo kodo, ki
pove, ce je bilo branje argumentov uspesno (negativna vrednost pomeni neuspeh;
funkcije za branje vec argumentov hkrati vrnejo stevilo uspesno prebranih
argumentov). Ostale potrebne podatke (npr. sistem za ovrednotenje izrazov in
sklade, na katerih so spremenljivke) dobijo funkcije iz globalnih spremenljivk
programa. */


/* OPOMBA: Teh vrst funkcij naj se v prihodnje ne uporablja, namesto njih naj
se uporabljajo ustrezne funkcije s koncnico "simp"!!! */

static int invgetvalarg(FILE *fp,long from,long to,double *val,long *start,long *next)
    /* Prebere stevilcni argument in ga zapise v *val.
    $A Igor jul99; */
{
return freadnumarg(fp,val,from,to,com.fcom->syst,start,next);
}

static int invgetvalargs(FILE *fp,long from,long to,int maxnum,stack *valst,
               long *start,long *next)
    /* Prebere najvec maxnum stevilcnih argumentov in njihove vrednosti polozi
    na sklad *valst kot kazalce na tip double. Vrne stevilo prebranih
    argumentov oz. -1, ce je kaj narobe.
    $A Igor jul99; */
{
return freadnumargs(fp,from,to,maxnum,com.fcom->syst,valst,start,next);
}

static int invgetcountarg(FILE *fp,long from,long to,counter *cnt,long *start,long *next)
    /* Prebere stevcni argument in ga zapise v *cnt.
    $A Igor jul99; */
{
return freadcountarg(fp,cnt,from,to,com.count,com.str,com.fcom->syst,
       start,next);
}

static int invgetscalarg(FILE *fp,long from,long to,scalar *scal,long *start,long *next)
    /* Prebere skalarni argument in ga zapise v *scal.
    $A Igor jul99; */
{
return freadscalarg(fp,scal,from,to,com.scal,com.str,com.fcom->syst,
       start,next);
}

static int invgetvecarg(FILE *fp,long from,long to,vector *vec,long *start,long *next)
    /* Prebere vektorski argument in ga zapise v *vec.
    $A Igor jul99; */
{
return freadvecarg(fp,vec,'{','}',from,to,com.vec,com.str,com.fcom->syst,
       start,next);
}

static int invgetmatarg(FILE *fp,long from,long to,matrix *mat,long *start,long *next)
    /* Prebere matricni argument in ga zapise v *mat.
    $A Igor jul99; */
{
return freadmatarg(fp,mat,'{','}',':',from,to,com.mat,com.str,com.fcom->syst,
       start,next);
}

/*
static int invgetfldarg(FILE *fp,long from,long to,field *fld,long *start,long *next)
     Prebere poljski argument in ga zapise v *fld.
    $A Igor jul99; 
{
return freadfldarg(fp,fld,'{','}',':',from,to,com.fld,com.str,com.fcom->syst,
       start,next);
}
*/

int invgetstrarg(FILE *fp,long from,long to,string *str,long *start,long *next)
    /* Prebere nizovni argument in ga zapise v *str.
    $A Igor jul99; */
{
return freadstrarg(fp,str,from,to,com.str,com.fcom->syst,
       start,next);
}

static int invgetstrargs(FILE *fp,long from,long to,int maxnum,stack *st,
               long *start,long *next)
    /* Prebere najvec maxnum nizovnih argumentov in jih nalozi na sklad *st
    kot kazalce tipa char *. Ce je maxnum 0, stevilo argumentov ni omejeno.
    $A Igor jul99; */
{
return freadstrargs(fp,from,to,maxnum,com.str,com.fcom->syst,st,
       start,next);
}

int invgetvarspecarg(FILE *fp,long from,long to,char **name,stack *indst,
               long *start,long *next)
    /* Reads specification of a variable element or element sub-table from the
    interpreted file fp between positions from and to inclusive. It stores
    variable name to *name and element (or sub-table) indices to *indst, where
    they are stored as dynamically allocated pointers to int (int *).
      Returns 1 if specification could be read and 0 if not.
    $A Igor jul99; */
{
return freadvarspec(fp,from,to,com.fcom->syst,name,indst,start,next);
}


/* ENOSTAVNE FUNKCIJE ZA BRANJE ARGUMENTOV FUNKCIJ DATOTECNEGA INTERPRETERJA
BREZ PODANE DATOTEKE IN POZICIJ: */

/* Naslednje funkcije imajo za argument le naslov, kamor naj shranjo prebrane
vrednosti, in po moznosti se kak dodaten argument. Ostale podatke dobijo od
datotecnega interpreterja. Ko preberemo argument s taksno funkcijo, se postavi
pozicija iskanja naslednjega argumenta. To se ne zgodi pri uporabi drugih
funkcij (zgoraj), zato lahko spodnje funkcije upporabljamo le v kombinaciji s
podobnimi funkciji. Zacetno pozicijo iskanja za 1. argument funkcije
interpreterja postavi sam interpreter. */


int invgetvalargsimp(double *val)
    /* Prebere stevilcni argument in ga zapise v *val.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=invgetvalarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   val,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int invgetvalargssimp(int maxnum,stack *valst)
    /* Prebere najvec maxnum stevilcnih argumentov in njihove vrednosti polozi
    na sklad *valst kot kazalce na tip double. Vrne stevilo prebranih
    argumentov oz. -1, ce je kaj narobe.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=invgetvalargs(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   maxnum,valst,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int invgetcountargsimp(counter *cnt)
    /* Prebere stevcni argument in ga zapise v *cnt.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=invgetcountarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   cnt,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int invgetscalargsimp(scalar *scal)
    /* Prebere skalarni argument in ga zapise v *scal.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=invgetscalarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   scal,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int invgetvecargsimp(vector *vec)
    /* Prebere vektorski argument in ga zapise v *vec.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=invgetvecarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   vec,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int invgetmatargsimp(matrix *mat)
    /* Prebere matricni argument in ga zapise v *mat.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=invgetmatarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   mat,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

/*
int invgetfldargsimp(field *fld)
     Prebere poljski argument in ga zapise v *fld.
    $A Igor jul99; 
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=invgetfldarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   fld,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}
*/

int invgetstrargsimp(string *str)
    /* Prebere nizovni argument in ga zapise v *str.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=invgetstrarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   str,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int invgetstrargssimp(int maxnum,stack *st)
    /* Prebere najvec maxnum nizovnih argumentov in jih nalozi na sklad *st
    kot kazalce tipa char *. Ce je maxnum 0, stevilo argumentov ni omejeno.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=invgetstrargs(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   maxnum,st,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}

int invgetvarspecargsimp(char **name,stack *indst)
    /* Reads specification of a variable element or element sub-table. It stores
    variable name to *name and element (or sub-table) indices to *indst, where
    they are stored as dynamically allocated pointers to int (int *).
      Returns 1 if specification could be read and 0 or -1 if not.
    $A Igor jul99; */
{
int ret=-1;
long start=-1,next=-1;
if (com.fcom->argpos>0)
{
  ret=invgetvarspecarg(com.fcom->fp,com.fcom->argpos,com.fcom->end-1,
   name,indst,&start,&next);
  if (next>0)
    com.fcom->argpos=next;
}
return ret;
}




           /**************************************************/
           /*                                                */
           /*  MANIPULACIJA Z UPORABNISKIMI SPREMENLJIVKAMI  */
           /*                                                */
           /**************************************************/







/* Deklaracije iz invvar.c: */

int updatecountvar(char *name,int place);
int updatescalvar(char *name,int place);
int updatevecvar(char *name,int place);
int updatematvar(char *name,int place);
int updatefldvar(char *name,int place);
int updatestrvar(char *name,int place);
int updatevfivar(char *name,int place);


varholder updatecountdata(char *name,int place);
varholder updatescaldata(char *name,int place);
varholder updatevecdata(char *name,int place);
varholder updatematdata(char *name,int place);
varholder updateflddata(char *name,int place);
varholder updatestrdata(char *name,int place);
varholder updatevfidata(char *name,int place);






    /* POMOZNE FUNKCIJE ZA MANIPULACIJO S SPREMENLJIVKAMI */



/* FUNKCIJA, KI BREZPOGOJNO ZBRISEJO CELO SPREMENLJIVKO Z DANIM IMENOM: */


int invdispvar(char *typespec,char *name)
    /* Zbrise spremenljivko z imenom name, ce ustreza specifikaciji tipa
    typespec glede na funkcijo invcheckvartype(). Vrne celo stevilo, ki je 0,
    ce spremenljivka z imenom name ne obstaja ali ce ni pravega tipa, oz. zap.
    stevilko na skladu spremenljivk, ce se je brisanje izvedlo. Ce je typespec
    NULL, se brise spremenljivka z imenom name ne glede na tip.
    $A Igor okt01; */
{
int place=0;
stack varst=com.var;
varholder var;
if (( place=findsortstackvar(varst,name,0,0) ) >0)
{
  var=varst->s[place];
  if (invcheckvartype(var,typespec))
  {
    invdispvarholder((varholder *) &(varst->s[place]));
    delstack(varst,place);
  } else
    place=0;
}
return place;
}


/* FUNKCIJE, KI NAREDIJO NOVO SPREMENLJIVKO (ce spremenljivka z danim imenom
ze obstaja, se jo najprej zbrise z elementi vred): */



int invcreatevar(char *spec,char *name,stack dim)
    /* Naredi spremenljivko z imenom name in dimenzijami dim, katere tip je
    dolocen s spec. spec mora biti specifikacija, ki je razumnljiva funkciji
    invsetvartype(). Ce spremenljivka z imenom name ze obstaja, se jo
    najprej zbrise z elementi vred.
    Dimenzije na dim morajo biti kazalci na tip int. Sklad z nic elementi ali
    nealociran sklad (NULL) pomenita spremenljivko z rangom 0 (1 element).
    $A Igor avg99 sep01; */
{
int place=0;
stack varst=com.var;
varholder var;
if (( place=findsortstackvar(varst,name,0,0) ) >0)
{
  invdispvarholder((varholder *) &(varst->s[place]));
  var=varst->s[place]=newvarholdernamest(name,dim);
  invsetvartype(var,spec);
} else
{
  place=inssortstackvar(varst,(var=newvarholdernamest(name,dim)));
  invsetvartype(var,spec);
}
return place;
}


int invcreatecountvar(char *name,stack dim)
    /* Naredi stevcno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99 sep01; */
{
int place;
place=invcreatevar("counter",name,dim);
updatecountdata(name,place);
return place;
}


int invcreatescalvar(char *name,stack dim)
    /* Naredi skalarno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=invcreatevar("scalar",name,dim);
updatescaldata(name,place);
return place;
}


int invcreatevecvar(char *name,stack dim)
    /* Naredi vektorsko spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=invcreatevar("vector",name,dim);
updatevecdata(name,place);
return place;
}


int invcreatematvar(char *name,stack dim)
    /* Naredi matricno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=invcreatevar("matrix",name,dim);
updatematdata(name,place);
return place;
}


int invcreatestrvar(char *name,stack dim)
    /* Naredi nizovno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=invcreatevar("string",name,dim);
updatestrdata(name,place);
return place;
}


int invcreatevfivar(char *name,stack dim)
    /* Naredi datotecno spremenljivko z imenom name in dimenzijami dim. Ce
    spremenljivka z imenom name ze obstaja, se jo najprej zbrise z elementi
    vred.
    $A Igor avg99; */
{
int place;
place=invcreatevar("vfile",name,dim);
updatevfidata(name,place);
return place;
}




/* FUNKCIJE, KI VRACAJO NASLOVE ELEMENTOV SPREMENLJIVK: */


void **invgetvareladdr(char *spec,char *name,stack indst)
    /* Vrne naslov elementa spremenljivke, katere tip je dolocen s spec, imena
    name in z indeksno specifikacijo indst. Specifikacija tipa spremenljivke
    spec mora biti taksna, kot jo dovoljuje funkcija invgetvariablestack().
    $A Igor jul99 sep01; */
{
stack varst;
varholder var;
int place;
varst=com.var; /* invgetvariablestack(spec); */
place=findsortstackvar(varst,name,0,0);
if (place==0)
  return NULL;
else
{
  var=varst->s[place];
  if (invcheckvartype(var,spec))
    return vareladdrst(var,indst);
  else
    return NULL;
}
}

counter *invgetcounteladdr(char *name,stack indst)
    /* Vrne naslov elementa stevcne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99 sep01; */
{
/*
int place;
place=findsortstackvar(com.count,name,0,0);
if (place==0)
  return NULL;
else
  return (counter *) vareladdrst(com.count->s[place],indst);
*/
return (counter *) invgetvareladdr("counter",name,indst);
}

scalar *invgetscaleladdr(char *name,stack indst)
    /* Vrne naslov elementa skalarne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */
{
return (scalar *) invgetvareladdr("scalar",name,indst);
}

vector *invgetveceladdr(char *name,stack indst)
    /* Vrne naslov elementa vektorske spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
return (vector *) invgetvareladdr("vector",name,indst);
}

matrix *invgetmateladdr(char *name,stack indst)
    /* Vrne naslov elementa matricne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
return (matrix *) invgetvareladdr("matrix",name,indst);
}

string *invgetstreladdr(char *name,stack indst)
    /* Vrne naslov elementa nizovne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
return (string *) invgetvareladdr("string",name,indst);
}

vfile *invgetvfileaddr(char *name,stack indst)
    /* Vrne naslov elementa datotecne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
return (vfile *) invgetvareladdr("vfile",name,indst);
}





/* FUNKCIJE, KI VRACAJO ELEMENTE SPREMENLJIVK: */

void *invgetvarel(char *spec,char *name,stack indst)
    /* Vrne element spremenljivke, katere tip je dolocen s spec, imena name in 
    z indeksno specifikacijo indst. Specifikacija tipa spremenljivke spec mora
    biti taksna, kot jo dovoljuje funkcija invgetvariablestack().
    $A Igor jul99; */
{
stack varst;
varholder var;
int place;
void **addr;
varst=com.var; /* invgetvariablestack(spec); */
place=findsortstackvar(varst,name,0,0);
if (place==0)
  return NULL;
else
{
  var=varst->s[place];
  if (invcheckvartype(var,spec))
  {
    if ((addr=vareladdrst(var,indst))!=NULL)
      return *addr;
    else
      return NULL;
  } else
    return NULL;
}
}



counter invgetcountel(char *name,stack indst)
    /* Vrne element stevcne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */
{
return (counter) invgetvarel("counter",name,indst);
}

scalar invgetscalel(char *name,stack indst)
    /* Vrne element skalarne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst. Indeksi morajo biti na sklad nalozeni kot
    kazalci na int.
    $A Igor jul99; */
{
return (scalar) invgetvarel("scalar",name,indst);
}

vector invgetvecel(char *name,stack indst)
    /* Vrne element vektorske spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
return (vector) invgetvarel("vector",name,indst);
}

matrix invgetmatel(char *name,stack indst)
    /* Vrne element matricne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
return (matrix) invgetvarel("matrix",name,indst);
}

/*
field invgetfldel(char *name,stack indst)
    Vrne element poljske spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; 
{
return (field) invgetvarel("field",name,indst);
}
*/

string invgetstrel(char *name,stack indst)
    /* Vrne element nizovne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
return (string) invgetvarel("string",name,indst);
}

vfile invgetvfile(char *name,stack indst)
    /* Vrne element datotecne spremenljivke z imenom name in z indeksi,
    ki so na skladu indst.
    $A Igor jul99; */
{
return (vfile) invgetvarel("vfile",name,indst);
}


/* FUNKCIJE, KI VRACAJO SPREMENLJIVKE IN PRVE ELEMENTE SPREMENLJIVK: */

varholder invgetvar(char *spec,char *name)
    /* Vrne nosilec spremenljivke, katere tip je dolocen s spec ter imenom
    name. Specifikacija tipa spremenljivke spec mora biti taksna, kot jo
    dovoljuje funkcija invgetvariablestack().
    $A Igor aug04; */
{
stack varst;
varholder var=NULL;
int place;
void *ret=NULL;
varst=com.var; /* invgetvariablestack(spec); */
place=findsortstackvar(varst,name,0,0);
if (place>0)
{
  var=varst->s[place];
  if (!invcheckvartype(var,spec))
    var=NULL;
}
return var;
}

void *invgetvarelfirst(char *spec,char *name)
    /* Vrne prvi element spremenljivke, katere tip je dolocen s spec ter imenom
    name. Specifikacija tipa spremenljivke spec mora biti taksna, kot jo
    dovoljuje funkcija invgetvariablestack().
    $A Igor aug04; */
{
stack varst;
varholder var=NULL;
int place;
void *ret=NULL;
varst=com.var; /* invgetvariablestack(spec); */
place=findsortstackvar(varst,name,0,0);
if (place>0)
{
  var=varst->s[place];
  if (!invcheckvartype(var,spec))
    ret=NULL;
  else
    ret=varelfirst(var);
}
return ret;
}

/* FUNKCIJE, KI VRNEJO DIMENZIJE SPREMENLJIVK: */


int invvardimension(char *spec,char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije spremenljivke z imenom name in tipa, ki
    ga doloca spec (ime tipa mora biti prepoznavno za funkcijo
    invgetvariablestack). Nalozene dimenzije so tipa int *. Vrne mesto na skladu,
    na katerem se nahaja spremenljivka.
    $A Igor avg99 sep01; */
{
stack varst;
varholder var;
int place;
varst=com.var; /* invgetvariablestack(spec); */
place=findsortstackvar(varst,name,0,0);
if (place==0)
  dispstackall(dim);
else
{
  var=varst->s[place];
  if (invcheckvartype(var,spec))
    getvardimst(var,dim);
  else
  {
    dispstackall(dim);
    place=0;
  }
}
return place;
}

int invcountvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije stevcne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return invvardimension("counter",name,dim);
}

int invscalvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije skalarne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return invvardimension("scalar",name,dim);
}

int invvecvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije vektorske spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return invvardimension("vector",name,dim);
}

int invmatvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije matricne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return invvardimension("matrix",name,dim);
}

int invstrvardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije nizovne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return invvardimension("string",name,dim);
}

int invvfivardimension(char *name,stack *dim)
    /* Na sklad *dim nalozi dimenzije datotecne spremenljivke z imenom name. Nalozene
    dimenzije so tipa int *. Vrne mesto na skladu, na katerem se nahaja
    spremenljivka.
    $A Igor avg99; */
{
return invvardimension("vfile",name,dim);
}




/* FUNCTION THAT RETURNS VARIABLE TYPE: */

int invgetvartype(char *name)
    /* Returns the type of the interpreter variable named name, or 0 if the
    variable with this name does not exist. The type can be one of VT_COUNTER,
    VT_SCALAR, VT_VECTOR, VT_MATRIX, VT_STRING, or VT_VFILE, which are 
    constants defined in varop.h (when using these constants, make sure to
    include varop.h!).
    */
{
stack varst;
varholder var;
int place,ret=0;
varst=com.var;
place=findsortstackvar(varst,name,0,0);
if (place>0)
{
  var=varst->s[place];
  if (var!=NULL)
    ret=var->type;
  if (0)
  {
    printf("\nVariable named \"%s\", type \"%s\" (type ID %i).\n\n",
        name,vartypetostring(var->type),var->type);
  }
}
return ret;
}



/* FUNKCIJE, KI TESTIRAJO OBSTOJ SPREMENLJIVK: */


int invvarexists(char *spec, char *name)
    /* Vrne 0, ce spremenljivka z imenom name in specifikacijo tipa ne obstaja,
    drugace vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na
    ustreznem skladu. Ce je specifikacija NULL ali "", potem funkcija samo 
    preveri, ce obstaja spremenljivka kateregakoli tipa z danim imenom, in
    vrne tip spremenljivke, �e obstaja in 0, �e ne.
    $A Igor avg99 sep01; Domen aug05; */
{
stack varst;
varholder var;
int place;
varst=com.var; /* invgetvariablestack(spec); */
place=findsortstackvar(varst,name,0,0);
if (place>0)
{
  if( spec!=NULL  )   /* pogoj dodal domen, zdaj ni ve� potreben */
  {
    var=varst->s[place];
    if (!invcheckvartype(var,spec))
      place=0;
  }
}
return place;
}



int invcountvarexists0(char *name)
    /* Vrne 0, ce stevcna spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
return invvarexists("counter",name);
}

int invscalvarexists0(char *name)
    /* Vrne 0, ce skalarna spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
return invvarexists("scalar",name);
}

int invvecvarexists0(char *name)
    /* Vrne 0, ce vektorska spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
return invvarexists("vector",name);
}

int invmatvarexists0(char *name)
    /* Vrne 0, ce matricna spremenljivka z imenom name ne obstaja, drugace
    vrne pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
return invvarexists("matrix",name);
}

int invstrvarexists0(char *name)
    /* Vrne 0, ce nizovna spremenljivka z imenom name ne obstaja, drugace vrne
    pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
return invvarexists("string",name);
}

int invvfivarexists0(char *name)
    /* Vrne 0, ce datotecna spremenljivka z imenom name ne obstaja, drugace vrne
    pozitivno stevilo, ki je ekvivalentno mestu spremenljivke na skladu.
    $A Igor avg99; */
{
return invvarexists("vfile",name);
}




/* OPERACIJE NAD PODTABELAMI ELEMENTOV SPREMENLJIVK: */


int invvaropsimple(char *spec,char *name1,stack which1,
                void operation(void *operand))
    /* Izvede operacijo operation nad podtabelo elementov spremenljivke z imenom
    name1 in tipa, ki ga doloca specifikacija spec1. Ta mora biti prepoznavna za
    fnkcijo invcheckvartype(). Podtabelo elementov doloca indeksna specifkacija
    which1. Spremenljivka mora obstajati in mora vsebovati dano podtabelo.
    Funkcija vrne stevilo izvedenih operacij oz. negativno stevilo, ce je
    med operacijo prislo do napake.  Iz te oznake se lahko dobi niz, ki
    oznacuje napako, s funkcijo varoperrorstr.
    $A Igor okt01; */
{
int ret=-30000;
stack stvar1;
varholder var1;
int place1;
stvar1=com.var; /* invgetvariablestack(spec); */
place1=findsortstackvar(stvar1,name1,0,0);
if (place1>0)
{
  var1=stvar1->s[place1];
  if (invcheckvartype(var1,spec))
    ret=simpvaropst(var1,which1,operation);
}
return ret;
}


int invvaropunary(char *spec1,char *name1,stack which1,
               char *specres,char *nameres,stack whichres,
               void *operation(void *operand1,void **res))
    /* Izvede operacijo operation nad enakoleznimi pari podtabel elementov 
    spremenljivk, ki ju dolocata specifikaciji tipa spremenljivk spec1 in
    specres, imeni spremenljivk name1 in nameres ter specifikaciji podtabel
    which1  in whichres. operation je unarna operacija, ki se izvede na enem
    objektu, rezultat pa shrane v drugega. Spremenljivka ustrez. tipa z imenom
    name1 mora obstajati in vsebovati podtabelo, ki jo doloca which1. Ce
    specifikacija whichres vsebuje kaksne indekse, mora ustrezna podtabela
    spremenljivke z imenom res obstajati in mora imeti iste dimenzije kot
    podtabela 1. operanda. V nasprotnem primeru se vzame celotna tabela
    elementov spremenljivke res in ce ta ni ustrezne dimenzije, se cela
    spremenljivka najprej brise in nato kreira tako, da ima njena tabela
    elementov isto dimenzijo kot podtabela, ki jo doloca which1.
     Ce se funkcija uspesno izvede, vrne stevilo izvedenih operacij, drugace
    vrne negativno oznako napake. Iz te oznake se lahko dobi niz, ki oznacuje
    napako, s funkcijo varoperrorstr.
    $A Igor okt01; */
{
int ret=-30000;
stack stvar1,stres;
varholder var1,varres=NULL,*pres;
int place1,placeres;
stvar1=stres=com.var; /* invgetvariablestack(spec); */
place1=findsortstackvar(stvar1,name1,0,0);
if (place1>0)
{
  var1=stvar1->s[place1];
  if (invcheckvartype(var1,spec1))
  {
    /* Prvi operand obstaja in je pravilnega tipa, pogledamo, kako je z
    rezultatom: */
    placeres=findsortstackvar(stres,nameres,0,0);
    if (placeres>0)
    {
      /* Spremenljivka, v katero se shrane rezultat operacije, obstaja, vzamemo
      njen naslov: */
      pres=(varholder *) &(stres->s[placeres]);
      if (!invcheckvartype(*pres,specres))
      {
        /* Spremenljivka, kamor se shrane rezultat, ni pravega tipa, zato jo
        zbrisemo, za rezultat operacije vzamemo naslov neinicializirane
        spremenljivke: */
        invdispvarholder(pres);
        delstack(stres,placeres);
        pres=&varres;
      }
    } else
      /* Spremenljivka, v katero bomo hranili rezultate, se ne obstaja, zato jo
      vzamemo za operacijo naslov neinicializirane spremenljivke: */
      pres=&varres;
    /* Izvedba operacije: */
    ret=unvaropst(var1,which1,pres,whichres,operation,
     (void (*)(void **)) invdispvarel(invvartype(specres)));
    if (varres!=NULL)
    {
      /* Ker spremenljivka, v katero se shrani rezultate, ni obstajala oz. smo
      jo brisali, ker je bila napacnega tipa, moramo postaviti ime in tip
      spremenljivke, katere nastanek je rezultat operacije, in spremenljivko
      shraniti na ustrezni sklad spremenljivk: */
      varres->name=stringcopy(nameres);
      invsetvartype(varres,specres);
      inssortstackvar(stres,varres);
    }
  }
}
return ret;
}


int invvaropbinary(char *spec1,char *name1,stack which1,
                char *spec2,char *name2,stack which2,
                char *specres,char *nameres,stack whichres,
                void *operation(void *operand1,void *operand2,void **res))
    /* Izvede operacijo operation nad istoleznimi trojicami elementov podtabel,
    ki jih dolocajo specifikacije tipa spremenljivk spec1, spec2 in specres,
    imena spremenljivk name1, name2 in nameres ter specifikacije podtabel
    elementov which1, which2 in whichres. operation je binarna operacija, ki se
    izvede na dveh objektih, rezultat pa shrane v tretjega.
     Spremenljivki ustrez. tipa z imenoma name1 in name2 morata obstajati in
    vsebovati podtabeli, ki jo dolocata which1 in which2, le-ti morata biti
    istih dimenzij. Ce specifikacija whichres vsebuje kaksne indekse, mora
    ustrezna podtabela spremenljivke z imenom res obstajati in mora imeti iste
    dimenzije kot podtabeli operandov. V nasprotnem primeru se vzame celotna
    tabela elementov spremenljivke res in ce ta ni ustrezne dimenzije, se cela
    spremenljivka najprej brise in nato kreira tako, da ima njena tabela
    elementov isto dimenzijo kot podtabela, ki jo doloca which1.
     Ce se funkcija uspesno izvede, vrne stevilo izvedenih operacij, drugace
    vrne negativno oznako napake. Iz te oznake se lahko dobi niz, ki oznacuje
    napako, s funkcijo varoperrorstr.
    $A okt01; */
{
int ret=-30000;
stack stvar1,stvar2,stres;
varholder var1,var2,varres=NULL,*pres;
int place1,place2,placeres;
stvar1=stvar2=stres=com.var; /* invgetvariablestack(spec); */
place1=findsortstackvar(stvar1,name1,0,0);
if (place1>0)
  place2=findsortstackvar(stvar2,name2,0,0);
if (place1>0 && place2>0)
{
  var1=stvar1->s[place1];
  var2=stvar2->s[place2];
  if (invcheckvartype(var1,spec1) && invcheckvartype(var2,spec2))
  {
    /* Oba operanda obstajata in sta pravilnega tipa, pogledamo, kako je z
    rezultatom: */
    placeres=findsortstackvar(stres,nameres,0,0);
    if (placeres>0)
    {
      /* Spremenljivka, v katero se shrane rezultat operacije, obstaja, vzamemo
      njen naslov: */
      pres=(varholder *) &(stres->s[placeres]);
      if (!invcheckvartype(*pres,specres))
      {
        /* Spremenljivka, kamor se shrane rezultat, ni pravega tipa, zato jo
        zbrisemo, za rezultat operacije vzamemo naslov neinicializirane
        spremenljivke: */
        invdispvarholder(pres);
        delstack(stres,placeres);
        pres=&varres;
      }
    } else
      /* Spremenljivka, v katero bomo hranili rezultate, se ne obstaja, zato jo
      vzamemo za operacijo naslov neinicializirane spremenljivke: */
      pres=&varres;
    /* Izvedba operacije: */
    ret=binvaropst(var1,which1,
                var2,which2,
                pres,whichres,operation,
                (void (*)(void **)) invdispvarel(invvartype(specres)) );
    if (varres!=NULL)
    {
      /* Ker spremenljivka, v katero se shrani rezultate, ni obstajala oz. smo
      jo brisali, ker je bila napacnega tipa, moramo postaviti ime in tip
      spremenljivke, katere nastanek je rezultat operacije, in spremenljivko
      shraniti na ustrezni sklad spremenljivk: */
      varres->name=stringcopy(nameres);
      invsetvartype(varres,specres);
      inssortstackvar(stres,varres);
    }
  }
}
return ret;
}





    /* TESTI FUNKCIJ ZA BRANJE ARGUMENTOV: */

   /*  T O   B E   I M P L E M E N T E D  */


    /* FUNKCIJE ZA DELO S KALKULATORJEM */



void instcalcinv(char *name,double fdoubleval (object,stack,stack,int,void *))
    /* V sistem kalkulatorja programa instalira funkcijo fdoubleval pod imenom
    name.
    $A igor avg01; */
{
installuserfunc(com.fcom->syst,name,fdoubleval,NULL,NULL,NULL);
}



void invassigncalcvar(char *name,double val)
    /* Spremenljivki kalkulatorja z imenom name priredi vrednost val. Ce taksna
    spremenljivka se ne obstaja, se naredi na novo.
    $A Igor jul99; */
{
assigndouble(com.fcom->syst,name,val);
}


int invgetcalcarg(int i,double *val,char **strval,object obj,stack st,
                  stack user)
    /* Racunanje vrednosti i-tega argumenta uporabniske funkcije kalkulatorja,
    ki se trenutno vrednoti. Ce je i-ti argument stevilski, vrne funkcija 1 in
    zapise v kalkulatorju izracunano vrednost argumenta, ce je argument niz,
    vrne funkcija 2 in zapise niz v *strval, ce pa i. argumenta ni, vrne
    0. Niz, ki se ha zapise v *strval, se ne sme brisati ali spreminjati.
    Argumenti obj, st in user so ustrezni argumenti uporabnisko definirane
    funkcije kalkulatorja, ki jih le-ta dobi ob klicu.
    $A Igor avg01; */
{
int ret=0; 
object oo;
*val=0;
*strval=NULL;
if (st->n>=i)
{
  oo=nstack(st,i);
  if (oo!=NULL)
  {
    if (oo->kind=='0' && oo->subkind=='s')
    {
      ret=2; /* nizovni argument */
      *strval=(char*) oo->v;
    } else
    {
      ret=1;
      *val=doubleval(oo,st,user);
    }
  }
}
return ret;
}


double invgetcalcargval(int i,object obj,stack st,stack user)
    /* Vrne vrednost i-tega argumenta uporabniske funkcije kalkulatorja,
    ki se trenutno vrednoti. Ce ta argument ne obstaja ali ni stevilskega tipa,
    javi funkcija napako.
    $A Igor avg01; */
{
char *str=NULL;
double val=0;
int code;
if ((code=invgetcalcarg(i,&val,&str,obj,st,user)!=1))
{
  if (code==2)
  {
    ercalcinv0();
    fprintf(inverf(),"Function invgetcalcargval:\n");
    fprintf(inverf(),"Expression evaluator argument No. %i is of string instead of scalar type.\n",i);
    ercalcinv2();
  } else
  {
    ercalcinv0();
    fprintf(inverf(),"Function invgetcalcargval:\n");
    fprintf(inverf(),"Expression evaluator argument No. %i does not exist.\n",i);
    ercalcinv2();
  }
}
return val;
}


char *invgetcalcargstr(int i,object obj,stack st,stack user)
    /* Vrne niz, ki ustreza i-temu argumenta uporabniske funkcije kalkulatorja,
    ki se trenutno vrednoti. Ce ta argument ne obstaja ali ni nizovnega tipa,
    javi funkcija napako.
    $A Igor avg01; */
{
char *str=NULL;
double val=0;
int code;
if ((code=invgetcalcarg(i,&val,&str,obj,st,user)!=2))
{
  if (code==2)
  {
    ercalcinv0();
    fprintf(inverf(),"Function invgetcalcargstr:\n");
    fprintf(inverf(),"Expression evaluator argument No. %i is of scalar instead of string type.\n",i);
    ercalcinv2();
  } else
  {
    ercalcinv0();
    fprintf(inverf(),"Function invgetcalcargstr:\n");
    fprintf(inverf(),"Expression evaluator argument No. %i does not exist.\n",i);
    ercalcinv2();
  }
}
return str;
}




#endif  /* ifdef INVCLOSED */






/* BRANJE STEVILSKIH IN NIZOVNIH ARGUMENTOV - NADOMESTKI ZA STAREJSE FUNKCIJE: */


stack freadstringargsprev(FILE *fp,char *left,int nleft,char *right,int nright,
                   long from,long to,int maxnum,int buflength,
                   long *begin,long *next)
    /* Ta funkcija je nadomestilo za prejsnjo funkcijo freadstringssimp(), ki se
    je uporabljala za branje nizovnih argumentov funkcij interpreterja.
    Funkcija naj se NE UPORABLJA vec, namesto tega naj se uporablja
    invgetstrargsimp()! Funkcija ima nekaj odvecnih argumentov, ki se sploh ne
    uporabljajo, ker je njen edini namen nadomestiti prejsnjo funkcijo in
    hkrati delovati na nacin, na katerega delujejo zdajsnje funkcije.
    $A Igor jul99; */
{
stack ret;
ret=newstack(10);
freadstrargs(fp,from,to,maxnum,com.str,com.fcom->syst,&ret,begin,next);
return ret;
}



int freadvarspecargprev(FILE *fp,long from, long to,ssyst syst,
                        char **name,stack *ind,long *start,long *newdata)
    /* Ta funkcija je nadomestilo za prejsnjo freadvarspec(), ki se je
    uporabljala za branje specifikacij spremenljivk in njihovih podtabel
    oziroma posameznih elementov.
    Funkcija naj se NE UPORABLJA vec, namesto tega naj se uporablja
    freadsvarspecarg()! Funkcija ima nekaj odvecnih argumentov, ki se sploh ne
    uporabljajo, ker je njen edini namen nadomestiti prejsnjo funkcijo in
    hkrati delovati na nacin, na katerega delujejo zdajsnje funkcije.
    $A Igor jul99; */
{
return freadvarspecarg(fp,from,to,com.str,syst,name,ind,start,newdata);
}


long freadvarspecargsimpprev(FILE *fp,long from, long to,ssyst syst,
                        char **name,stack *ind)
    /* Ta funkcija je nadomestilo za prejsnjo freadvarspecsimp(), ki se je
    uporabljala za branje specifikacij spremenljivk in njihovih podtabel
    oziroma posameznih elementov.
    Funkcija naj se NE UPORABLJA vec, namesto tega naj se uporablja
    freadsvarspecargsimp()! Funkcija ima nekaj odvecnih argumentov, ki se sploh
    ne uporabljajo, ker je njen edini namen nadomestiti prejsnjo funkcijo in
    hkrati delovati na nacin, na katerega delujejo zdajsnje funkcije.
    $A Igor jul99; */
{
return freadvarspecargsimp(fp,from,to,com.str,syst,name,ind);
}







