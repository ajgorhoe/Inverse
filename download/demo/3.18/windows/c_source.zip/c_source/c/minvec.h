#include <sysint.h>

#include <stdio.h>
#include <math.h>



#include <er.h>

#include <mtypes.h>
#include <minnd.h>
#include <mat.h>
#include <vec.h>



FILE *fp;
int countan;






double vfunc(_vector x)
       /* Skalarna funkcija vektorske spremenljivke */
{
double a,b;
++ countan;
a=x.v[1]*x.v[1]/10;
b=x.v[2]*x.v[2];
return(0.1+a+b+x.v[1]);
}







int connection (int a)
{
}

int connection1(int a)
{
fflush(fp);
}













void main()
{
int dim=2, it, maxit=500;
double tol;
_matrix simp;
_vector x,y;
int i,j;
_vector centre;
double a3,a4,a5,a6;

/* Dodatne spremenljivke za funkcijo powell */
_vector pointmin={0}, hbrak={0};
_matrix mdir={0};
double fmin, tolbrent, smallbrak;



/* errf=fopen("xerr","ab"); */
fp=fopen("xxx","ab+");
errmode =0;


dim=2;
getvec(&pointmin,dim);    getvec(&hbrak,dim);
pointmin.v[1]=8.34;
pointmin.v[2]=1.14;
fmin=vfunc(pointmin);
hbrak.v[1]=1;
hbrak.v[2]=1;
it=0;
maxit=20;
tol=1.0e-6;
tolbrent=1.0e-9;

it=0;    countan=0;

minrec2d(&pointmin, &fmin, &hbrak,  tol, 
              &it, maxit,
              vfunc,connection1,fp);
             


fprintf(fp,"\n\n\n\n\n\n\n\n");
fprintvec(fp,pointmin);
fprintf(fp,"VREDNOST FUNKCIJE: %g",vfunc(pointmin));
fprintf(fp,"\n\n\n\n\n\n\n\n");
fflush(fp);
printf("\n\n\n\n\n\n\n\n");
printvec(pointmin);
printf("VREDNOST FUNKCIJE: %20.15g\n",vfunc(pointmin));
printf("Stevilo iteracij  : %i\n",it);
printf("Stevilo izracunov : %i\n",countan);
printf("\n\n\n\n\n\n\n\n");

getchar();










dim=2;
mdir=identitymat(dim);
dispmat(&mdir);
mdir=identitymat(dim);
printf("USPESNO BRISANJE.");
mdir.m[1][2]=1;
mdir.m[2][1]=0.1;
getvec(&pointmin,dim);    getvec(&hbrak,dim);
pointmin.v[1]=8.34;
pointmin.v[2]=1.14;
fmin=vfunc(pointmin);
hbrak.v[1]=1;
hbrak.v[2]=1;
smallbrak=1.0e-4;
it=0;
maxit=20;
tol=1.0e-7;
tolbrent=1.0e-9;

it=0;    countan=0;

/*
powellinitdir(&pointmin, &fmin, &mdir,
       tol, &it, maxit,
       &hbrak, &tolbrent, 40,    
       vfunc,connection1,fp);
*/




fprintf(fp,"\n\n\n\n\n\n\n\n");
fprintvec(fp,pointmin);
fprintf(fp,"VREDNOST FUNKCIJE: %g",vfunc(pointmin));
fprintf(fp,"\n\n\n\n\n\n\n\n");
fflush(fp);
printf("\n\n\n\n\n\n\n\n");
printvec(pointmin);
printf("VREDNOST FUNKCIJE: %20.15g\n",vfunc(pointmin));
printf("Stevilo iteracij  : %i\n",it);
printf("Stevilo izracunov : %i\n",countan);
printf("\n\n\n\n\n\n\n\n");

getchar();






/*
mdir=identitymat(dim);
mdir.m[1][2]=1;
mdir.m[2][1]=0.1;
getvec(&pointmin,dim);    getvec(&hbrak,dim);
pointmin.v[1]=8.34;
pointmin.v[2]=1.14;
fmin=vfunc(pointmin);
hbrak.v[1]=1;
hbrak.v[2]=1;
smallbrak=1.0e-4;
it=0;
maxit=20;
tol=1.0e-3;
tolbrent=1.0e-4;

it=0;    countan=0;
powell(&pointmin, &fmin, &mdir,
       tol, &it, maxit,
       &hbrak, &tolbrent, 40,    
       vfunc,connection1,fp);


fprintf(fp,"\n\n\n\n\n\n\n\n");
fprintvec(fp,pointmin);
fprintf(fp,"VREDNOST FUNKCIJE: %g",vfunc(pointmin));
fprintf(fp,"\n\n\n\n\n\n\n\n");
fflush(fp);
printf("\n\n\n\n\n\n\n\n");
printvec(pointmin);
printf("VREDNOST FUNKCIJE: %g\n",vfunc(pointmin));
printf("Stevilo iteracij  : %i\n",it);
printf("Stevilo izracunov : %i\n",countan);
printf("\n\n\n\n\n\n\n\n");

getchar();







mdir=identitymat(dim);
mdir.m[1][2]=1;
mdir.m[2][1]=0.1;
getvec(&pointmin,dim);    getvec(&hbrak,dim);
pointmin.v[1]=8.34;
pointmin.v[2]=1.14;
fmin=vfunc(pointmin);
hbrak.v[1]=1;
hbrak.v[2]=1;
smallbrak=1.0e-4;
it=0;
maxit=20;
tol=1.0e-3;
tolbrent=1.0e-4;

it=0;    countan=0;
/*
powell1(&pointmin, &fmin, &mdir,
       tol, &it, maxit,
       &hbrak, &tolbrent, 40,    
       vfunc,connection1,fp);
*/





fprintf(fp,"\n\n\n\n\n\n\n\n");
fprintvec(fp,pointmin);
fprintf(fp,"VREDNOST FUNKCIJE: %g",vfunc(pointmin));
fprintf(fp,"\n\n\n\n\n\n\n\n");
fflush(fp);
printf("\n\n\n\n\n\n\n\n");
printvec(pointmin);
printf("VREDNOST FUNKCIJE: %g\n",vfunc(pointmin));
printf("Stevilo iteracij: %i\n",it);
printf("Stevilo izracunov : %i\n",countan);
printf("\n\n\n\n\n\n\n\n");

getchar();




/* MINSIMP: */

it=0;
dim=2;
tol=1.0e-40;

getmat(&simp,dim+1,dim);
getvec(&x,dim);
getvec(&y,dim+1);


a3=pointmin.v[1];
a4=pointmin.v[2];

simp.m[1][1]=-0+a3;
simp.m[1][2]=-0.01+a3;

simp.m[2][1]=-0.01+a3;
simp.m[2][2]=-0+a3;

simp.m[3][1]=0.01+a3;
simp.m[3][2]=-0.01+a3;


for (i=1; i<=dim+1; ++i)
{
  for (j=1; j<=dim; ++j)
    x.v[j]=simp.m[i][j];
  y.v[i]=vfunc(x);
}

printf("ZACETNI PRIBLIZEK: \n");
printmat(simp);


printf("\n\n");

tol=1.0e-10;
maxit=100;


it=0;     countan=0;
minsimp(
&simp, 
&y,
&centre,
tol, 
&it, 
maxit, 
vfunc,connection,fp);


printf("\n\n");
printf("Stevilo iteracij: %i\n",it);
printf("Stevilo izracunov : %i\n",countan);
printf("Vrednost funkcije: \n");
printvec(y);






printmat(simp);



fclose(fp);

}




