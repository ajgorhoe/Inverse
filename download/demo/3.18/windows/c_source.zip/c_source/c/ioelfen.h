/*** Branje polj iz datotek tipa *.dat ***/

long freaddatfield(FILE *fp,char *keystr,long from,field *fld)
    /* Iz datoteke fp prebere prvo polje stevil, oznaceno z imenom keystr
    od pozicije from naprej. Funkcija uposteva da so podatki urejeni tako,
    kot v vhodni datoteki tipa *.dat za program ELFEN. Podatke nalozi na
    strukturo tipa field s funkcijo freadfieldcomp. V primeru napake pri 
    branju dobi polje fld vrednost NULL. Funkcija vrne pozicijo konca polja.
    V primeru napake vrne -1.
    $A Damjan jul98; */
{
int buf=30;
long pos,ret=-1;

if(fp!=NULL && keystr!=NULL && from>0)
{
  pos=filestring(fp,keystr,from,buf);
  if(pos>0)
  {
    pos=filechar(fp,"\n",1,pos,20);
    ret=freadfieldcomp(fp,pos,fld,0,0);
  } else
  {
    dispfield(fld);
    *fld=NULL;
  }
} else
  if((*fld)!=NULL)
  {
    dispfield(fld);
    *fld=NULL;
  }
return(ret);
}


/*** Branje polj iz datotek tipa *.neu ***/

long freadneufield(FILE *fp,char *keystr,long from,field *fld)
    /* Iz datoteke fp prebere prvo polje stevil od pozicije from naprej,
    ki je oznaceno z imenom keystr. Dimenzije tabele prebere iz standardne
    definicije polja. Podatke nalozi na strukturo tipa field s funkcijo 
    freadfieldcomp. V primeru napake pri branju dobi polje fld vrednost NULL.
    Funkcija vrne pozicijo konca polja. V primeru napake vrne -1.
    $A Damjan maj98 jul98; */
{
int col,lin;
long pos,ret=-1;

pos=freadfieldheader(fp,keystr,from,&lin,&col);
if(pos>0)
{
  ret=freadfieldcomp(fp,pos,fld,lin,col);
  ret=filechar(fp,"}",1,ret,20);
} else
  if((*fld)!=NULL)
  {
    dispfield(fld);
    fld=NULL;
  }
return(ret);
}


/*** Branje podatkov iz datotek tipa *.res ***/

long freadresfield(FILE *fp,char *keystr,long from,field *fld)
    /* Iz datoteke fp prebere prvo polje stevil z imenom keystr od pozicije
    from naprej. Funkcija uposteva da so podatki urejeni tako, kot v izhodni
    datoteki tipa *.res za program ELFEN. Podatke nalozi na strukturo tipa
    field s funkcijo freadfieldcomp. V primeru napake pri branju dobi polje fld
    vrednost NULL. Funkcija vrne pozicijo konca polja. V primeru napake vrne -1.
    $A Damjan maj98; */
{
int buflength=1000,length;
long pos,pos1,ret=-1;


if(fp!=NULL && keystr!=NULL && from>0)
{
  pos=filestring(fp,keystr,from,buflength);
  pos1=filechar(fp,"\n",1,pos,20);
  pos=filechar(fp,"=",1,pos,20);
  if(pos-pos1<5)
  {
    filenum(fp,pos1,10,&pos,&length);
    if (pos>0)
      ret=freadfieldcomp(fp,pos,fld,0,0);
    else
      if((*fld)!=NULL)
      {
        dispfield(fld);
        fld=NULL;
      }
  }
} else
  if((*fld)!=NULL)
  {
    dispfield(fld);
    fld=NULL;
  }
return(ret);
}


/*** Zamenjava vsebine polj v vhodnih datotekah za program Elfen ***/

long freplacefield(field fld,FILE *fp,char *keystr,long from)
    /* Funkcija v navedeni datoteki fp najde prvo polje z imenom keystr 
    za pozicijo from, doloci njegove meje in nadomesti njegove komponente
    s komponentami polja fld. Datoteka s zamenjanimi komponentami polja se
    shrani pod imenom "invan.tmp". Funkcija vrne pozicijo zacetka polja v 
    vhodni datoteki fp. V primeru napake vrne -1.
    $A Damjan jun98; */
{
int length,buflength=1000;
long start,numstart,end,pos,pos1,pos2,ret=-1;
double x;
char *tmpstr=NULL;
FILE *temp;

if(fp!=NULL)
{
  if(fld!=NULL)
  {
    if(fld->st->n>0)
    {
      pos=filestring(fp,keystr,from,buflength);
      if(pos>0)
      {
        pos=filechar(fp,"\n",1,pos,20);
        ret=start=pos;
        do
        {
          pos1=filenotchar(fp," \n\r\t\0",5,pos,20);
          pos2=filechar(fp," \n\r\t\0",5,pos1,20);
          x=filenumto(fp,pos1,pos2,buflength,&numstart,&length);
          if(numstart>0)
            pos=pos2;
        } while(numstart>0);
        end=pos;
        if(end-start>0)
        {
          temp=fopen("invan.tmp","w");
          fcopyfilepart(fp,1,start,temp,buflength);
          fwritefieldcomp(temp,fld);
          fcopyfilepart(fp,end,flength(fp),temp,buflength);
          fflush(temp);
          fclose(temp);
        } 
      } else
        printf("FIELD \"%s\" NOT FOUND.\n",keystr);
    } else
      printf("EMPTY FIELD.\n");
  } else
    printf("NULL FIELD.\n");   
} else
  printf("NULL FILE.\n");
if(tmpstr!=NULL)
  free(tmpstr);
return(ret);
}



/********* Dodatne funkcije *********/


/* Pomozna funkcija za urejanje skladov */
static cmp(void *p1,void *p2)
{
if(*((int *)p1)>*((int *)p2))
  return 1;
else if(*((int *)p1)<*((int *)p2))
  return -1;
else
  return 0;
}


/* Pomozna za izracun vrednosti lagrangeovega polinoma skozi dane tocke */

double lagrange(double xx, vector x, vector y)
  /* Funcija izracuna vrednost Lagrangeovega interpolacijskega polinoma skozi
  tocke podanne z vektorjema koordinat x in y (x1,x2,..,xn) v tocki xx.
  $A Damjan sep98 */
{
int i,j,n;
double k,ret=0;

if(x!=NULL && y!=NULL)
{
  n=x->d;
  if(n>1 && n==y->d)
  {
    if(xx>=x->v[1] && xx<=x->v[n])
    {
      for(i=0;i<=n-1;++i)
      {
        k=1;
        j=0;
        do
        {
          if(i!=j)
            k=k*(xx-x->v[j])/(x->v[i]-x->v[j]);
          ++j;
        } while(j<=n-1 && k!=0);
        ret+=k*y->v[i];
      }
    } else
    {
      printf(" Internal error; function lagrange: x coordinate out of range.\n");
      ret=infinity();
    }  
  } else
  {
    printf("Internal error; function lagrange: Wrong input vector dimension.\n"); 
    ret=infinity();
  }  
} else
{
  printf("Internal error; function lagrange: Input vector not defined.\n");
  ret=infinity();
}  
return(ret);
}


/* Funkciji za izracun vrednosti "spline" polinoma 3. reda skozi dane tocke */

int spline_sec_derivs(vector x,vector y, double yp1, double ypn, vector *y2)
  /* Funkcija izracuna vrednosti drugih odvodov zlepka interpolacijskih 
     polinomov 3. stopnje (splines) v interpolacijskih tockah (xi,yi), ki so 
     podane z vektorjema x in y (x1,x2,..,xn). Dodatni podatki so 
     vrednosti 1. odvodov v robnih tockah interpolacijskega intervala yp1 in 
     yp2. Vrednosti izracunanih 2. odvodov se shranijo v vektor y2. 
     Vrednosti 2. odvodov potrebujemo pri izracunu vrednosti inerpolacijske 
     funkcije, njenih 1. odvodov in integrala interpolacijske funkcije na 
     interpolacijskem intervalu.
     $A Damjan sep98
  */ 
{
int i,k,n,ret=0;
double p,qn,sig,un;
vector u;

if(x!=NULL && y!=NULL)
{
  n=x->d;
  if(n>1 && n==y->d)
  {
    u=getvector(n-1);
    if(*y2!=NULL)
      dispvector(y2);
    *y2=getvector(n);
    if (yp1 > 0.99e30)
      (*y2)->v[1]=u->v[1]=0.0;
    else
    {
      (*y2)->v[1] = -0.5;
      u->v[1]=(3.0/(x->v[2]-x->v[1]))*
      ((y->v[2]-y->v[1])/(x->v[2]-x->v[1])-yp1);
    }
    for (i=2;i<=n-1;i++) 
    {
      sig=(x->v[i]-x->v[i-1])/(x->v[i+1]-x->v[i-1]);
      p=sig*(*y2)->v[i-1]+2.0;
      (*y2)->v[i]=(sig-1.0)/p;
      u->v[i]=(y->v[i+1]-y->v[i])/(x->v[i+1]-x->v[i])-
      (y->v[i]-y->v[i-1])/(x->v[i]-x->v[i-1]);
      u->v[i]=(6.0*u->v[i]/(x->v[i+1]-x->v[i-1])-sig*u->v[i-1])/p;
    }
    if (ypn > 0.99e30)
      qn=un=0.0;
    else
    {
      qn=0.5;
      un=(3.0/(x->v[n]-x->v[n-1]))*(ypn-(y->v[n]-y->v[n-1])/
      (x->v[n]-x->v[n-1]));
    }
    (*y2)->v[n]=(un-qn*u->v[n-1])/(qn*(*y2)->v[n-1]+1.0);
    for (k=n-1;k>=1;k--)
      (*y2)->v[k]=(*y2)->v[k]*(*y2)->v[k+1]+u->v[k];
    dispvector(&u);
    ret=n;
  } else
  {
    printf("Internal error; function spline_sec_derivs: Wrong input vector dimension.\n"); 
    if(*y2!=NULL)
      dispvector(y2);
    *y2=NULL;
  }  
} else
{
  printf("Internal error; function spline_sec_derivs: Input vector not defined.\n");
}  
return(ret);
}


double spline(double xx,vector x,vector y,vector y2)
  /*
  Funkcija vrne vrednost interpolacijske funkcije v tocki x, ki mora
  biti znotraj interpolacijskega intervala. Poleg koordinate x so vhodni 
  podatki se vektorja koordinat interpolacijskih tock x in y ter vektor drugih
  odvodov interpolacijske funkcije v tockah xi, ki jih dobimo s funkcijo 
  spline_sec_derivs. V primeru neustreznih vhodnih podatkov funkcija vrne 
  infinity().
  $A Damjan sep98
  */
{
int klo,khi,k,n;
double h,b,a,ret;/*=-infinity();*/

if(x!=NULL && y!=NULL && y2!=NULL)
{
  n=x->d;
  if(n>1 && n==y->d && n==y2->d)
  {
    if(xx>=x->v[1] && xx<=x->v[n])
    {
      klo=1;
      khi=n;
      while (khi-klo > 1) 
      {
        k=(khi+klo) >> 1;
        if (x->v[k] > xx) 
          khi=k;
        else 
          klo=k;
      }
      h=x->v[khi]-x->v[klo];
      if(h>0.0)if(h>0.0)
      {
        a=(x->v[khi]-xx)/h;
        b=(xx-x->v[klo])/h;
        ret=a*y->v[klo]+b*y->v[khi]+((a*a*a-a)*y2->v[klo]+(b*b*b-b)*y2->v[khi])*(h*h)/6.0;
      }
    } else
      printf(" Internal error; function spline: x coordinate out of range.\n");  
  } else
    printf("Internal error; function spline: Wrong input vector dimension.\n"); 
} else
  printf("Internal error; function spline: Input vector(s) not defined.\n");
return(ret);
}


double spline_integral(double xl,double xh,vector x,vector y,vector y2)
  /*
  Funkcija vrne velikost dolocenega integrala interpolacijske funkcije z 
  mejama x1 in x2, morata biti vsebovani v interpolacijskem intervalu. 
  Vhodni podatki so meji intervalov x1 in x2 ter vektorja koordinat
  interpolacijskih tock x in y ter vektor drugih odvodov interpolacijske
  funkcije, ki jih dobimo s funkcijo spline_sec_derivs.
  $A Damjan sep98 nov98
  */
{
int i,n,n1,n2,klo,khi,k;
double xa,xb,x1,x2,ya,yb,y2a,y2b,h,s1=0,s2=0,ss=0,ret=-infinity();

if(x!=NULL && y!=NULL && y2!=NULL)
{
  n=x->d;
  if(n>1 && n==y->d && n==y2->d)
  {
    if(xl>=x->v[1] && xl<=x->v[n] && xh>=x->v[1] && xh<=x->v[n])
    {
      if(xl!=xh)
      {
        if(xl>xh)
        {
          xa=xl;
          xl=xh;
          xh=xa;
        }
      
        klo=1;
        khi=n;
        while (khi-klo > 1) 
        {
          k=(khi+klo) >> 1;
          if (x->v[k] >= xl) 
            khi=k;
          else 
            klo=k;
        }
        n1=klo;
        
        klo=1;
        khi=n;
        while (khi-klo > 1) 
        {
          k=(khi+klo) >> 1;
          if (x->v[k] >= xh) 
            khi=k;
          else 
            klo=k;
        }
        n2=klo;
        
        if(n1==n2 || (n1==n2-1 && xl==x->v[n2]))
        {
          xa=x->v[n2];
          xb=x->v[n2+1];  
          x1=xl;
          x2=xh;
          h=xb-xa;
          if(h>0)
          {
            ya=y->v[n2];
            yb=y->v[n2+1];
            y2a=y2->v[n2];
            y2b=y2->v[n2+1];      
            ss=1/(24*h)*(x1-x2)*(x2*x2*x2*y2a-4*x2*x2*xb*y2a+6*x2*xb*xb*y2a-
            4*xb*xb*xb*y2a+x1*x1*x1*(y2a-y2b)-x2*x2*x2*y2b+4*x2*x2*xa*y2b-
            6*x2*xa*xa*y2b+4*xa*xa*xa*y2b-2*h*h*(x2*y2a-2*xb*y2a+x1*(y2a-y2b)-
            x2*y2b+2*xa*y2b)+x1*x1*(x2*y2a-4*xb*y2a-x2*y2b+4*xa*y2b)+12*x2*ya-
            24*xb*ya+x1*(x2*x2*y2a-4*x2*xb*y2a+6*xb*xb*y2a-x2*x2*y2b+
            4*x2*xa*y2b-6*xa*xa*y2b+12*ya-12*yb)-12*x2*yb+24*xa*yb);
          }
		  ret=ss;
        } else
        {
          if(n2-n1 >= 1)
          {
            xa=x->v[n1];
            xb=x->v[n1+1];  
            x1=xl;
            x2=xb; 
            h=xb-xa;
            if(h>0)
            {
              ya=y->v[n1];
              yb=y->v[n1+1];
              y2a=y2->v[n1];
              y2b=y2->v[n1+1];      
              s1=1/(24*h)*(x1-x2)*(x2*x2*x2*y2a-4*x2*x2*xb*y2a+6*x2*xb*xb*y2a-
              4*xb*xb*xb*y2a+x1*x1*x1*(y2a-y2b)-x2*x2*x2*y2b+4*x2*x2*xa*y2b-
              6*x2*xa*xa*y2b+4*xa*xa*xa*y2b-2*h*h*(x2*y2a-2*xb*y2a+x1*(y2a-y2b)-
              x2*y2b+2*xa*y2b)+x1*x1*(x2*y2a-4*xb*y2a-x2*y2b+4*xa*y2b)+12*x2*ya-
              24*xb*ya+x1*(x2*x2*y2a-4*x2*xb*y2a+6*xb*xb*y2a-x2*x2*y2b+
              4*x2*xa*y2b-6*xa*xa*y2b+12*ya-12*yb)-12*x2*yb+24*xa*yb);
            }
            
            xa=x->v[n2];
            xb=x->v[n2+1];  
            x1=xa;
            x2=xh; 
            h=xb-xa;
            if(h>0)
            {
              ya=y->v[n2];
              yb=y->v[n2+1];
              y2a=y2->v[n2];
              y2b=y2->v[n2+1];      
              s2=1/(24*h)*(x1-x2)*(x2*x2*x2*y2a-4*x2*x2*xb*y2a+6*x2*xb*xb*y2a-
              4*xb*xb*xb*y2a+x1*x1*x1*(y2a-y2b)-x2*x2*x2*y2b+4*x2*x2*xa*y2b-
              6*x2*xa*xa*y2b+4*xa*xa*xa*y2b-2*h*h*(x2*y2a-2*xb*y2a+x1*(y2a-y2b)-
              x2*y2b+2*xa*y2b)+x1*x1*(x2*y2a-4*xb*y2a-x2*y2b+4*xa*y2b)+12*x2*ya-
              24*xb*ya+x1*(x2*x2*y2a-4*x2*xb*y2a+6*xb*xb*y2a-x2*x2*y2b+
              4*x2*xa*y2b-6*xa*xa*y2b+12*ya-12*yb)-12*x2*yb+24*xa*yb);
            }
            for(i=n1+1;i<n2;++i)
            {
              xa=x->v[i];
              xb=x->v[i+1];
              ya=y->v[i];
              yb=y->v[i+1];
              y2a=y2->v[i];
              y2b=y2->v[i+1];      
              h=xb-xa;
              ss+=-1/(24*h)*(xa-xb)*(xa-xb)*(2*h*h *y2a -xa*xa*y2a+2*xa*xb*y2a-xb*xb*y2a+ 
              2*h*h*y2b-xa*xa*y2b+2*xa*xb*y2b-xb*xb*y2b-12*ya-12*yb);
            }
            ss+=s1+s2;
            ret=ss; 
          }
        }
      } else ret=0.0; 
    } else
      printf(" Internal error; function spline_integral: Integral limits out of range.\n");        
  } else
    printf(" Internal error; function spline_integral: Wrong input vector(s) dimension.\n");  
} else
  printf(" Internal error; function spline_integral: Input vector(s) not defined.\n");  
return(ret);  
}


double spline_deriv(double xx,vector x,vector y,vector y2)
  /*
  Funkcija vrne prvi odvod interpolacijske funkcije v tocki x na 
  interpolacijskem intervalu. Poleg koordinate x so vhodni podatki se 
  vektorja koordinat interpolacijskih tock in vektor drugih odvodov,
  interpolacijske funkcije ki jih dobimo s funkcijo spline_sec_derivs.
  V primeru neustreznih vhodnih podatkov funkcija vrne -infinity().
  $A Damjan sep 98
  */
{
int klo,khi,k,n;
double h,xa,xb,ya,yb,y2b,y2a,ret=-infinity();

if(x!=NULL && y!=NULL && y2!=NULL)
{
  n=x->d;
  if(n>1 && n==y->d && n==y2->d)
  {
    if(xx>=x->v[1] && xx<=x->v[n])
    {
      klo=1;
      khi=n;
      while (khi-klo > 1) 
      {
        k=(khi+klo) >> 1;
        if (x->v[k] > xx) 
          khi=k;
        else 
          klo=k;
      }
      h=x->v[khi]-x->v[klo];
      if(h>0.0)
      {
        xa=x->v[klo];
        xb=x->v[khi];
        ya=y->v[klo];
        yb=y->v[khi];
        y2a=y2->v[klo];
        y2b=y2->v[khi];      
        h=xb-xa;
        ret=( (h*h-3*xx*xx+6*xb*xx-3*xb*xb)*y2a-(h*h-3*xx*xx+6*xa*xx-3*xa*xa)*y2b+     
        6*(yb-ya) )/(6*h);
      }
    } else
      printf(" Internal error; function spline_deriv: x coordinate out of range.\n");  
  } else
    printf("Internal error; function spline: Wrong input vector(s) dimension.\n");  
} else
  printf("Internal error; function spline: Input vector(s) not defined.\n");  
return(ret);
}


int file_get_group_nodes_vector(FILE *fp,long from,vector *vec)
  /* Funkcija v vhodni datoteki za analizo fp (tip *.neu) poisce prvo skupino
  elementov z imenom "Element_topology" od pozicije from naprej in vsa vozlisca,
  ki sestavljajo to skupino elementov nalozi na vektorsko spremenljivko *vec.
  Ce je operacija uspesna funkcija vrne stevilo vozlisc, ce pa pride do 
  napake vrne -1, vektor vec pa dobi vrednost NULL. Datotecni kazalec se po 
  uspesnem klicu funkcije postavi na mesto za oklepajem, ki oznacuje konec
  polja elementov, sicer pa se postavi na zacetek datoteke. 
  $A Damjan sep98; */
{  
int i,ret=-1,npoints,length,buflength=1000,readok,*tmp;
long pos1=1,start;
vector nodes;
stack tempst;

if(fp!=NULL)
{
  if(*vec!=NULL)
    dispvector(vec);     
  /* Branje vseh stevilk vozlisc */
  pos1=filestring(fp,"NPOIN",pos1,buflength);
  if (pos1>0)
  {
    npoints=(int) round(filenum(fp,pos1,10,&start,&length));
    nodes=getvector(npoints);
    for(i=1;i<=npoints;++i)
      nodes->v[i]=0;
    pos1=filestring(fp,"Element_topology",from,buflength);
    if(pos1>0)
    {
      pos1=filestring(fp,"\n",pos1,buflength);
      fseek(fp,pos1-1,SEEK_SET);
      tempst=newstack(100);
      do
      {
        tmp=calloc(1,sizeof(int *));
        readok=fscanf(fp,"%i",tmp);
        if(readok==1)
          if(nodes->v[*tmp]==0)
          {
            nodes->v[*tmp]=1;
            pushstack(tempst,tmp);
          } 
      } while(readok==1);
      pos1=filestring(fp,"\n",ftell(fp)+1,buflength);
      ret=tempst->n;
      qsortstack(tempst,cmp);
      *vec=getvector(ret);
      for(i=1;i<=ret;++i)
      {       
        (*vec)->v[i]=*((int *)tempst->s[i]);
      }
      
    }
    dispstackval(tempst);   
    dispstack(&tempst);
    dispvector(&nodes);
  }
}
fseek(fp,pos1,SEEK_SET); 
return(ret);
}


int file_get_slideline_nodes_vector(FILE *fp,long from,vector *vec)
    /*  Funkcija prebere vozlisca v prvem polju z imenom 
       "Nodal_pointers_for_segments" za pozicijo from in 
        jih nalozi na vektorsko spremenljivko *vec.
        $A Damjan nov98
    */
{
int lin,col,i,j,k,tmp,ret=-1;
long pos=0;

pos=freadfieldheader(fp,"_for_segments",from,&lin,&col);
if(pos>0)
{
  if(*vec!=NULL)
    dispvector(vec);     
  *vec=getvector(lin+1);
  fseek(fp,pos,SEEK_SET); 
  j=1;
  do
  {
    i=fscanf(fp,"%i",&tmp );
    (*vec)->v[j]=tmp;
    i=fscanf(fp,"%i",&k);
    ++j;
  } while((j<=lin) && i>0);
  (*vec)->v[j]=k;
  if(j>1)
    ret=j;
}
return(ret);
}


int transform_coords(vector nodes,field *coords,vector xtransvec,
                       vector ytransvec,vector secder,double ex,int side)
  /* Funkcija transformira koordinate vozlisc, ki so shranjene v polju coords
  in nasteta po vrsti v vektorju nodes. Za pravilno delovanje funkcije mora 
  biti zacetna oblika skupine nastetih vozlisc pravokotnik s stranicami 
  vzporednimi koordinatnim osem. Transformacijsko funcijo dolocajo koordinate 
  transformacijskih tock nastete v vektorjih xtransvec in ytransvec ter 
  korekcijski faktor ex. xi so koeficienti,ki dolocajo x koordinate 
  interpolacijskih tock in imajo lahko vrednost med [0,1]. yi so koeficienti, 
  ki dolocajo vrednost transformiranih koordinat zgornjega roba in imajo lahko 
  vrednost [0,inf], oziroma v praksi so meje zaradi deformacij mreze manjse. 
  Skozi tako predpisane tocke funkcija povlece zlepek polinomov 3. reda 
  (splines). Navesti moramo se  vektor drugih odvodov zlepka. Spremenljivka 
  side doloca smer transformacije. (1:+x, 2:+y, 3:-x, 4:-y) Funkcija vrne 
  stevilo transformiranih koordinat, v primeru neuspesnega klica pa vrne -1.
  $A Damjan sep98, jan99 */
{
int i,ret=-1,nnod,ncoor,nip,nodenum,error=0;
double minx,maxx,miny,maxy,x0,y0,w,h,tmpspl;
vector xc,yc,tmpvec;


tmpvec=getvector(5);

if(nodes!=NULL && *coords!=NULL && xtransvec!=NULL && 
   ytransvec!=NULL && secder!=NULL && side>=1 && side<=4)
{
  if(nodes->d>0)
  {
    nnod=nodes->d;
    if ((*coords)->lin>0)
    {
      ncoor=(*coords)->lin;
      nip=xtransvec->d;
      if(nip>1 && nip==ytransvec->d)
      {
        xc=getvector(nnod);
        yc=getvector(nnod);
        /* Iskanje ekstremnih tock pravokotnika */
        nodenum=(int) nodes->v[1];
        minx=maxx=xc->v[1]=((vector)((*coords)->st->s[nodenum]))->v[1];
        miny=maxy=yc->v[1]=((vector)((*coords)->st->s[nodenum]))->v[2];
        for(i=2;i<=nnod;++i)
        {
          nodenum=(int) nodes->v[i];
          xc->v[i]=((vector)((*coords)->st->s[nodenum]))->v[1];
          yc->v[i]=((vector)((*coords)->st->s[nodenum]))->v[2];
          if( xc->v[i] < minx) minx=xc->v[i];
          if( xc->v[i] > maxx) maxx=xc->v[i];
          if( yc->v[i] < miny) miny=yc->v[i];
          if( yc->v[i] > maxy) maxy=yc->v[i];
        }
        x0=minx; y0=miny;
        w=maxx-minx; h=maxy-miny; 
        
        switch(side)
        {
          case 1:
            for(i=1;i<=nnod;++i)
            {      
              nodenum=(int) nodes->v[i];
              if(xc->v[i]-x0>0)
                tmpspl=exp(ex*log((xc->v[i]-x0)/w));
              else
                tmpspl=0;
              ((vector)((*coords)->st->s[nodenum]))->v[1]=
              x0+spline((yc->v[i]-y0)/h,xtransvec,ytransvec,secder)*(xc->v[i]-x0)*tmpspl;       
            }  
          break;
          case 2:
            for(i=1;i<=nnod;++i)
            {  
              nodenum=(int) nodes->v[i];
              if(yc->v[i]-y0>0)
                tmpspl=exp(ex*log((yc->v[i]-y0)/h));
              else
                tmpspl=0;
              ((vector)((*coords)->st->s[nodenum]))->v[2]=
              y0+spline((xc->v[i]-x0)/w,xtransvec,ytransvec,secder)*(yc->v[i]-y0)*tmpspl;
	    }
          break;
          case 3:
            for(i=1;i<=nnod;++i)
            { 
              nodenum=(int) nodes->v[i];
              if(maxx-xc->v[i]>0)
                tmpspl=exp(ex*log((maxx-xc->v[i])/w));
              else
                tmpspl=0;
              ((vector)((*coords)->st->s[nodenum]))->v[1]=
              maxx+spline((yc->v[i]-y0)/h,xtransvec,ytransvec,secder)*(xc->v[i]-maxx)*tmpspl;
            }        
          break;
          case 4:
            for(i=1;i<=nnod;++i)
	    {
              nodenum=(int) nodes->v[i];
              if(maxy-yc->v[i]>0)
                tmpspl=exp(ex*log((maxy-yc->v[i])/h));
              else
                tmpspl=0;
              ((vector)((*coords)->st)->s[nodenum])->v[2]=
              maxy+spline((xc->v[i]-x0)/w,xtransvec,ytransvec,secder)*(yc->v[i]-maxy)*tmpspl;
            }
            break; 
        }
        ret=nnod;
        dispvector(&xc);
        dispvector(&yc); 
      }
    }
  }
}
return(ret);
}


int update_mesh(FILE *in,FILE *out)
/*
$A Damjan sep98
*/
{
int i,j,dat=0,col,ret=-1;
long pos;
field coords,tmp;

if(in!=NULL && out!=NULL)
{
  pos=freadneufield(in,"Coordinates",1,&coords);
  if(pos<0)
  {
    pos=freaddatfield(in,"NODE COORDINATES",1,&coords);
    dat=1;  
  }
  if(pos>0)
  {
    ret=coords->lin;
    col=coords->col;
    tmp=getfield(ret,3);
    if(dat==0)
    {
      for(i=1;i<=ret;++i)
      {
        for(j=1;j<=2;++j)
          ((vector)(tmp->st->s[i]))->v[j]=((vector)(coords->st->s[i]))->v[j];
        if(coords->col==2)
          ((vector)(tmp->st->s[i]))->v[3]=0;
        else
          ((vector)(tmp->st->s[i]))->v[3]=((vector)(coords->st->s[i]))->v[3]; 
      }
    } else
    {
      for(i=1;i<=ret;++i)
      {
        for(j=1;j<=2;++j)
          ((vector)(tmp->st->s[i]))->v[j]=((vector)(coords->st->s[i]))->v[j+1]; 
        if(coords->col==2)
          ((vector)(tmp->st->s[i]))->v[3]=0;
        else
          ((vector)(tmp->st->s[i]))->v[3]=((vector)(coords->st->s[i]))->v[3]; 
      }
    }
    pos=freplacefield(tmp,out,"coordinates",1);
  }  
  if(pos<0)
    printf("Internal error: function \"update_mesh\".\n");
} else
  printf("Internal error: function \"update_mesh\".\n");
return(ret);
}
