


#include <sysint.h>

#include <math.h>

#include <er.h>
#include <rf.h>

#include <limfunc.h>


         /***************************************/
         /*                                     */
         /*      LIMITED RANGE ENFORCEMENT      */
         /*                                     */
         /***************************************/


  /* This module defines a set fo monotonic functions with limited range of
  values that can be used for limiting parameter ranges. */




    /* EXPONENTIAL - IDENTITY - EXPONENTIAL SPLINE: */

  /* Continuous second derivatives, asymptotically approaches lim. values */

#define fe(x,d) (d)*exp((x)/(d))
#define derfe(x,d) exp((x)/(d))
#define invfe(x,d) (d)*ln((x)/(d))

double limfuncexpid(double x,double min,double max,double d)
    /* Returns the value of the limiting function that is composed of two
    assymptotic exponential branches and an identity function between them.
    The function is monotonic and continuously differential with respect to x.
      x is the independent variable, min is minimum and max is maximum value
    of the function and d is range of each assymptotic branch (must be less
    or equal to (max-min)/2!).
    $A Igor oct03; */
{
if (d<0 || fabs(d)>1.000001*fabs(max-min)/2)
{
  errfunc0("limfuncexpid");
  sprintf(ers(),"Parameter d is out of range; should not be greater than (max-min)/2.\n");
  sprintf(ers(),"min=%g, max=%g, d=%g.\n",min,max,d);
  errfunc2();
  return (min+max/2);
}
if (x<min+d)
  return min+fe(x-(min+d),d);
else if (min+d <= x && x <= max-d)
  return x;
else if (max-d<x)
  return max-fe((max-d)-x,d);
return (min+max/2);
}



double derlimfuncexpid(double x,double min,double max,double d)
    /* Returns the derivative of limfuncexpid.
    $A Igor oct03; */
{
if (d<0 || fabs(d)>1.000001*fabs(max-min)/2)
{
  errfunc0("derlimfuncexpid");
  sprintf(ers(),"Parameter d is out of range; should not be greater than (max-min)/2.\n");
  sprintf(ers(),"min=%g, max=%g, d=%g.\n",min,max,d);
  errfunc2();
  return 1;
}
if (x<min+d)
  return derfe(x-(min+d),d);
else if (min+d <= x && x <= max-d)
  return 1;
else if (max-d<x)
  return derfe((max-d)-x,d);
return 1;
}



double invlimfuncexpid(double y,double min,double max,double d)
    /* Returns the inverse of limfuncexpid. If y is less or equal to min or
    greater or equal to max then minus or plus infinity is returned,
    respectively.
    $A Igor oct03; */
{
if (d<0 || fabs(d)>1.000001*fabs(max-min)/2)
{
  errfunc0("derlimfuncexpid");
  sprintf(ers(),"Parameter d is out of range; should not be greater than (max-min)/2.\n");
  sprintf(ers(),"min=%g, max=%g, d=%g.\n",min,max,d);
  errfunc2();
  return (min+max/2);
}
if (y<=min)
  return -infinity();
else if (min<y && y<min+d)
  return min+d+invfe(y-min,d);
else if (min+d<=y && y<=max-d)
  return y;
else if (max-d<y && y<max)
  return max-d-invfe(max-y,d);
else if (max<=y)
  return infinity();
return (min+max/2);
}




#undef fe
#undef derfe
#undef invfe









