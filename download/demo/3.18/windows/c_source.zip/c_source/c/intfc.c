/* VMESNIK ZA DIREKTNE ANALIZE */



#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>


#include <mtypes.h>
#include <er.h>
#include <rf.h>
#include <simb.h>
#include <fop.h>
#include <st.h>
#include <strop.h>
#include <simb.h>
#include <efint.h>




struct _OUTINFO{
       char *name;
       long pos,start,end;
       /* void *val; */
       stack cont;
       stack res;
       void *point;
       struct _OUTINFO * superior;
       };

typedef struct _OUTINFO _outinfo;
typedef _outinfo *outinfo;



/* DEFINICIJE SPREMENLJIVK: */

/* Vhodna datoteka direktne analize: */
static FILE *fin;
/* Skladi, na katere se nalozijo podatki o parametrih direktne analize v vhodni
datoteki: */
static stack stfileplace=NULL,stlength=NULL,stparamnum=NULL;

static outinfo oi=NULL;
static FILE *fout=NULL;

static char checkincfield=0;
/* Ce je ta spremennljivka razlicna od 0, se pri funkcijah, ki iscejo vrednost
kaksnega polja v prvem ali zadnjem inkrementu v izhodni datoteki direktne
analize, preveri, ce je polje za dani inkrement zapisano. Ce ni, se iscejo po-
datki v naslednjih oziroma predhodnih inkrementih. */


static char *basename  = "BAS";

static char *incname  = "INC";
/* Polje name v strukturi tipa _outinfo, ki vsebuje podatke o vseh inkrementih */

static char *timestepname  = "TSTEP";
/* Polje name v strukturi tipa _outinfo, ki vsebuje podatke o vseh cas. korakih */

/* static char *incstr   = "INCREMENT NUMBER";  !!!!!!!!!!!!!!!!!!  */
static char *incstr   = "INCREMENT ";


static char *incstraux=NULL;
/*
static char *incstr   = "LOAD CASE";
*/
/* Niz, ki v izhod. datoteki oznacuje zacetek podatkov o danem inkrementu */

static char *timestepstr   = "TIMESTEP NUMBER";
/* Niz, ki v izhod. datoteki oznacuje zacetek podatkov o danem casov. koraku */

static char *nodtempstr = "FIELD VALUES";

static char *noddispstr = "NODAL DISPLACEMENTS";

static char *nodreacstr = "NODAL REACTIONS";

static char *locnoddispstr = "LOCAL NODAL DISPLACEMENTS";

static char *locnodreacstr = "LOCAL NODAL REACTIONS";


/*

static char *strainstr = "ELEMENT NODAL STRAINS FOR INCREMENT";

static char *stressstr = "ELEMENT NODAL STRESSES FOR INCREMENT";

static char *strainstressstr = "ELEMENT NUMBER";

static char *nodcontforcstr="CONTACT NODAL FORCES (GLOBLE) FOR INCREMENT";
static char *locnodcontforcstr="CONTACT NODAL FORCES (LOCAL) FOR INCREMENT";
static char *nodcontwearstr ="USER DEFINED CONTACT STATE VARIABLES";

static char *nodcontforcsubstr="SLIDELINE SURFACE NUMBER =";

static char *totalsstring="TOTALS";


*/



static char *strainstr = "ELEMENT NODAL STRAINS";

static char *stressstr = "ELEMENT NODAL STRESSES";

static char *strainstressstr = "ELEMENT NUMBER";

static char *nodcontforcstr="CONTACT NODAL FORCES (GLOBLE)";
static char *locnodcontforcstr="CONTACT NODAL FORCES (LOCAL)";
static char *nodcontwearstr ="USER DEFINED CONTACT STATE VARIABLES";

static char *nodcontforcsubstr="SLIDELINE SURFACE NUMBER =";

static char *totalsstring="TOTALS";



/* Stevilo znakov pred koncem izhod. datoteke analize, kjer se zacne iskati
niz, ki pomeni uspesno izvedbo analize (successstr) ali niz, ki pomeni napako
pri analizi (errorstr): */
#define MAX_TILLEND 1000

static char *errorstr="**ERROR**";
static char *successstr="ELFEN SUCCESSFULLY COMPLETED";



/*
	Urejenost podatkov:

name=basname
  name=incname
    name=incstr
      name=noddispstr
        name=noddispstr,*point=(long) st. vozla, res->s[i]=vrednost i.
             komponente
      name=nodreacstr
        name=nodreacstr,*point=(long) st. vozla, res->s[i]=vrednost i.
             komponente
      name=locnoddispstr
        name=locnoddispstr,*point=(long) st. vozla, res->s[i]=vrednost i.
             komponente
      name=locnodreacstr
        name=locnodreacstr,*point=(long) st. vozla, res->s[i]=vrednost i.
             komponente

*/






typedef struct{
        char *name;        /* ime kljuc. besede */
        char *superior;    /* ime nadrejene besede */
        stack searchfrom;  /* zacetki obmocij, kjer je bila ta bes. iskana */
        stack searchto;    /* konci obmocij, kjer je bila ta beseda iskana */

        stack pos;   /* pozicije, kjer smo to besedo nasli */
        stack endbrackets; /* konci obmocij, ki pripadajo posam. pojavom kljuc. b. */
        stack defnames;    /* imena, ki definirajo doloc. kljuc. bes. */
        stack subnames;    /* podimena. */
        stack descriptors; /* kazalci na opise; lahko jih brises s free. Tip
                              objektov, na katere kazejo, je long. */
        } _kwdinfo;   /* S prazno vrstico so loceni skladi, ki imajo razlic. st.
        elementov */

typedef _kwdinfo *kwdinfo;










/* Notranje globalne spremenljivke: */

stack fargs,         /* kazalci na tabele funkcijskih argumentov */
      foundkwd,      /* podatki o najdenih kljuc. besedah */
      searchnext;   /* kljuc. besede, ki se naj iscejo v enem zamahu */





outinfo newoutinfo(void)
{
outinfo oi;
oi=malloc(sizeof(*oi));
oi->name=NULL;
oi->pos=0;
oi->start=0;
oi->end=0;
oi->cont=NULL;
oi->res=NULL;
oi->point=NULL;
oi->superior=NULL;
return oi;
}



void disp1outinfo(outinfo *oi1)
     /* Zbrise podatkovno strukturo, na katero kaze *oi, in postavi *oi na NULL.
     Funkcija zbrise tudi vse kazalce, ki so polja te struktre, zbrise tudi
     vsebino sklada (*oi)->res, ne zbrise pa vsebine sklada oi->cont. */

{
outinfo oi;
oi=*oi1;
if (oi!=NULL)
{
  if (oi->name!=NULL)
    free(oi->name);
  if (oi->point!=NULL)
    free(oi->point);
  if (oi->res!=NULL)
  {
    dispstackval(oi->res);
    dispstack(&(oi->res));
  }
  if (oi->cont!=NULL)
    dispstack(&(oi->cont));
  free(oi);
  (*oi1)=NULL;
}
}



void dispoutinfo(outinfo *oi1)
     /* Zbrise podatkovno strukturo, na katero kaze *oi, in postavi *oi na NULL.
     Funkcija zbrise tudi vse kazalce, ki so polja te struktre, zbrise tudi
     vsebino sklada (*oi)->res. Ce sklad oi->cont ni prazen, rekurzivno zbrise
     tudi elemente tipa outinfo, ki so potisnjeni na ta sklad. */
{
outinfo oi,ref;
int i;
oi=*oi1;
if (oi!=NULL)
{
  if (oi->cont!=NULL)
    if (oi->cont->n>0)
    {
      for (i=1; i<=oi->cont->n; ++i)
      {
        ref=(outinfo) oi->cont->s[i];
        dispoutinfo(& ref);
        oi->cont->s[i]=NULL;
      }
    }
  disp1outinfo(oi1);
}
}


static void printspaces(int n)
       /* Na standardni izhod izpise n presledkov. */
{
int i;
for (i=1; i<=n; ++i)
  printf("%s"," ");
}




static void printoutinfo1(outinfo oi,int spaces)
{
int i;
if (oi!=NULL)
{
long num;
printspaces(spaces);
printf("Ime: ");
if (oi->name!=NULL)
  printf("\"%s\"\n",oi->name);
else
  printf("\"\"\n");
if (oi->point!=NULL)
{
  num=* (long *) oi->point;
  printspaces(spaces);
  printf("Zap. st.: %i\n",num);
}
if (oi->res!=NULL && oi->res->n>0)
{
  printspaces(spaces);
  printf("Rezultati: ");
  for (i=1; i<=oi->res->n; ++i)
    printf("  %g", * (double *) oi->res->s[i] );
  printf("\n");
}
printspaces(spaces);
printf("Pozicija:    %li\n",oi->pos);
printspaces(spaces);
printf("Zacet.    :  %li\n",oi->start);
printspaces(spaces);
printf("Konc.     :  %li\n",oi->end);
} else
{
  printspaces(spaces);
  printf("PROSTOR NI ALOCIRAN.\n");
}
}


void _printoutinfo(outinfo oi,int spaces)
{
int i;
printoutinfo1(oi,spaces);
if (oi->cont!=NULL)
{
  if (oi->cont->n>0)
  {
    printspaces(spaces);
    printf("Podteme:\n");
    for (i=1; i<=oi->cont->n; ++i)
      _printoutinfo(oi->cont->s[i],spaces+2);
  }
}
}


void printoutinfo(outinfo oi)
{
_printoutinfo(oi,0);
}


void po(outinfo oi)
{
printoutinfo(oi);
}


















void printkwdinfo(kwdinfo ki)
{
int i;
printf("Keyword name: \"%s\"\n",ki->name);
if (ki->superior!=NULL)
  printf("Superior name: \"%s\"\n",ki->superior);
if (ki->searchfrom->n>0 && ki->searchto->n>0
 && ki->searchto->n ==ki->searchfrom->n)
{
  printf("Searched areas:\n");
  for (i=1; i<=ki->searchfrom->n; ++i)
  {
    printf("from %li to %li",ki->searchfrom->s[i],ki->searchto->s[i]);
    if (i<ki->searchfrom->n)
      printf(",");
    else
      printf(".");
  }
}
if (ki->pos!=NULL && ki->pos->n>0)
{
  printf("Found pos:\n");
  for (i=1; i<=ki->pos->n; ++i)
  {
    printf("%i. pozicija: %li;",i,* (long *) ki->pos->s[i]);
    if (ki->endbrackets!=NULL && ki->endbrackets->n>=i)
      printf("  zaklepaj: %li;",*(long *) (ki->endbrackets->s[i]));
    if (ki->descriptors!=NULL && ki->descriptors->n>=i)
      printf("  dolocit. st.: %li;",* (long *) ki->descriptors->s[i]);
  }
}
printf("\n");
}

kwdinfo newkwdinfo1(void)
        /* Alocira prostor za spremenljivko tipa _kwdinfo in vrne kazalec na
        alociran prostor. Prostor tudi inicializira. */
{
kwdinfo kwd;
kwd=malloc(sizeof(*kwd));
kwd->name=NULL;
kwd->superior=NULL;
kwd->searchfrom=NULL;
kwd->searchto=NULL;
kwd->pos=NULL;
kwd->endbrackets=NULL;
kwd->defnames=NULL;
kwd->subnames=NULL;
kwd->descriptors=NULL;
return kwd;
}

kwdinfo newkwdinfo(void)
        /* Alocira prostor za spremenljivko tipa _kwdinfo in vrne kazalec na
        alociran prostor. Prostor tudi inicializira. */
{
kwdinfo kwd;
kwd=malloc(sizeof(*kwd));
kwd->name=NULL;
kwd->superior=NULL;
kwd->searchfrom=newstack(5);
kwd->searchto=newstack(5);
kwd->pos=newstack(5);
kwd->endbrackets=newstack(5);
kwd->defnames=newstack(5);
kwd->subnames=newstack(5);
kwd->descriptors=newstack(5);
return kwd;
}


void dispkwdinfo(kwdinfo *kwdi)
     /* Sprosti spomin, na katerega kaze *kwd in postavi ta kazalec na 0. */
{
kwdinfo kwd;
kwd=*kwdi;
if (*kwdi!=NULL)
{
dispstack(&(kwd->searchfrom));
dispstack(&(kwd->searchto));
dispstack(&(kwd->pos));
dispstack(&(kwd->endbrackets));
dispstack(&(kwd->defnames));
dispstack(&(kwd->subnames));
dispstack(&(kwd->descriptors));
free(kwd);
*kwdi=NULL;
}
}





void addkwd(stack st,char *kwd)
     /* Niz kwd potisne na sklad st, ce na njem se ni enakega niza. */
{
int i;
i=findstack(st,(void *)kwd,1,-1,(int (*)(void *,void *)) cmpstrings);
if (i<=0)
  pushstack(st,kwd);
}




/* IZHODNI PARAMETRI ZA DIREKTNO ANALIZO (branje) */

/*
POZOR !!
V SEDANJI FAZI JE V ENEM KORAKU MOZNO BRANJE PODATKOV IZ ENE SAME DATOTEKE !!!
PO BRANJU SE CELOTEN SISTEM PODATKOV RESETIRA!
*/



static void findincrements(char *stepname,FILE *fp,outinfo oi /* ,outinfo superior */ )
     /* V datoteki, povezani z fp, najde vsa mesta, kjer so podatki o posameznih
     korakih. Ta mesta najde po pojavih nizov stepname, ki jim
     sledi stevilka koraka. Podatke o najdenih obmocjih v datoteki nalozi
     na sklad oi->cont in so tudi tipa outinfo.
     superior je kazalec na strukturo, katere polje cont vsebuje kazalec oi. (??)
     oi->name mora biti enako incstr. */
{
double x;
int i,length;
long pos,start,endinc,*lp=NULL;
stack places;
/* char * incstr="INCREMENT NUMBER"; */
outinfo ref,ref1;
char samelastinc;
if (oi->name==NULL)
  oi->name=stringcopy(incname);
oi->pos=oi->start=oi->end=0;
/* oi->superior=superior; */
places=newstack(5);
/* V datoteki fp se poiscejo vsi nizi, ki vsebujejo niz incstr: */
allfilestring(fp,stepname,1,10000,places);
if (places->n>0)
{
  /* V danem formatu se odsek, ki vsebuje podatke o inkrementih, zacne s prvim
  pojavom niza stepname in konca na koncu datoteke. */
  oi->pos= * (long *) places->s[1];
  oi->start= * (long *) places->s[1];
  oi->end=flength(fp);
  if (oi->cont==NULL)
    oi->cont=newstack(5);
  for (i=1; i<=places->n; ++i)
  {
    /* Glede na pojave niozov stepname se dolocijo ostali podatki za vsak ink. */
    pos=* (long *) places->s[i];
    /* Stevilka inkrementa */
    x=filenum(fp,pos,20,&start,&length);
    if (i<places->n)
      endinc= * (long *)places->s[i+1]-1;
    else endinc=flength(fp);
     /* Preveriti je treba, ce morda inkrement z dano zaporedno stevilko ni bil
    najden ze eno mesto pred tem. To je zato, ker Elfen zapise v datoteko z
    rezultati tudi podatke o iteracijah inkrementa, ki ni skonvergiral in je
    zato v datoteki lahko vec pojavov niza, ki oznacuje isti inkrement. V tem
    primeru kazalca ref ne potisnemo na sklad, temvec le razsirimo obmocje
    zadnjega skupka podatkov na oi->cont, tako da zajame tudi obmocje skupka
    podatkov, na katere kaze ref. to naredimo tako, da stevilo, na katero kaze
    polje point zadnjega elementa na skladu oi->cont, postavimo na vrednost, na
    katero kaze ref->point: */
    if (oi->cont->n>0)
    {
      ref1= (outinfo) nstack(oi->cont,1); /* Zadnji element na skladu */
      if ( (long) x == (* (long *) ref1->point) && start>0 && length>0 )
        samelastinc=1;
      else
        samelastinc=0;
    } else
      samelastinc=0;
    if (samelastinc)
    {
      /* Ce so podatki o danem inkrementu ze na koncu sklada oi->cont (torej v
      ref1), potem samo povecamo obmocje: */
      ref1->end=endinc;
    } else
    {
      ref=newoutinfo();
      ref->pos=pos;
      ref->end=endinc;
      if (start>0 && length>0)
      {
        ref->start=start+length+1;
        lp=malloc(sizeof(*lp));
        *lp=(long) x;
        ref->point=(void *) lp;
      }
      else
      {
        ref->start=ref->pos; ref->point=NULL;
      }
      ref->res=NULL;
      ref->name=stringcopy(stepname);
      /* ref->superior=oi; */
      pushstack(oi->cont,ref);
    }
  }
}
dispstackval(places);
dispstack(&places);
}



static void findfield1(FILE *fp,outinfo oi,char *fieldname)
       /* V datoteki, poveznai z fp, najde zacetek in konec obmocja, kjer so
       zapisane vrednosti danega vektorskega ali skalarnega polja v posameznih
       vozlih. Te podatke potem doda na sklad oi->cont. oi->name mota biti enako
       incstr. */
{
char end=0;
double x;
int length;
long count=0,pos,pos1;
outinfo ref=NULL;
if (oi!=NULL && cmpstrings(oi->name,incstr)==0 && oi->start>0 && oi->end>oi->start)
{
  pos=filestringto(fp,fieldname,oi->start,oi->end,1000);
  if (pos>0)
  {
    /* $$$ sprememba za DOS komp.
    pos=filecharto(fp,"\n\r",2,pos,oi->end,200);
    */
    pos=filecharto(fp,"\n",1,pos,oi->end,200);
    ref=newoutinfo();
    ref->name=stringcopy(fieldname);
    ref->pos=pos;
    x=filenum(fp,pos,30,&pos,&length);
    /* $$$ sprememba za DOS komp.
    pos1=filecharto(fp,"\n\r",2,pos,oi->end,200);
    */
    pos1=filecharto(fp,"\n",1,pos,oi->end,200);
    if (pos>0 && pos<=oi->end)
      ref->start=pos;
    else
    {
      ref->start=0;
      end=1;
    }
  if (pos1>0)
      ref->end=pos1;
  else
    end=1;
  while (!end)
  {
    x=filenum(fp,pos1+1,30,&pos,&length);
    if (pos>=oi->start && pos<=oi->end)
      /* $$$ sprememba za DOS komp.
      pos1=filecharto(fp,"\n\r",2,pos,oi->end,200);
      */
      pos1=filecharto(fp,"\n",1,pos,oi->end,200);
    else
      end=1;
    if (pos1>0)
      ref->end=pos1;
    else
      end=1;
  }
}
pushstack(oi->cont,ref);
}
}






static void findfield(char *stepname,FILE *fp,outinfo oi,char *fieldname)
       /* V datoteki, poveznai z fp, najde zacetek in konec obmocja, kjer so
       zapisane vrednosti danega vektorskega ali skalarnega polja v posameznih
       vozlih. Te podatke potem doda na sklad oi->cont. oi->name mota biti enako
       stepname.
       POZOR: Prostor za oi->cont mora biti alociran pred klicom funkcije! */
{
char end=0;
double x;
int length;
long count=0,pos,pos1,pos2,pos0;
outinfo ref=NULL;
if (oi->cont==NULL)
  oi->cont=newstack(5);
if (oi!=NULL && cmpstrings(oi->name,stepname)==0 && oi->start>0 && oi->end>oi->start)
{
  pos=filestringto(fp,fieldname,oi->start,oi->end,1000);
  if (pos>0)
  {
    ref=newoutinfo();
    ref->name=stringcopy(fieldname);
    ref->superior=oi;
    ref->pos=pos;
    /* Izpustiti moramo vse, kar se ne pomeni zacetka podatkov: */
    /* $$$ sprememba za DOS komp.
    pos=filecharto(fp,"\n\r",2,pos+strlen(fieldname),oi->end,50);
    */
    pos=filecharto(fp,"\n",1,pos+strlen(fieldname),oi->end,50);
    x=filenumto(fp,pos,oi->end,40,&pos,&length);
    if (pos>0 && pos<=oi->end)
    {
      ref->start=pos;
      ref->end=pos;
    }
    else
    {
      ref->start=0;
      ref->end=0;
      end=1;
    }
    while (!end)
    {
      /* Preveri se, ce prvi znak v vrstici, ki je razlicen od presledka,
      pripada stevilu: */
      /* $$$ sprememba za DOS komp.
      pos2=filecharto(fp,"\n\r",2,pos,oi->end,15);
      */
      pos2=filecharto(fp,"\n",1,pos,oi->end,15); /* Konec vrstice */
      pos0=filenotcharto(fp," ",1,pos,pos2,15);
      x=filenumto(fp,pos,pos2,30,&pos1,&length);
      if (pos0!=pos1 || pos1<=0)
      {
        end=1;
        ref->end=pos;
      }
      pos=pos2+1;
    }
  }
  pushstack(oi->cont,ref);
}
}





void findnodefield(FILE *fp,outinfo oi,long node)
     /* V datoteki fp poisce podatke o polju, katerega osnovne podatke vsebuje
     oi, v vozlu node. Podatke potisne na sklad oi->cont. */
{
outinfo ref=NULL;
char end=0,end1=0,found=0;
long pos1=0,pos2=0,*lnum;
double x,*dnum;
int length;
if (oi!=NULL && oi->start>0 && oi->start<oi->end)
{
  if (node<0)
  {
    end=1;
    pos1=filestring(fp,totalsstring,oi->end,50);
    if (pos1>0)
    {
      end1=0;
      pos1+=strlen(totalsstring);
      /* $$$ sprememba za DOS komp.
      pos2=filechar(fp,"\n\r",2,pos1,50);
      */
      pos2=filechar(fp,"\n",1,pos1,50);
      if (pos2<pos1)
        pos2=flength(fp);
      ref=newoutinfo();
      ref->superior=oi;
      ref->res=newstack(5);
      /*  !!!!!!!!!!$$$$$$$$$$&&&&&&&&&&&&
      ref->name=stringcopy(oi->name);
      */
      lnum=malloc(sizeof(*lnum));
      *lnum=node;
      ref->point=(void *) lnum; lnum=NULL;
      while (!end1)
      {
        x=filenumto(fp,pos1,pos2,30,&pos1,&length);
        if (pos1>0)
        {
          pos1+=length+1;
          dnum=malloc(sizeof(*dnum));
          *dnum=x;
          pushstack(ref->res,dnum);
        } else
          end1=1;
      }
    }
  }
  pos1=oi->start;
  while (!end)
  {
    x=filenumto(fp,pos1,oi->end,30,&pos1,&length);
    /* $$$ sprememba za DOS komp.
    pos2=filecharto(fp,"\n\r",2,pos1,oi->end,100);
    */
    pos2=filecharto(fp,"\n",1,pos1,oi->end,100);
    if (pos1<=0|| pos2<=0)
      end=1;
    else
    {
      if ( (long) x == node )
      {
        end=1;
        pos1+=length+1;
        ref=newoutinfo();
        ref->superior=oi;
        ref->res=newstack(5);
        /*  !!!!!!!!!!$$$$$$$$$$&&&&&&&&&&&&
        ref->name=stringcopy(oi->name);
        */
        lnum=malloc(sizeof(*lnum));
        *lnum=node;
        ref->point=(void *) lnum;
        while (!end1)
        {
          x=filenumto(fp,pos1,pos2,30,&pos1,&length);
          if (pos1>0)
          {
            pos1+=length+1;
            dnum=malloc(sizeof(*dnum));
            *dnum=x;
            pushstack(ref->res,dnum);
          } else
            end1=1;
        }
      }
    }
    pos1=pos2+1;
  }
}
/*
po(ref);
*/
if (oi!=NULL)
{
  if (oi->cont==NULL)
    oi->cont=newstack(5);
  pushstack(oi->cont,ref);
}
}











outinfo oifindincnum1(stack st,long num)
        /* Na skladu st, ki vsebuje podatke tipa outifo, ki kazejo na podatke o
        posameznih inkrementih, najde podatke o inkrementu z zap. st. num. Vrne
        kazalec na srukturo tipa outinfo, ki vsebuje te podatke, ali pa NULL,
        ce ne najde ustreznega kazalca.
        Ce je num 0, se iscejo podatki za inkrement z najvisjo, ce pa je -1, se
        iscejo podatki za inkrement z najnizjo stevilko.
        */
{
outinfo oi,ret=NULL;
char end=0;
int i=1;
long lmax=-1,lmin=-1,lnum;
if (st!=NULL && st->n>0)
  while (!end && i<=st->n)
  {
    oi=st->s[i];
    lnum=-2;
    if (oi!=NULL && cmpstrings(oi->name,incstr)==0 )
    {
      if (oi->point!=NULL)
      {
        lnum=* (long *) oi->point;
        if (lmin==-1 || lnum<lmin)
          lmin=lnum;
        if (lmax==-1 || lnum>lmax)
          lmax=lnum;
      }
    }
    if (lnum!=-2 && lnum==num)
    {
      end=1; ret=oi;
    }
    ++i;
  }
if (num<=0)
{
  if (num==0 && lmax>0)
    ret=st->s[lmax];
  if (num==-1 && lmin>0)
    ret=st->s[lmin];
}
return ret;
}






long oitellincnum(char *stepname,stack st,long *first,long *last)
     /* Na skladu st, ki vsebuje podatke tipa outifo, ki kazejo na podatke o
     posameznih inkrementih, preveri stanje. Funkcija vrne stevilo inkrementov
     na skladu (ce jih ni, vrne 0), stevilko 1. inkrementa na skladu v *first in
     stevilko zadnjega inkrementa na skladu v *last.
       Opomba: kot 1. inkrement je misljen tisti z najnizjo zaporedno stevilko.
     */
{
outinfo oi;
int i;
long lnum,ret=0;
*first=-1; *last=-1;
if (st!=NULL && st->n>0)
{
  i=1;
  while (i<=st->n)
  {
    oi=st->s[i];
    lnum=-2;
    if (oi!=NULL && cmpstrings(oi->name,stepname)==0 )
    {
      if (oi->point!=NULL)
      {
        lnum=* (long *) oi->point;
      }
    }
    if (lnum!=-2)
    {
      ++ret;
      if (lnum<*first || *first<0)
        *first=lnum;
      if (lnum>*last || *last<0)
        *last=lnum;
    }
    ++i;
  }
} else ret=0;
return ret;
}




outinfo oifindincnum(char *stepname,stack st,long num)
        /* Na skladu st, ki vsebuje podatke tipa outifo, ki kazejo na podatke o
        posameznih inkrementih, najde podatke o inkrementu z zap. st. num. Vrne
        kazalec na srukturo tipa outinfo, ki vsebuje te podatke, ali pa NULL,
        ce ne najde ustreznega kazalca.
        Ce je num 0, se iscejo podatki za inkrement z najvisjo, ce pa je -1, se
        iscejo podatki za inkrement z najnizjo stevilko.
        */
{
outinfo oi,ret=NULL;
char end=0;
int i=1;
long lnum;
if (st!=NULL && st->n>0 && num>0)
{
  while (!end && i<=st->n)
  {
    oi=st->s[i];
    lnum=-2;
    if (oi!=NULL && cmpstrings(oi->name,stepname)==0 )
    {
      if (oi->point!=NULL)
      {
        lnum=* (long *) oi->point;
      }
    }
    if (lnum!=-2 && lnum==num)
    {
      end=1; ret=oi;
    }
    ++i;
  }
} else if (num==0)
{
  /* Zadnji inkrement, o katerem so na razpolago podatki: */
  ret=st->s[st->n];
} else if (num==-1)
{
  /* Prvi inkrement, o katerem so na razpolago podatki: */
  ret=st->s[1];
} else if (num<0)
{
  /* -num. inkrement: */
  ret=nstack(st,-num);
}
return ret;
}



outinfo oifindname(stack st,char *str)
        /* V skladu st, ki vsebuje podatke o mestih v datoteki v okviru enega
        inkrementa, kjer so vrednosti vektorskih polj, poisce mesto, ki opisuje
        polje z dolocenim imenom. Vrne kazalec na strukturo, ki vsebuje iskane
        podatke, ali NULL, ce podatkov ne najde. */
{
outinfo oi,ret=NULL;
int i;
char end=0;
if (st!=NULL && st->n>0)
{
  i=1;
  while (!end && i<=st->n)
  {
    oi=st->s[i];
    if (oi!=NULL && cmpstrings(str,oi->name)==0)
    {
      ret=oi; end=1;
    }
    ++i;
  }
}
return ret;
}


outinfo oifindfieldval(stack st,long nodnum)
        /* Na skladu st najde tisti kazalec, ki kaze na podatke o dolocenem
        polju pri vozlu stevilka nodnum, ter ta kazalec vrne. */
{
outinfo oi, ret=NULL;
int i;
long lnum;
char end=0;
if (st!=NULL && st->n>0)
{
  i=1;
  while (!end && i<=st->n)
  {
    oi=st->s[i];
    if (oi!=NULL && oi->point!=NULL)
    {
      lnum=* (long *) oi->point;
      if (lnum==nodnum)
      {
        ret=oi; end=1;
      }
    }
    ++i;
  }
}
return ret;
}











double fieldval(char * subbasename,char *stepname,long incnum,char *fieldname,
    long nodenum,int coord,FILE *fp,outinfo *oi1)
    /* Vrne koordinato coord vrednosti polja z imenom fieldname po inkrementu
    s stevilko incnum v vozlu s stevilko nodnum. Podatke najde v datoteki fp,
    ze najdene podatki pa so vpisani v sistemu oi1. */
{
outinfo oi,oiref,ref;
double ret;
char errors=0,end=0;
outinfo o;
long numincs,firstinc,lastinc,incnum1;
if (*oi1==NULL)
  *oi1=newoutinfo();
oi=*oi1;
o=*oi1;
if (cmpstrings(oi->name,basename)!=0 || oi->name==NULL)
  oi->name=stringcopy(basename);
if(oi->cont==NULL)
  oi->cont=newstack(5);
ref=oifindname(oi->cont,subbasename);
if (ref==NULL)
{
  ref=newoutinfo();
  ref->name=stringcopy(subbasename);
  ref->superior=oi;
  ref->cont=newstack(5);
  pushstack(oi->cont,ref);
}
oi=ref;
/* oi je sedaj kazalec na strukturo, ki v polju cont vsebuje podatke o posameznih
inkrementih. */

/* Prejsnji del programa:           (SPREMENJENO ZARADI EFEKTIVNOSTI)
ref=oifindincnum(stepname,oi->cont,incnum);
if (ref==NULL)
  findincrements(stepname,fp,oi);
*/
/* Novi del programa: */
if (oi->cont==NULL)
  findincrements(stepname,fp,oi);
else if (oi->cont->n<1)
  findincrements(stepname,fp,oi);


if (checkincfield && incnum<=0)
{
  end=0;
  numincs=oitellincnum(stepname,oi->cont,&firstinc,&lastinc);
  if (incnum==0)
  {
    incnum1=lastinc;
    if (lastinc<=0)
      end=1;
  }
  if (incnum==-1)
  {
    incnum1=firstinc;
    if (firstinc<=0)
      end=1;
  }
  oiref=oi;
  while (! end)
  {
    ref=oifindincnum(stepname,oiref->cont,incnum1);
    /* if (ref==NULL) ++errors; */
    if (ref!=NULL)
    {
      oi=ref;
      if (oi->cont==NULL)
        oi->cont=newstack(5);
      ref=oifindname(oi->cont,fieldname);
      if (ref==NULL)
        findfield(stepname,fp,oi,fieldname);
      ref=oifindname(oi->cont,fieldname);
      /* if (ref==NULL) ++ errors; */
      if (ref!=NULL) end=1;
      if (ref!=NULL && !errors)
      {
        oi=ref;
        ref=oifindfieldval(oi->cont,nodenum);
        if (ref==NULL)
        {
          findnodefield(fp,oi,nodenum);
          ref=oifindfieldval(oi->cont,nodenum);
        }
        if (ref==NULL) ++ errors;
        oi=(ref);
        if (coord>=0 && coord<=ref->res->n)
          ret= * (double *) ref->res->s[coord];
        else
        {
          printf("Error in function fieldval(): Invalid coordinate number %i.\n",coord);
          ++ errors;
        }
        end=1;
      }
    }
    if (incnum==0)
      --incnum1;
    else
      ++incnum1;
    if (incnum1<firstinc && incnum1>lastinc)
    {
      end=1;
      ++errors;
    }
  }
} else
{
  ref=oifindincnum(stepname,oi->cont,incnum);
  if (ref==NULL)
    ++errors;
  else
  {
    oi=ref;
    if (oi->cont==NULL)
      oi->cont=newstack(5);
    ref=oifindname(oi->cont,fieldname);
    if (ref==NULL)
      findfield(stepname,fp,oi,fieldname);
    ref=oifindname(oi->cont,fieldname);
    if (ref==NULL) ++ errors;
    oi=ref;
    ref=oifindfieldval(oi->cont,nodenum);
    if (ref==NULL)
    {
      findnodefield(fp,oi,nodenum);
      ref=oifindfieldval(oi->cont,nodenum);
    }
    if (ref==NULL) ++ errors;
    oi=(ref);
    if (coord>=0 && coord<=ref->res->n)
      ret= * (double *) ref->res->s[coord];
    else
    {
      printf("Error in function fieldval(): Invalid coordinate number %i.\n",coord);
      ++ errors;
    }
  }
}
if (errors)
  return infinity();
else
  return ret;
fflush(fp);
}











static void strainstressfindfield(char *stepname,FILE *fp,outinfo oi,
       char *fieldname)
       /* V datoteki, poveznai z fp, najde zacetek in konec obmocja, kjer so
       zapisane vrednosti danega vektorskega ali skalarnega polja v posameznih
       vozlih. Te podatke potem doda na sklad oi->cont. oi->name mota biti enako
       stepname.
       POZOR: Prostor za oi->cont mora biti alociran pred klicom funkcije! */
{
char end=0,dosform=0,*buf=NULL;
long count=0,pos,pos1;
outinfo ref=NULL;
if (oi->cont==NULL)
  oi->cont=newstack(5);
if (oi!=NULL && cmpstrings(oi->name,stepname)==0 && oi->start>0 && oi->end>oi->start)
{
  pos=filestringto(fp,fieldname,oi->start,oi->end,1000);
  if (pos>0)
  {
    ref=newoutinfo();
    ref->name=stringcopy(fieldname);
    ref->superior=oi;
    ref->pos=pos;
    ref->start=-1;
    ref->end=-1;
    /* Izpustiti moramo vse, kar se ne pomeni zacetka podatkov: */
    /* $$$ sprememba za DOS komp.
    pos=filecharto(fp,"\n\r",2,pos+strlen(fieldname),oi->end,50);
    */
    pos=filecharto(fp,"\n",1,pos+strlen(fieldname),oi->end,50);
    pos=filestringto(fp,strainstressstr,pos,oi->end,50);
    if (pos>0 && pos<=oi->end)
    {
      ref->start=pos;
      ref->end=pos;
    }
    else
    {
      ref->start=0;
      ref->end=0;
      end=1;
    }
    buf=stringcopy(strainstressstr);
    while (!end)
    {
      pos1=pos;
      /* $$$ sprememba za DOS komp.
      pos=filestringto(fp,"\n\n",pos1,oi->end,200);
      if (pos<=0)
        pos=filestringto(fp,"\r\r",pos1,oi->end,200);
      */
      if (!dosform)
        pos=filestringto(fp,"\n\n",pos1,oi->end,200);
      if (pos<=0 || dosform)
      {
        pos=filestringto(fp,"\r\n\r\n",pos1,oi->end,200);
        dosform=1;
      }
      if (pos>0)
      {
        ref->end=pos+1;
        pos=filenotcharto(fp,"\n\r ",3,pos,oi->end,10);
        if (pos>0)
        {
          buf[strlen(strainstressstr)-1]='\0';  /* buf se za vsak primer pokvari */
          fileread(buf,1,strlen(strainstressstr),fp,pos);
          if (cmpstrings(strainstressstr,buf)!=0)
            end=1;
        } else end=1;
      } else end=1;
    }
    if (buf!=NULL) free(buf);
    buf=NULL;
  }
  pushstack(oi->cont,ref);
}
}



static double strainstressnodeval(FILE *fp,outinfo ref,int nodenum,char *compstr)
{
char error=0,*basestr="GLOBAL NODAL POINT =",*buf=NULL;
int i,length;
long pos;
double x,ret;
stack st=NULL;
ret=infinity();
/* if (ref=NULL) */
if (ref!=NULL)
{
  st=newstack(5);
  buf=stringcat(basestr,"               ");
  sprintf(buf,"%s%5i",basestr,nodenum);
  filestringallto(fp,buf,ref->start,ref->end,1000,st);
  if (buf!=NULL)
    free(buf);
  buf=NULL;
  error=0; ret=0;
  if (st->n>0)
    for (i=1;i<=st->n;++i)
    {
      pos=filestringto(fp,compstr,* ((long *) st->s[i]),ref->end,1000);
      if (pos>0)
      {
        x=filenumto(fp,pos+strlen(compstr),ref->end,30,&pos,&length);
        if (pos>0)
          ret+=x;
        else
          error=1;
      } else error=1;
    }
  ret/=(double) st->n;
  if (error)
    ret=infinity();
  if (st!=NULL)
    dispstack(&st);
  st=NULL;
}
return ret;
}



double strainstressfieldval(char * subbasename,char *stepname,long incnum,
       char *fieldname,int nodenum,char *compstr,FILE *fp,outinfo *oi1)
       /* Vrne koordinato coord vrednosti polja z imenom fieldname po inkrementu
       s stevilko incnum v vozlu s stevilko nodnum. Podatke najde v datoteki fp,
       ze najdene podatki pa so vpisani v sistemu oi1. */
{
outinfo oi,oiref,ref;
double ret;
char errors=0,end=0;
outinfo o;
long numincs,firstinc,lastinc,incnum1;
if (*oi1==NULL)
  *oi1=newoutinfo();
oi=*oi1;
o=*oi1;
if (cmpstrings(oi->name,basename)!=0 || oi->name==NULL)
  oi->name=stringcopy(basename);
if(oi->cont==NULL)
  oi->cont=newstack(5);
ref=oifindname(oi->cont,subbasename);
if (ref==NULL)
{
  ref=newoutinfo();
  ref->name=stringcopy(subbasename);
  ref->superior=oi;
  ref->cont=newstack(5);
  pushstack(oi->cont,ref);
}
oi=ref;
/* oi je sedaj kazalec na strukturo, ki v polju cont vsebuje podatke o posameznih
inkrementih. */

/* Prejsnji del programa:           (SPREMENJENO ZARADI EFEKTIVNOSTI)
ref=oifindincnum(stepname,oi->cont,incnum);
if (ref==NULL)
  findincrements(stepname,fp,oi);
*/
/* Novi del programa: */
if (oi->cont==NULL)
  findincrements(stepname,fp,oi);
else if (oi->cont->n<1)
  findincrements(stepname,fp,oi);

if (checkincfield && incnum<=0)
{
  end=0;
  numincs=oitellincnum(stepname,oi->cont,&firstinc,&lastinc);
  if (incnum==0)
  {
    incnum1=lastinc;
    if (lastinc<=0)
      end=1;
  }
  if (incnum==-1)
  {
    incnum1=firstinc;
    if (firstinc<=0)
      end=1;
  }
  oiref=oi;
  while (! end)
  {
    ref=oifindincnum(stepname,oiref->cont,incnum1);
    /* if (ref==NULL) ++errors; */
    if (ref!=NULL)
    {
      oi=ref;
      if (oi->cont==NULL)
        oi->cont=newstack(5);
      ref=oifindname(oi->cont,fieldname);
      if (ref==NULL)
        strainstressfindfield(stepname,fp,oi,fieldname);
      ref=oifindname(oi->cont,fieldname);
      /* if (ref==NULL) ++ errors; */
      if (ref!=NULL && !errors)
      {
        ret=strainstressnodeval(fp,ref,nodenum,compstr);
        end=1;
      }
    }
    if (incnum==0)
      --incnum1;
    else
      ++incnum1;
    if (incnum1<firstinc && incnum1>lastinc)
    {
      end=1;
      ++errors;
    }
  }
} else
{
  ref=oifindincnum(stepname,oi->cont,incnum);
  if (ref==NULL) ++errors;
  oi=ref;
  if (oi->cont==NULL)
    oi->cont=newstack(5);
  ref=oifindname(oi->cont,fieldname);
  if (ref==NULL)
    strainstressfindfield(stepname,fp,oi,fieldname);
  ref=oifindname(oi->cont,fieldname);
  if (ref==NULL) ++ errors;
  if (ref!=NULL && !errors)
    ret=strainstressnodeval(fp,ref,nodenum,compstr);
}
if (errors)
  return infinity();
else
  return ret;
fflush(fp);
}





outinfo oifindsubname(stack st,char *str,char *substr,long subfieldnum)
        /* V skladu st, ki vsebuje podatke o mestih v datoteki v okviru enega
        inkrementa, kjer so vrednosti vektorskih polj, poisce mesto, ki opisuje
        polje z dolocenim imenom. Vrne kazalec na strukturo, ki vsebuje iskane
        podatke, ali NULL, ce podatkov ne najde. */
{
outinfo oi,oi1,ret=NULL;
stack st1;
int i;
char end=0;
long *psubnum;
if (st!=NULL && st->n>0)
{
  i=1; oi1=NULL; end=0;
  while (!end && i<=st->n)
  {
    oi=st->s[i];
    if (oi!=NULL)
      if (cmpstrings(str,oi->name)==0)
      {
        oi1=oi; end=1;
      }
    ++i;
  }
  if (oi1!=NULL)
  {
    st1=oi1->cont;
    i=1;  oi=NULL;  end=0;
    if (st1==NULL)
      end=1;
    else if (st1->n<1)
      end=1;
    if (st1!=NULL)
      while (!end && i<=st1->n)
      {
        oi=st1->s[i];
        if (oi!=NULL)
        {
          psubnum= (long *) oi->point;
          if ( (cmpstrings(substr,oi->name)==0) && (*psubnum==subfieldnum) )
          {
            ret=oi; end=1;
          }
        }
        ++i;
      }
  }
}
return ret;
}




static void findsubfieldold(char *stepname,FILE *fp,outinfo oi,char *fieldname,
                         char *subfieldname)
       /*
       STARA VERZIJA !!!
         V datoteki, poveznai z fp, najde zacetek in konec obmocja, kjer so
       zapisane vrednosti danega vektorskega ali skalarnega polja v posameznih
       vozlih. Te podatke potem doda na sklad oi->cont. oi->name mota biti enako
       stepname.
       POZOR: Prostor za oi->cont mora biti alociran pred klicom funkcije! */
{
char end=0,end1=0;
double x;
int length;
long count=0,pos,pos1,pos2,pos0,*subnum=NULL;
outinfo ref=NULL,ref1=NULL;
if (oi->cont==NULL)
  oi->cont=newstack(5);
if (oi!=NULL && cmpstrings(oi->name,stepname)==0 && oi->start>0 && oi->end>oi->start)
{
  pos=filestringto(fp,fieldname,oi->start,oi->end,1000);
  if (pos>0)
  {
    ref=newoutinfo();
    ref->name=stringcopy(fieldname);
    ref->superior=oi;
    ref->pos=pos;
    ref->start=ref->end=0;
    /* Nasli smo pozicijo polja, sedaj moramo najti se vse pozicije podpolj.
    Za podpolja se moramo posebej prepricati, da res pripadajo nasemu polju. */
    pos1=pos2=0;
    pos=filecharto(fp,"\n\r",2,pos,oi->end,100);
    if (pos>0)
      pos=filecharto(fp,"\n\r",2,pos+1,oi->end,100);
    if (pos>0)
    {
      pos1=filenotcharto(fp," \n\r",3,pos,oi->end,100);
      pos2=filestringto(fp,subfieldname,pos,oi->end,80);
    }
    if (pos1>0 && pos1==pos2)
    {
      /* Nasli smo pozicijo 1. podpolja */
      end=0;
      pos=pos2;
      ref->start=ref->end=pos;
      if (ref->cont==NULL)
        ref->cont=newstack(5);
    } else  /* Polje nima podpolj. */
      end=1;
    while (!end)
    {
      /* V pos je sedaj pozicija naslednjega podpolja. Ugotovi se dolzina
      podpolja, podatki o podpolju se zapisejo v sistem podatkov, ugotovi
      se obstoj naslednjega podpolja: */
      ref1=newoutinfo();
      pushstack(ref->cont,ref1);
      ref1->superior=ref;
      ref1->pos=pos;
      ref1->start=ref->end=0;
      ref1->name=stringcopy(subfieldname);
      pos1=pos+strlen(subfieldname);
      x=filenumto(fp,pos1,oi->end,15,&pos2,&length);
      if (pos2>0 && length>0)
        /* pos1=pos2+length; */
        {
          subnum=malloc(sizeof(*subnum));
          *subnum=(long)x;
          ref1->point=subnum; subnum=NULL;
        }
      /* Izpustiti moramo vse, kar se ne pomeni zacetka podatkov podpolja : */
      pos=filecharto(fp,"\n\r",2,pos+strlen(subfieldname),oi->end,50);
      x=filenumto(fp,pos,oi->end,40,&pos,&length);
      if (pos>0 && pos<=oi->end)
      {
        end1=0;
        ref1->start=pos;
        ref1->end=pos;
      }
      else
      {
        ref1->start=0;
        ref1->end=0;
        end=1;
        end1=1;
      }
      while (!end1)
      {
        /* Preveri se, ce prvi znak v vrstici, ki je razlicen od presledka,
        pripada stevilu: */
        pos2=filecharto(fp,"\n\r",2,pos,oi->end,15); /* Konec vrstice */
        pos0=filenotcharto(fp," ",1,pos,pos2,15);
        x=filenumto(fp,pos,pos2,30,&pos1,&length);
        if (pos0!=pos1 || pos1<=0)
        {
          end1=1;
          ref1->end=pos;
        }
        pos=pos2+1;
      }
      /* Preveri se, ce obstaja naslednje polje: */
      pos1=pos2=0;
      pos=filecharto(fp,"\n\r",2,ref1->end,oi->end,100);
      if (pos>0)
        pos=filecharto(fp,"\n\r",2,pos+1,oi->end,100);
      if (pos>0)
      {
        pos1=filenotcharto(fp," \n\r",3,pos,oi->end,100);
        pos2=filestringto(fp,subfieldname,pos,oi->end,80);
      }
      if (pos1>0 && pos1==pos2)
      {
        /* Nasli smo pozicijo naslednjega podpolja */
        pos=pos2;
        ref->end=pos;
      } else  /* Polje nima vec podpolj. */
        end=1;
    }
  }
  pushstack(oi->cont,ref);
}
}






static void findsubfield(char *stepname,FILE *fp,outinfo oi,char *fieldname,
                         char *subfieldname)
       /* V datoteki, poveznai z fp, najde zacetek in konec obmocja, kjer so
       zapisane vrednosti danega vektorskega ali skalarnega polja v posameznih
       vozlih. Te podatke potem doda na sklad oi->cont. oi->name mota biti enako
       stepname.
       POZOR: Prostor za oi->cont mora biti alociran pred klicom funkcije!
       $A Igor <== mar97; */
{
char end=0,end1=0;
double x;
int length;
long count=0,pos,pos1,pos2,pos0,*subnum=NULL;
outinfo ref=NULL,ref1=NULL;
if (oi->cont==NULL)
  oi->cont=newstack(5);
if (oi!=NULL && cmpstrings(oi->name,stepname)==0 && oi->start>0 && oi->end>oi->start)
{
  pos=filestringto(fp,fieldname,oi->start,oi->end,1000);
  if (pos>0)
  {
    ref=newoutinfo();
    ref->name=stringcopy(fieldname);
    ref->superior=oi;
    ref->pos=pos;
    ref->start=ref->end=0;
    /* Nasli smo pozicijo polja, sedaj moramo najti se vse pozicije podpolj.
    Za podpolja se moramo posebej prepricati, da res pripadajo nasemu polju. */
    pos1=pos2=0;
    /* $$$ sprememba za DOS komp.
    pos=filecharto(fp,"\n\r",2,pos,oi->end,100);
    */
    pos=filecharto(fp,"\n",1,pos,oi->end,100);
    if (pos>0)
    /* $$$ sprememba za DOS komp.
      pos=filecharto(fp,"\n\r",2,pos+1,oi->end,100);
    */
      pos=filecharto(fp,"\n",1,pos+1,oi->end,100);
    if (pos>0)
    {
      pos1=filenotcharto(fp," \n\r",3,pos,oi->end,100);
      pos2=filestringto(fp,subfieldname,pos,oi->end,80);
    }
    if (pos1>0 && pos1==pos2)
    {
      /* Nasli smo pozicijo 1. podpolja */
      end=0;
      pos=pos2;
      ref->start=ref->end=pos;
      if (ref->cont==NULL)
        ref->cont=newstack(5);
    } else  /* Polje nima podpolj. */
      end=1;
    while (!end)
    {
      /* V pos je sedaj pozicija naslednjega podpolja. Ugotovi se dolzina
      podpolja, podatki o podpolju se zapisejo v sistem podatkov, ugotovi
      se obstoj naslednjega podpolja: */
      ref1=newoutinfo();
      pushstack(ref->cont,ref1);
      ref1->superior=ref;
      ref1->pos=pos;
      ref1->start=ref->end=0;
      ref1->name=stringcopy(subfieldname);
      pos1=pos+strlen(subfieldname);
      x=filenumto(fp,pos1,oi->end,15,&pos2,&length);
      if (pos2>0 && length>0)
        /* pos1=pos2+length; */
        {
          subnum=malloc(sizeof(*subnum));
          *subnum=(long)x;
          ref1->point=subnum; subnum=NULL;
        }
      /* Izpustiti moramo vse, kar se ne pomeni zacetka podatkov podpolja : */
      /* $$$ sprememba za DOS komp.
      pos=filecharto(fp,"\n\r",2,pos+strlen(subfieldname),oi->end,50);
      */
      pos=filecharto(fp,"\n",1,pos+strlen(subfieldname),oi->end,50);
      x=filenumto(fp,pos,oi->end,40,&pos,&length);
      if (pos>0 && pos<=oi->end)
      {
        end1=0;
        ref1->start=pos;
        ref1->end=pos;
      }
      else
      {
        ref1->start=0;
        ref1->end=0;
        end=1;
        end1=1;
      }
      while (!end1)
      {
        /* Preveri se, ce prvi znak v vrstici, ki je razlicen od presledka,
        pripada stevilu: */
        /* $$$ sprememba za DOS komp.
        pos2=filecharto(fp,"\n\r",2,pos,oi->end,15);
        */
        pos2=filecharto(fp,"\n",1,pos,oi->end,15); /* Konec vrstice */
        pos0=filenotcharto(fp," ",1,pos,pos2,15);
        x=filenumto(fp,pos,pos2,30,&pos1,&length);
        if (pos0!=pos1 || pos1<=0)
        {
          end1=1;
          ref1->end=pos;
        }
        pos=pos2+1;
      }


      if (0)  /* STARA KODA !!! Spremenjena zato, da dela bolj splosno (zaradi
                 napake v Elfenu). */
      {

        /* Preveri se, ce obstaja naslednje polje: */
        pos1=pos2=0;
        /* $$$ sprememba za DOS komp.
        pos=filecharto(fp,"\n\r",2,ref1->end,oi->end,100);
        */
        pos=filecharto(fp,"\n",1,ref1->end,oi->end,100);
        if (pos>0)
          /* $$$ sprememba za DOS komp.
          pos=filecharto(fp,"\n\r",2,pos+1,oi->end,100);
          */
          pos=filecharto(fp,"\n",1,pos+1,oi->end,100);
        if (pos>0)
        {
          pos1=filenotcharto(fp," \n\r",3,pos,oi->end,100);
          pos2=filestringto(fp,subfieldname,pos,oi->end,80);
        }
        if (pos1>0 && pos1==pos2)
        {
          /* Nasli smo pozicijo naslednjega podpolja */
          pos=pos2;
          ref->end=pos;
        } else  /* Polje nima vec podpolj. */
          end=1;
      }




      /* Preveri se, ce obstaja naslednje polje: */
      pos1=pos2=0;
      /* POZOR: V tem delu kode se najprej poisce zacetek 6. vrstice od konca
      prejsnjega polja naprej in se preveri, ce niz za zacetek naslednjega
      podpolja lezi do tam (do 6. vrstice po koncu polja). To sluzi kot
      indikator, ali naslednje pod pollje obstaja ali ne. Ce se lahko zgodi,
      da je med koncem prejsnjega podpolja in pozicijo naslednjega vec kot 6
      novih vrstic, je treba se veckrat ponoviti klic filecharto(). Prej je
      bilo to narejeno tako, da se je po koncu prejsnjega podpolja preskocilo
      2 vrstici (ker po koncu polja sledi sestevek komponent podpolja), potem
      pa se je preverilo, ce je 1. znak od tam naprej, ki je razlicen od
      presledkov in znakov za novo vrstico, tudi 1. znak niza, ki oznacuje
      podpolje. To je potem sluzilo za indikacijo, ce ima polje se nadaljnja
      podpolja, vendar to ne dela pri poljih, kjer ni na koncu sestevkov za
      podpolja in je zdajsnji nacinn bolj splosen. */
      pos=filecharto(fp,"\n",1,ref1->end+1,oi->end,100);
      if (pos>0)
        pos=filecharto(fp,"\n",1,pos+1,oi->end,100);
      if (pos>0)
        pos=filecharto(fp,"\n",1,pos+1,oi->end,100);
      if (pos>0)
        pos=filecharto(fp,"\n",1,pos+1,oi->end,100);
      if (pos>0)
        pos=filecharto(fp,"\nr",1,pos+1,oi->end,100);
      if (pos>0)
        pos=filecharto(fp,"\n",1,pos+1,oi->end,100);
      if (pos<=0)
        pos=oi->end;
      if (pos>0)
      {
        pos2=filestringto(fp,subfieldname,ref1->end,pos,80);
      }
      if (pos2>0)
      {
        /* Nasli smo pozicijo naslednjega podpolja */
        pos=pos2;
        ref->end=pos;
      } else  /* Polje nima vec podpolj. */
        end=1;
    }
  }
  pushstack(oi->cont,ref);
}
}










double subfieldval(char * subbasename,char *stepname,long incnum,char *fieldname,
       char *subfieldname,long subfieldnum,long nodenum,int coord,FILE *fp,
       outinfo *oi1)
       /* Vrne koordinato coord vrednosti polja z imenom fieldname po inkrementu
       s stevilko incnum v vozlu s stevilko nodnum. Podatke najde v datoteki fp,
       ze najdene podatki pa so vpisani v sistemu oi1. */
{
outinfo oi,oiref,ref;
double ret;
char errors=0,end=0;
outinfo o;
long numincs,firstinc,lastinc,incnum1;
if (*oi1==NULL)
  *oi1=newoutinfo();
oi=*oi1;
o=*oi1;
if (cmpstrings(oi->name,basename)!=0 || oi->name==NULL)
  oi->name=stringcopy(basename);
if(oi->cont==NULL)
  oi->cont=newstack(5);
ref=oifindname(oi->cont,subbasename);
if (ref==NULL)
{
  ref=newoutinfo();
  ref->name=stringcopy(subbasename);
  ref->superior=oi;
  ref->cont=newstack(5);
  pushstack(oi->cont,ref);
}
oi=ref;
/* oi je sedaj kazalec na strukturo, ki v polju cont vsebuje podatke o posameznih
inkrementih. */

/* Prejsnji del programa:           (SPREMENJENO ZARADI EFEKTIVNOSTI)
ref=oifindincnum(stepname,oi->cont,incnum);
if (ref==NULL)
  findincrements(stepname,fp,oi);
*/
/* Novi del programa: */
if (oi->cont==NULL)
  findincrements(stepname,fp,oi);
else if (oi->cont->n<1)
  findincrements(stepname,fp,oi);

if (checkincfield && incnum<=0)
{
  end=0;
  numincs=oitellincnum(stepname,oi->cont,&firstinc,&lastinc);
  if (incnum==0)
  {
    incnum1=lastinc;
    if (lastinc<=0)
      end=1;
  }
  if (incnum==-1)
  {
    incnum1=firstinc;
    if (firstinc<=0)
      end=1;
  }
  oiref=oi;
  while (! end)
  {
    ref=oifindincnum(stepname,oiref->cont,incnum1);
    /* if (ref==NULL) ++errors; */
    if (ref!=NULL)
    {
      oi=ref;
      if (oi->cont==NULL)
        oi->cont=newstack(5);
      ref=oifindsubname(oi->cont,fieldname,subfieldname,subfieldnum);
      if (ref==NULL)
        findsubfield(stepname,fp,oi,fieldname,subfieldname);
      ref=oifindsubname(oi->cont,fieldname,subfieldname,subfieldnum);
      /* if (ref==NULL) ++ errors; */
      if (ref!=NULL) end=1;
      if (ref!=NULL && !errors)
      {
        oi=ref;
        ref=oifindfieldval(oi->cont,nodenum);
        if (ref==NULL)
        {
          findnodefield(fp,oi,nodenum);
          ref=oifindfieldval(oi->cont,nodenum);
        }
        if (ref==NULL) ++ errors;
        oi=(ref);
        if (coord>=0 && coord<=ref->res->n)
          ret= * (double *) ref->res->s[coord];
        else
        {
          printf("Error in function fieldval(): Invalid coordinate number %i.\n",coord);
          ++ errors;
        }
        end=1;
      }
    }
    if (incnum==0)
      --incnum1;
    else
      ++incnum1;
    if (incnum1<firstinc && incnum1>lastinc)
    {
      end=1;
      ++errors;
    }
  }
} else
{
  ref=oifindincnum(stepname,oi->cont,incnum);
  if (ref==NULL) ++errors;
  oi=ref;
  if (oi->cont==NULL)
    oi->cont=newstack(5);
  ref=oifindsubname(oi->cont,fieldname,subfieldname,subfieldnum);
  if (ref==NULL)
    findsubfield(stepname,fp,oi,fieldname,subfieldname);
  ref=oifindsubname(oi->cont,fieldname,subfieldname,subfieldnum);
  if (ref==NULL) ++ errors;
  oi=ref;
  ref=oifindfieldval(oi->cont,nodenum);
  if (ref==NULL)
  {
    findnodefield(fp,oi,nodenum);
    ref=oifindfieldval(oi->cont,nodenum);
  }
  if (ref==NULL) ++ errors;
  oi=(ref);
  if (coord>=0 && coord<=ref->res->n)
    ret= * (double *) ref->res->s[coord];
  else
  {
    printf("Error in function fieldval(): Invalid coordinate number %i.\n",coord);
    ++ errors;
  }
}
if (errors)
  return infinity();
else
  return ret;
fflush(fp);
}














/* FUNKCIJE, KI JIH LAHKO VKLJUCIMO V SIMBOLNI INTERPRETER KOT UPORABNISKE
   FUNKCIJE */





static double usernodtemp(object obj,stack st,stack user,int numargs,void *ptr)
       /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne temperaturo
       danega vozlisca v dani smeri. Pri klicu ustrezne funkcije v sistemu za
       simbolno racunanje pomenijo argumenti naslednje:
       1. argument je stevilka casovnega koraka, 2. argument je stevilka vozlisca,
       3. argument pa koordinata.
       Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
       Pri izvrsevanju funkcije se uporablja sistem podatkov o izhodni datoteki
       oi, ki je tako kot fout lokalna spremenljivka v tem modulu. */
{
object oo;
double ret,x;
long incnum,nodenum;
int coord;
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
incnum=(long) x;
oo=nstack((stack) st,2);
x=doubleval(oo,st,user);
nodenum=(long) x;
oo=nstack((stack) st,3);
x=doubleval(oo,st,user);
coord=(int) x;
ret=fieldval(timestepname,timestepstr,incnum,nodtempstr,nodenum,coord,fout,&oi);
return ret;
}




static double usernoddisp(object obj,stack st,stack user,int numargs,void *ptr)
       /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne odmik danega
       vozlisca v dani smeri. Pri klicu ustrezne funkcije v sistemu za simbolno
       racunanje pomenijo argumenti naslednje:
       1. argument je stevilka inkrementa, 2. argument je stevilka vozlisca,
       3. argument pa koordinata.
       Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
       Pri izvrsevanju funkcije se uporablja sistem podatkov o izhodni datoteki
       oi, ki je tako kot fout lokalna spremenljivka v tem modulu. */
{
object oo;
double ret,x;
long incnum,nodenum;
int coord;
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
incnum=(long) x;
oo=nstack((stack) st,2);
x=doubleval(oo,st,user);
nodenum=(long) x;
oo=nstack((stack) st,3);
x=doubleval(oo,st,user);
coord=(int) x;
ret=fieldval(incname,incstr,incnum,noddispstr,nodenum,coord,fout,&oi);
return ret;
}



static double userlocnoddisp(object obj,stack st,stack user,int numargs,
       void *ptr)
       /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne odmik danega
       vozlisca v dani smeri v lokalnem koordinat. sistemu za to vozlisce. Pri
       klicu ustrezne funkcije v sistemu za simbolno racunanje pomenijo
       argumenti naslednje:
       1. argument je stevilka inkrementa, 2. argument je stevilka vozlisca,
       3. argument pa koordinata.
       Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
       Pri izvrsevanju funkcije se uporablja sistem podatkov o izhodni datoteki
       oi, ki je tako kot fout lokalna spremenljivka v tem modulu. */
{
object oo;
double ret,x;
long incnum,nodenum;
int coord;
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
incnum=(long) x;
oo=nstack((stack) st,2);
x=doubleval(oo,st,user);
nodenum=(long) x;
oo=nstack((stack) st,3);
x=doubleval(oo,st,user);
coord=(int) x;
ret=fieldval(incname,incstr,incnum,locnoddispstr,nodenum,coord,fout,&oi);
return ret;
}


static double usernodreac(object obj,stack st,stack user,int numargs,void *ptr)
       /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne reakcijo na
       dano vozlisce v dani smeri. Pri klicu ustrezne funkcije v sistemu za
       simbolno racunanje pomenijo argumenti naslednje:
       1. argument je stevilka inkrementa, 2. argument je stevilka vozlisca,
       3. argument pa koordinata.
       Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
       Pri izvrsevanju funkcije se uporablja sistem podatkov o izhodni datoteki
       oi, ki je tako kot fout lokalna spremenljivka v tem modulu. */
{
object oo;
double ret,x;
long incnum,nodenum;
int coord;
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
incnum=(long) x;
oo=nstack((stack) st,2);
x=doubleval(oo,st,user);
nodenum=(long) x;
oo=nstack((stack) st,3);
x=doubleval(oo,st,user);
coord=(int) x;
ret=fieldval(incname,incstr,incnum,nodreacstr,nodenum,coord,fout,&oi);
return ret;
}



static double userlocnodreac(object obj,stack st,stack user,int numargs,void *ptr)
       /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne reakcijo na
       dano vozlisce v dani smeri v lokalnem koordinatnem sistemu, ki je
       predpisan za to vozlisce. Pri klicu ustrezne funkcije v sistemu za
       simbolno racunanje pomenijo argumenti naslednje:
       1. argument je stevilka inkrementa, 2. argument je stevilka vozlisca,
       3. argument pa koordinata.
       Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
       Pri izvrsevanju funkcije se uporablja sistem podatkov o izhodni datoteki
       oi, ki je tako kot fout lokalna spremenljivka v tem modulu. */
{
object oo;
double ret,x;
long incnum,nodenum;
int coord;
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
incnum=(long) x;
oo=nstack((stack) st,2);
x=doubleval(oo,st,user);
nodenum=(long) x;
oo=nstack((stack) st,3);
x=doubleval(oo,st,user);
coord=(int) x;
ret=fieldval(incname,incstr,incnum,locnodreacstr,nodenum,coord,fout,&oi);
return ret;
}



static double usernodstrain(object obj,stack st,stack user,int numargs,
       void *ptr)
       /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne odmik danega
       vozlisca v dani smeri. Pri klicu ustrezne funkcije v sistemu za simbolno
       racunanje pomenijo argumenti naslednje:
       1. argument je stevilka inkrementa, 2. argument je stevilka vozlisca,
       3. argument pa koordinata.
       Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
       Pri izvrsevanju funkcije se uporablja sistem podatkov o izhodni datoteki
       oi, ki je tako kot fout lokalna spremenljivka v tem modulu. */
{
object oo;
double ret,x;
int coord1,coord2,incnum,nodenum;
char *mainstr=NULL,*whichstr=NULL,*compstr=NULL,*strptr=NULL;
whichstr=stringcopy("  ");
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
incnum=(long) x;
oo=nstack((stack) st,2);
x=doubleval(oo,st,user);
nodenum=(long) x;
oo=nstack((stack) st,3);
x=doubleval(oo,st,user);
coord1=(int) x;
if (numargs==4) /* Isce se komponenta deformacijskega tenzorja */
{
  oo=nstack((stack) st,4);
  x=doubleval(oo,st,user);
  coord2=(int) x;
  mainstr="STRN-";
  strptr=whichstr;
  if (coord1==1) *strptr='X';
  if (coord1==2) *strptr='Y';
  if (coord1==3) *strptr='Z';
  ++strptr;
  if (coord2==1) *strptr='X';
  if (coord2==2) *strptr='Y';
  if (coord2==3) *strptr='Z';
  compstr=stringcat(mainstr,whichstr);
} else if (numargs==3) /* Isce se lastna vrednost deformacijskega tenzorja */
{
  mainstr="PRINC-";
  strptr=whichstr;
  sprintf(strptr,"%1i",coord1);
  ++strptr;
  *strptr='\0';
  compstr=stringcat(mainstr,whichstr);
}
ret=strainstressfieldval(incname,incstr,incnum,strainstr,nodenum,compstr,
    fout,&oi);
if (compstr!=NULL)
  free(compstr);
compstr=NULL;
if (whichstr!=NULL)
  free(whichstr);
return ret;
}



static double usernodstress(object obj,stack st,stack user,int numargs,
       void *ptr)
       /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne odmik danega
       vozlisca v dani smeri. Pri klicu ustrezne funkcije v sistemu za simbolno
       racunanje pomenijo argumenti naslednje:
       1. argument je stevilka inkrementa, 2. argument je stevilka vozlisca,
       3. argument pa koordinata.
       Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
       Pri izvrsevanju funkcije se uporablja sistem podatkov o izhodni datoteki
       oi, ki je tako kot fout lokalna spremenljivka v tem modulu. */
{
object oo;
double ret,x;
int coord1,coord2,incnum,nodenum;
char *mainstr=NULL,*whichstr,*compstr=NULL,*strptr=NULL;
whichstr=stringcopy("  ");
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
incnum=(long) x;
oo=nstack((stack) st,2);
x=doubleval(oo,st,user);
nodenum=(long) x;
oo=nstack((stack) st,3);
x=doubleval(oo,st,user);
coord1=(int) x;
if (numargs==4) /* Isce se komponenta deformacijskega tenzorja */
{
  oo=nstack((stack) st,4);
  x=doubleval(oo,st,user);
  coord2=(int) x;
  mainstr="STRS-";
  strptr=whichstr;
  if (coord1==1) *strptr='X';
  if (coord1==2) *strptr='Y';
  if (coord1==3) *strptr='Z';
  ++strptr;
  if (coord2==1) *strptr='X';
  if (coord2==2) *strptr='Y';
  if (coord2==3) *strptr='Z';
  compstr=stringcat(mainstr,whichstr);
} else if (numargs==3) /* Isce se lastna vrednost deformacijskega tenzorja */
{
  mainstr="PRINC-";
  strptr=whichstr;
  sprintf(strptr,"%1i",coord1);
  ++strptr;
  *strptr='\0';
  compstr=stringcat(mainstr,whichstr);
}
ret=strainstressfieldval(incname,incstr,incnum,stressstr,nodenum,compstr,
    fout,&oi);
if (compstr!=NULL)
  free(compstr);
compstr=NULL;
if (whichstr!=NULL)
  free(whichstr);
return ret;
}



static double usernodcontforc(object obj,stack st,stack user,int numargs,
                              void *ptr)
       /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne reakcijo na
       dano vozlisce v dani smeri. Pri klicu ustrezne funkcije v sistemu za
       simbolno racunanje pomenijo argumenti naslednje:
       1. argument je stevilka inkrementa, 2. argument je stevilka vozlisca,
       3. argument pa koordinata.
       Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
       Pri izvrsevanju funkcije se uporablja sistem podatkov o izhodni datoteki
       oi, ki je tako kot fout lokalna spremenljivka v tem modulu. */
{
object oo;
double ret,x;
long incnum,surfnum,nodenum;
int coord;
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
incnum=(long)x;
oo= nstack((stack) st,2);
x=doubleval(oo,st,user);
surfnum=(long) x;
oo=nstack((stack) st,3);
x=doubleval(oo,st,user);
nodenum=(long) x;
oo=nstack((stack) st,4);
x=doubleval(oo,st,user);
coord=(int) x;
if (nodenum>=0)
  ++ coord; /* Ker je na mestu 1. podatka FLAG in ne 1. koordinata. */
ret=subfieldval(incname,incstr,incnum,nodcontforcstr,nodcontforcsubstr,
                surfnum,nodenum,coord,fout,&oi);
return ret;
}



static double userlocnodcontforc(object obj,stack st,stack user,int numargs,
                              void *ptr)
       /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne reakcijo na
       dano vozlisce v dani smeri. Pri klicu ustrezne funkcije v sistemu za
       simbolno racunanje pomenijo argumenti naslednje:
       1. argument je stevilka inkrementa, 2. argument je stevilka vozlisca,
       3. argument pa koordinata.
       Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
       Pri izvrsevanju funkcije se uporablja sistem podatkov o izhodni datoteki
       oi, ki je tako kot fout lokalna spremenljivka v tem modulu. */
{
object oo;
double ret,x;
long incnum,surfnum,nodenum;
int coord;
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
incnum=(long)x;
oo= nstack((stack) st,2);
x=doubleval(oo,st,user);
surfnum=(long) x;
oo=nstack((stack) st,3);
x=doubleval(oo,st,user);
nodenum=(long) x;
oo=nstack((stack) st,4);
x=doubleval(oo,st,user);
coord=(int) x;
if (nodenum>=0)
  ++ coord; /* Ker je na mestu 1. podatka FLAG in ne 1. koordinata. */
ret=subfieldval(incname,incstr,incnum,locnodcontforcstr,nodcontforcsubstr,
                surfnum,nodenum,coord,fout,&oi);
return ret;
}




static double usernodcontwear(object obj,stack st,stack user,int numargs,
                              void *ptr)
       /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne reakcijo na
       dano vozlisce v dani smeri. Pri klicu ustrezne funkcije v sistemu za
       simbolno racunanje pomenijo argumenti naslednje:
       1. argument je stevilka inkrementa, 2. argument je stevilka vozlisca,
       3. argument pa koordinata.
       Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
       Pri izvrsevanju funkcije se uporablja sistem podatkov o izhodni datoteki
       oi, ki je tako kot fout lokalna spremenljivka v tem modulu. */
{
object oo;
double ret,x;
long incnum,surfnum,nodenum;
int coord;
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
incnum=(long)x;
oo= nstack((stack) st,2);
x=doubleval(oo,st,user);
surfnum=(long) x;
oo=nstack((stack) st,3);
x=doubleval(oo,st,user);
nodenum=(long) x;
oo=nstack((stack) st,4);
x=doubleval(oo,st,user);
coord=(int) x;
if (nodenum>=0)
  ++ coord; /* Ker je na mestu 1. podatka FLAG in ne 1. koordinata. */
ret=subfieldval(incname,incstr,incnum,nodcontwearstr,nodcontforcsubstr,
                surfnum,nodenum,coord,fout,&oi);
return ret;
}




/* FUNKCIJA IN PODPORA FUNKCIJI ZA BRANJE ZACETNIH KOORDINAT VOZLISC IZ
   DATOTEKE REZULTATOV: */


static stack nodcoordstack=NULL;

static void readnodecoordinates(void)
    /* Iz datoteke fout (lokalna spremenljivka; to mora biti odprta datoteka
    rezultatov) prebere celotno polje vozliscnih koordinat in spravi podatke na
    sklad nodcoordstack.
    $A Igor jul97; */
{
if (nodcoordstack==NULL)
  nodcoordstack=newstack(20);
if (fout!=NULL)
  fresreadnodefield("NODE COORD",fout,1,nodcoordstack);
else
  printf("Error in function \"readnodecoordinates\": File not ready for reading.\n");
}

static void clearnodecoordinates(void)
    /* Zbrise podatke s sklada nodcoordstack, kamor se nalozi celotno polje
    vozliscnih koordinat.
    $A Igor jul97; */
{
nodcoord nc;
int i;
if (nodcoordstack!=NULL)
{
  for (i=1;i<=nodcoordstack->n;++i)
  {
    nc=nodcoordstack->s[i];
    if (nc!=NULL)
      free(nc);
    nodcoordstack->s[i]=NULL;
  }
  dispstack(&nodcoordstack);
}
nodcoordstack=NULL;
}

static double getnodecoord(int node,int which)
    /* Funkcija najde in vrne koordinato which vozlisca node na skladu
    nodcoordstack.
    $A Igor jul97; */
{
nodcoord nc;
int i;
char found=0;
double ret=0;
if (nodcoordstack==NULL)
  readnodecoordinates();
if (node>0 && which>0 && which<=3)
  if (nodcoordstack!=NULL)
  {
    i=1; found=0;
    while (!found && i<=nodcoordstack->n)
    {
      nc=nodcoordstack->s[i];
      if (nc!=NULL)
        if (nc->i==node)
          found=1;
      ++i;
    }
  }
if (found)
{
  switch(which)
  {
    case 1:
      ret=nc->x;
      break;
    case 2:
      ret=nc->y;
      break;
    case 3:
      ret=nc->z;
      break;
  }
}
return ret;
}

static double usernodcoord(object obj,stack st,stack user,int numargs,
                              void *ptr)
    /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne zahtevano
    koordinato zacetnega polozaja danega vozlisca. Pri klicu ustrezne
    funkcije v sistemu za simbolno racunanje pomenijo argumenti naslednje:
    1. argument je stevilka vozlisca, 2. argument je stevilka koordinatne
    osi.
    Datoteka, iz katere vzame podatek, je fout in mora biti odprta za branje.
    Pri izvrsevanju funkcije se uporablja sklad nodcoordstack, na katerega
    se nalozijo podatki o celotnem polju pozicij vozlisc in je tako kot fout
    lokalna spremenljivka v tem modulu.
    $A Igor jul97; */
{
object oo;
double x;
int nodenum,coord;
oo= nstack((stack) st,1);
x=doubleval(oo,st,user);
nodenum=(int)x;
oo= nstack((stack) st,2);
x=doubleval(oo,st,user);
coord=(int) x;
return getnodecoord(nodenum,coord);
}



static double useranerror(object obj,stack st,stack user,int numargs,
                              void *ptr)
    /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne 1, ce se je
    med analizo pojavila napaka in je to zapisano v izhodni datoteki analize
    (lokalna spremenljivka fout), drugace vrne 0.
     POZOR!
    Funkcija smatra, da je prislo do napake med analizo, ce najde niz errorstr
    v datoteki fout, vendar mora biti zacetek niza manj kot MAX_TILLEND znakov
    pred koncem datoteke.
    $A Igor dec97; */
{
double ret=0;
long pos;
if (fout!=NULL)
{
  pos=flength(fout)-MAX_TILLEND;
  if (pos<0)
    pos=1;
  pos=filestring(fout,errorstr,pos,200);
  if (pos>0)
    ret=1;
}
return ret;
}

static double useransuccess(object obj,stack st,stack user,int numargs,
                              void *ptr)
    /* Funkcijo instaliramo v sistem za simbolno racunanje. Vrne 1, ce se je
    analiza uspesno izvedla in je to zapisano v izhodni datoteki analize
    (lokalna spremenljivka fout), drugace vrne 0.
     POZOR!
    Funkcija smatra, da je bila analiza uspesna, ce najde niz successstr
    v datoteki fout, vendar mora biti zacetek niza manj kot MAX_TILLEND znakov
    pred koncem datoteke.
    $A Igor dec97; */
{
double ret=0;
long pos;
if (fout!=NULL)
{
  pos=flength(fout)-MAX_TILLEND;
  if (pos<0)
    pos=1;
  pos=filestring(fout,successstr,pos,200);
  if (pos>0)
    ret=1;
}
return ret;
}




void instintfcuserfunc(ssyst system)
     /* Na sistem za simbolno racunanje instalira funkcije za ekstrakcijo
     podatkov iz izhodne datoteke programa za direktne analize. */
{
installuserfunc(system,"nodtemp",usernodtemp,NULL,NULL,NULL);
installuserfunc(system,"noddisp",usernoddisp,NULL,NULL,NULL);
installuserfunc(system,"locnoddisp",userlocnoddisp,NULL,NULL,NULL);
installuserfunc(system,"nodreac",usernodreac,NULL,NULL,NULL);
installuserfunc(system,"locnodreac",userlocnodreac,NULL,NULL,NULL);
installuserfunc(system,"nodstrain",usernodstrain,NULL,NULL,NULL);
installuserfunc(system,"nodstress",usernodstress,NULL,NULL,NULL);
installuserfunc(system,"nodcontforc",usernodcontforc,NULL,NULL,NULL);
installuserfunc(system,"locnodcontforc",userlocnodcontforc,NULL,NULL,NULL);

installuserfunc(system,"nodcontwear",usernodcontwear,NULL,NULL,NULL);

installuserfunc(system,"nodcoord",usernodcoord,NULL,NULL,NULL);

installuserfunc(system,"anerror",useranerror,NULL,NULL,NULL);
installuserfunc(system,"ansuccess",useransuccess,NULL,NULL,NULL);

}


void setintfcoutfile(FILE *outfile)
     /* Postavi izhodno datoteko direktne analize, iz katere se jemlejo podatki.
     To datoteko uporabljajo funkcije usernoddisp, userlocnoddisp, usernodreac,
     userlocnodreac, ... */
{
fout=outfile;
}



void clearintfcoutinfo(void)
     /* Funkcija zbrise celoten sistem podatkov oi o izhodni datoteki direktne
     analize. oi se postavi na NULL. Ta kazalec na sistem podatkov uporabljajo
     funkcije usernoddisp, userlocnoddisp, usernodreac, userlocnodreac, ... */
{
clearnodecoordinates();
dispoutinfo(& oi);
}



void setintfcoutinfo(void *ptr)
     /* Funkcija postavi kazalec na sistem podatkov oi o izhodni datoteki
     direktne analize (ta sistem uporabljajo funkcije usernoddisp, userlocnoddisp,
     usernodreac, userlocnodreac, ... ) na ptr. V resnici je funkcija namenjena
     za postavljanje tega kazalca na NULL. */
{
oi= (outinfo) ptr;
}


void setintfcincstr(char *str)
    /* Postavi niz incstr na niz str (str se najprej skopira v incstraux, nato
    pa se postavi incstr na incstraux). incstr je niz, ki v izhodni datoteki
    direktne analize oznacuje zacetek novega inkrementa.
    $A Igor feb98; */
{
if (incstraux!=NULL)
  free(incstraux);
if (str!=NULL)
  incstraux=stringcopy(str);
else
  incstraux=NULL;
incstr=incstraux;
}



/* IZHODNI PARAMETRI ZA DIREKTNO ANALIZO (branje) */


/*
POZOR !!
V SEDANJI FAZI JE V ENEM KORAKU MOZNO BRANJE PODATKOV IZ ENE SAME DATOTEKE !!!
PO BRANJU SE CELOTEN SISTEM PODATKOV RESETIRA!
*/



void prepare01(char * filename,stack args,stack foundkwd)
     /* 1. priprava za iskanje v datoteki z imenom filename, ki vsebuje izhodne
     podatke za direktno analizo. args je sklad, ki vsebuje sezname argumentov
     funkcij, ki prebirajo vrednosti parametrov. foundwd je sklad, kamor se
     nalagajo podatki o najdenih kljucnih besedah. */

{
FILE *fp;
stack searchnext;
kwdinfo kwdi;
char end;
long lnum;
int i;
void *point;
char *incstr="INCREMENT NUM";
fp=fopen(filename,"rb");
searchnext=NULL;
/* Najprej se poiscejo mesta v datoteki, ki vsebujejo podatke za posamezne
inkremente. V datoteki se poiscejo vsi nizi, ki pomenijo zacetek podatkov o
novih inkrementih: */
kwdi=newkwdinfo();
kwdi->name=stringcopy(incstr);
point=malloc(sizeof(long));
* (long *) point= 1;
pushstack(kwdi->searchfrom,point);
point=NULL;
point=malloc(sizeof(long));
* (long *) point= flength(fp);
pushstack(kwdi->searchto,point); /* Iscemo po celotni datoteki. */
point=NULL;
/* Na sklad kwdi->pos se nalozijo pozicije vseh nizov incstr v datoteki */
allfilestring(fp,incstr,1,10000,kwdi->pos);
if (kwdi->pos->n>1)
  for (i=1; i<=kwdi->pos->n; ++i)
  {
    /* Koncni oklepaji se vzamejo eno mesto pred pojavom niza, ki oznacuje
    zacetek podatkov za naslednji inkrement: */
    point=malloc(sizeof(long));
    if (i<kwdi->pos->n)
      * (long *) point= * (long *) (kwdi->pos->s[i+1]) -1;
    else
      * (long *) point=flength(fp);
    pushstack(kwdi->endbrackets,point);
  }
if (kwdi->pos->n>0)
{
  /* Polji defnames in subnames ne pri nizu, ki oznacuje */
  for (i=1; i<=kwdi->pos->n; ++i)
  {
    pushstack(kwdi->defnames,NULL);
    pushstack(kwdi->subnames,NULL);
  }
}
end=1; i=1;
do
{
  lnum=1;
  ++i;
} while (end);
kwdi=NULL;
fclose(fp);
fp=NULL;
}






















/* VHODNI PARAMETRI ZA DIREKTNO ANALIZO */



static int intfcoutdig=15,   /* St. dec. mest pri izpisovanju stevil */
           intfcoutchar=1;  /* Min. st. mest pri izpisovanju stevil */

int intfcgetoutdig(void)
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu intfc.c.
    $A Igor mar99; */
{
return intfcoutdig;
}

int intfcgetoutchar(void)
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu intfc.c.
    $A Igor mar99; */
{
return intfcoutchar;
}

void intfcsetoutdig(int num)
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu intfc.c.
    $A Igor mar99; */
{
if (intfcoutdig>0)
  intfcoutdig=num;
}

void intfcsetoutchar(int num)
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu intfc.c.
    $A Igor mar99; */
{
if (intfcoutchar>0)
  intfcoutchar=num;
}




static int findinputparam(FILE *fp,stack stfileplace,stack stlength,
           stack stparamnum)
                  /* V datoteki fp, ki mora biti vhodna datoteka za analizo,
                  najde vsa mesta, kjer so zapisani tisti vhodni parametri, ki
                  jih spreminjamo. V datoteki morajo biti ta mesta predhodno
                  oznacena z oklepajem tipa
                    { $$INV {p1:s1} {p2:s2} {p3:s3} ....  END }
                  2. stevila (s) povedo, s katerim parametrom inverzne analize
                  se mora povezati doticni podatek v datoteki. 1. stevila (p)
                  pa povedo, kje se doticni podatek najde, konkretno ta stevila
                  povedo, katero stevilo po vrsti od oznacevalnega oklepaja
                  naprej predstavlja nas doticni podatek.
                    Funkcija v v ustrezna mesta na skladih zapise potrebne
                  podatke, in sicer v paramnum stevilko parametra, v fileplace
                  mesto v datoteki (steti se zacne z 1), kjer se doticni podatek
                  nahaja, v length pa stevilo bytov, ki jih je treba zapisati
                  pri prepisovanju tega podatka. To je pomembno zato, da se pri
                  prepisovanju podatka ne bi pisalo na mesta, ki pripadajo ze
                  drugim podatkom, ter da se lahko preprecijo napake, ki bi
                  nastale, ko bi pri naslednjem pisanju niz, ki predstavlja
                  novo vrednost doloceneka podatka, bil krajsi kot pri
                  predhodnem ter bi zato pri prepisanju podatka ostali
                  nepravilni znaki. Dolzina se vzame tako, da se od konca niza,
                  ki predstavlja vrednost doticnega podatka, k dolzini stejejo
                  se vsi presledki razen zadnjega do naslednjega podatka.
                    PRIMER: Ce so v vhodni datoteki za analizo naslednje vrstice
                  {$$INV {2:4} {3:1} {4:1} {5:2} END}
                  LOCAL DOF 1
                  12 14 16 17 18 19 20 21
                  , bo vrednost 12 pripadala 4. parametru (in se skupaj z njim
                  spreminjala), vrednosti 14 in 16 1. parametru ter vrednost 18
                  2. parametru.
                    POZOR!
                  Vsi skladi morajo kazati na ze alociran spominski prostor!
                  Oznacevalni niz $$INV se mora drzati skupaj!
                  */
{
char searchout=1,searchin=1;
long openout,closeout,openin,closein,posout,posin,poscolumn,ll1,ll2,pos,start;
int buflength=1000;
int *dparamnum,*dlength,ii,jj,i,j,length,ret=0;
long *dplace;
double xx;
posout=1;
while (searchout)
{
  /* Iskanje znamenja, ki oznacuje pozicije */
  ll1=filestring(fp,"$$INV",posout,buflength);
  if (ll1>0)
    ll2=filestring(fp,"END",ll1,buflength);
  if (ll1<=0 || ll2<=0)
  {
    searchout=0;
  } else
  {
    /* Nasli smo oznacevalni niz, sedaj lahko zacnemo z iskanjem notranjih
    oklepajev, ki nam povedo pozicije parametrov v datoteki. */
    openout=ll1; closeout=ll2; searchin=1;
    posin=openout+1;
    posout=closeout+1;
    while (searchin)
    {
      filebracto(fp,'{','}',posin,closeout,100,&openin,&closein);
      if (openin<=0 || closein<=0)
      {
        searchin=0;
      } else
      {
        /* Nasli smo notranji oklepaj. Najprej povecamo stevec notranje
        pozicije, nato preberemo navodila v tem oklepaju in poiscemo ustrezni
        podatek */
        posin=closein+1;
        poscolumn=filecharto(fp,":",1,openin,closein,20);
        if (poscolumn>openin && poscolumn<closein)
        {
          /* Preberemo, kje se ustrezni podatek nahaja */
          fflush(fp);
          fseek(fp,openin,SEEK_SET);
          i=fscanf(fp,"%i",&ii);
          /* Preberemo, kateri parameter moramo povezati s tem podatkom */
          fflush(fp);
          fseek(fp,poscolumn,SEEK_SET);
          j=fscanf(fp,"%i",&jj);
          if (i>0 && j>0)
          {
            i=1;
            pos=closeout;
            while (i<=ii)
            {
              xx=filenum(fp,pos,100,&start,&length);
              if (start<0 || length<0)
                i=ii;
              else pos=start+length; /* Da se lahko isce naslednje stevilo */
              ++i;
            }
            if (start>0 && length>0)
            {
               /* Nasli smo niz v datoteki, ki predstavlja ustrezni podatek.
               Sedaj moramo ugotoviti uporabno dolzino tega niza ter podatke o
               poziciji, dolzini in o tem, s katerim parametrom je podatek
               povezan, spraviti na ustrezne sklade. */
               /* K dolzini niza, ki predstavlja podatek, se pristejejo se vsi
               presledki. */
               pos=filenotcharto(fp," ",1,pos,pos+100,20);
               if (pos>0)
                 pos-=2; /* En presledek do naslednjega podatka mora ostati */
               else
                 pos=start+length-1;
               length=(pos-start)+1;
               /* Ugotovljene vrednosti se spravijo na sklad: */
               dparamnum=calloc(1,sizeof(*dparamnum));
               dlength=calloc(1,sizeof(*dlength));
               dplace=calloc(1,sizeof(*dplace));
               *dparamnum=jj;
               *dlength=length;
               *dplace=start;
               pushstack(stparamnum,dparamnum);
               pushstack(stfileplace,dplace);
               pushstack(stlength,dlength);
			   ++ret;
             }
          }
        }
      }
    }
  }
}
fflush(fp);
return ret;
}



static void setinputparam(FILE *fp,struct _vector param,stack stfileplace,
                          stack stlength,stack stparamnum)
    /* V datoteki fp, ki mora biti vhodna datoteka za analizo, nastavi tiste
    vhodne parametre, ki se varirajo, na vrednosti, ki so zapisane v vektorju
    param. v skladih stfileplace, stlength in stparamnum je za vsak podatek v
    datoteki, ki ga je treba spremeniti, zapisano, kje v datoteki je njegov
    zacetek, kako dolg je in kateremu parametru po vrsti iz vektorja param
    pripada.
    $A Igor <== jan99; */
{
int maxlength=30;
int i,j,comp;
char *s;
size_t length;
s=makestring(maxlength);
if (fp!=NULL && stfileplace!=NULL && stlength!=NULL && stparamnum!=NULL
    && stfileplace->n>0 && stlength->n==stfileplace->n
    && stparamnum->n==stfileplace->n)
if (stfileplace->n>0) for (i=1; i<=stfileplace->n; ++i)
{
  comp= *( (int *) stparamnum->s[i] ); /* komponenta vektorja param */
  if (comp<=param.d && comp>0)
  {
    for (j=0;j<maxlength; ++j)
      s[j]=' ';
    sprintf(s,"%-*.*g",intfcoutchar,intfcoutdig,param.v[comp]);
    for (j=0;j<maxlength; ++j)
      if (s[j]=='\0')
        s[j]=' ';
    /* Ce v datoteko zapisemo znak \0, je na tistem mestu odrezana. */
    length=*((int *)stlength->s[i]);
    if ((int) length>maxlength)
      length=maxlength;
    filewrite(s,1,length,fp,*((long *)stfileplace->s[i]));
  }
}
free(s);
fflush(fp);
}





void setintfcinfile(FILE *fp)
     /* Postavi vhodno datoteko direktne analize */
{
fin=fp;
}



void setintfcstacks(void *fileplace,void *length,void *paramnum)
     /* Sklade, ki vsebujejo podatke o parametrih direktne analize v vhodni
     datoteki za direktno analizo, postavi na vrednosti, ki so navedene kot
     argumenti. V resnici je funkcija namenjena temu, da te sklade postavi na
     NULL. */
{
stfileplace=(stack) fileplace;
stlength=(stack) length;
stparamnum=(stack) paramnum;
}



void clearintfcstacks(void)
     /* Funkcija zbrise vse sklade, ki vsebujejo podatke o parametrih direktne
     analize v vhodni datoteki za direktno analizo, in jih postavi na NULL.
     Zbrise tudi vse podatke, ki so nalozeni na te sklade. */
{
if (stfileplace!=NULL)
{
  dispstackval(stfileplace);
  dispstack(&stfileplace);
}
if (stlength!=NULL)
{
  dispstackval(stlength);
  dispstack(&stlength);
}
if (stparamnum!=NULL)
{
  dispstackval(stparamnum);
  dispstack(&stparamnum);
}
setintfcstacks(NULL,NULL,NULL);
}






int intfcfindinputparam(void)
           /* V Ustrezne sklade zapise pozicije in dolzine parametrov, pri cemer
           uporablja funkcijo findinputparam(...). Datoteka, ki jo uporablja ta
           funkcija, je fin. */
{
/* Ce za sklade se ni alociran spomin, se to naredi sedaj: */
if (stfileplace==NULL)
  stfileplace=newstack(10);
if (stlength==NULL)
  stlength=newstack(10);
if (stparamnum==NULL)
  stparamnum=newstack(10);
return findinputparam(fin,stfileplace,stlength,stparamnum);
}


void intfcsetinputparam(struct _vector param)
            /* V datoteki fin postavi vhodne parametre za inverzno znalizo na
            vrednosti, ki so v vektorju param. Pri tem uporablja funkcijo
            setinputparam(...). */
{
setinputparam(fin,param,stfileplace,stlength,stparamnum);
}





void intfccheckincfield(char ch)
     /* Postavi spremenljivko checkincfield, ki je notranja spremenljivka
     vmesnika, na vrednost, ki jo ima ch. */
{
checkincfield=ch;
}








































































