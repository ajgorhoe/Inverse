/* CAS, DATUMI */

#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#ifdef ITK
 #include <itk.h>
#endif

#include <rf.h>

#ifdef MPI
 #include "mpi.h"
#endif



double stdabsolutetime(void)
    /* Returns the amount of time that has passed since a given moment
    in seconds by use of standard C functions. This function is used to
    synchronize other functions that return absolute time with the C
    definition of the absolute time.
    $A Igor jun03; */
{
time_t t;
t=time(NULL);
return difftime(t,0);
}




#ifdef MPI
  static double mpi_absolutetime(void)
      /* Auxiliary function that utilizes the MPI function for calculating
      absolute time.
      $A Igor jun03; */
  {
  static char difobtained=0;
  static double difference=0;
  double ret=0;
  /* Get absolute time from MPI; */
  ret=MPI_Wtime();
  if (!difobtained)
  {
    /* We equal MPI's absolute time with the standard library's one (within
    its accuricy of 1 second): */
    difference=stdabsolutetime();
    difference=ret-difference;
    difobtained=1;
  }
  ret-=difference;
  return ret;
  }
#endif


double absolutetime(void)
    /* Vrne preteceni cas od nekega dolocenega trenutka v sekundah.
    $A Igor sep97; */
{

return stdabsolutetime();

#if 0

#if defined(MPI)
  /*
  return MPI_Wtime();
  */
  return mpi_absolutetime();
#elif defined(ITK)
  return tcl_absolutetime();
#else
  return stdabsolutetime();
#endif

#endif
}


double cputime(void)
    /* Vrne porabljen CPU cas v sekundah od zacetka programa.
    $A Igor Avg98; */
{
return ((double) clock()) / ((double) CLOCKS_PER_SEC);
}


void fprinttime(FILE *fp)
    /* V datoteko fp zapise trenutni lokalni cas (datum in cas v dnevu) brez
    znaka za novo vrstico v berljivi obliki.
    $A Igor avg98; */
{
char *s;
time_t now;
s=malloc(100);
now=time(NULL);
strftime(s,100,"%A, %B %d %Y, %H:%M:%S",localtime(&now));
fprintf(fp,"%s",s);
free(s);
}


void printtime(void)
    /* Na standardni izhod zapise trenutni lokalni cas (datum in cas v dnevu)
    brez znaka za novo vrstico v berljivi obliki.
    $A Igor avg98; */
{
fprinttime(stdout);
}

void fprintdaytime(FILE *fp)
    /* V datoteko fp zapise trenutni lokalni cas v dnevu brez znaka za novo
    vrstico v berljivi obliki.
    $A Igor avg98; */
{
char *s;
time_t now;
s=malloc(100);
now=time(NULL);
strftime(s,100,"%H:%M:%S",localtime(&now));
fprintf(fp,"%s",s);
free(s);
}


void printdaytime(void)
    /* Na standardni izhod zapise trenutni lokalni cas v dnevu brez znaka za
    novo vrstico v berljivi obliki.
    $A Igor avg98; */
{
fprintdaytime(stdout);
}


void fprintdate(FILE *fp)
    /* V datoteko fp zapise trenutni datum brez znaka za novo vrstico v
    berljivi obliki.
    $A Igor avg98; */
{
char *s;
time_t now;
s=malloc(100);
now=time(NULL);
strftime(s,100,"%A, %B %d %Y",localtime(&now));
fprintf(fp,"%s",s);
free(s);
}


void printdate(void)
    /* Na standardni izhod zapise trenutni datum brez znaka za novo vrstico v
    berljivi obliki.
    $A Igor avg98; */
{
fprintdate(stdout);
}


char laterdate(int day,int month,int year)
    /* Vrne 1, ce je trenutni datum po lokalnem casu poznejsi od datuma (day,
    month,year).
    $A Igor avg98;  */
{
char ret=0;
time_t now;
int d,m,y;
struct tm *tp;
now=time(NULL);
tp=localtime(&now);
d=tp->tm_mday;  m=tp->tm_mon;  y=tp->tm_year;
++m;  /* Ker se mesec steje od 0. */
/* Ker se v strukturo namesto letnice zapise letnica brez 1900: */
if (y<1000)
{
if (y<=80)
  y+=2000;
else
  y+=1900;
}
if (y>year)
  ret=1;
else if (y==year)
{
  if (m>month)
    ret=1;
  else if (m==month)
  {
    if (d>day)
      ret=1;
  }
}
return ret;
}


char laterdate0(int day,int month,int year)
    /* Vrne 1, ce je trenutni datum po lokalnem casu poznejsi od datuma (day,
    month,year). Za razliko od laterdate() ta funkcija uporablja vec orodij,
    ki so v standardnih knjiznicah za C.
    $A Igor avg98; */
{
char ret=0;
time_t now,date;
struct tm *tp;
now=time(NULL);
tp=localtime(&now);
tp->tm_mday=day;  tp->tm_mon=month-1;   /* ker se mesec v letu steje od 0 */
/* Paziti je treba, ce se letnice na strukturi po dogovoru stejejo od 1900
naprej: */
if (tp->tm_year<1000)
  tp->tm_year=year-1900;
else
  tp->tm_year=year;
date=mktime(tp);
if (now>date)
  ret=1;
return ret;
}


int dateshift(int day,int month,int year)
    /* Vrne stevilo dni razlike med datumom dolocenim z (day,month,year) in
    trenutnim datumom. Ce je ta datum pred trenutnim datumom, je razlika
    negativna, ce pa se ujema s trenutnim datumom, je razlika 0. Pri klicu
    mora biti year polna, ne dvomestna letnica.
     POZOR!
     Razlika se na nekaterih sistemom ne racuna pravilno, ce je datum prejsnji
    ali poznejsi od dolocenega datuma (to je lastnost standardnih funkcij, ki
    so uporabljene v tej funkciji).
    $A avg98; */
{
time_t now,date;
struct tm *tp;
now=time(NULL);
tp=localtime(&now);  /* da se lahko preveri, kako se stejejo leta */
tp->tm_mday=day;  tp->tm_mon=month-1;   /* ker se mesec v letu steje od 0 */
/* Paziti je treba, ce se letnice na strukturi po dogovoru stejejo od 1900
naprej: */
if (tp->tm_year<1000)  /* Leta se stejejo od 1900 naprej */
  /*  $$
  */
  tp->tm_year=year-1900;
else
  tp->tm_year=year;
date=mktime(tp);
return (int) round(difftime(date,now)/86400/* st. sekund v dnevu */);
}


void calcdate(int dayshift,int *day,int *month,int *year)
    /* Izracuna datum, ki je pomaknjen za dayshift dni od trenutnega datuma.
    Ce je dayshift negativen, vrne datum starejsi od trenutnega. Datum zapise
    v day,month in year (letnice so polne, ne dvomestne).
     POZOR!
     Datum se na nekaterih sistemom ne racuna pravilno, ce je datum prejsnji
    ali poznejsi od dolocenega datuma (to je lastnost standardnih funkcij, ki
    so uporabljene v tej funkciji).
    $A Igor avg98; */
{
char twodigityear=0;
time_t now;
struct tm *tp;
now=time(NULL);
tp=localtime(&now);
if (tp->tm_year<1000)
  twodigityear=1; /* letu je treba dodati 1900 */
tp->tm_mday+=dayshift;
mktime(tp); /* izracun zamaknjenega datume */
*day=tp->tm_mday;  *month=tp->tm_mon+1;  *year=tp->tm_year;
if (twodigityear)
  *year+=1900;
}



void currentdate(int *day,int *month,int *year)
    /* Trenutni datum zapise v *day, *month in *year;
    $A Igor avg98; */
{
calcdate(0,day,month,year);
}


char *numbertomonth0(int month,int mode)
    /* Pretvori stevilko meseca (month) v niz, ki pripada temu mesecu, in ga
    vrne. Mode doloca nacin pretvorbe in sicer:
     0: Oct
     1: October
     10: okt.
     11: oktober
     $A Igor nov99; */
{
if (month<0 || month>12)
  return "XXX";
switch (month)
{
  case 1:
    switch(mode)
    {
      case 0:
        return "Jan";
      case 1:
        return "January";
      case 10:
        return "jan.";
      case 11:
        return "januar";
      default:
        return "Jan";
    }
  case 2:
    switch(mode)
    {
      case 0:
        return "Feb";
      case 1:
        return "February";
      case 10:
        return "feb.";
      case 11:
        return "februar";
      default:
        return "Feb";
    }
  case 3:
    switch(mode)
    {
      case 0:
        return "Mar";
      case 1:
        return "March";
      case 10:
        return "mar.";
      case 11:
        return "marec";
      default:
        return "Mar";
    }
  case 4:
    switch(mode)
    {
      case 0:
        return "Apr";
      case 1:
        return "April";
      case 10:
        return "apr.";
      case 11:
        return "april";
      default:
        return "Apr";
    }
  case 5:
    switch(mode)
    {
      case 0:
        return "May";
      case 1:
        return "May";
      case 10:
        return "maj.";
      case 11:
        return "maj";
      default:
        return "May";
    }
  case 6:
    switch(mode)
    {
      case 0:
        return "Jun";
      case 1:
        return "June";
      case 10:
        return "jun.";
      case 11:
        return "junij";
      default:
        return "Jun";
    }
  case 7:
    switch(mode)
    {
      case 0:
        return "Jul";
      case 1:
        return "July";
      case 10:
        return "jul.";
      case 11:
        return "julij";
      default:
        return "Jul.";
    }
  case 8:
    switch(mode)
    {
      case 0:
        return "Aug";
      case 1:
        return "August";
      case 10:
        return "avg.";
      case 11:
        return "avgust";
      default:
        return "Avg";
    }
  case 9:
    switch(mode)
    {
      case 0:
        return "Sep";
      case 1:
        return "September";
      case 10:
        return "sep.";
      case 11:
        return "september";
      default:
        return "Sep";
    }
  case 10:
    switch(mode)
    {
      case 0:
        return "Oct";
      case 1:
        return "October";
      case 10:
        return "okt.";
      case 11:
        return "oktober";
      default:
        return "Oct";
    }
  case 11:
    switch(mode)
    {
      case 0:
        return "Nov";
      case 1:
        return "November";
      case 10:
        return "nov.";
      case 11:
        return "november";
      default:
        return "Nov";
    }
  case 12:
    switch(mode)
    {
      case 0:
        return "Dec";
      case 1:
        return "December";
      case 10:
        return "dec.";
      case 11:
        return "december";
      default:
        return "Dec";
    }
}
return NULL;
}


/*

main ()
{
printf("Lokalni cas: ");
printtime();
printf(".\n\n");

printf("Lokalni cas v dnevu: ");
printdaytime();
printf(".\n\n");

printf("Datum: ");
printdate();
printf(".\n\n");

if (laterdate(25,8,1998))
  printf("Datum (25,8,1998) je poznejsi od danasnjega.\n");
else
  printf("Datum (25,8,1998) ni poznejsi od danasnjega.\n");

if (laterdate(24,8,1998))
  printf("Datum (24,8,1998) je poznejsi od danasnjega.\n");
else
  printf("Datum (24,8,1998) ni poznejsi od danasnjega.\n");

if (laterdate(28,7,1998))
  printf("Datum (28,7,1998) je poznejsi od danasnjega.\n");
else
  printf("Datum (28,7,1998) ni poznejsi od danasnjega.\n");

if (laterdate(27,8,1998))
  printf("Datum (27,8,1998) je poznejsi od danasnjega.\n");
else
  printf("Datum (27,8,1998) ni poznejsi od danasnjega.\n");

if (laterdate(2,1,2005))
  printf("Datum (2,1,2005) je poznejsi od danasnjega.\n");
else
  printf("Datum (2,1,2005) ni poznejsi od danasnjega.\n");



printf("\n");
if (laterdate0(25,8,1998))
  printf("Datum (25,8,1998) je poznejsi od danasnjega.\n");
else
  printf("Datum (25,8,1998) ni poznejsi od danasnjega.\n");

if (laterdate0(24,8,1998))
  printf("Datum (24,8,1998) je poznejsi od danasnjega.\n");
else
  printf("Datum (24,8,1998) ni poznejsi od danasnjega.\n");

if (laterdate0(28,7,1998))
  printf("Datum (28,7,1998) je poznejsi od danasnjega.\n");
else
  printf("Datum (28,7,1998) ni poznejsi od danasnjega.\n");

if (laterdate0(27,8,1998))
  printf("Datum (27,8,1998) je poznejsi od danasnjega.\n");
else
  printf("Datum (27,8,1998) ni poznejsi od danasnjega.\n");

if (laterdate0(2,1,2005))
  printf("Datum (2,1,2005) je poznejsi od danasnjega.\n");
else
  printf("Datum (2,1,2005) ni poznejsi od danasnjega.\n");


if (1)
{
  int shift=1,day=1,month=1,year=1;
  while(year>0)
  {
    printf("\nInsert a date!\n");
    printf("day: ");   scanf("%i",&day);
    printf("month: "); scanf("%i",&month);
    printf("yar:   "); scanf("%i",&year);
    printf("Difference betweeen %i. %i. %i and now is %i days.\n",
           day,month,year,dateshift(day,month,year));
  }
  shift=1;
  while(shift!=0)
  {
    printf("\nInsert number of days from today!\n");
    printf("day: ");   scanf("%i",&shift);
    calcdate(shift,&day,&month,&year);
    printf("Today's date shifted for %i days is %i. %i. %i.\n",shift,day,month,year);
  }
}


}


*/
