/* Switch on tracing:
#define EXTRACE
*/

      /*************************************/
      /*                                   */ 
      /*   SGS:                            */
      /*   BASIS FOR PLOTTING INTERFACES   */
      /*                                   */ 
      /*************************************/



#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <math.h>

#include <sysint.h>

#include <strop.h>
#include <rf.h>
#include <st.h>
#include <er.h>
#include <mtime.h>
#include <rand.h>
#include <itk.h>

#include <sg_obj.h>
#include <sg_ploto.h>
#include <sg_intfc.h>

#include <sg_draw.h>





    /* GENERAL SETTINGS (used across plotting interfaces) */

int sg_interfaceid=0;          /* Active plotting interface ID */
char * sg_interfacename=NULL;  /* Name of the active interface */
int sg_interfaceflag=0;  /* Name of the active interface */

/* Window handling options: */
char *sg_windowtitle=NULL;
int sg_MAXX=1280,sg_MAXY=1024;  /* Screen width and height */
/* Window positioning and size: */
float sg_windowxpos=-1,sg_windowypos=-1,
             sg_windowwidth=0.3f,sg_windowheight=0.3f;
int sg_iwindowxpos=-1,sg_iwindowypos=-1,
             sg_iwindowwidth=500,sg_iwindowheight=500;


char sg_coloring=1; /* Whether color or grayscale plotting is used */
int sg_numshades=256; /* Number of discrete accessible shades for color comp. */
int sg_numdiscretecolors=0;
int sg_indexsize=0; /* Size of color index tables */
int sg_numindices=0;
char sg_preindexall=0; /* If 1, all possible pixel colors are allocated
            at the initialization. */

/* Color settings: */
_truecolor sg_linecolor = {0.1f,0.1f,0.3f},
                  sg_fillcolor = {0.8f,0.8f,0.1f},
                  sg_textcolor = {0.8f,0.2f,0.1f};


/* Line, text and oter settings: */
int sg_ilinewidth=1;
double sg_linewidth=0.01;
int sg_linetype=1;

int sg_textxalignment=0,sg_textyalignment=0;

float sg_textheight=0.02f;
int sg_itextheight=8;


/* Options for drawing points and curved object such as circle arcs: */
float sg_pointsize=0.01f;
int sg_curvepoints=30,
    sg_markercurvepoints=10;


/* FONT and WINDOW stacks:
Each window belongs to a particular plotting interface. Fonts are valid for
all plotting interface, so each font has a stack on which for each plotting
interface there is an object (possibly NULL) that contains interface -
specific data (these objects are handled locally by plotting interfaces). */
stack sg_fonts=NULL,
      sg_windows=NULL;

static stack sg_dispwinst=NULL,  /* Functions for cleaning the interface specific
                            font data */
      sg_dispfontst=NULL; /* Functions for cleaning the interface specific
                            window data */

int sg_currentfont=0;   /* Current font used */
int sg_currentwindow=0; /* Current window */




    /* AUXILIARY FUNCTIONS: */


  /* GENERAL AUXILIARY FUNCTIONS: */

int sg_screeninterface(int intfc)
    /* Returns 1 if the interface denoted by intfc is a screen interface and 0
    if not (e.g. it is a file plotting interface).
    $A Igor mar04; */
{
switch(intfc)
{
  case SG_PLOT_ITK: case SG_PLOT_X:
    return 1;
  default: 
    return 0;
}
}


  /* CALCULATING COLOR SCALES: */


_truecolor sg_colorscalerainbow(double factor)
    /* Scale to color conversion that approximately corresponds to a rainbow.
    $A Igor oct03; */
{
_truecolor color;
double trimfactor=0.2; /* may be at most 0.25 */
if (factor<0.0)
  factor=0.0;
else if (factor>1.0)
  factor=1.0;
if (factor<=0.5)
{
  color.red=0;
  if (factor<=trimfactor)
    color.blue=1;
  else
    color.blue=(float) ((0.5-factor)/(0.5-trimfactor));
  if (factor>=0.5-0.5*trimfactor)
    color.green=1.0f;
  else
    color.green=(float) (factor/(0.5-0.5*trimfactor));
} else
{
  color.blue=0;
  if (factor<0.5+0.5*trimfactor)
    color.green=1.0f;
  else
    color.green=(float) ((1.0-factor)/(0.5-0.5*trimfactor));
  if (factor>=1.0-trimfactor)
    color.red=1.0f;
  else
    color.red=(float) ((factor-0.5)/(0.5-trimfactor));
}
return color;
}


_truecolor sg_colorscalerainbow0(double factor)
    /* Scale to color conversion that approximately corresponds to a rainbow.
    $A Igor oct03; */
{
_truecolor color;
double sigma=0.3;
color.blue=(float) exp(-factor*factor/(2*sigma*sigma));
color.green=(float) exp(-(factor-0.5)*(factor-0.5)/(2*sigma*sigma));
color.red=(float) exp(-(factor-1.0)*(factor-1.0)/(2*sigma*sigma));
return color;
}

_truecolor sg_colorscalerainbowlight(double factor)
    /* Light variant of sg_colorscalerainbow(), a combination of a 0.5 white and
    0.5 of what sg_colorscalerainbow() returns.
    $A Igor oct03; */
{
_truecolor color;
color=sg_colorscalerainbow(factor);
color.red=0.5f+0.5f*color.red;
color.green=0.5f+0.5f*color.green;
color.blue=0.5f+0.5f*color.blue;
return color;
}


_truecolor sg_colorscalebas(double factor)
    /* Scale to color conversion that is suitable for contour plots. Factor
    must be in range [0,1], otherwise it is set to 0 or 1, respectively.
      The grey level of the returned color equals 1/3 for all values of
    factor while the maximum possible component is 1. Factor 0 corresponds to
    pure blue - RGB color (1,0,0), factor 0.5 corresponds to pure green (0,1,0)
    and factor 1 corresponds to pure red (1,0,0).
    $A Igor oct03; */
{
_truecolor color;
if (factor<0.0)
  factor=0.0;
else if (factor>1.0)
  factor=1.0;
if (factor<=0.5)
{
  color.red=0;
  color.blue=(float) (2.0*(0.5-factor));
  color.green=(float) (2.0*factor);
} else
{
  color.blue=0;
  color.green=(float) (2.0*(1.0-factor));
  color.red=(float) (2.0*(factor-0.5));
}
return color;
}


_truecolor sg_colorscalebaslight(double factor)
    /* Light variant of sg_colorscalebas(), a combination of a 0.5 white and
    0.5 of what sg_colorscalebas() returns.
    $A Igor oct03; */
{
_truecolor color;
color=sg_colorscalebas(factor);
color.red=0.5f+0.5f*color.red;
color.green=0.5f+0.5f*color.green;
color.blue=0.5f+0.5f*color.blue;
return color;
}


_truecolor sg_colorscalecomp(double factor)
    /* Returns the color that is complementary to those returned by
    sg_colorscalebas, i.e. each color component is obtained as 1 minus the
    corresponding component returned by sg_colorscalebas(). The grey level of
    the produced colors is therefore 2/3 for all values of factor and the
    maximum possible component is 1.
    $A Igor oct03; */
{
_truecolor color;
color=sg_colorscalebas(factor);
color.red=1.0f-color.red;
color.green=1.0f-color.green;
color.blue=1.0f-color.blue;
return color;
}

_truecolor sg_colorscalecomplight(double factor)
    /* Light variant of sg_colorscalecomp(), a combination of a 0.4 white and
    0.6 of what sg_colorscalecomp() returns.
    $A Igor oct03; */
{
_truecolor color;
color=sg_colorscalecomp(factor);
color.red=0.4f+0.6f*color.red;
color.green=0.4f+0.6f*color.green;
color.blue=0.4f+0.6f*color.blue;
return color;
}


_truecolor sg_colorscalemix(double factor)
    /* Returns a color dependent on factor that is a proportional mixture of 
    what is obtained by sg_colorscalebas() and inverse of what is obtained by
    g_colorscalecomp() (i.e. what is obtained by g_colorscalecomp(1-factor)).
    The grey level of the returned colors therefore equals 1/2 and the maximum
    possible component is 1.
    $A Igor oct03; */
{
_truecolor color1,color2;
color1=sg_colorscalebas(factor);
color2=sg_colorscalecomp(1-factor);
color1.red=0.5f*(color1.red+color2.red);
color1.green=0.5f*(color1.green+color2.green);
color1.blue=0.5f*(color1.blue+color2.blue);
return color1;
}

_truecolor sg_colorscalemixlight(double factor)
    /* Light variant of sg_colorscalemixinv(), a combination of a 0.5 white and
    0.5 of what sg_colorscalemix() returns.
    $A Igor oct03; */
{
_truecolor color;
color=sg_colorscalemix(factor);
color.red=0.5f+0.5f*color.red;
color.green=0.5f+0.5f*color.green;
color.blue=0.5f+0.5f*color.blue;
return color;
}



  /* WINDOW AND FONT AUXILIARY FUNCTIONS: */

void sg_register_dispwin(void (*dispwindowdata) (void **))
    /* Installs the function for deletion of the interface specific window
    data on the structures of type sg_window. Argument may be NULL. This
    function should be called in the function for the activation of the
    plotting interface.
    $A Igor sep03; */
{
char *ptr=NULL;
void (*func)(void **)=NULL;
if (sg_dispwinst==NULL)
  sg_dispwinst=newstack(5);
setstack(sg_dispwinst,dispwindowdata,sg_interfaceid);
func=sg_dispwinst->s[sg_interfaceid];
if (dispwindowdata!=NULL)
  func((void **) &ptr);
}

void sg_register_dispfont(void (*dispfontdata) (void **))
    /* Installs the function for deletion of the interface specific font
    data on the structures of type sg_font. Argument can be NULL. This
    function should be called in the function for the activation of the
    plotting interface.
    $A Igor sep03; */
{
if (sg_dispfontst==NULL)
  sg_dispfontst=newstack(5);
setstack(sg_dispfontst,dispfontdata,sg_interfaceid);
}



sg_window newsg_window(void)
    /* Creates a new window structure and marks the current plotting interface
    (which created the window) on it, so that the function for deleting the
    interface specific data can be located later when the structure is deleted.
    Returns the pointer to the structure.
    $A Igo sep03; */
{
sg_window w;
static int serial=0;
w=malloc(sizeof(*w));
memset(w,0,sizeof(*w));
w->serial=(++serial);
w->intfc=sg_interfaceid;   /* Mark the interface that created the window */
return w;
}

void dispsg_window(sg_window *addr)
    /* Deallocates all the window data contained in **addr and sets *addr to 
    NULL;
    $A Igor sep03; */
{
sg_window w;
void (*dispintfcdata) (void **) = NULL;
if (addr!=NULL)
{
  w=*addr;
  if (w->intfcdata!=NULL && w->intfc>0 && sg_dispwinst!=NULL);
  {
    /* Clean the interface specific data, first get the function: */
    dispintfcdata=stackel(sg_dispwinst,w->intfc);
    if (dispintfcdata!=NULL)
      dispintfcdata(&(w->intfcdata));
  }
  /* Clean other data: */
  disppointer((void **) &(w->title));
  /* Free the struct. itself, set *addr to NULL: */
  free(w);
  *addr=NULL;
}
}


/* Data for storing the interface ID and pointer to interface specific data
(e.g. font data): */
typedef struct {
  int id;
  void *data;
} _intfcdata;
typedef _intfcdata *intfcdata;



sg_font newsg_font(void)
    /* Creates a new font structure ans returns a pointer to this structure.
    $A igor sep03; */
{
sg_font f;
static int serial=0;
f=malloc(sizeof(*f));
memset(f,0,sizeof(*f));
f->serial=(++serial);
f->intfcst=newstack(2);   /* stack containing interface specific data */
return f;
}

void dispsg_font(sg_font *addr)
    /* Deallocates all the font data contained in **addr and sets *addr to 
    NULL;
    $A Igor sep03; */
{
sg_font f;
intfcdata data;
void (*dispintfcdata) (void **) = NULL;
if (addr!=NULL)
{
  f=*addr;
  /* Clean the interface specific data: */
  if (f->intfcst!=NULL)
  {
    while (f->intfcst->n>0)
    {
      data=popstack(f->intfcst);
      if (data!=NULL)
      {
        if (sg_dispfontst!=NULL)
          dispintfcdata=stackel(sg_dispfontst,data->id);
        else
          dispintfcdata=NULL;
        if (dispintfcdata!=NULL)
          dispintfcdata(&(data->data));
        free(data);
      }
    }
    dispstack(&(f->intfcst));
  }
  /* Clean other data: */
  disppointer((void **) &(f->family));
  /* Free the struct. itself, set *addr to NULL: */
  free(f);
  *addr=NULL;
}
}


void **sg_fontdataaddr(sg_font font)
    /* Returns the address of the interface specific data for the currently
    active plotting interface
    identified by id on the SGS font structure font. If there is no data for
    the plotting interface identified by id on font, then the data entry is
    created anew and the address of the pointer which will point to the
    interface specific data is returned (the pointer itself is NULL in this
    case).
      Function returns NULL only if font is NULL or if the active plotting
    interface is not defined.
    $A Igor sep03; */
{
stack st;
intfcdata data=NULL;
int place=0,i,interface_id;
interface_id=sg_interfaceid;
if (interface_id<0)
  return NULL;
if (font==NULL)
  return NULL;
else
{
  if ((st=font->intfcst)==NULL)
    st=font->intfcst=newstack(2);
  else
  {
    /* Find the data for a given interface on the stack: */
    i=1;
    while(i<=st->n && place==0)
    {
      data=st->s[i];
      if (data->id==interface_id)
        place=i;
      else
        ++i;
    }
    if (place==0)
    {
      /* Data for specific interface is not yet on the structure, allocate new
      entry: */
      data=malloc(sizeof(*data));
      data->id=interface_id;
      data->data=NULL;
      pushstack(st,data);
      place=st->n;
    }
  }
}
if (data==NULL)
  return NULL;
else
  return &(data->data);
}




/* BASIC DRAWING FUNCTIONS */

/* Auxiliary function that enable error reporting when no drawing context has
been installed but drawing functions are called: */

static void sg_reportnographicinterface(char *funcname)
{
static int count=0,next=1;
++count;
if (count>=next)
{
  next*=10;
  errfunc0(funcname);
  sprintf(ers(),"There is no drawing interface or it has not been initialized.\n");
  sprintf(ers(),"Possible reasons for this error are the following:\n");
  sprintf(ers(),"  - The source code or the library you use has not been linked with one of\n");
  sprintf(ers(),"the libraries that can be used by the SGS system for drawing.\n");
  sprintf(ers(),"  - No initialization functions have been called to tell which graphic\n");
  sprintf(ers(),"interface should be used by SGS.\n");
  sprintf(ers(),"WARNING:\nNext %i messages of this kind that might appear will be suppresed.\n",
    next-count-1);
  if (count>1)
    sprintf(ers(),"This is occurence No. %i of the situation.\n",count);
  err2();
}
}


static int actbasint(void)
    /* Tries to activate the basic plotting interface. It returns 1 if it is
    successful and 0 otherwise (in this case the warning message is also
    launched). If there is already some other interface than SG_PLOT_DEFAULT
    active, then the function just returns 0 and does not launch an error.
    This enables some function of the interface SG_PLOT_DEFAULT to be programmed
    in such a way that they can be caled by functions of true interfaces, see
    e.g. the sg_installfont_default!
    $A Igor sep03; */
{
static int trials=0;
if (sg_interfaceid!=SG_PLOT_DEFAULT && sg_interfaceid>0)
  return 0;
if (trials>0) /* report failure if already tried */
  return 0;
++trials;
sg_interface(SG_PLOT_BASIC);  /* try to activate the basic interface */
/* Check the success by checking the address of the function for opening a
window; If the address is that of the sg_openwindow_default() (which does
nothing and is initial value for this function) then it was not successful: */
if (sg_openwindow!=sg_openwindow_default)
{
  warnfunc1(1,"actbasint");
  sprintf(ers(),"Loading the basic SGS plotting interface because no working interface\n");
  sprintf(ers(),"was active.\n");
  warnfunc2();
  return 1;
}
return 0;
}





static void sgcalccolor(float red,float green, float blue,truecolor col)
    /* Calculates the color that is actually used to represent the color
    composed of RGB shades red, green and blue with respect to current color
    handling parameters, and writes the color to col.
    $A Igor sep03; */
{
float c1;
if (!sg_coloring)
{
  /* Plotting in grey scale */
  c1=(red+green+blue)/3.0f;
  /* Force colors within the limits: */
  if (c1<0)
    c1=0.0;
  else if (c1>1.0)
    c1=1;
  if (sg_numshades>0 && sg_numshades<256)
  {
    /* Discretize colors: */
    c1=(float) round((double) c1 * ((double) sg_numshades-0.8))/
      ((float) sg_numshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (c1>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Grey level was set to %g>1 after discretization.\n",
        c1);
      errfunc2();
      c1=(float) 1;
    }
  }
  red=green=blue=c1;
} else
{
  /* Coloring; Force limits: */
  if (red<0.0) red=0.0; else if (red>1.0) red=1.0;
  if (green<0.0) green=0.0; else if (green>1.0) green=1.0;
  if (blue<0.0) blue=0.0; else if (blue>1.0) blue=1.0;
  if (sg_numshades>0 && sg_numshades<256)
  {
    /* Discretize colors: */
    red=(float) round((double) red * ((double) sg_numshades-0.8))/
      ((float) sg_numshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (red>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Red color component set to %g>1 after discretization.\n",
        red);
      errfunc2();
      red=(float) 1;
    }
    green=(float) round((double) green * ((double) sg_numshades-0.8))/
      ((float) sg_numshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (green>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Green color component set to %g>1 after discretization.\n",
        green);
      errfunc2();
      green=(float) 1;
    }
    green=(float) round((double) green * ((double) sg_numshades-0.8))/
      ((float) sg_numshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (green>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Red color component set to %g>1 after discretization.\n",
        green);
      errfunc2();
      green=(float) 1;
    }
  }
}
col->red=red;
col->green=green;
col->blue=blue;
}






    /* WINDOW (and graphic context) HNADLING: */



int sg_openwindow_default(void)
    /* Creates a new window structure and puts it to the stack sg_windows,
    returns the place of the structure on the stack. This function can be
    called by functions for opening a window in true interfaces to perform the
    task of data initialisation. This is because it is programmed in such a way
    that does not try to activate the basic interface or report an error if 
    some interface other than SG_PLOT_DEFAULT is already active (see also
    actbasint()).
    $A Igor sep09; */
{
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  return sg_openwindow();
} else
{
  sg_window wn=NULL;
  int place=0,i=1;
  if (sg_interfaceid==SG_PLOT_DEFAULT)
    /* don't launch warning if called from a true interface: */
    sg_reportnographicinterface("sg_openwindow_default");
  wn=newsg_window();
  sg_initintbas();
  if (sg_windows==NULL)
    sg_windows=newstack(5);
  while (i<=sg_windows->n && place==0)
  {
    if (sg_windows->s[i]==NULL)
      place=i;
    ++i;
  }
  if (place>0)
    sg_windows->s[place]=wn;
  else
  {
    pushstack (sg_windows,wn);
    place=sg_windows->n;
  }
  wn->id=place;
  return wn->id;
}
return 0;
}
int (*sg_openwindow) (void) = sg_openwindow_default;


int sg_setwindow_default(int id) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  return sg_setwindow(id);
} else
  sg_reportnographicinterface("sg_setwindow");
return 0;
}
int (*sg_setwindow) (int id) = sg_setwindow_default;

void sg_clearwindow_default(void) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_clearwindow();
  return ;
} else
  sg_reportnographicinterface("sg_clearwindow");
}
void (*sg_clearwindow) (void) = sg_clearwindow_default;

void  sg_resetwindow_default(void) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_resetwindow();
  return ;
} else
  sg_reportnographicinterface("sg_resetwindow");
}
void (*sg_resetwindow) (void) = sg_resetwindow_default;


void sg_closewindow_default(void) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_closewindow();
  return;
} else
  sg_reportnographicinterface("sg_closewindow");
}
void (*sg_closewindow) (void) = sg_closewindow_default;


void sg_raisewindow_default(void) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_raisewindow();
  return;
} else
  sg_reportnographicinterface("sg_raisewindow");
}
void (*sg_raisewindow) (void) = sg_raisewindow_default;


int sg_installfont_default(char *family,char bold,char italic,char underline,
                           char overstrike)
    /* Creates a new font structure and puts it to the fonts stack, returns
    the place of the structure on the stack. This function can be called by
    functions for installation of font for true interfaces to perform the task
    of data initialisation. This is because it is programmed in such a way that
    does not try to activate the basic interface or report an error if  some
    interface other than SG_PLOT_DEFAULT is already active (see also actbasint()).
    $A Igor sep03; */
{
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  return sg_installfont(family,bold,italic,underline,overstrike);
} else
{
  sg_font ft=NULL;
  int place=0;
  if (sg_interfaceid==SG_PLOT_DEFAULT)
    /* don't launc warning if called from a true interface: */
    sg_reportnographicinterface("sg_installfont");
  ft=newsg_font();
  ft->family=stringcopy(family);
  ft->bold=bold;
  ft->italic=italic;
  ft->underline=underline;
  ft->overstrike=overstrike;
  if (sg_fonts==NULL)
    sg_initintbas();  /* This will initialize the font stack */
  /* Remark: the following can change in the future in such a way that NULL
  entries on the stack can be re-used. */
  pushstack(sg_fonts,ft);
  ft->id=sg_fonts->n;
  return ft->id;
}
return 0;
}
int (*sg_installfont) (char *family,char bold,char italic,char underline,
                           char overstrike) = sg_installfont_default;


void sg_installfontstr_default(int id,char *spec)
    /* THIS FUNCTION IS A TEMPORARY SOLUTION AND SHOULD BE EXCLUDED BY
    NOVEMBER 2003. */
{
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_installfontstr(id,spec);
  return ;
} else
  sg_reportnographicinterface("sg_installfontstr");
}
void (*sg_installfontstr) (int, char *) = sg_installfontstr_default;




void sg_setcoloring_default(int yes)
    /* If yes is 0, then graphics will be plotted in grey, otherwise in colors.
    $A Igor sep03; */
{
if (yes)
  sg_coloring=1;
else
  sg_coloring=0;
}
void (*sg_setcoloring) (int yes) = sg_setcoloring_default;


void sg_setnumshades_default(int num)
    /* Sets the number of shades for each color component to num (or the number
    of gray scales if coloring is switched off). If num is 0, the colors are
    contiguous, in this case also indexing can not be used on the systems where
    it can otherwise be enabled.
    $A Igor sep03; */
{
if (num<0)
  num=0;
if (num==1) /* Must be at least 2!!! */
  num=2;
if (num>1024)
  num=1024;
sg_numshades=num;
}
void (*sg_setnumshades) (int num) = sg_setnumshades_default;


void sg_colortabsize_default(int size)
    /* Sets the size of the table that stores indices of already allocated
    collor cells, to size. If size is 0, indexing is not used, which means that
    for use of any color the graphic underlying library is instructed to
    allocate the appropriate color cell, regardless of whether the color has
    been used before.
    With ITK, this does not have any effect (but does e.g. with Xlib)
    $A Igor sep03; */
{
if (size<0)
  size=0;
sg_indexsize=size;
}
void (*sg_colortabsize) (int size) = sg_colortabsize_default;


void sg_preindexcolors_default(int yes)
    /* If yes is 0, then the requests for allocation of colors are sent to the
    library each time. If it is 1, then colors are allocated in advance at the
    initialization of the screen, if the table of indices is large enough.
      This function has no effect with ITK, but does w.g. with Xlib.
    $A Igor sep03; */
{
if (yes)
  sg_preindexall=1;
else
  sg_preindexall=0;
}
void (*sg_preindexcolors) (int yes) = sg_preindexcolors_default;


void sg_setwindowtitle_default(char *title)
    /* Sets the window title for windows that will be open anew. If title is
    NULL, then the SGS chooses its own title when opening new toplevel
    windows, which distinguishes the SGS graphics windows from the others and
    also indicates the number of the window (recommended unless this would
    affect the look of the application in an undesired way, useful for
    debugging).
      The SGS makes a dynamic copy of the string title. Therefore, if a
    dynamically allocated string is passed as an argument, it can be
    deallocated after the function call.
    $A Igor sep03; */
{
if (sg_windowtitle!=NULL)
  free(sg_windowtitle);
sg_windowtitle=stringcopy(title);
}
void (*sg_setwindowtitle) (char *title) = sg_setwindowtitle_default;


char *sg_getwindowtitle_default(void)
    /* Returns the current window title as has been set by the user. A pointer
    to the title is returned, therefore it may not be allocated or modified by
    the user.
      Warning:
    This function must be used with care when graphics is used by multiple
    threads.
    $A Igor sep03; */
{
return sg_windowtitle;
}
char * (*sg_getwindowtitle) (void) = sg_getwindowtitle_default;


float sg_setwindowxpos_default(float z)
    /* Sets the initial position of windows (upper left corner) at opening in
    the x direction to z where z is relative to screen width with the
    range from 0 to 1. If z is out of range (e.g. negative), the underlying
    graphic library will chose the window position position.
      The previous position is returned.
    $A Igor sep03; */
{
float ret;
ret=sg_windowxpos;
if (z>=0 && z<=1)
{
  sg_windowxpos=z;
  sg_iwindowxpos=1+(int) (z*(sg_MAXX-1));
} else
{
  sg_iwindowxpos=(int) z;
  sg_windowxpos=(float) sg_iwindowxpos/(float) sg_MAXX;
}
return ret;
}
float (*sg_setwindowxpos) (float z) = sg_setwindowxpos_default;


float sg_getwindowxpos_default(void)
    /* return the current position for opening new windows in the x direction
    relative to the screen width. Negative value means that the system chooses
    the position.
    $A Igor sep03; */
{
return sg_windowxpos;
}
float (*sg_getwindowxpos) (void) = sg_getwindowxpos_default;


float sg_setwindowypos_default(float z)
    /* Sets the initial position of windows (upper left corner) at opening in
    the y direction to z where z is relative to screen height with the
    range from 0 to 1. If z is out of range (e.g. negative), the underlying
    graphic library will chose the window position position.
    $A Igor sep03; */
{
float ret;
ret=sg_windowypos;
if (z>=0 && z<=1)
{
  sg_windowypos=z;
  sg_iwindowypos=1+(int) (z*(sg_MAXY-1));
} else
{
  sg_iwindowypos=(int) z;
  sg_windowypos=(float) sg_iwindowxpos/(float) sg_MAXY;

}
return ret;
}
float (*sg_setwindowypos) (float z) = sg_setwindowypos_default;


float sg_getwindowypos_default(void)
    /* return the current position for opening new windows in the x direction
    relative to the screen width. Negative value means that the system chooses
    the position.
    $A Igor sep03; */
{
return sg_windowypos;
}
float (*sg_getwindowypos) (void) = sg_getwindowypos_default;


float sg_setwindowwidth_default(float z)
    /* Sets the initial width of windows when they are open to z. Returns
    previous value. Possible range is from 0 to 1.
    $A Igor sep03; */
{
float ret;
ret=sg_windowwidth;
if (z>=0 && z<=1)
{
  sg_windowwidth=z;
  sg_iwindowwidth=(int) ( 1.0f+(z*(sg_MAXX-1)) );
}
return ret;
}
float (*sg_setwindowwidth) (float z) = sg_setwindowwidth_default;


float sg_getwindowwidth_default(void)
    /* Returns the currently set value of the window width for newly open
    windows.
    $A Igor sep03; */
{
return sg_windowwidth;
}
float (*sg_getwindowwidth) (void) = sg_getwindowwidth_default;


float sg_setwindowheight_default(float z)
    /* Sets the initial height of windows when they are open to z. Returns
    previous value. Possible range is from 0 to 1.
    $A Igor sep03; */
{
float ret;
ret=sg_windowheight;
if (z>=0 && z<=1)
{
  sg_windowheight=z;
  sg_iwindowheight=(int) ( 1+(z*(sg_MAXY-1)) );
}
return ret;
}
float (*sg_setwindowheight) (float z) = sg_setwindowheight_default;


float sg_getwindowheight_default(void)
    /* Returns the currently set value of the window height for newly open
    windows.
    $A Igor sep03; */
{
return sg_windowheight;
}
float (*sg_getwindowheight) (void) = sg_getwindowheight_default;


int sg_nsetwindowxpos_default(int z)
    /* Sets the initial position for newly open windows in the x direction in
    pixels from the upper left corner of the screen. Negative vlaues imposes
    that the system can choose the position. The previous value is returned.
    If the value is greater than the screen widt, it is adjusted to the screen
    width. Negative values mean that the system is let to choose the position.
    $A Igor sep03; */
{
int ret;
ret=sg_iwindowxpos;
if (z<0)
{
  sg_windowxpos=-1;
  sg_iwindowxpos=-1;
} else
{
  if (z>sg_MAXX)
    z=sg_MAXX;
  sg_windowxpos=(float) z/sg_MAXX;
  sg_iwindowxpos=z;
}
return ret;
}
int (*sg_nsetwindowxpos) (int z) = sg_nsetwindowxpos_default;


int sg_ngetwindowxpos_default(void)
    /* Returns the current position in the x direction in pixels from the
    upper-left corner of the screen for newly open windows (negative value
    means that the system positions newly open windows).
    $A Igor sep03; */
{
return sg_iwindowxpos;
}
int (*sg_ngetwindowxpos) (void) = sg_ngetwindowxpos_default;


int sg_nsetwindowypos_default(int z)
    /* Sets the initial position for newly open windows in the y direction in
    pixels from the upper left corner of the screen. Negative vlaues imposes
    that the system can choose the position. The previous value is returned.
    If the value is greater than the screen height, it is adjusted to the screen
    height. Negative values mean that the system is let to choose the position.
    $A Igor sep03; */
{
int ret;
ret=sg_iwindowypos;
if (z<0)
{
  sg_windowypos=-1;
  sg_iwindowypos=-1;
} else
{
  if (z>sg_MAXY)
    z=sg_MAXY;
  sg_windowypos=(float) z/sg_MAXY;
  sg_iwindowypos=z;
}
return ret;
}
int (*sg_nsetwindowypos) (int z) = sg_nsetwindowypos_default;


int sg_ngetwindowypos_default(void)
    /* Returns the current position in the y direction in pixels from the
    upper-left corner of the screen for newly open windows (negative value
    means that the system positions newly open windows).
    $A Igor sep03; */
{
return sg_iwindowypos;
}
int (*sg_ngetwindowypos) (void) = sg_ngetwindowypos_default;


int sg_nsetwindowwidth_default(int z)
    /* Sets the initial width of newly open graphical windows in pixels and
    returns the previous value. If z is greater than the screen width, it is
    corrected do the screen width; if it is less than 1 then it is corrected
    to some reasonable value.
    $A Igor sep03; */
{
int ret;
if (z<1)
  z=100;
if (z>sg_MAXX)
  z=sg_MAXX;
ret=sg_iwindowwidth;
sg_windowwidth=(float) z/sg_MAXX;
sg_iwindowwidth=z;
return ret;
}
int (*sg_nsetwindowwidth) (int z) = sg_nsetwindowwidth_default;


int sg_ngetwindowwidth_default(void)
    /* Returns the currently set width for newly open windows in pixels.
    $A Igor sep03; */
{
return sg_iwindowwidth;
}
int (*sg_ngetwindowwidth) (void) = sg_ngetwindowwidth_default;


int sg_nsetwindowheight_default(int z)
    /* Sets the initial height of newly open graphical windows in pixels and
    returns the previous value. If z is greater than the screen height, it is
    corrected do the screen heigth; if it is less than 1 then it is corrected
    to some reasonable value.
    $A Igor sep03; */
{
int ret;
if (z<1)
  z=100;
if (z>sg_MAXY)
  z=sg_MAXY;
ret=sg_iwindowheight;
sg_windowheight=(float) z/sg_MAXY;
sg_iwindowheight=z;
return ret;
}
int (*sg_nsetwindowheight) (int z) = sg_nsetwindowheight_default;


int sg_ngetwindowheight_default(void)
    /* Returns the currently set height for newly open windows in pixels.
    $A Igor sep03; */
{
return sg_iwindowheight;
}
int (*sg_ngetwindowheight) (void) = sg_ngetwindowheight_default;




  /* Settings for plotting points: */


float sg_setpointsize_default(float size)
      /* Sets the size of points relative to screen width and height and
      returns the current size. The size must be within the range from 0 to 1.0
      inclusively. If it is out of range, some reasonable size is set.
      $A Igor sep03; */
{
float ret=sg_pointsize;
if (size>0 && size<=1)
  sg_pointsize=size;
else
  sg_pointsize=0.01f;
return ret;
}
float (*sg_setpointsize) (float size) = sg_setpointsize_default;

float sg_getpointsize_default(void)
    /* Returns the current relative size for plotting points. 
    $A Igor sep03; */
{
return sg_pointsize;
}
float (*sg_getpointsize) (void) = sg_getpointsize_default;

int sg_setcurvepoints_default(int num)
    /* Sets the number of divisions for drawing curved objects such as circles,
    and returns the current number. If num is less than 4, then 4 points are
    used. If it is more than 4000, then 4000 points are used.
    $A Igor sep03; */
{
int ret=sg_curvepoints;
if (num<4)
  num=4;
else if (num>4000)
  num=4000;
sg_curvepoints=num;
return ret;
}
int (*sg_setcurvepoints) (int num) = sg_setcurvepoints_default;

int sg_getcurvepoints_default(void)
    /* Returns number of divisions used for drawing curved objects
    $A Igor sep03; */
{
return sg_curvepoints;
}
int (*sg_getcurvepoints) (void) = sg_getcurvepoints_default;


    /* SETTING COLORS: */

void sg_setlinecolor_default(float red,float green,float blue)
     /* Sets the color for drawing lines. Color components red, green and blue
     should be in the range between 0 and 1. Color discretization and grayscale
     conversion is performed if specified by the settings.
     $A Igor sep03; */
{
sgcalccolor(red,green,blue,&sg_linecolor);
}
void (*sg_setlinecolor) (float red,float green,float blue) = sg_setlinecolor_default;

void sg_getlinecolor_default(float *red,float *green,float *blue)
    /* Sets *red, *green and *blue to the current values of RGB color
    components for drawing lines. These components are as have been set by the
    last call to the sg_itk_setlinecolor() and possibly updated according to
    the discrete shading or grayscale settings.
     $A Igor sep03; */
{
*red=sg_linecolor.red; *green=sg_linecolor.green; *blue=sg_linecolor.blue;
}
void (*sg_getlinecolor) (float *red,float *green,float *blue) = sg_getlinecolor_default;

void sg_setfillcolor_default(float red,float green,float blue)
     /* Sets the color for filling. Color components red, green and blue
     should be in the range between 0 and 1. Color discretization and grayscale
     conversion is performed if specified by the settings.
     $A Igor sep03; */
{
sgcalccolor(red,green,blue,&sg_fillcolor);
}
void (*sg_setfillcolor) (float red,float green,float blue) = sg_setfillcolor_default;

void sg_getfillcolor_default(float *red,float *green,float *blue)
    /* Sets *red, *green and *blue to the current values of RGB color
    components for filling. These components are as have been set by the
    last call to the sg_itk_setfillcolor() and possibly updated according to the
    discrete shading or grayscale settings.
     $A Igor sep03; */
{
*red=sg_fillcolor.red; *green=sg_fillcolor.green; *blue=sg_fillcolor.blue;
}
void (*sg_getfillcolor) (float *red,float *green,float *blue) = sg_getfillcolor_default;

void sg_settextcolor_default(float red,float green,float blue)
     /* Sets the color for drawing text. Color components red, green and blue
     should be in the range between 0 and 1. Color discretization and grayscale
     conversion is performed if specified by the settings.
     $A Igor sep03; */
{
sgcalccolor(red,green,blue,&sg_textcolor);
}
void (*sg_settextcolor) (float red,float green,float blue) = sg_settextcolor_default;

void sg_gettextcolor_default(float *red,float *green,float *blue)
    /* Sets *red, *green and *blue to the current values of RGB color
    components for drawing text. These components are as have been set by the
    last call to the sg_itk_settextcolor() and possibly updated according to the
    discrete shading or grayscale settings.
     $A Igor sep03; */
{
*red=sg_textcolor.red; *green=sg_textcolor.green; *blue=sg_textcolor.blue;
}
void (*sg_gettextcolor) (float *red,float *green,float *blue) = sg_gettextcolor_default;


    /* LINE SETTINGS */

void sg_setlinewidth_default(double width)
     /* Sets width of the lines to width. width should normally be an integer
     starting from 1. 
       WARNING - For programmers:
       This function should be replaced in the future in order to take integer
     arguments, possibly supplemented by one that takes floating point
     arguments. Handling for floating point values should be such that if they
     are less than 1, they are considered as relative width with respect to the
     window size, otherwise they are considered as width in window pixels.
     $A Igor sep03; */
{
if (width<0)
  width=0;
sg_linewidth=width;
if (width>=1)
  sg_ilinewidth=(int) width;
else
  sg_ilinewidth=1+(int) (width*(float) m_minval(sg_iwindowwidth,sg_iwindowheight));
}
void (*sg_setlinewidth) (double width) = sg_setlinewidth_default;


double sg_getlinewidth_default(void)
    /* Returns the current line width.
     $A Igor sep03; */
{
return sg_linewidth;
}
double (*sg_getlinewidth) (void) = sg_getlinewidth_default;

void sg_setlinetype_default(int type)
     /* Sets the type of lines to type. If type is 1 then lines are continuous.
     $A Igor sep03; */
{
if( type<1)
  type=1;
else if (type>3)
  type=3;
sg_linetype=type;
}
void (*sg_setlinetype) (int type) = sg_setlinetype_default;

int sg_getlinetype_default(void)
    /* Returns the current line type.
     $A Igor sep03; */
{
return sg_linetype;
}
int (*sg_getlinetype) (void) = sg_getlinetype_default;




    /* TEXT SETTINGS: */


void sg_settextfont_default(int font)
     /* Sets the font that is used for plotting text.
     $A Igor sep03; */
{
if (font<1)
  font=1;
sg_currentfont=font;
}
void (*sg_settextfont) (int font) = sg_settextfont_default;


int sg_gettextfont_default(void)
    /* Returns the current font that is used for plotting text strings.
    $A Igor sep03; */
{
return sg_currentfont;
}
int (*sg_gettextfont) (void) = sg_gettextfont_default;


void sg_settextheight_default(float height)
     /* Sets the height of the plotted text. height can either specify the
     height relative to the window size, in which case it must be less than
     1 (0 means the smallest admissible height that is system dependent) or
     an integer meaning the height in pixels. Floating point values greater
     than 1 are rounded to the nearest integer. Values smaller than 0 are
     treated as 0.
     $A Igor sep03; */
{
if (height<0)
  height=0;
sg_textheight=height;
if (height>=1)
  sg_itextheight=(int) height;
else
  sg_itextheight=1+(int) (height*(float) m_minval(sg_iwindowwidth,sg_iwindowheight));
}
void (*sg_settextheight) (float height) = sg_settextheight_default;


float sg_gettextheight_default(void)
{
return sg_textheight;
}
float (*sg_gettextheight) (void) = sg_gettextheight_default;


void sg_settextxalignment_default(int alignment)
    /* Sets the alignment of text in the horizontal direction. If alignment
    is -1 then text is aligned to the left of the anchor position, if it is
    0, the text is centered around the anchor position and if it is 1, the
    text is aligned to the right of the anchor position.
    $A Igor sep03; */
{
if (alignment<-1)
  alignment=-1;
else if (alignment>1)
  alignment=1;
sg_textxalignment=alignment;
}
void (*sg_settextxalignment) (int alignment) = sg_settextxalignment_default;


int sg_gettextxalignment_default(void)
    /* Returns the current allignment of plotted text strings in the horizontal
    direction.
    $A Igor sep03; */
{
return sg_textxalignment;
}
int (*sg_gettextxalignment) (void) = sg_gettextxalignment_default;


void sg_settextyalignment_default(int alignment)
    /* Sets the alignment of text in the vertical direction. If alignment
    is -1 then text is aligned below the anchor position, if it is 0, the text
    is centered around the anchor position and if it is 1, the text is aligned
    above the anchor position.
    $A Igor sep03; */
{
if (alignment<-1)
  alignment=-1;
else if (alignment>1)
  alignment=1;
sg_textyalignment=alignment;
}
void (*sg_settextyalignment) (int alignment) = sg_settextyalignment_default;


int sg_gettextyalignment_default(void)
    /* Returns the current allignment of plotted text strings in the vertical
    direction.
    $A Igor sep03; */
{
return sg_textyalignment;
}
int (*sg_gettextyalignment) (void) = sg_gettextyalignment_default;


void sg_settextalignment_default(int xalignment,int yalignment)
    /* Sets the alignment of text in both horizontal and vertical directions
    by using the functions sg_itk_settextxalignment() and settextyalignment().
    $A Igor sep03; */
{
sg_settextxalignment(xalignment);
sg_settextyalignment(yalignment);
}
void (*sg_settextalignment) (int xalignment,int yalignment) = sg_settextalignment_default;


void sg_gettextalignment_default(int *xalignment,int *yalignment)
    /* Returns the current allignment of the plotted text strings in the
    horizontal direction in *xalignment and in vertical direction in
    *yalignment. The pointer arguments may not be NULL.
    $A Igor sep03; */
{
*xalignment=sg_textxalignment;  *yalignment=sg_textyalignment;
}
void (*sg_gettextalignment) (int *xalignment,int *yalignment) = sg_gettextalignment_default;





    /* BASIC DRAWING FUNCTIONS: */

/* WARNING - For programmers:
Implemented should be also plotting with integer coordinates!
Implement calculation of fp coordinates from window coordinates and vice versa!
*/

void sg_line_default(float x1,float y1,float x2,float y2) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_line(x1,y1,x2,y2);
  return ;
} else
  sg_reportnographicinterface("sg_line");
}
void (*sg_line) (float x1,float y1,float x2,float y2) = sg_line_default;

void sg_triangle_default(float x1,float y1,float x2,float y2,float x3,float y3) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_triangle(x1,y1,x2,y2,x3,y3);
  return ;
} else
  sg_reportnographicinterface("sg_triangle");
}
void (*sg_triangle) (float x1,float y1,float x2,float y2,
                        float x3,float y3) = sg_triangle_default;

void sg_fourangle_default(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_fourangle(x1,y1,x2,y2,x3,y3,x4,y4);
  return ;
} else
  sg_reportnographicinterface("sg_fourangle");
}
void (*sg_fourangle) (float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4) = sg_fourangle_default;

void sg_filltriangle_default(float x1,float y1,float x2,float y2,
                        float x3,float y3) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_filltriangle(x1,y1,x2,y2,x3,y3);
  return ;
} else
  sg_reportnographicinterface("sg_filltriangle");
}
void (*sg_filltriangle) (float x1,float y1,float x2,float y2,
                        float x3,float y3) = sg_filltriangle_default;

void sg_fillfourangle_default(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_fillfourangle(x1,y1,x2,y2,x3,y3,x4,y4);
  return ;
} else
  sg_reportnographicinterface("sg_fillfourangle");
}
void (*sg_fillfourangle) (float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4) = sg_fillfourangle_default;

void sg_text_default(char *str,float x1,float y1) {
if (actbasint())
{
  /* Activation of interface succeeded, repeat func. call in order to call
  the function of a working drawing interface: */
  sg_text(str,x1,y1);
  return ;
} else
  sg_reportnographicinterface("sg_text");
}
void (*sg_text) (char *str,float x1,float y1) = sg_text_default;




   /* BASIC GRAPHIC ELEMENTS THAT ARE DRAWN BY OTHER DRAWING FUNCTIONS: */


void sg_rectangle_default(float x1,float y1,float x2,float y2)
{
sg_fourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}
void (*sg_rectangle) (float x1,float y1,float x2,float y2) = sg_rectangle_default;

void sg_circle_default(float x,float y,float r)
    /* Draws a circle with the center (x,y) and radius r composed of
    sg_curvepoints lines.
    $A Igor sep03; */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) sg_curvepoints);
x1=x+r;
y1=y;
for (i=1;i<=sg_curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  sg_line((float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}

void (*sg_circle) (float x,float y,float r) = sg_circle_default;


void sg_circlearc_default(float x,float y,float r,float fi1,float fi2)
    /* Draws a circle arc with the center (x,y), radius r and start and end
    angles fi1 and fi2. It composes the arc of lines in such a way that full
    angle would be composed of sg_curvepoints lines.
    $A Igor sep03; */
{
double x1,y1,x2,y2,fi,hfi;
int i,curvepoints;
curvepoints=1 + (int) round(fabs(fi2-fi1)/(2*ConstPi));
fi=fi1;
hfi=(fi2-fi1)/((double) curvepoints);
x1=x+r*cos(fi);
y1=y+r*sin(fi);
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  sg_line((float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}

void (*sg_circlearc)(float x,float y,float r,float fi1,float fi2) = sg_circlearc_default;


void sg_ellipse_default(float x,float y,float a,float b)
     /* Narise elipso iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) sg_curvepoints);
x1=x+a;
y1=y;
for (i=1;i<=sg_curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  sg_line((float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}

void (*sg_ellipse) (float x,float y,float a,float b) = sg_ellipse_default;


void sg_ellipsearc_default(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise elipsin lok iz sg_curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri ter z zacetnim kotom fi1 in
     s koncnim kotom fi2. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i,curvepoints;
curvepoints=1 + (int) round(fabs(fi2-fi1)/(2*ConstPi));
fi=fi1;
hfi=(fi2-fi1)/((double) curvepoints);
x1=x+a*cos(fi);
y1=y+b*sin(fi);
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  sg_line((float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}

void (*sg_ellipsearc)(float x,float y,float a,float b,float fi1,float fi2) = sg_ellipsearc_default;


void sg_fillrectangle_default(float x1,float y1,float x2,float y2)
     /* Narise zapolnjen pravokotnik s protileznima ogliscema (x1,y1) in
     (x2,y2). */
{
sg_fillfourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}

void (*sg_fillrectangle)(float x1,float y1,float x2,float y2) = sg_fillrectangle_default;


void sg_point_default(float x,float y)
     /* Narise tocko s koordinatami (x,y). Za barvo se uporalbja barva za
     polnjenje likov. */
{
sg_fillfourangle(x,y,x,y,x,y,x,y);
}

void (*sg_point)(float x,float y) = sg_point_default;


void sg_fillcircle_default(float x,float y,float r)
     /* Narise zapolnjen krog s srediscem v (x,y) in polmerom r iz sg_curvepoints
     zapolnjenih trikotnikov. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double)  sg_curvepoints);
x1=x+r;
y1=y;
for (i=1;i<=sg_curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  sg_filltriangle((float) x,(float) y,(float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}

void (*sg_fillcircle)(float x,float y,float r) = sg_fillcircle_default;


void sg_fillcirclearc_default(float x,float y,float r,float fi1,float fi2)
     /* Narise zapolnjen krozni lok s srediscem (x,y), polmerom r ter zacetnim
     kotom fi1 in koncnim kotom fi2 zi sg_curvepoints zapolnjenih trikotnikov. Koti
     so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i,curvepoints;
curvepoints=1 + (int) round(fabs(fi2-fi1)/(2*ConstPi));
fi=fi1;
hfi=(fi2-fi1)/((double) sg_curvepoints);
x1=x+r*cos(fi);
y1=y+r*sin(fi);
for (i=1;i<=sg_curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  sg_filltriangle((float) x,(float) y,(float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}

void (*sg_fillcirclearc) (float x,float y,float r,float fi1,float fi2) = sg_fillcirclearc_default;


void sg_fillellipse_default(float x,float y,float a,float b)
     /* Narise zapolnjeno elipso s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b iz sg_curvepoints zapolnjenih trikornikov. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) sg_curvepoints);
x1=x+a;
y1=y;
for (i=1;i<=sg_curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  sg_filltriangle((float) x,(float) y,(float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}

void (*sg_fillellipse)(float x,float y,float a,float b) = sg_fillellipse_default;


void sg_fillellipsearc_default(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise zapolnjen elipsin lok s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b ter zacetnim kotom fi1 in koncnim fi2 iz sg_curvepoints
     zapolnjenih trikornikov. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i=0,curvepoints;
curvepoints=1 + (int) round(fabs(fi2-fi1)/(2*ConstPi));
fi=fi1;
hfi=(fi2-fi1)/((double) sg_curvepoints);
x1=x+a*cos(fi);
y1=y+b*sin(fi);
for (i=1;i<=sg_curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  sg_filltriangle((float) x,(float) y,(float) x1,(float) y1,(float) x2,(float) y2);
  x1=x2; y1=y2;
}
}

void (*sg_fillellipsearc)(float x,float y,float a,float b,
                          float fi1,float fi2) = sg_fillellipsearc_default;





    /* FUNCTIONS FOR DRAWING MARKERS (=points): */

/* Auxiliary variables for quicker calculation: */

static float sin45=(float) 0.707107;
static float cos45=(float) 0.707107;
static float sin30=(float) 0.5;
static float cos30=(float) 0.866025;



static void sg_marker1_default(float x,float y,float size)
    /* Horizontal cross */
{
float step=size/2;
float asprat;
asprat=(float) sg_ngetwindowheight()/sg_ngetwindowwidth();
sg_line(x-step*asprat,y,x+step*asprat,y);
sg_line(x,y+step,x,y-step);
}

static void sg_marker2_default(float x,float y,float size)
    /* Oblique cross */
{
float step=size*sin45/2;
float asprat;
asprat=(float) sg_ngetwindowheight()/sg_ngetwindowwidth();
sg_line(x-step*asprat,y-step,x+step*asprat,y+step);
sg_line(x-step*asprat,y+step,x+step*asprat,y-step);
}

static void sg_marker3_default(float x,float y,float size)
    /* Horizontal square */
{
float step=size*sin45/2;
float asprat;
asprat=(float) sg_ngetwindowheight()/sg_ngetwindowwidth();
sg_fourangle(x-step*asprat,y-step,x+step*asprat,y-step,x+step*asprat,y+step,x-step*asprat,y+step);
}

static void sg_marker4_default(float x,float y,float size)
    /* Oblique square */
{
float asprat;
asprat=(float) sg_ngetwindowheight()/sg_ngetwindowwidth();
sg_fourangle(x-size*asprat/2,y,x,y-size/2,x+size*asprat/2,y,x,y+size/2);
}

static void sg_marker5_default(float x,float y,float size)
    /* Horizontal square with horizontal cross */
{
sg_marker3_default(x,y,size);
sg_marker1_default(x,y,size);
}

static void sg_marker6_default(float x,float y,float size)
    /* Horizontal square with oblique cross */
{
sg_marker3_default(x,y,size);
sg_marker2_default(x,y,size);
}

static void sg_marker7_default(float x,float y,float size)
    /* Oblique square with horizontal cross */
{
sg_marker4_default(x,y,size);
sg_marker1_default(x,y,size);
}

static void sg_marker8_default(float x,float y,float size)
    /* Oblique square with oblique cross */
{
sg_marker4_default(x,y,size);
sg_marker2_default(x,y,size);
}

static void sg_marker9_default(float x,float y,float size)
    /* Asterisk (6 rays) */
{
float asprat;
asprat=(float) sg_ngetwindowheight()/sg_ngetwindowwidth();
sg_line(x-size*asprat/2,y,x+size*asprat/2,y);
sg_line(x-sin30*size*asprat/2,y-cos30*size/2,x+sin30*size*asprat/2,y+cos30*size/2);
sg_line(x+sin30*size*asprat/2,y-cos30*size/2,x-sin30*size*asprat/2,y+cos30*size/2);
}

static void sg_marker10_default(float x,float y,float size)
    /* Circle */
{
int curvepoints;
float asprat;
asprat=(float) sg_ngetwindowheight()/sg_ngetwindowwidth();
curvepoints=sg_curvepoints;
sg_curvepoints=sg_markercurvepoints;
sg_ellipse(x,y,size*asprat/2,size/2);
sg_curvepoints=curvepoints;
}

static void sg_marker11_default(float x,float y,float size)
    /* Circle with horizontal cross */
{
sg_marker10_default(x,y,size);
sg_marker1_default(x,y,size);
}

static void sg_marker12_default(float x,float y,float size)
    /* Circle with oblique cross */
{
sg_marker10_default(x,y,size);
sg_marker2_default(x,y,size);
}

static void sg_marker13_default(float x,float y,float size)
    /* Circle with asterisk */
{
sg_marker10_default(x,y,size);
sg_marker9_default(x,y,size);
}

static void sg_marker14_default(float x,float y,float size)
    /* Horizontal square with asterisk */
{
sg_marker3_default(x,y,size);
sg_marker9_default(x,y,size);
}



static void (*sg_defaultmarker) (float x,float y,float size) = sg_marker1_default;

static stack sg_markerstack=NULL;



static void sg_initmarkerstack(void)
    /* Initializes the marker stack on which there are functions for drawing
    markers: */
{
if (sg_markerstack==NULL)
{
  sg_markerstack=newstack(5);
  pushstack(sg_markerstack,(void *) sg_marker1_default);
  pushstack(sg_markerstack,(void *) sg_marker2_default);
  pushstack(sg_markerstack,(void *) sg_marker3_default);
  pushstack(sg_markerstack,(void *) sg_marker4_default);
  pushstack(sg_markerstack,(void *) sg_marker5_default);
  pushstack(sg_markerstack,(void *) sg_marker6_default);
  pushstack(sg_markerstack,(void *) sg_marker7_default);
  pushstack(sg_markerstack,(void *) sg_marker8_default);
  pushstack(sg_markerstack,(void *) sg_marker9_default);
  pushstack(sg_markerstack,(void *) sg_marker10_default);
  pushstack(sg_markerstack,(void *) sg_marker11_default);
  pushstack(sg_markerstack,(void *) sg_marker12_default);
  pushstack(sg_markerstack,(void *) sg_marker13_default);
  pushstack(sg_markerstack,(void *) sg_marker14_default);
}
}



void sg_marker_default(float x,float y,float size,int kind)
    /* Draws a marker at (x,y) of a specified size and kind.
    $A Igor sep03; */
{
void (*sg_markerloc) (float x,float y,float size)=sg_defaultmarker;
/* Load functions for individual marker types if they're not loaded yet: */
if (sg_markerstack==NULL)
  sg_initmarkerstack();
/* Take the appropriate drawing function with respect to kind: */
if (kind>0 && kind<=sg_markerstack->n)
  if (sg_markerstack->s[kind]!=NULL)
    sg_markerloc= (void(*)(float,float,float)) sg_markerstack->s[kind];
sg_markerloc(x,y,size);  /* perform drawing */
}

void (*sg_marker) (float x,float y,float size,int kind) = sg_marker_default;


int sg_registermarker_default (void (*drawmarker) (float x,float y,float size))
    /* Registers a new function for drawing a marker and returns its ID by
    which it will be accessed (via the kind argument ar rhe call to sg_marker).
    $A Igor sep03; */
{
if (sg_markerstack==NULL)
  sg_initmarkerstack();
pushstack(sg_markerstack,drawmarker);
return (sg_markerstack->n);
}

int (*sg_registermarker) (void (*drawmarker) (float x,float y,float size)) = sg_registermarker_default;





void sg_arrow_default(float x1,float y1,float x2,float y2,float size,
                      float tgangle,int attr)
  /* Draws an arrow from (x1,y2) to (x2,y2) with the size of the head size and
  the tangens of the half angle of the head tgangle. attr determine how the arrow
  head is plotted. It can be a bitwise orred combination of the flags
  SG_ARROW_NOFILL (the head is not filled), SG_ARROW_LINE (the head is outlined),
  SG_ARROW_TRIANGLE (transversal line is also plotted in the outline) and
  SG_ARROW_ABS (the head size is understood absolute, i.e. relative to the window
  size; if this flag is not 1 then the head size is taken relative to the arrow
  length).
  $A Igor sep03; */
{
double asprat,ifi,ieta,sinfi,cosfi,isinfi,icosfi,length,
       dx1,dy1,dx2,dy2,checkcosifi,checksinifi;
if (!(attr&SG_ARROW_NOFILL) && !(attr&SG_ARROW_ABS))
  sg_line(x1,y1,x1+(x2-x1)*(float) (1-0.5*size),y1+(y2-y1)*(float) (1-0.5*size));
else
  sg_line(x1,y1,x2,y2);
if (size==0 || (x1==x2 && y1==y2) || ((attr&SG_ARROW_NOFILL) && !(attr&SG_ARROW_LINE)) )
  return; 
if (1)
{
  /* The ratio between the height and the width of the drawing window: */
  asprat=(double) sg_ngetwindowheight()/sg_ngetwindowwidth();
  /* Arrow size in natural co-ordinates: */
  length=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
  if (!(attr&SG_ARROW_ABS))
    size*=(float) length;  /* head size is relative to arrow length */
  /* Sine and cosine of the angle between the arrow and x axis in natural coord.: */
  sinfi=(y2-y1)/length;
  cosfi=(x2-x1)/length;
  /* Sin. and cos. of this angle in window coord.: */
  if (fabs(cosfi)>1e-6)
  {
    icosfi=1/sqrt(1+(sinfi/cosfi)*(sinfi/cosfi)*asprat*asprat);
    isinfi=sqrt(1-icosfi*icosfi);
  } else
  {
    isinfi=1/sqrt(1+(cosfi/sinfi)*(cosfi/sinfi)*asprat*asprat);
    icosfi=sqrt(1-isinfi*isinfi);
  }
  if (sinfi*isinfi<0)
    isinfi=-isinfi;
  if (cosfi*icosfi<0)
    icosfi=-icosfi;
  /* Angle between the arrow and x axis in the window co-ordinates: */
  if (fabs(icosfi)>1e-6)
    ifi=arctg(isinfi/icosfi);
  else
    ifi=arcctg(icosfi/isinfi);
  checksinifi=sin(ifi);
  checkcosifi=cos(ifi);
  if (isinfi*sin(ifi)<0 || icosfi*cos(ifi)<0)
    ifi+=ConstPi;
  checksinifi=sin(ifi);
  checkcosifi=cos(ifi);
  ieta=arctg(tgangle); /* arrow head half angle (spec. in windows coord.) */
  /* Steps for plotting the head (in natural co-ordinates): */
  dx1=size*sqrt(cosfi*cosfi+sinfi*sinfi*asprat*asprat) *
      cos(ifi+ConstPi+ieta)/cos(ieta);
  dy1=size*sqrt(cosfi*cosfi/(asprat*asprat)+sinfi*sinfi) *
      sin(ifi+ConstPi+ieta)/cos(ieta);
  dx2=size*sqrt(cosfi*cosfi+sinfi*sinfi*asprat*asprat) *
      cos(ifi+ConstPi-ieta)/cos(ieta);
  dy2=size*sqrt(cosfi*cosfi/(asprat*asprat)+sinfi*sinfi) *
      sin(ifi+ConstPi-ieta)/cos(ieta);
  if (!(attr&SG_ARROW_NOFILL))
    sg_filltriangle((float) x2,(float) y2,(float) (x2+dx1),(float) (y2+dy1),
                    (float) (x2+dx2),(float) (y2+dy2));
  if (attr&SG_ARROW_LINE)
  {
    sg_line((float) x2,(float) y2,(float) (x2+dx1),(float) (y2+dy1));
    sg_line((float) x2,(float) y2,(float) (x2+dx2),(float) (y2+dy2));
    if(attr&SG_ARROW_TRIANGLE)
      sg_line((float) (x2+dx1),(float) (y2+dy1),(float) (x2+dx2),(float) (y2+dy2));
  }
}
}


void (*sg_arrow)(float x1,float y1,float x2,float y2,float size,
            float tgangle,int attr) = sg_arrow_default;






    /* DRAWING STACKS (or better lists) OF GRAPHIC PRIMITIVES: */


void sg_godrawstack_default(stack st)
    /* Plots the stack st containing graphic primitives. Primitives are
    plotted in order of appearance.
    $A Igor sep03; */
{
int i;
if (st!=NULL)
  if (st->n>0)
    for (i=1;i<=st->n;++i)
      sg_godrawprimitive( (goprimitive) st->s[i]);
}

void (*sg_godrawstack) (stack st) = sg_godrawstack_default;



    /* AUXILIARY UTILITIES: */


static char *sg_plotfile=NULL, /* file name for the next open graphic file */
     *sg_plotfileroot;   /* recommended root for the plot file name */


char *sg_obtainplotfile(char *extension)
    /* Returns a dynamically allocated name for the graphic file in which
    a file graphic interface will plot its output. This function is usually
    called in a function for opening a window. The name is created according
    to instructions posed by sg_setplotfile() of sg_setplotfileroot()
    or autonomously if no recommendations were set.
      The extension specifies which extension should be appended to the file
    name, but has no wffect if the name has been requested by a call to the
    sg_setplotfilename() function. If extension has been dynamically allocated,
    it should be deallocated after the call to this function.
    $A Igor sep03; */
{
static int serial=0;
char *ret,buf[30],*root;
++serial;
if (sg_plotfile!=NULL)
{
  /* The complete name has been specified, use it: */
  ret=sg_plotfile;
  /* sg_plotfilename must be reset to NULL, otherwise the same file could be
  used by several drawing contexts: */
  sg_plotfile=NULL;
  return ret;
} else
{
  if (sg_plotfileroot!=NULL)
    root=sg_plotfileroot;
  else
    root="SGS_plot";
  sprintf(buf,"#%04i",serial);
  ret=stringcat(root,buf);
  stringappend(&ret,extension);
  return ret;
}
}

void sg_setplotfile(char *filename)
    /* Sets the name for the graphic file that will be first open for output
    by any graphic interface. The copy of filename is created, therefore the
    caller must eventually deallocate filename after the call to this function.
      filename can be NULL, in this case the previous setting is cancelled.
    $A Igor sep03; */
{
disppointer((void **) &sg_plotfile);
if (filename!=NULL)
  if (*filename!='\0')
    sg_plotfile=stringcopy(filename);
}


void sg_setplotfileroot(char *root)
    /* Sets the name root for the graphic file that will be next open for
    output by any graphic interface. The copy of root is created, therefore the
    caller must eventually deallocate the string after the call to this
    function.
      After a call to this function root will be used for forming the name of
    the graphic output file by the function sg_obtainplotfile() whenever
    the complete name will not be explicitly instructed by a preceeding
    call to sg_setplotfile().
      root can be NULL, in this case the previous setting is cancelled.
    $A Igor sep03; */
{
disppointer((void **) &sg_plotfileroot);
if (root!=NULL)
  if (*root!='\0')
    sg_plotfileroot=stringcopy(root);
}


    /* SWITCHING BETWEEN PLOTTING INTERFACES: */



void sg_initintbas(void)
    /* Performs the basic initialization for drawing interfaces. This function
    must be called at the beginning of each interface activation function.
    $A Igor sep03; */
{
if (sg_windows==NULL)
  sg_windows=newstack(10);
if (sg_fonts==NULL)
{
  sg_fonts=newstack(5);
  /* 5 instances of courier (plain, italic, bold, bold-italic, underline): */
  sg_installfont("courier",0,0,0,0);
  sg_installfont("courier",1,0,0,0);
  sg_installfont("courier",0,1,0,0);
  sg_installfont("courier",1,1,0,0);
  sg_installfont("courier",0,0,1,0);
  /* 5 instances of times (plain, italic, bold, bold-italic, underline): */
  sg_installfont("times",0,0,0,0);
  sg_installfont("times",1,0,0,0);
  sg_installfont("times",0,1,0,0);
  sg_installfont("times",1,1,0,0);
  sg_installfont("times",0,0,1,0);
  /* Other fonts: */
  sg_installfont("system",0,0,0,0);
  sg_installfont("helvetica",0,0,0,0);
  sg_installfont("lucida",0,0,0,0);
  sg_installfont("swiss",0,0,0,0);
  sg_installfont("ariel",0,0,0,0);
  sg_installfont("script",0,0,0,0);
  sg_installfont("terminal",0,0,0,0);
  sg_installfont("symbol",0,0,0,0);
}
}

static void sg_default_interface()
    /* Activates the default functions of graphic interface, which don't do
    anything. In the functions for installing true drawing interfaces it is
    good to call this function first, in order to override for sure any
    functions of previously active interfaces. This prevents mixing of
    interface functions and it is likely that an error will be reported if
    some interface functions are missing.
    $A Igor jan03; */
{
sg_initintbas();  /* must be called at the beginning of every interface 
                     activation function */
sg_interfaceid=SG_PLOT_DEFAULT;
/* We need to register the interface houskeeping functions: */
sg_register_dispwin(NULL); /* for deletion of intfc. specific win. data */
sg_register_dispfont(NULL); /* deletion of intfc. specific font data */
/* INSTALL INTERFACE SPECIFIC PLOTTING FUNCTIONS: */
/* WINDOW (and graphic context) HNADLING: */
sg_openwindow = sg_openwindow_default;
sg_setwindow = sg_setwindow_default;
sg_clearwindow = sg_clearwindow_default;
sg_resetwindow = sg_resetwindow_default;
sg_closewindow = sg_closewindow_default;
sg_raisewindow = sg_raisewindow_default;
sg_installfontstr = sg_installfontstr_default;
sg_setcoloring = sg_setcoloring_default;
sg_setnumshades = sg_setnumshades_default;
sg_colortabsize = sg_colortabsize_default;
sg_preindexcolors = sg_preindexcolors_default;
sg_setwindowtitle = sg_setwindowtitle_default;
sg_getwindowtitle = sg_getwindowtitle_default;
sg_setwindowxpos = sg_setwindowxpos_default;
sg_getwindowxpos = sg_getwindowxpos_default;
sg_setwindowypos = sg_setwindowypos_default;
sg_getwindowypos = sg_getwindowypos_default;
sg_setwindowwidth = sg_setwindowwidth_default;
sg_getwindowwidth = sg_getwindowwidth_default;
sg_setwindowheight = sg_setwindowheight_default;
sg_getwindowheight = sg_getwindowheight_default;
sg_nsetwindowxpos = sg_nsetwindowxpos_default;
sg_ngetwindowxpos = sg_ngetwindowxpos_default;
sg_nsetwindowypos = sg_nsetwindowypos_default;
sg_ngetwindowypos = sg_ngetwindowypos_default;
sg_nsetwindowwidth = sg_nsetwindowwidth_default;
sg_ngetwindowwidth = sg_ngetwindowwidth_default;
sg_nsetwindowheight = sg_nsetwindowheight_default;
sg_ngetwindowheight = sg_ngetwindowheight_default;
sg_setpointsize = sg_setpointsize_default;
sg_getpointsize = sg_getpointsize_default;
sg_setcurvepoints = sg_setcurvepoints_default;
sg_getcurvepoints = sg_getcurvepoints_default;
/* SETTING COLORS: */
sg_setlinecolor= sg_setlinecolor_default;
sg_getlinecolor = sg_getlinecolor_default;
sg_setfillcolor = sg_setfillcolor_default;
sg_getfillcolor = sg_getfillcolor_default;
sg_settextcolor = sg_settextcolor_default;
sg_gettextcolor = sg_gettextcolor_default;
/* LINE SETTINGS */
sg_setlinewidth = sg_setlinewidth_default;
sg_getlinewidth = sg_getlinewidth_default;
sg_setlinetype = sg_setlinetype_default;
sg_getlinetype = sg_getlinetype_default;
/* TEXT SETTINGS: */
sg_settextfont = sg_settextfont_default;
sg_gettextfont = sg_gettextfont_default;
sg_settextheight = sg_settextheight_default;
sg_gettextheight = sg_gettextheight_default;
sg_settextxalignment = sg_settextxalignment_default;
sg_gettextxalignment = sg_gettextxalignment_default;
sg_settextyalignment = sg_settextyalignment_default;
sg_gettextyalignment = sg_gettextyalignment_default;
sg_settextalignment = sg_settextalignment_default;
sg_gettextalignment = sg_gettextalignment_default;
/* BASIC DRAWING FUNCTIONS: */
sg_line = sg_line_default;
sg_triangle = sg_triangle_default;
sg_fourangle = sg_fourangle_default;
sg_filltriangle = sg_filltriangle_default;
sg_fillfourangle = sg_fillfourangle_default;
sg_text = sg_text_default;
/* BASIC GRAPHIC ELEMENTS THAT ARE DRAWN BY OTHER DRAWING FUNCTIONS: */
sg_rectangle = sg_rectangle_default;
sg_circle = sg_circle_default;
sg_circlearc = sg_circlearc_default;
sg_ellipse = sg_ellipse_default;
sg_ellipsearc = sg_ellipsearc_default;
sg_fillrectangle = sg_fillrectangle_default;
sg_point = sg_point_default;
sg_fillcircle = sg_fillcircle_default;
sg_fillcirclearc = sg_fillcirclearc_default;
sg_fillellipse = sg_fillellipse_default;
sg_fillellipsearc = sg_fillellipsearc_default;
/* FUNCTIONS FOR DRAWING MARKERS (=points) AND ARROWS (vectors) : */
sg_marker = sg_marker_default;
sg_registermarker = sg_registermarker_default;
sg_arrow = sg_arrow_default;
/* DRAWING STACKS (or better lists) OF GRAPHIC PRIMITIVES: */
sg_godrawstack = sg_godrawstack_default;
}





/* Stack of functions for activation of graphic interfaces and corresponding
interface names and flags: */
static stack sg_interfaces=NULL,sg_interfacenames=NULL;
/* $$ static indtab sg_interfaceflags=NULL; */


static void initinterfaces(void)
    /* Loads functions for activating SGS interfaces so they can be accessed
    by the sg_interface(). */
{
if (sg_interfaces==NULL)
{
  sg_interfaces=newstack(4);
  sg_interfacenames=newstack(4);
  /* $$ sg_interfaceflags=newindtab(4,0); */
  /* Default interface: */
  setstack(sg_interfacenames,stringcopy("Default (empty) interface"),
    SG_PLOT_DEFAULT);
  setstack(sg_interfaces,sg_default_interface,SG_PLOT_DEFAULT);
  /* $$ setindtab(sg_interfaceflags,0,SG_PLOT_DEFAULT), */
  /* X-Windows screen plotting interface:
  setstack(sg_interfacenames,stringcopy("X-Windows interface"),SG_PLOT_X),
  setstack(sg_interfaces,sg_x_interface,SG_PLOT_X);
  setindtab(sg_interfaceflags,1,SG_PLOT_X),
  */
  /* ITK screen plotting interface: */
  setstack(sg_interfacenames,stringcopy("ITK screen interface"),SG_PLOT_ITK);
  setstack(sg_interfaces,sg_itk_interface,SG_PLOT_ITK);
  /* $$ setindtab(sg_interfaceflags,1,SG_PLOT_ITK); */
  /* PostScript file plotting interface: */
  setstack(sg_interfacenames,stringcopy("PostScript file interface"),SG_PLOT_PS);
  setstack(sg_interfaces,sg_ps_interface,SG_PLOT_PS);
  /* $$ setindtab(sg_interfaceflags,0,SG_PLOT_PS); */
  /* Tcl/Tk file plotting interface: */
  setstack(sg_interfacenames,stringcopy("Tcl/Tk file interface"),SG_PLOT_TCL);
  setstack(sg_interfaces,sg_tcl_interface,SG_PLOT_TCL);
  /* $$ setindtab(sg_interfaceflags,0,SG_PLOT_TCL); */
}
}



int sg_interface(int id)
    /* Activates a specific drawing interface for SGS that is identified by
    id. id can be 0 (meaning the default interface) or any of the valid numbers
    that identify an interface. Macros such as SG_PLOT_X, SG_PLOT_ITK,
    SG_PLOT_PS and SG_PLOT_TCL can be used for the argument id.
      Retuns actual interface id (different than id if id is 0) or 0 if there
    is no interface identified by id.
    $A Igor sep03; */
{
void (*sg_interface_ptr)(void)=NULL;
/* According to interface ID, locate the interface activation function: */
if (sg_interfaces==NULL)
  initinterfaces();
if (id==0)
  id=SG_PLOT_DEFAULT;
sg_interface_ptr=stackel(sg_interfaces,id);
if ((sg_interface_ptr)==NULL)
{
  errfunc0("sg_interface");
  sprintf(ers(),"There is no SGS graphic interface identified by %i.\n",id);
  errfunc2();
  return 0;
} else
{
  sg_interface_ptr(); /* activates the interface */
  sg_interfaceid=id;  /* marks interface id for interface-dependent functions */
  sg_interfacename=stackel(sg_interfacenames,id);
  /*
  if (sg_interfaceflags!=NULL)
    if (sg_interfaceflags->n>=id)
      sg_interfaceflag=sg_interfaceflags->t[id];
  */
  return id;
}
}


int sg_registerinterface(void (*activate_interface) (void),char *name,int screen)
    /* Registeres a new interface. activate_interface is the function for
    activation and initialization of the interface, name is the name of the
    interface, and screen tells whether the interface draws on screen (1 for
    yes, 0 for no).
      A dynamic copy of name is made for use by SGS, which is available in the
    global variable sg_interfacename when the interface is active (while its
    ID is available in sg_interfaceid and the screen flah in sg_interfaceflag).
      This function RETURNS the interface ID that is assigned to this interface.
    This ID is used in all further references to the interface (e.g. after the
    call to this function, the interface will be activated by sg_interface(ID)).
    $A Igor sep03; */
{
/* Register pre-build interfaces if they haven't been registered yet: */
if (sg_interfaces==NULL || sg_interfacenames==NULL
    /* $$ || sg->interfaceflags!=NULL */
    )
  initinterfaces();
pushstack(sg_interfaces,activate_interface);
setstack(sg_interfacenames,stringcopy(name),sg_interfaces->n);
/*
setindtab(sg_interfaceflags,screen,sg_interfaces->n);
*/
return sg_interfaces->n;
}







static void test_sg_intfc_itk(void *ptr)
    /* Function that is posted by the function test_sg_intfc() for execution
    in the ITK server thread and does most of the job to of this function.
    The data is packed to a record pointed to by *ptr that contains a pointer
    to int (num), -argument of the calling function, and index tables list and
    winlist (list of interface numbers and list of windows, prepared by the
    calling functions).
    $A Igor sep03; */
{
#define NRAND 200
#define SKIPFILL 6
int direct=0,num,*pnum,i,j,k,rand10_1,rand10_2,rand3_1,rand3_2,*iptr;
indtab list=NULL,winlist=NULL;
float rand[NRAND+1];
static int reported=0;
TRIN(45,1,"test_sg_intfc_itk","Beginning of test_sg_intfc_itk")
/* Set direct access of ITK plotting interface to the interpreter and store the
current setting: */
if (getthreadid()==getitkthreadid())
{
  #ifndef ITK
    if (!reported)
    {
      ++reported;
      warnfunc1(1,"test_sg_intfc_itk");
      sprintf(ers(),"ITK is not present.");
      warnfunc2();
    }
  #else
    direct=sg_itk_setdirectitk(1,(void *) itk_interp());
    printf("The ITK interpreter will be accessed directly.\n");
  #endif
} else
{
  #ifndef ITK
    if (!reported)
    {
      ++reported;
      warnfunc1(1,"test_sg_intfc_itk");
      sprintf(ers(),"ITK is not present.");
      warnfunc2();
    }
  #else
    direct=sg_itk_setdirectitk(0,(void *) itk_interp());
    printf("Non-direct access, commands will be sent to the ITK server.\n");
  #endif
}
/* Extract data pointed to by ptr: */
iptr=ptr;
pnum=(int *) iptr[0];
num=*pnum;
list=(indtab) iptr[1];
winlist=(indtab) iptr[2];
timeinitrand();
TRIN(45,2,"test_sg_intfc_itk","Test 1")
for (i=1;i<=num;++i)
{
  /* Outer iteration, calculate random parameters for plotting things: */
  for (k=0;k<NRAND;++k)
    rand[k]=(float) random1();  /* random co-ordinates and colors */
  rand10_1=1+(int)(9.2*random1());
  rand10_2=1+(int)(9.2*random1());
  rand3_1=1+(int)(2.2*random1());
  rand3_2=1+(int)(2.2*random1());
  for (j=1;j<=list->n;++j)
  {
    for (k=0;k<NRAND;++k)
      rand[k]=(float) random1();  /* random co-ordinates and colors */
    rand10_1=1+(int)(9.2*random1());
    rand10_2=1+(int)(9.2*random1());
    rand3_1=1+(int)(2.2*random1());
    rand3_2=1+(int)(2.2*random1());
    /* Inner iteration, draw one group of things with all interfaces: */
    if (list->n>1)
    {
      /* Activate a particular interface and the corresponding window, but only if
      more than one interfaces are tested: */
      sg_interface(list->t[j]);
      sg_setwindow(winlist->t[j]);
    }
    /* Plotting: */
    sg_setlinecolor(rand[0],rand[1],rand[2]);
    sg_setlinetype(rand3_1);
    sg_setlinewidth(rand[6]*0.02);
    sg_line(rand[3],rand[4],rand[5],rand[6]);

    sg_setlinecolor(rand[7],rand[8],rand[9]);
    sg_setlinetype(rand3_2);
    sg_setlinewidth(rand[10]*0.02);
    sg_triangle(rand[10],rand[11],rand[12],rand[13],rand[14],rand[15]);

    if (i%SKIPFILL==0)
    {
      sg_setfillcolor(rand[16],rand[17],rand[18]);
      sg_filltriangle(rand[19],rand[20],rand[21],rand[22],rand[23],rand[24]);
    }

    if (i%SKIPFILL==0)
    {
      sg_setfillcolor(rand[25],rand[26],rand[27]);
      sg_fillfourangle(rand[28],rand[29],rand[30],rand[31],
          rand[32],rand[33],rand[34],rand[35]);
    }

    sg_setlinecolor(rand[36],rand[37],rand[38]);
    sg_setlinetype(rand3_1);
    sg_setlinewidth(rand[39]*0.02);
    sg_fourangle(rand[40],rand[41],rand[42],rand[43],
        rand[44],rand[45],rand[46],rand[47]);

    sg_setlinecolor(rand[48],rand[49],rand[50]);
    sg_setlinetype(rand3_2);
    sg_setlinewidth(rand[51]*0.02);
    sg_rectangle(rand[52],rand[53],rand[54],rand[55]);

    if (i%SKIPFILL==0)
    {
      sg_setfillcolor(rand[56],rand[57],rand[58]);
      sg_fillrectangle(rand[59],rand[60],rand[61],rand[62]);
    }

    if (i%SKIPFILL==0)
    {
      sg_setfillcolor(rand[63],rand[64],rand[65]);
      sg_fillcircle(rand[66],rand[67],rand[68]);
    }

    sg_setlinecolor(rand[70],rand[71],rand[72]);
    sg_setlinetype(rand3_1);
    sg_setlinewidth(rand[73]*0.02);
    sg_circle(rand[74],rand[75],rand[76]);
    
    if (i%SKIPFILL==0)
    {
      sg_setfillcolor(rand[78],rand[79],rand[80]);
      sg_fillcirclearc(rand[81],rand[82],rand[83],
        2*(float) ConstPi*rand[84],2*(float) ConstPi*rand[85]);
    }

    sg_setlinecolor(rand[86],rand[87],rand[88]);
    sg_setlinetype(rand3_1);
    sg_setlinewidth(rand[89]*0.02);
    sg_circlearc(rand[90],rand[91],rand[92],
      2*(float) ConstPi*rand[93],2*(float) ConstPi*rand[94]);

    sg_settextcolor(rand[94],rand[95],rand[96]);
    sg_settextfont(rand10_1);
    sg_settextheight(0.4f*rand[97]);
    sg_settextalignment(rand3_1-1,rand3_1-1);
    sg_text("Text string",rand[98],rand[99]);

    sg_setlinecolor(rand[100],rand[101],rand[102]);
    sg_marker(rand[100],rand[101],rand[102]*0.09f,rand10_1);
    sg_setlinecolor(rand[103],rand[104],rand[105]);
    sg_marker(rand[106],rand[107],rand[108]*0.09f,rand10_2);

    sg_setlinecolor(rand[109],rand[110],rand[111]);
    sg_setfillcolor(rand[112],rand[113],rand[114]);
    sg_arrow(rand[115],rand[116],rand[117],rand[118],rand[119],
      rand[120]*0.5f,0);

    sg_setlinecolor(rand[120],rand[121],rand[122]);
    sg_setfillcolor(rand[123],rand[124],rand[125]);
    sg_arrow(rand[126],rand[127],rand[128],rand[129],rand[130],
      rand[131]*0.5f,0);
    

    sg_setlinecolor(rand[131],rand[132],rand[133]);
    sg_setlinetype(rand3_1);
    sg_setlinewidth(rand[134]*0.02);
    sg_ellipse(rand[135],rand[136],rand[137],rand[138]);
    
    sg_setlinecolor(rand[139],rand[140],rand[141]);
    sg_setlinetype(rand3_2);
    sg_setlinewidth(rand[142]*0.02);
    sg_ellipsearc(rand[143],rand[144],rand[145],rand[146],
      2*(float) ConstPi*rand[147],2*(float) ConstPi*rand[148]);
  }
}

TRPT(45,2,"test_sg_intfc_itk","Before itk_procallrequests")
#ifndef ITK
  if (!reported)
  {
    ++reported;
    warnfunc1(1,"test_sg_intfc_itk");
    sprintf(ers(),"ITK is not present.");
    warnfunc2();
  }
#else
  itk_procallrequests();
#endif
TROUT(45,2,"test_sg_intfc_itk","Test 1")

printf("\n\n<Enter> for the next test!\n");

TRPT(45,3,"test_sg_intfc_itk","Before getchar()")
getchar();

TRIN(45,3,"test_sg_intfc_itk","Test 2 - color scales")
/* Color scales: */
for (j=1;j<=list->n;++j) /* Iterate over interfaces */
{
  TRIN(45,32,"test_sg_intfc_itk","Start - Interface scope")
  TRDOPR(45,32,NULL,NULL,
    fprintf(trf(),"%i.%i Interface No. %i.\n",45,32,j); fflush(trf());)
  if (list->n>1)
  {
    /* Activate a particular interface and the corresponding window, but only if
    more than one interfaces are tested: */
    TRPT(45,32,"test_sg_intfc_itk","Before sg_interface(...)")
    sg_interface(list->t[j]);
    TRPT(45,32,"test_sg_intfc_itk","Before sg_setwindow(...)")
    sg_setwindow(winlist->t[j]);
  }
  /* Close the the vindow used by the previous test and open a new window: */
  sg_closewindow();
  winlist->t[j]=sg_openwindow();
  /* Plotting: */
  if (1)
  {
    double factor=0,h=0.11,base=0.0;
    _truecolor col;
    int i;
    sg_setlinewidth(0.008f);
    sg_setlinetype(1);
    TRIN(45,31,"test_sg_intfc_itk","Before the for loop")
    for (i=1;i<=100;++i)
    {
      TRDOPR(45,31,NULL,NULL,
        fprintf(trf(),"%i.%i %i.iteration of for loop\n",45,31,i); fflush(trf());)
      base=0.0;
      factor=(double) i/(double) 100;
      TRPT(45,311,"test_sg_intfc_itk","")
      col=sg_colorscalerainbow(factor);
      /*
      col.red*=(float) (0.5*(1+factor));
      col.green*=(float) (0.5*(1+factor));
      col.blue*=(float) (0.5*(1+factor));
      */
      TRPT(45,312,"test_sg_intfc_itk","")
      sg_setlinecolor(col.red,col.green,col.blue);
      TRPT(45,313,"test_sg_intfc_itk","")
      sg_line((float) factor,(float)(base),(float) factor,(float)(base+h));
      base+=h;
      
      factor=(double) i/(double) 100;
      col=sg_colorscalerainbowlight(factor);
      sg_setlinecolor(col.red,col.green,col.blue);
      sg_line((float) factor,(float)(base),(float) factor,(float)(base+h));
      base+=h;
      TRPT(45,314,"test_sg_intfc_itk","")
      
      factor=(double) i/(double) 100;
      col=sg_colorscalebas(factor);
      sg_setlinecolor(col.red,col.green,col.blue);
      sg_line((float) factor,(float)(base),(float) factor,(float)(base+h));
      base+=h;
      
      factor=(double) i/(double) 100;
      col=sg_colorscalebaslight(factor);
      sg_setlinecolor(col.red,col.green,col.blue);
      sg_line((float) factor,(float)(base),(float) factor,(float)(base+h));
      base+=h;
      
      factor=(double) i/(double) 100;
      col=sg_colorscalecomp(factor);
      sg_setlinecolor(col.red,col.green,col.blue);
      sg_line((float) factor,(float)(base),(float) factor,(float)(base+h));
      base+=h;
      TRPT(45,315,"test_sg_intfc_itk","")
      
      factor=(double) i/(double) 100;
      col=sg_colorscalecomplight(factor);
      sg_setlinecolor(col.red,col.green,col.blue);
      sg_line((float) factor,(float)(base),(float) factor,(float)(base+h));
      base+=h;
      
      factor=(double) i/(double) 100;
      col=sg_colorscalemix(factor);
      sg_setlinecolor(col.red,col.green,col.blue);
      sg_line((float) factor,(float)(base),(float) factor,(float)(base+h));
      base+=h;
      
      factor=(double) i/(double) 100;
      col=sg_colorscalemixlight(factor);
      sg_setlinecolor(col.red,col.green,col.blue);
      sg_line((float) factor,(float)(base),(float) factor,(float)(base+h));
      base+=h;
      
    }
    TROUT(45,31,"test_sg_intfc_itk","After the for loop")
  }
  TROUT(45,32,"test_sg_intfc_itk","End - interface scope")
}

TRPT(45,3,"test_sg_intfc_itk","Before itk_procallrequests()")
#ifndef ITK
  if (!reported)
  {
    ++reported;
    warnfunc1(1,"test_sg_intfc_itk");
    sprintf(ers(),"ITK is not present.");
    warnfunc2();
  }
#else
  itk_procallrequests();
#endif
TROUT(45,3,"test_sg_intfc_itk","Test 2 - color scales")

printf("\n\n<Enter> for the next test!\n");
TRPT(45,4,"test_sg_intfc_itk","Before getchar()")
getchar();

TRIN(45,4,"test_sg_intfc_itk","Test 3 - Text tests")
/* Text test - fonts, size and color: */
for (j=1;j<=list->n;++j) /* Iterate over interfaces */
{
  if (list->n>1)
  {
    /* Activate a particular interface and the corresponding window, but only if
    more than one interfaces are tested: */
    sg_interface(list->t[j]);
    sg_setwindow(winlist->t[j]);
  }
  /* Close the the vindow used by the previous test and open a new window: */
  sg_closewindow();
  winlist->t[j]=sg_openwindow();
  /* Plotting: */
  if (1)
  {
    char buf[500],*ptr=buf;
    double height=0.04,edge=0.05,x=0.02,y=0,factor=1.2,spacefactor=0.5;
    int i,num=10;
    sg_font font;
    /* Calculate the initial height in such a way that the collective height of
    all plotted strings will match the image heighr minus twice the edge: */
    height=0;
    for (i=0;i<num;++i)
      height+=pow(factor,i)*(1+spacefactor);
    height=(1-2*edge)/height;
    sg_settextalignment(1,1);
    y=1-edge-height;
    for (i=1;i<=num;++i)
    {
      sg_settextfont(i);
      ptr=buf;
      if (sg_currentfont>0)
      {
        font=sg_fonts->s[sg_currentfont];
        ptr+=sprintf(ptr,"%i: Height %g, font \"%s\"",i,height,font->family);
        if (font->bold)
          ptr+=sprintf(ptr," bold");
        if (font->italic)
          ptr+=sprintf(ptr," italic");
        if (font->underline)
          ptr+=sprintf(ptr," underlined");
        if (font->overstrike)
          ptr+=sprintf(ptr," overstroke");
        sg_settextcolor((float) i/ (float) num, 1.f -(float) i/(float) num,
                        (float) i/(float) num);
        sg_settextheight((float) height);
        sg_text(buf,(float) x,(float) y);
        height*=factor;
        y-=height*(1+spacefactor);
      }
    }
  }
}

TRPT(45,4,"test_sg_intfc_itk","Before itk_procallrequests")
#ifndef ITK
  if (!reported)
  {
    ++reported;
    warnfunc1(1,"test_sg_intfc_itk");
    sprintf(ers(),"ITK is not present.");
    warnfunc2();
  }
#else
  itk_procallrequests();
#endif
TROUT(45,4,"test_sg_intfc_itk","Test 3 - Text tests")
printf("\n\n<Enter> for the next test!\n");
TRPT(45,5,"test_sg_intfc_itk","Before getchar()")
getchar();

TRIN(45,5,"test_sg_intfc_itk","Test 4 - Text alignment tests")
/* Text test - alignment: */
for (j=1;j<=list->n;++j) /* Iterate over interfaces */
{
  if (list->n>1)
  {
    /* Activate a particular interface and the corresponding window, but only if
    more than one interfaces are tested: */
    sg_interface(list->t[j]);
    sg_setwindow(winlist->t[j]);
  }
  /* Close the the vindow used by the previous test and open a new window: */
  sg_closewindow();
  winlist->t[j]=sg_openwindow();
  /* Plotting: */
  if (1)
  {
    char buf[500],*ptr=buf;
    float height=0.04f,x,y;
    int alx,aly;
    /* Calculate the initial height in such a way that the collective height of
    all plotted strings will match the image heighr minus twice the edge: */
    sg_settextfont(5);
    sg_settextheight(height);
    sg_setlinewidth(0.00001);
    sg_setlinecolor(0,0,0.8f);
    for (alx=-1;alx<=1;++alx)
      for (aly=-1;aly<=1;++aly)
      {
        x=(float)(1.5+alx)/3.0f;
        y=(float)(1.5+aly)/3.0f;
        sg_settextcolor(x,(1-y),((1-x)+y)/2);
        /*
        sg_setlinecolor(x,(1-y),((1-x)+y)/2);
        */
        sg_settextalignment(alx,aly);
        sprintf(buf,"[%i,%i]",alx,aly);
        sg_marker(x,y,height,1);
        sg_text(buf,x,y);
      }
  }
}

#ifndef ITK
  if (!reported)
  {
    ++reported;
    warnfunc1(1,"test_sg_intfc_itk");
    sprintf(ers(),"ITK is not present.");
    warnfunc2();
  }
#else
  itk_procallrequests();
#endif
TROUT(45,5,"test_sg_intfc_itk","Test 4 - Text alignment tests")
printf("\n\n<Enter> for the next test!\n");
getchar();

/* Plotting arrows - orientation test: */
for (j=1;j<=list->n;++j) /* Iterate over interfaces */
{
  if (list->n>1)
  {
    /* Activate a particular interface and the corresponding window, but only if
    more than one interfaces are tested: */
    sg_interface(list->t[j]);
    sg_setwindow(winlist->t[j]);
  }
  /* Close the the vindow used by the previous test and open a new window: */
  sg_closewindow();
  winlist->t[j]=sg_openwindow();
  /* Plotting: */
  if (1)
  {
    float x=0.5f,y=0.5f,fi=0,stepfi=0.5,length=0.5;
    int num=12;
    sg_setlinecolor(0,0,1);
    sg_setlinetype(1);
    sg_setlinewidth(2);
    sg_setfillcolor(0,1,1);
    stepfi=(float) (2*ConstPi/(num));
    while(fi<2*ConstPi)
    {
      sg_arrow(x,y,
        (float) (x+length*cos(fi)),
        (float) (y+length*sin(fi)), (float) 0.4, (float) 0.15,
        SG_ARROW_LINE);
      fi+=stepfi;
    }
  }
}
#ifndef ITK
  if (!reported)
  {
    ++reported;
    warnfunc1(1,"test_sg_intfc_itk");
    sprintf(ers(),"ITK is not present.");
    warnfunc2();
  }
#else
  itk_procallrequests();
#endif
printf("\n\n<Enter> for the next test!\n");
getchar();

/* Plotting markers - test of different kinds: */
for (j=1;j<=list->n;++j) /* Iterate over interfaces */
{
  if (list->n>1)
  {
    /* Activate a particular interface and the corresponding window, but only if
    more than one interfaces are tested: */
    sg_interface(list->t[j]);
    sg_setwindow(winlist->t[j]);
  }
  /* Close the the vindow used by the previous test and open a new window: */
  sg_closewindow();
  winlist->t[j]=sg_openwindow();
  /* Plotting: */
  if (1)
  {
    char buf[500],*ptr=buf;
    float height,x0=0.1f,y0=0.1f,hx,hy,x,y;
    int line,column,numlines=6,numcolumns=4,kind;
    /* Calculate the initial height in such a way that the collective height of
    all plotted strings will match the image heighr minus twice the edge: */
    hx=(float) (1-2*x0)/(numlines);
    hy=(float) (1-2*y0)/(numcolumns);
    height=(float) 0.4*m_minval(hx,hy);
    sg_setlinewidth(1);
    sg_setlinetype(1);
    sg_settextfont(5);
    sg_settextheight(height);
    sg_setlinewidth(0.00001);
    sg_setlinecolor(0,0,0.8f);
    sg_settextalignment(-1,0);
    kind=0;
    for (line=0;line<numlines;++line)
      for (column=0;column<numcolumns;++column)
      {
        ++kind;
        x=(float)(x0+line*hx);
        y=(float)(1-y0-column*hy);
        sg_settextcolor(x,(1-y),((1-x)+y)/2);
        /*
        sg_setlinecolor(x,(1-y),((1-x)+y)/2);
        */
        sg_setlinecolor(x,(1-y),((1-x)+y)/2);
        sprintf(buf,"%i: ",kind);
        sg_text(buf,(float) (x-0.25*height),y);
        sg_marker((float) (x+0.25*height),y,height,kind);
      }
  }
}

#ifndef ITK
  if (!reported)
  {
    ++reported;
    warnfunc1(1,"test_sg_intfc_itk");
    sprintf(ers(),"ITK is not present.");
    warnfunc2();
  }
#else
  itk_procallrequests();
#endif
printf("\n\n<Enter> for the next test!\n");
getchar();

/* Finally close all window used by the tests: */
for (j=1;j<=list->n;++j) /* Iterate over interfaces */
{
  if (list->n>1)
  {
    /* Activate a particular interface and the corresponding window, but only if
    more than one interfaces are tested: */
    sg_interface(list->t[j]);
    sg_setwindow(winlist->t[j]);
  }
  /* Close the the vindow used by the previous test and open a new window: */
  sg_closewindow();
}

/* Restore the previous setting regarding the direct access to ITK interpreter: */
sg_itk_setdirectitk(direct,NULL);
TROUT(45,1,"test_sg_intfc_itk","End of test_sg_intfc_itk")
#undef NRAND
#undef SKIPFILL
}


void test_sg_intfc(int direct,int num,char *fileroot,int intfc1,...)
    /* Performs the test of SGS drawing interfaces by drawing the same things in a
    random way with all interfaces. The Current window settings are assumed when
    opening windows. fileroot is the first part of the name of the file in which
    graphics will be output in the case that file interfaces are also included in
    the test. intfc1, etc., are the IDs of interfaces that should be tested. There
    can be a variable number of these arguments, the list must be terminated by
    an argument whose value is less or equal 0 (and which may not be omitted). num
    is the number of repetions of the basic loop which plots one primitive of each 
    ind with each interface.
      direct determines whether a direct access of the ITK interpreter is used
    or the interpreter is accessed via the ITK server.
    $A Igor sep03; */
{
indtab list=NULL,winlist=NULL;
int i,j,arg,id,winid;
double t1=0,t2=0,t3=0,t4=0,t5=0,ct1=0,ct2=0,ct3=0,ct4=0,ct5=0;
void *ptr[5];
static int reported=0;
va_list ap;
sg_setplotfileroot(fileroot);
list=newindtab(2,4);
winlist=newindtab(2,4);
arg=intfc1;
printf("\n\nTesting SGS plotting interfaces (test_sg_intfc):\n");
if (arg==0)
{
  printf("\nAt least one interface argument must be different than 0!\n");
  return;
}
va_start(ap,intfc1);
TRIN(44,1,"test_sg_intfc","Before loop over interfaces")
while(arg>0)
{
  if (id=sg_interface(arg))  /* Test if interface is installed: */
  {
    TRIN(44,2,"test_sg_intfc","Inside loop over interfaces")
    if (id==SG_PLOT_DEFAULT)
      printf("  The empty interface (ID %i) will be skipped.\n",sg_interfaceid);
    else
    {
      printf("  %s (ID %i) will be tested.\n",sg_interfacename,sg_interfaceid);
      /*
      pushindtab(list,id);
      */
      if (addindtabun(list,id,0,0)<1)
      {
      /* Open a window in a particular interface: */
        pushindtab(winlist,winid=sg_openwindow());
        sg_setwindow(winid);
      }
    }
    TROUT(44,2,"test_sg_intfc","Inside loop over interfaces")
  } else
    printf("  %i is not a valid graphic interface ID.\n",arg);
  arg=va_arg(ap,int);
}
TROUT(44,1,"test_sg_intfc","Before loop over interfaces")
if (list->n==1)
{
  printf("\nOnly one interface (%i) will be tested, therefore no interface or window\n",
    list->t[1]);
  printf("activation functions will be called.\n");
} else
{
  printf("%i interfaces will be tested.\n",list->n);
  printf("Interfaces and windows will be switched between each basic draving operation,\n");
  printf("which will significantly slow down plotting.\n");
  printf("Interfaces tested: ");
  for (i=1;i<=list->n;++i)
    if (i<list->n)
      printf("%i, ",list->t[i]);
    else printf("%i\n",list->t[i]);
}
/* Prepare things and plot: */
TRPT(44,3,"test_sg_intfc",NULL)
t1=absolutetime(); ct1=cputime();
TRPT(44,4,"test_sg_intfc",NULL)
/* Prepare data and launc function test_sg_intfc_itk() for execution by the
ITK server: */
TRPT(44,5,"test_sg_intfc",NULL)
ptr[0]=&num;
ptr[1]=list;
ptr[2]=winlist;
TRPT(44,6,"test_sg_intfc",NULL)

t3=absolutetime(); ct3=cputime();
TRPT(44,7,"test_sg_intfc","Before call to test_sg_intfc_itk")
if (list->n<1)
  printf("No graphic interfaces to test.\n");
#ifdef ITK
if (direct && list->n==1 && (list->t[1]==SG_PLOT_ITK || list->t[1]==SG_PLOT_BASIC))
#else
if (direct && list->n==1 && list->t[1]==SG_PLOT_ITK )
#endif
{
  TRCOM(44,7,"test_sg_intfc","Test will run directly (within the SGS interp. thread)");
  #ifndef ITK
    if (!reported)
    {
      ++reported;
      warnfunc1(1,"test_sg_intfc");
      sprintf(ers(),"ITK is not present.");
      warnfunc2();
    }
  #else
    printf("\nTest launched to execute directly in the ITK thread...\n\n");
    itk_sendfunc(test_sg_intfc_itk,ptr);
  #endif
  TRCOM(44,7,"test_sg_intfc","Run directly (within the interp. thread)");
} else
{
  TRCOM(44,7,"test_sg_intfc","Will run non-directly (sending requests to thread server)");
  printf("\nTest executed in the calling thread...\n\n");
  test_sg_intfc_itk(ptr);
  TRCOM(44,7,"test_sg_intfc","Will run non-directly (sending requests to thread server)");
}
TRPT(44,7,"test_sg_intfc","After call to test_sg_intfc_itk")

t4=absolutetime(); ct4=cputime();
printf("Time spent for function call: %g s (CPU %g s).\n",t4-t3,ct4-ct3);

#ifndef ITK
  if (!reported)
  {
    ++reported;
    warnfunc1(1,"test_sg_intfc_itk");
    sprintf(ers(),"ITK is not present.");
    warnfunc2();
  }
#else
  itk_procallrequests();
#endif
t2=absolutetime(); ct2=cputime();
printf("Plotting completed.\n");
printf("% i groups of basic plotting operations tested for %i plotting interfaces.\n",
       num,list->n);
printf("Total time spent for plotting and switching windows and interfaces is\n");
printf("                     %g s (CPU time: %g s).\n",t2-t1,ct2-ct1);
printf("\n\n<Enter> to close windows and continue!\n");
getchar();
for (j=1;j<=list->n;++j)
{
  sg_interface(list->t[j]);
  sg_setwindow(winlist->t[j]);
  sg_closewindow();
}
dispindtab(&list);
dispindtab(&winlist);
}










