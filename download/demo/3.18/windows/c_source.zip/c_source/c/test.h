#include <math.h>
#include <float.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <memory.h>

#include <mtypes.h>
#include <er.h>
#include <rf.h>
#include <st.h>
#include <vec.h>
#include <mat.h>
#include <strop.h>
#include <fop.h>
#include <numut.h>
#include <simb.h>
#include <test.h>

#include <fem.h>

static void fwritehexdigit(FILE *fp,int digit)
    /* V datoteko fp zapise heksadecimalno stevilko digit. digit mora biti
    celo stevilo od 0 do 15. */
{
if (digit<0) digit=0;
if (digit>15) digit=15;
if (digit<10)
  fprintf(fp,"%c",digit+'0');
else
  fprintf(fp,"%c",digit-10+'A');
}

static void fwritehex2dig(FILE *fp,int num)
    /* V datoteko fp zapise celo stevilo num v sestnajstiski obliki. Num mora
    biti nenegativno celo stevilo manjse od 256. */
{
div_t res;
if (num<0) num=0;
if (num>255) num=255;
res=div(num,16);
fwritehexdigit(fp,res.quot);
fwritehexdigit(fp,res.rem);
}

static void fwritehexcolor(FILE *fp,float red,float green,float blue)
    /* V datoteko fp zapise barvo s komponentami red, green in blue v formatu,
    ki je razpoznaven za X windowse ( #rrggbb , kjer za vsako komponento
    stojita dve heksadecimalni stevilki). */
{
fprintf(fp,"#");
fwritehex2dig(fp,(int) red*255);
fwritehex2dig(fp,(int) green*255);
fwritehex2dig(fp,(int) blue*255);
}


int numcmp=0;

int ipcmp(void *ip1,void *ip2)
{
int i1,i2;
++numcmp;
i1=*(int *) ip1;
i2=*(int *) ip2;
if (i1<i2)
  return -1;
else if (i1==i2)
  return 0;
else
  return 1;
}




int findsortstack0(stack st,void *ptr,int from, int to,int cmp(void *p1,void *p2))
    /* Na skladu st najde 1. taksen kazalec med from in to, da je objekt, na
    katerega kaze, enak objektu, na katerega kaze kazalec ptr. Kriterij za
    enakost je funkcija cmp, ki mora vrniti vrednost 0, ce sta objekta, na
    katera kazeta kazalca p1 in p2, enaka, ter katerokoli drugo vrednost, ce
    nista. funkcija vrne mesto, na katerem je ta kazalec. Ce taksnega mesta ne
    najde, vrne -1.
      Ce je from enako 0, funkcija isce od 1. elementa sklada naprej, ce pa je
    to enoko 0, isce funkcija do zadnjega elementa slada.
    VAZNA OPOMBA: 1. argument, ki se nalozi funkciji cmp, je vedno ptr !!!
    Zato mora biti tudi funkcija cmp narejena tako, da vzame ptr kot 1. arg.
    */
{
int ret=-1,left,right,middle,resleft,resright,resmiddle;
if (st!=NULL)
  if (st->n>0)
  {
    if (from<=0)
      from=1;
    if (to<=0)
      to=st->n;
    if (to>st->n)
      to=st->n;
    if (from<=to)
    {
      left=from;  right=to;
      resleft=cmp(ptr,st->s[left]);
      if (resleft==0)
        ret=left;
      else if (resleft>0)
      {
        resright=cmp(ptr,st->s[right]);
        if (resright==0)
          ret=right;
        else if (resright<0)
          while (ret<1 && right-left>1)
          {
            middle=(int)round((right+left)*0.5);
            resmiddle=cmp(ptr,st->s[middle]);
            if (resmiddle<0)
              right=middle;
            else if (resmiddle>0)
              left=middle;
            else
              ret=middle;
          }
      }
    }
  }
/* Zagotoviti je treba, da se res vrne prvi pojav kazalca , ki je glede
na funkcijo cmp enak kazalcu ptr (samo v primeru, ce je ret>1): */
if (ret>1)
  resmiddle=0;
else
  resmiddle=1;
while (!resmiddle && 0)
{
  if ( (resmiddle=cmp(ptr,st->s[ret-1])) ==0)
  {
    /* ret zmanjsamo za 1, ker je tudi element na mestu ret-1 enak ptr: */
    --ret;
    if (ret<2)
      resmiddle=1; /* Ce je ret ze enak 1, bomo prenehali z zmanjsevanjem */
  }
}
return ret;
}






static int (*cmpfunction1) (void *,void *); /* Pomoz. spr. za qsortstack. */

static int comparefunction1 (const void *t1,const void *t2)
       /* Pomozna funkcija za funkcijo qsortstack. */
{
void *p1,*p2;
p1=* (void **) t1; p2=* (void **) t2;
return cmpfunction1(p1,p2);
}

void *standptrfindsortstack(stack st,void *ptr,int from, int to,
                       int cmp(void *p1,void *p2))
{
cmpfunction1=cmp;
if (st!=NULL && st->n>0)
  return *(void **)bsearch(&ptr,st->s+1,st->n,sizeof(void *),comparefunction1);
else
  return NULL;
}


void pst(stack st)
{
if (st!=NULL)
  if (st->n>0)
  {
    int i;
    for (i=1;i<=st->n;++i)
      printf("[%i]:%i  ",i,*(int *)st->s[i]);
  }
printf("\n\n");
}







typedef struct
{
  double x,f,d,d2,a;
  char flagmin,flagmax,flagzero;
  vector v;
} _funcptdata1;

typedef _funcptdata1 *funcptdata1;

static funcptdata1 getfuncptdata1(int vecdim)
    /* Naredi objekt tipa _funcptdata1 in vrne kazalec nanj.
    $A Igor mar01; */
{
funcptdata1 ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
if (vecdim>0)
  ret->v=getvector(vecdim);
else
  ret->v=NULL;
return ret;
}

static void dispfuncptdata1(funcptdata1 *p)
    /* Zbrise objekt tipa dispfuncptdata1, na katerega kaze *p, ter postavi *p
    na NULL.
    $A Igor mar01; */
{
if (p!=NULL)
  if (*p!=NULL)
  {
    dispvector(&((*p)->v));
    free(*p);
    *p=NULL;
  }
}


static int cmpfuncptdata1(void *p1,void *p2)
    /* Primerja kazalca p1 in p2 tipa cmpfuncptdata1 po (...)->x. Ce sta p1 in
    p2 NULL, vrne 0, ce je le p1 NULL, vrne 2 (v tem primeru se smatra, da je
    p1 vecji od p2), ce pa je le p2 NULL, vrne -2. Funkcija vrne -1, ce je
    p1->x<p2->x, 0, ce sta enaka, in 1, ce je p1->x>p2->x.
    $A Igor mar01; */ 
{
funcptdata1 u1,u2;
u1=p1; u2=p2;
if (u1!=NULL && u2!=NULL)
{
  if (u1->x<u2->x)
    return -1;
  else if (u1->x==u2->x)
    return 0;
  else
    return 1;
} else if (u1==NULL)
{
  if (u2==NULL)
    return 0;
  else
    return 2;
} else if (u2==NULL)
  return -2;
return -2; /* samo zaradi prevajalnika */
}

static int cmpfuncptdata1x(void *p1,void *p2)
{
cmpfuncptdata1(p1,p2);
}

static int cmpfuncptdata1f(void *p1,void *p2)
    /* Primerja kazalca p1 in p2 tipa cmpfuncptdata1 po (...)->f. Ce sta p1 in
    p2 NULL, vrne 0, ce je le p1 NULL, vrne 2 (v tem primeru se smatra, da je
    p1 vecji od p2), ce pa je le p2 NULL, vrne -2. Funkcija vrne -1, ce je
    p1->x<p2->x, 0, ce sta enaka, in 1, ce je p1->x>p2->x.
    $A Igor mar01; */ 
{
funcptdata1 u1,u2;
u1=p1; u2=p2;
if (u1!=NULL && u2!=NULL)
{
  if (u1->f<u2->f)
    return -1;
  else if (u1->f==u2->f)
    return 0;
  else
    return 1;
} else if (u1==NULL)
{
  if (u2==NULL)
    return 0;
  else
    return 2;
} else if (u2==NULL)
  return -2;
return -2; /* samo zaradi prevajalnika */
}



int min1dcubint1(double (*func)(double),double start,double h,
       double safety,double tolx,double toly,double tolder,int maxit,
       double *x,double *y)
{
#define flin(x) ( a1*(x)+a0 )
#define fsqr(x) ( a2*m_sqr(x)+a1*(x)+a0 )
#define fcub(x) ( a3*m_cube(x)+a2*m_sqr(x)+a1*(x)+a0 )
#define dsqr(x) ( 2*a2*(x)+a1 )
#define dcub(x) ( 3*a3*m_sqr(x)+2*a2*(x)+a1 )

_funcptdata1 p1,p2,p3,p4,p,pleft,pright;
double maxstep=0,maxer,er,dx=0,df=0,fact,val,
       a3,a2,a1,a0,minx,miny,derleft,derright,erx,ery,erder,xx;
char stop=0,prn=1,extint,cubmininside;
int numit=0,numeval=0,nmin;
if (maxit<=0)
  maxit=10000;
if (safety<0)
  safety=-safety;
if (safety==0)
  safety=0.05;
if (h==0)
  h=1e-1;
if (tolx<0) tolx=-tolx;  if (toly<0) toly=-toly;
if (tolx==0 && toly==0)
  tolx=fabs(h)*1e-3;
/* Najprej se izracuna tri tocke, ki se postavijo v enakomernih razmikih: */
p1.x=start; p1.f=func(p1.x); ++numeval;
p2.x=start+h; p2.f=func(p2.x); ++numeval;
/* Tretjo tocko postavimo v smeri padanja funkcijske vrednosti: */
if (p2.f<=p1.f)
  p3.x=p2.x+h;
else
{
  h=-h; p=p1; p1=p2; p2=p;
  p3.x=p2.x+h;
}
p3.f=func(p3.x); ++numeval;
if (p3.f>=p2.f)
{
  /* Izgleda, da smo minimum ze ujeli; 4. tocko postavimo na sredino med
  2. in 3.: */
  p4.x=0.5*(p2.x+p3.x);
} else
{
  /* Tocke p1 ... p3 so monotono padajoce, zato s p4 podaljsamo interval;
  Tu bi se dalo morda najti boljso pozicijo p4 z upostevanjem vrednosti
  p1...p3 - vrednosti bi interpolirali in ocenili dolzino koraka, pri katerem
  napaka ne preseze vrednosti predpisane s safety. */
  p4.x=p3.x+2*h;
}
p4.f=func(p4.x); ++numeval;
++numit;
if (prn)
{
  printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
   numit,numeval,p1.x,p1.f,p2.x,p2.f,p3.x,p3.f,p4.x,p4.f);
}
/* Izracun absolutne razlike med vrednostjo funkcije in kvadratne parabole
skozi p1,p2 in p3 v tocki p4: */
sqrcoefrelval(p3.x,p3.f,p2.x,p2.f,p1.x,p1.f,&a2,&a1,&a0);
er=fabs( fsqr(p4.x-p3.x)+p3.f -p.f );
/* Izracun maksimalne dovoljene napake na zacetku: */
maxstep=h/2;
df=m_maxval(fabs(p3.f-p2.f),fabs(p3.f-p4.f));
dx=m_maxval(fabs(p3.x-p2.x),fabs(p3.x-p4.x));
if (df>dx)
  maxer=0.4*safety*df;  /* 0.4 je dodat. var. faktor */
else
  maxer=safety*sqrt(dx*df);
if (er>maxer)
{
  fact=0.5*maxer/er;
  if (fact<0.05)
    fact=0.05;
  maxstep*=fact;
}
if (prn)
  printf("dx=%g, df=%g,\ner=%g, maxer=%g, maxstep=%g\n",dx,df,er,maxer,maxstep);
/* Ekstrapolacijsko napako poskusamo s krcenjem intervala spraviti pod
dovoljeno: */

while (er>maxer)
{
  ++numit;
  /* Varovalka,  da nismo ze pod tolerancami - v tem primeru je numericni
  sum prevelik */
  if (tolx && m_maxval(fabs(p1.x-p3.x),fabs(p3.x-p4.x))<tolx)
  {
    errfunc0("min1dcubint1");
    fprintf(erf(),"Exceeding x-tolerance (%g) while struggling for safety accuracy.\n",tolx);
    fprintf(erf(),"Function is either too noisy or to wild.\n");
    errfunc2();
    return 0;
  } else if (toly && m_maxval(fabs(p1.f-p3.f),fabs(p3.f-p4.f))<toly)
  {
    errfunc0("min1dcubint1");
    fprintf(erf(),"Exceeding y-tolerance (%g) while struggling for safety accuracy.\n",toly);
    fprintf(erf(),"Function seems to be too wild, please decrease tolerances.\n");
    errfunc2();
    return 0;
  } else if (numit>maxit)
  {
    errfunc0("min1dcubint1");
    fprintf(erf(),"Maximum number of iterations (%i) exceeded while struggling for safety accuracy.\n",maxit);
    errfunc2();
    return 0;
  }
  /* Dolocimo meji intervala, ki ga razpenjajo tocke p1 ... p4 : */
  pleft.x=minval4(p1.x,p2.x,p3.x,p4.x);
  pright.x=maxval4(p1.x,p2.x,p3.x,p4.x);
  if (pleft.x==p1.x) pleft=p1; else if (pleft.x==p2.x) pleft=p2;
   else if (pleft.x==p3.x) pleft=p3; else pleft=p4;
  if (pright.x==p1.x) pright=p1; else if (pright.x==p2.x) pright=p2;
   else if (pright.x==p3.x) pright=p3; else pright=p4;
  p.x=p1.x+maxstep; p.f=func(p.x); ++numeval;
  /* Izracun absolutne razlike vrednosti kubicne parabole skozi p1, p2, p3 in
  p4 in funkcije v tocki p: */
  cubcoefrelval(p4.x,p4.f,p3.x,p3.f,p2.x,p2.f,p1.x,p1.f,&a3,&a2,&a1,&a0);
  er=fabs( fcub(p.x-p4.x)+p4.f -p.f );
  /* Izracun maksimalne dovoljene napake na zacetku: */
  df=m_maxval(fabs(p3.f-p2.f),fabs(p3.f-p4.f));
  dx=m_maxval(fabs(p3.x-p2.x),fabs(p3.x-p4.x));
  maxer=0.4*safety*df;  /* 0.4 je dodat. var. faktor */
  if (er>maxer)
  {
    fact=0.5*maxer/er;
    if (fact<0.05)
      fact=0.05;
    maxstep*=fact;
  }
  p1=p2; p2=p3; p3=p4; p4=p;
  if (prn)
  {
    printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
     numit,numeval,p1.x,p1.f,p2.x,p2.f,p3.x,p3.f,p4.x,p4.f);
    printf("Interval: [ %g , %g ]\n",pleft.x,pright.x);
    printf("dx=%g, df=%g,\ner=%g, maxer=%g, maxstep=%g\n",dx,df,er,maxer,maxstep);
  }
}
if (prn)
  printf("\nAccuracy satisfactory, searching for minimum:\n\n");
/* Iterativno iskanje minimuma: */
while ((!stop) && numit<maxit)
{
  ++numit;
  /* Varovalka,  da nismo ze pod tolerancami - v tem primeru je numericni
  sum prevelik */
  /*
  if (m_maxval(fabs(p1.x-p3.x),fabs(p3.x-p4.x))<tolx)
  {
    errfunc0("min1dcubint1");
    fprintf(erf(),"Exceeding x-tolerance (%g) while struggling for accuracy.\n",tolx);
    fprintf(erf(),"Function is either too noisy or to wild.\n");
    errfunc2();
    return 0;
  } else if (m_maxval(fabs(p1.f-p3.f),fabs(p3.f-p4.f))<toly)
  {
    errfunc0("min1dcubint1");
    fprintf(erf(),"Exceeding y-tolerance (%g) while struggling for accuracy.\n",toly);
    fprintf(erf(),"Function seems to be too wild, please decrease tolerances.\n");
    errfunc2();
    return 0;
  } else 
  */
  if (numit>maxit)
  {
    errfunc0("min1dcubint1");
    fprintf(erf(),"Maximum number of iterations (%i) exceeded while struggling for accuracy.\n",maxit);
    errfunc2();
    *x=p4.x;
    *y=p4.f;
    return 0;
  }
  /* Dolocimo meji intervala, ki ga razpenjajo tocke p1 ... p4 : */
  pleft.x=minval4(p1.x,p2.x,p3.x,p4.x);
  pright.x=maxval4(p1.x,p2.x,p3.x,p4.x);
  if (pleft.x==p1.x) pleft=p1; else if (pleft.x==p2.x) pleft=p2;
   else if (pleft.x==p3.x) pleft=p3; else pleft=p4;
  if (pright.x==p1.x) pright=p1; else if (pright.x==p2.x) pright=p2;
   else if (pright.x==p3.x) pright=p3; else pright=p4;
  cubcoefrelval(p4.x,p4.f,p3.x,p3.f,p2.x,p2.f,p1.x,p1.f,&a3,&a2,&a1,&a0);
  nmin=cubmin(a3,a2,a1,a0,&minx,&miny);
  minx+=p4.x; miny+=p4.f;
  cubmininside=0;
  if (nmin && ( (minx>pleft.x && minx<pright.x) || fabs(minx-pleft.x)<=fabs(maxstep)
   || fabs(minx-pright.x)<=fabs(maxstep) ) )
  {
    /* Kubicna parabola ima minimum. Ce lezi znotraj intervala
    [pleft.x-fabs(maxstep),pright.x+fabs(maxstep)], se novo tocko postavi v ta
    minimum: */ 
    p.x=minx;
    if (minx>pleft.x && minx<pright.x)
      cubmininside=1;
  } else
  {
    /* Kub. parabola nima minimuma, ali pa ga ima in lezi izven intervala
    [pleft.x-fabs(maxstep),pright.x+fabs(maxstep)]. Interval z novo tocko podalsamo v
    smeri nasprotni od odvoda kubicne parabole v tocki p4, ki je enak a1: */
    derleft=dcub(pleft.x-p4.x);
    derright=dcub(pright.x-p4.x);
    if (derleft>0)
      p.x=pleft.x-fabs(maxstep);
    else
      p.x=pright.x+fabs(maxstep);
  }
  if (p.x>=pleft.x && p.x<=pright.x)
    extint=0;
  else
    extint=1;
  p.f=func(p.x); ++numeval;
  if (prn)
  {
    printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
     numit,numeval,p1.x,p1.f,p2.x,p2.f,p3.x,p3.f,p4.x,p4.f);
    printf("Interval: [ %g , %g ]\n",pleft.x,pright.x);
    /*
    printf("Cub. parabola in points (x,y,der):\n");
    printf("( %g, %g, %g )\n",p1.x,p4.f+fcub(p1.x-p4.x),dcub(p1.x-p4.x));
    printf("( %g, %g, %g )\n",p2.x,p4.f+fcub(p2.x-p4.x),dcub(p2.x-p4.x));
    printf("( %g, %g, %g )\n",p3.x,p4.f+fcub(p3.x-p4.x),dcub(p3.x-p4.x));
    printf("( %g, %g, %g )\n",p4.x,p4.f+fcub(p4.x-p4.x),dcub(p4.x-p4.x));
    */
    if (nmin)
      printf("Min. cub. par.: ( %g , %g ), der:%g\n",minx,miny,dcub(minx-p4.x));
    printf("dx=%g, df=%g,\ner=%g, maxer=%g, maxstep=%g\n",dx,df,er,maxer,maxstep);
    /*
    printf("Derivative in p4: %g, left der.: %g, right der.: %g\n",a1,derleft,derright);
    */
    printf("p:      ( %g, %g )\n",p.x,p.f);
  }
  /* Izracun absolutne razlike vrednosti kubicne parabole skozi p1, p2, p3 in
  p4 in funkcije v tocki p: */
  er=fabs( fcub(p.x-p4.x)+p4.f -p.f );
  /* Izracun maksimalne dovoljene napake na zacetku: */
  df=m_maxval(fabs(p3.f-p2.f),fabs(p3.f-p4.f));
  dx=m_maxval(fabs(p3.x-p2.x),fabs(p3.x-p4.x));
  /* Izracun maksimalne napake interpolacije. Ce je razmah v smeri y vecji kot
  v smeri x, se uposteva razmah v smeri y (pomnozen z varnostnim faktorjem).
  Drugace se uposteva geometricna sredina med razmahom v smeri y in v smeri x: */
  if (df>dx)
    maxer=safety*df;
  else
    maxer=safety*sqrt(dx*df);
  if (extint)
  {
    if (er>0)
    {
      fact=maxer/er;
      if (fact<0.1)
        fact=0.1;
      else if (fact>10)
        fact=10;
      maxstep*=fact;
    } else
      maxstep*=10;
  }
  /* stop se postavi na 1, izracunajo se napake vrednosti in odvoda kot
  maksimum razlike v p3 in p4 ter razlike v p3 in kub. parabole v min. Ce
  kaksni od specifiranih toleranc ni zadosceno, se stop postavi na 0: */
  stop=1;
  if (tolx>0)
  {
    erx=m_maxval(fabs(p3.x-p4.x),fabs(p3.x-minx));
    if (erx>tolx)
      stop=0;
    if (prn)
    {
      if (erx<tolx)
        printf("x tolerance satisfied. ");
      printf("x error: %g (tol. %g)\n",erx,tolx);
    }
  }
  if (toly>0)
  {
    ery=m_maxval(fabs(p3.f-p4.f),fabs(p3.f-miny));
    if (ery>toly)
      stop=0;
    if (prn)
    {
      if (ery<toly)
        printf("y tolerance satisfied. ");
      printf("y error: %g (tol. %g)\n",ery,toly);
    }
  }
  if (tolder>0)
  {
    erder=fabs(dcub(0));
    if (erder>tolder)
      stop=0;
    if (prn)
    {
      if (erder<tolder)
        printf("der. tolerance satisfied. ");
      printf("abs. derivative: %g (tol. %g)\n",erder,tolder);
    }
  }
  if (cubmininside)
  {
    /* Minimum kub. parabole je v notranjosti najmanjsega intervala, ki vsebuje
    tocke p1 ... p4. Zato moramo preveriti, da je vrednost v p manjsa od
    najnizje vrednosti izmed tock p1 ... p4. Ce ni, potem je zelo verjetno,
    da je minimum zunaj intervala; Tocko p obdrzimo in kreiramo se eno tocko,
    ki je zunaj intervala: */
    val=minval4(p1.f,p2.f,p3.f,p4.f);
    if (val<p.f)
    {
      /* Vazno je, ali je minimum objet ali ne. Ce je minimum objet, je samo
      nekaj narobe s kubicno interpolacijo in postavimo tocko p blizu tocki z
      najmanjso funkcijako vrednostjo, toda na nasprotno stran te tocke kot je
      bil prejsnji p. Ce minimum ni objet, moramo pomozno tocko postaviti
      izven intervala. */
      
        /* Najprej tocko z najvisjo vrednostjo f nadomesti p: */
        val=maxval4(p1.f,p2.f,p3.f,p4.f);
        if (p1.f==val)
          p1=p;
        else if (p2.f==val)
          p2=p;
        else if (p3.f==val)
          p3=p;
        else if (p4.f==val)
          p4=p;
      
      val=minval4(p1.f,p2.f,p3.f,p4.f);
      if (val<pleft.f && val<pright.f)
      {
        /* Ce je minimum objet, novo tocko p postavimo blizu tocke z najmanjso
        vrednostjo, a na nasprotno stran kot je bila stara tocka p. Poskrbimo
        tudi, da je nova tocka blizje tocki z najnizjo vrednostjo kot
        katerakoli od ostalih tock (in da se ne pokriva s kaksno drugo tocko). */
        if (val==p1.f)
          xx=p1.x;
        else if (val==p2.f)
          xx=p2.x;
        else if (val==p3.f)
          xx=p3.x;
        else if (val==p4.f)
          xx=p4.x;
        p.x=xx-0.1*(p.x-xx);
        if ((p.x-xx)/(p1.x-xx)>1/5)
          p.x=(p1.x-xx)/5;
        if ((p.x-xx)/(p2.x-xx)>1/5)
          p.x=(p2.x-xx)/5;
        if ((p.x-xx)/(p3.x-xx)>1/5)
          p.x=(p3.x-xx)/5;
        if ((p.x-xx)/(p4.x-xx)>1/5)
          p.x=(p4.x-xx)/5;
        p.f=func(p.x); ++numeval;
      } else
      {
        if (pleft.f<pright.f)
          p.x=pleft.x-dx;
        else
          p.x=pright.x+dx;
        p.f=func(p.x); ++numeval;
      }
    }
  }
  /* Poskrbeti moramo, da se zamenja s p tocka, ki ima najvisjo funkcijsko
  vrednost: */
  val=maxval4(p1.f,p2.f,p3.f,p4.f);
  if (p1.f==val)
    p1=p;
  else if (p2.f==val)
    p2=p;
  else if (p3.f==val)
    p3=p;
  else if (p4.f==val)
    p4=p;
  /*
  p1=p2; p2=p3; p3=p4; p4=p;
  */
}

*x=p4.x;
*y=p4.f;

return 1;
#undef flin
#undef fsqr
#undef fcub
#undef dsqr
#undef dcub
}









int min1dcubintbas(double (*func)(double),double start,double h,
       double safety,double tolx,double toly,double tolder,int maxit,
       funcptdata1 p1,funcptdata1 p2,funcptdata1 p3,funcptdata1 p4,
       double *x,double *y,stack *addrst,funcptdata1 *pmin,
       int *itcnt,char prn)
    /*
    
      VAZNE OPOMBE:
     Ce so na skladu *addrst ob klicu ze kaksne tocke, naj bi bile sortirane
    po narascajocem x (drugace jihmin1dcubintba funkcija tudi sama sortira). Funkcija da
    vse nove tocke na sklad tako, da so sortirane po x.
     Vse tocke, ki so morebiti ze na skladu *addrst ob klicu funkcije, morajo
    biti obvezno taksne, da se lahko brisejo (npr. s funkcijo dispfuncptdata1),
    ker sama funkcija na sklad nalaga na novo alocirane tocke, ki se morajo
    brisati nekje izven funkcije.
     Ce so podane tocke p1, ... p4, naj bi bile prve tri tocke sortirane po
    padajocih funkcijskih vrednostih (vsaj performancno je bolje tako).
     Ce posebej za to funkcijo alociramo katero od tock p1 ... p4, je pametno
    dati le-te na sklad *addrst, ker ta sklad vsebuje tocke, ki se lahko
    brisejo. Funkcija sama ne skrbi za to, da so te tocke tudi na skladu, da
    se lahko te tocke obravnavajo loceno od ostalih.
    $A Igor apr01; */
{
#define flin(x) ( a1*(x)+a0 )
#define fsqr(x) ( a2*m_sqr(x)+a1*(x)+a0 )
#define fcub(x) ( a3*m_cube(x)+a2*m_sqr(x)+a1*(x)+a0 )
#define dsqr(x) ( 2*a2*(x)+a1 )
#define dcub(x) ( 3*a3*m_sqr(x)+2*a2*(x)+a1 )

_funcptdata1 *p=NULL,pleft,pright,l,r;
double maxstep=0,maxer,er,dx=0,df=0,dxmin,fact,val,
       a3,a2,a1,a0,minx,miny,derleft,derright,erx,ery,erder,xx,xx1;
char stop=0,extint,cubmininside;
int numit=0,numeval=0,nmin;
stack st;
if (pmin!=NULL)
  *pmin=NULL;
if (addrst==NULL)
{
  errfunc0("min1dcubintbas");
  fprintf(erf(),"Address of stack not specified.\n",tolx);
  errfunc2();
  if (itcnt!=NULL) *itcnt+=numit;
  return -10;
}
if (*addrst==NULL)
  *addrst=newstack(10);
st=*addrst;
qsortstack(st,cmpfuncptdata1);
if (maxit<=0)
  maxit=100;
if (safety<0)
  safety=-safety;
if (safety==0)
  safety=0.05;
if (safety>0.5)
  safety=0.5;
if (h==0)
  h=1e-1;
if (tolx<0) tolx=-tolx;  if (toly<0) toly=-toly;
if (tolx==0 && toly==0)
  tolx=fabs(h)*1e-3;
/* Najprej se izracuna stiri tocke, ki se postavijo v enakomernih razmikih: */
if (p1==NULL)
{
  xx=start;
  l.x=xx-0.1*fabs(h);
  r.x=xx+0.1*fabs(h);
  p1=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p1==NULL)
  {
    p1=getfuncptdata1(0);
    p1->x=xx;
    p1->f=func(p1->x); ++numeval;
    inssortstack(st,(void *) p1,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p1->x);
}
if (p2==NULL)
{
  xx=p1->x+h;
  l.x=xx-0.1*fabs(h);
  r.x=xx+0.1*fabs(h);
  p2=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p2==NULL)
  {
    p2=getfuncptdata1(0);
    p2->x=xx;
    p2->f=func(p2->x); ++numeval;
    inssortstack(st,(void *) p2,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p2->x);
}
/* Tretjo tocko postavimo v smeri padanja funkcijske vrednosti: */
if (p3==NULL)
{
  if (p2->f<=p1->f)
  {
    xx=p2->x+h;
    /* Preprecimo, da bi bil p3 preblizu p2 ali p1, ce slucajno p3 ne lezi
    izven intervala, ki ga omejujeta p1 in p2: */
    if ((xx-p2->x)*(xx-p1->x)<=0)
      xx=0.5*(p1->x+p2->x);
  } else
  {
    h=-h; p=p1; p1=p2; p2=p;
    xx=p2->x+h;
    /* Preprecimo, da bi bila tocka p3 preblizu p2 ali p1, ce slucajno p3 ne
    lezi izven intervala, ki ga omejujeta p1 in p2: */
    if ((xx-p2->x)*(xx-p1->x)<=0)
      xx=0.5*(p1->x+p2->x);
  }
  l.x=r.x=xx;
  p3=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p3==NULL)
  {
    p3=getfuncptdata1(0);
    p3->x=xx;
    p3->f=func(p3->x); ++numeval;
    inssortstack(st,(void *) p3,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p3->x);
}
if (p4==NULL)
{
  if (p3->f>p2->f && p1->f>p2->f)
  {
    /* Izgleda, da smo minimum ze ujeli; 4. tocko postavimo na sredino med
    2. in 3.: */
    xx=0.5*(p2->x+p3->x);
  } else
  {
    /* Tocke p1 ... p3 naj bi bile monotono padajoce, zato s p4 podaljsamo
    interval; Tu bi se dalo morda najti boljso pozicijo p4 z upostevanjem
    vrednosti p1 ... p3 - vrednosti bi interpolirali in ocenili dolzino koraka,
    pri katerem napaka ne preseze vrednosti predpisane s safety. */
    xx=p3->x+2.1*h;
  }
  /* Preprecimo, da bi bila tocka p4 preblizu p1, p2 ali p3 ce slucajno p4
  ne lezi izven intervala, ki ga omejujejo te tocke: */
  if ((xx-p2->x)*(xx-p1->x)<=0)
    xx=0.5*(p1->x+p2->x);
  if ((xx-p3->x)*(xx-p2->x)<=0)
    xx=0.5*(p2->x+p3->x);
  l.x=r.x=xx;
  p4=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p4==NULL)
  {
    p4=getfuncptdata1(0);
    p4->x=xx;
    p4->f=func(p4->x); ++numeval;
    inssortstack(st,(void *) p4,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p4->x);
}
if (prn)
{
  printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
   numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
}
/* Izracun absolutne razlike med vrednostjo funkcije in kvadratne parabole
skozi p1,p2 in p3 v tocki p4: */
sqrcoefrelval(p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a2,&a1,&a0);
er=fabs( fsqr(p4->x-p3->x)+p3->f - p4->f );
/* Izracun maksimalne dovoljene napake na zacetku: */
maxstep=h/2;
df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
if (df>dx)
  maxer=0.4*safety*df;  /* 0.4 je dodat. var. faktor */
else
  maxer=safety*sqrt(dx*df);
if (er>maxer)
{
  fact=0.5*maxer/er;
  if (fact<0.05)
    fact=0.05;
  maxstep*=fact;
}
if (prn)
  printf("dx=%g, df=%g,\ner=%g, maxer=%g, maxstep=%g\n",dx,df,er,maxer,maxstep);
/* Ekstrapolacijsko napako poskusamo s krcenjem intervala spraviti pod
dovoljeno: */
while (er>maxer)
{
  *x=p4->x; *y=p4->f;
  ++numit;
  /* Varovalka,  da nismo ze pod tolerancami - v tem primeru je numericni
  sum prevelik */
  if (tolx && m_maxval(fabs(p1->x-p2->x),fabs(p2->x-p4->x))<tolx)
  {
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Exceeding x-tolerance (%g) while struggling for safety accuracy.\n",tolx);
    fprintf(erf(),"Function is either too noisy or to wild.\n");
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -1;
  } else if (toly && m_maxval(fabs(p1->f-p2->f),fabs(p2->f-p4->f))<toly)
  {
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Exceeding y-tolerance (%g) while struggling for safety accuracy.\n",toly);
    fprintf(erf(),"Function seems to be too wild, please decrease tolerances.\n");
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -2;
  } else if (numit>maxit)
  {
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Maximum number of iterations (%i) exceeded while struggling for safety accuracy.\n",maxit);
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -3;
  }
  if (0)  /* STAREJSA VERZIJA */
  {
  /* Leva in desna meja: */
  pleft.x=minval4(p1->x,p2->x,p3->x,p4->x);
  pright.x=maxval4(p1->x,p2->x,p3->x,p4->x);
  if (pleft.x==p1->x) pleft=*p1; else if (pleft.x==p2->x) pleft=*p2;
   else if (pleft.x==p3->x) pleft=*p3; else pleft=*p4;
  if (pright.x==p1->x) pright=*p1; else if (pright.x==p2->x) pright=*p2;
   else if (pright.x==p3->x) pright=*p3; else pright=*p4;
  p=getfuncptdata1(0);
  p->x=p1->x+maxstep;
  /* Preprecimo, da bi bila tocka p preblizu p1, p2, p3 ali p4: */
  if (fabs((p->x-p2->x)*(p->x-p1->x))<1e-3*m_sqr(p2->x-p1->x))
    p->x=0.5*(p1->x+p2->x);
  if (fabs((p->x-p3->x)*(p->x-p2->x))<1e-3*m_sqr(p3->x-p2->x))
    p->x=0.5*(p2->x+p3->x);
  if (fabs((p->x-p4->x)*(p->x-p3->x))<1e-3*m_sqr(p4->x-p3->x))
    p->x=0.5*(p3->x+p4->x);
  p->f=func(p->x); ++numeval;
  inssortstack(st,(void *) p,cmpfuncptdata1);
  /* Izracun absolutne razlike vrednosti kubicne parabole skozi p1, p2, p3 in
  p4 in funkcije v tocki p: */
  cubcoefrelval(p4->x,p4->f,p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a3,&a2,&a1,&a0);
  er=fabs( fcub(p->x-p4->x)+p4->f - p->f );
  /* Izracun maksimalne dovoljene napake na zacetku: */
  df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
  dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
  maxer=0.4*safety*df;  /* 0.4 je dodat. var. faktor */
  if (er>maxer)
  {
    fact=0.5*maxer/er;
    if (fact<0.05)
      fact=0.05;
    maxstep*=fact;
  }
  p1=p2; p2=p3; p3=p4; p4=p;
  if (prn)
  {
    printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
     numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
    printf("Interval: [ %g , %g ]\n",pleft.x,pright.x);
    printf("dx=%g, df=%g,\ner=%g, maxer=%g, maxstep=%g\n",dx,df,er,maxer,maxstep);
  }
  }
  
  /* Dolocimo meji intervala, ki ga razpenjajo tocke p1 ... p4 : */
  pleft.x=minval4(p1->x,p2->x,p3->x,p4->x);
  pright.x=maxval4(p1->x,p2->x,p3->x,p4->x);
  if (pleft.x==p1->x) pleft=*p1; else if (pleft.x==p2->x) pleft=*p2;
   else if (pleft.x==p3->x) pleft=*p3; else pleft=*p4;
  if (pright.x==p1->x) pright=*p1; else if (pright.x==p2->x) pright=*p2;
   else if (pright.x==p3->x) pright=*p3; else pright=*p4;
  /* Ocenimo minimalni razmah v smeri x: */
  dxmin=minval4(fabs(p3->x-p4->x),fabs(p3->x-p2->x),fabs(p2->x-p4->x),
   fabs(p2->x-p1->x));
  /* Dobimo novo tocko; Najprej dolocimo x, nato pogledamo, ce je kaksna tocka
  s tem x ali dovolj blizu ze na skladu ter vzamemo ali to tocko s sklada (ce
  obstaja) ali naredimo novo pri dolocenem x: */
  xx=p1->x+h;
  /* Preprecimo, da bi bila tocka p preblizu p1, p2, p3 ali p4: */
  if (fabs((xx-p2->x)*(xx-p1->x))<1e-3*m_sqr(p2->x-p1->x))
    xx=0.5*(p1->x+p2->x);
  if (fabs((xx-p3->x)*(xx-p2->x))<1e-3*m_sqr(p3->x-p2->x))
    xx=0.5*(p2->x+p3->x);
  if (fabs((xx-p4->x)*(xx-p3->x))<1e-3*m_sqr(p4->x-p3->x))
    xx=0.5*(p3->x+p4->x);
  /* Dolocimo sprejemljive meje, da lahko vzamemo tocko s sklada */
  l.x=xx-m_minval(dxmin,fabs(h))/5; r.x=xx+m_minval(dxmin,fabs(h))/5;
  p=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p==NULL)
  {
    p=getfuncptdata1(0);
    p->x=xx;
    p->f=func(p->x); ++numeval;
    inssortstack(st,(void *) p,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p->x);
  /* Izracun absolutne razlike vrednosti kubicne parabole skozi p1, p2, p3 in
  p4 in funkcije v tocki p: */
  cubcoefrelval(p4->x,p4->f,p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a3,&a2,&a1,&a0);
  er=fabs( fcub(p->x-p4->x)+p4->f - p->f );
  /* Izracun maksimalne dovoljene napake na zacetku: */
  df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
  dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
  maxer=0.4*safety*df;  /* 0.4 je dodat. var. faktor */
  if (er>maxer)
  {
    fact=0.5*maxer/er;
    if (fact<0.05)
      fact=0.05;
    h*=fact;
  }
  p1=p2; p2=p3; p3=p4; p4=p;
  if (prn)
  {
    printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
     numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
    printf("Interval: [ %g , %g ]\n",pleft.x,pright.x);
    printf("dx=%g, df=%g,\ner=%g, maxer=%g, h=%g\n",dx,df,er,maxer,h);
  }
  
}
if (prn)
  printf("\nAccuracy satisfactory, searching for minimum:\n\n");
/* Iterativno iskanje minimuma: */
while ((!stop) /* && numit<maxit */ )
{
  *x=p4->x; *y=p4->f;
  ++numit;
  /* Varovalka,  da nismo ze pod tolerancami - v tem primeru je numericni
  sum prevelik */
  if (tolx && m_maxval(fabs(p1->x-p3->x),fabs(p3->x-p4->x))<0.5*tolx)
  {
    /*
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Exceeding x-tolerance (%g) while struggling for accuracy.\n",tolx);
    fprintf(erf(),"Function is either too noisy or to wild.\n");
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -1;
    */
  } else if (toly && m_maxval(fabs(p1->f-p3->f),fabs(p3->f-p4->f))<toly)
  {
    /*
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Exceeding y-tolerance (%g) while struggling for accuracy.\n",toly);
    fprintf(erf(),"Function seems to be too wild, please decrease tolerances.\n");
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -2;
    */
  } else 
  if (numit>maxit)
  {
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Maximum number of iterations (%i) exceeded while struggling for accuracy.\n",maxit);
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -5;
  }
  /* Dolocimo meji intervala, ki ga razpenjajo tocke p1 ... p4 : */
  pleft.x=minval4(p1->x,p2->x,p3->x,p4->x);
  pright.x=maxval4(p1->x,p2->x,p3->x,p4->x);
  if (pleft.x==p1->x) pleft=*p1; else if (pleft.x==p2->x) pleft=*p2;
   else if (pleft.x==p3->x) pleft=*p3; else pleft=*p4;
  if (pright.x==p1->x) pright=*p1; else if (pright.x==p2->x) pright=*p2;
   else if (pright.x==p3->x) pright=*p3; else pright=*p4;
  /* Ocenimo minimalni razmah v smeri x: */
  dxmin=minval4(fabs(p3->x-p4->x),fabs(p3->x-p2->x),fabs(p2->x-p4->x),
   fabs(p2->x-p1->x));
  /* koeficienti kubicne parabole relativno na tocko p4: */
  cubcoefrelval(p4->x,p4->f,p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a3,&a2,&a1,&a0);
  nmin=cubmin(a3,a2,a1,a0,&minx,&miny);
  minx+=p4->x; miny+=p4->f;
  cubmininside=0;
  /*
  p=getfuncptdata1(0);
  */
  if (nmin && ( (minx>pleft.x && minx<pright.x) || fabs(minx-pleft.x)<=fabs(maxstep)
   || fabs(minx-pright.x)<=fabs(maxstep) ) )
  {
    /* Kubicna parabola ima minimum. Ce lezi znotraj intervala
    [pleft.x-fabs(maxstep),pright.x+fabs(maxstep)], se novo tocko postavi v ta
    minimum: */ 
    /*
    p->x=minx;
    */
    xx=minx;
    l.x=r.x=xx;
    if (minx>pleft.x && minx<pright.x)
      cubmininside=1;
  } else
  {
    /* Kub. parabola nima minimuma, ali pa ga ima in lezi izven intervala
    [pleft.x-fabs(maxstep),pright.x+fabs(maxstep)]. Interval z novo tocko
    podaljsamo v smeri nasprotni od odvoda kubicne parabole v enem od krajisc: */
    derleft=dcub(pleft.x-p4->x);
    derright=dcub(pright.x-p4->x);
    /*
    if (derleft>0)
      p->x=pleft.x-fabs(maxstep);
    else
      p->x=pright.x+fabs(maxstep);
    */
    if (derleft>0)
      xx=pleft.x-fabs(maxstep);
    else
      xx=pright.x+fabs(maxstep);
    l.x=xx-0.1*dxmin;
    r.x=xx+0.1*dxmin;
  }
  /*
  if (p->x>=pleft.x && p->x<=pright.x)
    extint=0;
  else
    extint=1;
  */
  if (xx>=pleft.x && xx<=pright.x)
    extint=0;
  else
    extint=1;
  /*
  p->f=func(p->x); ++numeval;
  inssortstack(st,(void *) p,cmpfuncptdata1);
  */
  p=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p!=NULL)
    xx=p->x;
  /* Prepreciti moramo, da bi p sovpadal s p1, p2, p3 ali p4: */
  if (xx==p1->x || xx==p2->x || xx==p3->x || xx==p4->x)
  {
    xx+=0.09*dxmin;
    p=NULL;
  }
  if (p==NULL)
  {
    p=getfuncptdata1(0);
    p->x=xx;
    p->f=func(p->x); ++numeval;
    inssortstack(st,(void *) p,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p->x);
  if (prn)
  {
    printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
     numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
    printf("Interval: [ %g , %g ]\n",pleft.x,pright.x);
    /*
    printf("Cub. parabola in points (x,y,der):\n");
    printf("( %g, %g, %g )\n",p1->x,p4->f+fcub(p1->x-p4->x),dcub(p1->x-p4->x));
    printf("( %g, %g, %g )\n",p2->x,p4->f+fcub(p2->x-p4->x),dcub(p2->x-p4->x));
    printf("( %g, %g, %g )\n",p3->x,p4->f+fcub(p3->x-p4->x),dcub(p3->x-p4->x));
    printf("( %g, %g, %g )\n",p4->x,p4->f+fcub(p4->x-p4->x),dcub(p4->x-p4->x));
    */
    if (nmin)
      printf("Min. cub. par.: ( %g , %g ), der:%g\n",minx,miny,dcub(minx-p4->x));
    printf("dx=%g, df=%g,\ner=%g, maxer=%g, maxstep=%g\n",dx,df,er,maxer,maxstep);
    /*
    printf("Derivative in p4: %g, left der.: %g, right der.: %g\n",a1,derleft,derright);
    */
    printf("p:      ( %g, %g )\n",p->x,p->f);
  }
  /* Izracun absolutne razlike vrednosti kubicne parabole skozi p1, p2, p3 in
  p4 in funkcije v tocki p: */
  er=fabs( fcub(p->x-p4->x)+p4->f - p->f );
  /* Izracun maksimalne dovoljene napake na zacetku: */
  df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
  dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
  /* Izracun maksimalne napake interpolacije. Ce je razmah v smeri y vecji kot
  v smeri x, se uposteva razmah v smeri y (pomnozen z varnostnim faktorjem).
  Drugace se uposteva geometricna sredina med razmahom v smeri y in v smeri x: */
  if (df>dx)
    maxer=safety*df;
  else
    maxer=safety*sqrt(dx*df);
  if (extint)
  {
    if (er>0)
    {
      fact=maxer/er;
      if (fact<0.1)
        fact=0.1;
      else if (fact>10)
        fact=10;
      maxstep*=fact;
    } else
      maxstep*=10;
  }
  if (cubmininside)
  {
    /* Minimum kub. parabole je v notranjosti najmanjsega intervala, ki vsebuje
    tocke p1 ... p4. Zato moramo preveriti, da je vrednost v p manjsa od
    najnizje vrednosti izmed tock p1 ... p4. Ce ni, potem je zelo verjetno,
    da je minimum zunaj intervala; Tocko p obdrzimo in kreiramo se eno tocko,
    ki je zunaj intervala: */
    val=minval4(p1->f,p2->f,p3->f,p4->f);
    if (val<p->f)
    {
      /* Vazno je, ali je minimum objet ali ne. Ce je minimum objet, je samo
      nekaj narobe s kubicno interpolacijo in postavimo tocko p blizu tocki z
      najmanjso funkcijako vrednostjo, toda na nasprotno stran te tocke kot je
      bil prejsnji p. Ce minimum ni objet, moramo pomozno tocko postaviti
      izven intervala. */
      /* Najprej tocko z najvisjo vrednostjo f nadomesti p: */
      val=maxval4(p1->f,p2->f,p3->f,p4->f);
      if (p1->f==val)
        p1=p;
      else if (p2->f==val)
        p2=p;
      else if (p3->f==val)
        p3=p;
      else if (p4->f==val)
        p4=p;
      val=minval4(p1->f,p2->f,p3->f,p4->f);
      if (val<pleft.f && val<pright.f)
      {
        /*
        p=getfuncptdata1(0);
        */
        /* Ce je minimum objet, novo tocko p postavimo blizu tocke z najmanjso
        vrednostjo, a na nasprotno stran kot je bila stara tocka p. Poskrbimo
        tudi, da je nova tocka blizje tocki z najnizjo vrednostjo kot
        katerakoli od ostalih tock (in da se ne pokriva s kaksno drugo tocko). */
        if (val==p1->f)
          xx=p1->x;
        else if (val==p2->f)
          xx=p2->x;
        else if (val==p3->f)
          xx=p3->x;
        else if (val==p4->f)
          xx=p4->x;
        /*
        p->x=xx-0.1*(p->x-xx);
        xx1=xx-0.1*(p->x-xx);
        */
        if (xx!=p->x)
          xx1=xx-0.1*(p->x-xx)*fabs(dxmin/(p->x-xx));
        else
          xx1=xx+0.07*dxmin;
        /*
        if ((p->x-xx)/(p1->x-xx)>1/5)
          p->x=(p1->x-xx)/5;
        if ((p->x-xx)/(p2->x-xx)>1/5)
          p->x=(p2->x-xx)/5;
        if ((p->x-xx)/(p3->x-xx)>1/5)
          p->x=(p3->x-xx)/5;
        if ((p->x-xx)/(p4->x-xx)>1/5)
          p->x=(p4->x-xx)/5;
        p->f=func(p->x); ++numeval;
        inssortstack(st,(void *) p,cmpfuncptdata1);
        if ((xx1-xx)/(p1->x-xx)>1/5)
          xx1=(p1->x-xx)/5;
        if ((xx1-xx)/(p2->x-xx)>1/5)
          xx1=(p2->x-xx)/5;
        if ((xx1-xx)/(p3->x-xx)>1/5)
          xx1=(p3->x-xx)/5;
        if ((xx1-xx)/(p4->x-xx)>1/5)
          xx1=(p4->x-xx)/5;
        */
        if (fabs(xx1-p1->x)<=0.05*dxmin)
        {
          if (xx1<p1->x)
            xx1-=0.03*dxmin;
          else
            xx1+=0.03*dxmin;
        }
        if (fabs(xx1-p2->x)<=0.05*dxmin)
        {
          if (xx1<p2->x)
            xx1-=0.03*dxmin;
          else
            xx1+=0.03*dxmin;
        }
        if (fabs(xx1-p3->x)<=0.05*dxmin)
        {
          if (xx1<p3->x)
            xx1-=0.03*dxmin;
          else
            xx1+=0.03*dxmin;
        }
        if (fabs(xx1-p4->x)<=0.05*dxmin)
        {
          if (xx1<p4->x)
            xx1-=0.03*dxmin;
          else
            xx1+=0.03*dxmin;
        }
        l.x=xx1;
        p=ptrfindsortstack(st,&l,0,0,cmpfuncptdata1);
        if (p==NULL)
        {
          p=getfuncptdata1(0);
          p->x=xx1;
          p->f=func(p->x); ++numeval;
          inssortstack(st,(void *) p,cmpfuncptdata1);
        } else if (prn)
          printf("\nA point was picked from stack, x=%g.\n\n",p->x);
      } else
      {
        /*
        p=getfuncptdata1(0);
        if (pleft.f<pright.f)
          p->x=pleft.x-dx;
        else
          p->x=pright.x+dx;
        p->f=func(p->x); ++numeval;
        inssortstack(st,(void *) p,cmpfuncptdata1);
        */
        if (pleft.f<pright.f)
          xx=pleft.x-dx;
        else
          xx=pright.x+dx;
        l.x=xx;
        p=ptrfindsortstack(st,&l,0,0,cmpfuncptdata1);
        if (p==NULL)
        {
          p=getfuncptdata1(0);
          p->x=xx;
          p->f=func(p->x); ++numeval;
          inssortstack(st,(void *) p,cmpfuncptdata1);
        } else if (prn)
          printf("\nA point was picked from stack, x=%g.\n\n",p->x);
      }
    }
  }
  /* Poskrbeti moramo, da se zamenja s p tocka, ki ima najvisjo funkcijsko
  vrednost: */
  val=maxval4(p1->f,p2->f,p3->f,p4->f);
  if (p1->f==val)
    p1=p;
  else if (p2->f==val)
    p2=p;
  else if (p3->f==val)
    p3=p;
  else if (p4->f==val)
    p4=p;
  /*
  p1=p2; p2=p3; p3=p4; p4=p;
  */
  /* stop se postavi na 1, izracunajo se napake vrednosti in odvoda kot
  maksimum razlike v p3 in p4 ter razlike v p3 in kub. parabole v min. Ce
  kaksni od specifiranih toleranc ni zadosceno, se stop postavi na 0: */
  stop=1;
  if (tolx>0)
  {
    erx=1000*tolx;
    if (nmin)
      erx=m_maxval(fabs(p3->x-p4->x),fabs(p3->x-minx));
    if (erx>tolx)
      stop=0;
    if (prn)
    {
      if (erx<tolx)
        printf("x tolerance satisfied. ");
      printf("x error: %g (tol. %g)\n",erx,tolx);
    }
  }
  if (toly>0)
  {
    ery=1000*toly;
    if (nmin)
      ery=m_maxval(fabs(p3->f-p4->f),fabs(p3->f-miny));
    if (ery>toly)
      stop=0;
    if (prn)
    {
      if (ery<toly)
        printf("y tolerance satisfied. ");
      printf("y error: %g (tol. %g)\n",ery,toly);
    }
  }
  if (tolder>0)
  {
    erder=fabs(dcub(0));
    if (erder>tolder)
      stop=0;
    if (prn)
    {
      if (erder<tolder)
        printf("der. tolerance satisfied. ");
      printf("abs. derivative: %g (tol. %g)\n",erder,tolder);
    }
  }
}
*x=p4->x;
*y=p4->f;
p4->flagmin=1;  /* Zastavica za minimum */
if (pmin!=NULL)
  *pmin=p4;
if (prn)
  printf("\nCalculated minimum: ( %g , %g ).\n\n",*x,*y);
if (itcnt!=NULL) *itcnt+=numit;
return 0;
#undef flin
#undef fsqr
#undef fcub
#undef dsqr
#undef dcub
}



static double (*auxfunc)(double)=NULL;

static double minusauxfunc(double x)
{
if (auxfunc!=NULL)
  return -auxfunc(x);
else
  return 0;
}

int max1dcubintbas(double (*func)(double),double start,double h,
       double safety,double tolx,double toly,double tolder,int maxit,
       funcptdata1 p1,funcptdata1 p2,funcptdata1 p3,funcptdata1 p4,
       double *x,double *y,stack *addrst,funcptdata1 *pmax,
       int *itcnt,char prn)
{
int ret,i;
funcptdata1 p;
stack st;
auxfunc=func;
if (prn)
{
  printf("\n\nCalculating maximum of a function of one variable\n");
  printf("by using a minimum search function:\n\n---------------");
}
if (pmax==NULL)
  pmax=&p;
/* Pripreva sklada *addrst, ki vkljucuje alokacijo po potrebi, sortiranje
sklada in zagotovitev, da so vse tocke p1 ... p4, ki niso NULL, na skladu: */
if (addrst!=NULL)
{
  if (*addrst==NULL)
    *addrst=newstack(10);
  st=*addrst;
} else
  st=NULL;
qsortstack(st,cmpfuncptdata1);
/* Ce katera od tock p1 ... p4 ni NULL in je tudi ni ns skladu st, moramo
posebej poskrbeti za to, da zanjo spremenimo podatke tako, da ustreza
funkciji minus func: */
if (p1!=NULL)
  if (!findsortstack(st,(void *) p1,0,0,cmpfuncptdata1) )
  {
    p1->f=-p1->f;
    p1->d=-p1->d;
    p1->d2=-p1->d2;
  }
if (p2!=NULL)
  if (!findsortstack(st,(void *) p2,0,0,cmpfuncptdata1) )
  {
    p2->f=-p2->f;
    p2->d=-p2->d;
    p2->d2=-p2->d2;
  }
if (p3!=NULL)
  if (!findsortstack(st,(void *) p3,0,0,cmpfuncptdata1) )
  {
    p3->f=-p3->f;
    p3->d=-p3->d;
    p3->d=-p3->d2;
  }
if (p4!=NULL)
  if (!findsortstack(st,(void *) p4,0,0,cmpfuncptdata1) )
  {
    p4->f=-p4->f;
    p4->d=-p4->d;
    p4->d2=-p4->d2;
  }
/* Vse podatke o ze izracunanih tockah spremenimo tako, da ustrezajo funkciji
minus func: */
if (st!=NULL)
  for(i=1;i<=st->n;++i)
  {
    p=st->s[i];
    p->f=-p->f;
    p->d=-p->d;
    p->d2=-p->d2;
  }
/* Izracunamo minimum funkcije -func, ki je hkrati maksimum funkcije func: */
ret=min1dcubintbas(minusauxfunc,start,h,safety,tolx,toly,tolder,maxit,
       p1,p2,p3,p4,x,y,addrst,pmax,itcnt,prn);
/* Vse podatke o izracunanih tockah spremenimo tako, da ustrezajo originalni
funkciji in ne minus func; Popravimo tudi zastavico na *pmax: */
if (*pmax!=NULL)
{
  (*pmax)->flagmin=0;
  (*pmax)->flagmax=1;
}
*y=-*y;
if (addrst!=NULL)
  st=*addrst;
else
  st=NULL;
/* Ce katera od tock p1 ... p4 ni NULL in je tudi ni ns skladu st, moramo
posebej poskrbeti za to, da zanjo spremenimo podatke tako, da spet ustreza
funkciji func namesto minus func: */
if (p1!=NULL)
  if (!findsortstack(st,(void *) p1,0,0,cmpfuncptdata1) )
  {
    p1->f=-p1->f;
    p1->d=-p1->d;
    p1->d2=-p1->d2;
  }
if (p2!=NULL)
  if (!findsortstack(st,(void *) p2,0,0,cmpfuncptdata1) )
  {
    p2->f=-p2->f;
    p2->d=-p2->d;
    p2->d2=-p2->d2;
  }
if (p3!=NULL)
  if (!findsortstack(st,(void *) p3,0,0,cmpfuncptdata1) )
  {
    p3->f=-p3->f;
    p3->d=-p3->d;
    p3->d=-p3->d2;
  }
if (p4!=NULL)
  if (!findsortstack(st,(void *) p4,0,0,cmpfuncptdata1) )
  {
    p4->f=-p4->f;
    p4->d=-p4->d;
    p4->d2=-p4->d2;
  }
if (st!=NULL)
  for(i=1;i<=st->n;++i)
  {
    p=st->s[i];
    p->f=-p->f;
    p->d=-p->d;
    p->d2=-p->d2;
  }
auxfunc=NULL;
if (prn)
  printf("---------------\n\nMaximum: ( %g , %g )\n\n",*x,*y);
return ret;
}







































int zero1dcubintbas(double (*func)(double),double start,double h,
       double safety,double tolx,double toly,int maxit,
       funcptdata1 p1,funcptdata1 p2,funcptdata1 p3,funcptdata1 p4,
       double *x,double *y,stack *addrst,funcptdata1 *pmin,
       int *itcnt,char prn)
{

#define flin(x) ( a1*(x)+a0 )
#define fsqr(x) ( a2*m_sqr(x)+a1*(x)+a0 )
#define fcub(x) ( a3*m_cube(x)+a2*m_sqr(x)+a1*(x)+a0 )
#define dsqr(x) ( 2*a2*(x)+a1 )
#define dcub(x) ( 3*a3*m_sqr(x)+2*a2*(x)+a1 )

_funcptdata1 *p=NULL,pleft,pright,l,r;
double maxstep=0,maxer,er,dx=0,df=0,dxmin,fact,val,zero1,zero2,zero3,
       a3,a2,a1,a0,minx,miny,derleft,derright,erx,ery,xx,xx1;
char stop=0,extint,pointinside;
int numit=0,numeval=0,nmin,nzero;
stack st;
if (pmin!=NULL)
  *pmin=NULL;
if (addrst==NULL)
{
  errfunc0("min1dcubintbas");
  fprintf(erf(),"Address of stack not specified.\n",tolx);
  errfunc2();
  if (itcnt!=NULL) *itcnt+=numit;
  return -10;
}
if (*addrst==NULL)
  *addrst=newstack(10);
st=*addrst;
qsortstack(st,cmpfuncptdata1);
if (maxit<=0)
  maxit=100;
if (safety<0)
  safety=-safety;
if (safety==0)
  safety=0.05;
if (safety>0.5)
  safety=0.5;
if (h==0)
  h=1e-1;
if (tolx<0) tolx=-tolx;  if (toly<0) toly=-toly;
if (tolx==0 && toly==0)
  tolx=fabs(h)*1e-3;
/* Najprej se izracuna stiri tocke, ki se postavijo v enakomernih razmikih: */
if (p1==NULL)
{
  xx=start;
  l.x=xx-0.1*fabs(h);
  r.x=xx+0.1*fabs(h);
  p1=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p1==NULL)
  {
    p1=getfuncptdata1(0);
    p1->x=xx;
    p1->f=func(p1->x); ++numeval;
    inssortstack(st,(void *) p1,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p1->x);
}
if (p2==NULL)
{
  xx=p1->x+h;
  l.x=xx-0.1*fabs(h);
  r.x=xx+0.1*fabs(h);
  p2=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p2==NULL)
  {
    p2=getfuncptdata1(0);
    p2->x=xx;
    p2->f=func(p2->x); ++numeval;
    inssortstack(st,(void *) p2,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p2->x);
}
/* Tretjo tocko postavimo v smeri padanja absolutne funkcijske vrednosti: */
if (p3==NULL)
{
  if (fabs(p2->f)<=fabs(p1->f))
  {
    xx=p2->x+h;
    /* Preprecimo, da bi bil p3 preblizu p2 ali p1, ce slucajno p3 ne lezi
    izven intervala, ki ga omejujeta p1 in p2: */
    if ((xx-p2->x)*(xx-p1->x)<=0)
      xx=0.5*(p1->x+p2->x);
  } else
  {
    h=-h; p=p1; p1=p2; p2=p;
    xx=p2->x+h;
    /* Preprecimo, da bi bila tocka p3 preblizu p2 ali p1, ce slucajno p3 ne
    lezi izven intervala, ki ga omejujeta p1 in p2: */
    if ((xx-p2->x)*(xx-p1->x)<=0)
      xx=0.5*(p1->x+p2->x);
  }
  l.x=r.x=xx;
  p3=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p3==NULL)
  {
    p3=getfuncptdata1(0);
    p3->x=xx;
    p3->f=func(p3->x); ++numeval;
    inssortstack(st,(void *) p3,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p3->x);
}
if (p4==NULL)
{
  if (fabs(p3->f)>fabs(p2->f) && fabs(p1->f)>fabs(p2->f))
  {
    /* Izgleda, da smo minimum ze ujeli; 4. tocko postavimo na sredino med
    2. in 3.: */
    xx=0.5*(p2->x+p3->x);
  } else
  {
    /* Tocke p1 ... p3 naj bi bile monotono padajoce, zato s p4 podaljsamo
    interval; Tu bi se dalo morda najti boljso pozicijo p4 z upostevanjem
    vrednosti p1 ... p3 - vrednosti bi interpolirali in ocenili dolzino koraka,
    pri katerem napaka ne preseze vrednosti predpisane s safety. */
    xx=p3->x+2.1*h;
  }
  /* Preprecimo, da bi bila tocka p4 preblizu p1, p2 ali p3 ce slucajno p4
  ne lezi izven intervala, ki ga omejujejo te tocke: */
  if ((xx-p2->x)*(xx-p1->x)<=0)
    xx=0.5*(p1->x+p2->x);
  if ((xx-p3->x)*(xx-p2->x)<=0)
    xx=0.5*(p2->x+p3->x);
  l.x=r.x=xx;
  p4=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p4==NULL)
  {
    p4=getfuncptdata1(0);
    p4->x=xx;
    p4->f=func(p4->x); ++numeval;
    inssortstack(st,(void *) p4,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p4->x);
}
if (prn)
{
  printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
   numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
}
/* Izracun absolutne razlike med vrednostjo funkcije in kvadratne parabole
skozi p1,p2 in p3 v tocki p4: */
sqrcoefrelval(p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a2,&a1,&a0);
er=fabs( fsqr(p4->x-p3->x)+p3->f - p4->f );
/* Izracun maksimalne dovoljene napake na zacetku: */
maxstep=h/2;
df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
if (df>dx)
  maxer=0.4*safety*df;  /* 0.4 je dodat. var. faktor */
else
  maxer=safety*sqrt(dx*df);
if (er>maxer)
{
  fact=0.5*maxer/er;
  if (fact<0.05)
    fact=0.05;
  maxstep*=fact;
}
if (prn)
  printf("dx=%g, df=%g,\ner=%g, maxer=%g, maxstep=%g\n",dx,df,er,maxer,maxstep);
/* Ekstrapolacijsko napako poskusamo s krcenjem intervala spraviti pod
dovoljeno: */
while (er>maxer)
{
  *x=p4->x; *y=p4->f;
  ++numit;
  /* Varovalka,  da nismo ze pod tolerancami - v tem primeru je numericni
  sum prevelik */
  if (tolx && m_maxval(fabs(p1->x-p2->x),fabs(p2->x-p4->x))<tolx)
  {
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Exceeding x-tolerance (%g) while struggling for safety accuracy.\n",tolx);
    fprintf(erf(),"Function is either too noisy or to wild.\n");
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -1;
  } else if (toly && m_maxval(fabs(p1->f-p2->f),fabs(p2->f-p4->f))<toly)
  {
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Exceeding y-tolerance (%g) while struggling for safety accuracy.\n",toly);
    fprintf(erf(),"Function seems to be too wild, please decrease tolerances.\n");
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -2;
  } else if (numit>maxit)
  {
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Maximum number of iterations (%i) exceeded while struggling for safety accuracy.\n",maxit);
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -3;
  }
  if (0)  /* STAREJSA VERZIJA */
  {
  /* Leva in desna meja: */
  pleft.x=minval4(p1->x,p2->x,p3->x,p4->x);
  pright.x=maxval4(p1->x,p2->x,p3->x,p4->x);
  if (pleft.x==p1->x) pleft=*p1; else if (pleft.x==p2->x) pleft=*p2;
   else if (pleft.x==p3->x) pleft=*p3; else pleft=*p4;
  if (pright.x==p1->x) pright=*p1; else if (pright.x==p2->x) pright=*p2;
   else if (pright.x==p3->x) pright=*p3; else pright=*p4;
  p=getfuncptdata1(0);
  p->x=p1->x+maxstep;
  /* Preprecimo, da bi bila tocka p preblizu p1, p2, p3 ali p4: */
  if (fabs((p->x-p2->x)*(p->x-p1->x))<1e-3*m_sqr(p2->x-p1->x))
    p->x=0.5*(p1->x+p2->x);
  if (fabs((p->x-p3->x)*(p->x-p2->x))<1e-3*m_sqr(p3->x-p2->x))
    p->x=0.5*(p2->x+p3->x);
  if (fabs((p->x-p4->x)*(p->x-p3->x))<1e-3*m_sqr(p4->x-p3->x))
    p->x=0.5*(p3->x+p4->x);
  p->f=func(p->x); ++numeval;
  inssortstack(st,(void *) p,cmpfuncptdata1);
  /* Izracun absolutne razlike vrednosti kubicne parabole skozi p1, p2, p3 in
  p4 in funkcije v tocki p: */
  cubcoefrelval(p4->x,p4->f,p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a3,&a2,&a1,&a0);
  er=fabs( fcub(p->x-p4->x)+p4->f - p->f );
  /* Izracun maksimalne dovoljene napake na zacetku: */
  df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
  dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
  maxer=0.4*safety*df;  /* 0.4 je dodat. var. faktor */
  if (er>maxer)
  {
    fact=0.5*maxer/er;
    if (fact<0.05)
      fact=0.05;
    maxstep*=fact;
  }
  p1=p2; p2=p3; p3=p4; p4=p;
  if (prn)
  {
    printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
     numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
    printf("Interval: [ %g , %g ]\n",pleft.x,pright.x);
    printf("dx=%g, df=%g,\ner=%g, maxer=%g, maxstep=%g\n",dx,df,er,maxer,maxstep);
  }
  }
  
  /* Dolocimo meji intervala, ki ga razpenjajo tocke p1 ... p4 : */
  pleft.x=minval4(p1->x,p2->x,p3->x,p4->x);
  pright.x=maxval4(p1->x,p2->x,p3->x,p4->x);
  if (pleft.x==p1->x) pleft=*p1; else if (pleft.x==p2->x) pleft=*p2;
   else if (pleft.x==p3->x) pleft=*p3; else pleft=*p4;
  if (pright.x==p1->x) pright=*p1; else if (pright.x==p2->x) pright=*p2;
   else if (pright.x==p3->x) pright=*p3; else pright=*p4;
  /* Ocenimo minimalni razmah v smeri x: */
  dxmin=minval4(fabs(p3->x-p4->x),fabs(p3->x-p2->x),fabs(p2->x-p4->x),
   fabs(p2->x-p1->x));
  /* Dobimo novo tocko; Najprej dolocimo x, nato pogledamo, ce je kaksna tocka
  s tem x ali dovolj blizu ze na skladu ter vzamemo ali to tocko s sklada (ce
  obstaja) ali naredimo novo pri dolocenem x: */
  xx=p1->x+h;
  /* Preprecimo, da bi bila tocka p preblizu p1, p2, p3 ali p4: */
  if (fabs((xx-p2->x)*(xx-p1->x))<1e-3*m_sqr(p2->x-p1->x))
    xx=0.5*(p1->x+p2->x);
  if (fabs((xx-p3->x)*(xx-p2->x))<1e-3*m_sqr(p3->x-p2->x))
    xx=0.5*(p2->x+p3->x);
  if (fabs((xx-p4->x)*(xx-p3->x))<1e-3*m_sqr(p4->x-p3->x))
    xx=0.5*(p3->x+p4->x);
  /* Dolocimo sprejemljive meje, da lahko vzamemo tocko s sklada */
  l.x=xx-m_minval(dxmin,fabs(h))/5; r.x=xx+m_minval(dxmin,fabs(h))/5;
  p=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p==NULL)
  {
    p=getfuncptdata1(0);
    p->x=xx;
    p->f=func(p->x); ++numeval;
    inssortstack(st,(void *) p,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p->x);
  /* Izracun absolutne razlike vrednosti kubicne parabole skozi p1, p2, p3 in
  p4 in funkcije v tocki p: */
  cubcoefrelval(p4->x,p4->f,p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a3,&a2,&a1,&a0);
  er=fabs( fcub(p->x-p4->x)+p4->f - p->f );
  /* Izracun maksimalne dovoljene napake na zacetku: */
  df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
  dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
  maxer=0.4*safety*df;  /* 0.4 je dodat. var. faktor */
  if (er>maxer)
  {
    fact=0.5*maxer/er;
    if (fact<0.05)
      fact=0.05;
    h*=fact;
  }
  p1=p2; p2=p3; p3=p4; p4=p;
  if (prn)
  {
    printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
     numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
    printf("Interval: [ %g , %g ]\n",pleft.x,pright.x);
    printf("dx=%g, df=%g,\ner=%g, maxer=%g, h=%g\n",dx,df,er,maxer,h);
  }
  
}
if (prn)
  printf("\nAccuracy satisfactory, searching for minimum:\n\n");
/* Iterativno iskanje minimuma: */
while ((!stop) /* && numit<maxit */ )
{
  *x=p4->x; *y=p4->f;
  ++numit;
  /* Varovalka,  da nismo ze pod tolerancami - v tem primeru je numericni
  sum prevelik */
  if (tolx && m_maxval(fabs(p1->x-p3->x),fabs(p3->x-p4->x))<0.5*tolx)
  {
    /*
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Exceeding x-tolerance (%g) while struggling for accuracy.\n",tolx);
    fprintf(erf(),"Function is either too noisy or to wild.\n");
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -1;
    */
  } else if (toly && m_maxval(fabs(p1->f-p3->f),fabs(p3->f-p4->f))<toly)
  {
    /*
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Exceeding y-tolerance (%g) while struggling for accuracy.\n",toly);
    fprintf(erf(),"Function seems to be too wild, please decrease tolerances.\n");
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -2;
    */
  } else 
  if (numit>maxit)
  {
    errfunc0("min1dcubintbas");
    fprintf(erf(),"Maximum number of iterations (%i) exceeded while struggling for accuracy.\n",maxit);
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -5;
  }
  /* Dolocimo meji intervala, ki ga razpenjajo tocke p1 ... p4 : */
  pleft.x=minval4(p1->x,p2->x,p3->x,p4->x);
  pright.x=maxval4(p1->x,p2->x,p3->x,p4->x);
  if (pleft.x==p1->x) pleft=*p1; else if (pleft.x==p2->x) pleft=*p2;
   else if (pleft.x==p3->x) pleft=*p3; else pleft=*p4;
  if (pright.x==p1->x) pright=*p1; else if (pright.x==p2->x) pright=*p2;
   else if (pright.x==p3->x) pright=*p3; else pright=*p4;
  /* Ocenimo minimalni razmah v smeri x: */
  dxmin=minval4(fabs(p3->x-p4->x),fabs(p3->x-p2->x),fabs(p2->x-p4->x),
   fabs(p2->x-p1->x));
  /* koeficienti kubicne parabole relativno na tocko p4: */
  cubcoefrelval(p4->x,p4->f,p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a3,&a2,&a1,&a0);
  
  nmin=nzero=0;
  /* Najprej poiscemo nicle kubicne parabole in vzamemo prvo, ki lezi med
  pleft-fabs(maxstep) in pright+fabs(maxstep): */
  nzero=cubzeros(a3,a2,a1,a0+p4->f,&zero1,&zero2,&zero3);
  /*
  if (prn)
  {
    printf("\nZeros cub. par.: \n");
    if (nzero>=1)
      printf("( %g , %g )\n",zero1+p4->x,p4->f+fcub(zero1));
    if (nzero>=2)
      printf("( %g , %g )\n",zero2+p4->x,p4->f+fcub(zero2));
    if (nzero>=3)
      printf("( %g , %g )\n",zero3+p4->x,p4->f+fcub(zero3));
    printf("\n");
  }
  */
  zero1+=p4->x;  zero2+=p4->x;  zero3+=p4->x;
  if (nzero>=1 && zero1>pleft.x-fabs(maxstep) && zero1<pright.x+fabs(maxstep))
    ;  /* 1. nicla ustreza zahtevam */
  else if (nzero>=2 && zero2>pleft.x-fabs(maxstep) && zero2<pright.x+fabs(maxstep))
  {
    /* 2. nicla ustreza zahtevam: */
    nzero=1;
    zero1=zero2;
  } else if (nzero>=3 && zero3>pleft.x-fabs(maxstep) && zero3<pright.x+fabs(maxstep))
  {
    nzero=1;
    zero1=zero3;
  } else
    nzero=0;  /* Nobena nicla ne ustreza */
  if (!nzero /* || (p1->f<0 && p2->f<0 && p3->f<0 && p4->f<0) || 
   (p1->f>0 && p2->f>0 && p3->f>0 && p4->f>0) */ )
  {
    if (p3->f>0)
    {
      /* Ce ne najdemo nicle v ustreznem intervalu in je vrednost v p4
      vecja od 0, poiscemo minimum; Tudi, ce so vse tocke p1 ... p4 enako
      predznacene, je bolje gledati za ekstrem kot za nicle: */
      nmin=cubmin(a3,a2,a1,a0,&minx,&miny);
      minx+=p4->x; miny+=p4->f;
      if (minx>pleft.x-fabs(maxstep) && minx<pright.x+fabs(maxstep))
        nmin=1;
      else
        nmin=0;
    } else
    {
      /* Ce ne najdemo nicle v ustreznem intervalu in je vrednost v p4
      vecja od 0, poiscemo maksimum: */
      nmin=cubmax(a3,a2,a1,a0,&minx,&miny);
      minx+=p4->x; miny+=p4->f;
      if (minx>pleft.x-fabs(maxstep) && minx<pright.x+fabs(maxstep))
        nmin=1;
      else
        nmin=0;
    }
  }
  if ( nzero || nmin )
  {
    /* Kubicna parabola ima niclo ali ustrezni ekstrem znotraj intervala
    [pleft.x-fabs(maxstep),pright.x+fabs(maxstep)], novo tocko postavimo v ta
    ekstrem: */ 
    if (nzero)
      xx=zero1;
    else  /* nmin */
      xx=minx;
    /*
    if (xx==p1->x || xx==p2->x || xx==p3->x ||  xx=p4->x)
      xx+=0.05*dxmin;
    */
    l.x=xx;
    r.x=xx;
    pointinside=0;
    if (nzero && zero1>pleft.x && zero2<pright.x)
      pointinside=1;
    if (nmin && minx>pleft.x && minx<pright.x)
      pointinside=1;
  } else
  {
    /* Kub. parabola nima minimuma, ali pa ga ima in lezi izven intervala
    [pleft.x-fabs(maxstep),pright.x+fabs(maxstep)]. Interval z novo tocko
    podaljsamo v smeri nasprotni od odvoda kubicne parabole v enem od krajisc: */
    derleft=dcub(pleft.x-p4->x);
    derright=dcub(pright.x-p4->x);
    /*
    if (derleft>0)
      p->x=pleft.x-fabs(maxstep);
    else
      p->x=pright.x+fabs(maxstep);
    */
    if (derleft>0)
      xx=pleft.x-fabs(maxstep);
    else
      xx=pright.x+fabs(maxstep);
    l.x=xx-0.5*dxmin;
    r.x=xx+0.5*dxmin;
  }
  if (xx>=pleft.x && xx<=pright.x)
    extint=0;
  else
    extint=1;
  p=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p!=NULL)
    xx=p->x;
  /* Prepreciti moramo, da bi p sovpadal s p1, p2, p3 ali p4: */
  if (xx==p1->x || xx==p2->x || xx==p3->x || xx==p4->x)
  {
    xx+=0.09*dxmin;
    p=NULL;
  }
  if (p==NULL)
  {
    p=getfuncptdata1(0);
    p->x=xx;
    p->f=func(p->x); ++numeval;
    inssortstack(st,(void *) p,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p->x);
  if (prn)
  {
    printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
     numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
    printf("Interval: [ %g , %g ]\n",pleft.x,pright.x);
    /*
    printf("Cub. parabola in points (x,y,der):\n");
    printf("( %g, %g, %g )\n",p1->x,p4->f+fcub(p1->x-p4->x),dcub(p1->x-p4->x));
    printf("( %g, %g, %g )\n",p2->x,p4->f+fcub(p2->x-p4->x),dcub(p2->x-p4->x));
    printf("( %g, %g, %g )\n",p3->x,p4->f+fcub(p3->x-p4->x),dcub(p3->x-p4->x));
    printf("( %g, %g, %g )\n",p4->x,p4->f+fcub(p4->x-p4->x),dcub(p4->x-p4->x));
    */
    if (nzero)
      printf("Approp. zero cub. par.: ( %g , %g ), der:%g\n",
       zero1,p4->f+fcub(zero1-p4->x),dcub(zero1-p4->x));
    if (nmin)
      printf("Extr. cub. par.: ( %g , %g ), der:%g\n",minx,miny,dcub(minx-p4->x));
    printf("dx=%g, df=%g,\ner=%g, maxer=%g, maxstep=%g\n",dx,df,er,maxer,maxstep);
    /*
    printf("Derivative in p4: %g, left der.: %g, right der.: %g\n",a1,derleft,derright);
    */
    printf("p:      ( %g, %g )\n",p->x,p->f);
  }
  /* Izracun absolutne razlike vrednosti kubicne parabole skozi p1, p2, p3 in
  p4 in funkcije v tocki p: */
  er=fabs( fcub(p->x-p4->x)+p4->f - p->f );
  /* Izracun maksimalne dovoljene napake na zacetku: */
  df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
  dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
  /* Izracun maksimalne napake interpolacije. Ce je razmah v smeri y vecji kot
  v smeri x, se uposteva razmah v smeri y (pomnozen z varnostnim faktorjem).
  Drugace se uposteva geometricna sredina med razmahom v smeri y in v smeri x: */
  if (df>dx)
    maxer=safety*df;
  else
    maxer=safety*sqrt(dx*df);
  if (extint)
  {
    if (er>0)
    {
      fact=maxer/er;
      if (fact<0.1)
        fact=0.1;
      else if (fact>10)
        fact=10;
      maxstep*=fact;
    } else
      maxstep*=10;
  }
  if (pointinside)
  {
    /* Ustrez. nicla ali ekstrem kub. parabole je v notranjosti najmanjsega
    intervala, ki vsebuje tocke p1 ... p4. Zato moramo preveriti, da je abs.
    vrednost v p manjsa od najnizje vrednosti izmed tock p1 ... p4. Ce ni,
    potem je zelo verjetno, da je minimum zunaj intervala; Tocko p obdrzimo in
    kreiramo se eno tocko, ki je zunaj intervala: */
    val=minval4(fabs(p1->f),fabs(p2->f),fabs(p3->f),fabs(p4->f));
    if (val<fabs(p->f))
    {
      /* Vazno je, ali je nicla oz. ekstrem objet ali ne. Ce je objet, je samo
      nekaj narobe s kubicno interpolacijo in postavimo tocko p blizu tocki z
      najmanjso funkcijako vrednostjo, toda na nasprotno stran te tocke kot je
      bil prejsnji p. Ce ni objet, moramo pomozno tocko postaviti izven intervala. */
      /* Najprej tocko z najvisjo absolutno vrednostjo nadomesti p: */
      val=maxval4(fabs(p1->f),fabs(p2->f),fabs(p3->f),fabs(p4->f));
      if (fabs(p1->f)==val)
        p1=p;
      else if (fabs(p2->f)==val)
        p2=p;
      else if (fabs(p3->f)==val)
        p3=p;
      else if (fabs(p4->f)==val)
        p4=p;
      val=minval4(fabs(p1->f),fabs(p2->f),fabs(p3->f),fabs(p4->f));
      if (val<fabs(pleft.f) && val<fabs(pright.f))
      {
        /* Ce je abs. minimum objet, novo tocko p postavimo blizu tocke z
        najnizjo absolutno  vrednostjo, a na nasprotno stran kot je bila stara
        tocka p. Poskrbimo tudi, da je nova tocka blizje tocki z najnizjo
        vrednostjo kot katerakoli od ostalih tock (in da se ne pokriva s
        kaksno drugo tocko). */
        if (val==fabs(p1->f))
          xx=p1->x;
        else if (val==fabs(p2->f))
          xx=p2->x;
        else if (val==fabs(p3->f))
          xx=p3->x;
        else if (val==fabs(p4->f))
          xx=p4->x;
        if (xx!=p->x)
          xx1=xx-0.1*(p->x-xx)*fabs(dxmin/(p->x-xx));
        else
          xx1=xx+0.07*dxmin;
        if (fabs(xx1-p1->x)<=0.05*dxmin)
        {
          if (xx1<p1->x)
            xx1-=0.03*dxmin;
          else
            xx1+=0.03*dxmin;
        }
        if (fabs(xx1-p2->x)<=0.05*dxmin)
        {
          if (xx1<p2->x)
            xx1-=0.03*dxmin;
          else
            xx1+=0.03*dxmin;
        }
        if (fabs(xx1-p3->x)<=0.05*dxmin)
        {
          if (xx1<p3->x)
            xx1-=0.03*dxmin;
          else
            xx1+=0.03*dxmin;
        }
        if (fabs(xx1-p4->x)<=0.05*dxmin)
        {
          if (xx1<p4->x)
            xx1-=0.03*dxmin;
          else
            xx1+=0.03*dxmin;
        }
        l.x=xx1;
        p=ptrfindsortstack(st,&l,0,0,cmpfuncptdata1);
        if (p==NULL)
        {
          p=getfuncptdata1(0);
          p->x=xx1;
          p->f=func(p->x); ++numeval;
          inssortstack(st,(void *) p,cmpfuncptdata1);
        } else if (prn)
          printf("\nA point was picked from stack, x=%g.\n\n",p->x);
      } else  /* min. abs. vred. ni objet, zato novo tocko postavimo izven int. */
      {
        if (fabs(pleft.f)<fabs(pright.f))
        {
          xx=pleft.x-dx;
          l.x=xx-0.1*dx; r.x=xx+0.5*dx;
        } else
        {
          xx=pright.x+dx;
          l.x=xx-0.5*dx; r.x=xx+0.1*dx;
        }
        p=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
        if (p==NULL)
        {
          p=getfuncptdata1(0);
          p->x=xx;
          p->f=func(p->x); ++numeval;
          inssortstack(st,(void *) p,cmpfuncptdata1);
        } else if (prn)
          printf("\nA point was picked from stack, x=%g.\n\n",p->x);
      }
    }
  }
  /* Poskrbeti moramo, da se zamenja s p tocka, ki ima najvisjo absolutno
  funkcijsko vrednost: */
  val=maxval4(fabs(p1->f),fabs(p2->f),fabs(p3->f),fabs(p4->f));
  if (fabs(p1->f)==val)
    p1=p;
  else if (fabs(p2->f)==val)
    p2=p;
  else if (fabs(p3->f)==val)
    p3=p;
  else if (fabs(p4->f)==val)
    p4=p;
  /* stop se postavi na 1, izracunajo se napake vrednosti kot maksimum razlike
  v p3 in p4 ter razlike v p3 in kub. parabole v nicli oz. ekstremu. Ce
  kaksni od specifiranih toleranc ni zadosceno, se stop postavi na 0: */
  stop=1;
  if (tolx>0)
  {
    erx=1000*tolx;
    if (nzero)
      erx=m_maxval(fabs(p3->x-p4->x),fabs(p3->x-zero1));
    else if (nmin)
      erx=m_maxval(fabs(p3->x-p4->x),fabs(p3->x-minx));
    if (erx>tolx)
      stop=0;
    if (prn)
    {
      if (erx<tolx)
        printf("x tolerance satisfied. ");
      printf("x error: %g (tol. %g)\n",erx,tolx);
    }
  }
  if (stop && fabs(p4->x)<=toly)
    ;  /* V primeru nicel lahko toleranco ultimativno preverimo po abs. vred. */
  else if (toly>0)
  {
    ery=1000*toly;
    if (nzero)
      ery=m_maxval(fabs(p3->f-p4->f),fabs(p3->f));
    else if (nmin)
      ery=m_maxval(fabs(p3->f-p4->f),fabs(p3->f-miny));
    if (ery>toly)
      stop=0;
    if (prn)
    {
      if (ery<toly)
        printf("y tolerance satisfied. ");
      printf("y error: %g (tol. %g)\n",ery,toly);
    }
  }
  
}
*x=p4->x;
*y=p4->f;
if (nzero)
{
  p4->flagzero=1;  /* Zastavica za niclo */
  if (prn)
    printf("\nCalculated zero: ( %g , %g ).\n\n",*x,*y);
} else if (nmin)
{
  
  if (fabs(miny) < m_maxval(fabs(p3->x-p4->x),fabs(p2->x-p4->x)) )
  {
    /* Ceprav smo na kub. paraboli nasli le ustrezen ekstrem, so pogoji taksni,
    da ga lahko priznamo za niclo: */
    p4->flagzero=1;  /* Zastavica za niclo */
    if (prn)
      printf("\nCalculated zero (multiple): ( %g , %g ).\n\n",*x,*y);
  } else if (p4->f>0 && p3->f>0)
  {
    p4->flagmin=1;
    if (prn)
      printf("\nCalculated minimum instead of zero: ( %g , %g ).\n\n",*x,*y);
  } else if (p4->f<0 && p3->f<0)
  {
    p4->flagmax=0;
    if (prn)
      printf("\nCalculated maximum instead of zero: ( %g , %g ).\n\n",*x,*y);
  }
}
if (pmin!=NULL)
  *pmin=p4;
if (itcnt!=NULL) *itcnt+=numit;
return 0;
#undef flin
#undef fsqr
#undef fcub
#undef dsqr
#undef dcub
}































static void setfuncdatastackflags(stack st,double closetol)
    /* Postavi zastavice za minimume, maksimume in ekstreme za funkcijske
    vrednosti, ki so nalozene na skladu st kot objekti tipa funcptdata1.
    Funkcija tudi zbrise tiste tocke, ki so si preblizu skupaj; pri tem je
    closetol relativna toleranca za dovoljeno blizino: ce je interval med
    zaporednima tockama manj kot closetol krat prejsnji interval, se desno
    krajisce intervala brise. Ce je closetol 0, se brisejo le identicne tocke.
    Primerna vrednost za closetol je 1e-3 (odvisno sicer od suma, s katerim je
    obremenjena funkcija).
    $A Igor maj01; */
{
funcptdata1 p,prev,post;
double a2,a1,a0,minx,miny;
int nmin,i;
if (st!=NULL)
{
  if (closetol<0)
    closetol=-closetol;
  prev=st->s[1];  p=st->s[2];  post=st->s[3];
  while (st->n>3 && ( p->x-prev->x < closetol*(post->x-prev->x) ) )
  {
    delstack(st,1);
    dispfuncptdata1(&prev);
    prev=st->s[1];  p=st->s[2];  post=st->s[3];
  }
  if (st->n>0)
  {
    p=st->s[1];
    p->flagmin=p->flagmax=p->flagzero=0;
    p=st->s[st->n];
    p->flagmin=p->flagmax=p->flagzero=0;
  }
  for (i=2;i<=st->n-1;++i)  /* identifikacija tock, ki so blizu ekstremom */
  {
    prev=st->s[i-1];  p=st->s[i];  post=st->s[i+1];
    if ( post->x-p->x <= closetol* (post->x-prev->x))
    {
      /* Zbrisejo se tocke, ki so preblizu skupaj: */
      delstack(st,i+1);
      dispfuncptdata1(&post);
    } else
    {
      p->flagmin=p->flagmax=p->flagzero=0;
      if (p->f>=prev->f && p->f>=post->f)
        p->flagmax=1;
      else if (p->f<=prev->f && p->f<=post->f)
        p->flagmin=1;
    }
  }
  for (i=2;i<=st->n-1;++i)  /* identifikacija tock, ki so blizu niclam */
  {
    prev=st->s[i-1];  p=st->s[i];  post=st->s[i+1];
    if (p->f*prev->f<=0)
    {
      if (fabs(p->f)<fabs(prev->f))
        p->flagzero=1;
      else
        prev->flagzero=1;
    } else if ( (p->flagmax || p->flagmin) && 
     !(p->flagzero || prev->flagzero || post->flagzero) )
    {
      /* Preveriti je treba, ce lahko ekstrem predstavlja veckratno niclo: */
      if ( fabs(p->f) <= fabs(p->f-prev->f)+fabs(p->f-post->f) ) 
        p->flagzero=1;
      else
      {
        /* Po funkcijskih vrednostih treh tock ni ocitno, da bi lahko ekstrem
        predstavljal niclo, zato preverimo se vrednost po kvadratni
        interpolaciji: */
        sqrcoefrelval(prev->x,prev->f,p->x,p->f,post->x,post->f,&a2,&a1,&a0);
        if (p->flagmin)
          nmin=sqrmin(a2,a1,a0,&minx,&miny);
        else
          nmin=sqrmax(a2,a1,a0,&minx,&miny);
        if (nmin)
        {
          miny+=prev->f;
          if (miny*p->f<=0)
            p->flagzero=1;
          else if ( fabs(miny) <= fabs(p->f-prev->f)+fabs(p->f-post->f) )
            p->flagzero=1;
        }
      }
    }
  }
}
}


int scan1dcubintbas(double (*func)(double),double from,double to,double h,
       double safety,double tolx,int maxit,funcptdata1 p1,funcptdata1 p2,
       funcptdata1 p3,funcptdata1 p4,stack *addrst,int *itcnt,char prn)
    /*
    
      VAZNE OPOMBE:
     Ce so na skladu *addrst ob klicu ze kaksne tocke, naj bi bile sortirane
    po narascajocem x (drugace jih funkcija tudi sama sortira). Funkcija da
    vse nove tocke na sklad tako, da so sortirane po x.
     Vse tocke, ki so morebiti ze na skladu *addrst ob klicu funkcije, morajo
    biti obvezno taksne, da se lahko brisejo (npr. s funkcijo dispfuncptdata1),
    ker sama funkcija na sklad nalaga na novo alocirane tocke, ki se morajo
    brisati nekje izven funkcije.
     Ce so podane tocke p1, ... p4, naj bi bile prve tri tocke sortirane po
    padajocih funkcijskih vrednostih (vsaj performancno je bolje tako).
     Ce posebej za to funkcijo alociramo katero od tock p1 ... p4, je pametno
    dati le-te na sklad *addrst, ker ta sklad vsebuje tocke, ki se lahko
    brisejo. Funkcija sama ne skrbi za to, da so te tocke tudi na skladu, da
    se lahko te tocke obravnavajo loceno od ostalih.
    $A Igor apr01; */
{
#define flin(x) ( a1*(x)+a0 )
#define fsqr(x) ( a2*m_sqr(x)+a1*(x)+a0 )
#define fcub(x) ( a3*m_cube(x)+a2*m_sqr(x)+a1*(x)+a0 )
#define dsqr(x) ( 2*a2*(x)+a1 )
#define dcub(x) ( 3*a3*m_sqr(x)+2*a2*(x)+a1 )

_funcptdata1 *p=NULL,pleft,pright,l,r;
double maxer,er,dx=0,df=0,dxmin,fact,
       a3,a2,a1,a0,xx;
char stop=0,reversedir=0;
int numit=0,numeval=0,i;
stack st;
if (addrst==NULL)
{
  errfunc0("scan1dcubintbas");
  fprintf(erf(),"Address of stack not specified.\n",tolx);
  errfunc2();
  if (itcnt!=NULL) *itcnt+=numit;
  return -10;
}
if (*addrst==NULL)
  *addrst=newstack(10);
st=*addrst;
qsortstack(st,cmpfuncptdata1);
if (maxit<=0)
  maxit=1000;
if (safety<0)
  safety=-safety;
if (safety==0)
  safety=0.05;
if (safety>0.5)
  safety=0.5;
if (h==0)
  h=1e-1;
/* Najprej vzamemo h pozitiven: */
h=fabs(h);
if (tolx<0) tolx=-tolx;
if (h==0)
  h=1e-1;
/* Najprej se izracuna stiri tocke, ki se postavijo v enakomernih razmikih: */
if (p1==NULL)
{
  xx=from;
  l.x=xx-0.1*fabs(h);
  r.x=xx+0.1*fabs(h);
  p1=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p1==NULL)
  {
    p1=getfuncptdata1(0);
    p1->x=xx;
    p1->f=func(p1->x); ++numeval;
    inssortstack(st,(void *) p1,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p1->x);
}
if (p2==NULL)
{
  xx=p1->x+h;
  l.x=xx-0.1*fabs(h);
  r.x=xx+0.1*fabs(h);
  p2=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p2==NULL)
  {
    p2=getfuncptdata1(0);
    p2->x=xx;
    p2->f=func(p2->x); ++numeval;
    inssortstack(st,(void *) p2,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p2->x);
}
if (p3==NULL)
{
  xx=p2->x+h;
  /* Preprecimo, da bi bil p3 preblizu p2 ali p1, ce slucajno p3 ne lezi
  izven intervala, ki ga omejujeta p1 in p2: */
  if ((xx-p2->x)*(xx-p1->x)<=0)
    xx=p2->x+0.5*(p2->x-p1->x);
  l.x=r.x=xx;
  p3=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p3==NULL)
  {
    p3=getfuncptdata1(0);
    p3->x=xx;
    p3->f=func(p3->x); ++numeval;
    inssortstack(st,(void *) p3,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p3->x);
}
if (p4==NULL)
{
  xx=p3->x+h;
  /* Preprecimo, da bi bil p4 preblizu p1, p2 ali p3, ce slucajno p3 ne lezi
  izven intervala, ki ga omejujeta p1 in p2: */
  if ((xx-p3->x)*(xx-p2->x)<=0)
    xx=p3->x+0.5*(p3->x-p2->x);
  if ((xx-p3->x)*(xx-p1->x)<=0)
    xx=p3->x+0.25*(p3->x-p1->x);
  l.x=r.x=xx;
  p4=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p4==NULL)
  {
    p4=getfuncptdata1(0);
    p4->x=xx;
    p4->f=func(p4->x); ++numeval;
    inssortstack(st,(void *) p4,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p4->x);
}
if (prn)
{
  printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
   numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
}
/* Izracun absolutne razlike med vrednostjo funkcije in kvadratne parabole
skozi p1,p2 in p3 v tocki p4: */
sqrcoefrelval(p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a2,&a1,&a0);
er=fabs( fsqr(p4->x-p3->x)+p3->f - p4->f );
df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
if (df>dx)
  maxer=0.4*safety*df;  /* 0.4 je dodat. var. faktor */
else
  maxer=safety*sqrt(dx*df);
if (er>maxer)
{
  fact=0.5*maxer/er;
  if (fact<0.05)
    fact=0.05;
  h*=fact;
}
if (prn)
  printf("dx=%g, df=%g,\ner=%g, maxer=%g, h=%g\n",dx,df,er,maxer,h);
if (p1->x>from && p2->x>from && p3->x>from && p4->x>from)
  reversedir=1;
/* Ekstrapolacijsko napako poskusamo s krcenjem intervala spraviti pod
dovoljeno: */
while (er>maxer)
{
  ++numit;
  /* Varovalka,  da nismo ze pod tolerancami - v tem primeru je numericni
  sum prevelik */
  if (tolx && m_maxval(fabs(p1->x-p2->x),fabs(p2->x-p4->x))<tolx)
  {
    errfunc0("scan1dcubintbas");
    fprintf(erf(),"Exceeding x-tolerance (%g) while struggling for safety accuracy.\n",tolx);
    fprintf(erf(),"Function is either too noisy or too wild.\n");
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -1;
  } 
  /* Dolocimo meje intervala, ki ga razpenjajo tocke p1 ... p4 : */
  pleft.x=minval4(p1->x,p2->x,p3->x,p4->x);
  pright.x=maxval4(p1->x,p2->x,p3->x,p4->x);
  if (pleft.x==p1->x) pleft=*p1; else if (pleft.x==p2->x) pleft=*p2;
   else if (pleft.x==p3->x) pleft=*p3; else pleft=*p4;
  if (pright.x==p1->x) pright=*p1; else if (pright.x==p2->x) pright=*p2;
   else if (pright.x==p3->x) pright=*p3; else pright=*p4;
  /* Ocenimo minimalni razmah v smeri x: */
  dxmin=minval4(fabs(p3->x-p4->x),fabs(p3->x-p2->x),fabs(p2->x-p4->x),
   fabs(p2->x-p1->x));
  /* Dobimo novo tocko; Najprej dolocimo x, nato pogledamo, ce je kaksna tocka
  s tem x ali dovolj blizu ze na skladu ter vzamemo ali to tocko s sklada (ce
  obstaja) ali naredimo novo pri dolocenem x: */
  xx=p1->x+h;
  /* Preprecimo, da bi bila tocka p preblizu p1, p2, p3 ali p4: */
  if (fabs((xx-p2->x)*(xx-p1->x))<1e-3*m_sqr(p2->x-p1->x))
    xx=0.5*(p1->x+p2->x);
  if (fabs((xx-p3->x)*(xx-p2->x))<1e-3*m_sqr(p3->x-p2->x))
    xx=0.5*(p2->x+p3->x);
  if (fabs((xx-p4->x)*(xx-p3->x))<1e-3*m_sqr(p4->x-p3->x))
    xx=0.5*(p3->x+p4->x);
  /* Dolocimo sprejemljive meje, da lahko vzamemo tocko s sklada */
  l.x=xx-m_minval(dxmin,fabs(h))/5; r.x=xx+m_minval(dxmin,fabs(h))/5;
  p=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p==NULL)
  {
    p=getfuncptdata1(0);
    p->x=xx;
    p->f=func(p->x); ++numeval;
    inssortstack(st,(void *) p,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p->x);
  /* Izracun absolutne razlike vrednosti kubicne parabole skozi p1, p2, p3 in
  p4 in funkcije v tocki p: */
  cubcoefrelval(p4->x,p4->f,p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a3,&a2,&a1,&a0);
  er=fabs( fcub(p->x-p4->x)+p4->f - p->f );
  /* Izracun maksimalne dovoljene napake na zacetku: */
  df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
  dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
  maxer=0.4*safety*df;  /* 0.4 je dodat. var. faktor */
  if (er>maxer)
  {
    fact=0.5*maxer/er;
    if (fact<0.05)
      fact=0.05;
    h*=fact;
  }
  p1=p2; p2=p3; p3=p4; p4=p;
  if (prn)
  {
    printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
     numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
    printf("Interval: [ %g , %g ]\n",pleft.x,pright.x);
    printf("dx=%g, df=%g,\ner=%g, maxer=%g, h=%g\n",dx,df,er,maxer,h);
  }
}
if (prn)
  printf("\nAccuracy satisfactory, searching for minimum:\n\n");
/* Iterativno iskanje minimuma: */
while ((!stop) /* && numit<maxit */ )
{
  ++numit;
  /* Varovalka,  da nismo ze pod tolerancami - v tem primeru je numericni
  sum prevelik */
  if (tolx && m_maxval(fabs(p1->x-p3->x),fabs(p3->x-p4->x))<0.5*tolx)
  {
    errfunc0("scan1dcubintbas");
    fprintf(erf(),"Exceeding x-tolerance (%g) while struggling for accuracy.\n",tolx);
    fprintf(erf(),"Function is either too noisy or to wild.\n");
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -1;
  } else 
  if (numit>maxit)
  {
    errfunc0("scan1dcubintbas");
    fprintf(erf(),"Maximum number of iterations (%i) exceeded.\n",maxit);
    errfunc2();
    if (itcnt!=NULL) *itcnt+=numit;
    return -5;
  }
  /* Dolocimo meje intervala, ki ga razpenjajo tocke p1 ... p4 : */
  pleft.x=minval4(p1->x,p2->x,p3->x,p4->x);
  pright.x=maxval4(p1->x,p2->x,p3->x,p4->x);
  if (pleft.x==p1->x) pleft=*p1; else if (pleft.x==p2->x) pleft=*p2;
   else if (pleft.x==p3->x) pleft=*p3; else pleft=*p4;
  if (pright.x==p1->x) pright=*p1; else if (pright.x==p2->x) pright=*p2;
   else if (pright.x==p3->x) pright=*p3; else pright=*p4;
  /* Ocenimo minimalni razmah v smeri x: */
  /*
  dxmin=minval4(fabs(p3->x-p4->x),fabs(p3->x-p2->x),fabs(p2->x-p4->x),
   fabs(p2->x-p1->x));
  */
  /* Koeficienti kubicne parabole relativno na tocko p4: */
  cubcoefrelval(p4->x,p4->f,p3->x,p3->f,p2->x,p2->f,p1->x,p1->f,&a3,&a2,&a1,&a0);
  /* Dobimo novo tocko; Najprej dolocimo x, nato pogledamo, ce je kaksna tocka
  s tem x ali dovolj blizu ze na skladu ter vzamemo ali to tocko s sklada (ce
  obstaja) ali naredimo novo pri dolocenem x: */
  xx=pright.x+h;
  /* Sprejemljive meje, da lahko vzamemo tocko s sklada */
  l.x=pright.x+0.1*h;
  r.x=xx+0.05*h;
  p=ptrfindsortstacklim(st,&l,&r,0,0,cmpfuncptdata1);
  if (p==NULL)
  {
    p=getfuncptdata1(0);
    p->x=xx;
    p->f=func(p->x); ++numeval;
    inssortstack(st,(void *) p,cmpfuncptdata1);
  } else if (prn)
    printf("\nA point was picked from stack, x=%g.\n\n",p->x);
  if (prn)
  {
    printf("\n%i. it. (%i eval.):\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n  ( %-12g, %12g )\n",
     numit,numeval,p1->x,p1->f,p2->x,p2->f,p3->x,p3->f,p4->x,p4->f);
    printf("Interval: [ %g , %g ]\n",pleft.x,pright.x);
    printf("p:      ( %g, %g )\n",p->x,p->f);
  }
  /* Izracun absolutne razlike vrednosti kubicne parabole skozi p1, p2, p3 in
  p4 in funkcije v tocki p: */
  er=fabs( fcub(p->x-p4->x)+p4->f - p->f );
  /* Izracun maksimalne dovoljene napake na zacetku: */
  df=m_maxval(fabs(p3->f-p2->f),fabs(p3->f-p4->f));
  dx=m_maxval(fabs(p3->x-p2->x),fabs(p3->x-p4->x));
  /* Izracun maksimalne napake interpolacije. Ce je razmah v smeri y vecji kot
  v smeri x, se uposteva razmah v smeri y (pomnozen z varnostnim faktorjem).
  Drugace se uposteva geometricna sredina med razmahom v smeri y in v smeri x: */
  if (df>dx)
    maxer=safety*df;
  else
  maxer=safety*sqrt(dx*df);
  if (er>maxer)
    fact=0.1;
  else if (er==0)
    fact*=10;
  else
  {
    if (er<=0.5*maxer)
      fact=sqrt((0.5*maxer)/er);
    else
      fact=m_sqr((0.5*maxer)/er);
    if (fact<0.2)
      fact=0.2;
    else if (fact>4)
      fact=4;
  }
  h*=fact;
  if (er<2*maxer)
  {
    p1=p2; p2=p3; p3=p4; p4=p;
    if (p4->x>=to || p4->x<=from)
      stop=1;
  }
  if (prn)
  {
    printf("dx=%-10g, df=%g\ner=%g, maxer=%g, h=%g\n",
     dx,df,er,maxer,h);
  }
}
/* Ce bi slucajno zaceli kje v sredini, je potrebno seskenirati v obratni
smeri: */
if (reversedir && numit<maxit)
{
  if (st->n>3)
  {
    p1=st->s[4];
    p2=st->s[3];
    p3=st->s[2];
    p4=st->s[1];
    h=p4->x-p3->x;
  } else if (st->n>2)
  {
    p1=st->s[3];
    p2=st->s[2];
    p3=st->s[1];
    p4=NULL;
    h=p3->x-p2->x;
  } else if (st->n>1)
  {
    p1=st->s[2];
    p2=st->s[1];
    p3=p4=NULL;
    h=p2->x-p1->x;
  } else
  {
    /* Ce ima st najvec en element, uporabimo raje kar tocke p1 ... p4; Treba je
    samo obrniti h. */
    h=-h;
  }
  return scan1dcubintbas(func,from,to,h,safety,tolx,maxit,p1,p2,
   p3,p4,addrst,itcnt,prn);
}
/* Pregleda se, ce smo nasli kaksna izhodisca za minimume, maksimume in nicle;
Izlocijo se tudi tocke, ki so preblizu skupaj: */
setfuncdatastackflags(st,0);
if (prn)
{
  printf("Evaluated points:\n");
  for (i=1;i<=st->n;++i)
  {
    p=st->s[i];
    printf("%4i:  ( %-10g, %10g )",i,p->x,p->f);
    if (p->flagmin)
      printf(" min. ");
    if (p->flagmax)
      printf(" max. ");
    if (p->flagzero)
      printf(" zero. ");
    printf("\n");
  }
  printf("\n\n");
}
if (itcnt!=NULL) *itcnt+=numit;
return 0;
#undef flin
#undef fsqr
#undef fcub
#undef dsqr
#undef dcub
}



static void printstpoints(stack st)
{
funcptdata1 p;
int i;
if (st!=NULL)
{
  printf("Evaluated points:\n");
  for (i=1;i<=st->n;++i)
  {
    p=st->s[i];
    printf("%4i:  ( %-10g, %10g )",i,p->x,p->f);
    if (p->flagmin)
      printf(" min. ");
    if (p->flagmax)
      printf(" max. ");
    if (p->flagzero)
      printf(" zero. ");
    printf("\n");
  }
}
}



void plotcubintfuncptlim(stack points,double (*func1) (double x),
       double (*func2) (double x),int n);


void scan1dcubintbasint(double (*func)(double),double from,double to,double h,
       double safety,double tolx,int maxit,funcptdata1 p1,funcptdata1 p2,
       funcptdata1 p3,funcptdata1 p4,stack *addrst,int *itcnt,char prn)
    /* Preskenira funkcijo func podobno kot scan1dcubintbasint, le da dela
    interaktivno in poleg tega se bolj natancno poisce minimume, maksimume
    in nicle. Argumenti so isti kot pri scan1dcubintbas().
    $A Igor apr01; */
{
int plot,print,i,n1,n2,n3;
double x,y,tlx,tly,tlder;
funcptdata1 p,pp;
stack st=NULL;
printf("\n\nScanning the function...\n");
scan1dcubintbas(func,from,to,h,safety,tolx,maxit,p1,p2,p3,p4,addrst,itcnt,prn);
if (addrst!=NULL)
  st=*addrst;
setfuncdatastackflags(st,0);
if (st==NULL)
{
  printf("No points evaluated! Press <Return> to continue!");
  readdouble(&x);
} else if (st->n==0)
{
  printf("No points evaluated! Press <Return> to continue!");
  readdouble(&x);
} else
{
  printf("\n\nRough estimation of minima, maxima and zeros:\n");
  n1=n2=n3=0;
  for (i=1;i<=st->n;++i)
  {
    p=st->s[i];
    if (p->flagmin)
    {
      printf("Minimum near ( %-10g, %10g )\n",i,p->x,p->f);
      ++n1;
    }
    if (p->flagmax)
    {
      printf("Maximum near ( %-10g, %10g )\n",i,p->x,p->f);
      ++n2;
    }
    if (p->flagzero)
    {
      printf("Zero near    ( %-10g, %10g )\n",i,p->x,p->f);
      ++n3;
    }
  }
  if (n1==0)
    printf("No minima detected.\n");
  if (n2==0)
    printf("No maxima detected.\n");
  if (n3=0)
    printf("No zeros detected.\n");
  printf("\nPrint evaluated points (0/1)? ");  readint(&print);
  if (print)
  {
    printf("Evaluated points:\n");
    for (i=1;i<=st->n;++i)
    {
      p=st->s[i];
      printf("%4i:  ( %-10g, %10g )",i,p->x,p->f);
      if (p->flagmin)
        printf(" min. ");
      if (p->flagmax)
        printf(" max. ");
      if (p->flagzero)
        printf(" zero. ");
      printf("\n");
    }
  }
  printf("\nPlot function on the basis of evaluated points (0/1)? ");
  readint(&plot);
  if (plot)
  {
    printf("Plot the true function together with interpolation (0/1)? ");
    readint(&plot);
    n1=50;
    printf("Number of points: "); readint(&n1);
    if (plot)
      plotcubintfuncptlim(st,func,NULL,n1);
    else
      plotcubintfuncptlim(st,NULL,NULL,n1);
  }
  printf("\nWould you like to change the safety factoror or / and\n");
    printf("limits and scan the function again (0/1)? ");
  readint(&n1);
  if (n1)
  {
    printf("Safety factor (now %g): ",safety); readdouble(&safety);
    printf("Left limit (now %g)   : ",from); readdouble(&from);
    printf("Right limit (now %g)  : ",to); readdouble(&to);
    scan1dcubintbasint(func,from,to,h,safety,tolx,maxit,p1,p2,p3,p4,addrst,itcnt,prn);
    return;
  }
  printf("\n\nWould you like to evaluate minima more exactly (0/1)? ");
  readint(&n1);
  if (n1)
  {
    printf("Tolerance for x: "); readdouble(&tlx);
    printf("Tolerance for y: "); readdouble(&tly);
    printf("Tolerance for derivative: "); readdouble(&tlder);
    printf("Evaluating minima...\n");
    if (st->n>3)
    {
      for (i=st->n;i>=1;--i)
      {
        p=st->s[i];
        if (p->flagmin)
        {
          n1=i-2;
          while (n1<1) ++n1;
          while (n1>st->n-3) --n1;
          p1=st->s[n1];
          p2=st->s[n1+1];
          p3=st->s[n1+2];
          p4=st->s[n1+3];
          p->flagmin=0;
          printf("\nEvaluating minimum near ( %-10g, %10g ) ...\n",p->x,p->f);
          printf("Press <Return>!\n"); readint(&n1);
          n1=min1dcubintbas(func,p4->x,(p4->x-p3->x)/4,safety,tlx,tly,tlder,
           maxit,p1,p2,p3,p4,&x,&y,addrst,&pp,itcnt,prn);
          if (!n1)
          {
            printf("\n\nMore exact minimum: ( %-10g, %10g ).\n",x,y);
            if (!(pp->flagmin))
            {
              printf("Warning: flagmin is not set for min. point.\n");
               /* Zastavica za minimum se spet postavi pri prvotni tocki: */
              p->flagmin=1;
            }
          } else
            printf("Evaluation was not successful.\n");
        }
      }
      printf("\nEvaluation of minima done.\n");
    } else
      printf("Can not perform evlauation: less than 4 points on the stack.\n");
  }
  printf("\n\nWould you like to evaluate maxima more exactly (0/1)? ");
  readint(&n2);
  if (n2)
  {
    printf("Tolerance for x: "); readdouble(&tlx);
    printf("Tolerance for y: "); readdouble(&tly);
    printf("Tolerance for derivative: "); readdouble(&tlder);
    printf("Evaluating maxima...\n");
    if (st->n>3)
    {
      for (i=st->n;i>=1;--i)
      {
        p=st->s[i];
        if (p->flagmax)
        {
          n1=i-2;
          while (n1<1) ++n1;
          while (n1>st->n-3) --n1;
          p1=st->s[n1];
          p2=st->s[n1+1];
          p3=st->s[n1+2];
          p4=st->s[n1+3];
          p->flagmax=0;
          printf("\nEvaluating maximum near ( %-10g, %10g ) ...\n",p->x,p->f);
          printf("Press <Return>!\n"); readint(&n1);
          n1=max1dcubintbas(func,p4->x,(p4->x-p3->x)/4,safety,tlx,tly,tlder,
           maxit,p1,p2,p3,p4,&x,&y,addrst,&pp,itcnt,prn);
          if (!n1)
          {
            printf("\n\nMore exact maximum: ( %-10g, %10g ).\n",x,y);
            if (!(pp->flagmax))
            {
              printf("Warning: flagmax is not set for max. point.\n");
              /* Zastavica za maksimum se spet postavi pri prvotni tocki: */
              p->flagmax=1;
            }
          } else
            printf("Evaluation was not successful.\n");
        }
      }
      printf("\nEvaluation of maxima done.\n");
    } else
      printf("Can not perform evlauation: less than 4 points on the stack.\n");
  }
  printf("\n\nWould you like to evaluate zeros more exactly (0/1)? ");
  readint(&n3);
  if (n3)
  {
    printf("Tolerance for x: "); readdouble(&tlx);
    printf("Tolerance for y: "); readdouble(&tly);
    printf("Evaluating zeros...\n");
    if (st->n>3)
    {
      for (i=st->n;i>=1;--i)
      {
        p=st->s[i];
        if (p->flagzero)
        {
          n1=i-2;
          while (n1<1) ++n1;
          while (n1>st->n-3) --n1;
          p1=st->s[n1];
          p2=st->s[n1+1];
          p3=st->s[n1+2];
          p4=st->s[n1+3];
          p->flagzero=0;
          printf("\nEvaluating zero near ( %-10g, %10g ) ...\n",p->x,p->f);
          printf("Press <Return>!\n"); readint(&n1);
          n1=zero1dcubintbas(func,p4->x,(p4->x-p3->x)/4,safety,tlx,tly,
           maxit,p1,p2,p3,p4,&x,&y,addrst,&pp,itcnt,prn);
          if (!n1)
          {
            printf("\n\nMore exact zero: ( %-10g, %10g ).\n",x,y);
            if (!(pp->flagzero))
            {
              printf("Warning: flagzero is not set for min. point.\n");
              /* Zastavica za niclo se spet postavi pri prvotni tocki: */
              p->flagzero=1;
            }
          } else
            printf("Evaluation was not successful.\n");
        }
      }
      printf("\nEvaluation of zeros done.\n");
    } else
      printf("Can not perform evlauation: less than 4 points on the stack.\n");
  }
  setfuncdatastackflags(st,0);
  printf("\n\nEstimation of minima, maxima and zeros:\n");
  n1=n2=n3=0;
  for (i=1;i<=st->n;++i)
  {
    p=st->s[i];
    if (p->flagmin)
    {
      printf("Minimum at ( %-10g, %10g )\n",i,p->x,p->f);
      ++n1;
    }
    if (p->flagmax)
    {
      printf("Maximum at ( %-10g, %10g )\n",i,p->x,p->f);
      ++n2;
    }
    if (p->flagzero)
    {
      printf("Zero at    ( %-10g, %10g )\n",i,p->x,p->f);
      ++n3;
    }
  }
  if (n1==0)
    printf("No minima detected.\n");
  if (n2==0)
    printf("No maxima detected.\n");
  if (p3=0)
    printf("No zeros detected.\n");
  printf("\nPrint evaluated points (0/1)? ");  readint(&print);
  if (print)
  {
    printf("Evaluated points:\n");
    for (i=1;i<=st->n;++i)
    {
      p=st->s[i];
      printf("%4i:  ( %-10g, %10g )",i,p->x,p->f);
      if (p->flagmin)
        printf(" min. ");
      if (p->flagmax)
        printf(" max. ");
      if (p->flagzero)
        printf(" zero. ");
      printf("\n");
    }
  }
  printf("\nPlot function on the basis of evaluated points (0/1)? ");
  readint(&plot);
  if (plot)
  {
    printf("Plot the true function together with interpolation (0/1)? ");
    readint(&plot);
    n1=50;
    printf("Number of points: "); readint(&n1);
    if (plot)
      plotcubintfuncptlim(st,func,NULL,n1);
    else
      plotcubintfuncptlim(st,NULL,NULL,n1);
  }
  printf("\nWould you like to change the safety factoror or / and limits and scan \n");
    printf("the function again (0/1; 0 will exit the scanning process)? ");
  readint(&n1);
  if (n1)
  {
    printf("Safety factor (now %g): ",safety); readdouble(&safety);
    printf("Left limit (now %g)   : ",from); readdouble(&from);
    printf("Right limit (now %g)  : ",to); readdouble(&to);
    scan1dcubintbasint(func,from,to,h,safety,tolx,maxit,p1,p2,p3,p4,addrst,itcnt,prn);
    return;
  }
}
printf("Delete points from the stack (0/1)? ");  readint(&n1);
if (n1)
  dispstackvalspec(st,(void (*)(void **)) dispfuncptdata1);
}



double cubinttabval(vector px,vector py,double x)
    /* Vrne intrerpolirano vrednost funkcije v tocki x, kjer so v vektorjih
    px in py vrednosti abscis in ordinat tock na grafu funkcije. Vrednost
    interpolira s kupicno parabolo skozi stiri sosednje tocke tocki x iz
    tabele. Dimenziji px in py se morata ujemati in morata biti najmanj 4,
    da se lahko uporabi kubicno interpolacijo. Ce je tock manj, se uporabi
    interpolacijo nizjega reda.
    $A Igor mar01; */
{
#define fcub(x) ( a3*m_cube(x)+a2*m_sqr(x)+a1*(x)+a0 )
#define fsqr(x) ( a2*m_sqr(x)+a1*(x)+a0 )
#define flin(x) ( a1*(x)+a0 )
double ret=0,a3,a2,a1,a0;
static int ileft=1;
int i1=1,i2=2,i3=3,i4=4;
if (px!=NULL && py!=NULL && px->d==py->d)
{
  if (px->d==3)
  {
    /* Izracunajo se koeficienti kvadratne interpolacije skozi tri tocke tabele ter
    vrednost kubicne interpolacije v tocki x: */
    sqrcoefrelval(px->v[i1],py->v[i1],px->v[i2],py->v[i2],px->v[i3],py->v[i3],
     &a2,&a1,&a0);
    ret=py->v[i1]+fsqr(x-px->v[i1]);
  } else if (px->d==2)
  {
    /* Izracunajo se koeficienti linearne interpolacije skozi dve tocki tabele
    ter vrednost linearne interpolacije v tocki x: */
    lincoefrelval(px->v[i1],py->v[i1],px->v[i2],py->v[i2],&a1,&a0);
    ret=py->v[i1]+flin(x-px->v[i1]);
  } else if (px->d==1)
    ret=py->v[1];
  else
  {
    if (ileft>px->d || ileft<1)
      ileft=1;
    /* Najprej postane ileft indeks zadnje tocke, katere abscisa je manjsa
    od x (ce ni taksne tocke pa 1): */
    while (ileft<px->d && px->v[ileft]<x)
      ++ileft;
    while (ileft>1 && px->v[ileft]>x)
      --ileft;
    /* Potem se dolocijo indeksi stirih tock v tabeli, ki so blizu abscisi x.
    To so tocke s prvo in drugo manjso ter prvo in drugo vecjo absciso, ce
    obstajajo, drugace pa so to krajne tocke intervala: */
    if (ileft<=2)
    {
      i1=1;  i2=2;  i3=3;  i4=4;
    } else if (ileft>=px->d-2)
    {
      i1=px->d-3; i2=px->d-2; i3=px->d-1; i4=px->d;
    } else
    {
      i1=ileft-1; i2=ileft; i3=ileft+1; i4=ileft+2;
    }
    /* Izracunajo se koeficienti interpolacije skozi stiri tocke tabele z
    indeksi i1, i2, i3 in i4 ter vrednost kubicne interpolacije v tocki x: */
    cubcoefrelval(px->v[i1],py->v[i1],px->v[i2],py->v[i2],px->v[i3],py->v[i3],
     px->v[i4],py->v[i4],&a3,&a2,&a1,&a0);
    ret=py->v[i1]+fcub(x-px->v[i1]);
  }
}
return ret;
#undef fcub
#undef fsqr
#undef flin
}



/* Pomozne spremenljivke in fukcija za funkcijo plotcubintvecsimp */
static vector auxx=NULL,auxy=NULL;

static double auxintval(double x)
{
return cubinttabval(auxx,auxy,x);
}

void plotcubintfuncvec(vector x,vector y,double (*func1) (double x),
       double (*func2) (double x),double from,double to,int n)
    /* Narise (na tekstovni zaslon) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana z vektorjema abscis x in ordinat y,
    od from do to z n izrisanimi tockami. Ce je func1 ali func2 NULL, potem
    ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). FUNKCIJA DELA INTERAKTIVNO.
    $A Igor mar01; */
{
auxx=x; auxy=y;
drawfuncsimp(auxintval,func1,func2,from,to,n);
}

void plotcubintfuncveclim(vector x,vector y,double (*func1) (double x),
       double (*func2) (double x),int n)
    /* Narise (na tekstovni zaslon) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana z vektorjema abscis x in ordinat y,
    z n izrisanimi tockami. Ce je func1 ali func2 NULL, potem ustrezne funkcije
    ne izrise. Za interpolacijo uporabi funkcijo cubinttabval(). Za meje grafa
    vzame abscisi prve in zadnje tocke v vektorjih.
    FUNKCIJA DELA INTERAKTIVNO.
    $A Igor mar01; */
{
auxx=x; auxy=y;
if (auxx!=NULL)
  if (auxx->d>0)
    drawfuncsimp(auxintval,func1,func2,auxx->v[1],auxx->v[auxx->d],n);
}

void fplotcubintfuncvec(vector x,vector y,double (*func1) (double x),
       double (*func2) (double x),double from,double to,int n,FILE *fp)
    /* Narise (v tekst. datoteko fp) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana z vektorjema abscis x in ordinat y,
    od from do to z n izrisanimi tockami. Ce je func1 ali func2 NULL, potem
    ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). FUNKCIJA DELA INTERAKTIVNO.
    $A Igor mar01; */
{
auxx=x; auxy=y;
fdrawfuncsimp(auxintval,func1,func2,from,to,n,fp);
}

void fplotcubintfuncveclim(vector x,vector y,double (*func1) (double x),
       double (*func2) (double x),int n,FILE *fp)
    /* Narise (v tekst. datoteko fp) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana z vektorjema abscis x in ordinat y,
    z n izrisanimi tockami. Ce je func1 ali func2 NULL, potem ustrezne
    funkcije ne izrise. Za interpolacijo uporabi funkcijo cubinttabval().
    Za meje grafa vzame abscisi prve in zadnje tocke.
    FUNKCIJA DELA INTERAKTIVNO.
    $A Igor mar01; */
{
auxx=x; auxy=y;
if (auxx!=NULL)
  if (auxx->d>0)
    fdrawfuncsimp(auxintval,func1,func2,auxx->v[1],auxx->v[auxx->d],n,fp);
}

void fplotcubintfuncpt(stack points,double (*func1) (double x),
       double (*func2) (double x),double from,double to,int n,FILE *fp)
    /* Narise (v datoteko fp) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana s tabelo tock tipa funcptdata1 na
    skladu points, od from do to z n izrisanimi tockami. Ce je func1 ali func2
    NULL, potem ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). FUNKCIJA DELA INTERAKTIVNO.
    $A Igor mar01; */
{
funcptdata1 pt;
int i;
vector x=NULL,y=NULL;
/* Abscise in ordinate tock iz grafa funkcije se najprej prepisejo v vektorja
x in y: */
if (points!=NULL)
  if (points->n>0)
  {
    x=getvector(points->n);
    y=getvector(points->n);
    for (i=1;i<=x->d;++i)
    {
      pt=(funcptdata1) points->s[i];
      x->v[i]=pt->x;
      y->v[i]=pt->f;
    }
  }
fplotcubintfuncvec(x,y,func1,func2,from,to,n,fp);
dispvector(&x);
dispvector(&y);
}

void fplotcubintfuncptlim(stack points,double (*func1) (double x),
       double (*func2) (double x),int n,FILE *fp)
    /* Narise (v datoteko fp) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana s tabelo tock tipa funcptdata1 na
    skladu points, z n izrisanimi tockami. Ce je func1 ali func2 NULL, potem
    ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). Za meje vzame abscise prve in zadnje tocke.
    FUNKCIJA DELA INTERAKTIVNO.
    $A Igor mar01; */
{
funcptdata1 pt;
int i;
vector x=NULL,y=NULL;
/* Abscise in ordinate tock iz grafa funkcije se najprej prepisejo v vektorja
x in y: */
if (points!=NULL)
  if (points->n>0)
  {
    x=getvector(points->n);
    y=getvector(points->n);
    for (i=1;i<=x->d;++i)
    {
      pt=(funcptdata1) points->s[i];
      x->v[i]=pt->x;
      y->v[i]=pt->f;
    }
  }
fplotcubintfuncveclim(x,y,func1,func2,n,fp);
dispvector(&x);
dispvector(&y);
}

void plotcubintfuncpt(stack points,double (*func1) (double x),
       double (*func2) (double x),double from,double to,int n)
    /* Narise (na tekstovni zaslon) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana s tabelo tock tipa funcptdata1 na
    skladu points, od from do to z n izrisanimi tockami. Ce je func1 ali func2
    NULL, potem ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). FUNKCIJA DELA INTERAKTIVNO.
    $A Igor mar01; */
{
fplotcubintfuncpt(points,func1,func2,from,to,n,NULL);
}

void plotcubintfuncptlim(stack points,double (*func1) (double x),
       double (*func2) (double x),int n)
    /* Narise (na tekstovni zaslon) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana s tabelo tock tipa funcptdata1 na
    skladu points,  z n izrisanimi tockami. Ce je func1 ali func2
    NULL, potem ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). Za meje vzame abscise prve in zadnje tocke.
    FUNKCIJA DELA INTERAKTIVNO.
    $A Igor mar01; */
{
fplotcubintfuncptlim(points,func1,func2,n,NULL);
}




void plotcubintfuncveccont(vector x,vector y,double (*func1) (double x),
       double (*func2) (double x),double from,double to,int n)
    /* Narise (na tekstovni zaslon) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana z vektorjema abscis x in ordinat y,
    od from do to z n izrisanimi tockami. Ce je func1 ali func2 NULL, potem
    ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). Funkcija ne dela interaktivno!
    $A Igor mar01; */
{
auxx=x; auxy=y;
drawfuncsimpcont(auxintval,func1,func2,from,to,n);
}

void plotcubintfuncveccontlim(vector x,vector y,double (*func1) (double x),
       double (*func2) (double x),int n)
    /* Narise (na tekstovni zaslon) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana z vektorjema abscis x in ordinat y,
    z n izrisanimi tockami. Ce je func1 ali func2 NULL, potem
    ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). Za meji vzame abscisi prve in zadnje tocke.
    Funkcija ne dela interaktivno!
    $A Igor mar01; */
{
auxx=x; auxy=y;
if (auxx!=NULL)
  if (auxx->d>0)
    drawfuncsimpcont(auxintval,func1,func2,auxx->v[1],auxx->v[auxx->d],n);
}

void fplotcubintfuncveccont(vector x,vector y,double (*func1) (double x),
       double (*func2) (double x),double from,double to,int n,FILE *fp)
    /* Narise (v tekst. datoteko fp) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana z vektorjema abscis x in ordinat y,
    od from do to z n izrisanimi tockami. Ce je func1 ali func2 NULL, potem
    ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). Funkcija ne dela interaktivno!
    $A Igor mar01; */
{
auxx=x; auxy=y;
fdrawfuncsimpcont(auxintval,func1,func2,from,to,n,fp);
}

void fplotcubintfuncveccontlim(vector x,vector y,double (*func1) (double x),
       double (*func2) (double x),int n,FILE *fp)
    /* Narise (v tekst. datoteko fp) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana z vektorjema abscis x in ordinat y,
    z n izrisanimi tockami. Ce je func1 ali func2 NULL, potem
    ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). Za meji vzame abscisi prve in zadnje tocke.
    Funkcija ne dela interaktivno!
    $A Igor mar01; */
{
auxx=x; auxy=y;
if (auxx!=NULL)
  if (auxx->d>0)
    fdrawfuncsimpcont(auxintval,func1,func2,auxx->v[1],auxx->v[auxx->d],n,fp);
}

void fplotcubintfuncptcont(stack points,double (*func1) (double x),
       double (*func2) (double x),double from,double to,int n,FILE *fp)
    /* Narise (v datoteko fp) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana s tabelo tock tipa funcptdata1 na
    skladu points, od from do to z n izrisanimi tockami. Ce je func1 ali func2
    NULL, potem ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). Funkcija ne dela interaktivno!
    $A Igor mar01; */
{
funcptdata1 pt;
int i;
vector x=NULL,y=NULL;
/* Abscise in ordinate tock iz grafa funkcije se najprej prepisejo v vektorja
x in y: */
if (points!=NULL)
  if (points->n>0)
  {
    x=getvector(points->n);
    y=getvector(points->n);
    for (i=1;i<=x->d;++i)
    {
      pt=(funcptdata1) points->s[i];
      x->v[i]=pt->x;
      y->v[i]=pt->f;
    }
  }
fplotcubintfuncveccont(x,y,func1,func2,from,to,n,fp);
dispvector(&x);
dispvector(&y);
}

void fplotcubintfuncptcontlim(stack points,double (*func1) (double x),
       double (*func2) (double x),int n,FILE *fp)
    /* Narise (v datoteko fp) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana s tabelo tock tipa funcptdata1 na
    skladu points, z n izrisanimi tockami. Ce je func1 ali func2
    NULL, potem ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). Za meji vzame abscisi prve in zadnje tocke.
    Funkcija ne dela interaktivno!
    $A Igor mar01; */
{
funcptdata1 pt;
int i;
vector x=NULL,y=NULL;
/* Abscise in ordinate tock iz grafa funkcije se najprej prepisejo v vektorja
x in y: */
if (points!=NULL)
  if (points->n>0)
  {
    x=getvector(points->n);
    y=getvector(points->n);
    for (i=1;i<=x->d;++i)
    {
      pt=(funcptdata1) points->s[i];
      x->v[i]=pt->x;
      y->v[i]=pt->f;
    }
  }
fplotcubintfuncveccontlim(x,y,func1,func2,n,fp);
dispvector(&x);
dispvector(&y);
}

void plotcubintfuncptcont(stack points,double (*func1) (double x),
       double (*func2) (double x),double from,double to,int n,FILE *fp)
    /* Narise (na tekstovni zaslon) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana s tabelo tock tipa funcptdata1 na
    skladu points, od from do to z n izrisanimi tockami. Ce je func1 ali func2
    NULL, potem ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). Funkcija ne dela interaktivno!
    $A Igor mar01; */
{
fplotcubintfuncptcont(points,func1,func2,from,to,n,NULL);
}

void plotcubintfuncptcontlim(stack points,double (*func1) (double x),
       double (*func2) (double x),int n,FILE *fp)
    /* Narise (na tekstovni zaslon) funkciji func1 in func2 ter kubicno
    interpolirano funkcije, ki je podana s tabelo tock tipa funcptdata1 na
    skladu points, z n izrisanimi tockami. Ce je func1 ali func2
    NULL, potem ustrezne funkcije ne izrise. Za interpolacijo uporabi funkcijo
    cubinttabval(). Za meji vzame abscisi prve in zadnje tocke.
    Funkcija ne dela interaktivno!
    $A Igor mar01; */
{
fplotcubintfuncptcontlim(points,func1,func2,n,NULL);
}






static int cmpdouble(void *p1,void *p2)
{
double *d1=p1,*d2=p2;
if (*d1<*d2)
  return -1;
else if (*d1>*d2)
  return 1;
else
  return 0;
}

static void testfindlim(void)
{
stack st;
double r=1,*p,left,right;
int place,i;
st=newstack(10);
while (r!=0)
{
  printf("New number:  "); readdouble(&r);
  printf("Left limit:  "); readdouble(&left);
  printf("Right limit: "); readdouble(&right);
  printf("\n\n");
  p=malloc(sizeof(*p));
  *p=r;
  inssortstack(st,p,cmpdouble);
  place=findsortstacklim(st,&left,&right,0,0,cmpdouble);
  printf("Stack elements:\n");
  for (i=1;i<=st->n;++i)
  {
    p=st->s[i];
    printf("%4i: %g\n",i,*p);
  }
  printf("\n");
  if (place<1)
    printf("Appropriate element not found.\n");
  else
  {
    p=st->s[place];
    printf("Appropriate element:\n");
    printf("%4i: %g\n",place,*p);
  }
  printf("\n\n");
}
}

char *ig_getmachinestr(void);


int main(void)
{

stack st=NULL,st1=NULL;
int *i,j,k,m,n=100,tab[5];
void *ptr;
double x,y,z,start=4,h=0.1,safety=1e-1,tolx=1e-3,toly=1e-6,tolder=0.005,
       from=0,to=5;
int maxit=100,np=20;
vector vx,vy,vz;
char prn=1;
void *ptr1,*ptr2;
char *str,*str1,*str2,*str3,*str4,*str5;
long ll;


/* GETTING THE SYSTEM IDENTIFICATION STRING: */
if (0)
{
  printf("System identification string: \n\n\"%s\"\n\n",ig_getmachinestr());
  exit(0);
}

/* SOME FILE UTILITIES FROM fop.h: */

if (0)
{
  str1="home";
  str2="users";
  str3="";
  str4="igor";
  str5="a1.doc";
  str=multdirplusmultfile(str1,str2,str3,NULL,str4,str5,NULL);
  if (str1==NULL) printf("str1 is NULL.\n");
  if (str2==NULL) printf("str2 is NULL.\n");
  if (str3==NULL) printf("str3 is NULL.\n");
  if (str4==NULL) printf("str4 is NULL.\n");
  if (str5==NULL) printf("str5 is NULL.\n");
  printf("str1=\"%s\"\nstr2=\"%s\"\nstr3=\"%s\"\nstr4=\"%s\"\nstr5=\"%s\"\n",
   str1,str2,str3,str4,str5);
  if (str==NULL) printf("str is NULL.\n");
  printf("File name: \"%s\"\n\n",str);



  str1="/home";
  str2="users/";
  str3="/a/";
  str4="/igor/";
  str5="a1.doc";
  str=multdirplusmultfile(str1,str2,str3,NULL,str4,str5,NULL);
  if (str1==NULL) printf("str1 is NULL.\n");
  if (str2==NULL) printf("str2 is NULL.\n");
  if (str3==NULL) printf("str3 is NULL.\n");
  if (str4==NULL) printf("str4 is NULL.\n");
  if (str5==NULL) printf("str5 is NULL.\n");
  printf("str1=\"%s\"\nstr2=\"%s\"\nstr3=\"%s\"\nstr4=\"%s\"\nstr5=\"%s\"\n",
   str1,str2,str3,str4,str5);
  if (str==NULL) printf("str is NULL.\n");
  printf("File name: \"%s\"\n\n",str);


  str1="home";
  str2="users/";
  str3="";
  str4="igor/";
  str5="a1.doc";
  str=multdirplusmultfile(str1,str2,str3,NULL,str4,str5,NULL);
  if (str1==NULL) printf("str1 is NULL.\n");
  if (str2==NULL) printf("str2 is NULL.\n");
  if (str3==NULL) printf("str3 is NULL.\n");
  if (str4==NULL) printf("str4 is NULL.\n");
  if (str5==NULL) printf("str5 is NULL.\n");
  printf("str1=\"%s\"\nstr2=\"%s\"\nstr3=\"%s\"\nstr4=\"%s\"\nstr5=\"%s\"\n",
   str1,str2,str3,str4,str5);
  if (str==NULL) printf("str is NULL.\n");
  printf("File name: \"%s\"\n\n",str);


  str1="";
  str2="";
  str3="";
  str4="igor/";
  str5="a1.doc/";
  str=multdirplusmultfile(str1,str2,str3,NULL,str4,str5,NULL);
  if (str1==NULL) printf("str1 is NULL.\n");
  if (str2==NULL) printf("str2 is NULL.\n");
  if (str3==NULL) printf("str3 is NULL.\n");
  if (str4==NULL) printf("str4 is NULL.\n");
  if (str5==NULL) printf("str5 is NULL.\n");
  printf("str1=\"%s\"\nstr2=\"%s\"\nstr3=\"%s\"\nstr4=\"%s\"\nstr5=\"%s\"\n",
   str1,str2,str3,str4,str5);
  if (str==NULL) printf("str is NULL.\n");
  printf("File name: \"%s\"\n\n",str);


  str1="home";
  str2="users";
  str3="";
  str4="";
  str5="";
  str=multdirplusmultfile(str1,str2,str3,NULL,str4,str5,NULL);
  if (str1==NULL) printf("str1 is NULL.\n");
  if (str2==NULL) printf("str2 is NULL.\n");
  if (str3==NULL) printf("str3 is NULL.\n");
  if (str4==NULL) printf("str4 is NULL.\n");
  if (str5==NULL) printf("str5 is NULL.\n");
  printf("str1=\"%s\"\nstr2=\"%s\"\nstr3=\"%s\"\nstr4=\"%s\"\nstr5=\"%s\"\n",
   str1,str2,str3,str4,str5);
  if (str==NULL) printf("str is NULL.\n");
  printf("File name: \"%s\"\n\n",str);

  exit(0);
}




/* KONVERZIJA MED NIZI IN STEVILI: */

if (0)
{
  /*
  str="  \n\t  1.43e-4  ";
  x=strtod(str,&str1);
  printf("\nstr: \"%s\"\nstr1: \"%s\"\nx: %g\n\n",str,str1,x);

  str="    -1.43E-4.  ";
  x=strtod(str,&str1);
  printf("\nstr: \"%s\"\nstr1: \"%s\"\nx: %g\n\n",str,str1,x);

  str="    1.43e-4  ";
  x=strtod(str,&str1);
  printf("\nstr: \"%s\"\nstr1: \"%s\"\nx: %g\n\n",str,str1,x);
  */

  str="  \n\t  1.43e-4  ";
  ll=strtol(str,&str1,0);
  printf("\nstr: \"%s\"\nstr1: \"%s\"\nll: %li\n\n",str,str1,ll);


  str="  \n\t  -0238  ";
  ll=strtol(str,&str1,0);
  printf("\nstr: \"%s\"\nstr1: \"%s\"\nll: %li\n\n",str,str1,ll);

  str="  \n\t  -0xf 38  ";
  ll=strtol(str,&str1,0);
  printf("\nstr: \"%s\"\nstr1: \"%s\"\nll: %li\n\n",str,str1,ll);

  str="  \n\t  -0Xa0Bcfx 38  ";
  ll=strtol(str,&str1,0);
  printf("\nstr: \"%s\"\nstr1: \"%s\"\nll: %li\n\n",str,str1,ll);


  printf("\n\nLong string representation of a number:\n%.100lg\n",0.0000000000000000000000001/3);

  exit(1);
}







/* TESTIRANJE FUNKCIJ ZA SKENIRANJE FUNKCIJ ENE SPREMENLJIVKE: */

/*
democalcdeffunc();
*/
demotestfunc1d();

if (1)
{
  double from=-5,to=5;
  int n=100;
  choosfunc1dderint();
  printf("Data for graph:\n");
  printf("Left limit:       "); readdouble(&from);
  printf("Right limit:      "); readdouble(&to);
  printf("number of points: "); readint(&n);
  fdrawfuncsimp(testfunc1d,NULL,NULL,from,to,n,NULL);
  fdrawfuncsimp(testder1d,testnumder1d,NULL,from,to,n,NULL);
  exit(1);

  /*
  vx=getvector(np);
  vy=getvector(np);
  for (j=1;j<=vx->d;++j)
  {
    x=0.1*j;
    y=func0(x);
    vx->v[j]=x;
    vy->v[j]=y;
  }
  for (j=1;j<=vx->d;++j)
  {
    z=cubinttabval(vx,vy,vx->v[j]);
    printf("%12g %12g %12g\n",
     vx->v[j],vy->v[j],z);
  }

  printf("Vector X:\n");
  printvector(vx);
  printf("Vector Y:\n");s
  printvector(vy);
  plotcubintfuncvec(vx,vy,func0,NULL,vx->v[1],vx->v[vx->d],2*np);
  drawfuncsimp(NULL,func0,NULL,vx->v[1],vx->v[vx->d],2*np);
  */

  /*
  min1dcubint1(func,start,h,safety,tolx,toly,tolder,maxit,&x,&y);
  */
  /*
  max1dcubintbas(func1d,start,h,safety,tolx,toly,tolder,maxit,
         NULL,NULL,NULL,NULL,&x,&y,&st,NULL,NULL,prn);
  plotcubintfuncptlim(st,func1d,NULL,25);
  */


  st=NULL;
  tolx=1e-6;
  maxit=500;
  safety=0.1;
  from=-5;
  to=5;

  /*
  scan1dcubintbas(func,from,to,h,safety,tolx,maxit,NULL,NULL,NULL,NULL,&st,
                  NULL,prn);
  plotcubintfuncptlim(st,func,NULL,30);
  */

  scan1dcubintbasint(testfunc1d,from,to,h,safety,tolx,maxit,NULL,NULL,NULL,NULL,&st,
                  NULL,prn);

}







if (0) /* testi funkcij iz numut.c */
{
  if (0)
  {
    inspsqrval(1,0,2,-1,4,0);
    inspsqrval(1,0,2,5,4,0);
  
    inspsqrval(12.3e6,0.23,14.21e6,1004,21.5e6,-6.32);
  
    inspcubval(12.3e6,0.23,14.21e6,1004,21.5e6,-6.32,22.7e6,36.7);
    inspcubval(-10,0, -5,20, 3,0, 4,0);
    inspcubval(-1,-1, 0,0, 1,1, 2,8-0.000001);
  }

  /*
  inspsqrvalder(1,5,-8,4,5,8);
  inspsqrvalder(1,5,8,4,6,-8);

  inspcubvalder(-1,-1,3,1,1,3);
  inspcubvalder(-2,0,-5,3,1,10);
  */


  if (0)
  {
    inspcubvalder(2,0,3,4,2,3); /* ena enojna nicla, p=0 */
    inspcubvalder(5,0,0,6,1,3); /* ena trojna nicla, p=0 */
    inspcubvalder(2,0.1,0,4,10,0); /* ena enojna nicla, p<0,d>0 */
    inspcubval(0,1,1,3,2,11,3,31); /* Ena enojna nicla, p>0 */
  }




  if (0)
  {
    inspcubvalder(2,0,0,4,0,8); /* dvojna in enojna nicla, p<0,d<=0 */
    inspcubvalder(2,0,-8,4,0,0); /* enojna in dvojna nicla, p<0,d<=0 */

    inspcubvalder(2,0,-8,4,0,-9);  /* tri nicle, p<0,d<=0 */
  }

  exit(1);

}



/* ISKANJE PO SKLADIH: */
if (0)
{

  tab[0]=3;
  tab[1]=5;
  tab[2]=10;
  tab[3]=11;
  tab[4]=12;

  /*
  j=11;
  i=(void *) bsearch(&j,tab,5,sizeof(int),ipcmp);
  printf("Nasel stevilo %i.\n\n",*(int *)i);
  exit(1);
  */

  st=newstack(10);
  st1=newstack(10);

  i=malloc(sizeof(*i));
  *i=5;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-1;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=100;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=120;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=60;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=1;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-2;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-2;
  pushstack(st,i);

  i=malloc(sizeof(*i));
  *i=40;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-110;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=502;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=20;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=13;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-30;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=8;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-8;
  pushstack(st,i);

  i=malloc(sizeof(*i));
  *i=54;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=532;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=14;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-43;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=75;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=87;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-43;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=65;
  pushstack(st,i);

  i=malloc(sizeof(*i));
  *i=-75;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-753;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=0;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=51;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=73;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-32;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=-2;
  pushstack(st,i);
  i=malloc(sizeof(*i));
  *i=16;
  pushstack(st,i);


  for (j=1;j<=st->n;++j)
  {
    int place;
    printf("Mesto: %i\n",placesortstack(st1,st->s[j],ipcmp));
    insstack(st1,st->s[j],placesortstack(st1,st->s[j],ipcmp));
  }


  pst(st1);

  pst(st);
  npopstack(st,0);

  numcmp=0;
  qsortstack(st,ipcmp);
  printf("Sortiran sklad (stevilo primerjav: %i, dimenzija:%i)\n",numcmp,st->n);
  pst(st);




  numcmp=0;
  qsortstack(st,ipcmp);
  printf("Sortiran sklad (stevilo primerjav: %i, dimenzija:%i)\n",numcmp,st->n);
  pst(st);

  printf("Iskanje po sortiranem skladu:\n\n");



  j=5;
  numcmp=0;
  n=findsortstack(st,&j,20,26,ipcmp);
  printf("Mesto stevila %i je %i (izvedenih %i primerjav).\n",j,n,numcmp);
  numcmp=0;
  if (ptrfindsortstack(st,&j,0,0,ipcmp)==st->s[n])
    printf("Rezultat ptrfindsortstack se s tem ujema, oprevljenih %i primerjav.\n",
           numcmp);
  else
    printf("Rezultat ptrfindsortstack se s tem NE ujema (oprevljenih %i primerjav)!\n",numcmp);
  numcmp=0;
  ptr=standptrfindsortstack(st,&j,0,0,ipcmp);
  if (ptr==st->s[n])
    printf("Rezultat standptrfindsortstack se s tem ujema, oprevljenih %i primerjav.\n",
           numcmp);
  else
    printf("Rezultat standptrfindsortstack se s tem NE ujema (oprevljenih %i primerjav)!\n",numcmp);




  j=1;
  while(j!=0)
  {
    printf("j = ");
    scanf("%i",&j);
    printf("\n");
    numcmp=0;
    n=findsortstack(st,&j,20,27,ipcmp);
    printf("Mesto stevila %i je %i (izvedenih %i primerjav).\n",j,n,numcmp);
    numcmp=0;
    if (ptrfindsortstack(st,&j,20,27,ipcmp)==st->s[n])
      printf("Rezultat ptrfindsortstack se s tem ujema, oprevljenih %i primerjav.\n",
             numcmp);
    else
      printf("Rezultat ptrfindsortstack se s tem NE UJEMA (oprevljenih %i primerjav)!\n",numcmp);
    numcmp=0;
    ptr=standptrfindsortstack(st,&j,20,27,ipcmp);
    if (ptr==st->s[n])
      printf("Rezultat standptrfindsortstack se s tem ujema, oprevljenih %i primerjav.\n",
             numcmp);
    else
      printf("Rezultat standptrfindsortstack se s tem NE UJEMA (oprevljenih %i primerjav)!\n",numcmp);
    printf("\n\n");  
    printf("Na skladu bi imel element mesto %i.\n",placesortstackint(st,&j,20,27,ipcmp));
  }


  exit(1);

  fwritehexcolor(stdout,1,1,1);
  fwritehexcolor(stdout,0.15,0.5,0.75);
  fwritehexcolor(stdout,0.1,0.8,0);
}










}







