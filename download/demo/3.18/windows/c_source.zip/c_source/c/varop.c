/* MANIPULACIJA Z UPORABNISKO DEFINIRANIMI SPREMENLJIVKAMI */



#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>

#include <mtypes.h>
#include <st.h>
#include <strop.h>
#include <er.h>
#include <varop.h>



int VT_NUMTYPES=VT_PREDEF;  /* The number of defined types */


/* POMOZNE FUNKCIJE ZA TESTIRANJE IN DEBAGIRANJE; PO TESTIRANJU JE TREBA
TE FUNKCIJE ZBRISATI!!! */

static void pindst(stack st)
    /* Prints indices on the stack st.
    $A Igor nov02; */
{
int *ip,i;
if (st==NULL)
  printf("NULL");
else if (st->n<1)
  printf("No indices on stack.");
else for (i=1;i<=st->n;++i)
{
  ip=st->s[i];
  printf("%i  ",*ip);
}
printf("\n");
}

void printvarholder(varholder);

static void pvar(varholder var)
    /* Izpise osnovne podatke o var.
    $A Igor nov02;  */
{
printvarholder(var);
}

#include <vec.h>

void printvarholderspec(varholder v,void printel(void *));

static void pvec(varholder var)
    /* Prints vectors that reside on the varholder var.
    $A Igor nov02;  */
{
printvarholderspec(var,(void (*)(void *))printvectorline);
}

static void pst(stack st)
    /* Prints data about all varholders that are on the stack st.
    $A Igor nov02;  */
{
int i;
if (st==NULL)
  printf("Stack is NULL.\n");
else if (st->n<1)
  printf("No holders on stack\n");
else for (i=1;i<=st->n;++i)
  pvar(st->s[i]);
}

static stack s=NULL;




/**************************************************************

                        BASIC FUNCTIONS

***************************************************************/




     /* OLDER VERSIONS (mainly out of date) */

char *makestindspecstring(stack st)
    /* Vrne niz, ki je reprezentacija indeksne specifikacije na sklatu st.
    Niz se lahko brise s free(). Indeksi na skladu st morajo biti tipa int *.
    Zastarela, uporabljaj makeindspecstring.
    $A Igor jan99; */
{
int *ip,i;
char spec[1000];
if (st==NULL)
  sprintf(spec,"[]");
else if (st->n<1)
  sprintf(spec,"[]");
else
{
  sprintf(spec,"[");
  if (st->n>0)
    for (i=1;i<=st->n;++i)
    {
      ip=st->s[i];
      sprintf(spec,"%i",*ip);
      if (i<st->n)
        sprintf(spec,",");
    }
  sprintf(spec,"]");
}
sprintf(spec,"\0");
return stringcopy(spec);
}

void fprintstindspec(FILE *fp,stack st)
    /* Izpise indekse na skladu st v oglatem oklepaju in z vejicami v datoteko
    fp. Indeksi na skladu st morajo biti tipa int *.
    Zastarela; Uporabljati fprintindspec!
    $A Igor jan99; */
{
int *ip,i;
if (st==NULL)
  fprintf(fp,"[]");
else if (st->n<1)
  fprintf(fp,"[]");
else
{
  fprintf(fp,"[");
  if (st->n>0)
    for (i=1;i<=st->n;++i)
    {
      ip=st->s[i];
      fprintf(fp,"%i",*ip);
      if (i<st->n)
        fprintf(fp,",");
    }
  fprintf(fp,"]");
}
}

void printstindspec(stack st)
    /* Izpise indekse na skladu st v oglatem oklepaju in z vejicami na
    standardni izhod. Indeksi na skladu st morajo biti tipa int *.
    Zastarela; uporabljati printindspec!
    $A Igor jan99; */
{
fprintstindspec(stdout,st);
}

void sprintstindspec(char *ptr,stack st)
    /* Prints comma separated indices on the stack st in square brackets on the
    string ptr, which must provide enough space for this task. Indices on the
    stack must be of the type int *.
    Zastarela, uporabljaj sprintindspec!
    $A Igor nov02; */
{
int *ip,i;
char *str=ptr;
if (ptr!=NULL)
{
  if (st==NULL)
    sprintf(str,"[]");
  else if (st->n<1)
    sprintf(str,"[]");
  else
  {
    sprintf(str,"[");  str+=strlen(str);
    if (st->n>0)
      for (i=1;i<=st->n;++i)
      {
        ip=st->s[i];
        sprintf(str,"%i",*ip);  str+=strlen(str);
        if (i<st->n)
        {
          sprintf(str,",");  str+=strlen(str);
        }
      }
    sprintf(str,"]");
  }
}
}

char equalvardimstack(varholder var,stack st)
    /* Vrne 1, ce se dimenzije objekta var ujemajo z dimenzijami, ki so na
    skladu st, drugace pa 0. Elementi sklada st morajo biti tipa int *.
    Zastarela. Uporabljaj equalvardimit.
    $A Igor feb98; */
{
char ret;
int *ip,i;
if (var==NULL)
  ret=0;
else
{
  if (st==NULL)
  {
    if (var->rank<1)
      ret=1;
    else
      ret=0;
  } else if (st->n<1)
  {
    if (var->rank<1)
      ret=1;
    else
      ret=0;
  } else
  {
    if (var->rank!=st->n || var->dim==NULL)
      ret=0;
    else
    {
      ret=1;
      for (i=1;ret&&i<=var->rank;++i)
      {
        ip=st->s[i];
        if (*ip!=var->dim[i])
          ret=0;
      }
    }
  }
}
return ret;
}

varholder newvarholderst(stack dim)
    /* Alocira prostor za novo spreemnljivko tipa varholder in vrne kazalec
    nanjo. Na skladu dim morajo biti dimenzije spremenljivke, za katero bomo
    uporabili vrnjen kazalec (s tem so dopuscene tabelaricne spremenljivke
    poljubnega reda in dimenzij, npr. 3x2x5). Ce je sklad dim enak NULL, se
    vrnjen kazalec pripravi na sprejem ene same vrednosti, ne tabele.
    Objekt tipa varholder, ki ga funkcija vrne, ima ze pripravljeno tabelo
    kazalcev, kamor se lahko nalozijo kazalci na vrednosti vsebujocih
    spremenljivk (...->v), (...)->rank je postavljen na rang tabele (je enak 0,
    ce gre za eno samo vrednost in ne za tabelo), v (...)->rank pa so dimenzije
    tabele.
    $A Igor dec97; */
{
varholder ret=NULL;
if (dim==NULL)
{
  ret=malloc(sizeof(*ret));
  ret->name=NULL;
  ret->type=VT_UNDEF;
  ret->rank=0;
  ret->dim=NULL;
  ret->v=malloc(sizeof(void *));
  --ret->v;
  ret->v[1]=NULL;
} else
{
  if (dim->n<1)
    ret=newvarholderst(NULL);
  else
  {
    int wholedim=1,i,*d;
    ret=malloc(sizeof(*ret));
    ret->name=NULL;
    ret->rank=0;
    ret->dim=malloc(dim->n*sizeof(*(ret->dim)) );
    --ret->dim;
    for (i=1;i<=dim->n;++i)
    {
      if (( d=dim->s[i]) !=NULL)
      {
        if (*d>0)
        {
          ++(ret->rank);
          wholedim*=(*d);
          ret->dim[i]=*d;
        }
      }
    }
    ret->v=malloc(wholedim*sizeof(void *));
    --ret->v;
    for (i=1;i<=wholedim;++i)
      ret->v[i]=NULL;
  }
}
return ret;
}

varholder newvarholdernamest(char *name,stack dim)
    /* Naredi nov objekt tipa varholder z imenom name. dim je sklad dimenzij.
    Funkcija alocira prostor za objekt s funkcijo newvarholderst(), skopira niz
    name v polje (...)->name in vrne narejeni objekt.
    $A Igor feb98; */
{
varholder ret;
if (! legalvarname(name))
{
  errfunc0("newvarholdernamest");
  fprintf(erf(),"\"%s\" is not a legal variable name. Variable space is allocated anyway.\n",name);
  errfunc2();
}
ret=newvarholderst(dim);
ret->name=stringcopy(name);
return ret;
}

varholder newvarholdernametypest(char *name,int type,stack dim)
    /* Naredi nov objekt tipa varholder z imenom name in tipom type. dim je
    sklad dimenzij.
    Funkcija alocira prostor za objekt s funkcijo newvarholderst(), skopira niz
    name v polje (...)->name ter postavi (..)->type na type in vrne narejeni
    objekt.
    $A Igor avg01; */
{
varholder ret;
if ((int) type<(int) 1 || (int) type>(int) VT_NUMTYPES)
{
  errfunc0("assocvartypename");
  fprintf(erf(),"Invalid type %s (type num. %i).\n",
   vartypetostring(type),(int) type);
  errfunc2();
  return NULL;
} else if (! legalvarname(name))
{
  errfunc0("newvarholdernametypest");
  fprintf(erf(),"\"%s\" is not a legal variable name. Variable space is allocated anyway.\n",name);
  errfunc2();
}
ret=newvarholderst(dim);
ret->name=stringcopy(name);
ret->type=type;
return ret;
}




void getvardimst(varholder var,stack *dimp)
    /* Sklad *dimp popravi tako, da so na njem nalozene dimenzije spremenljivke,
    ki jo nosi var. dimp mora biti obvezno razlicen od NULL, drugace se v
    funkciji nic ne zgodi.
     Sklad *dimp je po izvedbi funkcije taksen, da ce z njim klicemo funkcijo
    newvarholderst, vrne ta kazalec tipa varholder, ki ima enake dimenzije kot
    var.
     Ce je var enak NULL, tudi *dimp postane NULL, ravno tako, ce je
    var->rank<0. Ce je var->rank enak 0, *dimp postane prazen sklad. Ce je
    var->rank vecji od 0, postane *dimp sklad s toliko elementi, kolikor je
    var->rank, na njem pa so kazalci na objekte tipa int, katerih vrednosti so
    enake ustreznim dimenzijam v var->dim.
     OPOMBA:
    $A Igor jan98 */
{
stack dim=NULL;
int *ip,i;
if (dimp!=NULL)
{
  if (var==NULL)
    dispstack(dimp);
  else
  {
    if (var->rank<0)
      dispstack(dimp);
    else if (var->rank==0)
    {
      if (*dimp==NULL)
        *dimp=newstack(1);
      dispstackval(*dimp);
      popstackall(*dimp);
    } else
    {
      if (*dimp==NULL)
        *dimp=newstack(var->rank);
      dim=*dimp;
      if (dim->n>var->rank);
        for (i=var->rank+1;i<=dim->n;++i)
        {
          ip=popstack(dim);
          if (ip!=NULL)
           free(ip);
        }
      for (i=1;i<=var->rank;++i)
      {
        if (dim->n<i || dim->s[i]==NULL)
        {
          ip=malloc(sizeof(*ip));
          *ip=var->dim[i];
          if (dim->n<i)
            pushstack(dim,ip);
          else
            dim->s[i]=ip;
        } else /* Element na skladu je ze na alociran, priredimo mu vrednost */
        {
          ip=dim->s[i];
          *ip=var->dim[i];
        }
      }
    }
  }
}
}

int calcvarplacest(varholder var,stack st)
    /* Izracuna zaporedno stevilko, ki bi jo imel na var element z indeksi
    tabele, ki so na sklatu st. na skladu morajo biti indeksi tipa int *.
    Ce dani element ne obstaja, vrne 0.
    $A Igor jan98 mar98; */
{
int place=0,*ip;
char error=0;
if (st!=NULL && var!=NULL)
{
  if (var->rank==0)
  {
    if (st->n<1)
      place=1;
    else
      place=0;
  } else if (var->rank>0 && var->dim!=NULL && st->n==var->rank)
  {
    int weight,i;
    place=0;
    weight=wholevardim(var);
    if (weight>0)
      for (i=1;i<=var->rank;++i)
        if (var->dim[i]>0)
        {
          weight/=var->dim[i];
          ip=st->s[i];
          /* $$ Error if overflow: */
          if (ip==NULL)
            ++error;
          else if (*ip>var->dim[i])
            ++error;
          place+=weight*(*ip-1);
        } else
          error=1;
      ++place;
  } else place=0;
} else if (var!=NULL)
{
  if (var->rank==0)
    place=1;
} else if (var==NULL)
  place=0;
if (error)
  place=0;
return place;
}

void *varelst(varholder var,stack idx)
    /* Vrne kazalec na element spremenljivke var, katerega indeksi ustrezajo
    indeksom na skladu idx. Za dolocitev elementa se uporabi funkcija
    calcvarplacest(). Ce ni elementa, ki bi ustrezal indeksom, vrne NULL.
    $A Igor jan98; */
{
int place;
if ((place=calcvarplacest(var,idx))>0)
  return var->v[place];
else
  return NULL;
}

void **vareladdrst(varholder var, stack idx)
    /* Vrne naslov kazalca na element spremenljivke var, katerega indeksi
    ustrezajo indeksom na skladu idx. Za dolocitev elementa se uporabi funkcija
    calcvarplacest(). Ce ni elementa, ki bi ustrezal indeksom, vrne NULL.
    $A Igor jan98; */
{
int place;
if ((place=calcvarplacest(var,idx))>0)
  return &(var->v[place]);
else
  return NULL;
}

void restvardimst(varholder var,stack dim,stack *rest)
    /* Na sklad *restst nalozi preostale dimenzije (v obliki kazalcev tipa
    int *) nosilca var (dimenzije so v var->dim), ki niso ze nalozene na
    sklad dim. Funkcija privzame, da je prvih dim->n dimenzij ze nalozenih
    in ne preverja, ce te dimenzije na skladu dim pravilne.
      Funkcija je narejena tako, da zbrise sklad *rest in ga postavi na NULL,
    ce nanj ne da nobenih elementov (to je pomembno za funkcije, ki po klicu te
    funkcije preverijo, ali ima ta sklad kaj elementov ali ne - dovolj je
    preveriti, ali je sklad enak NULL, polje (...)->n pa ni vazno).
     Pozor:
    Ce ob klicu funkcije sklad *rest ni prazen, morajo biti elementi na njem
    obvezno tipa int * in taksni, da jih lahko brez skode brisemo s funkcijo
    free().
    $A Igor jan98; */
{
char disprest=0;
int covered=0,i,*ip1;
stack restst=NULL;
if (rest!=NULL)
{
  if (var==NULL)
    disprest=1;
  else
  {
    if (dim!=NULL)
      if (dim->n>0)
        for(i=1;i<=dim->n;++i)
          ++covered;
    if (covered>=var->rank || var->dim==NULL)
      disprest=1;
    else
    {
      /* Vse je v redu, na sklad *rest se nalozijo ostale dimenzije; Ce *rest
      ze ima nekaj elemantov, se morebitni odvecni elementi brisejo: */
      if (*rest==NULL)
        *rest=newstack(var->rank-covered);
      restst=*rest;
      if (restst->n>var->rank-covered)
        for (i=covered+1;i<=var->rank;++i)
        {
          ip1=popstack(restst);
          if (ip1!=NULL)
            free(ip1);
        }
      for (i=1;i<=var->rank-covered;++i) /* prepisovanje dimenzij na *rest */
      {
        if (restst->n<i)
        {
          ip1=malloc(sizeof(*ip1));
          pushstack(restst,ip1);
        } else if (restst->s[i]==NULL)
        {
          ip1=malloc(sizeof(*ip1));
          restst->s[i]=ip1;
        } else
          ip1=restst->s[i];
        *ip1=var->dim[covered+i];
      }
    }
  }
  if (disprest && *rest!=NULL)
  {
    dispstackval(*rest);
    dispstack(rest);
  }
}
}

int incelst(stack elst,stack dimst)
    /* Funkcija inkrementira element vecdimenzionalne tabele, katere dimenzije
    so v obliki kazalcev tipa int * nalozene na sklad dimst. Element je
    dolocen z indeksi na skladu elst, ki so na tem skladu nalozeni kot kazalci
    tipa int *; funkcija ustrezno spremeni (glede na dimenzije na skladu dimst)
    vrednosti teh indeksov.  Ce funkcija uspesno inkrementira element, ne da bi
    vrednosti indeksov presegle obmocje doloceno z dimenzijami na skladu dimst,
    vrne 1, drugace pa 0.
     Ce je stevilo elementov na skladu elst manjse kot na skladu dimst,
    funkcija privzame, da ustreza indeksom na skladu elst po vrsti zadnjih
    elst->n dimenzij na skladu dimst.
    $A Igor jan98; */
{
int i,ret=0,excluded=0,*pdim,*pel;
if (dimst!=NULL && elst!=NULL)
{
  if (dimst->n>0 && elst->n<=dimst->n && elst->n>0)
  {
    excluded=dimst->n-elst->n; /* st. dimenzij, ki niso vkljucene obravnavo */
    /* Inkrementira se zadnji indeks: */
    pel=elst->s[elst->n];
    if (pel!=NULL)
    {
      ++(*pel);
      ret=1;
    }
    if (elst->n>1)
      for (i=elst->n;i>1;--i)
      {
        pel=elst->s[i];
        pdim=dimst->s[i+excluded];
        if (pel!=NULL && pdim!=NULL)
        {
          if (*pel>*pdim)
          {
            /* Ce dani indeks preseze ustrezno dimenzijo, ga postavimo na 1
            in povisamo indeks visjega ranga: */
            *pel=1;
            pel=elst->s[i-1];
            if (pel!=NULL)
              ++(*pel);
            else
              ret=0;
          }
        }
      }
    /* Preverimo, ce niso indeksi na elst usli iz obsega, ki ga predpisujejo
    dimenzije na skladu dimst (v tem primeru mora funkcija vrniti 0). Preveriti
    je potrebno le 1. indeks, ker je bilo za visje intekse ze opravljeno
    prenasanje na indekse visjega ranga: */
    pel=elst->s[1];
    pdim=dimst->s[1+dimst->n-elst->n];
    if (pel!=NULL)
    {
      if (pdim==NULL)
        ret=0;
      else if (*pel>*pdim)
        ret=0; /* z inkrementiranjem elst smo presegli obmocje dimst */
    }
  }
}
return ret;
}

char firstindicesinrangest(varholder var,stack elst)
    /* Vrne 1, ce so vsi indeksi s sklada elst (katerega elementi morajo biti
    tipa int *) v obsegu prvih elst->n dimenzij varholderja var, drugace vrne
    0. Ce je na skladu vec indeksov kot je var->rank, ce je var enak NULL ali
    ce je var->rank manjsi od 1 ali ce je kateri od elementov sklada elst enak
    NULL, vrne funkcija 0.
    $A Igor jan98; */
{
char ret=1;
int i,*ip;
if (var==NULL)
  ret=0;
else if (var->rank<0)
  ret=0;
else if (elst!=NULL)
  if (elst->n>0)
  {
    if (elst->n>var->rank)
      ret=0;
    else if (var->dim==NULL)
      ret=0;
    else for (i=1;i<=elst->n;++i)
    {
      ip=elst->s[i];
      if (ip==NULL)
        ret=0;
      else if (*ip>var->dim[i] || *ip<=0)
        ret=0;
    }
  }
return ret;
}

char elstinrange(stack elst,stack dimst)
    /* Funkcija vrne 1, ce so indeksi, ki so nalozeni na sklad elst, v obmocju,
    ki ga dopuscajo dimenzije vecdimenzionalne dabele, nalozene na sklad dimst.
    indeksi in dimenzije so na sklada nalozeni kot kazalci tipa int *. Ce je
    stevilo elementov na skladu elst manjse kot na skladu dimst, funkcija
    privzame, da ustreza indeksom na skladu elst po vrsti zadnjih elst->n
    dimenzij na skladu dimst.
    $A Igor jan98; */
{
char ret=1;
int i,excluded=0,*pel,*pdim;
if (elst!=NULL)
{
  if (dimst==NULL)
    ret=0;
  else
  {
    if (elst->n>0)
    {
      if (dimst->n<elst->n)
        ret=0;
      else
      {
        excluded=dimst->n-elst->n;
        for (i=elst->n;i>=1;--i)
        {
          pel=elst->s[i];
          pdim=dimst->s[i+excluded];
          if (pel!=NULL)
          {
            if (pdim==NULL)
              ret=0;
            else
              if (*pel>*pdim || *pel<=0)
                ret=0;
          } else if (pdim!=NULL)
            ret=0;
        }
      }
    }
  }
}
return ret;
}

char equaldimstack(stack st1,stack st2)
    /* Vrne 1, ce sta sklada dimenzij st1 in st2 enaka, in 0, ce nista. Enakost
    pomeni, da morajo biti tudi vse vrednosti, na katere kazejo kazalci
    nalozeni na sklada (ki morajo biti obvezno tipa int *) enake.
    $A Igor jan98; */
{
char ret=1;
int i,*ip1,*ip2;
if (st1==NULL)
{
  if (st2!=NULL)
    if (st2->n>0)
      ret=0;
} else if (st2==NULL)
{
  if (st1->n>0)
    ret=0;
} else if (st1->n!=st2->n)
  ret=0;
else if (st1->n>0)
  for (i=1;i<=st1->n && ret;++i)
  {
    ip1=st1->s[i]; ip2=st2->s[i];
    if (ip1==NULL)
    {
      if (ip2!=NULL)
        ret=0;
    } else if(ip2==NULL)
    {
      if (ip1!=NULL)
        ret=0;
    } else if (*ip1!=*ip2)
      ret=0;
  }
return ret;
}

int totaldimstack(stack st)
    /* Vrne celotno stevilo elementov tabele glede na njene dimenzije, ki so na
    skladu st.
     POZOR!
    Ce je st==NULL ali st->n==0, vrne funkcija 1!
    $A Igor jan98; */
{
int ret=1,i,*ip;
if (st!=NULL)
  if (st->n>0)
    for (i=1;i<=st->n;++i)
    {
      ip=st->s[i];
      if (ip==NULL)
        ret=0;
      else
        ret*=(*ip);
      if (ret<0)
        ret=0;
    }
return ret;
}


int simpvaropst(varholder var1,stack which1,void operation(void *operand1))
    /* Izvrsi operacijo operation nad elementi spremenljivke var1. which1 pove,
    nad katero podtabelo spremenljivke var1 se izvrsi operacija.
     Pravila glede dimenzij:
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladiu which1 se nanasajo na prve indekse ustrezne
    spremenljivke. Ce katerakoli od njihovih dimenzij ni v obsegu ustrezne
    dimenzije ali ce je indeksov vec kot ustreznih dimenzij (rang
    spremenljivke), je to napaka. Elementi na tem skladu so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
    $A Igor mar98; */
{
int error=0,num=0,i,*ip;
char proceed=1;
void *p1=NULL;
stack rest1=NULL,  /* preostale dimenzije (ki niso na which...) */
      dim1=NULL,   /* celotne dimenzije */
      inc1=NULL,   /* indeksi, ki se inkrementirajo */
      el1=NULL,    /* kompletni indeksi, ki dolocajo element v obdelavi */
      indexdim=NULL; /* dimenzija udelezenega dela tabele */
if (operation==NULL)
  error=-1;
else if (var1==NULL)
  error=-3;
else if (wholevardim(var1)<1)
  error=-5;
else if (!firstindicesinrangest(var1,which1))
  error=-8;
else
{
  /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
  restvardimst(var1,which1,&rest1);
  indexdim=rest1;
  if (indexdim==NULL)
  {
    /* 1. primer: OPERACIJA SE IZVEDE NAD ENIM ELEMENTOM */
    /* Dobimo ustrezne elemente in izvedemo operacijo nad njimi: */
    p1=varelst(var1,which1);
    operation(p1); /* izvedba operacije */
    ++num;
  } else
  {
    /* 2. primer: OPERACIJA SE IZVEDE NAD VEC ELEMENTI */
    /* Priprava pomoznih skladov: */
    if (rest1!=NULL)
    {
      /* Indeksi operand, ki se bodo inkrementirali: */
      inc1=newstack(rest1->n);
      if (rest1->n>0)
        for (i=1;i<=rest1->n;++i)
        {
          ip=malloc(sizeof(*ip));
          *ip=1;
          pushstack(inc1,ip);
        }
    }
    /* Specifikacija elementa za operand: */
    el1=newstack(5);
    if (which1!=NULL)
      if (which1->n>0)
        for (i=1;i<=which1->n;++i)
          pushstack(el1,which1->s[i]);
    if (inc1!=NULL)
      if (inc1->n>0)
        for (i=1;i<=inc1->n;++i)
          pushstack(el1,inc1->s[i]);
    /* Zanka, v kateri se izvede operacija nad udelezenimi elementi: */
    while (proceed)
    {
      if (!elstinrange(inc1,rest1))
        proceed=0;
      else
      {
        /* Poiscejo se elementi in nad njimi izvede operacija: */
        p1=varelst(var1,el1);
        operation(p1);  /* izvedba operacije */
        ++num;
        /* Inkrementacija indeksov, ki dolocajo element nad katerim
        se izvede operacija. Inkremantirajo se le indeksi, ki so na
        skladu inc1, prvi del specifikacije el1, ki je sestavljenaiz
        indeksov na which1, se ne inkrementirata: */
        incelst(inc1,rest1);
      }
    }
  }
}
/* Brisanje pomoznih skladov: */
dispstackval(rest1);
dispstack(&rest1);
dispstackval(inc1);
dispstack(&inc1);
dispstack(&el1);
if (error>=0)
  error=num;
return error;
}

int simpvaropchst(varholder var1,stack which1,void operation(void **operand1))
    /* Izvrsi operacijo operation nad elementi spremenljivke var1. which1 pove,
    nad katero podtabelo spremenljivke var1 se izvrsi operacija. Funkcija je
    podobna funkciji simpvaropst(), le da operacija, ki se izvrsi, lahko spremeni
    elemente spremenljivke var1 in je zato tipa void (void **).
     Pravila glede dimenzij:
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladiu which1 se nanasajo na prve indekse ustrezne
    spremenljivke. Ce katerakoli od njihovih dimenzij ni v obsegu ustrezne
    dimenzije ali ce je indeksov vec kot ustreznih dimenzij (rang
    spremenljivke), je to napaka. Elementi na tem skladu so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
    $A Igor mar98; */
{
int error=0,num=0,i,*ip;
char proceed=1;
void **p1=NULL;
stack rest1=NULL,  /* preostale dimenzije (ki niso na which...) */
      dim1=NULL,   /* celotne dimenzije */
      inc1=NULL,   /* indeksi, ki se inkrementirajo */
      el1=NULL,    /* kompletni indeksi, ki dolocajo element v obdelavi */
      indexdim=NULL; /* dimenzija udelezenega dela tabele */
if (operation==NULL)
  error=-1;
else if (var1==NULL)
  error=-3;
else if (wholevardim(var1)<1)
  error=-5;
else if (!firstindicesinrangest(var1,which1))
  error=-8;
else
{
  /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
  restvardimst(var1,which1,&rest1);
  indexdim=rest1;
  if (indexdim==NULL)
  {
    /* 1. primer: OPERACIJA SE IZVEDE NAD ENIM ELEMENTOM */
    /* Dobimo ustrezne elemente in izvedemo operacijo nad njimi: */
    p1=vareladdrst(var1,which1);
    operation(p1); /* izvedba operacije */
    ++num;
  } else
  {
    /* 2. primer: OPERACIJA SE IZVEDE NAD VEC ELEMENTI */
    /* Priprava pomoznih skladov: */
    if (rest1!=NULL)
    {
      /* Indeksi operand, ki se bodo inkrementirali: */
      inc1=newstack(rest1->n);
      if (rest1->n>0)
        for (i=1;i<=rest1->n;++i)
        {
          ip=malloc(sizeof(*ip));
          *ip=1;
          pushstack(inc1,ip);
        }
    }
    /* Specifikacija elementa za operand: */
    el1=newstack(5);
    if (which1!=NULL)
      if (which1->n>0)
        for (i=1;i<=which1->n;++i)
          pushstack(el1,which1->s[i]);
    if (inc1!=NULL)
      if (inc1->n>0)
        for (i=1;i<=inc1->n;++i)
          pushstack(el1,inc1->s[i]);
    /* Zanka, v kateri se izvede operacija nad udelezenimi elementi: */
    while (proceed)
    {
      if (!elstinrange(inc1,rest1))
        proceed=0;
      else
      {
        /* Poiscejo se elementi in nad njimi izvede operacija: */
        p1=vareladdrst(var1,el1);
        operation(p1);  /* izvedba operacije */
        ++num;
        /* Inkrementacija indeksov, ki dolocajo element nad katerim
        se izvede operacija. Inkremantirajo se le indeksi, ki so na
        skladu inc1, prvi del specifikacije el1, ki je sestavljenaiz
        indeksov na which1, se ne inkrementirata: */
        incelst(inc1,rest1);
      }
    }
  }
}
/* Brisanje pomoznih skladov: */
dispstackval(rest1);
dispstack(&rest1);
dispstackval(inc1);
dispstack(&inc1);
dispstack(&el1);
if (error>=0)
  error=num;
return error;
}

int simpvaropeldatast(varholder var1,stack which1,
                    void operation(void *operand1,stack elst))
    /* Izvrsi operacijo operation nad elementi spremenljivke var1. which1 pove,
    nad katero podtabelo spremenljivke var1 se izvrsi operacija. Funkciji
    operation(), ki izvede operacijo, posreduje ta funkcija prek njenega
    drugega argumenta sklad, na katerem so indeksi, ki dolocajo element, nad
    katerim se izvede operacija, na nosilcu var1.
     Pravila glede dimenzij:
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladiu which1 se nanasajo na prve indekse ustrezne
    spremenljivke. Ce katerakoli od njihovih dimenzij ni v obsegu ustrezne
    dimenzije ali ce je indeksov vec kot ustreznih dimenzij (rang
    spremenljivke), je to napaka. Elementi na tem skladu so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
    $A Igor mar98; */
{
int error=0,num=0,i,*ip;
char proceed=1;
void *p1=NULL;
stack rest1=NULL,  /* preostale dimenzije (ki niso na which...) */
      dim1=NULL,   /* celotne dimenzije */
      inc1=NULL,   /* indeksi, ki se inkrementirajo */
      el1=NULL,    /* kompletni indeksi, ki dolocajo element v obdelavi */
      indexdim=NULL; /* dimenzija udelezenega dela tabele */
if (operation==NULL)
  error=-1;
else if (var1==NULL)
  error=-3;
else if (wholevardim(var1)<1)
  error=-5;
else if (!firstindicesinrangest(var1,which1))
  error=-8;
else
{
  /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
  restvardimst(var1,which1,&rest1);
  indexdim=rest1;
  if (indexdim==NULL)
  {
    /* 1. primer: OPERACIJA SE IZVEDE NAD ENIM ELEMENTOM */
    /* Dobimo ustrezne elemente in izvedemo operacijo nad njimi: */
    p1=varelst(var1,which1);
    operation(p1,which1); /* izvedba operacije */
    ++num;
  } else
  {
    /* 2. primer: OPERACIJA SE IZVEDE NAD VEC ELEMENTI */
    /* Priprava pomoznih skladov: */
    if (rest1!=NULL)
    {
      /* Indeksi operand, ki se bodo inkrementirali: */
      inc1=newstack(rest1->n);
      if (rest1->n>0)
        for (i=1;i<=rest1->n;++i)
        {
          ip=malloc(sizeof(*ip));
          *ip=1;
          pushstack(inc1,ip);
        }
    }
    /* Specifikacija elementa za operand: */
    el1=newstack(5);
    if (which1!=NULL)
      if (which1->n>0)
        for (i=1;i<=which1->n;++i)
          pushstack(el1,which1->s[i]);
    if (inc1!=NULL)
      if (inc1->n>0)
        for (i=1;i<=inc1->n;++i)
          pushstack(el1,inc1->s[i]);
    /* Zanka, v kateri se izvede operacija nad udelezenimi elementi: */
    while (proceed)
    {
      if (!elstinrange(inc1,rest1))
        proceed=0;
      else
      {
        /* Poiscejo se elementi in nad njimi izvede operacija: */
        p1=varelst(var1,el1);
        operation(p1,el1);  /* izvedba operacije */
        ++num;
        /* Inkrementacija indeksov, ki dolocajo element nad katerim
        se izvede operacija. Inkremantirajo se le indeksi, ki so na
        skladu inc1, prvi del specifikacije el1, ki je sestavljena iz
        indeksov na which1, se ne inkrementirata: */
        incelst(inc1,rest1);
      }
    }
  }
}
/* Brisanje pomoznih skladov: */
dispstackval(rest1);
dispstack(&rest1);
dispstackval(inc1);
dispstack(&inc1);
dispstack(&el1);
if (error>=0)
  error=num;
return error;
}

int unvaropst(varholder var1,stack which1,varholder *res,stack whichres,
            void *operation(void *operand1,void **res),void disp(void **))
    /* Izvrsi unarno operacijo operation nad elementi spremenljivke var1, pri
    cemer se rezultati spravijo kot elementi spremenljivke res. which1 pove,
    nad katero podtabelo spremenljivke var1 se izvrsi operacija, whichres pa
    pove, v katero podtabelo spremenljivke *res se spravijo rezultati.
     Pravila glede dimenzij:
     Ce na skladu whichres ni nobenih indeksov, je lahko dimenzija
    spremenljivke *res razlicna od dimenzije podtabele, nad katero se izvaja
    operacija. V tem primeru se spremenljivka *res najprej zbrise z vsemi
    elementi vred, nato pa se tvori na novo tako, da so vsi elementi pred
    izvedbo operacije enaki NULL in je dimenzija spremenljivke enaka dimenziji
    podtabele, nad katero se izvede operacija. Za brisanje elementov podtabele
    se uporabi funkcija disp (ce je disp==NULL, se elementi ne brisejo).
     Ce je na skladu whichres kak indeks, mora biti dimenzija podtabele
    spremenljivke *res, ki jo dolocajo indeksi na which, nujno enaka dimenziji
    podtabele, nad katero se izvede operacija operation.
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce  je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladih whichres in which1 se nanasajo na prve indekse
    ustreznih spremenljivk. Ce katerakoli od njihovih dimenzij ni v
    obsegu ustrezne dimenzije ali ce je indeksov vec kot ustreznih dimenzij
    (rang spremenljivke), je to napaka. Elementi na teh skladih so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
     Ce se med izvedbo funkcije nosilec *res brise in naredi na novo, se ohrani
    njgovo eime.
    $A Igor jan98 mar98; */
{
int error=0,num=0,i,*ip;
char proceed=1,*nameres=NULL;
void *p1=NULL,**pres=NULL;
varholder varres=NULL;
stack rest1=NULL,restres=NULL,  /* preostale dimenzije (ki niso na which...) */
      dim1=NULL,dimres=NULL,    /* celotne dimenzije */
      inc1=NULL,incres=NULL,    /* indeksi, ki se inkrementirajo */
      el1=NULL,elres=NULL,      /* kompletni indeksi */
      indexdim=NULL; /* dimenzija udelezenega dela tabele */
if (res==NULL)
  error=-2;
else
{
  if (operation==NULL)
    error=-1;
  else if (var1==NULL)
    error=-3;
  else if (wholevardim(var1)<1)
    error=-5;
  else if (!firstindicesinrangest(var1,which1))
    error=-8;
  else
  {
    if (*res!=NULL)
    {
      /* Ce je *res!=NULL, morajo biti indeksi na whichres v obsegu: */
      if (!firstindicesinrangest(*res,whichres))
        error=-7;
    } else
    {
      /* Ce pa je *res enak NULL, na whichres ne sme biti indeksov: */
      if (whichres!=NULL)
        if (whichres->n>0)
          error=-7;
    }
    /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
    restvardimst(*res,whichres,&restres);
    restvardimst(var1,which1,&rest1);
    indexdim=rest1;
    if (indexdim==NULL)
    {
      /* 1. primer: OPERACIJA SE IZVEDE NAD ENIM ELEMENTOM */
      /* Najprej se preveri, ce ni dimenzija *res neustrezna: */
      if (restres!=NULL)
        if (restres->n>0)
        {
          /* Ce obstaja specifikacija whichres, vendar ne doloca enega samega
          elementa na *res, je to napaka: */
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-20;
          if (!error)
          {
            /* Primer, ko *res ze obstaja, vendar je njegova dimenzija
            neustrezna in ga je treba brisati; samo v primeru, ko ni navedena
            specifikacija whichres: */
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name); /* Pred brisanjem shranemo ime */
            dispwholevarspec(res,disp);
          }
        }
      if (!error)
      {
        if (*res==NULL)
        {
          /* Ce je *res enak NULL, se tvori na novo: */
          *res=newvarholderst(indexdim);
          /* Ce smo v tej funkciji brisali *res, mu moramo dati nazaj isto ime,
          ko ga tvorimo na novo: */
          (*res)->name=nameres;
          nameres=NULL;
        }
        /* Dobimo ustrezne elemente in izvedemo operacijo nad njimi: */
        pres=vareladdrst(*res,whichres);
        p1=varelst(var1,which1);
        if (pres==NULL)
          error=-25;
        else
        {
          operation(p1,pres); /* izvedba operacije */
          ++num;
        }
      }
    } else
    {
      /* 2. primer: OPERACIJA SE IZVEDE NAD VEC ELEMENTI */
      if (!error)
      {
        if (!equaldimstack(indexdim,restres) || *res==NULL)
        /* Dimenzija *res ni ustrezna, zato se *res najprej brise in nato
        tvori na novo: */
        {
          /* Ce je podana specifikacija whichres in ni ustrezna, je to napaka: */
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-21;
          /* POMEMBNA OPOMBA: Ce je aktualna dimenzija spremenljivek, ki je
          rezultat operacije, razlicna od aktualne dimenzije operanda, to
          NI NAPAKA, ampak se spremenljivka rezultatov najprej pobrise in nato
          tvori na novo. Aktualna dimenzija je dimenzija dela tabele, nad
          katero se izvrsi operacija. To pravilo velja le, ce je indeks
          sklada whichres, ki doloca, kateri del tabele spremenljivke *res je 
          aktualen, niceln; Nasprotni primer velja za napako. */
          if (!error)
          {
            /* Ce specifikacija which ni bila podana, *res pa ni prave
            dimenzije, se *res zbrise, da se bo pozneje tvoril na novo: */
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name); /* Ime *res shranemo */
            dispwholevarspec(res,disp);
          }
        }
        if (!error)
        {
          if (*res==NULL)  /* Ce je *res NUL, se tvori na novo: */
          {
            *res=newvarholderst(indexdim);
            /* Ce je bil *res brisan, damo novo tvorjenemu *res prejsnje ime,
            ki smo ga shranili: */
            (*res)->name=nameres;
            nameres=NULL;
            /* Potrebno je se na novo popraviti dimenzijo indeksov za *res: */
            restvardimst(*res,whichres,&restres);
          }
          varres=*res;
          /* Priprava pomoznih skladov: */
          if (rest1!=NULL)
          {
            /* Indeksi operand, ki se bodo inkrementirali: */
            inc1=newstack(rest1->n);
            if (rest1->n>0)
              for (i=1;i<=rest1->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(inc1,ip);
              }
          }
          /* Specifikacija elementa za operand: */
          el1=newstack(5);
          if (which1!=NULL)
            if (which1->n>0)
              for (i=1;i<=which1->n;++i)
                pushstack(el1,which1->s[i]);
          if (inc1!=NULL)
            if (inc1->n>0)
              for (i=1;i<=inc1->n;++i)
                pushstack(el1,inc1->s[i]);
          /* Indeksi rezultata, ki se bodo inkrementirali skupaj z indeksi
          operanda: */
          if (restres!=NULL)
          {
            incres=newstack(restres->n);
            if (restres->n>0)
              for (i=1;i<=restres->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(incres,ip);
              }
          }
          /* Specifikacija elementa rezultata: */
          elres=newstack(5);
          if (whichres!=NULL)
            if (whichres->n>0)
              for (i=1;i<=whichres->n;++i)
                pushstack(elres,whichres->s[i]);
          if (incres!=NULL)
            if (incres->n>0)
              for (i=1;i<=incres->n;++i)
                pushstack(elres,incres->s[i]);
          while (proceed)
          {
            if (!elstinrange(inc1,rest1))
              proceed=0;
            else
            {
              /* Poiscejo se elementi in nad njimi izvede operacija: */
              pres=vareladdrst(varres,elres);
              if (pres!=NULL)
              {
                p1=varelst(var1,el1);
                operation(p1,pres);  /* izvedba operacije */
                ++num;
              } else
              {
                error=-20;
                proceed=0;
              }
              /* Inkrementacija indeksov, ki dolocajo elementa, nad katerima
              se izvede operacija. Inkremantirajo se le indeksi, ki so na
              skladih inc1 in incres, prva dela specifikacij el1 in elres, ki
              sta sestavljena iz indeksov na which1 in whichres, se ne
              inkrementirata: */
              incelst(inc1,rest1);
              incelst(incres,restres);
            }
          }
        }
      }
    }
  }
}
if (nameres!=NULL)
  free(nameres);
/* Brisanje pomoznih skladov: */
dispstackval(rest1);
dispstack(&rest1);
dispstackval(inc1);
dispstack(&inc1);
dispstack(&el1);
dispstackval(restres);
dispstack(&restres);
dispstackval(incres);
dispstack(&incres);
dispstack(&elres);
if (error>=0)
  error=num;
return error;
}

int unvaropchst(varholder var1,stack which1,varholder *res,stack whichres,
            void *operation(void **operand1,void **res),void disp(void **))
    /* Izvrsi unarno operacijo operation nad elementi spremenljivke var1, pri
    cemer se rezultati spravijo kot elementi spremenljivke res. Operacija je
    taksna, da lahko spremeni 1. operand, zatoje njen 1. argument tipa void **.
    Vse ostalo je isto kot pri funkciji unvaropst().
    $A Igor mar98; */
{
int error=0,num=0,i,*ip;
char proceed=1,*nameres=NULL;
void **p1=NULL,**pres=NULL;
varholder varres=NULL;
stack rest1=NULL,restres=NULL,  /* preostale dimenzije (ki niso na which...) */
      dim1=NULL,dimres=NULL,    /* celotne dimenzije */
      inc1=NULL,incres=NULL,    /* indeksi, ki se inkrementirajo */
      el1=NULL,elres=NULL,      /* kompletni indeksi */
      indexdim=NULL; /* dimenzija udelezenega dela tabele */
if (res==NULL)
  error=-2;
else
{
  if (operation==NULL)
    error=-1;
  else if (var1==NULL)
    error=-3;
  else if (wholevardim(var1)<1)
    error=-5;
  else if (!firstindicesinrangest(var1,which1))
    error=-8;
  else
  {
    if (*res!=NULL)
    {
      if (!firstindicesinrangest(*res,whichres))
        error=-7;
    } else
    {
      if (whichres!=NULL)
        if (whichres->n>0)
          error=-7;
    }
    /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
    restvardimst(*res,whichres,&restres);
    restvardimst(var1,which1,&rest1);
    indexdim=rest1;
    if (indexdim==NULL)
    {
      /* Gre za tocno dolocen element: */
      /* Najprej se preveri, ce ni dimenzija *res neustrezna: */
      if (restres!=NULL)
        if (restres->n>0)
        {
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-20;
          if (!error)
          {
            /*
            dispvarvalspec(*res,disp);
            dispvarholder(res);
            */
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name);
            dispwholevarspec(res,disp);
          }
        }
      if (!error)
      {
        if (*res==NULL)
        {
          *res=newvarholderst(indexdim);
          (*res)->name=nameres; nameres=NULL;
        }
        pres=vareladdrst(*res,whichres);
        p1=vareladdrst(var1,which1);
        if (pres==NULL)
          error=-25;
        else
        {
          operation(p1,pres);
          ++num;
        }
      }
    } else
    {
      if (!error)
      {
        if (!equaldimstack(indexdim,restres) || *res==NULL)
        /* Dimenzija *res ni ustrezna, zato se *res najprej brise in nato
        tvori na novo: */
        {
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-21;
          /* POMEMBNA OPOMBA: Ce je aktualna dimenzija spremenljivek, ki je
          rezultat operacije, razlicna od aktualne dimenzije operanda, to
          NI NAPAKA, ampak se spremenljivka rezultatov najprej pobrise in nato
          tvori na novo. Aktualna dimenzija je dimenzija dela tabele, nad
          katero se izvrsi operacija. To pravilo velja le, ce je indeks
          sklada whichres, ki doloca, kateri del tabele spremenljivke *res je 
          aktualen, niceln; Nasprotni primer velja za napako. */
          if (!error)
          {
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name);
            dispwholevarspec(res,disp);
          }
        }
        if (!error)
        {
          if (*res==NULL)
          {
            *res=newvarholderst(indexdim);
            (*res)->name=nameres; nameres=NULL;
            restvardimst(*res,whichres,&restres);  /* Popravek !!! */
          }
          varres=*res;
          /* Priprava pomoznih skladov: */
          if (rest1!=NULL)
          {
            inc1=newstack(rest1->n);
            if (rest1->n>0)
              for (i=1;i<=rest1->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(inc1,ip);
              }
          }
          el1=newstack(5);
          if (which1!=NULL)
            if (which1->n>0)
              for (i=1;i<=which1->n;++i)
                pushstack(el1,which1->s[i]);
          if (inc1!=NULL)
            if (inc1->n>0)
              for (i=1;i<=inc1->n;++i)
                pushstack(el1,inc1->s[i]);
          if (restres!=NULL)
          {
            incres=newstack(restres->n);
            if (restres->n>0)
              for (i=1;i<=restres->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(incres,ip);
              }
          }
          elres=newstack(5);
          if (whichres!=NULL)
            if (whichres->n>0)
              for (i=1;i<=whichres->n;++i)
                pushstack(elres,whichres->s[i]);
          if (incres!=NULL)
            if (incres->n>0)
              for (i=1;i<=incres->n;++i)
                pushstack(elres,incres->s[i]);
          while (proceed)
          {
            if (!elstinrange(inc1,rest1))
              proceed=0;
            else
            {
              pres=vareladdrst(varres,elres);
              if (pres!=NULL)
              {
                p1=vareladdrst(var1,el1);
                operation(p1,pres);
                ++num;
              } else
              {
                error=-20;
                proceed=0;
              }
              incelst(inc1,rest1);
              incelst(incres,restres);
            }
          }
        }
      }
    }
  }
}
if (nameres!=NULL)
  free(nameres);
/* Brisanje pomoznih skladov: */
dispstackval(rest1);
dispstack(&rest1);
dispstackval(inc1);
dispstack(&inc1);
dispstack(&el1);
dispstackval(restres);
dispstack(&restres);
dispstackval(incres);
dispstack(&incres);
dispstack(&elres);
if (error>=0)
  error=num;
return error;
}

int binvaropst(varholder var1,stack which1, varholder var2,stack which2,
             varholder *res,stack whichres,
             void *operation(void *operand1,void *operand2,void **res),
             void disp(void **))
    /* Izvrsi binarno operacijo operation nad elementi spremenljivk var1 in
    var2, pri cemer se rezultati spravijo kot elementi spremenljivke res.
    which1 in which2 povesta, nad katerima podtabelama spremenljivk var1 in
    var2 se izvrsi operacija, whichres pa pove, v katero podtabelo
    spremenljivke *res se spravijo rezultati.
     Pravila glede dimenzij:
     Dimenziji podtabel, ki ju dolocata which1 in which2, morata biti enaki,
    razen, ce je vsaj na eni od teh podtabel en sam element (rang podtabele
    enak 0). V tem primeru se operacija izvede nad vsakim elementom podtabele,
    katere rang je vecji od 0, in nad edinim elementom druge tabele.
     Ce na skladu whichres ni nobenih indeksov, je lahko dimenzija
    spremenljivke *res razlicna od dimenzije podtabele, nad katero se izvaja
    operacija. V tem primeru se spremenljivka *res najprej zbrise z vsemi
    elementi vred, nato pa se tvori na novo tako, da so vsi elementi pred
    izvedbo operacije enaki NULL in je dimenzija spremenljivke enaka dimenziji
    podtabele, nad katero se izvede operacija. Za brisanje elementov podtabele
    se uporabi funkcija disp (ce je disp==NULL, se elementi ne brisejo).
     Ce je na skladu whichres kak indeks, mora biti dimenzija podtabele
    spremenljivke *res, ki jo dolocajo indeksi na which, nujno enaka dimenziji
    podtabele, nad katero se izvede operacija operation.
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce  je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladih whichres, which1 in which2 se nanasajo na prve
    indekse ustreznih spremenljivk. Ce katerakoli od njihovih dimenzij ni v
    obsegu ustrezne dimenzije ali ce je indeksov vec kot ustreznih dimenzij,
    je to napaka. Elementi na teh skladih so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
     Ce se med izvedbo funkcije nosilec *res brise in nato tvori na novo, se
     njegovo ime ohrani.
    $A Igor jan98 mar98; */
{
int error=0,num=0,i,*ip;
char proceed=1,*nameres=NULL;
void *p1=NULL,*p2=NULL,**pres=NULL;
varholder varres=NULL;
stack rest1=NULL,rest2=NULL,restres=NULL,  /* preostale dimenzije (ki niso na which...) */
      dim1=NULL,dim2=NULL,dimres=NULL,     /* celotne dimenzije */
      inc1=NULL,inc2=NULL,incres=NULL,     /* indeksi, ki se inkrementirajo */
      el1=NULL,el2=NULL,elres=NULL,        /* Kompletni indeksi */
      indexdim=NULL; /* dimenzija udelezenega dela tabele */
if (res==NULL)
  error=-2;
else
{
  if (operation==NULL)
    error=-1;
  else if (var1==NULL)
    error=-3;
  else if (var2==NULL)
    error=-4;
  else if (wholevardim(var1)<1)
    error=-5;
  else if (wholevardim(var2)<1)
    error=-6;
  else if (!firstindicesinrangest(var1,which1))
    error=-8;
  else if (!firstindicesinrangest(var2,which2))
    error=-9;
  else
  {
    if (*res!=NULL)
    {
      if (!firstindicesinrangest(*res,whichres))
        error=-7;
    } else
    {
      if (whichres!=NULL)
        if (whichres->n>0)
          error=-7;
    }
    /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
    restvardimst(*res,whichres,&restres);
    restvardimst(var1,which1,&rest1);
    restvardimst(var2,which2,&rest2);
    if (rest1!=NULL)
      indexdim=rest1;
    else
      indexdim=rest2;
    if (indexdim==NULL)
    {
      /* Pri var1 in var2 gre za tocno dolocen element: */
      /* Najprej se preveri, ce ni dimenzija *res neustrezna: */
      if (restres!=NULL)
        if (restres->n>0)
        {
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-20;
          if (!error)
          {
            /*
            dispvarvalspec(*res,disp);
            dispvarholder(res);
            */
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name);
            dispwholevarspec(res,disp);
          }
        }
      if (!error)
      {
        if (*res==NULL)
        {
          *res=newvarholderst(indexdim);
          (*res)->name=nameres; nameres=NULL;
        }
        pres=vareladdrst(*res,whichres);
        p1=varelst(var1,which1);
        p2=varelst(var2,which2);
        if (pres==NULL)
          error=-25;
        else
        {
          operation(p1,p2,pres);
          ++num;
        }
      }
    } else
    {
      /* Najprej se preveri, ce so dimencije indeksov enake za 1. in 2. spr. */
      if (!equaldimstack(rest1,rest2))
        if (totaldimstack(rest1)>1 && totaldimstack(rest2)>1)
          error=-10;
      if (!error)
      {
        if (!equaldimstack(indexdim,restres) || *res==NULL)
        /* Dimenzija *res ni ustrezna, zato se *res najprej brise in nato
        tvori na novo: */
        {
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-21;
          /* POMEMBNA OPOMBA: Ce je aktualna dimenzija spremenljivek, ki je
          rezultat operacije, razlicna od aktualnih dimenzij operandov, to
          NI NAPAKA, ampak se spremenljivka rezultatov najpre pobrise in nato
          tvori na novo. Aktualna dimenzija je dimenzija dela tabele, nad
          katero se izvrsi operacija. To pravilo velja le, ce je indeks
          sklada whichres, ki doloca, kateri del tabele spremenljivke *res je 
          aktualen, niceln; Nasprotni primer velja za napako. */
          if (!error)
          {
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name);
            dispwholevarspec(res,disp);
          }
        }
        if (!error)
        {
          if (*res==NULL)
          {
            *res=newvarholderst(indexdim);
            (*res)->name=nameres; nameres=NULL;
            restvardimst(*res,whichres,&restres);
          }
          varres=*res;
          /* Priprava pomoznih skladov: */
          if (rest1!=NULL)
          {
            inc1=newstack(rest1->n);
            if (rest1->n>0)
              for (i=1;i<=rest1->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(inc1,ip);
              }
          }
          el1=newstack(5);
          if (which1!=NULL)
            if (which1->n>0)
              for (i=1;i<=which1->n;++i)
                pushstack(el1,which1->s[i]);
          if (inc1!=NULL)
            if (inc1->n>0)
              for (i=1;i<=inc1->n;++i)
                pushstack(el1,inc1->s[i]);
          
          if (rest2!=NULL)
          {
            inc2=newstack(rest2->n);
            if (rest2->n>0)
              for (i=1;i<=rest2->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(inc2,ip);
              }
          }
          el2=newstack(5);
          if (which2!=NULL)
            if (which2->n>0)
              for (i=1;i<=which2->n;++i)
                pushstack(el2,which2->s[i]);
          if (inc2!=NULL)
            if (inc2->n>0)
              for (i=1;i<=inc2->n;++i)
                pushstack(el2,inc2->s[i]);
          
          if (restres!=NULL)
          {
            incres=newstack(restres->n);
            if (restres->n>0)
              for (i=1;i<=restres->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(incres,ip);
              }
          }
          elres=newstack(5);
          if (whichres!=NULL)
            if (whichres->n>0)
              for (i=1;i<=whichres->n;++i)
                pushstack(elres,whichres->s[i]);
          if (incres!=NULL)
            if (incres->n>0)
              for (i=1;i<=incres->n;++i)
                pushstack(elres,incres->s[i]);
          while (proceed)
          {
            if (!elstinrange(inc1,rest1) || !elstinrange(inc2,rest2))
              proceed=0;
            else
            {
              /*
              incelst(inc1,rest1);
              incelst(inc2,rest2);
              incelst(incres,restres);
              */
              pres=vareladdrst(varres,elres);
              if (pres!=NULL)
              {
                p1=varelst(var1,el1);
                p2=varelst(var2,el2);
                operation(p1,p2,pres);
                ++num;
              } else
              {
                error=-20;
                proceed=0;
              }
              incelst(inc1,rest1);
              incelst(inc2,rest2);
              incelst(incres,restres);
              
            }
          }
        }
      }
    }
  }
}
if (nameres!=NULL)
  free(nameres);
/* Brisanje pomoznih skladov: */
dispstackval(rest1);
dispstack(&rest1);
dispstackval(inc1);
dispstack(&inc1);
dispstack(&el1);
dispstackval(rest2);
dispstack(&rest2);
dispstackval(inc2);
dispstack(&inc2);
dispstack(&el2);
dispstackval(restres);
dispstack(&restres);
dispstackval(incres);
dispstack(&incres);
dispstack(&elres);
/* Ce je vse v redu, vrne funkcija stevilo izvedenih operacij: */
if (error>=0)
  error=num;
return error;
}



/**************************************************************

                     DELO S SKLADI

***************************************************************/


int simpvaropnamest(stack st1, char *name1, stack which1,
                  void operation(void *operand1))
    /* Izvede operacijo simpvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropnamesortst().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropst(var1,which1,operation);
  }
}
return ret;
}

int simpvaropnamesortst(stack st1, char *name1, stack which1,
                  void operation(void *operand1))
    /* Izvede operacijo simpvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropnamest().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropst(var1,which1,operation);
  }
}
return ret;
}

int simpvaropchnamest(stack st1, char *name1, stack which1,
                  void operation(void **operand1))
    /* Izvede operacijo simpvaropchst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropchst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropchnamesortst().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropchst(var1,which1,operation);
  }
}
return ret;
}

int simpvaropchnamesortst(stack st1, char *name1, stack which1,
                  void operation(void **operand1))
    /* Izvede operacijo simpvaropchst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropchst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropchnamest().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropchst(var1,which1,operation);
  }
}
return ret;
}

int simpvaropeldatanamest(stack st1, char *name1, stack which1,
                  void operation(void *operand1,stack elst))
    /* Izvede operacijo simpvaropeldatast() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropeldatast() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropeldatast(). Ce ne najde operanda z imenom name1 na skladu
    st1, vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropeldatast.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropeldatanamesortst().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropeldatast(var1,which1,operation);
  }
}
return ret;
}

int simpvaropeldatanamesortst(stack st1, char *name1, stack which1,
                  void operation(void *operand1,stack elst))
    /* Izvede operacijo simpvaropeldatast() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropeldatast() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekt na skladu in izvede nad njim
    funkcijo simpvaropeldatast(). Ce ne najde operanda z imenom name1 na skladu
    st1, vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropnamest().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropeldatast(var1,which1,operation);
  }
}
return ret;
}

int unvaropnamest(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void *operand1,void **res),void disp(void **))
    /* Izvede unarno operacijo unvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    unvaropnamesortst().
    $A Igor jan98 mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL;
if (st1==NULL)
  ret=-101;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=unvaropst(var1,which1,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v tem
        primeru je bil res pred izvedbo unvaropst enak NULL), in nastane nov objekt
        tipa varholder kot rezultat operacije unvaropst, damo temu objektu ime
        nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        insstackvar(stres,res);
      }
    }
  }
}
return ret;
}

int unvaropnamesortst(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void *operand1,void **res),void disp(void **))
    /* Izvede unarno operacijo unvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    unvaropnamest().
    $A Igor jan98 mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL;
if (st1==NULL)
  ret=-101;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findsortstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=unvaropst(var1,which1,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v tem
        primeru je bil res pred izvedbo unvaropst enak NULL), in nastane nov objekt
        tipa varholder kot rezultat operacije unvaropst, damo temu objektu ime
        nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        inssortstackvar(stres,res);
      }
    }
  }
}
return ret;
}

int unvaropchnamest(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void **operand1,void **res),void disp(void **))
    /* Izvede unarno operacijo unvaropchst() nad objektom tipa varholder, ki je
    na skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropchst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropchst().
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropchst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    unvaropchnamesortst().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL;
if (st1==NULL)
  ret=-101;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=unvaropchst(var1,which1,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v tem
        primeru je bil res pred izvedbo unvaropchst enak NULL), in nastane nov
        objekt tipa varholder kot rezultat operacije unvaropchst, damo temu
        objektu ime nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        insstackvar(stres,res);
      }
    }
  }
}
return ret;
}

int unvaropchnamesortst(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void **operand1,void **res),void disp(void **))
    /* Izvede unarno operacijo unvaropchst() nad objektom tipa varholder, ki je
    na skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropchst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropchst().
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropchst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    unvaropchnamest().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL;
if (st1==NULL)
  ret=-101;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findsortstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=unvaropchst(var1,which1,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v
        tem primeru je bil res pred izvedbo unvaropchst enak NULL), in nastane
        nov objekt tipa varholder kot rezultat operacije unvaropchst, damo temu
        objektu ime nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        inssortstackvar(stres,res);
      }
    }
  }
}
return ret;
}

int binvaropnamest(stack st1,char *name1,stack which1,
                 stack st2,char *name2,stack which2,
                 stack stres,char *nameres,stack whichres,
                 void *operation(void *,void *,void **),void disp(void **))
    /* Izvede binarno operacijo binvaropst() nad objektoma tipa varholder, ki sta
    na skladih st1 in st2 in imata imeni name1 in name2. Rezultati se spravijo
    v objekt, ki je na skladu stres in ima ime nameres. Ostali argumenti so
    neposredno argumenti funkcije binvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezne objekte na skladih in izvede nad njimi
    funkcijo binvaropst(). Ce ne najde 1.  ali 2. operanda z ustreznim imenom
    na ustreanem skladu, vrne ustrezno kodo napake (opisni niz za to kodo vrne
    funkcija varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne binvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu binvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    binvaropnamesortst().
    $A Igor jan98 mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL,var2=NULL;
if (st1==NULL)
  ret=-101;
else if (st2==NULL)
  ret=-102;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  /* Poiscemo 2. operand: */
  place=findstackvar(st2,name2,0,0);
  if (place>0)
    var2=st2->s[place];
  else
    ret=-51; /* Napaka: 2. operand ni definiran */
  if (ret>=0)
  {
    ret=binvaropst(var1,which1,var2,which2,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v
        tem primeru je bil res pred izvedbo binvaropst enak NULL), in nastane nov
        objekt tipa varholder kot rezultat operacije binvaropst, damo temu
        objektu ime nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        insstackvar(stres,res);
      }
    }
  }
}
return ret;
}

int binvaropnamesortst(stack st1,char *name1,stack which1,
                 stack st2,char *name2,stack which2,
                 stack stres,char *nameres,stack whichres,
                 void *operation(void *,void *,void **),void disp(void **))
    /* Izvede binarno operacijo binvaropst() nad objektoma tipa varholder, ki sta
    na skladih st1 in st2 in imata imeni name1 in name2. Rezultati se spravijo
    v objekt, ki je na skladu stres in ima ime nameres. Ostali argumenti so
    neposredno argumenti funkcije binvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezne objekte na skladih in izvede nad njimi
    funkcijo binvaropst(). Ce ne najde 1.  ali 2. operanda z ustreznim imenom
    na ustreanem skladu, vrne ustrezno kodo napake (opisni niz za to kodo vrne
    funkcija varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne binvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu binvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR!!
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    binvaropnamesortst().
    $A Igor jan98 mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL,var2=NULL;
if (st1==NULL)
  ret=-101;
else if (st2==NULL)
  ret=-102;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findsortstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  /* Poiscemo 2. operand: */
  place=findsortstackvar(st2,name2,0,0);
  if (place>0)
    var2=st2->s[place];
  else
    ret=-51; /* Napaka: 2. operand ni definiran */
  if (ret>=0)
  {
    s=stres;
    /*
    printf("PRED binvaropst:\n");
    pst(stres);
    */
    ret=binvaropst(var1,which1,var2,which2,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    /*
    printf("PO binvaropst:\n");
    pst(stres);
    printf("KONEC IZPISA:\n");
    */
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v
        tem primeru je bil res pred izvedbo binvaropst enak NULL), in nastane nov
        objekt tipa varholder kot rezultat operacije binvaropst, damo temu
        objektu ime nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        inssortstackvar(stres,res);
      }
    }
  }
}
return ret;
}





       /* NEWER VERSIONS */



char *makeindspecstring(indtab it)
    /* Returns a string that represents index specification it, with comma
    separated indices in square brackets. The returned string can  be deleted
    by free().
    $A Igor nov02; */
{
int i,length,buflength=1000;
char *spec,*ptr;
spec=calloc(1,1000); ptr=spec; spec[0]='\0';
if (it==NULL)
  sprintf(spec,"[]");
else if (it->n<1)
  sprintf(spec,"[]");
else
{
  sprintf(spec,"[");
  ptr+=strlen(ptr);
  if (it->n>0)
    for (i=1;i<=it->n;++i)
    {
      sprintf(spec,"%i",it->t[i]);
      ptr+=strlen(ptr);
      if (i<it->n)
      {
        sprintf(spec,",");
        ptr+=strlen(ptr);
      }
      if ((length=ptr-spec)>buflength-20)
      {
        buflength*=2;
        spec=realloc(spec,buflength);
        ptr=spec+length;
      }
    }
  sprintf(spec,"]");
  ptr+=strlen(ptr);
}
sprintf(spec,"\0");
ptr=stringcopy(spec);
free(spec);
return stringcopy(ptr);
}

void fprintindspec(FILE *fp,indtab it)
    /* Prints comma separated indices on it in square brackets to the file fp.
    $A Igor nov02; */
{
int i;
if (fp!=NULL)
  {
  if (it==NULL)
    fprintf(fp,"[]");
  else if (it->n<1)
    fprintf(fp,"[]");
  else
  {
    fprintf(fp,"[");
    for (i=1;i<=it->n;++i)
    {
      fprintf(fp,"%i",it->t[i]);
      if (i<it->n)
        fprintf(fp,",");
    }
    fprintf(fp,"]");
  }
}
}

void printindspec(indtab it)
    /* Prints comma separated indices on it in square brackets to the standard
    output.
    $A Igor nov02; */
{
fprintindspec(stdout,it);
}

void sprintindspec(char *ptr,indtab it)
    /*  Prints comma separated indices on the index table it in square brackets
    on the string buffer ptr, which must provide enough space for this task.
    $A Igor nov02; */
{
int i;
char *str=ptr;
if (ptr!=NULL)
{
  if (it==NULL)
    sprintf(str,"[]");
  else if (it->n<1)
    sprintf(str,"[]");
  else
  {
    sprintf(str,"[");
    str+=strlen(str);
    for (i=1;i<=it->n;++i)
    {
      sprintf(str,"%i",it->t[i]);  str+=strlen(str);
      if (i<it->n)
      {
        sprintf(str,",");
        str+=strlen(str);
      }
    }
    sprintf(str,"]");
  }
}
}


int wholevardim(varholder var)
    /* Vrne celotno dimenzijo spremenljivke, ki jo predstavlja var. To je
    produkt posameznih dimenzij na var->dim. Ce je rang var enak 0 (v primeru,
    ko je var->rank==0 in var->v!=NULL), vrne 1. Ce var ni pripravljena za
    nosenje vrednosti, vrne funkcija 0.
    $A igor dec97; */
{
int ret=1,i;
if (var!=NULL)
{
  if (var->rank==0)
  {
    if (var->v!=NULL)
      return 1;
    else
      return 0;
  } else if (var->rank>0)
  {
    if (var->dim==NULL || var->v==NULL)
      return 0;
    else
    {
      for (i=1;i<=var->rank;++i)
        ret*=var->dim[i];
      return ret;
    }
  } else
    return 0;
} else
  return 0;
return ret;
}

char equalvardimit(varholder var,indtab it)
    /* Returns 1 if the dimensions of the varholder var agree with the
    dimensions on it, otherwise it returns 0.
    $A Igor nov02; */
{
char ret;
int i;
if (var==NULL)
  ret=0;
else
{
  if (it==NULL)
  {
    if (var->rank<1)
      ret=1;
    else
      ret=0;
  } else if (it->n<1)
  {
    if (var->rank<1)
      ret=1;
    else
      ret=0;
  } else
  {
    if (var->rank!=it->n || var->dim==NULL)
      ret=0;
    else
    {
      ret=1;
      for (i=1;ret&&i<=var->rank;++i)
      {
        if (it->t[i]!=var->dim[i])
          ret=0;
      }
    }
  }
}
return ret;
}

char equalvardim(varholder var1,varholder var2)
    /* returns 1 if the dimensions of the varholder var1 agree with the
    dimensions of var2, otherwise it returns 0. If either var1 or var2 or
    both are NULL, 0 is returned.
    $A Igor nov02; */
{
char ret;
int i;
if (var1==NULL || var2==NULL)
  ret=0;
else
{
  if (var2->rank<1)
  {
    if (var1->rank<1)
      ret=1;
    else
      ret=0;
  } else
  {
    if (var1->rank!=var2->rank || var1->dim==NULL || var2->dim==NULL)
      ret=0;
    else
    {
      ret=1;
      for (i=1;ret&&i<=var1->rank;++i)
      {
        if (var2->dim[i]!=var1->dim[i])
          ret=0;
      }
    }
  }
}
return ret;
}


int stringtovartype(char *typespec)
    /* Returns an integer equivalent of variable type that is determined by
    typespec. The returned value can be used for setting or checking variable
    types. 
    $A Igor aug05; */
{
int ret=(int) VT_UNDEF;
if ( cmpstrings(typespec,"count")==0 || cmpstrings(typespec,"counter")==0 )
  ret=(int) VT_COUNTER;
else if ( cmpstrings(typespec,"scal")==0 || cmpstrings(typespec,"scalar")==0 )
  ret=(int) VT_SCALAR;
else if ( cmpstrings(typespec,"vec")==0 || cmpstrings(typespec,"vector")==0 )
  ret=(int) VT_VECTOR;
else if ( cmpstrings(typespec,"mat")==0 || cmpstrings(typespec,"matrix")==0 )
  ret=(int) VT_MATRIX;
else if ( cmpstrings(typespec,"str")==0 || cmpstrings(typespec,"string")==0 )
  ret=(int) VT_STRING;
else if ( cmpstrings(typespec,"vfi")==0 || cmpstrings(typespec,"vfile")==0 )
  ret=(int) VT_VFILE;
else if ( cmpstrings(typespec,"any")==0 || stringlength(typespec)==0 )
  ret=(int) VT_ANY;
return ret;
}


char *vartypetostring(int type)
    /* Returns a string that represents a long name of the variable type.
    A constant string is returned that may not be de-allocated.
    Function returns "" if type is not a valid variable type ID.
    $A Igor aug05; */
{
switch(type)
{
  case VT_ANY:
    return "any";
    break;
  case VT_COUNTER:
    return "counter";
    break;
  case VT_SCALAR:
    return "scalar";
    break;
  case VT_VECTOR:
    return "vector";
    break;
  case VT_MATRIX:
    return "matrix";
    break;
  case VT_STRING:
    return "string";
    break;
  case VT_VFILE:
    return "vfile";
    break;
  case VT_UNDEF:
    /*
    return "undefined";
    */
    return "undefined";
    break;
  default:
    return "undefined";
    break;
}
}


void fprintvarholderspecname(FILE *fp,varholder v,
                             void fprintel(FILE *fp,void *ptr,char *name))
    /* Prints data about the variable v to the file fp. It also prints elements
    of v by the function fprintel(), which prints a specific element with a
    given name.
    $A Igor feb98; */
{
int i,j,n;
if (fp!=NULL)
{
  if (v!=NULL)
  {
    fprintf(fp,"Name: \"%s\"\n",v->name);
    fprintf(fp,"Type: %i (%s)\n",(int) v->type,vartypetostring(v->type));
    fprintf(fp,"Rank: %i\n",v->rank);
    if (v->rank>0)
    {
      fprintf(fp,"Dimension: ");
      for (i=1;i<=v->rank;++i)
      {
        fprintf(fp,"%i",v->dim[i]);
        if (i<v->rank)
          fprintf(fp,"x");
        else
          fprintf(fp,"\n");
      }
    }
    fprintf(fp,"Whole dimension: %i\n",wholevardim(v));
    if (v->v==NULL)
      fprintf(fp,"Value table not allocated\n");
    else if (v->rank>0)
    {
      int *tab=NULL,close,k;
      tab=malloc(v->rank*sizeof(int)); /* Za belezenje dimenzij */
      --tab; /* zato, da zacnemo elemente steti z 1 */
      for (i=1;i<=v->rank;++i)
        tab[i]=1;
      fprintf(fp,"Value table: ");
      for (j=1;j<=v->rank;++j)
      {
        fprintf(fp,"{");
        for (k=1;k<=v->rank-j;++k)
          fprintf(fp," ");
      }
      for (i=1;i<=wholevardim(v);++i)
      {
        close=0;
        for (j=v->rank;j>=1;--j)
          if (tab[j]>v->dim[j])
          {
            ++close;
            tab[j]=1;
            ++tab[j-1];
          }
        if (close>0)
        {
          for (j=1;j<=close;++j)
          {
            fprintf(fp,"}");
            for (k=1;k<=j;++k)
              fprintf(fp," ");
          }
          for (j=1;j<=close;++j)
          {
            fprintf(fp,"{");
            for (k=1;k<=close-j;++k)
              fprintf(fp," ");
          }
        }
        /*
        for (k=1;k<=v->rank;++k)
          fprintf(fp,"%i",tab[k]);
        fprintf(fp,":");
        */
        if (v->v[i]==NULL)
          fprintf(fp,"0");
        else
          fprintf(fp,"1");
        /*
        if (tab[v->rank]<v->dim[v->rank])
          fprintf(fp,",");
        */
        ++tab[v->rank];
      }
      for (j=1;j<=v->rank;++j)
      {
        fprintf(fp,"}");
        if (j<v->rank)
          for (k=1;k<=j;++k)
            fprintf(fp," ");
      }
      fprintf(fp,"\n");
      if (fprintel!=NULL)
      {
        fprintf(fp,"\nElements:\n");
        for (i=1;i<=v->rank;++i)
          tab[i]=1;
        /* fprintf(fp,"Value table: "); */
        for (j=1;j<=v->rank;++j)
        {
          fprintf(fp,"{");
          for (k=1;k<=v->rank-j;++k)
            fprintf(fp," ");
        }
        for (i=1;i<=wholevardim(v);++i)
        {
          close=0;
          for (j=v->rank;j>=1;--j)
            if (tab[j]>v->dim[j])
            {
              ++close;
              tab[j]=1;
              ++tab[j-1];
            }
          if (close>0)
          {
            for (j=1;j<=close;++j)
            {
              fprintf(fp,"}");
              for (k=1;k<=j;++k)
                fprintf(fp," ");
            }
            for (j=1;j<=close;++j)
            {
              fprintf(fp,"{");
              for (k=1;k<=close-j;++k)
                fprintf(fp," ");
            }
          }
          /*
          if (v->v[i]==NULL)
            fprintf(fp,"0");
          else
            fprintf(fp,"1");
          */
          fprintf(fp,"\n  %s[",v->name);
          for (n=1;n<=v->rank;++n)
          {
            fprintf(fp,"%i",tab[n]);
            if (n<v->rank)
              fprintf(fp,",");
          }
          fprintf(fp,"]:\n");
          fprintel(fp,v->v[i],v->name);
          ++tab[v->rank];
        }
        for (j=1;j<=v->rank;++j)
        {
          fprintf(fp,"}");
          if (j<v->rank)
            for (k=1;k<=j;++k)
              fprintf(fp," ");
        }
        fprintf(fp,"\n");
        ++tab;
        if (tab!=NULL)
          free(tab);
      }
    } else
    {
      fprintf(fp,"Value table: ");
      if (v->v[1]==NULL)
        fprintf(fp,"{ 0 }\n");
      else
        fprintf(fp,"{ 1 }\n");
      if (fprintel!=NULL)
      {
        fprintf(fp,"Element:\n");
        fprintf(fp,"\n  %s:\n",v->name);
        fprintel(fp,v->v[1],v->name);
      }
     }
  } else
    fprintf(fp,"NULL.\n");
}
fprintf(fp,"\n");
}


static void (*printelauxname) (void *ptr,char *name)=NULL; /* Aux. func. for stdfprintel() */

static void stdfprintelname(FILE *fp,void *ptr,char *name)
    /* Auxiliary function which enables use of the function
    fprintvarholderspecname() in printvarholderspecname().
    $A Igor feb98; */
{
if (printelauxname!=NULL)
  printelauxname(ptr,name);
}

void printvarholderspecname(varholder v,void printel(void *,char *))
    /* Prints data about the variable v to the standard output. It also prints
    elements of v by the function fprintel(), which prints a specific element
    with a given name.
    $A Igor feb98; */
{
printelauxname=printel;
fprintvarholderspecname(stdout,v,stdfprintelname);
}



void fprintvarholderspec(FILE *fp,varholder v,void fprintel(FILE *,void *))
    /* Prints data about the variable v to the file fp. Elements of v are
    printed by the function fprintel().
    $A Igor feb98; */
{
int i,j,n;
if (fp!=NULL)
{
  if (v!=NULL)
  {
    fprintf(fp,"Name: \"%s\"\n",v->name);
    fprintf(fp,"Type: %i (%s)\n",(int) v->type,vartypetostring(v->type));
    fprintf(fp,"Rank: %i\n",v->rank);
    if (v->rank>0)
    {
      fprintf(fp,"Dimension: ");
      for (i=1;i<=v->rank;++i)
      {
        fprintf(fp,"%i",v->dim[i]);
        if (i<v->rank)
          fprintf(fp,"x");
        else
          fprintf(fp,"\n");
      }
    }
    fprintf(fp,"Whole dimension: %i\n",wholevardim(v));
    if (v->v==NULL)
      fprintf(fp,"Value table not allocated\n");
    else if (v->rank>0 )
    {
      int *tab=NULL,close,k;
      tab=malloc(v->rank*sizeof(int)); /* Za belezenje dimenzij */
      --tab; /* zato, da zacnemo elemente steti z 1 */
      for (i=1;i<=v->rank;++i)
        tab[i]=1;
      fprintf(fp,"Value table: ");
      for (j=1;j<=v->rank;++j)
      {
        fprintf(fp,"{");
        for (k=1;k<=v->rank-j;++k)
          fprintf(fp," ");
      }
      for (i=1;i<=wholevardim(v);++i)
      {
        close=0;
        for (j=v->rank;j>=1;--j)
          if (tab[j]>v->dim[j])
          {
            ++close;
            tab[j]=1;
            ++tab[j-1];
          }
        if (close>0)
        {
          for (j=1;j<=close;++j)
          {
            fprintf(fp,"}");
            for (k=1;k<=j;++k)
              fprintf(fp," ");
          }
          for (j=1;j<=close;++j)
          {
            fprintf(fp,"{");
            for (k=1;k<=close-j;++k)
              fprintf(fp," ");
          }
        }
        /*
        for (k=1;k<=v->rank;++k)
          fprintf(fp,"%i",tab[k]);
        fprintf(fp,":");
        */
        if (v->v[i]==NULL)
          fprintf(fp,"0");
        else
          fprintf(fp,"1");
        /*
        if (tab[v->rank]<v->dim[v->rank])
          fprintf(fp,",");
        */
        ++tab[v->rank];
      }
      for (j=1;j<=v->rank;++j)
      {
        fprintf(fp,"}");
        if (j<v->rank)
          for (k=1;k<=j;++k)
            fprintf(fp," ");
      }
      fprintf(fp,"\n");
      if (fprintel!=NULL)
      {
        fprintf(fp,"\nElements:\n");
        for (i=1;i<=v->rank;++i)
          tab[i]=1;
        /* fprintf(fp,"Value table: "); */
        for (j=1;j<=v->rank;++j)
        {
          fprintf(fp,"{");
          for (k=1;k<=v->rank-j;++k)
            fprintf(fp," ");
        }
        for (i=1;i<=wholevardim(v);++i)
        {
          close=0;
          for (j=v->rank;j>=1;--j)
            if (tab[j]>v->dim[j])
            {
              ++close;
              tab[j]=1;
              ++tab[j-1];
            }
          if (close>0)
          {
            for (j=1;j<=close;++j)
            {
              fprintf(fp,"}");
              for (k=1;k<=j;++k)
                fprintf(fp," ");
            }
            for (j=1;j<=close;++j)
            {
              fprintf(fp,"{");
              for (k=1;k<=close-j;++k)
                fprintf(fp," ");
            }
          }
          /*
          if (v->v[i]==NULL)
            fprintf(fp,"0");
          else
            fprintf(fp,"1");
          */
          fprintf(fp,"\n  %s[",v->name);
          for (n=1;n<=v->rank;++n)
          {
            fprintf(fp,"%i",tab[n]);
            if (n<v->rank)
              fprintf(fp,",");
          }
          fprintf(fp,"]:\n");
          fprintel(fp,v->v[i]);
          ++tab[v->rank];
        }
        for (j=1;j<=v->rank;++j)
        {
          fprintf(fp,"}");
          if (j<v->rank)
            for (k=1;k<=j;++k)
              fprintf(fp," ");
        }
        fprintf(fp,"\n");
        ++tab;
        if (tab!=NULL)
          free(tab);
      }
    } else
    {
      fprintf(fp,"Value table: ");
      if (v->v[1]==NULL)
        fprintf(fp,"{ 0 }\n");
      else
        fprintf(fp,"{ 1 }\n");
      if (fprintel!=NULL)
      {
        fprintf(fp,"Element:\n");
        fprintf(fp,"\n  %s:\n",v->name);
        fprintel(fp,v->v[1]);
      }
    }
  } else
    fprintf(fp,"NULL.\n");
}
fprintf(fp,"\n");
}


static void (*printelaux) (void *ptr)=NULL; /* Aux. func. for stdfprintel() */

static void stdfprintel(FILE *fp,void *ptr)
    /* Auxiliary function which enables use fo the function
    fprintvarholderspec() in the printvarholderspec().
    $A Igor feb98; */
{
if (printelaux!=NULL)
  printelaux(ptr);
}

void printvarholderspec(varholder v,void printel(void *))
    /* Prints data about the variable v to the standard output. Elements of v
    are printed by the function fprintel().
    $A Igor feb98; */
{
printelaux=printel;
fprintvarholderspec(stdout,v,stdfprintel);
}


void fprintvarholder(FILE *fp,varholder v)
    /* Prints data about the variable v to the file fp.
    $A Igor jan98, feb98; */
{
fprintvarholderspec(fp,v,NULL);
}


void printvarholder(varholder v)
    /* Prints data about the variable v to the standard output.
    $A Igor jan98, feb98; */
{
printvarholderspec(v,NULL);
}


varholder newvarholder(indtab dimit)
    /* Allocates space for a new varholder and returns a pointer to the
    allocated object. dimit must contain dimensions of the returned varholder
    (this enables use of multi-dimensional variables of arbitrary ranks, e.g.
    of dimensions 3x2x5). If dimit is NULL, then tehe returned varholder is of
    rank 0 and a single element can be stored on it (i.e. in the corresponding
    variable represented by the varholder). The same situation occur if
    dimit->n is 0.
      The returned object has the table of elements (...)->v already allocated,
    The rank (...)->rank is seto to the number of indices of dimit, and
    (...)->dim contains the dimensions from it.
    $A Igor nov02; */
{
varholder ret=NULL;
if (dimit==NULL)
{
  ret=malloc(sizeof(*ret));
  ret->name=NULL;
  ret->type=VT_UNDEF;
  ret->rank=0;
  ret->dim=NULL;
  ret->v=malloc(sizeof(void *));
  --ret->v;
  ret->v[1]=NULL;
} else
{
  if (dimit->n<1)
    ret=newvarholderst(NULL);
  else
  {
    int wholedim=1,i,d;
    ret=malloc(sizeof(*ret));
    ret->name=NULL;
    ret->rank=0;
    ret->dim=malloc(dimit->n*sizeof(*(ret->dim)) );
    --ret->dim;
    for (i=1;i<=dimit->n;++i)
    {
      d=dimit->t[i];
      if (d>0)
      {
        ++(ret->rank);
        wholedim*=d;
        ret->dim[i]=d;
      } else
      {
        errfunc0("newvarholder");
        sprintf(ers(),"Invalid dimension specification: ");
        sprintindspec(ers(),dimit);
        sprintf(ers(),"\n%i-th dimension may not be 0.\n",i);
        errfunc2();
      }
    }
    ret->v=malloc(wholedim*sizeof(void *));
    --ret->v;
    for (i=1;i<=wholedim;++i)
      ret->v[i]=NULL;
  }
}
return ret;
}

varholder newvarholdername(char *name,indtab dimit)
    /* Creates a new varholder object named name. dimit must be a table of
    dimension of the created varholder. The function allocates the space by
    the function newvarholderst(), copies the string name to the field
    (...)->name (space for this is allocated) and returns the created object.
    An error is reported if name does not satisfy variable naming conventions.
    $A Igor nov02; */
{
varholder ret;
if (! legalvarname(name))
{
  errfunc0("newvarholdername");
  sprintf(ers(),"\"%s\" is not a legal variable name. Variable space is allocated anyway.\n",name);
  errfunc2();
}
ret=newvarholder(dimit);
ret->name=stringcopy(name);
return ret;
}

varholder newvarholdernametype(char *name,int type,indtab dimit)
    /* Creates a new varholder object named name of the type type and returns
    its pointer.
    $A Igor avg01; */
{
varholder ret;
if ((int) type<(int) 1 || (int) type>(int) VT_NUMTYPES)
{
  errfunc0("newvarholdernametype");
  fprintf(erf(),"Invalid type %s (type num. %i).\n",
   vartypetostring(type),(int) type);
  errfunc2();
  return NULL;
} else if (! legalvarname(name))
{
  errfunc0("newvarholdernametype");
  fprintf(erf(),"\"%s\" is not a legal variable name. Variable space is allocated anyway.\n",name);
  errfunc2();
}
ret=newvarholder(dimit);
ret->name=stringcopy(name);
ret->type=type;
return ret;
}

void dispvarholder(varholder *pointvar)
    /* Deallocates the varholder pointed to by *pointvar and sets this pointer
    to NULL. The function does not delete the variable elements, which are on
    var->v (since it does not know what types of objects these are).
    $A Igor jan98; */
{
varholder var;
if (pointvar!=NULL)
{
  var=*pointvar;
  if (var!=NULL)
  {
    if (var->name!=NULL)
      free(var->name);
    if (var->dim!=NULL)
    {
      ++(var->dim);
      free(var->dim);
    }
    if (var->v!=NULL)
    {
      ++(var->v);
      free(var->v);
    }
    free(var);
    *pointvar=NULL;
  }
}
}



static int cmpvarname(char *name,varholder var)
    /* Ce je var enak 0, vrne -1, drugace pa cmpstrings(name,var->name).
    $A Igor jan98; */
{
if (var!=NULL)
{
  return cmpstrings(name,var->name);
} else return -1;
}

static int cmpvar(varholder var1, varholder var2)
    /* Primerja var1 in var2 po njunih imenih ((...)->name). Ce sta oba
    razlicna od NULL, vrne cmpstrings(var1->name,var2->name). Ce je katera od
    spremenljivk enaka NULL ali je katero od imen enako NULL, vrne vrednost,
    kot je nakazano v spodnji tabeli:
     var1 |  var2 |  var1->name | var2->name | vrnjena vred.
     -------------------------------------------------------
     NULL |  xxx  |             |            |   1
     xxx  |  NULL |             |            |  -1
     NULL |  NULL |             |            |   0
     xxx  |  xxx  |  NULL       | xxx        |   1
     xxx  |  xxx  |  xxx        | NULL       |  -1
     xxx  |  xxx  |  NULL       | NULL       |   0
    $A igor jan98; */
{
int ret;
if (var1!=NULL && var2!=NULL)
{
  if (var1->name!=NULL && var2->name!=NULL)
  {
    ret=cmpstrings(var1->name,var2->name);
  } else
  {
    if (var1->name==NULL)
    {
      if (var2->name!=NULL)
        ret=1;
      else
        ret=0;
    } else
      ret=-1;
  }
} else
{
  if (var1==NULL)
  {
    if (var2!=NULL)
      ret=1;
    else
      ret=0;
  } else
    ret=-1;
}
return ret;
}
















indtab getvardim(varholder var,indtab *dimp)
    /* Updates index table *dimp in such a way that it contains dimensions of
    the variable represented by the varholder var, and returns *dimp. dimp
    can be NULL, in this case a newly created index table or NULL is returned,
    dependent on the dimensions of var.
      After the function call, *dimp (or the returned index table) is such that
    the function newvarholder() called with *dimp as its argument returns a
    varholder with the same dimensions as var. If var is NULL or var->rank<0,
    then *dimp becomes NULL. If var->rank is 0, then *dimp becomes an
    allocated, but empty index table. If var->rank>0, then *dimp contains
    var->rank indices whose values are equal to the dimensions contained in
    var->dim.
    $A Igor nov02 */
{
int i;
indtab dim;
if (dimp!=NULL)
{
  if (var==NULL)
    dispindtab(dimp);
  else
  {
    if (var->rank==0)
    {
      if (*dimp==NULL)
        *dimp=newindtab(3,0);
      else
      {
        (*dimp)->n=0; (*dimp)->ex=3;
      }
    } else if (var->rank>0)
    {
      if (*dimp==NULL)
        *dimp=newindtab(3,var->rank);
      if ((*dimp)->r<var->rank)
        resizeindtab(dimp,3,0,var->rank);
      else
        (*dimp)->n=var->rank;
      for (i=1;i<=var->rank;++i)
        (*dimp)->t[i]=var->dim[i];
    } else
      dispindtab(dimp);  /* var->rank<0 */
  }
  return *dimp;
} else
  return getvardim(var,&dim);
}



int calcvarplace(varholder var,indtab it)
    /* Calculates and returns the consecutive number of the element defined
    by indices in it, in the element table of varholder var, or 0, if the
    element specified does not exist. If var->rank is 0, it must be NULL or
    nt->n must be 0 in order to return a non-zero value (namely 1).
    $A Igor nov02; */
{
int place=0,weight,i;
char error=0;
if (it!=NULL && var!=NULL)
{
  if (var->rank==0)
  {
    if (it->n<1)
      place=1;
    else
      place=0;
  } else if (var->rank>0 && var->dim!=NULL && it->n==var->rank)
  {
    /* place=0; */
    weight=wholevardim(var);
    if (weight>0)
      for (i=1;i<=var->rank;++i)
        if (var->dim[i]>0)
        {
          if (it->t[i]>var->dim[i])
            error=1;
          else
          {
            weight/=var->dim[i];
            place+=weight*(it->t[i]-1);
          }
        } else
          error=1;
    ++place;
    if (error)
        place=0;
  }
} else if (var!=NULL)
{
  /* it=NULL */
  if (var->rank==0)
    place=1;
} else
  place=0;
return place;
}



int setvar(varholder var,void *p,int place)
    /* Puts the pointer p to the absolute place place in the element table of
    var, if this is possible, and returns place or 0, if this is not possible
    (e.g. if the elment table has less entries than place). If place==0, it is
    taken as 1.
    $A Igor nov01; */
{
int ret=0;
if (var!=NULL && place>0)
{
  if (wholevardim(var)>=place)
  {
     var->v[place]=p;
     ret=place;
  } else
  {
    errfunc0("setvar");
    sprintf(ers(),"Place (%i) greater than total number of elements (%i).",
      place,wholevardim(var));
    errfunc2();
  }
} else if (place<1)
{
  errfunc0("setvar");
  sprintf(ers(),"Place less than zero (%i).",place);
  errfunc2();
} else if (var==NULL)
{
  errfunc0("setvar");
  sprintf(ers(),"Varholder is NULL.");
  errfunc2();
}
return ret;
}



void dispvarval(varholder var)
    /* Delets all elements form the varholder var by free() and sets the
    corresponding pointers to NULL. For deleting of elements that are of more
    complex types, the functio dispvarvalspec() must be used.
    $A Igor nov02; */
{
int dim,i;
dim=wholevardim(var);
for (i=1;i<=dim;++i)
  if (var->v[i]!=NULL)
  {
    free(var->v[i]);
    var->v[i]=NULL;
  }
}


void dispvarvalspec(varholder var,void disp (void **))
    /* Delets all elements form the varholder var using function disp(), which
    must set pointer to NULL after deletion.
    $A Igor nov02; */
{
if (var!=NULL)
{
int dim,i;
dim=wholevardim(var);
for (i=1;i<=dim;++i)
  if (var->v[i]!=NULL)
  {
    disp(&(var->v[i]));
    var->v[i]=NULL;
  }
}
}



void dispwholevar(varholder *var)
    /* Deallocates the space occupied by *var and sets *var to NULL. Elements
    of *var (contained in (*var)->v) are deleted by free(), therefore for
    varholders containing more complex objects, function dispwholevarspec()
    must be used.
    $A Igor nov02; */
{
if (var!=NULL)
{
  dispvarval(*var);
  dispvarholder(var);
}
}


void dispwholevarspec(varholder *var,void (*disp)(void **))
    /* Deallocates the spece occupied by *var and sets *var to NULL. Elements
    of *var (contained in (*var)->v) are deleted by disp()
    $A Igor nov02; */
{
if (var!=NULL)
{
  dispvarvalspec(*var,disp);
  dispvarholder(var);
}
}



void *varel(varholder var,indtab idx)
    /* Returns the element of var specified by indices on idx, as void *, or
    NULL, if such element does not exist.
    $A Igor nov02; */
{
int place;
if ((place=calcvarplace(var,idx))>0)
  return var->v[place];
else
  return NULL;
}

void **vareladdr(varholder var,indtab idx)
    /* Returns the address of the element specified by indices idx of var as
    void **, or NULL if indices are not in range.
    $A Igor nov02; */
{
int place;
if ((place=calcvarplace(var,idx))>0)
  return &(var->v[place]);
else
  return NULL;
}


void *varelfirst(varholder var)
    /* Returns the first element of var, or NULL, if such element does not
    exist.
    $A Igor aug04; */
{
if (var!=NULL)
  if (var->v!=NULL)
    return var->v[1];
return NULL;
}

void **vareladdrfirst(varholder var)
    /* Returns the address of the first element of var as void **, or NULL if
    indices are not in range.
    $A Igor aug04; */
{
if (var!=NULL)
  if (var->v!=NULL)
    return &(var->v[1]);
return NULL;
}


static void restvardim(varholder var,indtab dim,indtab *rest)
    /* Loads the rest dimensions from var (contained in var->dim), which are
    not included in dim, to *rest. It does not check whether the dimensions
    on dim coincide with the first dimensions of var. If the rest dimensions
    can not be defined (either dim->n equals var->rank or var does not contain
    any elments), *rest becomes NULL.
    $A Igor nov02; */
{
int covered=0,i;
if (rest!=NULL)
{
  if (var==NULL)
    dispindtab(rest);
  else
  {
    if (dim!=NULL)
      covered+=dim->n;
    if (covered>=var->rank || var->dim==NULL)
    {
      dispindtab(rest);
      if (covered>var->rank)
      {
        errfunc0("restvardim");
        sprintf(ers(),"Number of reference dimensions %i greater than variable rank %i.",
          dim->n,var->rank);
        errfunc2();
      }
      if (var->dim==NULL && var->rank>0)
      {
        errfunc0("restvardim");
        sprintf(ers(),"Table of dimensions is NULL, although rank is %i.",
          var->rank);
        errfunc2();
      }
    } else
    {
      /* Everything's OK, the rest dimensions are loded on *rest. */
      resizeindtab(rest,3,0,var->rank-covered);  /* ensure necessary space */
      for (i=1;i<=var->rank-covered;++i) /* transcription of dimensions to *rest */
        (*rest)->t[i]=var->dim[covered+i];
    }
  }
} else
{
  errfunc0("restvardim");
  sprintf(ers(),"The address of the resulting index table not specified.");
  errfunc2();
}
}




#if 0
static int incelit(indtab elit,indtab dimit)
    /* Increments element index in a multi-dimensional table specified by elit
    where dimensions of the element table are specified by dimit. If the
    incrementation of indices is successful, 1 is returned, otherwise 0 is
    returned (e.g. if indices on elst would fall out of range specified by
    dimit after incrementation).
      If the number of indices on elit is smaller than the number of indices
    on dimit, it is assumed that indices on elit correspond to the last
    elit->n dimensions on dimit.
    $A Igor nov02; */
{
int i,ret=0,excluded=0;
if (dimit!=NULL && elit!=NULL)
{
  if (dimit->n>0 && elit->n<=dimit->n && elit->n>0)
  {
    excluded=dimit->n-elit->n; /* num. dim. not included in treatment */
    /* Increment the last index: */
    /*
    pel=elst->s[elst->n];
    if (pel!=NULL)
    {
      ++(*pel);
      ret=1;
    }
    */
    ++(elit->t[elit->n]);
    ret=1;
    for (i=elit->n;i>1;--i)
    {
      if (elit->t[i]>dimit->t[i+excluded])
      {
        /* If specific index is greater that the corresponding dimension,
        it is set to 1 ans the index of higher importance is increased: */
        elit->t[i]=1;
        ++(elit->t[i-1]);
      }
    }
    /* We check that indices on elit did not run out of range specified by
    dimit (in this case 0 must be returned): */
    if (elit->t[1]>dimit->t[1+dimit->n-elit->n])
      return 0;
  } else
  {
    if (elit->n>dimit->n)
    {
      errfunc0("incelit");
      sprintf(ers(),"Number of indices (%i) is greater than number of dimensions (%i).",
        elit->n,dimit->n);
      errfunc2();
    }
  }
} else
{
  if (elit!=NULL)
     if (elit->n>0)
    {
      /* dimit=NULL */
      errfunc0("incelit");
      sprintf(ers(),"Table of dimensions is NULL (number of indices: %i).",
        elit->n);
      errfunc2();
    }
}
return ret;
}
#endif /* #if 0 */



static int incelvar(indtab elit,varholder var,int excluded)
    /* Increments index elit of an element in a multi-dimensional sub-table of
    elements contained in var. The first (excluded) indices of elit define the
    sub-table within which element indices can be incremented and therefore
    remain fixed. 
      If the incrementation of indices is successful, 1 is returned, otherwise
    0 is returned (e.g. if indices on elst would fall out of range specified by
    the dimensions of var and "excluded" after the incrementation).
      The number of indices on elit must be the same as the number of
    dimensions of var. Excluded must not be greater than the number of
    dimensions.
      If elit represents the last element of the sub-table, i.e. index can not
    be increased without falling out of range, then indices on elit remain
    unchanged after the call to this function.
    $A Igor nov02; */
{
int i,j,ret=0;
if (var!=NULL && elit!=NULL)
{
  if (var->rank>0 && elit->n==var->rank && excluded<var->rank && var->dim!=NULL)
  {
    i=elit->n;
    while(i>excluded)
    {
      if (elit->t[i]<var->dim[i])
      {
        /* We found index which can be increased and stay in range" */
        ++(elit->t[i]);
        /* Reset all inner-more indices (if any) and return 1: */
        for (j=i+1;j<=elit->n;++j)
          elit->t[j]=1;
        return 1;
      }
    }
    return 0; /* no index can be incremented */
  } else
  {
    /* No free indices oradequate arguments */
    if (elit->n!=var->rank)
    {
      errfunc0("incelvar");
      sprintf(ers(),"Number of indices (%i) is different than number of dimensions (%i).",
        elit->n,var->rank);
      errfunc2();
    }
    if (excluded>var->rank)
    {
      errfunc0("incelvar");
      sprintf(ers(),"Number of excluded indices (%i) is greater than the number of dimensions (%i).",
        excluded,var->rank);
      errfunc2();
    }
    if (var->rank>0 && var->dim==NULL)
    {
        errfunc0("incelvar");
        sprintf(ers(),"Table of variable dimensions is NULL while its rank is %i.",
          var->rank);
        errfunc2();
    }
    return 0;
  }
} else
{
  if (elit!=NULL)
  {
    if (elit->n>0)
    {
      /* dimit=NULL */
      errfunc0("incelvar");
      sprintf(ers(),"Table of dimensions is NULL while number of indices is %i.",
        elit->n);
      errfunc2();
    }
  } else if (var!=NULL)
  {
    if (var->rank>0)
    {
      errfunc0("incelvar");
      sprintf(ers(),"Table of indices is NULL while number of dimensions is %i.",
        var->rank);
      errfunc2();
    }
  }
  return 0;
}
}



static int incelit(indtab elit,indtab dimit,int excluded)
    /* Increments index elit of an element in a multi-dimensional subtable
    where dimensions of the whole element table are specified by dimit. The
    first (excluded) indices of elit define the sub-table within which element
    indices can not change and remain fixed. 
      If the incrementation of indices is successful, 1 is returned, otherwise
    0 is returned (e.g. if indices on elst would fall out of range specified by
    dimit and excluded after incrementation).
      The number of indices on elit must be the same as the number of indices
    on dimit. Excluded must not be greater than the number of dimensions.
      If elit represents the last element of the sub-table, i.e. index can not
    be increased without falling out of range, then indices on elit remain
    unchanged after the call to this function.
    $A Igor nov02; */
{
int i,j,ret=0;
if (dimit!=NULL && elit!=NULL)
{
  if (dimit->n>0 && elit->n==dimit->n && excluded<dimit->n)
  {
    i=elit->n;
    while(i>excluded)
    {
      if (elit->t[i]<dimit->t[i])
      {
        /* We found index which can be increased and stay in range" */
        ++(elit->t[i]);
        /* Reset all inner-more indices (if any) and return 1: */
        for (j=i+1;j<=elit->n;++j)
          elit->t[j]=1;
        return 1;
      }
    }
    return 0; /* no index can be incremented */
  } else
  {
    /* No free indices or adequate arguments */
    if (elit->n!=dimit->n)
    {
      errfunc0("incelit");
      sprintf(ers(),"Number of indices (%i) is different than number of dimensions (%i).",
        elit->n,dimit->n);
      errfunc2();
    }
    if (excluded>dimit->n)
    {
      errfunc0("incelit");
      sprintf(ers(),"Number of excluded indices (%i) is greater than the number of dimensions (%i).",
        excluded,dimit->n);
      errfunc2();
    }
    return 0;
  }
} else
{
  if (elit!=NULL)
  {
    if (elit->n>0)
    {
      /* dimit=NULL */
      errfunc0("incelit");
      sprintf(ers(),"Table of dimensions is NULL while number of indices is %i.",
        elit->n);
      errfunc2();
    }
  } else if (dimit!=NULL)
  {
    if (dimit->n>0)
    {
      errfunc0("incelit");
      sprintf(ers(),"Table of indices is NULL while number of dimensions is %i.",
        dimit->n);
      errfunc2();
    }
  }
  return 0;
}
return ret;
}


static char firstindicesinrangeit(varholder var,indtab elit)
    /* Returns 1, if all the indices on elit are in range of the first
    elit->n dimensions of var, otherwise it returns 0.
      If there are more indices in elit than var->rank, if var->rank<1 or
    var is NULL, then also 0 is returned.
    $A Igor nov02; */
{
char ret=1;
int i,ind;
if (var==NULL)
  return 0;
else if (var->rank<0)
  return 0;
else if (elit!=NULL)
{
  if (elit->n>0)
  {
    if (elit->n>var->rank)
      return 0;
    else if (var->dim==NULL||var->v==NULL)
      return 0;
    else for (i=1;i<=elit->n;++i)
    {
      ind=elit->t[i];
      if (ind>var->dim[i] || ind<=0)
        return 0;
    }
    return 1;
  } else
    return 1;
} else
  return 1;
}


static char elinrangeit(indtab el,indtab dim)
    /* Returns 1, if indices on el are in range specified by dimensions on
    dim, otherwise it returns 0. If the number of indices on el is smaller
    than the number of dimensions on dim, it is assumed that the last el->n
    dimensions on dim correspond to indices on el.
    $A Igor nov02; */
{
char ret=1;
int i,excluded,ind;
if (el!=NULL)
{
  if (dim==NULL)
    return 0;
  else
  {
    if (el->n>0)
    {
      if (dim->n<el->n)
        return 0;
      else
      {
        excluded=dim->n-el->n;
        for (i=1;i<=el->n;++i)
        {
          ind=el->t[i];
          if (ind>dim->t[i+excluded]||ind<=0)
            return 0;
        }
        return 1;
      }
    } else
      return 1;
  }
} else
  return 1;
}


static char equaldimit(indtab it1,indtab it2)
    /* Returns 1 if tables of dimensions it1 and it2 are equal and 0 if they
    are not. Dimensions are not considered equal if for example it1 is NULL
    and it2 has on index which is 1, even if in that case the total number of 
    elements represented by it1 and it2 is the same. Dimensions are considered
    equal e.g. if it1==NULL and it2->n==0.
    $A Igor nov02; */
{
int i;
if (it1==NULL)
{
  if (it2!=NULL)
  {
    if (it2->n>0)
      return 0;
    else
      return 1;
  } else
    return 1;
} else if (it2==NULL)
{
  if (it1->n>0)
    return 0;
  else
    return 1;
} else if (it1->n!=it2->n)
  return 0;
else if (it1->n>0)
{
  for (i=1;i<=it1->n;++i)
  {
    if (it1->t[i]!=it2->t[i])
      return 0;
  }
  return 1;
}
}



static int totaldimit(indtab it)
    /* Returns total number of elements in the multi-dimensional table whose
    dimensions are specified by it. If it==NULL or it->n==0, 1 is returned 
    since this corresponds to a table of rank 0, but with 1 element.
    $A Igor jan98; */
{
int ret=1,i;
if (it!=NULL)
  for (i=1;i<=it->n;++i)
  {
    ret*=it->t[i];
    if (ret<0)
    {
      errfunc0("totaldimit");
      sprintf(ers(),"%i-th dimension is negative (%i)!",i,it->t[i]);
      errfunc2();
      ret=0;
    }
  }
return ret;
}




int simpvarop(varholder var1,indtab which1,void operation(void *operand1))
    /* Performs the operation operation on elements of the varholder
    var1. Index table which1 determines the sub-table of elements on which
    the operation is performed.
      Rules concerning dimensions:
     if which1==NULL or which1->n==0, the operation is performed on all
    elements of var1.
     Indices on which1 correspond to the first dimensions of var1. If any of
    them exceeds the corresponding dimension or the number of indices is
    greater than the number of dimensions of var1, this is an error.
      If an error occurs, the function returns the code of the error. We can
    call the function varoperrorstr() with this code as argument to get a
    string that describes the nature of the error. If everything is OK, the
    number of performed operations is returned.
    $A Igor nov02; */
{
int error=0,num=0,i,rank1=0,excluded1=0;
char proceed=1;
void *p1=NULL;
indtab el1=NULL;    /* complete indices that determine the currently treated element */
if (operation==NULL)
{
  errfunc0("simpvarop");
  sprintf(ers(),"Operation is NULL.");
  errfunc2();
  error=-1;
} else if (var1==NULL)
{
  errfunc0("simpvarop");
  sprintf(ers(),"The operand is NULL.");
  errfunc2();
  error=-3;
} else if (wholevardim(var1)<1)
{
  errfunc0("simpvarop");
  sprintf(ers(),"The operand contains no elements.");
  errfunc2();
  error=-5;
} else if (!firstindicesinrangeit(var1,which1))
{
  errfunc0("simpvarop");
  sprintf(ers(),"Index specification not in range: ");
  sprintindspec(ers(),which1);
  errfunc2();
  error=-8;
} else
{
  if (which1!=NULL)
    if (which1->n>0)
      excluded1=which1->n;
  if (var1!=NULL)
    if (var1->rank>0)
    {
      rank1=var1->rank;
      /* el1 becomes the index of the first element of the first sub-table on
      which the operation acts: */
      el1=newindtab(0,rank1);  el1->n=rank1;
      for (i=1;i<=excluded1;++i)
        el1->t[i]=which1->t[i];
      for (i=excluded1+1;i<=rank1;++i)
        el1->t[i]=1;
    }
  /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
  while (proceed)
  {
    p1=varel(var1,el1);  /* the current element: */
    operation(p1);  /* performance of operation */
    ++num;
    /* Incrementation of element indices; The first excluded1 indices of el1
    remains fixed: */
    incelvar(el1,var1,excluded1);
  }
}
/* Deletion of allocated memory: */
dispindtab(&el1);
if (error>=0)
  error=num; /* No error occured */
return error;
}


int simpvaropch(varholder var1,indtab which1,void operation(void **operand1))
    /* Perfomrs the operation "operation()" on those elements of var1, which
    are specified by indices on which1. The operation is such that it can
    change elements, not only use their values (therefore its argument is of
    type void **). For each affected element of var1, operation is called with
    its address as the argument.
      Indices on which1 determine the sub-table of elements of var1 on which
    the operation is performed. If which1==NULL or which1->n==0, then the
    whole table of elements is meant and the operation is performed in turns on
    each of the elements in the element table vari->v. The order is such that
    the last indices vary the most quickly.
      Indices on which1 refer to the first dimensions of var1. If any of them
      is not in the range of the corresponding dimension or if there are more
    indices than the number of dimensions of var1, this is an error.
      If an error occurs, the function returns the code of the error (always
    a negative number), otherwise it returns the number of executions of the
    operation. In the case of error, the function varoperrorstr() can be
    called on the returned error code in order to get a string description of
    the error.
    $A Igor nov02; */
{
int error=0,num=0,i,rank1=0,excluded1=0;
char proceed=1;
void **p1=NULL;
indtab el1=NULL;    /* complete indices that determine the currently treated element */
if (operation==NULL)
{
  errfunc0("simpvaropch");
  sprintf(ers(),"Operation is NULL.");
  errfunc2();
  error=-1;
} else if (var1==NULL)
{
  errfunc0("simpvaropch");
  sprintf(ers(),"The operand is NULL.");
  errfunc2();
  error=-3;
} else if (wholevardim(var1)<1)
{
  errfunc0("simpvaropch");
  sprintf(ers(),"The operand contains no elements.");
  errfunc2();
  error=-5;
} else if (!firstindicesinrangeit(var1,which1))
{
  errfunc0("simpvaropch");
  sprintf(ers(),"Index specification not in range: ");
  sprintindspec(ers(),which1);
  errfunc2();
  error=-8;
} else
{
  if (which1!=NULL)
    if (which1->n>0)
      excluded1=which1->n;
  if (var1!=NULL)
    if (var1->rank>0)
    {
      rank1=var1->rank;
      /* el1 becomes the index of the first element of the first sub-table on
      which the operation acts: */
      el1=newindtab(0,rank1);  el1->n=rank1;
      for (i=1;i<=excluded1;++i)
        el1->t[i]=which1->t[i];
      for (i=excluded1+1;i<=rank1;++i)
        el1->t[i]=1;
    }
  /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
  while (proceed)
  {
    p1=vareladdr(var1,el1);  /* the current element: */
    operation(p1);  /* performance of operation */
    ++num;
    /* Incrementation of element indices; The first excluded1 indices of el1
    remains fixed: */
    incelvar(el1,var1,excluded1);
  }
}
/* Deletion of allocated memory: */
dispindtab(&el1);
if (error>=0)
  error=num; /* No error occured */
return error;
}


int simpvaropeldata(varholder var1,indtab which1,
                    void operation(void *operand1,indtab elit))

    /* Performs the operation operation on elements of the varholder
    var1. Index table which1 determines the sub-table of elements on which
    the operation is performed. Beside of the element on which it acts, the
    operation also gets the indices of this element through its second
    argument (as an object of type indtab), so that they can be printed, for
    example.
      Rules concerning dimensions:
     if which1==NULL or which1->n==0, the operation is performed on all
    elements of var1.
     Indices on which1 correspond to the first dimensions of var1. If any of
    them exceeds the corresponding dimension or the number of indices is
    greater than the number of dimensions of var1, this is an error.
      If an error occurs, the function returns the code of the error. We can
    call the function varoperrorstr() with this code as argument to get a
    string that describes the nature of the error. If everything is OK, the
    number of performed operations is returned.
    $A Igor nov02; */
{
int error=0,num=0,i,rank1=0,excluded1=0;
char proceed=1;
void *p1=NULL;
indtab el1=NULL;    /* complete indices that determine the currently treated element */
if (operation==NULL)
{
  errfunc0("simpvaropeldata");
  sprintf(ers(),"Operation is NULL.");
  errfunc2();
  error=-1;
} else if (var1==NULL)
{
  errfunc0("simpvaropeldata");
  sprintf(ers(),"The operand is NULL.");
  errfunc2();
  error=-3;
} else if (wholevardim(var1)<1)
{
  errfunc0("simpvaropeldata");
  sprintf(ers(),"The operand contains no elements.");
  errfunc2();
  error=-5;
} else if (!firstindicesinrangeit(var1,which1))
{
  errfunc0("simpvaropeldata");
  sprintf(ers(),"Index specification not in range: ");
  sprintindspec(ers(),which1);
  errfunc2();
  error=-8;
} else
{
  if (which1!=NULL)
    if (which1->n>0)
      excluded1=which1->n;
  if (var1!=NULL)
    if (var1->rank>0)
    {
      rank1=var1->rank;
      /* el1 becomes the index of the first element of the first sub-table on
      which the operation acts: */
      el1=newindtab(0,rank1);  el1->n=rank1;
      for (i=1;i<=excluded1;++i)
        el1->t[i]=which1->t[i];
      for (i=excluded1+1;i<=rank1;++i)
        el1->t[i]=1;
    }
  /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
  while (proceed)
  {
    p1=varel(var1,el1);  /* the current element: */
    operation(p1,el1);  /* performance of operation */
    ++num;
    /* Incrementation of element indices; The first excluded1 indices of el1
    remains fixed: */
    incelvar(el1,var1,excluded1);
  }
}
/* Deletion of allocated memory: */
dispindtab(&el1);
if (error>=0)
  error=num; /* No error occured */
return error;
}




int unvarop(varholder var1,stack which1,varholder *res,stack whichres,
            void *operation(void *operand1,void **res),void disp(void **))
    /* 
    $$
    Izvrsi unarno operacijo operation nad elementi spremenljivke var1, pri
    cemer se rezultati spravijo kot elementi spremenljivke res. which1 pove,
    nad katero podtabelo spremenljivke var1 se izvrsi operacija, whichres pa
    pove, v katero podtabelo spremenljivke *res se spravijo rezultati.
     Pravila glede dimenzij:
     Ce na skladu whichres ni nobenih indeksov, je lahko dimenzija
    spremenljivke *res razlicna od dimenzije podtabele, nad katero se izvaja
    operacija. V tem primeru se spremenljivka *res najprej zbrise z vsemi
    elementi vred, nato pa se tvori na novo tako, da so vsi elementi pred
    izvedbo operacije enaki NULL in je dimenzija spremenljivke enaka dimenziji
    podtabele, nad katero se izvede operacija. Za brisanje elementov podtabele
    se uporabi funkcija disp (ce je disp==NULL, se elementi ne brisejo).
     Ce je na skladu whichres kak indeks, mora biti dimenzija podtabele
    spremenljivke *res, ki jo dolocajo indeksi na which, nujno enaka dimenziji
    podtabele, nad katero se izvede operacija operation.
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce  je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladih whichres in which1 se nanasajo na prve indekse
    ustreznih spremenljivk. Ce katerakoli od njihovih dimenzij ni v
    obsegu ustrezne dimenzije ali ce je indeksov vec kot ustreznih dimenzij
    (rang spremenljivke), je to napaka. Elementi na teh skladih so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
     Ce se med izvedbo funkcije nosilec *res brise in naredi na novo, se ohrani
    njgovo eime.
    $A Igor jan98 mar98; */
{
int error=0,num=0,i,*ip;
char proceed=1,*nameres=NULL;
void *p1=NULL,**pres=NULL;
varholder varres=NULL;
stack rest1=NULL,restres=NULL,  /* preostale dimenzije (ki niso na which...) */
      dim1=NULL,dimres=NULL,    /* celotne dimenzije */
      inc1=NULL,incres=NULL,    /* indeksi, ki se inkrementirajo */
      el1=NULL,elres=NULL,      /* kompletni indeksi */
      indexdim=NULL; /* dimenzija udelezenega dela tabele */
if (res==NULL)
  error=-2;
else
{
  if (operation==NULL)
    error=-1;
  else if (var1==NULL)
    error=-3;
  else if (wholevardim(var1)<1)
    error=-5;
  else if (!firstindicesinrangest(var1,which1))
    error=-8;
  else
  {
    if (*res!=NULL)
    {
      /* Ce je *res!=NULL, morajo biti indeksi na whichres v obsegu: */
      if (!firstindicesinrangest(*res,whichres))
        error=-7;
    } else
    {
      /* Ce pa je *res enak NULL, na whichres ne sme biti indeksov: */
      if (whichres!=NULL)
        if (whichres->n>0)
          error=-7;
    }
    /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
    restvardimst(*res,whichres,&restres);
    restvardimst(var1,which1,&rest1);
    indexdim=rest1;
    if (indexdim==NULL)
    {
      /* 1. primer: OPERACIJA SE IZVEDE NAD ENIM ELEMENTOM */
      /* Najprej se preveri, ce ni dimenzija *res neustrezna: */
      if (restres!=NULL)
        if (restres->n>0)
        {
          /* Ce obstaja specifikacija whichres, vendar ne doloca enega samega
          elementa na *res, je to napaka: */
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-20;
          if (!error)
          {
            /* Primer, ko *res ze obstaja, vendar je njegova dimenzija
            neustrezna in ga je treba brisati; samo v primeru, ko ni navedena
            specifikacija whichres: */
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name); /* Pred brisanjem shranemo ime */
            dispwholevarspec(res,disp);
          }
        }
      if (!error)
      {
        if (*res==NULL)
        {
          /* Ce je *res enak NULL, se tvori na novo: */
          *res=newvarholderst(indexdim);
          /* Ce smo v tej funkciji brisali *res, mu moramo dati nazaj isto ime,
          ko ga tvorimo na novo: */
          (*res)->name=nameres;
          nameres=NULL;
        }
        /* Dobimo ustrezne elemente in izvedemo operacijo nad njimi: */
        pres=vareladdrst(*res,whichres);
        p1=varelst(var1,which1);
        if (pres==NULL)
          error=-25;
        else
        {
          operation(p1,pres); /* izvedba operacije */
          ++num;
        }
      }
    } else
    {
      /* 2. primer: OPERACIJA SE IZVEDE NAD VEC ELEMENTI */
      if (!error)
      {
        if (!equaldimstack(indexdim,restres) || *res==NULL)
        /* Dimenzija *res ni ustrezna, zato se *res najprej brise in nato
        tvori na novo: */
        {
          /* Ce je podana specifikacija whichres in ni ustrezna, je to napaka: */
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-21;
          /* POMEMBNA OPOMBA: Ce je aktualna dimenzija spremenljivek, ki je
          rezultat operacije, razlicna od aktualne dimenzije operanda, to
          NI NAPAKA, ampak se spremenljivka rezultatov najprej pobrise in nato
          tvori na novo. Aktualna dimenzija je dimenzija dela tabele, nad
          katero se izvrsi operacija. To pravilo velja le, ce je indeks
          sklada whichres, ki doloca, kateri del tabele spremenljivke *res je 
          aktualen, niceln; Nasprotni primer velja za napako. */
          if (!error)
          {
            /* Ce specifikacija which ni bila podana, *res pa ni prave
            dimenzije, se *res zbrise, da se bo pozneje tvoril na novo: */
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name); /* Ime *res shranemo */
            dispwholevarspec(res,disp);
          }
        }
        if (!error)
        {
          if (*res==NULL)  /* Ce je *res NUL, se tvori na novo: */
          {
            *res=newvarholderst(indexdim);
            /* Ce je bil *res brisan, damo novo tvorjenemu *res prejsnje ime,
            ki smo ga shranili: */
            (*res)->name=nameres;
            nameres=NULL;
            /* Potrebno je se na novo popraviti dimenzijo indeksov za *res: */
            restvardimst(*res,whichres,&restres);
          }
          varres=*res;
          /* Priprava pomoznih skladov: */
          if (rest1!=NULL)
          {
            /* Indeksi operand, ki se bodo inkrementirali: */
            inc1=newstack(rest1->n);
            if (rest1->n>0)
              for (i=1;i<=rest1->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(inc1,ip);
              }
          }
          /* Specifikacija elementa za operand: */
          el1=newstack(5);
          if (which1!=NULL)
            if (which1->n>0)
              for (i=1;i<=which1->n;++i)
                pushstack(el1,which1->s[i]);
          if (inc1!=NULL)
            if (inc1->n>0)
              for (i=1;i<=inc1->n;++i)
                pushstack(el1,inc1->s[i]);
          /* Indeksi rezultata, ki se bodo inkrementirali skupaj z indeksi
          operanda: */
          if (restres!=NULL)
          {
            incres=newstack(restres->n);
            if (restres->n>0)
              for (i=1;i<=restres->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(incres,ip);
              }
          }
          /* Specifikacija elementa rezultata: */
          elres=newstack(5);
          if (whichres!=NULL)
            if (whichres->n>0)
              for (i=1;i<=whichres->n;++i)
                pushstack(elres,whichres->s[i]);
          if (incres!=NULL)
            if (incres->n>0)
              for (i=1;i<=incres->n;++i)
                pushstack(elres,incres->s[i]);
          while (proceed)
          {
            if (!elstinrange(inc1,rest1))
              proceed=0;
            else
            {
              /* Poiscejo se elementi in nad njimi izvede operacija: */
              pres=vareladdrst(varres,elres);
              if (pres!=NULL)
              {
                p1=varelst(var1,el1);
                operation(p1,pres);  /* izvedba operacije */
                ++num;
              } else
              {
                error=-20;
                proceed=0;
              }
              /* Inkrementacija indeksov, ki dolocajo elementa, nad katerima
              se izvede operacija. Inkremantirajo se le indeksi, ki so na
              skladih inc1 in incres, prva dela specifikacij el1 in elres, ki
              sta sestavljena iz indeksov na which1 in whichres, se ne
              inkrementirata: */
              incelst(inc1,rest1);
              incelst(incres,restres);
            }
          }
        }
      }
    }
  }
}
if (nameres!=NULL)
  free(nameres);
/* Brisanje pomoznih skladov: */
dispstackval(rest1);
dispstack(&rest1);
dispstackval(inc1);
dispstack(&inc1);
dispstack(&el1);
dispstackval(restres);
dispstack(&restres);
dispstackval(incres);
dispstack(&incres);
dispstack(&elres);
if (error>=0)
  error=num;
return error;
}




int unvaropch(varholder var1,stack which1,varholder *res,stack whichres,
            void *operation(void **operand1,void **res),void disp(void **))
    /* 
    $$
    Izvrsi unarno operacijo operation nad elementi spremenljivke var1, pri
    cemer se rezultati spravijo kot elementi spremenljivke res. Operacija je
    taksna, da lahko spremeni 1. operand, zatoje njen 1. argument tipa void **.
    Vse ostalo je isto kot pri funkciji unvaropst().
    $A Igor mar98; */
{
int error=0,num=0,i,*ip;
char proceed=1,*nameres=NULL;
void **p1=NULL,**pres=NULL;
varholder varres=NULL;
stack rest1=NULL,restres=NULL,  /* preostale dimenzije (ki niso na which...) */
      dim1=NULL,dimres=NULL,    /* celotne dimenzije */
      inc1=NULL,incres=NULL,    /* indeksi, ki se inkrementirajo */
      el1=NULL,elres=NULL,      /* kompletni indeksi */
      indexdim=NULL; /* dimenzija udelezenega dela tabele */
if (res==NULL)
  error=-2;
else
{
  if (operation==NULL)
    error=-1;
  else if (var1==NULL)
    error=-3;
  else if (wholevardim(var1)<1)
    error=-5;
  else if (!firstindicesinrangest(var1,which1))
    error=-8;
  else
  {
    if (*res!=NULL)
    {
      if (!firstindicesinrangest(*res,whichres))
        error=-7;
    } else
    {
      if (whichres!=NULL)
        if (whichres->n>0)
          error=-7;
    }
    /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
    restvardimst(*res,whichres,&restres);
    restvardimst(var1,which1,&rest1);
    indexdim=rest1;
    if (indexdim==NULL)
    {
      /* Gre za tocno dolocen element: */
      /* Najprej se preveri, ce ni dimenzija *res neustrezna: */
      if (restres!=NULL)
        if (restres->n>0)
        {
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-20;
          if (!error)
          {
            /*
            dispvarvalspec(*res,disp);
            dispvarholder(res);
            */
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name);
            dispwholevarspec(res,disp);
          }
        }
      if (!error)
      {
        if (*res==NULL)
        {
          *res=newvarholderst(indexdim);
          (*res)->name=nameres; nameres=NULL;
        }
        pres=vareladdrst(*res,whichres);
        p1=vareladdrst(var1,which1);
        if (pres==NULL)
          error=-25;
        else
        {
          operation(p1,pres);
          ++num;
        }
      }
    } else
    {
      if (!error)
      {
        if (!equaldimstack(indexdim,restres) || *res==NULL)
        /* Dimenzija *res ni ustrezna, zato se *res najprej brise in nato
        tvori na novo: */
        {
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-21;
          /* POMEMBNA OPOMBA: Ce je aktualna dimenzija spremenljivek, ki je
          rezultat operacije, razlicna od aktualne dimenzije operanda, to
          NI NAPAKA, ampak se spremenljivka rezultatov najprej pobrise in nato
          tvori na novo. Aktualna dimenzija je dimenzija dela tabele, nad
          katero se izvrsi operacija. To pravilo velja le, ce je indeks
          sklada whichres, ki doloca, kateri del tabele spremenljivke *res je 
          aktualen, niceln; Nasprotni primer velja za napako. */
          if (!error)
          {
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name);
            dispwholevarspec(res,disp);
          }
        }
        if (!error)
        {
          if (*res==NULL)
          {
            *res=newvarholderst(indexdim);
            (*res)->name=nameres; nameres=NULL;
            restvardimst(*res,whichres,&restres);  /* Popravek !!! */
          }
          varres=*res;
          /* Priprava pomoznih skladov: */
          if (rest1!=NULL)
          {
            inc1=newstack(rest1->n);
            if (rest1->n>0)
              for (i=1;i<=rest1->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(inc1,ip);
              }
          }
          el1=newstack(5);
          if (which1!=NULL)
            if (which1->n>0)
              for (i=1;i<=which1->n;++i)
                pushstack(el1,which1->s[i]);
          if (inc1!=NULL)
            if (inc1->n>0)
              for (i=1;i<=inc1->n;++i)
                pushstack(el1,inc1->s[i]);
          if (restres!=NULL)
          {
            incres=newstack(restres->n);
            if (restres->n>0)
              for (i=1;i<=restres->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(incres,ip);
              }
          }
          elres=newstack(5);
          if (whichres!=NULL)
            if (whichres->n>0)
              for (i=1;i<=whichres->n;++i)
                pushstack(elres,whichres->s[i]);
          if (incres!=NULL)
            if (incres->n>0)
              for (i=1;i<=incres->n;++i)
                pushstack(elres,incres->s[i]);
          while (proceed)
          {
            if (!elstinrange(inc1,rest1))
              proceed=0;
            else
            {
              pres=vareladdrst(varres,elres);
              if (pres!=NULL)
              {
                p1=vareladdrst(var1,el1);
                operation(p1,pres);
                ++num;
              } else
              {
                error=-20;
                proceed=0;
              }
              incelst(inc1,rest1);
              incelst(incres,restres);
            }
          }
        }
      }
    }
  }
}
if (nameres!=NULL)
  free(nameres);
/* Brisanje pomoznih skladov: */
dispstackval(rest1);
dispstack(&rest1);
dispstackval(inc1);
dispstack(&inc1);
dispstack(&el1);
dispstackval(restres);
dispstack(&restres);
dispstackval(incres);
dispstack(&incres);
dispstack(&elres);
if (error>=0)
  error=num;
return error;
}





int binvarop(varholder var1,stack which1, varholder var2,stack which2,
             varholder *res,stack whichres,
             void *operation(void *operand1,void *operand2,void **res),
             void disp(void **))
    /* 
    $$
    Izvrsi binarno operacijo operation nad elementi spremenljivk var1 in
    var2, pri cemer se rezultati spravijo kot elementi spremenljivke res.
    which1 in which2 povesta, nad katerima podtabelama spremenljivk var1 in
    var2 se izvrsi operacija, whichres pa pove, v katero podtabelo
    spremenljivke *res se spravijo rezultati.
     Pravila glede dimenzij:
     Dimenziji podtabel, ki ju dolocata which1 in which2, morata biti enaki,
    razen, ce je vsaj na eni od teh podtabel en sam element (rang podtabele
    enak 0). V tem primeru se operacija izvede nad vsakim elementom podtabele,
    katere rang je vecji od 0, in nad edinim elementom druge tabele.
     Ce na skladu whichres ni nobenih indeksov, je lahko dimenzija
    spremenljivke *res razlicna od dimenzije podtabele, nad katero se izvaja
    operacija. V tem primeru se spremenljivka *res najprej zbrise z vsemi
    elementi vred, nato pa se tvori na novo tako, da so vsi elementi pred
    izvedbo operacije enaki NULL in je dimenzija spremenljivke enaka dimenziji
    podtabele, nad katero se izvede operacija. Za brisanje elementov podtabele
    se uporabi funkcija disp (ce je disp==NULL, se elementi ne brisejo).
     Ce je na skladu whichres kak indeks, mora biti dimenzija podtabele
    spremenljivke *res, ki jo dolocajo indeksi na which, nujno enaka dimenziji
    podtabele, nad katero se izvede operacija operation.
     Ce na skladu, ki doloca podtabelo spremenljivke, ni nobenih indeksov, ali 
    ce  je sklad enak NULL, je misljena celotna tabela spremenljivke.
      Indeksi na skladih whichres, which1 in which2 se nanasajo na prve
    indekse ustreznih spremenljivk. Ce katerakoli od njihovih dimenzij ni v
    obsegu ustrezne dimenzije ali ce je indeksov vec kot ustreznih dimenzij,
    je to napaka. Elementi na teh skladih so tipa int *.
      Ce pride do napake, vrne funkcija kodo napake, s katero lahko poklicemo
    funkcijo varoperrorstr, ki glede na to kodo vrne niz, ki opisuje vrsto
    napake. Koda je vedno negativno stevilo. Ce je vse v redu, vrne funkcija
    stevilo izvedb operacije operation.
     Ce se med izvedbo funkcije nosilec *res brise in nato tvori na novo, se
     njegovo ime ohrani.
    $A Igor jan98 mar98; */
{
int error=0,num=0,i,*ip;
char proceed=1,*nameres=NULL;
void *p1=NULL,*p2=NULL,**pres=NULL;
varholder varres=NULL;
stack rest1=NULL,rest2=NULL,restres=NULL,  /* preostale dimenzije (ki niso na which...) */
      dim1=NULL,dim2=NULL,dimres=NULL,     /* celotne dimenzije */
      inc1=NULL,inc2=NULL,incres=NULL,     /* indeksi, ki se inkrementirajo */
      el1=NULL,el2=NULL,elres=NULL,        /* Kompletni indeksi */
      indexdim=NULL; /* dimenzija udelezenega dela tabele */
if (res==NULL)
  error=-2;
else
{
  if (operation==NULL)
    error=-1;
  else if (var1==NULL)
    error=-3;
  else if (var2==NULL)
    error=-4;
  else if (wholevardim(var1)<1)
    error=-5;
  else if (wholevardim(var2)<1)
    error=-6;
  else if (!firstindicesinrangest(var1,which1))
    error=-8;
  else if (!firstindicesinrangest(var2,which2))
    error=-9;
  else
  {
    if (*res!=NULL)
    {
      if (!firstindicesinrangest(*res,whichres))
        error=-7;
    } else
    {
      if (whichres!=NULL)
        if (whichres->n>0)
          error=-7;
    }
    /* Dolocijo se dimenzije indeksov, nad katerimi se bo operacija izvajala: */
    restvardimst(*res,whichres,&restres);
    restvardimst(var1,which1,&rest1);
    restvardimst(var2,which2,&rest2);
    if (rest1!=NULL)
      indexdim=rest1;
    else
      indexdim=rest2;
    if (indexdim==NULL)
    {
      /* Pri var1 in var2 gre za tocno dolocen element: */
      /* Najprej se preveri, ce ni dimenzija *res neustrezna: */
      if (restres!=NULL)
        if (restres->n>0)
        {
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-20;
          if (!error)
          {
            /*
            dispvarvalspec(*res,disp);
            dispvarholder(res);
            */
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name);
            dispwholevarspec(res,disp);
          }
        }
      if (!error)
      {
        if (*res==NULL)
        {
          *res=newvarholderst(indexdim);
          (*res)->name=nameres; nameres=NULL;
        }
        pres=vareladdrst(*res,whichres);
        p1=varelst(var1,which1);
        p2=varelst(var2,which2);
        if (pres==NULL)
          error=-25;
        else
        {
          operation(p1,p2,pres);
          ++num;
        }
      }
    } else
    {
      /* Najprej se preveri, ce so dimencije indeksov enake za 1. in 2. spr. */
      if (!equaldimstack(rest1,rest2))
        if (totaldimstack(rest1)>1 && totaldimstack(rest2)>1)
          error=-10;
      if (!error)
      {
        if (!equaldimstack(indexdim,restres) || *res==NULL)
        /* Dimenzija *res ni ustrezna, zato se *res najprej brise in nato
        tvori na novo: */
        {
          if (whichres!=NULL)
            if (whichres->n>0)
              error=-21;
          /* POMEMBNA OPOMBA: Ce je aktualna dimenzija spremenljivek, ki je
          rezultat operacije, razlicna od aktualnih dimenzij operandov, to
          NI NAPAKA, ampak se spremenljivka rezultatov najpre pobrise in nato
          tvori na novo. Aktualna dimenzija je dimenzija dela tabele, nad
          katero se izvrsi operacija. To pravilo velja le, ce je indeks
          sklada whichres, ki doloca, kateri del tabele spremenljivke *res je 
          aktualen, niceln; Nasprotni primer velja za napako. */
          if (!error)
          {
            if (res!=NULL)
              if (*res!=NULL)
                nameres=stringcopy((*res)->name);
            dispwholevarspec(res,disp);
          }
        }
        if (!error)
        {
          if (*res==NULL)
          {
            *res=newvarholderst(indexdim);
            (*res)->name=nameres; nameres=NULL;
            restvardimst(*res,whichres,&restres);
          }
          varres=*res;
          /* Priprava pomoznih skladov: */
          if (rest1!=NULL)
          {
            inc1=newstack(rest1->n);
            if (rest1->n>0)
              for (i=1;i<=rest1->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(inc1,ip);
              }
          }
          el1=newstack(5);
          if (which1!=NULL)
            if (which1->n>0)
              for (i=1;i<=which1->n;++i)
                pushstack(el1,which1->s[i]);
          if (inc1!=NULL)
            if (inc1->n>0)
              for (i=1;i<=inc1->n;++i)
                pushstack(el1,inc1->s[i]);
          
          if (rest2!=NULL)
          {
            inc2=newstack(rest2->n);
            if (rest2->n>0)
              for (i=1;i<=rest2->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(inc2,ip);
              }
          }
          el2=newstack(5);
          if (which2!=NULL)
            if (which2->n>0)
              for (i=1;i<=which2->n;++i)
                pushstack(el2,which2->s[i]);
          if (inc2!=NULL)
            if (inc2->n>0)
              for (i=1;i<=inc2->n;++i)
                pushstack(el2,inc2->s[i]);
          
          if (restres!=NULL)
          {
            incres=newstack(restres->n);
            if (restres->n>0)
              for (i=1;i<=restres->n;++i)
              {
                ip=malloc(sizeof(*ip));
                *ip=1;
                pushstack(incres,ip);
              }
          }
          elres=newstack(5);
          if (whichres!=NULL)
            if (whichres->n>0)
              for (i=1;i<=whichres->n;++i)
                pushstack(elres,whichres->s[i]);
          if (incres!=NULL)
            if (incres->n>0)
              for (i=1;i<=incres->n;++i)
                pushstack(elres,incres->s[i]);
          while (proceed)
          {
            if (!elstinrange(inc1,rest1) || !elstinrange(inc2,rest2))
              proceed=0;
            else
            {
              /*
              incelst(inc1,rest1);
              incelst(inc2,rest2);
              incelst(incres,restres);
              */
              pres=vareladdrst(varres,elres);
              if (pres!=NULL)
              {
                p1=varelst(var1,el1);
                p2=varelst(var2,el2);
                operation(p1,p2,pres);
                ++num;
              } else
              {
                error=-20;
                proceed=0;
              }
              incelst(inc1,rest1);
              incelst(inc2,rest2);
              incelst(incres,restres);
              
            }
          }
        }
      }
    }
  }
}
if (nameres!=NULL)
  free(nameres);
/* Brisanje pomoznih skladov: */
dispstackval(rest1);
dispstack(&rest1);
dispstackval(inc1);
dispstack(&inc1);
dispstack(&el1);
dispstackval(rest2);
dispstack(&rest2);
dispstackval(inc2);
dispstack(&inc2);
dispstack(&el2);
dispstackval(restres);
dispstack(&restres);
dispstackval(incres);
dispstack(&incres);
dispstack(&elres);
/* Ce je vse v redu, vrne funkcija stevilo izvedenih operacij: */
if (error>=0)
  error=num;
return error;
}




char *varoperrorstr(int error)
    /* Vrne niz,ki opisuje napako s kodo error, ki se je pojavila v funkciji
    unvaropst() ali binvaropst(). Niza se ne sme brisati s free()!
    $A Igor jan98; */
{
switch(error)
{
  case -1:
    return "Operation not defined.";
    break;
  case -2:
    return "Result not specified.";
    break;
  case -3:
    return "First operand not defined.";
    break;
  case -4:
    return "Second operand not defined.";
    break;
  case -5:
    return "First operand contains no elements.";
    break;
  case -6:
    return "Second operand contains no elements.";
    break;
  case -7:
    return "Result index not in range.";
    break;
  case -8:
    return "First operator index not in range.";
    break;
  case -9:
    return "Second operator index not in range.";
    break;
  case -10:
    return "Dimensions of operand tables do not match.";
    break;
  case -20:
    return "Dimension of result table too large.";
    break;
  case -21:
    return "Inappropriate dimension of result table.";
    break;
  case -25:
    return "Result variable element does not exist.";
    break;
  case -50:
    return "First operand does not exist.";
    break;
  case -51:
    return "Second operand does not exist.";
    break;
  case -100:
    return "Result stack not specified.";
    break;
  case -101:
    return "First operand stack not specified.";
    break;
  case -102:
    return "Second operand stack not specified.";
    break;
}
if (error<0)
  return "Unspecified error.";
return NULL;
}


/**************************************************************

                     WORK WITH STACKS

***************************************************************/


int findstackvar(stack st,char *name,int from,int to)
    /* Na skladu st poisce med mestoma from in to spremenljivko (objekt tipa
    varholder) z imenom name ter vrne pozicijo spremenljivke na skladu.
    $A Igor jan98; */
{
return findstack(st,(void *) name,from,to,(int (*)(void *,void *)) cmpvarname);
}

int findsortstackvar(stack st,char *name,int from,int to)
    /* Na skladu st poisce med mestoma from in to spremenljivko (objekt tipa
    varholder) z imenom name ter vrne pozicijo spremenljivke na skladu. Kazalci
    tipa varholder morajo biti na skladust sortirani po imenih od najmanjsega
    do najvecjega glede na funkcijo cmpstrings.
    $A Igor jan98; */
{
return findsortstack(st,(void *) name,from,to,
       (int (*)(void *,void *)) cmpvarname);
}


int insstackvar(stack st,varholder var)
    /* var da na konec sklada st in vrne zaporedno stevilko na skladu, kjer je
    po izvedbi funkcije var. Ce je st==NULL, vrne 0.
    $A Igor jan98; */
{
if (st!=NULL)
{
  pushstack(st,var);
  return st->n;
} else
  return 0;
}

int inssortstackvar(stack st,varholder var)
    /* Kazalec var vrine na ustrezno mesto na sortiranem skladu st tako, da
    sklad ostane sortiran glede na polja (...)->name kazalcev, ki so nalozeni
    nanj. Funkcija vrne mesto na skladu, kamor se vrine var (oz. stevilo manjse
    od 1, ce kazalca var ni mozno vriniti na sklad).
    $A Igor jan98; */
{
return inssortstack(st,var,(int (*)(void *,void *)) cmpvar);
}


int delstackvar(stack st,char *name)
    /* Na skladu st poisce spremenljivko z imenom name, ki jo predstavlja
    kazalec tipa varholder, in jo zbrise. Zbrise celotno vsebino spremenljivke,
    pri cemer posamezne elemente na (...)->v brise s funkcijo free(). Po
    brisanju spremenljivke sbrise se nastalo prazno mesto na skladu s funkcijo
    delstack().
     Funkcija vrne mesto na skladu st, na katerem je bila spremenljivka z
    imenom name, oziroma stevilo manjse od 1, ce spremenljivke ni nasla.
    $A Igor jan98; */
{
int ret=0;
varholder *pointvar=NULL;
if (name!=NULL)
{
  ret=findstackvar(st,name,0,0);
  if (ret>0) 
  {
    pointvar=(varholder *) &(st->s[ret]);
    dispwholevar(pointvar);
    delstack(st,ret);
  }
}
return ret;
}


int delstackvarspec(stack st,char *name,void disp(void**))
    /* Na skladu st poisce spremenljivko z imenom name, ki jo predstavlja
    kazalec tipa varholder, in jo zbrise. Zbrise celotno vsebino spremenljivke,
    pri cemer posamezne elemente na (...)->v brise s funkcijo disp(). Po
    brisanju spremenljivke sbrise se nastalo prazno mesto na skladu s funkcijo
    delstack().
     Funkcija vrne mesto na skladu st, na katerem je bila spremenljivka z
    imenom name, oziroma stevilo manjse od 1, ce spremenljivke ni nasla.
    $A Igor jan98; */
{
int ret=0;
varholder *pointvar=NULL;
if (name!=NULL)
{
  ret=findstackvar(st,name,0,0);
  if (ret>0)
  {
    pointvar=(varholder *) &(st->s[ret]);
    dispwholevarspec(pointvar,disp);
    delstack(st,ret);
  }
}
return ret;
}


int simpvaropname(stack st1, char *name1, stack which1,
                  void operation(void *operand1))
    /* 
    $$
    Izvede operacijo simpvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropnamesortst().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropst(var1,which1,operation);
  }
}
return ret;
}

int simpvaropnamesort(stack st1, char *name1, stack which1,
                  void operation(void *operand1))
    /* 
    $$
    Izvede operacijo simpvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropnamest().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropst(var1,which1,operation);
  }
}
return ret;
}


int simpvaropchname(stack st1, char *name1, stack which1,
                  void operation(void **operand1))
    /* 
    $$
    Izvede operacijo simpvaropchst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropchst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropchnamesortst().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropchst(var1,which1,operation);
  }
}
return ret;
}


int simpvaropchnamesort(stack st1, char *name1, stack which1,
                  void operation(void **operand1))
    /* 
    $$
    Izvede operacijo simpvaropchst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropchst(). Ce ne najde operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropchnamest().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropchst(var1,which1,operation);
  }
}
return ret;
}


int simpvaropeldataname(stack st1, char *name1, stack which1,
                  void operation(void *operand1,stack elst))
    /* 
    $$
    Izvede operacijo simpvaropeldatast() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropeldatast() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekta na skladu in izvede nad njim
    funkcijo simpvaropeldatast(). Ce ne najde operanda z imenom name1 na skladu
    st1, vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropeldatast.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    simpvaropeldatanamesortst().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropeldatast(var1,which1,operation);
  }
}
return ret;
}

int simpvaropeldatanamesort(stack st1, char *name1, stack which1,
                  void operation(void *operand1,stack elst))
    /* 
    $$
    Izvede operacijo simpvaropeldatast() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Ostali argumenti so neposredno argumenti
    funkcije simpvaropeldatast() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezen objekt na skladu in izvede nad njim
    funkcijo simpvaropeldatast(). Ce ne najde operanda z imenom name1 na skladu
    st1, vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne simpvaropst.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    simpvaropnamest().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder var1=NULL;
if (st1==NULL)
  ret=-101;
else
{
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=simpvaropeldatast(var1,which1,operation);
  }
}
return ret;
}


int unvaropname(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void *operand1,void **res),void disp(void **))
    /* 
    $$
    Izvede unarno operacijo unvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    unvaropnamesortst().
    $A Igor jan98 mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL;
if (st1==NULL)
  ret=-101;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=unvaropst(var1,which1,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v tem
        primeru je bil res pred izvedbo unvaropst enak NULL), in nastane nov objekt
        tipa varholder kot rezultat operacije unvaropst, damo temu objektu ime
        nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        insstackvar(stres,res);
      }
    }
  }
}
return ret;
}


int unvaropnamesort(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void *operand1,void **res),void disp(void **))
    /* 
    $$
    Izvede unarno operacijo unvaropst() nad objektom tipa varholder, ki je na
    skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    unvaropnamest().
    $A Igor jan98 mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL;
if (st1==NULL)
  ret=-101;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findsortstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=unvaropst(var1,which1,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v tem
        primeru je bil res pred izvedbo unvaropst enak NULL), in nastane nov objekt
        tipa varholder kot rezultat operacije unvaropst, damo temu objektu ime
        nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        inssortstackvar(stres,res);
      }
    }
  }
}
return ret;
}




int unvaropchname(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void **operand1,void **res),void disp(void **))
    /* 
    $$
    Izvede unarno operacijo unvaropchst() nad objektom tipa varholder, ki je
    na skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropchst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropchst().
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropchst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    unvaropchnamesortst().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL;
if (st1==NULL)
  ret=-101;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=unvaropchst(var1,which1,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v tem
        primeru je bil res pred izvedbo unvaropchst enak NULL), in nastane nov
        objekt tipa varholder kot rezultat operacije unvaropchst, damo temu
        objektu ime nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        insstackvar(stres,res);
      }
    }
  }
}
return ret;
}


int unvaropchnamesort(stack st1, char *name1, stack which1,
              stack stres,char *nameres,stack whichres,
              void *operation(void **operand1,void **res),void disp(void **))
    /* 
    $$
    Izvede unarno operacijo unvaropchst() nad objektom tipa varholder, ki je
    na skladu st1 in ima ime name1. Rezultati se spravijo v objekt, ki je na
    skladu stres in ima ime nameres. Ostali argumenti so neposredno argumenti
    funkcije unvaropchst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezna objekta na skladu in izvede nad njima
    funkcijo unvaropchst(). Ce ne najde 1. operanda z imenom name1 na skladu st1,
    vrne ustrezno kodo napake (opisni niz za to kodo vrne funkcija
    varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne unvaropchst().
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu unvaropchst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    unvaropchnamest().
    $A Igor mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL;
if (st1==NULL)
  ret=-101;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findsortstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  if (ret>=0)
  {
    ret=unvaropchst(var1,which1,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v
        tem primeru je bil res pred izvedbo unvaropchst enak NULL), in nastane
        nov objekt tipa varholder kot rezultat operacije unvaropchst, damo temu
        objektu ime nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        inssortstackvar(stres,res);
      }
    }
  }
}
return ret;
}




int binvaropname(stack st1,char *name1,stack which1,
                 stack st2,char *name2,stack which2,
                 stack stres,char *nameres,stack whichres,
                 void *operation(void *,void *,void **),void disp(void **))
    /* 
    $$
    Izvede binarno operacijo binvaropst() nad objektoma tipa varholder, ki sta
    na skladih st1 in st2 in imata imeni name1 in name2. Rezultati se spravijo
    v objekt, ki je na skladu stres in ima ime nameres. Ostali argumenti so
    neposredno argumenti funkcije binvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezne objekte na skladih in izvede nad njimi
    funkcijo binvaropst(). Ce ne najde 1.  ali 2. operanda z ustreznim imenom
    na ustreanem skladu, vrne ustrezno kodo napake (opisni niz za to kodo vrne
    funkcija varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne binvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu binvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR:
      To funkcijo se sme uporabiti le v primeru, ko objekti na skladih
    niso sortirani po imenih. Za sortirane sklade je treba vzeti funkcijo
    binvaropnamesortst().
    $A Igor jan98 mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL,var2=NULL;
if (st1==NULL)
  ret=-101;
else if (st2==NULL)
  ret=-102;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  /* Poiscemo 2. operand: */
  place=findstackvar(st2,name2,0,0);
  if (place>0)
    var2=st2->s[place];
  else
    ret=-51; /* Napaka: 2. operand ni definiran */
  if (ret>=0)
  {
    ret=binvaropst(var1,which1,var2,which2,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v
        tem primeru je bil res pred izvedbo binvaropst enak NULL), in nastane nov
        objekt tipa varholder kot rezultat operacije binvaropst, damo temu
        objektu ime nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        insstackvar(stres,res);
      }
    }
  }
}
return ret;
}



int binvaropnamesort(stack st1,char *name1,stack which1,
                 stack st2,char *name2,stack which2,
                 stack stres,char *nameres,stack whichres,
                 void *operation(void *,void *,void **),void disp(void **))
    /* 
    $$
    Izvede binarno operacijo binvaropst() nad objektoma tipa varholder, ki sta
    na skladih st1 in st2 in imata imeni name1 in name2. Rezultati se spravijo
    v objekt, ki je na skladu stres in ima ime nameres. Ostali argumenti so
    neposredno argumenti funkcije binvaropst() (glej specifikacijo te funkcije!).
      Funkcija najprej poisce ustrezne objekte na skladih in izvede nad njimi
    funkcijo binvaropst(). Ce ne najde 1.  ali 2. operanda z ustreznim imenom
    na ustreanem skladu, vrne ustrezno kodo napake (opisni niz za to kodo vrne
    funkcija varoperrorstr()). Drugace vrne funkcija kodo, ki jo vrne binvaropst.
      Ce na skladu stres ni definirana spremenljivka z imenom nameres, pa se
    pri klicu binvaropst() na novo tvori rezultat tipa varholder, se na novo
    tvorjenemu objektu priredi ime nameres in se ga postavi na sklad stres.
      POZOR!!
      To funkcijo se sme uporabiti le v primeru, ko so objekti na skladih
    sortirani po imenih. Za nesortirane sklade je treba vzeti funkcijo
    binvaropnamesortst().
    $A Igor jan98 mar98; */
{
int ret=0,place;
char addresvar=0;
varholder *pres=NULL,res=NULL,var1=NULL,var2=NULL;
if (st1==NULL)
  ret=-101;
else if (st2==NULL)
  ret=-102;
else if(stres==NULL)
  ret=-100;
else
{
  /* Poiscemo spremenljivko, kamor naj se zapise rezultat operacije: */
  place=findsortstackvar(stres,nameres,0,0);
  if (place>0)
    pres=(varholder *) &(stres->s[place]);
  else
  {
    pres=&res;
    addresvar=1; /* Spremenljivka z danim imenom se ni definirana, zato jo moramo
                    na koncu dodati na sklad! */
  }
  /* Poiscemo 1. operand: */
  place=findsortstackvar(st1,name1,0,0);
  if (place>0)
    var1=st1->s[place];
  else
    ret=-50; /* Napaka: 1. operand ni definiran */
  /* Poiscemo 2. operand: */
  place=findsortstackvar(st2,name2,0,0);
  if (place>0)
    var2=st2->s[place];
  else
    ret=-51; /* Napaka: 2. operand ni definiran */
  if (ret>=0)
  {
    s=stres;
    /*
    printf("PRED binvaropst:\n");
    pst(stres);
    */
    ret=binvaropst(var1,which1,var2,which2,pres,whichres,operation,disp);
    /* $$ The type of the result variable is automatically copied from the operand;
    Therefore, if the operation produce the result that is of different type than
    the first operand, the type of the result should be changed in the calling 
    function: */
    if (res!=NULL && var1!=NULL)
      res->type=var1->type;
    /*
    printf("PO binvaropst:\n");
    pst(stres);
    printf("KONEC IZPISA:\n");
    */
    if (addresvar)
    {
      if (res!=NULL)
      {
        /* Ce prej na skladu stres ni bilo spremenljivke z imenom nameres (v
        tem primeru je bil res pred izvedbo binvaropst enak NULL), in nastane nov
        objekt tipa varholder kot rezultat operacije binvaropst, damo temu
        objektu ime nameres in ga dodamo na sklad stres: */
        res->name=stringcopy(nameres);
        inssortstackvar(stres,res);
      }
    }
  }
}
return ret;
}



















    /* SISTEM ZA MANIPULACIJO S TIPI SPREMENLJIVK: */


/* Sklad imen, ki jih lahko uporabljamo za razlicne tipe, in indeksna tabela
legalnih tipov: */
static stack typenames=NULL;
static indtab legaltypes=NULL;


int assocvartypename(int type,char *name)
    /* V sistem za manipulacijo s tipi spremenljivk instalira povezavo med
    tipom type in nizom name. Funkcija doda tip type doda na indeksno tabelo
    legalnih tipov legaltypes, na sklad imenskih asociacij tipov typenames
    pa doda varholder z imenom name in tipom type, ce se ne obstaja.
    Funkcija vrne 0, ce pride do kaksne napake,
    $A Igor avg01; */
{
varholder v;
int place=0;
if (typenames==NULL)
  typenames=newstack(1);
if (legaltypes==NULL)
  legaltypes=newindtab(1,5);
if ((int) type<=(int) 0 || (int) type>(int) VT_UNDEF)
{
  errfunc0("assocvartypename");
  fprintf(erf(),"Invalid type %s (type num. %i) attempted to associate with \"%s\".\n",
   vartypetostring(type),(int) type,name);
  errfunc2();
  return place;
}
if ( (inssortindtabun(legaltypes,(int) type,0,0)) ==0) /* tip vrinemo na tabelo legalnih tipov */
{
  /* nekaj je narobe na tabeli legalnih tipov: */
  errfunc0("assocvartypename");
  fprintf(erf(),"Table of legal variable types is corrupted.\n");
  errfunc2();
  return place;
}
if ( ( v=(varholder) ptrfindsortstack(typenames,name,0,0,
 (int (*)(void *,void *)) cmpvarname) ) !=NULL )
{
  /* Ime name je ze instalirano na skladu povezav med imeni in tipi, preverimo,
  ce tip ustreza: */
  if (type!=v->type)
  {
    errfunc0("assocvartypename");
    fprintf(erf(),"Table of legal variable types is corrupted.\n");
    errfunc2();
  } else
  {
    printf("\nassocvartypename: string \"%s\" is already associated with type No. %i (%s)\n\n",
      name,(int) type,vartypetostring(type));
    place=-1;
  }   
} else
{
  place=placesortstack(typenames,(void *) (v=newvarholdernametypest(name,type,NULL)),
   (int(*)(void *,void *)) cmpvar);
  if (place>0)
    insstack(typenames,v,place);
  else
  {
    errfunc0("assocvartypename");
    fprintf(erf(),"Can not associate string %s with variable type No. %i (%s).\n",
     name,(int) type,vartypetostring(type));
    errfunc2();
    dispvarholder(&v);
    place=0;
  }
}
return place;
}


void assocdefaultvartypenames(void)
    /* Naredi seznam standardnih legalnih tipov spremenljivk s pripadajocimi
    imeni.
    $A Igor avg01; */
{
assocvartypename(VT_COUNTER,"counter");  assocvartypename(VT_COUNTER,"count");
assocvartypename(VT_SCALAR,"scalar");  assocvartypename(VT_SCALAR,"scal");
assocvartypename(VT_VECTOR,"vector");  assocvartypename(VT_VECTOR,"vec");
assocvartypename(VT_MATRIX,"matrix");  assocvartypename(VT_MATRIX,"mat");
assocvartypename(VT_STRING,"string");  assocvartypename(VT_STRING,"str");
assocvartypename(VT_VFILE,"vfile");  assocvartypename(VT_VFILE,"vfi");
/*
assocvartypename(VT_VFILE,"file");  assocvartypename(VT_VFILE,"file");
*/
}



void fprintvartypesinfo(FILE *fp)
    /* V fp izpise podatke o legalnih tipih spremenljivk in o imenih, ki jih
    lahko zanje uporabljamo.
    $A Igor avg01; */
{
int i,j;
varholder v;
fprintf(fp,"\nInformation about legal variable types:\n");
if (legaltypes==NULL)
  fprintf(fp,"There are no legal types.\n");
else
{
  if (typenames==NULL)
    fprintf(fp,"There are no associated type names.\n");
  else
  {
    for (i=1;i<=legaltypes->n;++i)
    {
      fprintf(fp,"  Type %i (%s):\nAssociated names:",legaltypes->t[i],
       vartypetostring((int) legaltypes->t[i]));
      for (j=1;j<=typenames->n;++j)
        if ((v=typenames->s[j])!=NULL)
          if (v->type==(int) legaltypes->t[i])
          {
            fprintf(fp,"  %s",v->name);
          }
          fprintf(fp,"\n");
    }
    printf("  Installed type names:\n");
    for (j=1;j<=typenames->n;++j)
      if ((v=typenames->s[j])!=NULL)
        {
          fprintf(fp,"Name \"%s\" associated with type %i (%s).\n",
           v->name,v->type,vartypetostring(v->type));
        }
  }
}
fprintf(fp,"\n");
}


void printvartypesinfo(void)
    /* Izpise podatke o legalnih tipih spremenljivk in o imenih, ki jih
    lahko zanje uporabljamo.
    $A Igor avg01; */
{
fprintvartypesinfo(stdout);
}


int legalvartype(varholder var)
    /* Vrne 0, ce spremenljivka var ni legalnega tipa, in zaporedno stevilko
    njenega tipa na skladu legalnih tipov, ce je.
    $A Igor avg01; */
{
if (var->v==NULL)
  return 0;
else
  return findsortindtab(legaltypes,(int) var->type,0,0);
}

int legalvartypename(char *name)
    /* Vrne 0, ce str ni legalno ime tipa spremenljivke, ce pa je, vrne
    zaporedno stevilko povezanega tipa na skladu legaltypes.
    $A Igor avg01; */
{
int ret=0;
varholder v;
if ( (v= (varholder) ptrfindsortstack(typenames,name,0,0,
 (int (*)(void *,void *)) cmpvarname) )!=NULL )
  ret=findsortindtab(legaltypes,(int) v->type,0,0);
return ret;
}

int vartypename(char *name)
    /* Vrne VT_ANY (0), ce str ni legalno ime tipa spremenljivke, ce pa je,
    vrne tip, ki je povezan s tem imenom.
    $A Igor avg01; */
{
int ret=VT_ANY;
varholder v;
if ( (v= (varholder) ptrfindsortstack(typenames,name,0,0,
 (int (*)(void *,void *)) cmpvarname) )!=NULL )
  if (findsortindtab(legaltypes,(int) v->type,0,0))
    ret=v->type;
return ret;
}



void testvartypemanipulation(void)
    /* Izvede test funkcij za manipulacijo s tipi spremanljivk.
    $A Igor avg01; */
{
int i=-2;
varholder v;
assocvartypename(VT_VECTOR,"vector");
assocvartypename(VT_VECTOR,"realvector");
assocvartypename(VT_VECTOR,"vector");  /* ponovni poskus definicije */
assocvartypename((int) i,"realmatrix");  /* napacen tip */
assocvartypename(VT_MATRIX,"matrix");
assocvartypename(VT_MATRIX,"realvector");  /* poskus redefinicije */
assocvartypename(VT_UNDEF,"undefined_type");
assocvartypename(VT_ANY,"non_defined_type");  /* napacen tip */
printvartypesinfo();

printf("\nLegality of types:\n");
printf("Type name %s, legality: %i\n","vector",legalvartypename("vector"));
printf("Type name %s, legality: %i\n","realvector",legalvartypename("realvector"));
printf("Type name %s, legality: %i\n","realmatrix",legalvartypename("realmatrix"));
printf("Type name %s, legality: %i\n","matrix",legalvartypename("matrix"));
printf("Type name %s, legality: %i\n","undefined_type",legalvartypename("undefined_type"));
printf("Type name %s, legality: %i\n","non_defined_type",legalvartypename("non_defined_type"));
printf("\nAssociated types:\n");

printf("Type name %s, type: %i (%s)\n",
 "vector",vartypename("vector"),vartypetostring(vartypename("vector")));
printf("Type name %s, type: %i (%s)\n",
 "realvector",vartypename("realvector"),vartypetostring(vartypename("realvector")));
printf("Type name %s, type: %i (%s)\n",
 "realmatrix",vartypename("realmatrix"),vartypetostring(vartypename("realmatrix")));
printf("Type name %s, type: %i (%s)\n",
 "matrix",vartypename("matrix"),vartypetostring(vartypename("matrix")));
printf("Type name %s, type: %i (%s)\n",
 "undefined_type",vartypename("undefined_type"),vartypetostring(vartypename("undefined_type")));
printf("Type name %s, type: %i (%s)\n",
 "non_defined_type",vartypename("non_defined_type"),vartypetostring(vartypename("non_defined_type")));

printf("\nLegality of varholder types:\n");
v=newvarholdernametypest("VEC",VT_VECTOR,NULL);
printf("Varholder %s of type %i (%s), legality: %i\n",
 v->name,v->type,vartypetostring(v->type),legalvartype(v));
v=newvarholdernametypest("MAT",VT_MATRIX,NULL);
printf("Varholder %s of type %i (%s), legality: %i\n",
 v->name,v->type,vartypetostring(v->type),legalvartype(v));
v=newvarholdernametypest("STR",VT_STRING,NULL);
printf("Varholder %s of type %i (%s), legality: %i\n",
 v->name,v->type,vartypetostring(v->type),legalvartype(v));
v=newvarholdernametypest("SCAL",VT_SCALAR,NULL);
printf("Varholder %s of type %i (%s), legality: %i\n",
 v->name,v->type,vartypetostring(v->type),legalvartype(v));
v=newvarholdernametypest("NONE",VT_UNDEF,NULL);
printf("Varholder %s of type %i (%s), legality: %i\n",
 v->name,v->type,vartypetostring(v->type),legalvartype(v));
v=newvarholdernametypest("DEFAULT",VT_ANY,NULL);
printf("Varholder %s of type %i (%s), legality: %i\n",
 v->name,v->type,vartypetostring(v->type),legalvartype(v));

}


/* KONEC FUNKCIJ ZA MANIPULACIJO S TIPI */






