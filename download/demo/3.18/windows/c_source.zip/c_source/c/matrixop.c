#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <stdarg.h>


#include <mtypes.h>
#include <rf.h>
#include <vec.h>
#include <mat.h>
#include <rand.h>
#include <er.h>

#include <lin_alg.h>


#include <matrixop.h>



            /**********************/
            /*                    */
            /*    VECTOR NORMS    */
            /*                    */
            /**********************/


double vecnorm1(vector v)
    /* Vrne normo 1 vektorja v (vsoto abs. vred. komponent); Ce je v enak NULL
    ali ima dimenzijo 0, vrne 0.
    $A Igor jan00; */
{
int i;
double ret=0;
if (v!=NULL)
{
  for (i=1;i<=v->d;++i)
    ret+=fabs(v->v[i]);
}
return ret;
}

double vecnorm2(vector v)
    /* Vrne normo 2 vektorja v (koren vsote kvadratov komp.); Ce je v enak NULL
    ali ima dimenzijo 0, vrne 0.
    $A Igor jan00; */
{
int i;
double ret=0;
if (v!=NULL)
{
  for (i=1;i<=v->d;++i)
    ret+=v->v[i]*v->v[i];
}
ret=sqrt(ret);
return ret;
}

double vecnorminf(vector v)
    /* Vrne normo neskoncno vektorja v (najvec. abs. vred. komp.); Ce je v enak
    NULL ali ima dimenzijo 0, vrne 0.
    $A Igor jan00; */
{
int i;
double ret=0,x;
if (v!=NULL)
{
  for (i=1;i<=v->d;++i)
    if ((x=fabs(v->v[i]))>ret)
      ret=x;
}
return ret;
}

double vecnormE(vector v)
    /* Vrne evklidsko normo vektorja v (koren vsote kvadratov komp.); Ce je v
    enak NULL ali ima dimenzijo 0, vrne 0.
    $A Igor jan00; */
{
return vecnorm2(v);
}


double vecnorm(vector v)
    /* Vrne evklidsko normo oz. normo 2 vektorja v (koren vsote kvadratov
    komp.); Ce je v enak NULL ali ima dimenzijo 0, vrne 0.
    $A Igor jan00; */
{
int i;
double ret=0;
if (v!=NULL)
{
  for (i=1;i<=v->d;++i)
    ret+=v->v[i]*v->v[i];
}
ret=sqrt(ret);
return ret;
}


void normvecplain(vector v,vector res)
    /* Vector res postane normiran vektor v (uporabi se norma 2 oz. evklidska
    norma). res mora biti ze alociran z enako dimenzijo (vecjo od 0) kot
    v. res je lahko isti vektor kot v.
    $A Igor jan00; */
{
double norm;
int i;
norm=vecnorm(v);
if (norm!=0)
  for (i=1;i<=v->d;++i)
    res->v[i]=v->v[i]/norm;
}



vector normvec0(vector v1,vector *res)
    /* Vrne normiran vektor v1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. res je lahko tudi naslov v1.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi vektor, ki ga funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor jan00; */
{
vector m=NULL;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je vektor v1 kompatibilen z operacijo: */
  if (v1==NULL)
    dispvector(res);
  else if (v1->d<1)
    dispvector(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d!=v1->d)
        dispvector(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getvector(v1->d);
    /* Izvedba operacije: */
    normvecplain(v1,*res);
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nova vektor, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce je v1 kompatibilen z operacijo: */
  if (v1==NULL)
    return NULL;
  else if (v1->d<1)
    return NULL;
  else
  {
    m=getvector(v1->d);
    /* Izvedba operacije: */
    normvecplain(v1,m);
    return m;
  }
}
}



            /************************/
            /*                      */
            /*     MATRIX NORMS     */
            /*                      */
            /************************/



double matnorm1(matrix m)
    /* Vrne normo 1 matrike m (maksimum po stolpcih vsot absolutnih vrednosti
    komponent v danem stolpcu); Ce je m enaka NULL ali ima kaksno dimenzijo 0,
    vrne funkcija 0.
    $A Igor jan00; */
{
int i,j;
double ret=0,s;
if (m!=NULL)
  if (m->d1!=0 && m->d2!=0)
  {
    for (j=1;j<=m->d2;++j)
    {
      /* Vsota abs. vred. komponent v stolpcu j: */
      s=0;
      for (i=1;i<=m->d1;++i)
        s+=fabs(m->m[i][j]);
      /* Ce je vsota vecja od dozdaj najvecje, nadomesti ret: */
      if (s>ret)
        ret=s;
    }
  }
return ret;
}



double matnorminf(matrix m)
    /* Vrne normo neskoncno matrike m (maksimum po vrsticah vsot absolutnih
    vrednosti komponent v dani vrstici). Ce je m enaka NULL ali ima kaksno
    dimenzijo 0, vrne funkcija 0.
    $A Igor jan00; */
{
int i,j;
double ret=0,s;
if (m!=NULL)
  if (m->d1!=0 && m->d2!=0)
  {
    for (i=1;i<=m->d1;++i)
    {
      /* Vsota abs. vred. komponent v stolpcu j: */
      s=0;
      for (j=1;j<=m->d2;++j)
        s+=fabs(m->m[i][j]);
      /* Ce je vsota vecja od dozdaj najvecje, nadomesti ret: */
      if (s>ret)
        ret=s;
    }
  }
return ret;
}


double matnormE(matrix m)
    /* Vrne evklidsko normo matrike m (koren iz vsote kvadratov komponent). Ce
    je m enaka NULL ali ima kaksno
    dimenzijo 0, vrne funkcija 0.
    $A Igor jan00; */
{
int i,j;
double ret=0;
if (m!=NULL)
  if (m->d1!=0 && m->d2!=0)
  {
    for (i=1;i<=m->d1;++i)
    {
      for (j=1;j<=m->d2;++j)
        ret+=m->m[i][j]*m->m[i][j];
    }
  }
ret=sqrt(ret);
return ret;
}


double matnorm(matrix m)
    /* Vrne evklidsko normo matrike m (koren iz vsote kvadratov komponent). Ce
    je m enaka NULL ali ima kaksno
    dimenzijo 0, vrne funkcija 0.
    $A Igor jan00; */
{
int i,j;
double ret=0;
if (m!=NULL)
  if (m->d1!=0 && m->d2!=0)
  {
    for (i=1;i<=m->d1;++i)
    {
      for (j=1;j<=m->d2;++j)
        ret+=m->m[i][j]*m->m[i][j];
    }
  }
ret=sqrt(ret);
return ret;
}



void normmatplain(matrix m,matrix res)
    /* Matrika res postane normirana matrika m (uporabi se evklidska norma).
    res mora biti ze alocirana z enakimi dimenzijami (vecjimi od 0) kot
    m. res je lahko ista matrika kot m.
    $A Igor jan00; */
{
double norm;
int i,j;
norm=matnorm(m);
for (i=1;i<=m->d1;++i)
  for (j=1;j<=m->d2;++j)
    res->m[i][j]=m->m[i][j]/norm;
}


matrix normmat0(matrix m1,matrix *res)
    /* Vrne normirano matriko m1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. res je lahko tudi naslov m1.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
matrix m=NULL;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispmatrix(res);
  else if (m1->d1<1 || m1->d2<1)
    dispmatrix(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d1!=m1->d1 || (*res)->d2!=m1->d2)
        dispmatrix(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    normmatplain(m1,*res);
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    normmatplain(m1,m);
    return m;
  }
}
}



            /*******************************************/
            /*                                         */
            /*  CONVERSION BETWEEN MATRIX AND VECTORS  */
            /*                                         */
            /*******************************************/


matrix vectomatrow0(vector v1,matrix res,int nrow)
    /* Copies vector v1 to row nrow of matrix res. It returns res if operation
    was successful and NULL otherwise.
      v1 and res must be allocated and v1->d==res->d2 and 0<nrow<=res->d1.
    $A Igor feb05; */
{
int i;
if (v1!=NULL && res!=NULL)
  if (v1->d==res->d2 && nrow>0 && nrow<=res->d1)
  {
    for (i=1;i<=v1->d;++i)
      res->m[nrow][i]=v1->v[i];
    return res;
  }
return NULL;
}


matrix vectomatcol0(vector v1,matrix res,int ncol)
    /* Copies vector v1 to column ncol of matrix res. It returns res if 
    operation was successful and NULL otherwise. 
      v1 and res must be allocated and v1->d==res->d1 and 0<ncol<=res->d2.
    $A Igor feb05; */
{
int i;
if (v1!=NULL && res!=NULL)
  if (v1->d==res->d1 && ncol>0 && ncol<=res->d2)
  {
    for (i=1;i<=v1->d;++i)
      res->m[i][ncol]=v1->v[i];
    return res;
  }
return NULL;
}


matrix vectomatdiag0(vector v1,matrix res)
    /* Copies vector v1 to the diagonal of matrix res. It returns res if 
    operation was successful and NULL otherwise.
      v1 and res must be allocated and v1->d==res->d1==res->d2 (res a square
    matrix).
    $A Igor feb05; */
{
int i;
if (v1!=NULL && res!=NULL)
  if (v1->d==res->d1 && v1->d==res->d2)
  {
    for (i=1;i<=v1->d;++i)
      res->m[i][i]=v1->v[i];
    return res;
  }
return NULL;
}



matrix vectomat0(vector v1,matrix *res)
    /* Vrne matricno kopijo (stolpec) vektorja v1. Ce je res razlicen od NULL,
    zapise rezultat v *res in vrne *res.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
matrix m=NULL;
int i;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je vektor v1 kompatibilen z operacijo: */
  if (v1==NULL)
    dispmatrix(res);
  else if (v1->d<1)
    dispmatrix(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d1!=v1->d || (*res)->d2!=1)
        dispmatrix(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getmatrix(v1->d,1);
    /* Izvedba operacije: */
    for (i=1;i<=v1->d;++i)
      (*res)->m[i][1]=v1->v[i];
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce je v1 kompatibilen z operacijo: */
  if (v1==NULL)
    return NULL;
  else if (v1->d<1)
    return NULL;
  else
  {
    m=getmatrix(v1->d,1);
    /* Izvedba operacije: */
    for (i=1;i<=v1->d;++i)
      m->m[i][1]=v1->v[i];
    return m;
  }
}
}



matrix vectransptomat0(vector v1,matrix *res)
    /* Vrne matricno kopijo (vrstico) transponiranega vektorja v1. Ce je res
    razlicen od NULL, zapise rezultat v *res in vrne *res.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
matrix m=NULL;
int i;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je vektor v1 kompatibilen z operacijo: */
  if (v1==NULL)
    dispmatrix(res);
  else if (v1->d<1)
    dispmatrix(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d1!=1 || (*res)->d2!=v1->d)
        dispmatrix(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getmatrix(1,v1->d);
    /* Izvedba operacije: */
    for (i=1;i<=v1->d;++i)
      (*res)->m[1][i]=v1->v[i];
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce je v1 kompatibilen z operacijo: */
  if (v1==NULL)
    return NULL;
  else if (v1->d<1)
    return NULL;
  else
  {
    m=getmatrix(1,v1->d);
    /* Izvedba operacije: */
    for (i=1;i<=v1->d;++i)
      m->m[1][i]=v1->v[i];
    return m;
  }
}
}



vector mattovec0(matrix m1,vector *res)
    /* Vrne vektorsko kopijo matrike m1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. Matrika m1 se v vektor prepise po vrsticah.
    $A Igor feb00; */
{
vector v=NULL;
int i,j,k;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispvector(res);
  else if (m1->d1<1 || m1->d2<1)
    dispvector(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d!=m1->d1*m1->d2)
        dispvector(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getvector(m1->d1*m1->d2);
    /* Izvedba operacije: */
    k=1;
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
      {
        (*res)->v[k]=m1->m[i][j];
        ++k;
      }
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nov vektor, v katero se zapise rezultat operacije,
  vrne se njgov kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    v=getvector(m1->d1*m1->d2);
    /* Izvedba operacije: */
    k=1;
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
      {
        v->v[k]=m1->m[i][j];
        ++k;
      }
    return v;
  }
}
}


vector mattransptovec0(matrix m1,vector *res)
    /* Vrne vektorsko kopijo (transponirane) matrike m1. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. Matrika m1 se v vektor prepise
    po stolpcih.
    $A Igor feb00; */
{
vector v=NULL;
int i,j,k;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispvector(res);
  else if (m1->d1<1 || m1->d2<1)
    dispvector(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d!=m1->d1*m1->d2)
        dispvector(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getvector(m1->d1*m1->d2);
    /* Izvedba operacije: */
    k=1;
    for (j=1;j<=m1->d2;++j)
      for (i=1;i<=m1->d1;++i)
      {
        (*res)->v[k]=m1->m[i][j];
        ++k;
      }
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nov vektor, v katero se zapise rezultat operacije,
  vrne se njgov kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    v=getvector(m1->d1*m1->d2);
    /* Izvedba operacije: */
    k=1;
    for (j=1;j<=m1->d2;++j)
      for (i=1;i<=m1->d1;++i)
      {
        v->v[k]=m1->m[i][j];
        ++k;
      }
    return v;
  }
}
}



matrix matparttomat0(matrix m1,int i1,int j1,int i2,int j2,matrix *res)
    /* Vrne matricno kopijo dela matrike m1 po vrsticah. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. i1, j1, i2 in j2 dolocajo del
    matrike, ki se prepise v rezultat (tj. od vkljucno elementa (i1,j1) do
    vkljucno elementa (i2,j2)).
    $A Igor feb00; */
{
matrix m=NULL;
int i,j;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispmatrix(res);
  else if (i1<1 || j1<1 || i2<i1 || j2<j1 || m1->d1<i2 || m1->d2<j2)
    dispmatrix(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d1!=i2-i1+1 || (*res)->d2!=j2-j1+1)
        dispmatrix(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getmatrix(i2-i1+1,j2-j1+1);
    /* Izvedba operacije: */
    for (i=i1;i<=i2;++i)
      for (j=j1;j<=j2;++j)
      {
        (*res)->m[i-i1+1][j-j1+1]=m1->m[i][j];
      }
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (i1<1 || j1<1 || i2<i1 || j2<j1 || m1->d1<i2 || m1->d2<j2)
    return NULL;
  else
  {
    m=getmatrix(i2-i1+1,j2-j1+1);
    /* Izvedba operacije: */
    for (i=i1;i<=i2;++i)
      for (j=j1;j<=j2;++j)
      {
        m->m[i-i1+1][j-j1+1]=m1->m[i][j];
      }
    return m;
  }
}
}


matrix matparttransptomat0(matrix m1,int i1,int j1,int i2,int j2,matrix *res)
    /* Vrne matricno kopijo dela matrike m1 po stolpcih. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. i1, j1, i2 in j2 dolocajo del
    matrike, ki se prepise v rezultat (tj. od vkljucno elementa (i1,j1) do
    vkljucno elementa (i2,j2)). Del matrike se prepisuje po stolpcih v vrstice.
    $A Igor feb00; */
{
matrix m=NULL;
int i,j;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispmatrix(res);
  else if (i1<1 || j1<1 || i2<i1 || j2<j1 || m1->d1<i2 || m1->d2<j2)
    dispmatrix(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d1!=j2-j1+1 || (*res)->d2!=i2-i1+1)
        dispmatrix(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getmatrix(j2-j1+1,i2-i1+1);
    /* Izvedba operacije: */
    for (i=i1;i<=i2;++i)
      for (j=j1;j<=j2;++j)
      {
        (*res)->m[j-j1+1][i-i1+1]=m1->m[i][j];
      }
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (i1<1 || j1<1 || i2<i1 || j2<j1 || m1->d1<i2 || m1->d2<j2)
    return NULL;
  else
  {
    m=getmatrix(j2-j1+1,i2-i1+1);
    /* Izvedba operacije: */
    for (i=i1;i<=i2;++i)
      for (j=j1;j<=j2;++j)
      {
        m->m[j-j1+1][i-i1+1]=m1->m[i][j];
      }
    return m;
  }
}
}



vector matparttovec0(matrix m1,int i1,int j1,int i2,int j2,vector *res)
    /* Vrne vektorsko kopijo dela matrike m1 po vrsticah. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. i1, j1, i2 in j2 dolocajo del
    matrike, ki se prepise v rezultat (tj. od vkljucno elementa (i1,j1) do
    vkljucno elementa (i2,j2)).
    $A Igor feb00; */
{
vector v=NULL;
int i,j,k;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispvector(res);
  else if (i1<1 || j1<1 || i2<i1 || j2<j1 || m1->d1<i2 || m1->d2<j2)
    dispvector(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d!=(i2-i1+1)*(j2-j1+1))
        dispvector(res);
    /* Ce je *res==NULL, ga tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getvector((i2-i1+1)*(j2-j1+1));
    /* Izvedba operacije: */
    k=1;
    for (i=i1;i<=i2;++i)
      for (j=j1;j<=j2;++j)
      {
        (*res)->v[k]=m1->m[i][j];
        ++k;
      }
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nov vektor, v katerega se zapise rezultat operacije,
  vrne se njegov kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (i1<1 || j1<1 || i2<i1 || j2<j1 || m1->d1<i2 || m1->d2<j2)
    return NULL;
  else
  {
    v=getvector((i2-i1+1)*(j2-j1+1));
    /* Izvedba operacije: */
    for (i=i1;i<=i2;++i)
      for (j=j1;j<=j2;++j)
      {
        v->v[k]=m1->m[i][j];
        ++k;
      }
    return v;
  }
}
}


vector matparttransptovec0(matrix m1,int i1,int j1,int i2,int j2,vector *res)
    /* Vrne vektorsko kopijo dela matrike m1 po stolpcih. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. i1, j1, i2 in j2 dolocajo del
    matrike, ki se prepise v rezultat (tj. od vkljucno elementa (i1,j1) do
    vkljucno elementa (i2,j2)).
    $A Igor feb00; */
{
vector v=NULL;
int i,j,k;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispvector(res);
  else if (i1<1 || j1<1 || i2<i1 || j2<j1 || m1->d1<i2 || m1->d2<j2)
    dispvector(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d!=(i2-i1+1)*(j2-j1+1))
        dispvector(res);
    /* Ce je *res==NULL, ga tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getvector((i2-i1+1)*(j2-j1+1));
    /* Izvedba operacije: */
    k=1;
    for (j=j1;j<=j2;++j)
      for (i=i1;i<=i2;++i)
      {
        (*res)->v[k]=m1->m[i][j];
        ++k;
      }
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nov vektor, v katerega se zapise rezultat operacije,
  vrne se njegov kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (i1<1 || j1<1 || i2<i1 || j2<j1 || m1->d1<i2 || m1->d2<j2)
    return NULL;
  else
  {
    v=getvector((i2-i1+1)*(j2-j1+1));
    /* Izvedba operacije: */
    for (j=i1;j<=i2;++j)
      for (i=i1;i<=i2;++i)
      {
        v->v[k]=m1->m[i][j];
        ++k;
      }
    return v;
  }
}
}


vector matrowtovec0(matrix m1,int ln,vector *res)
    /* Returns a vector copy of the line ln of matrix m1. If res is not NULL
    then the copy is stored to *res and *res is returned.
    $A Igor feb00; */
{
if (m1!=NULL)
  return matparttovec0(m1,ln,1,ln,m1->d2,res);
else
{
  dispvector(res);
  return NULL;
}
}


vector matcoltovec0(matrix m1,int col,vector *res)
    /* Returns a vector copy of the column col of matrix m1. If res is not NULL
    then the copy is stored to *res and *res is returned.
    $A Igor feb00; */
{
if (m1!=NULL)
  return matparttovec0(m1,1,col,m1->d1,col,res);
else
{
  dispvector(res);
  return NULL;
}
}


vector matdiagtovec0(matrix m1,vector *res)
    /* Returns a vector copy of the diagonal of matrix m1, which must be a
    square matrix. If res!=NULL then result is written to *res and *res is
    returned (if necessary, *res is allocated or reallocated according to
    the dimensions of m1).
    $A Igor feb05; */
{
vector v=NULL;
int i;
if (res!=NULL)
{
  /* If res!=NULL then the result is stored into *res: */
  /* First we check if matrix m1 is compatible with the operation: */
  if (m1==NULL)
    dispvector(res);
  else if (m1->d1<1 || m1->d1!=m1->d2)
    dispvector(res);
  else
  {
    /* We check the dimension fo *res, delete *res if not appropriate: */
    if (*res!=NULL)
      if ((*res)->d!=m1->d1)
        dispvector(res);
    /* If *res==NULL it is allocated with appropriate dimensions: */
    if (*res==NULL)
      *res=getvector(m1->d1);
    /* Perform operation: */
    for (i=1;i<=m1->d1;++i)
      (*res)->v[i]=m1->m[i][i];
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, a new vector for storing the result is created and returned: */
  /* Check first if m1 is compatible with the operation: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2!=m1->d1)
    return NULL;
  else
  {
    v=getvector(m1->d1);
    /* Perform operation: */
    for (i=1;i<=m1->d1;++i)
      v->v[i]=m1->m[i][i];
    return v;
  }
}
}



            /*********************************/
            /*                               */
            /*   INITIALIZATION OF VECTORS   */
            /*                               */
            /*********************************/


vector initvec0(vector *v,int d,double comp1,...)
    /* Creates and returns a vector with a given set of components which must
    be listed after v. All components of the vector must be listed (their
    number is specified by d) and must be of type double. This function is
    convenient for initialization of smaller or mid-size vectors with known
    components.
      If v!=NULL then *v is initialized. In any case the pointer of vector
    is returned. If v is NULL then a vector is created anew and returned.
      WARNING:
      The caller must make sure that actual arguments that follow comp1 are
    indeed of type double (e.g. by cast). If components are integers they
    should be followed by ., for example 2., 3., 15.! The most common error is
    listing integers as integers, e.g. 2, 3, 15. In this case conversion is
    not performed implicitly as usually because at the caller's side the type
    of arguments following comp11 is not determined!
    $A Igor nov03; */
{
vector ret=NULL;
va_list ap;
int i;
if (d>0)
{
  if (v!=NULL)
  {
    if (*v==NULL)
      *v=getvector(d);
    else if ((*v)->d!=d)
    {
      dispvector(v);
      *v=getvector(d);
    }
    ret=*v;
  } else
    ret=getvector(d);
  va_start(ap,comp1);
  ret->v[1]=comp1;
  i=2;
  while(i<=d)
  {
    ret->v[i]=va_arg(ap,double);
    ++i;
  }
} else
  dispvector(v);
return ret;
}


vector randvec0(int d,int which,double par1,double par2,vector *v)
    /* Naredi in vrne vektor z nakljucnimi elementi. d je dimenzija vektorja,
    which doloca, po kaksni porazdelitvi so porazdeljeni elementi, par1 in par2
    sta parametra verjet. porazdelitve (npr. pri Gaussovi).
     Ce je d 0, postane d dimenzija vektorja *v, ce je ta razlicen od NULL.
    Vektor se vrne tudi v *v, ce je v razlicen od NULL.
     Zaenkrat so implementirane naslednje moznosti glede na vrednosti argumenta
    which:
     0,1: enakomer. porazdelitev med 0 in 1
     2:   enakomer. porazdelitev med par1 in par2
     3:   enakomer. porazdelitev med -par1 in par1
    $A Igor jul00 */
{
vector ret=NULL;
int i;
if (d==0 && v!=NULL) /* privzame se dimenzija *v */
  if (*v!=NULL)
    d=(*v)->d;
if (d>0)
{
  if (v!=NULL)
  {
    if (*v==NULL)
      *v=getvector(d);
    else if ((*v)->d!=d)
    {
      dispvector(v);
      *v=getvector(d);
    }
    ret=*v;
  } else
    ret=getvector(d);
  if (which==2)
  {
    /* Enakomerna porazdelitev med par1 in par2: */
    for (i=1;i<=d;++i)
      ret->v[i]=par1+random1()*(par2-par1);
  } else if (which==3)
  {
    /* Enakomerna porazdelitev med -par1 in par1: */
    for (i=1;i<=d;++i)
      ret->v[i]=-par1+random1()*2*par1;
  } else  /* which=1,0 */
  {
    /* Enakomerna porazdelitev med 0 in 1: */
    for (i=1;i<=d;++i)
      ret->v[i]=random1();
  }  
} else
  dispvector(v);
return ret;
}



vector constvec0(int d,double c,vector *v)
    /* Naredi in vrne vektor z elementi enakimi c. d je dimenzija vektorja.
    Ce je d 0, postane d dimenzija vektorja *v, ce je ta razlicen od NULL.
    Vektor se vrne tudi v *v, ce je v razlicen od NULL.
    $A Igor jul00 */
{
vector ret=NULL;
int i;
if (d==0 && v!=NULL) /* privzame se dimenzija *v */
  if (*v!=NULL)
    d=(*v)->d;
if (d>0)
{
  if (v!=NULL)
  {
    if (*v==NULL)
      *v=getvector(d);
    else if ((*v)->d!=d)
    {
      dispvector(v);
      *v=getvector(d);
    }
    ret=*v;
  } else
    ret=getvector(d);
  for (i=1;i<=d;++i)
    ret->v[i]=c;
} else
  dispvector(v);
return ret;
}


vector zerovec0(int d,vector *v)
    /* Naredi in vrne vektor z elementi enakimi 0. d je dimenzija vektorja.
    Ce je d 0, postane d dimenzija vektorja *v, ce je ta razlicen od NULL.
    Vektor se vrne tudi v *v, ce je v razlicen od NULL.
    $A Igor jul00 */
{
return constvec0(d,0,v);
}


vector unitvec0(int d,int which,vector *v)
    /* Naredi in vrne which-ti enotski vektor (elementi 0 razen na mestu which,
    kjer je element enak 1). d je dimenzija vektorja.
    Ce je d 0, postane d dimenzija vektorja *v, ce je ta razlicen od NULL.
    Vektor se vrne tudi v *v, ce je v razlicen od NULL.
    $A Igor jul00 */
{
vector ret=NULL;
int i;
if (d==0 && v!=NULL) /* privzame se dimenzija *v */
  if (*v!=NULL)
    d=(*v)->d;
if (d>0 && which>0 && which<=d)
{
  if (v!=NULL)
  {
    if (*v==NULL)
      *v=getvector(d);
    else if ((*v)->d!=d)
    {
      dispvector(v);
      *v=getvector(d);
    }
    ret=*v;
  } else
    ret=getvector(d);
  for (i=1;i<=d;++i)
    ret->v[i]=0;
  ret->v[which]=1;
} else
  dispvector(v);
return ret;
}





            /**********************************/
            /*                                */
            /*   INITIALIZATION OF MATRICES   */
            /*                                */
            /**********************************/



matrix initmat0(matrix *m,int d1,int d2,double comp11,...)
    /* Creates and returns a matrix with a given set of components which must
    be listed after m. All components of the matrix must be listed (their
    number is d1*d2) and must be of type double. This function is convenient
    for initialization of smaller or mid-size matrices with known components.
      If m!=NULL then *m is initialized. In any case the pointer of the matrix
    is returned. If m is NULL then a matrix is created anew and returned. If
    d1 or d2 is 0 then a NULL matrix is created.
      WARNING:
    The caller must make sure that actual arguments that follow comp11 are
    indeed of type double (e.g. by cast). If components are integers they
    should be followed by ., for example 2., 3., 15.! The most common error is
    listing integers as integers, e.g. 2, 3, 15. In this case conversion is
    not performed implicitly as usually because at the caller's side the type
    of arguments following comp11 is not determined!
    $A Igor nov03; */
{
matrix ret=NULL;
int i,j;
va_list ap;
if (d2==0)
  d2=d1;
if (d1>0 && d2>0)
{
  if (m!=NULL)
  {
    if (*m==NULL)
      *m=getmatrix(d1,d2);
    else if ((*m)->d1!=d1 || (*m)->d2!=d2)
    {
      dispmatrix(m);
      *m=getmatrix(d1,d2);
    }
    ret=*m;
  } else
    ret=getmatrix(d1,d2);
  va_start(ap,comp11);
  ret->m[1][1]=comp11;
  i=1; j=2;
  while(i<=d1)
  {
    while(j<=d2)
    {
      ret->m[i][j]=va_arg(ap,double);
      ++j;
    }
    ++i;
    j=1;
  }
} else
  dispmatrix(m);
return ret;
}




matrix randmat0(int d1,int d2,int which,double par1,double par2,
       matrix *m)
    /* Naredi in vrne matriko z nakljucnimi elementi. d1 in d2 sta dimenziji
    matrike, par1 in par2 sta parametra verjet. porazdelitve (npr. pri
    Gaussovi), which doloca, po kaksni porazdelitvi so porazdeljeni elementi.
    Ce je d2 0, postane d2 enak d1 (kvadratna matrika), ce pa sta d2 in d1
    enaka 0, postaneta dimenziji matrike *m, ce je ta razlicna od NULL.
    Zaenkrat so implementirane naslednje moznosti glede na vrednosti argumenta
    which:
     0,1: enakomer. porazdelitev med 0 in 1
     2:   enakomer. porazdelitev med par1 in par2
     3:   enakomer. porazdelitev med -par1 in par1
    $A Igor jan00 */
{
matrix ret=NULL;
int i,j;
if (d2==0)
  d2=d1;
if (d2==0 && m!=NULL) /* Torej d2 in d1 enaka 0, privzamejo se dimenzije *m */
  if (*m!=NULL)
  {
    d1=(*m)->d1;
    d2=(*m)->d2;
  }
if (d1>0 && d2>0)
{
  if (m!=NULL)
  {
    if (*m==NULL)
      *m=getmatrix(d1,d2);
    else if ((*m)->d1!=d1 || (*m)->d2!=d2)
    {
      dispmatrix(m);
      *m=getmatrix(d1,d2);
    }
    ret=*m;
  } else
    ret=getmatrix(d1,d2);
  if (which==2)
  {
    /* Enakomerna porazdelitev med par1 in par2: */
    for (i=1;i<=d1;++i)
      for (j=1;j<=d2;++j)
        ret->m[i][j]=par1+random1()*(par2-par1);
  } else if (which==3)
  {
    /* Enakomerna porazdelitev med -par1 in par1: */
    for (i=1;i<=d1;++i)
      for (j=1;j<=d2;++j)
        ret->m[i][j]=-par1+random1()*2*par1;
  } else  /* which=1 */
  {
    /* Enakomerna porazdelitev med 0 in 1: */
    for (i=1;i<=d1;++i)
      for (j=1;j<=d2;++j)
        ret->m[i][j]=random1();
  }  
} else
  dispmatrix(m);
return ret;
}




matrix constmat0(int d1,int d2,double c,matrix *m)
    /* Elemente matrike dimenzij d1*d2 postavi na d in vrne matriko. Ce je m
    razlicna od NULL, postane *m ta matrika, drugace se matrika tvori na novo.
    Ce je d2 0, postane d2 enak d1 (kvadratna matrika), ce pa sta d2 in d1
    enaka 0, postaneta dimenziji matrike *m, ce je ta razlicna od NULL.
    $A Igor jan00; */
{
matrix ret=NULL;
int i,j;
if (d2==0)
  d2=d1;
if (d2==0 && m!=NULL) /* Torej d2 in d1 enaka 0, privzamejo se dimenzije *m */
  if (*m!=NULL)
  {
    d1=(*m)->d1;
    d2=(*m)->d2;
  }
if (d1>0 && d2>0)
{
  if (m!=NULL)
  {
    if (*m==NULL)
      *m=getmatrix(d1,d2);
    else if ((*m)->d1!=d1 || (*m)->d2!=d2)
    {
      dispmatrix(m);
      *m=getmatrix(d1,d2);
    }
    ret=*m;
  } else
    ret=getmatrix(d1,d2);
  for (i=1;i<=d1;++i)
    for (j=1;j<=d2;++j)
      ret->m[i][j]=c;
} else
  dispmatrix(m);
return ret;
}


matrix zeromat0(int d1,int d2,matrix *m)
    /* Elemente matrike dimenzij d1*d2 postavi na 0 in vrne matriko. Ce je m
    razlicna od NULL, postane *m ta matrika, drugace se matrika tvori na novo.
    Ce je d2 0, postane d2 enak d1 (kvadratna matrika), ce pa sta d2 in d1
    enaka 0, postaneta dimenziji matrike *m, ce je ta razlicna od NULL.
    $A Igor jan00; */
{
return constmat0(d1,d2,0,m);
}


matrix identmat0(int d1,matrix *m)
    /* Naredi identicno kvadratno matriko dimenzij d1*d1 in vrne matriko. Ce
    je m razlicna od NULL, postane *m ta matrika, drugace se matrika tvori na
    novo.
    Ce je d1 enak 0, postane dimenzija matrike kar dimenzija *m, ce m kaze na
    kvadratno matriko.
    $A Igor jan00; */
{
matrix ret=NULL;
int i,j;
if (d1==0 && m!=NULL)
  if (*m!=NULL)
    if ((*m)->d1==(*m)->d2)
      d1=(*m)->d1;
if (d1>0)
{
  if (m!=NULL)
  {
    if (*m==NULL)
      *m=getmatrix(d1,d1);
    else if ((*m)->d1!=d1 || (*m)->d2!=d1)
    {
      dispmatrix(m);
      *m=getmatrix(d1,d1);
    }
    ret=*m;
  } else
    ret=getmatrix(d1,d1);
  for (i=1;i<=d1;++i)
    for (j=1;j<=d1;++j)
    {
      if (i==j)
        ret->m[i][j]=1;
      else
        ret->m[i][j]=0;
    }
} else
  dispmatrix(m);
return ret;
}


matrix diagmatconst0(int d1,double c,matrix *m)
    /* Naredi diagonalno kvadratno matriko dimenzij d1*d1 z diagonalnimi
    elementi enakimi c in vrne matriko. Ce je m razlicna od NULL, postane *m ta
    matrika, drugace se matrika tvori na novo.
    Ce je d1 enak 0, postane dimenzija matrike kar dimenzija *m, ce m kaze na
    kvadratno matriko.
    $A Igor jul00; */
{
matrix ret=NULL;
int i,j;
if (d1==0 && m!=NULL)
  if (*m!=NULL)
    if ((*m)->d1==(*m)->d2)
      d1=(*m)->d1;
if (d1>0)
{
  if (m!=NULL)
  {
    if (*m==NULL)
      *m=getmatrix(d1,d1);
    else if ((*m)->d1!=d1 || (*m)->d2!=d1)
    {
      dispmatrix(m);
      *m=getmatrix(d1,d1);
    }
    ret=*m;
  } else
    ret=getmatrix(d1,d1);
  for (i=1;i<=d1;++i)
    for (j=1;j<=d1;++j)
    {
      if (i==j)
        ret->m[i][j]=c;
      else
        ret->m[i][j]=0;
    }
} else
  dispmatrix(m);
return ret;
}


matrix diagmatvec0(vector v,matrix *m2)
    /* Creates a diagonal matrix whose diagonal elements are components of the
    vector v. If m!=NULL then the matrix is stored to *m (with eventually
    performing the necessary reallocations), otherwise it is created anew. In
    both cases the matrix is returned.
    $A Igor dec03; */
{
matrix m;
int i,j;
if (m2!=NULL)
{
  /* m2!=NULL, matrix is stored to *m2: */
  if (v==NULL)
  {
    dispmatrix(m2);
  } else if (v->d==0)
  {
    dispmatrix(m2);
  } else
  {
    resizematrix(m2,v->d,v->d);
    if (*m2==NULL)
      *m2=getmatrix(v->d,v->d);
    m=*m2;
    for (i=1;i<=v->d;++i)  /* set elements */
      for (j=1;j<=v->d;++j)
        m->m[i][j]=(i==j?v->v[i]:0);
  }
  return *m2;
} else
{
  /* m2==NULL, a new matrix is created and its pointer returned: */
  if (v==NULL)
    return NULL;
  else if (v->d==0)
    return NULL;
  else
  {
    m=getmatrix(v->d,v->d);
    for (i=1;i<=v->d;++i)  /* set elements */
      for (j=1;j<=v->d;++j)
        m->m[i][j]=(i==j?v->v[i]:0);
    return m;
  }
}
}







            /***********************************************/
            /*                                             */
            /*  SUMS AND PRODUCTS OF MATRICES AND VECTORS  */
            /*                                             */
            /***********************************************/




    /* SUMS AND PRODUCTS: VECTORS */


void vecsumplain(vector v1,vector v2,vector res)
    /* V vektor res zapise vsoto vektorjev v1 in v2. Funkcija ne kontrolira
    niti dimenzij niti tega, ce je prostor alociran. Vektor res je lahko isti
    kot v1 ali v2, prav tako sta v1 in v2 lahko ista vektorja.
    $A Igor jul00; */
{
int i;
for (i=1;i<=v1->d;++i)
  res->v[i]=v1->v[i]+v2->v[i];
}

void vecdifplain(vector v1,vector v2,vector res)
    /* V vektor res zapise razliko vektorjev v1 in v2. Funkcija ne kontrolira
    niti dimenzij niti tega, ce je prostor alociran. Vektor res je lahko isti
    kot v1 ali v2, prav tako sta v1 in v2 lahko ista vektorja.
    $A Igor jul00; */
{
int i;
for (i=1;i<=v1->d;++i)
  res->v[i]=v1->v[i]-v2->v[i];
}

vector vecsum0(vector v1,vector v2,vector *v3)
    /* Stores a sum of v1 and v2 to *v3 and returns *v3. If v3=NULL then the
    sum is created anew and returned. *v3 can point to v1 or v2, which can be
    the same vectors. If dimensions of *v3 do not match then v3 is reallocated
    first.
    $A jul00; */
{
return vectorsum0(v1,v2,v3);
}

vector vecdif0(vector v1,vector v2,vector *v3)
    /* Stores a difference of v1 and v2 to *v3 and returns *v3. If v3=NULL then
    the result vector is created anew and returned. *v3 can point to v1 or v2,
    which can be the same vectors. If dimensions of *v3 do not match then v3 is
    reallocated first.
    $A jul00; */
{
return vectordif0(v1,v2,v3);
}


void vecprodscalplain(vector v1,double s,vector res)
    /* Multiplies vector v1 by scalar s and stores result to res, which can be
    the same vector as v1. v1 and res may not be NULL must have compatible
    dimensions, since this is not checked in the function.
    $A Igor dec03; */
{
int i;
for (i=1;i<=v1->d;++i)
  res->v[i]=v1->v[i]*s;
}


vector vecprodscal0(vector v1,double s2,vector *v3)
    /* Returns vector v1 multiplied by scalar s2. If v3 is different than NULL
    then the result is stored to *v3 and *v3 is redurned (with all the
    necessary allocations, deallocations or reallocations performed).
    $A Igor dec03; */
{
vector v;
int i;
if (v3!=NULL)
{
  /* If *v3!=NULL then the result is stored to *v3: */
  if (v1==NULL)
    dispvector(v3);
  else if (v1->d<1)
    dispvector(v3);
  else
  {
    /* Resize *v3 if necessary: */
    resizevector(v3,v1->d);
    v=*v3;
    /* Perform operation */
    for (i=1;i<=v1->d;++i)
      v->v[i]=v1->v[i]*s2;
  }
  return *v3;
} else
{
  /* v3==NULL, a new vector is created, the result stored in it and vector
  returned: */
  if (v1==NULL)
    return NULL;
  else if (v1->d<1)
    return NULL;
  else
  {
    v=getvector(v1->d);
    /* Perform operation: */
    for (i=1;i<=v1->d;++i)
      v->v[i]=v1->v[i]*s2;
    return v;
  }
}
}


double scalprodvec(vector v1,vector v2)
    /* Returns scalar product of vectors v1 and v2 or 0 if vector dimensions
    do not match or vectors are NULL.
    $A Igor <==; */
{
int i;
double prod=0;
if (v1!=NULL && v2!=NULL)
{
  if (v1->d>0 && v1->d==v2->d)
  {
    for (i=1; i<=v1->d; ++i)
      prod+=v1->v[i]*v2->v[i];
  }
}
return prod;
}


void vecprodvectranspplain(vector v1,vector v2,matrix res)
    /* A product of vector v1 and transpose of v2 (i.e. dyadic product of v1
    and v2) is written to matrix res.
      Function does not check the dimensions and whether space is properly
    allocated, it just performs the operation.
    $A Igor apr05;; */
{
int i,j;
for (i=1;i<=v1->d;++i)
  for (j=1;j<=v2->d;++j)
    res->m[i][j]=v1->v[i]*v2->v[j];
}

matrix vecprodvectransp0(vector v1,vector v2,matrix *m3)
    /* Returns product of vector v1 and transposed vector v2 (i.e. the dyadic
    product of v1 and v2). If m3!=NULL then the result is written to *m3 and
    returns *m3.
    $A Igor apr05; */
{
matrix m=NULL;
if (m3==NULL)
  m3=&m;  /* no result address provided, result matrix will be created & 
             returned */
/* Check whether v1 and v2 are compatible for operation: */
if (v1==NULL || v2==NULL)
{
  if (*m3!=NULL)
    dispmatrix(m3);
} else if (v1->d<1 || v2->d<1)
{
  if (*m3!=NULL)
    dispmatrix(m3);
} else
{
  /* Check dimensions of *m3, reallocate if necessary: */
  if ((*m3)!=NULL)
  {
    if ((*m3)->d1!=v1->d || (*m3)->d2!=v2->d)
      resizematrix(m3,v1->d,v2->d);
  } else
    *m3=getmatrix(v1->d,v2->d);
  /* Perform operation: */
  vecprodvectranspplain(v1,v2,*m3);
}
return *m3; /* Ker je bil v3!=NULL, se vrne *v3. */
}


    /* PRODUCTS OF MATRICES AND VECTORS */


void matprodvecplain(matrix m1,vector v2,vector res)
    /* V vektor res zapise produkt matrike m1 in vektorja v2. Funkcija ne
    kontrolira niti dimenzij niti tega, ce je prostor alociran. Vektor res ne
    sme biti isti kot v2.
    $A Igor avg00; */
{
int i,k;
double s;
for (i=1;i<=m1->d1;++i)
{
  s=0;
  for (k=1;k<=m1->d2;++k)
    s+=m1->m[i][k]*v2->v[k];
  res->v[i]=s;
}
}


vector matprodvec0(matrix m1,vector v2,vector *v3)
    /* Vrne produkt matrike m1 in vektorja v2. Ce je v3 razlicen od NULL,
    zapise rezultat v *v3 in vrne *v3. v3 je lahko tudi naslov v2, funkcija v
    tem primeru poskrbi za to, da se najprej izracuna rezultat operacije in
    sele nato prepise operand.
     OPOMBA:
     Ce je v3 razlicen od NULL, se po navadi vektor, ki ga funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze v3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */
{
vector v=NULL,*save=NULL;
if (v3!=NULL)
{
  if (*v3==v2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce v3 kaze na
    v2: */
    save=v3;
    v3=&v;
  }
  /* Ce je v3!=NULL, se rezultat shrane v *v3: */
  /* Najprej preverimo, ce sta m1 in v2 kompatibilna z operacijo: */
  if (m1==NULL || v2==NULL)
    dispvector(v3);
  else if (m1->d2!=v2->d || m1->d1<1 || m1->d2<1)
    dispvector(v3);
  else
  {
    /* Preverimo dimenzijo *v3, ce ni ustrezna, zbrisemo *v3: */
    if (*v3!=NULL)
      if ((*v3)->d!=m1->d1)
        dispvector(v3);
    /* Ce je *v3==NULL, tvorimo *v3 s 1. dimenzijo m1: */
    if (*v3==NULL)
      *v3=getvector(m1->d1);
    /* Izvedba operacije: */
    matprodvecplain(m1,v2,*v3);
  }
  if (save!=NULL)
  {
    dispvector(save);
    *save=*v3;
  }
  return *v3; /* Ker je bil v3!=NULL, se vrne *v3. */
} else
{
  /* v3==NULL, naredi se nov vektor, v katerega se zapise rezultat operacije,
  vrne se njegov kazalec: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni za operacijo: */
  if (m1==NULL || v2==NULL)
    return NULL;
  else if (m1->d2!=v2->d || m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    v=getvector(m1->d1);
    /* Izvedba operacije: */
    matprodvecplain(m1,v2,v);
    return v;
  }
}
}


void mattranspprodvecplain(matrix m1,vector v2,vector res)
    /* V vektor res zapise produkt transponirane matrike m1 in vektorja v2.
    Funkcija ne kontrolira niti dimenzij niti tega, ce je prostor alociran.
    Vektor res ne sme biti isti kot v2.
    $A Igor avg00; */
{
int i,k;
double s;
for (i=1;i<=m1->d2;++i)
{
  s=0;
  for (k=1;k<=m1->d1;++k)
    s+=m1->m[k][i]*v2->v[k];
  res->v[i]=s;
}
}


vector mattranspprodvec0(matrix m1,vector v2,vector *v3)
    /* Vrne produkt transponirane  matrike m1 in vektorja v2. Ce je v3 razlicen
    od NULL, zapise rezultat v *v3 in vrne *v3. v3 je lahko tudi naslov v2,
    funkcija v tem primeru poskrbi za to, da se najprej izracuna rezultat
    operacije in sele nato prepise operand.
     OPOMBA:
     Ce je v3 razlicen od NULL, se po navadi vektor, ki ga funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze v3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */
{
vector v=NULL,*save=NULL;
if (v3!=NULL)
{
  if (*v3==v2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce v3 kaze na
    v2: */
    save=v3;
    v3=&v;
  }
  /* Ce je v3!=NULL, se rezultat shrane v *v3: */
  /* Najprej preverimo, ce sta m1 in v2 kompatibilna z operacijo: */
  if (m1==NULL || v2==NULL)
    dispvector(v3);
  else if (m1->d1!=v2->d || m1->d1<1 || m1->d2<1)
    dispvector(v3);
  else
  {
    /* Preverimo dimenzijo *v3, ce ni ustrezna, zbrisemo *v3: */
    if (*v3!=NULL)
      if ((*v3)->d!=m1->d2)
        dispvector(v3);
    /* Ce je *v3==NULL, tvorimo *v3 s 1. dimenzijo m1: */
    if (*v3==NULL)
      *v3=getvector(m1->d2);
    /* Izvedba operacije: */
    matprodvecplain(m1,v2,*v3);
  }
  if (save!=NULL)
  {
    dispvector(save);
    *save=*v3;
  }
  return *v3; /* Ker je bil v3!=NULL, se vrne *v3. */
} else
{
  /* v3==NULL, naredi se nov vektor, v katerega se zapise rezultat operacije,
  vrne se njegov kazalec: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni za operacijo: */
  if (m1==NULL || v2==NULL)
    return NULL;
  else if (m1->d1!=v2->d || m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    v=getvector(m1->d2);
    /* Izvedba operacije: */
    matprodvecplain(m1,v2,v);
    return v;
  }
}
}


double vectranspprodmatprodvec0(vector v1,matrix m,vector v2)
    /* Returns a generalized scalar product v1T*M*v2.
    $A Igor jun05; */
{
int i,j;
double ret=0;
if (v1->d==m->d1 && v2->d==m->d2) for (i=1;i<=v1->d;++i)
{
  for (j=1;j<=v2->d;++j)
  {
    ret+=v1->v[i]*m->m[i][j]*v2->v[j];
  }
}
return ret;
}


void matproddiagplain(matrix m1,vector v2,matrix res)
    /* Multiplies m1 by a diagonal matrix whose diagonal elements are elements
    of v2, and stores the result in res. All arguments must be of consistent
    dimensions and different than NULL.
      Operation can be performed "in place", i.e. res can be the same matrix
    as m1.
    Dimensions:  m1(mxn), v2(n), res(mxn)
    $A Igor dec03; */
{
int i,j;
for (i=1;i<=m1->d1;++i)
  for (j=1;j<=m1->d2;++j)
    res->m[i][j]=v2->v[j]*m1->m[i][j];
}


matrix matproddiag0(matrix m1,vector v2,matrix *m3)
    /* Returns the product of m1 and diagonal the matrix whose diagnoal
    elements are components of v2. If m3!=NULL then the result is stored to
    *m3 and *m3 returned, with reallocations performed if necessary.
      Operation can be performed "in place", i.e. m3 can be address of m1.
    Dimensions:  m1(mxn), v2(n), *m3(mxn) (=ret. val.)
    $A Igor des03; */
{
matrix m=NULL;
if (m3!=NULL)
{
  /* Check compatibility of operands: */
  if (m1==NULL || v2==NULL)
    dispmatrix(m3);
  else if (m1->d2!=v2->d || m1->d1<1 || m1->d2<1)
    dispmatrix(m3);
  else
  {
    /* Ensure the right dimension of the result: */
    resizematrix(m3,m1->d1,m1->d2);
    /* Perform operation: */
    matproddiagplain(m1,v2,*m3);
  }
  return *m3;
} else
{
  /* m3==NULL, allocate the result and return it: */
  /* check compatibility: */
  if (m1==NULL || v2==NULL)
    return NULL;
  else if (m1->d2!=v2->d || m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    matproddiagplain(m1,v2,m);  /* perform operation */
    return m;
  }
}
}


void diagprodmatplain(vector v1,matrix m2,matrix res)
    /* Multiplies a diagonal matrix whose diagonal elements are elements of 
    v1 by m2, and stores the result in res. All arguments must be of consistent
    dimensions and different than NULL.
      Operation can be performed "in place", i.e. res can be the same matrix
    as m2.
    Dimensions:  v1(n), m2(nxm), res(nxm)
    $A Igor jul03; */
{
int i,j;
for (i=1;i<=v1->d;++i)
  for (j=1;j<=m2->d2;++j)
    res->m[i][j]=v1->v[i]*m2->m[i][j];
}


matrix diagprodmat0(vector v1,matrix m2,matrix *m3)
    /* Returns the product of a diagonal matrix whose diagonal elements are 
    elements of v1, and m2. If m3!=NULL then the result is stored to
    *m3 and *m3 returned, with reallocations performed if necessary.
      Operation can be performed "in place", i.e. m3 can be address of m2.
    Dimensions:  v1(n), m2(nxm), *m3(mxn) (=ret. val.)
    $A Igor des03; */
{
matrix m=NULL;
if (m3==NULL)
  m3=&m;
/* Check compatibility of operands: */
if (v1==NULL || m2==NULL)
  dispmatrix(m3);
else if (m2->d1!=v1->d || m2->d1<1 || m2->d2<1)
  dispmatrix(m3);
else
{
  /* Ensure the right dimension of the result: */
  resizematrix(m3,m2->d1,m2->d2);
  /* Perform operation: */
  diagprodmatplain(v1,m2,*m3);
}
return *m3;
}


void diagprodvecplain(vector v1,vector v2,vector res)
    /* Multiplies a diagonal matrix whose diagonal elements are elements of 
    v1 by v2, and stores the result in res. All arguments must be of consistent
    dimensions and different than NULL.
      Operation can be performed "in place", i.e. res can be the same vector 
    as v1 or v2.
    Dimensions:  v1(n), v2(n), res(nn)
    $A Igor jul03; */
{
int i;
for (i=1;i<=v1->d;++i)
  res->v[i]=v1->v[i]*v2->v[i];
}


vector diagprodvec0(vector v1,vector v2,vector *v3)
    /* Returns the product of a diagonal matrix whose diagonal elements are 
    elements of v1, and v2. If v3!=NULL then the result is stored to
    *v3 and *v3 returned, with reallocations performed if necessary.
      Operation can be performed "in place", i.e. v3 can be the address of
    v1 or v2.
    Dimensions:  v1(n), v2(n), *v3(n) (=ret. val.)
    $A Igor des03; */
{
vector v=NULL;
if (v3==NULL)
  v3=&v;
/* Check compatibility of operands: */
if (v1==NULL || v2==NULL)
  dispvector(v3);
else if (v2->d!=v1->d || v2->d<1)
  dispvector(v3);
else
{
  /* Ensure the right dimension of the result: */
  resizevector(v3,v1->d);
  /* Perform operation: */
  diagprodvecplain(v1,v2,*v3);
}
return *v3;
}




    /* SUMS AND PRODUCTS: MATRICES */


void matsumplain(matrix m1,matrix m2,matrix res)
    /* V matriko res zapise vsoto matrik m1 in m2. Funkcija ne kontrolira
    niti dimenzij niti tega, ce je prostor alociran. Matrika res je lahko ista
    kot m1 ali m2, prav tako sta m1 in m2 lahko isti matriki.
    $A Igor jan00; */
{
int i,j;
for (i=1;i<=m1->d1;++i)
  for (j=1;j<=m1->d2;++j)
    res->m[i][j]=m1->m[i][j]+m2->m[i][j];
}


void matdifplain(matrix m1,matrix m2,matrix res)
    /* V matriko res zapise razliko matrik m1 in m2. Funkcija ne kontrolira
    niti dimenzij niti tega, ce je prostor alociran. Matrika res je lahko ista
    kot m1 ali m2, prav tako sta m1 in m2 lahko isti matriki.
    $A Igor jan00; */
{
int i,j;
for (i=1;i<=m1->d1;++i)
  for (j=1;j<=m1->d2;++j)
    res->m[i][j]=m1->m[i][j]-m2->m[i][j];
}

matrix matsum0(matrix m1,matrix m2,matrix *m3)
    /* Stores a sum of m1 and m1 to *m3 and returns *m3. If m3=NULL then the
    sum is created anew and returned. *m3 can point to m1 or m2, which can be
    the same matrices. If dimensions of *m3 do not match then *m3 is reallocated
    first.
    $A jul00; */
{
return matrixsum0(m1,m2,m3);
}


matrix matdif0(matrix m1,matrix m2,matrix *m3)
    /* Stores a difference of m1 and m1 to *m3 and returns *m3. If m3=NULL then
    the difference is created anew and returned. *m3 can point to m1 or m2,
    which can be the same matrices. If dimensions of *m3 do not match then *m3
    is reallocated first.
    $A jul00; */
{
return matrixdif0(m1,m2,m3);
}


void matprodscalplain(matrix m1,double s,matrix res)
    /* Multiplies matrix m1 by scalar s and stores result to res, which can be
    the same matrix as m1. m1 and res may not be NULL and must have compatible
    dimensions, since this is not checked within the function.
    $A Igor dec03; */
{
int i,j;
for (i=1;i<=m1->d1;++i)
  for (j=1;j<=m1->d2;++j)
  res->m[i][j]=m1->m[i][j]*s;
}


matrix matprodscal0(matrix m1,double s2,matrix *m3)
    /* Returns matrix m1 multiplied by scalar s2. If m3 is different than NULL
    then the result is stored to *m3 and *m3 is redurned (with all the
    necessary allocations, deallocations or reallocations performed).
    $A Igor dec03; */
{
matrix m;
int i,j;
if (m3!=NULL)
{
  /* If *m3!=NULL then the result is stored to *m3: */
  if (m1==NULL)
    dispmatrix(m3);
  else if (m1->d1<1 || m1->d2<1)
    dispmatrix(m3);
  else
  {
    /* Resize *m3 if necessary: */
    resizematrix(m3,m1->d1,m1->d2);
    m=*m3;
    /* Perform the operation */
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        m->m[i][j]=m1->m[i][j]*s2;
  }
  return *m3;
} else
{
  /* m3==NULL, a new matrix is created, the result stored in it and matrix
  returned: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    /* Perform operation: */
    /* Perform the operation */
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        m->m[i][j]=m1->m[i][j]*s2;
    return m;
  }
}
}


void matprodplain(matrix m1,matrix m2,matrix res)
    /* V matriko res zapise produkt matrik m1 in m2. Funkcija ne kontrolira
    niti dimenzij niti tega, ce je prostor alociran. Matrika res ne sme biti
    ista kot m1 ali m2, m1 in m2 pa sta lahko isti.
    $A Igor jan00; */
{
int i,j,k;
double s;
for (i=1;i<=m1->d1;++i)
  for (j=1;j<=m2->d2;++j)
  {
    s=0;
    for (k=1;k<=m1->d2;++k)
      s+=m1->m[i][k]*m2->m[k][j];
    res->m[i][j]=s;
  }
}

matrix matprod0(matrix m1,matrix m2,matrix *m3)
    /* Vrne produkt matrik m1 in m2. Ce je m3 razlicen od NULL, zapise rezultat
    v *m3 in vrne *m3. m3 je lahko tudi naslov m1 ali m2, funkcija v tem
    primeru poskrbi za to, da se najprej izracuna rezultat operacije in sele
    nato prepise operand.
     OPOMBA:
     Ce je m3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze m3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
matrix m=NULL,*save=NULL;
if (m3!=NULL)
{
  if (*m3==m1 || *m3==m2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce m3 kaze na
    m1 ali m2: */
    save=m3;
    m3=&m;
  }
  /* Ce je m3!=NULL, se rezultat shrane v *m3: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni z operacijo: */
  if (m1==NULL || m2==NULL)
    dispmatrix(m3);
  else if (m1->d2!=m2->d1 || m1->d1<1 || m1->d2<1 || m2->d2<1)
    dispmatrix(m3);
  else
  {
    /* Preverimo dimenzijo *m3, ce ni ustrezna, zbrisemo *m3: */
    if (*m3!=NULL)
      if ((*m3)->d1!=m1->d1 || (*m3)->d2!=m2->d2)
        dispmatrix(m3);
    /* Ce je *m3==NULL, tvorimo *m3 z dimenzijama m1: */
    if (*m3==NULL)
      *m3=getmatrix(m1->d1,m2->d2);
    /* Izvedba operacije: */
    matprodplain(m1,m2,*m3);
  }
  if (save!=NULL)
  {
    dispmatrix(save);
    *save=*m3;
  }
  return *m3; /* Ker je bil m3!=NULL, se vrne *m3. */
} else
{
  /* m3==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni za operacijo: */
  if (m1==NULL || m2==NULL)
    return NULL;
  else if (m1->d2!=m2->d1 || m1->d1<1 || m1->d2<1 || m2->d2<1)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m2->d2);
    /* Izvedba operacije: */
    matprodplain(m1,m2,m);
    return m;
  }
}
}


void mattranspprodmatplain(matrix m1,matrix m2,matrix res)
    /* V matriko res zapise produkt transponirane matrike m1 in matrike m2.
    Funkcija ne kontrolira niti dimenzij niti tega, ce je prostor alociran.
    Matrika res ne sme biti ista kot m1 ali m2, m1 in m2 pa sta lahko isti.
    $A Igor jan00; */
{
int i,j,k;
double s;
for (i=1;i<=m1->d2;++i)
  for (j=1;j<=m2->d2;++j)
  {
    s=0;
    for (k=1;k<=m1->d1;++k)
      s+=m1->m[k][i]*m2->m[k][j];
    res->m[i][j]=s;
  }
}

matrix mattranspprodmat0(matrix m1,matrix m2,matrix *m3)
    /* Vrne produkt transponirane matrike m1 in matrike m2. Ce je m3 razlicen
    od NULL, zapise rezultat v *m3 in vrne *m3. m3 je lahko tudi naslov m1 ali
    m2, funkcija v tem primeru poskrbi za to, da se najprej izracuna rezultat
    operacije in sele nato prepise operand. Ce matriki nista kompatibilni za
    operacijo, je rezultat NULL.
     OPOMBA:
     Ce je m3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze m3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
matrix m=NULL,*save=NULL;
if (m3!=NULL)
{
  if (*m3==m1 || *m3==m2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce m3 kaze na
    m1 ali m2: */
    save=m3;
    m3=&m;
  }
  /* Ce je m3!=NULL, se rezultat shrane v *m3: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni z operacijo: */
  if (m1==NULL || m2==NULL)
    dispmatrix(m3);
  else if (m1->d1!=m2->d1 || m1->d1<1 || m1->d2<1 || m2->d2<1)
    dispmatrix(m3);
  else
  {
    /* Preverimo dimenzijo *m3, ce ni ustrezna, zbrisemo *m3: */
    if (*m3!=NULL)
      if ((*m3)->d1!=m1->d2 || (*m3)->d2!=m2->d2)
        dispmatrix(m3);
    /* Ce je *m3==NULL, tvorimo *m3 z dimenzijama m1: */
    if (*m3==NULL)
      *m3=getmatrix(m1->d2,m2->d2);
    /* Izvedba operacije: */
    mattranspprodmatplain(m1,m2,*m3);
  }
  if (save!=NULL)
  {
    dispmatrix(save);
    *save=*m3;
  }
  return *m3; /* Ker je bil m3!=NULL, se vrne *m3. */
} else
{
  /* m3==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni za operacijo: */
  if (m1==NULL || m2==NULL)
    return NULL;
  else if (m1->d1!=m2->d1 || m1->d1<1 || m1->d2<1 || m2->d2<1)
    return NULL;
  else
  {
    m=getmatrix(m1->d2,m2->d2);
    /* Izvedba operacije: */
    mattranspprodmatplain(m1,m2,m);
    return m;
  }
}
}




void matprodmattranspplain(matrix m1,matrix m2,matrix res)
    /* V matriko res zapise produkt matrike m1 in transponirane matrike m2.
    Funkcija ne kontrolira niti dimenzij niti tega, ce je prostor alociran.
    Matrika res ne sme biti ista kot m1 ali m2, m1 in m2 pa sta lahko isti.
    $A Igor jan00; */
{
int i,j,k;
double s;
for (i=1;i<=m1->d1;++i)
  for (j=1;j<=m2->d1;++j)
  {
    s=0;
    for (k=1;k<=m1->d2;++k)
      s+=m1->m[i][k]*m2->m[j][k];
    res->m[i][j]=s;
  }
}

matrix matprodmattransp0(matrix m1,matrix m2,matrix *m3)
    /* Vrne produkt matrike m1 in transponirane matrike m2. Ce je m3 razlicna
    od NULL, zapise rezultat v *m3 in vrne *m3. m3 je lahko tudi naslov m1 ali
    m2, funkcija v tem primeru poskrbi za to, da se najprej izracuna rezultat
    operacije in sele nato prepise operand.
     OPOMBA:
     Ce je m3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze m3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
matrix m=NULL,*save=NULL;
if (m3!=NULL)
{
  if (*m3==m1 || *m3==m2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce m3 kaze na
    m1 ali m2: */
    save=m3;
    m3=&m;
  }
  /* Ce je m3!=NULL, se rezultat shrane v *m3: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni z operacijo: */
  if (m1==NULL || m2==NULL)
    dispmatrix(m3);
  else if (m1->d2!=m2->d2 || m1->d1<1 || m1->d2<1 || m2->d1<1)
    dispmatrix(m3);
  else
  {
    /* Preverimo dimenzijo *m3, ce ni ustrezna, zbrisemo *m3: */
    if (*m3!=NULL)
      if ((*m3)->d1!=m1->d1 || (*m3)->d2!=m2->d1)
        dispmatrix(m3);
    /* Ce je *m3==NULL, tvorimo *m3 z dimenzijama m1: */
    if (*m3==NULL)
      *m3=getmatrix(m1->d1,m2->d1);
    /* Izvedba operacije: */
    matprodmattranspplain(m1,m2,*m3);
  }
  if (save!=NULL)
  {
    dispmatrix(save);
    *save=*m3;
  }
  return *m3; /* Ker je bil m3!=NULL, se vrne *m3. */
} else
{
  /* m3==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni za operacijo: */
  if (m1==NULL || m2==NULL)
    return NULL;
  else if (m1->d2!=m2->d2 || m1->d1<1 || m1->d2<1 || m2->d1<1)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m2->d1);
    /* Izvedba operacije: */
    matprodmattranspplain(m1,m2,m);
    return m;
  }
}
}


void mattranspprodmattranspplain(matrix m1,matrix m2,matrix res)
    /* V matriko res zapise produkt transponirane matrike m1 in transponirane
    matrike m2. Funkcija ne kontrolira niti dimenzij niti tega, ce je prostor
    alociran. Matrika res ne sme biti ista kot m1 ali m2, m1 in m2 pa sta
    lahko isti.
    $A Igor jan00; */
{
int i,j,k;
double s;
for (i=1;i<=m1->d2;++i)
  for (j=1;j<=m2->d1;++j)
  {
    s=0;
    for (k=1;k<=m1->d1;++k)
      s+=m1->m[k][i]*m2->m[j][k];
    res->m[i][j]=s;
  }
}

matrix mattranspprodmattransp0(matrix m1,matrix m2,matrix *m3)
    /* Vrne produkt transponirane matrike m1 in transponirane matrike m2. Ce je
    m3 razlicna od NULL, zapise rezultat v *m3 in vrne *m3. m3 je lahko tudi
    naslov m1 ali m2, funkcija v tem primeru poskrbi za to, da se najprej
    izracuna rezultat operacije in sele nato prepise operand. Ce matriki nista
    kompatibilni za operacijo, je rezultat NULL.
     OPOMBA:
     Ce je m3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze m3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
matrix m=NULL,*save=NULL;
if (m3!=NULL)
{
  if (*m3==m1 || *m3==m2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce m3 kaze na
    m1 ali m2: */
    save=m3;
    m3=&m;
  }
  /* Ce je m3!=NULL, se rezultat shrane v *m3: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni z operacijo: */
  if (m1==NULL || m2==NULL)
    dispmatrix(m3);
  else if (m1->d1!=m2->d2 || m1->d1<1 || m1->d2<1 || m2->d1<1)
    dispmatrix(m3);
  else
  {
    /* Preverimo dimenzijo *m3, ce ni ustrezna, zbrisemo *m3: */
    if (*m3!=NULL)
      if ((*m3)->d1!=m1->d2 || (*m3)->d2!=m2->d1)
        dispmatrix(m3);
    /* Ce je *m3==NULL, tvorimo *m3 z dimenzijama m1: */
    if (*m3==NULL)
      *m3=getmatrix(m1->d2,m2->d1);
    /* Izvedba operacije: */
    mattranspprodmattranspplain(m1,m2,*m3);
  }
  if (save!=NULL)
  {
    dispmatrix(save);
    *save=*m3;
  }
  return *m3; /* Ker je bil m3!=NULL, se vrne *m3. */
} else
{
  /* m3==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce sta m1 in m2 kompatibilni za operacijo: */
  if (m1==NULL || m2==NULL)
    return NULL;
  else if (m1->d1!=m2->d2 || m1->d1<1 || m1->d2<1 || m2->d1<1)
    return NULL;
  else
  {
    m=getmatrix(m1->d2,m2->d1);
    /* Izvedba operacije: */
    mattranspprodmattranspplain(m1,m2,m);
    return m;
  }
}
}




void mattranspplain(matrix m,matrix res)
    /* Elementi matrike res postanejo elementi transponirane matrike m.
    Funkcija ne preverja dimenzij in obstoja matrik, zato morajo biti dimenzije
    kompatibilne. Ce j m kvadratna matrika, je lahko res ista matrika kot m.
    $A Igor jan00; */
{
int i,j;
if (res->d1==res->d2)
{
  double x;
  /* Kvadratne matrike: */
  for (i=1;i<=res->d1;++i)
  {
    res->m[i][i]=m->m[i][i];  /* Diagonal. element */
    for (j=1;j<i;++j)
    {
      /* Izvendiagonalni elementi; Ce sta m in res isti matriki, vmesna
      spremenljivka x prepreci, da bi se poddiagonalni element original.
      matrike prepisal z ustreznim naddiagonalnim, preden je prirejen: */
      x=m->m[i][j];
      res->m[i][j]=m->m[j][i];
      res->m[j][i]=x;
    }
  }
} else
{
  /* Nekvadratne matrike: */
  for (i=1;i<=res->d1;++i)
    for (j=1;j<=res->d2;++j)
      res->m[i][j]=m->m[j][i];
}
}


matrix mattransp0(matrix m1,matrix *res)
    /* Vrne transponirano matriko m1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. res je lahko tudi naslov m1, funkcija v tem
    primeru poskrbi za to, da se najprej izracuna rezultat operacije in sele
    nato prepise operand.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
matrix m=NULL,*save=NULL;
if (res!=NULL)
{
  if (*res==m1 && m1!=NULL)
    if (m1->d1!=m1->d2)
    {
      /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce res kaze na
      m1 in m1 ni kvadratna matrika: */
      save=res;
      res=&m;
    }
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispmatrix(res);
  else if (m1->d1<1 || m1->d2<1)
    dispmatrix(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d1!=m1->d2 || (*res)->d2!=m1->d1)
        dispmatrix(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getmatrix(m1->d2,m1->d1);
    /* Izvedba operacije: */
    mattranspplain(m1,*res);
  }
  if (save!=NULL)
  {
    dispmatrix(save);
    *save=*res;
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    m=getmatrix(m1->d2,m1->d1);
    /* Izvedba operacije: */
    mattranspplain(m1,m);
    return m;
  }
}
}



            /***************************/
            /*                         */
            /*  INVERSION OF MATRICES  */
            /*                         */
            /***************************/



static void matinvplain1(matrix mat,matrix res)
    /* Kvadratna matrika res postane inverzna matrika matrike mat, ce je m 
    obrnljiva. Funkcija ne preverja dimenzij matrik, zato morajo biti te
    kompatibilne.
    - INVERZ PO TOMAZU SUSTERJU
    $A Igor jan00; */
{
int i,j;
int *order=NULL;
vector scale=NULL;
matrix coef=NULL;
coef=getmatrix(mat->d1,mat->d2);
for (i=1;i<=mat->d1;++i)
  for (j=1;j<=mat->d2;++j)
    coef->m[i][j]=mat->m[i][j];
order=malloc((1+mat->d1)*sizeof(*order));
scale=getvector(mat->d1);
luordermat(scale,coef,order);
ludecompmat(scale,coef,order);
luinvmat(coef,res,order);
free(order);
dispmatrix(&coef);
dispvector(&scale);
}


matrix matinv1(matrix m1,matrix *res)
    /* Vrne inverz matrike m1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. res je lahko tudi naslov m1, funkcija v tem
    primeru poskrbi za to, da se najprej izracuna rezultat operacije in sele
    nato prepise operand.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    - INVERZ PO TOMAZU SUSTERJU
    $A Igor jan00; */
{
matrix m=NULL,*save=NULL;
if (res!=NULL)
{
  if (*res==m1)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce res kaze na
    m1: */
    save=res;
    res=&m;
  }
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispmatrix(res);
  else if (m1->d1<1 || m1->d2<1 || m1->d1!=m1->d2)
    dispmatrix(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d1!=m1->d1 || (*res)->d2!=m1->d2)
        dispmatrix(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    matinvplain1(m1,*res);
  }
  if (save!=NULL)
  {
    dispmatrix(save);
    *save=*res;
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2<1 || m1->d1!=m1->d2)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    matinvplain1(m1,m);
    return m;
  }
}
}


void matinvplain(matrix mat,matrix res)
    /* Kvadratna matrika res postane inverzna matrika matrike mat, ce je m 
    obrnljiva. Funkcija ne preverja dimenzij matrik, zato morajo biti te
    kompatibilne.
    $A Igor jan00; */
{
matinvplain1(mat,res);
}

matrix matinv0(matrix m1,matrix *res)
    /* Vrne inverz matrike m1. Ce je res razlicen od NULL, zapise
    rezultat v *res in vrne *res. res je lahko tudi naslov m1, funkcija v tem
    primeru poskrbi za to, da se najprej izracuna rezultat operacije in sele
    nato prepise operand.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
return matinv1(m1,res);
}




            /********************************/
            /*                              */
            /*  DECOMPOSITIONS OF MATRICES  */
            /*                              */
            /********************************/



    /* LLT (Choleski) DECOMPOSITION (symmetric positive definite matrices) */

int LLTdecomptolplain(matrix m1,matrix res,double smalltol)
    /* Izvede Choleskijevo dekompozicijo matrike m1 in shrane rezultat v res.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 pozitivno definitna)
    ali negativno vrednost, ce operacija ni bila uspesna. V tem primeru vrne
    minus stevilko vrstice, kjer se je pojavil negativni diagonalni element,
    ali -m1->d-1, ce je kvadrat razmerja med min. in maks. elemantom manj kot
    smalltol.
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan diagonalni element ali deljitelj enak 0 (obicajno je kar 0!).
    Matrika res je lahko ista kot m1, v tem primeru funkcija zapise v m1
    spodnjetrikotne elemente dekompozicije ter nicle nad diagonalo.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */
{
int i,j,k,ret=0;
double s,mindiag,maxdiag;
smalltol=fabs(smalltol);
for (i=1;i<=m1->d1;++i)
{
  /* Diagonalni element: */
  s=m1->m[i][i];
  for (k=1;k<i;++k)
    s-=res->m[i][k]*res->m[i][k];
  if (s<=0)
  {
    printf("\n\nLLT - Check 0: l[%i,%i]<=0\n\n",i,i);
    return -i;
  }
  if (i==1)
    maxdiag=mindiag=fabs(s);
  else
  {
    maxdiag=m_maxval(maxdiag,fabs(s));
    mindiag=m_minval(mindiag,fabs(s));
  }
  res->m[i][i]=sqrt(s);
  /* Izvendiagonalni elementi: */
  for (j=i+1;j<=m1->d1;++j)
  {
    s=m1->m[i][j];
    for (k=1;k<i;++k)
      s-=res->m[i][k]*res->m[j][k];
    res->m[j][i]=s/res->m[i][i];
    res->m[i][j]=0;
  }
}
if (mindiag/maxdiag<smalltol)
{
  printf("n\nLLT - Check 1: (min. diag.)/(max.diag.) < %g\n\n",smalltol);
  ret=-m1->d1-1;
}
return ret;
}



int LLTdecomptolplainrows(matrix m1,matrix res,double smalltol)
    /* Izvede Choleskijevo dekompozicijo matrike m1 in shrane rezultat v res.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 pozitivno definitna)
    ali negativno vrednost, ce operacija ni bila uspesna.
      Dekompozicija se izvede po vrsticah, v nasprotju s funkcijo
    LLTdecomptolplain, ki jo izvede po stolpcih. V splosnem naj se uporablja
    LLTdecomptolplain!
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan diagonalni element ali deljitelj enak 0 (obicajno je kar 0!).
    Matrika res in d je lahko ista kot m1, v tem primeru funkcija zapise
    v m1 spodnjetrikotne elemente res ter nicle nad diagonalo.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira s spodnjim trikotnikom matrike.
    $A Igor jan00; */
{
int i,j,k,ret=0;
double s,mindiag,maxdiag;
smalltol=fabs(smalltol);
for (i=1;i<=m1->d1;++i)
{
  /* Izvendiagonalni elementi: */
  for (j=1;j<i;++j)
  {
    s=m1->m[i][j];
    for (k=1;k<j;++k)
      s-=res->m[i][k]*res->m[j][k];
    res->m[i][j]=s/res->m[j][j];
    res->m[j][i]=0;
  }
  /* Diagonalni element: */
  s=m1->m[i][i];
  for (k=1;k<i;++k)
    s-=res->m[i][k]*res->m[i][k];
  if (s<=0)
  {
    printf("\n\nLLT - Check 0: l[%i,%i]<=0\n\n",i,i);
    return -i;
  }
  if (i==1)
    maxdiag=mindiag=fabs(s);
  else
  {
    maxdiag=m_maxval(maxdiag,fabs(s));
    mindiag=m_minval(mindiag,fabs(s));
  }
  res->m[i][i]=sqrt(s);
}
if (mindiag/maxdiag<smalltol)
{
  printf("n\nLLT - Check 1: (min. diag.)/(max.diag.) < %g\n\n",smalltol);
  ret=-m1->d1-1;
}
return ret;
}


matrix LLTdecomptol0(matrix m1,matrix *res,double smalltol)
    /* Vrne LLT (Choleskijevo) dekompozicijo matrike m1. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. res je lahko tudi naslov m1.
    Funkcija vrne NULL, ce dekompozicija  ni bila uspesna. Funkcija ne cekira,
    ce je matrika m1 simetricna, temvec operacijo enostavno izvede na zgornjem
    trikotnik matrike.
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan diagonalni element ali deljitelj enak 0 (obicajno je kar 0!).
    Matrika res in d je lahko ista kot m1, v tem primeru funkcija zapise
    v m1 spodnjetrikotne elemente res ter nicle nad diagonalo.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
matrix m=NULL;
if (res!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
    dispmatrix(res);
  else if (m1->d1<1 || m1->d2<1 || m1->d1!=m1->d2)
    dispmatrix(res);
  else
  {
    /* Preverimo dimenzijo *res, ce ni ustrezna, zbrisemo *res: */
    if (*res!=NULL)
      if ((*res)->d1!=m1->d1 || (*res)->d2!=m1->d2)
        dispmatrix(res);
    /* Ce je *res==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*res==NULL)
      *res=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    if (LLTdecomptolplain(m1,*res,smalltol))
      dispmatrix(res); /* operacija je bila neuspesna */
  }
  return *res; /* Ker je bil res!=NULL, se vrne *res. */
} else
{
  /* res==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2<1 || m1->d1!=m1->d2)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    if (LLTdecomptolplain(m1,m,smalltol))
      dispmatrix(&m);
    return m;
  }
}
}

int LLTdecompplain(matrix m1,matrix res)
    /* Izvede Choleskijevo dekompozicijo matrike m1 in shrane rezultat v res.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 pozitivno definitna)
    ali -1, ce operacija ni bila uspesna.
    Matrika res in d je lahko ista kot m1, v tem primeru funkcija zapise
    v m1 spodnjetrikotne elemente res ter nicle nad diagonalo.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */
{
return LLTdecomptolplain(m1,res,0);
}


matrix LLTdecomp0(matrix m1,matrix *res)
    /* Vrne LLT (Choleskijevo) dekompozicijo matrike m1. Ce je res razlicen od
    NULL, zapise rezultat v *res in vrne *res. res je lahko tudi naslov m1.
    Funkcija vrne NULL, ce dekompozicija  ni bila uspesna. Funkcija ne cekira,
    ce je matrika m1 simetricna, temvec operacijo enostavno izvede na zgornjem
    trikotnik matrike.
     OPOMBA:
     Ce je res razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze res (ker imamo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor jan00; */
{
return LLTdecomptol0(m1,res,0);
}



    /*  LDLT DECOMPOSITION (symmetric matrices) */



int LDLTdecomptolplain(matrix m1,matrix res,matrix d,double smalltol)
    /* Izvede LDLT dekompozicijo matrike m1 in shrane rezultat v l in d.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 obrnljiva), ali
    negativno vrednost, ce operacija ni bila uspesna in sicer -i, ce je
    diagonalni element i tocno 0, ali -m1->d1-1, ce je razmerje med absolutno
    najmanjsim in najvecjim izracunanim diagonalnim elementom manj kot
    smalltol (v tem primeru se dekompozicija sicer izracuna do konca, le da je
    treba racunati z vecjim vplivom numericnih napak).
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    razmerje med absolutno najmanjsim in najvecjim diagonalnim elementom zelo
    malo (slaba pogojenost - velikokrat damo za toleranco kar 0!).
    Matriki res in d sta lahko isti kot m1, v tem primeru funkcija zapise
    v m1 diegonalne elemente d in poddiagonalne elemente matrike res, nad
    diagonalo pa zapise nicle.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */
{
int i,j,k,ret=0,dim1,dim2;
double s,maxdiag,mindiag;
double *line_m1_i,*line_res_i,*line_res_j,*diag;
vector vdiag=NULL;
dim1=m1->d1;
dim2=m1->d2;
if (dim1>20)
{
  /* Optimised version by using auxiliary pointers: */
  vdiag=getvector(dim1);
  diag=vdiag->v;
  for (i=1;i<=dim1;++i)
  {
    line_m1_i=m1->m[i];
    line_res_i=res->m[i];
    /* Diagonalni element: */
    s=line_m1_i[i];
    for (k=1;k<i;++k)
      s-=line_res_i[k]*line_res_i[k]*diag[k];
    line_res_i[i]=1;
    diag[i]=s; /* sqrt(s); */
    if (i==1)
      maxdiag=mindiag=fabs(s);
    else
    {
      maxdiag=m_maxval(maxdiag,fabs(s));
      mindiag=m_minval(mindiag,fabs(s));
    }
    if (s==0)
    {
      printf("\n\nCheck 0: diag[%i,%i]=0\n\n",i,i);
      return -i;
    }
    /* Izveniagonalni elementi: */
    for (j=i+1;j<=dim1;++j)
    {
      line_res_j=res->m[j];
      s=line_m1_i[j];
      for (k=1;k<i;++k)
        s-=line_res_i[k]*line_res_j[k]*diag[k];
      d->m[i][j]=d->m[j][i]=0;
      line_res_j[i]=s/diag[i];
    }
  }
  for (i=1;i<=dim1;++i)
    d->m[i][i]=diag[i];
  dispvector(&vdiag);
} else
  {
    /* Original version, components of matrices and vectors are accessed
    directly: */
  for (i=1;i<=m1->d1;++i)
  {
    /* Diagonalni element: */
    s=m1->m[i][i];
    for (k=1;k<i;++k)
      s-=res->m[i][k]*res->m[i][k]*d->m[k][k];
    res->m[i][i]=1;
    d->m[i][i]=s; /* sqrt(s); */
    if (i==1)
      maxdiag=mindiag=fabs(s);
    else
    {
      maxdiag=m_maxval(maxdiag,fabs(s));
      mindiag=m_minval(mindiag,fabs(s));
    }
    if (s==0)
    {
      printf("\n\nCheck 0: diag[%i,%i]=0\n\n",i,i);
      return -i;
    }
    /* Izveniagonalni elementi: */
    for (j=i+1;j<=m1->d1;++j)
    {
      s=m1->m[i][j];
      for (k=1;k<i;++k)
        s-=res->m[i][k]*res->m[j][k]*d->m[k][k];
      d->m[i][j]=d->m[j][i]=0;
      res->m[j][i]=s/d->m[i][i];
    }
  }
}
if (mindiag/maxdiag<smalltol)
{
  printf("\n\nLDLT - Check 1: (min. diag./max.diag.)<%g\n\n",i,i,smalltol);
  ret=-m1->d1-1;
}
return ret;
}


int LDLTdecomptolplainrows(matrix m1,matrix res,matrix d,double smalltol)
    /* Izvede LDLT dekompozicijo matrike m1 in shrane rezultat v l in d.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 obrnljiva) ali
    negativno stevilo (podobno kot LDLTdecomptolplain), ce operacija ni bila
    uspesna.
    Elementi matrike L so v nasprotju s funkcijo LDLTdecomptolplain izracunani
    po vrsticah. Uporablja naj se kar funkcija LDLTdecomptolplain!
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan deljitelj enak 0 (obicajno je ta kar 0!).
    Matriki res in d sta lahko isti kot m1, v tem primeru funkcija zapise
    v m1 diegonalne elemente d in poddiagonalne elemente matrike res, nad
    diagonalo pa zapise nicle.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */
{
int i,j,k,ret=0;
double s,mindiag,maxdiag;
for (i=1;i<=m1->d1;++i)
{
  /* Izveniagonalni elementi: */
  for (j=1;j<i;++j)
  {
    s=m1->m[i][j];
    for (k=1;k<j;++k)
      s-=res->m[i][k]*res->m[j][k]*d->m[k][k];
    /*
    if (fabs(d->m[j][j])<=smalltol)
    {
      printf("\n\nCheck 1: l[%i,%i]<tol\n\n",i,i);
      return -1;
    }
    */
    d->m[i][j]=d->m[j][i]=0;
    res->m[i][j]=s/d->m[j][j];
  }
  /* Diagonalni element: */
  s=m1->m[i][i];
  for (k=1;k<i;++k)
    s-=res->m[i][k]*res->m[i][k]*d->m[k][k];
  res->m[i][i]=1;
  d->m[i][i]=s; /* sqrt(s); */
  if (i==1)
    maxdiag=mindiag=fabs(s);
  else
  {
    maxdiag=m_maxval(maxdiag,fabs(s));
    mindiag=m_minval(mindiag,fabs(s));
  }
  if (s==0)
  {
    printf("\n\nLDLT - Check 0: l[%i,%i]=0\n\n",i,i);
    return -i;
  }
}
if (mindiag/maxdiag<smalltol)
{
  printf("\n\nLDLT - Check 1: (min. diag./max.diag.)<%g\n\n",i,i,smalltol);
  ret=-m1->d1-1;
}
return ret;
}


matrix LDLTdecomptol0(matrix m1,matrix *resL,matrix *resD,double smalltol)
    /* Vrne LDLT dekompozicijo matrike m1. Spodnje trikotno matriko zapise v
    matriko *resL , ki jo tudi vrne, diagonalno pa v resD. resL ali resD sta
    lahko tudi naslova m1 ali naslova iste matrike.
    Funkcija vrne NULL, ce dekompozicija  ni bila uspesna. Funkcija ne cekira,
    ce je matrika m1 simetricna, temvec operacijo enostavno izvede na zgornjem
    trikotnik matrike.
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan deljitelj enak 0 (obicajno je kar 0!).
     OPOMBA:
     resL in resD sta lahko tudi NULL.
    $A Igor jan00; */
{
matrix m=NULL;
if (resD==NULL)
  resD=resL;
else if (resL==NULL)
  resL=resD;
if (resL!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
  {
    dispmatrix(resL);
    dispmatrix(resD);
  }
  else if (m1->d1<1 || m1->d2<1 || m1->d1!=m1->d2)
  {
    dispmatrix(resL);
    dispmatrix(resD);
  }
  else
  {
    /* Preverimo dimenzijo *resL in *resD, ce ni ustrezna, ju zbrisemo: */
    if (*resL!=NULL)
      if ((*resL)->d1!=m1->d1 || (*resL)->d2!=m1->d2)
        dispmatrix(resL);
    /* Ce je *resL==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*resL==NULL)
      *resL=getmatrix(m1->d1,m1->d2);
    if (*resD!=NULL)
      if ((*resD)->d1!=m1->d1 || (*resD)->d2!=m1->d2)
        dispmatrix(resD);
    /* Ce je *resD==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*resD==NULL)
      *resD=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    if (LDLTdecomptolplain(m1,*resL,*resD,smalltol))
    {
      /* Operacija je bila neuspesna: */
      dispmatrix(resL); 
      dispmatrix(resD);
    }
  }
  return *resL;
} else
{
  /* resD=resL=NULL, naredi se nova matrika, v katero se zapise rezultat
  operacije, vrne se njen kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2<1 || m1->d1!=m1->d2)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    if (LDLTdecomptolplain(m1,m,m,smalltol))
      dispmatrix(&m);
    return m;
  }
}
}


int LDLTdecompplain(matrix m1,matrix res,matrix d)
    /* Izvede LDLT dekompozicijo matrike m1 in shrane rezultat v l in d.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 obrnljiva) ali -1,
    ce operacija ni bila uspesna.
    Matriki res in d sta lahko isti kot m1, v tem primeru funkcija zapise
    v m1 diegonalne elemente d in poddiagonalne elemente matrike res, nad
    diagonalo pa zapise nicle.
     POZOR:
     Funkcija tudi ne kontrolira, ce je matrika m1 simetricna, temvec enostavno
    operira z zgornjim trikotnikom matrike.
    $A Igor jan00; */
{
return LDLTdecomptolplain(m1,res,d,0);
}

matrix LDLTdecomp0(matrix m1,matrix *resL,matrix *resD)
    /* Vrne LDLT dekompozicijo matrike m1. Spodnje trikotno matriko zapise v
    matriko *resL , ki jo tudi vrne, diagonalno pa v resD. resL ali resD sta
    lahko tudi naslova m1 ali naslova iste matrike.
    Funkcija vrne NULL, ce dekompozicija  ni bila uspesna. Funkcija ne cekira,
    ce je matrika m1 simetricna, temvec operacijo enostavno izvede na ZGORNJEM
    TRIKOTNIKU matrike.
     OPOMBA:
     resL in resD sta lahko tudi NULL.
    $A Igor jan00; */
{
return LDLTdecomptol0(m1,resL,resD,0);
}




int LUdecomptolplain(matrix m1,matrix ml,matrix mu,indtab ind,
                     int *parity,double smalltol)
    /* Izvede LU dekompozicijo matrike m1 in shrane rezultat v ml in mu.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 obrnljiva) ali -1,
    ce operacija ni bila uspesna.
    indtab je lahko NULL, v tem primeru se dekompozicija izvede brez
    pivotiranja, vendar to NI PRIPOROCLJIVO, ker lahko dobimo 0 na diagonali,
    ceprav matrika ni singularna. parity je lahko NULL, v tem primeru se ne
    zabelezi, ce je bilo zamenjav liho stevilo, in se ne more racunati
    determinanta matrike.
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan deljitelj enak 0 (obicajno je ta kar 0!).
    Matriki ml in md sta lahko isti kot m1, v tem primeru funkcija zapise
    v ml diagonalne elemente in poddiagonalne elemente matrike ml, nad
    diagonalo pa elemente matrike mu.
      parity je lahko enak NULL, v tem primeru se ne zabelezi, ali je stevilo
    zamenjav bilo liho ali sodo (to se tako ali tako rabi samo pri racunanju
    determinante). Tudi indtab je naceloma lahko NULL, vendat to NI
    PRIPOROCLJIVO! V tem primeru namrec funkcija ne izvaja pivotiranja in se
    lahko zgodi, da ima matriko za singularno, ceprav ni. Drugace funkcija
    izvaja implicitno pivotiranje.
    Ref. Num. Rec., p.p.43-49.
    $A Igor avg00; */
{
int ret=0;
int i,j,k,n,imax,dim1,dim2;
double x,s,val;
double *line_m1_i,*line_m1_j,*line_l_i,*line_l_j,*line_u_i,*line_u_j,*line_v;
vector v=NULL;
dim1=m1->d1;
dim2=m1->d2;
n=m1->d1;
if (parity!=NULL)
  *parity=1;
if (ind!=NULL)
{
  /* Mozne so zamenjave vrstic, zato najprej poskrbimo, da se ohrani originalna
  matrika m1, ce je tako misljeno (torej, ce nobena od matrik ml in mu ni ista
  kot m1); ohranitev originalnih vrednosti dosezemo s tem, da m1 skopiramo v
  ml in uporabljamo to kopijo kot m1: */
  if (m1!=ml && m1!=mu)
  {
    for (i=1;i<=m1->d1;++i)
    {
      line_m1_i=m1->m[i];
      line_l_i=ml->m[i];
      for (j=1;j<=m1->d2;++j)
        line_l_i[j]=line_m1_i[j];
    }
    m1=ml;
  }
  v=getvector(n);
  line_v=v->v;
  /* Izracun skalirnih faktorjev za izbiro najboljsega pivota: */
  for (i=1;i<=n;++i)
  {
    val=0;
    line_m1_i=m1->m[i];
    for (j=1;j<=n;++j)
      if ((x=fabs(line_m1_i[j]))>val)
        val=x;
    if (val==0) /* V i. vrstici ni nenicelnega elementa, matrika je singularna */
    {
      dispvector(&v);
      return -1;
    } else
      line_v[i]=1/val;
  }
}
for (j=1;j<=n;++j) /* iteracija po stolpcih */
{
  line_m1_j=m1->m[j];
  line_l_j=ml->m[j];
  line_u_j=mu->m[j];  
  /* Izracun elementov nad diagonalo: */
  /* Izracun elementov nad diagonalo: */
  for (i=1;i<j;++i)
  {
    line_l_i=ml->m[i];
    s=m1->m[i][j];
    for (k=1;k<i;++k)
      s-=line_l_i[k]*mu->m[k][j];
    mu->m[i][j]=s;
  }
  /* Izracun elementov na in pod diagonalo in pomnjenje vrstice z relativno 
  najvecjim pivotom: */
  val=0; /* najvecji primerjalni faktor za pivot */
  imax=j; /* vrstica z najboljsim pivotom */
  for (i=j;i<=n;++i)
  {
    s=m1->m[i][j];
    line_l_i=ml->m[i];
    for (k=1;k<j;++k)
      s-=line_l_i[k]*mu->m[k][j];
    /* Prireditev izracunane vrednosti ustreznemu elementu ustrezne matrike: */
    if (i==j)
    {
      line_l_i[j]=1;
      mu->m[i][j]=s;
    } else
      line_l_i[j]=s;
    if (v!=NULL)
    {
      if ((x=v->v[i]*fabs(s)) >= val)
      {
        /* Nasli smo boljsi pivot od prejsnjega najboljsega */
        val=x;
        imax=i;
      }
    }
  }  /* iteracija po vrsticah - elementi na in pod diagonalo */
  /* Zamenjava vrstic, ce je to potrebno: */
  if (v!=NULL)
  {
    ind->t[j]=imax; /* indeks v tabeli, ki belezi zamenjave vrstic */
    if (imax!=j) /* zamenjava vrstic je potrebna */
    {
      /* printf("INTERCHANGING rows %i and %i.\n",j,imax); */
      /* Zamenjava vrstic j in imax: */
      line_l_i=ml->m[imax];
      line_u_i=mu->m[imax];
      for (k=1;k<j;++k)
      {
        x=line_l_j[k];
        line_l_j[k]=line_l_i[k];
        line_l_i[k]=x;
      }
      x=line_u_j[j];
      line_u_j[j]=line_l_i[j];
      line_l_i[j]=x;
      line_m1_i=m1->m[imax];
      for (k=j+1;k<=n;++k)
      {
        x=line_m1_j[k];
        line_m1_j[k]=line_m1_i[k];
        line_m1_i[k]=x;
      }
      /* Zaradi zamenjave se spremeni parnost, zamenjati je potrebno tudi
      skalirni faktor vrstice imax: */
      if (parity!=NULL)
        *parity=-*parity;
      line_v[imax]=line_v[j];  /* j. elementa ne rabimo vec */
    }
  }
  
  if (fabs(line_u_j[j])<=smalltol)
  {
    /* Zabelezen je nicti pivot, matrika je singularna */
    
  }
  /* Nazadnje se deljenje s pivotom: */
  if (j<n)
  {
    x=1/line_u_j[j];
    for (i=j+1;i<=n;++i)
      ml->m[i][j]*=x;
  }
} /* iteracija po stolpcih */
/* Ce se zgornje in spodnje trikotna matrika ne shranita v isto matriko,
postavimo naddiagonalne elemente pri ml in poddiagonalne pri mu na 0: */

if (ml!=mu)
  for (i=1;i<=n;++i)
  {
    line_l_i=ml->m[i];
    for (j=i+1;j<=n;++j)
      line_l_i[j]=mu->m[j][i]=0;
  }
dispvector(&v);
return ret;
}




int LUdecomptolplainold(matrix m1,matrix ml,matrix mu,indtab ind,
                     int *parity,double smalltol)
    /* Izvede LU dekompozicijo matrike m1 in shrane rezultat v l in d.
    Funkcija sama ne kontrolira kompatibilnosti dimenzij, zato morajo biti
    dimenzije argumentov ze kompatibilne. Funkcija vrne 0, ce je lahko
    dekompozicijo uspesno opravila (t.j. ce je matrika m1 obrnljiva) ali -1,
    ce operacija ni bila uspesna.
    indtab je lahko NULL, v tem primeru se dekompozicija izvede brez
    pivotiranja, vendar to NI PRIPOROCLJIVO, ker lahko dobimo 0 na diagonali,
    ceprav matrika ni singularna. parity je lahko NULL, v tem primeru se ne
    zabelezi, ce je bilo zamenjav liho stevilo, in se ne more racunati
    determinanta matrike.
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan deljitelj enak 0 (obicajno je ta kar 0!).
    Matriki res in d sta lahko isti kot m1, v tem primeru funkcija zapise
    v m1 diegonalne elemente d in poddiagonalne elemente matrike res, nad
    diagonalo pa zapise nicle.
      parity je lahko enak NULL, v tem primeru se ne zabelezi, ali je stevilo
    zamenjav bilo liho ali sodo (to se tako ali tako rabi samo pri racunanju
    determinante). Tudi indtab je naceloma lahko NULL, vendat to NI
    PRIPOROCLJIVO! V tem primeru namrec funkcija ne izvaja pivotiranja in se
    lahko zgodi, da ima matriko za singularno, ceprav ni. Drugace funkcija
    izvaja implicitno pivotiranje.
    Ref. Num. Rec., p.p.43-49.
    $A Igor avg00; */
{
int ret=0;
int i,j,k,n,imax;
double x,s,val;
vector v=NULL;
n=m1->d1;
if (parity!=NULL)
  *parity=1;
if (ind!=NULL)
{
  /* Mozne so zamenjave vrstic, zato najprej poskrbimo, da se ohrani originalna
  matrika m1, ce je tako misljeno (torej, ce nobena od matrik ml in mu ni ista
  kot m1); ohranitev originalnih vrednosti dosezemo s tem, da m1 skopiramo v
  ml in uporabljamo to kopijo kot m1: */
  if (m1!=ml && m1!=mu)
  {
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        ml->m[i][j]=m1->m[i][j];
    m1=ml;
  }
  v=getvector(n);
  /* Izracun skalirnih faktorjev za izbiro najboljsega pivota: */
  for (i=1;i<=n;++i)
  {
    val=0;
    for (j=1;j<=n;++j)
      if ((x=fabs(m1->m[i][j]))>val)
        val=x;
    if (val==0) /* V i. vrstici ni nenicelnega elementa, matrika je singularna */
    {
      dispvector(&v);
      return -1;
    } else
      v->v[i]=1/val;
  }
}
for (j=1;j<=n;++j) /* iteracija po stolpcih */
{
  /* Izracun elementov nad diagonalo: */
  for (i=1;i<j;++i)
  {
    s=m1->m[i][j];
    for (k=1;k<i;++k)
      s-=ml->m[i][k]*mu->m[k][j];
    mu->m[i][j]=s;
  }
  /* Izracun elementov na in pod diagonalo in pomnjenje vrstice z relativno 
  najvecjim pivotom: */
  val=0; /* najvecji primerjalni faktor za pivot */
  imax=j; /* vrstica z najboljsim pivotom */
  for (i=j;i<=n;++i)
  {
    s=m1->m[i][j];
    for (k=1;k<j;++k)
      s-=ml->m[i][k]*mu->m[k][j];
    /* Prireditev izracunane vrednosti ustreznemu elementu ustrezne matrike: */
    if (i==j)
    {
      ml->m[i][j]=1;
      mu->m[i][j]=s;
    } else
      ml->m[i][j]=s;
    if (v!=NULL)
    {
      if ((x=v->v[i]*fabs(s)) >= val)
      {
        /* Nasli smo boljsi pivot od prejsnjega najboljsega */
        val=x;
        imax=i;
      }
    }
  }  /* iteracija po vrsticah - elementi na in pod diagonalo */
  /* Zamenjava vrstic, ce je to potrebno: */
  if (v!=NULL)
  {
    ind->t[j]=imax; /* indeks v tabeli, ki belezi zamenjave vrstic */
    if (imax!=j) /* zamenjava vrstic je potrebna */
    {
      /* printf("INTERCHANGING rows %i and %i.\n",j,imax); */
      /* Zamenjava vrstic j in imax: */
      for (k=1;k<j;++k)
      {
        x=ml->m[j][k];
        ml->m[j][k]=ml->m[imax][k];
        ml->m[imax][k]=x;
      }
      x=mu->m[j][j];
      mu->m[j][j]=ml->m[imax][j];
      ml->m[imax][j]=x;
      for (k=j+1;k<=n;++k)
      {
        x=m1->m[j][k];
        m1->m[j][k]=m1->m[imax][k];
        m1->m[imax][k]=x;
      }
      /* Zaradi zamenjave se spremeni parnost, zamenjati je potrebno tudi
      skalirni faktor vrstice imax: */
      if (parity!=NULL)
        *parity=-*parity;
      v->v[imax]=v->v[j];  /* j. elementa ne rabimo vec */
    }
  }
  
  if (fabs(mu->m[j][j])<=smalltol)
  {
    /* Zabelezen je nicti pivot, matrika je singularna */
    
  }
  /* Nazadnje se deljenje s pivotom: */
  if (j<n)
  {
    x=1/mu->m[j][j];
    for (i=j+1;i<=n;++i)
      ml->m[i][j]*=x;
  }
} /* iteracija po stolpcih */
/* Ce se zgornje in spodnje trikotna matrika ne shranita v isto matriko,
postavimo naddiagonalne elemente pri ml in poddiagonalne pri mu na 0: */

if (ml!=mu)
  for (i=1;i<=n;++i)
    for (j=i+1;j<=n;++j)
      ml->m[i][j]=mu->m[j][i]=0;
dispvector(&v);
return ret;
}




matrix LUdecomptol0(matrix m1,matrix *resL,matrix *resU,indtab *ind,
                    int *parity,double smalltol)
    /* Vrne LU dekompozicijo matrike m1, t.j. produkt spodnjetrikotne matrike
    z enkami na diagonali in zgornjetrikotne matrike. Spodnjetrikotno matriko
    zapise v matriko *resL , ki jo tudi vrne, zgornjetrikotno pa v resU. resL
    ali resU sta lahko tudi naslova m1 ali naslova iste matrike. V tem primeru
    se enice na diagonali spodnjetrikotne matrike prepisejo z diagonalnimi
    elementi zgornjetrikotne matrike. V *indtab funkcija zabelezi vrstni red
    vrstic po zamenjavah, v *parity pa zapise -1, ce je bilo zamenjav liho st.,
    in 1, ce jih je bilo sodo stevilo (to se rabi pri racunanju determinante).
    indtab je lahko NULL, v tem primeru se dekompozicija izvede brez
    pivotiranja, vendar to NI PRIPOROCLJIVO, ker lahko dobimo 0 na diagonali,
    ceprav matrika ni singularna. parity je lahko NULL, v tem primeru se ne
    zabelezi, ce je bilo zamenjav liho stevilo, in se ne more racunati
    determinanta matrike.
    Funkcija vrne NULL, ce dekompozicija  ni bila uspesna (singularna matrika
    ali kak drug razlog).
    Funkcija uporablja konstanto smalltol za toleranco, s katero preveri, ce je
    izracunan deljitelj enak 0 (obicajno je kar 0!).
     OPOMBA:
     resL in resU sta lahko tudi NULL, v tem primeru funkcija vrne matriko, v
    kateri ima spravljeni obe trikotni matriki.
    $A Igor avg00; */
{
matrix m=NULL;
indtab indint;
if (resU==NULL)
  resU=resL;
else if (resL==NULL)
  resL=resU;
if (resL!=NULL)
{
  /* Ce je res!=NULL, se rezultat shrane v *res: */
  /* Najprej preverimo, ce je matrika m1 kompatibilna z operacijo: */
  if (m1==NULL)
  {
    dispmatrix(resL);
    dispmatrix(resU);
  }
  else if (m1->d1<1 || m1->d2<1 || m1->d1!=m1->d2)
  {
    dispmatrix(resL);
    dispmatrix(resU);
  }
  else
  {
    /* Preverimo dimenzijo *resL in *resU, ce ni ustrezna, ju zbrisemo: */
    if (*resL!=NULL)
      if ((*resL)->d1!=m1->d1 || (*resL)->d2!=m1->d2)
        dispmatrix(resL);
    /* Ce je *resL==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*resL==NULL)
      *resL=getmatrix(m1->d1,m1->d2);
    if (*resU!=NULL)
      if ((*resU)->d1!=m1->d1 || (*resU)->d2!=m1->d2)
        dispmatrix(resU);
    /* Ce je *resU==NULL, jo tvorimo z ustreznima dimenzijama: */
    if (*resU==NULL)
      *resU=getmatrix(m1->d1,m1->d2);
    if (ind!=NULL)
    {
      if (*ind!=NULL) /* Preverijo se dimenzije *ind */
        if ((*ind)->r<m1->d1 || (*ind)->r-(*ind)->ex>m1->d1)
          dispindtab(ind);
      if (*ind==NULL) /* Po potrebi se *ind alocira na novo */
        *ind=newindtab(0,m1->d1);
      (*ind)->n=m1->d1;
      indint=*ind; /* V operaciji bomo uporabljali indint, ki je NULL, ce je ind=NULL. */
    }
    /* Izvedba operacije: */
    if (LUdecomptolplain(m1,*resL,*resU,indint,parity,smalltol))
    {
      /* Operacija je bila neuspesna: */
      dispmatrix(resL); 
      dispmatrix(resU);
      dispindtab(ind);
      return NULL;
    }
  }
  return *resL;
} else
{
  /* resU=resL=NULL, naredi se nova matrika, v katero se zapise rezultat
  operacije, vrne se njen kazalec: */
  /* Najprej preverimo, ce je m1 kompatibilna z operacijo: */
  if (m1==NULL)
    return NULL;
  else if (m1->d1<1 || m1->d2<1 || m1->d1!=m1->d2)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    if (ind!=NULL)
    {
      if (*ind!=NULL) /* Preverijo se dimenzije *ind */
        if ((*ind)->r<m1->d1 || (*ind)->r-(*ind)->ex>m1->d1)
          dispindtab(ind);
      if (*ind==NULL) /* Po potrebi se *ind alocira na novo */
        *ind=newindtab(0,m1->d1);
      (*ind)->n=m1->d1;
      indint=*ind; /* V operaciji bomo uporabljali indint, ki je NULL, ce je ind=NULL. */
    }
    if (LUdecomptolplain(m1,m,m,indint,parity,smalltol))
    {
      dispmatrix(&m);
      dispindtab(ind);
    }
    return m;
  }
}
}




            /************************/
            /*                      */
            /*   QR DECOMPOSITION   */
            /*                      */
            /************************/

int QRdecompplaincomp(matrix m1,matrix qr,vector diag);
int QRdecompplain(matrix m1,matrix mq,matrix mr);





            /*****************************************/
            /*                                       */
            /*   GRAMM-SCHMIDT's ORTHOGONALIZATION   */
            /*                                       */
            /*****************************************/


void GSortplain(matrix v,matrix q,matrix a)
    /* Gramm-Schmidtova ortogonalizacija. Stolpci matrike v so originalni
    vektorji, v matriko q se zapisejo ortogonalni vektorji dobljeni iz teh,
    v matriko a pa (desni) koeficienti, tako da je q=v*a. q postane ortogonalna
    matrika, a pa zgornjetrikotna z enkami na glavni diagonali.
      Dimenzije so naslednje: v n*m, q n*m, a m*m, kjer je n dimenzija
    vektorskega prostora, m pa stevilo vektorjev. Stolpci matrike a so
    vektorji q izrazeni kot linearne kombinacije vektorjev v.
      Matrika a je lahko NULL, v tem primeru se ne izracunajo koeficienti
    linearnih kombinacij.
      POZOR:
    Matriki q in a ne smeta biti isti kot v.
    $A Igor jul00; */
{
int i,j,k,l,m,n;
double x;
vector qnorms=NULL;
n=v->d1;  /* dimenzija prostora */
m=v->d2;  /* stevilo vektorjev */
identmat0(m,&a);
qnorms=getvector(m);
qnorms->v[1]=0;
/* 1. ortogon. vektor je enak 1. vektorju: */
for (i=1;i<=n;++i)
{
  q->m[i][1]=(x=v->m[i][1]);
  qnorms->v[1]+=x*x;
}
for (j=2;j<=m;++j)  /* tu j vedno tece po vektorjih, i pa po komponentah */
{
  for (i=1;i<=n;++i)
    q->m[i][j]=v->m[i][j];
  for (l=1;l<j;++l)
  {
    x=0;
    for (i=1;i<=n;++i)
      x+=v->m[i][j]*q->m[i][l]; /* Skal. prod. j. vekt. v in l. q */
    x/=qnorms->v[l];
    for (i=1;i<=n;++i)
      q->m[i][j]-=x*q->m[i][l];
    if (a!=NULL)  /* popravek koeficientov a */
      for (k=1;k<=l;++k)
      {
        a->m[k][j]-=x*a->m[k][l];
      }
  }
  if (j<m)
  {
    qnorms->v[j]=0;
    for (i=1;i<=n;++i)  /* Izracun kvadrata norme j. normalnega vektorja */
    {
      x=q->m[i][j];
      qnorms->v[j]+=x*x;
    }
  }
}
dispvector(&qnorms);
}


void GSortnormplain(matrix v,matrix q,matrix a)
    /* Gramm-Schmidtova ortogonalizacija z normiranjem. Stolpci matrike v so
    originalni vektorji, v matriko q se zapisejo ortonormirani vektorji
    dobljeni iz teh, v matriko a pa (desni) koeficienti, tako da je q=v*a.
    q postane ortonormalna atrika, a pa zgornjetrikotna z enkami na glavni
    diagonali.
      Dimenzije so naslednje: v n*m, q n*m, a m*m, kjer je n dimenzija
    vektorskega prostora, m pa stevilo vektorjev. Stolpci matrike a postanejo
    vektorji q izrazeni kot linearne kombinacije vektorjev v.
      Matrika a je lahko NULL, v tem primeru se ne izracunajo koeficienti
    linearnih kombinacij.
    $A Igor jul00; */
{
int i,j,k,l,m,n;
double x;
double norm;
n=v->d1;  /* dimenzija prostora */
m=v->d2;  /* stevilo vektorjev */
identmat0(m,&a);
norm=0;
/* 1. ortogon. vektor je enak 1. vektorju: */
for (i=1;i<=n;++i)
{
  q->m[i][1]=(x=v->m[i][1]);
  norm+=x*x;
}
norm=sqrt(norm);
for (i=1;i<=n;++i)
{
  q->m[i][1]/=norm;
}
if (a!=NULL)
  a->m[1][1]/=norm;
for (j=2;j<=m;++j)  /* tu j vedno tece po vektorjih, i pa po komponentah */
{
  for (i=1;i<=n;++i)
    q->m[i][j]=v->m[i][j];
  for (l=1;l<j;++l)
  {
    x=0;
    for (i=1;i<=n;++i)
      x+=v->m[i][j]*q->m[i][l]; /* Skal. prod. j. vekt. v in l. q */
    for (i=1;i<=n;++i)
      q->m[i][j]-=x*q->m[i][l];
    if (a!=NULL)  /* popravek koeficientov a */
      for (k=1;k<=l;++k)
      {
        a->m[k][j]-=x*a->m[k][l];
      }
  }
  norm=0;
  for (i=1;i<=n;++i)  /* izracun kvadrata norme j. normalnega vektorja */
  {
    x=q->m[i][j];
    norm+=x*x;
  }
  norm=sqrt(norm);
  for (i=1;i<=n;++i)  /* normiranje j. normalnega vektorja */
    q->m[i][j]/=norm;
  if (a!=NULL)
    for (k=1;k<=j;++k)
      a->m[k][j]/=norm;
}
}



void GSort0(matrix v,matrix *q,matrix *a)
    /* Gramm-Schmidtova ortogonalizacija. V matriko *q zapise po stolpcih
    ortogonalne vektorje dobljene iz stolpcev matrike v, v matriko *a pa
    ortogonalne vektorje kot linearne kombinacije stolpcev v (tudi po
    stolpcih). Ce je matrika v dimenzije n*m (m<=n), je *q dimenzije n*m in
    *a dimenzije m*m (m je stevilo vektorjev (stolpcev) v v, n pa je dimenzija
    vektorskega prostora).
     Ali q ali a je lahko NULL (ce je a NULL, se ustrezna matrika en izracuna,
    medtem ko se ort. vektorji v *q vedno izracunajo). a ali q je lahko tudi
    naslov v, v tem primeru se alocira nov prostor , originalni v pa zbrise po
    operaciji.
    $A Igor jul00; */
{
matrix Q=NULL,A=NULL,*saveq=NULL,*savea=NULL;
if (v==NULL)
{
  dispmatrix(q); dispmatrix(a);
} else if ((q==NULL && a==NULL) || v->d2<1 || v->d1<v->d2)
{
  dispmatrix(q); dispmatrix(a);
} else
{
  if (a==q)  /* a in q ne moreta zasedati istega prostora */
    a=NULL;
  if (q!=NULL)
  {
    /* Rezultat spravimo v *q: */
    /* Koda, ki preprecuje, da bi prislo do napacnih rezultatov, ce q kaze na
    v: */
    if (*q==v)
    {
      saveq=q;
      q=&Q;
    }
    /* Preverimo dimenzijo *q; ce ni ustrezna, zbrisemo matriko: */
    if (*q!=NULL)
      if ((*q)->d1!=v->d1 || (*q)->d2!=v->d2)
        dispmatrix(q);
    if (*q==NULL)
      *q=getmatrix(v->d1,v->d2);
    if (a==NULL)
      GSortplain(v,*q,NULL);
    else
    {
      /* V rezultatih se zahteva tudi matrika a: */
      /* Koda, ki preprecuje, da bi prislo do napacnih rezultatov, ce a kaze na
      v: */
      if (*a==v)
      {
        savea=a;
        a=&A;
      }
      /* Preverimo dimenzijo *a; ce ni ustrezna, zbrisemo matriko: */
      if (*a!=NULL)
        if ((*a)->d1!=v->d2 || (*a)->d2!=v->d2)
          dispmatrix(a);
      if (*a==NULL)
        *a=getmatrix(v->d2,v->d2);
      GSortplain(v,*q,*a);   /* Izvedba operacije */
      if (savea!=NULL) /* ce je *a==v */
      {
        dispmatrix(savea);
        *savea=*a;
      }
    }  /* a!=NULL) */
    if (saveq!=NULL) /* ce je *q==v */
    {
      dispmatrix(saveq);
      *saveq=*q;
    }
  } else  /* od q!=NULL */
  {
    /* q=NULL, funkcija naj vrne le koeficiente lin. komb. v *a. Vseeno moramo
    zacasno tvoriti matriko q, ker jo rabimo za izvedbo operacije: */
    Q=getmatrix(v->d1,v->d2);
    /* a!=NULL zaradi prej preverjenih pogojev. Spodnja koda preprecuje, da bi
    prislo do napacnih rezultatov, ce a kaze na v: */
    if (*a==v)
    {
      savea=a;
      a=&A;
    }
    /* Preverimo dimenzijo *a; ce ni ustrezna, zbrisemo matriko: */
    if (*a!=NULL)
      if ((*a)->d1!=v->d2 || (*a)->d2!=v->d2)
        dispmatrix(a);
    if (*a==NULL)
      *a=getmatrix(v->d2,v->d2);
    GSortplain(v,Q,*a);   /* Izvedba operacije */
    if (savea!=NULL) /* ce je *a==v */
    {
      dispmatrix(savea);
      *savea=*a;
    }
    dispmatrix(&Q);
  }
}
}



void GSortnorm0(matrix v,matrix *q,matrix *a)
    /* Gramm-Schmidtova ortogonalizacija z normalizacijo. V matriko *q zapise
    po stolpcih ortogonalne in normirane  vektorje dobljene iz stolpcev matrike
    v, v matriko *a pa ortogonalne vektorje kot linearne kombinacije stolpcev v
    (tudi po stolpcih). Ce je matrika v dimenzije n*m (m<=n), je *q dimenzije
    n*m in *a dimenzije m*m (m je stevilo vektorjev (stolpcev) v v, n pa je
    dimenzija vektorskega prostora).
     Ali q ali a je lahko NULL (ce je a NULL, se ustrezna matrika en izracuna,
    medtem ko se ort. vektorji v *q vedno izracunajo). a ali q je lahko tudi
    naslov v, v tem primeru se alocira nov prostor , originalni v pa zbrise po
    operaciji.
    $A Igor jul00; */
{
matrix Q=NULL,A=NULL,*saveq=NULL,*savea=NULL;
if (v==NULL)
{
  dispmatrix(q); dispmatrix(a);
} else if ((q==NULL && a==NULL) || v->d2<1 || v->d1<v->d2)
{
  dispmatrix(q); dispmatrix(a);
} else
{
  if (a==q)  /* a in q ne moreta zasedati istega prostora */
    a=NULL;
  if (q!=NULL)
  {
    /* Rezultat spravimo v *q: */
    /* Koda, ki preprecuje, da bi prislo do napacnih rezultatov, ce q kaze na
    v: */
    if (*q==v)
    {
      saveq=q;
      q=&Q;
    }
    /* Preverimo dimenzijo *q; ce ni ustrezna, zbrisemo matriko: */
    if (*q!=NULL)
      if ((*q)->d1!=v->d1 || (*q)->d2!=v->d2)
        dispmatrix(q);
    if (*q==NULL)
      *q=getmatrix(v->d1,v->d2);
    if (a==NULL)
      GSortnormplain(v,*q,NULL);
    else
    {
      /* V rezultatih se zahteva tudi matrika a: */
      /* Koda, ki preprecuje, da bi prislo do napacnih rezultatov, ce a kaze na
      v: */
      if (*a==v)
      {
        savea=a;
        a=&A;
      }
      /* Preverimo dimenzijo *a; ce ni ustrezna, zbrisemo matriko: */
      if (*a!=NULL)
        if ((*a)->d1!=v->d2 || (*a)->d2!=v->d2)
          dispmatrix(a);
      if (*a==NULL)
        *a=getmatrix(v->d2,v->d2);
      GSortnormplain(v,*q,*a);   /* Izvedba operacije */
      if (savea!=NULL) /* ce je *a==v */
      {
        dispmatrix(savea);
        *savea=*a;
      }
    }  /* a!=NULL) */
    if (saveq!=NULL) /* ce je *q==v */
    {
      dispmatrix(saveq);
      *saveq=*q;
    }
  } else  /* od q!=NULL */
  {
    /* q=NULL, funkcija naj vrne le koeficiente lin. komb. v *a. Vseeno moramo
    zacasno tvoriti matriko q, ker jo rabimo za izvedbo operacije: */
    Q=getmatrix(v->d1,v->d2);
    /* a!=NULL zaradi prej preverjenih pogojev. Spodnja koda preprecuje, da bi
    prislo do napacnih rezultatov, ce a kaze na v: */
    if (*a==v)
    {
      savea=a;
      a=&A;
    }
    /* Preverimo dimenzijo *a; ce ni ustrezna, zbrisemo matriko: */
    if (*a!=NULL)
      if ((*a)->d1!=v->d2 || (*a)->d2!=v->d2)
        dispmatrix(a);
    if (*a==NULL)
      *a=getmatrix(v->d2,v->d2);
    GSortnormplain(v,Q,*a);   /* Izvedba operacije */
    if (savea!=NULL) /* ce je *a==v */
    {
      dispmatrix(savea);
      *savea=*a;
    }
    dispmatrix(&Q);
  }
}
}




            /****************************/
            /*                          */
            /*   SYSTEMS OF EQUATIONS   */
            /*                          */
            /****************************/



    /* SOLUTION OF SYSTEMS WITH THE LDLT DECOMPOSITION: */


void solvLDLTplain(matrix L,matrix D,vector b,vector x)
    /* Solves the system of equations L D LT x = b, where L is a lower
    triangular matrix with diagonal elemnts 1, D is a diagonal matrix, and
    stores the result in x. Arguments must be allocated and of consistent
    dimensions since this is not checked.
      L and D can point to the same matrix since the function does not operate
    on diagonal elements of L (it just assumes these are 1).
      b and x can also point to the same vector.
    $A Igor nov03; */
{
int i,k,dim;
/* Remark: The order of solution is L y = b, D z = y, LT x = z */
dim=x->d;
/* Solve L y = b: */
x->v[1]=b->v[1];
for (i=2;i<=dim;++i)
{
  x->v[i]=b->v[i];
  for (k=1;k<i;++k)
    x->v[i]-=L->m[i][k]*x->v[k];
}
/* Solve D z = =y */
for (i=1;i<=dim;++i)
  x->v[i]/=D->m[i][i];
/* Solve LT x = z: */
for (i=dim-1;i>0;--i)
  for (k=i+1;k<=dim;++k)
    x->v[i]-=L->m[k][i]*x->v[k];   /* coef. of LT obtained from L (sym.) */
}


void solvLLTplain(matrix L,vector b,vector x)
    /* Solves the system of equations L LT x = b, where L is a lower
    triangular matrix, and stores the result in x. Arguments must be allocated
    and of consistent dimensions since this is not checked.
      b and x can point to the same vector.
      The function is usually used for back-substitution after the choleski
    (LLT) decomposition for positive definite matrices. A system of equations
    with a symmetric matrix A can be converted to a system with a positive
    definite matrix by multiplying the matrix ant the right-hand side vector
    by AT: A x = b => (AT A) x = (AT b). This is however not feasible because
    preparation of the system takes much more time than the solution, and it
    is much better to perform the LDLT deocmposition.
    $A Igor nov03; */
{
int i,k,dim;
/* Remark: The order of solution is L y = b, LT x = y */
dim=x->d;
/* Solve L y = b: */
x->v[1]=b->v[1]/L->m[1][1];
for (i=2;i<=dim;++i)
{
  x->v[i]=b->v[i];
  for (k=1;k<i;++k)
    x->v[i]-=L->m[i][k]*x->v[k];
  x->v[i]/=L->m[i][i];
}
/* Solve LT x = y: */
x->v[dim]/=L->m[dim][dim];
for (i=dim-1;i>0;--i)
{
  for (k=i+1;k<=dim;++k)
    x->v[i]-=L->m[k][i]*x->v[k];   /* coef. of LT obtained from L (sym.) */
  x->v[i]/=L->m[i][i];
}
}


    /* SOLUTION OF TRIANGULAR SYSTEMS AND BY LU DECOMPOSITION: */


void solvlowerplain(matrix ml,vector b,vector x)
    /* Solves the system ml*x=b, where ml is a lower triangular matrix with
    arbitrary elements on the diagonal. 
      Arguments may not be NULL and must be of consistent dimensions.
      Vector b and x can be the same.
    $A Igor dec03; */
{
int i,j;
double s;
for (i=1;i<=ml->d1;++i)
{
  s=b->v[i];
  for (j=1;j<=i-1;++j)
    s-=ml->m[i][j]*x->v[j];
  x->v[i]=s/ml->m[i][i];
}

}


void solvupperplain(matrix mu,vector b,vector x)
    /* Solves the system mu*x=b, where mu is a lower triangular matrix with
    arbitrary elements on the diagonal.
      mu can be non-square, we then solve mu(mxn)*x(n)=b(m) (overdetermined
    system where elements of mu are 0 below the n-th line, and the block of
    first n lines is upper triangular). This is used sometimes for the least
    square solutions. 
      Arguments may not be NULL and must be of consistent dimensions.
      Vectors b and x can be the same.
    $A Igor dec03; */
{
int i,j;
double s;
for (i=mu->d2;i>=1;--i)
{
  s=b->v[i];
  for (j=i+1;j<=mu->d2;++j)
    s-=mu->m[i][j]*x->v[j];
  x->v[i]=s/mu->m[i][i];
}
}



vector solvlower0(matrix ml1,vector b2,vector *x3)
    /* Returns the solution of the LOWER TRIANGULAR system ml*x==b2. If
    x3!=NULL then the solution is stored to *x3 and returned. All neccessary
    allocations are performed. If the dimensions of ml and b2 are not
    compatible then NULL is returned. It does not check for zero diagonal
    elements.
    $A Igor avg00; */
{
vector v=NULL;
if (x3!=NULL)
{
  /* When x3!=NULL, the result will be stored in *x3; check whether ml and b2
  are compatible for the operation: */
  if (ml1==NULL || b2==NULL)
    dispvector(x3);
  else if (ml1->d1!=b2->d || ml1->d2!=b2->d || b2->d<1)
    dispvector(x3);
  else
  {
    /* If necessary, resize *x3: */
    if (x3==NULL)
      resizevector(x3,b2->d);
    else if ((*x3)->d!=b2->d)
      resizevector(x3,b2->d);
    /* Izvedba operacije: */
    solvlowerplain(ml1,b2,*x3);
  }
  return *x3;
} else   /* x3==NULL */
{
  /* Check compatibility: */
  if (ml1==NULL || b2==NULL)
    return NULL;
  else if (ml1->d1!=b2->d || ml1->d2!=b2->d || b2->d<1)
    return NULL;
  else
  {
    v=getvector(b2->d);
    solvlowerplain(ml1,b2,v);
    return v;
  }
}
}


vector solvupper0(matrix mu1,vector b2,vector *x3)
    /* Returns the solution of the UPPER TRIANGULAR system ml*x==b2. If
    x3!=NULL then the solution is stored to *x3 and returned. All neccessary
    allocations are performed. If the dimensions of ml and b2 are not
    compatible then NULL is returned. It does not check for zero diagonal
    elements.
    $A Igor avg00; */
{
vector v=NULL;
if (x3!=NULL)
{
  /* When x3!=NULL, the result will be stored in *x3; check whether ml and b2
  are compatible for the operation: */
  if (mu1==NULL || b2==NULL)
    dispvector(x3);
  else if (mu1->d1!=b2->d || mu1->d2!=b2->d || b2->d<1)
    dispvector(x3);
  else
  {
    /* If necessary, resize *x3: */
    if (x3==NULL)
      resizevector(x3,b2->d);
    else if ((*x3)->d!=b2->d)
      resizevector(x3,b2->d);
    /* Izvedba operacije: */
    solvlowerplain(mu1,b2,*x3);
  }
  return *x3;
} else   /* x3==NULL */
{
  /* Check compatibility: */
  if (mu1==NULL || b2==NULL)
    return NULL;
  else if (mu1->d1!=b2->d || mu1->d2!=b2->d || b2->d<1)
    return NULL;
  else
  {
    v=getvector(b2->d);
    solvlowerplain(mu1,b2,v);
    return v;
  }
}
}




void solvLUplain(matrix ml,matrix mu,indtab it,vector b,vector x)
    /* Resi sistem (ml*mu)x=b, kjer vsebujeta matriki ml in mu LU dekompozicijo
    matrike sistema, in resitev zapise v vektor x, ki je lahko tudi
    isti vektor kot vektor desnih strani b. L mora biti spodnjetrikotna z
    enicami na diagonali, U pa zgornjetrikotna matrika, dobljena z LU
    dekompozicijo, it pa je permutacijska tabela, v kateri so spravljene
    zamenjave vrstic. ml in mu sta lahko shranjeni tudi v isti matriki, ker se
    avtomaticno privzameta trikotnost obeh matrik in enice na diagonali pri ml.
     it je lahko tudi NULL, v tem primeru se privzame, da pri dekompoziciji ni
    bilo zamenjav vrstic. to se NIKOLI NE UPORABLJA, ker so v splosnem
    zamenjave vrstic nujne.
    $A Igor avg00; */
{
int i,j,firsnonzero=0,n;
double s;
n=b->d;
/* Ce se mora vektor b ohraniti (t.j. ce b ni isti vektor kot x), se najprej
b prepise v x: */
if (b!=x)
  for (i=1;i<=n;++i)
    x->v[i]=b->v[i];
/* 1. stopnja je resevanje sistema Ly=b (forward substitution), y se shrane v
x, kjer je ze kopija b: */
if (it==NULL) /* ce ni bilo zamenjav vrstic */
  for (i=1;i<=n;++i) /* treba je razvozlati zamenjave vrstic */
  {
    /* Ni zamenjave vrstic vektorju b */
    s=x->v[i];
    if (firsnonzero)
      for (j=firsnonzero;j<=i-1;++j)
        s-=ml->m[i][j]*x->v[j];
    else if (s)
      firsnonzero=i;
    x->v[i]=s; /* Ker so diagonalni elementi od ml enaki 1, ni deljenja */
  }
else
  for (i=1;i<=n;++i) /* treba je razvozlati zamenjave vrstic */
  {
    /* Zamenjava vrstic v vektorju b */
    s=x->v[it->t[i]];
    x->v[it->t[i]]=x->v[i];
    if (firsnonzero)
      for (j=firsnonzero;j<=i-1;++j)
        s-=ml->m[i][j]*x->v[j];
    else if (s)
      firsnonzero=i;
    x->v[i]=s; /* Ker so diagonalni elementi od ml enaki 1, ni deljenja */
  }
/* Resevanje sistema Ux=y (backsubstitution), y je shranjen v x: */
for (i=n;i>=1;--i)
{
  s=x->v[i];
  for (j=i+1;j<=n;++j)
    s-=mu->m[i][j]*x->v[j];
  x->v[i]=s/mu->m[i][i];
}
}




vector solvLU0(matrix ml,matrix mu,indtab it,vector b2,vector *x3)
    /* Vrne resitev sistema enacb (ml*mu)*x3=b2, kjer sta ml in mu matriki
    dobljeni z LU dekompozicijo matrike sistema, b2 pa vektor desnih strani.
    it je indeksna tabela, v kateri so zabelezene izvedene zamenjave vrstic
    pri dekompoziciji. Lahko je NULL, ce smo dekompozicijo na siloizvedli
    tako, da ni bilo zamenjav, vendar se to v praksi NE SME narediti, ker
    lahko na ta nacin dekompozicija spodleti tudi pri nesingularnih matrikah.
    Ce je x3 razlicen od NULL, zapise rezultat v *x3 in vrne *x3. x3 je lahko
    tudi naslov b2, funkcija v tem primeru poskrbi za to, da se najprej
    izracuna rezultat operacije in sele nato prepise operand. ml in mu sta
    lahko shranjeni v isti matriki, ker se avtomatsko privzame, da ima ml enice
    na diagonali. Ce je ml ali mu NULL, se vzame, da sta ml in mu shranjeni v
    isti matriki in se za obe uporabi tista, ki je razlicna od NULL.
     OPOMBA:
     Ce je x3 razlicen od NULL, se po navadi vektor, ki ga funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze x3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */
{
vector v=NULL;
/* Ce je ml ali mu enak NULL, se privzame, da sta oba faktorja shranjena v isti
matriki: */
if (ml==NULL)
  ml=mu;
else if (mu==NULL)
  mu=ml;
if (x3!=NULL)
{
  /* Ce je x3!=NULL, se rezultat shrane v *x3. Najprej preverimo, ce so ml, mu,
  it in b2 kompatibilni z operacijo: */
  if (ml==NULL || mu==NULL || b2==NULL)
    dispvector(x3);
  else if (ml->d1!=b2->d || ml->d2!=b2->d ||
   mu->d1!=b2->d || mu->d2!=b2->d || b2->d<1)
    dispvector(x3);
  else
  {
    /* Preverimo dimenzijo *x3, ce ni ustrezna, zbrisemo *x3: */
    if (*x3!=NULL)
      if ((*x3)->d!=b2->d)
        dispvector(x3);
    /* Ce je *x3==NULL, tvorimo *x3 z dimenzijama ml: */
    if (*x3==NULL)
      *x3=getvector(b2->d);
    /* Izvedba operacije, preveri se se, ce ima it pravilne dimenzije: */
    if (it==NULL)
      solvLUplain(ml,mu,it,b2,*x3);
    else if (it->n==b2->d)
      solvLUplain(ml,mu,it,b2,*x3);
    else
      dispvector(x3);
  }
  return *x3; /* Ker je bil x3!=NULL, se vrne *x3. */
} else   /* x3=NULL */
{
  /* x3==NULL, naredi se nova vektor, v katerega se zapise rezultat operacije,
  vrne se njegov kazalec: */
  /* Najprej preverimo, ce sta ml in b2 kompatibilni za operacijo: */
  if (ml==NULL || mu==NULL || b2==NULL)
    return NULL;
  else if (ml->d1!=b2->d || ml->d2!=b2->d ||
   mu->d1!=b2->d || mu->d2!=b2->d || b2->d<1)
    return NULL;
  else
  {
    /* Izvedba operacije, preveri se se, ce ima it pravilne dimenzije: */
    if (it==NULL)
    {
      v=getvector(b2->d);
      solvLUplain(ml,mu,it,b2,v);
    } else if (it->n==b2->d)
    {
      v=getvector(b2->d);
      solvLUplain(ml,mu,it,b2,v);
    }
    return v;
  }
}
}


void solvLUmatplain(matrix ml,matrix mu,indtab it,matrix b,matrix mx)
    /* Resi sistem (ml*mu)x=b, kjer vsebujeta matriki ml in mu LU dekompozicijo
    matrike sistema, in resitev zapise v vektor mx, ki je lahko tudi
    isti vektor kot vektor desnih strani b. L mora biti spodnjetrikotna z
    enicami na diagonali, U pa zgornjetrikotna matrika, dobljena z LU
    dekompozicijo, it pa je permutacijska tabela, v kateri so spravljene
    zamenjave vrstic. ml in mu sta lahko shranjeni tudi v isti matriki, ker se
    avtomaticno privzameta trikotnost obeh matrik in enice na diagonali pri ml.
     it je lahko tudi NULL, v tem primeru se privzame, da pri dekompoziciji ni
    bilo zamenjav vrstic. to se NIKOLI NE UPORABLJA, ker so v splosnem
    zamenjave vrstic nujne.
    $A Igor avg00; */
{
int i,j,k,firsnonzero,n,m;
double s;
n=b->d1;
m=b->d2;
/* Ce se mora matrika b ohraniti (t.j. ce b ni ista matrika kot mx), se najprej
b prepise v mx: */
if (b!=mx)
  for (i=1;i<=n;++i)
    for (k=1;k<=m;++k)
      mx->m[i][k]=b->m[i][k];
for (k=1;k<=m;++k) /* Iteracija po stolpcih desnih strani */
{
  firsnonzero=0;
  /* 1. stopnja je resevanje sistema Ly=b (forward substitution), y se shrane v
  mx, kjer je ze kopija b: */
  if (it==NULL) /* ce ni bilo zamenjav vrstic */
    for (i=1;i<=n;++i) /* treba je razvozlati zamenjave vrstic */
    {
      /* Zamenjava vrstic v vektorju b */
      s=mx->m[i][k];
      if (firsnonzero)
        for (j=firsnonzero;j<=i-1;++j)
          s-=ml->m[i][j]*mx->m[j][k];
      else if (s)
        firsnonzero=i;
      mx->m[i][k]=s; /* Ker so diagonalni elementi ml enaki 1, ni deljenja */
    }
  else
    for (i=1;i<=n;++i) /* treba je razvozlati zamenjave vrstic */
    {
      /* Zamenjava vrstic v vektorju b */
      s=mx->m[it->t[i]][k];
      mx->m[it->t[i]][k]=mx->m[i][k];
      if (firsnonzero)
        for (j=firsnonzero;j<=i-1;++j)
          s-=ml->m[i][j]*mx->m[j][k];
      else if (s)
        firsnonzero=i;
      mx->m[i][k]=s; /* Ker so diagonalni elementi od ml enaki 1, ni deljenja */
    }
  /* Resevanje sistema Ux=y (backsubstitution), y je shranjen v mx: */
  for (i=n;i>=1;--i)
  {
    s=mx->m[i][k];
    for (j=i+1;j<=n;++j)
      s-=mu->m[i][j]*mx->m[j][k];
    mx->m[i][k]=s/mu->m[i][i];
  }
}
}




    /* SOLUTION OF SYSTEMS OF ORTHOGONAL EQUATIONS: */


void solvortplain(matrix q,vector b,vector x)
    /* Resi sistem enacb q*x=b, kjer je q ortogonalna matrika (stolpci matrike
    so ortogonalni), b pa vektor desnih strani. Resitev se zapise v vektor x.
    Funkcija ne kontrolira dimenzij.
    x ne sme biti isti vektor kot b.
    $A Igor jul00; */
{
int i,k,n;
double qnorm,scalprod;
n=q->d1;
for (i=1;i<=n;++i) /* iteracija po stolpcih q oz. vrsticah x */
{
  /* Norma i. stolpca q: */
  qnorm=0;
  for (k=1;k<=n;++k)
  {
    scalprod=q->m[k][i]; /* pomozna sprem. */
    qnorm+=scalprod*scalprod;
  }
    scalprod=0;
    for (k=1;k<=n;++k)
      scalprod+=q->m[k][i]*b->v[k];
    x->v[i]=scalprod/qnorm;
}
}


void solvortmatplain(matrix q,matrix b,matrix x)
    /* Resi sistem enacb q*x=b, kjer je q ortogonalna matrika (stolpci matrike
    so ortogonalni), stolpci b pa so vektorji desnih strani. Resitev se zapise
    po stolpcih v matriko x. Funkcija ne kontrolira dimenzij.
    x ne sme biti ista matrika kot b.
    $A Igor jul00; */
{
int i,j,k,n,m;
double qnorm,scalprod;
n=q->d1;
m=x->d2;
for (i=1;i<=n;++i) /* iteracija po stolpcih q oz. vrsticah x */
{
  /* Norma i. stolpca q: */
  qnorm=0;
  for (j=1;j<=n;++j)
  {
    scalprod=q->m[j][i]; /* pomozna sprem. */
    qnorm+=scalprod*scalprod;
  }
  for (j=1;j<=m;++j) /* iteracija po stolpcih x in b */
  {
    scalprod=0;
    for (k=1;k<=n;++k)
      scalprod+=q->m[k][i]*b->m[k][j];
    x->m[i][j]=scalprod/qnorm;
  }
}
}



void solvortnormplain(matrix q,vector b,vector x)
    /* Resi sistem enacb q*x=b, kjer je q ortonormalna matrika (stolpci matrike
    so paroma ortogonalni in normirani), b pa vektor desnih strani. Resitev se
    zapise v vektor x. Funkcija ne kontrolira dimenzij.
    x ne sme biti isti vektor kot b.
    $A Igor jul00; */
{
int i,k,n;
double scalprod;
n=q->d1;
for (i=1;i<=n;++i) /* iteracija po stolpcih q oz. vrsticah x */
{
  scalprod=0;
  for (k=1;k<=n;++k)
    scalprod+=q->m[k][i]*b->v[k];
  x->v[i]=scalprod;
}
}



void solvortnormmatplain(matrix q,matrix b,matrix x)
    /* Resi sistem enacb q*x=b, kjer je q ortonormalna matrika (stolpci matrike
    so ortogonalni in normirani), stolpci b pa so vektorji desnih strani.
    Resitev se zapise po stolpcih v matriko x. Funkcija ne kontrolira dimenzij.
    x ne sme biti ista matrika kot b.
    $A Igor jul00; */
{
int i,j,k,n,m;
double scalprod;
n=q->d1;
m=x->d2;
for (i=1;i<=n;++i) /* iteracija po stolpcih q oz. vrsticah x */
  for (j=1;j<=m;++j) /* iteracija po stolpcih x in b */
  {
    scalprod=0;
    for (k=1;k<=n;++k)
      scalprod+=q->m[k][i]*b->m[k][j];
    x->m[i][j]=scalprod;
  }
}




vector solvort0(matrix q1,vector b2,vector *x3)
    /* Vrne resitev sistema enacb q1*x3=b2, kjer je q1 ortogonalna matrika,
    t.j. matrika s paroma ortogonalnimi stolpci. Ce je x3 razlicen od NULL,
    zapise rezultat v *x3 in vrne *x3. x3 je lahko tudi naslov b2, funkcija
    v tem primeru poskrbi za to, da se najprej izracuna rezultat operacije
    in sele nato prepise operand.
     OPOMBA:
     Ce je x3 razlicen od NULL, se po navadi vektor, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze x3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */
{
vector v=NULL,*save=NULL;
if (x3!=NULL)
{
  if (*x3==b2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce x3 kaze na
    b2: */
    save=x3;
    x3=&v;
  }
  /* Ce je x3!=NULL, se rezultat shrane v *x3. Najprej preverimo, ce sta q1
  in b2 kompatibilni z operacijo: */
  if (q1==NULL || b2==NULL)
    dispvector(x3);
  else if (q1->d1!=b2->d || q1->d2!=b2->d || b2->d<1)
    dispvector(x3);
  else
  {
    /* Preverimo dimenzijo *x3, ce ni ustrezna, zbrisemo *x3: */
    if (*x3!=NULL)
      if ((*x3)->d!=b2->d)
        dispvector(x3);
    /* Ce je *x3==NULL, tvorimo *x3 z dimenzijama q1: */
    if (*x3==NULL)
      *x3=getvector(b2->d);
    /* Izvedba operacije: */
    solvortplain(q1,b2,*x3);
  }
  if (save!=NULL)
  {
    dispvector(save);
    *save=*x3;
  }
  return *x3; /* Ker je bil x3!=NULL, se vrne *x3. */
} else   /* x3=NULL */
{
  /* x3==NULL, naredi se nova vektor, v katerega se zapise rezultat operacije,
  vrne se njegov kazalec: */
  /* Najprej preverimo, ce sta q1 in b2 kompatibilni za operacijo: */
  if (q1==NULL || b2==NULL)
    return NULL;
  else if (q1->d1!=b2->d || q1->d2!=b2->d || b2->d<1)
    return NULL;
  else
  {
    v=getvector(b2->d);
    /* Izvedba operacije: */
    solvortplain(q1,b2,v);
    return v;
  }
}
}



matrix solvortmat0(matrix q1,matrix b2,matrix *x3)
    /* Vrne resitve sistemov enacb q1*x3=b2, kjer je q1 ortogonalna matrika,
    t.j. matrika s paroma ortogonalnimi stolpci. Ce je x3 razlicen od NULL,
    zapise rezultat v *x3 in vrne *x3. x3 je lahko tudi naslov q1 ali b2,
    funkcija v tem primeru poskrbi za to, da se najprej izracuna rezultat
    operacije in sele nato prepise operand.
     OPOMBA:
     Ce je x3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze x3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor avg00; */
{
matrix m=NULL,*save=NULL;
if (x3!=NULL)
{
  if (*x3==q1 || *x3==b2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce x3 kaze na
    q1 ali b2: */
    save=x3;
    x3=&m;
  }
  /* Ce je x3!=NULL, se rezultat shrane v *x3. Najprej preverimo, ce sta q1
  in b2 kompatibilni z operacijo: */
  if (q1==NULL || b2==NULL)
    dispmatrix(x3);
  else if (q1->d1!=b2->d1 || q1->d2!=b2->d1 || b2->d1<1 || b2->d2<1)
    dispmatrix(x3);
  else
  {
    /* Preverimo dimenzijo *x3, ce ni ustrezna, zbrisemo *x3: */
    if (*x3!=NULL)
      if ((*x3)->d1!=b2->d1 || (*x3)->d2!=b2->d2)
        dispmatrix(x3);
    /* Ce je *x3==NULL, tvorimo *x3 z dimenzijama q1: */
    if (*x3==NULL)
      *x3=getmatrix(b2->d1,b2->d2);
    /* Izvedba operacije: */
    solvortmatplain(q1,b2,*x3);
  }
  if (save!=NULL)
  {
    dispmatrix(save);
    *save=*x3;
  }
  return *x3; /* Ker je bil x3!=NULL, se vrne *x3. */
} else   /* x3=NULL */
{
  /* x3==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce sta q1 in b2 kompatibilni za operacijo: */
  if (q1==NULL || b2==NULL)
    return NULL;
  else if (q1->d1!=b2->d1 || q1->d2!=b2->d1 || b2->d1<1 || b2->d2<1)
    return NULL;
  else
  {
    m=getmatrix(b2->d1,b2->d2);
    /* Izvedba operacije: */
    solvortmatplain(q1,b2,m);
    return m;
  }
}
}



vector solvortnorm0(matrix q1,vector b2,vector *x3)
    /* Vrne resitev sistema enacb q1*x3=b2, kjer je q1 ortogonalna matrika,
    t.j. matrika s paroma ortogonalnimi stolpci. Ce je x3 razlicen od NULL,
    zapise rezultat v *x3 in vrne *x3. x3 je lahko tudi naslov b2, funkcija
    v tem primeru poskrbi za to, da se najprej izracuna rezultat operacije
    in sele nato prepise operand.
     OPOMBA:
     Ce je x3 razlicen od NULL, se po navadi vektor, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi vektorju, na katerega kaze x3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isti vektor).
    $A Igor avg00; */
{
vector v=NULL,*save=NULL;
if (x3!=NULL)
{
  if (*x3==b2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce x3 kaze na
    b2: */
    save=x3;
    x3=&v;
  }
  /* Ce je x3!=NULL, se rezultat shrane v *x3. Najprej preverimo, ce sta q1
  in b2 kompatibilni z operacijo: */
  if (q1==NULL || b2==NULL)
    dispvector(x3);
  else if (q1->d1!=b2->d || q1->d2!=b2->d || b2->d<1)
    dispvector(x3);
  else
  {
    /* Preverimo dimenzijo *x3, ce ni ustrezna, zbrisemo *x3: */
    if (*x3!=NULL)
      if ((*x3)->d!=b2->d)
        dispvector(x3);
    /* Ce je *x3==NULL, tvorimo *x3 z dimenzijama q1: */
    if (*x3==NULL)
      *x3=getvector(b2->d);
    /* Izvedba operacije: */
    solvortnormplain(q1,b2,*x3);
  }
  if (save!=NULL)
  {
    dispvector(save);
    *save=*x3;
  }
  return *x3; /* Ker je bil x3!=NULL, se vrne *x3. */
} else   /* x3=NULL */
{
  /* x3==NULL, naredi se nova vektor, v katerega se zapise rezultat operacije,
  vrne se njegov kazalec: */
  /* Najprej preverimo, ce sta q1 in b2 kompatibilni za operacijo: */
  if (q1==NULL || b2==NULL)
    return NULL;
  else if (q1->d1!=b2->d || q1->d2!=b2->d || b2->d<1)
    return NULL;
  else
  {
    v=getvector(b2->d);
    /* Izvedba operacije: */
    solvortnormplain(q1,b2,v);
    return v;
  }
}
}


matrix solvortnormmat0(matrix q1,matrix b2,matrix *x3)
    /* Vrne resitve sistemov enacb q1*x3=b2, kjer je q1 ortogonormirana matrika,
    t.j. matrika s paroma ortogonalnimi in normiranimi stolpci (v evklidski
    normi). Ce je x3 razlicen od NULL, zapise rezultat v *x3 in vrne *x3. x3
    je lahko tudi naslov q1 ali b2, funkcija v tem primeru poskrbi za to, da
    se najprej izracuna rezultat operacije in sele nato prepise operand.
     OPOMBA:
     Ce je x3 razlicen od NULL, se po navadi matrika, ki jo funkcija vrne, ne
    priredi nicemur ali se priredi matriki, na katero kaze x3 (ker dobimo
    drugace situacijo, ko dva kazalca kazeta na isto matriko).
    $A Igor avg00; */
{
matrix m=NULL,*save=NULL;
if (x3!=NULL)
{
  if (*x3==q1 || *x3==b2)
  {
    /* Koda, ki prepreci, da bi prislo do napacnih rezultatov, ce x3 kaze na
    q1 ali b2: */
    save=x3;
    x3=&m;
  }
  /* Ce je x3!=NULL, se rezultat shrane v *x3. Najprej preverimo, ce sta q1
  in b2 kompatibilni z operacijo: */
  if (q1==NULL || b2==NULL)
    dispmatrix(x3);
  else if (q1->d1!=b2->d1 || q1->d2!=b2->d1 || b2->d1<1 || b2->d2<1)
    dispmatrix(x3);
  else
  {
    /* Preverimo dimenzijo *x3, ce ni ustrezna, zbrisemo *x3: */
    if (*x3!=NULL)
      if ((*x3)->d1!=b2->d1 || (*x3)->d2!=b2->d2)
        dispmatrix(x3);
    /* Ce je *x3==NULL, tvorimo *x3 z dimenzijama q1: */
    if (*x3==NULL)
      *x3=getmatrix(b2->d1,b2->d2);
    /* Izvedba operacije: */
    solvortnormmatplain(q1,b2,*x3);
  }
  if (save!=NULL)
  {
    dispmatrix(save);
    *save=*x3;
  }
  return *x3; /* Ker je bil x3!=NULL, se vrne *x3. */
} else   /* x3=NULL */
{
  /* x3==NULL, naredi se nova matrika, v katero se zapise rezultat operacije,
  vrne se njen kazalec: */
  /* Najprej preverimo, ce sta q1 in b2 kompatibilni za operacijo: */
  if (q1==NULL || b2==NULL)
    return NULL;
  else if (q1->d1!=b2->d1 || q1->d2!=b2->d1 || b2->d1<1 || b2->d2<1)
    return NULL;
  else
  {
    m=getmatrix(b2->d1,b2->d2);
    /* Izvedba operacije: */
    solvortnormmatplain(q1,b2,m);
    return m;
  }
}
}




void solvQRplain(matrix mq,matrix mr,vector b,vector x)
    /* Solves the system of equations A x = b, where mq and mr contain the QR
    factors of A. Arguments must be of consistend dimensions and may not be
    NULL, since checks are not performed within the function.
      Dimensions: mq(nxn), mr(mxn), b(m), x(n),  m>=n!
      b can be the same as x. If m>n then x must be of dimension m and is
    resized within the function to the dimension n.
      Warning:
      Solution by compact form of QR is much quicker (function above)!
    $A Igor dec03; */
{
if (x->d!=b->d)
  resizevector(&x,b->d);
solvortnormplain(mq,b,x);
solvupperplain(mr,x,x);
if (x->d!=mr->d2)
  resizevector(&x,mr->d2);
}

    /* SOLUTION OF SYSTEMS BY THE GRAMM-SCHMIDT ORTHOGONALIZATION: */


vector solvGS0(matrix M,vector b,vector *x)
    /* Resi sistem enacb M*x=b tako, da najprej izvede normirano
    Gramm-Schmidtovo ortogonalizacijo stolpcev M in v obliki Q=MA, nato
    pa resi sistem v dveh stopnjah, najprej resi Q*y=b, nato pa izracuna x kot
    x=A*y.
     M mora biti kvadratna matrika in b vektor iste dimenzije kot M. x je lahko
    NULL, v tem primeru se na novo kreira in vrne vektor, ki vsebuje resitev.
    Ce je x!=NULL, se resitev zapise v *x (najprej se poskrbi, da ima *x isto
    dimenzijo kot b), *x pa se tudi vrne.
    $A Igor jul00; */
{
matrix Q=NULL,A=NULL;
vector y=NULL;
GSortnorm0(M,&Q,&A);
if (x!=NULL)
{
  solvortnorm0(Q,b,x);
  matprodvec0(A,*x,x);
  dispmatrix(&Q);
  dispmatrix(&A);
  return(*x);
} else  /* x=NULL */
{
  solvortnorm0(Q,b,&y);
  matprodvec0(A,y,&y);
  dispmatrix(&Q);
  dispmatrix(&A);
  return y;
}
}


matrix solvmatGS0(matrix M,matrix b,matrix *x)
    /* Resi sisteme enacb M*x=b tako, da najprej izvede normirano
    Gramm-Schmidtovo ortogonalizacijo stolpcev M in v obliki Q=MA, nato
    pa resi sistem v dveh stopnjah, najprej resi Q*y=b, nato pa izracuna x kot
    x=A*y.
     M mora biti kvadratna matrika in b matrika z istim stevilom vrstic, kot je
    dimenzija m, stolpcev pa mora imeti toliko, kolikor sistemov resujemo. x je
    lahko NULL, v tem primeru se na novo kreira in vrne vektor, ki vsebuje
    resitev. Ce je x!=NULL, se resitev zapise v *x (najprej se poskrbi, da ima
    *x iste dimenzije kot b), *x pa se tudi vrne.
    $A Igor jul00; */
{
matrix Q=NULL,A=NULL;
matrix y=NULL;
GSortnorm0(M,&Q,&A);
if (x!=NULL)
{
  solvortnormmat0(Q,b,x);
  matprod0(A,*x,x);
  dispmatrix(&Q);
  dispmatrix(&A);
  return(*x);
} else  /* x=NULL */
{
  solvortnormmat0(Q,b,&y);
  matprod0(A,y,&y);
  dispmatrix(&Q);
  dispmatrix(&A);
  return y;
}
}





            /*****************************/
            /*                           */
            /*   INVERSION OF MATRICES   */
            /*                           */
            /*****************************/



static void matinvortplain(matrix q,matrix inv)
    /* Izracuna inverz ortogonalne matrike q in rezultat zapise v inv. Funkcija
    ne preverja dimenzij. Matrika inv ne sme biti ista kot q.
    $A Igor jul00; */
{
int i,j,n;
double qnorm,x;
n=q->d1;
for (i=1;i<=n;++i)
{
  qnorm=0;
  for (j=1;j<=n;++j)  /* kvadrat norme i. vrstice */
  {
    x=q->m[j][i];
    qnorm+=x*x;
  }
  /* Izracun elementov i. stolpca inverzne matrike: */
  for (j=1;j<=n;++j)
    inv->m[i][j]=q->m[j][i]/qnorm;
}
}



matrix matinvGS0(matrix M,matrix *inv)
    /* Izracuna inverzno matriko matrike M s pomocjo Gramm-Schmidtove
    ortogonalizacije in jo vrne. Ce je inv!=NULL, vrne inverzno matriko v
    *inv, drugace inverzno matriko tvori na novo.
    $A Igor jul00; */
{
matrix Q=NULL,A=NULL;
matrix y=NULL;
GSortnorm0(M,&Q,&A);
mattransp0(Q,&Q);  /* Inverz Q je kar transponirana matrika Q */
if (inv!=NULL)
{
  matprod0(A,Q,inv);
  dispmatrix(&Q);
  dispmatrix(&A);
  return *inv;
} else  /* x=NULL */
{
  y=matprod0(A,Q,NULL);
  dispmatrix(&Q);
  dispmatrix(&A);
  return y;
}
}



























    /* TEST FUNCTIOS */


#include <strop.h>
#include <mtime.h>


void tesmatrixop(void)
    /* A test function for matrix operations. Several types of functionality
    are tested, some of which are included in "if (0)" - change 0 to 1 if you
    want to run tests for this functionality.
      Warning:
      These tests are not elaborated, in some placthe main purpose is for
    testing during development rather than for demonstration.
    $A Igor nov03; */
{
indtab it=NULL;
matrix G=NULL,G1=NULL,tabx=NULL,maux=NULL,A=NULL,ml=NULL,mu=NULL,
       Q=NULL,R=NULL,QR=NULL;
vector b=NULL,b1=NULL,v=NULL,
       taby=NULL,tabw=NULL,raw=NULL,
       tabfunc=NULL,x=NULL,vaux=NULL,
       d=NULL;
double c=0,c1=0,density=1.0,domdiag=1.0,negport=0.5;
int numx=10,numy=5,numz=5,i,j,k,randpow /*,ind*/ ,
    numcalc=1,  /* Number of calculations of 3D approximation */
    dim=500;   /* dimension for matrix operation tests */
double t0=0,t1=0,t2=0,t3=0,t4=0,t5=0,t6=0,ct0=0,ct1=0,ct2=0,ct3=0,ct4=0,ct5=0,ct6=0;

t0=absolutetime();  ct0=cputime();

timeinitrand();

/* LDLT DECOMPOSITION: */
if (0)
{
  printf("\nPress <Enter>!");
  if (1)
    getchar();
  /* Test of solution of system of equations by LDLT decomp: */
  printf("\n\n\n\n\n\nSolution of symmetric system of equations by LDLT dec.:\n");
  t0=absolutetime();  ct0=cputime();

  printf("Creation of random matrix and vector...\n");
  randvec0(dim,1,0,0,&vaux);
  randmat0(dim,dim,1,0,0,&A);
  /* Symmetrize A: */
  matsum0(A,mattransp0(A,&maux),&A);
  /* Check symmetricity: */
  k=1;
  for (i=1;i<=dim;++i)
    for (j=i;j<=dim;++j)
      if (fabs(A->m[i][j]-A->m[j][i])>1e-10)
        k=0;
  if (!k)
  {
    errfunc0("");
    sprintf(ers(),"Matrix A is not symmetric.\n");
    errfunc2();
  }
  /*
  printf("Matrix A:\n");
  printmatrixlist(A);
  */
  matprodvec0(A,vaux,&b);
  /* Decomposition: */
  resizematrix(&G,dim,dim);

  t1=absolutetime(); ct1=cputime();
  printf("\n\nPreparing the system: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);

  k=LDLTdecomptolplain(A,G,G,0.0);

  t2=absolutetime(); ct2=cputime();
  printf("\n\nLDLT Decomposition: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t2-t0,ct2-ct0,t2-t1,ct2-ct1);
  /*
  printf("Matrix A after decomp:\n");
  printmatrixlist(A);
  printf("Matrix G:\n");
  printmatrixlist(G);
  */

  if (k)
  {
    errfunc0("testmatrixop");
    sprintf(ers(),"Matrix A is not invertible.\n");
    errfunc2();
  } else
  {
    dispvector(&x);
    x=getvector(dim);
    solvLDLTplain(G,G,b,x);

    t3=absolutetime(); ct3=cputime();
    printf("\n\nSubstitution: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t3-t0,ct3-ct0,t3-t2,ct3-ct2);

    vecdif0(vaux,x,&tabw);
    /*
    printf("\n\nSystem matrix:\n");
    printmatrixlist(A);
    printf("Right-hand side vector:\n");
    printvectorlist(b);
    printf("True solution:\n");
    printvectorlist(vaux);
    printf("Calculated solution:\n");
    printvectorlist(x);
    printf("True solution:\n");
    printf("Difference between the true and the calculated solution:\n");
    printvectorlist(tabw);
    */
    printf("\nNorm of the difference: %g (norm/dim: %g), dim= %i\n",
      vecnorm(tabw),vecnorm(tabw)/(double) dim,dim);
  }
}



/* SYMMETRIC EIGENVALUES: */
if (0)
{
  printf("\nPress <Enter>!");
  if (1)
    getchar();
  /* Test of calculating eigenvalues of a symmetric matrix: */
  printf("\n\n\n\n\n\nEigenvalues of a symmetric matrix.:\n");
  t0=absolutetime();  ct0=cputime();

  /* Praparation: */
  randmat0(dim,dim,1,0,0,&A);
  printf("Making the system symmetric...\n");
  mattranspprodmat0(A,A,&A);
  zeromat0(A->d1,A->d2,&G);
  zerovec0(A->d1,&v);
  t1=absolutetime(); ct1=cputime();
  
  printf("\n\nPreparing the system: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);

  k=eigsyssymplain(A,G,v);
  
  t2=absolutetime(); ct2=cputime();
  printf("\n\nEigensystem solution: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t2-t0,ct2-ct0,t2-t1,ct2-ct1);

  if (0)
  {
    errfunc0("testmatrixop");
    sprintf(ers(),"Eigenvalues could not be computed.\n");
    errfunc2();
  } else
  {
    dispmatrix(&Q);
    dispmatrix(&R);
    /* Product of A with a matrix whose columns are its eigenvectors: */
    matprod0(A,G,&Q);

    /* Product of the matrix of eigenvectors as columns with a diagonal matrix
    containing the corresponding eigenvalues: */
    matproddiag0(G,v,&R);


    t3=absolutetime(); ct3=cputime();
    printf("\n\nSubstitution: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t3-t0,ct3-ct0,t3-t2,ct3-ct2);

    matdif0(Q,R,&R);
    printf("\nCompare the calculated solution to the true solution:\n");
    printf("Norm of the difference: %g (norm/dim: %g), dim= %ix%i\n",
      matnorm(R),matnorm(R)/(double) R->d1,R->d1,R->d2);
    /*
    printf("Norm Of the product (%ix%i): %g, dim. of the difference: (%ix%i).\n",
      Q->d1,Q->d2,  matnorm(Q) ,R->d1,R->d2);
    */
    dispmatrix(&A);
    dispmatrix(&G);
    dispmatrix(&Q);
    dispmatrix(&R);
    dispvector(&v);
    dispmatrix(&ml);
    dispmatrix(&mu);

  }
}




/* ITERATIVE SOLUTION OF LIN. SYS.: */
if (1)
{
  printf("\nPress <Enter>!");
  if (1)
    getchar();
  /* Test of solution of system of equations by LU decomp: */
  printf("\n\n\n\n\n\nIterative solution of a system of lin. equations:\n");
  t0=absolutetime();  ct0=cputime();

  /* Prepare the data: */  
  /* Prepare A with a possibly sparse structure: */
  density=1./1.; /* average rel. number of non-zero elements in a row */
  domdiag=5.0; /* average ration between diagonal and other nonzero elements */
  randpow=1;  /* power to amplify differences between random numbers */
  negport=0.;  /* portion of negative elements */
  zeromat0(dim,dim,&A);
  for (i=1;i<=A->d1;++i)
    for (j=1;j<=A->d2;++j)
      if (density>=1 || random1()<density)
      {
        A->m[i][j]=pow(random1(),randpow);
        if (negport>0 && random1()<negport)
          A->m[i][j]*=-1;
      }
  for (i=1;i<=dim;++i)
  {
    A->m[i][i]=domdiag*(0.5+pow(random1(),randpow))/2.0;
    if (negport>0 && random1()<negport)
      A->m[i][i]*=-1;
  }
  /* Symmetrize A: */
  /*
  matsum0(A,mattransp0(A,&maux),&A);
  */
  

  if (0)
  {
    printf ("System matrix A:\n");
    printmatrixlist(A);
  }
  randvec0(dim,1,0,0,&vaux);
  matprodvec0(A,vaux,&b);   /* ensure that A*vaux=b */
  zerovec0(A->d1,&x);
  
  t1=absolutetime(); ct1=cputime();
  printf("\n\nPreparing the system: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);

  if (0)
  {
    /* Add a large number to the diagonal and successively lower this number
    until 0, current solution is initial guess for the next iteration (the
    first solution is arbitrary because of good induced conditioning); the
    last iteration is outside this loop: */
    copymatrix(A,&G);
    domdiag=50.;
    while(domdiag>0)
    {
      printf("Added to diag: %g\n",domdiag);
        for (i=1;i<=A->d1;++i)
        /* if (i<=A->d2) */
          G->m[i][i]=A->m[i][i]+domdiag;
      k=solvitermgcrplain(G,b,x,500,1e-5);
      if (k<10)
        domdiag-=10.0;
      else if (k<20)
        domdiag-=2;
      else if (k<30)
        domdiag-=0.1;
      else
        domdiag+=5;
    }
  }
  /*
  for (i=1;i<=A->d1;++i)
    A->m[i][i]+=50;
    */
  k=solvitergmresplain(A,b,x,500,1e-12);

  t2=absolutetime(); ct2=cputime();
  printf("\n\nIterative solution: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t2-t0,ct2-ct0,t2-t1,ct2-ct1);

  if (k<0)
  {
    errfunc0("testmatrixop");
    sprintf(ers(),"Solution failed.\n");
    errfunc2();
  } else
  {
    printf("\n%i iterations performed.\nAccuracy of the solution:",k);
    vecdif0(vaux,x,&x);
    printf("Norm of the difference: %g (norm/dim: %g), dim= %ix%i\n",
      vecnorm(x),vecnorm(vaux)/(double) A->d1,A->d1,A->d2);
    printf("Relative error (||dif||/||sol||): %g (dimension: %i)\n",
      vecnorm(x)/vecnorm(vaux),x->d);
  }

}




/* LU DECOMPOSITION AND QR DECOMPOSITION: */
if (1)
{
  printf("\nPress <Enter>!");
  if (1)
    getchar();
  /* Test of solution of system of equations by LU decomp: */
  printf("\n\n\n\n\n\nSolution of a system of equations by LU dec.:\n");
  t0=absolutetime();  ct0=cputime();

  /* Decomposition: */
  randmat0(dim,dim,1,0,0,&A);
  randvec0(dim,1,0,0,&vaux);
  matprodvec0(A,vaux,&b);   /* ensure that A*vaux=b */
  resizematrix(&ml,dim,dim);
  resizematrix(&mu,dim,dim);
  resizeindtab(&it,1000,dim,dim);
  
  t1=absolutetime(); ct1=cputime();
  printf("\n\nPreparing the system: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);

  k=LUdecomptolplain(A,ml,mu,it,&i,0.0);

  t2=absolutetime(); ct2=cputime();
  printf("\n\nLU Decomposition: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t2-t0,ct2-ct0,t2-t1,ct2-ct1);

  if (k)
  {
    errfunc0("testmatrixop");
    sprintf(ers(),"Matrix A is not invertible.\n");
    errfunc2();
  } else
  {
    dispvector(&x);
    x=getvector(dim);
    solvLUplain(ml,mu,it,b,x);

    t3=absolutetime(); ct3=cputime();
    printf("\n\nSubstitution: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t3-t0,ct3-ct0,t3-t2,ct3-ct2);

    vecdif0(vaux,x,&tabw);
    printf("\nCompare the calculated solution to the true solution:\n");
    printf("Norm of the difference: %g (norm/dim: %g), dim= %i\n",
      vecnorm(tabw),vecnorm(tabw)/(double) dim,dim);
    dispmatrix(&ml);
    dispmatrix(&mu);

    printf("\n\nRepeate the test with Meschach (0/1)?");
    readint(&k);
    if (k)
    {
      t0=absolutetime();  ct0=cputime();
      /* Just for any case randomize x and ml, so that the components could not
      be inherited from previous calculations: */
      randvec0(dim,1,0,0,&x);
      randmat0(dim,dim,1,0,0,&ml);
      t1=absolutetime();  ct1=cputime();
      k=LUdecomp_mes(A,ml,it);

      t2=absolutetime(); ct2=cputime();
      printf("\n\nLU Decomposition (Meschach): %g s (CPU %g s), pure: %g s (CPU %g s)\n",
        t2-t0,ct2-ct0,t2-t1,ct2-ct1);
      if (k)
      {
        errfunc0("testmatrixop");
        sprintf(ers(),"Matrix A is not invertible.\n");
        errfunc2();
      } else
      {
        solvLU_mes(ml,it,b,x);

        t3=absolutetime(); ct3=cputime();
        printf("\n\nSubstitution: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
          t3-t0,ct3-ct0,t3-t2,ct3-ct2);

        vecdif0(vaux,x,&tabw);
        printf("\nCompare the calculated solution to the true solution:\n");
        printf("Norm of the difference: %g (norm/dim: %g), dim= %i\n",
          vecnorm(tabw),vecnorm(tabw)/(double) dim,dim);

      }
      dispmatrix(&ml);


      printf("\n\nRepeate the test with Meschach compact QR decomposition (0/1)? ");
      readint(&k);
      if (k)
      {
        t0=absolutetime();  ct0=cputime();
        /* Just for any case randomize x and ml, so that the components could not
        be inherited from previous calculations: */
        zerovec0(dim,&x);
        zeromat0(dim,dim,&QR);
        zerovec0(dim,&d);
        t1=absolutetime();  ct1=cputime();
        k=QRdecompplaincomp(A,QR,d);
        t2=absolutetime(); ct2=cputime();
        printf("\n\nQR Decomposition: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
          t2-t0,ct2-ct0,t2-t1,ct2-ct1);
        if (k)
        {
          errfunc0("testmatrixop");
          sprintf(ers(),"Matrix A is not invertible.\n");
          errfunc2();
        } else
        {
          solvQRplaincomp(QR,d,b,x);

          t3=absolutetime(); ct3=cputime();
          printf("\n\nSubstitution: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
            t3-t0,ct3-ct0,t3-t2,ct3-ct2);

          vecdif0(vaux,x,&tabw);
          printf("\nCompare the calculated solution to the true solution:\n");
          printf("Norm of the difference: %g (norm/dim: %g), dim= %i\n",
            vecnorm(tabw),vecnorm(tabw)/(double) dim,dim);
        }
        dispmatrix(&QR);
      }


      printf("\n\nRepeate the test with the expanded form QR decomposition (0/1)? ");
      readint(&k);
      if (k)
      {
        matrix B=NULL;
        t0=absolutetime();  ct0=cputime();
        /* Just for any case randomize x and ml, so that the components could not
        be inherited from previous calculations: */
        zerovec0(dim,&x);
        zeromat0(dim,dim,&QR);
        zeromat0(dim,dim,&Q);
        zeromat0(dim,dim,&R);
        zerovec0(dim,&d);
        t1=absolutetime();  ct1=cputime();
        k=QRdecompplain(A,Q,R);

        t2=absolutetime(); ct2=cputime();
        printf("\n\nNative QR dec.: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
          t2-t0,ct2-ct0,t2-t1,ct2-ct1);

        /* Test if QR==A: */
        /*
        matprod0(Q,R,&B);
        matdif0(A,B,&B);
        printf("\n\nNorm of difference between A (%i*%i) and its Q*R product is %g.\n",
          A->d1,A->d2,matnorm(B));
        printf("Norm of A: %g\n\n",matnorm(A));
        dispmatrix(&B);
        */

        if (k)
        {
          errfunc0("testmatrixop");
          sprintf(ers(),"Matrix A is not invertible.\n");
          errfunc2();
        } else
        {
          /*
          solvortnormplain(Q,b,x);
          solvupperplain(R,x,x);
          */
          solvQRplain(Q,R,b,x);

          t3=absolutetime(); ct3=cputime();
          printf("\n\nSubstitution: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
            t3-t0,ct3-ct0,t3-t2,ct3-ct2);

          vecdif0(vaux,x,&tabw);
          printf("\nCompare the calculated solution to the true solution:\n");
          printf("Norm of the difference: %g (norm/dim: %g), dim= %i\n",
            vecnorm(tabw),vecnorm(tabw)/(double) dim,dim);
        }
        dispmatrix(&QR);
      }

      printf("\n\nRepeate with the native non-square QR decomposition (0/1)? ");
      readint(&k);
      if (k)
      {
        matrix B=NULL;
        t0=absolutetime();  ct0=cputime();
        /* Just for any case randomize x and ml, so that the components could not
        be inherited from previous calculations: */
        randmat0(dim+10,dim,1,0,0,&A);
        randvec0(A->d2,1,0,0,&x);
        copyvector(x,&vaux);  /* True solution */
        matprodvec0(A,x,&b); /* dim. A->d1  (>A->d2) */
        zerovec0(A->d2,&x);
        zeromat0(A->d1,A->d1,&Q);
        zeromat0(A->d1,A->d2,&R);
        t1=absolutetime();  ct1=cputime();
        k=QRdecompplain(A,Q,R);

        t2=absolutetime(); ct2=cputime();
        printf("\n\nQR ,non-square: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
          t2-t0,ct2-ct0,t2-t1,ct2-ct1);

        /* Test if QR==A: */
        matprod0(Q,R,&B);
        matdif0(A,B,&B);
        printf("\n\nNorm of difference between A (%ix%i) and its Q*R product is %g.\n",
          A->d1,A->d2,matnorm(B));
        printf("Norm of A: %g\n\n",matnorm(A));
        dispmatrix(&B);

        if (k)
        {
          errfunc0("testmatrixop");
          sprintf(ers(),"Matrix A is not invertible.\n");
          errfunc2();
        } else
        {
          /*
          resizevector(&x,b->d);
          randvec0(x->d,1,0,0,&x);
          solvortnormplain(Q,b,x);
          solvupperplain(R,x,x);
          resizevector(&x,R->d2);
          */
          solvQRplain(Q,R,b,x);

          t3=absolutetime(); ct3=cputime();
          printf("\n\nSubstitution: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
            t3-t0,ct3-ct0,t3-t2,ct3-ct2);

          vecdif0(vaux,x,&tabw);
          printf("\nCompare the calculated solution to the true one:\n");
          printf("Norm of the difference: %g (norm/dim: %g), dim= %i\n",
            vecnorm(tabw),vecnorm(tabw)/(double) dim,dim);
        }
        dispmatrix(&QR);
      }

    }
  }
}

/* LLT (CHOLESKI) decomposition: */
if (0)
{
  printf("\nPress <Enter>!");
  getchar();
  /* Test of solution of system of equations by LLT (Choleski) decomp.: */
  printf("\n\n\n\n\n\nSolution by LLT decomp.:\n");
  t0=absolutetime();  ct0=cputime();

  printf("Making the system symmetric...\n");
  dispvector(&tabw);
  mattranspprodmat0(A,A,&G);
  mattranspprodvec0(A,b,&b);

  t1=absolutetime(); ct1=cputime();
  printf("\n\nPreparing the system: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);

  k=LLTdecomptolplain(G,G,0.0);

  t2=absolutetime(); ct2=cputime();
  printf("\n\nLLT Decomposition: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t2-t0,ct2-ct0,t2-t1,ct2-ct1);

  if (k)
  {
    errfunc0("testmatrixop");
    sprintf(ers(),"Matrix ATA is not positive definite.\n");
    errfunc2();
  } else
  {
  
    resizevector(&x,dim);
    solvLLTplain(G,b,x);

    t3=absolutetime(); ct3=cputime();
    printf("\n\nSubstitution: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
      t3-t0,ct3-ct0,t3-t2,ct3-ct2);

    vecdif0(vaux,x,&tabw);
  
    printf("\nNorm of the difference: %g (norm/dim: %g), dim= %i\n",
      vecnorm(tabw),vecnorm(tabw)/(double) dim,dim);
  }
}


dispmatrix(&G);
dispvector(&b);
}


