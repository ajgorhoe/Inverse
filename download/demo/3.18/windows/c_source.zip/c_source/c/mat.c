

            /*****************************/
            /*                           */   
            /*  BASIC MATRIX OPERATIONS  */
            /*                           */   
            /*****************************/


/* SPLOSNA OPOMBA: TISTE FUNKCIJE, KI IMAJO PRVO CRKO IMENA S, SO NAREJENE ZA
   VARNI NACIN DELA S SPOMINOM. TO POMENI, DA ELEMENTE MATRIK LE KOPIRAJO NA
   MESTA ELEMENTOV ZE OBSTOJECIH MATRIK TER NE TVORIJO NOVIH MATRIK. */


#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>

#include <rf.h>
#include <er.h>

#include <mtypes.h>
/* dodano za potrebe LU */ 
#include  <vec.h>
#include  <math.h>

#include  <mat.h>



static int /* outdig=8, */   /* St. dec. mest pri izpisovanju stevil */
           outchar=1;  /* Min. st. mest pri izpisovanju stevil */

int matgetoutdig(void)
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu mat.c.
    $A Igor mar99; */
{
return m_outdig;
}

int matgetoutchar(void)
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu mat.c.
    $A Igor mar99; */
{
return outchar;
}

void matsetoutdig(int num)
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu mat.c.
    $A Igor mar99; */
{
if (m_outdig>0)
  m_outdig=num;
}

void matsetoutchar(int num)
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu mat.c.
    $A Igor mar99; */
{
if (outchar>0)
  outchar=num;
}



void getmat(matrix mat, int m, int n)
     /* Naredi matriko dimenzije m*n */
{
int i;
double *lineptr;
mat->d1=m;
mat->d2=n;
mat->m=calloc(m,sizeof(*(mat->m)));
--mat->m;
mat->comp=calloc(m*n,sizeof(*(mat->comp)));
lineptr=mat->comp-1;
for (i=1;i<=m;++i)
{
  mat->m[i]=lineptr;
  lineptr+=n;
}
#if 0
int i;
mat->d1=m;
mat->d2=n;
mat->m=calloc(m,sizeof(double*));
--mat->m;
for(i=1; i<=m; ++i)
{
  mat->m[i]=calloc(n,sizeof(double));
  --(mat->m[i]);
}
#endif
}



void  dispmat(matrix mat)
      /* Sprosti *mat.m, postavi *mat.m ter *mat.d1 in
         *mat.d2 na 0 */
{
if (mat->d1>0 && mat->d2>0)
{
if (mat->m!=NULL && mat->d1>0)
  free(++mat->m);
mat->m=NULL;
free(mat->comp);
mat->comp=NULL;
}
#if 0
int i;
double **pp;
double *p;
pp=mat->m;
if (++(pp) !=0 && mat->d1 != 0)
{
  if (mat->d2 !=0)
    for (i=1; i<=mat->d1; ++i)
    {
      p=mat->m[i];
      if (++(p) !=0)  free(++(mat->m[i]));
    }
  free(++mat->m);
}
mat->m=0;
mat->d1=0;
mat->d2=0;
#endif
}



void initmat(matrix m)
     /* inicializira matriko */
{
(*m).d1=(*m).d2=0;
(*m).m=0;
}



matrix getmatrix(int m,int n)
       /* Rezervira prostor za matriko z m vrsticami in n stolpci ter vrne
       kazalec na ta prostor. */
{
matrix mat;
mat=malloc(sizeof(*mat));
getmat(mat,m,n);
return mat;
}


matrix resizematrix(matrix *addrm,int dim1,int dim2)
    /* Resizes a matrix pointed to by addrm so that its new dimensions are dim1
    and dim2. All components of an old matrix that fit in the new one are
    preserved. If addrm=NULL then a matrix is created and returned. If dim1=0
    and dim2=0 then the matrix is set to NULL. If only one of dim1 and dim2 is
    0 then the appropriate dimension of the old matrix is kept (if there is no
    old matrix then NULL matrix is returned).
    $A Igor nov03; */
{
matrix old,ret;
int i,j;
if (addrm!=NULL)
  old=*addrm;
else
  old=NULL;
if (old==NULL)
{
  if (dim1>0 && dim2>0)
    ret=getmatrix(dim1,dim2);
  else
    ret=NULL;
} else
{
  if (dim1<=0 && dim2>0)
    dim1=old->d1;
  if (dim2<=0 && dim1>0)
    dim2=old->d2;
  if (dim1==0)
  {
    dispmatrix(&old);
    ret=NULL;
  } else if (dim1==old->d1 && dim2==old->d2)
  {
    ret=old;
  } else
  {
    ret=getmatrix(dim1,dim2);
    for (i=1;i<=old->d1 && i<=ret->d1;++i)
      for (j=1;j<=old->d2 && j<=ret->d2;++j)
        ret->m[i][j]=old->m[i][j];
    dispmatrix(&old);
  }
}
if (addrm!=NULL)
  *addrm=ret;
return ret;
}

matrix matrixcopy(matrix m)
    /* Vrne kopijo matrike m.
    $A Igor okt97; */
{
matrix ret=NULL;
if (m!=NULL)
{
  ret=getmatrix(m->d1,m->d2);
  if (m->d1>0 && m->d2>0)
  {
    int i,j;
    for (i=1;i<=m->d1;++i)
      for (j=1;j<=m->d2;++j)
        ret->m[i][j]=m->m[i][j];
  }
}
return ret;
}


void dispmatrix(matrix *mat)
     /* Zbrise matriko *mat z vsebino vred in njeno vrednost postavi na NULL. */
{
matrix m;
if (mat!=NULL)
{
  m=*mat;
  if (m!=NULL)
  {
    dispmat(m);
    free(m);
    *mat=NULL;
  }
}
}


matrix copytabletomatrix(double *x,int dim1,int dim2,matrix *mat)
    /* Tabela dim1xdim2 stevil dipa double *x se prepise v matriko *mat. Ce je
    dim1 ali dim2 enak 0 ali ce je x enak NULL, postane *mat enak NULL.
    Funkcija matriko, ki je nastala s prepisom, tudi vrne.
      Ce je argument mat, ki je naslov ciljne matrike, enak NULL, se matrika,
    v katereo se prepise tabela in ki jo funkcija vrne, tvori na novo.
    Dimenziji matrike, v katereo se prepise tabela, sta po operaciji enaki
    dim1 in dim2.
      POZOR:
    x mora kazati na 1. element tabele. To pomeni, da se na 1. element
    sklicujemo z x[0] in ne z x[1].
    $A Igor jul98; */
{
matrix ret=NULL;
int i,j,itab;
if (dim1>0 && dim2>0 && x!=NULL)
{
  /* Ce so x, dim1 in dim2, ki podajajo tabelo, ustrezni, se tabela prepise v
  *mat, ki jo funkcija tudi vrne; Ce je mat enaka NULL, se na novo tvori
  matrika, ki ga funkcija vrne, tabela se prepise v to matriko: */
  if (mat==NULL)
  {
    /* Ce je mat (naslov ciljnege matrike) enak NULL, se tvori nova matrika
    ustrezne dimenzije in se priredi matriki, ki jo funkcija vrne: */
    ret=getmatrix(dim1,dim2);
    mat=&ret;  /* zato, da nadalje ni treba operirati nad matriko ret */
  } else
  {
    resizematrix(mat,dim1,dim2);
    ret=*mat;
  }
  if (*mat==NULL)
    *mat=getmatrix(dim1,dim2);
  /*
  else if ((*mat)->d1!=dim1 || (*mat)->d2!=dim2)
  {
    /* Ce *mat obstaja, a ni ustreznih dimenzij, se zbrise in tvori na
    novo, po tem moramo matriko, ki se vrne, znova postaviti na *mat: *
    dispmatrix(mat);
    *mat=getmatrix(dim1,dim2);
    ret=*mat;
  }
  */
  /* Prepisovanje komponent: */
  itab=0;
  for (i=1;i<=dim1;++i)
    for (j=1;j<=dim2;++j)
    {
      ret->m[i][j]=x[itab];
      ++itab;
    }
} else 
{
  /* Ce x ali dim1 ali dim2, ki podajajo tabelo, niso ustrezni, se *mat zbrise
  in se vrne NULL: */
  if (mat!=NULL)
    dispmatrix(mat);
}
return ret;
}

int copymatrixtotable(matrix mat,double **x,int *dim1,int *dim2)
    /* Matrika mat se prepise v tabelo stevil tipa double, katere nasov je x.
    Ce je mat enaka NULL ali je katera od njenih dimenzij (v->d1 oz. v->d2)
    enaka 0 ali je x enak NULL, se ne zgodi nic. Ce sta dim1 in dim2 razlicna
    od NULL, je *dim1x*dim2 resnicna dimenzija tabele oz. alociranega prostora.
    V tem primeru se preveri, ce je alociranega prostora dovolj in ce ga ni, se
    *x zbrise in alocira na novo, v *dim1 in *dim2  pa se zapiseta dimenziji
    matrike mat. *x se alocira na novo tudi, ce je enak NULL. Funkcija vrne
    stevilo prepisanih komponent (ki je lahko samo 0 ali mat->d1xmat->d2).
    Ce je dim1 razlicen od NULL, se v *dim1 zapise mat->d1; ce je dim2 razlicen
    od NULL, se v *dim2 zapise mat->d2 (oboje v primeru, da je mat razlicna od
    NULL in sta njeni dimenziji vecji od 0).
      POZOR:
    *x mora kazati na 1. element tabele, na katerega se torej sklicujemo z
    (*x)[0] in ne z (*x)[1].
    $A Igor jul98; */
{
int ret=0,i,j;
if (dim1!=NULL)
  *dim1=0;
if (dim2!=NULL)
  *dim2=0;
if (x!=NULL && mat!=NULL)
  if (mat->d1>0 && mat->d2>0)
  {
    if (*x==NULL || (dim1!=NULL && dim2!=NULL && *dim1*(*dim2)<mat->d1*mat->d2))
    {
      /* Ce sta podani dimenziji tabele in ce je njun produkt manjsi od
      produkta dimenzij matrike, se tabela *x zbrise in alocira na novo (ce je
      dim1 ali dim2 enak NULL, se predpostavi, da za tabelo ze alociranega
      dovolj prostora). */
      if (*x!=NULL)
        free(*x);
      *x=malloc(mat->d1*mat->d2*sizeof(double));
    }
    if (dim1!=NULL)
      *dim1=mat->d1;
    if (dim2!=NULL)
      *dim2=mat->d2;
    /* Prepisovanje komponent: */
    for (i=1;i<=mat->d1;++i)
      for (j=1;j<=mat->d2;++j)
      {
        (*x)[ret]=mat->m[i][j];
        ++ret;
      }
  }
return ret;
}


void copymat(matrix m1, matrix m2)
     /* Matriko *m2 skopira na matriko *m1 */
{
int i,j;
if (m1->d1!=0 && m1->d2!=0 && m1->m!=0)
  dispmat(m1);
getmat(m1,m2->d1,m2->d2);
for (i=1; i<=m2->d1; ++i)
  for (j=1; j<=m2->d2; ++j)
    (m1->m)[i][j]=(m2->m)[i][j];
m1->d1=m2->d1;
m1->d2=m2->d2;
}



matrix copymatrix(matrix m1,matrix *m2)
    /* Returns the copy of matrix m1. If m2 is different than NULL, then m1 is
    coppied to *m2 and *m2 returned.
    $A Igor mar98; */
{
matrix m;
int i,j;
if (m2!=NULL)
{
  /* If m2!=NULL then m1 is copied to *m2: */
  if (m1==NULL)
  {
    dispmatrix(m2);
  } else
  {
    /* Check dimensions of *m2, delete it if not appropriate: */
    if (*m2!=NULL)
      if ((*m2)->d1!=m1->d1 || (*m2)->d2!=m1->d2)
        dispmatrix(m2);
    /* If *m2==NULL we create it, with dimensions of m1: */
    if (*m2==NULL)
      *m2=getmatrix(m1->d1,m1->d2);
    m=*m2;
    /* Copying of values: */
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        m->m[i][j]=m1->m[i][j];
  }
  return *m2; /* Since m2!=NULL, *m2 is returned. */
} else
{
  /* m2==NULL, we create a new matrix - copy of m1, return its pointer: */
  if (m1==NULL)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        m->m[i][j]=m1->m[i][j];
    return m;
  }
}
}


matrix copymatrix0(matrix m1,matrix *m2)
    /* Returns the copy of matrix m1. If m2 is different than NULL, then m1 is
    coppied to *m2 and *m2 returned.
    $A Igor mar98; */
{
return copymatrix(m1,m2);
}


matrix matrixsum0(matrix m1,matrix m2,matrix *m3)
    /* Vrne vsoto matrik m1 in m2. Ce je m3 razlicen od NULL, zapise rezultat
    v *m3 in vrne *m3.
    $A Igor mar98; */
{
matrix m;
int i,j;
if (m3!=NULL)
{
  /* Ce je m3!=NULL, se rezultat shrane v *m3: */
  if (m1==NULL || m2==NULL)
    dispmatrix(m3);
  else if (m1->d1!=m2->d1 ||m1->d2!=m2->d2 || m1->d1<1|| m1->d2<1)
    dispmatrix(m3);
  else
  {
    /* Preverimo dimenzijo *m3, ce ni ustrezna, zbrisemo *m3: */
    if (*m3!=NULL)
      if ((*m3)->d1!=m1->d1 || (*m3)->d2!=m1->d2)
        dispmatrix(m3);
    /* Ce je *m3==NULL, tvorimo *m3 z dimenzijama m1: */
    if (*m3==NULL)
      *m3=getmatrix(m1->d1,m1->d2);
    m=*m3;
    /* Izvedba operacije: */
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        m->m[i][j]=m1->m[i][j]+m2->m[i][j];
  }
  return *m3; /* Ker je bil m3!=NULL, se vrne *m3. */
} else
{
  /* m3==NULL, naredi se nova matrika, ki je vsota m1 in m2, vrne se njen
  kazalec: */
  if (m1==NULL || m2==NULL)
    return NULL;
  else if (m1->d1!=m2->d1 ||m1->d2!=m2->d2 || m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        m->m[i][j]=m1->m[i][j]+m2->m[i][j];
    return m;
  }
}
}


matrix matrixdif0(matrix m1,matrix m2,matrix *m3)
    /* Vrne razliko matrik m1 in m2. Ce je m3 razlicen od NULL, zapise rezultat
    v *m3 in vrne *m3.
    $A Igor mar99; */
{
matrix m;
int i,j;
if (m3!=NULL)
{
  /* Ce je m3!=NULL, se rezultat shrane v *m3: */
  if (m1==NULL || m2==NULL)
    dispmatrix(m3);
  else if (m1->d1!=m2->d1 ||m1->d2!=m2->d2 || m1->d1<1|| m1->d2<1)
    dispmatrix(m3);
  else
  {
    /* Preverimo dimenzijo *m3, ce ni ustrezna, zbrisemo *m3: */
    if (*m3!=NULL)
      if ((*m3)->d1!=m1->d1 || (*m3)->d2!=m1->d2)
        dispmatrix(m3);
    /* Ce je *m3==NULL, tvorimo *m3 z dimenzijama m1: */
    if (*m3==NULL)
      *m3=getmatrix(m1->d1,m1->d2);
    m=*m3;
    /* Izvedba operacije: */
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        m->m[i][j]=m1->m[i][j]-m2->m[i][j];
  }
  return *m3; /* Ker je bil m3!=NULL, se vrne *m3. */
} else
{
  /* m3==NULL, naredi se nova matrika, ki je vsota m1 in m2, vrne se njen
  kazalec: */
  if (m1==NULL || m2==NULL)
    return NULL;
  else if (m1->d1!=m2->d1 ||m1->d2!=m2->d2 || m1->d1<1 || m1->d2<1)
    return NULL;
  else
  {
    m=getmatrix(m1->d1,m1->d2);
    /* Izvedba operacije: */
    for (i=1;i<=m1->d1;++i)
      for (j=1;j<=m1->d2;++j)
        m->m[i][j]=m1->m[i][j]-m2->m[i][j];
    return m;
  }
}
}


matrix movematrix0(matrix *m1,matrix *m2)
    /* Premakne *m1 v *m2 in vrne *m2. Po izvedbi je vedno *m1==NULL. Ce je
    m2==NULL, samo vrne *m1 (ce je m1==NULL, vrne NULL).
    $A Igor mar98; */
{
matrix m;
if (m1!=NULL)
{
  if (m2!=NULL)
  {
    /* Ce je m2!=NULL, se *m1 premakne v *m2: */
    dispmatrix(m2);
    *m2=*m1;
    *m1=NULL;
    return *m2;
  } else
  {
    m=*m1;
    *m1=NULL;
    return m;
  }
} else
{
  /* Ce je m1 NULL, se zbrise m2 in vrne NULL. */
  if (m2!=NULL)
    dispmatrix(m2);
  return NULL;
}
}



void fprintmat(FILE *fp, struct _matrix m)
     /* Izpise matriko m */
{
int i,j;
if (fp!=NULL)
{
  if (m.d1!=0 && m.d2!=0 && m.m!=0)
  {
    fprintf(fp,"Dimension: %i*%i\n",m.d1,m.d2);
    fprintf(fp,"Elements:\n\n");
    for(i=1; i<=m.d1; ++i)
    {
    for (j=1; j<=m.d2; ++j)
      fprintf(fp,"m[%i,%i]= %.*g\n",i,j,m_outdig,m.m[i][j]);
    fprintf(fp,"\n");
    }
  } else fprintf(fp,"EMPTY MATRIX.\n");
}
}



void printmat(struct _matrix m)
     /* Izpise matriko m */
{
int i,j;
if (m.d1!=0 && m.d2!=0 && m.m!=0)
{
  printf("Dimension: %i*%i\n",m.d1,m.d2);
  printf("Elements:\n\n");
  for(i=1; i<=m.d1; ++i)
  {
  for (j=1; j<=m.d2; ++j)
    printf("m[%i,%i]= %-*.*g\n",i,j,outchar,m_outdig,m.m[i][j]);
  printf("\n");
  }
} else printf("EMPTY MATRIX.\n");
}




void fprintmatrix(FILE *fp,matrix mat)
     /* Izpise vsebino matrike mat v datoteko fp. */
{
  if (fp!=NULL)
  {
  if (mat==NULL)
    fprintf(fp,"NULL MATRIX.\n");
  else
    fprintmat(fp,*mat);
}
}


void printmatrix(matrix mat)
     /* Izpise vsebino matrike mat na standardni izhod. */
{
fprintmatrix(stdout,mat);
}



void fprintmatname(FILE *fp,struct _matrix m, char *name)
     /* Izpise matriko m. Niz name uporabi pri poimenovanju matrike. */
{
int i,j;
if (fp!=NULL)
{
  if (m.d1!=0 && m.d2!=0 && m.m!=0)
  {
    fprintf(fp,"Dimension: %i*%i\n",m.d1,m.d2);
    fprintf(fp,"Elements:\n\n");
    for(i=1; i<=m.d1; ++i)
    {
    for (j=1; j<=m.d2; ++j)
      fprintf(fp,"%s[%i,%i]= %-*.*g\n",name,i,j,outchar,m_outdig,m.m[i][j]);
    fprintf(fp,"\n");
    }
  } else fprintf(fp,"EMPTY MATRIX.\n");
}
}


void printmatname(struct _matrix m, char *name)
     /* Izpise matriko m. Niz name uporabi pri poimenovanju matrike. */
{
int i,j;
if (m.d1!=0 && m.d2!=0 && m.m!=0)
{
  printf("Dimension: %i*%i\n",m.d1,m.d2);
  printf("Elements:\n\n");
  for(i=1; i<=m.d1; ++i)
  {
  for (j=1; j<=m.d2; ++j)
    printf("%s[%i,%i]= %-*.*g\n",name,i,j,outchar,m_outdig,m.m[i][j]);
  printf("\n");
  }
} else printf("EMPTY MATRIX.\n");
}




void fprintmatrixname(FILE *fp,matrix m,char *name)
     /* Izpise vsebino matrike m v datoteko fp. Ime vektorja je name. */
{
if (fp!=NULL)
{
  if (m==NULL)
    fprintf(fp,"%s = NULL\n",name);
  else
    fprintmatname(fp,*m,name);
}
}




void printmatrixname(matrix m,char *name)
     /* Izpise vsebino matrike m na na standardni izhod. Ime vektorja je name. */
{
  fprintmatrixname(stdout,m,name);
}



void fprintmatrixline(FILE *fp,matrix mat)
    /* V datoteko fp zapise matriko mat, pri cemer vrstice izpise v eni vrsti.
    $A Igor sep97; */
{
int i,j;
if (fp!=NULL)
{
  if (mat==NULL)
    fprintf(fp,"NULL MATRIX");
  else if (mat->d1!=0 && mat->d2!=0)
  {
    for (i=1;i<=mat->d1;++i)
    {
      for (j=1;j<=mat->d2;++j)
      {
        fprintf(fp,"m[%i][%i]=%-*.*g",i,j,outchar,m_outdig,mat->m[i][j]);
        if (j<mat->d2)
          fprintf(fp,", ");
        else fprintf(fp,"\n");
      }
      fprintf(fp,"\n");
    }
  }
}
}


void printmatrixline(matrix mat)
    /* Na stand. izhod zapise matriko mat, pri cemer vrstice izpise v eni vrsti.
    $A Igor sep97; */
{
fprintmatrixline(stdout,mat);
}



void fprintmatrixlist(FILE *fp,matrix mat)
    /* Prints matrix mat to the file fp in a list form as used in Mathematica.
    Line breaks are printed between lines.
    $A Igor nov03; */
{
int i,j;
if (fp!=NULL)
{
  fprintf(fp,"{");
  if (mat==NULL)
    fprintf(fp,"{}");
  else if (mat->d1<1)
    fprintf(fp,"{}");
  else
  {
    for (i=1;i<=mat->d1;++i)
    {
      if (i>1)
        fprintf(fp," ");
      fprintf(fp,"{");
      for (j=1;j<mat->d2;++j)
        /* 
        fprintf(fp,"%5g, ",mat->m[i][j]); 
        */
        fprintf(fp,"%.*g, ",m_outdig,mat->m[i][j]);
      /*
      fprintf(fp,"%5g",mat->m[i][j]);
      */
      fprintf(fp,"%g",mat->m[i][j]);
      if (i<mat->d1)
        fprintf(fp,"}, \n");
      else
        fprintf(fp,"}");
    }
  }
  fprintf(fp,"}\n");
}
}

void printmatrixlist(matrix mat)
    /* Prints matrix mat to the standard output in a list form as used in
    Mathematica. Line breaks are printed between lines.
    $A Igor nov03; */
{
fprintmatrixlist(stdout,mat);
}



void fprintmatrixlistline(FILE *fp,matrix mat)
    /* Prints matrix mat to the file fp in a list form as used in Mathematica.
    Only spaces are printed between lines (no line breaks).
    $A Igor apr05; */
{
int i,j;
if (fp!=NULL)
{
  fprintf(fp,"{");
  if (mat==NULL)
    fprintf(fp,"{}");
  else if (mat->d1<1)
    fprintf(fp,"{}");
  else
  {
    for (i=1;i<=mat->d1;++i)
    {
      if (i>1)
        fprintf(fp," ");
      fprintf(fp,"{");
      for (j=1;j<mat->d2;++j)
        /* 
        fprintf(fp,"%5g, ",mat->m[i][j]); 
        */
        fprintf(fp,"%.*g, ",m_outdig,mat->m[i][j]);
      /*
      fprintf(fp,"%5g",mat->m[i][j]);
      */
      fprintf(fp,"%.*g",m_outdig,mat->m[i][j]);
      if (i<mat->d1)
        fprintf(fp,"},  ");
      else
        fprintf(fp,"}");
    }
  }
  fprintf(fp,"} ");
}
}


void printmatrixlistline(matrix mat)
    /* Prints matrix mat to the standard output in a list form as used in
    Mathematica. Only spaces are printed between lines (no line breaks).
    $A Igor apr05; */
{
fprintmatrixlistline(stdout,mat);
}



void readmat(matrix m)
     /* Prebere matriko s standardnega vhoda. */
{
int i,j;
if (m->d1!=0 && m->d2!=0 && m->m!=0)
  dispmat(m);
printf("Rows   : ");       scanf("%i",&i);
printf("Columns: ");    scanf("%i",&j);
printf("Elements:\n");
getmat(m,i,j);
m->d1=i;
m->d2=j;
for (i=1; i<=m->d1; ++i)
{
  for (j=1; j<=m->d2; ++j)
  {
    printf("m[%i,%i] : ",i,j);
    scanf("%lg",&(m->m[i][j]));
  }
  printf("\n");
}
}




struct _matrix identitymat(int n)
       /* Vrne identicno matriko n*n */
{
int i,j;
struct _matrix m;
if (n>0)
{
  getmat(&m,n,n);
  for (i=1; i<=n; ++i)
    for (j=1; j<=n; ++j)
      m.m[i][j] = (i==j)? 1: 0;
} else initmat(&m);
return(m);
}




struct _matrix prodmat(struct _matrix m1, struct _matrix m2)
       /* Vrne matricni produkt matrik m1 in m2 */
{
int i,j,k;
struct _matrix m={0};
if(m1.d2==m2.d1 && m1.d1!=0 && m1.d2!=0 && m2.d1!=0
&& m2.d2!=0 && m1.m!=0 && m2.m!=0)
{
  getmat(&m,m1.d1,m2.d2);
  for (i=1; i<=m.d1; ++i)
    for (j=1; j<=m.d2; ++j)
    {
      m.m[i][j]=0;
      for (k=1; k<=m1.d2; ++k)
        m.m[i][j]+=m1.m[i][k]*m2.m[k][j];
    }
} else initmat(&m);
return(m);
}








struct _matrix timesmat(struct _matrix m, double t)
       /* Vrne matriko m, pomnozeno s stevilom t */
{
int i,j;
struct _matrix mm;
if (m.d1!=0 && m.d2!=0 && m.m!=0)
{
getmat(&mm,m.d1,m.d2);
for(i=1; i<=m.d1; ++i)
  for (j=1; j<=m.d2;++j)
  {
    mm.m[i][j]=t*m.m[i][j];
  }
} else initmat(&mm);
return mm;
}




struct _matrix summat(struct _matrix m1, struct _matrix m2)
       /* Vrne vsoto matrik m1 in m2. */
{
int i,j;
struct _matrix mm;
if (m1.d1==m2.d1 && m1.d2==m2.d2 && m1.d1!=0
&& m1.d2!=0 && m1.m!=0 && m2.m!=0)
{
  getmat(&mm,m1.d1,m1.d2);
  for(i=1; i<=m1.d1; ++i)
    for (j=1; j<=m1.d2;++j)
    {
      mm.m[i][j]=m1.m[i][j]+m2.m[i][j];
    }
} else initmat(&mm);
return mm;
}






struct _matrix difmat(struct _matrix m1, struct _matrix m2)
       /* Vrne razliko matrik (m1-m2) */
{
int i,j;
struct _matrix mm;
if (m1.d1==m2.d1 && m1.d2==m2.d2 && m1.d1!=0
&& m1.d2!=0 && m1.m!=0 && m2.m!=0)
{
  getmat(&mm,m1.d1,m1.d2);
  for(i=1; i<=m1.d1; ++i)
    for (j=1; j<=m1.d2;++j)
    {
      mm.m[i][j]=m1.m[i][j]-m2.m[i][j];
    }
} else initmat(&mm);
return mm;
}





struct _matrix transpmat(struct _matrix m)
       /* Vrne transponirano matriko matrike m */
{
int i,j;
struct _matrix mm;
if (m.m!=0 && m.d1!=0 && m.d2!=0)
{
  getmat(&mm,m.d2,m.d1);
  for(i=1; i<=mm.d1; ++i)
    for (j=1; j<=mm.d2; ++i)
      mm.m[i][j]=m.m[j][i];
} else initmat(&mm);
return mm;
}




double detmat(struct _matrix mm)
       /* Vrne determinanto kvadratne matrike m. */
{
struct _matrix m={0};
double x;
int sign=1,i,j,k,dim;
char end=0;
copymat(&m,&mm);
if (m.m!=0 && m.d1==m.d2)
{
  dim=m.d1;
  for (i=1; i<=dim-1; ++i) if (! end)  /* Tvorjenje zgornje trikot. mat. */
  {
    if (m.m[i][i]==0)
    {
      j=i;
      do ++j; while(m.m[j][i]==0 && j<dim);
      if (m.m[j][i]==0)
        {++end;} /* end:=true */
      else for(k=1; k<=dim; ++k) /* Zamenjava vrstic i in j */
      {
         x=m.m[i][k]; m.m[i][k]=m.m[j][k]; m.m[j][k]=x;
         sign*=-1;
      }   /* Elementi levo od i. stolpca niso pomembni */
    }
    if (! end) for(j=i+1; j<=dim; ++j) if (m.m[i][j]!=0)
    /* Pridobivanje nicel desno od m.m[i][i] */
    {
      x=m.m[i][j];
      for (k=1; k<=dim; ++k) m.m[k][j]-=x*(m.m[k][i]/m.m[i][i]);
      /* Od i naprej, ker so nad i. vrstico v obeh stolpcih
      same nicle; Od j. stolpca se odsteje i., stolpec,
      pomnozen z m.m[i][j]/m.m[i][i] */
    }
  }
  if (! end)
  {
    x=1;
    for (i=1; i<=dim; ++i) x*=m.m[i][i];
    x*=sign;
  }  else x=0;
} else x=0;
dispmat(&m);
return x;
}





struct _matrix invmat(struct _matrix m)
       /* Vrne inverzno matriko kvadratne matrike m */
{
struct _matrix a={0},inv={0};
double x;
int i,j,k,dim /*,sign=1*/ ;
char end=0,singular=0;
if (m.d1==m.d2 && m.d1>0  && m.m!=0)
{
  dim=m.d1;
  inv=identitymat(dim);
  initmat(&a);
  copymat(&a,&m);
  for (i=1; i<=dim; ++i)  /* Tvori se diagonalna matrika */
  {
    end=0;
    if(a.m[i][i]==0)
    {
      j=i;
      if(i<dim) do
      {
        ++j;
      } while (a.m[j][i]==0 && j!=dim);
      if (a.m[j][i]==0) ++end; else
      {
        for(k=1; k<=dim; ++k)  /* i. vrstici se pristeje j. vrstica */
        {
          a.m[i][k]+=a.m[j][k];
          /* Ista operacija se mora izvesti na inv.*/
          inv.m[i][k]+=inv.m[j][k];
        }
      }
      if (end) ++singular;
    }
    if (! end) for (j=1; j<=dim; j++)
    {
      if (a.m[j][i] !=0) if (j!=i)
      /* Pridelovanje nicel v i. stolpcu matrike a: */
      {
        x=a.m[j][i];
        for (k=1; k<=dim; ++k)
        {
          a.m[j][k]-=x*(a.m[i][k]/a.m[i][i]);
          /* Ustrezna operacija na inverzni matriki: */
          inv.m[j][k]-=x*(inv.m[i][k]/a.m[i][i]);
        }
        /* Od j. vrstice smo odsteli i., pomnozeno z a.m[j][i]/a.m[i][i]. */
      }
    }
  }
  if (singular) dispmat(&inv); else
  {
    for (i=1; i<=dim; ++i)
      for (j=1; j<=dim; ++j)
        inv.m[i][j]/=a.m[i][i];
  }
  dispmat(&a);
} else initmat(&inv);
/* printmat(inv); */
return inv;
}





struct _matrix quotmat(struct _matrix a, struct _matrix b)
       /* Vrne kvocient matrik (a inv(b)) */
{
struct _matrix i={0},q={0};
i=invmat(b);
q=prodmat(a,i);
dispmat(&i);
return q;
}





/* "Varne matricne funkcije: matrika, ki je rezultat funkcije, se ne tvori na
    novo, ce ustrezna matrika ze obstaja. S tem se izognemo napakam pri delu s
    spominom, ki se lahko pojavijo, ce hocemo znotraj funkcije brisati matriko,
    ki je bila definirana zunaj te funkcije. */



void scopymat(matrix m1, struct _matrix m2)
     /* Varno kopiranje:
        Matriko *m2 skopira na matriko m1. Ce je matrika m1 ze ustrezne
        dimenzije, se le prepise vsebina in se ne tvori na novo. */
{
int i,j;
if (m1->d1!=m2.d1 || m1->d2!=m2.d2 || m1->m==NULL)
{
  dispmat(m1);
  getmat(m1,m2.d1,m2.d2);
}
for (i=1; i<=m1->d1; ++i)
  for (j=1; j<=m1->d2; ++j)
    (m1->m)[i][j]=(m2.m)[i][j];
}




void sidentitymat(matrix mat, int n)
       /* Vrne identicno matriko n*n */
{
int i,j;
if (mat->d1!=n || mat->d2!=n || mat->m==NULL)
{
  dispmat(mat);
  getmat(mat,n,n);
}
if (n>0)
{
  for (i=1; i<=n; ++i)
    for (j=1; j<=n; ++j)
      mat->m[i][j] = (i==j)? 1: 0;
} else initmat(mat);
}


void sprodmat(matrix m, struct _matrix m1, struct _matrix m2)
       /* Varni matricni produkt matrik m1 in m2:
          Matrika m postane produkt matrik m1 in m2. Ce je m ze obstojeca
          matrika ustreznih dimenzij, se ne zbrise in tvori na novo! */
{
int i,j,k;
if(m1.d2==m2.d1 && m1.d1!=0 && m1.d2!=0 && m2.d1!=0
&& m2.d2!=0 && m1.m!=0 && m2.m!=0)
{
  if (m->d1!=m1.d1 || m->d2!=m2.d2 || m->m==NULL)
  {
    dispmat(m);
    getmat(m,m1.d1,m2.d2);
  }
  for (i=1; i<=m->d1; ++i)
    for (j=1; j<=m->d2; ++j)
    {
      m->m[i][j]=0;
      for (k=1; k<=m1.d2; ++k)
        m->m[i][j]+=m1.m[i][k]*m2.m[k][j];
    }
} else initmat(m);
}







void stimesmat(matrix mm, struct _matrix m, double t)
       /* Vrne matriko m, pomnozeno s stevilom t */
{
int i,j;
if (m.d1!=0 && m.d2!=0 && m.m!=0)
{
  if (mm->d1!=m.d1 || mm->d2!=m.d2 || mm->m==NULL)
  {
    dispmat(mm);
    getmat(mm,m.d1,m.d2);
  }
  for(i=1; i<=m.d1; ++i)
    for (j=1; j<=m.d2;++j)
    {
      mm->m[i][j]=t*m.m[i][j];
    }
} else initmat(mm);
}




void ssummat(matrix mm, struct _matrix m1, struct _matrix m2)
       /* Vrne vsoto matrik m1 in m2. */
{
int i,j;
if (m1.d1==m2.d1 && m1.d2==m2.d2 && m1.d1!=0
&& m1.d2!=0 && m1.m!=0 && m2.m!=0)
{
  if (mm->d1!=m1.d1 || mm->d2!=m1.d2 || mm->m==NULL)
  {
    dispmat(mm);
    getmat(mm,m1.d1,m1.d2);
  }
  for(i=1; i<=m1.d1; ++i)
    for (j=1; j<=m1.d2;++j)
    {
      mm->m[i][j]=m1.m[i][j]+m2.m[i][j];
    }
} else initmat(mm);
}






void sdifmat(matrix mm, struct _matrix m1, struct _matrix m2)
       /* Vrne razliko matrik (m1-m2) */
{
int i,j;
if (m1.d1==m2.d1 && m1.d2==m2.d2 && m1.d1!=0
&& m1.d2!=0 && m1.m!=0 && m2.m!=0)
{
  if (mm->d1!=m1.d1 || mm->d2!=m1.d2 || mm->m==NULL)
  {
    dispmat(mm);
    getmat(mm,m1.d1,m1.d2);
  }
  for(i=1; i<=m1.d1; ++i)
    for (j=1; j<=m1.d2;++j)
    {
      mm->m[i][j]=m1.m[i][j]-m2.m[i][j];
    }
} else initmat(mm);
}





void stranspmat(matrix mm, struct _matrix m)
       /* Vrne transponirano matriko matrike m */
{
int i,j;
if (m.m!=0 && m.d1!=0 && m.d2!=0)
{
  if (mm->d1!=m.d2 || mm->d2 !=m.d1 || mm->m==NULL)
  {
    dispmat(mm);
    getmat(mm,m.d2,m.d1);
  }
  for(i=1; i<=mm->d1; ++i)
    for (j=1; j<=mm->d2; ++i)
      mm->m[i][j]=m.m[j][i];
} else initmat(mm);
}




void sinvmat(matrix inv, struct _matrix m,matrix a)
       /* Vrne inverzno matriko kvadratne matrike m v matriki inv. Matrika
          a je pomozna matrika, ki mora biti iste dimenzije kot m. */
{
/* struct _matrix a={0}; */
double x;
int i,j,k,dim/*,sign=1*/;
char end=0,singular=0;
if (m.d1==m.d2 && m.d1>0  && m.m!=0)
{
  dim=m.d1;
  sidentitymat(inv,dim);
  scopymat(a,m);
  for (i=1; i<=dim; ++i)  /* Tvori se diagonalna matrika */
  {
    end=0;

    if(a->m[i][i]==0)
    {
      j=i;
      if(i<dim) do
      {
        ++j;
      } while (a->m[j][i]==0 && j!=dim);
      if (a->m[j][i]==0) ++end; else
      {
        for(k=1; k<=dim; ++k)  /* i. vrstici se pristeje j. vrstica */
        {
          a->m[i][k]+=a->m[j][k];
          /* Ista operacija se mora izvesti na inv.*/
          inv->m[i][k]+=inv->m[j][k];
        }
      }
      if (end) ++singular;
    }
    if (! end) for (j=1; j<=dim; j++)
    {
      if (a->m[j][i] !=0) if (j!=i)
      /* Pridelovanje nicel v i. stolpcu matrike a: */
      {
        x=a->m[j][i];
        for (k=1; k<=dim; ++k)
        {
          a->m[j][k]-=x*(a->m[i][k]/a->m[i][i]);
          /* Ustrezna operacija na inverzni matriki: */
          inv->m[j][k]-=x*(inv->m[i][k]/a->m[i][i]);
        }
        /* Od j. vrstice smo odsteli i., pomnozeno z a->m[j][i]/a->m[i][i]. */
      }
    }
  }
  if (singular) dispmat(inv); else
  {
    for (i=1; i<=dim; ++i)
      for (j=1; j<=dim; ++j)
        inv->m[i][j]/=a->m[i][i];
  }
} else initmat(inv);
/* printmat(inv); */
}





void squotmat(matrix q, struct _matrix a, struct _matrix b,matrix buf)
       /* Vrne kvocient matrik (a inv(b)) v matriki q. buf je pomozna
       matrika. */
{
sinvmat(buf,b,q);
sprodmat(q,a,*buf);
}




void sinvmat1(matrix inv, struct _matrix m)
       /* Vrne inverzno matriko kvadratne matrike m */
{
struct _matrix a={0};
double x;
int i,j,k,dim/*,sign=1*/;
char end=0,singular=0;
if (m.d1==m.d2 && m.d1>0  && m.m!=0)
{
  dim=m.d1;
  sidentitymat(inv,dim);
  initmat(&a);
  scopymat(&a,m);
  for (i=1; i<=dim; ++i)  /* Tvori se diagonalna matrika */
  {
    end=0;
    if(a.m[i][i]==0)
    {
      j=i;
      if(i<dim) do
      {
        ++j;
      } while (a.m[j][i]==0 && j!=dim);
      if (a.m[j][i]==0) ++end; else
      {
        for(k=1; k<=dim; ++k)  /* i. vrstici se pristeje j. vrstica */
        {
          a.m[i][k]+=a.m[j][k];
          /* Ista operacija se mora izvesti na inv.*/
          inv->m[i][k]+=inv->m[j][k];
        }
      }
      if (end) ++singular;
    }
    if (! end) for (j=1; j<=dim; j++)
    {
      if (a.m[j][i] !=0) if (j!=i)
      /* Pridelovanje nicel v i. stolpcu matrike a: */
      {
        x=a.m[j][i];
        for (k=1; k<=dim; ++k)
        {
          a.m[j][k]-=x*(a.m[i][k]/a.m[i][i]);
          /* Ustrezna operacija na inverzni matriki: */
          inv->m[j][k]-=x*(inv->m[i][k]/a.m[i][i]);
        }
        /* Od j. vrstice smo odsteli i., pomnozeno z a.m[j][i]/a.m[i][i]. */
      }
    }
  }
  if (singular) dispmat(inv); else
  {
    for (i=1; i<=dim; ++i)
      for (j=1; j<=dim; ++j)
        inv->m[i][j]/=a.m[i][i];
  }
  dispmat(&a);
} else initmat(inv);
/* printmat(inv); */
}





void squotmat1(matrix q, struct _matrix a, struct _matrix b)
       /* Vrne kvocient matrik (a inv(b)) v matriki q. */
{
struct _matrix i={0};
sinvmat1(&i,b);
sprodmat(q,a,i);
dispmat(&i);
}




/* Matricne funkcije za uporabo v matricnih enacbah. So hkrati preproste za
   uporabo (uporabljas jih lahko skoraj tako kot obicajne funkcije) in varne,
   kar se tice napak pri ravnanju s spominom: Ce matrika, v katero naj se zapise
   rezultat, ze obstaja, potem je ni treba brisati pred prireditvijo in se tudi
   ne brise znotraj funkcije same. edina neprijetnost teh funkcij je v tem, da
   moramo matriko, ki naj vsebuje rezultat operacije, navesti kot 1. parameter.
     PRIMERI:
   a=b*c zapisemo kot a=cprodmat(&a,b,c) ali kar cprodmat(&a,b,c).
   c=c*c zapisemo kot c=cprodmat(&c,c,c) ali cprodmat(&c,c,c).
   c=c*c*c zapisemo npr. kot cprodmat(&c,cprodmat(&c,c,c),c).
   c=a*(1/b) zapisemo lahko kot c=cprodmat(&c,a,cinvmat(&c,b)).
     POZOR!
   Pri uporabi teh funkcij je treba paziti na naslednje:
   Ce napisemo na primer a=cprodmat(&b,x,y) , si matriki a in b delita
   komponente (te so na istih spominskih lokacijah). Ce kdaj pozneje zbrisemo
   matriko a, se hkrati zbrise tudi matrika b, vendar nepravilno, ker ostanejo
   dimenziji ter kazalec na komponente razlicni od 0.
*/



struct _matrix cidentitymat(matrix mat, int n)
       /* Identicna matrika dimenzije n */
{
sidentitymat(mat,n);
return(*mat);
}



struct _matrix cprodmat(matrix res, struct _matrix m1, struct _matrix m2)
       /* produkt matrik m1 in m2 */
{
struct _matrix buf={0};
getmat(&buf,m1.d1,m2.d2);
sprodmat(&buf,m1,m2);
scopymat(res,buf);
dispmat(&buf);
return(*res);
}



struct _matrix ctimesmat(matrix res, struct _matrix m, double t)
       /* Produkt matrike m s stevilom t */
{
struct _matrix buf={0};
getmat(&buf,m.d1,m.d2);
stimesmat(&buf,m,t);
scopymat(res,buf);
dispmat(&buf);
return(*res);
}



struct _matrix csummat(matrix res, struct _matrix m1, struct _matrix m2)
       /* Vsota matrik m1 in m2 */
{
struct _matrix buf={0};
getmat(&buf,m1.d1,m1.d2);
ssummat(&buf,m1,m2);
scopymat(res,buf);
dispmat(&buf);
return(*res);
}



struct _matrix cdifmat(matrix res, struct _matrix m1, struct _matrix m2)
              /* Razlika matrik m1 in m2 */
{
struct _matrix buf={0};
getmat(&buf,m1.d1,m1.d2);
sdifmat(&buf,m1,m2);
scopymat(res,buf);
dispmat(&buf);
return(*res);
}




struct _matrix ctranspmat(matrix res, struct _matrix m)
       /* Transponirana matrika matrike m */
{
struct _matrix buf={0};
getmat(&buf,m.d2,m.d1);
stranspmat(&buf,m);
scopymat(res,buf);
dispmat(&buf);
return(*res);
}



struct _matrix cinvmat(matrix res, struct _matrix m)
       /* Inverzna matrika matrike m */
{
struct _matrix buf={0};
getmat(&buf,m.d1,m.d2);
sinvmat1(&buf,m);
scopymat(res,buf);
dispmat(&buf);
return(*res);
}




struct _matrix cquotmat(matrix res, struct _matrix m1, struct _matrix m2)
       /* Kvocient matrik m1 in m2 (m1/m2) */
{
struct _matrix buf={0};
getmat(&buf,m2.d1,m2.d2);
cinvmat(&buf,m2);
/*
squotmat1(&buf,m1,m2);
scopymat(res,buf);
dispmat(&buf);
return(*res);
*/
*res=cprodmat(res,m1,buf);
return(*res);
}



struct _matrix cinvmat1(matrix  inverse, struct _matrix m)
       /* Vrne inverzno matriko kvadratne matrike m */
{
struct _matrix a={0},inv={0};
double x;
int i,j,k,dim/*,sign=1*/;
char end=0,singular=0;
if (m.d1==m.d2 && m.d1>0  && m.m!=0)
{
  dim=m.d1;
  inv=identitymat(dim);
  initmat(&a);
  copymat(&a,&m);
  for (i=1; i<=dim; ++i)  /* Tvori se diagonalna matrika */
  {
    end=0;
    if(a.m[i][i]==0)
    {
      j=i;
      if(i<dim) do
      {
        ++j;
      } while (a.m[j][i]==0 && j!=dim);
      if (a.m[j][i]==0) ++end; else
      {
        for(k=1; k<=dim; ++k)  /* i. vrstici se pristeje j. vrstica */
        {
          a.m[i][k]+=a.m[j][k];
          /* Ista operacija se mora izvesti na inv.*/
          inv.m[i][k]+=inv.m[j][k];
        }
      }
      if (end) ++singular;
    }
    if (! end) for (j=1; j<=dim; j++)
    {
      if (a.m[j][i] !=0) if (j!=i)
      /* Pridelovanje nicel v i. stolpcu matrike a: */
      {
        x=a.m[j][i];
        for (k=1; k<=dim; ++k)
        {
          a.m[j][k]-=x*(a.m[i][k]/a.m[i][i]);
          /* Ustrezna operacija na inverzni matriki: */
          inv.m[j][k]-=x*(inv.m[i][k]/a.m[i][i]);
        }
        /* Od j. vrstice smo odsteli i., pomnozeno z a.m[j][i]/a.m[i][i]. */
      }
    }
  }
  if (singular) dispmat(&inv); else
  {
    for (i=1; i<=dim; ++i)
      for (j=1; j<=dim; ++j)
        inv.m[i][j]/=a.m[i][i];
  }
  dispmat(&a);
} else initmat(&inv);
/* printmat(inv); */
scopymat(inverse,inv);
dispmat(&inv);
return *inverse;
}




/* ============= LU dodatek ====================== */

void luordermat(vector scale,matrix a,int *order)
    /* funkcija pripravi vse potrebno za potrebe delnega pivotiranja. Vektor
    celih  stevil order se v funkciji le inicializira. V vektor scale pa se 
    shranijo scale faktorji.
      POZOR !!! Funkcijo izvrsimo vedno pred LU dekompozicijo.
    $A Tomsus feb97;  */
{
int i,j,n;
n=a->d1;
for(i=1;i<=n;i++)
  {
    order[i]=i;
    scale->v[i]=fabs(a->m[i][1]);
    for(j=2;j<=n;j++)
    {
      if(fabs(a->m[i][j]>scale->v[i]))
      scale->v[i]=fabs(a->m[i][j]);
    }
  }
}




void lupivot(vector scale,matrix a,int *order,int row)
    /* funkcija izvaja delno pivotiranje matrike glede na velikosti scale 
    faktorjev, ki jih izracuna funkcija luordermat. Nove pozicije vrstic 
    matrike a se shranijo v vektor celih stevil order.
    Funkcija je pomozna funkcija glavne dekompozicijske funkcije ludecompmat,
    ki po obdelavi posamezne vrstice row znova poisce pivota
    $A Tomsus feb97; */
{
int ii,n;
int pvt, idum;
double max,dum;
n=a->d1;
pvt=row;
max=fabs(a->m[order[row]][row]/scale->v[order[row]]);
for(ii=row+1;ii<n;ii++)
  {
    dum=fabs(a->m[order[ii]][row]/scale->v[order[ii]]);
    if (dum>max)
    {
      max=dum;
      pvt=ii;
    }
  }
idum=order[pvt];
order[pvt]=order[row];
order[row]=idum;
}




void ludecompmat(vector scale,matrix a, int *order)
    /* funkcija opravi LU dekompozicijo matrike a z Crautovim algoritmom.
    Funkcija izvaja delno pivotiranje za to potrebuje predhodno izracunani
    vektor scale faktorjev (vektor scale) in pa vektor celih stevil oreder
    v katerm je shranjena trenutna lega posamezne vrstice matrike a.
    Obe novo nastali matriki L in U shrani v matriko a. Matriko L 
    (lower matrix) sestavljajo elementi pod diagonalo.
    POZOR !!! pred klicem funkcije ludecompmat je zaradi potreb pivotiranja
    nujen klic funkcije luordermat.
    (POZOR !!! v originalni varianti ima matrika L vse diagonalne elemente 
    enake 1. Matriko U (upper matrix) pa sestavljajo elementi na 
    diagonali in nad njo )
    Primer dekompozicije matrike a :
      luordermat(scale,a,order);
      ludecompmat(scale,a,order);
    POZOR: Pri alokaciji order je potrebno alocirati eno mesto vec kot je
      dimenzija!
    $A Tomsus feb97; */
{
int i,j,k;
double sum;
int n;
n=a->d1;
j=1;
lupivot(scale,a,order,j);
for(j=2;j<=n;j++)
{
  a->m[order[1]][j]=a->m[order[1]][j]/a->m[order[1]][1];
}
for(j=2;j<=(n-1);j++)
  {
    for(i=j;i<=n;i++)
    {
      sum=0.0;
      for(k=1;k<=(j-1);k++)
      sum+=a->m[order[i]][k]*a->m[order[k]][j];
      a->m[order[i]][j]=a->m[order[i]][j]-sum;
    }
    lupivot(scale,a,order,j);
    for(k=(j+1);k<=n;k++)
    {
      sum=0.0;
      for(i=1;i<=(j-1);i++)
        sum+=a->m[order[j]][i]*a->m[order[i]][k];
      a->m[order[j]][k]=(a->m[order[j]][k]-sum)/a->m[order[j]][j];	  
    }      
  }
sum=0.0;
for(k=1;k<=(n-1);k++)
  sum+=a->m[order[n]][k]*a->m[order[k]][n];
a->m[order[n]][n]=a->m[order[n]][n]-sum;  
}




void lusolvemat(matrix a, vector b,vector x, int *order)
    /* Funkcija za resevanje sistema linearnih enacb s pomocjo LU-dekompozicije.
    Matrika a mora biti ze dekompozirana (Solve obicajno sledi klicu 
    ludecompmat(a) ). b je vektor konstant na desni strani enacbe. Resitev 
    sistema se shrani v vektor x. Zaradi delnega pivotiranja mora biti
    znan tudi trenutni polozaj vrstic v vektorju celih stevil order.
      Postopek za resevanje sistema A x = b
       luordermat(scale,a,order);
       ludecompmat(scale,a,order);
       lusolvemat(stress,b,x,order);   
    POZOR: Pri alokaciji order je potrebno alocirati eno mesto vec kot je
      dimenzija!
    $A Tomsus  feb97; */
{
double sum;
int i,j,n;
n=a->d1;
x->v[1]=b->v[order[1]]/a->m[order[1]][1];
for(i=2;i<=n;i++)
{
  sum=0.0;
  for(j=1;j<=(i-1);j++)
    sum+=a->m[order[i]][j]*x->v[j];
  x->v[i]=(b->v[order[i]]-sum)/a->m[order[i]][i];	
}
for(i=(n-1);i>=1;i--)
{
  sum=0.0;
  for(j=(i+1);j<=n;j++)
    sum+=a->m[order[i]][j]*x->v[j];
  x->v[i]=x->v[i]-sum;      
}
}



void luinvmat(matrix a,matrix inv,int *order)
    /* funkcija izracuna inverz ze dekompozirane matrike.
    Funkcija vrne inverzno matriko.
    Primer izracuna inverzne matrike inv  matrike a :
      ( inv = a^-1 )
      luordermat(scale,a,order);
      ludecompmat(scale,a,order);
      inv=luinvmat(a,order);
    POZOR: Pri alokaciji order je potrebno alocirati eno mesto vec kot je
      dimenzija!
    $A Tomsus feb97; */
{
int i,j,n;
vector col,tmp;
n=a->d1;
tmp=getvector(n);
col=getvector(n);
for(j=1;j<=n;j++)
{
  for(i=1;i<=n;i++)
    col->v[i]=0;
  col->v[j]=1;
  lusolvemat(a,col,tmp,order);
  for(i=1;i<=n;i++)
    inv->m[i][j]=tmp->v[i];
}
dispvec(col);
dispvec(tmp);
}



double ludetmat(matrix a,int *order)
    /* funkcija vrne vrednost determinante dekompozirane matrike a.
    Primer izracuna determinante matrike a:
      luordermat(scale,a,order);
      ludecompmat(scale,a,order);
      printf("det(A) = %f \n",ludetmat(a,order));
    POZOR: Pri alokaciji order je potrebno alocirati eno mesto vec kot je
      dimenzija!
    $A Tomsus feb97; */
{
int i,n;
double ret;
n=a->d1;
ret=1;
for(i=1;i<=n;i++)
  ret*=(a->m[order[i]][i]);
return ret;
}








void fprintmatrow(FILE *fp,matrix a)
    /* Funkcija izpise matriko v datoteko fp po vrsticah 
    Tomaz feb97; */
{
int i,j;
if (fp!=NULL)
{
  fprintf(fp,"matrix dimension : %i x %i \n",a->d1,a->d2);
  for(i=1;i<=(a->d1);i++)
  {
    for(j=1;j<=(a->d2);j++)
    {
      fprintf(fp,"[%i,%i] %.*g\t",i,j,m_outdig,a->m[i][j]);
    }
    fprintf(fp,"\n");
  }
}
}



void printmatrow(matrix a)
    /* Funkcija izpise matriko na zaslon fp po vrsticah 
    Tomaz feb97; */
{
fprintmatrow(stdout,a);
}
