

    /* PROGRAM ZA KODIRANJE DATOTEK IN NIZOV */



#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mtypes.h>
#include <st.h>
#include <strop.h>
#include <t_strop.h>
#include <fop.h>
#include <mtime.h>
#include <rf.h>
#include <er.h>
#include <globut.h>
#include <z.h>


static char *extendedfilename(char *name,char *dirext,char *fileext)
  
{
char *ret=NULL,*path=NULL,*file=NULL;
convertfilesyst(name);
path=fileminusfile(name);
file=fileminusfile(name);
ret=multdirplusmultfile(path,dirext,NULL,file,fileext,NULL);
disppointer((void **) &path);
disppointer((void **) &file);
return ret;
}

static void removesafe(char *filename)
    /* Removes file named filename. First it tries with the function remove,
    if not successfull, the system command is used.
    $A Igor jan03; */
{
char *com=NULL;
if (remove(filename))
{
  #ifdef DOSWN
   com=stringcat("del ",filename);
  #else
   com=stringcat("rm ",filename);
  #endif
  system(com);
  disppointer((void **) &com);
}
}

static void cls(void)
{
int i;
#ifdef UNIX
  system("clear");
#elif defined(DOSWN)
 system("cls");
#endif
for (i=1;i<=10;++i)
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
}


static char
    *decodestr="-d",    /* decode option */
    *keepstr="-keep",   /* keep original files after coding or decoding */
    *listfstr="-l",     /* file containing list of files to code or decode;
      file name command-line arguments, if any, specify which files should be
      chosen for codig or decoding amongst the files from the list file, if
      none, the all files from the file list are taken. */
    *listfastr="-l",    /* file containing list of files to code or decode,
      this list is appended by command-line arguments. */
    *addfilestr="-af",  /* add extension to encrypted files */
    *addpathstr="-ad",   /* add extension to enc. files path */
    *unarystr="-u",     /* each file transcripted to itself */
    *inspecstr="-is",   /* escape sequences in input */
    *outspecstr="-os",  /* escape sequences in output */
    *filespecstr="-os", /* escape sequences in output */
    *stringstr="-s",    /* code or dec. strings rather than files */
    *keystr="-k",       /* coding key follows */
    *codingstr="-c",    /* codig algorithm follows */
    *printlevstr="-p",  /* printing level follows (0 to 3) */
    *teststr="-t",      /* testing of encryption algorithms */
    *envstr="-env",     /* require print of environment */
    *helpstr1="-h",     /* help required */
    *helpstr2="-?";     /* help required */


static stack files=NULL,args=NULL;
static char *key=NULL,*testkey=NULL,*algorithm="default",*fl=NULL,
             *fileext=NULL,*pathext=NULL;
static int 
    code=1,      /* coding rather than decoding */
    pl=0,        /* print level */
    keep=0,      /* keep files or not */
    unary=0,     /* files transcripted to themselves */
    inspec=0,    /* contains escape sequences */
    outspec=0,   /* output contains special sequences */
    filespec=0;
    cstrings=0,  /* work on strings rather than on files */
    selfiles=0,  /* 1 if a file containing a file list is specified. */
    test=0,      /* 1 if testing should be performed */
    ntest=40;    /* Number of bytes for testing */



static void readfilesfromlist(char *listname,stack files)
    /* Reads a list of space separated files from the file named listname and
    pushes the names on the stack files, which must be allocated at the calll.
    $A Igor jan03; */
{
char *fstr=NULL,*ptr,*ptr1,*name=NULL;
int length,printlev=pl,pos;
fstr=filetostr(listname,&length);
if (length==0 || fstr==NULL)
{
  errfunc0("readfilesfromlist");
  sprintf(ers(),"Could not obtain a list of files from the file \"%s\".\n",listname);
  sprintf(ers(),"The file does not exist, is empty or is not readable.\n");
  errfunc2();
} else if (files==NULL)
{
  errfunc0("readfilesfromlist");
  sprintf(ers(),"The stack of file names is NULL.\n");
  errfunc2();
} else
{
  if (printlev>1)
    printf("\nExtracting the list of file names from the file \"%s\":\n  ",listname);
  ptr=fstr;
  m_strskipblanks(ptr);
  while(*ptr!='\0')
  {
    ptr1=ptr;
    if (*ptr1=='\"')
    {
      ++ptr1;
      pos=strchr1(ptr1,'\"');
      if (pos>=0)
        ptr1+=pos;
      else
        ptr1=NULL;
    } else
      m_strnextblank(ptr1);
    if (ptr1>ptr)
    {
      name=stringncopy(ptr,ptr1-ptr);
      /*
      ordinarystr(name,NULL,&name);
      convertfilesyst(name);
      */
      pushstack(files,name);
      if (printlev>1)
        printf("%s ",name);
    }
    ptr=ptr1;
    m_strskipblanks(ptr);
    if (printlev>1)
      printf("\n  ");
  }
}
disppointer((void **) &fstr);
}

static void printshorthelp(int argc,char *argv[])
    /* Print a short reminder for the program. argv must be a table of command
    - line arguments and argc their number
    $A Igor jan03; */
{
if (argc>0)
  printf("Usage:\n        %s [options] <file1, file2, file3...>\n\n",*argv);
else
  printf("Usage:\n        %s [options] <file1, file2, file3...>\n\n","program");
printf("Encrypts or decrypts files or strings.\n\n");
printf("Options:\n");
printf("-d:\n  decryption rather than encryption\n");
printf("-l listfile:\n  read filenames from listfile; file1, ... select from list\n");
printf("-la listfile:\n  read filenames from listfile; file1, ... add to list\n");
printf("-u:\n  copy result files to themselves\n");
printf("-is:\n  replace escape sequences in input prior to use\n");
printf("-os:\n  replace special characters by escape sequences prior to ourput results\n");
printf("-k key:\n  use key for encryption or description; read interactively by default\n");
printf("-c alg:\n  set encryption algorithm to alg\n");
printf("-p level:\n  set printing level (should be 0, 1, 2 or 3)\n");
/* printf("  -env var:     prints the value of the system environment variable var\n"); */
printf("  -h topic, -?:\n  launches help on topic, or program help if topic not specified\n");
printf("\nWhen decrypting files without -u, the second file of each pair is decrypted\n");
printf("to the first file (enables the same lists for encryption and decryption).");
printf("\n");
}

void interpretarguments(int numargs,char *argv[])
    /* Interprets command-line arguments.
    $A Igor jan03; */
{
int i;
int numnameargs=0; /* Number of arguments that doesn't specify oprions (file names or strings) */
char *arg=NULL,*arg1=NULL;
if (numargs<=2)
{
  printshorthelp(numargs,argv);
  exit(0);
} else for (i=1;i<=numargs-1;++i)
  {
    arg=argv[i];
    if (arg[0]!='-')
    {
      ++numnameargs;
      pushstack(args,stringcopy(arg));
      if (pl>3)
        printf("File \"%s\" added.\n",arg);
      if (numnameargs==1)  /* 1. argument, ki ne predstavlja opcije */
      {
        /* argument, ki predstavlja ime vhodne datoteke */
        /* com.commandfilename=stringcopy(arg); */
      }
    } else
    {
      if (cmpstrings(arg,decodestr)==0)
        code=0;  /* Decoding rather than coding */
      else if (cmpstrings(arg,keepstr)==0)
        keep=1;  /* Keep original files after coding or decoding */
      else if (cmpstrings(arg,unarystr)==0)
        unary=1;  /* Files transcripted to themselves */
      else if (cmpstrings(arg,inspecstr)==0)
        inspec=1;  /* Escape sequences used in input */
      else if (cmpstrings(arg,outspecstr)==0)
        outspec=1;  /* Escape sequences used in input */
      else if (cmpstrings(arg,filespecstr)==0)
        filespec=1;  /* Escape sequences used in input */
      else if (cmpstrings(arg,stringstr)==0)
        cstrings=1;  /* Work on strings rather than files  */
      else if (cmpstrings(arg,teststr)==0)
      {
        test=1;  /* Work on strings rather than files  */
        if (numargs-1>i)
        {
          int n;
          char *ptr;
          arg1=argv[i+1];
          n=strtol(arg1,&ptr,10);
          if (ptr>arg1)
          {
            ++i;  /* move to the next command-line argument */
            ntest=n;
          }
        }
      } else if (cmpstrings(arg,listfstr)==0)
      {
        /* The name of the file containing the list is specified as the following
        argument: */  
        if (numargs-1>i)
        {
          arg1=argv[i+1];
          if (arg1[0]!='-')
          {
            ++i;  /* move to the next command-line argument */
            readfilesfromlist(arg1,files);
            selfiles=1;
          } else
          {
            err0();
            sprintf(ers(),"File containing the list of files  should follow the command-line argument \"%s\"\n",arg);
            sprintf(ers(),"rather than a new option \"%s\".\n",arg1);
            err2();
            exit(-1);
          }
        } else
        {
          err0();
          sprintf(ers(),"File containing the list of files not specified\n");
          sprintf(ers(),"after command-line argument \"%s\".\n",arg);
          err2();
          exit(-1);
        }
      } else if (cmpstrings(arg,listfastr)==0)
      {
        /* The name of the file containing the list is specified as the following
        argument: */  
        if (numargs-1>i)
        {
          arg1=argv[i+1];
          if (arg1[0]!='-')
          {
            ++i;  /* move to the next command-line argument */
            readfilesfromlist(arg1,files);
            /* selfiles=1; */
          } else
          {
            err0();
            sprintf(ers(),"File containing the list of files  should follow the command-line argument \"%s\"\n",arg);
            sprintf(ers(),"rather than a new option \"%s\".\n",arg1);
            err2();
            exit(-1);
          }
        } else
        {
          err0();
          sprintf(ers(),"File containing the list of files not specified\n");
          sprintf(ers(),"after command-line argument \"%s\".\n",arg);
          err2();
          exit(-1);
        }
      } else if (cmpstrings(arg,addfilestr)==0)
      {
        /* Extension added to encrypted files: */  
        if (numargs-1>i)
        {
          arg1=argv[i+1];
          if (arg1[0]!='-')
          {
            ++i;  /* move to the next command-line argument */
            fileext=stringcopy(arg1);
            /* selfiles=1; */
          } else
          {
            err0();
            sprintf(ers(),"File extension for encrypted files should follow the command-line argument \"%s\"\n",arg);
            sprintf(ers(),"rather than a new option \"%s\".\n",arg1);
            err2();
            exit(-1);
          }
        } else
        {
          err0();
          sprintf(ers(),"File extension for encrypted files specified\n");
          sprintf(ers(),"after command-line argument \"%s\".\n",arg);
          err2();
          exit(-1);
        }
      } else if (cmpstrings(arg,addpathstr)==0)
      {
        /* Extension added to encrypted files: */  
        if (numargs-1>i)
        {
          arg1=argv[i+1];
          if (arg1[0]!='-')
          {
            ++i;  /* move to the next command-line argument */
            pathext=stringcopy(arg1);
            /* selfiles=1; */
          } else
          {
            err0();
            sprintf(ers(),"Path extension for encrypted files should follow the command-line argument \"%s\"\n",arg);
            sprintf(ers(),"rather than a new option \"%s\".\n",arg1);
            err2();
            exit(-1);
          }
        } else
        {
          err0();
          sprintf(ers(),"Path extension for encrypted files specified\n");
          sprintf(ers(),"after command-line argument \"%s\".\n",arg);
          err2();
          exit(-1);
        }
      } else if (cmpstrings(arg,keystr)==0)
      {
        /* The coding key is specified: */
        if (numargs-1>i)
        {
          arg1=argv[i+1];
          key=stringcopy(arg1);
          ++i;
        } else
        {
          err0();
          sprintf(ers(),"The key is not specified\n");
          sprintf(ers(),"after command-line argument \"%s\".\n",keystr);
          err2();
        }
      } else if (cmpstrings(arg,codingstr)==0)
      {
        /* The coding key is specified: */
        if (numargs-1>i)
        {
          arg1=argv[i+1];
          algorithm=stringcopy(arg1);
          ++i;
        } else
        {
          err0();
          sprintf(ers(),"The coding algorithm is not specified\n");
          sprintf(ers(),"after command-line argument \"%s\".\n",codingstr);
          err2();
        }
      } else if (cmpstrings(arg,printlevstr)==0)
      {
        /* The name of the file containing the list is specified as the following
        argument: */  
        if (numargs-1>i)
        {
          int n;
          char *ptr;
          arg1=argv[i+1];
          n=strtol(arg1,&ptr,10);
          if (ptr>arg1)
          {
            ++i;  /* move to the next command-line argument */
            pl=n;
          } else
          {
            err0();
            sprintf(ers(),"Printing level should follow the command-line argument \"%s\"\n",listfstr);
            sprintf(ers(),"rather than  \"%s\".\n",arg1);
            err2();
          }
        } else
        {
          err0();
          sprintf(ers(),"Printing level not specified after command-line argument \"%s\".\n",printlevstr);
          err2();
        }
      } else if (cmpstrings(arg,envstr)==0)
      {
        char *env,*var=NULL;
        int j;
        /* Vzamemo naslednji argument, ki predstavlja ime sistemske
        spremenljivke, in izpisemo vrednost te sistemske spremenljivke: */
        ++i;
        if (i>numargs-1)
        {
          /* Ni naslednjega argumenta, zato se izpisejo vse sistem.
          spremenljivke: */
          
          /*
          printf("\nSystem environment variables:\n\n");
          for (j=0; com.env[j]!=NULL;++j)
            printf("%s\n",com.env[j]);
          printf("\n\nProgram arguments (in quotes):\n");
          for (j=0;j<com.argc;++j)
            printf("\"%s\" ",com.argv[j]);
          printf("\n\n\n");
          */

          /* Ce je bil program klican le z 1 argumentom, ga ustavimo, da se ne
          izpise kaksno motece dodatno sporocilo: */
          if (numargs==2)
            exit(0);
        } else
        {
          /* Obstaja naslednji argument, ki je ime sistemske spremenljivke,
          katere vrednost naj se izpise; Izpisemo spremenljivko (ce ni
          definirana, poskusimo se kapitalizirati ime spremenljivke): */
          printf("\nValue of environment variable %s (in quotes):\n",argv[i]);
          printf("\"%s\"\n",env=getenv(argv[i]));
          if (env==NULL)
          {
            /* The variable is not defined, maybe we should have capitalized it: */
            var=stringcopy(argv[i]);
            for (j=0;j<(int) strlen(var);++j)
            {
              if (var!=NULL)
              {
                var[j]=toupper(var[j]);
                if ((env=getenv(var))!=NULL)
                {
                  printf("\nCapitalizing...\nValue of environment variable %s (in quotes):\n",var);
                  printf("\"%s\"\n",env);
                }
              }
            }
          }
          printf("\n\n\n");
          /* Ce je bil program klican le z 2 argumentoma, ga ustavimo, da se ne
          izpise kaksno motece dodatno sporocilo: */
          if (numargs==3)
            exit(0);
        }
      } else if (cmpstrings(arg,helpstr1)==0 || cmpstrings(arg,helpstr2)==0)
      {
        /* Vzamemo naslednji argument, ki predstavlja temo pomoci, in prikazemo
        pomoc na to temo, ce le-ta obstaja: */
        ++i;
        if (i>numargs-1)
        {
          globuthelpfirst("igcrypt");
        } else
        {
          globuthelpfirst(argv[i]);
        }
      } else
      {
        errfunc0("interpretarguments");
        sprintf(ers(),"Unknown command-line option \"%s\".\n",arg);
        errfunc2();
        printf("\nAbort: unknown option \"%s\".\n",arg);
        exit(-1);
      }
    }
  }
}



void proginit(void)
{
globutsetprogram("IGCrypt");
globutsetprog("igcrypt");
globutsetauthor("Igor Gresovnik");
globutsetauthormail("igor@c3m.si");
globutsetauthorad1("Crnece 147");
globutsetauthorad2("2370 Dravograd, Slovenia");
globutsetversion(0,1);
globutsetverspec("shareware");
globutsetcreationdate(CDD,CMM,CYY);
globutsetexpirationdate(10,10,5000);
globutsetwww("www.c3m.si/inverse/");
globutsetmail("igor@c3m.si");
globutinit(1,0,1);
}


int main(int argc,char **argv)
{
#ifdef IGTEST
int i,j,n,length;
char *file,*file1,*flags=NULL,sel,*name,*name1,*ts=NULL;
FILE *fp;
/* Initialisation: */
proginit();
files=newstack(20);
args=newstack(5);
/* Interpretation of the command-line arguments: */
interpretarguments(argc,argv);
/* Update dependencies of different options: */
if (fileext!=NULL || pathext!=NULL)
  unary=0;
/* Launch warnings when appropriate: */
if (inspec && code && !cstrings)
{
  warnfunc1(1,"main");
  sprintf(ers(),"Characters \\ will be treated as leading characters of escape sequences\n");
  sprintf(ers(),"in encrypted files.\n");
  sprintf(ers(),"Are you sure that special characters are represented by escape sequences\n  in the coded files?\n");
  warnfunc2();
  i=0;
  printf("Do you really want to treat the backslash characters ('\\')\n");
  printf("  in encrypted files as escape sequences (0/1)? ");
  readint(&i); printf("\n");
  if (!i)
  {
    printf("Abort for inappropriate treatment of coded files; run again and omit the \"%s\" option!\n",
      inspecstr);
    exit(-1);
  }
}
if (outspec && !code && !cstrings)
{
  warnfunc1(1,"main");
  sprintf(ers(),"Special characters will be replaced by escape sequences\n");
  sprintf(ers(),"in decrypted files.\n");
  sprintf(ers(),"Are you sure that you want special characters represented by escape sequences\n  in the decoded files?\n");
  warnfunc2();
  i=0;
  printf("Do you really want to replace special characters\n");
  printf("  by escape sequences in target (decoded) files (0/1)? ");
  readint(&i); printf("\n");
  if (!i)
  {
    printf("Abort for inappropriate treatment of decoded files; run again and omit he \"%s\" option!\n",
      outspecstr);
    exit(-1);
  }
}
if (algorithm=="i")
{
  if (cstrings)
    printf("\nIdentity coding (no encryption)!\n\n");
  else
  {
    warnfunc1(0,"main");
    sprintf(ers(),"Identity coding applies (no encryption or decryption).\n");
    warnfunc2();
  }
}
/* Set the coding alhorithm: */
setcodingdata(algorithm);
/* Get the key interactively if not specified: */
while(key==NULL)
{
  printf("\n\nCoding key: ");
  readstring(&key); cls();
  printf("\n\nRetype the coding key for test: ");
  readstring(&testkey); cls();
  if (cmpstrings(key,testkey))
  {
    err0();
    sprintf(ers(),"The key and the test do not match. Retype the key!\n");
  }
}
/* Test the encryption algorithm: */
if (cmpstrings(algorithm,"i"))
{
  /* Test if the algorithm is OK on a string containing all characters: */
  unsigned char *refstr,*teststr;
  int tl;
  refstr=malloc(256);
  for (i=1;i<=255;++i)
    refstr[i-1]=i;
  refstr[255]='\0';
  teststr=stringcopy(refstr);
  tl=stringlength(teststr);
  codestring(teststr,tl,key);
  if (!cmpstrings(refstr,teststr))
  {
    if (cstrings)
    {
      warnfunc1(1,NULL);
      sprintf(ers(),"Inappropriate encryption algorithm \"%s\" (performs no encryption).\n",algorithm);
      warnfunc2();
    } else
    {
      err0();
      sprintf(ers(),"Inappropriate encryption algorithm \"%s\" (performs no encryption).\n",algorithm);
      err2();
      printf("Abort: inappropriate encoding algorithm.\n\n");
      exit(-1);
    }
  }
  decodestring(teststr,tl,key);
  if (cmpstrings(refstr,teststr))
  {
    if (cstrings)
    {
      warnfunc1(1,NULL);
      sprintf(ers(),"Inappropriate encryption algorithm \"%s\" (decoding fails to restore the original).\n",algorithm);
      warnfunc2();
    } else
    {
      err0();
      sprintf(ers(),"Inappropriate encryption algorithm \"%s\" (decoding fails to restore the original).\n",algorithm);
      err2();
      printf("Abort: inappropriate decoding algorithm.\n\n");
      exit(-1);
    }
  }
  decodestring(teststr,tl,key);
}
/* Print a notice about what program will do: */
if (pl>0)
{
  if (code)
    printf("\nEncrypt");
  else
    printf("\nDecrypt");
  if (cstrings)
    printf(" strings.\n\n");
  else
  {
    printf(" files");
    if (args->n==0)
      printf(".\n\n");
    else
    {
      for (i=1;i<=args->n;++i)
      {
        if (unary || i==args->n)
        {
          if (i<args->n)
            printf(" %s,",args->s[i]);
          else
            printf(" %s",args->s[i]);
        } else
        {
          if (!code)
            ++i;
          if (i<args->n-1)
            printf(" %s,",args->s[i]);
          else
            printf(" %s",args->s[i]);
          if (code)
            ++i;
        }
      }
      printf(".\n\n");
    }
  }
}
/* Update the list of files or strings if appropriate: */
if (cstrings)
{
  while(args->n>0)
    pushstack(files,delstack(args,1));
} else
{
  if (pl>1)
    printf("Updating file names:\n");
  for (i=1;i<=files->n;++i)
  {
    if (pl>1)
      printf("  %s -> ",files->s[i]);
    if (filespec)
      ordinarystr(files->s[i],NULL,(char **) &(files->s[i]));
    convertfilesyst(files->s[i]);
    if (pl>1)
      printf("%s\n",files->s[i]);
  }
  if (pl>1 && args->n>0)
    printf("  ------ (from cmd args)\n");
  for (i=1;i<=args->n;++i)
  {
    if (pl>1)
      printf("  %s -> ",args->s[i]);
    if (filespec)
      ordinarystr(args->s[i],NULL,(char **) &(args->s[i]));
    convertfilesyst(args->s[i]);
    if (pl>1)
      printf("%s\n",args->s[i]);
  }
  if (pl>1)
    printf("\n");
  /* File names obtained through command-line arguments are added to the
  filenames on the stack files except if these names represent files that
  should be selected amongst the names on files: */
  if (!selfiles)
    while (args->n>0)
      pushstack(files,delstack(args,1));
  /* If extensions for transforming original filenames to encrypted filenames
  are provided, then update the file names so that each name of an original
  file on the stack files is supplemented by the name of its corresponding
  encrypted version by adding an extensions to the file name and path: */
  if (pathext!=NULL || fileext!=NULL)
  {
    i=1;
    while (files->n>=i)
    {
      insstack(files,extendedfilename(files->s[i],pathext,fileext),i+1);
      i+=2;
    }
  }
  /* Case when files on the stack args specify which files on the stack files
  should be selected for coding or decoding: */
  if (selfiles && args->n>0)
  {
    /* Take care that only pure file names are contained on args: */
    if (pl>1)
    {
      printf("\nSelecting files ");
      if (code)
        printf("to encrypt out of the list:\n");
      else
        printf("to decrypt out of the list:\n");
    }
    flags=calloc(1,args->n+i);  /* indicates which selections exist on files */
    for (i=1;i<=files->n;++i)
    {
      if (unary || i==files->n)
      {
        sel=0;
        for (j=1;j<=args->n;++j)
        {
          name=args->s[j];
          if (! cmpstringtails(name,files->s[i],stringlength(name)))
          {
            flags[j]=1;
            sel=1;
          }
        }
        if (sel)
        {
          if (pl>1)
            printf(">>  Selected: %s\n",files->s[i]);
        } else
        {
          if (pl>1)
            printf("    Excluded: %s\n",files->s[i]);
          name=delstack(files,i);
          disppointer((void **) &name);
          --i;
        }
      } else
      {
        sel=0;
        for (j=1;j<=args->n;++j)
        {
          name=args->s[j];
          if ( ! cmpstringtails(name,files->s[i],stringlength(name)) || 
               ! cmpstringtails(name,files->s[i+1],stringlength(name)) )
          {
            flags[j]=1;
            sel=1;
          }
        }
        if (sel)
        {
          if (pl>1)
            printf(">>  Selected: (%s, %s).\n",files->s[i],files->s[i+1]);
        } else
        {
          if (pl>1)
            printf("    Excluded: (%s, %s).\n",files->s[i],files->s[i+1]);
          name=delstack(files,i);
          name1=delstack(files,i);
          disppointer((void **) &name);
          disppointer((void **) &name1);
          --i;
          --i;
        }
        ++i;  /* Because files are treated in pairs */
      }
    }
    if (pl>1)
      printf("\n\n");
    disppointer((void **) &flags);
  }
}

if (files->n<1)  /* Check if any files or strings are specified: */
{
  err0();
  if (cstrings)
    sprintf(ers(),"No strings specified ");
  else
    sprintf(ers(),"No files specified ");
  if (code)
    sprintf(ers(),"for coding.\n");
  else
    sprintf(ers(),"for decoding.\n");
  err2();
} else
{
  /* Perform encryption or decryption on each string or file specified: */
  for (i=1;i<=files->n;++i)
  {
    if (!cstrings && !unary && !code && i<files->n)
      file=files->s[i+1];
    else
      file=files->s[i];
    if (cstrings)
    {
      /* Encryption or decryption performed on strings: */
      if (pl>1)
      {
        if (code)
          printf("  Encrypting");
        else
          printf("  Decrypting");
        printf(" %i. string \"%s\".\n  Result:\n",i,file);
      }
      if (inspec)
        ordinarystr(file,&length,&file);
      else
        length=stringlength(file);
      if (code)
      {
        if (test)
          printf("\nTEST:\nBefore coding:\n\"%s\"\n",file);
        codestring(file,length,key);
        if (test)
        {
          ts=stringncopy(file,length);
          printf("After coding:\n\"%s\"\n",ts);
          decodestring(ts,length,key);
          printf("After decoding:\n\"%s\"\n\n",ts);
          disppointer((void **) &ts);
        }
      } else
      {
        static int printed=0;
        if (test)
          printf("Test not available for decoding.\n");
        decodestring(file,length,key);
      }
      if (outspec)
        specseqstr(file,length,&file);
      printf("%s\n",file);
    } else
    {
      /* Encryption or decryption performed on files: */
      /* Get the target file: */
      if (unary || i==files->n)
      {
        if (!unary)
        {
          warnfunc1(1,"main");
          sprintf(ers(),"Source file \"%s\" does not have its target pair.\n",file);
          sprintf(ers(),"Output written to source file.\n");
          warnfunc2();
        }
        file1=files->s[i];
      } else
      {
        ++i;
        if (code)
          file1=files->s[i];
        else
          file1=files->s[i-1];  /* Decrypting, target and source are reversed */
      }
      if (pl>0)
      {
        if (code)
          printf("  Encrypting:");
        else
          printf("  Decrypting:");
        printf(" %s",file);
        if (!unary)
          printf(" -> %s",file1);;
        printf("\n");
      }
      /* Read the contents of the file and encrypt or decrypt it: */
      name=filetostr(file,&length);
      if (name==NULL || length<1)
      {
        if (!fileexists(file))
        {
          err0();
          sprintf(ers(),"File \"%s\" does not exist.\n",file);
          err2();
          continue;
        } else
        {
          warnfunc1(1,"main");
          sprintf(ers(),"File \"%s\" is empty or does not exist.\n",file);
          warnfunc2();
          /* continue; */;
        }
      } else
      {
        /* If necessary, convert escape sequences to special characters: */
        if (inspec)
          ordinarystr(name,&length,&name);
        if (code)
        {
          if (test)
          {
            ts=stringncopy(name,m_minval(length,ntest));
            printf("\nTEST: %i of %i bytes of the file:\nBefore coding:\n\"%s\"\n",
              m_minval(length,ntest),length,ts);
            disppointer((void **) &ts);
          }
          /* Encrypt file contents: */
          codestring(name,length,key);
          if (test)
          {
            ts=stringncopy(name,m_minval(length,ntest));
            printf("After coding:\n\"%s\"\n",ts);
            decodestring(ts,m_minval(length,ntest),key);
            printf("After decoding:\n\"%s\"\n\n",ts);
            disppointer((void **) &ts);
          }
        } else
        {
          static int printed=0;
          if (test)
            printf("Test not available for decoding.\n");
          /* Decrypt file contents: */
          decodestring(name,length,key);
        } 
        if (outspec)
          specseqstr(name,length,&name);
      }
      fp=fopen(file1,"wb");
      if (fp==NULL)
      {
        errfunc0("main");
        sprintf(ers(),"Destination file \"%s\" can not be open for writing.\n",file1);
        if (!keep || unary)
          sprintf(ers(),"Source file \"%s\" is kept in the original form.\n",file);
        errfunc2();
      } else
      {
        n=filewrite(name,1,length,fp,1);
        fclose(fp);
        if (n==length)
        {
          if (!keep && !unary && cmpstrings(file,file1))
          {
            if (! remove(file))
            {
              if (pl>0)
                printf("File \"%s\" removed.\n",file);
            } else
            {
              warnfunc1(1,"main");
              sprintf(ers(),"File \"%s\" could not be deleted.\n",file);
              sprintf(ers(),"Try to delete it manually!\n");
              warnfunc2();
              removesafe(file);
            }
          }
        } else
        {
          errfunc0("main");
          sprintf(ers(),"Only %i of %i bytes could be written to target file \"%s\".",
            n,length,file1);
          if (!keep && !unary)
            sprintf(ers(),"The source file \"%s\" is not deleted.\n",file);
          if (unary)
            sprintf(ers(),"Check if the file is damaged!\n");
          errfunc2();
        }
      }
    }
  }
  if (files->n>0)
    printf("\n");
}
if (pl>2)
  globutprogtitle(NULL,8);
  
#else  /* defined IGTEST */
 err0();
 sprintf(ers(),The programme was not compiled with IGTEST macro defined!\n");
 err2();
#endif /* not defined IGTEST */
}




#if 0
static stack files=NULL,args=NULL;
static char *key=NULL,*testkey=NULL,*algorithm="default",*fl=NULL;
int code=1,      /* coding rather than decoding */
    pl=0,        /* print level */
    keep=0,      /* keep files or not */
    unary=0,     /* files transcripted to themselves */
    inspec=0,    /* contains escape sequences */
    outspec=0,   /* output contains special sequences */
    cstrings=0;    /* work on strings rather than on files */
# endif





