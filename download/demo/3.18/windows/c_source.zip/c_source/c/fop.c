

          /*********************************/
          /*                               */
          /*  FILE MANIPULATION UTILITIES  */
          /*                               */
          /*********************************/


#include <sysint.h>

#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>



#include <er.h>


#include <mtypes.h>
#include <strop.h>
#include <st.h>
#include <itk.h>
#include <mtime.h>
#include <udir.h>   /* only because of getpwdstring */

#include <fop.h>





/* GUIDLINES: manipulation of file names and interaction with the filesystem
  Function should be such that they give correct results with either path names
containing native or non-native file path separators (i.e. both / or \). If
necessary, internal conversions should be made when necessary. The overhead of
the CPU time spent for this should not be a limiting factor for these functions,
since any interaction with the file system is usually much slover than simple
name conversions.
  Eventual preliminary conversions of path strings should levave the input
arguments intouched, although not declared as constant.
  Output file and directory names should always be expressed in the form native
to the operating system (e.g. with backslash path separators on MS Windows).
Result strings that represent directory names should always end with a path
separator.
*/


/* MANIPULATION OF FILE NAMES */


#if defined(UNIX)
  static char pathsep=    '/';
  static char *strpathsep="/";
#elif defined(DOSWN)
  static char pathsep=    '\\';
  static char *strpathsep="\\";
#else
  static char pathsep=    '/';
  static char *strpathsep="/";
#endif

char filepathseparator(void)
    /* Returns file path separator for current operating system.
    $A Igor jan02; */
{
return pathsep;
}

void replacepathseparators(char *path,char separator,char targetseparator)
    /* Replaces all occurences of separator in path name path by
    targetseparator.
    $A Igor jan02; */
{
int i,l;
l=stringlength(path);
for (i=0;i<l;++i)
  if (path[i]==separator)
    path[i]=targetseparator;
}

void changepathseparators(char *path,char targetseparator)
    /* Changes all occurences of file system's path separator in path name
    path by character targetseparator.
    $A Igor jan02; */
{
int i,l;
l=stringlength(path);
for (i=0;i<l;++i)
  if (path[i]==pathsep)
    path[i]=targetseparator;
}

void updatepathseparators(char *path,char separator)
    /* Changes all occurences of character separator in path name path by
    system's native path separator.
    $A Igor jan02; */
{
int i,l;
l=stringlength(path);
for (i=0;i<l;++i)
  if (path[i]==separator)
    path[i]=pathsep;
}


void convertfilesyst(char *file)
    /* Changes non-native path separators, if present, to the native system
    path separators (e.g. / to \ on Windows and vice versa on UNIX).
    $A Igor avg01; */
{
int i;
if (file!=NULL)
{
  #ifdef DOSWN
    for (i=0;i<(int) strlen(file);++i)
      if (file[i]=='/')
        file[i]='\\';
  #else
    for (i=0;i<(int) strlen(file);++i)
      if (file[i]=='\\')
        file[i]='/';
  #endif
}
}


void cleanpathname(char **pathaddr)
    /* Cleans the path name *pathaddr, i.e. changes path separators to the
    system path separator and removes unnecessary things like /./ and /../.
    If pathaddr or *pathaddr is NULL, the function does nothing.
    $A Igor apr04; */
{
char *path=NULL,*ptr;
#ifdef DOSWN
  static char *cur="\\.\\";
  static char *par="\\..\\";
  static int lengthcur=3;
  static int lengthpar=4;
#elif defined(UNIX)
  static char *cur="/./";
  static char *par="/../";
  static int lengthcur=3;
  static int lengthpar=4;
#else
  static char *cur="/./";
  static char *par="/../";
  static int lengthcur=3;
  static int lengthpar=4;
#endif
if (pathaddr!=NULL)
{
  path=*pathaddr;
  if (path!=NULL)
  {
    convertfilesyst(path);
    ptr=path;
    while (*path!='\0')
    {
      *ptr=*path;
      ++ptr;
      if (!strncmp(path,cur,lengthcur))
        path+=lengthcur;
      /*
      else if (!strncmp(path,par,lengthpar))
        path+=lengthpar;
      */
      else
        ++path;
    }
    *ptr=*path;
  }
}
}


char *filenameext(char *name)
    /* Returns pointer to file name extension (inclusive .) of name.
    If there is no dot before the first /, \ or native path separator,
    NULL is returned.
    $A Igor apr04l */  
{
char *ret;
if (name!=NULL)
{
  ret=name+strlen(name);
  while (! (*ret=='\\' || *ret=='/' || *ret=='.' || ret<=name
            || *ret==filepathseparator()))
    --ret;
  if (*ret!='.')
    ret=NULL;
} else
  ret=NULL;
return ret;
}




char *dirplusfile(char *dir,char *file)
    /* Returns the name of the file, which is composed of the directory name
    dir and the file name file. file may contain a relative path composed of
    several directory names spearated by path separators. A path separator is
    inserted between dir and file when necessary. The function can be used
    equally well for composing directory names - just the sevond name must be
    the directory name.
      The returned string is dynamically allocated.
    $A Igor sep98; */
{
char *ret=NULL,*str;
if (dir!=NULL)
  if (*dir!='\0')
  {
    if (dir[strlen(dir)-1]==pathsep)
      ret=stringcat(dir,file);
    else
    {
      str=stringcat(dir,strpathsep);
      ret=stringcat(str,file);
      free(str);
    }
  }
if (ret==NULL)
{
  /* Ce je bil direktorij NULL ali prazen niz, se vrne kopija imena datoteke: */
  ret=stringcopy(file);
} 
return ret;
}


char *multdirplusfile(char *first,...)
    /* Vrne ime datoteke, ki je sestavljeno iz imen vsebovanih direktorijev od
    direktorija first naprej in imena datoteke, ki je zadnji argument razlicen
    od NULL. Funkcija vrne alociran niz. Ce so vsi argumenti prazni nizi ali
    NULL, vrne funkcija NULL. Funkcija vrine med posameznimi argumenti
    separatorje datotecnih imen, ce je to potrebno (tj. ce separatorji niso ze
    vkljuceni na zacetku ali na koncu imen). Ce sta zadnji znak dolocenega
    argumenta in prvi naslednjega separatorja, se namesto njiju vrine en sam
    separator. Prazni nizi se ignorirajo. Ce je na koncu zadnjega argumenta, ki
    ni NULL, separator, se le-ta obdrzi (torej vrnjeno ime predstavlja
    datoteko). Prvi argument, ki je NULL, zakljuci serijo imen, ki sestavljajo
    vrnjeno ime.
     Pravila so ista kot pri multdirplusmultfile(), le da je le ena skupina
    sestavnih delov imena in vedno zadnji niz razlicen od NULL predstavlja
    ime datoteke.
    $A Igor jan02; */
{
int j,length=0,length1,length2,l,numargs,num;
char *arg=first,*ret=NULL,*ptr,lastpathsep=0;
va_list ap;
/* Najprej prestejemo argumente, ki niso NULL: */
numargs=0;
va_start(ap,first);
arg=first;
while(arg!=NULL)
{
  ++numargs;
  arg=va_arg(ap,char *);
}
/* Preverjanje dolzine za pot: */
va_start(ap,first);
arg=first;
num=1;
length=0;
while(num<numargs)
{
  ++num;
  l=strlen(arg);
  if (l>0)
  {
    if (length>0 && *arg==pathsep)
    {
      /* Ce to ni prvi neprazni argument, se morebitni separator na zacetku
      ne uposteva, ker bomo sami poskrbeli za vrivanje separatorja med tem in
      naslednjim imenom: */
      ++arg;
      --l;
    }
    /* Ce je zadnji znak separator, se ne uposteva, ker sami poskrbimo za
    vrivanje separatorjev; Izjema je, ce je to prvi neprazni argument
    in vsebuje le en ali dva separatorja: */
    if (l>0)
      if (arg[l-1]==pathsep)
      {
        --l;
        if (l==0 && length==0)
          ++length;
      }
    /* Dodamo dolzino tega niza + 1 za path sep. za tem nizom: */
    if (l>0)
      length+=l+1;   
  }
  arg=va_arg(ap,char *);
}
length1=length;  /* dolzina sestavljene poti s separatorjem na koncu */
/* Preverjanje dolzine imena */
/* arg=argprev; */
length2=0;
if (arg!=NULL)
{
  l=strlen(arg);
  /* Preverimo, ce je prvi znak separator, ki se v tem primeru ne uposteva,
  ce je podana tudi pot, saj vse separatorje doda funkcija sama: */
  if (length2==0 && l>0 && *arg==pathsep && length1>0)
  {
    ++arg;
    --l;
  }
  length2+=l;
}
length+=length2;
if (length>0)
{
  ret=malloc(length+1); /* 1 char. for ending '\0' */
  ret[length]='\0';
  ptr=ret;
  va_start(ap,first);
  arg=first;
  /* argprev=NULL; */
  /* Prepisovanje delov poti: */
  length=0;
  num=1;
  while (num<numargs)
  {
    ++num;
    l=strlen(arg);
    if (l>0)
    {
      if (length>0 && *arg==pathsep)
      {
        /* Ce to ni prvi neprazni argument, se morebitni separator na zacetku
        ne uposteva, ker bomo sami poskrbeli za vrivanje separatorja med tem in
        naslednjim imenom: */
        ++arg;
        --l;
      }
      /* Ce je zadnji znak separator, se ne uposteva, ker sami poskrbimo za
      vrivanje separatorjev; Izjema je, ce je to prvi neprazni argument in
      vsebuje le en ali dva separatorja: */
      if (l>0)
        if (arg[l-1]==pathsep)
        {
          --l;
          if (l==0 && length==0)
          {
            *ptr=pathsep;
            ++ptr;
            ++length;
          } 
        }
      if (l>0)
      {
        for (j=0;j<l;++j)
        {
          *ptr=arg[j];
          ++ptr;
        }
        /* Doda se se separator: */
        *ptr=pathsep;
        ++ptr;
        length+=l+1;
      }
    }
    arg=va_arg(ap,char *);
  }
  if (length!=length1)
  {
    errfunc0("multdirplusfile");
    sprintf(ers(),"Bug in the function:\n");
    sprintf(ers(),"Actual length of the path part (%i) different from calculated length (%i).\n",
      length,length1);
    errfunc2();
    length1=length;
  }
  /* arg=va_arg(ap,char *); */
  /* Prepisovanje delov imena: */
  length=0;
  if (arg!=NULL)
  {
    l=strlen(arg);
    /* Ce je to prvi neprazni argument v skupini, preverimo, ce je njegov prvi
    znak separator, ki se v tem primeru ne uposteva, ce je dolzina poti
    vecja od 0: */
    if (length==0 && l>0 && *arg==pathsep && length1>0)
    {
      ++arg;
      --l;
    }
    length+=l;
    for (j=0;j<l;++j)
    {
      *ptr=arg[j];
      ++ptr;
    }
    /* arg=va_arg(ap,char *); */
  }
  if (length!=length2)
  {
    errfunc0("multdirplusfile");
    sprintf(ers(),"Bug in the function:\n");
    sprintf(ers(),"Actual length of the path part (%i) different from calculated length (%i).\n",
      length,length2);
    errfunc2();
    length2=length;
  }
  ret[length1+length2]='\0';
}
return ret;
}




char *multdirplusmultfile(char *first,...)
    /* Vrne ime datoteke, ki je sestavljeno iz imen vsebovanih direktorijev od
    direktorija first do prvega argumenta, ki je NULL, ter iz sledecih delov
    imena datoteke do prvega naslednjega argumenta, ki jhe NULL. Med deli imena
    direktorijev vrine separator, ce je to potrebno (t.j. ce ni ze zadnji znak
    nekega dela ali prvi znak naslednjega dela enak separatorju; ce sta oba
    enaka separatorju za datotec. imena, se enega spusti). Med deli imena
    datoteke ne vriva nicesar. Ce so vsi argumenti prazni nizi ali NULL, vrne
    funkcija NULL, tudi drugace funkcija ignorira prazne nize. Ce je na koncu
    zadnjega argumenta, ki ni NULL, separator, se le-ta obdrzi (torej vrnjeno
    ime predstavlja direktorij). Prvi argument, ki je NULL, zakljuci serijo 
    delov, ki sestavljajo pot, drugi del pa serijo delov, ki sestavljajo ime
    datoteke. Funkcija vrine separator tudi med deli, ki sestavljajo pot (ime
    direktorija) in deli, ki sestavljajo ime datoteke, ce je to potrebno (oz.
    enega odstrani, ce je separator hkrati na koncu poti in na zacetku imena).
      Vrnjeno ime je potrebno brisati (npr. s free()).
      PRIMERI:
    Na Unixu vrne
     multdirplusmultfile("/home","users/igor/","/d",NULL,"readme",".txt",NULL)
    ime "/home/users/igor/d/readme.txt". Niz "/d" bi bil lahko tudi "/d/",
    "readme" pa "/readme", pa bi bil rezultat isti.
     multdirplusmultfile("c",NULL,"a",".c",NULL)
    vrne "c/a.c", enako tudi multdirplusmultfile("c/",NULL,"/a",".c",NULL) .
     multdirplusmultfile("/c",NULL,"a",".c",NULL)
    vrne "/c/a.c".
     multdirplusmultfile("",NULL,"a",".c",NULL)
    vrne "a.c" - na zacetku ni separatorja, ker je skupna dolzina delov, ki
    predstavljajo pot, enaka 0.
     multdirplusmultfile("","/home","","//","/","igor",NULL,"a",".c",NULL)
    vrne "/home/igor/a.c", ravno tako
     multdirplusmultfile("/home","","igor",NULL,"a",".c",NULL) ,
    ker se deli dolzine niz ne upostevajo in ker se pri sestavljanju poti
    steje, da imata "/" in "//" dolzino 0, razen ce je to prvi neprazni niz,
    ki sestavlja pot.
     multdirplusmultfile("/","home","","igor",NULL,"a",".c",NULL)
    vrne "/home/igor/a.c", ker se "/" uposteva, ce je to prvi neprazni niz, ki
    sestavlja pot.
      POZOR:
      Paziti je treba, da sta vsaj dva argumenta enaka NULL, od tega zadnji,
    saj se le tako zakljuci branje argumentov. Paziti je tudi treba, da ni kak
    niz, ki naj bi bil sestavni del poti ali imena, NULL, ker to ustavi
    sestavljanje poti oz. imena.
    $A Igor jan03; */
{
int j,length=0,length1,length2,l;
char *arg=first,*ret=NULL,*ptr,lastpathsep=0,reporterror=0;
va_list ap;
va_start(ap,first);
arg=first;
/* Preverjanje dolzine za pot: */
while(arg!=NULL)
{
  l=strlen(arg);
  if (l>0)
  {
    if (length>0 && *arg==pathsep)
    {
      /* Ce to ni prvi neprazni argument, se morebitni separator na zacetku
      ne uposteva, ker bomo sami poskrbeli za vrivanje separatorja med tem in
      naslednjim imenom: */
      ++arg;
      --l;
    }
    /* Ce je zadnji znak separator, se ne uposteva, ker sami poskrbimo za
    vrivanje separatorjev; Izjema je, ce je to prvi neprazni argument
    in vsebuje le en ali dva separatorja: */
    if (l>0)
      if (arg[l-1]==pathsep)
      {
        --l;
        if (l==0 && length==0)
          ++length;
      }
    /* Dodamo dolzino tega niza + 1 za path sep. za tem nizom: */
    if (l>0)
      length+=l+1;   
  }
  arg=va_arg(ap,char *);
}
length1=length;  /* dolzina sestavljene poti s separatorjem na koncu */
arg=va_arg(ap,char *);
length2=0;
/* Preverjanje dolzine imena */
while (arg!=NULL)
{
  l=strlen(arg);
  /* Ce je to prvi neprazni argument v skupini, preverimo, ce je njegov prvi
  znak separator, ki se v tem primeru ne uposteva, saj vse separatorje doda
  funkcija sama: */
  if (length2==0 && l>0 && *arg==pathsep && length1>0)
  {
    ++arg;
    --l;
  }
  if (length2>0 && l>0 && *arg==pathsep)
  {
    /* Prvi znak neprvega sestavnega dela imena je separator, zato javimo
    napako: */
    errfunc0("multdirplusmultfile");
    sprintf(ers(),"Inappropriate part of the file name \"%s\":\n",arg);
    sprintf(ers(),"Not the first part, but begins with the path separator.\n");
    errfunc2();
    reporterror=1;
  }
  length2+=l;
  arg=va_arg(ap,char *);
}
length+=length2;
if (length>0)
{
  ret=malloc(length+1); /* 1 char. for ending '\0' */
  ret[length]='\0';
  ptr=ret;
  va_start(ap,first);
  arg=first;
  /* argprev=NULL; */
  /* Prepisovanje delov poti: */
  length=0;
  while (arg!=NULL)
  {
    l=strlen(arg);
    if (l>0)
    {
      if (length>0 && *arg==pathsep)
      {
        /* Ce to ni prvi neprazni argument, se morebitni separator na zacetku
        ne uposteva, ker bomo sami poskrbeli za vrivanje separatorja med tem in
        naslednjim imenom: */
        ++arg;
        --l;
      }
      /* Ce je zadnji znak separator, se ne uposteva, ker sami poskrbimo za
      vrivanje separatorjev; Izjema je, ce je to prvi neprazni argument in
      vsebuje le en ali dva separatorja: */
      if (l>0)
        if (arg[l-1]==pathsep)
        {
          --l;
          if (l==0 && length==0)
          {
            *ptr=pathsep;
            ++ptr;
            ++length;
          } 
        }
      if (l>0)
      {
        for (j=0;j<l;++j)
        {
          *ptr=arg[j];
          ++ptr;
        }
        /* Doda se se separator: */
        *ptr=pathsep;
        ++ptr;
        length+=l+1;
      }
    }
    arg=va_arg(ap,char *);
  }
  if (length!=length1)
  {
    errfunc0("multdirplusmultfile");
    sprintf(ers(),"Bug in the function:\n");
    sprintf(ers(),"Actual length of the path part (%i) different from calculated length (%i).\n",
      length,length1);
    errfunc2();
    length1=length;
  }
  arg=va_arg(ap,char *);
  /* Prepisovanje delov imena: */
  length=0;
  while (arg!=NULL)
  {
    l=strlen(arg);
    /* Ce je to prvi neprazni argument v skupini, preverimo, ce je njegov prvi
    znak separator, ki se v tem primeru ne uposteva, ce je dolzina poti
    vecja od 0: */
    if (length==0 && l>0 && *arg==pathsep && length1>0)
    {
      ++arg;
      --l;
    }
    length+=l;
    for (j=0;j<l;++j)
    {
      *ptr=arg[j];
      ++ptr;
    }
    arg=va_arg(ap,char *);
  }
  if (length!=length2)
  {
    errfunc0("multdirplusmultfile");
    sprintf(ers(),"Bug in the function:\n");
    sprintf(ers(),"Actual length of the path part (%i) different from calculated length (%i).\n",
      length,length2);
    errfunc2();
    length2=length;
  }
  ret[length1+length2]='\0';
}
if (reporterror)
{
  errfunc0("multdirplusmultfile");
  sprintf(ers(),"Inappropriate parts of the file name encountered (not repaired).\n");
  sprintf(ers(),"  Composed name: \"%s\"\n",ret);
  errfunc2();
  reporterror=1;
}
return ret;
}


char *fileminusdir(char *file)
    /* Iz imena datoteke file izlusci in vrne samo ime datoteke brez
    direktorijev. Ime, ki ga vrne, lahko brisemo s free().
    $A Igor sep98; */
{
char *ret=NULL;
int i;
if (file!=NULL)
  if (*file!='\0')
  {
    #ifdef DOSWN
      i=strlen(file)-1;
      while(i>=0 && file[i]!=pathsep && file[i]!=':')
        --i;
      ret=stringcopy(&(file[i+1]));
      if (ret!=NULL)
        if (*ret=='\0')
        {
          free(ret);
          ret=NULL;
        }
    #else
      i=strlen(file)-1;
      while(i>=0 && file[i]!=pathsep)
        --i;
      ret=stringcopy(&(file[i+1]));
      if (ret!=NULL)
        if (*ret=='\0')
        {
          free(ret);
          ret=NULL;
        }
    #endif
  }
return ret;
}



char *fileminusfile(char *file)
    /* Iz imena datoteke file izlusci ime direktorija, v katerem je datoteka
    (t.j. 1. del imena z ustreznimi zakljucnimi znaki). Ce je file ime
    direktorija in se zakljuci z '/' oz. '\\' v DOSu, vrne funkcija kar to ime,
    ce pa je to ime direktorija, ki se ne zakljuci s tem znakom, vrne funkcija
    ime enega direktorija nizje.
    $A Igor sep98 jan03; */
{
char *ret=NULL;
int i;
if (file!=NULL)
  if (*file!='\0')
  {
    #ifdef DOSWN
      i=strlen(file);
      while(i>0 && file[i-1]!=pathsep && file[i-1]!='/' && file[i-1]!=':')
        --i;
      if (i>0)
        ret=stringncopy(file,i);
    #else
      i=strlen(file);
      while(i>0 && file[i-1]!=pathsep)
        --i;
      if (i>0)
        ret=stringncopy(file,i);
    #endif
  }
/*
if (stringlength(ret)<1)
{
  if (ret!=NULL)
    free (ret);
  #ifdef DOSWN
   ret=stringcopy(".\\");
  #else 
   ret=stringcopy("./");
  #endif
}
*/
return ret;
}


char *parentdir(char *file)
    /* Returns parent directory of path. If path is a file name , name of the
    directory that would containin the file is returned. If path is a directory
    name, name of its parent directory that would contain this directory is
    returned. It is not necessary that either path or the returned directory
    exists. Name returned by this function must be deallocated when not used
    any more (e.g. by free()).
      file is a directory name if it ends with a path separator and is a file
    name otherwise. Difference with fileminusfile() is that when file ia a
    directory name, fileminusfile() returns file itself, but parentdir returns
    one level lower directory.
    $A Igor jan03; */
{
char *ret=NULL;
int i;
if (file!=NULL)
  if (*file!='\0')
  {
    #ifdef DOSWN
      i=strlen(file);
      if (i>0)
        if (file[i-1]==pathsep)
          --i;
      while(i>0 && file[i-1]!=pathsep && file[i-1]!=':')
        --i;
      if (i>0)
        ret=stringncopy(file,i);
    #else
      i=strlen(file);
      if (i>0)
        if (file[i-1]==pathsep)
          --i;
      while(i>0 && file[i-1]!=pathsep)
        --i;
      if (i>0)
        ret=stringncopy(file,i);
    #endif
  }
return ret;
}


char *pathvolume(char *path)
    /* Returns the volume (i.e. the root point of the file system) in which the
    given path is contained. On Unix this is always "/". On Windows, if the
    path is for example "c:\windows", then the function returns "c:\". The path
    does not need to be a path of an existent file or directory. The returned
    string is dynamically allocated and can be deallocated by free().
    $A Igor apr03; */
{
int i=0;
char *ret=NULL;
if (stringlength(path)==0)
  return NULL;
else
{
  while (path[i]!='/' && path[i]!='\\' && path[i]!='\0' &&
    path[i]!=pathsep)
    ++i;
  if (path[i-1]=='\0')
  {
    ret=stringncopy(path,i);
    stringappend(&ret,strpathsep);
  } else
    ret=stringncopy(path,i+1);
  return ret;
}
}


char *filesystemroot(void)
    /* Returns the system root, i.e. the root directory of the drive on which
    the operatind system is located ("/" on UNIX or for example "c:\\" on
    Windows). This information can be used as a starting point for searching
    for a given information stored at the agreed locations.
      The returned string is dynamically allocated.
     $A Igor apr03; */
{
#ifdef UNIX
  return stringcopy("/");
#elif defined(DOSWN)
  char *sd=NULL,*sysdrive=NULL;
  int retry=1;
  sd=getenv("WINDIR");
  if (sd!=NULL)
  {
    sysdrive=pathvolume(sd);
    if (!direxists(sysdrive))
      disppointer((void **) &sysdrive);
    sd=NULL;
  }
  /* Need to consider if it is OK to check also the TEMP and TMP variables!
  if (sysdrive==NULL)
  {
    sd=getenv("TEMP");
    if (sd!=NULL)
    {
      sysdrive=pathvolume(sd);
      if (!direxists(sysdrive))
        disppointer((void **) &sysdrive);
      sd=NULL;
    }
    if (sysdrive==NULL)
    {
      sd=getenv("TMP");
      if (sd!=NULL)
      {
        sysdrive=pathvolume(sd);
        if (!direxists(sysdrive))
          disppointer((void **) &sysdrive);
        sd=NULL;
      }
    }
  }
  */
  if (sysdrive==NULL)
  {
    /* Try to obtain a valid drive through the tmpnam() standard library
    function: */
    sd=stringcopy(tmpnam(NULL));
    sysdrive=pathvolume(sd);
    disppointer((void **) &sd);
    if (!direxists(sysdrive))
      disppointer((void **) &sysdrive);
  }
  if (sysdrive==NULL)
  {
    errfunc0("filesystemroot");
    sprintf(ers(),"Can not locate the system drive automatically.\n");
    errfunc2();
  }
  while (sysdrive==NULL && retry)
  {
    sd=NULL;
    printf("\n\nPlease insert the system drive such as \"C:\", but without the quotes!");
    printf("\nSystem drive: ");  readstring(&sd);
    sysdrive=pathvolume(sd);
    if (!direxists(sysdrive))
    {
      printf("\nYou inserted \"%s\", but it seems that the directory  \n\"%s\" is not accessible.\n",
        sd,sysdrive);
      printf("You can choose a different hard drive for which you have\n  the appropriate permissions!");
      printf("\nWill you try to insert a different drive (0/1)? ");
      readint(&retry);
      disppointer((void **) &sysdrive);
    }
    disppointer((void **) &sd);
  }
  if (sysdrive==NULL)
  {
    errfunc0("filesystemroot");
    sprintf(ers(),"Could not locate the file system root or the system drive on this computer.");
  }
  return sysdrive;
#else
  char *sd=NULL,*sysdrive=NULL;
  int retry=1;
  /* Try to obtain a valid drive through the tmpname() standard library
  function: */
  sd=stringcopy(tmpnam(NULL));
  sysdrive=pathvolume(sd);
  disppointer((void **) &sd);
  if (!direxists(sysdrive))
    disppointer((void **) &sysdrive);
  if (sysdrive==NULL)
  {
    errfunc0("filesystemroot");
    sprintf(ers(),"Can not locate the file system root or the system drive on your computer.\n");
    errfunc2();
  }
  while (sysdrive==NULL && retry)
  {
    sd=NULL;
    printf("\n\nPlease insert the system drive such as \"C:\" or \"/\", but without the quotes!");
    printf("\nSystem drive: ");  readstring(&sd);
    sysdrive=pathvolume(sd);
    if (!direxists(sysdrive))
    {
      printf("\nYou inserted \"%s\", but it seems that the directory  \n\"%s\" is not accessible.\n",
        sd,sysdrive);
      printf("You can choose a different hard drive for which you have\n  the appropriate permissions!");
      printf("\nWill you try to insert a different drive (0/1)? ");
      readint(&retry);
      disppointer((void **) &sysdrive);
    }
    disppointer((void **) &sd);
  }
  if (sysdrive==NULL)
  {
    errfunc0("filesystemroot");
    sprintf(ers(),"Could not locate the file system root on this computer.");
    errfunc2();
  }
  return sysdrive;
#endif
}




    /* INTERACTION WITH FILE SYSTEM */




void getvolumes(stack st)
    /* Gets pushes on st the volumes currently mounted on the file system.
    $A Igor apr01; */
{
  char *res=NULL,*aux=NULL,**argv=NULL;
  int code=0,argc=0,i=0;
if (st==NULL)
{
  errfunc0("getvolumes");
  sprintf(ers(),"Stack for storing file system volumes is NULL.\n");
  errfunc2();
  return;
}
#if defined(UNIX)
  pushstack(st,stringcopy(""));
#elif defined(ITK)
  res=tcl_interpretcp("file volumes",&code);
  if (code!=TCL_OK)
  {
    errfunc0("getvolumes");
    sprintf(ers(),"Can not get file system volumes, error %i:\n\"%s\".\n",
            code,res);
    errfunc2();
  } else
  {
    code=Tcl_SplitList(NULL,res, &argc, &argv);
    if (code!=TCL_OK)
    {
      errfunc0("getvolumes");
      sprintf(ers(),"Tcl interpreter can not split the following string:\n\"%s\".\n",
              res);
      errfunc2();
    } else
    {
      for (i=0;i<argc;++i)
      {
        aux=stringcopy(argv[i]);
        if (stringlength(aux)>0)
        {
          if (aux[strlen(aux)-1]!='/' && aux[strlen(aux)-1]!='\\')
            stringappend(&aux,"/");
          updatepathseparators(aux,'/');
          updatepathseparators(aux,'\\');
        }
        pushstack(st,(aux));
      }
      Tcl_Free((char *) argv);
    }
  }
  disppointer((void **) &res);
#elif defined (DOSWN)
  aux=NULL;  /* just because of compiler */
  for (i='A'; i<='Z';++i)
  {
    res=stringcopy("x:\\");
    *res=(char) i;
    if (direxists(res))
      pushstack(st,res);
    else
      disppointer((void **) &res);
  }
#else
  errfunc0("getvolumes");
  sprintf(ers(),"Not available on this platform.\n");
  errfunc2();
#endif
}


long ig_filelength(char *filename)
    /* Returns length of the file names filename or -1 if length can not be
    retreived.
    $A Igor <== apr03; */
{
long l;
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL;
  int tclcode;
  tclname=stringcopy(filename);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","size",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    l=atol(tclret);
  else
    l=-1;
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return l;
#else
  FILE *fp;
  fp=fopen(filename,"rb");
  if (fp!=NULL)
  {
    l=flength(fp);
    fclose(fp);
  } else
    l=-1;
  return l;
#endif
}


long getfilemtime(char *filename)
    /* Returns the time of the last modification of the file or directory
    named filename, or 0 if the time can not be retreived or the file does not
    exists.
    $A Igor apr03; */
{
#ifdef ITK
  long l=0;
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL;
  int tclcode;
  tclname=stringcopy(filename);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","mtime",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    l=atol(tclret);
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return l;
#else
  warnfunc1(1,"filemtime");
  sprintf(ers(),"Unable to retreive the file last modification time on this platform.\n");
  warnfunc2();
  return 0;
#endif
}


long getfileatime(char *filename)
    /* Returns the time of the last access to the file or directory named
    filename, or 0 if the time can not be retreived or the file does not
    exists.
    $A Igor apr03; */
{
#ifdef ITK
  long l=0;
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL;
  int tclcode;
  tclname=stringcopy(filename);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","atime",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    l=atol(tclret);
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return l;
#else
  warnfunc1(1,"fileatime");
  sprintf(ers(),"Unable to retreive the file last access time on this platform.\n");
  warnfunc2();
  return 0;
#endif
}

char setfilemtime(char *filename,long time)
    /* Sets the last modification time of the file or directory named filename,
    to time seconds. time must be positive. Function returns 1 if successful,
    0 otherwise.
    $A Igor apr03; */
{
#ifdef ITK
  long l=0;
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL,*timebuf=NULL,ret=1;
  int tclcode;
  if (time<=0)
    return 0;
  if (time<=0)
    return 0;
  timebuf=malloc(30);
  sprintf(timebuf,"%li\0",time);
  if (filename!=NULL)
    tclname=stringcopy(filename);
  else
    tclname=stringcopy("");
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","mtime",tclname,timebuf,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    ret=1;
  disppointer((void **) &timebuf);
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#else
  if (time<=0)
    return 0;
  if (time<=0)
    return 0;
  warnfunc1(1,"setfilemtime");
  sprintf(ers(),"Unable to set the file last modification time on this platform.\n");
  warnfunc2();
  return 0;
#endif
}

char setfileatime(char *filename,long time)
    /* Sets the last access time of the file or directory named filename,
    to time seconds. time must be positive. Function returns 1 if successful,
    0 otherwise.
    $A Igor apr03; */
{
#ifdef ITK
  long l=0;
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL,*timebuf=NULL,ret=1;
  int tclcode;
  if (time<=0)
    return 0;
  timebuf=malloc(30);
  sprintf(timebuf,"%li\0",time);
  if (filename!=NULL)
    tclname=stringcopy(filename);
  else
    tclname=stringcopy("");
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","atime",tclname,timebuf,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    ret=1;
  disppointer((void **) &timebuf);
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#else
  if (time<=0)
    return 0;
  warnfunc1(1,"setfileatime");
  sprintf(ers(),"Unable to set the file last access time on this platform.\n");
  warnfunc2();
  return 0;
#endif
}


char fileexistsprimitive(char *filename)
    /* Does the same as fileexists. It is provided only for initialization in
    globut.c, because Tcl interpreter is not yet initielized at the time when
    this function is called and attempt to call it (which actually happens in
    dfileexists()) would crash the program.
    $A Igor feb04; */
{
FILE *fp;
fp=fopen(filename,"rb");
if (fp==NULL)
  return 0;
else
{
  fclose(fp);
  return 1;
}
}

char fileexists(char *filename)
    /* Vrne 1, ce datoteka z imenom filename ze obstaja, in 0, ce ne obstaja.
    0 vrne tudi, ce obstaja direktorij z imenom path.
    $A Igor avg98; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL,ret=0;
  int tclcode;
  tclname=stringcopy(filename);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","isfile",tclname,NULL);
  /* tclcom=stringcopy(tclcom); */
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    if (atol(tclret)==1)
    {
      ret=1;
    }
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#else
  FILE *fp;
  fp=fopen(filename,"rb");
  if (fp==NULL)
    return 0;
  else
  {
    fclose(fp);
    return 1;
  }
#endif
}


char filewritable(char *filename)
    /* Returns 1 if filename is a name of a writable file (not a directory)
    and 0 otherwise.
    $A Igor apr03; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL,ret=0;
  int tclcode;
  tclname=stringcopy(filename);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","isfile",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    if (!cmpstrings(tclret,"1"))
    {
      disppointer((void **) &tclcom);
      disppointer((void **) &tclret);
      tclcom=tcl_multstrcom("file","writable",tclname,NULL);
      tclret=tcl_interpret(tclcom,&tclcode);
      if (tclcode==TCL_OK)
        if (!cmpstrings(tclret,"1"))
      ret=1;
    }
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  disppointer((void **) &tclname);
  return ret;
#else
  char ret;
  FILE *fp;
  fp=fopen(filename,"wb");
  if (fp!=NULL)
  {
    fclose(fp);
    ret=1;
  } else
    ret=0;
  return ret;
#endif
}

char filereadable(char *filename)
    /* Returns 1 if filename is a name of a readable file (not a directory)
    and 0 otherwise.
    $A Igor apr03; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL,ret=0;
  int tclcode;
  tclname=stringcopy(filename);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","isfile",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    if (!cmpstrings(tclret,"1"))
    {
      disppointer((void **) &tclcom);
      disppointer((void **) &tclret);
      tclcom=tcl_multstrcom("file","readable",tclname,NULL);
      tclret=tcl_interpret(tclcom,&tclcode);
      if (tclcode==TCL_OK)
        if (!cmpstrings(tclret,"1"))
      ret=1;
    }
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  disppointer((void **) &tclname);
  return ret;
#else
  char ret;
  FILE *fp;
  fp=fopen(filename,"rb");
  if (fp!=NULL)
  {
    fclose(fp);
    ret=1;
  } else
    ret=0;
  return ret;
#endif
}

char fileexecutable(char *filename)
    /* Returns 1 if filename is a name of a writable file (not a directory)
    and 0 otherwise.
    $A Igor apr03; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL,ret=0;
  int tclcode;
  tclname=stringcopy(filename);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","isfile",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    if (!cmpstrings(tclret,"1"))
    {
      disppointer((void **) &tclcom);
      disppointer((void **) &tclret);
      tclcom=tcl_multstrcom("file","executable",tclname,NULL);
      tclret=tcl_interpret(tclcom,&tclcode);
      if (tclcode==TCL_OK)
        if (!cmpstrings(tclret,"1"))
      ret=1;
    }
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  disppointer((void **) &tclname);
  return ret;
#else
  errfunc0("filename");
  sprintf(ers(),"Unable to check if the file is executable (\"%s\").\n",filename);
  errfunc2();
  return 0;
#endif
}

char *getcurrentdir(void)
    /* Returns the current (working) directory. The returned string should be
    deallocated after use. The last character is always a path separator. If
    the current dir can not be obtained for any reason, function returns NULL.
    $A Igor apr03; */
{
#ifdef ITK
  char *tclcom=NULL,*tclret=NULL,*ret=NULL;
  int tclcode;
  tclcom=stringcopy("pwd");
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
  {
    ret=tclret;
    updatepathseparators(ret,'/');
    if (ret!=NULL)
      if (ret[strlen(ret)-1]!=pathsep)
        stringappend(&ret,strpathsep);
  }
  else
    disppointer((void **) &tclret);
  disppointer((void **) &tclcom);
  return ret;
#else
  char *ret=getpwdstring();
  if (ret!=NULL)
      if (ret[strlen(ret)-1]!=pathsep)
        stringappend(&ret,strpathsep);
  return ret;
#endif
}


char setcurrentdir(char *dir)
    /* Changes the current (working) directory to dir. It returns 1 if the
    operation succedeeded and 0 otherwise.
    $A Igor apr03; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL,ret=0;
  int tclcode;
  if (stringlength(dir)==0)
    return 0;
  if (dir!=NULL)
    tclname=stringcopy(dir);
  else
    tclname=stringcopy("");
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("cd",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    ret=1;
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#else
  char ret=0;
  errfunc0("setcurrentdir");
  sprintf(ers(),"Changing current dorectory not yet implemented on this platform.\n");
  warnfunc2();
  return ret;
#endif
}



char *getabsolutepath(char *filename)
    /* Returns an absolute path of filename with native path separators. The
    returned string must be deallocated e.g. by free().
    $A Igor apr04; */
{
#ifdef DOSWN
  char *name=NULL,*currentdir=NULL,*ptr;
  if (filename==NULL)
    return NULL;
  name=stringcopy(filename);
  convertfilesyst(name);
  if (*name==pathsep)
  {
    /*filename represents the path with respect to the current drive, probably a
    drive name has to be added: */
    currentdir=getcurrentdir();
    if (currentdir!=NULL)
    {
      ptr=currentdir;
      while(*ptr!=pathsep && *ptr!=':' && *ptr!='\0')
        ++ptr;
      if (*ptr==':')
      {
        ptr[1]='\0';
        stringinsert(&name,currentdir,0);
      }
    }
    disppointer((void **) &currentdir);
    cleanpathname(&name);
    return name;
  } else
  {
    /* Name does not begin with a path separator; We must establish if it
    contains the drive number, since otherwise the name is relative: */
    ptr=name;
    while(*ptr!=pathsep && *ptr!=':' && *ptr!='\0')
      ++ptr;
    if (*ptr==':')   /* filename path is already absolute */
    {
      cleanpathname(&name);
      return name;
    }
    else
    {
      currentdir=getcurrentdir();
      stringinsert(&name,currentdir,0);
      disppointer((void **) &currentdir);
      cleanpathname(&name);
      return name;
    }
  }
#else
  char *name=NULL,*currentdir=NULL,*ptr=NULL;
  if (filename==NULL)
    return NULL;
  name=stringcopy(filename);
  convertfilesyst(name);
  if (*filename==pathsep)  /* filename is already an absolute path */
  {
    cleanpathname(&name);
    return name;
  }
  else
  {
    /* filename is relative, we must append it with the absolute path: */
    currentdir=getcurrentdir();
    stringinsert(&name,currentdir,0);
    disppointer((void **) &currentdir);
    cleanpathname(&name);
    return name;
  }
#endif
}

void pathtoabsolute(char **pathaddr)
    /* Changes path string pointed to by pathaddr to absolute path.
    $A Igor apr03; */
{
char *name=NULL;
if (pathaddr!=NULL)
{
  name=getabsolutepath(*pathaddr);
  disppointer((void **) pathaddr);
  *pathaddr=name;
}
}

char *getargpath(char *filepath)
    /* Returns the representation of path in the form suitable for using
    as a command line argument of programs, i.e. the path separators are
    system native ones, the path is cleaned and if the path contains any blank
    characters, it is embedded in double quotes.
    $A Igor apr04; */
{
char *ptr=NULL,*name;
/*
name=getabsolutepath(filepath);
*/
name=stringcopy(filepath);
convertfilesyst(name);
if (name!=NULL)
{
  ptr=name;
  while (*ptr!='\0' && !isspace(*ptr))
    ++ptr;
  if (*ptr!='\0' && *ptr!='\"')
  {
    stringinsert(&name,"\"",0);
    stringappend(&name,"\"");
  }
}
return name;
}


void pathtoarg(char **pathaddr)
    /* Changes path string pointed to by pathaddr so that it can be used as
    command-line argument at program invocation: converts fileseparator to
    native ones, embeds path in double qoutes if it contains whitespaces and
    cleans the path of meaningless things such as
    ./. .
    $A Igor apr03; */
{
char *name=NULL;
if (pathaddr!=NULL)
{
  name=getargpath(*pathaddr);
  disppointer((void **) pathaddr);
  *pathaddr=name;
}
}


int direxistsprimitive(char *dir)
    /* Does the same as direxists, it is provided only for initialization in
    globut.c, because Tcl interpreter is not yet initielized at the time when
    this function is called and attempt to call it (which actually happens in
    direxists()) would crash the program.
    $A Igor feb04; */
{
char *file;
FILE *fp;
long l;
file=dirplusfile(dir,"readme.txt");
if ((fp=fopen(file,"rb"))!=NULL)
{
  fclose(fp);
  disppointer((void **) &file);
  return 1;
} else
{
  fp=fopen(file,"ab+");
  if (fp!=NULL)
  {
    l=flength(fp);
    fclose(fp);
    /* We have most likely created a new file, therefore we delete id: */
    if (l<1)
      remove(file);
    disppointer((void **) &file);
    return 1;
  }
}
disppointer((void **) &file);
return 0;
}


int direxists(char *dir)
    /* Returns 1 if directory named dir exists and 0 if not.
    $A Igor jan02; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL;
  int tclcode,ret=0;
  tclname=stringcopy(dir);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","isdir",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    if (!cmpstrings(tclret,"1"))
    {
      ret=1;
    }
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#else
  char *file;
  FILE *fp;
  long l;
  file=dirplusfile(dir,"readme.txt");
  if ((fp=fopen(file,"rb"))!=NULL)
  {
    fclose(fp);
    disppointer((void **) &file);
    return 1;
  } else
  {
    fp=fopen(file,"ab+");
    if (fp!=NULL)
    {
      l=flength(fp);
      fclose(fp);
      /* We have most likely created a new file, therefore we delete id: */
      if (l<1)
        remove(file);
      disppointer((void **) &file);
      return 1;
    }
  }
  disppointer((void **) &file);
  return 0;
#endif
}



int dirreadable(char *dir)
    /* Returns 1 if directory named dir exists and is writable, 0 if not.
    This function uses temporary string buffer.
    $A Igor jan02; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL;
  int tclcode,ret=0;
  tclname=stringcopy(dir);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","isdirectory",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    if (!cmpstrings(tclret,"1"))
    {
      disppointer((void **) &tclcom);
      disppointer((void **) &tclret);
      tclcom=tcl_multstrcom("file","readable",tclname,NULL);
      tclret=tcl_interpret(tclcom,&tclcode);
      if (tclcode==TCL_OK)
        if (!cmpstrings(tclret,"1"))
      ret=1;
    }
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  disppointer((void **) &tclname);
  return ret;
#else
 #ifdef DOSWN
  char *dirname=NULL,*command=NULL,*out=NULL;
  int ret=0;
  dirname=stringcopy(dir);
  pathtoarg(&dirname);
  command=stringcat("dir ",dirname);
  out=systemresstr(command);
  if (stringlength(out)>0)
    ret=1;
  else
    ret=0;
  disppointer((void **) &dirname);
  disppointer((void **) &command);
  /* disppointer((void **) &ret); */
  disppointer((void **) &out);
  return ret;
 #elif defined (UNIX)
  char *command=NULL,*out=NULL;
  int ret=0;
  command=stringcat("ls -a ",dir);
  out=systemresstr(command);
  if (stringlength(out)>0)
    ret=1;
  else
    ret=0;
  disppointer((void **) &command);
  disppointer((void **) &out);
  return ret;
 #else
  errfunc0("dirwritable");
  sprintf(ers(),"Can not check if the directory is writable on this platform.\n");
  errfunc2();
  return 0;
 #endif
#endif
}


static int uniqfileid=1;

int dirwritable(char *dir)
    /* Returns 1 if directory named dir exists and is writable, 0 if not.
    This function uses temporary string buffer.
    $A Igor jan02; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL;
  int tclcode,ret=0;
  tclname=stringcopy(dir);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","isdirectory",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    if (!cmpstrings(tclret,"1"))
    {
      disppointer((void **) &tclcom);
      disppointer((void **) &tclret);
      tclcom=tcl_multstrcom("file","writable",tclname,NULL);
      tclret=tcl_interpret(tclcom,&tclcode);
      if (tclcode==TCL_OK)
        if (!cmpstrings(tclret,"1"))
      ret=1;
    }
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  disppointer((void **) &tclname);
  return ret;
#else
  char *name,*p;
  FILE *fp;
  if (!direxists(dir))
    return 0;
  /* First we find a name of a non-existent file in the directory dir (or at
  least a file that can not be read): */
  p=tmpstringbufmin(20+stringlength(dir));
  sprintf(p,"ig_un_f_%i.tmp",uniqfileid);
  name=dirplusfile(dir,p);
  while (fileexists(name))
  {
    /* fclose(fp); */
    disppointer((void **) &name);
    ++uniqfileid;
    sprintf(p,"ig_un_f_%i.tmp",uniqfileid);
    name=dirplusfile(dir,p);
  }
  fp=fopen(name,"ab+");
  if (fp!=NULL)
  {
    if (flength(fp)>0)
    {
      fclose(fp);
      ++uniqfileid;
    } else
    {
      fclose(fp);
      remove(name);
    }
    disppointer((void **) &name);
    return 1;
  }
  disppointer((void **) &name);
  return 0;
#endif
}


int fileordirexists(char *path)
    /* Returns 1 if either file or directory specified by path exists,
    otherwise returns 0;
    $A Igor apr04; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL;
  int tclcode,ret=0;
  tclname=stringcopy(path);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","exists",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    if (atol(tclret)==1)
    {
      ret=1;
    }
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#else
  if (fileexists(path) || direxists(path))
    return 1;
  else
    return 0;
#endif
}


char *newfilename(char *dir)
    /* Returns a name of a file that does not currently exist in directory dir.
    Returned string must be removed (e.g. by free()) from memory when not
    needed any more. It contains the complete path of the file, including
    dir. If creation of the unique file name fails (e.g. if dir is not a valid
    directory with write permission), the function returns NULL.
    $A Igor jan02; */
{
char *name,*p;
/* FILE *fp; */
if (!dirwritable(dir))
  return NULL;
/* First we find a name of a non-existent file in the directory dir: */
p=tmpstringbufmin(20+stringlength(dir));
sprintf(p,"ig_un_f_%i.tmp",uniqfileid);
name=dirplusfile(dir,p);
/*
while ((fp=fopen(name,"rb"))!=NULL)
{
  fclose(fp);
  disppointer((void **) &name);
  ++uniqfileid;
  sprintf(p,"ig_un_f_%i.tmp",uniqfileid);
  name=dirplusfile(dir,p);
}
*/
while (fileexists(name))
{
  disppointer((void **) &name);
  ++uniqfileid;
  sprintf(p,"ig_un_f_%i.tmp",uniqfileid);
  name=dirplusfile(dir,p);
}
/*
fp=fopen(name,"ab+");
if (fp!=NULL)
{
  while (flength(fp)>0)
  {
    fclose(fp);
    disppointer((void **) &name);
    ++uniqfileid;
    sprintf(p,"ig_un_f_%i.tmp",uniqfileid);
    name=dirplusfile(dir,p);
    fp=fopen(name,"ab+");
    if (fp==NULL)
    {
      disppointer((void **) &name);
      return name;
    }
  }
  ++ uniqfileid;
  fclose(fp);
  remove(name);
  return name;
} else
{
  disppointer((void **) &name);
  return name;
}
*/
return name;
}


int renamedirorfile(char *namefrom,char *nameto)
    /* renames or moves file namefrom to nameto. This function works different
    from the system rename() in that it also moves directories to different
    path. Function does not overwrite files or directories. If nameto
    specifies an existent directory, then the file or directory is moved to
    thet directory. Function returns 1 if successful and 0 if not.
    $A Igor april 03; */
{
#ifdef ITK
  char *tclnamefrom=NULL,*tclnameto=NULL,*tclcom=NULL,*tclret=NULL,ret=0;
  int tclcode;
  tclnamefrom=stringcopy(namefrom);
  changepathseparators(tclnamefrom,'/');
  tclnameto=stringcopy(nameto);
  changepathseparators(tclnameto,'/');
  tclcom=tcl_multstrcom("file","rename","--",tclnamefrom,tclnameto,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    ret=1;
  disppointer((void **) &tclnamefrom);
  disppointer((void **) &tclnameto);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#else
  if (rename(namefrom,nameto)==0)
    return 1;
  else
    return 0;
#endif
}

int createdir(char *dirname)
    /* Creates a directory named dirname, if it does not yet exist. The
    function works for sure only if parent directory of dirname exists. It
    returns 0 if directory dirname have already existed, 1 if it successfully
    created dir. and -1 if it failed to create it.
    This function uses temporary string buffer. 
    $A Igor jan02; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL,ret=0;
  int tclcode;
  if (direxists(dirname))
    return 0;
  if (stringlength(dirname)==0)
    return -1;
  tclname=stringcopy(dirname);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","mkdir",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    ret=1;
  else
    ret=-1;
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#elif defined(DOSWN) || defined (UNIX)
  char *command;
  if (direxists(dirname))
    return 0;
  if (stringlength(dirname)==0)
    return -1;
  command=tmpstringbufmin(10+stringlength(dirname));
  sprintf(command,"mkdir %s",dirname);
  system(command);
  if (direxists(dirname))
    return 1;
  else
    return -1;
#else
  errfunc0("createdir");
  sprintf(ers(),"Can not create directories on this platform.\n");
  errfunc2();
  return -1;
#endif
}

int createdirsafe(char *dirname)
    /* Creates a directory named dirname, if it does not yet exist. The
    function works even if parent directory of dirname does not exist, in
    which case parent directory is recursively created first. Function returns
    0 if directory dirname have already existed, 1 if it successfully created
    the directory and -1 if it failed to create it.
    This function uses temporary string buffer. 
    $A Igor jan02; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL,ret=0;
  int tclcode;
  if (direxists(dirname))
    return 0;
  if (stringlength(dirname)==0)
    return -1;
  tclname=stringcopy(dirname);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","mkdir",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    ret=1;
  else
    ret=-1;
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#elif defined(DOSWN) || defined(UNIX)
char *name;
int ret=0;
ret=createdir(dirname);
if (ret>=0)
  return ret;
else
{
  if (stringlength(dirname)>1)
    if (!(dirname[1]==':' && strlen(dirname)==2))  /* Excludes the case where
        dirname is a drive name like "F:" */
    {
      /* Creation of directory failed; We try to create its parent directory
      first and then the directory itself: */
      name=parentdir(dirname);
      ret=createdirsafe(name);
      disppointer((void **) &name);
      if (ret>=0)
        return createdir(dirname);
    }
}
return -1;
#else
  errfunc0("createdir");
  sprintf(ers(),"Can not create directories on this platform.\n");
  errfunc2();
  return -1;
#endif
}

int removedir(char *dirname)
    /* Removes a directory named dirname, if it exists (existence is checked
    before action is undertaken). Directory is not deleted if it is not empty.
    This function uses temporary string buffer.
    Returns 0 or 1 if operation is successful, otherwise it returns -1.
    $A Igor jan02; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL;
  int tclcode,ret;
  tclname=stringcopy(dirname);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","isdir",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    if (!cmpstrings(tclret,"1"))
    {
      disppointer((void **) &tclcom);
      disppointer((void **) &tclret);
      tclcom=tcl_multstrcom("file","delete",tclname,NULL);
      tclret=tcl_interpret(tclcom,&tclcode);
      if (tclcode==TCL_OK)
        ret=1;
      else
        ret=-1;
    }
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#elif defined(DOSWN) || defined(UNIX)
  char *command;
  if (direxists(dirname))
  {
    command=tmpstringbufmin(10+stringlength(dirname));
    sprintf(command,"rmdir %s",dirname);
    system(command);
    disppointer((void **) &command);
    return 1;
  } else
    return -1;
#else
  errfunc0("removedir");
  sprintf(ers(),"Can not remove directories on this platform,\n");
  errfunc2();
  return -1;
#endif
}


int removedirrec(char *dirname)
    /* Removes a directory named dirname, if it exists (existence is checked
    before action is undertaken). Directory is removed even if it is not empty.
    This function uses temporary string buffer.
    Returns 0 or 1 if operation is successful, otherwise it returns -1.
    $A Igor jan02; */
{
#ifdef ITK
  char *tclname=NULL,*tclcom=NULL,*tclret=NULL;
  int tclcode,ret=0;
  tclname=stringcopy(dirname);
  changepathseparators(tclname,'/');
  tclcom=tcl_multstrcom("file","isdir",tclname,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK)
    if (!cmpstrings(tclret,"1"))
    {
      disppointer((void **) &tclcom);
      disppointer((void **) &tclret);
      tclcom=tcl_multstrcom("file","delete","-force","--",tclname,NULL);
      tclret=tcl_interpret(tclcom,&tclcode);
      if (tclcode==TCL_OK)
        ret=1;
      else
        ret=-1;
    }
  disppointer((void **) &tclname);
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  return ret;
#else
  char *command;
  if (direxists(dirname))
  {
    command=tmpstringbufmin(20+stringlength(dirname));
    #if defined(UNIX)
      sprintf(command,"rm -R %s",dirname);
    #elif defined(DOSWN)
      sprintf(command,"rmdir %s /s /q",dirname);
    #else
      errfunc0("removedirrec");
      sprintf(ers(),"Can not remove directories on this platform,\n");
      errfunc2();
      return -1;
    #endif
    #if defined(DOSWN) || defined(UNIX)
      system(command);
      return 1;
    #endif
  } else return -1;
#endif
}


removedirorfile(char *path)
    /* Attempts to unconditionally remove a file or directory path, and does
    so even if path is a non-empty directory.
    $A Igor apr03; */
{
if (fileexists(path))
  remove(path);
else if (direxists(path))
  removedirrec(path);
}





              /****************************/
              /*                          */
              /*  FILE LISTING UTILITIES  */
              /*                          */
              /****************************/



int cmpfilenamesflags(char *name1,char *name2,long flags)
    /* Compares files named name1 and name2 according to file sorting
    flags and returns result similar to strcmp(). name1 and name2
    should be vlaid file names that can be used in fopen().
    $A Igor apr04l */  
{
static int warnflags=0;
int ret=0,isdir1,isdir2,tclcode=0;
long size1,size2;
double time1=0,time2=0;
char endchar=0,*tclcom=NULL,*tclret=NULL;
if (flags & (F_SORTDIRSFIRST | F_SORTFILESFIRST))
{
  if (! (warnflags & (F_SORTDIRSFIRST | F_SORTFILESFIRST)) )
  {
    warnfunc1(1,"cmpfilenamesflags");
    sprintf(ers(),"Sorting files and directories separately not yet properly implemented.\n");
    sprintf(ers(),"Try to distinguish by end character.\n");
    warnfunc2();
    warnflags |= F_SORTDIRSFIRST | F_SORTFILESFIRST;
  }
#ifdef ITK
  tclcom=tcl_multstrcom("file","isdirectory",name1,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK && !cmpstrings(tclret,"1"))
    isdir1=1;
  else
    isdir1=0;
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
  tclcom=tcl_multstrcom("file","isdirectory",name2,NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode==TCL_OK && !cmpstrings(tclret,"1"))
    isdir2=1;
  else
    isdir2=0;
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
#else
  endchar='\0';
  if (name1!=NULL)
  {
    endchar=name1[strlen(name1)-1];
    if (endchar=='\\' || endchar=='/' || endchar==filepathseparator())
      isdir1=1;
    else
      isdir1=0;
  } else
    isdir1=0;
  if (name2!=NULL)
  {
    endchar=name2[strlen(name2)-1];
    if (endchar=='\\' || endchar=='/' || endchar==filepathseparator())
      isdir2=1;
    else
      isdir2=0;
  } else
    isdir2=0;
#endif   /* defined ITK */
  if (isdir1 && !isdir2)
    ret=-1;
  else if (!isdir1 && isdir1)
    ret=1;
  if (flags & F_SORTFILESFIRST)
    ret=-ret;
}
if (!ret && (flags & F_SORTEXT))
  ret=cmpstrings(filenameext(name1),filenameext(name2));
if (!ret && (flags & F_SORTNAME))
  ret=cmpstrings(name1,name2);
if (!ret && (flags & F_SORTSIZE))
{
  size1=filelength(name1);
  size2=filelength(name2);
  if (size1<size2)
    ret=-1;
  else if (size1>size2)
    ret=1;
}
if (!ret && (flags & (F_SORTCTIME | F_SORTMTIME | F_SORTATIME)) )
{
#ifdef ITK
  if (flags & F_SORTMTIME)
  {
    tclcom=tcl_multstrcom("file","mtime",name1,NULL);
    tclret=tcl_interpret(tclcom,&tclcode);
    if (tclcode==TCL_OK)
      time1=atof(tclret);
    else
      time1=0;
    disppointer((void **) &tclcom);
    disppointer((void **) &tclret);
    tclcom=tcl_multstrcom("file","mtime",name2,NULL);
    tclret=tcl_interpret(tclcom,&tclcode);
    if (tclcode==TCL_OK)
      time2=atof(tclret);
    else
      time2=0;
    disppointer((void **) &tclcom);
    disppointer((void **) &tclret);
  } else if (flags & F_SORTCTIME)
  {
    tclcom=tcl_multstrcom("file","ctime",name1,NULL);
    tclret=tcl_interpret(tclcom,&tclcode);
    if (tclcode==TCL_OK)
      time1=atof(tclret);
    else
      time1=0;
    disppointer((void **) &tclcom);
    disppointer((void **) &tclret);
    tclcom=tcl_multstrcom("file","ctime",name2,NULL);
    tclret=tcl_interpret(tclcom,&tclcode);
    if (tclcode==TCL_OK)
      time2=atof(tclret);
    else
      time2=0;
    disppointer((void **) &tclcom);
    disppointer((void **) &tclret);
  } else if (flags & F_SORTATIME)
  {
    tclcom=tcl_multstrcom("file","atime",name1,NULL);
    tclret=tcl_interpret(tclcom,&tclcode);
    if (tclcode==TCL_OK)
      time1=atof(tclret);
    else
      time1=0;
    disppointer((void **) &tclcom);
    disppointer((void **) &tclret);
    tclcom=tcl_multstrcom("file","atime",name2,NULL);
    tclret=tcl_interpret(tclcom,&tclcode);
    if (tclcode==TCL_OK)
      time2=atof(tclret);
    else
      time2=0;
    disppointer((void **) &tclcom);
    disppointer((void **) &tclret);
  }
  if (time1<time2)
    ret=-1;
  else if (time1>time2)
    ret=1;
  else ret=0;
#else
  if (! (warnflags & (F_SORTCTIME | F_SORTMTIME | F_SORTATIME)) )
  {
    warnfunc1(1,"cmpfilenamesflags");
    sprintf(ers(),"Sorting files by creation, modification or access time not yet implemented.\n");
    warnfunc2();
    warnflags |= F_SORTCTIME | F_SORTMTIME | F_SORTATIME;
  }
#endif    /* not defined ITK */
}
if (!ret && (flags & F_SORTREVERSE) )
  ret=-ret;
return ret;
}


static long filesortflags=0,filesortlock=0;

static int cmpfilenames(void *name1,void *name2)
    /* Compares files named name1 and name2 according to file sorting flags
    filesortflags (local var.) and returns result similar to strcmp(). name1
    and name2 should be vlaid file names that can be used in fopen().
    $A Igor apr04l */  
{
return cmpfilenamesflags(name1,name2,filesortflags);
}


void updatefilesortflags(long *pflags)
    /* Updates file sorting flags pointed to by pflags so that they are
    consistent, e.g sorting by name and time is not on at the same time.
    $A Igor apr04l */  
{
if (pflags!=NULL)
{
  if ((*pflags & F_SORTDIRSFIRST) && (*pflags & F_SORTFILESFIRST))
    *pflags &= ~F_SORTFILESFIRST;
  if (*pflags & F_SORTNAME)
    *pflags &= ~(F_SORTSIZE | F_SORTCTIME & F_SORTMTIME & F_SORTATIME);
  else if (*pflags & F_SORTSIZE)
    *pflags &= ~(F_SORTCTIME & F_SORTMTIME & F_SORTATIME);
  else if (*pflags & F_SORTCTIME)
    *pflags &= ~(F_SORTMTIME & F_SORTATIME);
  else if (*pflags & F_SORTMTIME)
    *pflags &= ~F_SORTATIME;
  if (*pflags & F_RECBYLEVELS)
    *pflags &= ~F_RECONELEVEL;
}
}


/* PREVERI:
Preveri, ce listanje res dela pravilno, ko kateri od flagov niso postavljeni!

PREVERI, ce na Windowsih delajo vse stvari, ce so presledki v imenih datotek
ali tirektorijev, predvsem, ce uporabljas Tcl (primer: dirwritable)
*/


void dirlistsys(char *path,char *spec,long flags,stack list)
    /* Loads a list of files (dynamically allocated strings (char *) in the 
    directory path, which match specification spec and flags, to stack list.
    list must be initialised. If it already contains any elements, these are
    not deleted.
      path can be either relative or absolute. spec must be a glob-type
    specification containing wildcharacters such as * or ? (see system
    manuals for details) or a specific name.
      flags specify the types of files that are listed. Macros F_LISTFILES,
    F_LISTDIRS, F_LISTLINKS, F_LISTSPECIAL and F_LISTMASK can be used or any
    or-ed combination of these.
      The system "dir" command (or "ls" on UNIX) is used to get the names.
    $A Igor apr04; */
{
char *dir=NULL,*com=NULL,*dirlist=NULL,*separators=NULL,*name=NULL,
     last='\0',*sortopt=NULL,*aux1=NULL;
int i=0,j=0,n=0,listmark;
stack files=NULL,dirs=NULL;
if ( !(flags & F_LISTMASK) )
  return;
if (list==NULL)
{
  errfunc0("dirlistsys");
  sprintf(ers(),"Stack of file names not defined.\n");
  errfunc2();
  return;
}
if (stringlength(spec)==0)
  spec="*";
#ifndef DOSWN
if (flags & (F_SORTDIRSFIRST | F_SORTFILESFIRST))
{
  /* Sort directories and files separately: */
  files=newstack(100);
  dirs=newstack(100);
  dirlistsys(path,spec,flags & ~F_SORTDIRSFIRST & ~F_SORTFILESFIRST & 
    ~F_LISTFILES,dirs);
  dirlistsys(path,spec,flags & ~F_SORTDIRSFIRST & ~F_SORTFILESFIRST & 
    ~F_LISTDIRS,files);
  if ( ((flags & F_SORTDIRSFIRST)   && !(flags & F_SORTREVERSE)) || 
       ((flags & F_SORTFILESFIRST) &&  (flags & F_SORTREVERSE))  )
  {
    for (i=1;i<=dirs->n;++i)
      pushstack(list,dirs->s[i]);
    for (i=1;i<=files->n;++i)
      pushstack(list,files->s[i]);
  } else
  {
    for (i=1;i<=files->n;++i)
      pushstack(list,files->s[i]);
    for (i=1;i<=dirs->n;++i)
      pushstack(list,dirs->s[i]);
  }
  dispstack(&files);
  dispstack(&dirs);
  return;
}
#endif   /* not defined DOSWN */
updatefilesortflags(&flags);
listmark=list->n+1;
dir=dirplusfile(path,spec);
pathtoarg(&dir);
if (flags==0)
  flags=F_LISTMASK;
#ifdef DOSWN
  separators="\n\r\t\v";
  if (flags & F_SORTDIRSFIRST)
    stringappend(&sortopt," /OG ");
  if (flags & F_SORTFILESFIRST)
    stringappend(&sortopt," /O-G ");
  if (flags & F_SORTEXT)
    stringappend(&sortopt," /OE ");
  if (flags & F_SORTNAME)
    stringappend(&sortopt," /ON ");
  if (flags & F_SORTSIZE)
    stringappend(&sortopt," /OS ");
  if (flags & F_SORTCTIME)
    stringappend(&sortopt," /TC /OD ");
  if (flags & F_SORTMTIME)
    stringappend(&sortopt," /TW /OD ");
  if (flags & F_SORTATIME)
    stringappend(&sortopt," /TA /OD ");
  if (sortopt==NULL)
    stringappend(&sortopt," ");
  /* Switch off flags that are taken into account: */
  flags &= ~F_SORTDIRSFIRST & ~F_SORTFILESFIRST & ~F_SORTEXT & ~F_SORTNAME
         & ~F_SORTSIZE & ~F_SORTCTIME & ~F_SORTMTIME & ~F_SORTATIME;
  if (!(flags & F_LISTFILES))
    com=multstringcat("dir /B /AD ",sortopt,dir,NULL);  /* List only directories */
  else if (!(flags & F_LISTDIRS))
    com=multstringcat("dir /B /A-D ",sortopt,dir,NULL);  /* List only files */
  else
    com=multstringcat("dir /B ",sortopt,dir,NULL);  /* List all files */
  disppointer((void **) &sortopt);
  dirlist=systemresstr(com);
  /*
  printf("\ndirlistsys: command: \"%s\",\ndir. string: \n\"%s\"\n\n",com,dirlist);
  */
  cutstringtowords(dirlist,separators,list);
  if (stringlength(path)>0)
    for (i=listmark;i<=list->n;++i)
    {
      aux1=dirplusfile(path,list->s[i]);
      convertfilesyst(aux1);
      disppointer((void **) &list->s[i]);
      list->s[i]=aux1;
      aux1=NULL;
    }
#elif defined (UNIX)   /* DOSWN */
  separators="\n\r\t\v";
  if (flags & F_SORTCTIME)
    stringappend(&sortopt," -c -t ");
  if (flags & F_SORTMTIME)
    stringappend(&sortopt," -t ");
  if (flags & F_SORTATIME)
    stringappend(&sortopt," -u -t ");
  if (sortopt==NULL)
    stringappend(&sortopt," ");
  /* Switch off flags that are taken into account: */
  flags &= ~F_SORTNAME & ~F_SORTCTIME & ~F_SORTMTIME & ~F_SORTATIME;
  if (stringlength(spec)==0)
    com=multstringcat("ls -F -A -1 ",sortopt,dir,NULL);
  else
    com=multstringcat("ls -F -A -1 -d ",sortopt,dir,NULL);
  disppointer((void **) &sortopt);
  dirlist=systemresstr(com);
  cutstringtowords(dirlist,separators,list);
  n=0;
  /* Check if types of the names retreived match flags; types are specified by the
  last character (because of the -L option) */
  for (i=1;i<=list->n;++i)
  {
    name=list->s[i];
    if (name!=NULL)
    {
      if ( *name=='\0')
        last=*name;
      else
        last=name[strlen(name)-1];
      if (last=='*') /* executable file */
      {
        if (!(flags & F_LISTFILES))
          disppointer((void **) &(list->s[i]));
        else
          name[strlen(name)-1]='\0';
      } else if (last=='/')  /* directory */
      {
        if (!(flags & F_LISTDIRS))
          disppointer((void **) &(list->s[i]));
      } else if (last=='@')
      {
        if (!(flags & F_LISTLINKS))  /* symbolic link */
          disppointer((void **) &(list->s[i]));
        else
          name[strlen(name)-1]='\0';
      } else if (last=='|')
      {
        if (!(flags & F_LISTSPECIAL))  /* symbolic link */
          disppointer((void **) &(list->s[i]));
        else
          name[strlen(name)-1]='\0';
      } else if (last=='=')  /* Unknown type (specifics of Linux) */
      {
        errfunc0("dirlistsys");
        sprintf(ers(),"Unknown file type (denoted by \'=\' by the \"ls -F\" command).\n");
        sprintf(ers(),"Output string of the \"ls -F\": \"%s\".\n",name);
        errfunc2();
        name[strlen(name)-1]='\0';
      } else  /* File */
      {
        if (!(flags & F_LISTFILES))
          disppointer((void **) &(list->s[i]));
      }
    }
    name=list->s[i];
    if (name!=NULL)
      if (*name=='\0')
      {
        disppointer((void **) &(list->s[i]));
      }
    if (list->s[i]!=NULL)
      ++n;
    if (n<i)
    {
      list->s[n]=list->s[i];
      list->s[i]=NULL;
    }
  }
  list->n=n;
#else  /* not DOSWN || UNIX */
  errfunc0("dirlistsys");
  sprintf(ers(),"Function not implemented for this operating system.\n");
  errfunc2();
#endif
if (flags & F_SORTMASK)
{
  /* Not all sorting options have been taken into account, sort by acocunting
  for these options: */
  m_threadlocksleep(filesortlock,1);
  filesortflags=flags & ~F_SORTREVERSE;
  if (filesortflags & F_SORTMASK)
    qsortstacklim(list,listmark,0,cmpfilenames);
  m_threadunlock(filesortlock);
  if ((flags & F_SORTREVERSE) && listmark>0)
  {
    /* Reverse order if flag F_SORTREVERSE is set */
    i=listmark;
    j=list->n;
    while(i<j)
    {
      name=list->s[i];
      list->s[i]=list->s[j];
      list->s[j]=name;
      ++i;
      --j;
    }
    name=NULL;
  }
}
disppointer((void **) &dir);
disppointer((void **) &com);
disppointer((void **) &dirlist);
}



void dirlisttcl(char *path,char *spec,long flags,stack list)
    /* Loads a list of files (dynamically allocated strings (char *) in the 
    directory path, which match specification spec and flags, to stack list.
    list must be initialised. If it already contains any elements, these are
    not deleted.
      path can be either relative or absolute. spec must be a glob-type
    specification containing wildcharacters such as * or ? (see system
    manuals for details) or a specific name.
      flags specify the types of files that are listed. Macros F_LISTFILES,
    F_LISTDIRS, F_LISTLINKS, F_LISTSPECIAL and F_LISTMASK can be used or any
    or-ed combination of these.
      The Tcl system is used to get the names. If Tcl can not be initialized
    properly then the dirlisttcl is called to do the work.
    $A Igor apr04; */
{
char *types=NULL,*aux=NULL,*com=NULL,*name=NULL,*res=NULL,**argv=NULL;
int argc=0,code=0,i=0,j=0,listmark=0;
stack files=NULL,dirs=NULL;
if ( !(flags & F_LISTMASK) )
  return;
#ifdef ITK
  tcl_initialize();
  if (tcl_initialized())
  {
    if (list==NULL)
    {
      errfunc0("dirlistsys");
      sprintf(ers(),"Stack of file names not defined.\n");
      errfunc2();
      return;
    }
    if (stringlength(spec)==0)
      spec="*";
    if (flags & (F_SORTDIRSFIRST | F_SORTFILESFIRST))
    {
      /* Sort directories and files separately: */
      files=newstack(100);
      dirs=newstack(100);
      dirlisttcl(path,spec,flags & ~F_SORTDIRSFIRST & ~F_SORTFILESFIRST & 
        ~F_LISTFILES,dirs);
      dirlisttcl(path,spec,flags & ~F_SORTDIRSFIRST & ~F_SORTFILESFIRST & 
        ~F_LISTDIRS,files);
      if ( ((flags & F_SORTDIRSFIRST)   && !(flags & F_SORTREVERSE)) || 
           ((flags & F_SORTFILESFIRST) &&  (flags & F_SORTREVERSE))  )
      {
        for (i=1;i<=dirs->n;++i)
          pushstack(list,dirs->s[i]);
        for (i=1;i<=files->n;++i)
          pushstack(list,files->s[i]);
      } else
      {
        for (i=1;i<=files->n;++i)
          pushstack(list,files->s[i]);
        for (i=1;i<=dirs->n;++i)
          pushstack(list,dirs->s[i]);
      }
      dispstack(&files);
      dispstack(&dirs);
      return;
    }
    updatefilesortflags(&flags);
    listmark=list->n+1;
    if (flags==0)
      flags=F_LISTMASK;
    if (flags & F_LISTFILES)
    {
      aux=types;
      types=stringcat(aux," f ");
      disppointer((void **) &aux);
    }
    if (flags & F_LISTDIRS)
    {
      aux=types;
      types=stringcat(aux," d ");
      disppointer((void **) &aux);
    }
    if (flags & F_LISTLINKS)
    {
      aux=types;
      types=stringcat(aux," l ");
      disppointer((void **) &aux);
    }
    if (flags & F_LISTSPECIAL)
    {
      aux=types;
      types=multstringcat(aux," b "," c "," p "," s ",NULL);
      disppointer((void **) &aux);
    }
    if (types==NULL)
      types=stringcopy("");
    if (stringlength(spec)==0)
      spec="*";
    if (stringlength(path)>0)
      aux=stringcopy(path);
    else
      aux=stringcopy("");
    changepathseparators(aux,'/');
    com=tcl_multstrcomsubst("glob","-nocomplain","-type",types,"-directory",aux,"--",spec,NULL);
    disppointer((void **) &aux);
    res=tcl_interpret(com,&code);
    if (code!=TCL_OK)
    {
      errfunc0("dirlisttcl");
      sprintf(ers(),"Error %i at executing the command\n\"%s\":\n\"%s\".\n",
              code,com,res);
      errfunc2();
    } else
    {
      code=Tcl_SplitList(NULL,res,&argc,(const char ***) &argv);
      if (code!=TCL_OK)
      {
        errfunc0("dirlisttcl");
        sprintf(ers(),"Tcl can not split the following string:\n\"%s\".\n",
                res);
        errfunc2();
      } else
      {
        for (i=0;i<argc;++i)
        {
          pushstack(list,(aux=stringcopy(argv[i])));
          updatepathseparators(aux,'/');
          updatepathseparators(aux,'\\');
        }
        Tcl_Free((char *) argv);
      }
    }
    disppointer((void **) &com);
    disppointer((void **) &res);
    if (flags & F_SORTMASK)
    {
      /* Not all sorting options have been taken into account, sort by acocunting
      for these options: */
      m_threadlocksleep(filesortlock,1);
      filesortflags=flags & ~F_SORTREVERSE;
      qsortstacklim(list,listmark,0,cmpfilenames);
      m_threadunlock(filesortlock);
      if ((flags & F_SORTREVERSE) && listmark>0)
      {
        /* Reverse order if flag F_SORTREVERSE is set */
        i=listmark;
        j=list->n;
        while(i<j)
        {
          name=list->s[i];
          list->s[i]=list->s[j];
          list->s[j]=name;
          ++i;
          --j;
        }
        name=NULL;
      }
    }
  } else  /* Tcl not initialized successfully */
  {
    dirlistsys(path,spec,flags,list);
  }
#else
  dirlistsys(path,spec,flags,list);
#endif
}



void dirlist(char *path,char *spec,long flags,stack list)
    /* Loads a list of files (dynamically allocated strings (char *) in the 
    directory path, which match specification spec and flags, to stack list.
    list must be initialised. If it already contains any elements, these are
    not deleted.
      path can be either relative or absolute. spec must be a glob-type
    specification containing wildcharacters such as * or ? (see system
    manuals for details) or a specific name.
      flags specify the types of files that are listed. Macros F_LISTFILES,
    F_LISTDIRS, F_LISTLINKS, F_LISTSPECIAL and F_LISTMASK can be used or any
    or-ed combination of these.
      The Tcl system is used to get the names. If Tcl can not be initialized
    properly then the dirlisttcl is called to do the work.
    $A Igor apr04; */
{
#ifdef ITK
  dirlisttcl(path,spec,flags,list);
#else
  dirlistsys(path,spec,flags,list);
#endif
}



void diractionrec(char *path,char *spec,long flags,long dirflags,
                  int maxlevel,int maxchecked,int maxworked,int printlevel,
                  int *level,int *checked,int *worked,long *signal,
                  stack list,void *pdata,
                  int action(int level,char *name,void *dataptr),
                  int preaction(int level,char *name,void *dataptr),
                  int postaction(int level,char *name,void *dataptr),
                  int postrecaction(int level,char *name,void *dataptr))
    /* Recursively performs an action on files or/and directories contained in
    path and specified by spec, which is a glob-like specification of file
    names or an empty string or NULL for all files (equivalent to "*"). flags
    specify listing and ordering flags for files and/or directories on which
    action is performes, while dirflags specify the directory listing and
    ordering flags for going into directories recursively. If either of these
    is 0, it is set to F_LISTMASK & ~F_LISTSPECIAL, which means that all files
    and directories except special files are listed and orderis system
    dependent.
      *level keeps the level of recursion (or directory level) where initial
    level 1 corresponds to path), *numlisted keeps the number of files on which
    action has been performed and worked keeps cummulative sum of all
    positive values returned by action. *maxlevel, *maxchecked and *maxworked
    are normally set to 0 at the function call. level, maxchecked and maxworked
    can be NULL in which case they are initialised to pointers that point to a
    zero integer internally at the behinning of outer recursion level. *level
    is incremented right at the beginning of function, so initial level is 1,
    not 0.
      signal is intentioned for passing signals from one level to another and
    for interrupting recursion from outside, typically from a parallel thread.
    It can be NULL, but if not, *signal should be 0.
      maxlevel, maxchecked and maxworked are define the maximal values for
    *level, *checked and *worked. Whenever any of these is reached, all
    levels of recursion exit immediately. If either of these argument is
    negative, it means that its correspoonding number (e.g. recursion level or
    number of considered files) is not limited. 
      printlevel specifies the amount of information that is printed to the
    standard output by the function during its execution. It can be 0 (no
    output at all), 1, 2, 3 or 4 (all possible information is printed). This
    is used for control mostly. Usually the action functions are ment to print
    out information for the user.
    function during execution. It can be
      Names of all recursively listed files for which action returns a positive
    number are pushed to staxk list, if it is not NULL. First part of names
    contain path so names are either absolute ore relative to path, dependend
    whether path is absolute or relative to the current directory.
      pdata is pointer that is passed to action. In this way action can store
    its own results or retreive relevant options that depend its behavior.
      action is performed on names (2. argument) of all files that are listed
    according to path, spec and flags. The first argument passed to action()
    is the recursion (sub-directory) level in which the file is listed
    (*level is passed where level is argument of diractionrec()). The third
    argument is the same as the pdata argument of the diractionrec(). action
    must return an integer, which is usually 1 if the file satisfies some
    action specific criteria (possibly defined by contents of the dataptr
    argument) and therefore some action is actually performed on the file, or 0
    otherwise. In any case, each positive return value is added to *worked,
    which can as a consequence end the performance if a nonnegative maxworked
    is reached. If action is NULL then 1 is added to *worked for each listed
    file. If ia action is NULL or its return value is positive, then the
    corresponding file name is added to the stack list.
      There are three functions similar to actoin: preaction, postaction and
    postrecaction. The only difference is that the name of the direcory which
    is being worked is passed to them, rather than a file. preaction is
    executed before the directory is listed and postaction is executed after
    the files are listed in a directory. postrecaction is executed after the
    subdirectories are listed recursively, too. Their return vlaue is also
    added to *worked, therefore they should normally return 0, unless we wanto
    thad number of listed directories contributes to the stopping criteria.
    If action or preaction is NULL, then nothing is added to *worked for each
    directory listed.
      Any or all of the action functions action, preaction or postaction can
    be NULL, this simply causes that no corresponding action is performed
    at a given time (before and after directory listing or after a file is
    listed)
    $A Igor apr04; */
{
int level0=0,numchecked0=0,numworked0=0,i,n;
long signal0=0;
stack files=NULL,dirs=NULL;
/* Update arguments for consistency: */
if (level==NULL)
  level=&level0;
if (checked==NULL)
  checked=&numchecked0;
if (worked==NULL)
  worked=&numworked0;
if (signal==NULL)
  signal=&signal0;
if (flags==0)
  flags=F_LISTMASK & ~F_LISTSPECIAL;
if (dirflags==0)
  dirflags=F_LISTMASK & ~F_LISTSPECIAL;
dirflags &= ~F_LISTSPECIAL & ~F_LISTFILES;
if (stringlength(spec)==0)
  spec="*";
++ *level;  /* mark higher recursion level */
if (maxlevel>0)
  if (*level>maxlevel)
  {
    /* return if max. level is exceeded: */
    --*level;
    return;
  }
if (*level==maxlevel)
  if (signal!=NULL)
    *signal |= F_RECLEVELREACHED;  /* Notify that requested level has been reached */
  /* ++levelreached; */
if (worked==NULL)
  worked=&numworked0;
if (flags & F_RECBYLEVELS)
{
  i= *level;
  -- *level; /* annihilate incrementation at the beginning of the function */
  /* Modify flags so that single level is worked by each function call: */
  flags |= F_RECONELEVEL;
  flags &= ~F_RECBYLEVELS;
  if (printlevel>1)
    printf("\nRecursion by levels; Current level: %i.\n",*level);
  while (maxlevel<=0 || i<=maxlevel)
  {
    if (printlevel >1)
      printf("\nWorking level %i...\n",i);
    /* Unset level reached indicator; If level i will be reached by any branch
    of the recursion, then this indicator will be set; if not, this indicates
    that we must break the loop because there are no deeper levels: */
    *signal &= ~F_RECLEVELREACHED;
    diractionrec(path,spec,flags,dirflags,
                 i,  maxchecked,maxworked,printlevel,
                 level,checked,worked,signal,
                 list,pdata,action,preaction,postaction,postrecaction);
    if ((maxchecked>0 && *checked>=maxchecked) ||
        (maxworked>0 && *worked>=maxworked) ||
        !(*signal &F_RECLEVELREACHED) || (*signal &F_RECBREAK))
    {
      /* Either stopping criteria or the deepest existent level has been
      reached or the break signal has been triggered from a parallel thread: */
      --*level;
      return;
    }
    ++i; /* increment the level */
  }
  -- *level;
  return;
}
if (!(flags & F_RECONELEVEL) || *level==maxlevel)
{
  if (preaction!=NULL)
  {
    n=preaction(*level,path,pdata);
    if (n>0)
      *worked+=n;
  }
  /* List files and perform action on them: */
  files=newstack(100);
  if (printlevel>1)
    printf("\nListing files in level %i, path: \"%s\", spec: %s\n\n",*level,path,spec);
  dirlist(path,spec,flags,files);
  if (printlevel>2)
  {
    for (i=1;i<=files->n;++i)
      printf("\"%s\"  ",files->s[i]);
  }
  if (printlevel>1)
    printf("\n");
  n=0;
  for (i=1;i<=files->n;++i)
  {
    if (action!=NULL)
      n=action(*level,files->s[i],pdata);
    else
      n=1;
    if (printlevel>3)
      if (n>0)
        printf("File \"%s\" produced working number %i.\n",files->s[i],n);
    ++ *checked;
    if (n>0)
    {
      *worked+=n;
      if (list!=NULL)
      {
        pushstack(list,files->s[i]);
        files->s[i]=NULL;
      }
    }
    /* Check for stopping criteria: */
    if ((maxchecked>0 && *checked>=maxchecked) ||
        (maxworked>0 && *worked>=maxworked) )
    {
      --*level;
      dispstackall(&files);
      /* We must perform the post-action before the early return: */
      if (postaction!=NULL)
      {
        postaction(*level,path,pdata);
        if (n>0)
          *worked+=n;
      }
      if (!(flags & F_RECONELEVEL) || *level==maxlevel)
      {
        if (postrecaction!=NULL)
        {
          n=postrecaction(*level,path,pdata);
          if (n>0)
            *worked+=n;
        }
      }
      return;
    }
  }
  dispstackall(&files);
  if (postaction!=NULL)
  {
    postaction(*level,path,pdata);
    if (n>0)
      *worked+=n;
  }
}
if (maxlevel<=0 ||  *level<maxlevel)
{
  /* Further recursion: list directories */
  dirs=newstack(10);
  dirflags &= ~F_LISTSPECIAL & ~F_LISTFILES;
  dirlist(path,"*",dirflags,dirs);
  if (printlevel>0 && dirs->n>0)
    printf("\nLevel %i, Continue recursion...\n",*level);
  for (i=1;i<=dirs->n;++i)
  {
    /* Continue recursion on the listed directories: */
    if (printlevel>1)
      printf("\n  Continue recursion on the directory %s...\n",dirs->s[i]);
    diractionrec(dirs->s[i],spec,flags,dirflags,
                 maxlevel,maxchecked,maxworked,printlevel,
                 level,checked,worked,signal,
                 list,pdata,action,preaction,postaction,postrecaction);
    if ((maxchecked>0 && *checked>=maxchecked) ||
        (maxworked>0 && *worked>=maxworked) )
    {
      /* Stopping criteria has been reached: */
      --*level;
      dispstackall(&dirs);
      /* We must perform the post-action before the early return: */
      if (!(flags & F_RECONELEVEL) || *level==maxlevel)
      {
        if (postrecaction!=NULL)
        {
          n=postrecaction(*level,path,pdata);
          if (n>0)
            *worked+=n;
        }
      }
      return;
    }
  }
}
if (!(flags & F_RECONELEVEL) || *level==maxlevel)
{
  if (postrecaction!=NULL)
  {
    n=postrecaction(*level,path,pdata);
    if (n>0)
      *worked+=n;
  }
}
--*level; /* restore level of the previous recursion */
}




/* ACTION FUNCTIONS FOR USE WITH diractionrec(): PRINT DIR. TREE SIZE
Use settreesizespec() to define the behaviour. The dataptr argument of 
diractionrec() must be a pointer to an empty stack or NULL. After the
function call there are two double pointers on this stack, the first one
is the total number of files while the last one is the total size.
  Remarks:
  In number of files contained in directly directories or in whole trees,
directories may be also counted. To prevent this, unset the F_LISTDIRS in the
flags argument of diractionrec(). */


static int treesizeer=0;  /* internal use */
static stack treesizest=NULL;  /* internal use */
static FILE *treesizefp=NULL/* stdout */,*treesizefp1=NULL;  /* output files */
/* Printing options: */
static int treesizeprintdirs=1,treesizeprintfiles=1,
           treesizeindent=2;
static char treesizesep=',';


void settreesizespec(FILE *fp1,FILE *fp2,int printdirs,int printfiles,
                     int indent,char numsep)
    /* Defines the behaviour of getting and writing tree size by diractionrec()
    and the appropriate action functions as arguments.
    fp1, fp2: files to which output is written; either of them or both can be
    NULL.
    printdirs: whether to print data about directories.
    printfiles: whether to print data about files.
    indent: Number of spaces used for indentation - must be 0 or positive.
    numsep: Separator character used as a 1000 separator in number output.
    If it is '0' or '\0', numbers are printed without 1000 separators.
    $A Igor apr03; */
{
if (indent<0)
  indent=0;
treesizefp=fp1;
treesizefp1=fp2;
treesizeprintdirs=printdirs;
treesizeprintfiles=printfiles;
treesizeindent=indent;
treesizesep=numsep;
}


int printtreesizepreaction(int level,char *name,void *dataptr)
    /* The preaction argument for printing the tree size by the diractionrec().
    $A Igor apr03; */
{
stack sizes;
double *psize;
if (dataptr==NULL)
{
  if (treesizest==NULL)
    treesizest=newstack(10);
  dataptr=treesizest;
}
sizes=dataptr;
/* Add file and size counters to the stack: */
psize=malloc(sizeof(*psize));
*psize=0;
pushstack(sizes,psize);
psize=malloc(sizeof(*psize));
*psize=0;
pushstack(sizes,psize);
if (treesizeprintdirs)
{
  if (treesizefp!=NULL)
  {
    fprintf(treesizefp,"\n");
    fprintf(treesizefp,"%*s",(level-1)*treesizeindent,"");
    fprintf(treesizefp,"\"%s\":\n",name);
  }
}
return 0;
}


int printtreesizeaction(int level,char *name,void *dataptr)
    /* The action argument for printing the tree size by the diractionrec().
    $A Igor apr03; */
{
double size,*psize;
stack sizes;
if (dataptr==NULL)
{
  dataptr=treesizest;
  if (!treesizeer)
  {
    errfunc0("printtreesizeaction");
    sprintf(ers(),"No space for saving size information is given,\n");
    sprintf(ers(),"should be a pointer to two double int numbers.\n");
    errfunc2();
    ++treesizeer;
  }
}
sizes=dataptr;
size=filelength(name);
psize=nstack(sizes,1);
*psize+=size;
psize=nstack(sizes,2);
++*psize;
if (treesizeprintfiles)
{
  if (treesizefp!=NULL)
  {
    fprintf(treesizefp,"%*s",(level)*treesizeindent,"");
    /*
    fprintf(treesizefp,"%-11.15lg \"%s\"\n",size,name);
    */
    fprintdoublesep(treesizefp,size,treesizesep,"-",10,15,"lg");
    fprintf(treesizefp," %s\n",name);
  }
}
return 1;
}


int printtreesizepostaction(int level,char *name,void *dataptr)
    /* The postaction argument for printing the tree size by the diractionrec().
    $A Igor apr03; */
{
stack sizes;
double size,num,*psize;
if (dataptr==NULL)
{
  dataptr=treesizest;
}
sizes=dataptr;
/* Keep the last pair for file number and size, add one for sub-tree size: */
psize=nstack(sizes,2);
num=*psize;
psize=malloc(sizeof(*psize));
*psize=num;
pushstack(sizes,psize);
psize=nstack(sizes,2);
size=*psize;
psize=malloc(sizeof(*psize));
*psize=size;
pushstack(sizes,psize);
if (treesizeprintdirs)
{
  if (treesizefp!=NULL)
  {
    fprintf(treesizefp,"%*s",(level-1)*treesizeindent,"");
    fprintf(treesizefp,"------------ \"%s\"\n",name);
    fprintf(treesizefp,"%*s",(level-1)*treesizeindent,"");
    fprintdoublesep(treesizefp,size,treesizesep,"-",0,15,"lg");
    fprintf(treesizefp," bytes in ");
    fprintdoublesep(treesizefp,num,treesizesep,"-",0,15,"lg");
    fprintf(treesizefp," files\n");
  }
}
return 0;
}


int printtreesizepostrecaction(int level,char *name,void *dataptr)
    /* The postrecaction argument for printing the tree size by the
    diractionrec().
    $A Igor apr03; */
{
stack sizes;
double size,num,*psize;
if (dataptr==NULL)
{
  dataptr=treesizest;
}
sizes=dataptr;
/* Recursive listings have cleaned their data; One pointer before last contains
file size, the last one contains total sub-tree size, the previous two contain
partial data for files: */
psize=nstack(sizes,1);
size=*psize;
psize=nstack(sizes,2);
num=*psize;
if (treesizeprintdirs)
{
  if (treesizefp!=NULL)
  {
    fprintf(treesizefp,"\n");
    fprintf(treesizefp,"%*s",(level-1)*treesizeindent,"");
    fprintf(treesizefp,"========== %s\n",name);
    psize=nstack(sizes,3);
    fprintf(treesizefp,"%*s",(level-1)*treesizeindent,"");
    fprintdoublesep(treesizefp,*psize,treesizesep,"-",0,15,"lg");
    fprintf(treesizefp," bytes, ");
    psize=nstack(sizes,4);
    fprintdoublesep(treesizefp,*psize,treesizesep,"-",0,15,"lg");
    fprintf(treesizefp," files\n");
    fprintf(treesizefp,"%*s",(level-1)*treesizeindent,"");
    fprintdoublesep(treesizefp,size,treesizesep,"-",0,15,"lg");
    fprintf(treesizefp," total, ");
    fprintdoublesep(treesizefp,num,treesizesep,"-",0,15,"lg");
    fprintf(treesizefp," files.\n\n");
  }
}
/* Clean directory sizes & add sub-tree size to containing directory: */
if (sizes->n>4)
{
  free(popstack(sizes));
  free(popstack(sizes));
  free(popstack(sizes));
  free(popstack(sizes));
  
  psize=nstack(sizes,1);
  *psize+=size;
  psize=nstack(sizes,2);
  *psize+=num;
} else
{
  /* Recursion is done, leave the total size for outer-most directory on the
  stack: */
  if (sizes->n>2)
  {
    free(delstack(sizes,1));
    free(delstack(sizes,1));
  }
}
return 0;
}



/* Empty action functions for use with diractionrec(): just count listed files.
Remark: when diractionrec() is called, the action arguments can be NULL except
the action. */


int dirrecaction0(int level,char *name,void *dataptr)
{
return 1;
}

int dirrecpreaction0(int level,char *name,void *dataptr)
{
return 0;
}

int dirrecpostaction0(int level,char *name,void *dataptr)
{
return 0;
}

int dirrecpostrecaction0(int level,char *name,void *dataptr)
{
return 0;
}





void testfilesysop(void)
    /* A test function for tools for interaction with the file system.
    $A Igor apr04; */
{
char *path=NULL,*chpath=NULL,*currentdir=NULL;
int cont=1,create=0,remdir=0,testrec=1,testlist=1;
int i=0,n;
stack words=NULL;
char *spec=NULL;
long flags=F_LISTMASK|F_SORTNAME|F_SORTEXT,dirflags=F_LISTMASK,setsortflags=0,
    setlistflags=0,setdirlistflags=0;
double t1,t2,ct1,ct2;
int level,checked,worked,maxlevel=10,maxchecked=10000,maxworked=10000,
    printlevel=2,whichaction=0;
stack list=NULL,sizestack=NULL;
void *dataptr=NULL;
int (*preaction)(int,char *,void *)=NULL;
int (*action)(int,char *,void *)=NULL;
int (*postaction)(int,char *,void *)=NULL;
int (*postrecaction)(int,char *,void *)=NULL;
words=newstack(30);
path=stringcopy("numut.c");
while (cont)
{
  printf("Current directory: %s.\n",getcurrentdir());
  printf("\nFile or directory: ");  readstring(&path);
  printf("fileordirexists: %i.\n",fileordirexists(path));
  if (direxists(path))
  {
    printf("\nDirectory %s exists.\n",path);
  } else
    printf("\nDirectory %s does not exist.\n",path);
  if (dirwritable(path))
  {
    printf("\nDirectory %s is writable.\n",path);
  } else
    if (direxists(path))
      printf("\nDirectory %s is not writable.\n",path);
  if (fileexists(path))
  {
    printf("\nFile \"%s\" exists.\n",path);
    printf("Length of the file %s: %li bytes.\n",path,filelength(path));
    if (filewritable(path))
      printf("File is writable. ");
    else
      printf("File is not writable. ");
    if (filereadable(path))
      printf("File is readable.\n");
    else
      printf("File is not readable.\n");
  } else
    printf("\nFile %s does not exist.\n",path);
  printf("\n\n\nTest recursive directory operations (0/1)? ",
    path);
  readint(&testrec);
  disppointer((void **) &path);
  disppointer((void **) &spec);
  while (testrec)
  {
    /* TESTING RECURSIVE OPERATIONS ON DIRECTORIES: */
    printf("\n\n\n|%s>\n",getcurrentdir());
    printf("\nFile listing test...\n");
    disppointer((void **) &chpath);
    printf("\nChange dir. to (<Enter for none>): ");
    readstring(&chpath);
    if (stringlength(chpath)>0)
    {
      printf("Dir. cleaned absolute path: %s\n",getargpath(chpath));
      if (direxists(chpath))
      {
        printf("Directory \"%s\" exists",chpath);
        if (dirwritable(chpath))
          printf(" and is writable.\n");
        else printf(", but is not writable.\n");
        if (setcurrentdir(chpath)<0)
          printf("Could not change to this directory.\n");
      } else
      {
        printf("Directory \"%s\" does not exist, create it (0/1)? "); readint(&create);
        if (create)
        {
          if (createdirsafe(chpath)<0)
          printf("Could not create the directory %s.\n",chpath);
          else
          {
            printf("Directory \"%s\" created.\n",chpath);
            if (setcurrentdir(chpath)<0)
              printf("Could not change the directory to \"%s\".\n",chpath);
          }
        }
      }
    }
    printf("|%s>\n",getcurrentdir());
    dispstackval(words);
    printf("\nListing path: "); readstring(&path);
    printf("Name specification: "); readstring(&spec);
    printf("Maximum level: "); readint(&maxlevel);
    printf("Maximum number of checked files: "); readint(&maxchecked);
    printf("Maximum number of worked files: "); readint(&maxworked);
    printf("Printing level: "); readint(&printlevel);

    printf("Flags: ");  printintflags(flags & F_LISTMASK);
    printf("\n\nChange file listing flags? "); readlong(&setlistflags);
    if (setlistflags)
    {
      printf("  Specify file listing flags!\n");
      printf("List files?             "); readlongflags(&flags,F_LISTFILES);
      printf("List directories?       "); readlongflags(&flags,F_LISTDIRS);
      printf("List links?             "); readlongflags(&flags,F_LISTLINKS);
      printf("List special files?     "); readlongflags(&flags,F_LISTSPECIAL);
    }
    printf("\nChange sorting flags? "); readlong(&setsortflags);
    if (setsortflags)
    {
      printf("  Specify file sorting flags!\n");
      printf("Sort by name?                "); readlongflags(&flags,F_SORTNAME);
      printf("Sort by extension?           "); readlongflags(&flags,F_SORTEXT);
      printf("Sort by size?                "); readlongflags(&flags,F_SORTSIZE);
      printf("Sort by creation time?       "); readlongflags(&flags,F_SORTCTIME);
      printf("Sort by modification time?   "); readlongflags(&flags,F_SORTMTIME);
      printf("Sort by last access time?    "); readlongflags(&flags,F_SORTATIME);
      printf("Sort directories first?      "); readlongflags(&flags,F_SORTDIRSFIRST);
      printf("Sort files first?            "); readlongflags(&flags,F_SORTFILESFIRST);
      printf("Reverse sorting order?       "); readlongflags(&flags,F_SORTREVERSE);

      printf("\nRecursion by levels?         "); readlongflags(&flags,F_RECBYLEVELS);
      printf("Only one level?              "); readlongflags(&flags,F_RECONELEVEL);
    }
    printf("\n\nChange directgory listing flags? "); readlong(&setdirlistflags);
    if (setdirlistflags)
    {
      printf("  Specify directory listing flags!\n");
      printf("List directories?       "); readlongflags(&dirflags,F_LISTDIRS);
      printf("List links?             "); readlongflags(&dirflags,F_LISTLINKS);
    }
    printf("\nChoose an action:\n");
    printf("  0: No action.\n");
    printf("  1: Actions that do nothing.\n");
    printf("  2: Tree size\n");
    printf("Enter your choice: "); readint(&whichaction);
    if (whichaction==0)
    {
      preaction=action=postaction=postrecaction=NULL;
    } else if (whichaction==1)
    {
      preaction=dirrecpreaction0;
      action=dirrecaction0;
      postaction=dirrecpostaction0;
      postrecaction=dirrecpostrecaction0;
    } else if (whichaction==2)
    {
      preaction=printtreesizepreaction;
      action=printtreesizeaction;
      postaction=printtreesizepostaction;
      postrecaction=printtreesizepostrecaction;
      printf("Note: Printing level will be set to 0 for this action.\n");
      printlevel=0;
      dispstackall(&sizestack);
      sizestack=newstack(12);
      dataptr=sizestack;
    }
    level=checked=worked=0;
    if (list==NULL)
      list=newstack(30);
    dispstackval(list);
    level=checked=worked=0;
    t1=absolutetime();  ct1=cputime();
    
    diractionrec(path,spec,flags,dirflags,
                  maxlevel,maxchecked,maxworked, printlevel,
                  &level,&checked,&worked,NULL,
                  list,dataptr,action,preaction,postaction,postrecaction);
    t2=absolutetime();  ct2=cputime();
    printf("\n\nRecursive action finished.\n");
    printf("Time spent: %g s (CPU %g).\n\n",t2-t1,ct2-ct1);
    if (whichaction==0)
    {
      printf("Files on the list:\n");
      for (i=1;i<=list->n;++i)
        printf("%s ",list->s[i]);
      printf("\n");
    } else if (whichaction==1)
    {
      printf("Files on the list:\n");
      for (i=1;i<=list->n;++i)
        printf("%s ",list->s[i]);
      printf("\n");
    } else if (whichaction==2)
    {
      double *psize;
      psize=nstack(sizestack,1);
      printf("\nTOTAL dir. tree size: ");
      printdoublesep(*psize,'\'',NULL,0,30,"lg");
      printf(" bytes in ");
      psize=nstack(sizestack,2);
      printdoublesep(*psize,'\'',NULL,0,30,"lg");
      printf(" files.\n");
    }

    printf("\nContinue Testing recursive dir. operations (0/1)? ");
    readint(&testrec);
  }
  printf("\n\n\nTest listing utilities (0/1)? ");
  readint(&testlist);
  while (testlist)
  {
    /* TESTING FILE LISTING UTILITIES: */
    printf("\n\n\n|%s>\n",getcurrentdir());
    printf("\nFile listing test...\n");
    disppointer((void **) &chpath);
    printf("\nChange dir. to (<Enter for none>): ");
    readstring(&chpath);
    if (stringlength(chpath)>0)
    {
      printf("Dir. cleaned absolute path: %s\n",getargpath(chpath));
      if (direxists(chpath))
      {
        printf("Directory \"%s\" exists",chpath);
        if (dirwritable(chpath))
          printf(" and is writable.\n");
        else printf(", but is not writable.\n");
        if (setcurrentdir(chpath)<0)
          printf("Could not change to this directory.\n");
      } else
      {
        printf("Directory \"%s\" does not exist, create it (0/1)? "); readint(&create);
        if (create)
        {
          if (createdirsafe(chpath)<0)
          printf("Could not create the directory %s.\n",chpath);
          else
          {
            printf("Directory \"%s\" created.\n",chpath);
            if (setcurrentdir(chpath)<0)
              printf("Could not change the directory to \"%s\".\n",chpath);
          }
        }
      }
    }
    printf("|%s>\n",getcurrentdir());
    dispstackval(words);
    printf("\nListing path: "); readstring(&path);
    printf("Name specification: "); readstring(&spec);

    printf("Flags: ");  printintflags(flags & F_LISTMASK);
    printf("\n\nChange listing flags? "); readlong(&setlistflags);
    if (setlistflags)
    {
      printf("  Specify listing flags!\n");
      printf("List files?             "); readlongflags(&flags,F_LISTFILES);
      printf("List directories?       "); readlongflags(&flags,F_LISTDIRS);
      printf("List links?             "); readlongflags(&flags,F_LISTLINKS);
      printf("List special files?     "); readlongflags(&flags,F_LISTSPECIAL);
    }
    printf("\nChange sorting flags? "); readlong(&setsortflags);
    if (setsortflags)
    {
      printf("  Specify sorting flags!\n");
      printf("Sort by name?                "); readlongflags(&flags,F_SORTNAME);
      printf("Sort by extension?           "); readlongflags(&flags,F_SORTEXT);
      printf("Sort by size?                "); readlongflags(&flags,F_SORTSIZE);
      printf("Sort by creation time?       "); readlongflags(&flags,F_SORTCTIME);
      printf("Sort by modification time?   "); readlongflags(&flags,F_SORTMTIME);
      printf("Sort by last access time?    "); readlongflags(&flags,F_SORTATIME);
      printf("Sort directories first?      "); readlongflags(&flags,F_SORTDIRSFIRST);
      printf("Sort files first?            "); readlongflags(&flags,F_SORTFILESFIRST);
      printf("Reverse sorting order?       "); readlongflags(&flags,F_SORTREVERSE);
    }
    printf("Number of repetions: "); readint(&n);
    if (n<=1)
    {
      printf("\nListing dir. \"%s\", spec. \"%s\":\n\n",path,spec);
      dirlisttcl(path,spec,flags,words);
      if (words->n==0)
        printf("No files found.\n");
      else for (i=1;i<=words->n;++i)
        printf("%i: \"%s\"\n",i,words->s[i]);
    } else
    {
      printf("Directory listing in a loop...\n");
      t1=absolutetime();  ct1=cputime();
      for (i=1;i<=n;++i)
      {
        dispstackval(words);
        dirlist(path,spec,flags,words);
      }
      t2=absolutetime();  ct2=cputime();
      if (words->n==0)
        printf("No files found.\n");
      else for (i=1;i<=words->n;++i)
        printf("\"%s\" ",words->s[i]);
      printf("\n");
      printf("Time spent: CPU %g s, abs. %g s.\n",ct2-ct1,t2-t1);
    }
    printf("\nContinue Testing listing utilities (0/1)? ");
    readint(&testlist);
  }
  if (1)
  {
    printf("\n\n\n|%s>\n",getcurrentdir());
    printf("\nChange dir. to (<Enter for none>): ");
    disppointer((void **) &chpath);
    readstring(&chpath);
    if (stringlength(chpath)>0)
    {
      printf("Dir. cleaned absolute path: %s\n",getargpath(chpath));
      if (direxists(chpath))
      {
        printf("Directory \"%s\" exists",chpath);
        if (dirwritable(chpath))
          printf(" and is writable.\n");
        else printf(", but is not writable.\n");
        if (setcurrentdir(chpath)<0)
          printf("Could not change to this directory.\n");
      } else
      {
        printf("Directory \"%s\" does not exist, create it (0/1)? "); readint(&create);
        if (create)
        {
          if (createdirsafe(chpath)<0)
          printf("Could not create the directory %s.\n",chpath);
          else
          {
            printf("Directory \"%s\" created.\n",chpath);
            if (setcurrentdir(chpath)<0)
              printf("Could not change the directory to \"%s\".\n",chpath);
          }
        }
      }
    }
    printf("|%s>\n",getcurrentdir());
    disppointer((void **) &chpath);
    printf("\nCREATE dir. (<Enter> to skip): ");
    readstring(&chpath);
    if (stringlength(chpath)>0)
    {
      printf("Clean absolute path: %s\n",getargpath(chpath));
      if (createdir(chpath)<0)
        printf("Directory could not be created.\n");
      else
      {
        if (!direxists(chpath))
          printf("Directory was created, but it does not exists (strange!).\n");
        else if (dirwritable(chpath))
          printf("The created directory is writable.\n");
        else
          printf("The created diretory is not writable.\n");
      }
    }
    disppointer((void **) &chpath);
    printf("\nREMOVE dir. (<Enter> to skip): ");
    readstring(&chpath);
    if (removedir(chpath)<0)
    {
      printf("Could not remove dir, possibly non-empty.\n");
      printf("\n\nApplying recursive remove for dir. %s (0/1)?"); readint(&remdir);
      if (remdir)
      {
        if (removedirrec(chpath)<0)
          printf("Sorry, could not remove the directory \"%s\".\n",chpath);
        else
        {
          if (direxists(chpath))
            printf("Directory has been removed, but still exists (strange!).\n");
          else
            printf("Directory successfully removed.\n");
        }
      }
    } else
    {
      if (direxists(chpath))
        printf("Directory has been removed, but still exists (strange!).\n");
      else
        printf("Directory successfully removed\n");
    }
    disppointer((void **) &chpath);
  }
  printf("\n\nContinue the main loop? "); readint(&cont);
  if (!cont)
    break;
}
}






      /****************************/
      /*                          */
      /*  SUPPLEMENT TO system()  */
      /*                          */
      /****************************/


char *filetostr(char *filename,int *length)
    /* Copies the complete contents of the file named filename to a dynamically
    allocated string and returns this string. If length!=NULL, the number of
    bytes successfully copied from the file is returned in length. The
    allocated space in the returned string is one byte more than the file
    length and string is zero terminated (therefore, if the file does not
    contain zero characters, we don't the need length information).
    $A Igor jan03; */
{
int l=0,read=0,lengthlimit=10000000;
char *ret=NULL;
FILE *fp;
fp=fopen(filename,"rb");
if (fp==NULL)
{
  errfunc0("filetostr");
  sprintf(ers(),"File \"%s\" could not be opened.\n",filename);
  errfunc2();
} else
{
  l=flength(fp);
  if (l>lengthlimit)
  {
    errfunc0("filetostr");
    sprintf(ers(),"File \"%s\" is too long to copy it to a string.\n",filename);
    sprintf(ers(),"File length is %i bytes while the limit is %i bytes (ratio: %g).\n",
      l,lengthlimit,(double) l/(double) lengthlimit);
    errfunc2();    
  } else
  {
    ret=malloc(l+1);
    read=fileread(ret,1,l,fp,1);
    ret[read]='\0';
    if (read<l)
    {
      errfunc0("filetostr");
      sprintf(ers(),"File \"%s\" could not be read completely.\n",filename);
      sprintf(ers(),"%i of %i bytes were read.\n",read,l);
      errfunc2();
    }
  }
  fclose(fp);
}
if (length!=NULL)
  *length=l;
return ret;
}


char *systemresstr0(char *command)
    /* Returns a string that contains all the output of command to the standard
    output, when executed by the operating system. The returned string is
    dynamically allocated and can be deallocated by free().
      Warning: standard error is not redirected when executing this function!
    $A Igor dec02; */
{
char *ret=NULL,*filename=NULL,*com=NULL,*buf=NULL;
long length=0;
FILE *fp=NULL;
if (command!=NULL)
{
  filename=tmpnam(NULL);
  if (filename==NULL)
  {
    errfunc0("systemresstr0");
    sprintf(ers(),"The operating system failed to provide a temporary file name.\n");
    errfunc2();
  } else 
  {
    com=multstringcatn(3,command," > ",filename);
    remove(filename);
    system(com);
    if (fileexists(filename))
      ret=filetostr(filename,NULL);
    remove(filename);
    disppointer((void **) &com);
  }
}
return ret;
}


static int rde=-1;  /* standard error redirection possible */
static int csh=-1;  /* csh-like shell on UNIX */
static int redirer(void);

static int cshsyntax(void)
    /* Checks if the UNIX shell currently used is csh or tcsh; if it is, it
    returns 1, otherwise it returns 0. It is important to know this information
    e.g. because of different ways of redirecting the standard error - between
    the csh and tcsh on one hand and the other shells on the other.
      Warning: Checking is performed on a rather primitive way - by executing
    the ps command and checking if the string "csh" appears in the command output.
    $A Igor jan03; */
{
char *output=NULL;
#ifndef UNIX
 csh=0;
#else
if (csh<0)
{
  /* The check has not yet been performed, perform it now: */
  output=systemresstr0("ps");
  if (memfind(output,stringlength(output),"csh",3)!=NULL)
    csh=1;
  else
    csh=0;
  disppointer((void **) output);
  if (csh)
  {
    if (!redirer())
    {
      /* We have initially established that the csh syntax applies, but it
      appears that standard error can not be redirected by using this syntax;
      Try with the sh syntax; if successfull, then conclude that the sh
      syntax applies: */
      csh=0;
      rde=-1;
      if (!redirer())
      {
        /* Change did not work out, reverse it: */
        csh=1;
        warnfunc1(1,"cshsyntax");
        sprintf(ers(),"Could not reliably determine whether csh (and tcsh) shell syntax applies on this system.\n");
        sprintf(ers(),"It is assumed that it applies.\n");
        warnfunc2();
      }
    }
  } else
  {
    if (!redirer())
    {
      /* We have initially established that the sh syntax applies, but it
      appears that standard error can not be redirected by using this syntax;
      Try with the csh syntax; if successfull, then conclude that the csh
      syntax applies: */
      csh=1;
      rde=-1;
      if (!redirer())
      {
        /* Change did not work out, reverse it: */
        csh=0;
        warnfunc1(1,"cshsyntax");
        sprintf(ers(),"Could not reliably determine whether csh (and tcsh) shell syntax applies on this system.\n");
        sprintf(ers(),"It is assumed that it does not apply.\n");
        warnfunc2();
      }
    }
  }
}
#endif  /* defined UNIX */
return csh;
}

static int redirer(void)
    /* Checks if the standart error can be redirected in the system() function.
    Returns 1 if it can be, 0 if it can not be.
    $A Igor jan03; */
{
char *str=NULL;
static int warnset=0;
#ifdef UNIX
 if (csh<0)
   cshsyntax();
#endif
if (rde<0)
{
  /* It is not yet known if standard error redirection is possible, check it: */
  rde=1;  /* prevent infinite recursion */
  #ifdef DOSWN
    systemouterstr("dir /jkaljfltueiowtas",NULL,&str);
  #elif defined(UNIX)
   systemouterstr("ls -jkaljfltueiowtas",NULL,&str);
  #else
    systemouterstr("bjkatjaklgjkalljgkl",NULL,&str);
  #endif
  if (stringlength(str)>0)
    rde=1;
  else
  {
    rde=0;
    if (!warnset)
    {
      warnset=1;  /* Prevents of reporting this error several times */
      warnfunc1(1,"redirer");
      sprintf(ers(),"It appears that standard error can not be redirected on this operating system.\n");
      sprintf(ers(),"Some less important system dependent functions might not function correctly.\n");
      sprintf(ers(),"Error messages from programs executed via the OS will not be captured.\n");
      sprintf(ers(),"This should not represent a major problem for program functionality.\n");
      warnfunc2();
    }
  }
  disppointer((void **) &str);
}
return rde;
}

int systemouterstr(char *command,char **out,char **er)
    /* Returns a string that contains all the output of sommand to the standard
    output, when executed by the operating system. The returned string is
    dynamically allocated and can be deallocated by free(). Function returns
    the code returned by system().
      Warning: standard error is not redirected when executing the file!
    $A Igor jan03; */
{
char *filename=NULL,*erfilename=NULL,*com=NULL,*buf=NULL;
long length=0;
FILE *fp=NULL;
int ret=0;
disppointer((void **) out);
disppointer((void **) er);
if (command!=NULL)
{
  filename=stringcopy(tmpnam(NULL));
  erfilename=stringcopy(tmpnam(NULL));
  if (filename==NULL || erfilename==NULL)
  {
    errfunc0("systemouterstr");
    sprintf(ers(),"The operating system failed to provide two temporary file names.\n");
    errfunc2();
  } else
  {
    if (redirer())
    {
      #if defined(DOSWN)
       com=multstringcatn(5,command," > ",filename," 2> ",erfilename);
      #elif defined(UNIX)
       if (cshsyntax())
       {
         com=multstringcatn(6,"(( ",command," ) > ",filename," ) >& ",erfilename);
       } else
       {
         com=multstringcatn(5,command," > ",filename," 2> ",erfilename);
       }
      #endif
    } else
    {
      /* Redirection of standard error not possibleon this system, only the
      standard output is redirected: */
      com=multstringcatn(3,command," > ",filename);
    }
    ret=system(com);
    if (out!=NULL && fileexists(filename))
      *out=filetostr(filename,NULL);
    if (er!=NULL && fileexists(erfilename))
      *er=filetostr(erfilename,NULL);
    remove(filename);
    remove(erfilename);
    disppointer((void **) &com);
  }
} else
  ret=system(NULL);
disppointer((void **) &filename);
disppointer((void **) &erfilename);
return ret;
}


char *systemresstr(char *command)
    /* Returns a string that contains all the output of command to the standard
    output, when executed by the operating system. The returned string is
    dynamically allocated and can be deallocated by free(). If possible, the
    standard error is also redirected when executing the command, so that its
    error messages are not printed to the terminal.
    $A Igor dec02; */
{
char *res=NULL;
systemouterstr(command,&res,NULL);
return res;
}



FILE *fopensafe(char *name,char *mode)
    /* Odpre datoeko z imenom name in na nacin mode. Ce dtoteke ne more
    odpreti ali ce je name ali mode NULL, vprasa uporabnika za ime datoteke in
    nacin odprtja. V koncni fazi se lahko uporabnik odloci tudi, da se dateke
    ne odpre.
    $A Igor jan01; */
{
FILE *fp=NULL;
char *name1=NULL,*mode1=NULL;
double doopen=1;
if (name!=NULL && mode!=NULL)
  fp=fopen(name,mode);
if (fp==NULL)
{
  name1=stringcopy(name);
  mode1=stringcopy(mode);
  printf("\n\nWARNING:\nFile \"%s\" could not be open in mode \"%s\".\n",name1,mode1);
  printf("Insert new name or/and mode! Press return for retaining the old string\n");
  printf("or insert \"\\ \\\" to append to the old string!\n");
  printf("\nFile name: ");  readstring(&name1);
  fp=fopen(name1,mode1);
  if (fp==NULL)
  {
    printf("\nFile \"%s\" could not be open in mode \"%s\".\n",name1,mode1);
    printf("\nFile mode: ");  readstring(&mode1);
    fp=fopen(name1,mode1);
    while (fp==NULL && doopen)
    {
      printf("\nFile \"%s\" could not be open in mode \"%s\".\n",name1,mode1);
      printf("Try again with new parameters (0/1)? "); readdouble(&doopen);
      if (doopen)
      {
        printf("\nFile name: ");  readstring(&name1);
        printf("\nFile mode: ");  readstring(&mode1);
        fp=fopen(name1,mode1);
      }
    }
  }
  printf("\n\n");
}
disppointer((void **) &name1);
disppointer((void **) &mode1);
return fp;
}


FILE *fopensafeaddr(char **name,char **mode)
    /* Odpre datoeko z imenom *name in na nacin *mode. Ce dtoteke ne more
    odpreti ali ce je *name ali *mode NULL, vprasa uporabnika za ime datoteke
    in nacin odprtja. V koncni fazi se lahko uporabnik odloci tudi, da se
    dateke ne odpre. Razlika s funkcijo fopensafe() je v tem, da se *name in
    *mode spremenita na koncni vrednosti, kot ju (po moznosti) doloci
    uporabnik. Zaradi tega pa morata *name in *mode OBVEZNO kazati na niz,
    ki se lahko brise s free().
    $A Igor jan01; */
{
FILE *fp=NULL;
double doopen=1;
if (name!=NULL && mode!=NULL)
{
  if (*name!=NULL && *mode!=NULL)
    fp=fopen(*name,*mode);
  if (fp==NULL)
  {
    printf("\n\nWARNING:\nFile \"%s\" could not be open in mode \"%s\".\n",*name,*mode);
    printf("Insert new name or/and mode! Press return for retaining the old string\n");
    printf("or insert \"\\ \\\" to append to the old string!\n");
    printf("\nFile name: ");  readstring(name);
    if (*name!=NULL && *mode!=NULL)
      fp=fopen(*name,*mode);
    if (fp==NULL)
    {
      printf("\nFile \"%s\" could not be open in mode \"%s\".\n",*name,*mode);
      printf("\nFile mode: ");  readstring(mode);
      if (*name!=NULL && *mode!=NULL)
        fp=fopen(*name,*mode);
      while (fp==NULL && doopen)
      {
        printf("\nFile \"%s\" could not be open in mode \"%s\".\n",*name,*mode);
        printf("Try again with new parameters (0/1)? "); readdouble(&doopen);
        if (doopen)
        {
          printf("\nFile name: ");  readstring(name);
          printf("\nFile mode: ");  readstring(mode);
          if (*name!=NULL && *mode!=NULL)
            fp=fopen(*name,*mode);
        }
      }
    }
    printf("\n\n");
  }
}
return fp;
}




size_t fileread(void *ptr,size_t elsize,size_t n,FILE *fp,long pos)
       /* Iz datoteke fp prebere n*elsize bytov v spomin. lokacijo, na katero
       kaze ptr, od pozicije pos naprej. Vrne stevilo v resnici prebranih
       bytov. */
{
size_t ret;
if (elsize<1 || n<1)
  return 0;
/* fflush(fp); */
fseek(fp,pos-1,SEEK_SET);
ret=fread(ptr,elsize,n,fp);
fflush(fp);
return ret;
}

long flength(FILE *fp)
        /* Vrne dolzino datoteke, ki je povezana z datotecnim kazalcem fp */
{
/* fflush(fp); */
fseek(fp,0,SEEK_END);
/* fflush(fp); */
return(ftell(fp));
}


char *filereadline(FILE *fp,int maxlength)
     /* Vrne niz, v katerega prebere vrstico iz datoteke fp. Ta niz lahko brises
     z ukazom free. Zakljucni znaki za vrstico so \n, \r in \0. Najvecje st.
     znakov, ki jih funkcija prebere, je maxlength. */
{
char *buf,*ret;
if (maxlength>0)
{
  buf=makestring(maxlength);
  fgets(buf,maxlength+1,fp);
  if (buf[strlen(buf)-1]=='\n' || buf[strlen(buf)-1]=='\r')
    buf[strlen(buf)-1]='\0';
  ret=stringcopy(buf);
  free(buf);
  return ret;
} else return NULL;
}

char *_filereadline(FILE *fp,int maxlength)
     /* Vrne niz, v katerega prebere vrstico iz datoteke fp. Ta niz lahko brises
     z ukazom free. Zakljucni znaki za vrstico so \n, \r in \0. Najvecje st.
     znakov, ki jih funkcija prebere, je maxlength. */
{
char *buf,*ret;
if (maxlength>0)
{
  buf=makestring(maxlength);
  fgets(buf,maxlength+1,fp);
  ret=stringcopy(buf);
  free(buf);
  return ret;
} else return NULL;
}

char *readline(int maxlength)
     /* Vrne niz, v katerega prebere vrstico s stand. zas. Ta niz lahko brises
     z ukazom free. Zakljucni znaki za vrstico so \n, \r in \0. Najvecje st.
     znakov, ki jih funkcija prebere, je maxlength. */
{
char *buf,*ret;
if (maxlength>0)
{
  buf=makestring(maxlength);
  gets(buf);
  ret=stringcopy(buf);
  free(buf);
  return ret;
} else return NULL;
}


/*
char *readline(int maxlength)
     /* Vrne niz, v katerega prebere vrstico iz std. inp. Ta niz lahko brises
     z ukazom free. Zakljucni znaki za vrstico so \n, \r in \0. Najvecje st.
     znakov, ki jih funkcija prebere, je maxlength.
{
return filereadline(stdout,maxlength);
}
*/



char *filereadline1(FILE *fp,int maxlength)
     /* Vrne niz, v katerega prebere vrstico iz datoteke fp. Ta niz lahko brises
     z ukazom free. Zakljucni znaki za vrstico so \n, \r in \0. Najvecje st.
     znakov, ki jih funkcija prebere, je maxlength. */
{
char *buf,*ret;
int i;
char c;
if (maxlength>0)
{
  buf=makestring(maxlength);
  i=0;
  do
  {
    c=fgetc(fp);
    if (c=='\0' || c=='\r'|| c=='n')
    {
      c='\0';
    }
    buf[i]=c;
    ++i;
  } while (c=='\0' && i<maxlength);
  buf[maxlength]='\0';
  ret=stringcopy(buf);
  free(buf);
  return ret;
} else return NULL;
}


char *readline1(int maxlength)
     /* Vrne niz, v katerega prebere vrstico iz std. inp. Ta niz lahko brises
     z ukazom free. Zakljucni znaki za vrstico so \n, \r in \0. Najvecje st.
     znakov, ki jih funkcija prebere, je maxlength. */
{
return filereadline1(stdout,maxlength);
}


size_t filewrite(void *ptr,size_t elsize,size_t n,FILE *fp,long pos)
       /* V datoteko fp zapise n*elsize bytov iz spomin. lokacije, na katero
       kaze ptr, od pozicije pos naprej. Vrne stevilo v resnici zapisanih
       bytov. Ce je pos enek 0, se pisanje zacne na koncu datoteke. */
{
size_t ret;
if (pos==0)
  pos=flength(fp)+1;
/* fflush(fp); */
fseek(fp,pos-1,SEEK_SET);
ret=fwrite(ptr,elsize,n,fp);
fflush(fp);
return ret;
}



char filereadchar(FILE *fp,long pos)
     /* Vrne znak, ki je v datoteki fp na mestu pos (Stetje od 1 naprej). */
{
char ch;
/* fflush(fp); */
fseek(fp,pos-1,SEEK_SET);
ch=getc(fp);
fflush(fp);
return (ch);
}


int filewritechar(FILE *fp,char put,long pos)
    /* Zapise znak put v datoteko fp na mesto pos. Neuspesen klic vrne EOF. */
{
int ch,ret;
ch=put;
/* fflush(fp); */
fseek(fp,pos-1,SEEK_SET);
ret=putc(ch,fp);
fflush(fp);
return ret;
}



void fcopyfilepart(FILE *fp1,long first,long last,FILE *fp2,int maxbuf)
    /* Iz datoteke fp1 skopira del od vkljucno first do vkljucno last v
    datoteko f2 pri trenutni poziciji. Pozicije se stejejo od 1 naprej. maxbuf
    je najvecja dovoljena dolzina vmesnega pomnilnika.
     POZOR!
    fp1 in fp2 ne smeta biti isti datoteki!
    $A Igor jun97 */
{
long pos,buflength,read=0,doread,wasread,length;
void *buf=NULL;
/*
if (first<=0)
  first=1;
if (last<=0 || last>flength(fp1))
  last=flength(fp1);
*/
if (fp1!=NULL && fp2!=NULL && first>=0 && last>=first)
{
  if (first==0)
    first=1;
  if (last==0)
    last=flength(fp1);
  if (last>=first)
  {
    if (maxbuf<1)
      maxbuf=100;
    length=last-first+1;
    buflength=length;
    if (buflength>maxbuf)
      buflength=maxbuf;
    buf=malloc(buflength);
    read=0;
    pos=first;
    while (read<length)
    {
      doread=length-read;
      if (doread>buflength)
        doread=buflength;
      wasread=fileread(buf,1,doread,fp1,pos);
      read+=wasread; pos+=wasread;
      fwrite(buf,1,wasread,fp2);
      if (wasread==0)
        read=length; /* Preprecimo neskoncno zanko, ce je fp1 krajsa od last */
    }
  }
}
if (buf!=NULL)
  free(buf);
}



long filecopyfilepart(FILE *fp1,long first,long last,FILE *fp2,long pos2,
                     int maxbuf)
    /* Iz datoteke fp1 skopira del od vkljucno first do vkljucno last v
    datoteko f2 pri poziciji pos2. Pozicije se stejejo od 1 naprej. maxbuf
    je najvecja dovoljena dolzina vmesnega pomnilnika. Funkcija se lahko
    uporablja tudi, ce sta sta fp1 in fp2 ista datotecna kazalca. Uporablja se
    recimo v funkcijah fi_function() in fi_update().
     Funkcija vrne eno vec kot je pozicija zadnjega zapisanega byta v fp2
    ali pos2, ce ni bilo nic zapisano.
     POZOR: Ce je pos2 0 ali vecji kot dolzina datoteke fp2, se postavi na
    dolzino datoteke +1 (torej se zacne pisati na konec datoteke) !!! Ce je
    last enak 0, se prepise datoteka fp1 od first do konca.
    $A Igor apr99; */
{
long pos,buflength,read=0,doread,wasread,length;
void *buf=NULL;
if (fp1!=NULL && fp2!=NULL)
{
  if (first==0)
    first=1;
  if (last==0)
    last=flength(fp1);
  if (pos2==0 || pos2>(pos=flength(fp2)) )
    pos2=pos+1;
  if (first>0 && last>=first && pos2>0)
  {
    if (maxbuf<1)
      maxbuf=100;
    length=last-first+1;
    buflength=length;
    if (buflength>maxbuf)
      buflength=maxbuf;
    buf=malloc(buflength);
    read=0;
    pos=first;
    while (read<length)
    {
      doread=length-read;
      if (doread>buflength)
        doread=buflength;
      wasread=fileread(buf,1,doread,fp1,pos);
      read+=wasread; pos+=wasread;
      filewrite(buf,1,wasread,fp2,pos2);
      pos2+=wasread;
      if (wasread==0)
        read=length; /* Preprecimo neskoncno zanko, ce je fp1 krajsa od last */
    }
  }
}
if (buf!=NULL)
  free(buf);
return pos2;
}



long fappend(FILE *f1,FILE *f2,int maxbuf)
    /* Na konec datoteke f1 se skopira vsebina datoteke f2. maxbuf je najvecja
    dovoljena dolzina vmesnega pomnilnika. Funkcija vrne dolzino datoteke f2,
    ce pa je kaj narobe, vrne -1. */
{
long fl,ret;
int buflength=0,transfered=0,transfered1=0;
char *buf;
if (f1==NULL || f2==NULL)
  ret=-1;
else
{
  if (maxbuf<=0)
    maxbuf=30000;
  fl=flength(f2);
  ret=fl;
  if (fl<=maxbuf)
    buflength=fl;
  else
    buflength=maxbuf;
  buf=malloc(buflength);
  /* fflush(f1); */
  fseek(f1,0,SEEK_END);
  /* fflush(f2); */
  fseek(f2,0,SEEK_SET);
  while ( (transfered=fread(buf,1,buflength,f2))>0)
  {
    transfered1=fwrite(buf,1,transfered,f1);
    if (transfered1!=transfered)
      ret=-1;
  }
  fflush(f1);
  fflush(f2);
}
return ret;
}



long fileappend(char *s1,char *s2,int maxbuf)
    /* Na konec datoteke z imenom s1 se skopira vsebina datotekez imenom s2.
    maxbuf je najvecja dovoljena dolzina vmesnega pomnilnika. Funkcija vrne
    dolzino datoteke z imenom n2, ce pa je kaj narobe, vrne -1. Funkcijo se
    lahko uporabi tudi za navadno kopiranje datotek, v tem primeru mora biti
    s1 ime datoteke, ki se ne obstaja. */
{
FILE *f1,*f2;
long ret;
f1=fopen(s1,"ab+");
f2=fopen(s2,"rb");
ret=fappend(f1,f2,maxbuf);
fclose(f1);
fclose(f2);
return ret;
}









long findfrel(FILE *fp, char *str, int length, int minbuf)
               /* Najde prvo pojavo niza *str v datoteki fp od trenutne pozicije
               naprej. Vrne stevilo bytov od trenutne pozicije do pozicije, kjer
               se iskani niz prvic pojavi. Ce niza ne najde, vrne -1. Niz lahko
               vsebuje tudi nicelne znake. length je dolzina niza, ki se isce.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               Funkcija deluje tako, da rezervira tri nize bytov v spominu eden
               za drugim. prvi ima dolzino iskanega niza, drugi poljubno dolzino
               in tretji spet dolzino iskanega niza.
               Pri iskanju se zaporedoma kopirajo deli datoteke na rezervirani
               prostor, s tem da se vsakic skopira zadnji segment na prvega in
               se preveri, ce tako nastali niz vsebuje iskanega.
               OPOMBA: Ce se iskani niz zacne ze na trenutni poziciji, funkcija
               vrne vrednost 0!*/
{
char found=0,end=0;
char *ss,*ss1,*ss2,*strpos;
long pos=0,transfered;
int endlength,midlength,buflength,wholelength;
midlength=1; /* dolzina dodatnega pomnilnika */
endlength=length-1;
if (endlength<minbuf)
  midlength=minbuf-endlength;
buflength=endlength+midlength;
wholelength=2*endlength+midlength;
ss=malloc(wholelength*sizeof(char));
ss1=ss+endlength;
ss2=ss1+midlength;
transfered=fread(ss,sizeof(char),wholelength,fp);
if (transfered<wholelength)
{
  end=1;
}
strpos=memfind(ss,transfered,str,length);
if (strpos!=NULL)
{
  end=1;
  pos+=strpos-ss;
  found=1;
}
while (!end)
{
  /* strcpy(ss,ss2); */
  memcpy(ss,ss2,endlength);
  pos+=buflength;
  transfered=fread(ss1,sizeof(char),buflength,fp);
  if (transfered<buflength)
  {
     /* ss1[transfered]='\0'; */
     end=1;
  }
  strpos=memfind(ss,endlength+transfered,str,length);
  if (strpos!=NULL)
  {
    end=1;
    pos+=strpos-ss;
    found=1;
  }
}
free(ss);
if (!found) pos=-1;
return pos;
}






long filestr(FILE *fp, char *str, int length, long from, int minbuf)
               /* Najde prvo pojavo niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo bytov do pozicije, kjer se iskani niz
               prvic pojavi. Ce niza ne najde, vrne -1. Pozicija se steje v
               bytih od 1 naprej od zacetka datoteke. length podaja dolzino
               niza, ki ga iscemo (s to funkcijo lahko iscemo tudi nize, ki
               vsebujejo znake '\0').
               */
{
long pos=0;
/* fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrel(fp,str,length,minbuf);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}





int allfilestr(FILE *fp,char *str,int length,long from,int minbuf,stack st)
    /* Poisce vse pojave niza str v datoteki fp. Pri tem uporablja za posamezna
    iskanja funkcijo filestr. Funkcija vrne stevilo najdenih pojav, v sklad st
    pa doda kazalce na mesta pojav, ki so tipa longint. */
{
int ret=0;
long sfpos,*aa;
aa=malloc(sizeof(*aa));
sfpos=from-1;
do
{
  sfpos=filestr(fp,str,length,sfpos+1,minbuf);
  if (sfpos>0)
  {
    ++ret;
    *aa=sfpos;
    pushstack(st,aa);
    aa=malloc(sizeof(*aa));
  }
} while (sfpos>0);
free(aa);
return ret;
}





long filestring(FILE *fp, char *str, long from, int minbuf)
               /* Najde prvo pojavo niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo bytov do pozicije, kjer se iskani niz
               prvic pojavi. Ce niza ne najde, vrne -1. Pozicija se steje v
               bytih od 1 naprej od zacetka datoteke.
               POZOR: S to funkcijo ne moremo iskati nizov, ki vsebujejo znak
               '\0', torej funkcija ni prevec primerne za iskanje po binarnih
               datotekah. Dolzina niza je dolocena kot pri obicajnih nizih s 1.
               pojavom znaka '\0'. */
{
return filestr(fp,str,strlen(str),from,minbuf);
}



int allfilestring(FILE *fp, char *str, long from, int minbuf,stack st)
    /* Poisce vse pojave niza str v datoteki fp. Pri tem uporablja za posamezna
    iskanja funkcijo filestring. Funkcija vrne stevilo najdenih pojav, v sklad
    st pa doda kazalce na mesta pojav, ki so tipa longint. */
{
return allfilestr(fp,str,strlen(str),from,minbuf,st);
}

















int findfrelall(FILE *fp, char *str, int length, int minbuf, stack st)
               /* Najde vse pojave niza *str v datoteki fp od trenutne pozicije
               naprej. Vrne stevilo najdenih pojav. Hkrati na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od trenutne pozicije do pozicije, kjer se iskani niz
               pojavi. Niz lahko vsebuje tudi nicelne znake. length je dolzina
               niza, ki se isce. minbuf je nanjmanjsa dolzina pomoznega spomina
               v bytih.
               Funkcija deluje podobno kot findrel.
               OPOMBA: Ce se iskani niz zacne ze na trenutni poziciji, je
               ustrezna pozicija na skladu 0!*/
{
char end=0;
char *ss,*ss1,*ss2;
long pos=0,transfered,*fpos;
int endlength,midlength,buflength,wholelength,ret=0,*mempos,memfound,i;
stack memst;
memst=newstack(5);
midlength=1; /* dolzina dodatnega pomnilnika. Zaradi naslednjega stavka mora
         biti vsaj 1. */
endlength=length-1;  /* To je pri tej funkciji zelo pomembno. Brez tega stavka
bi se kak pojav niza lahko stel dvakrat. */
if (endlength<minbuf)
  midlength=minbuf-endlength;
buflength=endlength+midlength;
wholelength=2*endlength+midlength;
ss=malloc(wholelength*sizeof(char));
ss1=ss+endlength;
ss2=ss1+midlength;
transfered=fread(ss,sizeof(char),wholelength,fp);
if (transfered<wholelength)
{
  end=1;
}
memfound=memfindall(ss,transfered,str,length,memst);
if (memfound!=0)
{
  for (i=1; i<=memfound;++i)
  {
    ++ret;
    mempos=memst->s[i];
    fpos=malloc(sizeof(*fpos));
    *fpos=pos+*mempos;
    pushstack(st,fpos);
    free(mempos);
  }
  popstackall(memst);
}
while (!end)
{
  memcpy(ss,ss2,endlength);
  pos+=buflength;
  transfered=fread(ss1,sizeof(char),buflength,fp);
  if (transfered<buflength)
  {
     end=1;
  }
  memfound=memfindall(ss,transfered+endlength,str,length,memst);
  if (memfound!=0)
  {
    for (i=1; i<=memfound;++i)
    {
      ++ret;
      mempos=memst->s[i];
      fpos=malloc(sizeof(*fpos));
      *fpos=pos+*mempos;
      pushstack(st,fpos);
      free(mempos);
    }
    popstackall(memst);
  }
}
free(ss);
free(memst);
return ret;
}




int filestrall(FILE *fp, char *str, int length, long from, int minbuf,stack st)
               /* Najde vse pojave niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo pojav, hkrati pa na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od zacetka datoteke do pozicije, kjer se iskani niz pojavi.
               Pozicija se steje v bytih od 1 naprej od zacetka datoteke. length
               podaja dolzino niza, ki ga iscemo (s to funkcijo lahko iscemo
               tudi nize, ki vsebujejo znake '\0').
               */
{
int ret=0,i;
long *pos;
/* fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  ret=findfrelall(fp,str,length,minbuf,st);
  if (ret>=0)
  for (i=1;i<=ret;++i)
  {
    pos=nstack(st,i);
    /* Pos se zaporedoma poveze z vsakim od ret zapisanih mest, na katera kaze
    ZADNJIH ret elementov sklada st. Vsakemu od teh mest se nato pristeje from:
    */
    *pos+=from;
  }
}
return ret;
}



int filestringall(FILE *fp, char *str, long from, int minbuf,stack st)
               /* Najde vse pojave niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo pojav, hkrati pa na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od zacetka datoteke do pozicije, kjer se iskani niz pojavi.
               Pozicija se steje v bytih od 1 naprej od zacetka datoteke.
               '\0', torej funkcija ni prevec primerne za iskanje po binarnih
               datotekah. Dolzina niza je dolocena kot pri obicajnih nizih s 1.
               pojavom znaka '\0'. */
{
return filestrall(fp,str,strlen(str),from,minbuf,st);
}













long nfindfrel(FILE *fp,stack strst,stack lengthst,int minbuf,int *which)
               /* Najde 1. pojav katerega od nizov na skladu strst. Kazalci na
               dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               funkcija vrne relativ. mesto najdenega niza, v *which pa zapise,
               kateri po vrsti je ta niz na skladu strst.
               OPOMBA: Ce se dani niz zacne ze na trenutni poziciji, je
               ustrezna vrnjena pozicija na skladu 0!
               Vse vrnjene pozicije se stejejo od trenutne pozicije v datoteki
               fp naprej, zacensi z 0.
               POZOR!
               Pri uporabi te funkcije je treba  paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst. */
{
char end=0;
char *ss,*ss1,*ss2,*strpos;
long pos=0,transfered,ret=-1;
int i,endlength,midlength,buflength,wholelength,length;
if (strst==NULL || lengthst==NULL)
  return ret;
else if (strst->n<1 || lengthst->n!=strst->n)
  return ret;
/* length postane dolzina najdaljsega niza: */
length=0;
if (lengthst!=NULL && lengthst->n>0)
{
  for (i=1; i<=lengthst->n; ++i)
  {
    if (lengthst->s[i]==NULL)
      return ret;
    else if (*(int *)lengthst->s[i]>length)
      length=*(int *)lengthst->s[i];
  }
}
midlength=1; /* dolzina dodatnega pomnilnika. Zaradi naslednjega stavka mora
         biti vsaj 1. */
endlength=length-1;  /* To je pri tej funkciji zelo pomembno. Brez tega stavka
bi se kak pojav niza lahko stel dvakrat. */
if (endlength<minbuf)
  midlength=minbuf-endlength;
buflength=endlength+midlength;
wholelength=2*endlength+midlength;
ss=malloc(wholelength*sizeof(char));
ss1=ss+endlength;
ss2=ss1+midlength;
transfered=fread(ss,sizeof(char),wholelength,fp);
if (transfered<wholelength)
  end=1;
/* Isce se po vseh nizih, ce niz ss vsebuje katerega od iskanih nizov */
strpos=nmemfind(ss,transfered,strst,lengthst,which);
if (*which >0)
{
  end=1;
  ret=pos+(strpos-ss);
}
while (!end)
{
  memcpy(ss,ss2,endlength);
  pos+=buflength;
  transfered=fread(ss1,sizeof(char),buflength,fp);
  if (transfered<buflength)
     end=1;
  /* Isce se po vseh nizih, ce miz mm vsebuje katerega od iskanih nizov */
  strpos=nmemfind(ss,endlength+transfered,strst,lengthst,which);
  if (*which >0)
  {
    end=1;
    ret=pos+(strpos-ss);
  }
}
free(ss);
return ret;
}




long nfilestr(FILE *fp,stack strst,stack lengthst,long from,int minbuf,
     int *which)
               /* Najde 1. pojav katerega od nizov na skladu strst. Kazalci na
               dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               Funkcija vrne mesto v datoteki (od zacetka datoteke naprej, steti
               se zacne z 1), na katerem je najdeni niz, v *which pa se zapise
               zaporedna stevilka tega mesta v skladu strst.
               POZOR!
               Pri uporabi te funkcije je treba paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst.
               */
{
long pos=-1;
*which=0;
/* fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=nfindfrel(fp,strst,lengthst,minbuf,which);
  if (pos>=0 && *which >0)
    pos+=from;
}
return pos;
}






long nfilestring(FILE *fp,stack strst, long from, int minbuf,int *which)
               /* Najde 1. pojav katerega od nizov na skladu strst. Nizi
               morajo biti zakljuceni z znakom '\0', funkcija torej ni preimerna
               za iskanje nizov, ki vsebujejo ta znak. minbuf je nanjmanjsa
               dolzina pomoznega spomina v bytih.
               Na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               */
{
stack lengthst;
long ret;
int i,num,*length;
num=strst->n;
lengthst=newstack(5);
/* Na sklad lengthst se nalozijo dolzine nizov iz sklada strst: */
for (i=1; i<=num; ++i)
{
  length=malloc(sizeof(*length));
  *length=strlen((char *)strst->s[i]);
  pushstack(lengthst,length);
}
ret=nfilestr(fp,strst,lengthst,from,minbuf,which);
dispstackval(lengthst);
dispstack(&lengthst);
return ret;
}







int nfindfrelall(FILE *fp,stack strst,stack lengthst,int minbuf,stack retst)
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Kazalci na
               Dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki.
               OPOMBA: Ce se dani niz zacne ze na trenutni poziciji, je
               ustrezna vrnjena pozicija na skladu 0!
               Vse vrnjene pozicije se stejejo od trenutne pozicije v datoteki
               fp naprej, zacensi z 0.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst. Se bolj je treba paziti, da ima sklad retstr eneko st.
               elementov kot strst ter da vsi kazejo na ze alociran spomin
               tipa _stack.
               $A Igor <== feb97 */
{
char end=0,oldfound=0;
char *ss,*ss1,*ss2,*jstr;
long pos=0,transfered,*fpos;
int endlength,midlength,buflength,wholelength,ret=0,*mempos,memfound,i,j,k;
int length,numstr,jlength;
stack memst,jst,ctrlst=NULL,jctrlst;
if (strst==NULL || lengthst==NULL)
  return ret;
else if (strst->n<1 || lengthst->n!=strst->n)
  return ret;
memst=newstack(5);
/* Stevilo nizov, ki se iscejo: */
numstr=lengthst->n;
/* Kondrolni sklad za preverjanje, da nismo kake pozicije steli dvakrat: */
ctrlst=newstack(numstr);
for (i=1;i<=numstr;++i)
  pushstack(ctrlst,newstack(10));
/* length postane dolzina najdaljsega niza: */
length=0;
for (i=1; i<=lengthst->n; ++i)
{
    if (lengthst->s[i]==NULL)
      return ret;
    else if (*(int *)lengthst->s[i]>length)
    length=*(int *)lengthst->s[i];
}
midlength=1; /* dolzina dodatnega pomnilnika. Zaradi naslednjega stavka mora
         biti vsaj 1. */
endlength=length-1;  /* To je pri tej funkciji zelo pomembno. Brez tega stavka
bi se kak pojav niza lahko stel dvakrat. */
if (endlength<minbuf)
  midlength=minbuf-endlength;
buflength=endlength+midlength;
wholelength=2*endlength+midlength;
ss=malloc(wholelength*sizeof(char));
ss1=ss+endlength;
ss2=ss1+midlength;
transfered=fread(ss,sizeof(char),wholelength,fp);
if (transfered<wholelength)
{
  /* ss[transfered]='\0'; */
  end=1;
}
/* Isce se po vseh nizih, ce miz mm vsebuje katerega od iskanih nizov */
for (j=1; j<=numstr; ++j)
{
  /* Lokalne spremenljivke se povezejo z ustreznimi elementi skladov, ki
  ustrezajo argumentom funkcije: */
  jstr=(char *)strst->s[j];        /* j-ti niz */
  jlength=*(int *)lengthst->s[j];  /* dolzina j-tega niza */
  jst=(stack)retst->s[j];          /* j-ti sklad, v katerega se bodo nalozile
  najdene pozicije */
  /* V memst se spravijo mesta vseh pojav j. niza */
  memfound=memfindall(ss,transfered,jstr,jlength,memst);
  jctrlst=ctrlst->s[j]; /* Sklad na kontrolnem sklatu, kamor se bodo tudi */
  if (memfound!=0)
  {
    for (i=1; i<=memfound;++i)
    {
      /* ++ret; */
      mempos=memst->s[i];
      fpos=malloc(sizeof(*fpos));
      *fpos=pos+*mempos;
      pushstack(jst,fpos);
      pushstack(jctrlst,fpos); /* Pozicijo damo tudi na kontrolni niz. */
      free(mempos);
    }
    popstackall(memst);
  }
}
while (!end)
{
  memcpy(ss,ss2,endlength);
  pos+=buflength;
  transfered=fread(ss1,sizeof(char),buflength,fp);
  if (transfered<buflength)
  {
     end=1;
  }
  /* Isce se po vseh nizih, ce miz mm vsebuje katerega od iskanih nizov */
  for (j=1; j<=numstr; ++j)
  {
    /* Lokalne spremenljivke se povezejo z ustreznimi elementi skladov, ki
    ustrezajo argumentom funkcije: */
    jstr=(char *)strst->s[j];        /* j-ti niz */
    jlength=*(int *)lengthst->s[j];  /* dolzina j-tega niza */
    jst=(stack)retst->s[j];          /* j-ti sklad, v katerega se bodo nalozile
    najdene pozicije */
    /* V memst se spravijo mesta vseh pojav j. niza */
    memfound=memfindall(ss,transfered+endlength,jstr,jlength,memst);
    jctrlst=ctrlst->s[j]; /* Kontrolni sklad */
    oldfound=1; /* To postavimo na 0 takoj, ko pojav niza najdemo na novo
                    (torej ce ga ni na jctrlst). */
    if (memfound!=0)
    {
      for (i=1; i<=memfound;++i)
      {
        /* ++ret; */
        mempos=memst->s[i];
        fpos=malloc(sizeof(*fpos));
        *fpos=pos+*mempos;
        
        
        if (oldfound)
        {
          if (jctrlst->n==0)
            oldfound=0;
          else
          {
            oldfound=0;
            for (k=1;k<=jctrlst->n;++k)
              if (*fpos==*(long *)jctrlst->s[k])
                oldfound=1;
            if (!oldfound) /* 1. niz jstr, ki smo ga nasli na novo v tej
                  iteraciji, zato ne rabimo vec pozicij na kontrol. skladu. */
              popstackall(jctrlst);
          }
        }
        if (oldfound)
          free(fpos);
        else
        {
          pushstack(jst,fpos);
          pushstack(jctrlst,fpos); /* Pozicija gre tudi na kontrolni sklad. */
        }
        
        /*
        pushstack(jst,fpos);
        */
        free(mempos);
      }
      popstackall(memst);
    }
  }
}
free(ss);
free(memst);
return ret;
}










int nfilestrall(FILE *fp,stack strst,stack lengthst,long from,int minbuf,
    stack retst)
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Kazalci na
               Dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst. Se bolj je treba paziti, da ima sklad retstr eneko st.
               elementov kot strst ter da vsi kazejo na ze alociran spomin
               tipa _stack.
               */
{
int ret=0,i,j,new,numstr,*number;
stack jst,numret;
long *pos;
numret=newstack(5);
numstr=strst->n;
/* Na stack numret se nalozijo stevila elementov, ki jih ze vsebujejo elementi
sklada retst (ki so tudi sami skladi): */
for (i=1; i<=numstr;++i)
{
  number=malloc(sizeof(*number));
  *number=((stack) retst->s[i])->n;
  pushstack(numret,number);
}
/* fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  ret=nfindfrelall(fp,strst,lengthst,minbuf,retst);
  for (j=1; j<=numstr; ++j)
  {
    /* Sklad, ki pripada j-temu nizu: */
    jst=(stack)retst->s[j];
    /* Izracuna se, koliko novih elementov je pridobil ta sklad: */
    new=jst->n-*(int*)numret->s[j];
    if (new>0)
    {
      /* Vsem vrednostim, na katere kazejo na novo pridobljeni elementi, se doda
      vrednost from: */
      for (i=1;i<=new;++i)
      {
        pos=nstack(jst,i);
        /* Pos se zaporedoma poveze z vsakim od ret zapisanih mest, na katera kaze
        ZADNJIH new elementov sklada st. Vsakemu od teh mest se nato pristeje from:*/
        *pos+=from;
      }
    }
  }
}
dispstackval(numret);
dispstack(&numret);
return ret;
}







int nfilestringall(FILE *fp,stack strst, long from, int minbuf,stack retst)
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Nizi
               morajo biti zakljuceni z znakom '\0', funkcija torej ni preimerna
               za iskanje nizov, ki vsebujejo ta znak. minbuf je nanjmanjsa
               dolzina pomoznega spomina v bytih.
               Na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da ima sklad retstr
               eneko st. elementov kot strst ter da vsi kazejo na ze alociran
               spomin tipa _stack.
               */
{
stack lengthst;
int *length,ret;
int i,num;
num=strst->n;
lengthst=newstack(5);
/* Na sklad lengthst se nalozijo dolzine nizov iz sklada strst: */
for (i=1; i<=num; ++i)
{
  length=malloc(sizeof(*length));
  *length=strlen((char *)strst->s[i]);
  pushstack(lengthst,length);
}
ret=nfilestrall(fp,strst,lengthst,from,minbuf,retst);
dispstackval(lengthst);
dispstack(&lengthst);
return ret;
}




















long findfrelto(FILE *fp,char *str,int length,long to,int minbuf)
               /* Najde prvo pojavo niza *str v datoteki fp od trenutne pozicije
               naprej, najvec do pozicije to. Vrne stevilo bytov od trenutne
               pozicije do pozicije, kjer se iskani niz prvic pojavi. Ce niza ne
               najde, vrne -1. Niz lahko vsebuje tudi nicelne znake. length je
               dolzina niza, ki se isce. minbuf je nanjmanjsa dolzina pomoznega
               spomina v bytih. Funkcija isce tako, da ce se iskani niz zacne s
               to-tim znakom, ga se vedno uposteva.
               Funkcija deluje tako, da rezervira tri nize bytov v spominu eden
               za drugim. prvi ima dolzino iskanega niza, drugi poljubno dolzino
               in tretji spet dolzino iskanega niza.
               Pri iskanju se zaporedoma kopirajo deli datoteke na rezervirani
               prostor, s tem da se vsakic skopira zadnji segment na prvega in
               se preveri, ce tako nastali niz vsebuje iskanega.
               OPOMBA: Ce se iskani niz zacne ze na trenutni poziciji, funkcija
               vrne vrednost 0!*/
{
char found=0,end=0;
char *ss,*ss1,*ss2,*strpos;
long pos=0,transfered,dotransf;
int endlength,midlength,buflength,wholelength;
midlength=1; /* dolzina dodatnega pomnilnika */
endlength=length-1;
if (endlength<minbuf)
  midlength=minbuf-endlength;
buflength=endlength+midlength;
wholelength=2*endlength+midlength;
ss=malloc(wholelength*sizeof(char));
ss1=ss+endlength;
ss2=ss1+midlength;
/* Maksimalno stevilo prebranih bytov je to+length: */
if (wholelength<=to+length)
  dotransf=wholelength;
else
  dotransf=to+length;
transfered=fread(ss,sizeof(char),dotransf,fp);
/*
transfered=fread(ss,sizeof(char),wholelength,fp);
*/
if (transfered<wholelength)
{
  /* ss[transfered]='\0'; */
  end=1;
}
strpos=memfind(ss,transfered,str,length);
if (strpos!=NULL)
{
  end=1;
  pos+=strpos-ss;
  found=1;
}
while (!end)
{
  /* strcpy(ss,ss2); */
  memcpy(ss,ss2,endlength);
  pos+=buflength;
  if ((pos+endlength)+buflength<=to+length)
    dotransf=buflength;
  else
    dotransf=to+length-(pos+endlength);
  /* to+length je najvecje dovoljeno stevilo prebranih bytov. pos+endlength je
  stevilo do tega trenutka ze prebranih bytov, buflength pa je stevilo bytov, ki
  bi se po pravem moralo prebrati v tem trenutku.
  */
  transfered=fread(ss1,sizeof(char),dotransf,fp);
  if (transfered<buflength)
  {
     /* ss1[transfered]='\0'; */
     end=1;
  }
  strpos=memfind(ss,endlength+transfered,str,length);
  if (strpos!=NULL)
  {
    end=1;
    pos+=strpos-ss;
    found=1;
  }
}
free(ss);
if (!found) pos=-1;
return pos;
}






long filestrto(FILE *fp,char *str,int length,long from,long to,int minbuf)
               /* Najde prvo pojavo niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo bytov do pozicije, kjer se iskani niz
               prvic pojavi. Ce niza ne najde, vrne -1. Pozicija se steje v
               bytih od 1 naprej od zacetka datoteke. length podaja dolzino
               niza, ki ga iscemo (s to funkcijo lahko iscemo tudi nize, ki
               vsebujejo znake '\0').
               */
{
long pos=0;
if (to<=0)
  to=flength(fp);
/* fflush(fp); */
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelto(fp,str,length,to-from,minbuf);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}





int allfilestrto(FILE *fp,char *str,int length,long from,long to,
    int minbuf,stack st)
    /* Poisce vse pojave niza str v datoteki fp. Pri tem uporablja za posamezna
    iskanja funkcijo filestr. Funkcija vrne stevilo najdenih pojav, v sklad st
    pa doda kazalce na mesta pojav, ki so tipa longint. */
{
int ret=0;
long sfpos,*aa;
if (to<=0)
  to=flength(fp);
aa=malloc(sizeof(*aa));
sfpos=from-1;
do
{
  sfpos=filestrto(fp,str,length,sfpos+1,to,minbuf);
  if (sfpos>0)
  {
    ++ret;
    *aa=sfpos;
    pushstack(st,aa);
    aa=malloc(sizeof(*aa));
  }
} while (sfpos>0);
free(aa);
return ret;
}





long filestringto(FILE *fp,char *str,long from,long to,int minbuf)
               /* Najde prvo pojavo niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo bytov do pozicije, kjer se iskani niz
               prvic pojavi. Ce niza ne najde, vrne -1. Pozicija se steje v
               bytih od 1 naprej od zacetka datoteke.
               POZOR: S to funkcijo ne moremo iskati nizov, ki vsebujejo znak
               '\0', torej funkcija ni prevec primerne za iskanje po binarnih
               datotekah. Dolzina niza je dolocena kot pri obicajnih nizih s 1.
               pojavom znaka '\0'. */
{
return filestrto(fp,str,strlen(str),from,to,minbuf);
}



int allfilestringto(FILE *fp,char *str,long from,long to,int minbuf,stack st)
    /* Poisce vse pojave niza str v datoteki fp. Pri tem uporablja za posamezna
    iskanja funkcijo filestring. Funkcija vrne stevilo najdenih pojav, v sklad
    st pa doda kazalce na mesta pojav, ki so tipa longint. */
{
return allfilestrto(fp,str,strlen(str),from,to,minbuf,st);
}
















int findfrelallto(FILE *fp,char *str,int length,long to,int minbuf,stack st)
               /* Najde vse pojave niza *str v datoteki fp od trenutne pozicije
               naprej. Vrne stevilo najdenih pojav. Hkrati na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od trenutne pozicije do pozicije, kjer se iskani niz
               pojavi. Niz lahko vsebuje tudi nicelne znake. length je dolzina
               niza, ki se isce. minbuf je nanjmanjsa dolzina pomoznega spomina
               v bytih.
               Funkcija deluje podobno kot findrel.
               OPOMBA: Ce se iskani niz zacne ze na trenutni poziciji, je
               ustrezna pozicija na skladu 0!*/
{
char end=0;
char *ss,*ss1,*ss2;
long pos=0,transfered,*fpos,dotransf;
int endlength,midlength,buflength,wholelength,ret=0,*mempos,memfound,i;
stack memst;
memst=newstack(5);
midlength=1; /* dolzina dodatnega pomnilnika. Zaradi naslednjega stavka mora
         biti vsaj 1. */
endlength=length-1;  /* To je pri tej funkciji zelo pomembno. Brez tega stavka
bi se kak pojav niza lahko stel dvakrat. */
if (endlength<minbuf)
  midlength=minbuf-endlength;
buflength=endlength+midlength;
wholelength=2*endlength+midlength;
ss=malloc(wholelength*sizeof(char));
ss1=ss+endlength;
ss2=ss1+midlength;
/* Maksimalno stevilo prebranih bytov je to+length: */
if (wholelength<=to+length)
  dotransf=wholelength;
else
  dotransf=to+length;
transfered=fread(ss,sizeof(char),dotransf,fp);
if (transfered<wholelength)
{
  end=1;
}
memfound=memfindall(ss,transfered,str,length,memst);
if (memfound!=0)
{
  for (i=1; i<=memfound;++i)
  {
    ++ret;
    mempos=memst->s[i];
    fpos=malloc(sizeof(*fpos));
    *fpos=pos+*mempos;
    pushstack(st,fpos);
    free(mempos);
  }
  popstackall(memst);
}
while (!end)
{
  memcpy(ss,ss2,endlength);
  pos+=buflength;
  if ((pos+endlength)+buflength<=to+length)
    dotransf=buflength;
  else
    dotransf=to+length-(pos+endlength);
  /* to+length je najvecje dovoljeno stevilo prebranih bytov. pos+endlength je
  stevilo do tega trenutka ze prebranih bytov, buflength pa je stevilo bytov, ki
  bi se po pravem moralo prebrati v tem trenutku.
  */
  transfered=fread(ss1,sizeof(char),dotransf,fp);
  if (transfered<buflength)
  {
     end=1;
  }
  memfound=memfindall(ss,transfered+endlength,str,length,memst);
  if (memfound!=0)
  {
    for (i=1; i<=memfound;++i)
    {
      ++ret;
      mempos=memst->s[i];
      fpos=malloc(sizeof(*fpos));
      *fpos=pos+*mempos;
      pushstack(st,fpos);
      free(mempos);
    }
    popstackall(memst);
  }
}
free(ss);
free(memst);
return ret;
}












int filestrallto(FILE *fp,char *str,int length,long from,long to,
    int minbuf,stack st)
               /* Najde vse pojave niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo pojav, hkrati pa na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od zacetka datoteke do pozicije, kjer se iskani niz pojavi.
               Pozicija se steje v bytih od 1 naprej od zacetka datoteke. length
               podaja dolzino niza, ki ga iscemo (s to funkcijo lahko iscemo
               tudi nize, ki vsebujejo znake '\0').
               */
{
int ret=0,i;
long *pos;
if (to<=0)
  to=flength(fp);
/* fflush(fp); */
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  ret=findfrelallto(fp,str,length,to-from,minbuf,st);
  if (ret>=0)
  for (i=1;i<=ret;++i)
  {
    pos=nstack(st,i);
    /* Pos se zaporedoma poveze z vsakim od ret zapisanih mest, na katera kaze
    ZADNJIH ret elementov sklada st. Vsakemu od teh mest se nato pristeje from:
    */
    *pos+=from;
  }
} else
  ret=-1;
return ret;
}



int filestringallto(FILE *fp,char *str,long from,long to,int minbuf,stack st)
               /* Najde vse pojave niza *str v datoteki fp od pozicije from
               naprej. Vrne stevilo pojav, hkrati pa na sklad st potisne
               kazalce na vse najdene pozicije, ki so tipa long in pomenijo st.
               bytov od zacetka datoteke do pozicije, kjer se iskani niz pojavi.
               Pozicija se steje v bytih od 1 naprej od zacetka datoteke.               POZOR: S to funkcijo ne moremo iskati nizov, ki vsebujejo znak
               POZOR: S to funkcijo ne moremo iskati nizov, ki vsebujejo znak
               '\0', torej funkcija ni prevec primerne za iskanje po binarnih
               datotekah. Dolzina niza je dolocena kot pri obicajnih nizih s 1.
               pojavom znaka '\0'. */
{
return filestrallto(fp,str,strlen(str),from,to,minbuf,st);
}






long nfindfrelto(FILE *fp,stack strst,stack lengthst,long to,int minbuf,
     int *which)
    /* Najde 1. pojav katerega od nizov na skladu strst. Kazalci na
    dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
    mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
    minbuf je nanjmanjsa dolzina pomoznega spomina v bytih. Preisce
    se najvec to bytov v datoteki.
    funkcija vrne relativ. mesto najdenega niza, v *which pa zapise,
    kateri po vrsti je ta niz na skladu strst.
    OPOMBA: Ce se dani niz zacne ze na trenutni poziciji, je
    ustrezna vrnjena pozicija na skladu 0!
    Vse vrnjene pozicije se stejejo od trenutne pozicije v datoteki
    fp naprej, zacensi z 0.
    POZOR!
     Pri uporabi te funkcije je treba  paziti, da imata slada
    strst in lengthst enako stevilo elementov ter da so elementi
    sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
    strst.
    $A Igor <== dec97; */
{
char end=0;
char *ss,*ss1,*ss2,*strpos;
long pos=0,dotransf,transfered,ret=-1;
int i,endlength,midlength,buflength,wholelength,length;
if (strst==NULL || lengthst==NULL)
  return ret;
else if (strst->n<1 || lengthst->n!=strst->n)
  return ret;
/* length postane dolzina najdaljsega niza: */
length=0;
if (lengthst!=NULL && lengthst->n>0)
{
  for (i=1; i<=lengthst->n; ++i)
  {
    if (lengthst->s[i]==NULL)
      return ret;
    else if (*(int *)lengthst->s[i]>length)
      length=*(int *)lengthst->s[i];
  }
}
if (length==0)
  return ret;
midlength=1; /* dolzina dodatnega pomnilnika. Zaradi naslednjega stavka mora
         biti vsaj 1. */
endlength=length-1;  /* To je pri tej funkciji zelo pomembno. Brez tega stavka
bi se kak pojav niza lahko stel dvakrat. */
if (endlength<minbuf)
  midlength=minbuf-endlength;
/* midlength+=(endlength+10); */ /* Dodatna rezerva, da ne bi bilo kaj narobe. Kaze
                             namrec, da v tej funkciji ni vse v redu, ce je
                             minbuf manj od najdaljse dolzine katerega koli
                             iskanega niza. */
buflength=endlength+midlength;
wholelength=2*endlength+midlength;
ss=malloc(wholelength*sizeof(char));
ss1=ss+endlength;
ss2=ss1+midlength;
if (wholelength<=to)
  dotransf=wholelength;
else
  dotransf=to;
transfered=fread(ss,sizeof(char),dotransf,fp);
if (transfered<wholelength)
  end=1;
/* Isce se po vseh nizih, ce niz ss vsebuje katerega od iskanih nizov */
strpos=nmemfind(ss,transfered,strst,lengthst,which);
if (*which >0)
{
  end=1;
  ret=pos+(strpos-ss);
}
while (!end)
{
  memcpy(ss,ss2,endlength);
  pos+=buflength;
  if (buflength<=to-pos)
    dotransf=buflength;
  else
    dotransf=to-pos;
  transfered=fread(ss1,sizeof(char),dotransf,fp);
  if (transfered<buflength)
     end=1;
  /* Isce se po vseh nizih, ce miz mm vsebuje katerega od iskanih nizov */
  strpos=nmemfind(ss,endlength+transfered,strst,lengthst,which);
  if (*which >0)
  {
    end=1;
    ret=pos+(strpos-ss);
  }
}
free(ss);
return ret;
}





long nfilestrto(FILE *fp,stack strst,stack lengthst,long from,long to,
     int minbuf,int *which)
               /* Najde 1. pojav katerega od nizov na skladu strst. Kazalci na
               dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               Funkcija vrne mesto v datoteki (od zacetka datoteke naprej, steti
               se zacne z 1), na katerem je najdeni niz, v *which pa se zapise
               zaporedna stevilka tega mesta v skladu strst. Isce se najvec do
               mesta to v datoteki.
               POZOR!
               Pri uporabi te funkcije je treba paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst.
               */
{
long pos=-1;
*which=0;
/* fflush(fp); */
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=nfindfrelto(fp,strst,lengthst,to-from+1,minbuf,which);
  if (pos>=0 && *which >0)
    pos+=from;
} else
  pos=-1;
return pos;
}






long nfilestringto(FILE *fp,stack strst,long from,long to,int minbuf,int *which)
               /* Najde 1. pojav katerega od nizov na skladu strst. Nizi
               morajo biti zakljuceni z znakom '\0', funkcija torej ni preimerna
               za iskanje nizov, ki vsebujejo ta znak. minbuf je nanjmanjsa
               dolzina pomoznega spomina v bytih. Isce se najvec do mesta to v
               datoteki.
               Na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               */
{
stack lengthst=NULL;
long ret;
int i,num,*length;
if (strst!=NULL)
  if (strst->n>0)
  {
    num=strst->n;
    lengthst=newstack(5);
    /* Na sklad lengthst se nalozijo dolzine nizov iz sklada strst: */
    for (i=1; i<=num; ++i)
    {
      length=malloc(sizeof(*length));
      *length=strlen((char *)strst->s[i]);
      pushstack(lengthst,length);
    }
}
ret=nfilestrto(fp,strst,lengthst,from,to,minbuf,which);
dispstackval(lengthst);
dispstack(&lengthst);
return ret;
}















int nfindfrelallto(FILE *fp,stack strst,stack lengthst,long to,
    int minbuf,stack retst)
    /* Najde vse pojave vseh nizov, ki so v skladu strst. Kazalci na
    Dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
    mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
    minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
    na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
    nalozijo pozicije posameznih nizov v datoteki.
    OPOMBA: Ce se dani niz zacne ze na trenutni poziciji, je
    ustrezna vrnjena pozicija na skladu 0!
    Vse vrnjene pozicije se stejejo od trenutne pozicije v datoteki
    fp naprej, zacensi z 0.
    POZOR!
     Pri uporabi te funkcije je treba zelo paziti, da imata slada
    strst in lengthst enako stevilo elementov ter da so elementi
    sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
    strst. Se bolj je treba paziti, da ima sklad retstr eneko st.
    elementov kot strst ter da vsi kazejo na ze alociran spomin
    tipa _stack.
    $A Igor <== feb97 dec97; */
{
char end=0,oldfound=0;
char *ss,*ss1,*ss2,*jstr;
long pos=0,transfered,*fpos,dotransf;
int endlength,midlength,buflength,wholelength,ret=0,*mempos,memfound,i,j,k;
int length,numstr,jlength;
stack memst,jst,ctrlst=NULL,jctrlst;
if (strst==NULL || lengthst==NULL)
  return ret;
else if (strst->n<1 || lengthst->n!=strst->n)
  return ret;
memst=newstack(5);
/* Stevilo nizov, ki se iscejo: */
numstr=lengthst->n;
/* Kondrolni sklad za preverjanje, da nismo kake pozicije steli dvakrat: */
ctrlst=newstack(numstr);
for (i=1;i<=numstr;++i)
  pushstack(ctrlst,newstack(10));
/* length postane dolzina najdaljsega niza: */
length=0;
for (i=1; i<=lengthst->n; ++i)
{
    if (lengthst->s[i]==NULL)
      return ret;
    else if (*(int *)lengthst->s[i]>length)
    length=*(int *)lengthst->s[i];
}
midlength=1; /* dolzina dodatnega pomnilnika. Zaradi naslednjega stavka mora
         biti vsaj 1. */
endlength=length-1;  /* To je pri tej funkciji zelo pomembno. Brez tega stavka
bi se kak pojav niza lahko stel dvakrat. */
if (endlength<minbuf)
  midlength=minbuf-endlength;
buflength=endlength+midlength;
wholelength=2*endlength+midlength;
ss=malloc(wholelength*sizeof(char));
ss1=ss+endlength;
ss2=ss1+midlength;
/* Maksimalno stevilo prebranih bytov je to+length: */
if (wholelength<=to+length)
  dotransf=wholelength;
else
  dotransf=to+length;
transfered=fread(ss,sizeof(char),dotransf,fp);
if (transfered<wholelength)
{
  end=1;
}
/* Isce se po vseh nizih, ce niz mm vsebuje katerega od iskanih nizov */
for (j=1; j<=numstr; ++j)
{
  /* Lokalne spremenljivke se povezejo z ustreznimi elementi skladov, ki
  ustrezajo argumentom funkcije: */
  jstr=(char *)strst->s[j];        /* j-ti niz */
  jlength=*(int *)lengthst->s[j];  /* dolzina j-tega niza */
  jst=(stack)retst->s[j];          /* j-ti sklad, v katerega se bodo nalozile
  najdene pozicije */
  /* V memst se spravijo mesta vseh pojav j. niza */
  memfound=memfindall(ss,transfered,jstr,jlength,memst);
  jctrlst=ctrlst->s[j]; /* Sklad na kontrolnem sklatu, kamor se bodo tudi */
  if (memfound!=0)
  {
    for (i=1; i<=memfound;++i)
    {
      /* ++ret; */
      mempos=memst->s[i];
      fpos=malloc(sizeof(*fpos));
      *fpos=pos+*mempos;
      if (*fpos<=to)
      /* Lahko se zgodi nasprotno, ce iscemo nize razlic. dolzin */
      {
        pushstack(jst,fpos);
        pushstack(jctrlst,fpos); /* Pozicijo damo tudi na kontrolni niz. */
      }
      else
        free(fpos);
      free(mempos);
    }
    popstackall(memst);
  }
}
while (!end)
{
  memcpy(ss,ss2,endlength);
  pos+=buflength;
  if ((pos+endlength)+buflength<=to+length)
    dotransf=buflength;
  else
    dotransf=to+length-(pos+endlength);
  /* to+length je najvecje dovoljeno stevilo prebranih bytov. pos+endlength je
  stevilo do tega trenutka ze prebranih bytov, buflength pa je stevilo bytov, ki
  bi se po pravem moralo prebrati v tem trenutku.
  */
  transfered=fread(ss1,sizeof(char),dotransf,fp);
  if (transfered<buflength)
  {
     end=1;
  }
  /* Isce se po vseh nizih, ce miz mm vsebuje katerega od iskanih nizov */
  for (j=1; j<=numstr; ++j)
  {
    /* Lokalne spremenljivke se povezejo z ustreznimi elementi skladov, ki
    ustrezajo argumentom funkcije: */
    jstr=(char *)strst->s[j];        /* j-ti niz */
    jlength=*(int *)lengthst->s[j];  /* dolzina j-tega niza */
    jst=(stack)retst->s[j];          /* j-ti sklad, v katerega se bodo nalozile
    najdene pozicije */
    /* V memst se spravijo mesta vseh pojav j. niza */
    memfound=memfindall(ss,transfered+endlength,jstr,jlength,memst);
    jctrlst=ctrlst->s[j]; /* Kontrolni sklad */
    oldfound=1; /* To postavimo na 0 takoj, ko pojav niza najdemo na novo
                    (torej ce ga ni na jctrlst). */
    if (memfound!=0)
    {
      for (i=1; i<=memfound;++i)
      {
        /* ++ret; */
        mempos=memst->s[i];
        fpos=malloc(sizeof(*fpos));
        *fpos=pos+*mempos;
        if (*fpos<=to)
        /* Lahko se zgodi nasprotno, ce iscemo nize razlic. dolzin */
        {
          if (oldfound)
          {
            if (jctrlst->n==0)
              oldfound=0;
            else
            {
              oldfound=0;
              for (k=1;k<=jctrlst->n;++k)
                if (*fpos==*(long *)jctrlst->s[k])
                  oldfound=1;
              if (!oldfound) /* 1. niz jstr, ki smo ga nasli na novo v tej
                                iteraciji */
                popstackall(jctrlst);
            }
          }
          if (oldfound)
            free(fpos);
          else
          {
            pushstack(jst,fpos);
            pushstack(jctrlst,fpos); /* Pozicija gre tudi na kontrolni sklad. */
          }
        } else
          free(fpos);
        free(mempos);
      }
      popstackall(memst);
    } else
      popstackall(jctrlst); /* Brisanje pozicij na jctrlst iz prejsnje
                           iteracije zanke while */
  }
}
free(ss);
free(memst);
if (ctrlst!=NULL)
{
  if (ctrlst->n>0)
    for (i=1;i<=ctrlst->n;++i)
      if(ctrlst->s[i]!=NULL)
        dispstack((stack *) &(ctrlst->s[i]));
  dispstack(&ctrlst);
}
return ret;
}










int nfilestrallto(FILE *fp,stack strst,stack lengthst,long from,long to,
    int minbuf,stack retst)
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Kazalci na
               Dolzine teh nizov (tipa int) morajo biti nalozeni na ustreznih
               mestih sklada lengthst. Nizi lahko vsebujejo tudi nicelne znake.
               minbuf je nanjmanjsa dolzina pomoznega spomina v bytih.
               na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da imata slada
               strst in lengthst enako stevilo elementov ter da so elementi
               sklada lengthst zares dolzine ustreznih nizov, ki so v skladu
               strst. Se bolj je treba paziti, da ima sklad retstr eneko st.
               elementov kot strst ter da vsi kazejo na ze alociran spomin
               tipa _stack.
               */
{
int ret=0,i,j,new,numstr,*number;
stack jst,numret;
long *pos;
if (to<=0)
  to=flength(fp);
numret=newstack(5);
numstr=strst->n;
/* Na stack numret se nalozijo stevila elementov, ki jih ze vsebujejo elementi
sklada retst (ki so tudi sami skladi): */
for (i=1; i<=numstr;++i)
{
  number=malloc(sizeof(*number));
  *number=((stack) retst->s[i])->n;
  pushstack(numret,number);
}
/* fflush(fp); */
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  ret=nfindfrelallto(fp,strst,lengthst,to-from,minbuf,retst);
  for (j=1; j<=numstr; ++j)
  {
    /* Sklad, ki pripada j-temu nizu: */
    jst=(stack)retst->s[j];
    /* Izracuna se, koliko novih elementov je pridobil ta sklad: */
    new=jst->n-*(int*)numret->s[j];
    if (new>0)
    {
      /* Vsem vrednostim, na katere kazejo na novo pridobljeni elementi, se doda
      vrednost from: */
      for (i=1;i<=new;++i)
      {
        pos=nstack(jst,i);
        /* Pos se zaporedoma poveze z vsakim od ret zapisanih mest, na katera kaze
        ZADNJIH new elementov sklada st. Vsakemu od teh mest se nato pristeje from:*/
        *pos+=from;
      }
    }
  }
}  else
  ret=-1;
dispstackval(numret);
dispstack(&numret);
return ret;
}







int nfilestringallto(FILE *fp,stack strst,long from,long to,
    int minbuf,stack retst)
               /* Najde vse pojave vseh nizov, ki so v skladu strst. Nizi
               morajo biti zakljuceni z znakom '\0', funkcija torej ni preimerna
               za iskanje nizov, ki vsebujejo ta znak. minbuf je nanjmanjsa
               dolzina pomoznega spomina v bytih.
               Na ustrezne elemente sklada retst, ki morajo tudi biti skladi, se
               nalozijo pozicije posameznih nizov v datoteki. Te se stejejo od
               zacetka datoteke fp od 1 naprej.
               POZOR!
               Pri uporabi te funkcije je treba zelo paziti, da ima sklad retstr
               eneko st. elementov kot strst ter da vsi kazejo na ze alociran
               spomin tipa _stack.
               */
{
stack lengthst;
int *length,ret;
int i,num;
num=strst->n;
lengthst=newstack(5);
/* Na sklad lengthst se nalozijo dolzine nizov iz sklada strst: */
for (i=1; i<=num; ++i)
{
  length=malloc(sizeof(*length));
  *length=strlen((char *)strst->s[i]);
  pushstack(lengthst,length);
}
ret=nfilestrallto(fp,strst,lengthst,from,to,minbuf,retst);
dispstackval(lengthst);
dispstack(&lengthst);
return ret;
}





    /* FUNKCIJE ZA ISKANJE ZNAKOV, KI VRNEJO NAJDENI ZNAK: */





long findfrelcharret(FILE *fp, char *str, int length, int buflength, char *ch)
    /* Najde prvo mesto v datoteki fp, na katerem je zapisani znak
    vsebovan v nizu str dolzine length. Isce od trenutne pozicije
    naprej in vrne stevilo bytov od trenutne pozicije do najdenega
    mesta. Steje od 0 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    $A Igor okt01; */
{
char found=0,end=0;
char *ss;
long pos=0,transfered;
int i,mempos;
*ch='\0';
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
transfered=fread(ss,sizeof(char),buflength,fp);
mempos=0;
while (!end && mempos<transfered)
{
  for (i=0; i<length; ++i)
  {
    if (str[i]==ss[mempos])
    {
      if (!found) /*Drugace bi bili problemi z nizi, kjer se znaki ponavljajo */
      {
        pos+=mempos;
        *ch=ss[mempos];
      }
      end=1;
      found=1;
    }
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  transfered=fread(ss,sizeof(char),buflength,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    for (i=0; i<length; ++i)
    {
      if (str[i]==ss[mempos])
      {
        if (!found)/*Drugace bi bili problemi z nizi, kjer se znaki ponavljajo*/
        {
          pos+=mempos;
          *ch=ss[mempos];
        }
        end=1;
        found=1;
      }
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
if (!found) pos=-1;
return pos;
}





long filecharret(FILE *fp, char *str, int length, long from, int buflength, char *ch)
    /* Najde prvo mesto v datoteki fp od pozicije from naprej, na
    katerem je zapisani znak vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    $A Igor okt01; */
{
long pos=0;
/* fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelcharret(fp,str,length,buflength,ch);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}






long findfrelchartoret(FILE *fp,char *str,int length,long max,int buflength,char *ch)
    /* Najde prvo mesto v datoteki fp, na katerem je zapisani znak
    vsebovan v nizu str dolzine length. Isce od trenutne pozicije
    naprej, s tem da se preveri najvec max bytov, in vrne stevilo
    bytov od trenutne pozicije do najdenega mesta. Steje od 0 naprej,
    ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    $A Igor okt01; */
{
char found=0,end=0;
char *ss;
long pos=0,transfered,dotransf;
int i,mempos;
*ch='\0';
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
if (buflength>max)
  dotransf=max;
else
  dotransf=buflength;
transfered=fread(ss,sizeof(char),dotransf,fp);
mempos=0;
while (!end && mempos<transfered)
{
  for (i=0; i<length; ++i)
  {
    if (str[i]==ss[mempos])
    {
      if (!found) /*Drugace bi bili problemi z nizi, kjer se znaki ponavljajo */
      {
        pos+=mempos;
        *ch=ss[mempos];
      }
      end=1;
      found=1;
    }
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  if (pos+buflength>max)
    dotransf=max-pos;
  else
    dotransf=buflength;
  transfered=fread(ss,sizeof(char),dotransf,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    for (i=0; i<length; ++i)
    {
      if (str[i]==ss[mempos])
      {
        if (!found)/*Drugace bi bili problemi z nizi, kjer se znaki ponavljajo*/
        {
          pos+=mempos;
          *ch=ss[mempos];
        }
        end=1;
        found=1;
      }
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
if (!found) pos=-1;
return pos;
}





long filechartoret(FILE *fp,char *str,int length,long from,long to,int buflength,char *ch)
    /* Najde prvo mesto v datoteki fp od pozicije from do pozicije to,
    na katerem je zapisani znak vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    $A Igor okt01; */
{
long pos=0;
/* fflush(fp); */
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelchartoret(fp,str,length,to-from+1,buflength,ch);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}









long findfrelnotcharret(FILE *fp, char *str, int length, int buflength, char *ch)
    /* Najde prvo mesto v datoteki fp, na katerem zapisani znak ni
    vsebovan v nizu str dolzine length. Isce od trenutne pozicije
    naprej in vrne stevilo bytov od trenutne pozicije do najdenega
    mesta. Steje od 0 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    $A Igor okt01; */
{
char found=0,end=0;
char *ss;
long pos=0,transfered;
int i,mempos;
*ch='\0';
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
transfered=fread(ss,sizeof(char),buflength,fp);
mempos=0;
while (!end && mempos<transfered)
{
  found=1;
  for (i=0; i<length; ++i)
  {
    if (str[i]==ss[mempos])
      found=0;
  }
  if (found)
  {
    pos+=mempos;
    *ch=ss[mempos];
    end=1;
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  transfered=fread(ss,sizeof(char),buflength,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    found=1;
    for (i=0; i<length; ++i)
    {
      if (str[i]==ss[mempos])
        found=0;
    }
    if (found)
    {
      pos+=mempos;
      *ch=ss[mempos];
      end=1;
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
if (!found) pos=-1;
return pos;
}








long filenotcharret(FILE *fp, char *str, int length, long from, int buflength, char *ch)
    /* Najde prvo mesto v datoteki fp od mesta from naprej, na
    katerem zapisani znak ni vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    $A Igor okt01; */
{
long pos=0;
/*n fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelnotcharret(fp,str,length,buflength,ch);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}



long findfrelnotchartoret(FILE *fp,char *str,int length,long max,int buflength,char *ch)
    /* Najde prvo mesto v datoteki fp, na katerem zapisani znak ni
    vsebovan v nizu str dolzine length. Isce od trenutne pozicije
    naprej , preveri najvec max bytov in vrne stevilo bytov od
    trenutne pozicije do najdenega mesta. Steje od 0 naprej, ce pa
    taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    $A Igor okt01; */
{
char found=0,end=0;
char *ss;
long pos=0,transfered,dotransf;
int i,mempos;
*ch='\0';
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
if (max<buflength)
  dotransf=max;
else
  dotransf=buflength;
transfered=fread(ss,sizeof(char),dotransf,fp);
mempos=0;
while (!end && mempos<transfered)
{
  found=1;
  for (i=0; i<length; ++i)
  {
    if (str[i]==ss[mempos])
      found=0;
  }
  if (found)
  {
    pos+=mempos;
    *ch=ss[mempos];
    end=1;
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  if (pos+buflength<=max)
    dotransf=buflength;
  else
  dotransf=max-pos;
  transfered=fread(ss,sizeof(char),dotransf,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    found=1;
    for (i=0; i<length; ++i)
    {
      if (str[i]==ss[mempos])
        found=0;
    }
    if (found)
    {
      pos+=mempos;
      *ch=ss[mempos];
      end=1;
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
if (!found) pos=-1;
return pos;
}








long filenotchartoret(FILE *fp,char *str,int length,long from,long to,
     int buflength,char *ch)
    /* Najde prvo mesto v datoteki fp od mesta from do mesta to, na
    katerem zapisani znak ni vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    $A Igor okt01; */
{
long pos=0;
/* fflush(fp); */
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelnotchartoret(fp,str,length,to-from+1,buflength,ch);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}





    /* FUNKCIJE ZA ISKANJE ZNAKOV, KI NE VRNEJO NAJDENEGA ZNAKA: */


long findfrelchar(FILE *fp, char *str, int length, int buflength)
    /* Najde prvo mesto v datoteki fp, na katerem je zapisani znak
    vsebovan v nizu str dolzine length. Isce od trenutne pozicije
    naprej in vrne stevilo bytov od trenutne pozicije do najdenega
    mesta. Steje od 0 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    */
{
char found=0,end=0;
char *ss;
long pos=0,transfered;
int i,mempos;
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
transfered=fread(ss,sizeof(char),buflength,fp);
mempos=0;
while (!end && mempos<transfered)
{
  for (i=0; i<length; ++i)
  {
    if (str[i]==ss[mempos])
    {
      if (!found) /*Drugace bi bili problemi z nizi, kjer se znaki ponavljajo */
        pos+=mempos;
      end=1;
      found=1;
    }
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  transfered=fread(ss,sizeof(char),buflength,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    for (i=0; i<length; ++i)
    {
      if (str[i]==ss[mempos])
      {
        if (!found)/*Drugace bi bili problemi z nizi, kjer se znaki ponavljajo*/
          pos+=mempos;
        end=1;
        found=1;
      }
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
if (!found) pos=-1;
return pos;
}





long filechar(FILE *fp, char *str, int length, long from, int buflength)
    /* Najde prvo mesto v datoteki fp od pozicije from naprej, na
    katerem je zapisani znak vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    */
{
long pos=0;
/* fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelchar(fp,str,length,buflength);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}






long findfrelcharto(FILE *fp,char *str,int length,long max,int buflength)
    /* Najde prvo mesto v datoteki fp, na katerem je zapisani znak
    vsebovan v nizu str dolzine length. Isce od trenutne pozicije
    naprej, s tem da se preveri najvec max bytov, in vrne stevilo
    bytov od trenutne pozicije do najdenega mesta. Steje od 0 naprej,
    ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    */
{
char found=0,end=0;
char *ss;
long pos=0,transfered,dotransf;
int i,mempos;
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
if (buflength>max)
  dotransf=max;
else
  dotransf=buflength;
transfered=fread(ss,sizeof(char),dotransf,fp);
mempos=0;
while (!end && mempos<transfered)
{
  for (i=0; i<length; ++i)
  {
    if (str[i]==ss[mempos])
    {
      if (!found) /*Drugace bi bili problemi z nizi, kjer se znaki ponavljajo */
        pos+=mempos;
      end=1;
      found=1;
    }
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  if (pos+buflength>max)
    dotransf=max-pos;
  else
    dotransf=buflength;
  transfered=fread(ss,sizeof(char),dotransf,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    for (i=0; i<length; ++i)
    {
      if (str[i]==ss[mempos])
      {
        if (!found)/*Drugace bi bili problemi z nizi, kjer se znaki ponavljajo*/
          pos+=mempos;
        end=1;
        found=1;
      }
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
if (!found) pos=-1;
return pos;
}





long filecharto(FILE *fp,char *str,int length,long from,long to,int buflength)
    /* Najde prvo mesto v datoteki fp od pozicije from do pozicije to,
    na katerem je zapisani znak vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    */
{
long pos=0;
/* fflush(fp); */
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelcharto(fp,str,length,to-from+1,buflength);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}









long findfrelnotchar(FILE *fp, char *str, int length, int buflength)
    /* Najde prvo mesto v datoteki fp, na katerem zapisani znak ni
    vsebovan v nizu str dolzine length. Isce od trenutne pozicije
    naprej in vrne stevilo bytov od trenutne pozicije do najdenega
    mesta. Steje od 0 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    */
{
char found=0,end=0;
char *ss;
long pos=0,transfered;
int i,mempos;
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
transfered=fread(ss,sizeof(char),buflength,fp);
mempos=0;
while (!end && mempos<transfered)
{
  found=1;
  for (i=0; i<length; ++i)
  {
    if (str[i]==ss[mempos])
      found=0;
  }
  if (found)
  {
    end=1;
    pos+=mempos;
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  transfered=fread(ss,sizeof(char),buflength,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    found=1;
    for (i=0; i<length; ++i)
    {
      if (str[i]==ss[mempos])
        found=0;
    }
    if (found)
    {
      end=1;
      pos+=mempos;
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
if (!found) pos=-1;
return pos;
}








long filenotchar(FILE *fp, char *str, int length, long from, int buflength)
    /* Najde prvo mesto v datoteki fp od mesta from naprej, na
    katerem zapisani znak ni vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    */
{
long pos=0;
/*n fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelnotchar(fp,str,length,buflength);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}



long findfrelnotcharto(FILE *fp,char *str,int length,long max,int buflength)
    /* Najde prvo mesto v datoteki fp, na katerem zapisani znak ni
    vsebovan v nizu str dolzine length. Isce od trenutne pozicije
    naprej , preveri najvec max bytov in vrne stevilo bytov od
    trenutne pozicije do najdenega mesta. Steje od 0 naprej, ce pa
    taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    */
{
char found=0,end=0;
char *ss;
long pos=0,transfered,dotransf;
int i,mempos;
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
if (max<buflength)
  dotransf=max;
else
  dotransf=buflength;
transfered=fread(ss,sizeof(char),dotransf,fp);
mempos=0;
while (!end && mempos<transfered)
{
  found=1;
  for (i=0; i<length; ++i)
  {
    if (str[i]==ss[mempos])
      found=0;
  }
  if (found)
  {
    end=1;
    pos+=mempos;
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  if (pos+buflength<=max)
    dotransf=buflength;
  else
  dotransf=max-pos;
  transfered=fread(ss,sizeof(char),dotransf,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    found=1;
    for (i=0; i<length; ++i)
    {
      if (str[i]==ss[mempos])
        found=0;
    }
    if (found)
    {
      end=1;
      pos+=mempos;
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
if (!found) pos=-1;
return pos;
}








long filenotcharto(FILE *fp,char *str,int length,long from,long to,
     int buflength)
    /* Najde prvo mesto v datoteki fp od mesta from do mesta to, na
    katerem zapisani znak ni vsebovan v nizu str dolzine length.
    Vrne stevilo bytov od zacetka datoteke do najdenega mesta. Steje
    od 1 naprej, ce pa taksnega mesta ne najde, vrne -1.
    buflength je dolzina pomoznega pomnilnika.
    */
{
long pos=0;
/* fflush(fp); */
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelnotcharto(fp,str,length,to-from+1,buflength);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}
















int findfrelbrac(FILE *fp,char open,char close,int buflength,
    long *pos1,long *pos2)
               /* Najde mesti v datoteki fp, kjer se zacne in konca prvi oklepaj.
               oklepaj je definiran z znakom open, zaklepaj pa z znakom close.
               Isce se od trenutne pozicije naprej, steti se zacne z 0.
               Ce ne najde ustreznega oklepaja, vrne -1.
               buflength je dolzina pomoznega pomnilnika. Mesto klepaja se vrne
               v pos1, mesto zaklepaja pa v pos2.
               Funkcija vrne stevilo zakljucenih oklepajev, ki so vsebovani med
               glavnima okllepajema. Ce ni vsebovanih podoklepajev, vrne 0, ce
               ni niti glavnih oklepajev, pa -1.
               */
{
char end=0;
char *ss;
long pos=0,transfered;
int mempos,num=0,ret=-1;
*pos1=-1;
*pos2=-1;
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
transfered=fread(ss,sizeof(char),buflength,fp);
mempos=0;
while (!end && mempos<transfered)
{
  if (ss[mempos]==open)
  {
    if (num==0) /* Nasli smo 1. oklepaj */
      *pos1=pos+mempos;
    ++num;
  } else if (ss[mempos]==close)
  {
    if (num>0) /* Ce se nismo nasli odpr. oklepaja, se zaprti ne steje */
    {
      --num;
      ++ret;
      if (num==0)
      {
        end=1;
        *pos2=pos+mempos;
      }
    }
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  transfered=fread(ss,sizeof(char),buflength,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    if (ss[mempos]==open)
    {
      if (num==0) /* Nasli smo 1. oklepaj */
        *pos1=pos+mempos;
      ++num;
    } else if (ss[mempos]==close)
    {
      if (num>0) /* Ce se nismo nasli odpr. oklepaja, se zaprti ne steje */
      {
        --num;
        ++ret;
        if (num==0)
        {
          end=1;
          *pos2=pos+mempos;
        }
      }
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
if (*pos2>-1)
    return ret;
else
  return -1;
}






int filebrac(FILE *fp,char open,char close,long from,int buflength,
    long *pos1,long *pos2)
            /* Najde mesti v datoteki fp, kjer se zacne in konca prvi oklepaj.
            oklepaj je definiran z znakom open, zaklepaj pa z znakom close.
            Isce se od pozicije from naprej.
            buflength je dolzina pomoznega pomnilnika. Mesto klepaja se vrne
            v pos1, mesto zaklepaja pa v pos2.
            Funkcija vrne stevilo zakljucenih oklepajev, ki so vsebovani med
            glavnima oklepajema. Ce ni vsebovanih podoklepajev, vrne 0, ce
            ni niti glavnih oklepajev, pa -1.
            */
{
int pos=0;
/* fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelbrac(fp,open,close,buflength,pos1,pos2);
  if (*pos1>=0)
    *pos1+=from;
  if (*pos2>=0)
    *pos2+=from;
} else
  pos= -1;
return pos;
}














int findfrelbracto(FILE *fp,char open,char close,long max,int buflength,
    long *pos1,long *pos2)
               /* Najde mesti v datoteki fp, kjer se zacne in konca prvi oklepaj.
               oklepaj je definiran z znakom open, zaklepaj pa z znakom close.
               Isce se od trenutne pozicije naprej, steti se zacne z 0, ter
               preisce najvec max bytov.
               Ce ne najde ustreznega oklepaja, vrne -1.
               buflength je dolzina pomoznega pomnilnika. Mesto klepaja se vrne
               v pos1, mesto zaklepaja pa v pos2.
               Funkcija vrne stevilo zakljucenih oklepajev, ki so vsebovani med
               glavnima okllepajema. Ce ni vsebovanih podoklepajev, vrne 0, ce
               ni niti glavnih oklepajev, pa -1.
               */
{
char end=0;
char *ss;
long pos=0,transfered,dotransf;
int mempos,num=0,ret=-1;
*pos1=-1;
*pos2=-1;
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
if (max<buflength)
  dotransf=max;
else
  dotransf=buflength;
transfered=fread(ss,sizeof(char),dotransf,fp);
mempos=0;
while (!end && mempos<transfered)
{
  if (ss[mempos]==open)
  {
    if (num==0) /* Nasli smo 1. oklepaj */
      *pos1=pos+mempos;
    ++num;
  } else if (ss[mempos]==close)
  {
    if (num>0) /* Ce se nismo nasli odpr. oklepaja, se zaprti ne steje */
    {
      --num;
      ++ret;
      if (num==0)
      {
        end=1;
        *pos2=pos+mempos;
      }
    }
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  if (pos+buflength<=max)
    dotransf=buflength;
  else
    dotransf=max-pos;
  transfered=fread(ss,sizeof(char),dotransf,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    if (ss[mempos]==open)
    {
      if (num==0) /* Nasli smo 1. oklepaj */
        *pos1=pos+mempos;
      ++num;
    } else if (ss[mempos]==close)
    {
      if (num>0) /* Ce se nismo nasli odpr. oklepaja, se zaprti ne steje */
      {
        --num;
        ++ret;
        if (num==0)
        {
          end=1;
          *pos2=pos+mempos;
        }
      }
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
if (*pos2>-1)
    return ret;
else
  return -1;
}






int filebracto(FILE *fp,char open,char close,long from,long to,int buflength,
    long *pos1,long *pos2)
            /* Najde mesti v datoteki fp, kjer se zacne in konca prvi oklepaj.
            Oklepaj je definiran z znakom open, zaklepaj pa z znakom close.
            Isce se od pozicije from do pozicije to.
            buflength je dolzina pomoznega pomnilnika. Mesto oklepaja se vrne
            v pos1, mesto zaklepaja pa v pos2.
            Funkcija vrne stevilo zakljucenih oklepajev, ki so vsebovani med
            glavnima oklepajema. Ce ni vsebovanih podoklepajev, vrne 0, ce
            ni niti glavnih oklepajev, pa -1.
            */
{
int pos=0;
/* fflush(fp); */
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelbracto(fp,open,close,to-from+1,buflength,pos1,pos2);
  if (*pos1>=0)
    *pos1+=from;
  if (*pos2>=0)
    *pos2+=from;
} else
{
  pos= -1;
  *pos1=-1;
  *pos2=-1;
}
return pos;
}




















long findfrelbraclev(FILE *fp,char open,char close,int level,int buflength)
               /* Najde mesto v datoteki fp, kjer se nivo oklepajev doseze
               level. Oklepaj je definiran z znakom open, zaklepaj pa z znakom
               close. Nivo je na zacetku nic, z vsakim oklepajem se poveca za 1,
               z vsakim zaklepajem pa pade za 1. Isce se od trenutne pozicije
               naprej, steti se zacne z 0. Ce ne najde ustreznega nivoja, vrne
               -1. Ce je level 0, vrne 1. mesto za 1. oklepajem, kjer je nivo
               spet 0.   buflength je dolzina pomoznega pomnilnika.
               */
{
char end=0;
char *ss;
long pos=0,transfered;
int mempos,num=0,ret=-1;
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
transfered=fread(ss,sizeof(char),buflength,fp);
mempos=0;
while (!end && mempos<transfered)
{
  if (ss[mempos]==open)
  {
    ++num;
    if (num==level)
    {
      end=1;
      ret=pos+mempos;
    }
  } else if (ss[mempos]==close)
  {
    --num;
    if (num==level)
    {
      end=1;
      ret=pos+mempos;
    }
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  transfered=fread(ss,sizeof(char),buflength,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    if (ss[mempos]==open)
    {
      ++num;
      if (num==level)
      {
        end=1;
        ret=pos+mempos;
      }
    } else if (ss[mempos]==close)
    {
      --num;
      if (num==level)
      {
        end=1;
        ret=pos+mempos;
      }
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
return ret;
}






long filebraclev(FILE *fp,char open,char close,int level,
     long from,int buflength)
               /* Najde mesto v datoteki fp, kjer nivo oklepajev doseze level.
               Oklepaj je definiran z znakom open, zaklepaj pa z znakom close.
               Nivo je na zacetku nic, z vsakim oklepajem se poveca za 1,
               z vsakim zaklepajem pa pade za 1. Isce se od pozicije from
               naprej. Ce ne najde ustreznega nivoja, vrne -1. Ce je level 0,
               vrne 1. mesto za 1. oklepajem, kjer je nivo spet 0.
               buflength je dolzina pomoznega pomnilnika.
               */
{
long pos=0;
/* fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelbraclev(fp,open,close,level,buflength);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}














long findfrelbraclevto(FILE *fp,char open,char close,int level,
    long max,int buflength)
               /* Najde mesto v datoteki fp, kjer se nivo oklepajev doseze
               level. Oklepaj je definiran z znakom open, zaklepaj pa z znakom
               close. Nivo je na zacetku nic, z vsakim oklepajem se poveca za 1,
               z vsakim zaklepajem pa pade za 1. Isce se od trenutne pozicije
               naprej, steti se zacne z 0. Ce ne najde ustreznega nivoja, vrne
               -1. Ce je level 0, vrne 1. mesto za 1. oklepajem, kjer je nivo
               spet 0. Preisce se najvec max znakov. buflength je dolzina
               pomoznega pomnilnika.
               */
{
char end=0;
char *ss;
long pos=0,transfered,dotransf;
int mempos,num=0,ret=-1;
if (buflength<=0)
  buflength=5;
ss=malloc(buflength*sizeof(char));
if (max<buflength)
  dotransf=max;
else
  dotransf=buflength;
transfered=fread(ss,sizeof(char),dotransf,fp);
mempos=0;
while (!end && mempos<transfered)
{
  if (ss[mempos]==open)
  {
    ++num;
    if (num==level)
    {
      end=1;
      ret=pos+mempos;
    }
  } else if (ss[mempos]==close)
  {
    --num;
    if (num==level)
    {
      end=1;
      ret=pos+mempos;
    }
  }
  ++mempos;
}
if (transfered<buflength)
{
  end=1;
}
while (!end)
{
  pos+=buflength;
  if (pos+buflength<=max)
    dotransf=buflength;
  else
    dotransf=max-pos;
  transfered=fread(ss,sizeof(char),dotransf,fp);
  mempos=0;
  while (!end && mempos<transfered)
  {
    if (ss[mempos]==open)
    {
      ++num;
      if (num==level)
      {
        end=1;
        ret=pos+mempos;
      }
    } else if (ss[mempos]==close)
    {
      --num;
      if (num==level)
      {
        end=1;
        ret=pos+mempos;
      }
    }
    ++mempos;
  }
  if (transfered<buflength)
  {
     end=1;
  }
}
free(ss);
return ret;
}






long filebraclevto(FILE *fp,char open,char close,int level,
    long from,long to,int buflength)
               /* Najde 1. mesto v datoteki fpmed pozicijama from in to, kjer
               nivo oklepajev doseze level in vrne to mesto (steje od 1).
               Oklepaj je definiran z znakom open, zaklepaj pa z znakom
               close. Nivo je na zacetku nic, z vsakim oklepajem se poveca za 1,
               z vsakim zaklepajem pa pade za 1. Ce ne najde ustreznega nivoja,
               vrne -1. Ce je level 0, vrne 1. mesto za 1. oklepajem, kjer je
               nivo spet 0. buflength je dolzina  pomoznega pomnilnika.
               */
{
long pos=0;
/* fflush(fp); */
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  pos=findfrelbraclevto(fp,open,close,level,to-from+1,buflength);
  if (pos>=0)
    pos+=from;
} else
  pos= -1;
return pos;
}










double findfrelnum(FILE *fp,int minbuf,long *start,int *length)
               /* V datoteki fp najde prvi pojav niza, ki lahko predstavlja
               stevilo. Vrne vrednost tipa double, ki ustreza temu nizu, v
               start zapise relativno pozicijo zacetka niza, ki predstavlja
               stevilo, v length pa njegovo dolzino. Isce od trenutne pozicije
               v datoteki naprej, steti zacne z 0. Ce taksnega niza ne najde,
               postavi start in length na -1. */
{
char found=0,end=0;
char *ss,*ss1,*ss2,*endnum;
long pos=0,transfered;
int endlength,midlength,buflength,wholelength,i;
double ret;
*start=-1; *length=-1;
endnum=NULL;
midlength=1; /* dolzina dodatnega pomnilnika */
endlength=30; /* To je toliko, kolikor lahko najvec pricakujemo, da bo znakov v
nizu, ki predstavlja stevilo. */
if (endlength<minbuf)
  midlength=minbuf-endlength;
buflength=endlength+midlength;
wholelength=2*endlength+midlength;
ss=malloc((1+wholelength)*sizeof(char));
ss1=ss+endlength;
ss2=ss1+midlength;
transfered=fread(ss,sizeof(char),wholelength,fp);
if (transfered<wholelength)
{
  end=1;
  ss[transfered]='z'; /* Znak, ki ne more pripadati steivlu */
}
i=0;
if (end && transfered>0)
{
  /* Ce smo datoteko ze prebrali do konca, ne preiscemo samo zacetnega in
  srednjega dela pomoznega pomnilnika, ampak celotno prebrano obmocje. */
  while (i<transfered && !found)
  {
    ret=strtod(ss+i,&endnum);
    if (endnum-(ss+i)>0 && endnum!=NULL)
    {
      /* Funkcija strtod prepozna niz za niz, ki predstavlja stevilo, tudi,
      ce se zacne s presledkom ali newline. Zato stvar preverimo se z
      nstrnum1.*/
      if (nstrnum1(ss+i)>0)
        found=1;
      else
        endnum=NULL;
    }
    ++i;
  }
}
if (!end) /* Preiscemo le zacetni in srednji del pomoznega pomnilnika */
{
  while (i<buflength && !found)
  {
    ret=strtod(ss+i,&endnum);
    if (endnum-(ss+i)>0 && endnum!=NULL)
    {
      if (nstrnum1(ss+i)>0)
        found=1;
      else
        endnum=NULL;
    }
    ++i;
  }
}
if (found)
{
  --i; /* Ker se je i po tistem, ko smo niz nasli, se enkrat inkrementiral */
  pos+=i;
  /* Ker se je i po tistem, ki smo niz nasli, se enkrat inkrementiral */
  *start=pos;
  *length=(endnum-ss)-i;
  end=1;
}
while (!end)
{
  /* strcpy(ss,ss2); */
  memcpy(ss,ss2,endlength);
  pos+=buflength;
  transfered=fread(ss1,sizeof(char),buflength,fp);
  if (transfered<buflength)
  {
     end=1;
  }
  i=0;
  /* $$ bug: if (end && transfered>0)  */
  if (end)
  {
    /* Ce smo datoteko ze prebrali do konca, ne preiscemo samo zacetnega in
    srednjega dela pomoznega pomnilnika, ampak celotno prebrano obmocje. */
    /* $$ bug: while (i<transfered && !found)  */
    while (i<transfered+endlength && !found)
    {
      ret=strtod(ss+i,&endnum);
      if (endnum-(ss+i)>0 && endnum!=NULL)
      {
        if (nstrnum1(ss+i)>0)
          found=1;
        else
          endnum=NULL;
      }
      ++i;
    }
  }
  if (!end) /* Preiscemo le zacetni in srednji del pomoznega pomnilnika */
  {
    while (i<buflength && !found)
    {
      ret=strtod(ss+i,&endnum);
      if (endnum-(ss+i)>0 && endnum!=NULL)
      {
        if (nstrnum1(ss+i)>0)
          found=1;
        else
          endnum=NULL;
      }
      ++i;
    }
  }
  if (found)
  {
    --i; /* Ker se je i po tistem, ki smo niz nasli, se enkrat inkrementiral */
    pos+=i;
    *start=pos;
    *length=(endnum-ss)-i;
    end=1;
  }
}
free(ss);
return ret;
}



double filenum(FILE *fp,long from,int minbuf,long *start,int *length)
               /* V datoteki *fp najde prvi pojav niza, ki lahko predstavlja
               stevilo, od pozicije from naprej. Vrne vrednost, ki ustreza temu
               nizu, v start zapise mesto v datoteki (steje od 1 naprej), kjer
               se ta niz zacne, v length pa vrne dolzino tega niza. Ce taksnega
               niza ne najde, v start in length zapise -1, vrne pa poljubno
               vrednost.
               */
{
double ret=0;
/* fflush(fp); */
if (from<=flength(fp))
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  ret=findfrelnum(fp,minbuf,start,length);
  if (*start>=0)
  {
    *start+=from;
  }
} else
{
  *start=-1;
  *length=-1;
}
return ret;
}





double filenumbrac(FILE *fp,long from,char *left,int lleft,
       char *right,int lright,int minbuf,long *start,int *length)
               /* V datoteki *fp najde prvi pojav niza, ki lahko predstavlja
               stevilo, od pozicije from naprej. Stejejo samo tisti nizi, ki
               so z leve omejeni z znakom, ki je vsebovan v nizu left dolzine
               lleft, z desne pa z znakom, ki je vsebovan v nizu right dolzine
               lright. Namesto ustreznega znaka na levi velja tudi, ce se niz
               zacne na zacetku datoteke, namesto znaka na desni pa, ce se
               konca na koncu datoteke. Funkcija vrne vrednost, ki ustreza temu
               nizu, v start zapise mesto v datoteki (steje od 1 naprej), kjer
               se ta niz zacne, v length pa vrne dolzino tega niza. Ce taksnega
               niza ne najde, v start in length zapise -1, vrne pa poljubno
               vrednost. Zacetek in dolzina niza sta misljena brez znakov, ki
               ta niz omejujeta.
               Funkcija je uporabna na primer v datotekah, kjer so lahko nizi,
               ki lahko predstavljajo stevila, deli imen spremenljivk.
               */
{
double ret=0;
char end=0,found=0,wrongbrac,chr;
int i;
/* fflush(fp); */
if (from>flength(fp))
  end=1;
while (!end)
{
  ret=filenum(fp,from,minbuf,start,length);
  if (*start>0)
  {
    /* Ce je klic filenum uspesen, se preverijo znaki, ki omejujejo najdeni
    niz */
    found=1;
    if (*start>1) /* Ce se niz ne zacne na zacetku datoteke*/
    {
      chr=filereadchar(fp,*start-1); /* Znak, ki omejuje niz z leve */
      wrongbrac=1;
      if (lleft>0)
        for (i=0;i<lleft;++i)
        {
          if (chr==left[i])
            wrongbrac=0;
        }
      if (wrongbrac) found=0;
    }
    if (*start+*length-1<flength(fp)) /* Ce niz ni dolg do konca datoteke */
    {
      chr=filereadchar(fp,*start+*length); /* Znak, ki omejuje niz z desne */
      wrongbrac=1;
      if (lright>0)
        for (i=0;i<lright;++i)
        {
          if (chr==right[i])
            wrongbrac=0;
        }
      if (wrongbrac)
        found=0;
    }
    if (found)
      end=1;
  } else
  {
    end=1; /* Ce je klic filenum neuspesen */
  }
  if (!end)
  {
    from=*start+*length;
    /* Iskanje se nadaljuje naprej od najdenega niza, ki predstavlja stevilo */
  }
}
if (!found)
{
  *start=-1;
  *length=-1;
}
return ret;
}













double findfrelnumto(FILE *fp,long max,int minbuf,long *start,int *length)
               /* V datoteki fp najde prvi pojav niza, ki lahko predstavlja
               stevilo. Vrne vrednost tipa double, ki ustreza temu nizu, v
               start zapise relativno pozicijo zacetka niza, ki predstavlja
               stevilo, v length pa njegovo dolzino. Isce od trenutne pozicije
               v datoteki naprej, steti zacne z 0. Ce taksnega niza ne najde,
               postavi start in length na -1. */
{
char found=0,end=0;
char *ss,*ss1,*ss2,*endnum;
long pos=0,transfered,dotransf;
int endlength,midlength,buflength,wholelength,i;
double ret;
*start=-1; *length=-1;
endnum=NULL;
midlength=1; /* dolzina dodatnega pomnilnika */
endlength=30; /* To je toliko, kolikor lahko najvec pricakujemo, da bo znakov v
nizu, ki predstavlja stevilo. */
if (endlength<minbuf)
  midlength=minbuf-endlength;
buflength=endlength+midlength;
wholelength=2*endlength+midlength;
ss=malloc((wholelength+1)*sizeof(char));
ss[wholelength]='z';  /* Znak, ki ne more pripadati stevilu. */
ss1=ss+endlength;
ss2=ss1+midlength;
dotransf=wholelength;
if (dotransf>max)
  dotransf=max;
transfered=fread(ss,sizeof(char),dotransf,fp);
if (transfered<wholelength)
{
  end=1;
  ss[transfered]='z'; /* Znak, ki ne more pripadati steivlu */
}
i=0;
if (end && transfered>0)
{
  /* Ce smo datoteko ze prebrali do konca, ne preiscemo samo zacetnega in
  srednjega dela pomoznega pomnilnika, ampak celotno prebrano obmocje. */
  while (i<transfered && !found)
  {
    ret=strtod(ss+i,&endnum);
    if (endnum-(ss+i)>0 && endnum!=NULL)
    {
      /* Funkcija strtod prepozna niz za niz, ki predstavlja stevilo, tudi,
      ce se zacne s presledkom ali newline. Zato stvar preverimo se z
      nstrnum1.*/
      if (nstrnum1(ss+i)>0)
        found=1;
      else
        endnum=NULL;
    }
    ++i;
  }
}
if (!end) /* Preiscemo le zacetni in srednji del pomoznega pomnilnika */
{
  while (i<buflength && !found)
  {
    ret=strtod(ss+i,&endnum);
    if (endnum-(ss+i)>0 && endnum!=NULL)
    {
      if (nstrnum1(ss+i)>0)
        found=1;
      else
        endnum=NULL;
    }
    ++i;
  }
}
if (found)
{
  --i; /* Ker se je i po tistem, ko smo niz nasli, se enkrat inkrementiral */
  pos+=i;
  /* Ker se je i po tistem, ki smo niz nasli, se enkrat inkrementiral */
  *start=pos;
  *length=(endnum-ss)-i;
  end=1;
}
while (!end)
{
  /* strcpy(ss,ss2); */
  memcpy(ss,ss2,endlength);
  pos+=buflength;
  if (pos+buflength<=max)
    dotransf=buflength;
  else
    dotransf=max-pos;

  /* DODANO */
  if (dotransf<1)
  {
    end=1;
  }
  transfered=fread(ss1,sizeof(char),dotransf,fp);
  if (transfered<dotransf || transfered==0)
  {
     end=1;
  }
  i=0;
  /* $$ bug: if (end && transfered>0) */
  if (end)
  {
    /* Ce smo datoteko ze prebrali do konca, ne preiscemo samo zacetnega in
    srednjega dela pomoznega pomnilnika, ampak celotno prebrano obmocje. */
    /* $$ bug: while (i<transfered && !found) */
    while (i<transfered+endlength && !found)
    {
      ret=strtod(ss+i,&endnum);
      if (endnum-(ss+i)>0 && endnum!=NULL)
      {
        if (nstrnum1(ss+i)>0)
          found=1;
        else
          endnum=NULL;
      }
      ++i;
    }
  }
  if (!end) /* Preiscemo le zacetni in srednji del pomoznega pomnilnika */
  {
    while (i<buflength && !found)
    {
      ret=strtod(ss+i,&endnum);
      if (endnum-(ss+i)>0 && endnum!=NULL)
      {
        if (nstrnum1(ss+i)>0)
          found=1;
        else
          endnum=NULL;
      }
      ++i;
    }
  }
  if (found)
  {
    --i; /* Ker se je i po tistem, ki smo niz nasli, se enkrat inkrementiral */
    pos+=i;
    *start=pos;
    *length=(endnum-ss)-i;
    end=1;
  }
}
free(ss);
return ret;
}



double filenumto(FILE *fp,long from,long to,int minbuf,long *start,int *length)
               /* V datoteki *fp najde prvi pojav niza, ki lahko predstavlja
               stevilo, od pozicije from naprej. Vrne vrednost, ki ustreza temu
               nizu, v start zapise mesto v datoteki (steje od 1 naprej), kjer
               se ta niz zacne, v length pa vrne dolzino tega niza. Ce taksnega
               niza ne najde, v start in length zapise -1, vrne pa poljubno
               vrednost.
               */
{
double ret=0;
if (from<=0)
  from=1;
if (to<=0)
  to=flength(fp);
if (from<=flength(fp) && from<=to)
{
  /* fflush(fp); */
  fseek(fp,from-1,SEEK_SET); /* Ker c steje pozicije od 0 naprej */
  ret=findfrelnumto(fp,to-from+1,minbuf,start,length);
  if (*start>=0)
  {
    *start+=from;
  }
} else
{
  *start=-1;
  *length=-1;
  ret=-1;
}
return ret;
}





/* STEVILCENJE VRSTIC V DATOTEKI S C-JEVSKIMI KOMENTARJI */



int filelinenumbers(char *filename,int from,int to,char *beginstr,
    char *endstr,char *begincomment,char *endcomment,int buflength,
    char clearold,char clearspaces,char setnew)
    /* Stevilcenje vrstic datoteke z imenom filename. beginstr je niz, ki se
    doda na zacetku oznake stevilke vrstice, endstr pa niz, ki se doda na koncu
    oznake. buflength je dolzina  vmesnega pomnilnika, ki se uporali pri
    kopiranju vsebine datoteke. Hkrati je to najvecja dopustna dolzina vrstice
    v datoteki.
      Oznacijo se vrstice od from do to. begincomment je niz, ki oznacuje
    zacetek komentarja, endcomment pa niz, ki oznacuje njegov konec. Ce sta oba
    razlicna od NULL, se ne oznacijo stevilke tistih vrstic, katerih konci so
    znotraj komentarjev.
      Ce je clearold razlicen od 0, se najprej zbrisejo vse stare oznke stevilk
    vrstic. Ce je clearspaces razlicen od 0, se brisejo odvecni presledki na
    koncih vrstic. Ce je setnew razlicen od 0, se dodajo nove oznake stevilk
    vrstic vrsticam od from do to.
      Funkcija vrne 0, ce je izvedba uspesna in -1, ce datoteka z danim imenom
    ne  obstaja. */
{
int ret=0,i=0,num=0,n;
char incomment=0,end=0,checkcomment=1;
char *buf=NULL,*pos,*pos1,*control;
int start=70;  /* Mesto v vrstici, kjer naj se zacne oznaka stevilke */
FILE *fp,*fptemp;
if (to<=0) to=1000000;
if (from<=0) from=1;
if (to<from) to=from;
if (beginstr==NULL || strlen(beginstr)==0) beginstr="/*!";
if (endstr==NULL || strlen(endstr)==0) endstr="*/";
if (begincomment==NULL || strlen(begincomment)==0) begincomment="/*";
if (endcomment==NULL || strlen(endcomment)==0) endcomment="*/";
if (buflength<=80+(int) strlen(beginstr)) buflength=500+strlen(beginstr);
++buflength; /* Zaradi lastnosti fgets */
buf=malloc(buflength);
fp=fopen(filename,"rb");
if (fp==NULL)
  ret=-1;
else
{
  num=0;
  fptemp=tmpfile();
  if (begincomment==NULL || endcomment==NULL)
    checkcomment=0;
  while (!feof(fp))
  {
    ++num;
    /* V buf se prebere vrstica iz datoteke, ki jo stevilcimo: */
    control=fgets(buf,buflength,fp);
    if (control==buf) /* Ce je bila vrstica res prebrana */
    {
      if (checkcomment)
      {
        end=0;
        pos=buf;
        while (!end)
        {
          /* incomment pove, ali je konec vrstice v komentarju ali ne. */
          if (incomment)
          {
            pos=memfind(pos,strlen(pos),endcomment,strlen(endcomment));
            if (pos==NULL)
              end=1;
            else
            {
              incomment=0;
              ++pos;
            }
          } else  /* !incomment */
          {
            pos=memfind(pos,strlen(pos),begincomment,strlen(begincomment));
            if (pos==NULL)
              end=1;
            else
            {
              incomment=1;
              ++pos;
            }
          }
        }
      }
      if (buf[strlen(buf)-1]=='\n')
        buf[strlen(buf)-1]='\0';
      if (clearold)
      {
        /* Preveri se, ce je ta vrstica ze ima stevilko vrstice: */
        pos=memfind(buf,strlen(buf),beginstr,strlen(beginstr));
        if (pos!=NULL)
          pos1=memfind(pos+1,strlen(pos)-1,endstr,strlen(endstr));
        /* Ce vrstica ze ima oznako stevilke na koncu, se ta odreze: */
        if (pos!=NULL && pos1!=NULL)
          pos[0]='\0';
      }
      if (clearspaces)
        if (!(setnew && num>=from && num<=to && (!incomment)))
        {
          /* Ce vrstica ni med tistimi, ki jih je treba ostevilciti, se zbrisejo
          odvecni presledki na koncu vrstice: */
          pos=buf+strlen(buf)-1;
          while (pos>=buf && pos[0]==' ')
          {
            pos[0]='\0';
            --pos;
          }
        }
      if (setnew)
      {
        if (num>=from && num<=to && (!incomment))
        {
          /* Doda se oznaka stevilke vrstice, ce konec vrstice ni v komentaju: */
          if ((int) strlen(buf)<start)
          {
            for (i=strlen(buf); i<=start; ++i)
              buf[i]=' ';
            buf[start]='\0';
          } else if ((int) strlen(buf)+20<buflength)
          {
            n=strlen(buf);
            for (i=n; i<=n+2; ++i)
              buf[i]=' ';
            buf[n+2]='\0';

          }
          pos=buf+strlen(buf);
          sprintf(pos,"%s%i%s\0",beginstr,num,endstr);
        }
      }
      fputs(buf,fptemp);
      putc('\n',fptemp);
    }
  }
  fclose(fp);
  /* Kopiranje vsebine datoteke fptemp na datoteko z imenom filename: */
  fp=fopen(filename,"wb");
  rewind(fp);
  /* fflush(fptemp); */
  rewind(fptemp);
  while (!feof(fptemp))
  {
    i=fread(buf,1,buflength,fptemp);
    if (i>0)
      fwrite(buf,1,i,fp);
  }
  fclose(fp);
  fclose(fptemp);
}
if (buf!=NULL)
  free(buf);
return ret;
}



int numberfilelines(char *filename,int from, int to,char *beginstr,
            char *endstr,char *begincomment,char *endcomment,int buflength)
    /* V datoteki z imenom filename ostevilci vrstice tako, da na koncu vsake
    vrstice od from do to, ki ni v komentarju, doda beginstr, stevilko vrstice
    in endstr. Ce je begincomment ali endcomment enak NULL, se na komentarje ne
    ozira. buflength je dolzina vmesnega pomnilnika, ki se uporabi pri kopiranju
    datotek in hkrati najvecja dopustna dolzina vrstice. Vrstice, ki so ze
    ostevilcene, se ostevilcijo se enkrat.
      Funkcija vrne 0, ce je klic uspesen, in -1, ce datoteka z danim imenom
    ne obstaja.  */
{
return filelinenumbers(filename,from,to,beginstr,endstr,
                       begincomment,endcomment,buflength,0,0,1);
}

int renumberfilelines(char *filename,int from, int to,char *beginstr,
               char *endstr,char *begincomment,char *endcomment,int buflength)
    /* Podobno kot funkcija numberfilelines, le da se najprej zbrisejo vse
    obstojece oznake vrstic. */
{
return filelinenumbers(filename,from,to,beginstr,endstr,
                       begincomment,endcomment,buflength,1,1,1);
}

int denumberfilelines(char *filename,int from, int to,char *beginstr,
             char *endstr,char *begincomment,char *endcomment,int buflength)
    /* Iz datoteke z imenom filename zbrise oznake stevilk vrstic, ki so bile
    postavljene s funkcijama numberfilelines in renumberfilelines, ce smo ti
    funkciji klicali z enakimi argumenti from, to, beginstr, endstr, begincomment
    in endcomment. buflength je dolzina vmesnega pomnilnika, ki se uporabi pri
    prepisovanju datotek in hkrati najvecja dopustna dolzina vrstice.
      Funkcija zbrise tudi vse odvecne presledke na koncu vrstic. Uspesen klic
      vrne 0, neuspesen pa -1, ce datoteka z imenom filename ne obstaja. */
{
return filelinenumbers(filename,from,to,beginstr,endstr,
                       begincomment,endcomment, buflength,1,1,0);

}



/* SPLOSNE POMOZNE FUNKCIJE : identifikacija stevilke vrstice in stolpca,
     preverjanje oklepajnih parov, izpis nekaj vrstic ... */



void filelinepos(FILE *fp,long pos,int *line,int *column)
    /* V *line in *column zapise vrstico in stolpec znaka, ki ima v datoteki fp
    pozicijo pos.
    $A Igor apr98; */
{
long pos1=1,pos2=1;
*line=*column=-1;
if (pos==0)
  pos=flength(fp);
if (fp!=NULL && pos1>0)
{
  *line=*column=1;
  while(pos2<pos && pos2>0)
  {
    /* Najprej pos2 postane zacetek naslednje vrstice od pos1 naprej: */
    pos2=filechar(fp,"\n",1,pos1,80);
    if (pos2<0)
    {
      /* Ce ni zacetka naslednje vrstice (ce je pred tem konec datoteke),
      postane pos2 za eno vec kot dolzina datoteke: */
      pos2=flength(fp);
      pos1=-1;
    }
    ++pos2;
    if (pos<pos2)
    {
      *column=1+pos-pos1;
    } else
    {
      ++*line;
      pos1=pos2; /* pos1 postane zacetek nove tekoce vrstice */
    }
  }
  if (*column<=0)
    *line=-1;
}
}


int fline(FILE *fp,int pos)
    /*Vrne stevilko vrstice v datoteki fp, ki ustreza trenutni poziciji pos.
    $A Igor sep01; */
{
int line,col;
filelinepos(fp,pos,&line,&col);
return line;
}

int fcol(FILE *fp,int pos)
    /*Vrne stevilko stolpca v vrstici v datoteki fp, ki ustreza trenutni
    poziciji pos.
    $A Igor sep01; */
{
int line,col;
filelinepos(fp,pos,&line,&col);
return col;
}

long fileabspos(FILE *fp,int line,int column)
    /* Vrne pozicijo znaka, ki je v datoteki fp v vrstici line in stolpcu
    column.
    $A Igor apr98; */
{
long pos=-1;
int i;
if (line>0 && column>0 && fp!=NULL)
{
  i=1; pos=1;
  while (i<line && pos>0)
  {
    pos=filechar(fp,"\n",1,pos,80);
    if (pos>0)
    {
      ++i;
      ++pos;
    }
  }
  if (pos>0)
  {
    pos+=column-1;
  }
}
return pos;
}


int fprintcheckfilebracto0(FILE *out,FILE *fp,long from,long to,int buf)
    /* Preveri, ce imajo vsi oklepaji v datoteki fp med from in to svoje
    zaklepaje. V datoteko out izpise vse oklepaje in zaklepaje, pri cemer oznaci
    tiste, ki nimajo para, in vrne stivilo oklepajev in zaklepajev, ki nimajo
    para. buf je dolzina pomoznega pomnilnika za iskanje po datotekah.
     Preverjajo se pari (), [] in {}.
    Opomba: Ime funkcije ima na koncu znak '0', ker je ime brez nicle
    prihranjeno za bolj splosno funkcijo, pri kateri se z argumenti doloci,
    katere pare oklepajev naj se preverja.
    $A Igor apr98; */
{
long pos,pos1,pos2;
char brac1,brac2;
int errors=0;
if (out!=NULL)
{
  pos=filecharto(fp,"([{}])",6,from,to,buf);
  if (pos>0)
  {
    brac1=filereadchar(fp,pos);
    if (brac1==')' || brac1==']' || brac1=='}')
    {
      fprintf(out," =>%c! ",brac1);
      ++errors;
      if(to>pos)
        errors+=fprintcheckfilebracto0(out,fp,pos+1,to,buf);
    } else
    {
      if (brac1=='(')
        brac2=')';
      else if (brac1=='[')
        brac2=']';
      else if (brac1=='{')
        brac2='}';
      filebracto(fp,brac1,brac2,pos,to,buf,&pos1,&pos2);
      if (pos1>0 && pos2>0)
      {
        fprintf(out,"%c",brac1);
        if (pos2>pos1+1)
          errors+=fprintcheckfilebracto0(out,fp,pos1+1,pos2-1,buf);
        fprintf(out,"%c",brac2);
        if (to>pos2)
          errors+=fprintcheckfilebracto0(out,fp,pos2+1,to,buf);
      } else
      {
        fprintf(out," =>%c! ",brac1);
        ++errors;
        if(to>pos)
          errors+=fprintcheckfilebracto0(out,fp,pos+1,to,buf);
      }
    }
  }
}
return errors;
}


int printcheckfilebracto0(FILE *fp,long from,long to,int buf)
    /* Preveri, ce imajo vsi oklepaji v datoteki fp med from in to svoje
    zaklepaje. Na stand. izhod izpise vse oklepaje in zaklepaje, pri cemer
    oznaci tiste, ki nimajo para, in vrne stivilo oklepajev in zaklepajev, ki
    nimajo para. buf je dolzina pomoznega pomnilnika za iskanje po datotekah.
     Preverjajo se pari (), [] in {}.
    Opomba: Ime funkcije ima na koncu znak '0', ker je ime brez nicle
    prihranjeno za bolj splosno funkcijo, pri kateri se z argumenti doloci,
    katere pare oklepajev naj se preverja.
    $A Igor apr98; */
{
return fprintcheckfilebracto0(stdout,fp,from,to,buf);
}


int checkfilebracto0(FILE *fp,long from,long to,int buf)
    /* Preveri, ce imajo vsi oklepaji v datoteki fp med from in to svoje
    zaklepaje. Vrne stivilo oklepajev in zaklepajev, ki nimajo para oziroma 0,
    ce so vsi pravilno postavljeni. buf je dolzina pomoznega pomnilnika za
    iskanje po datotekah. Preverjajo se pari (), [] in {}.
    Opomba: Ime funkcije ima na koncu znak '0', ker je ime brez nicle
    prihranjeno za bolj splosno funkcijo, pri kateri se z argumenti doloci,
    katere pare oklepajev naj se preverja.
    $A Igor apr98; */
{
long pos,pos1,pos2;
char brac1,brac2;
int errors=0;
pos=filecharto(fp,"([{}])",6,from,to,buf);
if (pos>0)
{
  brac1=filereadchar(fp,pos);
  if (brac1==')' || brac1==']' || brac1=='}')
  {
    ++errors;
    if(to>pos)
      errors+=checkfilebracto0(fp,pos+1,to,buf);
  } else
  {
    if (brac1=='(')
      brac2=')';
    else if (brac1=='[')
      brac2=']';
    else if (brac1=='{')
      brac2='}';
    filebracto(fp,brac1,brac2,pos,to,buf,&pos1,&pos2);
    if (pos1>0 && pos2>0)
    {
      if (pos2>pos1+1)
        errors+=checkfilebracto0(fp,pos1+1,pos2-1,buf);
      if (to>pos2)
        errors+=checkfilebracto0(fp,pos2+1,to,buf);
    } else
    {
      ++errors;
      if(to>pos)
        errors+=checkfilebracto0(fp,pos+1,to,buf);
    }
  }
}
return errors;
}



int fprintfewfilelines(FILE *fp,FILE *from,long pos0,int pre,int post,
           char *sign)
    /* V datoteko fp se zapise pre vrstic iz datoteke from pred pozicijo pos0
    in post vrstic iz te datoteke za pozicijo pos0, vkljucno z vrstico, ki
    vsebuje pozicijo pos0. Funkcija vrne zaporedno stevilko vrstice v datoteki
    from, ki vsebuje pozicijo pos0. Tik pred zapisom te vrstice se v datoteko
    fp izpise niz sign.
    $A Igor apr98 apr99; */
{
int line=0,column,line1,line2;
long pos,pos1,pos2;
char ch;
if (from==NULL)
{
  printf("\n\nError in function fprintfewfilelines: File not open.\n\n");
} else if (fp==NULL)
{
  ;
} else
{
  filelinepos(from,pos0,&line,&column);
  if (line<=0)
  {
    printf("\n\nError in function fprintfewfilelines: Position out of range.\n\n");
  } else
  {
    line1=line-pre;
    if (line1<=0)
      line1=1;
    line2=line+post;
    pos1=fileabspos(from,line1,1);
    pos=fileabspos(from,line,1);
    pos2=fileabspos(from,line2,1);
    if ((pos2<=0) || pos2>flength(from))
      pos2=flength(from);
    if (line1>1)
    {
      ch=filereadchar(from,pos1);
      if (ch=='\n' || ch=='\r')
        ++pos1;
    }
    fcopyfilepart(from,pos1,pos-1,fp,200);
    if (sign!=NULL)
      fprintf(fp,"%s",sign);
    fcopyfilepart(from,pos,pos2-1,fp,200);
    ch=filereadchar(from,pos2-1);
    if (!(ch=='\n' || ch=='\r'))
      fprintf(fp,"\n");
  }
}
return line;
}

int printfewfilelines(FILE *from,long pos,int pre,int post,char *sign)
    /* Na stand. izhod se zapise pre vrstic iz datoteke from pred pozicijo pos0
    in post vrsticiz te datoteke za pozicijo pos0, vkljucno z vrstico, ki
    vsebuje pozicijo pos0. Funkcija vrne zaporedno stevilko vrstice v datoteki
    from, ki vsebuje pozicijo pos0. Tik pred zapisom te vrstice se na 
    standardni izhod izpise niz sign.
    $A Igor apr98; */
{
return fprintfewfilelines(stdout,from,pos,pre,post,sign);
}


















































































































/*
#include "fsback.h"
*/


