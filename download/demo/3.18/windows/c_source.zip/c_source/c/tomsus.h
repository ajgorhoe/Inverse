#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>



#include <mtypes.h>
#include <st.h>
#include <rf.h>
#include <rand.h>
#include <strop.h>
#include <mtime.h>





main()
{
 
/*
matrix A=NULL,A1=NULL,A2=NULL,B=NULL,B1=NULL,B2=NULL,B3=NULL,C=NULL;
matrix V=NULL,Q=NULL,X=NULL,L=NULL,U=NULL;
vector x=NULL,y=NULL,u=NULL,v=NULL,b=NULL,b1=NULL,b2=NULL,b3=NULL;

*/

int i,j,k,lm,m=5,n=10000,ex=20,al=0;
double d,e,t1,t2,t3;
indtab it=NULL,it1=NULL;
stack st=NULL;

int *ptrs=NULL,*cumptrs=NULL,*indxs=NULL;
double *diag=NULL,*coefs=NULL;

timeinitrand();
it=newindtab(1,m);
it1=newindtab(1,m);

randindtabun(it,it1,1,3*m,m,0);



printf("\n"); printindtablinesimp(it1); printindtablinesimp(it); printf("\n");



printf("n=%i, m=%i\n",n,m);
printf("Priprava indeksne tabele:\n");
t1=cputime();
prepspmatindtab(&st,n,ex,al);
t2=cputime();
printf("CPU time: %g (t1=%g, t2=%g).\n",t2-t1,t1,t2);
printf("\nPress <Return>!\n"); readdouble(&e);

/*
printspmatindtab(st);
*/

printf("\nPolnjenje tabele\n\n");
t1=cputime();
for (i=1;i<=n;++i)
  for (j=1;j<=m;++j)
    /*
    d=(double)it->t[j];
    */
    setspmatindtabel(st,i,it->t[j]);
printf("\n\n");
t2=cputime();
printf("CPU time: %g (t1=%g, t2=%g).\n\n",t2-t1,t1,t2);

sortspmatindtab(st);

t3=cputime();

printf("CPU time: %g (sorting %g).\n",t3-t1,t3-t2);

printf("\nPress <Return>!\n"); readdouble(&e);


printf("Transferring data to NASA format...\n");
t1=cputime();
spmatindtabtoNASA(st,&i,&j,&ptrs,&cumptrs,&indxs,&coefs,&diag);
t2=cputime();
printf("Number of equations: %i, number of elements: %i\n",i,j);
printf("CPU time: %g (t1=%g, t2=%g).\n\n",t2-t1,t1,t2);
printf("\nPress <Return>!\n"); readdouble(&e);


printspmatindtab(st);




exit(1);


it=newindtab(2,0);

printf("Po kreaciji:\n");
printindtabline(it);

pushindtab(it,5);
pushindtab(it,10);
pushindtab(it,3);

printf("Po push:\n");
printindtabline(it);

i=popindtab(it);
printf("Zadnji indeks: %i\n",i);
printf("Po pop:\n");
printindtabline(it);

insindtab(it,11,2);
insindtab(it,2,2);
insindtab(it,25,4);
printf("Po ins:\n");
printindtabline(it);


qsortindtab(it);


printf("Po sortiranju:\n");
printindtabline(it);

printf("Iskanje indeksov:\n");
i=2;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=25;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=10;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=11;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=5;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=3;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=1;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);
i=33;
j=findsortindtab(it,i,0,0);
printf("Indeks %2i: mesto %i.\n",i,j);

printf("\nVrivanje indeksov na enolicen nacin:\n");
i=2;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=1;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=33;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=33;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=11;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=9;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=8;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

printf("\nVrivanje indeksov na neenolicen nacin:\n");
i=2;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

printf("Vrivanje indeksov na enolicen nacin:\n");
i=1;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=33;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=33;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=11;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=9;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=8;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=55;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=45;
j=inssortindtabun(it,i,0,0);
printf("Indeks %2i vrinjen na mesto %i.\n",i,j);
printindtablinesimp(it);

i=delindtab(it,3);
printf("\nTretji indeks je bil: %i\n",i);
printf("Po brisanju:\n");
printindtabline(it);

exit(1);


}






































































