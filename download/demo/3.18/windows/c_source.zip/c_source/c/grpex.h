#include <stdlib.h>                      	/* standard library routines */
#include <stdio.h>                      	/* standard I/O definitions */
#include <math.h>                       	/* link with library "-lm" */

#include <X11/Xlib.h>                   	/* X windows library */
#include <X11/Xutil.h>                  	/* X windows utilities */
#include <X11/Xatom.h>                  	/* X windows atoms */

#include <X11/PEX5/PEXlib.h>            	/* PEX library definitions */
#include <X11/PEX5/PEXHPlib.h>          	/* PEX library definitions */


#include <mtypes.h>
#include <st.h>
#include <strop.h>
#include <titles.h>


#define MAXX 1280  /* resolucija zaslona v smeri x */
#define MAXY 1024  /* resolucija zaslona v smeri y */




static Display *display,*display1;
static Window *window,window1;
static PEXRenderer *renderer;

static stack windows=NULL;
static stack renderers=NULL;
static int   activewindow=0;
static int iwindowxpos=0,iwindowypos=0,iwindowheight=200,iwindowwidth=200;
static float windowxpos=0.0,windowypos=0.0,windowheight=0.4,windowwidth=0.4;
static char *windowtitle="";

static PEXCoord points[] = {{0.0, 0.0, 0.0}, {0.0, 0.0, 0.0}, {0.0, 0.0, 0.0}, {0.0, 0.0, 0.0}};
static PEXCoord2D points2d[]={{0.0, 0.0}, {0.0, 0.0}, {0.0, 0.0}, {0.0, 0.0}};


static PEXColor linecolor,fillcolor,textcolor;

static double linewidth;
static int linetype;

static int curvepoints=16;
static float pointsize;

static int textfont;
static float textheight;
static float textspacing;
static float textexpansion;
static int textxalignment;
static int textyalignment;
static float textprecision;

static PEXReflectionAttributes refl_attrs;
static PEXListOfCoord fill_areas;


static char                	Error[80];
static PEXExtensionInfo            *ExtensionInfo;
static PEXColorApproxEntry  	capx;
static PEXRendererAttributes	rnd_attrs;
static unsigned long 		mask = 0;





#include "grpexdef.h"                  	/* utilities for this program */





void gisetwindowtitle(char *title)
     /* Naslov oken, ki se na novo odpirajo, postavi na title. */
{
windowtitle=title;
/*
if (windowtitle!=NULL)
  if (cmpstrings(windowtitle,"")!=0)
  {
    free(windowtitle);
    windowtitle="";
  }
if (title!=NULL)
  if (cmpstrings(title,"")!=0)
    windowtitle=stringcopy(title);
*/
}

char *gigetwindowtitle(void)
{
return windowtitle;
}



float gisetwindowxpos(float z)
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri x na z. Vrne prej.
    pozicijo. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */
{
float ret;
ret=windowxpos;
if (z>=0 && z<=1)
{
  windowxpos=z;
  iwindowxpos=(int) (z*MAXX);
}
return ret;
}

float gigetwindowxpos(void)
{
return windowxpos;
}


float gisetwindowypos(float z)
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri y na z. Vrne prej.
    pozicijo. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */
{
float ret;
ret=windowypos;
if (z>=0 && z<=1)
{
  windowypos=z;
  iwindowypos=(int) (z*MAXY);
}
return ret;
}

float gigetwindowypos(void)
{
return windowypos;
}


float gisetwindowwidth(float z)
    /* Postavi zaceto sirino oken pri odpiranju v smeri na z. Vrne prej.
    sirino. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */
{
float ret;
ret=windowwidth;
if (z>=0 && z<=1)
{
  windowwidth=z;
  iwindowwidth=(int) (z*MAXX);
}
return ret;
}

float gigetwindowwidth(void)
{
return windowwidth;
}


float gisetwindowheight(float z)
    /* Postavi zaceto visino oken pri odpiranju v smeri na z. Vrne prej.
    visino. Mozni obseg z je od 0 do 1.
    $A Igor maj97; */
{
float ret;
ret=windowheight;
if (z>=0 && z<=1)
{
  windowheight=z;
  iwindowheight=(int) (z*MAXY);
}
return ret;
}

float gigetwindowheight(void)
{
return windowheight;
}



int ginsetwindowxpos(int z)
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri x na z. Vrne prej.
    pozicijo.
    $A Igor maj97; */
{
int ret;
ret=iwindowxpos;
windowxpos=(float) z/MAXX;
iwindowxpos=z;
return ret;
}

int gingetwindowxpos(void)
    /* $A Igor maj97; */
{
return iwindowxpos;
}


int ginsetwindowypos(int z)
    /* Postavi zaceto pozicijo oken pri odpiranju v smeri y na z. Vrne prej.
    pozicijo.
    $A Igor maj97; */
{
int ret;
ret=iwindowypos;
windowypos=(float) z/MAXY;
iwindowypos=z;
return ret;
}

int gingetwindowypos(void)
    /* $A Igor maj97; */
{
return iwindowypos;
}


int ginsetwindowwidth(int z)
    /* Postavi zaceto sirino oken pri odpiranju v smeri na z. Vrne prej.
    sirino.
    $A Igor maj97; */
{
int ret;
ret=iwindowwidth;
windowwidth=(float) z/MAXX;
iwindowwidth=z;
return ret;
}

int gingetwindowwidth(void)
    /* $A Igor maj97; */
{
return iwindowwidth;
}


int ginsetwindowheight(int z)
    /* Postavi zaceto visino oken pri odpiranju v smeri na z. Vrne prej.
    visino.
    $A Igor maj97; */
{
int ret;
ret=iwindowheight;
windowheight=(float) z/MAXY;
iwindowheight=z;
return ret;
}

int gingetwindowheight(void)
    /* $A Igor maj97; */
{
return iwindowheight;
}




float gisetpointsize(float size)
      /* Nastavi velikost tock. Vrne trenutno velokost. */
{
float ret=pointsize;
if (size>0)
  pointsize=size;
else
  pointsize=0.0001;
return ret;
}

float gigetpointsize(void)
{
return pointsize;
}


int gisetcurvepoints(int num)
    /* Nastavi stevilo vmesnih tock pri risanju krivuljnih objektov, npr.
    kroznic. Vrne trenutno stevilo tock. */
{
int ret=curvepoints;
if (num>0)
  curvepoints=num;
else
  curvepoints=15;
return ret;
}

int gigetcurvepoints()
{
return curvepoints;
}



static float testcolor(float color)
       /* Ce barvna komponenta ni v dovoljenem obsegu, jo postavi v dovoljen
       obseg in jo vrne, drugace vrne nespremenjno komponento. To funkcijo
       uporabljajo funkcije za nastavitev barv. */
{
/*
if ( !(color>=0 && color<=1) )
{
  printf("TESTCOLOR error;\n");
  color=0;
  if (color<0)
    color=0;
  else if (color>1)
    color=1;
}
*/
if (color<0.0)
  return 0.0;
else if (color>1.0)
  return 1.0;
else
  return color;
}


void gisetlinecolor(float red,float green,float blue)
     /* Nastavi barvo za risanje crt. */
{
linecolor.rgb.red=testcolor(red);  linecolor.rgb.green=testcolor(green);
linecolor.rgb.blue=testcolor(blue);
PEXSetLineColor(display,*renderer,PEXOCRender,PEXColorTypeRGB,&linecolor);
}

void gigetlinecolor(float *red,float *green,float *blue)
{
*red=linecolor.rgb.red; *green=linecolor.rgb.green; *blue=linecolor.rgb.blue;
}


void gisetfillcolor(float red,float green,float blue)
     /* Nastavi barvo za risanje zapolnjenih likov */
{
fillcolor.rgb.red=testcolor(red);  fillcolor.rgb.green=testcolor(green);
fillcolor.rgb.blue=testcolor(blue);
PEXSetInteriorStyle(display, *renderer, PEXOCRender, PEXInteriorStyleSolid);
PEXSetSurfaceColor(display,*renderer,PEXOCRender,PEXColorTypeRGB,&fillcolor);
}

void gigetfillcolor(float *red,float *green,float *blue)
{
*red=fillcolor.rgb.red; *green=fillcolor.rgb.green; *blue=fillcolor.rgb.blue;
}


void gisetlinewidth(double width)
     /* Nastavi sirino crt pri risanju (velja tudi za nezapolnjene like) */
{
linewidth=width;
PEXSetLineWidth(display,*renderer,PEXOCRender,linewidth);
}

double gigetlinewidth(void)
{
return linewidth;
}



void gisetlinetype(int type)
     /* Nastavi tip crt */
{
linetype=type;
PEXSetLineType(display,*renderer,PEXOCRender,linetype);
}

int gigetlinetype(void)
{
return linetype;
}



void gisettextcolor(float red,float green,float blue)
     /* Nastavi barvo teksta. */
{
textcolor.rgb.red=testcolor(red);  textcolor.rgb.green=testcolor(green);
textcolor.rgb.blue=testcolor(blue);
PEXSetTextColor(display,*renderer,PEXOCRender,PEXColorTypeRGB,&textcolor);
}

void gigettextcolor(float *red,float *green,float *blue)
{
*red=textcolor.rgb.red; *green=textcolor.rgb.green; *blue=textcolor.rgb.blue;
}


void gisettextprecision(float precision)
     /* Ta funkcija ni izdelana do konca! */
{
textprecision=0;
PEXSetTextPrecision(display,*renderer,PEXOCRender,PEXStrokePrecision);
}

float gigettextprecision()
{
return textprecision;
}


void gisettextfont(int font)
     /* Nastavi pisavo, ki se uporablja pri tekstu. */
{
textfont=font;
if (textfont<1)
  textfont=1;
PEXSetTextFontIndex(display,*renderer,PEXOCRender,textfont);
}

int gigettextfont(void)
{
return textfont;
}



void gisettextheight(float height)
     /* Nastavi velikost (visino) teksta. */
{
textheight=height;
if (textheight<=0.0)
  textheight=0.01;
PEXSetCharHeight(display,*renderer,PEXOCRender, textheight);
}

float gigettextheight(void)
{
return textheight;
}


void gisettextspacing(float spacing)
     /* Nastavi velikost presledkov med crkami pri tekstu. */
{
textspacing=spacing;
if (textspacing<0.0)
  textspacing=0.0;
PEXSetCharSpacing(display,*renderer,PEXOCRender,textspacing);
}

float gigettextspacing(void)
{
return textspacing;
}


void gisettextexpansion(float expansion)
     /* Nastavi razsiritev teksta v vodoravni smeri. */
{
textexpansion=expansion;
if (textexpansion<=0.0)
  textexpansion=1.0;
PEXSetCharExpansion(display,*renderer,PEXOCRender,textexpansion);
}

float gigettextexpansion(void)
{
return textexpansion;
}


void gisettextxalignment(int alignment)
     /* Nastavi poravnavanje teksta v vodoravni smeri. Ce je alignment -1, je
     poravnavanje levo, ce je 0, je centrirano, ce pa je 1, je desno. */
{
if (alignment==-1)
  textxalignment=PEXHAlignLeft;
else if (alignment==1)
  textxalignment=PEXHAlignRight;
else
  textxalignment=PEXHAlignCenter;
PEXSetTextAlignment(display,*renderer,PEXOCRender,
 textxalignment,textyalignment);
}

int gigettextxalignment(void)
{
return textxalignment;
}


void gisettextyalignment(int alignment)
     /* Nastavi poravnavanje teksta v navpicni smeri. Ce je -1, je poravnavanje
     spodnje, ce je 0, je centrirano, ce pa je 1, je zgornje. */
{
if (alignment==-1)
  textyalignment=PEXVAlignBottom;
else if (alignment==1)
  textyalignment=PEXVAlignTop;
else
  textyalignment=PEXVAlignHalf;
PEXSetTextAlignment(display,*renderer,PEXOCRender,
 textxalignment,textyalignment);
}

int gigettextyalignment(void)
{
return textyalignment;
}


void gisettextalignment(int xalignment,int yalignment)
     /* Hkrati nastavi poravnavanje teksta v obeh smereh, pri cemer uporablja
     funkciji gisettextxalignment in settextyalignment. */
{
gisettextxalignment(xalignment);
gisettextyalignment(yalignment);
}

void gigettextalignment(int *xalignment,int *yalignment)
{
*xalignment=textxalignment;  *yalignment=textyalignment;
}






int giinitdisplay(void)
    /* Odpre display. */
{
titleigs(10);
/* Open the X connection and initialize PEX on it. */
if ((display = XOpenDisplay(NULL)) == NULL)
{
  fprintf(stderr, "Cannot connect to display %s\n", XDisplayName(NULL));
  exit(-1);
}
if (PEXInitialize(display, &ExtensionInfo, 80, Error))
{
  fprintf(stderr, "No PEX extension on %s:\n", XDisplayName(NULL));
  fprintf(stderr, "  %s\n", Error);
  XCloseDisplay(display);
  exit(-2);
}
return 0;
}




int giinitgraph(void)
    /* Zacetne nastavitve za grafiko. To funkcijo se lahko pozene le enkrat ne
    glede na stevilo oken, ki so odprta (nastavitve veljajo za vsa okna). */
{

gisetwindowtitle("Graph. window (initialized)");
gisetwindowxpos(0.);
gisetwindowypos(0.);
gisetwindowwidth(0.3);
gisetwindowheight(0.3);

gisetlinecolor(0.8,0.2,0.2);
gisetfillcolor(0.2,0.8,0.2);
gisetlinewidth(1);
gisetlinetype(1);

gisettextcolor(0.8,0.5,0.8);
gisettextprecision(1.0);
gisettextfont(1);
gisettextheight(0.05);
gisettextspacing(0.2);
gisettextexpansion(1.0);
gisettextxalignment(0);
gisettextyalignment(0);

curvepoints=20;
pointsize=0.001;

}


int giopenwindow(void)
    /* Odpre novo okno. Vrne identifikacijsko stevilko tega okna, s to stevilko
    se nato sklicujemo na to okno v programu. Okno, ki ga odpre, postane
    aktivno. */
{
/* Create a window for PEX rendering. */
window=malloc(sizeof (*window)); /* Aktivno okno postane okno, ki ga odpiramo */
renderer=malloc(sizeof (*renderer)); /* Aktivno okno postane okno, ki ga odpiramo */
MakePEXWindow(display, True, window, &capx);
if (windows==NULL)
  windows=newstack(5);
if (renderers==NULL)
  renderers=newstack(5);
pushstack(windows,(void *) window);
pushstack(renderers,(void *) renderer);
activewindow=windows->n;
/* Create the Renderer and associated tables. */
CreatePEXResources(display, *window, &capx, renderer, &rnd_attrs);
PEXBeginRendering(display, *window, *renderer);
return (windows->n); /* Vrne zapored. st. okna */
}


int gisetwindow(int num)
    /* Okno z zaporedno stevilko num naredi za aktivno. */
{
if (windows!=NULL && renderers!=NULL)
  if (num>0 && num<=windows->n && num<=renderers->n)
  {
    window=windows->s[num];
    renderer=renderers->s[num];
    activewindow=num;
  }
}

void giresetwindow(void)
     /* Resetiranje aktivnega okna. Vsebina okna se zbrise. */
{
/* Create the Renderer and associated tables. */
CreatePEXResources(display, *window, &capx, renderer, &rnd_attrs);
PEXBeginRendering(display, *window, *renderer);
}

void giclosewindow(void)
     /* Zapre aktivno okno. */
{
XFlush(display);
PEXEndRendering(display, *renderer, True);
}

void giclearwindow(void)
     /* Zbrise vsebino aktivnega okna. */
{
XClearWindow(display,*window);
}

void giflushdisplay(void)
     /* Povzroci izris vsega, kar se se ni izrisalo. */
{
XFlush(display);
}



void giline(float x1,float y1,float x2,float y2)
     /* Narise crto med tockama (x1,y1) in (x2,y2). */
{
points2d[0].x=x1;  points2d[0].y=y1;  points2d[1].x=x2;  points2d[1].y=y2;
PEXPolyline2D(display,*renderer,PEXOCRender,2,points2d);
}

void gitriangle(float x1,float y1,float x2,float y2,float x3,float y3)
     /* Narise trikonik iz crt z oglisci (x1,y1), (x2,y2) in (x3,y3). */
{
giline(x1,y1,x2,y2); giline(x2,y2,x3,y3); giline(x3,y3,x1,y1);
}


void gifourangle(float x1,float y1,float x2,float y2,float x3,float y3,
               float x4,float y4)
     /* Narise stirikotnik iz crt z oglisci (x1,y1), (x2,y2), (x3,y3) in
     (x4,y4). */
{
giline(x1,y1,x2,y2); giline(x2,y2,x3,y3); giline(x3,y3,x4,y4); giline(x4,y4,x1,y1);
}


void girectangle(float x1,float y1,float x2,float y2)
     /* Narise pravokotnik iz crt z nasprotileznima ogliscema (x1,y1) in
     (x2,y2). */
{
gifourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}


void gicircle(float x,float y,float r)
     /* Narise krog iz curvepoints crt s srediscem (x,y) in radijem r. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) curvepoints);
x1=x+r;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  giline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gicirclearc(float x,float y,float r,float fi1,float fi2)
     /* Narise krozni lok iz curvepoints crt s srediscem (x,y), radijem r ter
     z zacetnim kotom fi1 in s koncnim kotom fi2. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) curvepoints);
x1=x+r*cos(fi);
y1=y+r*sin(fi);
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  giline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void giellipse(float x,float y,float a,float b)
     /* Narise elipso iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) curvepoints);
x1=x+a;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  giline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void giellipsearc(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise elipsin lok iz curvepoints crt s srediscem (x,y), s polosjo a v
     vodoravni smeri in polosjo b v navpicni smeri ter z zacetnim kotom fi1 in
     s koncnim kotom fi2. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) curvepoints);
x1=x+a*cos(fi);
y1=y+b*sin(fi);
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  giline(x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gifilltriangle(float x1,float y1,float x2,float y2,float x3,float y3)
     /* Narise pobarvan trikotnik z oglisci (x1,y1), (x2,y2) in (x3,y3). */
{
PEXListOfCoord2D fill_areas;
points2d[0].x=x1;  points2d[0].y=y1;  points2d[1].x=x2;  points2d[1].y=y2;
points2d[2].x=x3;  points2d[2].y=y3;
fill_areas.count=3;
fill_areas.points =points2d;
PEXFillAreaSet2D(display, *renderer, PEXOCRender,PEXShapeUnknown,False,
 PEXContourUnknown,1,&fill_areas);
}


void gifillfourangle(float x1,float y1,float x2,float y2,float x3,float y3,
                   float x4,float y4)
     /* Narise pobarvan stirikotnik z oglisci (x1,y1), (x2,y2), (x3,y3) in
     (x4,y4). */
{
PEXListOfCoord2D fill_areas;
points2d[0].x=x1;  points2d[0].y=y1;  points2d[1].x=x2;  points2d[1].y=y2;
points2d[2].x=x3;  points2d[2].y=y3;  points2d[3].x=x4;  points2d[3].y=y4;
/*
PEXSetInteriorStyle(display, *renderer, PEXOCRender, PEXInteriorStyleSolid);
PEXSetSurfaceColor(display,*renderer,PEXOCRender,PEXColorTypeRGB,&fillcolor);
*/
fill_areas.count=4;
fill_areas.points=points2d;
PEXFillAreaSet2D(display, *renderer, PEXOCRender,PEXShapeUnknown,False,
 PEXContourUnknown,1,&fill_areas);
}

void gifillrectangle(float x1,float y1,float x2,float y2)
     /* Narise zapolnjen pravokotnik s protileznima ogliscema (x1,y1) in
     (x2,y2). */
{
gifillfourangle(x1,y1,x2,y1,x2,y2,x1,y2);
}

void gipoint(float x,float y)
     /* Narise tocko s koordinatami (x,y). Za barvo se uporalbja barva za
     polnjenje likov. */
{
gifillrectangle(x-pointsize,y-pointsize,x+pointsize,y+pointsize);
}




void gifillcircle(float x,float y,float r)
     /* Narise zapolnjen krog s srediscem v (x,y) in polmerom r iz curvepoints
     zapolnjenih trikotnikov. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double)  curvepoints);
x1=x+r;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  gifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gifillcirclearc(float x,float y,float r,float fi1,float fi2)
     /* Narise zapolnjen krozni lok s srediscem (x,y), polmerom r ter zacetnim
     kotom fi1 in koncnim kotom fi2 zi curvepoints zapolnjenih trikotnikov. Koti
     so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) curvepoints);
x1=x+r*cos(fi);
y1=y+r*sin(fi);
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+r*cos(fi);
  y2=y+r*sin(fi);
  gifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gifillellipse(float x,float y,float a,float b)
     /* Narise zapolnjeno elipso s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b iz curvepoints zapolnjenih trikornikov. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=0;
hfi=4*asin(1)/((double) curvepoints);
x1=x+a;
y1=y;
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  gifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}


void gifillellipsearc(float x,float y,float a,float b,float fi1,float fi2)
     /* Narise zapolnjen elipsin lok s srediscem (x,y), vodoravno polosjo a in
     navpicno polosjo b ter zacetnim kotom fi1 in koncnim fi2 iz curvepoints
     zapolnjenih trikornikov. Koti so v radianih. */
{
double x1,y1,x2,y2,fi,hfi;
int i;
fi=fi1;
hfi=(fi2-fi1)/((double) i);
x1=x+a*cos(fi);
y1=y+b*sin(fi);
for (i=1;i<=curvepoints;++i)
{
  fi+=hfi;
  x2=x+a*cos(fi);
  y2=y+b*sin(fi);
  gifilltriangle(x,y,x1,y1,x2,y2);
  x1=x2; y1=y2;
}
}



void gitext(char *str,float x,float y)
     /* Izpise niz str pri koordinatah (x,u). */
{
points2d[0].x=x;  points2d[0].y=y; /* pozicija */
PEXText2D( display,*renderer,PEXOCRender,points2d,strlen(str),str);
}



void gidrawloop(void (*redraw)(void))
     /* Zanka okrog funkcije redraw, ki naj bi bila taksna funkcija, ki nekaj
     narise v aktivno okno. Funkcija na novo izrise aktivno okno vsakic, ko je
     potrebno zaradi odkrivanja okna ali cesa drugega. Ko kliknemo z misko v
     okno, se le-to zapre. */
{
    int                 Done = False;   /* done getting X events? */
    XEvent              Event;          /* what did user do? */

    /*--- draw the image the first time, then loop -------------------------*/
    /* Redraw(display, window, *renderer, rndrrattrs); */

    XSelectInput(display, *window, ExposureMask | ButtonPressMask);
    while (!Done) {
        XNextEvent(display, &Event);
        switch (Event.type) {
            case Expose:
                while (XCheckTypedWindowEvent(display, *window, Expose,
                  &Event))
                    ;
                /* Redraw(display, window, *renderer, rndrrattrs); */
                redraw();
                break;
            case ButtonPress:
                Done = True;
                break;
        }
    }
} /* MainXLoop */




int gibuttonpressed(void)
    /* Vrne st. gumba miske, ki je bil pritisnjen v aktivnem oknu. Ce ni bil
    pritisnjen noben gumb, vrne 0. Funkcija caka, dokler ni dejansko pritisnjen
    kak gumb ali se aktivno okno izpostavi. */
{
XEvent event;
unsigned char mask;
unsigned char cmask;
cmask=255;
memset(&mask,cmask,sizeof(mask));
XSelectInput(display,*window, ExposureMask | ButtonPressMask | PointerMotionMask);
/*
XSelectInput(display,*window,1+2+4+8+16+32+64+128+256+1024+2048+4096+8192
+16384);
*/
/*
XSelectInput(display,*window,mask);
*/
XNextEvent(display,&event);
if (event.type==ButtonPress)
{
  if (event.xbutton.button==Button1)
    return 1;
  else if (event.xbutton.button==Button2)
    return 2;
  else if (event.xbutton.button==Button3)
    return 3;
  else
    return 0;
} else if (event.type==Expose)
  return 0;
else return -1;
}

