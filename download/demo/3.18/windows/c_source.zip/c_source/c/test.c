#include <math.h>
#include <float.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <memory.h>

#include <mtypes.h>
#include <er.h>
#include <rf.h>
#include <st.h>
#include <vec.h>
#include <mat.h>
#include <strop.h>
#include <numut.h>
#include <simb.h>





         /**********************************************/
         /*                                            */
         /*     TESTNE IN DEMONSTRACIJSKE FUNKCIJE     */
         /*                                            */
         /**********************************************/





   /**********************************************/
   /*                                            */
   /*    DEFINICIJA FUNKCIJ PREKO KALKULATORJA   */
   /*                                            */
   /**********************************************/



static char *sss="sin(x)*cos(x)*exp(1/(1+x*x))*(23.3-3*sin(x))" ;

static double fff(double x)
    /* Testna funkcija, ki ustreza funkciji definirani z nizom sss */
{
return sin(x)*cos(x)*exp(1/(1+x*x))*(23.3-3*sin(x));
}

void democalcdeffunc(void)
    /* Demonstrira uporabo funkcij, ki jih uporabnik definira preko
    globalnega kalkulatorja.
    $A Igor maj01; */
{
stack st=NULL;
int j,m=2,n=2;
void *ptr;
double x,y;
vector vx,vp;
char *str;
initglobcalc();
printf("\nTest: definition of function of two variables:\n\n");
printf("\nDefine the function f[x,y]!\n");
ptr=defglobcalcfunc2dint();
printf("\nYou can now add definitions in the calculator system; Insert \\q for exit!\n");
globcalcint();
printf("\nInsert values of variables! The loop will exit when the variable is 0.\n\n");
x=1;
while(x!=0)
{
  printf("x: "); readdouble(&x);
  printf("y: "); readdouble(&y);
  printf("f[x,y] = %g\n\n",   globcalcfunc2d(ptr,x,y)  );
}
printf("\nTest: definition of Parametric function of vector variable:\n\n");
printf("Number of variables: "); readint(&m);
vx=getvector(m);
printf("Number of parameters: "); readint(&n);
vp=getvector(n);
printf("\nDefine the function f[x1,x2,...,p1,p2,...]!\n");
ptr=defglobcalcfuncvecparint(m,n);
printf("\nYou can now add definitions in the calculator system; Insert \\q for exit!\n");
globcalcint();
printf("\nInsert values of variables and parameters! \nThe loop will exit when the first variable is 0.\n\n");
x=1;
while(x!=0)
{
  for (j=1;j<=vx->d;++j)
  {
    printf("x%i: ",j); readdouble(&(vx->v[j]));
  }
  for (j=1;j<=vp->d;++j)
  {
    printf("p%i: ",j); readdouble(&(vp->v[j]));
  }
  x=vx->v[1];
  printf("f[x1,x2,...,p1,p2,...] = %g\n\n",   globcalcfuncvecpar(ptr,vx,vp)  );
}
printf("\nTest: definition of function of several variable:\n\n");
printf("Number of variables: "); readint(&m);
vx=getvector(m);
printf("Choose variable names!\n");
st=newstack(1);
for (j=1;j<=m;++j)
{
  str=NULL;
  printf("Name of the %i. variable: ",j);
  readstring(&str);
  pushstack(st,str);
}
printf("\nDefine the function f[...]!\n");
ptr=defglobcalcfuncvecsymbint(st);
printf("\nYou can now add definitions in the calculator system; Insert \\q for exit!\n");
globcalcint();
printf("\nInsert values of variables! The loop will exit when the first variable is 0.\n\n");
x=1;
while(x!=0)
{
  for (j=1;j<=vx->d;++j)
  {
    printf("%s: ",(char *)st->s[j]); readdouble(&(vx->v[j]));
  }
  x=vx->v[1];
  printf("f[...] = %g\n\n",   globcalcfuncvecsymb(ptr,vx)  );
}
/*
n=1000000;
*/
n=100000;
x=3.33;
printf("\n\nTesting speed....\n\n");
printf("%i evaluations of coded function:...\n",n);
for (j=1;j<=n;++j)
  y=fff(x);
printf("STOP.\n\n\n");
ptr=defglobcalcfunc1d(sss);
printf("%i evaluations of coded function:...\n",n);
for (j=1;j<=n;++j)
  y=globcalcfunc1d(ptr,x);
printf("STOP.\n\n\n");
}







   /***********************************************/
   /*                                             */
   /*   SISTEM ZA DEFINICIJO TESTNIH FUNKCIJ      */
   /*           ENE SPREM. Z ODVODI               */
   /*                                             */
   /***********************************************/




static char *strfunc1d1="(sin(x^2))^2";

static void func1dder1(double x,double *f,double *d)
    /* Funkcija in odvod (sin(x^2))^2 */
{
*f=m_sqr(sin(m_sqr(x)));
*d=4*x*cos(m_sqr(x))*sin(m_sqr(x));
}

static char *strfunc1d2="(sin(x^2))^2/x";

static void func1dder2(double x,double *f,double *d)
    /* Funkcija in odvod (sin(x^2))^2/x */
{
*f=m_sqr(sin(m_sqr(x)))/x;
*d=4*cos(m_sqr(x))*sin(m_sqr(x))-m_sqr(sin(m_sqr(x)))/m_sqr(x);
}


static char *strfunc1d3="(sin(x^2))^2/x^2";

static void func1dder3(double x,double *f,double *d)
    /* Funkcija in odvod (sin(x^2))^2/x^2 */
{
*f=m_sqr(sin(m_sqr(x)))/m_sqr(x);
*d=4*cos(m_sqr(x))*sin(m_sqr(x))/x-2*m_sqr(sin(m_sqr(x)))/m_cube(x);
}

static char *strfunc1d4="-0.1*x^2+x^6";

static void func1dder4(double x,double *f,double *d)
    /* Funkcija in odvod -0.1*x^2+x^6 */
{
*f=-0.1*m_sqr(x)+m_sqr(m_cube(x));
*d=-0.2*x+6*m_sqr(x)*m_cube(x);
}

static char *strfunc1d5="-0.1*x^2-0.4*x^3+x^4";

static void func1dder5(double x,double *f,double *d)
    /* Funkcija in odvod -0.1*x^2-0.4*x^3+x^4 */
{
*f=-0.1*m_sqr(x)-0.4*m_cube(x)+m_sqr(m_sqr(x));
*d=-0.2*x-1.2*m_sqr(x)+4*m_cube(x);
}


/* Testna funkcija ene spremenljivke z odvodom: */
static void (*vartestfunc1dder) (double,double *,double *)=func1dder1;

void testfunc1dder(double x,double *f,double *d)
    /* Testna funkcija ene spremenljivke; x je argument funkcije, v f se
    zapise vrednost funkcije pri x, v d pa vrednost odvoda.
    %A Igor maj01; */
{
if (vartestfunc1dder!=NULL)
{
  vartestfunc1dder(x,f,d);
} else
  *f=*d=0;
}

double testfunc1d(double x)
    /* Testna funkcija ene spremenljivke; x je argument funkcije, vrne se njena
    vrednost.
    %A Igor maj01; */
{
double f,d;
if (vartestfunc1dder!=NULL)
  vartestfunc1dder(x,&f,&d);
else
  f=0;
return f;
}

double testder1d(double x)
    /* Odvod testne funkcije ene spremenljivke; x je argument funkcije, vrne se
    njenodvod.
    %A Igor maj01; */
{
double f,d;
if (vartestfunc1dder!=NULL)
  vartestfunc1dder(x,&f,&d);
else
  d=0;
return d;
}


static double testfunc1dhder=1e-3;

double testnumder1d(double x)
    /* Numericni odvod testne funkcije ene spremenljivke.
    $A Igor maj01; */
{
return (testfunc1d(x+0.5*testfunc1dhder)-testfunc1d(x-0.5*testfunc1dhder))
 /testfunc1dhder;
}


/* Za definicijo funkcije preko kalkulatorja: */

/* Kazalca za dostop definicije funkcije in odvoda : */
static void *ptrfunc1duser=NULL,*ptrder1duser=NULL;

static void func1dderuser(double x,double *f,double *d)
    /* Funkcija ene spremenljivke z odvodom za primer, ko sta funkcija in
    odvod definirana preko kalkulatorja (kazalca ptrfunc1duser in ptrder1duser)
    $A Igor maj01; */
{
*f=globcalcfunc1d(ptrfunc1duser,x);
*d=globcalcfunc1d(ptrder1duser,x);
}


static double func1duser(double x)
{
return globcalcfunc1d(ptrfunc1duser,x);
}

static void func1ddernumuser(double x,double *f,double *d)
    /* Funkcija ene spremenljivke z odvodom za primer, ko je funkcija
    definirana preko kalkulatorja (kazalca ptrfunc1duser in ptrder1duser),
    odvod pa se racuna numericno.
    $A Igor maj01; */
{
*f=func1duser(x);
*d=(func1duser(x+0.5*testfunc1dhder)-func1duser(x-0.5*testfunc1dhder))
 /testfunc1dhder;
}


static stack defstfunc1dder=NULL,strstfunc1dder=NULL;


int adddeffunc1dder(void (*func1dder)(double,double *,double *),char *str)
    /* Doda definicijo nove funkcije, ki vrne funkcijo in odvod funkcije
    ene spremenljivke. func1dder je ta funkcija, str pa njen identifikacijski
    niz, ki jo predstavlja. Ni potrebno, da se da str brisati s free().
    Funkcija vrne zapored. stevilko nove definicije.
    $A Igor maj01; */
{
if (defstfunc1dder==NULL)
{
  defstfunc1dder=newstack(5);
  strstfunc1dder=newstack(5);
}
if (func1dder!=NULL)
{
  pushstack(defstfunc1dder,(void *) func1dder);
  pushstack(strstfunc1dder,stringcopy(str));
  return defstfunc1dder->n;
}
return 0;
}

void initdeffunc1dder(void)
    /* Inicializira sklada defstfunc1dder in strstfunc1dder, ki vsebujeta
    definicije funkcij ene spremenljivke z odvodi. Na sklada da nekaj lastnih
    definicij.
    $A Igor maj01; */
{
if (defstfunc1dder==NULL)
{
  defstfunc1dder=newstack(5);
  strstfunc1dder=newstack(5);
  adddeffunc1dder(func1dder1,strfunc1d1);
  adddeffunc1dder(func1dder2,strfunc1d2);
  adddeffunc1dder(func1dder3,strfunc1d3);
  adddeffunc1dder(func1dder4,strfunc1d4);
  adddeffunc1dder(func1dder5,strfunc1d5);
}
}

void deldeffunc1dder(int i)
   /* Zbrise i - to definicijo funkcije ene spremenljivke s sklada.
    $A Igor maj01; */
{
char *str;
delstack(defstfunc1dder,i);
str=(char *) delstack(strstfunc1dder,i);
disppointer((void **) &str);
}

void delalldeffunc1dder(void)
    /* Zbrise vse definicije funkcij ene spremenljivke s sklada.
    $A Igor maj01; */
{
if (defstfunc1dder==NULL)
{
  defstfunc1dder->n=0;
  dispstackval(strstfunc1dder);
}
}

void *choosfunc1dderint(void)
    /* Interaktivna izbira funkcijo ene spremenljivke z definiranim odvodom.
    Vrne funkcijo tipa void(double,void *,void *) in nastavi ustrezne funkcije
    tako, da ustrezajo tej funkciji.
    $A Igor maj01; */
{
int i,choice;
initdeffunc1dder();
printf("\nChoose a function of one variable!\n\n");
printf("Possible choices:\n");
printf("  0: Your own definition\n");
for (i=1;i<=strstfunc1dder->n;++i)
  printf("  %i: %s\n",i,(char *) strstfunc1dder->s[i]);
printf("  Other: Your own definition\n");
printf("\nYour choice: "); readint(&choice);
if (choice>0 && choice <=defstfunc1dder->n)
{
  printf("\nChosen function: \nf[x]=%s\n\n",strstfunc1dder->s[choice]);
  vartestfunc1dder= (void (*)(double,double *,double *))
   defstfunc1dder->s[choice];
  return defstfunc1dder->s[choice];
} else
{
  printf("\nYou chose to define your own function.\n\nFunction:\n");
  ptrfunc1duser=defglobcalcfunc1dint();
  printf("\nWill you also define the derivative (0/1)? ");
  readint(&choice);
  if (choice)
  {
    printf("\nDerivative:\n");
    ptrder1duser=defglobcalcfunc1dint();
    printf("\n\n");
    vartestfunc1dder=func1dderuser;
    return (void *) func1dderuser;
  } else
  {
    printf("Derivative will be calculated numericlly.\n\n\n");
    vartestfunc1dder=func1ddernumuser;
    return (void *) func1ddernumuser;
  }
}
}

void demotestfunc1d(void)
    /* Funkcija za demonstracijo delovanja sistema za definicijo testne
    funkcije ene spremenljivke - uporabnik izbere funkcijo, izrise se funkcija
    in odvod. */
{
double from=-5,to=5;
int n=100,cont=1;
while (cont)
{
  choosfunc1dderint();
  printf("Data for graph:\n");
  printf("Left limit:       "); readdouble(&from);
  printf("Right limit:      "); readdouble(&to);
  printf("number of points: "); readint(&n);
  fdrawfuncsimp(testfunc1d,NULL,NULL,from,to,n,NULL);
  fdrawfuncsimp(testder1d,testnumder1d,NULL,from,to,n,NULL);
  printf("\n\nChoose another function (0/1)? "); readint(&cont);
}
}

















