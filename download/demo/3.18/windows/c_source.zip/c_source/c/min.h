/*GLAVNI PROGRAM*/

#include <sysint.h>

#include <stdio.h>
#include <math.h>


#include <er.h>

#include <mtypes.h>
#include <min1d.h>





int errordetect[10];
int countan;




int connection(int i)
{
return(i);
}


main()
{
  double x,y,a,b,c,fa,fb,fc; 
  int i,j,it,maxit;
  
  double h;
  x=3.14;
  h=1.0e-2;
  printf("Vrednost funkcije v tocki %5f je %8f\n\n",
  x,funk(x));
  y=odvod(x,&h,funk);
  printf("Odvod funkcije v tocki %5f je %8g\n\n",
  x,y);
  printf("novi h:  %8g\n\n",h);

  printf("OZENJE INTERVALOV:\n");
  a=2; b=2.1; c=2.2;
  countan=0;
  objemimin(&a,&b,&c,funk);
  printf("a:  %8g, b:  %8g, c:  %8g, countan:  %i\n",a,b,c,countan);
  countan=0;
  min1d(&a,&b,&c,1.0e-5,1.0e-7,funk);
  printf("Minimum funkcije:  %8g,  f(min.)= %8g, countan:  %i\n\n",b,funk(b),countan);

  printf("PARABOLICNA INTERPOLACIJA:\n");
  a=2; b=2.1; c=2.2;
  countan=0;
  fa=funk(a); fb=funk(b);  /*fc=funk(c);*/
  brakmin(&a,&b,&c,&fa,&fb,&fc,&it,100,funk,connection,stdout);
  printf("a:  %8g, b:  %8g, c:  %8g, countan:  %i\n",a,b,c,countan);
  countan=0;
  fa=funk(a); fb=funk(b); fc=funk(c);
  brent(&a,&b,&c,&fa,&fb,&fc,1.0e-15,&it,100,funk,connection,stdout);
  printf("Minimum funkcije:  %8g,  f(min.)= %8g, countan:  %i\n\n",b,funk(b),countan);


}


