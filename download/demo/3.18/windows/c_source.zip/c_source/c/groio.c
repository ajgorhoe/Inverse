
#ifdef IGS    /* This belongs to the IGS! */



/*         RUTINE ZA ZAPIS IN BRANJE GRAFICNIH OBJEKTOV IZ DATOTEK          */


#include <sysint.h>

#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <math.h>
#include <mtypes.h>
#include <sg_obj.h>
#include <strop.h>
#include <gro.h>
#include <st.h>
#include <fop.h>



/*
		OPIS MODULA << groio >>


	FORMAT

Graficni objekti se zapisujejo v tekstovnem nacinu. V datoteki so po vrsti
zapisani objekti, ki so najprej najavljeni z nizom, ki je oznaka za objekt
dolocenega tipa, nato pa so v zavitih oklepajih na enak nacin rekurzivno nastete
lastnosti tega objekta (to je vrednosti polj strukture, ki predstavlja objekt
dolocenega tipa) in podobjekti, ki so nalozeni na doticni objekt.

Primer:

    group
    {
      ID{ 1 }
      name{Podskupina}
      limitsset{0}
      transflimitsset{0}
      limits
      {
        { -0.3 -0.3 -0.3 }
        { 0.3 0.3 -0.3 }
      }
      ls1
      {
        lineset
        {
          color{ 1 0.5 0 }
          width{2}
          type{3}
        }
      }
      extraprimitives
      {
        nullprimitive{ }
        primitive
        {
          [l00]
          coords
          {
            { 0.3 -0.3 -0.3 }
            { -0.3 0.3 -0.3 }
          }
        }
        nullprimitive{ }
      }
    }

V zgornjem primeru je zapisana skupina (predstavlja jo niz "group", ki ima iden-
tifikacijsko stevilko ("ID") 1, ime ("name") "Podskupina", itd., postavljene so
meje ("limits"), ki so podobjekti objekta, ki predstavlja skupino, skupina
vsebuje tudi podobjekt ("ls1"), ki vsebuje informacije o nastavitvah pri risanju
crt ("lineset") z lastnostmi barvo ("color"), debelino ("width") in tipom
("type"). Poleg tega skupina vsebuje se tri graficne primitive ("primitive",
"nullprimitive") nalozene na svoj sklad extraprimitives ("extraprimitives"), od
teh sta dva nicelna ("nullprimitive"). Nenicelni primitiv ima v oglatih
oklepajih podano svojo vrsto, poleg tega vsebuje se podobjekte - koordinate.
Presledki ne igrajo vloge, razen tam, kjer so uporabljeni kot locilo (npr. med
posameznimi koordinatami znotraj polj "coords").



	ZAPIS GRAFICNIH SKUPIN V DATOTEKE

  Za zapis skupin graficnih objektov v datoteko skrbi funkcija gofwritegroup().
Ta najprej zapise niz groupstr, ki predstavlja skupine graficnih objektov, in
zaviti oklepaj ('{'), ki najavlja zacetek bloka, ki definira lastnosti skupine
in objekte, ki so naloceni nanjo.
  Za glavo se zapise identifikacijska stevilka (najprej niz identitystr, nato pa
stevilka v zavitih oklepajih).
  Nato se zapise ime skupine, ce je definirano.
  Zapisej se podatek o tem, ali so za skupino izracunane meje v originalnih
koordinatah ali ne. Ce je lokalna spremenljivka writecoord enaka 0, se v vsakem
primeru zapise, da meje v originalnih koordinatah niso definirane. Podobno je s
podatnkom o izracunanih mejah v transformiranih koordinatah, le da ima tu vpliv
lokalna spremenljivka writetransfcoord.
  Ce so definirane meje v prvotnih ali transformiranih koordinatah, se zapisejo.
Pri tem se uporabi funkcija gofwrite1coord(). Koordinate se izpisejo le, ce je
lokalna spremenljivka writecoord razlicna od 0, transformirane koordinate pa le,
ce je lokalna spremenljivka writetransfcoord razlicna od 0. To omogoca, da se
zapisejo le originalne (ce hocemo pozneje graficne objekte npr. gledati pod raz-
licnimi koti) ali le transformirane koordinate (ce nam bo datoteka sluzila le
za poznejsi izris v trenutni perspektivi).
  Ce je spremenljivka writecoord razlicna od 0, se izpiseta spodnja in zgornje
meja v originalnih koordinatah, ce sta definirani. Isto velja za meje v
transformiranih koordinatah, ce je spremenljivka writetransfcoord razlicna od 0.
  Izpisejo se kazalci na nastavitve za risanje crt, zapolnjenih likov in teksta
(ls1, ls2, fs1, fs2, ts1, ts2). Za vsakega od teh kazalcev se, ce je razlicen od
NULL, izpise posebna glava z zavitimi oklepaji. Izpis znotraj zavitih oklepajev
opravi za kazalca ls1 in ls2 funkcija fwritelineset(), za fs1 in fs2 funkcija
fwritefillset() ter za ts1 in ts2 funkcija fwritetextset().
  Ce je sklad primitives skupine razlicen od NULL, se izpise glava za ta sklad
z zavitimi oklepaji. Ce je na tem skladu kaj kazalcev, se izpisejo eden za
drugim znotraj teh zavitih oklepajev. Za izpis ustreznih objektov poskrbi
funkcija gofwriteprimitive(), ki zapise tudi kazalce, ki so enaki NULL, to pa
zato, da se zaporedne stevilke objektov na skladu ohranijo.
  Podobno je z izpisom za sklad extraprimitives.
  Nato se izpise sklad groups. Izpis poteka podobno kot pri skladih primitives
in extraprimitives, le da za izpis objektov na skladu (ce obstajajo) poskrbi
funkcija gofwritegroup(), ki je tako klicana rekurzivno.
  Na koncu se zapise se zaviti oklepaj, ki doloca konec bloka dane skupine.

	Zapis graficnih primitivov:

  Za zapis graficnih primitivov skrbi funkcija gofwriteprimitive(). Princip je
podoben kot pri funkciji gofwritegroup() - po vrsti se izpisujejo lastnosti
primitiva in njegovi podobjekti.
  Pri lastnostih primitiva (kazalci props1, props2, props3 in props4) se za vsak
kazalec posebej (ce je razlicen od 0) izpise ustrezna glava. Nato funkcija
fwriteprimitiveprop() Izpise objekte, na katere kazejo ti kazalci. En argument
te funkcije je stevilka, ki pove, za katerega od kazalcev props1 .. props4 gre,
argument funkcije pa je tudi kazalec na graficni primitiv, katerega lastnosti
naj funkcija izpise. To je potrebno zato, ker vrsta primitiva in specifikacija
kazalca dolocata, na kaksen objekt kaze doticni kazalec. V fwriteprimitiveprop()
je razvejitvena zanka, ki za vsako vrsto objekta klice svojo funkcijo, ki nato
glede na to, za katerega od kazalcev props1 ... props4 gre, izpise objekt, na
katerega kaze kazalec.
  Pri izpisu skladov before in after se ne izpisejo primitivi, na katere kazalci
so na teh skladih, temvec le mesta, kamor so nalozeni ti primitivi. Za vsak
primitiv na tem skladu se izpiseta po dve stevilki v zavih oklepajih, prva je
zaporedna stevilka podskupine, na katere skladu extraprimitives je nalozen
doticni primitiv, druga stevilka pa je zaporedna stevilka primitiva na skladu
extraprimitives. Recimo, da je ggg skupina, kivsebuje nas primitiv, na katerega
skladu after je kazalec na nek drug primitiv. Ce je ta drug primitiv nalozen na
sklad ggg->primitives, je zaporedna stevilka skupine 0, drugaze pa jeto
zaporedna stevilka tiste skupine na skladu ggg->groups, na katere skladu
primitives najdemo doticni objekt s sklada after.


*/




/* LOKALNE SPREMENLJIVKE - NIZI, KI DOLOCAJO OZNAKE ZA OBJEKTE OZIROMA POLJA
RAZLICNIH VRST: */

static char *primitivestr="primitive";
static char *nullprimitivestr="nullprimitive";
 static char *dpstr="doublepar";
 static char *coordstr="coords";
 static char *transfcoordstr="transfcoord";
 static char *beforestr="before";
 static char *afterstr="after";
 static char *props1str="props1";
 static char *props2str="props2";
 static char *props3str="props3";
 static char *props4str="props4";

static char *groupstr="group";
static char *nullgroupstr="nullgroup";
 static char *identitystr="ID";
 static char *namestr="name";
 static char *limsetstr="limitsset";
 static char *transflimsetstr="transflimitsset";
 static char *limitsstr="limits";
 static char *transflimitsstr="transflimits";
 static char *ls1str="ls1";
 static char *ls2str="ls2";
 static char *fs1str="fs1";
 static char *fs2str="fs";
 static char *ts1str="ts1";
 static char *ts2str="ts2";
 static char *primitivesstackstr="primitives";
 static char *extraprimitivesstackstr="extraprimitives";
 static char *groupsstackstr="groups";

/* Lastnosti: */

static char *colorstr="color";
static char *extrasetstr="extra";

static char *linesetstr="lineset";
 static char *linewidthstr="width";
 static char *linetypestr="type";

static char *fillsetstr="fillset";

static char *textsetstr="textset";
 static char *textfontstr="font";
 static char *textheightstr="height";
 static char *textspacingstr="spacing";
 static char *textexpansionstr="expansion";
 static char *textalignmentstr="alignment";

static char *textstringstr="text";

static char *bordflagsstr="borders";
static char *markersizestr="marksize";
static char *markerkindstr="markkind";


/***********************************************/
/*                                             */
/*            ZAPIS V DATOTEKE:                */
/*                                             */
/***********************************************/


static int precision=6;
static char writecoord=1,writetransfcoord=1;
static char coordnewlines=1; /* Zapisovanje vsake koordinate v svojo vrstico */


static void fprintspaces(FILE *fp, int spaces)
    /* V datoteko fp zapise spaces presledkov. */
{
int i;
for (i=1;i<=spaces;++i)
  fprintf(fp," ");

/* $$$$$$$ */
fflush(fp);
}




static void gofwrite1coord(FILE *fp,coord3d x)
    /* V datoteko fp zapise koordinate x */
{
if (x!=NULL)
  fprintf(fp,"{ %.*g %.*g %.*g }",precision,x->x,precision,x->y,precision,x->z);
else fprintf(fp,"{ }");
}


static void gofwritestackcoords(FILE *fp,stack coords,int spaces)
    /* V datoteko fp zapise vse koordinate, ki so na skladu st (v obliki
    kazalcev tipa coord3d). spaces je zacetni zamik, plusspaces pa dodatem
    zamik pri prehodu v nov nivo. */
{
int i;
coord3d x;
if (coords->n>0)
{
  fprintspaces(fp,spaces);
  for (i=1; i<=coords->n;++i)
  {
    x=coords->s[i];
    if (i>1)
    {
      if (coordnewlines)
      {
        fprintf(fp,"\n");
        fprintspaces(fp,spaces);
      }
      else fprintf(fp," ");
    }
    if (x!=NULL)
      fprintf(fp,"{ %.*g %.*g %.*g }",precision,x->x,precision,x->y,precision,x->z);
    else fprintf(fp,"{ }");
  }
  fprintf(fp,"\n");
}
}



static void fwritecolor(FILE *fp,truecolor color)
    /* V datoteko fp zapise barvo color. */
{
if (color!=NULL)
  fprintf(fp,"%s{ %.*g %.*g %.*g }",colorstr,precision,color->red,
          precision,color->green,precision,color->blue);
else fprintf(fp,"{ }");
}


static void fwritelineset(FILE *fp,golinesettings ls,int spaces,int plusspaces)
    /* V datoteko fp zapise nastavitve za risanje crt, ki so v *ls. spaces je
    zacetni zamik, plusspaces pa dodaten zamik pri prehodu v nov podnivo. */
{
if (ls!=NULL)
{
  fprintspaces(fp,spaces);  fprintf(fp,"%s\n",linesetstr);
  fprintspaces(fp,spaces);  fprintf(fp,"{\n");
  /* Telo: */
  spaces+=plusspaces;
  /* Barva: */
  fprintspaces(fp,spaces);  fwritecolor(fp,&(ls->color));  fprintf(fp,"\n");
  /* Debelina: */
  fprintspaces(fp,spaces);  
  fprintf(fp,"%s{%g}\n",linewidthstr,ls->linewidth);
  /*
  fprintf(fp,"%s{",linewidthstr);
  fprintf(fp,"%i",ls->linewidth);
  fprintf(fp,"}\n");
  */
  /* Tip: */
  fprintspaces(fp,spaces);  fprintf(fp,"%s{%i}\n",linetypestr,ls->linetype);
  /* Dodatne nastavitve: */
  if (ls->extra!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",extrasetstr);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");

    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  /* Rep: */
  spaces-=plusspaces;
  fprintspaces(fp,spaces);  fprintf(fp,"}\n");
}
}


static void fwritefillset(FILE *fp,gofillsettings fs,int spaces,int plusspaces)
    /* V datoteko fp zapise nastavitve za risanji pobarvanih likov, ki so v *fs.
    spaces je zacetni zamik, plusspaces pa dodatni zamik pri prehodu v nov
    podnivo. */
{
if (fs!=NULL)
{
  fprintspaces(fp,spaces);  fprintf(fp,"%s\n",fillsetstr);
  fprintspaces(fp,spaces);  fprintf(fp,"{\n");
  /* Telo: */
  spaces+=plusspaces;
  /* Barva: */
  fprintspaces(fp,spaces);  fwritecolor(fp,&(fs->color));  fprintf(fp,"\n");
  /* Dodatne nastavitve: */
  if (fs->extra!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",extrasetstr);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");

    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  /* Rep: */
  spaces-=plusspaces;
  fprintspaces(fp,spaces);  fprintf(fp,"}\n");
}
}


static void fwritetextset(FILE *fp,gotextsettings ts,int spaces,int plusspaces)
    /* V datoteko fp izpise nastavitve za risanje teksta, ki so v *ts. spaces
    je zacetni zamik, plusspaces pa dodatni zamik pri prehodu v nov podnivo. */
{
if (ts!=NULL)
{
  fprintspaces(fp,spaces);  fprintf(fp,"%s\n",textsetstr);
  fprintspaces(fp,spaces);  fprintf(fp,"{\n");
  /* Telo: */
  spaces+=plusspaces;
  /* Barva: */
  fprintspaces(fp,spaces);  fwritecolor(fp,&(ts->color));  fprintf(fp,"\n");
  /* Pisava: */
  fprintspaces(fp,spaces);  fprintf(fp,"%s{%i}\n",textfontstr,ts->font);
  /* Visina: */
  fprintspaces(fp,spaces);
  fprintf(fp,"%s{%.*g}\n",textheightstr,precision,ts->height);

  /* Spacing: */
  fprintspaces(fp,spaces);
  fprintf(fp,"%s{%.*g}\n",textspacingstr,precision,ts->spacing);
  /* Razsiritev: */
  fprintspaces(fp,spaces);
  fprintf(fp,"%s{%.*g}\n",textexpansionstr,precision,ts->expansion);
  /* Poravnavanje: */
  fprintspaces(fp,spaces);
  fprintf(fp,"%s{%i %i}\n",textalignmentstr,ts->xalignment,ts->yalignment);
  /* Dodatne nastavitve: */
  if (ts->extra!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",extrasetstr);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");

    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  /* Rep: */
  spaces-=plusspaces;
  fprintspaces(fp,spaces);  fprintf(fp,"}\n");
}
}


static void fwritebordflags(FILE *fp,char *p,int num,int spaces)
    /* V datoteko fp izpise zastavice (tipa char), ki povedo, kateri robovi
    veckotnika naj se izrisejo. Zastavice so v *p, num pa pove, koliko jih je.
    Za "da" se izpise znak '1', za "ne" pa znak '0'. Spaces je zamik. */
{
int i;
if (p!=NULL)
{
  fprintspaces(fp,spaces); fprintf(fp,"%s{",bordflagsstr);
  for (i=0;i<=num-1;++i)
    if (p[i]==0)
      fprintf(fp,"0");
    else
      fprintf(fp,"1");
  fprintf(fp,"}\n");
}
}


static void fwritemarkersize(FILE *fp,double *p,int spaces)
    /* V datoteko fp izpise velikost markerja. p je kazalec na velikost, ki je
    tipa double. Spaces je zamik. */
{
if (p!=NULL)
{
  fprintspaces(fp,spaces); fprintf(fp,"%s{",markersizestr);
  fprintf(fp," %g ",*p);
  fprintf(fp,"}\n");
}
}


static void fwritemarkerkind(FILE *fp,int *p,int spaces)
    /* V datoteko fp izpise vrsto markerja. p je kazalec na oznako vrste, ki je
    tipa int. Spaces je zamik. */
{
if (p!=NULL)
{
  fprintspaces(fp,spaces); fprintf(fp,"%s{",markerkindstr);
  fprintf(fp," %i ",*p);
  fprintf(fp,"}\n");
}
}






/* FUNKCIJE ZA IZPIS POLJ props1 ... props4 GRAFICNIH PRIMITIVOV: */

/* OPOMBA: Pri pisanju teh funkcij je treba paziti, da so konsistentne s
funkcijami basgp...(); iz teh funkcij se jasno vidi, kaj predstavljajo
posamezni kazalci, ...->props1 ...->props2,  ...->props3 in ...->props4
pri graficnih primitivih razlicnih vrst.

  OPOMBA: Te funkcije ne preverjajo same, ali je gp->props(...) razlicen od
NULL, zato je to treba obvezno storiti pred klicem teh funkcij.

*/


static void fwritepropsline(FILE *fp,goprimitive gp,char which,int spaces,
                        int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja crto ('l','0','0') */
{
if (which==1)
  fwritelineset(fp,(golinesettings) gp->props1,spaces,plusspaces);
}



static void fwritepropstriangle(FILE *fp,goprimitive gp,char which,int spaces,
                        int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja trikotnik iz crt
       ('3','0','0') */
{
if (which==1)
  fwritelineset(fp,(golinesettings) gp->props1,spaces,plusspaces);
}



static void fwritepropsfilltriangle(FILE *fp,goprimitive gp,char which,
                        int spaces, int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja pobarvan trikotnik
       ('3','f','0') */
{
if (which==1)
  fwritefillset(fp,(gofillsettings) gp->props1,spaces,plusspaces);
}



static void fwritepropsbordtriangle(FILE *fp,goprimitive gp,char which,
                        int spaces, int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja pobarvan obrobljen
       trikotnik ('3','b','0') */
{
if (which==1)
  fwritefillset(fp,(gofillsettings) gp->props1,spaces,plusspaces);
else if (which==2)
  fwritelineset(fp,(golinesettings) gp->props2,spaces,plusspaces);
}




static void fwritepropspartbordtriangle(FILE *fp,goprimitive gp,char which,
                        int spaces, int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja pobarvan delno obrobljen
       trikotnik ('3','p','0'). Ce je vsaj ena stranica trikotnika obrobljena s
       crto, je gp->props3 kazalec na niz 3 znakov. Obrobljene so stranice, za
       katere so ustrezni znako razlicni od '\0'. gp->props3[0] ustreza stranici
       med 1. in 2. koordinato itd. */
{
if (which==1)
  fwritefillset(fp,(gofillsettings) gp->props1,spaces,plusspaces);
else if (which==2)
  fwritelineset(fp,(golinesettings) gp->props2,spaces,plusspaces);
else if (which==3)
  fwritebordflags(fp,(char *) gp->props3,3,spaces);
}





static void fwritepropsfourangle(FILE *fp,goprimitive gp,char which,
                        int spaces, int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja stirikotnik iz crt
       ('4','0','0') */
{
if (which==1)
  fwritelineset(fp,(golinesettings) gp->props1,spaces,plusspaces);
}




static void fwritepropsfillfourangle(FILE *fp,goprimitive gp,char which,
                        int spaces, int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja zapolnjen stirikotnik
       ('4','f','0') */
{
if (which==1)
  fwritefillset(fp,(gofillsettings) gp->props1,spaces,plusspaces);
}


static void fwritepropsbordfourangle(FILE *fp,goprimitive gp,char which,
                        int spaces, int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja obrobljen zapolnjen
       stirikotnik ('4','b','0') */
{
if (which==1)
  fwritefillset(fp,(gofillsettings) gp->props1,spaces,plusspaces);
else if (which==2)
  fwritelineset(fp,(golinesettings) gp->props2,spaces,plusspaces);
}





static void fwritepropspartbordfourangle(FILE *fp,goprimitive gp,char which,
                        int spaces, int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja delno obrobljen zapolnjen
       stirikotnik ('4','p','0'). Ce je vsaj ena stranica stirikotnika obroblje-
       na, je gp->props3 kazalec na niz 4 znakov. Obrobljene so stranice, za
       katere so ustrezni znako razlicni od '\0'. gp->props3[0] ustreza stranici
       med 1. in 2. koordinato itd. */
{
if (which==1)
  fwritefillset(fp,(gofillsettings) gp->props1,spaces,plusspaces);
else if (which==2)
  fwritelineset(fp,(golinesettings) gp->props2,spaces,plusspaces);
else if (which==3)
  fwritebordflags(fp,(char *) gp->props3,4,spaces);
}




static void fwritepropsmarker(FILE *fp,goprimitive gp,char which,
                        int spaces, int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja delno obrobljen zapolnjen
       stirikotnik ('4','p','0'). Ce je vsaj ena stranica stirikotnika obroblje-
       na, je gp->props3 kazalec na niz 4 znakov. Obrobljene so stranice, za
       katere so ustrezni znako razlicni od '\0'. gp->props3[0] ustreza stranici
       med 1. in 2. koordinato itd. */
{
if (which==1)
  fwritefillset(fp,(gofillsettings) gp->props1,spaces,plusspaces);
else if (which==2)
  fwritelineset(fp,(golinesettings) gp->props2,spaces,plusspaces);
else if (which==3)
  fwritemarkersize(fp,gp->props3,spaces);
else if (which==4)
  fwritemarkerkind(fp,gp->props4,spaces);
}



static void fwritepropstext(FILE *fp,goprimitive gp,char which,int spaces,
                        int plusspaces)
       /* Izpise lastnosti za primitiv, ki predstavlja mavaden tekst
       ('t','0','0') */
{
if (which==1)
{
  fprintspaces(fp,spaces);
  fprintf(fp,"%s{%s}\n",textstringstr,(char *)gp->props1);
} else if (which==2)
  fwritetextset(fp,(gotextsettings) gp->props2,spaces,plusspaces);
}





static void fwriteprimitiveprop(FILE *fp,goprimitive gp,char which,int spaces,
                        int plusspaces)
    /* Zapise vsebino enega izmed kazalcev gp->props1 do gp->props4 v datoteko
    fp. which pove, za kateri kazalec gre (1 ustreza gp->props1, 2 ustreza
    gp->props2 itd. spaces je zamik vrstic, plusspaces pa dodatni zamik pri
    prehodu na nov podnivo. Telo funkcije je kar kopija glavnega dela funkcije
    godrawprimitive() iz gro.c, le da so imena klicanih funkcij spremenjena po
    nacelu gpdrawline()->fwritepropsline(). Tudi v prihodnje naj se telo te
    funkcije zaradi zanesljivosti kar skopira iz funkcije godrawprimitive(), s
    tem da se spremenijo imena klicanih funkcij in dodajo te funkcije za nove
    vrste graficnih primitivov. */
{
  if (gp->i1=='l')
  {
    if (gp->i2=='0')
    {
      if (gp->i3=='0')
        fwritepropsline(fp,gp,which,spaces,plusspaces); /* Navadna crta */
    }
  } else if (gp->i1=='3')
  {
    if (gp->i2=='p')
    {
      if (gp->i3=='0')
        fwritepropspartbordtriangle(fp,gp,which,spaces,plusspaces); /* Delno obrobljen zapolnjen trikotnik */
    } else if (gp->i2=='0')
    {
      if (gp->i3=='0')
        fwritepropstriangle(fp,gp,which,spaces,plusspaces); /* Trikotnik iz crt */
    } else if (gp->i2=='f')
    {
      if (gp->i3=='0')
        fwritepropsfilltriangle(fp,gp,which,spaces,plusspaces); /* Zapolnjen trikotnik iz crt */
    } else if (gp->i2=='b')
    {
      if (gp->i3=='0')
        fwritepropsbordtriangle(fp,gp,which,spaces,plusspaces); /* Obrobljen trikotnik iz crt */
    }
  } else if (gp->i1=='4')
  {
    if (gp->i2=='p')
    {
      if (gp->i3=='0')
        fwritepropspartbordfourangle(fp,gp,which,spaces,plusspaces); /* Delno obrobljen zapolnjen stirikotnik */
    } else if (gp->i2=='0')
    {
      if (gp->i3=='0')
        fwritepropsfourangle(fp,gp,which,spaces,plusspaces); /* Stirikotnik iz crt */
    } else if (gp->i2=='f')
    {
      if (gp->i3=='0')
        fwritepropsfillfourangle(fp,gp,which,spaces,plusspaces); /* Zapolnjen stirikotnik iz crt */
    } else if (gp->i2=='b')
    {
      if (gp->i3=='0')
        fwritepropsbordfourangle(fp,gp,which,spaces,plusspaces); /* Obrobljen stirikotnik iz crt */
    }
  } else if (gp->i1=='m')
  {
    if (gp->i2=='0')
    {
      if (gp->i3=='0')
        fwritepropsmarker(fp,gp,which,spaces,plusspaces); /* Tekst */
    }
  } else if (gp->i1=='t')
  {
    if (gp->i2=='0')
    {
      if (gp->i3=='0')
        fwritepropstext(fp,gp,which,spaces,plusspaces); /* Tekst */
    }
  }
}




static int findextraprimitive(void *p,gogroup gg,int *group,int *primitive)
    /* Poisce primitiv  z naslovom p na gg->extraprimitives in na skladih
    (...)->extraprimitives vseh skupin, ki so nalozene na gg->groups. Ce ga ne
    najde, vrne -1 in tudi v *group in *primitive zapise vrednosti -1. Drugace
    zapise v *group zaporedno stevilko skupine na skladu gg->groups, na katere
    skladu (...)->extraprimitives najde prvi pojav kazalca p (oziroma 0, ce
    najde kazalec ze na gg->extraprimitives), v *primitive pa zapise zaporedno
    stevilko najdenega kazalca na ustreznem skladu (...)->extraprimitives ter
    vrne *group. */
{
int ret=-1,i,j;
char found=0;
gogroup gg1;
*group=*primitive=-1;
if (p!=NULL && gg!=NULL)
{
  if (gg->extraprimitives!=NULL)
    if (gg->extraprimitives->n>0)
      for (j=1;j<=gg->extraprimitives->n;++j)
        if (!found)
          if (gg->extraprimitives->s[j]==p)
          {
            found=1;
            *group=ret=0;
            *primitive=j;
          }
  if (!found)
    if (gg->groups!=NULL)
      if (gg->groups->n>0)
        for (i=1;i<=gg->groups->n;++i)
          if (!found)
          {
            gg1=gg->groups->s[i];
            if (gg1->extraprimitives!=NULL)
              if (gg1->extraprimitives->n>0)
                for (j=1;j<=gg1->extraprimitives->n;++j)
                  if (!found)
                    if (gg1->extraprimitives->s[j]==p)
                    {
                      found=1;
                      *group=ret=i;
                      *primitive=j;
                    }
          }
}
return ret;
}




void gofwriteprimitive(FILE *fp,goprimitive gp,gogroup gg,
                       int spaces,int plusspaces)
    /* V datoteko fp zapise primitiv gp. gg je skupina, na katero je nalozen ta
    primitiv (potrebna je pri klicih findextraprimitive), spaces je zacetni
    zamik, plusspaces pa dodatni zamik pri prehodu v nov podnivo. */
{
int i,j,k;
if (gp!=NULL)
{
  /* Glava: */
  fprintspaces(fp,spaces);  fprintf(fp,"%s\n",primitivestr);
  fprintspaces(fp,spaces);  fprintf(fp,"{\n");
  /* Telo: */
  spaces+=plusspaces;
  /* Trije znaki v oglatem oklepaju, ki definirajo vrsto primitiva: */
  fprintspaces(fp,spaces);  fprintf(fp,"[%c%c%c]\n",gp->i1,gp->i2,gp->i3);
  /* Parameter tipa double: */
  if (gp->dp!=NULL)
  {
    fprintspaces(fp,spaces);
    fprintf(fp,"%s{%g}\n",dpstr,*(gp->dp));
  }
  /* Koordinate: */
  if (gp->coord!=NULL && writecoord)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",coordstr);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    gofwritestackcoords(fp,gp->coord,spaces+plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  /* Transformirane koordinate: */
  if (gp->transfcoord!=NULL && writetransfcoord)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",transfcoordstr);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    gofwritestackcoords(fp,gp->transfcoord,spaces+plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  /* Primitivi, ki se izrisejo pred tem primitivom: */
  if (gp->before!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s{",beforestr);
    if (gp->before->n>0)
      for (i=1;i<=gp->before->n;++i)
      {
        fprintf(fp,"{");
        if (findextraprimitive(gp->before->s[i],gg,&j,&k)>=0)
        {
          fprintf(fp,"%i %i",j,k);
        }
        fprintf(fp,"}");
      }
    fprintf(fp,"}\n");
  }
  /* Primitivi, ki se izrisejo za tem primitivom: */
  if (gp->after!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s{",afterstr);
    if (gp->after->n>0)
      for (i=1;i<=gp->after->n;++i)
      {
        fprintf(fp,"{");
        if (findextraprimitive(gp->after->s[i],gg,&j,&k)>=0)
        {
          fprintf(fp,"%i %i",j,k);
        }
        fprintf(fp,"}");
      }
    fprintf(fp,"}\n");
  }
  /* Lastnosti: */
  if (gp->props1!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",props1str);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fwriteprimitiveprop(fp,gp,1,spaces+plusspaces,plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  if (gp->props2!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",props2str);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fwriteprimitiveprop(fp,gp,2,spaces+plusspaces,plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  if (gp->props3!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",props3str);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fwriteprimitiveprop(fp,gp,3,spaces+plusspaces,plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  if (gp->props4!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",props4str);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fwriteprimitiveprop(fp,gp,4,spaces+plusspaces,plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }

  /* Rep: */
  spaces-=plusspaces;
  fprintspaces(fp,spaces);  fprintf(fp,"}\n");
} else
{
  fprintspaces(fp,spaces);  fprintf(fp,"%s{ }\n",nullprimitivestr);
}
}



void gofwritegroup(FILE *fp,gogroup gg,int spaces,int plusspaces)
    /* V datoteko fp zapise skupino graficnih objektov gg. spaces je zacetni
    zamik, plusspaces pa dodatni zamik pri prehodih v nov podnivo. */
{
int i;
if (fp!=NULL && gg!=NULL)
{
  /* Glava: */
  fprintspaces(fp,spaces);  fprintf(fp,"%s\n",groupstr);
  fprintspaces(fp,spaces);  fprintf(fp,"{\n");
  /* Telo: */
  spaces+=plusspaces;
  /* Identifikacijska stevilka: */
  fprintspaces(fp, spaces);  fprintf(fp, "%s{ %i }\n",identitystr,gg->id);
  /* Ime: */
  if (gg->name!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s{%s}\n",namestr,gg->name);
  }
  /* Podatki o izracunanih mejah: */
  /* (ali so izracunane meje v originalnih koord.; avtomatsko 0, ce je
  writecoord==0) */
  fprintspaces(fp,spaces);
  if (writecoord)
    fprintf(fp,"%s{%i}\n",limsetstr,gg->limitsset);
  else
    fprintf(fp,"%s{0}\n",limsetstr);
  /* (ali so izracunane meje v transf. koord.; avtomatsko 0, ce je
  writetransfcoord==0) */
  fprintspaces(fp,spaces);
  if (writetransfcoord)
    fprintf(fp,"%s{%i}\n",transflimsetstr,gg->transflimitsset);
  else
    fprintf(fp,"%s{0}\n",transflimsetstr);
  /* Meje v originalnih koordinatah: */
  if ((gg->min!=NULL || gg->max!=NULL) && writecoord)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",limitsstr);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fprintspaces(fp,spaces+plusspaces);
    gofwrite1coord(fp,gg->min);
    if (coordnewlines)
    {
      fprintf(fp,"\n");
      fprintspaces(fp,spaces+plusspaces);
    } else
      fprintf(fp," ");
    gofwrite1coord(fp,gg->max);
    fprintf(fp,"\n");
    fprintspaces(fp,spaces);
    fprintf(fp,"}\n");
  }
  /* Meje v transformiranih koordinatah: */
  if ((gg->mintransf!=NULL || gg->maxtransf!=NULL) && writetransfcoord)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",transflimitsstr);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fprintspaces(fp,spaces+plusspaces);
    gofwrite1coord(fp,gg->mintransf);
    if (coordnewlines)
    {
      fprintf(fp,"\n");
      fprintspaces(fp,spaces+plusspaces);
    } else
      fprintf(fp," ");
    gofwrite1coord(fp,gg->maxtransf);
    fprintf(fp,"\n");
    fprintspaces(fp,spaces);
    fprintf(fp,"}\n");
  }
  /* Nastavitve: */
  if (gg->ls1!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",ls1str);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fwritelineset(fp,gg->ls1,spaces+plusspaces,plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  if (gg->ls2!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",ls2str);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fwritelineset(fp,gg->ls2,spaces+plusspaces,plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  if (gg->fs1!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",fs1str);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fwritefillset(fp,gg->fs1,spaces+plusspaces,plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  if (gg->fs2!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",fs2str);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fwritefillset(fp,gg->fs2,spaces+plusspaces,plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  if (gg->ts1!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",ts1str);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fwritetextset(fp,gg->ts1,spaces+plusspaces,plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  if (gg->ts2!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",ts2str);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    fwritetextset(fp,gg->ts2,spaces+plusspaces,plusspaces);
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  /* Primitivi: */
  if (gg->primitives!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",primitivesstackstr);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    if (gg->primitives->n>0)
    {
      spaces+=plusspaces;
      for (i=1;i<=gg->primitives->n;++i)
      {
        gofwriteprimitive(fp,(goprimitive)gg->primitives->s[i],gg,
         spaces,plusspaces);
      }
      spaces-=plusspaces;
    }
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  /* Pomozni primitivi: */
  if (gg->extraprimitives!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",extraprimitivesstackstr);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    if (gg->extraprimitives->n>0)
    {
      spaces+=plusspaces;
      for (i=1;i<=gg->extraprimitives->n;++i)
      {
        gofwriteprimitive(fp,(goprimitive)gg->extraprimitives->s[i],gg,
         spaces,plusspaces);
      }
      spaces-=plusspaces;
    }
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  /* Podskupine: */
  if (gg->groups!=NULL)
  {
    fprintspaces(fp,spaces);  fprintf(fp,"%s\n",groupsstackstr);
    fprintspaces(fp,spaces);  fprintf(fp,"{\n");
    if (gg->groups->n>0)
    {
      spaces+=plusspaces;
      for (i=1;i<=gg->groups->n;++i)
      {
        gofwritegroup(fp,(gogroup)gg->groups->s[i],spaces,plusspaces);
      }
      spaces-=plusspaces;
    }
    fprintspaces(fp,spaces);  fprintf(fp,"}\n");
  }
  /* Rep: */
  spaces-=plusspaces;
  fprintspaces(fp,spaces);  fprintf(fp,"}\n");
} else
{
  fprintspaces(fp,spaces);  fprintf(fp,"%s{ }\n",nullgroupstr);
}
}


void gofilewritegroup(char *name,gogroup gg,int spaces,int plusspaces)
    /* V datoteko z imenom name zapise skupino graficnih elementov gg. Ce
    datoteka s tem imenom ze obstaja, se njena vsebina prepise. spaces je
    zacetni zamik, plusspaces pa dodatni zamik pri prehodu v nov podnivo. */
{
FILE *fp;
fp=fopen(name,"wb");
if (fp!=NULL)
{
  gofwritegroup(fp,gg,spaces,plusspaces);
  fclose(fp);
}
}











/***********************************************/
/*                                             */
/*            BRANJE IZ DATOTEK:               */
/*                                             */
/***********************************************/







/*

  BRANJE GRAFICNIH OBJEKTOV IZ DATOTEK:

  Graficni objekti so v datotekah zapisani kot polja, ki v argumentnem bloku
(prostoru v zavitem oklepaju) vsebujejo podpolja ali konkretne podatke. Podpolja
predstavljajo podobjekte danega objekta ali dele danega objekta oz. njegove
lastnosti. Vsako polje je v datoteki predstavljeno s karakteristicnim nizom, ki
pove vrsto polja, in argumentnim blokom, ki temu nizu sledi in je v njem podana
vsebina polja.
  Za branje polj razlicnih vrst skrbijo specificne funkcije. Tiste, ki berjo
polja, ki lahko vsebujejo vec podpolj, delujejo tako, da v danem obmocju
datoteke (to je podano z argumenti funkcije) zaporedoma iscejo karakteristicne
nize, ki lahko predstavljajo eno od teh podpolj, ter poganjajo ustrezne funkcije
za branje podpolj, ki pripadajo tem karakteristicnim nizom. Pri vsakem podpolju
poiscejo tudi obmocje, v katerem je argumentni blok taga podpolja (obmocje
znotraj zaprtega zavitega oklepaja, ki sledi karakteristicnemu nizu), ter to
obmocje prenesejo klicanim funkcijam z njihovimi argumenti. Za vsako taksno
funkcijo obstajata dva sklada, na enem so nalozeni karakteristicni nizi, ki
predstavljajo podpolja, na drugem pa ustrezne funkcije za branje teh podpolj.
  Funkcije, ki berejo objekte in podobjekte ter dele oz. lastnosti le-teh,
hkreti skrbijo tudi za to, da se ob branju vsakega novega objekta alocira tudi
prostor za ta objekt in da se, ce je potrebno, kazalci na podobjekte nalozijo na
ustrezna mesta v objektih, ki te podobjekte  vsebujejo.

*/




/* Struktura za podatke o graf. primitivih, nalozenih na sklade (...)->before in
(...)->after drugih primitivov: */

typedef struct {
        goprimitive gp; /* Primitiv, na katerega je nalozen dodatni primitiv */
        int gn;  /* Zap. st. podskupine, v kateri je vsebovan primitiv */
        int pn;  /* Zap. st. primitiva na skladu extraprimitives te skupine */
        char id; /* 0 za sklad before, 1 za sklad after */
        } _extrastruct;

typedef _extrastruct *extrastruct;



/* Struktura za prenos podatkov o iskanju polj in podatkov o najdenih poljih: */

typedef struct {
        FILE *fp;
        long from,to;
        stack names;
        int buf0,buf;
        char brac1,brac2;
        int n;
        long where,
             begin,
             end;
        } _fieldstruct;

typedef _fieldstruct *fieldstruct;


/* Skladi, na katere se nalozijo imena polj in funkcije za njihovo branje: */

static stack nsout=NULL, fsout=NULL,
              nsgroup=NULL, fsgroup=NULL,
              nsprimitive=NULL, fsprimitive=NULL,
              nsmoregroups=NULL, fsmoregroups=NULL,
              nsmoreprimitives=NULL, fsmoreprimitives=NULL,
              nsproperties=NULL, fsproperties=NULL,
              nslinesettings=NULL, fslinesettings=NULL,
              nsfillsettings=NULL, fsfillsettings=NULL,
              nstextsettings=NULL, fstextsettings=NULL;



static char grinit=0;

static int buf0=16,buf=400;





static void initfieldstruct(fieldstruct fs)
    /* Inicializira strukturo za podatke o naslednjem poiskanem objektu v
    datoteki */
{
fs->fp=NULL;
fs->from=1;
fs->to=1000000000;
fs->names=NULL;
fs->brac1='{';
fs->brac2='}';
fs->buf0=buf0;
fs->buf=buf;
}


static void findfield(fieldstruct fs)
    /* Najde naslednje polje v datoteki. V strukturi fs so vsi podatki potrebni
    za iskanje: fs->fp je datotecni kazalec datoteke, v kateri se isce; v
    fs->from in fs->to je obmocje iskanja; na skladu fs->names so imena moznih
    polj; fs->buf0 in fs->buf sta dolzini vmes. pomnilnikov pri iskanju gesla
    in pri iskanju obmocja polja (oklepajev); fs->brac1 in fs->brac2 sta
    oklepaja, ki omejujeta dano polje. V fs funkcija zapise tudi vrnjene
    podatke: v fs->n zap. stevilko imena polja (na skladu fs->st), v fs->where,
    fs->begin in fs->end pa pojav imena polja, zacetek polja (eno mesto za
    oklepajem) in konec polja (eno mesto za zaklepajem). */
{
fs->where=nfilestringto(fs->fp,fs->names,fs->from,fs->to,fs->buf0,&(fs->n));
if (fs->where>0)
{
  fs->from=fs->where+strlen( (char *) fs->names->s[fs->n] );
  filebracto(fs->fp,fs->brac1,fs->brac2,fs->from,fs->to,fs->buf,
   &(fs->begin),&(fs->end));
  if (fs->begin<1)
    fs->where=fs->n=-1;
} else
{
  fs->n=fs->begin=fs->where=-1;
}
}


/* BRANJE KOORDINAT: */

static void freadstcoords(FILE *fp,long from,long to,stack st)
    /* Prebere koordinade iz datoteke fp znotraj polja med from in to ter jih
    zaporedoma nalozi na sklad st v obliki kazalcev tipa coord3d. Koordinate
    morajo biti po vrsti nastete v zavitih oklepajih, komponente pa locene s
    presledki, npr. {0 1 1} {1.2 2.6 1.7} */
{
char b1='{',b2='}';
coord3d p;
long pos,brac1,brac2;
int length;
if (st==NULL)
  printf("ERROR in freadstcoords: stack not allocated.\n");
else
{
  brac1=from; brac2=to;
  while (brac1>0 && brac2>0)
  {
    filebracto(fp,b1,b2,from,to,25,&brac1,&brac2);
    if (brac1>0 && brac2>0)
    {
      p=malloc(sizeof(*p));
      pushstack(st,p);
      from=brac2+1;
      p->x=filenumto(fp,brac1,brac2,12,&pos,&length);
      if (pos>0 && length>0)
      {
        p->y=filenumto(fp,pos+length,brac2,12,&pos,&length);
        if (pos>0 && length>0)
          p->z=filenumto(fp,pos+length,brac2,12,&pos,&length);
      }
    }
  }
}
}

/* BRANJE BARVE IN NEKAJ POMOZNIH FUNKCIJ ZA BRANJE LASTNOSTI: */

static void freadtruecolor(FILE *fp,long from,long to,truecolor col)
    /* Iz datoteke fp prebere tri komponente barve v *col ned mestoma from in
    to. Komponente morajo biti locene s presledki ali znaki za novo vrstico.
    col ne sme biti NULL. */
{
long pos;
int length;
if (col==NULL)
  printf("ERROR in freadtruecolor: space for colour is not allocated.\n");
  /*
  fprintf(fp,"ERROR in freadtruecolor: space for colour is not allocated.\n");
  */
else
{
  col->red=(float) filenumto(fp,from,to,12,&pos,&length);
  if (pos>0 && length>0)
  {
    col->green=(float) filenumto(fp,pos+length,to,12,&pos,&length);
    if (pos>0 && length>0)
      col->blue=(float) filenumto(fp,pos+length,to,12,&pos,&length);
  }
}
}

static void freaddouble(FILE *fp,long from,long to,double *p)
    /* V *p, ki ne sme biti null, prebere 1. stevilo iz datoteke fp med mestoma
    from in to. */
{
long pos;
int length;
if (p==NULL)
  printf("ERROR in freaddouble: space for number is not allocated.\n");
  /*
  fprintf(fp,"ERROR in freaddouble: space for number is not allocated.\n");
  */
else
  *p=filenumto(fp,from,to,12,&pos,&length);
}

static void freadlong(FILE *fp,long from,long to,long *p)
    /* V *p, ki ne sme biti NULL, prebere prvo celo stevilo iz datoteke fp med
    mestoma from in to. */
{
long pos;
int length;
if (p==NULL)
  printf("ERROR in freaddouble: space for number is not allocated.\n");
  /*
  fprintf(fp,"ERROR in freaddouble: space for number is not allocated.\n");
  */
else
  *p=(long) filenumto(fp,from,to,12,&pos,&length);
}

static void freadint(FILE *fp,long from,long to,int *p)
    /* V *p, ki ne sme biti NULL, prebere prvo celo stevilo iz datoteke fp med
    mestoma from in to. */
{
long pos;
int length;
if (p==NULL)
  printf("ERROR in freaddouble: space for number is not allocated.\n");
  /*
  fprintf(fp,"ERROR in freaddouble: space for number is not allocated.\n");
  */
else
  *p=(int) filenumto(fp,from,to,12,&pos,&length);
}


/* FUNKCIJE ZA BRANJE RAZNIH OBJEKTOV, KI SO LAHKO NALOZENI NA KAZALCE
   props1, props2, props3 in props4 GRAFICNIH PRIMITIVOV. Te funkcije se
   uporabljajo tudi za branje objektov, nalozenih na kazalce ls1, ls2, fs1, fs2,
   ts1 in ts2 skupin graficnih objektov. */


/* FUNKCIJE ZA BRANJE POSAMEZNIH DELOV LASTNOSTI: */

static void fgrinlinecolor(FILE *fp,long from,long to,golinesettings p)
    /* V *p, za katerega mora biti rezerviran prostor, prebere nastavitve za
    risanje crt iz datoteke fp med mestoma from in to. */
{
freadtruecolor(fp,from,to,(truecolor) &(p->color));
}

static void fgrinlinewidth(FILE *fp,long from,long to,golinesettings p)
    /* V p->linewidth zapise sirino crt, definirano v datoteki fp med from in
    to. */
{
freaddouble(fp,from,to,(double *) &(p->linewidth));
}

static void fgrinlinetype(FILE *fp,long from,long to,golinesettings p)
    /* V p->linetype prebere tip crt, definiran v datoteki fp med mestoma from
    in to. */
{
freadint(fp,from,to,(int *) &(p->linetype));
}


static void fgrinfillcolor(FILE *fp,long from,long to,gofillsettings p)
    /* v p->color zapise barvo crt, ki jo prebere iz datoteke fp med mestoma
    from in to. */
{
freadtruecolor(fp,from,to,(truecolor) &(p->color));
}


static void fgrintextcolor(FILE *fp,long from,long to,gotextsettings p)
    /* V p->color zapise barvo teksta, ki je definirana v datoteki fp med from
    in to. */
{
freadtruecolor(fp,from,to,(truecolor) &(p->color));
}

static void fgrintextfont(FILE *fp,long from,long to,gotextsettings p)
    /* V p->font zapise vrsto pisave, ki jo rebere iz datoteke fp med from in
    to. */
{
freadint(fp,from,to,(int *) &(p->font));
}

static void fgrintextheight(FILE *fp,long from,long to,gotextsettings p)
   /* V p->height zapise visino teksta, ki jo prebere iz datoteke fp med mestoma
   from in to. */
{
freaddouble(fp,from,to,(double *) &(p->height));
}

static void fgrintextspacing(FILE *fp,long from,long to,gotextsettings p)
    /* V p->spacing prebere velikost presledkov, ki jo prebere iz datoteke fp
    med mestoma from in to. */
{
freaddouble(fp,from,to,(double *) &(p->spacing));
}

static void fgrintextexpansion(FILE *fp,long from,long to,gotextsettings p)
    /* V p->expansion prebere raztegnitev pisave, ki jo prebere iz fp med from
    in to. */
{
freaddouble(fp,from,to,(double *) &(p->expansion));
}

static void fgrintextalignment(FILE *fp,long from,long to,gotextsettings p)
    /* V *p zapise poravnavanje v obeh smereh, ki ju prebere iz datoteke fp
    med from in to. */
{
_truecolor color;
freadtruecolor(fp,from,to,&color);
p->xalignment=(int) color.red;
p->yalignment=(int) color.green;
}



/* FUNKCIJE ZA BRANJE OBJEKTOV, KI PREDSTAVLJAJO LASTNOSTI DANEGA TIPA: */

/* FUNKCIJE ZA LASTNOSTI RAZLICNIH VRST: */

static void fgrinlineset(FILE *fp,long from,long to,void **pp)
    /* V **pp prebere nastavitve za risanje crt iz datoteke fp med from in to.
    Pred tem se alocira prostor za **pp. */
{
_fieldstruct fs;
if (nslinesettings==NULL || fslinesettings==NULL)
  printf("ERROR in fgrinlineset: name/function stacks not initialized.\n");
else if (fp!=NULL && from>0 && to>from && pp!=NULL)
{
  *pp=(void *) malloc(sizeof(_golinesettings)); /* newgolinesettings(); */
  initfieldstruct(&fs);
  fs.fp=fp;
  fs.from=from;
  fs.to=to;
  fs.names=nslinesettings;
  fs.buf0=16;
  fs.buf=100;
  fs.where=fs.n=0;
  while (fs.where>=0 && fs.n>=0)
  {
    findfield(&fs);
    if (fs.where>0 && fs.n>0)
    {
      /* Klic ustrezne funkcije s sklada fslinesettings: */
      if (fslinesettings->n>=fs.n)
      {
        if (fslinesettings->s[fs.n]!=NULL)
          ( ( void (*) (FILE *,long,long,golinesettings) ) fslinesettings->s[fs.n] )
           (fs.fp,fs.begin+1,fs.end-1,*pp);
        else
          printf("ERROR in fgrinlineset: function to call is NULL.\n");
      } else printf("ERROR in fgrinlineset: name/function stacks not properly initialized.\n");
      fs.from=fs.end+1;
    }
  }
} else printf("ERROR in fgrinlineset: inappropriate input parameters.\n");
}

static void fgrinfillset(FILE *fp,long from,long to,void **pp)
    /* V **p prebere nastavitve za risanje zapolnjenih likov iz datoteke fp med
    mestoma from in to. Pred tem se alocira prostor za **pp. */
{
_fieldstruct fs;
if (nsfillsettings==NULL || fsfillsettings==NULL)
  printf("ERROR in fgrinfillset: name/function stacks not initialized.\n");
else if (fp!=NULL && from>0 && to>from && pp!=NULL)
{
  *pp=(void *) malloc(sizeof(_gofillsettings));  /* newgofillsettings(); */
  initfieldstruct(&fs);
  fs.fp=fp;
  fs.from=from;
  fs.to=to;
  fs.names=nsfillsettings;
  fs.buf0=16;
  fs.buf=100;
  fs.where=fs.n=0;
  while (fs.where>=0 && fs.n>=0)
  {
    findfield(&fs);
    if (fs.where>0 && fs.n>0)
    {
      /* Klic ustrezne funkcije s sklada fsfillsettings: */
      if (fsfillsettings->n>=fs.n)
      {
        if (fsfillsettings->s[fs.n]!=NULL)
          ( ( void (*) (FILE *,long,long,gofillsettings) ) fsfillsettings->s[fs.n] )
           (fs.fp,fs.begin+1,fs.end-1,*pp);
        else
          printf("ERROR in fgrinfillset: function to call is NULL.\n");
      } else printf("ERROR in fgrinfillset: name/function stacks not properly initialized.\n");
      fs.from=fs.end+1;
    }
  }
} else printf("ERROR in fgrinfillset: inappropriate input parameters.\n");
}

static void fgrintextset(FILE *fp,long from,long to,void **pp)
    /* V **pp prebere nastavitve za risanje teksta iz datoteke fp med mestoma 
    from in to. Pred tem se alocira prostor za **pp. */
{
_fieldstruct fs;
if (nstextsettings==NULL || fstextsettings==NULL)
  printf("ERROR in fgrintextset: name/function stacks not initialized.\n");
else if (fp!=NULL && from>0 && to>from && pp!=NULL)
{
  *pp=(void *) malloc(sizeof(_gotextsettings));  /* newgotextsettings(); */
  initfieldstruct(&fs);
  fs.fp=fp;
  fs.from=from;
  fs.to=to;
  fs.names=nstextsettings;
  fs.buf0=16;
  fs.buf=100;
  fs.where=fs.n=0;
  while (fs.where>=0 && fs.n>=0)
  {
    findfield(&fs);
    if (fs.where>0 && fs.n>0)
    {
      /* Klic ustrezne funkcije s sklada fstextsettings: */
      if (fstextsettings->n>=fs.n)
      {
        if (fstextsettings->s[fs.n]!=NULL)
          ( ( void (*) (FILE *,long,long,gotextsettings) ) fstextsettings->s[fs.n] )
           (fs.fp,fs.begin+1,fs.end-1,*pp);
        else
          printf("ERROR in fgrintextset: function to call is NULL.\n");
      } else printf("ERROR in fgrintextset: name/function stacks not properly initialized.\n");
      fs.from=fs.end+1;
    }
  }
} else printf("ERROR in fgrintextset: inappropriate input parameters.\n");
}

static void fgrinborders(FILE *fp,long from,long to,void **pp)
    /* V *pp se preberejo zastavice za meje veckotnika iz datoteke fp med from
    in to, pred tem se alocira prostor za ustrezno stevilo zastavic. */
{
int i;
char *flags;
long pos;
int length;
filenumto(fp,from,to,8,&pos,&length);
if (pos>0 && length>0)
{
  flags=malloc(length*sizeof(char));
  *pp=flags;
  fileread(flags,sizeof(char),length,fp,pos);
  for (i=1;i<=length;++i)
  {
    if (*flags=='0')
      *flags=0;
    else *flags=1;
    ++flags;
  }
}
}

static void fgrinmarkersize(FILE *fp,long from,long to,void **pp)
    /* V *pp se prebere velikost markerja iz datoteke fp med from
    in to, pred tem pa alocira prostor (za tip double). */
{
double *size,x;
long pos;
int length;
x=filenumto(fp,from,to,15,&pos,&length);
if (pos>0 && length>0)
{
  size=malloc(sizeof(*size));
  *size=x;
  *pp=size;
}
}

static void fgrinmarkerkind(FILE *fp,long from,long to,void **pp)
    /* V *pp se prebere vrsta markerja iz datoteke fp med from
    in to, pred tem se alocira prostor (za tip int). */
{
int *kind;
double x;
long pos;
int length;
x=filenumto(fp,from,to,15,&pos,&length);
if (pos>0 && length>0)
{
  kind=malloc(sizeof(*kind));
  *kind=(int) x;
  *pp=kind;
}
}





/* SPLOSNA FUNKCIJA ZA BRANJE LASTNOSTI KATEREGA KOLI TIPA: */


static void fgrinproperties(FILE *fp,long from,long to,void **pp)
    /* Iz datoteke fp med from in to prebere lastnost kateregakoli tipa in jo
    zapise v **p, pri cemer se alocira tudi prostor za **p. V resnici alokacijo
    in branje izvedejo funkcije, ki jih klice ta funkcija glede na vrsto
    lastnosti. Vloga te funkcije je v prenosu kazalca, ki nato kaze na dano
    lastnost. */
{
_fieldstruct fs;
if (nsproperties==NULL || fsproperties==NULL)
  printf("ERROR in fgrinproperties: name/function stacks not initialized.\n");
else if (fp!=NULL && from>0 && to>from && pp!=NULL)
{
  initfieldstruct(&fs);
  fs.fp=fp;
  fs.from=from;
  fs.to=to;
  fs.names=nsproperties;
  fs.buf0=16;
  fs.buf=100;
  fs.where=fs.n=0;
  while (fs.where>=0 && fs.n>=0)
  {
    findfield(&fs);
    if (fs.where>0 && fs.n>0)
    {
      /* Klic ustrezne funkcije s sklada fsproperties: */
      if (fsproperties->n>=fs.n)
      {
        if (fsproperties->s[fs.n]!=NULL)
          ( ( void (*) (FILE *,long,long,void **) ) fsproperties->s[fs.n] )
           (fs.fp,fs.begin+1,fs.end-1,pp);
        else
          printf("ERROR in fgrinproperties: function to call is NULL.\n");
      } else printf("ERROR in fgrinproperties: name/function stacks not properly initialized.\n");
      fs.from=fs.end+1;
    }
  }
} else printf("ERROR in fgrinproperties: inappropriate input parameters.\n");
}




/* FUNKCIJE ZA BRANJE PODATKOV ZNOTRAJ POLJA, KI PRIPADA GRAFICNEMU PRIMITIVU: */



static void fgrindoublepar(FILE *fp,long from,long to,goprimitive gp,stack extrast)
    /* Iz datoteke fp med from in to prebere gp->doublepar, pri cemer se za to
    spremenljivko tudi alocira prostor. argument extrast se ne uporablja. */
{
gp->dp=malloc(sizeof(*(gp->dp)));
freaddouble(fp,from,to,gp->dp);
}

static void fgrincoords(FILE *fp,long from,long to,goprimitive gp,stack extrast)
    /* Iz datoteke fp med from in to prebere koordinate graficnega primitiva
    gp->coord, pri cemer se alocira ves potreben prostor. */
{
gp->coord=newstack(2);
freadstcoords(fp,from,to,gp->coord);
}

static void fgrintransfcoords(FILE *fp,long from,long to,goprimitive gp,stack extrast)
    /* Iz datoteke fp med from in to prebere transformirane koordinate
    graficnega primitiva gp->transfcoord, pri cemer se alocira ves potreben
    prostor. */
{
gp->transfcoord=newstack(2);
freadstcoords(fp,from,to,gp->transfcoord);
}

static void fgrinbefore(FILE *fp,long from,long to,goprimitive gp,stack extrast)
    /* iz datoteke fp med from in to prebere, kateri graficni primitivi so
    nalozeni na sklad fp->before ter podatke o tem nalozi v posebni obliki na
    sklad extrast. Ti podatki se uporabijo v funkciji fgringroup() po branju
    vsega, kar vsebuje dana skupina graficnih objektov, za iskanje ustreznih
    primitivov in nakopicenje njihovih kazalcev na sklad gp->before. Tako je
    narejeno zato, ker se morebitni primitivi, ki so na skladu gp->before,
    preberejo sele po branju primitiva gp in v casu branja tega primitiva sploh
    se ne obstajajo. */
{
extrastruct es;
stack vals=NULL;
coord3d vp;
int i;
if (gp==NULL)
  printf("ERROR in fgrinbefore: primitive not existent.\n");
else if (extrast==NULL)
  printf("ERROR in fgrinbefore: data stack not allocated.\n");
else
{
  /* Preberejo se lokacije graficnih primitivov s funkcijo za branje koordinat: */
  vals=newstack(3);
  freadstcoords(fp,from,to,vals);
  if (vals->n<1)
    gp->before=newstack(1);
  else
  {
    gp->before=newstack(vals->n);
      for (i=1;i<=vals->n;++i)
        if ( (vp=(coord3d)vals->s[i]) !=NULL)
        {
          /* Za vsako vrednost na skladu vals se tvori struktura, ki nosi
          informacije o graficnem primitivu, mestu primitiva, ki je nalozen na
          sklad before, in o tam, da gre za sklad before; struktura se nalozi na
          sklad extrast, na katerega se nalagajo taksni podatki: */
          es=malloc(sizeof(*es));
          es->id=0;  /* ker gre za sklad before */
          es->gp=gp;
          es->gn=(int) vp->x;   /* zap. st. skupine */
          es->pn=(int) vp->y;   /* zap. st. primitiva */
          pushstack(extrast,es);
        }
  }
  if (vals!=NULL)
  {
    dispstackval(vals);
    dispstack(&vals);
  }
}
}

static void fgrinafter(FILE *fp,long from,long to,goprimitive gp,stack extrast)
    /* iz datoteke fp med from in to prebere, kateri graficni primitivi so
    nalozeni na sklad fp->after ter podatke o tem nalozi v posebni obliki na
    sklad extrast. Ti podatki se uporabijo v funkciji fgringroup() po branju
    vsega, kar vsebuje dana skupina graficnih objektov, za iskanje ustreznih
    primitivov in nakopicenje njihovih kazalcev na sklad gp->after. Tako je
    narejeno zato, ker se morebitni primitivi, ki so na skladu gp->after,
    preberejo sele po branju primitiva gp in v casu branja tega primitiva sploh
    se ne obstajajo. */
{
extrastruct es;
stack vals=NULL;
coord3d vp;
int i;
if (gp==NULL)
  printf("ERROR in fgrinafter: primitive not existent.\n");
else if (extrast==NULL)
  printf("ERROR in fgrinafter: data stack not allocated.\n");
else
{
  /* Preberejo se lokacije graficnih primitivov s funkcijo za branje koordinat: */
  vals=newstack(3);
  freadstcoords(fp,from,to,vals);
  if (vals->n<1)
    gp->after=newstack(1);
  else
  {
    gp->after=newstack(vals->n);
      for (i=1;i<=vals->n;++i)
        if ( (vp=(coord3d)vals->s[i]) !=NULL)
        {
          /* Za vsako vrednost na skladu vals se tvori struktura, ki nosi
          informacije o graficnem primitivu, mestu primitiva, ki je nalozen na
          sklad after, in o tam, da gre za sklad after; struktura se nalozi na
          sklad extrast, na katerega se nalagajo taksni podatki: */
          es=malloc(sizeof(*es));
          es->id=1;  /* ker gre za sklad after */
          es->gp=gp;
          es->gn=(int) vp->x;   /* zap. st. skupine */
          es->pn=(int) vp->y;   /* zap. st. primitiva */
          pushstack(extrast,es);
        }
  }
  if (vals!=NULL)
  {
    dispstackval(vals);
    dispstack(&vals);
  }
}
}

static void fgrinprops1(FILE *fp,long from,long to,goprimitive gp,stack extrast)
    /* Iz datoteke fp med from in to prebere gp->props1. */
{
fgrinproperties(fp,from,to,&(gp->props1));
}

static void fgrinprops2(FILE *fp,long from,long to,goprimitive gp,stack extrast)
    /* Iz datoteke fp med from in to prebere gp->props2. */
{
fgrinproperties(fp,from,to,&(gp->props2));
}

static void fgrinprops3(FILE *fp,long from,long to,goprimitive gp,stack extrast)
    /* Iz datoteke fp med from in to prebere gp->props3. */
{
fgrinproperties(fp,from,to,&(gp->props3));
}

static void fgrinprops4(FILE *fp,long from,long to,goprimitive gp,stack extrast)
    /* Iz datoteke fp med from in to prebere gp->props4. */
{
fgrinproperties(fp,from,to,&(gp->props4));
}


/* BRANJE GRAFICNEGA PRIMITIVA: */


static int count=0;

static void fgrinprimitive(FILE *fp,long from,long to,gogroup grp,
            stack primst,stack extrast)
    /* Iz datoteke fp med from in to prebere graficni primitiv ter ga nalozi na
    sklad primst, pri tem se sproti alocira ves potreben prostor. grp je kazalec
    na skupino, ki vsebuje sklad primst in se zapise v (...)->grp prebranega
    primitiva. extrast je sklad, na katerega se zapisejo morebitni podatki o
    tem, kateri primitivi so vsebovani na skladih (...)->before in (...)->after
    prebranega primitiva, da se lahko kazalci na te primitive potisnejo na ta
    sklada pozneje v funkciji fgringogroup(). */
{
_fieldstruct fs;
goprimitive ret=NULL;
if (nsprimitive==NULL || fsprimitive==NULL)
  printf("ERROR in fgrinprimitive: name/function stacks not initialized.\n");
else if (fp!=NULL && from>0 && to>from && primst!=NULL)
{
  /* Tvori se nov primitiv, ki se potisne na sklad primst: */
  ret=newgoprimitive();
  ret->grp=grp;
  pushstack(primst,(void *) ret);
  /* Najprej se prebere vrsta primitiva: */
  
  filebracto(fp,'[',']',from,to,10,&(fs.begin),&(fs.end));
  fs.begin=filenotcharto(fp,"\r\n\0 ",4,fs.begin+1,fs.end-1,3);
  if (fs.begin>0 && fs.begin+2<fs.end)
  {
    fflush(fp);
    fseek(fp,fs.begin-1,SEEK_SET);
    fscanf(fp,"%c%c%c",&(ret->i1),&(ret->i2),&(ret->i3));
  }
  initfieldstruct(&fs);
  fs.fp=fp;
  fs.from=from;
  fs.to=to;
  fs.names=nsprimitive;
  fs.buf0=16;
  fs.buf=1000;
  fs.where=fs.n=0;
  while (fs.where>=0 && fs.n>=0)
  {
    findfield(&fs);
    if (fs.where>0 && fs.n>0)
    {
      /* Klic ustrezne funkcije s sklada fsprimitive: */
      if (fsprimitive->n>=fs.n)
      {
        ++count;
        if (fsprimitive->s[fs.n]!=NULL)
          ( ( void (*) (FILE *,long,long,goprimitive,stack) ) fsprimitive->s[fs.n] )
           (fs.fp,fs.begin+1,fs.end-1,ret,extrast);
        else
          printf("%iERROR in fgrinprimitive: function to call is NULL.\n",count);
      } else printf("ERROR in fgrinprimitive: name/function stacks not properly initialized.\n");
      fs.from=fs.end+1;
    }
  }
} else printf("ERROR in fgrinprimitive: inappropriate input parameters.\n");
}

static void fgrinnullprimitive(FILE *fp,long from,long to,gogroup grp,
            stack primst,stack extrast)
    /* Na sklad primst, na katerega se sicer nalagajo prebrani graficni
    primitivi, se nalozi kazalec NULL. Nalaganje tudi nicelnih kazalcev na te
    sklade je potrebno zato, da se v vsakem primeru ohranijo zaporedne stevilke
    primitivov na skladih, brez cesar ne more brezhibno delovati povezovanje
    kazalcev na skladig (...)->before in (...)->after graficnih primitivov z
    ustreznimi primitivi na skladih (...)->extraprimitives skupin graficnih
    objektov. */
{
if (primst!=NULL)
  pushstack(primst,NULL);
else printf("ERROR in fgrinnullgroup: stack is null.\n");
}



/* FUNKCIJE ZA BRANJE PODATKOV ZNOTRAJ POLJA, KI PRIPADA SKUPINI OBJEKTOV: */


static void fgrinid(FILE *fp,long from,long to,gogroup grp,stack
            extrast)
   /* Iz datoteke fp med from in to prebere identifikacijsko stevilko skupine
   grp->id. extrast je v tej funkciji mrtev argument, ki se ne uporablja. */
{
freadint(fp,from,to,&grp->id);
}



static void fgrinname(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med from in to prebere ime skupine graf. objektov
    grp->name, pri cemer se tudi alocira prostor za ime. extrast je za to
    funkcijo mrtev argument. */
{
int length;
long pos,pos1;
pos=filenotcharto(fp," \n\r",3,from,to,3);
if (pos>0)
{
  pos1=filecharto(fp," \n\r",3,pos,to,15);
  if (pos1<=0)
    pos1=to+1;
  length=pos1-pos;
  if (length>0)
  {
    grp->name=makestring(length);
    fileread(grp->name,sizeof(char),length,fp,pos);
  }
}
}



static void fgrinlimitsset(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med from in to prebere grp->limitsset. */
{
int set;
freadint(fp,from,to,&set);
if (set==0)
  grp->limitsset=0;
else
  grp->limitsset=0;
}



static void fgrintransflimitsset(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med from in to prebere grp->transflimitsset. */
{
int set;
freadint(fp,from,to,&set);
if (set==0)
  grp->transflimitsset=0;
else
  grp->transflimitsset=0;
}



static void fgrinlimits(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med from in to prebere meje skupine graf. objektov
    ter jih zapise v grp->min in grp->max, pred tem alocira potreben prostor. */
{
stack st=NULL;
st=newstack(2);
freadstcoords(fp,from,to,st);
if (st->n>=1)
{
  grp->min=(coord3d) st->s[1];
  if (st->n>=2)
    grp->max=st->s[2];
}
if (st!=NULL)
  dispstack(&st);
}



static void fgrintransflimits(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med from in to prebere meje skupine graficnih objektov v 
    transformiranih koordinatah ter jih zapise v grp->mintransf in
    grp->maxtransf, pred tem pa se alocira potreben prostor. */
{
stack st=NULL;
st=newstack(2);
freadstcoords(fp,from,to,st);
if (st->n>=1)
{
  grp->mintransf=(coord3d) st->s[1];
  if (st->n>=2)
    grp->maxtransf=st->s[2];
}
if (st!=NULL)
  dispstack(&st);
}



static void fgrinls1(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med ftom in to prebere grp->ls1, pri cemer se alocira
    potreben prostor. */
{
fgrinproperties(fp,from,to,(void **) &(grp->ls1));
}



static void fgrinls2(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med ftom in to prebere grp->ls2, pri cemer se alocira
    potreben prostor. */
{
fgrinproperties(fp,from,to,(void **) &(grp->ls2));
}


static void fgrinfs1(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med ftom in to prebere grp->fs1, pri cemer se alocira
    potreben prostor. */
{
fgrinproperties(fp,from,to,(void **) &(grp->fs1));
}


static void fgrinfs2(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med ftom in to prebere grp->fs2, pri cemer se alocira
    potreben prostor. */
{
fgrinproperties(fp,from,to,(void **) &(grp->fs2));
}


static void fgrints1(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med ftom in to prebere grp->ts1, pri cemer se alocira
    potreben prostor. */
{
fgrinproperties(fp,from,to,(void **) &(grp->ts1));
}


static void fgrints2(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med ftom in to prebere grp->ts2, pri cemer se alocira
    potreben prostor. */
{
fgrinproperties(fp,from,to,(void **) &(grp->ts2));
}




static void fgrinmoreprimitives(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med from in to prebere primitive, ki so nalozeni na sklad
    grp->primitives, pri cemer se alocira ves potrebni prostor za sklad in
    primitive.  extrasr je sklad, na katerega se nalozijo podatki o tem, katere
    primitive vsebujejo skladi (...)->before in (...)->after prebranih
    primitivov. */
{
_fieldstruct fs;
if (nsmoreprimitives==NULL || fsmoreprimitives==NULL)
  printf("ERROR in fgrinmoreprimitives: name/function stacks not initialized.\n");
else if (fp!=NULL && from>0 && to>from && grp!=NULL)
{
  if (grp->primitives==NULL)
    grp->primitives=newstack(15);
  initfieldstruct(&fs);
  fs.fp=fp;
  fs.from=from;
  fs.to=to;
  fs.names=nsmoreprimitives;
  fs.buf0=16;
  fs.buf=100;
  fs.where=fs.n=0;
  while (fs.where>=0 && fs.n>=0)
  {
    findfield(&fs);
    if (fs.where>0 && fs.n>0)
    {
      /* Klic ustrezne funkcije s sklada fsmoreprimitives: */
      if (fsmoreprimitives->n>=fs.n)
      {
        if (fsmoreprimitives->s[fs.n]!=NULL)
          ( ( void (*) (FILE *,long,long,gogroup,stack,stack) )
            fsmoreprimitives->s[fs.n] )
             (fs.fp,fs.begin+1,fs.end-1,grp,grp->primitives,extrast);
        else
          printf("ERROR in fgrinmoreprimitives: function to call is NULL.\n");
      } else printf("ERROR in fgrinmoreprimitives: name/function stacks not properly initialized.\n");
      fs.from=fs.end+1;
    }
  }
} else printf("ERROR in fgrinmoreprimitives: inappropriate input parameters.\n");
}



static void fgrinextraprimitives(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med from in to prebere primitive, ki so nalozeni na sklad
    grp->extraprimitives, pri cemer se alocira ves potrebni prostor za sklad in
    primitive. extrasr je sklad, na katerega se nalozijo podatki o tem, katere
    primitive vsebujejo skladi (...)->before in (...)->after prebranih
    primitivov. */
{
_fieldstruct fs;
if (nsmoreprimitives==NULL || fsmoreprimitives==NULL)
  printf("ERROR in fgrinextraprimitives: name/function stacks not initialized.\n");
else if (fp!=NULL && from>0 && to>from && grp!=NULL)
{
  if (grp->extraprimitives==NULL)
    grp->extraprimitives=newstack(15);
  initfieldstruct(&fs);
  fs.fp=fp;
  fs.from=from;
  fs.to=to;
  fs.names=nsmoreprimitives;
  fs.buf0=16;
  fs.buf=100;
  fs.where=fs.n=0;
  while (fs.where>=0 && fs.n>=0)
  {
    findfield(&fs);
    if (fs.where>0 && fs.n>0)
    {
      /* Klic ustrezne funkcije s sklada fsmoreprimitives: */
      if (fsmoreprimitives->n>=fs.n)
      {
        if (fsmoreprimitives->s[fs.n]!=NULL)
          ( ( void (*) (FILE *,long,long,gogroup,stack,stack) )
            fsmoreprimitives->s[fs.n] )
             (fs.fp,fs.begin+1,fs.end-1,grp,grp->extraprimitives,extrast);
        else
          printf("ERROR in fgrinextraprimitives: function to call is NULL.\n");
      } else printf("ERROR in fgrinextraprimitives: name/function stacks not properly initialized.\n");
      fs.from=fs.end+1;
    }
  }
} else printf("ERROR in fgrinextraprimitives: inappropriate input parameters.\n");
}


/* Deklaraciji dveh funkcij, ki sta definirani pozneje, in se uporabljata v
   fgrinmoregroups(): */
static void fgringroup(FILE *fp,long from,long to,stack groups);
static void fgrinnullgroup(FILE *fp,long from,long to,stack groups);

static void fgrinmoregroups(FILE *fp,long from,long to,gogroup grp,stack extrast)
    /* Iz datoteke fp med from in to prebere skupine, ki so nalozeni na sklad
    grp->groups, pri cemer se alocira ves potrebni prostor za sklad in
    skupine graficnih objektov. */
{
_fieldstruct fs;
if (nsmoregroups==NULL || fsmoregroups==NULL)
  printf("ERROR in fgrinmoregroups: name/function stacks not initialized.\n");
else if (fp!=NULL && from>0 && to>from && grp!=NULL)
{
  if (grp->groups==NULL)
    grp->groups=newstack(5);
  initfieldstruct(&fs);
  fs.fp=fp;
  fs.from=from;
  fs.to=to;
  fs.names=nsmoregroups;
  fs.buf0=16;
  fs.buf=1000;
  fs.where=fs.n=0;
  while (fs.where>=0 && fs.n>=0)
  {
    findfield(&fs);
    if (fs.where>0 && fs.n>0)
    {
      /* Klic ustrezne funkcije s sklada fsmoregroups: */
      if (fsmoregroups->n>=fs.n)
      {
        if (fsmoregroups->s[fs.n]!=NULL)
          ( ( void (*) (FILE *,long,long,stack) )
            fsmoregroups->s[fs.n] )
             (fs.fp,fs.begin+1,fs.end-1,grp->groups);
        else
          printf("ERROR in fgrinmoregroups: function to call is NULL.\n");
      } else printf("ERROR in fgrinmoregroups: name/function stacks not properly initialized.\n");
      fs.from=fs.end+1;
    }
  }
} else printf("ERROR in fgrinmoregroups: inappropriate input parameters.\n");
}




/* BRANJE SKUPINE OBJEKTOV: */


static void fgringroup(FILE *fp,long from,long to,stack groups)
    /* Iz datoteke fp med from in to prebere skupino graficnih objektov in jo
    nalozi na sklad groups, za katerega mora biti prostor ze alociran. */
{
_fieldstruct fs;
gogroup ret=NULL;
stack extrast=NULL,st;
extrastruct es;
goprimitive gp;
gogroup gg;
int i;
if (nsgroup==NULL || fsgroup==NULL)
  printf("ERROR in fgringroup: name/function stacks not initialized.\n");
else if (fp!=NULL && from>0 && to>from && groups!=NULL)
{
  ret=newgogroup();
  pushstack(groups,(void *) ret);
  extrast=newstack(30);
  initfieldstruct(&fs);
  fs.fp=fp;
  fs.from=from;
  fs.to=to;
  fs.names=nsgroup;
  fs.buf0=16;
  fs.buf=1000;
  fs.where=fs.n=0;
  while (fs.where>=0 && fs.n>=0)
  {
    findfield(&fs);
    if (fs.where>0 && fs.n>0)
    {
      /* Klic ustrezne funkcije s sklada fsgroup: */
      if (fsgroup->n>=fs.n)
      {
        if (fsgroup->s[fs.n]!=NULL)
          ( ( void (*) (FILE *,long,long,gogroup,stack) ) fsgroup->s[fs.n] )
           (fs.fp,fs.begin+1,fs.end-1,ret,extrast);
        else
          printf("ERROR in fgringroup: function to call is NULL.\n");
      } else printf("ERROR in fgringroup: name/function stacks not properly initialized.\n");
      fs.from=fs.end+1;
    }
  }
  /* Postavitev kazalcev na skladih (...)->before in (...)->after graficnih
  primitivov nalozenih na to skupino na ustrezne primitive na skladih
  (...)->extraprimitives na tej skupini in njenih podskupinah: */
  if (extrast->n>0)
    for (i=1;i<=extrast->n;++i)
      if ( (es=(extrastruct)extrast->s[i]) !=NULL)
      {
        if (es->gp!=NULL)
        {
          /* Najde se primitiv na enem od skladov (...)->extraprimitives te
          skupine ali njenih podskupin: */
          gg=NULL; gp=NULL;
          if (es->gn==0)
            gg=ret;
          else if (es->gn>0)
          {
            if (ret->groups!=NULL)
              if (ret->groups->n>=es->gn)
                gg=(gogroup) ret->groups->s[es->gn];
          }
          if (gg==NULL)
            printf("ERROR in fgringroup: Wrong group number for extra primitive.\n");
          else
          {
            if (gg->extraprimitives!=NULL)
              if (gg->extraprimitives->n>=es->pn)
                gp=(goprimitive) gg->extraprimitives->s[es->pn];
            if (gp==NULL)
              printf("ERROR in fgringroup: Wrong primitive number for extra primitive.\n");
            else
            {
              /* Na ustrezni sklad (before ali after) primitiva es->gp se
              potisne kazalec na najdeni primitiv na (...)->extraprimitives: */
              if (es->id==0)
                st=es->gp->before;
              else
                st=es->gp->after;
              pushstack(st,(void *)gp);
            }
          }
        }
      }
  dispstackval(extrast);
  dispstack(&extrast);
} else printf("ERROR in fgringroup: inappropriate input parameters.\n");
}

static void fgrinnullgroup(FILE *fp,long from,long to,stack groups)
    /* Na sklad groups potisne kazalec NULL. Zapisovanje in branje kazalcev
    NULL pri skupinah je potrebno zato, da se ohranjajo zaporedne stevilke
    skupin na ustreznih skladih. Brez tega ni mozno pravilno povezovanje
    kazalcev na skladih (...)->before in (...)->after graficnih primitivov z
    ustreznimi primitivi na skladih (...)->extraprimitives. */
{
if (groups!=NULL)
  pushstack(groups,NULL);
else printf("ERROR in fgrinnullgroup: stack is null.\n");
}




static void initlinesettings(void)
    /* Na sklad nslinesettings potisne imena polj, ki jih lahko bere funkcija
    fgrinlineset(), na sklad fslinesettings pa ustrezne funkcije, ki jih ta
    funkcija klice za branje posameznih polj. */
{
if (nslinesettings==NULL)
  nslinesettings=newstack(4);
if (fslinesettings==NULL)
  fslinesettings=newstack(4);
pushstack(nslinesettings,colorstr);  pushstack(fslinesettings,(void *)fgrinlinecolor);
pushstack(nslinesettings,linewidthstr);  pushstack(fslinesettings,(void *)fgrinlinewidth);
pushstack(nslinesettings,linetypestr);  pushstack(fslinesettings,(void *)fgrinlinetype);
}

static void initfillsettings(void)
    /* Na sklad nsfillsettings potisne imena polj, ki jih lahko bere funkcija
    fgrinfillset(), na sklad fsfillsettings pa ustrezne funkcije, ki jih ta
    funkcija klice za branje posameznih polj. */
{
if (nsfillsettings==NULL)
  nsfillsettings=newstack(4);
if (fsfillsettings==NULL)
  fsfillsettings=newstack(4);
pushstack(nsfillsettings,colorstr);  pushstack(fsfillsettings,(void *)fgrinfillcolor);
}

static void inittextsettings(void)
    /* Na sklad nstextsettings potisne imena polj, ki jih lahko bere funkcija
    fgrintextset(), na sklad fstextsettings pa ustrezne funkcije, ki jih ta
    funkcija klice za branje posameznih polj. */
{
if (nstextsettings==NULL)
  nstextsettings=newstack(4);
if (fstextsettings==NULL)
  fstextsettings=newstack(4);
pushstack(nstextsettings,colorstr);  pushstack(fstextsettings,(void *)fgrintextcolor);
pushstack(nstextsettings,textfontstr);  pushstack(fstextsettings,(void *)fgrintextfont);
pushstack(nstextsettings,textheightstr);  pushstack(fstextsettings,(void *)fgrintextheight);
pushstack(nstextsettings,textspacingstr);  pushstack(fstextsettings,(void *)fgrintextspacing);
pushstack(nstextsettings,textexpansionstr);  pushstack(fstextsettings,(void *)fgrintextexpansion);
pushstack(nstextsettings,textalignmentstr);  pushstack(fstextsettings,(void *)fgrintextalignment);
}

static void initproperties(void)
    /* Na sklad nsproperties potisne imena polj, ki jih lahko bere funkcija
    fgrinproperties(), na sklad fsproperties pa ustrezne funkcije, ki jih ta
    funkcija klice za branje posameznih polj. */
{
if (nsproperties==NULL)
  nsproperties=newstack(4);
if (fsproperties==NULL)
  fsproperties=newstack(4);
pushstack(nsproperties,linesetstr);  pushstack(fsproperties,(void *)fgrinlineset);
pushstack(nsproperties,fillsetstr);  pushstack(fsproperties,(void *)fgrinfillset);
pushstack(nsproperties,textsetstr);  pushstack(fsproperties,(void *)fgrintextset);
pushstack(nsproperties,bordflagsstr);  pushstack(fsproperties,(void *)fgrinborders);
pushstack(nsproperties,markersizestr);  pushstack(fsproperties,(void *)fgrinmarkersize);
pushstack(nsproperties,markerkindstr);  pushstack(fsproperties,(void *)fgrinmarkerkind);
}


static void initprimitive(void)
    /* Na sklad nsprimitive potisne imena polj, ki jih lahko bere funkcija
    fgrinprimitive(), na sklad fsprimitive pa ustrezne funkcije, ki jih ta
    funkcija klice za branje posameznih polj. */
{
if (nsprimitive==NULL)
  nsprimitive=newstack(15);
if (fsprimitive==NULL)
  fsprimitive=newstack(15);
pushstack(nsprimitive,dpstr);   pushstack(fsprimitive,(void *) fgrindoublepar);
pushstack(nsprimitive,coordstr);   pushstack(fsprimitive,(void *) fgrincoords);
pushstack(nsprimitive,transfcoordstr);   pushstack(fsprimitive,(void *) fgrintransfcoords);
pushstack(nsprimitive,beforestr);   pushstack(fsprimitive,(void *) fgrinbefore);
pushstack(nsprimitive,afterstr);   pushstack(fsprimitive,(void *) fgrinafter);
pushstack(nsprimitive,props1str);   pushstack(fsprimitive,(void *) fgrinprops1);
pushstack(nsprimitive,props2str);   pushstack(fsprimitive,(void *) fgrinprops2);
pushstack(nsprimitive,props3str);   pushstack(fsprimitive,(void *) fgrinprops3);
pushstack(nsprimitive,props4str);   pushstack(fsprimitive,(void *) fgrinprops4);
}


static void initmoregroups(void)
    /* Na sklad nsmoregroups potisne imena polj, ki jih lahko bere funkcija
    fgrinmoregroups(), na sklad fsmoregroups pa ustrezne funkcije, ki jih ta
    funkcija klice za branje posameznih polj. */
{
if (nsmoregroups==NULL)
  nsmoregroups=newstack(2);
if (fsmoregroups==NULL)
  fsmoregroups=newstack(2);
pushstack(nsmoregroups,groupstr);   pushstack(fsmoregroups,(void *) fgringroup);
pushstack(nsmoregroups,nullgroupstr);   pushstack(fsmoregroups,(void *) fgrinnullgroup);
}


static void initmoreprimitives(void)
    /* Na sklad nsmoreprimitives potisne imena polj, ki jih lahko bereta
    funkciji fgrinmoreprimitives() in fgrinextraprimitives(), na sklad
    fsmoreprimitives pa ustrezne funkcije, ki jih ta funkcija klice za branje
    posameznih polj. */
{
if (nsmoreprimitives==NULL)
  nsmoreprimitives=newstack(2);
if (fsmoreprimitives==NULL)
  fsmoreprimitives=newstack(2);
pushstack(nsmoreprimitives,primitivestr);   pushstack(fsmoreprimitives,(void *) fgrinprimitive);
pushstack(nsmoreprimitives,nullprimitivestr);   pushstack(fsmoreprimitives,(void *) fgrinnullprimitive);
}


static void initgroup(void)
    /* Na sklad nsgroup potisne imena polj, ki jih lahko bere funkcija
    fgringroup(), na sklad fsgroup pa ustrezne funkcije, ki jih ta
    funkcija klice za branje posameznih polj. */
{
if (nsgroup==NULL)
  nsgroup=newstack(15);
if (fsgroup==NULL)
  fsgroup=newstack(15);
pushstack(nsgroup,identitystr);   pushstack(fsgroup,(void *) fgrinid);
pushstack(nsgroup,namestr);   pushstack(fsgroup,(void *) fgrinname);
pushstack(nsgroup,limsetstr);   pushstack(fsgroup,(void *) fgrinlimitsset);
pushstack(nsgroup,transflimsetstr);   pushstack(fsgroup,(void *) fgrintransflimitsset);
pushstack(nsgroup,limitsstr);   pushstack(fsgroup,(void *) fgrinlimits);
pushstack(nsgroup,transflimitsstr);   pushstack(fsgroup,(void *) fgrintransflimits);
pushstack(nsgroup,ls1str);   pushstack(fsgroup,(void *) fgrinls1);
pushstack(nsgroup,ls2str);   pushstack(fsgroup,(void *) fgrinls2);
pushstack(nsgroup,fs1str);   pushstack(fsgroup,(void *) fgrinfs1);
pushstack(nsgroup,fs2str);   pushstack(fsgroup,(void *) fgrinfs2);
pushstack(nsgroup,ts1str);   pushstack(fsgroup,(void *) fgrints1);
pushstack(nsgroup,ts2str);   pushstack(fsgroup,(void *) fgrints2);
pushstack(nsgroup,primitivesstackstr);   pushstack(fsgroup,(void *) fgrinmoreprimitives);
pushstack(nsgroup,extraprimitivesstackstr);   pushstack(fsgroup,(void *) fgrinextraprimitives);
pushstack(nsgroup,groupsstackstr);   pushstack(fsgroup,(void *) fgrinmoregroups);
/*
pushstack(nsgroup,);   pushstack(fsgroup,(void *) );
*/
}



static void initout(void)
    /* Na sklad nsout potisne imena polj, ki jih lahko bere funkcija
    freadgofile(), na sklad fsout pa ustrezne funkcije, ki jih ta
    funkcija klice za branje posameznih polj. */
{
if (nsout==NULL)
  nsout=newstack(6);
if (fsout==NULL)
  fsout=newstack(6);
pushstack(nsout,groupstr);   pushstack(fsout,(void *) fgringroup);
pushstack(nsout,nullgroupstr);   pushstack(fsout,(void *) fgrinnullgroup);
}



static void initialize(void)
    /* Inicializira sklade, ki v tem modulu vsebujejo imena polj v datotekah,
    kjer so zapisani graficni objekti, in sklade, ki vsebujejo naslove funkcij
    za branje teh polj. */
{
if (grinit==0)
{
  initout();
  initmoregroups();
  initmoreprimitives();
  initgroup();
  initprimitive();
  initproperties();
  inittextsettings();
  initfillsettings();
  initlinesettings();
}
}


void freadgofile(FILE *fp,long from,long to,stack *groups)
    /* Iz datoteke fp prebere graficno okolje in objekte med vkljucno from in to.
    groups je kazalec na sklad, kamor naj se nalozijo skupine graficnih objektov.
    Ce je *gogroups enak NULL, se prostor za ta sklad alocira znotraj te
    funkcije. */
{
_fieldstruct fs;
if (*groups==NULL)
  *groups=newstack(10);
if (grinit==0)
  initialize();
if (nsout==NULL || fsout==NULL)
  printf("ERROR in freadgofile: name/function stacks not initialized.\n");
else if (fp!=NULL && from>0 && to>from && groups!=NULL)
{
  initfieldstruct(&fs);
  fs.fp=fp;
  fs.from=from;
  fs.to=to;
  fs.names=nsout;
  fs.buf0=16;
  fs.buf=100;
  fs.where=fs.n=0;
  while (fs.where>=0 && fs.n>=0)
  {
    findfield(&fs);
    if (fs.where>0 && fs.n>0)
    {
      /* Klic ustrezne funkcije s sklada fsout: */
      if (fsout->n>=fs.n)
      {
        if (fsout->s[fs.n]!=NULL)
          ( ( void (*) (FILE *,long,long,stack) )
            fsout->s[fs.n] )
             (fs.fp,fs.begin+1,fs.end-1,*groups);
        else
          printf("ERROR in freadgofile: function to call is NULL.\n");
      } else printf("ERROR in freadgofile: name/function stacks not properly initialized.\n");
      fs.from=fs.end+1;
    }
  }
} else printf("ERROR in freadgofile: inappropriate input parameters.\n");

}


void filereadgofile(char *name,stack *groups)
     /* Prebere graficno okolje in objekte iz datoteke z imenom name. groups
     je kazalec na sklad, kamor naj se nalozijo skupine graficnih objektov. */
{
FILE *fp;
fp=fopen(name,"rb");
if (fp!=NULL)
  freadgofile(fp,1,flength(fp),groups);
else
  printf("ERROR in filereadgofile: can not open file.\n");
}









#endif /* defined (IGS) */
