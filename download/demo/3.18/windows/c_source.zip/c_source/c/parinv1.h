/*

	TESTIRANJE MPI - ja

*/



#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>





#include <mtypes.h>
#include <mat.h>
#include <vec.h>
#include <rand.h>
#include <min1d.h>
#include <minnd.h>
#include <st.h>
#include <strop.h>
#include <fop.h>
#include <simb.h>
#include <fint.h>
#include <titles.h>


#ifdef MPI
#include "mpi.h"
#endif


/*
#include <sys/times.h>
#include <unistd.h>
*/

/* pomozne definicije  */
#define DATASIZE  10
#define DIM1      400
#define DIM2      800
#define MAXANAL   30
#define NMAT 10


/* definicija message tag-ov */
#define PROC_INIT    1
#define PROC_READY   2
#define PROC_BUSY    3
#define PROC_DEAD    4
#define ANAL_DONE    5
#define BEGIN_DATA   11
#define END_DATA     12
#define GOT_DATA     13
#define SPEED_DATA   14
#define KILL_SELF    101
#define START_ANAL   102
#define TEST_SPEED   103
#define SEND_VEC     1001
#define SEND_MAT     1002
#define SEND_STR     1003
#define SEND_DOUBLE  1004
#define SEND_LONG    1005
#define SEND_CHAR    1006
#define MASTER       0

/*
konfiguracija virtualne masine
lamboot -v $LAMHOME/conf/config.hosts
izvajanje programa
mpirun -v myapp
*/
/* prevajas z
hcc -Ae -o parinv parinv_1.c -lmpi
*/



char *filename=NULL;
FILE *fp=NULL;




static stack procst=NULL;
static int numprocs;

static stack parameters=NULL,results=NULL;

static long longnum;
static double doublenum;
static char *str=NULL;


static procdata newprocdata(int rank)
{
procdata ret;
ret=malloc(sizeof(*ret));
memset(ret,sizeof(*ret),0);;
ret->rank=rank;
ret->id=0;
ret->busy=1;
ret->work=0;
ret->dead=0;
ret->locked=0;
ret->which=0;
ret->inpdata=NULL;
ret->resdata=NULL;
ret->lasttest=0;
ret->testtimes=NULL;
ret->lastwork=0;
ret->worktimes=NULL;
return ret;
}


/*
static void dispprocdata(procdata *proc)
{
if (proc->testtimes!=NULL)
{
  dispstaskval(proc->testtimes);
  dispstack(&(proc->testtimes));
}
if (proc->worktimes!=NULL)
{
  dispstaskval(proc->worktimes);
  dispstack(&(proc->worktimes));
}
}
*/


static void print00matrix(matrix m)
{
}

static void fprint00matrix(FILE *fp,matrix m)
{
}




#ifdef MPI
static MPI_Status refstatus;
#endif


static void sendlong(long l,int dest,int tag)
{
int n=1;
MPI_Send(&n,1,MPI_INT,dest,tag,MPI_COMM_WORLD);
MPI_Send(&l,1,MPI_LONG,dest,SEND_LONG,MPI_COMM_WORLD);
}



static void senddouble(double d,int dest,int tag)
{
int n=1;
MPI_Send(&n,1,MPI_INT,dest,tag,MPI_COMM_WORLD);
MPI_Send(&d,1,MPI_DOUBLE,dest,SEND_DOUBLE,MPI_COMM_WORLD);
}


static void sendspeeddata(double d,int dest)
{
int n=1;
MPI_Send(&n,1,MPI_INT,dest,SPEED_DATA,MPI_COMM_WORLD);
MPI_Send(&d,1,MPI_DOUBLE,dest,SEND_DOUBLE,MPI_COMM_WORLD);
}



static void sendstring(char * str,int dest,int tag)
    /* Poslje niz str na destinacijo dest, pri cemer pri prvem sporocilu, ko se
    poslje dolzina, doda privesek tag. Niz je standardni C-jevski niz, ki se
    zakljuci z znakom '\0'; protokolarna funkcija za vzporedno procesiranje.
    $A Igor avg97; */
{
#ifdef MPI
int dim;
char *data=NULL;
fprintf(fp,"\nROUTINE sendstring:\n");
fflush(fp);
if (str==NULL)
{
  dim=-1;
  MPI_Send(&dim,1,MPI_INT,dest,tag,MPI_COMM_WORLD);
} else
{
  dim=strlen(str)+1;
  fprintf(fp,"  Pre-messge: dim=%i, dest=%i, tag=%i.\n",dim,dest,tag);
  fflush(fp);
  MPI_Send(&dim,1,MPI_INT,dest,tag,MPI_COMM_WORLD);
  if (dim>0)
  {
    data=str;
    
    fprintf(fp,"  Pre-messge: dim=%i, dest=%i, tag=%i.\n",dim,dest,SEND_CHAR);
    fflush(fp);
    
    MPI_Send(data,dim,MPI_CHAR,dest,SEND_CHAR,MPI_COMM_WORLD);
  }
}
fprintf(fp,"End.\n");
#endif
}


static void receivestring(char **str,int dim,int source)
    /* Prejme niz od vira source. dim je dolzina niza brez zadnjega znaka '\0'.
    $A Igor avg97; */
{
#ifdef MPI
char *data;

fprintf(fp,"\nROUTINE receivestring, dim=%i:\n",dim);
fflush(fp);

if (dim<0)
{
  if (*str!=NULL)
    free(*str);
} else
{
  /* Ce je *str enak NULL, se niz na novo kreira: */
  if (*str==NULL)
    *str=makestring(dim);
  str[dim]='\0';
  data=*str;
  fprintf(fp,"dim=%i, source=%i\n",dim,source);
  fflush(fp);
  MPI_Recv(data,dim, MPI_CHAR,source,MPI_ANY_TAG,MPI_COMM_WORLD,&refstatus);
  fprintf(fp,"  Status: source=%i, tag=%i.\n",refstatus.MPI_SOURCE,refstatus.MPI_TAG);
  fflush(fp);
}

fprintf(fp,"End.\n");

#endif
}





static void sendvector(vector v,int dest,int tag)
    /* Poslje vsebino vektorja v na destinacijo dest, pri cemer pri prvem
    sporocilu, ko se poslje dimenzija, doda privesek tag; protokolarna funkcija
    za vzporedno procesiranje.
    $A Igor jul97; */
{
#ifdef MPI
int dim;
double *data;
fprintf(fp,"\nROUTINE sendvector:\n");
fflush(fp);
if (v==NULL)
{
  dim=-1;
  MPI_Send(&dim,1,MPI_INT,dest,tag,MPI_COMM_WORLD);
} else
{
  dim=v->d;
  fprintf(fp,"  Pre-messge: dim=%i, dest=%i, tag=%i.\n",dim,dest,tag);
  fflush(fp);
  MPI_Send(&dim,1,MPI_INT,dest,tag,MPI_COMM_WORLD);
  if (dim>0)
  {
    data=v->v;
    ++data;

    fprintf(fp,"  Pre-messge: dim=%i, dest=%i, tag=%i.\n",dim,dest,SEND_DOUBLE);
    fflush(fp);

    MPI_Send(data,dim,MPI_DOUBLE,dest,SEND_DOUBLE,MPI_COMM_WORLD);
  }
}
fprintf(fp,"End.\n");
#endif
}



static void receivevector(vector *v,int dim,int source)
{
#ifdef MPI
double *data;

fprintf(fp,"\nROUTINE receivevector, dim=%i:\n",dim);
fflush(fp);

if (dim<=0)
{
  if (*v!=NULL)
    dispvector(v);
} else
{
  /* Ce dimenzija vektorja *v ne ustreza, se najprej zbrise: */
  if (*v!=NULL)
    if ((*v)->d!=dim)
      dispvector(v);
  /* Ce je *v enak NULL, se vektor na novo kreira: */
  if (*v==NULL)
    *v=getvector(dim);
  data=(*v)->v;
  ++data;
  fprintf(fp,"dim=%i, source=%i\n",(*v)->d,source);
  fflush(fp);
  MPI_Recv(data,dim, MPI_DOUBLE,source,MPI_ANY_TAG,MPI_COMM_WORLD,&refstatus);
  fprintf(fp,"  Status: source=%i, tag=%i.\n",refstatus.MPI_SOURCE,refstatus.MPI_TAG);
  fflush(fp);
}

fprintf(fp,"End.\n");

#endif
}





static void sendmatrix(matrix m,int dest,int tag)
    /* Poslje vsebino matrike m na destinacijo dest, pri cemer pri prvem
    sporocilu, ko se posljeta dimenziji, doda privesek tag; protokolarna
    funkcija za vzporedno procesiranje.
    $A Igor jul97; */
{
#ifdef MPI
int dim[2],i;
double *data;

fprintf(fp,"\nROUTINE sendmatrix:\n");
fflush(fp);

if (m==NULL)
{
  dim[0]=dim[1]=-1;
  MPI_Send(dim,2,MPI_INT,dest,tag,MPI_COMM_WORLD);
} else
{
  dim[0]=m->d1;
  dim[1]=m->d2;

  fprintf(fp,"  Pre-messge: dim1=%i, dim2=%i, dest=%i, tag=%i.\n",dim[0],dim[1],dest,tag);
  fflush(fp);

  MPI_Send(dim,2,MPI_INT,dest,tag,MPI_COMM_WORLD);
  if (dim[0]>0 && dim[1]>0)
  {
    for (i=1;i<=dim[0]; ++i)
    {

      data=m->m[i];
      ++data;

      fprintf(fp,"  Row %i: dim1=%i, dim2=%1, dest=%i, tag=%i.\n",
       i,dim[0],dim[1],dest,SEND_DOUBLE);
      fflush(fp);

      MPI_Send(data,dim[1],MPI_DOUBLE,dest,SEND_DOUBLE,MPI_COMM_WORLD);
    }
  }
}

fprintf(fp,"End.\n");

#endif
}



static void receivematrix(matrix *m,int dim1,int dim2,int source)
{
#ifdef MPI
double *data;
int i;

fprintf(fp,"\nROUTINE receivematrix, dim1=%i, dim2=%i:\n",dim1,dim2);
fflush(fp);

if (dim1<=0 || dim2<=0)
{
  if (*m!=NULL)
    dispmatrix(m);
} else
{
  /* Ce dimenziji matrike *m ne ustrezata, se najprej zbrise: */
  if (*m!=NULL)
    if ((*m)->d1!=dim1 || (*m)->d2!=dim2)
      dispmatrix(m);
  /* Ce je *m enaka NULL, se matrika na novo kreira: */
  if (*m==NULL)
    *m=getmatrix(dim1,dim2);

  for (i=1;i<=dim1;++i)
  {
    data=(*m)->m[i];
    ++data;
    fprintf(fp,"%i. row: dim1=%i, dim2=%i, source=%i\n",i,(*m)->d1,(*m)->d2,source);
    fflush(fp);
    MPI_Recv(data,dim2, MPI_DOUBLE,source,MPI_ANY_TAG,MPI_COMM_WORLD,&refstatus);
    fprintf(fp,"  Status: source=%i, tag=%i.\n",refstatus.MPI_SOURCE,refstatus.MPI_TAG);
    fflush(fp);
  }
}

fprintf(fp,"End.\n");

#endif
}




static void probegen(int *source,int *tag)
{
#ifdef MPI
MPI_Status status;
if (*source<1)
  *source=MPI_ANY_SOURCE;
if (*tag<0)
  *tag=MPI_ANY_TAG;
MPI_Probe(*source,*tag,MPI_COMM_WORLD,&status );
*source=status.MPI_SOURCE;  *tag=status.MPI_TAG;
#endif
}





void receivegen(int *source,int *tag,int *num,long *l,double *d,vector *vec,
                 matrix *mat,char **str)
    /*
    */
{
#ifdef MPI
MPI_Status status;
*num=0;
if (*source<1)
  *source=MPI_ANY_SOURCE;
if (*tag<0)
  *tag=MPI_ANY_TAG;
MPI_Recv(num,5,MPI_INT,*source,*tag,MPI_COMM_WORLD,&status);
*source=status.MPI_SOURCE;  *tag=status.MPI_TAG;


fprintf(fp,"\nRoutine receivegen. source=%i, tag=%i.\n",*source,*tag);
fflush(fp);

switch(*tag)
{
  case SEND_LONG:
  {
    if (l!=NULL)
      MPI_Recv(l,num[0],MPI_LONG,*source,SEND_LONG,MPI_COMM_WORLD,&status);
    else
    {
      long *lp;
      lp=malloc(num[0]*sizeof(*lp));
      MPI_Recv(lp,num[0],MPI_LONG,*source,SEND_LONG,MPI_COMM_WORLD,&status);
      free(lp);
    }

    fprintf(fp,"SEND_LONG\n");

    break;
  }
  case SEND_DOUBLE:
  {
    if (d!=NULL)
      MPI_Recv(d,num[0],MPI_DOUBLE,*source,SEND_DOUBLE,MPI_COMM_WORLD,&status);
    else
    {
      double *dp;
      dp=malloc(num[0]*sizeof(*dp));
      MPI_Recv(dp,num[0],MPI_DOUBLE,*source,SEND_LONG,MPI_COMM_WORLD,&status);
      free(dp);
    }

    fprintf(fp,"SEND_DOUBLE\n");

    break;
  }
  case SPEED_DATA:
  {
    if (d!=NULL)
      MPI_Recv(d,num[0],MPI_DOUBLE,*source,SEND_DOUBLE,MPI_COMM_WORLD,&status);
    else
    {
      double *dp;
      dp=malloc(num[0]*sizeof(*dp));
      MPI_Recv(dp,num[0],MPI_DOUBLE,*source,SEND_LONG,MPI_COMM_WORLD,&status);
      free(dp);
    }

    fprintf(fp,"Inverse speed factor of process no. %i is %g.\n",*source,*d);

    fprintf(fp,"SPEED_DATA\n");

    break;
  }
  case SEND_STR:
  {
    receivestring(str,num[0],*source);

    fprintf(fp,"SEND_STR\n");

    break;
  }
  case SEND_VEC:
  {
    receivevector(vec,num[0],*source);

    fprintf(fp,"SEND_VEC\n");

    break;
  }
  case SEND_MAT:
  {
    receivematrix(mat,num[0],num[1],*source);

    fprintf(fp,"SEND_MAT\n");

    break;
  }

  /* */
  case BEGIN_DATA:
    fprintf(fp,"BEGIN_DATA\n");
    break;

  case END_DATA:
    fprintf(fp,"END_DATA\n");
    break;

  case START_ANAL:
    fprintf(fp,"START_ANAL\n");
    break;

  case KILL_SELF:
    fprintf(fp,"KILL_SELF\n");
    break;
  default:
    fprintf(fp,"OTHER_TAG\n");
    break;

}

fprintf(fp,"End receivegen.\n\n");
fflush(fp);

#endif
}


static void initpar(int *argc, char** argv[])
{
#ifdef MPI
MPI_Init(argc,argv);
#endif
}

static int myparid(void)
{
#ifdef MPI
int ret;
MPI_Comm_rank(MPI_COMM_WORLD,&ret);
return ret;
#endif
}

static int numpartasks(void)
{
#ifdef MPI
int ret;
MPI_Comm_size(MPI_COMM_WORLD,&ret);
return ret;
#endif
}


/*
static void sendkill(int id)
{
#ifdef MPI
MPI_Send(NULL,0,MPI_INT,id,KILL_SELF,MPI_COMM_WORLD);
#endif
}
*/


static void sendmessage(int dest,int message)
{
#ifdef MPI
MPI_Send(NULL,0,MPI_INT,dest,message,MPI_COMM_WORLD);

fprintf(fp,"\nMessage %i sent to process %i.\n\n",message,dest);
fflush(fp);

#endif
}


static void closepar(void)
{
#ifdef MPI
MPI_Finalize();
#endif
}




static procdata addprocdata(int rank)
{
int i;
procdata proc;
if (procst==NULL)
  procst=newstack(10);
if (rank>procst->n)
  for (i=procst->n+1;i<=rank;++i)
    pushstack(procst,NULL);
proc=newprocdata(rank);
proc->busy=0;
proc->id=rank;
procst->s[rank]=proc;
++ numprocs;
return proc;
}



static void findfreeprocs(stack freest)
{
int i;
procdata proc=NULL;
if (freest!=NULL)
{
  if (freest->n>0)
    popstackall(freest);
  if (procst!=NULL)
    if (procst->n>0)
      for (i=1;i<=procst->n;++i)
        if ((proc=procst->s[i])!=NULL)
          if (!proc->busy)
            pushstack(freest,proc);
}
}


static procdata findprocrank(int rank)
{
int i;
procdata ret=NULL,proc;
if (procst!=NULL)
  if (procst->n>0)
  {
    i=1;
    while (i<=procst->n && ret==NULL)
    {
      if ((proc=procst->s[i])!=NULL)
        if (proc->rank==rank)
          ret=proc;
      ++i;
    }
  }
return ret;
}



static void sendkillall(void)
{
int i;
procdata proc;
matrix mat=NULL;
vector vec=NULL;
int source,tag,size[5];
long longnum;
double doublenum;

fprintf(fp,"\nRoutine sendkillall.\n");
fflush(fp);

if (procst!=NULL)
  if (procst->n>0)
    for (i=1;i<=procst->n;++i)
      if ((proc=procst->s[i])!=NULL)
      {
        /* Najprej se berejo sporocila s procesa, dokler proces ni pripravljen
        na sprejem ukaza: */
        while (proc->busy)
        {
          tag=-1;
          source=proc->rank;
          receivegen(&source,&tag,size,&longnum,&doublenum,&vec,&mat,NULL);
          if (tag==PROC_READY)
            proc->busy=0;
            proc->work=0;
        }
        sendmessage(proc->rank,KILL_SELF);

        fprintf(fp,"Sent the KILL_SELF message to %i. process.\n",proc->rank);
        fflush(fp);

      }

fprintf(fp,"\nEnd sendkillall.\n");
fflush(fp);

}




static void waitprocdeaths(void)
{
procdata proc=NULL;
matrix mat=NULL;
vector vec=NULL;
int source,tag,size[5];
long longnum;
double doublenum;

fprintf(fp,"\nRoutine waitprocdeaths.\n");
fflush(fp);

while (numprocs>0)
{
  source=tag=-1;
  receivegen(&source,&tag,size,&longnum,&doublenum,&vec,&mat,NULL);
  if (tag==PROC_DEAD)
  {
    --numprocs;
    proc=findprocrank(source);
    if (proc!=NULL)
    {
      proc->work=0;
      proc->busy=1;
      proc->dead=1;

      fprintf(fp,"Received the PROC_DEAD message from %i. process.\n",proc->rank);
      fflush(fp);

    }
  }
}
fprintf(fp,"\nEnd waitprocdeaths.\n");
fflush(fp);

}




static int initialdimtestspeed=250;
static int dimtestspeed=250;

static void setspeedtestfactor(double factor)
{
double dim;
dim=(double)initialdimtestspeed;
dimtestspeed=(int)(dim*factor);
}

static double testspeed(void)
{
#ifdef MPI
double det=0,ret;
int i,j;
matrix mat;
double t1,t2;
t1=MPI_Wtime();
mat=getmatrix(dimtestspeed,dimtestspeed);
for(i=1;i<=dimtestspeed;i++)
{
  for(j=1;j<=dimtestspeed;j++)
    mat->m[i][j]=random1();
}
det=detmat(*mat);
/*
printf("Det. = %g\n",det);
*/
dispmatrix(&mat);
t2=MPI_Wtime();
ret=t2-t1;
return ret;
#else
double det=0,ret;
int i,j;
matrix mat;
time_t t1,t2;
t1=time(NULL);
mat=getmatrix(dimtestspeed,dimtestspeed);
for(i=1;i<=dimtestspeed;i++)
{
  for(j=1;j<=dimtestspeed;j++)
    mat->m[i][j]=random1();
}
det=detmat(*mat);
/*
printf("Det. = %g\n",det);
*/
dispmatrix(&mat);
t2=time(NULL);
ret=difftime(t2,t1);
return ret;
#endif
}





static jobdata newjobdata(void)
    /* Naredi nov objekt tipa _jobdata in vrne kazalec nanj. Polja objekta
    se incializirajo, tako da je objekt pripravljen za uporabo.
    $A Igor avg97; */
{
jobdata ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
ret->id=0;
ret->p=NULL;
ret->procnum=0;
ret->l=ret->d=ret->v=ret->m=NULL;
return ret;
}


static void dispjobdata(jobdata *datst)
    /* Zbrise objekt tipa jobdata. Najprej zbrise vse, kar je na skladih
    objekta **datst, potem zbrise te sklade in nazadnje sam objekt ter postavi
    *datst na NULL.
    $A Igor avg97; */
{
jobdata ds;
int i;
ds=*datst;
/* Brisanje elementov skladov: */
if (ds->l!=NULL)
{
  dispstackval(ds->l);
  dispstack(&(ds->l));
}
if (ds->d!=NULL)
{
  dispstackval(ds->d);
  dispstack(&(ds->d));
}
if (ds->v!=NULL)
{
  if ((ds->v)->n>0);
    for (i=1;i<=(ds->v)->n;++i);
      dispvector((vector *) &(ds->v->s[i]));
  dispstack(&(ds->v));
}
if (ds->m!=NULL)
{
  if ((ds->m)->n>0);
    for (i=1;i<=(ds->m)->n;++i);
      dispmatrix((matrix *) &(ds->m->s[i]));
  dispstack(&(ds->m));
}
free(*datst);
*datst=NULL;
}



/* FUNKCIJE, S KATERIMI PRENESEMO PODATKE, NA OBJEKT TIPA jobdata: */


static void putlongtojobdata(jobdata ds,long l)
    /* Na ds da stevilo tipa long l. Funkcija alocira kazalec na long, tja
    prepise l in da ta kazalec na sklad ds->l. l lahko poberemo z ds s
    funkcijo poplongfromjobdata().
    $A Igor avg97; */
{
long *lp;
if (ds!=NULL)
{
  lp=malloc(sizeof(*lp));
  *lp=l;
  if (ds->l==NULL)
    ds->l=newstack(1);
  pushstack(ds->l,lp);
}
}



static void putdoubletojobdata(jobdata ds,double d)
    /* Na ds da stevilo tipa double d. Funkcija alocira kazalec na double, tja
    prepise d in da ta kazalec na sklad ds->d. d lahko poberemo z ds s
    funkcijo popdoublefromjobdata().
    $A Igor avg97; */
{
double *dp;
if (ds!=NULL)
{
  dp=malloc(sizeof(*dp));
  *dp=d;
  if (ds->d==NULL)
    ds->d=newstack(1);
  pushstack(ds->d,dp);
}
}


static void putvectortojobdata(jobdata ds,vector v)
    /* Na ds da vektor v. v porine na sklad ds->v in nato. Z ds ga lahko
    poberemo s funkcijo popvectorfromjobdata().
    $A Igor avg97; */
{
if (ds!=NULL)
{
  if (ds->v==NULL)
    ds->v=newstack(1);
  pushstack(ds->v,v);
}
}

static void movevectortojobdata(jobdata ds,vector *v)
    /* Na ds da vektor *v. *v porine na sklad ds->v in nato *v postavi na NULL.
    v lahko poberemo z ds s funkcijo popvectorfromjobdata().
    $A Igor avg97; */
{
if (v!=NULL)
{
  putvectortojobdata(ds,*v);
  if (ds!=NULL)
    *v=NULL;
} else
  putvectortojobdata(ds,NULL);
}


static void putmatrixtojobdata(jobdata ds,matrix m)
    /* Na ds da matriko m. m porine na sklad ds->m. Z ds jo lahko poberemo s 
    funkcijo popmatrixfromjobdata().
    $A Igor avg97; */
{
if (ds!=NULL)
{
  if (ds->m==NULL)
    ds->m=newstack(1);
  pushstack(ds->m,m);
}
}


static void movematrixtojobdata(jobdata ds,matrix *m)
    /* Na ds da matriko *m. *m porine na sklad ds->m in nato *m postavi na
    NULL. m lahko poberemo z ds s funkcijo popmatrixfromjobdata().
    $A Igor avg97; */
{
if (m!=NULL)
{
  putmatrixtojobdata(ds,*m);
  if (ds!=NULL)
    *m=NULL;
} else
  putmatrixtojobdata(ds,NULL);
}


/* FUNKCIJE, S KATERIMI POBEREMO PODATKE, Z OBJEKTA  TIPA jobdata: */


static long *poplongfromjobdata(jobdata ds)
    /* Z *ds pobere kazalec na zadnje stevilo tipa long in vrne ta kazalec.
    Po izvedbi funkcije na skladu ds->l ni vec tega kazalca. Ce ne uspe najti
    kazalca, vrne NULL. Kazalec, ki ga vrne, lahko brisemo s free().
    $A Igor avg97; */
{
long *ret=NULL;
if (ds!=NULL)
  if (ds->l!=NULL)
    if (ds->l->n>0)
      ret=(long *) popstack(ds->l);
return ret;
}

static double *popdoublefromjobdata(jobdata ds)
    /* Z *ds pobere kazalec na zadnje stevilo tipa double in vrne ta kazalec.
    Po izvedbi funkcije na skladu ds->d ni vec tega kazalca. Ce ne uspe najti
    kazalca, vrne NULL. Kazalec, ki ga vrne, lahko brisemo s free().
    $A Igor avg97; */
{
double *ret=NULL;
if (ds!=NULL)
  if (ds->d!=NULL)
    if (ds->d->n>0)
      ret=(double *) popstack(ds->d);
return ret;
}

static vector popvectorfromjobdata(jobdata ds)
    /* Z *ds pobere Zadnji vektor in ga vrne. Po izvedbi funkcije na skladu
    ds->v ni vec tega vektorja. Ce ne uspe najti vektorja, vrne NULL. Vektor,
    ki ga vrne, lahko brisemo z dispvector().
    $A Igor avg97; */
{
vector ret=NULL;
if (ds!=NULL)
  if (ds->v!=NULL)
    if (ds->v->n>0)
      ret=(vector) popstack(ds->v);
return ret;
}

static matrix popmatrixfromjobdata(jobdata ds)
    /* Z *ds pobere Zadnjo matriko in jo vrne. Po izvedbi funkcije na skladu
    ds->m ni vec teg matrike. Ce ne uspe najti matrike, vrne NULL. Matriko,
    ki jo vrne, lahko brisemo z dispmatrix().
    $A Igor avg97; */
{
matrix ret=NULL;
if (ds!=NULL)
  if (ds->m!=NULL)
    if (ds->m->n>0)
      ret=(matrix) popstack(ds->m);
return ret;
}




/* FUNKCIJE, S KATERIMI DOBIMO KAZALCE NA PODATKE, NALOZENE NA
   OBJEKT TIPA jobdata: */


static long *getlongfromjobdata(jobdata ds,int num)
    /* Vrne kazalec na num-to stevilo tipa long od zadaj naprej na *ds.
    Kazalec po izvedbi funkcije ostane na skladu ds->l. Ce ne uspe najti
    kazalca, vrne NULL.
    $A Igor avg97; */
{
long *ret=NULL;
if (ds!=NULL)
  if (ds->l!=NULL)
    if (ds->l->n>0)
      ret=(long *) nstack(ds->l,num);
return ret;
}

static double *getdoublefromjobdata(jobdata ds,int num)
    /* Vrne kazalec na num-to stevilo tipa double od zadaj naprej na *ds.
    Kazalec po izvedbi funkcije ostane na skladu ds->d. Ce ne uspe najti
    kazalca, vrne NULL.
    $A Igor avg97; */
{
double *ret=NULL;
if (ds!=NULL)
  if (ds->d!=NULL)
    if (ds->d->n>0)
      ret=(double *) nstack(ds->d,num);
return ret;
}

static vector getvectorfromjobdata(jobdata ds,int num)
    /* Vrne num-ti vektor od zadaj naprej na *ds. Po izvedbi funkcije vektor
    ostane tudi na skladu ds->v. Ce ne uspe najti vektorja, vrne NULL.
    $A Igor avg97; */
{
vector ret=NULL;
if (ds!=NULL)
  if (ds->v!=NULL)
    if (ds->v->n>0)
      ret=(vector) nstack(ds->v,num);
return ret;
}

static matrix getmatrixfromjobdata(jobdata ds,int num)
    /* Vrne num-to matriko od zadaj naprej na *ds. Po izvedbi funkcije matrika
    ostane tudi na skladu ds->m. Ce ne uspe najti matrike, vrne NULL.
    $A Igor avg97; */
{
matrix ret=NULL;
if (ds!=NULL)
  if (ds->m!=NULL)
    if (ds->m->n>0)
      ret=(matrix) nstack(ds->m,num);
return ret;
}









static void sendwork(void)
{

}


static void getresults(void)
{

}




static char *pwdinfo(void)
     /* Vrne niz, ki vsebuje kombinacijo Unixovih ukazov hostname in pwd.
     Niz, ki ga vrne ta funkcija, se lahko brise s free. */
{
int buflength=200;
char *ret=NULL,*buf=NULL,*tmp=NULL,*filename=NULL;
FILE *fp;
filename=makestring(buflength-12);
filename=tmpnam(filename);
buf=malloc(buflength);
tmp=stringcat("hostname > ",filename);
system(tmp);   free(tmp);  tmp=NULL;
fp=fopen(filename,"rb");
tmp=fgets(buf,buflength,fp);
fclose(fp);
if (buf[strlen(buf)-1]=='\n' || buf[strlen(buf)-1]=='\r')
  buf[strlen(buf)-1]='\0';
ret=stringcat(buf,":");
tmp=stringcat("pwd > ",filename);
system(tmp);   free(tmp);  tmp=NULL;
fp=fopen(filename,"rb");
tmp=fgets(buf,buflength,fp);
fclose(fp);
if (buf[strlen(buf)-1]=='\n' || buf[strlen(buf)-1]=='\r')
  buf[strlen(buf)-1]='\0';
tmp=ret;
ret=stringcat(tmp,buf);
free(tmp);
tmp=stringcat("rm ",filename);
system(tmp);
free(tmp);
if (buf!=NULL)
  free(buf);
if (filename!=NULL)
  free(filename);
return ret;
}




int main(int argc, char* argv[])
{
/*
double *vec_pi,*vec_ksi;
*/
matrix matpi=NULL,matksi=NULL;
vector vec_pi=NULL,vec_ksi=NULL;
int ser_n,act_n,size[5];
char host_name[65];
float CPU_time;
int ntasks, my_stat;
int work,i,j,k;
double result;
int msgtag,msgsource,die,source,tag;
double tbegin=0,tend=0;

/*
system("hostname");
system("pwd");

printf("Stevilo argumentov: %i\n",argc);
*/


tbegin=MPI_Wtime();


if (argc<2)
{
  printf("Ni argumentov.\n");
  system("mpirun 0shema");
  exit(0);
}



initpar(&argc, &argv);
my_stat=myparid();

filename=stringcat("/home/igor/c/0rep_",stringlong(my_stat));
fp=fopen(filename,"ab");

fprintf(fp,"\n\n\n  **********\n  ZACETEK PROGRAMA\n  **********\n\n");
fprintf(fp,"Status:%i\n\n",my_stat);

fprintf(fp,"\n\nArgumenti:\n");
if (argc>0)
{
  int i;
  for (i=0;i<argc;++i)
  {
    fprintf(fp,"%i: %s\n",i,argv[i]);
    fflush(fp);
  }
  fprintf(fp,"\n");
}

fprintf(fp,"\n\n%s\n\n",pwdinfo());

fflush(fp);

if(my_stat==MASTER)
{
  
  double t0,t1;
  
  /*
  MPI_Spawn("parinv1","",1,NULL,)
  */


  char end=0;
  int nummat=0,numsent=0,numcalc=0,numloop=0;
  
  stack matrices=NULL;
  
  /*
  results=newstack(10);
  matrices=newstack(10);
  */
  
  
  t0=MPI_Wtime();

  while (! end)
  {
    
    ++numloop;
    
    t1=MPI_Wtime();
    printf("\nTIME (%i. loop): abs=%g, dif=%g.\n\n",numloop,t1,t1-t0);
    
    fprintf(fp,"\n  MASTER LOOP, %i. iteration:\n\n",numloop);
    printf("\n  MASTER LOOP, %i. iteration:\n\n",numloop);
    fflush(fp);


    /* Razposiljanje del: */
    if (numprocs>0)
    {
      
      printf("Razposiljanje del:\n");
      
      if (nummat>numsent)
      {
        stack freest=newstack(10);
        findfreeprocs(freest);
        if (freest->n>0)
        {
          procdata proc=NULL;
          i=1;
          while (i<=freest->n && nummat>numsent)
          {
            proc=freest->s[i];
            if (proc!=NULL)
              if (!(proc->busy))
              {
                matrix mattosend=NULL;
                jobdata ds;
                
                double time1,time2;
                
                time1=MPI_Wtime();
                
                
                ds=parameters->s[numsent+1];
                
                /*
                fprintf(fp,"  %i. posel.\n",numsent+1);
                fprintf(fp,"  nummat=%i\n",nummat);
                fprintf(fp,"  numsent=%i\n",numsent);
                fprintf(fp,"  ds->id=%i\n",ds->id);
                if (ds->m!=NULL)
                  fprintf(fp,"  ds->m->n=%i\n",ds->m->n);
                */
                
                
                proc->busy=1;
                proc->work=1;
                proc->which=numsent+1;
                sendmessage(proc->rank,BEGIN_DATA);
                
                /*
                sendmatrix(matrices->s[proc->which],proc->rank,SEND_MAT);
                */
                
                
                proc->inpdata=ds;
                proc->resdata=ds;
                
                mattosend=getmatrixfromjobdata(ds,1);
                
                fprintf(fp,"Matrix to be sent:\n");
                fprint00matrix(fp,mattosend);
                fflush(fp);
                
                sendmatrix(mattosend,proc->rank,SEND_MAT);
                sendmessage(proc->rank,END_DATA);
                                
                /*
                sendstring("<< Poslan bo ukaz za zacetek analize. >>",proc->rank,SEND_STR);
                */
                                
                sendmessage(proc->rank,START_ANAL);
                ++numsent;
                
                
                time2=MPI_Wtime();
                
                fprintf(fp,"Sending time for %i. matrix: %gs.\n",i,time2-time1);
                fprintf(fp,"\n\nSent %i. matrix to %i. process.\n\n",i,proc->rank);
                fflush(fp);
                
                
              }

            ++i;
          }
        }
      }
    }



    /* Inicializacija matrik: */
    if (nummat<NMAT)
    {
      jobdata ds;  /* =newjobdata(); */
      matrix mat=getmatrix(DIM1,DIM1);
      
      printf("Inicializacija %i. matrike.\n",nummat+1);
      
      if (parameters==NULL)
        parameters=newstack(10);
      if (matrices==NULL)  /* Tega sklada se v prihodnje ne bo vec uporabljajo */
        matrices=newstack(10);

      /* Nakljucna nastavitev komponent: */
      
      for(i=1;i<=DIM1;++i)
      {
        for(j=1;j<=DIM1;++j)
          mat->m[i][j]=random1();
      }
      
      
      /*
      for(j=1;j<=DIM1;j++)
        for (k=1;k<=DIM2;++k)
          mat->m[j][k]=(nummat+1)*100000+j*1000+k*100;
      */
      
      fprintf(fp,"\nInitializing %i. matrix:\n",nummat);
      fprint00matrix(fp,mat);
      fflush(fp);
      
      pushstack(matrices,mat); /* Ta stavek se bo brisal */
      
      ds=newjobdata();
      movematrixtojobdata(ds,&mat);
      pushstack(parameters,ds);
      ds->id=parameters->n;  /* Postavi se identifikac, st. podatkovne
        struktura, ki je kar njena zapovrstna stevilka */
      ++nummat;
    }



    /* Prisluskovanje procesom: */
    
    printf("Prisluskovenje procesom:\n");
    
    source=tag=-1;
    receivegen(&source,&tag,size,&longnum,&doublenum,&vec_ksi,&matksi,NULL);
    
    printf("  Sporocilo od %i. procesa, tag=%i.\n",source,tag);
    
    
    
    switch (tag)
    {
      case PROC_INIT:
      {
        procdata pd;
        pd=addprocdata(source);


        /* pd->busy=1; sendmessage(source,TEST_SPEED); */


        fprintf(fp,"\nProcess num. %i initialized.\n\n",source);
        fflush(fp);

        break;
      }
      case PROC_READY:
      {
        procdata proc=findprocrank(source);
        if (proc!=NULL)
        {
          proc->busy=0;
          proc->work=0;

          fprintf(fp,"\nProcess num. %i is ready for instructions.\n\n",source);
          fflush(fp);

        }
        break;
      }
      case PROC_BUSY:
      {
        procdata proc=findprocrank(source);
        if (proc!=NULL)
        {
          proc->busy=1;

          fprintf(fp,"\nProcess num. %i is busy.\n\n",source);
          fflush(fp);

        }
        break;
      }
      case SPEED_DATA:
      {
        fprintf(fp,"\nSpeed factor of %i. slave: %g\n",source,doublenum);
        break;
      }
      case BEGIN_DATA:
      {
        procdata pd;
        
        while (tag!=END_DATA)
        {
          tag=-1;
          receivegen(&source,&tag,size,&longnum,&doublenum,&vec_pi,&matpi,&str);
          if (tag==SPEED_DATA)
          {
            fprintf(fp,"\n%i. process: total time for analysis is %g seconds\n",source,doublenum);
          }
          if (tag==ANAL_DONE)
            ++numcalc;
        }
        
        
        /*
        fprintf(fp,"\nReceived matrix from %i. process:\n",source);
        fprint00matrix(fp,matpi);
        fflush(fp);
        printf("\nReceived matrix from %i. process:\n",source);
        print00matrix(matpi);
        */
        
        fprintf(fp,"\nReceived determinant from %i. process, value=%g.\n",
          source,doublenum);
        fflush(fp);
        printf("\nReceived determinant from %i. process, value=%g.\n",
          source,doublenum);
        
        
        pd=findprocrank(source);
        if (pd->resdata!=NULL)
        {
          jobdata ds;
          double *dp;
          ds=pd->resdata;
          /*
          movematrixtojobdata((jobdata) pd->resdata,&matpi);
          */
          putdoubletojobdata(ds,doublenum);
          
          dp=getdoublefromjobdata(ds,1);
          fprintf(fp,"Verification: det=%g.\n",*dp);
          fflush(fp);
        }
        
        sendmessage(source,GOT_DATA);
        
        break;
      }
    }


    if (numcalc>=NMAT)
      end=1;

    fprintf(fp,"\nEnd of master iteration, numcalc=%i, NMAT=%i\n ",numcalc,NMAT);

  }

  fprintf(fp,"\nEND OF MASTER LOOP.\n");
  fflush(fp);
  
  if (parameters!=NULL)
  {
    matrix matpar,matres;
    int i;
    jobdata ds;
    if (parameters->n>0)
    {
      printf("\n\n\n         REZULTATI:\n");
      fprintf(fp,"\n\n\n         REZULTATI:\n");
      for (i=1;i<=parameters->n;++i)
      {
        ds=parameters->s[i];
        if (ds!=NULL)
        {
          /*
          matres=popmatrixfromjobdata(ds);
          matpar=popmatrixfromjobdata(ds);
          printf("\n\n%i. matrika:\n",i);
          print00matrix(matres);
          fprintf(fp,"\n\n%i. matrika:\n",i);
          fprint00matrix(fp,matres);
          */
          double *det=NULL;
          det=getdoublefromjobdata(ds,1);
          printf("\n%i. determinanta: %.5g.\n",i,*det);
          fprintf(fp,"\n%i. determinanta: %.5g.\n",i,*det);
        }
      }
    }
      
      
  }
  

  sendkillall();
  waitprocdeaths();

} else
{
  /* slave code */

  int slavecount=0;

  die=0;


  /*
  sleep(my_stat);
  */
  timeinitrand();


  sendmessage(MASTER,PROC_INIT);

  while(die!=1)
  {

    ++slavecount;
    fprintf(fp,"\nSLAVE LOOP: %i. iteration.\n",slavecount);
    fflush(fp);


    msgsource=-1; msgtag=-1;
    msgsource=MASTER;
    receivegen(&msgsource,&msgtag,size,&longnum,&doublenum,&vec_pi,&matpi,&str);
    switch (msgtag)
    {
      case BEGIN_DATA:
      {
        fprintf(fp,"\n      *******************\nReceiving data from master.\n");

        while (msgtag!=END_DATA)
        {
          msgtag=-1;
          receivegen(&msgsource,&msgtag,size,&longnum,&doublenum,&vec_pi,&matpi,&str);

          fprintf(fp,"Message tag: %i.\n",msgtag);
          if (msgtag==SEND_MAT)
            fprint00matrix(fp,matpi);
          fflush(fp);

        }
        
        fprintf(fp,"Received matrix:\n");
        fprint00matrix(fp,matpi);
        fflush(fp);
        
        break;


      }
      case SEND_STR:
      {
        /*
        str=NULL;
        receivegen(&msgsource,&msgtag,size,&longnum,&doublenum,&vec_pi,&matpi,&str);
        */
        fprintf(fp,"\n\nNIZ: \"%s\".\n\n",str);
        free(str);
        str=NULL;
      }
      case START_ANAL:
      {
        double t1,t2,totaltime;
        
        matrix u,l;
        int *order;
        vector scale;
        double det;
        
        sendmessage(MASTER,PROC_BUSY);  /* To naj bi se v prihodnje opustilo!!! */
        t1=MPI_Wtime();
        /*
        for(i=1;i<=matpi->d1;i++)
          for (j=1;j<=matpi->d2;++j)
          {
            matpi->m[i][j]+=my_stat;
          }
        */
        
        l=getmatrix(matpi->d1,matpi->d2);
        u=getmatrix(matpi->d1,matpi->d2);
        order=(int *)malloc((1+matpi->d1)*sizeof(int));
        scale=getvector(matpi->d1);
        luordermat(scale,matpi,order);
        ludecompmat(scale,matpi,order);
        det=ludetmat(matpi,order);
        
        /*
        sleep((int) (10*random1()) );
        */
        
        t2=MPI_Wtime();
        totaltime=t2-t1;

        sendmessage(MASTER,BEGIN_DATA);
        sendmessage(MASTER,ANAL_DONE);
        sendspeeddata(totaltime,MASTER);
        
        /*
        sendmatrix(matpi,MASTER,SEND_MAT);
        fprintf(fp,"\nSent matrix to master. Components:\n");
        fprint00matrix(fp,matpi);
        */
        
        senddouble(det,MASTER,SEND_DOUBLE);
        fprintf(fp,"\nSent determinant to master. det= %g.\n",det);
        
        sendmessage(MASTER,END_DATA);
        
        /* Preveri se, ce master zahteva se kaksne podatke in se zahtevane
        podatke poslje: */
        do
        {
          msgsource=msgtag=-1;
          receivegen(&msgsource,&msgtag,size,&longnum,&doublenum,&vec_pi,&matpi,&str);
          switch (msgtag)
          {
          
          }
        } while (msgtag!=GOT_DATA);
        
        sendmessage(MASTER,PROC_READY);

        fprintf(fp,"        *********************\n");
        fflush(fp);

        break;
      }
      case TEST_SPEED:
      {
        sendmessage(MASTER,PROC_BUSY);  /* To naj bi se v prihodnje opustilo!!! */
        sendspeeddata(testspeed(),MASTER);
        sendmessage(MASTER,PROC_READY);
        break;
      }
      case KILL_SELF:
      {
	die=1;
	break;
      }
    }
  }

  sendmessage(MASTER,PROC_DEAD);

  /* end slave code */
}

closepar();
/*
return(0);
*/
printf("Sucessfully completed ... \n");

fprintf(fp,"Sucessfully completed ... \n");
fclose(fp);


tend=MPI_Wtime();
printf("\nCeloten porabljen cas je %g sekund.\n",tend-tbegin);


}













