#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>

#include <titles.h>



int main()
{
printf("Test izpisa naslova programa: \n");
fprogtitle0(NULL,stdout,
            "Inverse",3.4,"Beta",9,1998,
            "Igor G.", "igor@c3m.si",
            "Crnece 147", "", "2370 Dravograd",  NULL, 4,
            "http://www.c3m.si/inverse/",NULL,"e-mail:        inverse@crm.ci", 
            1, 20, 5);

printf("\n");


fprogtitle0(stdout,NULL,
            "Inverse",3.4,"Beta",10,60,
            "Igor G.", "igor@c3m.si",
            "Crnece 147", "", "2370 Dravograd",  NULL, 4,
            "http://www.c3m.si/inverse/",NULL,"e-mail:        inverse@c3m.ci", 
            10, 20, 1);

printf("\n");




fprogtitle0(stdout,NULL,
            "Inverse",3.4,"Beta",11,1,
            NULL, "igor@***********************c3m.si",
            "Crnece 147", "", "2370 Dravograd",  NULL, 4,
            "http://www.c3m.si/inverse/",NULL,"e-mail:        inverse@c3m.ci", 
            3, 20, 1);

printf("\n");



fprogtitle0(NULL,stdout,
            "Inverse",3.4,NULL,12,2000,
            "Igor Gresovnik *****@", "igor@c3m.si",
            "Crnece 147", "", "2370 Dravograd",  NULL, 4,
            "http://www.c3m.si/inverse/",NULL,"e-mail:        inverse@c3m.ci", 
            1, 20, 2);

printf("\n\n\n");

finvtitle0(stdout,NULL,"Inverse",3.5,"BEta DEMO",4,99,
           "Igor Gresovnik","igor@c3m.si",
           "Crnece 147","2370 Dravograd, Slovenia",NULL,NULL,
           "http://www.c3m.si","e-mail: inverse@c3m.si",NULL);

}

