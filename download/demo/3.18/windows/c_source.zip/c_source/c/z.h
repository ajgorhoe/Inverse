
#include <sysint.h>

# include <stdio.h>
# include <stdlib.h>
# include <string.h>

# include <mtypes.h>
# include <st.h>
# include <strop.h>
# include <t_strop.h>
# include <fop.h>
# include <mtime.h>
# include <rf.h>

#include <z.h>



main(int numargs,char **argv)
{
char *string=NULL,*key="Urslja Gora",*str=NULL,*k=NULL,*str1=NULL;
char *key1="Inverse",*k1,c1,c2;
int length,i,j,n,shift,n1,n2;

double t1,t2,t3;


str=string;
k=key;
k1=key1;


if (1) for (i=1;i<=1 || stringlength(str1)>0;++i)
{
  char *ptr,ch,*chartab,*copy;
  chartab=specchartab();
  
  printf("\n\nInsert a string (empty str. to exit)! \n");
  readstring(&str1);
  printf("\nRead string: ");
  printstrspec(str1);
  printf("\n  Ordinary form: \"%s\"",str1);
  printf("\n  Spec. seq. f.: \"%s\"",specseqstr(str1,stringlength(str1),NULL));
  printf("\n");
  
  /*
  str=str1+1;
  m_escapeseq(str,chartab,ch);
  copy=stringncopy(str1,(str-str1));
  i=ch;
  printf("\nEscape sequence \"%s\" mapped to character \'%c\' (%i).\n\n",
    copy,ch,i);
  */  
}


string=stringcopy("Optimization shell INVERSE.");

/*
printf("Character %i: \'%c\'\n",7,7);
printf("Character %i: \'%c\'\n",8,8);
printf("Character %i: \'%c\'\n",12,12);
printf("Character %i: \'%c\'\n",13,13);
printf("Character %i: \'%c\'\n",10,10);
printf("Character %i: \'%c\'\n",11,11);
printf("Character %i: \'%c\'\n",63,63);
printf("Character %i: \'%c\'\n",9,9);
exit(1);
*/

printf("string = \"%s\", key = \"%s\".\n\n",string,k);



if (1)
{

  str="0{23{56} } ";
    m_strbrac(str,'{','}',n1,n2,i,shift,string);


  n=1000000;
  t1=cputime();
  for (j=1;j<=n;++j)   /* Empty loop */
  {
  }
  t2=cputime();  t3=t2-t1;
  t1=cputime();
  for (j=1;j<=n;++j)
  {
    i=strbrac(str,'{','}',&n1,&n2);
  }
  t2=cputime();
  printf("Bracket ( %c,%c ) in \"%s\" (length %i):\nOpens at %i, closes at %i, num. embedded: %i\n"
    ,'{','}',str,strlen(str),n1,n2,i);
  printf("  Time spent for %i     (%g M) iterations:   %g s\n    (loop: %g s, total: %g s, time/loop: %g)\n\n",
    n,n/1e6,t2-t1-t3,t3,t2-t1,(t2-t1-t3)/t3);
  /*
  i=0;
  printf("\nString conversions:\n");
  str=stringcopy("\\\\ \'");
  printf("Conversion from special to ordinary: \n\"%s\" -> ",str);
  printf("\"%s\"",ordinarystr(str,&i,&str));
  printf(", length: %i\n",i);
  printf("  string after conversion: \"%s\"\n",str);
  str=stringcopy("Igor G.");
  printf("Conversion from ordinary to special: \n\"%s\" -> ",str);
  printf("\"%s\"\n",specseqstr0(str,&str));
  */
}

if (0)
{
  printf("\nUser data:\n\"%s\"\n",getuserdataintstr(NULL,NULL));
  printf("\n\n\nUser data:\n\"%s\"\n",getuserdatastr("prog","inverse","a",NULL,"pp","gg",NULL));
  printf("\n\n\nStandard user data:\n\"%s\"\n",getuserdatastandard());
}


if (0)
{
  length=5; shift=0;
  printf("Mapping to cyclic group (%i,%i):\n",length,shift);
  for (i=-20;i<=30;++i)
    printf("%5i: %4i\n",i,m_mapcyclicshift(length-2+2,shift-2+2,i-2+2));
  length=6; shift=-3;
  printf("Mapping to cyclic group (%i,%i):\n",length,shift);
  for (i=-20;i<=30;++i)
    printf("%5i: %4i\n",i,m_mapcyclicshift(length-2+2,shift-2+2,i-2+2));
  n1=22; n2=33;
  for (n2=1;n2<=20;n2=n2+1)
  {
    printf("%i+%i (=%i+%i): %i(%i)\n",n1,n2,
      m_mapcyclicshift(length-2+2,shift-2+2,n1-2+2),m_mapcyclicshift(length-2+2,shift-2+2,n2-2+2),
      m_pluscyclicshift(length-2+2,shift-2+2,n1-2+2,n2-2+2),
      m_pluscyclicshift(length-2+2,shift-2+2,m_mapcyclicshift(length-2+2,shift-2+2,n1-2+2),m_mapcyclicshift(length,shift,n2)));
  }

}


if (0)
{
  length=5; shift=0;
  printf("Mapping to cyclic group (%i,%i):\n",length,shift);
  for (i=-20;i<=30;++i)
    printf("%5i: %4i\n",i,mapcyclicshift(length,shift,i));
  length=6; shift=-3;
  printf("Mapping to cyclic group (%i,%i):\n",length,shift);
  for (i=-20;i<=30;++i)
    printf("%5i: %4i\n",i,mapcyclicshift(length,shift,i));
  n1=22; n2=33;
  for (n2=1;n2<=20;n2=n2+1)
  {
    printf("%i+%i (=%i+%i): %i(%i)\n",n1,n2,
      mapcyclicshift(length,shift,n1),mapcyclicshift(length,shift,n2),
      pluscyclicshift(length,shift,n1,n2),
      pluscyclicshift(length,shift,mapcyclicshift(length,shift,n1),mapcyclicshift(length,shift,n2)));
  }
  
  n=3000000;
  t1=cputime();
  for (i=1;i<=n;i=i+1)
  {
    j=m_pluscyclicshift(length,shift,10,i);
  }
  t2=cputime();
  printf("%i executions by macros took %g seconds.\n",n,t2-t1);
  t1=cputime();
  for (i=1;i<=n;i=i+1)
  {
    j=pluscyclicshift(length,shift,10,i);
  }
  t2=cputime();
  printf("%i executions by functions took %g seconds.\n",n,t2-t1);

}

if (0)
{
  length=5; shift=13; j=1;
  printf("Length: %i, shift: %i\n",length,shift);
  for (i=1;i<=60;++i)
  {
    j=m_mapcyclicshift(length,shift,j);
    printf("\nOriginal:      j = %i, i = %i    ",j,i);
    j=m_mapcyclicshift(length,shift,j+i);
    printf("  After sum:   j = %i, i = %i\n",j,i);
    j=m_mapcyclicshift(length,shift,j-i);
    printf("  After subt.: j = %i, i = %i\n",j,i);
    /* j=m_pluscyclicshift(length,shift,j,i); */
    ++j;
  }
}


printf("\n\n");

if (0)
{
  length=5; shift=13; j=1;
  printf("Length: %i, shift: %i\n",length,shift);
  for (i=1;i<=60;++i)
  {
    j=m_mapcyclicshift(length,shift,j);
    printf("\nOriginal:      j = %i, i = %i    ",j,i);
    j=m_pluscyclicshift(length,shift,j,i);
    printf("  After sum:   j = %i, i = %i\n",j,i);
    j=m_pluscyclicshift(length,shift,j,-i);
    printf("  After subt.: j = %i, i = %i\n",j,i);
    /* j=m_pluscyclicshift(length,shift,j,i); */
    ++j;
  }
}

printf("\n\n");

if (0)
{
  
  printf("string = \"%s\", key = \"%s\".\n\n",string,k);
  codeblocksimp100(string,strlen(string),k);
  printf("String after conversion = \"%s\". Key: %s\n\n",string,k);
  decodeblocksimp100(string,strlen(string),k);
  printf("String after decoding = \"%s\". Key: %s\n\n",string,k);
    codeblocksimp100(string,strlen(string),k);
    decodeblocksimp100(string,strlen(string),k);
  printf("String after coding and decoding = \"%s\". Key: %s\n\n",string,k);

  n=100000;
  t1=cputime();
  for (i=1;i<=n;++i)
  {
    codeblocksimp100(string,strlen(string),k);
    decodeblocksimp100(string,strlen(string),k);
  }
  t2=cputime();
  printf("String after multiple coding and decoding = \"%s\". Key: %s\n\n",string,k);
  printf("%i codings and decodings performed in %g seconds (length: %i)\n",
    n,t2-t1,strlen(string));

}



if (0)
{
  
  printf("string = \"%s\", key = \"%s\".\n\n",string,k);

  codefourstepsimp100(string,(length=strlen(string)),k);
  printf("String after the first conversion = \"%s\".\n\n",string);
  codefourstepsimp100(string,strlen(string),k);
  printf("String after the second conversion = \"%s\".\n\n",string);
  codefourstepsimp100(string,strlen(string),k);
  printf("String after the third conversion = \"%s\".\n\n",string);
  codefourstepsimp100(string,strlen(string),k);
  printf("String after the fourth conversion = \"%s\".\n\n",string);


  codetwostepsimp100(string,(length=strlen(string)),k);
  printf("String after conversion = \"%s\".\n\n",string);
  codetwostepsimp100(string,strlen(string),k);
  printf("String after the second conversion = \"%s\".\n\n",string);

  printf("string = \"%s\", key = \"%s\".\n\n",string,k);

  t1=cputime();
  codethreestepsimp100(string,(length=strlen(string)),k);
  printf("String after 1. conversion = \"%s\".\n\n",string);
  codethreestepsimp100(string,strlen(string),k);
  printf("String after 2. conversion = \"%s\".\n\n",string);
  codethreestepsimp100(string,strlen(string),k);
  t2=cputime();
  printf("String after 3. conversion = \"%s\".\n\n",string);
  printf("Total coding time: %g.\n",t2-t1);

  t1=cputime();
  n=3000;
  for (i=1;i<=n;++i)
    codefourstepsimp100(string,strlen(string),k);
  t2=cputime();
  printf("String after %i conversions = \"%s\".\n\n",n,string);
  printf("Total coding time: %g.\n",t2-t1);

}






if (0)
{

  printf("string = \"%s\", key = \"%s\".\n\n",str,k);

  codefourstepsimp100(string,(length=strlen(string)),k);
  printf("String after 1. conversion = \"%s\".\n\n",str);

  codefourstepsimp100(string,length,k);
  printf("String after 2. conversion = \"%s\".\n\n",str);

  codefourstepsimp100(string,length,k);
  printf("String after 3. conversion = \"%s\".\n\n",str);

  codefourstepsimp100(string,length,k);
  printf("String after 4. conversion = \"%s\".\n\n",str);




  printf("string = \"%s\", key = \"%s\".\n\n",str,k);

  codetwostepsimp100(string,(length=strlen(string)),k);
  printf("String after 1. conversion = \"%s\".\n\n",str);

  codetwostepsimp100(string,length,k1);
  printf("String after 2. conversion = \"%s\".\n\n",str);

  codetwostepsimp100(string,length,k1);
  printf("String after 3. conversion = \"%s\".\n\n",str);

  codetwostepsimp100(string,length,k);
  printf("String after 4. conversion = \"%s\".\n\n",str);

  codetwostepsimp100(string,length,k);
  printf("String after 5. conversion = \"%s\".\n\n",str);

}


if (0)
{

  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");
  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");
  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");
  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");
  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");
  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");
  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");
  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");
  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");
  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");
  printf("Identifikacijska stevilka racunalnika: \"%s\".\n",getmachineid("C:"));
  if (getmachineid("C:")==NULL)
    printf("NULL!\n");

}


if (0)
{
  char *data;
  data=getuserdatastandard();
  /*
  data=getuserdatainv(getmachineid(NULL));
  */
  printf("getuserdatafield0(...,program) = \"%s\"\n",getuserdatafield0(data,"program"));
  printf("getuserdatafield0(...,version) = \"%s\"\n",getuserdatafield0(data,"version"));
  printf("getuserdatafield0(...,key) = \"%s\"\n",getuserdatafield0(data,"key"));
  printf("getuserdatafield0(...,bla1) = \"%s\"\n",getuserdatafield0(data,"bla1"));
  printf("getuserdatafield0(...,bla2) = \"%s\"\n",getuserdatafield0(data,"bla2"));
}

if (0)
{
  FILE *fp;
  printf("\n0. argument: %s.\n",argv[0]);
  fp=fopen(argv[0],"ab");
  fprinttime(fp);
  fclose(fp);
}

/*
if (1)
{
  createkeyinv();
}
*/

}


