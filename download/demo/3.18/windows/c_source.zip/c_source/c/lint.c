#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include <mtypes.h>
#include <strop.h>
#include <st.h>
#include <lint.h>



                 /* VRSTICNI UKAZNI INTERPRETER */


licom newlicom(int maxlength)
    /* Vrne kazalec na objekt tipa _licom, za katerega alocira prostor. Vsa
    polja strukture postavi na 0, razen obeh skaldov, za katera se tudi
    alocira prostor, ter maxlength, kateremu se priredi argument funkcije. */
{
licom com;
com=malloc(sizeof(*com));
memset(com,0,sizeof(*com));
com->end=0;
com->buf=NULL;
com->line=NULL;
com->com=NULL;
com->param=NULL;
com->maxlength=maxlength;
com->commands=newstack(5);
com->actions=newstack(5);
com->before=NULL;
com->signal=NULL;
com->preaction=NULL;
com->unknown=NULL;
com->postaction=NULL;
com->after=NULL;
return com;
}



void displicom(licom *li)
    /* Sprosti spomin za spremenljivko **li. Zbrise tudi sklada (**li).actions
    in (**li).commands, s tem da pri skladu (**li).commands zbrise tudi vse
    nize, ki so na tem skladu (?). */
{
licom com;
if (li!=NULL)
{
  com=*li;
  if (com!=NULL)
  {
    disppointer((void **) &(com->buf));
    disppointer((void **) &(com->com));
    if (com->actions !=NULL)
      dispstack(& com->actions);
    if (com->commands!=NULL)
    {
      
      dispstackval(com->commands);
      
      dispstack(& com->commands);
    }
    free(com);
  }
  *li=NULL;
}
}




static char *pos;
static int which;
static void (*action) (licom);
static int length;

static void appendcomtool(licom com)
    /* Omogoci vstavljanje ukaza v vec vrsticah, ce je zadnji znak com->buf
    enak '\'.
    $A Igor avg01; */
{
if (com->buf!=NULL)
  if ((length=strlen(com->buf))>0)
    if (com->buf[length-1]=='\\')
    {
      char *buf1,*str=NULL,cont=1;
      buf1=malloc(com->maxlength+1);
      do
      {
        com->buf[strlen(com->buf)-1]=
        buf1[0]=0;
        gets(buf1);
        if (strlen(buf1)<1)
          cont=0;
        else if (buf1[strlen(buf1)-1]!='\\')
          cont=0;
        str=stringcat(com->buf,buf1);
        sprintf(com->buf,"%s\0",str);
        disppointer((void **) &str);
      } while (cont);
      disppointer((void **) &buf1);
      /*
      printf("command: \"%s\".\n",com->buf);
      */
    }
}

void lineinterpretbas(licom com)
    /* Osnovni korak interpretacije; Ta ukaz se lahko izvede, ko je v com->buf
    ze vrstica, ki se jo zinterpretira. Ta del ne skrbi za alokacio ali
    brisanje com->buf.
    $A Igor <== avg01; */
{
com->line=com->buf;
com->param=NULL;
pos=memnotnchr(com->buf,strlen(com->buf)," ",1);
if (pos!=NULL)
{
  com->line=pos;
  pos=strchr(pos,' ');
  if (pos!=NULL)
  {
    com->param=memnotnchr(pos,strlen(pos)," ",1);
    com->com=stringncopy(com->line,pos-com->line);
  } else com->com=stringcopy(com->line);
} else if (strlen(com->buf)>0)
{
  com->com=stringcopy(com->buf);
}
if (com->preaction!=NULL)
  com->preaction(com);
/* Izvrsitev ukaza: */
if (com->com!=NULL)
{
  which=findstack(com->commands,com->com,0,0, (int (*)(void*,void*)) cmpstrings);
  if (which>0)
  {
    action= (void (*)(licom)) com->actions->s[which];
    if (action!=NULL)
      action(com);
  } else if (cmpstrings(com->com,"")!=0)
     {
       if (com->unknown!=NULL)
         com->unknown(com);
       else
         printf("\nLINE INTERPRETER: Unrecognized command \"%s\".\n\n",com->com);
     }
}
if (com->postaction!=NULL)
  com->postaction(com);
disppointer((void **) &com->com);
}



void lineinterpret(licom com)
     /* Vrsticni interpreter za interpretacijo s standardnega vhoda. Funkcija
     bere vrstice s standardnega vhoda in izvrsuje ukaze, ki so v teh vrsticah.
     Ko se najde ukaz (1. beseda v vrstici) na skaldu com->commands, se izvrsi
     ustrezna funkcija tipa void(licom), nalozena na sladu com->actions.
       OPOMBE:
     com->com se brise s free, com->param in com->line pa ne.
     com->buf se na zacetku na novo kreira, na koncu pa se brise.
     
     $A Igor <== avg01; */
{
if (com==NULL)
   printf("LINE INTERPRETER: Interpreter not initialized.\n");
if (com->commands==NULL || com->commands->n<=0)
  printf("LINE INTERPRETER: Command list is missing.\n");
else if (com->actions==NULL || com->actions->n<=0)
  printf("LINE INTERPRETER: Action list is missing.\n");
else if (com->actions->n != com->commands->n)
  printf("LINE INTERPRETER: Number of actions is not equal to number of commands.\n");
else
{
  disppointer((void **) &com->buf);
  if (com->maxlength==0)
    com->maxlength=200;
  if (com->buf==NULL)
    com->buf=malloc(com->maxlength+1);
  if (com->before!=NULL)
    com->before(com);
  while (!com->end)
  {
    if (com->signal!=NULL)
      com->signal(com);
    /* Branje ukaza is standardnega vhoda: */
    com->buf[0]='\0';
    gets(com->buf);  /* Prebere ukaz s stand. vhoda */
    appendcomtool(com);  /* Omogoca pisanje ukazov v vec vrsticah */
    lineinterpretbas(com);
  }
  if (com->after!=NULL)
    com->after(com);
}
disppointer((void **) &com->buf);
}


void lineinterpretsavebuf(licom com)
     /* Vrsticni interpreter za interpretacijo s standardnega vhoda. Funkcija
     bere vrstice s standardnega vhoda in izvrsuje ukaze, ki so v teh vrsticah.
     Ko se najde ukaz (1. beseda v vrstici) na skaldu com->commands, se izvrsi
     ustrezna funkcija tipa void(licom), nalozena na sladu com->actions.
       OPOMBE:
     com->com se brise s free, com->param in com->line pa ne.
     com->buf se na po klicu funkcije ohrani, tudi na zacetku se ne kreira na
     novo, ce je ze alociran.
     $A Igor <== avg01; */
{
if (com==NULL)
   printf("LINE INTERPRETER: Interpreter not initialized.\n");
if (com->commands==NULL || com->commands->n<=0)
  printf("LINE INTERPRETER: Command list is missing.\n");
else if (com->actions==NULL || com->actions->n<=0)
  printf("LINE INTERPRETER: Action list is missing.\n");
else if (com->actions->n != com->commands->n)
  printf("LINE INTERPRETER: Number of actions is not equal to number of commands.\n");
else
{
  if (com->maxlength==0)
    com->maxlength=200;
  if (com->buf==NULL)
    com->buf=malloc(com->maxlength+1);
  if (com->before!=NULL)
    com->before(com);
  while (!com->end)
  {
    if (com->signal!=NULL)
      com->signal(com);
    /* Branje ukaza is standardnega vhoda: */
    gets(com->buf);  /* Prebere ukaz s stand. vhoda */
    lineinterpretbas(com);
  }
  if (com->after!=NULL)
    com->after(com);
}
}



void lineinterpretline(licom com,char *line)
    /* Izvedba ene same vrstice (line) v vrsticnem interpreterju.
      OPOMBE:
    com->buf se na koncu ne brise, prav tako se na zacetku ne ponovno alocira,
    ce je ze alociran.
    Funkcija ne preverja, ce je com razlicen od NULL, ce manjka sklad ukazov
    na com ipd.
    Funkcija tudi ne preverja, ce je com->buf alociran.
    $A Igor avg01; */
{
if (com->buf==NULL)
{
  if (com->maxlength==0)
    com->maxlength=200;
  com->buf=malloc(com->maxlength+1);
}
if (line!=NULL)
{
  sprintf(com->buf,"%s\0",line);
  lineinterpretbas(com);
}
}


void lineinterpretlines(licom com,char *lines)
    /* Izvedba vrstic, ki so v lines med sabo locene z line breaki ('\n' ali
    "\r\n") v vrsticnem interpreterju.
      OPOMBE:
    com->buf se na koncu ne brise, prav tako se na zacetku ne ponovno alocira,
    ce je ze alociran.
    Funkcija ne preverja, ce je com razlicen od NULL, ce manjka sklad ukazov
    na com ipd.
    $A Igor avg01; */
{
int ln,i;
char *copy=NULL;
if (com->buf==NULL)
{
  if (com->maxlength==0)
    com->maxlength=200;
  com->buf=malloc(com->maxlength+1);
}
if (lines!=NULL)
{
  ln=strlen(lines);
  copy=stringcopy(lines);
  for (i=0;i<ln;++i)
    if (copy[i]=='\n')
      copy[i]='\0';
  
  /* Niz lines popravi nazaj v originalno obliko */
  for (i=0;i<ln;++i)
    if (copy[i]=='\0')
      copy[i]='\n';
  disppointer((void **) &copy);
}
}



void lineinterpretline1(licom com,char *line)
     /* Vrsticni interpreter za interpretacijo ene same vrstice (line).
       OPOMBE:
     com->buf se na koncu ne brise, prav tako se na zacetku ne ponovno alocira,
     ce je ze alociran.
     Funkcija ne preverja, ce je com razlicen od NULL, ce manjka sklad ukazov
     no com ipd.
     Funkcija tudi ne preverja, ce je com->buf alociran.
     */
{
if (com->maxlength==0)
  com->maxlength=200;
if (com->buf==NULL)
  com->buf=malloc(com->maxlength+1);
lineinterpretline(com,line);
}




void instlicom(licom com,char * command,void action(licom))
    /* Na ukazno spremenljivko com, ki doloca nacin interpretacije vrstic,
    instalira nov ukaz command, ki mu pripada izvrsitev akcije action. */
{
pushstack(com->commands, (void *) command);
pushstack(com->actions, (void *) action);
}




