

          /******************************/
          /*                            */
          /*  RANDOM NUMBER GENERATION  */
          /*                            */
          /******************************/


/* Directive for using experimental generator as official - define or 
undefine approprietly:
#undef officialrandexp
 */

#include <sysint.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#include <mtime.h>  /* Because of test functions */
#include <rf.h>  /* Because of test functions */
#include <strop.h>
#include <st.h>
#include <er.h>

#include <vec.h>
#include <numut.h>

#include <rand.h>



static int prn=1;  /* Test printing flag */



  /* EXPERIMENTAL GENERATOR: */


/* Data for global experimental generator: */
static int randlockexp;  /* thread lock */
static randgenexp rgexp0=NULL;
static stack randgenstexp=NULL;



  /* MERSENNE TWISTER GENERATOR: */

/* Period parameters */  

#define N PAR_rand_mt_N
#define M 397
#define MATRIX_A 0x9908b0dfUL   /* constant vector a */
#define UPPER_MASK 0x80000000UL /* most significant w-r bits */
#define LOWER_MASK 0x7fffffffUL /* least significant r bits */


/* Data for global Mersenne twister generator: */
static int randlockmt;  /* thread lock */
static randgenmt rgmt0=NULL;
static stack randgenmtst=NULL;




  /* BASIC DATA HANDLING: */


static randgengen newrandgengen(void)
    /* Creates a gneeric random generator data structure and returns its
    address.
    $A Igor mar05; */
{
randgengen ret;
ret=calloc(1,sizeof(*ret));
ret->type=TYPE_randgengen;
ret->gentype=TYPE_randgengen;
return ret;
}



          /************************************/
          /*                                  */
          /*  USER DEFINED RANDOM GENERATORS  */
          /*                                  */
          /************************************/

/*
  NOTE on how to define and install random generator: 
  First data structure representing the generator must be defined. The first
element of the structure must always be struct _randgengen (see e.g. definition
of the type struct _randgenmt), which is by convention named bs (from "base").
  Then define the function for creating random generator data (e.g. such as
newrandgenmt) and the rest of the functions. Create a new generator data
structure, put relevant information on it (e.g. assign dynamically allocated
descriptive string to (...)->bs.name and addresses of functions that perform 
generation to elements of (...)->bs.func). Register the random generator by
calling definerandgen() with the address of the created structure (which must
be casted to type randgengen). Store the returned value, which will be used
as the generator's ID to a static variable where the data creation function can
read it. The data creation functuon must assign this generator ID to the
element (...)->bs.gentype of the structure it creates.
  It is recommended that the function for creation of generator data structure
(e.g. newmyrandgen()) assigns addresses of functions for various operations
to elements of the structure (...)->bs.func. If this is not done then using
the new generator through generic functions is a bit slower, since these must
look at the definition structure for function addresses.
  Don't forget that the function for generation of generator data structure
must assign the generator ID to (...)->bs.gentype. If checking of this type is
peformed by the generator functions then the generator should not be installed
more than once.
*/

static int lockgenerators=0 /* ,testpotential=0 */ ;
static stack generators=NULL;

static int definetesttwopartpot(void);




  /* FUNCTIONS FOR DEFINITION OF CUSTOM GENERATORS: */


int definerandgen(randgengen rg)
    /* Installs a new user defined random number generator and returns its ID.
    rg must contain all relevant data for the random generator, and it may not
    be deallocated elsewhere because rg is directly put to the stack of
    random generator definitions.
    $A Igor mar05; */
{
int i,ret=0;
randgengen pd;
m_threadlocksleep(lockgenerators,1);
if (generators==NULL)
{
  if (SUBTYPE_randgenlast>200)
  {
    errfunc0("definerandgen");
    sprintf(ers(),"Large number of pre-defined random number generators (%i) - ??\n",
       SUBTYPE_randgenlast);
    errfunc2();
  }
  generators=newstackrn(5,SUBTYPE_randgenlast+10);  /* allocate with some reserve */
  /* Add definitions of built-in generators: */
  for (i=1;i<=SUBTYPE_randgenlast;++i)
  {
    /*
    pd=generators->s[i]=newrandgengen();
    pd->subtype=i;
    */
    switch(i)
    {
      case SUBTYPE_randgenexp:
        pd=generators->s[i]=newrandgenexp();
        pd->gentype=i;
        if (pd->name!=NULL)
          pd->name=stringcopy("built in experimental random number generator");
        break;
      case SUBTYPE_randgenmt:
        pd=generators->s[i]=newrandgenmt();
        pd->gentype=i;
        if (pd->name!=NULL)
          pd->name=stringcopy("built in Mersenne twister random number generator");
        break;
    }
  }
}
if (rg==NULL)
{
  errfunc0("definerandgen");
  sprintf(ers(),"Definition structure is NULL, generator not registered.\n");
  errfunc2();
} else
{
  if (rg->type!=TYPE_randgengen)
  {
    errfunc0("definerandgen");
    sprintf(ers(),"Wrong type ID of random generator definition data %i (should be %i).\n",
        rg->type,TYPE_randgengen);
    sprintf(ers(),"Registration of random generator type will be performed anyway,\n");
    sprintf(ers(),"but this can cause program malfunction\n");
    errfunc2();
  }
  pushstack(generators,rg);
  ret=rg->gentype=generators->n;  /* ID of this random generator kind */
  m_threadunlock(lockgenerators);
  return ret;
}
return ret;
}


randgengen randgendef(int id)
    /* Returns definition data for user defined random number generator whose
    identity number is id.
    $A Igor mar05; */
{
randgengen ret=NULL;
if (generators==NULL)
{
  definerandgen(newrandgenmt());
}
m_threadlocksleep(lockgenerators,1);
if (generators!=NULL)
  if (id>0 && id<=generators->n)
    ret=generators->s[id];
m_threadunlock(lockgenerators);
return ret;
}


          /****************************************/
          /*                                      */
          /*  GENERIC RANDOM GENERATOR FUNCTIONS  */
          /*                                      */
          /****************************************/


randgengen newrandgen0(int gentype,char *description)
    /* Returns a new random number generator of the type gentype. Allocation
    and initialization is performed by the appropriate function provided for
    that type of generator.
      Pre-defined generator ID-s such as SUBTYPE_randgenmt or 
    SUBTYPE_randgenexp can be used.
      If gentype is 0 then a generator of default type is created (i.e. the
    type that is considered most appropriate for general purpose).
      If desccription is not NULL then its dynamic copiy is assigned to
    (...)->bs.name.
    $A Igor mar05; */
{
int maxtyperep=5;
static int numtyperep=0;
randgengen data=NULL,ret=NULL;
if (gentype<=0)
  gentype=SUBTYPE_randgendefault;
data=randgendef(gentype);
if (data==NULL)
{
  errfunc0("newrandgen0");
  sprintf(ers(),"No definition data for random generator of type %i.\n",gentype);
  errfunc2();
}
{
  if (data->gentype!=gentype || data->type!=TYPE_randgengen)
  {
    ++numtyperep;
    if (numtyperep<=maxtyperep)
    {
      errfunc0("newrandgen0");
      sprintf(ers(),"Wrong type of generator definition data structure.\n");
      sprintf(ers(),"Generator type: %i (requested type: %i).\n",
          data->gentype,gentype);
      sprintf(ers(),"Basic type: %i (expected: %i).\n",
          data->type,TYPE_randgengen);
      if (numtyperep==maxtyperep)
        sprintf(ers(),"Further messages of this type will be omitted.\n");
      errfunc2();
    }
  }
  if (data->gentype==gentype || data->type==TYPE_randgengen)
  {
    /* At least one among data->gentype or data->type must be correct in order
    to attempt creation of the structure. */
    if (data->func.newgen==NULL)
    {
      errfunc0("newrandgen0");
      sprintf(ers(),"Definition data for random generator type %i \n  does not contain creation function.\n",gentype);
      errfunc2();
    } else 
    {
      ret=data->func.newgen();
      if (description!=NULL)
        ret->name=stringcopy(description);
    }
  }
}
return ret;
}

randgengen newrandgen()
    /* Returns a new random number generator of the default type. Allocation
    and initialization is performed by the appropriate function provided for
    that type of generator.
    $A Igor mar05; */
{
int gentype=SUBTYPE_randgendefault;
randgengen data,ret;
char *description=NULL;
data=randgendef(gentype);
if (data!=NULL)
  description=data->name;
ret=newrandgen0(gentype,description);
return ret;
}


void disprandgen(randgengen *rg)
    /* Deallocates the random generator structure pointed to by *rg and sets
    *rg to NULL.
    $A Igor mar05; */
{
if (rg!=NULL) if (*rg!=NULL)
{
  if ((*rg)->type!=TYPE_randgengen)
  {
    errfunc0("disprandgen");
    sprintf(ers(),"Random generator structure: incorrect type %i (should be %i).\n",
        (*rg)->type,TYPE_randgengen);
    errfunc2();
  }
  if ((*rg)->func.dispgen!=NULL)
    (*rg)->func.dispgen(rg);
  else
  {
    randgengen data;
    data=randgendef((*rg)->gentype);
    if (data!=NULL)
      if (data->func.dispgen!=NULL)
        data->func.dispgen(rg);
  }
  *rg=NULL;
}
}

unsigned long seedrandgen(randgengen rg,unsigned long seed)
    /* Initializes random generator rg by the seed. If two generators of the
    same type are initialized by the same seed then they should generate the
    same sequences.
    $A Igor mar05; */
{
unsigned long ret=0;
if (rg!=NULL)
{
  if (rg->type!=TYPE_randgengen)
  {
    errfunc0("seedrandgen");
    sprintf(ers(),"Random generator structure: incorrect type %i (should be %i).\n",
        rg->type,TYPE_randgengen);
    errfunc2();
  }
  if (rg->func.seed!=NULL)
    ret=rg->func.seed(rg,seed);
  else
  {
    /* function is not specified on the structure, look at generator
    definition data: */
    randgengen data;
    data=randgendef(rg->gentype);
    if (data!=NULL) 
      if (data->func.seed==NULL) 
        data=NULL;
    if (data==NULL)
    {
      errfunc0("seedrandgen");
      sprintf(ers(),"Could not locate the function to perform the task on the\nrandom generator definition data.\n");
      errfunc2();
    } else
      ret=data->func.seed(rg,seed);
  }
} else
{
  errfunc0("seedrandgen");
  sprintf(ers(),"The generator is NULL.\n");
  errfunc2();
}
return ret;
}


unsigned long seedrandgentime(randgengen rg,unsigned long seed)
    /* Initializes random generator rg semi-randomly by using the current 
    system and CPU time and by the seed.
    $A Igor mar05; */
{
unsigned long ret=0;
if (rg!=NULL)
{
  if (rg->type!=TYPE_randgengen)
  {
    errfunc0("seedrandgentime");
    sprintf(ers(),"Random generator structure: incorrect type %i (should be %i).\n",
        rg->type!=TYPE_randgengen);
    errfunc2();
  }
  if (rg->func.seedrandtime!=NULL)
    ret=rg->func.seedrandtime(rg,seed);
  else
  {
    /* function is not specified on the structure, look at generator
    definition data: */
    randgengen data;
    data=randgendef(rg->gentype);
    if (data!=NULL) 
      if (data->func.seedrandtime==NULL) 
        data=NULL;
    if (data==NULL)
    {
      errfunc0("seedrandgentime");
      sprintf(ers(),"Could not locate the function to perform the task on the\nrandom generator definition data.\n");
      errfunc2();
    } else
      ret=data->func.seedrandtime(rg,seed);
  }
} else
{
  errfunc0("seedrandgentime");
  sprintf(ers(),"The generator is NULL.\n");
  errfunc2();
}
return ret;
}



unsigned long seedrandgenrand(randgengen rg,unsigned long seed)
    /* Randomly initializes the random generator rg; The initialization is
    uncorrelated among successive calls within the same process and among
    calls within different programs, even if they were called at the same time.
    seed is additional perturbation used in initialization and can be set to 0
    without affecting too much the behavior (otherwise, it can be some random
    number previously calculated).
    $A Igor mar05; */
{
unsigned long ret=0;
if (rg!=NULL)
{
  if (rg->type!=TYPE_randgengen)
  {
    errfunc0("seedrandgenrand");
    sprintf(ers(),"Random generator structure: incorrect type %i (should be %i).\n",
        rg->type,TYPE_randgengen);
    errfunc2();
  }
  if (rg->func.seedrandrand!=NULL)
    ret=rg->func.seedrandrand(rg,seed);
  else
  {
    /* function is not specified on the structure, look at generator
    definition data: */
    randgengen data;
    data=randgendef(rg->gentype);
    if (data!=NULL) 
      if (data->func.seedrandrand==NULL) 
        data=NULL;
    if (data==NULL)
    {
      errfunc0("seedrandgenrand");
      sprintf(ers(),"Could not locate the function to perform the task on the\nrandom generator definition data.\n");
      errfunc2();
    } else
      ret=data->func.seedrandrand(rg,seed);
  }
} else
{
  errfunc0("seedrandgenrand");
  sprintf(ers(),"The generator is NULL.\n");
  errfunc2();
}
return ret;
}



unsigned long randintgen(randgengen rg,unsigned long max)
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    current state of rg (which can be initialised by seedrandgen() or some
    other function).
    $A Igor mar05; */
{
unsigned long ret=0;
if (rg!=NULL)
{
  if (rg->type!=TYPE_randgengen)
  {
    errfunc0("randintgen");
    sprintf(ers(),"Random generator structure: incorrect type %i (should be %i).\n",
        rg->type,TYPE_randgengen);
    errfunc2();
  }
  if (rg->func.randint!=NULL)
    ret=rg->func.randint(rg,max);
  else
  {
    /* function is not specified on the structure, look at generator
    definition data: */
    randgengen data;
    data=randgendef(rg->gentype);
    if (data!=NULL) 
      if (data->func.randint==NULL) 
        data=NULL;
    if (data==NULL)
    {
      errfunc0("randintgen");
      sprintf(ers(),"Could not locate the function to perform the task on the\nrandom generator definition data.\n");
      errfunc2();
    } else
      ret=data->func.randint(rg,max);
  }
} else
{
  errfunc0("randintgen");
  sprintf(ers(),"The generator is NULL.\n");
  errfunc2();
}
return ret;
}



double randgen(randgengen rg)
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    the current state of rg (which can be initialised by seedrandbasmt).
    $A Igor mar05; */
{
double ret=0;
if (rg!=NULL)
{
  if (rg->type!=TYPE_randgengen)
  {
    errfunc0("randgen");
    sprintf(ers(),"Random generator structure: incorrect type %i (should be %i).\n",
        rg->type,TYPE_randgengen);
    errfunc2();
  }
  if (rg->func.rand!=NULL)
    ret=rg->func.rand(rg);
  else
  {
    /* function is not specified on the structure, look at generator
    definition data: */
    randgengen data;
    data=randgendef(rg->gentype);
    if (data!=NULL) 
      if (data->func.rand==NULL) 
        data=NULL;
    if (data==NULL)
    {
      errfunc0("randgen");
      sprintf(ers(),"Could not locate the function to perform the task on the\nrandom generator definition data.\n");
      errfunc2();
    } else
      ret=data->func.rand(rg);
  }
} else
{
  errfunc0("randgen");
  sprintf(ers(),"The generator is NULL.\n");
  errfunc2();
}
return ret;
}
 


          /*************************/
          /*                       */
          /*  RANDOM PERMUTATIONS  */
          /*                       */
          /*************************/

void randperm(randgengen rg,int n,indtab *addrit)
    /* Generates a random permutation of length n and stores it in *it (which
    is re-allocated if necessary). Permutations are generated by equal 
    probability (1/n!).
    The algorithm is Knutt Shuffle: the identity permutation is generated first.
    Then, for positions 1 through n-1, each element is swapped by a randomly 
    chosen element from the set i to n (inclusivelly).
    $A Igor dec05; */
{
int i,rest,which,store;
indtab it;
/* Reallocate the index table if necessary: */
resizeindtab(addrit,0,0,n);
it=*addrit;
/* Create identity permutation: */
for (i=1;i<=n;++i)
  it->t[i]=i;
rest=n-1;
for (i=1;i<n;++i)
{
  /* Randomly determine the element to be swapped with the current one: */
  which=randintgen(rg,rest);
  if (which>0)
  {
    which+=i;  /* candidate elements are from i to n, inclusively */
    /* swap the elements i and which: */
    store=it->t[i];
    it->t[i]=it->t[which];
    it->t[which]=store;
  }
  --rest;
}
}



          /************************************/
          /*                                  */
          /*  DIFFERENT RANDOM DISTRIBUTIONS  */
          /*                                  */
          /************************************/


    /* NORMAL DISTRIBUTION: standard (0,1) and parametric (mean,sigma) */


double randgennormstd(randgengen rg)
    /* Returns a normally distributed random number with mean value 0 and
    standard deviation 1, generated by using rg. Box-Miller transform is
    used (Ref. Wikipedia).
      The number of rejected generations is added to rg->rejected.
    $A Igor mar05; */
{
double r,x,y,fac,rn;
if (rg==NULL)
{
  errfunc0("randgennormstd");
  sprintf(ers(),"Random generator is NULL, global generator will be used instead.\n");
  errfunc2();
} else
{
  do  /* find a random point in unit circle in the plane */
  {
    x=2.0*randgen(rg)-1.0;
    y=2.0*randgen(rg)-1.0;
    r=x*x+y*y;
    ++rg->rejected;
  } while (r>1 || r==0);
  --rg->rejected;
  fac=sqrt(-2*log(r)/r);  /* Box-Muller transform */
  rn=x*fac;
}
return(rn);
}


double randgennorm(randgengen rg,void *clientdata)
    /* Returns a normally (Gaussian) distributed random number generated by
    using rg. 
      If clientdata is NULL then the distribution with mean value 0 and 
    standard deviation 1 is returned. Otherwise, clientdata must point to a
    table of two numbers of type double (offset 0), which define the mean
    and the standard deviation.
      The number of rejected generations is added to rg->rejected.
    $A Igor mar05; */
{
double ret,mean=0,sigma=0,*dptr;
if (rg==NULL)
{
  errfunc0("randgennormstd");
  sprintf(ers(),"Random generator is NULL, global generator will be used instead.\n");
  errfunc2();
} else
{
  ret=randgennormstd(rg);
  if ((dptr=clientdata)!=NULL)
  {
    mean=dptr[0];
    sigma=dptr[1];
    ret*=sigma;
    ret+=mean;
  }
}
return ret;
}



double densfuncnorm(double x,void *clientdata)
    /*  Normal probability density. If cd!=NULL it must point to a table of two
    numbers of type double, which represent the distribution mean value and
    standard deviation, respectively. Otherwise dens. of standard normal dist.
    is returned (mean 0, std. dev. 1).
      The density is normalized (integral from - to + infinity is 1).
    $A Igor mar05; */
{
double ret,mean=0,sigma=1,*dptr;
if ((dptr=clientdata)!=NULL)
{
  mean=dptr[0];
  sigma=dptr[1];
  ret=densfuncnorm((x-mean)/sigma,NULL)/sigma;
} else
  ret=exp(-m_sqr((x-mean)/(sigma*sqrt(2)))) / (sqrt(2.0*ConstPi)) ;
return ret;
}


double densfuncnormstd(double x)
    /*  Standard normal probability distribution (mean 0 and std. deviation 1)
   density function.
    The density is normalized (integral from - to + infinity is 1).
    $A Igor mar05; */
{
return densfuncnorm(x,NULL);
}


  /* Uniform distribution related functions: */

double constdistgenpar(randgengen rg,void *clientdata)
    /* Returns an uniformly distributed random number in the interval [0,1]. 
    clientdata is ignored.
    $A Igor mar05; */
{

return randgen(rg);
}


static double densfuncconstdist01(double x,void *cd)
    /* Constant probability density on [0,1], 0 elsewhere, normalized.
    $A Igor mar05; */
{
if (x>=0 && x<=1)
  return 1;
else
  return 0;
}



static double densfuncconstdist(double x,void *cd)
    /* Constant probability density everywhere; not normalized (actually it can
    not be normalized and is used only for testing).
    $A Igor mar05; */
{
return 1;
}




    /* CO-ORDINATE DISTRIBUTION IN A UNIT HYPERBAL */


double randgenhyperballcoord(randgengen rg,int *n)
    /* Returns a random number whose probability distribution corresponds to
    probability distribution with respect to given co-ordinate of points that
    are uniformly distributed in 0 centered unit ball in R^(n+1).
      The pdf (density function) is proportional to (1-x^2)^(n/2) on [-1,1].
    Instances are generated by the rejection method.
      The number of rejected generations is added to rg->rejected.
    $A Igor mar05; */
{
double ret=0,decide;
int accepted=0;
if (rg==NULL || n==NULL || *n<0)
{
  rg->generror=-1;
  errfunc0("randgenhyperballcoord");
  if (rg==NULL)
    sprintf(ers(),"Random generator is NULL.\n");
  else if (n==NULL)
  {
    sprintf(ers(),"Dimension is not specified (NULL pointer).\n");
  } else if (*n<0)
  {
    sprintf(ers(),"Wrong dimension parameter n=dim-1 %i, defined only for n>=0.\n",n);
  }
  errfunc2();
} else
{
  while (!accepted)
  {
    ret=2.*randgen(rg)-1.;
    decide=randgen(rg);
    if (decide<=pow(1-ret*ret,(double) (*n/2)))
      accepted=1;
    else
      ++rg->rejected;
  }
}
return ret;
}



double densfunchyperballcoord1(double x,int *n)
    /* Returns non-normalized probability density function that corresponds to
    probability distribution with respect to given co-ordinate of points that
    are uniformly distributed in 0 centered unit ball in R^dim, namely
      1-x^2)^(dim/2) on [-1,1], 0 elsewhere.
    Values are not normalized an 0 -> 1.
    $A Igor mar05; */
{
if (n==NULL)
{
  errfunc0("randgenhyperballcoord1");
  sprintf(ers(),"Dimension is not specified (NULL pointer).\n");
  errfunc2();
  return 0;
} else if (*n<0)
{
  errfunc0("randgenhyperballcoord1");
  sprintf(ers(),"Wrong family parameter n = %i, should be n>=0.\n",*n);
  errfunc2();
  return 0;
} else
{
  if (-1<=x && x<=1)
  {
    if (*n==0)
      return 1;
    else
      return pow(1-x*x,((double) *n/2.));
  }
  else
    return 0;
}
}

static double normfacthyperballcoord(int n)
    /* Returns normalization factor for densfunchyperballcoord(), i.e.
    1 over integral of the function from -1 to 1.
    $A Igor mar05; */
{
double ret;
if (n<0)
{
  errfunc0("normfacthyperballcoord");
  sprintf(ers(),"Wring family parameter n=%i, defined only for n>=0.\n",n);
  errfunc2();
  return 0;
} else
{
  if (n==0)
    ret=0.5;
  if (n==1)
    ret=0.5*ConstPi;
  else if (n==2)
    ret=4./3.;
  else if (n==3)
    ret=3.*ConstPi/8.;
  else if (n==4)
    ret=16./15.;
  else
  {
    double factor;
    int i,m;
    if (n%2==0)
    {
      m=n/2;
      ret=1;
      for (i=1;i<=2*m+2;++i)
      {
        factor=1.;
        if (i<=m)
          factor*=(double) i;  /* assemble m! */
        if (i<=m+1)
          factor*=(double) i;  /* assemble (m+1)! */
        factor*=2.;            /* assemble 2^(2*m+2) */
        factor/=(double) i;    /* assemble 1/(2*m+2)! */
        ret*=factor;
      }
    } else
    {
      m=(n-1)/2;
      ret=ConstPi;
      for (i=1;i<=2*m+2;++i)
      {
        factor=1.;
        factor*=(double) i;               /* assemble (2*m+2)! */
        if (i<=m+1)
          factor/=(double) i*(double) i;  /* assemble  1/((m+1)!)^2 */
        factor/=2.;                    /* assemble 1/2^(2*m+2) */
        ret*=factor;
      }
    }
  }
}
return 1./ret;
}


double densfunchyperballcoord(double x,int *dim)
    /* The same as densfunchyperballcoord1, but normalized such that integral
    from -1 to 1 (and over all real number) is 1.
    $A Igor mar05; */
{
double norm;
if (dim==NULL)
{
  errfunc0("randgenhyperballcoord");
  sprintf(ers(),"Dimension is not specified (NULL pointer).\n");
  errfunc2();
  return 0;
} else
{
  if (-1<=x && x<=1)
  {
    norm=1;
    return pow(1-x*x,((double) *dim/2.))/norm;
  } else
    return 0;
}
}





          /***************************************/
          /*                                     */
          /*  TESTS OF RANDOM NUMBER GENERATION  */
          /*                                     */
          /***************************************/


    /* TESTING PROBABILITY DISTRIBUTIONS: */

double inspranddist(randgengen rg,double from,double to,int n,int numint,
          int numgen,
          double distgen(randgengen rg,void *cd),void *distdata,
          double densfunc(double x,void *cd),void *funcdata)
    /* This function tests whether the generator distgen actually generates
    random numbers with expected probability distribution. Test is performed
    by generating numgen random numbers, checks how many of them falls into
    n intervals between from and to, and compares the counted hits with
    expected. The function returns average relative discrepancy between
    expected and counted number.
      rg is the random generator used for generation.
      from, to and n define the limits and number of equidistand test intervals.
      numgen is the total number of generations.
      distgen is the function for generating random numbers with specific
    probability distribution, which takes the random generator and definition
    data as arguments.
      distdata is the definition data for random distribution (e.g. average
    and standard deviation for Gauss distribution)
      densfunc must be a function whose returned values are proportional to
    the probability density of the distribution, which takes the value of
    independent variable and additional definition data as arguments.
      funcdata is the definition data for densfunc.
    $A Igor mar05; */
{
double ret=0,sumint=0,step,rn;
int allhits=0,i=0,j=0,found;
vector intlim=NULL,  /* Interval limits */
  expect=NULL,       /* Expected probability for hitting individual interval
            at condition that interval [from,to] was hit (hit ratio) */
  hitratios=NULL,  /* achieved hit ratios */
  hitsigma=NULL,   /* expected stand. dev. of hit ratios */
  normer,           /* relative errors (should be close to sqrt(numhits) */
  reler;           /* relative errors divided by expected (should be close to 1) */
indtab numhits=NULL; /* Counter of hits */
if (n<1)
  n=4;
if (numint<4)
  numint=10;
if (numgen<10*numint)
  numgen=10*numint;
intlim=getvector(n+1);
expect=getvector(n);
hitratios=getvector(n);
hitsigma=getvector(n);
normer=getvector(n);
reler=getvector(n);
numhits=newindtabrn(2,n);
step=(to-from)/((double) n);
intlim->v[1]=from;
for (i=1;i<=n;++i)
{
  intlim->v[i+1]=from+i*step;
  numhits->t[i]=0;
}
printf("\nTTEST OF PROBABILITY DISTRIBUTION: %i subintervals of [%g,%g],\n",
       n,from,to);
printf("%i random generations, numerical integration %i points/interval\n",
       numgen,numint);
printf("\nInterval endpoints:\n"); printvectorlist(intlim); printf("\n\n");
printf("Values of density function at interval endpoints:\n");
for (i=1;i<=n;++i)
  expect->v[i]=densfunc(intlim->v[i],funcdata);
printvectorlist(expect); printf("\n");
/* Calculate the expected relative numbers of hits for intervals: */
sumint=0;
for (i=1;i<=n;++i)
{
  sumint+=(  expect->v[i]=intsimp0(densfunc,funcdata,intlim->v[i],
          intlim->v[i+1],numint) );
}
for (i=1;i<=n;++i)
  expect->v[i]/=sumint;  /* norm expected hit ratio */
for (i=1;i<=numgen;++i)
{
  rn=distgen(rg,distdata);  /* generate next num. */
  if (rn>=from && rn<=to)
  {
    ++allhits;
    found=0;
    for (j=1;!found && j<=n;++j)
      if (rn<=intlim->v[j+1]) /* must be <= sign, otherwise change procedure! */
      {
        found=1;
        ++numhits->t[j];
      }
  }
}
if (allhits==0)
{
  errfunc0("inspranddist");
  sprintf(ers(),"No hits achieved in the interval [%g,%g] in %i generations.\n",
    from,to,numgen);
  errfunc2();
  return 0;
}
for (i=1;i<=n;++i)
{
  hitratios->v[i]=(double) numhits->t[i]/(double) allhits;
  /* one term ecpect->v[1] cancels below: */
  hitsigma->v[i]=sqrt(expect->v[i]*(double) allhits)/((double) allhits);
  normer->v[i]=(hitratios->v[i]-expect->v[i])/hitsigma->v[i];
  reler->v[i]=(hitratios->v[i]-expect->v[i])/expect->v[i];
  ret+=fabs(normer->v[i]);
}
ret/=n;
printf("\nThe number fo all hits: %i out of %i (rel. %g).\n",
       allhits,numgen,(double) allhits/(double) numgen);
printf("Integral of the density function on [%g,%g]: %g.\n",from,to,sumint);

printf("\n%3s %6s %6s %7s %10s %10s %8s %8s\n",
       "No","from","to","Ni","exp.","act.","rel. er.","norm. er.");
for (i=1;i<=n;++i)
  printf("\n%3i %6g %6g %7i %10.3g %10.3g %8.3g %8.3g\n",
      i,intlim->v[i],intlim->v[i+1],numhits->t[i],expect->v[i],hitratios->v[i],
         reler->v[i],normer->v[i]);
printf("\nNi - number fo hits for interval i, exp.: expected hit ratio for this int.,\n");
printf("act. - actual hit ratio, rel. er.: relative error, norm. er. - normed with dispersion.\n");

printf("\n\nNumber of hits in individual intervals:\n");
printindtablist(numhits); printf("\n");
printf("\nExpected hit ratios:\n");
printvectorlist(expect); printf("\n");
printf("\nAchieved hit ratios:\n");  printvectorlist(hitratios); printf("\n");
printf("\nrelative errors:\n");  printvectorlist(reler); printf("\n");
printf("\n\nNormalized errors of achieved hit ratios with respect to expected\n");
printf("standard deviations:\n");
printvectorlist(normer); printf("\n");
printf("\nAverage abs. rel. er.: %g\n",ret);
dispvector(&intlim);
dispvector(&expect);
dispvector(&hitratios);
dispvector(&hitsigma);
dispvector(&reler);
dispvector(&normer);
dispindtab(&numhits);
return ret;
}



          /*****************************/
          /*                           */
          /*  GLOBAL RANDOM GENERATOR  */
          /*                           */
          /*****************************/


static randgengen rgglob=NULL;

#define m_globrandgen (rgglob==NULL?(rgglob=newrandgen()):rgglob)

randgengen globrandgen(void)
    /* Returns the global random generator data. If the global generator has
    not yet been created then it is created first.
    $A Igor mar05; */
{
return m_globrandgen;
}


unsigned long seedrandglob(unsigned long seed)
    /* Seeds the global random generator by seed.
    $A Igor mar05; */
{
return seedrandgen(m_globrandgen,seed) ;
}


unsigned long seedrandtimeglob(unsigned long seed)
    /* Seeds the global random generator semi-randomly by seed and the current
    wallclock and CPU time.
    $A Igor mar05; */
{
return seedrandgentime(m_globrandgen,seed) ;
}


unsigned long seedrandrandglob(unsigned long seed)
    /* SRandomly initializes the global random generator. The initialization is
    uncorrelated among successive calls within the same process and among
    calls within different programs, even if they were called at the same time.
    seed is additional perturbation used in initialization and can be set to 0
    without affecting too much the behavior (otherwise, it can be some random
    number previously calculated).
    $A Igor mar05; */
{
return seedrandgenrand(m_globrandgen,seed) ;
}


unsigned long randintglob(unsigned long max)
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by the global random generator. The generated sequence is 
    deterministic, dependent on the current state of the generator (this can
    be initialized e.g. by seedrandglob().
    $A Igor mar05; */
{
return randintgen(m_globrandgen,max);
}


double randglob()
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by the global random generator. The generated sequence is 
    deterministic, dependent on the current state of the generator (which can
    be initialised e.g. by seedrandglob(), seedrandtimeglob() or 
    seedrandrandglob).
    $A Igor mar05; */
{
return randgen(m_globrandgen);
}

     /*  DIFFERENT RANDOM DISTRIBUTIONS by global generator  */

double normdistglob()
    /* Returns a normally distributed random number by mean value 0 and
    standard deviation 1, generated by using the global generator.
    $A Igor mar05; */
{
return randgennormstd(m_globrandgen);
}

#undef m_globrandgen






          /*****************************/
          /*                           */
          /*  SYSTEM RANDOM GENERATOR  */
          /*   (provided by compiler)  */
          /*                           */
          /*****************************/


void initrand(int seed)
    /* Inicializira random generator z vrednostjo seed.
    $A Igor sep00; */
{
srand(seed);
}


void timeinitrand(void)
     /* Inicializira generator nakljucnih stevil s pomocjo sistemskega casa */
{
time_t t;
int tmod;
t=time(&t);
tmod=(unsigned char) (t%255);
srand(tmod);
}



double random1(void)
       /* Vrne nakljucno stevilo med 0 in 1. */
{
double r;
int rnd; /* mod=RAND_MAX%999 */;
rnd=rand();
r=(double) rnd/((double) RAND_MAX);
return r;
}




double normdist(void)
       /* Vrne nakljucno stevilo po normalni porazdelitvi s srednjo vrednostjo 0
          in standardno deviacijo 1 */
{
double r,x,y,fac,rn;
do       /* najde nakljucno tocko v enotskem krogu v ravnini */
{
  x=2.0*random1()-1.0;
  y=2.0*random1()-1.0;
  r=x*x+y*y;
} while (r>=1);
fac=sqrt(-2*log(r)/r);  /* Box-Mullerjeva transformacija */
rn=x*fac;
return(rn);
}



          /*****************************/
          /*                           */
          /*  BASIC RANDOM GENERATORS  */
          /*                           */
          /*****************************/


/*   QUICK INSTRUCTIONS

  There are more than one random generator algorithms, and one of them is 
chosen as the default algorithm. The last suffix in a function name refers
to the algorithm, such as "mt" for Mersenne twister or "exp" for the 
experimental algorithm. 
  For each algorithm there is a data type. A couple of fields in this
such structural types are standard (such as type, count, etc.). There are
two groups of functions, one that takes the data structure representing the
random generator as the first argument, and one that operates on a "global"
random generator defined as a static variable. For the first kind of functions,
the random generator must be allocated before use by newrandgen*, where *
stands for the algorithm suffix, and must be released after use by the
disprandgen*. For the second kind of functions generator data is automatically
allocated.
  There are three types of initialisation for each generator -
deterministically by the seed, by the current time (and a seed) and random
initialisation that attemps to get rid of any correlation between different
random generators that might be used simultaneously within a single process
or across processes.
  Functions are divided to deterministic and random or non-deterministic,
which attempt to use "random" phenomena (such as current time or CPU time or
operations count from time to time to overcome the deterministic nature of 
software generation of random numbers. It is not necessary that the non-
deterministic generator would pass statistical tests better, it is just that
its output is less predictable in some sense.
  Each group of functions is further divided to those that generate integer
numbers (unsigned long) with a prescribed maximum and those that generate
real numbers (type double) between 0.0 and 1.0 (inclusively in the basic
variant).
*/

/* INVALID - this has been changed: 
For the official algorithm there are pre-process
definitions (via #define), which bind names without the type sffix to the
names that correspond to appropriate official algorithm. */



      /***********************************/
      /*                                 */
      /*  EXPERIMENTAL RANDOM GENERATOR  */
      /*                                 */
      /***********************************/




void *newrandgenexp(void)
    /* Creates and returna a new random generator; All data is initialized to
    0.
    $A Igor jun04; */
{
randgenexp ret;
ret=calloc(1,sizeof(*ret));
ret->bs.type=TYPE_randgengen;  ret->bs.gentype=SUBTYPE_randgenexp;
ret->bs.max=0xffffffff;
ret->bs.init=ret->bs.randinit=ret->bs.detinit=0;   /* Not initialized */
ret->bs.count=ret->bs.first=ret->bs.last=0;
/* Data about generator functions: */
ret->bs.func.newgen=newrandgenexp;
ret->bs.func.dispgen=disprandgenexp;
ret->bs.func.seed=seedrandbasexp;
ret->bs.func.seedrandtime=seedrandtimebasexp;
ret->bs.func.seedrandrand=seedrandrandbasexp;
ret->bs.func.randint=randintdetbasexp;
ret->bs.func.rand=randdetbasexp;
return ret;
}

void disprandgenexp(void **addr)
    /* Deallocates the space pointed to by *addr and sets this pointer to NULL.
    $A Igor jun04; */
{
if (addr!=NULL)
  if (*addr!=NULL)
  {
    randgenexp data=*addr;
    if (data->bs.gentype!=SUBTYPE_randgenexp || data->bs.type!=TYPE_randgengen)
    {
      errfunc0("disprandgenexp");
      sprintf(ers(),"Wrong type of random number generator.\n");
      sprintf(ers(),"Generator type: %i, should be %i.\n",
          data->bs.gentype,SUBTYPE_randgenexp);
      sprintf(ers(),"Basic type: %i, should be %i.\n",
        data->bs.type,TYPE_randgengen);
      errfunc2();
    } else
    {
      if (data->bs.threadlock)
      {
        warnfunc1(1,"disprandgenexp");
        sprintf(ers(),"Data structure is used by another thread when deallocated.\n");
        sprintf(ers(),"Waiting for to be unlocked, then delete.\n");
        warnfunc2();
      }
      /* set the lock; this lock will not be released since the data is
      deallocated. */
      m_threadlock(data->bs.threadlock);
      free(*addr);
      *addr=NULL;
    }
  }
}



static int randopcountbas(unsigned long max,int milsec,unsigned long pert)
    /* Returns a rnadom-featured number of operations that are necessary to
    add milsec milliseconds to the CPU time of the process. If milsec is less
    than 1 then milsec is set to 1. pert is the perturbation number that can
    affect the result.
      This function is thread safe.
    $A Igor jun04; */
{
unsigned long dif,t1,t2,count;
unsigned long k;
double x=0.1;
if (milsec>0)
  dif=m_maxval(1,milsec*CLOCKS_PER_SEC/1000);
else
  dif=m_maxval(1,CLOCKS_PER_SEC/1000);
/*
if (pert<0)
  pert=-(pert+1);
*/
t1=t2=clock();
count=0;
while(t2-t1<dif)
{
  x=sin(x);
  x=cos(x+0.5);
  if (count%10==0)
  {
    for (k=1;k<=(count+pert+t2)%6;++k)
    {
      x=sin(x+1.0);
      count+=3;
    }
  }
  if (count%55==0)
  {
    for (k=1;k<=(count+pert+t2)%15;++k)
    {
      x=cos(x+0.75);
      count+=8;
    }
  }
  t2=clock();
  ++count;
}
count+=t1+time(NULL);
/*
if (count<0)
  count=-(count+1);
*/
return count%(m_maxval(1,max+1));
}



unsigned long seedrandbasexp(void *rg,unsigned long seed)
    /* Initializes the random generator rg by the seed.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
unsigned long p1=0,p2=0,p3=0,p4=0,count=0,ret=0;
randgenexp data=rg;
if (rg==NULL)
{
  errfunc0("seedrandbasexp");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
} else if (data->bs.gentype!=SUBTYPE_randgenexp || 
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("seedrandbasexp");
  sprintf(ers(),"Wrong type of random generator (%i, should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenexp);
  sprintf(ers(),"Basic type: %i, should be %i.\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  m_threadlocksleep(data->bs.threadlock,1);
  /* Use bit masks to initialize the state, take care that all variables are 
  to some extent full in their bit representation: */
  p1=(seed ^ 0xcccccccc) &data->bs.max ; /* 0xc=1100 */
  p2=( p1^ (0xf0f0f0f0 >> (p1 & 0xf )) ) &data->bs.max ; /* 0xf0=11110000 */
  p3=(p2^0xaaaaaaaa) & data->bs.max;  /* 0xa=1010 */
  p3^=(seed<<16) & data->bs.max;
  p4=(p1^0x55555555) & data->bs.max;  /* 0x5=0101 */
  p4^=(seed>>8) & data->bs.max;
  /* Then do some additional manipulation in order to get rid of ordered
  patterns: */
  p1^= ( 0x0f0f0f0f << ((p2) & 0xf ) ) & data->bs.max ;  /* 0xf0=1111000 */
  p2^=0xcc5cc5cc >> ((p1) & 0xf);  /* 0xc=1100 */
  p2&=data->bs.max;
  p3^= ( p1 << (p2 &  0xf) ) & data->bs.max ;
  p2^=p1 & ( 0x0f0f0f0f << ((p3&0xf000)>>12) ); 
  p3^=(p1>>3) ^ p2;
  p2^=(p3+p1) & data->bs.max;
  p4^=p2^ (p3>>5);
  p1^=p4;
  
  
  ret=p1;

  data->bs.count=1;
  data->bs.init=1;
  data->bs.randinit=0;
  data->bs.detinit=1;
  data->bs.first=data->bs.last=ret;

	m_threadunlock(data->bs.threadlock);
}
return ret;
}



unsigned long seedrandtimebasexp(void *rg,unsigned long seed)
    /* Initializes the random generator rg semi-randomly by using the current
    system and CPU time and by the seed.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
unsigned long t,tc,ret=0;
randgenexp data=rg;
if (rg==NULL)
{
  errfunc0("seedrandtimebasexp");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
} else if (data->bs.gentype!=SUBTYPE_randgenexp ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("seedrandtimebasexp");
  sprintf(ers(),"Wrong type of random generator (%i, should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenexp);
  sprintf(ers(),"Basic type: %i, should be %i.\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  m_threadlocksleep(data->bs.threadlock,1);
  t=time(NULL);
  tc=clock();
  seedrandbasexp(rg,seed);
  data->p1^=(t+tc) & data->bs.max;
  data->p2^=tc & data->bs.max;
  data->p3^=t & data->bs.max;

  
  ret=data->p1;

  data->bs.count=1;
  data->bs.init=1;
  data->bs.randinit=0;
  data->bs.detinit=0;
  data->bs.first=data->bs.last=ret;

	m_threadunlock(data->bs.threadlock);
  /* return ret; */
}
return ret;
}

unsigned long seedrandrandbasexp(void *rg,unsigned long pert)
    /* Randomly initializes the random generator rg; The initialization is
    uncorrelated among successive calls within the same process and among
    calls within different programs, even if they were called at the same time.
    pert is additional perturbation used in initialization and can beset to 0
    without affecting too much the behavior (otherwise, it can be some random
    number previously calculated).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
unsigned long pc1,pc2,ret=0;
randgenexp data=rg;
if (rg==NULL)
{
  errfunc0("seedrandrandbasexp");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
} else if (data->bs.gentype!=SUBTYPE_randgenexp || 
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("seedrandrandbasexp");
  sprintf(ers(),"Wrong type of random generator (%i, should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenexp);
  sprintf(ers(),"Basic type: %i, should be %i.\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  m_threadlocksleep(data->bs.threadlock,1);
  /* Perform time initialization and get two random counts based numbers: */
  seedrandtimebasexp(rg,pert);
  pc1=randopcountbas(data->bs.max,1,pert);  /* Longer random number */
  pc2=randopcountbas(0xfff,1,0);  /* Short random number */
  /* Incorporate random counts in the generator state: */
  data->p1^=pc1 & data->bs.max;
  data->p2^=pc2 & data->bs.max;
  data->p3^=data->p1 >> (pc1 & 0xf);
  data->p4^=data->p3 >> (data->p1 & 0xf);
  data->p1^=( data->p4 << (1+(data->p1 & 0xf)) ) & data->bs.max;

  
  ret=data->p1;

  data->bs.count=1;
  data->bs.init=1;
  data->bs.randinit=1;
  data->bs.detinit=0;
  data->bs.first=data->bs.last=ret;
	m_threadunlock(data->bs.threadlock);
}
return (int) ret;
}



unsigned long randintdetbasexp(void *rg,unsigned long max)
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    current state of rg (which can be initialised by seedrandbas).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
unsigned long p1,p2,p3,p4,count,ret=0;
randgenexp data=rg;
if (rg==NULL)
{
  errfunc0("randintdetbasexp");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
  p1=-1;
} else if (data->bs.gentype!=SUBTYPE_randgenexp ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("randintdetbasexp");
  sprintf(ers(),"Wrong type of random generator (%i, should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenexp);
  sprintf(ers(),"Basic type: %i, should be %i.\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  m_threadlocksleep(data->bs.threadlock,1);
  if (max<1)
    max=1;
  if (data->bs.count==0 && data->p1==0 && data->p2==0)
    seedrandbasexp(rg,5555);
  count=data->bs.count;
  p1=data->p1;  p2=data->p2;  p3=data->p3;  p4=data->p4;
  
  
  /* Code below is to test how the generator recovers form the state where all
  auxiliary variables are 0: */
  /*
  if (1 && count==1)
  {
    p1=p2=p3=p4=0;
  }
  if (1 && count<25)
  {
    printf("%2i: p1 = %10lu, p2 = %10lu, p3 = %10lu, p4 = %lu\n",data->count,p1,p2,p3,p4);
  }
  */

  if (1)
  {
    /* There are three key ideas behind this generator: 1. xor-ing with some
    bit mask that has about half bits set, but is randomly shifted, enables
    quick take-off from settled patterns (such as 00000... or 00110011...).
    2. Incorporation of counter to the generation process ensures the period
    equal to at least data->max (i.e. maximum value of the numbers maintained)
    and prevents existence of non-trivial settings that would propagate
    ordered patterns over several generations. 3. Set of four random numbers
    are maintained (the state variables), which are "ramdomly" updated in each
    generation in the process where other state variables are employed, which
    pribides a kind of hardly predictable updates. */

    p1^= ( 0x0f0f0f0f << ((count+p2) & 0xf ) ) & data->bs.max ;  /* 0xf0=1111000 */
    p2^=0xcccccccc >> ((count+p1) & 0xf);  /* 0xc=1100 */
    p2&=data->bs.max;  /* for the case that mask is lrger than data->max */
    p3^= ( p1 << (p2 &  0xf) ) & data->bs.max ;

    p2^=p1 & ( 0x0f0f0f0f << ((p3&0xf000)>>12) ); 

    p3^=(p1>>3) ^ p2;
    /* Inclusion of count in the generation process ensures the period of
    at least data->max: */
    p2^=(count^p3) & data->bs.max;
    
    p4^=p2^ (p3>>5);
    p1^=p4;

 } else
  {
    /* This was the first experimental generator and is much less elaborated: */
    p2^=0x0f0f0f0f << (count & 0x15);
    p2&=data->bs.max;
    p1^=( (count & 0x01f) + ((count & 0xff) << (7+(p3 & 23) )) );
    p1&=data->bs.max;
    p3^=(p1 << (p2 & 0x1f)) | (p2 >> (p3 & 0x1f) );
    p3&=data->bs.max;
    p2^=p3+(77);
    p2&=data->bs.max;
    p1^=p2>>(p3 & 0x1f);
    p4^=(p3^p2);
    p4&=data->bs.max;
    p3^=((p1<<16) | (p2>>16));
    p3&=data->bs.max;
    p1^=p3;
    p2^=(0x72936742 ^ (p4&p1));
    p1^=(p2<<10 | p3 >> 22);
    p1&=data->bs.max;
  }


  data->p1=p1;  data->p2=p2;  data->p3=p3;  data->p4=p4;
  ret=p1;

  ++data->bs.count;
  data->bs.last=ret;

  if (max>data->bs.max)
  {
    errfunc0("randintdetbasexp");
    sprintf(ers(),"Max. number too large (%lu, limit %lu).\n",
      max,data->bs.max);
    errfunc2();
  } else if (max<data->bs.max)
  {
    int redundant=(1+data->bs.max%(max+1)) %(max+1); /* see end of this source */
    if(ret>data->bs.max-redundant)
    {
      ret=randintdetbasexp(rg,max);  /* current state of generator is not
              useful for this call, repeat recusively */
    } else
      ret=ret%(max+1);
  } else
    ret=ret%(max+1);

	m_threadunlock(data->bs.threadlock);
}
return ret;
}



unsigned long randintdetbassimpexp(void *rg,unsigned long max)
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    current state of rg (which can be initialised by seedrandbas).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
unsigned long p1,p2,p3,p4,count,ret=0;
randgenexp data=rg;
if (rg==NULL)
{
  errfunc0("randintdetbasexp");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
  p1=-1;
} else if (data->bs.gentype!=SUBTYPE_randgenexp ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("randintdetbassimpexp");
  sprintf(ers(),"Wrong type of random generator (%i, should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenexp);
  sprintf(ers(),"Basic type: %i, should be %i.\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  m_threadlocksleep(data->bs.threadlock,1);
  if (max<1)
    max=1;
  if (data->bs.count==0 && data->p1==0 && data->p2==0)
    seedrandbasexp(rg,5555);
  count=data->bs.count;
  p1=data->p1;  p2=data->p2;  p3=data->p3;  p4=data->p4;
  
  if (p1<0 || p2<0 || p3<0 || p4<0)
  {
    errfunc0("randintdetbas");
    sprintf(ers(),"Negative auxiliary random number before generation.\n");
    sprintf(ers(),"p1: %i, p2:%i, p3: %i, p4: %i.\n",p1,p2,p3,p4);
    errfunc2();
  }
  /* p2 augmented by random remainder and leading coef: */
  p2+=p1%(1+p2%11044)+p2%(20000+p1%10023)
      +(p2%4)*(p1/4)+(p1%5)*(p2/9);
  /*
  if (p2<0)
    p2=-(p2+1);
  */
  /* p1 augmented by a random remainder and leading coefficient: */
  p1+=p2%(1+p2%11044)+p2%(5000+p1%21500)+(p2%4)*(p2/4)+(p1%10)*(p2/100);
  /*
  if (p1<0)
    p1=-(p1+1);
  */
  if (p1<0 || p2<0 || p3<0 || p4<0)
  {
    errfunc0("randintdetbas");
    sprintf(ers(),"Negative auxiliary random number after generation.\n");
    sprintf(ers(),"p1: %i, p2:%i, p3: %i, p4: %i.\n",p1,p2,p3,p4);
    errfunc2();
  }
  data->p1=p1;  data->p2=p2;  data->p3=p3;  data->p4=p4;
  
  ret=p1;
  if(ret<data->bs.max%max)
  {
    ret=randintdetbassimpexp(data,max);
    --data->bs.count;
  } else
    ret=ret%(max+1);

  ++data->bs.count;
  data->bs.last=ret;
	m_threadunlock(data->bs.threadlock);
}
return ret;
}


double randdetbasexp(void *rg)
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    the current state of rg (which can be initialised by seedrandbasexp).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
unsigned long rn=0;
double ret=0;
randgenexp data=rg;
if (rg==NULL)
{
  errfunc0("randdetbasexp");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
  return 0;
} else if (data->bs.gentype!=SUBTYPE_randgenexp ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("randdetbasexp");
  sprintf(ers(),"Wrong type of random generator (%i, should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenexp);
  sprintf(ers(),"Basic type: %i, should be %i.\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  rn=randintdetbasexp(rg,data->bs.max);
  ret=((double) rn) * (1.0 / (double) data->bs.max);
}
return ret;
}


unsigned long randintrandbasexp(void *rg,unsigned long max)
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is randinit.
      This function is about 10 times SLOWER than randintdetbasexp(). and in wasp
    majority of cases that function should be used.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
randgenexp data=rg;
unsigned long p1=0,ret=0;
if (rg==NULL)
{
  errfunc0("randintrandbasexp");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
} else if (data->bs.gentype!=SUBTYPE_randgenexp ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("randintrandbasexp");
  sprintf(ers(),"Wrong type of random generator (%i, should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenexp);
  sprintf(ers(),"Basic type: %i, should be %i.\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  m_threadlocksleep(data->bs.threadlock,1);
  if (data->bs.count==0 || data->bs.randinit==0)
    seedrandrandbasexp(data,17888);
  /* Decide abount non-deterministic actions: */
  if (data->p1%(1+data->p2%50+data->p1%50)==0)
  {
    /* Use C random generator about every 50 iterations: */
    data->p1+=rand();
    /*
    if (data->p1<0)
      data->p1=-(data->p1+1);
    */
  } else if (data->p2%(1+data->p1%1000)==0)
  {
    /* Use system clock about every 500 iterations: */
    data->p1+=time(NULL);
    /*
    if (data->p1<0)
      data->p1=-(data->p1+1);
    */
  } else if (data->p2%(1+data->p1%80)==0)
  {
    /* Use CPU counter about every 40 iterations: */
    data->p1+=clock();
    /*
    if (data->p1<0)
      data->p1=-(data->p1+1);
    */
  } else if (data->p2%(1+data->p2%1000+data->p1%100)==0)
  {
    /* Use random counter of operations about every 500 iterations: */
    data->p1+=randopcountbas(10000+data->p1%100+data->p2%300,1,
          (5+data->p2/2+data->p1%800)%1000);
    /*
    if (data->p1<0)
      data->p1=-(data->p1+1);
    */
  }
  /* Call a deterministic generator: */
  
  ret=randintdetbasexp(data,max);

  data->bs.detinit=0;
	m_threadunlock(data->bs.threadlock);
}
return ret;
}


double randrandbasexp(void *rg)
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by rg. The generated sequence is not deterministic.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
unsigned long rn=0;
double ret=0;
randgenexp data=rg;
if (rg==NULL)
{
  errfunc0("randrandbasexp");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
  return 0;
} else if (data->bs.gentype!=SUBTYPE_randgenexp ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("randrandbasexp");
  sprintf(ers(),"Wrong type of random generator (%i, should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenexp);
  sprintf(ers(),"Basic type: %i, should be %i.\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  rn=randintrandbasexp(rg,data->bs.max);
  ret=((double) rn) * (1.0 / (double) data->bs.max);
}
return ret;
}



    /* GLOBAL EXPERIMENTAL RANDOM GENERATOR: */


unsigned long seedrandexp(unsigned long seed)
    /* Initializes the global random generator by seed. Following this command,
    the subsequent calls to the deterministic generator would produce always
    the same series of results.
      The function is thread safe.
    $A Igor jun04; */
{
unsigned long ret;
m_threadlocksleep(randlockexp,1);
if (rgexp0==NULL)
  rgexp0=newrandgenexp();
ret=seedrandbasexp(rgexp0,seed);
m_threadunlock(randlockexp);
return ret;
}


unsigned long seedrandtimeexp(unsigned long seed)
    /* Initializes the global random generator quasi-randomly by using the
    system time, and by seed.
      The function is thread safe.
    $A Igor jun04; */
{
unsigned long ret;
m_threadlocksleep(randlockexp,1);
if (rgexp0==NULL)
  rgexp0=newrandgenexp();
ret=seedrandtimebasexp(rgexp0,seed);
m_threadunlock(randlockexp);
return ret;
}


unsigned long seedrandrandexp(unsigned long pert)
    /* Initializes the global random generator randomly. Such initialization
    is not correlated across subsequent calls to this function within a process
    or across calls by different processes, even if these are performed at the
    same time. pert is additional perturbation used in initialization and can
    be 0 without affecting too much the behavior (otherwise, it can be some
    random number previously calculated).
      The function is thread safe.
    $A Igor jun04; */
{
unsigned long ret;
m_threadlocksleep(randlockexp,1);
if (rgexp0==NULL)
  rgexp0=newrandgenexp();
ret=seedrandrandbasexp(rgexp0,pert);
m_threadunlock(randlockexp);
return ret;
}

unsigned long randintdetexp(unsigned long max)
    /* Returns a random number from 0 to max inclusively, produced by the
    global random generator. The series of numbers generated  is deterministic,
    dependent only on the current state fo the global generator, which can be
    initialized by seedrand().
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */
{
unsigned long ret=0;
m_threadlocksleep(randlockexp,1);
if (rgexp0==NULL)
  rgexp0=newrandgenexp();
ret=randintdetbasexp(rgexp0,max);
m_threadunlock(randlockexp);
return ret;
}


double randdetexp(void)
    /* Returns a random number from 0 to 1.0 inclusively, produced by the
    global random generator. The series of numbers generated  is deterministic,
    dependent only on the current state fo the global generator, which can be
    initialized by seedrandexp().
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */
{
double ret=0;
m_threadlocksleep(randlockexp,1);
if (rgexp0==NULL)
  rgexp0=newrandgenexp();
ret=randdetbasexp(rgexp0);
m_threadunlock(randlockexp);
return ret;
}


unsigned long randintrandexp(unsigned long max)
    /* Returns a random number from 0 to max inclusively, produced by the
    global random generator. The series of numbers generated  is
    randinit.
      This function is about 10 times SLOWER than randintder(), and that
    function should be used in most cases.
      The function is thread safe.
    $A Igor jun04; */
{
unsigned long ret=0;
m_threadlocksleep(randlockexp,1);
if (rgexp0==NULL)
  rgexp0=newrandgenexp();
ret=randintrandbasexp(rgexp0,max);
m_threadunlock(randlockexp);
return ret;
}


double randrandexp(void)
    /* Returns a random number from 0 to 1.0 inclusively, produced by the
    global random generator. The series of numbers generated  is 
    nondeterministic.
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */
{
double ret=0;
m_threadlocksleep(randlockexp,1);
if (rgexp0==NULL)
  rgexp0=newrandgenexp();
ret=randrandbasexp(rgexp0);
m_threadunlock(randlockexp);
return ret;
}









          /********************************/
          /*                              */
          /*  MERSENNE TWISTER GENERATOR  */
          /*                              */
          /********************************/


/*  MERSENNE TWISTER GENERATOR
  Below is the code of Mersenne Twister random generator, which has been
modified in such a way that several generators with independent sequences
can be used at a time. The generator is very quality and efficient, the 
drawback is the amount of storage per generator (more than 600 long integers).
See the directory rand/mt/ for the original code with
copyright notices! */





void * newrandgenmt(void)
    /* Creates and returna a new random generator; All data is initialized to
    0.
    $A Igor jun04; */
{
randgenmt ret;
ret=calloc(1,sizeof(*ret));
ret->bs.type=TYPE_randgengen;  ret->bs.gentype=SUBTYPE_randgenmt;
ret->bs.max=0xffffffff;
ret->bs.init=ret->bs.randinit=ret->bs.detinit=0;   /* Not initialized */
ret->bs.count=ret->bs.first=ret->bs.last=0;
ret->mti=N+1;
ret->mag01[0] = 0x0UL;
ret->mag01[1] = MATRIX_A;
/* Functions of this random generator: */
ret->bs.func.newgen=newrandgenmt;
ret->bs.func.dispgen=disprandgenmt;
ret->bs.func.seed=seedrandbasmt;
ret->bs.func.seedrandtime=seedrandtimebasmt;
ret->bs.func.seedrandrand=seedrandrandbasmt;
ret->bs.func.randint=randintdetbasmt;
ret->bs.func.rand=randdetbasmt;

return ret;
}

void disprandgenmt(void **addr)
    /* Deallocates the space pointed to by *addr and sets this pointer to NULL.
    $A Igor jun04; */
{
if (addr!=NULL)
  if (*addr!=NULL)
  {
    randgenmt data=*addr;
    if (data->bs.gentype!=SUBTYPE_randgenmt || data->bs.type!=TYPE_randgengen)
    {
      errfunc0("disprandgenmt");
      sprintf(ers(),"Wrong type of random number generator.\n");
      sprintf(ers(),"Basic type: %i, should be %i.\n",data->bs.type,TYPE_randgengen);
      sprintf(ers(),"Generator type: %i, should be %i.\n",
          data->bs.gentype,SUBTYPE_randgenmt);
      errfunc2();
    } else
    {
      free(*addr);
      *addr=NULL;
    }
  }
}



#if 0
  static unsigned long mt[N]; /* the array for the state vector  */
  static /* mti==N+1 means mt[N] is not initialized */
#endif

static void init_genrand(void *rg,unsigned long s)
    /* initializes mt[N] with a seed */
{
randgenmt data=rg;
if (data==NULL)
{
  errfunc0("init_genrand");
  sprintf(ers(),"Pointer to random generator data is NULL.\n");
  errfunc2();
} else
{
  data->mt[0]= s & 0xffffffffUL;
  for (data->mti=1; data->mti<N; data->mti++) {
    data->mt[data->mti] = 
	  (1812433253UL * 
      (data->mt[data->mti-1] ^ (data->mt[data->mti-1] >> 30)) + data->mti); 
    /* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
    /* In the previous versions, MSBs of the seed affect   */
    /* only MSBs of the array mt[].            */
    /* 2002/01/09 modified by Makoto Matsumoto       */
    data->mt[data->mti] &= 0xffffffffUL;
    /* for >32 bit machines */
  }

}
}

static void init_by_array(void *rg,unsigned long init_key[], int key_length)
    /* initialize by an array with array-length */
    /* init_key is the array for initializing keys */
    /* key_length is its length */
    /* slight change for C++, 2004/2/26 */
{
int i, j, k;
randgenmt data=rg;
if (data==NULL)
{
  errfunc0("init_by_array");
  sprintf(ers(),"Pointer to random generator data is NULL.\n");
  errfunc2();
} else
{
  init_genrand(rg,19650218UL);
  i=1; j=0;
  k = (N>key_length ? N : key_length);
  for (; k; k--) {
    data->mt[i] = (data->mt[i] ^ 
      ((data->mt[i-1] ^ (data->mt[i-1] >> 30)) * 1664525UL))
      + init_key[j] + j; /* non linear */
    data->mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
    i++; j++;
    if (i>=N) { data->mt[0] = data->mt[N-1]; i=1; }
    if (j>=key_length) j=0;
  }
  for (k=N-1; k; k--) {
    data->mt[i] = (data->mt[i] ^ 
      ((data->mt[i-1] ^ (data->mt[i-1] >> 30)) * 1566083941UL))
      - i; /* non linear */
    data->mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
    i++;
    if (i>=N) { data->mt[0] = data->mt[N-1]; i=1; }
  }

  data->mt[0] = 0x80000000UL; /* MSB is 1; assuring non-zero initial array */ 
}
}


static unsigned long genrand_int32(void *rg)
    /* generates a random number on [0,0xffffffff]-interval */
{
unsigned long y;
/*
static unsigned long mag01[2]={0x0UL, MATRIX_A};
*/
randgenmt data=rg;
if (data==NULL)
{
  errfunc0("genrand_int32");
  sprintf(ers(),"Pointer to random generator data is NULL.\n");
  errfunc2();
  return 0;
} else
{
  /* mag01[x] = x * MATRIX_A  for x=0,1 */

  if (data->mti >= N) { /* generate N words at one time */
    int kk;

    if (data->mti == N+1)   /* if init_genrand() has not been called, */
      init_genrand(rg,5489UL); /* a default initial seed is used */

    for (kk=0;kk<N-M;kk++) {
      y = (data->mt[kk]&UPPER_MASK)|(data->mt[kk+1]&LOWER_MASK);
      data->mt[kk] = data->mt[kk+M] ^ (y >> 1) ^ data->mag01[y & 0x1UL];
    }
    for (;kk<N-1;kk++) {
      y = (data->mt[kk]&UPPER_MASK)|(data->mt[kk+1]&LOWER_MASK);
      data->mt[kk] = data->mt[kk+(M-N)] ^ (y >> 1) ^ data->mag01[y & 0x1UL];
    }
    y = (data->mt[N-1]&UPPER_MASK)|(data->mt[0]&LOWER_MASK);
    data->mt[N-1] = data->mt[M-1] ^ (y >> 1) ^ data->mag01[y & 0x1UL];

    data->mti = 0;
  }


  y = data->mt[(data->mti)++];

  /* Tempering */
  y ^= (y >> 11);
  y ^= (y << 7) & 0x9d2c5680UL;
  y ^= (y << 15) & 0xefc60000UL;
  y ^= (y >> 18);

  return y;

}
}


static long genrand_int31(void *rg)
    /* generates a random number on [0,0x7fffffff]-interval */
{
return (long)(genrand_int32(rg)>>1);
}


static double genrand_real1(void *rg)
    /* generates a random number on [0,1]-real-interval */
{
return genrand_int32(rg)*(1.0/4294967295.0); 
/* divided by 2^32-1 */ 
}


static double genrand_real2(void *rg)
    /* generates a random number on [0,1)-real-interval */
{
return genrand_int32(rg)*(1.0/4294967296.0); 
/* divided by 2^32 */
}


static double genrand_real3(void *rg)
    /* generates a random number on (0,1)-real-interval */
{
return (((double)genrand_int32(rg)) + 0.5)*(1.0/4294967296.0); 
/* divided by 2^32 */
}


static double genrand_res53(void *rg) 
    /* generates a random number on [0,1) with 53-bit resolution*/
{ 
unsigned long a=genrand_int32(rg)>>5, b=genrand_int32(rg)>>6; 
return(a*67108864.0+b)*(1.0/9007199254740992.0); 
} 
/* These real versions are due to Isaku Wada, 2002/01/09 added */


static int mainmt(void *rg,FILE *fp)
    /* Test function for the Mersenne twister random generator; It outputs
    1000 randomly generated numbers to the standart output (and to file fp 
    in the case that fp is not NULL). Otuput must match the numbers in the
    file rand/mt/mt19937ar.out, and this can be used for control when porting
    the code to other machines, which may for exmaple have different length
    of integer types. Output consists of 1000 random numbers generated by
    the generator, starting form pre-defined seed. */
{
int i;
unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;
init_by_array(rg,init, length);
printf("1000 outputs of genrand_int32()\n");
if (fp!=NULL)
  fprintf(fp,"1000 outputs of genrand_int32()\n");
for (i=0; i<1000; i++) {
  printf("%10lu ", genrand_int32(rg));
  if (i%5==4) printf("\n");
  if (fp!=NULL)
  {
    fprintf(fp,"%10lu ", genrand_int32(rg));
    if (i%5==4) fprintf(fp,"\n");
  }
}
printf("\n1000 outputs of genrand_real2()\n");
if (fp!=NULL)
  fprintf(fp,"\n1000 outputs of genrand_real2()\n");
for (i=0; i<1000; i++) {
  printf("%10.8f ", genrand_real2(rg));
  if (i%5==4) printf("\n");
  if (fp!=NULL)
  {
    fprintf(fp,"%10.8f ", genrand_real2(rg));
    if (i%5==4) fprintf(fp,"\n");
  }
}
return 0;
}



#undef N
#undef M
#undef MATRIX_A
#undef UPPER_MASK
#undef LOWER_MASK



unsigned long seedrandbasmt(void *rg,unsigned long seed)
    /* Initializes the random generator rg by the seed.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
randgenmt data=rg;
unsigned long ret=0;
if (rg==NULL)
{
  errfunc0("seedrandbasmt");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
} else if (data->bs.gentype!=SUBTYPE_randgenmt ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("seedrandtimebasmt");
  sprintf(ers(),"Wrong type of random number generator.\n");
  sprintf(ers(),"Generator type: %i (should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenmt);
  sprintf(ers(),"Basic type: %i, (should be %i).\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;

  m_threadlocksleep(data->bs.threadlock,1);

  /* Incorporate seed into initialization array: */
  init[0]^=seed & data->bs.max;
  init[1]^=(seed<<14) & data->bs.max;
  init[2]^=(seed<<8) & data->bs.max;
  init[2]^=init[1]^init[2];
  /* Take care of bit filling: */
  init[0]^= 0xcccccccc & data->bs.max;  /* 0xc=1100 */
  init[1]^= 0xf0f0f0f0 & data->bs.max;  /* 0xf0=11110000 */
  init[2]^= 0xcc5cc5cc & data->bs.max;
  init[3]^= 0x55555555 & data->bs.max;  /* 0x5=0101 */
  /* Perform some additional transforms to get rid of ordered samples: */
  init[0]^=(init[2] ^ (0xf0f0f0f0>>(init[3] & 0xf))) & data->bs.max; /* 0xf0=11110000 */
  init[1]^=( init[3] ^ 0x55555555 ) & data->bs.max;  /* 0x5=0101 */
  init[2]^=init[1] ^ init[3];
  init[3]^=init[2];
  init[1]^=init[3];
  /* Use the package initialization function: */
  init_by_array(rg,init, length);
  
  data->bs.count=1;
  data->bs.init=1;
  data->bs.randinit=0;
  data->bs.detinit=1;
  data->bs.first=data->bs.last=ret;
	m_threadunlock(data->bs.threadlock);
}
return ret;  /* error */
}

unsigned long seedrandtimebasmt(void *rg,unsigned long seed)
    /* Initializes the random generator rg semi-randomly by using the current
    system and CPU time and by the seed.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
randgenmt data=rg;
unsigned long ret=0;
if (rg==NULL)
{
  errfunc0("seedrandtimebasmt");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
  return 0;
} else if (data->bs.gentype!=SUBTYPE_randgenmt ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("seedrandtimebasmt");
  sprintf(ers(),"Wrong type of random number generator.\n");
  sprintf(ers(),"Generator type: %i (should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenmt);
  sprintf(ers(),"Basic type: %i, (should be %i).\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;

  m_threadlocksleep(data->bs.threadlock,1);

  /* Incorporate seed and time (absolute and CPU): */
  init[0]^=seed & data->bs.max;
  init[1]^=time(NULL) & data->bs.max;
  init[2]^=clock() & data->bs.max;
  init[3]^=init[1]^init[2];
  /* Take care of bit filling: */
  init[0]^= 0xcccccccc & data->bs.max;  /* 0xc=1100 */
  init[1]^= 0xf0f0f0f0 & data->bs.max;  /* 0xf0=11110000 */
  init[2]^= 0xcc5cc5cc & data->bs.max;
  init[3]^= 0x55555555 & data->bs.max;  /* 0x5=0101 */
  /* Perform some additional transforms to get rid of ordered samples: */
  init[0]^=(init[2] ^ (0xf0f0f0f0>>(init[3] & 0xf))) & data->bs.max; /* 0xf0=11110000 */
  init[1]^=( init[3] ^ 0x55555555 ) & data->bs.max;  /* 0x5=0101 */
  init[2]^=init[1] ^ init[3];
  init[3]^=init[2];
  init[1]^=init[3];
  /* Use the package initialization function: */
  init_by_array(rg,init, length);

  data->bs.count=1;
  data->bs.init=1;
  data->bs.randinit=0;
  data->bs.detinit=0;
  data->bs.first=data->bs.last=ret;
	m_threadunlock(data->bs.threadlock);
}
return ret;
}

unsigned long seedrandrandbasmt(void *rg,unsigned long pert)
    /* Randomly initializes the random generator rg; The initialization is
    uncorrelated among successive calls within the same process and among
    calls within different programs, even if they were called at the same time.
    pert is additional perturbation used in initialization and can beset to 0
    without affecting too much the behavior (otherwise, it can be some random
    number previously calculated).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
randgenmt data=rg;
unsigned long ret=0;
if (rg==NULL)
{
  errfunc0("seedrandrandbasmt");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
  return 0;
} else if (data->bs.gentype!=SUBTYPE_randgenmt ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("seedrandrandbasmt");
  sprintf(ers(),"Wrong type of random number generator.\n");
  sprintf(ers(),"Generator type: %i (should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenmt);
  sprintf(ers(),"Basic type: %i, (should be %i).\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;
  m_threadlocksleep(data->bs.threadlock,1);
  /* Incorporate seed, time (absolute and CPU) and random count: */
  init[0]^=pert & data->bs.max;
  init[1]^=time(NULL) & data->bs.max;
  init[2]^=clock() & data->bs.max;
  init[3]^=randopcountbas(data->bs.max,1,pert) & data->bs.max;
  /* Take care of bit filling: */
  init[0]^= 0xcccccccc & data->bs.max;  /* 0xc=1100 */
  init[1]^= 0xf0f0f0f0 & data->bs.max;  /* 0xf0=11110000 */
  init[2]^= 0xcc5cc5cc & data->bs.max;
  init[3]^= 0x55555555 & data->bs.max;  /* 0x5=0101 */
  /* Perform some additional transforms to get rid of ordered samples: */
  init[0]^=(init[2] ^ (0xf0f0f0f0>>(init[3] & 0xf))) & data->bs.max; /* 0xf0=11110000 */
  init[1]^=( init[3] ^ 0x55555555 ) & data->bs.max;  /* 0x5=0101 */
  init[2]^=init[1] ^ init[3];
  init[3]^=init[2];
  init[1]^=init[3];

  init_by_array(rg,init, length);
  
  /*
  ret=genrand_int32(rg);
  ret=genrand_int32(rg);
  ret=genrand_int32(rg);
  */
  
  data->bs.count=1;
  data->bs.init=1;
  data->bs.randinit=1;
  data->bs.detinit=0;
  data->bs.first=data->bs.last=ret;

	m_threadunlock(data->bs.threadlock);
}
return ret;
}




unsigned long randintdetbasmt(void *rg,unsigned long max)
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    current state of rg (which can be initialised by seedrandbasmt).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
randgenmt data=rg;
unsigned long ret=0;
if (rg==NULL)
{
  errfunc0("randintdetbasmt");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
  return 0;
} else if (data->bs.gentype!=SUBTYPE_randgenmt ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("randintdetbasmt");
  sprintf(ers(),"Wrong type of random number generator.\n");
  sprintf(ers(),"Generator type: %i (should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenmt);
  sprintf(ers(),"Basic type: %i, (should be %i).\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  m_threadlocksleep(data->bs.threadlock,1);

  ret=genrand_int32(rg);

  /* Less precise formula:
  ret=(unsigned long) round((double) (max+1.)*((double) ret/(double) data->max)-0.5);
  */
    
  if (max>data->bs.max)
  {
    errfunc0("randintdetbasmt");
    sprintf(ers(),"Max. number too large (%lu, limit %lu).\n",
      max,data->bs.max);
    errfunc2();
  } else if (max<data->bs.max)
  {
    int redundant=(1+data->bs.max%(max+1)) %(max+1);
    while(ret > data->bs.max-redundant)
      ret=genrand_int32(rg);
    ret=ret%(max+1);
  } else
    ret=ret%(max+1);

  ++data->bs.count;
  data->bs.last=ret;

	m_threadunlock(data->bs.threadlock);
}
return ret;
}


double randdetbasmt(void *rg)
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by rg. The generated sequence is deterministic, dependent on
    the current state of rg (which can be initialised by seedrandbasmt).
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
unsigned long rn=0;
double ret=0;
randgenmt data=rg;
if (rg==NULL)
{
  errfunc0("randdetbasmt");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
  return 0;
} else if (data->bs.gentype!=SUBTYPE_randgenmt ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("randdetbasmt");
  sprintf(ers(),"Wrong type of random number generator.\n");
  sprintf(ers(),"Generator type: %i (should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenmt);
  sprintf(ers(),"Basic type: %i, (should be %i).\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  m_threadlocksleep(data->bs.threadlock,1);
  rn=genrand_int32(rg);
  ret=((double) rn) * (1.0 / (double) data->bs.max);
    
  ++data->bs.count;
  data->bs.last=rn;
	m_threadunlock(data->bs.threadlock);
}
return ret;
}


unsigned long randintrandbasmt(void *rg,unsigned long max)
    /* Returns a random integer in the range between 0 and max inclusive,
    generated by rg. The generated sequence is randinit.
      This function is about 10 times SLOWER than randintdetbasmt(). and in wasp
      majority of cases that function should be used.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
randgenmt data=rg;
unsigned long p1=0,ret;
if (rg==NULL)
{
  errfunc0("randintrandbasmt");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
  return 0;
} else if (data->bs.gentype!=SUBTYPE_randgenmt ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("randintrandbasmt");
  sprintf(ers(),"Wrong type of random number generator.\n");
  sprintf(ers(),"Generator type: %i (should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenmt);
  sprintf(ers(),"Basic type: %i, (should be %i).\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  if (data->bs.count==0 || data->bs.randinit==0)
    seedrandrandbasmt(data,17888);
  /* Decide abount non-deterministic actions: */
  if (data->bs.last%(1+data->bs.last%200)==0)
  {
    /* Use C random generator about every 100 iterations: */
    seedrandbasmt(data,rand()+data->bs.last);
  } else if (data->bs.last%(1+data->bs.last%1000)==0)
  {
    /* Use system clock about every 500 iterations: */
    seedrandtimebasmt(data,data->bs.last);
  } else if (data->bs.last%(1+data->bs.last%2000)==0)
  {
    /* Use random counter of operations about every 500 iterations: */
    seedrandrandbasmt(data,data->bs.last);
  }
  /* Call a deterministic generator: */
  ret=randintdetbasmt(data,max);

  data->bs.detinit=0;
}
return ret;
}


double randrandbasmt(void *rg)
    /* Returns a random number in the range between 0 and 1.0 inclusive,
    generated by rg. The generated sequence is nondeterministic.
      The function is not thread safe, only one call with the same rg may
    be performed at once.
    $A Igor jun04; */
{
unsigned long rn=0;
double ret=0;
randgenmt data=rg;
if (rg==NULL)
{
  errfunc0("randdetbasmt");
  sprintf(ers(),"Pointer to the random generator is NULL!\n");
  errfunc2();
  return 0;
} else if (data->bs.gentype!=SUBTYPE_randgenmt ||
           data->bs.type!=TYPE_randgengen)
{
  errfunc0("randdetbasmt");
  sprintf(ers(),"Wrong type of random number generator.\n");
  sprintf(ers(),"Generator type: %i (should be %i).\n",
      data->bs.gentype,SUBTYPE_randgenmt);
  sprintf(ers(),"Basic type: %i, (should be %i).\n",
      data->bs.type,TYPE_randgengen);
  errfunc2();
} else
{
  rn=randintrandbasmt(rg,data->bs.max);
  ret=((double) rn) * (1.0 / (double) data->bs.max);
    
  /* 
  ++data->count;
  data->last=rn;
  */
}
return ret;
}


    /* GLOBAL MERSENNE TWISTER RANDOM GENERATOR: */


unsigned long seedrandmt(unsigned long seed)
    /* Initializes the global random generator by seed. Following this command,
    the subsequent calls to the deterministic generator would produce always
    the same series of results.
      The function is thread safe.
    $A Igor jun04; */
{
unsigned long ret;
m_threadlocksleep(randlockmt,1);
if (rgmt0==NULL)
  rgmt0=newrandgenmt();
ret=seedrandbasmt(rgmt0,seed);
m_threadunlock(randlockmt);
return ret;
}

unsigned long seedrandtimemt(unsigned long seed)
    /* Initializes the global random generator quasi-randomly by using the
    system time, and by seed.
      The function is thread safe.
    $A Igor jun04; */
{
unsigned long ret;
m_threadlocksleep(randlockmt,1);
if (rgmt0==NULL)
  rgmt0=newrandgenmt();
ret=seedrandtimebasmt(rgmt0,seed);
m_threadunlock(randlockmt);
return ret;
}

unsigned long seedrandrandmt(unsigned long pert)
    /* Initializes the global random generator randomly. Such initialization
    is not correlated across subsequent calls to this function within a process
    or across calls by different processes, even if these are performed at the
    same time. pert is additional perturbation used in initialization and can
    be 0 without affecting too much the behavior (otherwise, it can be some
    random number previously calculated).
      The function is thread safe.
    $A Igor jun04; */
{
unsigned long ret;
m_threadlocksleep(randlockmt,1);
if (rgmt0==NULL)
  rgmt0=newrandgenmt();
ret=seedrandrandbasmt(rgmt0,pert);
m_threadunlock(randlockmt);
return ret;
}

unsigned long randintdetmt(unsigned long max)
    /* Returns a random number from 0 to max inclusively, produced by the
    global random generator. The series of numbers generated  is deterministic,
    dependent only on the current state fo the global generator, which can be
    initialized by seedrand().
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */
{
unsigned long ret=0;
m_threadlocksleep(randlockmt,1);
if (rgmt0==NULL)
  rgmt0=newrandgenmt();
ret=randintdetbasmt(rgmt0,max);
m_threadunlock(randlockmt);
return ret;
}


double randdetmt(void)
    /* Returns a random number from 0 to 1.0 inclusively, produced by the
    global random generator. The series of numbers generated  is deterministic,
    dependent only on the current state fo the global generator, which can be
    initialized by seedrandmt().
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */
{
double ret=0;
m_threadlocksleep(randlockmt,1);
if (rgmt0==NULL)
  rgmt0=newrandgenmt();
ret=randdetbasmt(rgmt0);
m_threadunlock(randlockmt);
return ret;
}


unsigned long randintrandmt(unsigned long max)
    /* Returns a random number from 0 to max inclusively, produced by the
    global random generator. The series of numbers generated  is
    randinit.
      This function is about 10 times SLOWER than randintder(), and that
    function should be used in most cases.
      The function is thread safe.
    $A Igor jun04; */
{
unsigned long ret=0;
m_threadlocksleep(randlockmt,1);
if (rgmt0==NULL)
  rgmt0=newrandgenmt();
ret=randintrandbasmt(rgmt0,max);
m_threadunlock(randlockmt);
return ret;
}


double randrandmt(void)
    /* Returns a random number from 0 to 1.0 inclusively, produced by the
    global random generator. The series of numbers generated  is 
    nondeterministic.
      The function is thread safe, except that the sequence of results
    generated can change if reults are also generated in another thread. If
    this is a problem then randintdetid() must be used instead.
    $A Igor jun04; */
{
double ret=0;
m_threadlocksleep(randlockmt,1);
if (rgmt0==NULL)
  rgmt0=newrandgenmt();
ret=randrandbasmt(rgmt0);
m_threadunlock(randlockmt);
return ret;
}











static void emptyfunc(long l)
    /* Test function for speed tests. */
{
++l;
}

static long emptyfuncret(long l)
    /* Test function for speed tests. */
{
++l;
return l;
}




#define m_swap1(x1,x2,aux) {aux=x1; x1=x2; x2=aux;}
#define m_swap2(x1,y1,x2,y2,aux) {m_swap1(x1,x2,aux) m_swap1(y1,y2,aux)}
#define m_swap3(x1,y1,z1,x2,y2,z2,aux) {m_swap1(x1,x2,aux) \
           m_swap1(y1,y2,aux) m_swap1(z1,z2,aux)}


void testrand()
    /* Test random utilities. */
{
long clockspersec=CLOCKS_PER_SEC;
double t0=0,t1=0,t2=0,t3=0,ct0=0,ct1=0,ct2=0,ct3=0,
       x=0,y=0;
int i,j=0,k=0,n,m,ms,ix,iy;
/*
t1=absolutetime();
ct1=cputime();
printf("CPU time: %g, abs. time: %g.\n",ct1,t1);
printf("Int. part of abs. time: %g, fract. part: %g.\n",trunc(t1),frac(t1));
printf("CPU clocks per second: %i (reciprocial: %g).\n",clockspersec,1.0/(double)clockspersec);
*/

if (0)
{
  printf("\n\n\nRUNNING TESTS FROM numut.c:\n\n");
  testnumut();
}
if (1)
{
  /* Test of random generators for different distributions */
  double from=-1.,to=1.,par[10],restest=0;
  int dimball=30;
  int n=10,numint=100,numgen=10000,i;

  double (*distgen) (randgengen,void *) = randgenhyperballcoord;
  double (*densfunc) (double,void *) = densfunchyperballcoord1;
  void *distparam=&dimball;
  /*
  For randgenhyperballcoord, densfunchyperballcoord1:
  double (*distgen) (randgengen,void *) = randgenhyperballcoord;
  double (*densfunc) (double,void *) = densfunchyperballcoord1;
  void *distparam=&dimball;
  For randgennorm,densfuncnorm:
  double (*distgen) (randgengen,void *) = randgennorm;
  double (*densfunc) (double,void *) =  densfuncnorm;
  void *distparam=par;
 */
  randgengen rg=NULL;
  vector v=NULL;
  int dimv=200;

  resizevector(&v,dimv);
  if (0)
    {
    /* Normalization coefficients for unit hyper-ball cooordinate distributions: */
    for (i=1;i<=dimv;++i)
    {
      v->v[i]=normfacthyperballcoord(i);
      /* incert to obtain efficiencies:
      */
      v->v[i]=0.5/v->v[i];
    }
    printf("Normalization factors for hyperball coordinate distribution:\n");
    printvector(v); printf("\n\n");
  
    waituserresponse();
  }

  par[0]=0;    /* mean of the Gauss distribution */
  par[1]=0.1;  /* disersion of the Gauss distribution */
  rg=newrandgen();  seedrandgentime(rg,23);
  restest=inspranddist(rg,from,to,  n,numint,numgen,
    distgen,distparam,
    densfunc,
    distparam );

  if (restest>1.5)
  {
    warnfunc1(1,"testrand");
    sprintf(ers(),"The value returned from inspranddist is too large (%g),\n"
        ,restest);
    sprintf(ers(),"should (very) approximately 1.\n");
    warnfunc2();
  }

  waituserresponse();

  dispvector(&v);
}

if (0)
{
  void *rgmt;
  /* Test of the Mersenne twister random generator on the current platform.
  If the numbers that are output match the numbers stored in the file 
  rand/mt/mt19937ar.out, then the generator works properly on the current
  platform: */
  rgmt=newrandgenmt();
  mainmt(rgmt,NULL);
  disprandgenmt(&rgmt);
}

if (0)
{
  /* Test of random count function: */
  m=99,ms=1,n=10;
  printf("\nPerforming %i random counts in %i ms with max. %i: \n",n,ms,m);
  t1=absolutetime();
  ct1=cputime();
  for (i=1;i<=n;++i)
  {
    ix=randopcountbas(m,ms,0);
    printf("%i ",ix);
  }
  ct2=cputime();
  t2=absolutetime();
  printf("\n");
  printf("Time elapsed: CPU %g, abs. %g.\n",t2-t1,ct2-ct1);
}

if (0)
{
  /* Test of initialization functions (check also for negative parameters): */
  /* Random initialization: */
  m=999999,n=20;
  printf("\nRunning %i random initializations (max = %i).\n",n,m);
  seedrandglob(m);
  ix=randintglob(m);
  iy=randintglob(m);
  printf("First two random numbers: %i, %i.\n",ix,iy);
  t1=absolutetime();
  ct1=cputime();
  for (i=1;i<=n;++i)
  {
    seedrandglob(iy);
    ix=randintglob(m);
    iy=randintglob(m);
  }
  t2=absolutetime();
  ct2=cputime();
  printf("Time elapsed: CPU %g, abs. %g.\n",t2-t1,ct2-ct1);
  n=20;
  printf("%i sequential random initializations without seed:\n",n);
  for (i=1;i<=n;++i)
  {
    ix=seedrandglob(0);
    printf("%11i ",ix);
    if (i%4==0)
      printf("\n");
  }
  printf("\n");
  /* Initialization by seed: */
  m=999999,n=1000;
  printf("\nRunning %i initializations with seed (max = %i).\n",n,m);
  seedrandglob(m);
  ix=randintglob(m);
  iy=randintglob(m);
  t1=absolutetime();
  ct1=cputime();
  for (i=1;i<=n;++i)
  {
    seedrandglob(iy);
    /* ix=randintdet(m); */
    iy=randintglob(m);
  }
  t2=absolutetime();
  ct2=cputime();
  printf("Time elapsed: CPU %g, abs. %g.\n",t2-t1,ct2-ct1);
  n=20;
  printf("%i sequential initializations by seed being return of previous:\n",n);
  ix=seedrandglob(1);
  for (i=1;i<=n;++i)
  {
    ix=seedrandglob(ix);
    printf("%11i ",ix);
    if (i%4==0)
      printf("\n");
  }
  printf("\n");

}

/* SPEED test: */
if (0)
{
  m=9,n=10000;
  printf("\nSPEED test - %i evaluations:\n",n);
  t1=absolutetime();
  ct1=cputime();
  ix=iy=randintglob(m);
  ct2=cputime();
  t2=absolutetime();
  for (i=1;i<=n;++i)
  {
    ix=seedrandrandglob(ix);
    /*
    ix=seedrandrandtime(ix);
    ix=clock();
    ix=time(NULL);
    ix+=4;
    emptyfuncret(ix);
    emptyfunc(ix);  
    x=sin(1.+x);
    */
  }
  ct3=cputime();
  t3=absolutetime();
  printf("Time elapsed: CPU %g, abs. %g.\n",t3-t2,ct3-ct2);
}

if (0)
{
  /* Speed test for random numbers GENERATION: */
  m=9,n=1000000;
  printf("\nGENERATING %i random numbers with max. %i: \n",n,m);
  t1=absolutetime();
  ct1=cputime();
  iy=randintglob(m);
  ct2=cputime();
  t2=absolutetime();
  for (i=1;i<=n;++i)
  {
    ix=randintglob(m);
    /*
    ix=randintrand(m);
    ix=rand()%10;
    */
  }
  ct3=cputime();
  t3=absolutetime();
  printf("Time elapsed: CPU %g, abs. %g.\n",t3-t2,ct3-ct2);
  printf("(first gen.:  CPU %g, abs. %g)\n",t2-t1,ct2-ct1);
  /* Test of random number generation function - printout: */
  m=9,n=40;
  printf("\nGenerating %i random numbers with max. %i: \n",n,m);
  t1=absolutetime();
  ct1=cputime();
  iy=randintglob(m);
  ct2=cputime();
  t2=absolutetime();
  printf("The first number: %i.\n",iy);
  for (i=1;i<=n;++i)
  {
    ix=randintglob(m);
    /*
    ix=rand();
    */
    printf("%11i ",ix);
    if (0 && i%4==0)
      printf("\n");
  }
  ct3=cputime();
  t3=absolutetime();
  printf("\n");
  printf("Time elapsed: CPU %g, abs. %g.\n",t3-t2,ct3-ct2);
  printf("(first gen.:  CPU %g, abs. %g)\n",t2-t1,ct2-ct1);
}

/* Test of QUALITY of the generated numbers: */
if (1)
{
  indtab hyst=NULL;
  vector er=NULL,reler=NULL;
  double dn,dm,dnum,expect,erexpect,relerexpect,avabs,rms;
  printf("\nQUALITY of generated random numbers: Frequency test:\n");
  n=400000;
  m=24-1;
  hyst=newindtabrn(1,m+1);
  for (i=1;i<=m+1;++i)
    hyst->t[i]=0;
  er=getvector(m+1);
  reler=getvector(m+1);
  dn=(double) n;
  dm=(double) m;
  dnum=dm+1.0;
  expect=dn/dnum;
  erexpect=sqrt(expect);
  relerexpect=erexpect/expect;
  printf("Generate: %i numbers from 0 to %i (uniform distribution):\n",n,m);
  printf("Expected number of hits for each cell: %g, error %g (rel. %g).\n",
      expect,erexpect,relerexpect);
   timeinitrand();
  seedrandrandmt(111);    /* Random initialization */
  seedrandrandexp(111);   /* Random initialization */
  ct1=cputime();
  t1=absolutetime();
  for (i=1;i<=n;++i)
  {
    if (i%100000==0)
      printf(".");

    ix=randintdetexp(m);

    /*
    ix=randintdetmt(m);
    ix=rand()%(1+m);
    */
    ++(hyst->t[1+ix]);
  }
  ct2=cputime();
  t2=absolutetime();
  printf("\nResults:\n%4s %6s %9s %8s  %-s\n","No.","hits",
      "error","rel. er.","re/exp.");
  avabs=0;
  rms=0;
  for (i=1;i<=m+1;++i)
  {
    er->v[i]=(double) hyst->t[i]-expect;
    reler->v[i]=er->v[i]/expect;
    printf("%4i %6i %9.5g %8.3g  %-g\n",i-1,hyst->t[i],
        er->v[i],reler->v[i],reler->v[i]/relerexpect);
    avabs+=fabs(reler->v[i]/relerexpect);
    rms+=(reler->v[i]/relerexpect)*(reler->v[i]/relerexpect);
  }
  avabs/=(double)(m+1);
  rms/=(double)(m+1);
  rms=sqrt(rms);
  printf("Generation time: CPU %g, abs. %g.\n",t2-t1,ct2-ct1);
  printf("Average relative error: absolute = %g, r.m.s. = %g.\n",
      avabs,rms);
}

/* CARDINAL test of QUALITY of the generated numbers: */
/* This test is the same as previous one, except that experiment is repeted 
several times for each max. number between 1 and specified, and only the
measures of deviation are printed (those which are printed in the previous 
test at the end). */
if (0)
{
  indtab hyst=NULL;
  vector er=NULL,reler=NULL;
  double dn,dm,dnum,expect,erexpect,relerexpect,avabs,rms;
  int k,num,mmin,mmax,s=0,l=0,xl=0,xxl=0;
  n=10000;
  mmin=1;
  mmax=35;
  num=4;
  
  printf("\nCARDINAL QUALITY of generated random numbers: Frequency test:\n");
  printf("Max. max.: %i, generations/experiment: %i.\n",mmax,n);

  for (m=mmin;m<=mmax;++m)
    for (k=1;k<=num;++k)
    {

      hyst=newindtabrn(1,m+1);
      for (i=1;i<=m+1;++i)
        hyst->t[i]=0;
      er=getvector(m+1);
      reler=getvector(m+1);
      dn=(double) n;
      dm=(double) m;
      dnum=dm+1.0;
      expect=dn/dnum;
      erexpect=sqrt(expect);
      relerexpect=erexpect/expect;
      /*
      printf("Generate: %i numbers from 0 to %i (uniform distribution):\n",n,m);
      printf("Expected number of hits for each cell: %g, error %g (rel. %g).\n",
          expect,erexpect,relerexpect);
      */
       timeinitrand();
      seedrandrandmt(111);    /* Random initialization */
      seedrandrandexp(111);   /* Random initialization */
      ct1=cputime();
      t1=absolutetime();
      for (i=1;i<=n;++i)
      {
        if (i%100000==0)
          printf(".");

        ix=randintdetexp(m);

        /*
        ix=randintdetmt(m);
        ix=rand()%(1+m);
        */
        ++(hyst->t[1+ix]);
      }
      ct2=cputime();
      t2=absolutetime();
      /*
      printf("\nResults:\n%4s %6s %9s %8s  %-s\n","No.","hits",
          "error","rel. er.","re/exp.");
      */
      avabs=0;
      rms=0;
      for (i=1;i<=m+1;++i)
      {
        er->v[i]=(double) hyst->t[i]-expect;
        reler->v[i]=er->v[i]/expect;
        /*
        printf("%4i %6i %9.5g %8.3g  %-g\n",i-1,hyst->t[i],
            er->v[i],reler->v[i],reler->v[i]/relerexpect);
        */
        avabs+=fabs(reler->v[i]/relerexpect);
        rms+=(reler->v[i]/relerexpect)*(reler->v[i]/relerexpect);
      }
      avabs/=(double)(m+1);
      rms/=(double)(m+1);
      rms=sqrt(rms);
      /*
      printf("Generation time: CPU %g, abs. %g.\n",t2-t1,ct2-ct1);
      */
      printf("max.: %i, Av. rel. error: absolute = %8.3g, r.m.s. = %g.\n",
          m,avabs,rms);
      if (rms<0.5)
      {
        printf("    small r.m.s.\n");
        ++s;
      } else if (rms>1.2)
      {
        if (rms>1.5)
        {
          ++xl;
          if (rms>2)
          {
            printf("\n\n    EXTRA LARGE r.m.s. at:  %i\n\n\n",m);
            ++xxl;
          } else
          {
            printf("\n\n    LARGE r.m.s. at:  %i\n\n\n",m);
          }
        } else
        {
          printf("    Large r.m.s. at:  %i\n\n",m);
          ++l;
        }
      }
   }
  printf("Warning summary:\nS: %i \nL: %i \nXL: %i \n",s,l,xl);
  if (xxl>0)
    printf("\nXXL: %i \n",xxl);
  printf("\n");
}


if (0)
{
  /* Test of calculating the volume of a unit sphere in given number of
  dimensions by Monte Carlo integration: */
  double accuracy=0.1,norm,vol;
  unsigned long n=0,hits=0;
  int dim=12,i;
  vector r=NULL;
  printf("\nVolume of the unit sphere in %i dimensions by Monte Carlo integration:\n",
      dim);
  r=getvector(dim);
  seedrandtimeexp(1111);
  seedrandtimemt(1111);
  timeinitrand();
  ct1=cputime();
  t1=absolutetime();
  hits=n=0;
  while (hits<1 || ( sqrt((double) hits) / (double) hits) >accuracy)
  {
    /* Uniformly distributed random point in unit cube */
    if (n%100000==0)
      printf(".");
    for (i=1;i<=dim;++i)  
      r->v[i]=random1();
    /* Calculate its length: */
    norm=0;
    for (i=1;i<=dim;++i)
      norm+=r->v[i]*r->v[i];
    norm=sqrt(norm);
    /* Check if the point lies within the unit cube: */
    if (norm<=1.0)
      ++hits;
    ++n;
  }
  ct2=cputime();
  t2=absolutetime();
  vol=(double) hits/(double) n;
  printf("\nVolume of the unit sphere in %i dimensions: %g (=%g Pi r^%i).\n",
    dim,vol,vol/(ConstPi*pow(0.5,(double) dim)),dim);
  printf("%i generations, %i hits, rel. accuracy %g.\n",n,hits,accuracy);
  printf("Comput. time: CPU %g, abs. %g.\n",t2-t1,ct2-ct1);
}
}



/*

Explanation to transform for obtaining random num. 

max=4, the first line counts number of redundant outcomes for a given RAND_MAX,
which is listed in the outlined line.

See randdetbasmt, randdetbasexp, randdetbas, ...

1   2   3   4   0 | 1   2   3   4   0 | 1   2   3 (1 + rand % (max+1)) % (max+1)

0   1   2   3   4 | 0   1   2   3   4 | 0   1   2 | rand % (max+1)
------------------|-------------------|-----------|-----------------
0   1   2   3   4 | 5   6   7   8   9 |10  11  12 | rand (RAND_MAX)
------------------|-------------------|-----------|-----------------
1   2   3   4   5 | 6   7   8   9   10|11  12  13 | rand+1
1   2   3   4   0 | 1   2   3   4   0 | 1   2   3 | (rand+1) % (max+1)

*/