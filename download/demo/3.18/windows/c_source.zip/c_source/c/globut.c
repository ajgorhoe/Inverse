
/* Identify the contect of globut.c - for macro definitions in globut.h that
concern temporary files: */
#define INCLUDED_globut_c

    /* GLOBAL UTILITIES (definition of directories, resources, editor, browser,
    program data...) */


#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stddef.h>
#include <stdarg.h>
#include <limits.h>


#include <mtypes.h>
#include <er.h>
#include <strop.h>
#include <st.h>
#include <rf.h>
#include <rand.h>
#include <fop.h>
#include <titles.h>
#include <mtime.h>
#include <itk.h>
#include <globut.h>


/* Names of the environment variable that stores the software root (home)
directory, of the identification file in this directory, of mark file that
stores the location of software root, and the recommended name of the root
(see function setighomenames). */
static char *ighomeenv ="IGHOME",*ighomeidfile="ighome.did";
static char *ighomemarkfile=".ighome.dmk";
#if defined (UNIX)
  static char *recighomename="ighome/";
#elif defined(DOSWN)
  static char *recighomename="ighome\\";
#else
  static char *recighomename="ighome/";
#endif
/* Data structure of the module: */
static globutdata gud=NULL;
/* Maximum number of sessions: */
static int maxsessions=300;


    /* CHANGING THE DEFAULT SOFTWARE ROOT NAME SETTINGS: */

void setighomenames(char *envvar,char *idfile,char *markfile,
                    char *defaultname)
    /* Changes the default names related to the software root directory. If any
    of the function arguments is NULL or "", then the corresponding name is not
    changed. Otherwise the corresponding name is set to the argument. Copy of
    the argument is made to represent a given name, therefore the strings passed
    as arguments to this function may be deallocated after the call.
      Meaning of the arguments:
      envvar - the environment variable assigned to store the location of the
    software root directory.
      idfile - name of the identification file which must exist in the software
    root directory in order to identify that this is really a software root.
      markfile - name of the mark file which can be put to a number of standard
    locations on the file system (dependet on the operating system) in order to
    identify the location of the software root. This mechanism is handled
    automatically by this module and enables fast location fo the software root
    directory in the case that the appropriate environment variable is not set
    or is not set correctly.
      defaultname - Usual name of the software root directory. This name can be
    overridden by the user when installing the first software that uses this
    system.
      REMARKS
      This module works in such a way that the software root directory should be
    correctly identified even if the environment variable is not set correctly
    or if mark files do not identify the correct location of software root.
    Information on the location is always checked and any uncorrect information
    (e.g. in mark files) tries to be corrected. The only limitation is that the
    identification fie may not be modified or copied somewhere else on the
    mounted file system.
      This function enables various different softwares to use the functionality
    of this module, but with different names and independently of other
    software.
    $A Igor apr03; */
{
if (stringlength(envvar)>0)
  ighomeenv=stringcopy(envvar);
if (stringlength(idfile)>0)
  ighomeidfile=stringcopy(idfile);
if (stringlength(markfile)>0)
  ighomemarkfile=stringcopy(markfile);
if (stringlength(defaultname)!=0)
  recighomename=stringcopy(defaultname);
}



    /* FUNCTIONS FOR MANIPULATING LOCATION OF THE SOFTWARE ROOT: */


static int searchighome=1;  /* allows auto location of ighome */
static int reqighome=1;      /* ighome is required */
static int reqpropighome=1;  /* proper ighome required (such that the file
           named ighomeidfile exists in it */


void setighomesearch(int i)
    /* Enables (i=1) or disables (i=0) auto location of the software root
    directory.
    $A Igor apr03; */
{
searchighome=i;
}


void setighomereq(int i)
    /* Sets (i=1) or unsets (i=0) the ighome required option. If this option is
    set then, the program must have an ighome directory, but not necessarily
    the proper one (such with the file named ighomeidfile in it).
    $A Igor apr03; */
{
reqighome=i;
}

void setighomereqprop(int i)
    /* Sets (i=1) or unsets (i=0) the proper ighome required option. If this
    option is set, then the program must have a proper ighome directory, (such
    with the file named ighomeidfile in it).
    $A Igor apr03; */
{
reqpropighome=i;
}



void recighomeloc(stack list)
    /* Loads recommended ighome locations (= complete path of ighome) to the
    stack list, which must be allocated and preferably empty.
    $A Igor apr03; */
{
  char *path=NULL,*sysdrive=NULL,*parent=NULL,*strfilesep=NULL;
  int marknum;
  if (list==NULL)
  {
    errfunc0("recighomeloc");
    sprintf(ers(),"Stack for storing recommended locations of software root not allocated.\n");
    errfunc2();
    return;
  }
  marknum=list->n;
#if defined (UNIX)
  path=dirplusfile("/home/",recighomename);
  if (dirwritable(path))
  {
    pushstack(list,path);
    path=NULL;
  } else
    disppointer((void **) &path);
  path=dirplusfile("/users/",recighomename);
  if (dirwritable(path))
  {
    pushstack(list,path);
    path=NULL;
  } else
    disppointer((void **) &path);
  path=dirplusfile("/usr/",recighomename);
  if (dirwritable(path))
  {
    pushstack(list,path);
    path=NULL;
  } else
    disppointer((void **) &path);
  path=dirplusfile("/etc/",recighomename);
  if (dirwritable(path))
  {
    pushstack(list,path);
    path=NULL;
  } else
    disppointer((void **) &path);
  if (list->n-marknum<1)
  {
    path=dirplusfile("/",recighomename);
    if (dirwritable(path))
    {
      pushstack(list,path);
      path=NULL;
    } else
      disppointer((void **) &path);
  }
  if (list->n-marknum<1)
  {
    path=dirplusfile("/lib/",recighomename);
    if (dirwritable(path))
    {
      pushstack(list,path);
      path=NULL;
    } else
      disppointer((void **) &path);
  }
#elif defined(DOSWN)
  sysdrive=filesystemroot();
  if (sysdrive==NULL)
    return;
  if (dirwritable(sysdrive))
    pushstack(list,dirplusfile(sysdrive,recighomename));
  parent=dirplusfile(sysdrive,"users\\");
  if (dirwritable(parent))
  {
    pushstack(list,dirplusfile(parent,recighomename));
  }
  disppointer((void **) &parent);
  parent=dirplusfile(sysdrive,"home\\");
  if (dirwritable(parent))
  {
    pushstack(list,dirplusfile(parent,recighomename));
  }
  disppointer((void **) &parent);
  if (list->n-marknum<1)
  {
    parent=dirplusfile(sysdrive,"Program Files\\");
    if (dirwritable(parent))
    {
      pushstack(list,dirplusfile(parent,recighomename));
    }
    disppointer((void **) &parent);
  }
  disppointer((void **) &sysdrive);
#else
  strfilesep=stringcopy(" ");
  *strfilesep=filepathseparator();
  sysdrive=filesystemroot();
  if (sysdrive==NULL)
    return;
  if (dirwritable(sysdrive))
    pushstack(list,dirplusfile(sysdrive,recighomename));
  parent=mulddirplusfile(sysdrive,"users",strfilesep,NULL);
  if (dirwritable(parent))
  {
    pushstack(list,dirplusfile(parent,recighomename));
    parent=NULL;
  } else
    disppointer((void **) &parent);
  parent=multdirplusfile(sysdrive,"home",strfilesep,NULL);
  if (dirwritable(parent))
  {
    pushstack(list,dirplusfile(parent,recighomename));
    parent=NULL;
  } else
    disppointer((void **) &parent);
  disppointer((void **) &sysdrive);
  disppointer((void **) &strfilesep);
#endif
if (list->n-marknum<1)
{
  warnfunc1(1,"recighomeloc");
  sprintf(ers(),"Could not automatically suggest any suitable locations for the\n software root directory (\"%s\").\n",
    recighomename);
  sprintf(ers(),"Possible reason: You may not have sufficient privileges for creating directories.\n");
  sprintf(ers(),"Try to log on as system administrator and run the program again,\n");
  sprintf(ers(),"  or you may be able to manually choose an appropriate directory.\n");
  warnfunc2();
}
}



void recighomemarkloc(stack list)
    /* Loads recommended ighome mark locations to the stack list, which must be
    allocated and preferably empty.
    $A Igor apr03; */
{
  char *path=NULL,*sysdrive=NULL,*parent=NULL,*strfilesep=NULL;
  int marknum;
  if (list==NULL)
  {
    errfunc0("recighomeloc");
    sprintf(ers(),"Stack for storing recommended locations of software root not allocated.\n");
    errfunc2();
    return;
  }
  marknum=list->n;
#if defined (UNIX)
  path=stringcopy("/home/");
  if (dirwritable(path))
  {
    pushstack(list,path);
    path=NULL;
  } else
    disppointer((void **) &path);
  path=stringcopy("/users/");
  if (dirwritable(path))
  {
    pushstack(list,path);
    path=NULL;
  } else
    disppointer((void **) &path);
  path=stringcopy("/usr/");
  if (dirwritable(path))
  {
    pushstack(list,path);
    path=NULL;
  } else
    disppointer((void **) &path);
  path=stringcopy("/etc/");
  if (dirwritable(path))
  {
    pushstack(list,path);
    path=NULL;
  } else
    disppointer((void **) &path);
  if (list->n-marknum<2)
  {
    path=stringcopy("/lib/");
    if (dirwritable(path))
    {
      pushstack(list,path);
      path=NULL;
    } else
      disppointer((void **) &path);
  }
  if (list->n-marknum<2)
  {
    path=stringcopy("/var/");
    if (dirwritable(path))
    {
      pushstack(list,path);
      path=NULL;
    } else
      disppointer((void **) &path);
  }
  if (list->n-marknum<1)
  {
    path=stringcopy("/");
    if (dirwritable(path))
    {
      pushstack(list,path);
      path=NULL;
    } else
      disppointer((void **) &path);
  }
#elif defined(DOSWN)
  sysdrive=filesystemroot();
  if (sysdrive==NULL)
    return;
  if (dirwritable(sysdrive))
    pushstack(list,stringcopy(sysdrive));
  parent=dirplusfile(sysdrive,"users\\");
  if (dirwritable(parent))
  {
    pushstack(list,parent);
    parent=NULL;
  } else
    disppointer((void **) &parent);
  parent=dirplusfile(sysdrive,"home\\");
  if (dirwritable(parent))
  {
    pushstack(list,parent);
    parent=NULL;
  } else
    disppointer((void **) &parent);
  if (list->n-marknum<1)
  {
    parent=dirplusfile(sysdrive,"Program Files\\");
    if (dirwritable(parent))
    {
      pushstack(list,parent);
      parent=NULL;
    } else
      disppointer((void **) &parent);
  }
  disppointer((void **) &sysdrive);
#else
  strfilesep=stringcopy(" ");
  *strfilesep=filepathseparator();
  sysdrive=filesystemroot();
  if (sysdrive==NULL)
    return;
  if (dirwritable(sysdrive))
    pushstack(list,stringcopy(sysdrive));
  parent=multdirplusfile(sysdrive,"users",strfilesep,NULL);
  if (dirwritable(parent))
  {
    pushstack(list,parent);
    parent=NULL;
  } else
    disppointer((void **) &parent);
  parent=multdirplusfile(sysdrive,"home",strfilesep,NULL);
  if (dirwritable(parent))
  {
    pushstack(list,parent);
    parent=NULL;
  } else
    disppointer((void **) &parent);
  disppointer((void **) &sysdrive);
  disppointer((void **) &strfilesep);
#endif
if (list->n-marknum<1)
{
  warnfunc1(1,"recighomeloc");
  sprintf(ers(),"Could not automatically suggest any suitable locations for the\n software root directory (\"%s\").\n",
    recighomename);
  sprintf(ers(),"Possible reason: You may not have sufficient privileges for creating directories.\n");
  sprintf(ers(),"Try to log on as system administrator and run the program again,\n");
  sprintf(ers(),"  or you may be able to manually choose an appropriate directory.\n");
  warnfunc2();
}
}

char *readighomelocmark(char *filename)
    /* Reads the location of the software root directory from a file named
    filename and return its path as a dynamically allocated string. If it can
    not read the information (if the file is corrupted, not readable or not in
    the correct format), then NULL is returned.
    $A Igor apr03; */
{
char *cont=NULL,*idstr=NULL,*ret=NULL,*ptr=NULL,*ptr1=NULL;
int length;
cont=filetostr(filename,&length);
if (length>0)
{
  idstr=multstringcat("/",ighomeenv,"/",NULL);
  ptr=memfind(cont,length,idstr,stringlength(idstr));
  if (ptr!=NULL)
  {
    ptr+=stringlength(idstr);
    while (*ptr!='{' && ptr-cont<length)
      ++ptr;
    ptr1=ptr;
    while (*ptr1!='}' && ptr1-cont<length)
      ++ptr1;
    if (*ptr=='{' && *ptr1=='}')
    {
      ++ptr;
      ret=stringncopy(ptr,ptr1-ptr);
    }
  }
}
disppointer((void **) &cont);
disppointer((void **) &idstr);
return ret;
}


void markighomeid(char *path)
    /* Identifies the identity of the software root directory at path so that
    search routines can locate it.
    If path is NULL then the current software root as contained in gud->ighome
    is taken.
    $A apr03; */
{
char *idfile=NULL,*aux=NULL;
FILE *fp;
int createdir=1,overwrite=1;
if (path==NULL)
  path=gud->ighome;
if (path==NULL)
{
  errfunc0("markighomeid");
  sprintf(ers(),"Path of the software root is NULL.\n");
  return;
}
if (!direxists(path))
{
  printf("\nThe directory \"%s\" does not yet exist.\n",path);
  printf("Would you like to create it and use it as the software root (0/1)? ");
  readint(&createdir);
  if (createdir)
    createdirsafe(path);
}
if (! direxists(path))
{
  errfunc0("markighomeid");
  sprintf(ers(),"The directory \"%s\" does not exist.\n",path);
  return;
}
idfile=dirplusfile(path,ighomeidfile);
if (fileexists(idfile))
{
  aux=readighomelocmark(idfile);
  if (aux==NULL)
  {
    warnfunc1(1,"markighomeid");
    sprintf(ers(),"The identification file (\"%s\") already exists.",idfile);
    sprintf(ers(),"The file does not have contain the agreed identity information.");
    sprintf(ers(),"Please confirm overwriting!\n");
    warnfunc2();
    printf("Overwrite the file \"%s\" (0/1)? ",idfile);  readint(&overwrite);
  }
}
if (overwrite)
{
  fp=fopen(idfile,"wb");
  if (fp==NULL)
  {
    errfunc0("markighomeid");
    sprintf(ers(),"The identification file \"%s\" can not be open for writing.\n",
      idfile);
    errfunc2();
  } else
  {
    fprintf(fp,"/%s/ {%s}  \r\n\r\n",ighomeenv,path);
    fprintf(fp,"* {\r\n");
    fprintf(fp,"This file identifies that its containing directory is the software root\r\n");
    fprintf(fp,"directory for programs designed by Igor Gresovnik or for programs that\r\n");
    fprintf(fp,"use Igor's utilities.\r\n");
    fprintf(fp,"\r\n");
    fprintf(fp,"This file should only be present in the root software root, usually named\r\n");
    fprintf(fp,"ighome. It helps programs to determine the ighome directory when the $IGHOME\r\n");
    fprintf(fp,"system variable is not set.\r\n");
    fprintf(fp,"\r\n");
    fprintf(fp,"Please do not change the contents of this file or delete the file.\r\n");
    fprintf(fp,"\r\n");
    fprintf(fp,"$A Igor jan02;\r\n");
    fprintf(fp,"}\r\n");
    fprintf(fp,"\r\n");
    fclose(fp);
  }
}
disppointer((void **) &idfile);
disppointer((void **) &aux);
}


void markighomeloc(char *path,int num)
    /* Marks the software root location on the computer's file system, i.e.
    writes the path of the ighome directory to a number of files located in
    easily locatable pre-defined places (a list returned by recighomemarkloc).
    num is the maximal number of the locations in which the location is marked.
    It is always marked on at least two locations (for the case that a some
    temporary directory would have been identified as a suitable location).
    $A Igor apr03; */
{
stack st=NULL;
int i=0,n=1,validighome=0,overwrite=0;
char *file=NULL,*aux=NULL,*aux1=NULL;
FILE *fp;
if (num<2)
  num=2;
/* If path is NULL, take the current setting for the software root: */
  if (path==NULL)
  path=gud->ighome;
/* Check the validity of the path: */
if (path!=NULL)
{
  if (direxists(path))
  {
    aux=dirplusfile(path,ighomeidfile);
    aux1=readighomelocmark(aux);
    if (aux1!=NULL)
      validighome=1;
    disppointer((void **) &aux);
    disppointer((void **) &aux1);
  }
}
if (!validighome)
{
  warnfunc1(1,"markighomeloc");
  sprintf(ers(),"Directory \"%s\" is not a valid software root directory.\n",path);
  warnfunc2();
  printf("\nWould you like to make the directory \"%s\"\n  a valid software root (0/1)? ",
    path);
  readint(&validighome);
  if (validighome)
  {
    validighome=0;
    if (!direxists(path))
      createdirsafe(path);
    if (direxists(path))
    {
      markighomeid(path);
      aux=dirplusfile(path,ighomeidfile);
      aux1=readighomelocmark(aux);
      if (aux1!=NULL)
        validighome=1;
      disppointer((void **) &aux);
      disppointer((void **) &aux1);
    }
  }
  if (!validighome)
  {
    errfunc0("markighomeloc");
    sprintf(ers(),"Directory \"%s\" could not be made a valid software root directory.\n",
      path);
    errfunc2();
  }
}
if (validighome)
{
  st=newstack(10);
  recighomemarkloc(st);
  n=0;
  i=1;
  while(n<num && i<=st->n)
  {
    file=dirplusfile(st->s[i],ighomemarkfile);
    ++i;
    if (fileexists(file))
    {
      aux=readighomelocmark(file);
      if (aux!=NULL)
      {
        disppointer((void **) &aux);
      } else
      {
        /* It seems that the file already exists but is not the ighome location
        mark file, therefore it should not be overwritten because it probably
        belongs to some other application: */
        overwrite=0;
        if (i+1>=st->n)
        {
          /* We are running out of possible locations, therefore the user is
          asked if the file can be overwritten anyway: */
          printf("\nThe file \"%s\" exists, but is not formatted ass software root mark.\n");
          printf("You can choose to overwrite the file and use it as the mark file, buy you\n");
          printf("must be sure that the file is not used for some other purpose.\n");
          printf("Please check the file and decite if it may be overwritten. If you are not\n");
          printf("sure about that, you can still backup the file and restore it later (it\n");
          printf("is actually not very likely that the file is used for something else).\n");
          printf("  If this program can not overwrite the file, further searches for the\n");
          printf("software root might be slow. However, you can solve this problem by");
          printf("setting the environment variable $s to \"\".\n",ighomeenv,path);
          printf("\nCan the program overwrite this file (0/1)? ");
          readint(&overwrite);
        }
        if (!overwrite)
          continue; 
      }
    }
    fp=fopen(file,"wb");
    if (fp!=NULL)
    {
      ++n;
      fprintf(fp,"This file was automatically generated by markighomeloc(). Please\r\n");
      fprintf(fp,"do not remove the file from its location or change the file.\r\n\r\n");
      fprintf(fp,"/%s/ {%s}  ",ighomeenv,path);
      fclose(fp);
      printf("Software root marked by \"%s\"\n",file);
    }
  }
  dispstackall(&st);
}
}


char * locateighomefrommarks(void)
    /* Tries to locate the software root directory by checking a few standard
    locations on the file system for the mark files that indentify its location.
    Mark files are created by the function markighomeloc().
    $A Igor par03; */
{
stack st=NULL,loc=NULL;
int i,j,k,choice,same=1;
char *ret=NULL,*file=NULL,*dir=NULL,*dirprev=NULL,*idfile=NULL,*aux=NULL;
st=newstack(6);
loc=newstack(6);
recighomemarkloc(st);
if (st->n==0)
{
  warnfunc1(1,"locateighomefrommarks");
  sprintf(ers(),"No locations for software directory marks could be identified.\n");
  warnfunc2();
} else
{
  i=1;
  while(i<=st->n)
  {
    /* Check standard places for mark files and then if mark files point to a
    valid software root: */
    file=dirplusfile(st->s[i],ighomemarkfile);
    dir=readighomelocmark(file);
    if (dir!=NULL)
      idfile=dirplusfile(dir,ighomeidfile);
    if (idfile!=NULL) if (fileexists(idfile))
    {
      /*
      ret=dir;  dir=NULL;
      */
      /* Identification file exists, now check that it contains the mark similar
      to the one in the mark file, just with different contents: */
      aux=readighomelocmark(idfile);
      if (aux!=NULL)
      {
        pushstack(loc,dir);
        dir=NULL;
      }
      else
      {
        warnfunc1(1,"locateighomefrommarks");
        sprintf(ers(),"The software root mark file does not seem to contain the right information.\n",
          file);
        sprintf(ers(),"The contents of the identification file (%s) do not match the agreement.\n",
          ighomeidfile);
        sprintf(ers(),"Mark file: \"%s\", software root: \"%s\"\n",file,dir);
        /* If the information on the software root directory exists in the file
        but it is not correct, the file is deleted. Otherwise it is left
        untouchet because it can belong to something other than the IGHOME system. */
        if (dir!=NULL)
        {
          sprintf(ers(),"Mark file was deleted.\n");
          remove(file);
        } else
          sprintf(ers(),"Mark file was not deleted because it may belong to another application.\n");
        warnfunc2();
      }
    }
    disppointer((void **) &file);
    disppointer((void **) &dir);
    disppointer((void **) &idfile);
    disppointer((void **) &aux);
    ++i;
  }
  if (loc->n==0)
  {
    warnfunc1(1,"locateighomefrommarks");
    sprintf(ers(),"A software root directory could not be identified by checking marks\n");
    sprintf(ers(),"at the agreed locations.\n");
    warnfunc2();
  }
  else if (loc->n==1)
  {
    ret=loc->s[1];
    loc->s[1]=NULL;
  } else
  {
    /* If several locations are found, check if they are unique; If not, ask the
    user to choose one of them: */
    for (j=1;j<=loc->n;++j)
    {
      /* First try to transform all the proposed locations to the same form: */
      cleanpathname((char **) &(loc->s[j]));
      if (same && j>1)
        if (cmpstrings(loc->s[j],loc->s[j-1]))
          same=0;
    }
    if (same)
    {
      ret=loc->s[1];
      loc->s[1]=NULL;
    } else
    {
      /* exclude non-unique entries: */
      for (j=loc->n;j>1;--j)
        for (k=1;k<j;++k)
          if (!cmpstrings(loc->s[j],loc->s[k]))
          {
            aux=delstack(loc,j);
            disppointer((void **) &aux);
          }
      if (loc->n==1)
      {
        ret=loc->s[1];
        loc->s[1]=NULL;
      } else
      {
        warnfunc1(1,"locateighomefrommarks");
        sprintf(ers(),"More than one possible location of the software root was identified.\n");
        sprintf(ers(),"Please choose the preferable location!\n");
        warnfunc2();
        choice=globutmenusimp("Choose the desirable location of the software root!",loc);
        if (choice<1 || choice>loc->n)
        {
          warnfunc1(1,"locateighomefrommarks");
          sprintf(ers(),"The location of the software root was not identified.\n");
          warnfunc2();
        } else
        {
          ret=loc->s[choice];
          loc->s[choice]=NULL;
          printf("\nYou have chosen the directory \"%s\" as the software root.\n");
          printf("You can choose to mark this directory so that it will be uniquely identified\n");
          printf("by further searches.\n");
          choice=1;
          printf("\nMark the software root directory (0/1)? ");  readint(&choice);
          if (choice)
            markighomeloc(ret,2);
        }
      }
    }
  }
}
dispstackall(&st);
dispstackall(&loc);
return ret;
}




static int action(int level,char *name,void *dataptr)
    /* Action argument for diractionrec() when used for searching the ighome.
    Argument must be a stack on which the directory name will be pushed if it
    represents a valid software root. This stack shall be the same as the
    list argument of diractionrec().
    $A Igor apr03; */
{
char *purename;
int ret=0;
static int numcheckedfiles;
if (dataptr==NULL)
{
  errfunc0("action (for locateighomeonfilesys)");
  sprintf(ers(),"Stack for storing the file and directory names is NULL.\n");
  errfunc2();
  return INT_MAX;
}
++numcheckedfiles;
if (numcheckedfiles>=100)
{
  numcheckedfiles=0;
  printf(".");
}
purename=fileminusdir(name);
if (!cmpstrings(purename,recighomename))
{
  char *idfile=NULL,*aux=NULL;
  /* Name is the same as recommended name of the software root; check if there
  is a valid identification file in it; if there is, push the directory to the
  stack. */
  if (direxists(name))
  {
    idfile=dirplusfile(name,ighomeidfile);
    aux=readighomelocmark(idfile);
    if (aux!=NULL)
    {
      printf("\n\nSoftware root has been located: \"%s\".\n\n",name);
      ret=1;
      pushstack((stack)dataptr,stringcopy(name));
    }
  }
  disppointer((void **) &idfile);
  disppointer((void **) &aux);
} else if (!cmpstrings(purename,ighomeidfile))
{
  char *aux=NULL,*dir;
  aux=readighomelocmark(name);
  if (aux!=NULL)
  {
    dir=parentdir(name);
    printf("\n\nSoftware root has been located: \"%s\".\n\n",dir);
    ret=1;
    pushstack((stack)dataptr,dir);
  }
  disppointer((void **) &aux);
}
disppointer((void **) &purename);
return ret;
}


char *locateighomeonfilesys(void)
    /* Searches the file system for the software root directory. It searches for
    the occurances of the directories named recighomename (static variable) and
    files named ighomeidfile. It returns the first valid software root
    directory, i.e. the directory that includes an identification file with
    properly formated identification. Only the system rood drive is searched
    for. The directories are recursively searched by levels (i.e. the root dir.
    first, then all of its contained directories, then contained directories of
    these directories, etc. While searching, files and directories are sorted by
    name and direcotiries are checked before files.
      The function returnes the path of the located software root or NULL if it
    could not be located. The returned string is dynamically allocated and
    can be deallocated by free().
    $A Igor apr03; */
{
char *ret=NULL,*root=NULL;
stack st=NULL;
root=filesystemroot();
if (root==NULL)
{
  warnfunc1(1,"locateighomeonfilesys");
  sprintf(ers(),"Could not locate the file system root on this system,\n");
  sprintf(ers(),"  can not search for the software root.\n");
  warnfunc2();
} else
{
  st=newstack(2);
  diractionrec(root,"*",F_LISTFILES | F_LISTDIRS | F_RECBYLEVELS
                      | F_SORTNAME | F_SORTDIRSFIRST,  F_LISTDIRS | F_SORTNAME,
                  5,0,1,0,
                  NULL,NULL,NULL,NULL,
                  st,st,
                  action,NULL,NULL,NULL);
  if (st->n>0)
  {
    ret=st->s[1];
    st->s[1]=NULL;
  } else
  {
    warnfunc1(1,"locateighomeonfilesys");
    sprintf(ers(),"Could not locate the software root in \"%s\".\n",root);
    warnfunc2();
  }
}
disppointer((void **) &root);
dispstackall(&st);
return ret;
}



        /**********************************/
        /*                                */
        /* INITIALIZATION OF GLOBAL DATA: */
        /*                                */
        /**********************************/


static void creategud(void)
    /* Creates global utility data structure if it does not yet exists and
    initialises it to empty state.
    $A Igor jan02; */
{
if (gud==NULL)
{
  gud=malloc(sizeof(*gud));
  memset(gud,0,sizeof(*gud));
  gud->dd=18;
  gud->mm=1;
  gud->yy=2002;
}
}


void fprintglobutdata(FILE *fp)
    /* Print global utility data to file fp.
    $A Igor jan02; */
{
if (fp!=NULL)
{
  fprintf(fp,"\n\nProgramme's global utility data:\n");
  if (gud==NULL)
    fprintf (fp,"NULL");
  else
  {
    fprintf(fp,"  Basis home:           %s\n",gud->ighome);
    fprintf(fp,"  Programme:            %s\n",gud->program);
    fprintf(fp,"  Prog. computer name:  %s\n",gud->prog);
    fprintf(fp,"  Author:               %s\n",gud->author);
    fprintf(fp,"  Version:              %i\n",gud->version);
    fprintf(fp,"  Subversion:           %i\n",gud->subversion);
    fprintf(fp,"  Session:              %i\n",gud->session);
    fprintf(fp,"  Complete ver. (num.): %g\n",gud->doubleversion);
    fprintf(fp,"  Complete ver. (str.): %s\n",gud->stringversion);
    fprintf(fp,"  Creation date (dd/mm/yy):            %i.%i.%i\n",gud->dd0,gud->mm0,gud->yy0);
    fprintf(fp,"  Expiraation date (dd/mm/yy):         %i.%i.%i\n",gud->dd,gud->mm,gud->yy);
    fprintf(fp,"  Reserve expiraation date (dd/mm/yy): %i.%i.%i\n",gud->dd1,gud->mm1,gud->yy1);
    fprintf(fp,"    Resource directories:\n");
    fprintf(fp,"  Programme:        %s\n",gud->progdir);
    fprintf(fp,"  This version:     %s\n",gud->verdir);
    fprintf(fp,"  Current session:  %s\n",gud->sesdir);
    fprintf(fp,"  Session ID:       %i\n",gud->sesid);
    fprintf(fp,"    External utilities:\n");
    fprintf(fp,"  Editor:    %s\n",gud->editor);
    fprintf(fp,"  Biewer:    %s\n",gud->viewer);
    fprintf(fp,"  Browser:   %s\n",gud->browser);
    /*
    fprintf(fp,"  :    %s",gud->);
    */
  }
  fprintf(fp,"\n\n");
}
}


void printglobutdata(void)
    /* Prints global utility data to standard output.
    $A Igor jan02; */
{
fprintglobutdata(stdout);
}


globutdata getglobutdata(void)
    /* Returns a pointer to the global utility data. If the data does not yer
    exists, it initialises it.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud;
}



    /* FUNCTIONS FOR SETTING BASIC DATA: */


void globutsetprogram(char *program)
    /* Sets program name to program.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->program));
gud->program=stringcopy(program);
}

void globutsetprog(char *prog)
    /* Sets program computer name to prog.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->prog));
gud->prog=stringcopy(prog);
}

void globutsetauthor(char *author)
    /* Sets author name to author.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->author));
gud->author=stringcopy(author);
}

void globutsetauthormail(char *authormail)
    /* Sets author's mail to authormail.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->authormail));
gud->authormail=stringcopy(authormail);
}

void globutsetauthorad1(char *authorad1)
    /* Sets first part of author's address to authorad1 (this information is
    rarely set).
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->authorad1));
gud->authorad1=stringcopy(authorad1);
}

void globutsetauthorad2(char *authorad2)
    /* Sets second part of author's address to authorad2 (this information is
    rarely set).
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->authorad2));
gud->authorad2=stringcopy(authorad2);
}

void globutsetwww(char *www)
    /* Sets www address of program home page to www.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->www));
gud->www=stringcopy(www);
}

void globutsetmail(char *mail)
    /* Sets program correspondence mail address to mail.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->mail));
gud->mail=stringcopy(mail);
}

void globutsetversion(int version,int subversion)
    /* Sets program version to version and its subversion to subversion.
    If either of them is less than 0, it is not set (this enables setting
    version and subversion at different locations).
    $A Igor jan02; */
{
if (version<0 && subversion<0)
{
  errfunc0("globutsetversion");
  fprintf(erf(),"Both version and subversion are less than zero.\n");
  errfunc2();
} else
{
  if (gud==NULL)
    creategud();
  if (version>=0)
    gud->version=version;
  if (subversion>=0)
    gud->subversion=subversion;
}
}

void globutsetverspec(char *verspec)
    /* Sets program version specification  to verspec (this should be for
    example "DEMO", "shareware", "full", "professinal", etc.)
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->verspec));
gud->verspec=stringcopy(verspec);
}

void globutsetcreationdate(int dd,int mm,int yy)
   /* Sets program creation date to date specified by dd, mm and yy.
   $A Igor jan02; */
{
if (gud==NULL)
  creategud();
if (yy<100 || yy<1000)
  yy+=2000;
gud->dd0=dd;
gud->mm0=mm;
gud->yy0=yy;
}

void globutsetexpirationdate(int dd,int mm,int yy)
   /* Sets program expiration date to date specified by dd, mm and yy.
   $A Igor jan02; */
{
if (gud==NULL)
  creategud();
if (yy<100 || yy<1000)
  yy+=2000;
gud->dd=dd;
gud->mm=mm;
gud->yy=yy;
}

void globutsetreserveexpirationdate(int dd,int mm,int yy)
   /* Sets program expiration date to date specified by dd, mm and yy.
   $A Igor jan02; */
{
if (gud==NULL)
  creategud();
if (yy<100 || yy<1000)
  yy+=2000;
gud->dd1=dd;
gud->mm1=mm;
gud->yy1=yy;
}

void globutseteditor(char *editor)
    /* Sets external editor command to editor.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->editor));
gud->editor=stringcopy(editor);
}

void globutsetviewer(char *viewer)
    /* Sets external viewer command to viewer.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->viewer));
gud->viewer=stringcopy(viewer);
}

void globutsetbrowser(char *browser)
    /* Sets external internet browser command to browser.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->browser));
gud->browser=stringcopy(browser);
}




    /* FUNCTIONS FOR GETTING SPECIFIC DATA: */


char *globutgetprogram(void)
    /* Returns program name.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->program;
}

char *globutgetprog(void)
    /* Returns program computer name.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->prog;
}

char *globutgetauthor(void)
    /* Returns author name.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->author;
}

char *globutgetauthormail(void)
    /* Returns author's mail.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->authormail;
}

char *globutgetauthorad1(void)
    /* Returns first part of author's address.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->authorad1;
}

char *globutgetauthorad2(void)
    /* Returns second part of author's address.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->authorad2;
}

char *globutgetwww(void)
    /* Returns www address of program home page.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->www;
}

char *globutgetmail(void)
    /* Returns program correspondence mail address.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->mail;
}

int globutgetversion(void)
    /* Returns program version.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->version;
}


char *globutgetversionstr(void)
    /* Returns a string representation of program version. The returned
    pointer to string may not be de-allocated.
    $A Igor mar04; */
{
static char buf[8]="\0";
if (buf[0]=='\0')
  sprintf(buf,"%i",globutgetversion());
return buf;
}


char *globutgetverspec(void)
    /* Returns program version specification (such as "DEMO", "sgareware"...).
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->verspec;
}

int globutgetsubversion(void)
    /* Returns program subversion.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->subversion;
}


char *globutgetsubversionstr(void)
    /* Returns a string representation of program subversion. The returned
    pointer to string may not be de-allocated.
    $A Igor mar04; */
{
static char buf[8]="\0";
if (buf[0]=='\0')
  sprintf(buf,"%i",globutgetsubversion());
return buf;
}


void globutgetcreationdate(int *dd,int *mm,int *yy)
   /* Writes program creation date to *dd, *mm and *yy.
   $A Igor jan02; */
{
if (gud==NULL)
  creategud();
*dd=gud->dd0;
*mm=gud->mm0;
*yy=gud->yy0;
}

void globutgetexpirationdate(int *dd,int *mm,int *yy)
   /* Writes program expiration date to *dd, *mm and *yy.
   $A Igor jan02; */
{
if (gud==NULL)
  creategud();
*dd=gud->dd;
*mm=gud->mm;
*yy=gud->yy;
}

void globutgetreserveexpirationdate(int *dd,int *mm,int *yy)
   /* Writes program reserve expiration date to *dd, *mm and *yy.
   $A Igor jan02; */
{
if (gud==NULL)
  creategud();
*dd=gud->dd1;
*mm=gud->mm1;
*yy=gud->yy1;
}

char *globutgeteditor(void)
    /* Returns external editor command.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->editor;
}

char *globutgetviewer(void)
    /* Returns external viewer command.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->viewer;
}

char *globutgetbrowser(void)
    /* Returns external browswer command.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->browser;
}

/* Data which is usually not set directly: */

static int numrecgetighome=0;


char *globutighomeprimitive()
    /* A less sophisticated way of getting the software root directory, does
    not need extensive file operations. Threfore it is convenient for the
    initialization of the Tcl interpreter, since Tcl interpreter is not used
    when calling this function.
    Warning:
      The returned string may not be deallocated! Also this function may not be
    called at the same time from two threads.
    $A Igor feb04; */
{
char *fname=NULL,*ret=NULL,*aux=NULL;
static char *home=NULL;
if (home!=NULL)
{
  disppointer((void **) &home);  /* don't automatically return previously obtained
      path, so that there is a possibility of requesting that the operation
      is repeated */
}
if ((aux=getenv(ighomeenv))==NULL)
{
  warnfunc1(1,"globutighomeprimitive");
  sprintf(ers(),"System environment variable %s not defined.\n",ighomeenv);
  sprintf(ers(),"It is recommendable to define this variable so that it points \nto the software root directory.\n");
  warnfunc2();
  printf("\n\nPlease insert the path to the software root directory!\n");
  printf("Path: \n"); readstring(&home);
} else
  home=stringcopy(aux);
aux=NULL;
if (home!=NULL)
{
  if (!direxistsprimitive(home))
  {
    errfunc0("globutighomeprimitive");
    sprintf(ers(),"The directory identified as software root does not exist.\n");
    sprintf(ers(),"Directory: \"%s\".\n",home);
    errfunc2();
    disppointer((void **) &home);
  } else
  {
    fname=dirplusfile(home,ighomeidfile);
    if (fileexistsprimitive(fname))
    {
      aux=readighomelocmark(fname);
      if (aux==NULL)
      {
        warnfunc1(2,"globutighomeprimitive");
        sprintf(ers(),"The system root directory does not seem authentic.\n");
        sprintf(ers(),"Identification file (not valid): \"%s\"\n",fname);
        sprintf(ers(),"Directory: \"%s\"\n",home);
        warnfunc2();
      } else
        disppointer((void **) &aux);
    } else
    {
      warnfunc1(2,"globutighomeprimitive");
      sprintf(ers(),"The system root directory does not seem authentic.\n");
      sprintf(ers(),"Identification file does not exist.\n",fname);
      sprintf(ers(),"Should be: \"%s\"\n",fname);
      warnfunc2();
    }
    disppointer((void **) &fname);
  }
}
return home;
}

/*
static char *ighometmp=NULL;
*/

char *globutgetighome(void)
    /* Returns baisc root directory. If none of initializations of the global
    utility system has been performed before the call to this function, the
    search for this directory is performed.
    $A Igor jan02 apr04; */
{
++numrecgetighome;
if (numrecgetighome>5)
{
  errfunc0("globutgetighome");
  sprintf(ers(),"Function called recursively 5 times.\n");
  sprintf(ers(),"Possible bug or problem in Tcl initialization.\n");
  errfunc2();
} else
{
  if (gud==NULL)
    creategud();
  if (gud->ighome==NULL)
    globutupdateprogdir();
}
--numrecgetighome;
return gud->ighome;
}

char *globutgetstringversion(void)
    /* Returns program version in string form.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->stringversion;
}

char *globutgetprogdir(void)
    /* Returns program directory.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->progdir;
}

char *globutgetverdir(void)
    /* Returns program version directory.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->verdir;
}

int globutgetsesid(void)
    /* Returns session id or 0 if the program does not create sessions.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->sesid;
}

char *globutgetsesdir(void)
    /* Returns program session directory.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->sesdir;
}


char *globutgetsesfile(void)
    /* Returns program session file.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
return gud->sesfile;
}





    /* FUNCTIONS FOR UPDATING VARIOUS DEPENDENCIES: */



char *globutlocateighome(void)
    /* Locates the software root directory. First it checks the system
    variable whose name is stored in the variable ighomeenv. If this is not
    successful, the file system is searched for the directory. Directory is
    identified by the file whose name is in the variable ighomeidfile. If
    neither the check of environment variable nor the search of the file
    system is successful, the user is asked for the s. root directory. The
    function returns dynamically allocated path of the software root
    directory.
    $A Igor apr03; */
{
char *fname=NULL,*home=NULL,*ret=NULL,*aux=NULL;
int proper,answer;
if (!reqighome)
  return NULL;
else
{
  if ((home=getenv(ighomeenv))==NULL)
  {
    warnfunc1(2,"globutlocateighome");
    sprintf(ers(),"System environment variable %s not defined.\n",ighomeenv);
    sprintf(ers(),"It is recommendable to define this variable so that it points \nto the software root directory.\n");
    warnfunc2();
  } else
  {
    if (reqpropighome)
    {
      fname=dirplusfile(home,ighomeidfile);
      if (fileexists  /* primitive */ (fname))
      {
        aux=readighomelocmark(fname);
        if (aux!=NULL)
        {
          ret=stringcopy(home);
          disppointer((void **) &aux);
        }
      }
    } else
      if (direxists  /* primitive */ (home))
        ret=stringcopy(home);
    if (ret==NULL)
    {
      warnfunc1(1,"globutlocateighome");
      sprintf(ers(),"The directory \"%s\" is not a valid software root directory.\n",
        home);
      sprintf(ers(),"Directory name was obtained from the environment variable %s.\n",
        ighomeenv);
      sprintf(ers(),"Please update the environmental variable so that it will indicate\n");
      sprintf(ers(),"the correct location of the software root.\n");
      warnfunc2();
    }
    disppointer((void **) &fname);
  }
  if (ret==NULL && searchighome)
  {
    /* Environment variable not set or does not indicate a proper location of
    the software root directory; Search the file system for the location, first
    try to find marh files at standard locations, if this fails, do a real
    search by recursively checking the directories Only a proper software root
    directory (containing a valid identification) can be located in this way,
    therefore a time demanding complete search is omitted if a proper ighome
    is not required. */
    ret=locateighomefrommarks();
    if (ret==NULL && reqpropighome)
      ret=locateighomeonfilesys();
  }
  if (ret==NULL)
    proper=0;
  while (!proper)
  {
    /* Unable to locate program home directory, ask user for help: */
    printf("\n\nWarning: Unable to locate the program root (home) directory.\n");
    printf("\nPlease create the root directory if necessary and insert its name (it\n");
    printf("  should be contained in the environment variable %s)!\n",ighomeenv);
    printf("You can insert an empty string if you want to use just the program directory.\n");
    printf("\nDirectory name: ");
    readstring(&(ret));
    if (ret!=NULL && stringlength(ret)==0)
      disppointer((void **) &ret);
    if (ret!=NULL)
    {
      /* Check if the inserted directory is really the software root: */
      proper=0;
      if (reqpropighome)
      {
        fname=dirplusfile(ret,ighomeidfile);
        if (fileexists (fname))
        {
          aux=readighomelocmark(fname);
          if (aux!=NULL)
          {
            proper=1;
            disppointer((void **) &aux);
          }
        }
        if (!proper)
        {
          printf("\nThe directory \"%s\" which you have inserted\n");
          printf("Is not a valid software root directory:\n");
          printf("The directory does not contain proper identification.\n");
          printf("\nTry to create an one and make it a valid software toot (0/1)?");
          answer=0;
          readint(&answer);
          if (answer)
          {
            /* Try to create identification in the directory and verify: */
            markighomeid(ret);
            if (fileexists (fname))
            {
              aux=readighomelocmark(fname);
              if (aux!=NULL)
              {
                proper=1;
                disppointer((void **) &aux);
              }
            }
          }
          disppointer((void **) &fname);
        }
      } else
        if (direxists(ret))
          proper=1;
      if (!proper)
      {
        printf("The inserted directory \"%s\" is not a valid software root directory.\n",
          ret);
        sprintf(ers(),"You can insert a new directory or cancel the operation.\n");
        disppointer((void **) &ret);
        printf("\nInsert a new software root (0/1)?"); answer=1;
        readint(&answer);
        if (!answer)
        {
          /* The following causes exit the loop without having the software root
          located: */
          proper=1;
          disppointer((void **) &ret);
        }
      }
    }
  }
  if (ret==NULL)
  {
    errfunc0("globutlocateighome");
    sprintf(ers(),"Could not locate the software root directory.\n");
    errfunc2();
  }
}
return ret;
}




static void globutmarkdir(char *dirname)
    /* If a file readme.txt does not exist in the directory dirname, it creates
    it and writes some basic data about the program in it. Function reports an
    error if it can not create the file.
    $A Igor jan02; */
{
FILE *fp;
char *name;
name=dirplusfile(dirname,"readme.txt");
if ((fp=fopen(name,"rb"))!=NULL)
{
  fclose(fp);
} else
{
  fp=fopen(name,"wb");
  if (fp!=NULL)
  {
    fprintf(fp,"\nThis file and the directory containing it were created by\r\nprogram %s (%s) %s, session %i\nat ",
     gud->prog,gud->program,gud->stringversion,gud->sesid);
    fprinttime(fp);
    fprintf(fp,"\n\n");
    fclose(fp);
  } else
  {
    errfunc0("globutmarkdir");
    fprintf(erf(),"Unable to read & write in the directory %s.\n",dirname);
    errfunc2();
  }
}
disppointer((void **) &name);
}



void globutupdatedates(void)
    /* Does the necessary houskeeping concerning dates: prompts to exit if the
    expiration date is exceeded, and exits unconditionally if also the reserve
    expiration date is exceeded (this can be prevented by not settting the
    reserve expiration date).
    $A Igor jan02; */
{
int answer;
if (gud==NULL)
  creategud();
if (gud->yy1>0)
{
 if (laterdate(gud->dd1,gud->mm1,gud->yy1) && laterdate(gud->dd,gud->mm,gud->yy))
 {
   printf("\n\nValidity of this programe has expired %i days ago.\n\n",-dateshift(gud->dd,gud->mm,gud->yy));
   exit(0);
 }
}
if (gud->yy>0)
{
 if (laterdate(gud->dd,gud->mm,gud->yy))
 {
   printf("\n\nValidity of this programe has expired %i days ago.\n",-dateshift(gud->dd,gud->mm,gud->yy));
   printf("Continue execution anyway (0/1)? "); readint(&answer);
   if (answer==0)
     exit(0);
 }
}
}


void globutupdateversion(void)
    /* Updates dependent version data on basis of basic data.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
gud->doubleversion=gud->subversion;
while (gud->doubleversion>=1)
  gud->doubleversion*=0.1;
if (gud->subversion>0 && gud->subversion<10)
  gud->doubleversion*=0.1;
gud->doubleversion+=gud->version;
disppointer((void **) &(gud->stringversion));
if (gud->subversion!=0)
  sprintf(tmpstringbuf(),"%g",gud->doubleversion);
else
  sprintf(tmpstringbuf(),"%i.%i",gud->version,gud->subversion);
gud->stringversion=stringcopy(tmpstringbuf());
}




void globutupdateprogdir(void)
    /* Updates directory dependencies; Also checks if individual directories
    are valid.
    $A Igor jan02; */
{
char *name=NULL;
int ret;
if (gud==NULL)
  creategud();
if (gud->prog==NULL)
  gud->prog=stringcopy("unknown");
if (gud->stringversion==NULL)
  globutupdateversion();
if (gud->ighome==NULL)
{
  /*
  if ((home=getenv(ighomeenv))!=NULL)
    gud->ighome=stringcopy(home);
  */
  gud->ighome=globutlocateighome();
  if (reqighome && stringlength(gud->ighome)==0)
  {
    err0();
    sprintf(ers(),"Software root directory is required by this program, but it could not\n");
    sprintf(ers(),"be located; fatal error, aborting.\n");
    err2();
    exit(-1);
  }
}
/* We check if gud->ighome is a valid directory; if not, the directory name
is deleted: */
if (gud->ighome!=NULL)
{
  if ((ret=createdirsafe(gud->ighome))<0)  /* dir. nonexistent */
    disppointer((void **) &(gud->ighome));
  else if (ret>0)  /* dir. newly created */
    globutmarkdir(gud->ighome);
}
if (gud->ighome==NULL && gud->progdir!=NULL)
{
  /* We check if gud->progdir is a valid directory; if not, the directory name
  is deleted: */
  if ((ret=createdirsafe(gud->progdir))<0)  /* dir nonexistent */
    disppointer((void **) &(gud->progdir));
  else if (ret>0)  /* dir. newly created */
    globutmarkdir(gud->progdir);
}
if (gud->progdir==NULL && gud->ighome==NULL)
{
  /* Unable to locate program home directory, ask user for help: */
  printf("\n\nWarning: Unable to create program home directory.\n");
  printf("\nPlease create the base directory if necessary and insert its name (should be\n");
  printf("  environment variable %s)!\n",ighomeenv);
  printf("You can insert an empty string if you want to use just program directory.\n");
    printf("Directory name: ");
  readstring(&(gud->ighome));
  if (gud->ighome!=NULL) if (gud->ighome[0]=='\0')
    disppointer((void **) &(gud->ighome));
  if (gud->ighome!=NULL)
  {
    /* We check if gud->ighome input by user is a valid directory; if not, the
    directory name is deleted: */
    if ((ret=createdirsafe(gud->ighome))<0)  /* dir. nonexistent */
      disppointer((void **) &(gud->ighome));
    else if (ret>0)  /* dir. newly created */
      globutmarkdir(gud->ighome);
  }
  if (gud->ighome==NULL)
  {
    /* Still unable to locate program home directory. Ask user to input the
    program home directory directly instead of the base directory: */
    printf("\n\nWarning: Still unable to create program home directory.\n");
    printf("\nPlease create the program directory if necessary and input its name!\n");
    printf("Directory name: ");
    readstring(&(gud->progdir));
    if (gud->progdir!=NULL) if (gud->progdir[0]=='\0')
      disppointer((void **) &(gud->progdir));
    if (gud->progdir!=NULL)
    {
      /* We check if gud->progdir input by user is a valid directory; if not, the
      directory name is deleted: */
      if ((ret=createdirsafe(gud->progdir))<0)  /* dir. nonexistent */
        disppointer((void **) &(gud->progdir));
      else if (ret>0)  /* dir. newly created */
        globutmarkdir(gud->progdir);
    }
  }
}
if (gud->ighome==NULL)
{
  if (gud->progdir==NULL)
  {
    errfunc0("globutupdateprogdir");
    fprintf(erf(),"Fatal: unable to locate program directory.\n");
    errfunc2();
    exit(1);
  } else
  {
    gud->ighome=stringcopy(gud->progdir);
    disppointer((void **) &gud->verdir);
    name=stringcat("ver_",gud->stringversion);
    gud->verdir=dirplusfile(gud->progdir,name);
    disppointer((void **) &name);
    /* Verify validity of the directory; If not valid, set it to gud->progdir: */
    if (!direxists(gud->verdir))
    {
      disppointer((void **) &(gud->verdir));
      gud->verdir=stringcopy(gud->progdir);
    }
  }
} else
{
  if (gud->progdir==NULL)
  {
    /* If program dir is not yet specified, this is done and program directory
    is automatically given name within gud->ighome: */
    /* disppointer((void **) &(gud->progdir)); */
    if (gud->prog==NULL)
      gud->prog="unknown";
    gud->progdir=dirplusfile(gud->ighome,gud->prog);
    if ((ret=createdirsafe(gud->progdir))<0)  /* dir. nonexistent */
    {
      errfunc0("globutupdateprogdir");
      fprintf(erf(),"Unable to create program directory %s.\n",gud->progdir);
      fprintf(erf(),"Program directory will be set to %s.\n",gud->ighome);
      errfunc2();
      disppointer((void **) &(gud->progdir));
      gud->progdir=stringcopy(gud->ighome);
    } else if (ret>0)  /* dir. newly created */
      globutmarkdir(gud->progdir);
  }
  if (gud->verdir==NULL)
  {
    /* If program version dir is not yet specified, this is done and the
    directory is automatically given name within gud->progdir: */
    if (gud->stringversion!=NULL)
      name=stringcat("ver_",gud->stringversion);
    else
      name=stringcat("ver_","unknown");
    gud->verdir=dirplusfile(gud->progdir,name);
    disppointer((void **) &name);
    /* Verify validity of the directory; If not valid, set it to gud->progdir: */
    if ((ret=createdir(gud->verdir))<0)  /* dir. nonexistent */
    {
      errfunc0("globutupdateprogdir");
      fprintf(erf(),"Unable to create version directory %s.\n",gud->verdir);
      fprintf(erf(),"Version directory will be set to %s.\n",gud->progdir);
      errfunc2();
      disppointer((void **) &(gud->verdir));
      gud->verdir=stringcopy(gud->progdir);
    } else if (ret>0)  /* dir. newly created */
      globutmarkdir(gud->verdir);
  }
}
}


int globutremovesession(int id)
    /* Removes session directory and file for program session identifyed by id.
    Function returns 1 if the appropriate session file is found, 0 otherwise.
    $A Igor jan02; */
{
char *name=NULL,*p1,*p2;
if (gud->verdir==NULL)
  globutupdateprogdir();
if (gud->verdir==NULL)
{
  errfunc0("globutremoveallsessions");
  fprintf(erf(),"Unable to locate program directory.\n");
  errfunc2();
} else
{
  name=dirplusfile(gud->verdir,"sessions");
  p1=tmpstringbufmin(20+strlen(gud->verdir));
  sprintf(p1,"%s%c",name,filepathseparator());
  disppointer((void **) &name);
  p2=p1+strlen(p1);
  /* Obtain session file name: */
  sprintf(p2,"s_%i.sf",id);
  if (fileexists(p1))
  {
    remove(p1);
    sprintf(p2,"session_%i%c",id,filepathseparator());
    name=stringcopy(p1);
    if (direxists(name))
      removedirrec(name);
    disppointer((void **) &name);
    return 1;
  }
}
return 0;
}

void globutremoveallsessions(void)
    /* Removes session files and directories for all existent sessions
    of the program.
    $A Igor jan02; */
{
char *name=NULL,*p1,*p2;
int id,length;
long pos=1;
FILE *fp;
if (gud==NULL)
  creategud();
if (gud->verdir==NULL)
  globutupdateprogdir();
if (gud->verdir==NULL)
{
  errfunc0("globutremoveallsessions");
  fprintf(erf(),"Unable to locate program directory.\n");
  errfunc2();
} else
{
  name=dirplusfile(gud->verdir,"sessions");
  p1=tmpstringbufmin(20+strlen(gud->verdir));
  sprintf(p1,"%s%c",name,filepathseparator());
  p2=p1+strlen(p1);
  sprintf(p2,"%s","sesid.sf");
  fp=fopen(p1,"rb");
  if (fp==NULL)
  {
    printf("\nNo sessions found in the directory %s.\n",name);
  } else
  {
    while(pos>0)
    {
      /* Search in the file sesid.sf for existent sessions */
      id=(int) filenum(fp,pos,30,&pos,&length);
      if (pos>0)
      {
        globutremovesession(id);
        pos+=length;
      }
    }
    fclose(fp);
    sprintf(p2,"sesid.sf");
    remove(p1);
  }
  disppointer((void **) &name);
}
}


void globutupdatesession(void)
    /* Finds an available session ID and creates session file and session
    directory in the directory gud->verdir/sessions. Name of the session file
    is written to gud->sesfile, name of the session directory to gud->sesdir
    and session ID to gud->ID. Function exits program if it can not find an
    available ID.
    $A Igor jan02; */
{
char *name=NULL,*p1,*p2;
FILE *fp;
if (gud==NULL)
  creategud();
if (gud->verdir==NULL)
  globutupdateprogdir();
if (gud->sesid>0)
{
  /* If session data has already been set, session resources must be destroyed
 first. This happens e.g. when program directory is changed after global
 utility initialisation. */
  if (gud->sesfile!=NULL && gud->sesdir!=NULL)
  {
    globutremovesession(gud->sesid);
    disppointer((void **) gud->sesfile);
    disppointer((void **) gud->sesdir);
  }
}
if (gud->verdir==NULL)
{
  errfunc0("globutupdatesession");
  fprintf(erf(),"Fatal: unable to locate program directory.\n");
  errfunc2();
  exit(1);
} else
{
  name=dirplusfile(gud->verdir,"sessions");
  p1=tmpstringbufmin(20+strlen(gud->verdir));
  sprintf(p1,"%s%c",name,filepathseparator());
  p2=p1+strlen(p1);
  sprintf(p2,"%s","sesid.sf");
  fp=fopen(p1,"ab");
  if (fp==NULL)
  {
    /* It seems that session directory does not exist; Try to create it and
    open file again: */
    createdir(name);
    globutmarkdir(name);
    /* p1 could be corrupted by createdir, therefore we write it again: */
    p1=tmpstringbufmin(20+strlen(gud->verdir));
    sprintf(p1,"%s%c",name,filepathseparator());
    p2=p1+strlen(p1);
    sprintf(p2,"%s","sesid.sf");
    fp=fopen(p1,"ab");
  }
  if (fp==NULL)
  {
    sprintf(p2,'\0');
    errfunc0("globutupdatesession");
    fprintf(erf(),"Fatal: unable to create program sessions directory %s.\n",name);
    errfunc2();
    exit(1);
  } else
  {
    if (flength(fp)<1)
      fprintf(fp,"Do not remove or change this file.\nThis is a session ID file.\nCreated by I.G.'s global utility funcmodule.\n\n");
    fclose(fp);
  }
  gud->sesid=0;
  while (fileexists(p1))
  {
    ++gud->sesid;
    sprintf(p2,"s_%i.sf",gud->sesid);
    if (gud->sesid>maxsessions)
    {
      sprintf(p2,'\0');
      errfunc0("globutupdatesession");
      fprintf(erf(),"Fatal: Max. number of sessions (%i) exceeded.\n",maxsessions);
      fprintf(erf(),"In order to solve the problem, you must delete some session files\n");
      fprintf(erf(),"In the sessions directory %s.\n",name);
      errfunc2();
      exit(1);
    }
  }
  disppointer((void **) &name);
  disppointer((void **) &(gud->sesfile));
  gud->sesfile=stringcopy(p1);
  sprintf(p2,"session_%i%c",gud->sesid,filepathseparator());
  disppointer((void **) &(gud->sesdir));
  gud->sesdir=stringcopy(p1);
  sprintf(p2,"sesid.sf");
  fp=fopen(p1,"ab");
  fprintf(fp,"%i\n",gud->sesid);
  fclose(fp);
  fp=fopen(gud->sesfile,"wb");
  fprintf(fp,"\nSession %i of program %s (%s).\nCreated at: ",gud->sesid,gud->prog,gud->program);
  fprinttime(fp); fprintf(fp,"\n\n");
  fclose(fp);
  if (createdir(gud->sesdir)<0)
  {
    errfunc0("globutupdatesession");
    fprintf(erf(),"Fatal: Session directory %s can not be created.\n",gud->sesdir);
    fprintf(erf(),"Check access permissions for parent directories!\n");
    errfunc2();
    exit(1);
  }
}
}


void globutupdateexternal(void)
    /* Tries to automatically set external editor, viewer and browser.
    $A Igor jan02; */
{
char *name=NULL,*p1,*p2;
if (gud==NULL)
  creategud();
if (gud->ighome==NULL)
  globutupdateprogdir();
if (gud->ighome==NULL)
{
  errfunc0("globutupdateexternal");
  fprintf(erf(),"Unable to determine external utilities (editor, viewer, browser...).\n");
  fprintf(erf(),"Reason: could not locate base directory (should be in environment variable %s)\n",ighomeenv);
  errfunc2();
} else
{
  name=dirplusfile(gud->ighome,"bin");
  p1=tmpstringbufmin(20+strlen(gud->verdir));
  sprintf(p1,"%s%c",name,filepathseparator());
  disppointer((void **) &name);
  p2=p1+strlen(p1);
  #ifdef DOSWN
    if (gud->editor==NULL)
    {
      sprintf(p2,"edit.bat");
      if (fileexists(p1))
        gud->editor=stringcopy(p1);
    }
    if (gud->viewer==NULL)
    {
      sprintf(p2,"view.bat");
      if (fileexists(p1))
        gud->viewer=stringcopy(p1);
    }
    if (gud->browser==NULL)
    {
      sprintf(p2,"browse.bat");
      if (fileexists(p1))
        gud->browser=stringcopy(p1);
    }
  #else
    if (gud->editor==NULL)
    {
      sprintf(p2,"edit");
      if (fileexists(p1))
        gud->editor=stringcopy(p1);
    }
    if (gud->viewer==NULL)
    {
      sprintf(p2,"view");
      if (fileexists(p1))
        gud->viewer=stringcopy(p1);
    }
    if (gud->browser==NULL)
    {
      sprintf(p2,"browse");
      if (fileexists(p1))
        gud->browser=stringcopy(p1);
    }
  #endif
}
}


void globutinit(char progdir,char sesdir,char autoextern)
    /* Performs necessary initialisation and updates of dependencies on
    global utility data. This function is called after setting basic data,
    which is set automatically by the program. If progdir is 1, program will
    have its home directory. If sesdir is 1, program will allocate unique
    session directory. If autoextern is 0, external viewer, program and
    browser will be defined automatically if possible.
    $A Igor jan02 */
{
/*
printf("\n\nEnv. var. IGHOME: %s.\n\n",getenv("IGHOME"));
*/
globutupdatedates();
if (progdir)
  globutupdateversion();
if (gud->ighome==NULL)
  globutupdateprogdir();
if (sesdir)
  globutupdatesession();
if (autoextern)
  globutupdateexternal();
}


void globutend(void)
    /* Global utility clean-up;
    If session file or directory were created, they are deleted.
     Warning:
    If program creates a new session each time it runs, this function must be
    called before the program exits.
    $A Igor jan02; */
{
if (gud->sesfile!=NULL)
  globutremovesession(gud->sesid);
}



    /* FUNCTIONS FOR CHANGING SPECIFIC DATA (similar to functions for setting
    data, but include updating dependencies): */


void globutchangeprogram(char *program)
    /* Changes program name to program.
    $A Igor jan02; */
{
globutsetprogram(program);
}

void globutchangeprog(char *prog)
    /* Changes program computer name to prog.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
disppointer((void **) &(gud->prog));
gud->prog=stringcopy(prog);
globutupdateprogdir();
if (gud->sesid>0)
  globutupdatesession();
}

void globutchangeauthor(char *author)
    /* Changes author name to author.
    $A Igor jan02; */
{
globutsetauthor(author);
}

void globutchangeauthormail(char *authormail)
    /* Changes author's mail to authormail.
    $A Igor jan02; */
{
globutsetauthormail(authormail);
}

void globutchangeauthorad1(char *authorad1)
    /* Changes the first part of author's address to authorad1.
    $A Igor jan02; */
{
globutsetauthormail(authorad1);
}

void globutchangeauthorad2(char *authorad2)
    /* Changes the second part of author's address to authorad2.
    $A Igor jan02; */
{
globutsetauthormail(authorad2);
}

void globutchangewww(char *www)
    /* Changes www address of program home page to www.
    $A Igor jan02; */
{
globutsetwww(www);
}

void globutchangemail(char *mail)
    /* Changes program correspondence mail address to mail.
    $A Igor jan02; */
{
globutsetmail(mail);
}

void globutchangeversion(int version,int subversion)
    /* Changes program version to version and its subversion to subversion.
    If either of them is less than 0, it is not changed (this enables setting
    version and subversion at different locations).
    $A Igor jan02; */
{
if (version<0 && subversion<0)
{
  errfunc0("globutchangeversion");
  fprintf(erf(),"Both version and subversion are less than zero.\n");
  errfunc2();
} else
{
  if (gud==NULL)
    creategud();
  if (version>=0)
    gud->version=version;
  if (subversion>=0)
    gud->subversion=subversion;
  globutupdateversion();
  globutupdateprogdir();
  if (gud->sesid>0)
    globutupdatesession();  
}
}

void globutchangeverspec(char *verspec)
    /* Changes program version specification to verspec.
    $A Igor jan02; */
{
globutsetverspec(verspec);
}

void globutchangecreationdate(int dd,int mm,int yy)
   /* Changes program creation date to date specified by dd, mm and yy.
   $A Igor jan02; */
{
if (gud==NULL)
  creategud();
if (yy<100 || yy<1000)
  yy+=2000;
gud->dd0=dd;
gud->mm0=mm;
gud->yy0=yy;
globutupdatedates();
}

void globutchangeexpirationdate(int dd,int mm,int yy)
   /* Changes program expiration date to date specified by dd, mm and yy.
   $A Igor jan02; */
{
if (gud==NULL)
  creategud();
if (yy<100 || yy<1000)
  yy+=2000;
gud->dd=dd;
gud->mm=mm;
gud->yy=yy;
globutupdatedates();
}

void globutchangereserveexpirationdate(int dd,int mm,int yy)
   /* Changes program reserve expiration date to date specified by dd, mm and
   yy.
   $A Igor jan02; */
{
if (gud==NULL)
  creategud();
if (yy<100 || yy<1000)
  yy+=2000;
gud->dd1=dd;
gud->mm1=mm;
gud->yy1=yy;
globutupdatedates();
}

void globutchangeeditor(char *editor)
    /* Changes external (system) editor command to editor.
    $A Igor jan02; */
{
globutseteditor(editor);
}

void globutchangeviewer(char *viewer)
    /* Changes external (system) viewer command to viewer.
    $A Igor jan02; */
{
globutsetviewer(viewer);
}

void globutchangebrowser(char *browser)
    /* Changes external (system) internet browser command to browser.
    $A Igor jan02; */
{
globutsetbrowser(browser);
}


  /* Data which is usually not set directly: */


void globutchangeighome(char *ighome)
    /* Changes the ighome directory to ighome. It then updates program
    directories according to this. ighome must not be NULL or an empty string.
    $A Igor jan02; */
{
/* int contprogdir=-1,contverdir=-1,contsesdir-1; */
int l,placesesdir=-1;
if (ighome==NULL)
{
  errfunc0("globutchangeighome");
  fprintf(erf(),"Root software directory is NULL.\n");
  errfunc2();
  return;
} else if (ighome[0]=='\0')
{
  errfunc0("globutchangeighome");
  fprintf(erf(),"Root software directory not specified (it is an empty string).\n");
  errfunc2();
  return;
}
if (gud==NULL)
  creategud();
if (gud->ighome!=NULL)
{
  /* We check if gud->ighome contains other directories (program, version and
  session directories), in which case we ensure that these directories will
  also be updated. For program and version directory this is done by deleting
  gud->progdir and gud->verdir, which causes globutupdateprogdir() to update
  these directories; for session directory we will call updatesession() if this
  directory is contained in gud->ighome. */
  l=strlen(gud->ighome);
  if (imemfind(gud->progdir,stringlength(gud->progdir),gud->ighome,l)==0)
    disppointer((void **) &(gud->progdir));
  if (imemfind(gud->verdir,stringlength(gud->verdir),gud->ighome,l)==0)
    disppointer((void **) &(gud->verdir));
  placesesdir=imemfind(gud->sesdir,stringlength(gud->sesdir),gud->ighome,l)==0;
  disppointer((void **) &(gud->ighome));
}
gud->ighome=stringcopy(ighome);
globutupdateprogdir();
if (gud->sesid>0 && placesesdir==0)
  globutupdatesession();  
}

void globutchangeprogdir(char *progdir)
    /* Changes the program directory to progdir. It then updates program
    directories according to this change. progdir must not be NULL or an empty
    string.
    $A Igor jan02; */
{
int l,placesesdir=-1;
if (progdir==NULL)
{
  errfunc0("globutchangeprogdir");
  fprintf(erf(),"Program directory is NULL.\n");
  errfunc2();
  return;
} else if (progdir[0]=='\0')
{
  errfunc0("globutchangeprogdir");
  fprintf(erf(),"Program directory not specified (it is an empty string).\n");
  errfunc2();
  return;
}
if (gud==NULL)
  creategud();
if (gud->progdir!=NULL)
{
  /* We check if gud->ighome contains other directories (version or session
  directory), in which case we ensure that these directories will also be
  updated. For version directory this is done by deleting gud->verdir, which
  causes globutupdateprogdir() to update this directoriey; for session
  directory we will call updatesession() if this directory is contained in
  gud->ighome. */
  l=strlen(gud->progdir);
  if (imemfind(gud->verdir,stringlength(gud->verdir),gud->progdir,l)==0)
    disppointer((void **) &(gud->verdir));
  placesesdir=imemfind(gud->sesdir,stringlength(gud->sesdir),gud->progdir,l)==0;
  disppointer((void **) &(gud->progdir));
}
gud->progdir=stringcopy(progdir);
globutupdateprogdir();
if (gud->sesid>0 && placesesdir==0)
  globutupdatesession();  
}

void globutchangeverdir(char *verdir)
    /* Changes the program version directory to verdir. It then updates program
    directories according to this change.verdir  must not be NULL or an empty
    string.
    $A Igor jan02; */
{
int l,placesesdir=-1;
if (verdir==NULL)
{
  errfunc0("globutchangeverdir");
  fprintf(erf(),"Program version directory is NULL.\n");
  errfunc2();
  return;
} else if (verdir[0]=='\0')
{
  errfunc0("globutchangeverdir");
  fprintf(erf(),"Program version directory not specified (it is an empty string).\n");
  errfunc2();
  return;
}
if (gud==NULL)
  creategud();
if (gud->progdir!=NULL)
{
  /* We check if gud->ighome contains session directory, in which case we will
  call updatesession(). */
  l=strlen(gud->verdir);
  placesesdir=imemfind(gud->sesdir,stringlength(gud->sesdir),gud->progdir,l)==0;
  disppointer((void **) &(gud->verdir));
}
gud->verdir=stringcopy(verdir);
globutupdateprogdir();
if (gud->sesid>0 && placesesdir==0)
  globutupdatesession();  
}

void globutchangesesdir(char *sesdir,char *sesfile)
    /* Changes the process session directory to sesdir and process session
    file to sesfile. sesfile can be NULL, in which case the old session file
    is kept. sesdir must not be NULL or an empty string.
     WARNING:
    This function will not have any effect if globutupdatesession() is called
    after it (or any function which calls globutupdatesession() such as
    globutinit() or changeprogdir() in case that program session ID has already
    been set, etc.
    $A Igor jan02; */
{
FILE *fp;
if (sesdir==NULL)
{
  errfunc0("globutchangesesdir");
  fprintf(erf(),"Session directory is NULL.\n");
  errfunc2();
  return;
} else if (sesdir[0]=='\0')
{
  errfunc0("globutchangesesdir");
  fprintf(erf(),"Session directory not specified (it is an empty string).\n");
  errfunc2();
  return;
}
if (gud==NULL)
  creategud();
if (gud->sesid<=0)
  globutupdatesession();
if (createdirsafe(sesdir)<0)
{
  errfunc0("globutchangesesdir");
  fprintf(erf(),"Unable to create session directory %s.\n",sesdir);
  errfunc2();
} else
{
  if (gud->sesdir!=NULL)
  {
    removedirrec(gud->sesdir);
    free(gud->sesdir);
  }
  gud->sesdir=stringcopy(sesdir);
  if (sesfile!=NULL)
  {
    if (gud->sesfile!=NULL)
    {
      remove(gud->sesfile);
      free(gud->sesfile);
    }
    gud->sesfile=stringcopy(sesfile);
    /* Create new session file and write basic data about the process in it: */
    fp=fopen(sesfile,"wb");
    if (fp==NULL)
    {
      errfunc0("globutchangesesdir");
      fprintf(erf(),"Unable to create session file %s.\n",sesfile);
      errfunc2();
    } else
    {
      fprintf(fp,"\nSession %i of program %s (%s).\nCreated at: ",gud->sesid,gud->prog,gud->program);
      fprinttime(fp); fprintf(fp,"\n\n");
      fclose(fp);
    }
  }
}
}



        /************************/
        /*                      */
        /*  VARIOUS UTILITIES:  */
        /*                      */
        /************************/


void globutprogtitlebas(FILE *fp1,FILE *fp2,int shift)
    /* Prints program title to files fp1 and fp2 if they are not NULL. shift is
    number of spaces printed before the title frame in the text version of the
    title.
    $A Igor jan02; */
{
if (fp1!=NULL)
  fprintf(fp1,"\n");
if (fp2!=NULL)
  fprintf(fp2,"\n");
fprogtitle0(fp1,fp2,gud->program,gud->doubleversion,gud->verspec,
          gud->mm0,gud->yy0,
          gud->author,gud->authormail ,
          gud->authorad1,gud->authorad2,NULL,NULL,2,
          gud->mail,gud->www,NULL,1,shift,2);

/*
if (gud->mail==NULL && gud->authormail!=NULL)
  fprogtitle0(fp1,fp2,gud->program,gud->doubleversion,gud->verspec,
            gud->mm0,gud->yy0,
            gud->author,gud->authormail ,
            gud->authorad1,gud->authorad2,NULL,NULL,2,
            NULL,gud->www,NULL,1,shift,2);
else
  fprogtitle0(fp1,fp2,gud->program,gud->doubleversion,gud->verspec,
            gud->mm0,gud->yy0,
            gud->author, NULL,
            gud->authorad1,gud->authorad2,NULL,NULL,2,
            gud->mail,gud->www,NULL,1,shift,2);

*/
if (fp1!=NULL)
  fprintf(fp1,"\n");
if (fp2!=NULL)
  fprintf(fp2,"\n");
}


void globutprogtitle(FILE *fp,int shift)
    /* Shows program title; if fp!=NULL, a title is also printed in file fp.
    shift is number of spaces printed before the title frame in the text
    version of the title.
    $A Igor jan02; */
{
globutprogtitlebas(stdout,fp,shift);
}



        /************************/
        /*                      */
        /*  GENERAL UTILITIES:  */
        /*                      */
        /************************/


  /* TEMPORARY FILES AND DIRECTORIES */

/* COMMENTS: 
  The function that returns the temporary directory should be OK.
  Need to implement functions equivalent to tmpnam() and tmpfile().
 
   IMPORTANT - TO DO:
  Add the file(s) where the last number of the temp. file within the directory
is memorized, so that file numbers are cyclically chosen. Read and increment
this file when a new directory is chosen (within the lock/unlock tmp dir.!)
If the file can not be updated then report an error and ask user to modify the
access, increment the current number by a random number of usual increments!
  Add random seed that somehow takes into account the absolute and CPU time!
This would enable to obtain different random values from teo processes that
make their first access tot the tempotary file generation almost simultaneously.
Make two versions, one would use only the values provided by absolutetime and
cputime, while the other would e.g. count how many evaluations of something can
be performed in the smallest resolution unit of the absolutetime().

ran
  This must be performed when a new tmp. dir. is selected (since it should
be related to the instance of a temp. directory). 
  Arrange for CYCLIC number incrementation beyond the tmpmaxnum, but by
stopping when all tmpmaxnum possibilities were exhausted (allow for starting
at high numbers, but prevent infinite loops). Find all locations where this
should be done by searching for tmpmaxnum!
  When testing, test also the absolutetime()! Judge if it is appropriate to use
the Tcl system!

    The most SENSITIVE TASK:
with equivalent to tmpfile(), equivalent to fclose() must be provided that will
check if the file pointer was provided by the globuttmpfile(), and will in this
case remove the associated file. An idea is that in globut.h ther would be a
macro replacement of fclose() by that function (named e.g. globutfclose()).
A clean-up mechanism  should also be probided for automatic removal of the
tempporary files if their number exceeds a certain number. This can be e.g.
detected at the first call to the function that provides a temporary file name,
and cleaning in the case of too many temporary files can then be performed by
consent of the user.
   WARNING!
   In the fop.c, this system of temp. files allocation must be switched off in
order to avoid infinite recursion (e.g. functions of this temp. files system
call the functions for listing directory contents, which might (e.g. in absence
of Tcl functionality) in turn use temporary files for writing the results of the
system listing commands).

*/


typedef struct _tmpfiledata {
  char *name;
  FILE *fp;
} *tmpfiledata;


/* Auxiliary data for temporary files system; tmplockfile may not be changed! */

static int tmpdirlock=0,   /* Thread lock for temp. dir. data */
           tmpfilelock=0,  /* Thread lock for temp. file data */
           tmpnumacfail=0, /* Counter of access failures */   
           tmpskiplock=0;  /* Permission to skip locking */
static char *tmpprefix="IG_tmp_",  /* Prefix for temp. files */
         *tmplockfile="IG_tmp_lock"; /* Lock file name */
static int tmpnumlength=6,    /* Length of the serial number string */
           tmpmaxnum=999999,  /* Maximal seq. number of the file */
           cleanuplim=5; /* Maximal clean-up limit */
static double locklim=1.5,   /* Lock timeout limit */
              loclocktime=0; /* Lock time of the current process */
static char *tmpdir=NULL,    /* Temporary directory used by IG */
            *tmpname=NULL,   /* Temp. file name buffer */
            *tmplock=NULL,   /* Temp. dir. lock file name */
            *tmpnumptr=NULL; /* Pointer to temp. file number */
static int ighometmp=0,   /* 1 if tmpdir is contained in software home dir. */
           newtmpdir=1,   /* 1 if temp. dir. has changed */
           tmpnum=0;      /* Sequent. number of temp. file */

static stack tmpfilest=NULL;  /* Records about temp. files (including absolute
             path and file pointer if open by globuttmpfile(). */

static void trytmpighome(void)
    /* Tries to locate the tmeporary directory in the software root directory.
    Auxiliary function for globuttmpdir().
    $A Igor may04; */
{
char *dirname=NULL,*aux=NULL;
static char reported=0;
if (tmpdir!=NULL && ighometmp)  /* nothing to do */
  return;
if (gud!=NULL)
  if (gud->ighome!=NULL)
  {
    aux=dirplusfile(gud->ighome,"tmp/");
    if (stringlength(aux)>0)
    {
      dirname=getabsolutepath(aux);
      if (!direxists(dirname))
        createdirsafe(dirname);
      if (! direxists(dirname) || ! dirwritable(dirname))
      {
        disppointer((void **) dirname);
        if (!reported)
        {
          errfunc0("trytmpighome");
          sprintf(ers(),"The IG temporary directory is not writable or could not be created:\n");
          sprintf(ers(),"%s\n",dirname);
          errfunc2();
          reported=1;
        }
        disppointer((void **) dirname);
      }
    }
    disppointer((void **) &aux);
  }
if (dirname!=NULL)
{
  disppointer((void **) &tmpdir);
  tmpdir=dirname; dirname=NULL;
  ighometmp=1;
}
}

static void trytmpsys(void)
    /* Tries to set the temporary directory name to tmpdirname.
    Auxiliary function for globuttmpdir().
    $A Igor may04; */
{
char *aux=NULL;
if (tmpdir!=NULL)
  return;  /* nothing to do */
#ifdef DOSWN
  if (tmpdir==NULL)
  {
    aux=getenv("TMP");
    if (stringlength(aux)>0)
    {
      tmpdir=getabsolutepath(aux);
      if (!direxists(tmpdir) || ! dirwritable(tmpdir))
        disppointer((void **) &tmpdir);
    }
  }
  if (tmpdir==NULL)
  {
    aux=getenv("TEMP");
    if (stringlength(aux)>0)
    {
      tmpdir=getabsolutepath(aux);
      if (!direxists(tmpdir) || ! dirwritable(tmpdir))
        disppointer((void **) &tmpdir);
    }
  }
  aux=NULL;
  if (tmpdir==NULL)
  {
    tmpdir=getabsolutepath("\\tmp");
    if (!direxists(tmpdir))
      createdirsafe(tmpdir);
    if (!direxists(tmpdir) || ! dirwritable(tmpdir))
      disppointer((void **) &tmpdir);
  }
#endif
#ifdef UNIX
  if (tmpdir==NULL)
  {
    tmpdir=getabsolutepath("/tmp");
    if (!direxists(tmpdir) || ! dirwritable(tmpdir))
      disppointer((void **) &tmpdir);
  }
  if (tmpdir==NULL)
  {
    tmpdir=getabsolutepath("/usr/tmp");
    if (!direxists(tmpdir) || ! dirwritable(tmpdir))
      disppointer((void **) &tmpdir);
  }
#endif
if (tmpdir==NULL)
{
  /* Try also with a directory tmp/ within the current directory: */
  tmpdir=getabsolutepath("tmp/");
  if (!direxists(tmpdir))
    createdirsafe(tmpdir);
  if (! dirwritable(tmpdir))
    disppointer((void **) &tmpdir);
}
}

char *globuttmpdir(void)
    /* Returns path of a temporary directory where temporary files can be put,
    or NULL if such a directory can not be located. The returned directory
    exists and is writable for the current program. It is NOT the same as the
    system temporary directory (if defined), but rather a directory in the
    software root directory or any other suitable directory if this one can
    not be located.
    $A Igor may04; */
{
char *name=NULL;
stack list=NULL;
int i;
m_threadlocksleep(tmpdirlock,1)
if (tmpdir==NULL)
{
  /* Temporary directory has not yet been located, try to locate it: */
  trytmpighome();
  if (tmpdir==NULL)
    trytmpsys();
  if (tmpdir!=NULL)
    newtmpdir=1;
  if (tmpdir==NULL)
  {
    errfunc0("globuttmpdir");
    sprintf(ers(),"Could not locate the temporary directory.\n  Caution!\n");
    sprintf(ers(),"This can result in unexpected behavior of the program.\n");
    errfunc2();
  } else if (!ighometmp)
  {
    warnfunc1(1,"globuttmpdir");
    sprintf(ers(),"Could not provide a temporary directory within the software root.\n");
    sprintf(ers(),"If possible, this will be fixed at a later time; current temp. dir.:\n");
    sprintf(ers(),"%s\n",tmpdir);
    sprintf(ers(),"\nIt is recommended to manually clean the temporary directory from time to time.\n");
    warnfunc2();
  }
} else if (!ighometmp)
{
  /* Temporary directory has been allocated, but not in the software root
  directory. We check again if it is possible to locate the temporary directory
  within the software root. */
  trytmpighome();
  if (ighometmp)
    newtmpdir=1;
}
if (newtmpdir || tmpname==NULL || tmplock==NULL)
{
  /* Path of the temporary directory has been changed, we must therefore
  re-allocate the buffer for the file name: */
  newtmpdir=0;
  disppointer((void **) &tmplock);
  tmplock=dirplusfile(tmpdir,tmplockfile);
  disppointer((void **) &tmpname); tmpnumptr=NULL;
  name=malloc(2+stringlength(tmpprefix)+tmpnumlength);
  if (tmpnum<0)
    tmpnum=0;
  else if (tmpnum>tmpmaxnum)
    tmpnum=tmpmaxnum;
  sprintf(name,"%s%0*i\0",tmpprefix,tmpnumlength,tmpnum);
  tmpname=dirplusfile(tmpdir,name);
  tmpnumptr=tmpname+stringlength(tmpname);
  tmpnumptr-=tmpnumlength;
  disppointer((void **) &name);
  if (newtmpdir)
  {
    /* Check if clean-up is necessary: */
    list=newstack(100);
    name=stringcat(tmpprefix,"*");
    dirlist(tmpdir,name,F_LISTFILES,list);
    disppointer((void **) &name);
    if (list->n>cleanuplim)
    {
      warnfunc1(1,"globuttmpdir");
      sprintf(ers(),"Number of temporary files (%i) exceeds the limit (%i), performing\n",
        cleanuplim,list->n);
      sprintf(ers(),"clean-up. This may take a while.\n");
      sprintf(ers(),"Temporary directory to be cleaned: \"%s\".\n",tmpdir);
      warnfunc2();
      for (i=1;i<=list->n;++i)
        if (stringlength(list->s[i])>0)
        {
          remove(list->s[i]);
        }
    }
    dispstackall(&list);
  }
}
m_threadunlock(tmpdirlock)
return tmpdir;
}




static void locktmpdir()
    /* Locks the temporary directory in order to insure that it will not be
    temporarily used by other processes for allocating temporary file names.
    If another process has set a lock then the function waits until lock is
    released. In this case the calling thread is suspended for some time in
    order to allow proper usage of the temporary resource (e.g. opening a
    temporary file) to the process that has locked the temp. directory.
    $A Igor may04; */
{
FILE *fp=NULL;
int done=0,numtrials=0,length,length1,lockwarn=0,numaccessfail=0,
    repaccessfail=0,noaccess;
double locktime,locktime1,curtime,initialtime=0.0;
tmpskiplock=0;
while (!done)
{
  ++numtrials;
  curtime=absolutetime();  /* note cur. time */
  if (initialtime==0.0)
  {
    initialtime=curtime;  /* mark time for time-out calculation */
  }
  fp=fopen(tmplock,"rb");  /* check the lock */
  if (fp==NULL)
  {
    /* Not locked (lock file does not exist), set a lock: */
    done=1;
    fp=fopen(tmplock,"ab");
    if (fp==NULL)
    {
      /* Possible lack of access permitions; a possible reason is that lock
      is hold by another user; we shall delay some time and try later. */
      if (tmpnumacfail>2)
      {
        /* There has been too much waiting for access lock to be released,
        skip temp. dir. locking: */
        done=1;
        tmpskiplock=1;
        warnfunc1(1,"locktmpdir");
        sprintf(ers(),"Temporary directory locking skipped because of denied access to\n");
        sprintf(ers(),"lock file %s.\n",tmplock);
        warnfunc2();
        return;
      }
      done=0;
      ++numaccessfail;  /* counter for this function execution */
      #ifdef ITK
        tcl_sleep(20+(int) (random1()*10.0));
      #else
        warnfunc1(1,"locktmpdir");
        sprintf(ers(),"Temporary directory lock access failed. Sleeping for a while...");
        sprintf(ers(),"Lock file: \"%s\".\n",tmplock);
        warnfunc2();
        sleep(1);
      #endif
      if (numaccessfail>=4 && curtime-initialtime>locklim)
      {
        if (!repaccessfail)  /* report error only once in this function */
        {
          errfunc0("locktmpdir");
          sprintf(ers(),"The temporary access lock failed.\n");
          sprintf(ers(),"A possible reason is lack of file permissions on the lock file that has\n");
          sprintf(ers(),"not been cleaned by the owner process. Please check the permissions!\n");
          sprintf(ers(),"Lock file: \"%s\"",tmplock);
          errfunc2();
        }
        ++repaccessfail;  /* number of reported failures */
        printf("\n\nLock file could not be accessed for writing. Please check for the\n");
        printf("existence and access permissions of the lock file and its containing\n");
        printf("directory, modify permissions if necessary!\n");
        printf("Respond to continue program execution after settling the access!\n");
        printf("Lock file: \"%s\".\n\n",tmplock);
        /*
        waituserresponse();
        */
        if (repaccessfail==2)
        {
          ++tmpnumacfail;
          /* Give user some time to enable lock file access: */
          noaccess=1;
          printf("\nWaiting some time, please enable the modify access to the file\n");
          printf("\"%s\" or its containing directory if the file does not exist!\n");
          while(absolutetime()-curtime<=300 && noaccess)
          {
            sleep(2);
            fp=fopen(tmplock,"ab");
            if (fp!=NULL)
            {
              noaccess=0;
              fclose(fp);  fp=NULL;
            }
          }
          printf("\nWaiting for file access timed out, continue execution.\n\n");
        }
      }
    } else
    {
      fprintf(fp," %.25lg ",curtime);   /* mark locking time */
      fclose(fp);  fp=NULL;
      /* Double check (check the time of the lock and whether there are more than
      one time marks in the file); switch this on when the compromise should be
      more on the side of security than the speed: */
      length=0;
      fp=fopen(tmplock,"rb");
      if (fp!=NULL)
      {
        length=fscanf(fp,"%lg",&locktime);  /* read time mark */
        length1=fscanf(fp,"%lg",&locktime1);  /* check for multiple time marks */
        fclose(fp);
      }
      if (length<1 || length1>0 || locktime!=curtime)
      {
        done=0;  /* Check not passed */
        if (length>0 && locktime==curtime)
        {
          /* All checks OK, except that there are more time marks; possible race
          condition, remove the lock and wait for some time: */
          remove(tmplock);
          warnfunc1(3,"locktmpdir");
          sprintf(ers(),"Locking of temporary directory failed.\n");
          sprintf(ers(),"Possible race condition, sleep for a while...");
          warnfunc2();
          #ifdef ITK
            tcl_sleep(20+(int) (random1()*50.0));
          #else
            sleep(1);
          #endif
        }
      }
    }
    if (lockwarn && done)
    {
      /* Another process had a lock of temp. directory; Give that process some
      time to use the temporary file if it allocated one: */
      #ifdef ITK
        tcl_sleep(50);
      #else
        sleep(1);
      #endif
    }
    if (done)
      loclocktime=curtime;   /* note the locking time for control */
  } else
  {
    /* File is not NULL, which means that the file exists. Try to read the
    locking time: */
    length=fscanf(fp,"%lg",&locktime);
    fclose(fp);    fp=NULL;
    if (length<1)
    {
      /* The file exists, but there is no locking time. Possible race condition
      (opened file just after another process created it, but before a time
      mark was written), wait some time and check again: */
      #ifdef ITK
        tcl_sleep(100);
      #else
        sleep(1);
      #endif
      length=1;
      fp=fopen(tmplock,"rb");
      if (fp!=NULL)
      {
        length=fscanf(fp,"%lg",&locktime);
        fclose(fp);    fp=NULL;
      }
      if (length<1)  /* file exists but with no time mark */
      {
        /* Wait some more and try again: */
        sleep(1);
        /* It seems this was not a race condition, but there is an error in
        the lock file, which will therefore be deleted: */
        length=1;
        fp=fopen(tmplock,"rb");
        if (fp!=NULL)
        {
          length=fscanf(fp,"%lg",&locktime);
          fclose(fp);    fp=NULL;
        }
        if (length<1)  /* file exists but with no time mark */
        {
          remove(tmplock);
          errfunc0("locktmpdir");
          sprintf(ers(),"Temporary dir. lock file without a time mark, it will be removed.\n");
          sprintf(ers(),"File: \"%s\"\n.",tmplock);
          errfunc2();
        }
      }
    } else if (curtime-locktime<0)
    {
      /* The lock time is later than the current time. Wait a bit, check again
      and remove the lock file if the situation is the same (waite because the
      system time could be re-set just between): */
      #ifdef ITK
        tcl_sleep(100);
      #else
        sleep(1);
      #endif
      length=0;
      fp=fopen(tmplock,"rb");
      if (fp!=NULL)
      {
        length=fscanf(fp,"%lg",&locktime);
        fclose(fp);    fp=NULL;
      }
      if (length>0 && curtime-locktime<0)  /* situation did not change */
      {
        remove(tmplock);
        errfunc0("locktmpdir");
        sprintf(ers(),"Lock creation time later than current time.\n");
        sprintf(ers(),"File: \"%s\"\n.",tmplock);
        errfunc2();
      }
    } else
    {
      /* The temporary lock is properly set: */
      if (curtime-locktime>locklim)
      {
        /* The lock has timed out, remove it: */
        remove(tmplock);
        warnfunc1(1,"locktmpdir");
        sprintf(ers(),"The temporary directory lock has timed out (%g s, limit %g s).\n",
          curtime-locktime,locklim);
        warnfunc2();
      } else
      {
        /* Normal locking situation, wait a bit & launch a warning: */
        ++lockwarn;
        if (lockwarn>1)
        {
          ++lockwarn;
          warnfunc1(3,"locktmpdir");
          sprintf(ers(),"Temp. directory is locked, waiting to be unlocked.\n");
          warnfunc2();
        }
        tcl_sleep(10);
        if (lockwarn>1)
        {
          #ifdef ITK
            tcl_sleep(10);
          #else
            if (lockwarn==2)
              sleep(1);
          #endif
        }
      }
    }
  }
}

}

static void unlocktmpdir()
    /* Unlocks the temporary directory. */
{
FILE *fp=NULL;
double locktime=0;
int length=0;
if (tmpskiplock)
  return;
/* Control (this could be omitted without much harm) */
fp=fopen(tmplock,"rb");
if (fp!=0)
{
  length=fscanf(fp,"%lg",&locktime);
  fclose(fp);
}
if (length<1 || locktime!=loclocktime)
{
  warnfunc1(3,"unlocktmpdir");
  sprintf(ers(),"The temporary directory has not been properly locked.\n");
  sprintf(ers(),"Asynchronous access is possible (two processes could use the same\n");
  sprintf(ers(),"temporary file).\n");
  errfunc2();
}
/* Remove the lock file: */
remove(tmplock);
}


static char *tmpnam0()
    /* An auxiliary function for globuttmpnam() and globuttmpfile(). Returns
    a unique name of a temporary file, which is also created. It does not lock
    thread access to the data, this must be done in the calling function. This
    function does, however, include locking by signalling files for preventing
    different processes of using the same file names.
    $A Igor may04; */
{
static int deltmp=0,numex=0;
int length;
char *tmpdir,*name=NULL;
FILE *fp=NULL;
stack list=NULL;
++ numex;
tmpdir=globuttmpdir();
if (tmpdir==NULL)
  return NULL;
locktmpdir();   /* temporarily lock access for other processes */
/* Find an unoccupied temporary name, delete temporary files if there are many
of them: */
++tmpnum;
sprintf(tmpnumptr,"%0*i\0",tmpprefix,tmpnumlength,tmpnum);
while (fileexists(tmpname) && tmpnum<=tmpmaxnum && tmpnum>0)
{
  ++tmpnum;
  length=sprintf(tmpnumptr,"%0*i\0",tmpprefix,tmpnumlength,tmpnum);
  if (length!=tmpnumlength)
  {
    newtmpdir=1;
    errfunc0("tmpnam0");
    sprintf(ers(),"Name overflow.\n");
    sprintf(ers(),"Number string longer (%i characters) than prescribed length (%i).\n",
      length,tmpnumlength);
    sprintf(ers(),"Number string:\"%s\".\n",tmpnumptr);
    errfunc2();
  }
}
if (!(tmpnum<=tmpmaxnum && tmpnum>0))
{
  unlocktmpdir();  /* unlock temporary dir. */
  return NULL;
}
if (stringlength(tmpname)>0)
{
  fp=fopen(tmpname,"wb+");
  if (fp!=NULL)
    fclose(fp);
  else
  {
    errfunc0("tmpnam0");
    sprintf(ers(),"Temporary file \"%s\" could not be open for r&w access.\n",
      tmpname);
    errfunc2();
  }
  /* Delete this in the future! */
  printf("\n%i. execution of tmpnam0: file \"%s\"\n\n",numex,tmpname);
}
unlocktmpdir();  /* unlock temporary dir. */
return tmpname;
}

char *globuttmpnam(char *buf)
    /* A substitute for the standard function tmpnam().
    $A Igor may04; */
{
static int warnbuf=0;
int locked=0,length=0;
tmpfiledata data=NULL;
char *name=NULL;
if (tmpfilelock>0)
  locked=1;
m_threadlocksleep(tmpfilelock,1)
if (tmpfilest==NULL)
  tmpfilest=newstack(10);
if (locked)
{
  tcl_sleep(100);  /* Give some time for usage of previous temp. name */
}
name=tmpnam0();
if ((length=stringlength(name))>0)
{
  data=calloc(1,sizeof(*data));
  data->name=stringcopy(name);
  data->fp=NULL;
  pushstack(tmpfilest,NULL);
  if (buf!=NULL)
  {
    if (length>warnbuf)
    {
      warnbuf=length;
      warnfunc1(3,"globuttmpnam");
      sprintf(ers(),"Temporary name has been written to the user provided buffer.\n");
      sprintf(ers(),"This situation can be potentially dangerous for buffer overflow.\n");
      sprintf(ers(),"Name length is %i bytes.\n",length);
      warnfunc2();
    }
    sprintf(buf,"%s",name);
  }
} else
  if (buf!=NULL)
    *buf='\0';
m_threadunlock(tmpfilelock)
if (data!=NULL)
{
  remove(data->name);
  return data->name;
} else
  return NULL;
}



FILE *globuttmpfile(void)
    /* Returns a file pointer to an empty open file (open as wb+) that can be
    used as a temporary file. This function is a substitute for the standard
    function tmpfile().
    $A Igor may04; */
{
int locked=0,length=0;
tmpfiledata data=NULL;
char *name=NULL;
if (tmpfilelock>0)
  locked=1;
m_threadlocksleep(tmpfilelock,1)
if (tmpfilest==NULL)
  tmpfilest=newstack(10);
if (locked)
{
  tcl_sleep(100);  /* Give some time for usage of previous temp. name */
}
name=tmpnam0();
if ((length=stringlength(name))>0)
{
  data=calloc(1,sizeof(*data));
  data->name=stringcopy(name);
  data->fp=fopen(data->name,"wb+");
  pushstack(tmpfilest,NULL);
}
m_threadunlock(tmpfilelock)
if (data!=NULL)
{
  return data->fp;
} else
  return NULL;
}


int globutfclose(FILE *fp)
    /* A substitute for fclose(); If fp was open by globuttmpfile(), it deletes
    the appropriate data on the stack.
    $A Igor may04; */
{
int place=0,i,ret=0;
tmpfiledata data;
m_threadlocksleep(tmpfilelock,1)
if (fp!=NULL && tmpfilest!=NULL)
  for (i=1;i<=tmpfilest->n && place==0;++i)
  {
    data=tmpfilest->s[i];
    if (data!=NULL)
      if (data->fp==fp)
        place=i;
  }
ret=fclose(fp);
if (place>0)
{
  if (data!=NULL)
  {
    disppointer((void **) &(data->name));
    data->fp=NULL;
    free(data);
  }
  delstack(tmpfilest,place);
}
m_threadunlock(tmpfilelock)
return ret;
}


int globutremove(const char *filename)
    /* A substitute for standard C function remove; Beside removing the file,
    it checks if this file is a temporary file and in this case removes its
    record in the system of temporary files of the module globut.
    $A Igor may04; */
{
int place=0,i,ret=0;
tmpfiledata data;
m_threadlocksleep(tmpfilelock,1)
if (filename!=NULL && tmpfilest!=NULL)
  for (i=1;i<=tmpfilest->n && place==0;++i)
  {
    data=tmpfilest->s[i];
    if (data!=NULL)
      if (!cmpstrings(data->name,filename))
        place=i;
  }
ret=remove(filename);
if (place>0)
{
  if (data!=NULL)
  {
    disppointer((void **) &(data->name));
    data->fp=NULL;
    free(data);
  }
  delstack(tmpfilest,place);
}
m_threadunlock(tmpfilelock)
return ret;
}


void globutexit(int code)
    /* A subsititute for the standard exit() function. Cleans global utility
    temporary files before exit.
    $A Igor may04; */
{
int i;
tmpfiledata data;
m_threadlocksleep(tmpfilelock,1)
if (tmpfilest!=NULL)
{
  for (i=1;i<=tmpfilest->n;++i)
  {
    data=tmpfilest->s[i];
    if (data!=NULL)
      if (data->name!=NULL)
        if (fileexists(data->name))
        {
          remove(data->name);
        }
  }
  /* Repeat check, close open files before removing the appropriate files: */
  for (i=1;i<=tmpfilest->n;++i)
  {
    data=tmpfilest->s[i];
    if (data!=NULL)
      if (data->name!=NULL)
        if (fileexists(data->name))
        {
          remove(data->name);
          if (fileexists(data->name) && data->fp!=NULL)
          {
            fclose(data->fp);  data->fp=NULL;
            remove(data->name);
          }
        }
  }
}
m_threadunlock(tmpfilelock)
exit(code);
}



char *globuttmpnam1(void)
    /* Returns a temporary file name which can be used as auxiliary file, e.g.
    for writing text before showing it in a viewer. All calls to this function
    return the same file name, therefore the function may not be called in
    recursive block, i.e. you must be sure that the next call is made after
    the temporary file from previous call is stopped being used. When you use
    the temporary file name returned by this function, you may not call any
    other functions that might also use a temporary file whose name is obtained
    via the same mechanism.
     You MAY NOT free memory occupied by the returned string. You also don't
    need to remove the file when you stop using it because the globutend()
    that is called at the end of the program will do that (you should however
    close any logical files connected to the temporary file).
     The file whise name is returned by this function can be non-existent or
    nonempty. It is therefore user responsibility to initialise its state
    according to vurrent needs.
    $A Igor jan02; */
{
if (gud==NULL)
  creategud();
if (gud->tmpnam==NULL)
{
  if (gud->sesdir!=NULL)
    gud->tmpnam=stringcat(gud->sesdir,"globut.tmp");
  else
    gud->tmpnam=stringcopy(tmpnam(NULL));
}
return gud->tmpnam;
}

void globutsystempar(char *command)
    /* Executes command on the system in such a way that control is immediately
    returned to the program (i.e. editor opens in a window su that user can
    independently edit text, but at the same time the program runs on and user
    can interact with it).
    $A Igor jan02; */
{
char *com=NULL,*tclcom=NULL,*tclret=NULL;
int tclcode=0;
#ifdef ITK
  if (command!=NULL)
    tclcom=tcl_multstrcom("exec",command,"&",NULL);
  else
    tclcom=tcl_multstrcom("exec","&",NULL);
  tclret=tcl_interpret(tclcom,&tclcode);
  if (tclcode!=TCL_OK && !cmpstrings(tclret,"1"))
  {
    warnfunc1(1,"globutsystempar");
    sprintf(ers(),"Command \"%s\" could not be executed.\n");
    warnfunc2();
  }
  disppointer((void **) &tclcom);
  disppointer((void **) &tclret);
#else
 #if defined(UNIX)
  com=stringcat(command," &");
  system(com);
  disppointer((void **) &com);
 #elif defined(DOSWN)
  /*Not yet implemented!!! */
  com=stringcopy(command);
  system(com);
  disppointer((void **) &com);
 #else
  com=stringcat(command," &");
  system(com);
  disppointer((void **) &com);
 #endif
#endif
}



    /* EDITING & VIEWING TEXT FILES, BROWSING HTML DOCUMENTS: */


void globutview(char *filepath,char par)
    /* Opens file filepath in the viewer. if par is 0, program execution is
    blocked until viewer is closed, otherwise it is not.
    $A Igor jan02; */
{
char *str=NULL,*command=NULL,*argpath=NULL;
if (gud==NULL)
{
  errfunc0("globutbrowse");
  sprintf(ers(),"Global utilities not initialised.\n");
  errfunc2();

} else if (gud->viewer==NULL)
{
  errfunc0("globutview");
  fprintf(erf(),"Unable to view file:\nExternal viewer not determined, internal not defined.\n");
  if (gud->ighome!=NULL)
  {
    #if defined(DOSWN)
      fprintf(erf(),"Try to define external viewer in shell file %s\\bin\\view.bat\n",
       gud->ighome);
      fprintf(erf(),"Try to view file through \"more\" command...\n");
    #else
      fprintf(erf(),"Try to define external viewer in shell com. file %s/bin/view\n",
       gud->ighome);
      fprintf(erf(),"Trying to view file through \"more\" command...\n");
    #endif
  }
  errfunc2();
  #if defined(DOSWN)
    gud->viewer=stringcopy("more < ");
    globutview(filepath,par);
  #else
    gud->viewer=stringcopy("more < ");
    globutview(filepath,par);
  #endif
} else
{
  str=stringcat(gud->viewer," ");
  argpath=getargpath(filepath);
  command=stringcat(str,argpath);
  if (par)
    globutsystempar(command);
  else
    system(command);
  disppointer((void **) &command);
  disppointer((void **) &str);
  disppointer((void **) &argpath);
}
}


void globutedit(char *filepath,char par)
    /* Opens file filepath in the editor. if par is 0, program execution is
    blocked until editor is closed, otherwise it is not.
    $A Igor jan02; */
{
char *str=NULL,*command=NULL,*argpath=NULL;
if (gud==NULL)
{
  errfunc0("globutbrowse");
  sprintf(ers(),"Global utilities not initialised.\n");
  errfunc2();

} else if (gud->editor==NULL)
{
  errfunc0("globutedit");
  fprintf(erf(),"Unable to edit file:\nExternal editor not determined, internal not defined.\n");
  if (gud->ighome!=NULL)
  {
    #if defined(DOSWN)
      fprintf(erf(),"Try to define external editor in shell file %s\\bin\\edit.bat\n",
       gud->ighome);
    #else
      fprintf(erf(),"Try to define external editor in shell com. file %s/bin/edit\n",
       gud->ighome);
    #endif
  }
  fprintf(erf(),"Trying to view file...\n");
  errfunc2();
  globutview(filepath,par);
} else
{
  str=stringcat(gud->editor," ");
  argpath=getargpath(filepath);
  command=stringcat(str,argpath);
  if (par)
    globutsystempar(command);
  else
    system(command);
  disppointer((void **) &command);
  disppointer((void **) &str);
  disppointer((void **) &argpath);
}
}


void globutbrowse(char *location,char par)
    /* Opens file filepath in the browser. if par is 0, program execution is
    blocked until browser is closed, otherwise it is not.
    $A Igor jan02; */
{
char *str=NULL,*command=NULL,*argpath=NULL;
if (gud==NULL)
{
  errfunc0("globutbrowse");
  sprintf(ers(),"Global utilities not initialised.\n");
  errfunc2();

} else if (gud->browser==NULL)
{
  errfunc0("globutbrowse");
  fprintf(erf(),"Unable to browse location:\nExternal browser not determined, internal not defined.\n");
  if (gud->ighome!=NULL)
  {
    #if defined(DOSWN)
      fprintf(erf(),"Try to define external browser in shell file %s\\bin\\browse.bat\n",
       gud->ighome);
      fprintf(erf(),"Try to view file...\n");
    #else
      fprintf(erf(),"Try to define external browser in shell com. file %s/bin/browse\n",
       gud->ighome);
      fprintf(erf(),"Trying to view file...\n");
    #endif
  }
  errfunc2();
  globutview(location,par);
} else
{
  str=stringcat(gud->browser," ");
  /* Check if the location is a file: */
  argpath=getargpath(location);
  if (fileexists(argpath))
    command=stringcat(str,argpath);
  else
    command=stringcat(str,location);
  if (par)
    globutsystempar(command);
  else
    system(command);
  disppointer((void **) &command);
  disppointer((void **) &str);
  disppointer((void **) &argpath);
}
}




    /* MENUS, MESSAGES, etc. */


int globutmenusimp(char *message,stack items)
    /* Launches a simple menu for choosing between various possibilities.
    message is the message that accompanies the menu, and items is a stack of
    strings (char * each) that identify the possible choices.
      The function blocks until user makes a choice and returns the sequential
    number of the chosen item on the stack items (counting starts from 1). there
    is a possibility of making no choice, in which case the function returns 0.
    $A Igor apr03; */
{
int i;
printf("\n=====  Menu  ===========\n%s\n",message);
printf("----------\nPossible choices:\n");
printf("%4i: <No choice>\n",0);
if (items!=NULL)
  for(i=1;i<=items->n;++i)
    printf("%4i: \"%s\"\n",i,items->s[i]);
i=-1;
printf("----------\nInsert the number of your choice: "); readint(&i);
while(i<0 || i>items->n)
{
  printf("\nThe number %i is not a valid choice.\n",i);
  printf("Please insert a number between 0 and %i: ",items->n);
  readint(&i);
}
printf("\n");
return i;
}


int globutdialogsimp(char *message,stack items)
    /* Launches a simple dialog for choosing between various possibilities.
    message is the message that accompanies the menu, and items is a stack of
    strings (char * each) that appear as buttons and identify the possible
    choices.
      The function blocks until user makes a choice and returns the sequential
    number of the chosen item on the stack items (counting starts from 1). There
    is a possibility of making no choice, in which case the function returns 0.
    $A Igor apr03; */
{
int i;
printf("\n=====  Dialog  ===========\n%s\n",message);
printf("----------\nPossible choices:\n");
printf("%4i: <No choice>\n",0);
if (items!=NULL)
  for(i=1;i<=items->n;++i)
    printf("%4i: \"%s\"\n",i,items->s[i]);
i=-1;
printf("----------\nInsert the number of your choice: "); readint(&i);
while(i<0 || i>items->n)
{
  printf("\nThe number %i is not a valid choice.\n",i);
  printf("Please insert a number between 0 and %i: ",items->n);
  readint(&i);
}
printf("\n");
return i;
}

void globutmessagesimp(char *message)
    /* Launches a simple message and waits until the user responds to it (as a
    notification that he or she really saw the message).
    $A Igor apr03; */
{
printf("\n=====  Message  ===========\n");
printf("%s\n",message);
printf("---------------------------\n");
printf("<Press return to continue!>\n");
getchar();
printf("\n");
}




char *globuthomefindfirst(char *first,...)
    /* Searches for the first file in program home directories which satisfies
    criteria specified by string arguments of the function. It returns this
    name, which must be deallocated (e.g. by free()), or a NULL pointer if
    search was not successful. It searches first in gud->verdir, then in
    gud->progdir and finally in gud->ighome (gud must be initialised when
    the function is called, otherwise program can crash).
      Arguments must be separated into two groups by a NULL argument and must
    end with a NULL argument.
      The first group of arguments are directories relative to home directories
    which to search in. More than one can be specified, in which case "" can
    be specified for a home directory and individual directories are checked
    in the order as they appear in function arguments. If no directories are
    specified (i.e. the first argument is NULL), only the home directories
    will be checked for a file.
      The second group of arguments (i.e. arguments between the first and the
    second NULL argument) specify file names which are searched. The first of
    these arguments specifies the first part of the file name (usually name
    without extension) and the next arguments specify different suffices which
    are combined with the first part. These are combined in the order in which
    they appear when existence of the searched file is checked. There can be
    only one argument in this group, in which case it defines a whole name of
    the single file name we search for in specific directories. If there are
    several arguments in this group, the first argument can be an empty string
    (""), in which case every subsequent argument specify the whole file name
    by its own.
      File name(s) can include file path separators. If any name includes a
    path DOS path separators, but program runs on UNIX, these separators are
    replaced by proper UNIX separators, and vice versa. If the generated file
    names include space characters (' '), these are replaced by underscores
    ('_').
      The search for files is performed only in the specified directories,
    not recursively in their nested subdirectories.
      EXAMPLES:
      globuthomefindfirst("doc","",NULL,"pm",".txt",".html",".htm",NULL)
    will return the first name of an existet file within  directory "doc"
    within any home directory or within any home directory (arg. ""), whose
    name is either "pm.txt","pm.html", or "pm.htm".
      globuthomefindfirst(NULL,"","pm.txt","pm.html",NULL)
    will return the first name of an existent file named "pm.txt" or "pm.html"
    within any home directory of the program (because there are no arguments
    which would specift nested directory names).
      globuthomefindfirst("1/doc","hlp",NULL,"ig/a"," 1.txt"," 2.txt",NULL)
    will return (on UNIX) the first name of the existent file "ig/a1.txt" or
    "ig/a2.txt" within the directory "1/doc" or "hlp" within any home
    directory of the program. On DOS, this call would return the first file
    named "ig\a1.txt" or "ig\a2.txt" within the directory "1\doc" or "hlp"
    within any home directory of the program.
      WARNING:
    When calling this function, make sure that global utility data (gud) is
    initialised, which is achieved by any function that sets or gets any global
    data. Also make sure that two arguments of the function are NULL.
    $A Igor jan02; */
{
int i,j,k;
stack stbases=NULL,stdirs=NULL,stextensions=NULL;
char *searchname=NULL,*name=NULL,*arg,end=0;
va_list ap;
stbases=newstack(5);
stdirs=newstack(5);
stextensions=newstack(5);
/* Prepare stack of basis directories to look in: */
if (gud->verdir!=NULL)
  pushstack(stbases,gud->verdir);
if (gud->progdir!=NULL)
  if (cmpstrings(gud->progdir,gud->verdir))
    pushstack(stbases,gud->progdir);
if (gud->ighome!=NULL)
  if (cmpstrings(gud->ighome,gud->verdir) && cmpstrings(gud->ighome,gud->progdir))
    pushstack(stbases,gud->ighome);
/* Extraction of included directories to look in: */
va_start(ap,first);
arg=first;
while(arg!=NULL)
{
  pushstack(stdirs,arg);
  arg=va_arg(ap,char *);
}
arg=va_arg(ap,char *);
if (arg!=NULL)
{
  /* Extraction of search name: */
  searchname=arg;
  arg=va_arg(ap,char *);
  /* Extraction of extensions: */
  while (arg!=NULL)
  {
    pushstack(stextensions,arg);
    arg=va_arg(ap,char *);
  }
}
if (stdirs->n==0)
  pushstack(stdirs,"");
if (stextensions->n==0)
{
  if (searchname==NULL)
  {
    errfunc0("globuthomefindfirst");
    fprintf(erf(),"Search name is not defined.\n");
    errfunc2();
    return NULL;
  } else
    pushstack(stextensions,NULL);
}
if (searchname==NULL)
  searchname="";
if (stbases->n<1)
{
  errfunc0("globuthomefindfirst");
  fprintf(erf(),"None of the base directories defined.\nCheck the environment variable %s.\n",
   ighomeenv);
  errfunc2();
  return NULL;
}
for (i=1;i<=stbases->n;++i)
  for (j=1;j<=stdirs->n;++j)
    for (k=1;k<=stextensions->n;++k)
    {
      name=multdirplusmultfile((char *) stbases->s[i],(char *) stdirs->s[j],
       NULL,searchname,(char *) stextensions->s[k],NULL);
      /* Take care that separators within arguments are right with respect
      to platform, replacing spaces (' ') by underscores ('_'): */
      convertfilesyst(name);
      replacepathseparators(name,' ','_');
      /*
      printf("globuthomefindfirst: checking \"%s\"\n",name);
      */
      if (fileexists(name))
      {
        dispstack(&stbases);
        dispstack(&stdirs);
        dispstack(&stextensions);
        return name;
      } else
        disppointer((void **) &name);
    }
dispstack(&stbases);
dispstack(&stdirs);
dispstack(&stextensions);
return NULL;
}


void globuthelpfirst(char *helptopic)
    /* Searches for the first help file named helptopic with extension ".txt"
    or ".html" and opens it in a browser if it has extension ".html" or in
    viewer otherwise. It searches in home directories (version directory,
    program directory and software directory, in this order) and their
    subdirectory "doc". If it doesn't find a matching file, it reports an
    error.
    $A Igor jan02; */
{
char *filename=NULL;
if (helptopic==NULL)
  helptopic="index";
filename=globuthomefindfirst("doc","",NULL,helptopic,".html",".txt",NULL);
if (filename!=NULL)
{
  if (memfind(filename,strlen(filename),".html",5)!=NULL)
    globutbrowse(filename,1);
  else
    globutview(filename,1);
} else
{
  errfunc0("globuthelpfirst");
  fprintf(erf(),"Help topic %s not found.\n",helptopic);
  errfunc2();
  return;
}
disppointer((void **) &filename);
}









