#include <sysint.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>




void ftitleigs(FILE *fp,int spaces)
{
char *sp=malloc(spaces+1);
int i;
if (spaces>0)
  for (i=1; i<=spaces; ++i)
    sp[i-1]=' ';
sp[spaces]='\0';
fprintf(fp,"%s--------------------------------------------------\n",sp);
fprintf(fp,"%s|                                                |\n",sp);
fprintf(fp,"%s|   You are working with IGS 3.6 (2003),         |\n",sp);
fprintf(fp,"%s|   developed by Igor Gresovnik,                 |\n",sp);
fprintf(fp,"%s|                http://www.c3m.si/igor          |\n",sp);
fprintf(fp,"%s|                                                |\n",sp);
fprintf(fp,"%s--------------------------------------------------\n",sp);
}

void titleigs(int spaces)
{
ftitleigs(stdout,spaces);
}




void ftitleinverse20(FILE *fp,int spaces)
{
char *sp=malloc(spaces+1);
int i;
if (spaces>0)
  for (i=1; i<=spaces; ++i)
    sp[i-1]=' ';
sp[spaces]='\0';
fprintf(fp,"%s-------------------------------------------\n",sp);
fprintf(fp,"%s||---------------------------------------||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s||          INVERSE version 2.0          ||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s||      Developed by:                    ||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s||        Igor Gresovnik                 ||\n",sp);
fprintf(fp,"%s||        Crnece 147                     ||\n",sp);
fprintf(fp,"%s||        62370 Dravograd                ||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s||---------------------------------------||\n",sp);
fprintf(fp,"%s-------------------------------------------\n",sp);
if (sp!=NULL)
  free(sp);
}

void titleinverse20(int spaces)
{
  ftitleinverse20(stdout,spaces);
}




void ftitleinverse(FILE *fp,int spaces)
{
char *sp=malloc(spaces+1);
int i;
if (spaces>0)
  for (i=1; i<=spaces; ++i)
    sp[i-1]=' ';
sp[spaces]='\0';
fprintf(fp,"%s-------------------------------------------\n",sp);
fprintf(fp,"%s||---------------------------------------||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s||  INVERSE version 3.4    (Feb. 1999)   ||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s||      Created by:                      ||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s||        Igor Gresovnik  (igor@c3m.si)  ||\n",sp);
fprintf(fp,"%s||        Crnece 147                     ||\n",sp);
fprintf(fp,"%s||        2370 Dravograd, Slovenia       ||\n",sp);
fprintf(fp,"%s||                                       ||\n",sp);
fprintf(fp,"%s|| http://www.c3m.si/inverse             ||\n",sp);
fprintf(fp,"%s||---------------------------------------||\n",sp);
fprintf(fp,"%s-------------------------------------------\n",sp);
if (sp!=NULL)
  free(sp);
}

void titleinverse(int spaces)
{
  ftitleinverse(stdout,spaces);
}

void fprogtitle0(FILE *fp1,FILE *fp2,char *progname,double progversion,
     char *spec,int month,int year,char *creator,char *creatormail,char *line1,
     char *line2,char *line3,char *line4,int shift,char *info1,
     char *info2,char *info3,int shiftinfo,int spaces,int edge)
    /* V datotekoi fp1 in fp2 zapise naslovnico programa. progname je ime
    programa, progversion je verzija programa, spec je specifikacija (npr. Beta
    ali DEMO), month in year sta mesec in leto izdelave (ce je leto manj od 1
    se datum ne izpise, ce pa je mesec manj od 1 ali vec od 12, se ne izpise
    mesec), creator je ime ustvarjalca programa, creatormail je njegov e-mail
    naslov (ce je creator NULL, se ne izpise enako velja za creatormail),
    line1, line2, line3 in line4 so vrstice, ki se izpisejo pod ustvarjalcem
    programa, shift je zamik teh vrstic, info1, info2 in info3 so naslovi, kjer
    se dobijo informacije (obicajno html in e-mail), shiftinfo je st. znakov,
    za katero so ti nizi zamaknjeni od okvirja (vmes ni roba edge kot pri
    ostalih znakih), spaces je stevilo praznih znakov na zacetku vsake vrstice,
    edge pa najmanjse stevilo praznih znakov med robom in nizi (kar ne velja za
    levi rob pri info1, info2 in info3).
     Opomba: letnica year je lahko dvostevilcna.
    $A Igor mar99; */
{
int i,length,maxlength=2, /* stevilo prostorov na robu */
    lengthname,lengthcreator;
char framehor='*',framevert='*',*strcreator="Created by:";
char buf[200];
if (year<100 && year>-1)
{
  if (year<90)
    year+=2000;
  else
    year +=1900;
}
/* najprej se doloci dolzino najdaljse vrstice: */
/* Vrstica, v kateri so ime, verzija in datum izdelave programa: */
length=0;
if (progname!=NULL)
  length+=strlen(progname);
if (progversion>=0)
{
  sprintf(buf,"%g",progversion);
  length+=strlen(buf)+1;
}
if (spec!=NULL)
{
  length+=strlen(spec)+1;
}
if (year>-1)
{
  length+=3; /* 2 oklepaja + presledek */
  if (month>=1 && month<=12)
    length+=5; /* 3 crke za kratico, 1 za piko in 1 za presledek */
  sprintf(buf,"%i",year);
  length+=strlen(buf);
}
lengthname=length;
if (length>maxlength)
  maxlength=length;
if (creator!=NULL || creatormail!=NULL)
{
  length=strlen(strcreator)+shift+2;
  if (length>maxlength)
    maxlength=length;
  length=shift;
  if (creator!=NULL)
    length+=strlen(creator);
  if (creatormail!=NULL)
  {
    length+=strlen(creatormail);
    if (creator!=NULL)
      length+=3; /* presledek + 2 oklepaja */
  }
  lengthcreator=length;
  if (length>maxlength)
    maxlength=length;
}
length=0;
if (line1!=NULL)
{
  length=strlen(line1)+shift;
  if (length>maxlength)
    maxlength=length;
}
if (line2!=NULL)
{
  length=strlen(line2)+shift;
  if (length>maxlength)
    maxlength=length;
}
if (line3!=NULL)
{
  length=strlen(line3)+shift;
  if (length>maxlength)
    maxlength=length;
}
if (line4!=NULL)
{
  length=strlen(line4)+shift;
  if (length>maxlength)
    maxlength=length;
}
if (info1!=NULL)
{
  length=strlen(info1)+shiftinfo-edge;
  if (length>maxlength)
    maxlength=length;
}
if (info2!=NULL)
{
  length=strlen(info2)+shiftinfo-edge;
  if (length>maxlength)
    maxlength=length;
}
if (info3!=NULL)
{
  length=strlen(info3)+shiftinfo-edge;
  if (length>maxlength)
    maxlength=length;
}
/* Izpis naslovnice programa v obe datoteki: */
if (fp1!=NULL)
{
  /* 1. vrstica okvira: */
  for (i=1;i<=spaces;++i)
    fprintf(fp1," ");
  fprintf(fp1,"%c%c",framehor,framehor);
  for (i=1;i<=maxlength+2*edge;++i)
    fprintf(fp1,"%c",framehor);
  fprintf(fp1,"%c%c\n",framehor,framehor);
  /* 2. vrstica okvira: */
  for (i=1;i<=spaces;++i)
    fprintf(fp1," ");
  fprintf(fp1,"%c%c",framevert,framehor);
  for (i=1;i<=maxlength+2*edge;++i)
    fprintf(fp1,"%c",framehor);
  fprintf(fp1,"%c%c\n",framehor,framevert);
  /* Ena prazna vrstica: */
  for (i=1;i<=spaces;++i)
    fprintf(fp1," ");
  fprintf(fp1,"%c%c",framevert,framevert);
  for (i=1;i<=maxlength+2*edge;++i)
    fprintf(fp1," ");
  fprintf(fp1,"%c%c\n",framevert,framevert);
}
if (fp2!=NULL)
{
  /* 1. vrstica okvira: */
  for (i=1;i<=spaces;++i)
    fprintf(fp2," ");
  fprintf(fp2,"%c%c",framehor,framehor);
  for (i=1;i<=maxlength+2*edge;++i)
    fprintf(fp2,"%c",framehor);
  fprintf(fp2,"%c%c\n",framehor,framehor);
  /* 2. vrstica okvira: */
  for (i=1;i<=spaces;++i)
    fprintf(fp2," ");
  fprintf(fp2,"%c%c",framevert,framehor);
  for (i=1;i<=maxlength+2*edge;++i)
    fprintf(fp2,"%c",framehor);
  fprintf(fp2,"%c%c\n",framehor,framevert);
  /* Ena prazna vrstica: */
  for (i=1;i<=spaces;++i)
    fprintf(fp2," ");
  fprintf(fp2,"%c%c",framevert,framevert);
  for (i=1;i<=maxlength+2*edge;++i)
    fprintf(fp2," ");
  fprintf(fp2,"%c%c\n",framevert,framevert);
}
if (fp1!=NULL)
{
  /* Vrstica, v kateri so ime, verzija in datum izdelave: */
  for (i=1;i<=spaces;++i)
    fprintf(fp1," ");
  fprintf(fp1,"%c%c",framevert,framevert);
  for (i=1;i<=edge;++i)
    fprintf(fp1," ");
  if (progname!=NULL)
    fprintf(fp1,"%s",progname);;
  if (progversion>=0)
  {
    fprintf(fp1," %g",progversion);
  }
  if (spec!=NULL)
    fprintf(fp1," %s",spec);
  if (year>-1)
  {
    fprintf(fp1," (");
    if (month>=1 && month<=12)
    {
      /* fprintf(fp1,"%3i",month); */
      switch(month)
      {
        case 1:
          fprintf(fp1,"Jan");
          break;
        case 2:
          fprintf(fp1,"Feb");
          break;
        case 3:
          fprintf(fp1,"Mar");
          break;
        case 4:
          fprintf(fp1,"Apr");
          break;
        case 5:
          fprintf(fp1,"May");
          break;
        case 6:
          fprintf(fp1,"Jun");
          break;
        case 7:
          fprintf(fp1,"Jul");
          break;
        case 8:
          fprintf(fp1,"Aug");
          break;
        case 9:
          fprintf(fp1,"Sep");
          break;
        case 10:
          fprintf(fp1,"Oct");
          break;
        case 11:
          fprintf(fp1,"Nov");
          break;
        case 12:
          fprintf(fp1,"Dec");
          break;
      }
      fprintf(fp1,". ");
    }
    fprintf(fp1,"%i)",year);
  }
  for (i=1;i<=edge+maxlength-lengthname;++i)
    fprintf(fp1," ");
  fprintf(fp1,"%c%c\n",framevert,framevert);
  lengthname=length;
  if (creator!=NULL || creatormail!=NULL)
  {
    /* Dodatna prazna vrstica: */
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=maxlength+2*edge;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
    /* Niz, ki napoveduje ime kreatorja: */
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=shift+2+edge;++i)
      fprintf(fp1," ");
    fprintf(fp1,strcreator);
    for (i=1;i<=maxlength+edge- (int) strlen(strcreator)-shift-2;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
    /* Ime kreatorja in njegov mail: */
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=shift+edge;++i)
      fprintf(fp1," ");
    if (creator!=NULL)
      fprintf(fp1,"%s",creator);
    if (creatormail!=NULL)
    {
      if (creator==NULL)
        fprintf(fp1,"%s",creatormail);
      else
        fprintf(fp1," (%s)",creatormail);
    }
    for (i=1;i<=maxlength+edge-lengthcreator;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
  }
  if (line1!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=shift+edge;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%s",line1);
    for (i=1;i<=maxlength+edge- (int) strlen(line1)-shift;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
  }
  if (line2!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=shift+edge;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%s",line2);
    for (i=1;i<=maxlength+edge- (int) strlen(line2)-shift;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
  }
  if (line3!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=shift+edge;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%s",line3);
    for (i=1;i<=maxlength+edge- (int) strlen(line3)-shift;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
  }
  if (line4!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=shift+edge;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%s",line4);
    for (i=1;i<=maxlength+edge- (int) strlen(line4)-shift;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
  }
  if (creator!=NULL || creatormail!=NULL || line1==NULL || line2==NULL
   || line3==NULL || line4==NULL)
  {
    /* Ce se je za imenom programa izpisalo se kaj, sledi se ena prazna vrstica: */
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=maxlength+2*edge;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
  }
  if (info1!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=shiftinfo;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%s",info1);
    for (i=1;i<=maxlength+2*edge- (int) strlen(info1)-shiftinfo;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
  }
  if (info2!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=shiftinfo;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%s",info2);
    for (i=1;i<=maxlength+2*edge- (int) strlen(info2)-shiftinfo;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
  }
  if (info3!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c",framevert,framevert);
    for (i=1;i<=shiftinfo;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%s",info3);
    for (i=1;i<=maxlength+2*edge- (int) strlen(info3)-shiftinfo;++i)
      fprintf(fp1," ");
    fprintf(fp1,"%c%c\n",framevert,framevert);
  }
}
if (fp2!=NULL)
{
  /* Vrstica, v kateri so ime, verzija in datum izdelave: */
  for (i=1;i<=spaces;++i)
    fprintf(fp2," ");
  fprintf(fp2,"%c%c",framevert,framevert);
  for (i=1;i<=edge;++i)
    fprintf(fp2," ");
  if (progname!=NULL)
    fprintf(fp2,"%s",progname);;
  if (progversion>=0)
  {
    fprintf(fp2," %g",progversion);
  }
  if (spec!=NULL)
    fprintf(fp2," %s",spec);
  if (year>-1)
  {
    fprintf(fp2," (");
    if (month>=1 && month<=12)
    {
      /* fprintf(fp2,"%3i",month); */
      switch(month)
      {
        case 1:
          fprintf(fp2,"Jan");
          break;
        case 2:
          fprintf(fp2,"Feb");
          break;
        case 3:
          fprintf(fp2,"Mar");
          break;
        case 4:
          fprintf(fp2,"Apr");
          break;
        case 5:
          fprintf(fp2,"May");
          break;
        case 6:
          fprintf(fp2,"Jun");
          break;
        case 7:
          fprintf(fp2,"Jul");
          break;
        case 8:
          fprintf(fp2,"Aug");
          break;
        case 9:
          fprintf(fp2,"Sep");
          break;
        case 10:
          fprintf(fp2,"Oct");
          break;
        case 11:
          fprintf(fp2,"Nov");
          break;
        case 12:
          fprintf(fp2,"Dec");
          break;
      }
      fprintf(fp2,". ");
    }
    fprintf(fp2,"%i)",year);
  }
  for (i=1;i<=edge+maxlength-lengthname;++i)
    fprintf(fp2," ");
  fprintf(fp2,"%c%c\n",framevert,framevert);
  lengthname=length;
  if (creator!=NULL || creatormail!=NULL)
  {
    /* Dodatna prazna vrstica: */
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=maxlength+2*edge;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
    /* Niz, ki napoveduje ime kreatorja: */
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=shift+2+edge;++i)
      fprintf(fp2," ");
    fprintf(fp2,strcreator);
    for (i=1;i<=maxlength+edge- (int) strlen(strcreator)-shift-2;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
    /* Ime kreatorja in njegov mail: */
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=shift+edge;++i)
      fprintf(fp2," ");
    if (creator!=NULL)
      fprintf(fp2,"%s",creator);
    if (creatormail!=NULL)
    {
      if (creator==NULL)
        fprintf(fp2,"%s",creatormail);
      else
        fprintf(fp2," (%s)",creatormail);
    }
    for (i=1;i<=maxlength+edge-lengthcreator;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
  }
  if (line1!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=shift+edge;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%s",line1);
    for (i=1;i<=maxlength+edge- (int) strlen(line1)-shift;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
  }
  if (line2!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=shift+edge;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%s",line2);
    for (i=1;i<=maxlength+edge- (int) strlen(line2)-shift;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
  }
  if (line3!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=shift+edge;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%s",line3);
    for (i=1;i<=maxlength+edge- (int) strlen(line3)-shift;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
  }
  if (line4!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=shift+edge;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%s",line4);
    for (i=1;i<=maxlength+edge- (int) strlen(line4)-shift;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
  }
  if (creator!=NULL || creatormail!=NULL || line1==NULL || line2==NULL
   || line3==NULL || line4==NULL)
  {
    /* Ce se je za imenom programa izpisalo se kaj, sledi se ena prazna vrstica: */
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=maxlength+2*edge;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
  }
  if (info1!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=shiftinfo;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%s",info1);
    for (i=1;i<=maxlength+2*edge- (int) strlen(info1)-shiftinfo;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
  }
  if (info2!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=shiftinfo;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%s",info2);
    for (i=1;i<=maxlength+2*edge- (int) strlen(info2)-shiftinfo;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
  }
  if (info3!=NULL)
  {
    for (i=1;i<=spaces;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c",framevert,framevert);
    for (i=1;i<=shiftinfo;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%s",info3);
    for (i=1;i<=maxlength+2*edge- (int) strlen(info3)-shiftinfo;++i)
      fprintf(fp2," ");
    fprintf(fp2,"%c%c\n",framevert,framevert);
  }
}
if (fp1!=NULL)
{
  /* Predzadnja vrstica okvira: */
  for (i=1;i<=spaces;++i)
    fprintf(fp1," ");
  fprintf(fp1,"%c%c",framevert,framehor);
  for (i=1;i<=maxlength+2*edge;++i)
    fprintf(fp1,"%c",framehor);
  fprintf(fp1,"%c%c\n",framehor,framevert);
  /* Zadnja vrstica okvira: */
  for (i=1;i<=spaces;++i)
    fprintf(fp1," ");
  fprintf(fp1,"%c%c",framehor,framehor);
  for (i=1;i<=maxlength+2*edge;++i)
    fprintf(fp1,"%c",framehor);
  fprintf(fp1,"%c%c\n",framehor,framehor);
}
if (fp2!=NULL)
{
  /* Predzadnja vrstica okvira: */
  for (i=1;i<=spaces;++i)
    fprintf(fp2," ");
  fprintf(fp2,"%c%c",framevert,framehor);
  for (i=1;i<=maxlength+2*edge;++i)
    fprintf(fp2,"%c",framehor);
  fprintf(fp2,"%c%c\n",framehor,framevert);
  /* Zadnja vrstica okvira: */
  for (i=1;i<=spaces;++i)
    fprintf(fp2," ");
  fprintf(fp2,"%c%c",framehor,framehor);
  for (i=1;i<=maxlength+2*edge;++i)
    fprintf(fp2,"%c",framehor);
  fprintf(fp2,"%c%c\n",framehor,framehor);
}
}

void finvtitle0(FILE *fp1,FILE *fp2,
     char *name,double version,char *verspec,int month,int year,
     char *creator,char *creatormail,
     char *line1,char *line2,char *line3,char *line4,
     char *info1,char *info2,char *info3)
    /* V datoteki fp1 in fp2 izpise naslovnici za program Inverse.
    name je ime programa, version je verzija, verspec dopolnilna specifikacija
    verzije (npr. "Beta" ali "Demo", month in year sta mesec in leto izdelave,
    creator in creatormail sta ime in e-mail ustvarjalca programa, line1 ...
    line4 so vrstice, ki se izpisejo pod imenom ustvarjalca (in imajo enak
    zamik), info1 ... info3 pa so vrstice, ki se izpisejo na koncu (in so
    zamaknjene malo v levo, med njimi in spodnjim robom okvira ni praznega
    prostora).
     Opomba: letnica year je lahko dvostevilcna.
    $A Igor mar99; */
{
fprogtitle0(fp1,fp2,name,version,verspec,month,year,creator,creatormail,
            line1,line2,line3,line4,4,
            info1,info2,info3,1,20,3);
}

void _ftitleinverse20(FILE *fp,int spaces)
{
char *sp=malloc(spaces+1);
int i;
if (spaces>0)
  for (i=1; i<=spaces; ++i)
    sp[i-1]=' ';
sp[spaces]='\0';
if (sp!=NULL)
  free(sp);
}


void _titleinverse20(FILE *fp,int spaces)
{
  _ftitleinverse20(stdout,spaces);
}

void ftitlec3m(FILE *fp,int spaces)
{
int i;
char *sp=malloc(spaces+1);
if (spaces>0)
  for (i=1; i<=spaces; ++i)
    sp[i-1]=' ';
sp[spaces]='\0';
fprintf(fp,"%s-----------------------------------------------------\n",sp);
fprintf(fp,"%s||-------------------------------------------------||\n",sp);
fprintf(fp,"%s||  http://www.c3m.si                              ||\n",sp);
fprintf(fp,"%s||                                                 ||\n",sp);
fprintf(fp,"%s||    *****           *****         ***    ***     ||\n",sp);
fprintf(fp,"%s||   *******         *******        ****  ****     ||\n",sp);
fprintf(fp,"%s||  **     **       **     **       ** **** **     ||\n",sp);
fprintf(fp,"%s||  **                    ***       **  **  **     ||\n",sp);
fprintf(fp,"%s||  **                   ***        **      **     ||\n",sp);
fprintf(fp,"%s||  **                    ***       **      **     ||\n",sp);
fprintf(fp,"%s||  **     **       **     **       **      **     ||\n",sp);
fprintf(fp,"%s||   *******         *******        **      **     ||\n",sp);
fprintf(fp,"%s||    *****           *****         **      **     ||\n",sp);
fprintf(fp,"%s||                                                 ||\n",sp);
fprintf(fp,"%s|| CENTRE FOR COMPUTATIONAL CONTINUUM MECHANICS    ||\n",sp);
fprintf(fp,"%s|| Address:                                        ||\n",sp);
fprintf(fp,"%s||   Vandotova 55,  1000 Ljubljana, Slovenia       ||\n",sp);
fprintf(fp,"%s|| Tel/Fax:                                        ||\n",sp);
fprintf(fp,"%s||   +386-61-1271747                               ||\n",sp);
fprintf(fp,"%s|| Director:                                       ||\n",sp);
fprintf(fp,"%s||   Dr. Tomaz RODIC, dipl. ing.                   ||\n",sp);
fprintf(fp,"%s||-------------------------------------------------||\n",sp);
fprintf(fp,"%s-----------------------------------------------------\n",sp);
if (sp!=NULL)
  free(sp);
}

void titlec3m(int spaces)
{
ftitlec3m(stdout,spaces);
}




