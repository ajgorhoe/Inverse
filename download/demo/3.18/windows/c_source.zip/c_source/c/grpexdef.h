/*
******************************************************************************
    	Utility procedures for some HP-PEX example programs.

	$Source: /source2/PEX5/hp_examples/hp_example_utils.c,v $
	$Date: 94/08/18 17:29:07 $
	$Revision: 520.1.100.1 $

******************************************************************************
*/

/******************************************************************************/
/*                                                                            */
/*  (c) Copyright Hewlett-Packard Company, 1994,  Fort Collins, Colorado      */
/*                                                                            */
/*                            All Rights Reserved                             */
/*                                                                            */
/*  Permission to use, copy, modify, and distribute this software and its     */
/*  documentation for any purpose and without fee is hereby granted,          */
/*  provided that the above copyright notices appear in all copies and that   */
/*  both the copyright notices and this permission notice appear in           */
/*  supporting documentation, and that the name of Hewlett-Packard not be     */
/*  used in advertising or publicity pertaining to distribution of the        */
/*  software without specific, written prior permission.                      */
/*                                                                            */
/*  HEWLETT-PACKARD MAKES NO WARRANTY OF ANY KIND WITH REGARD TO THIS         */
/*  SOFTWARE, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/*  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Hewlett-Packard    */
/*  shall not be liable for errors contained herein or direct, indirect,      */
/*  special, incidental or consequential damages in connection with the       */
/*  furnishing, performance or use of this software.                          */
/*                                                                            */
/******************************************************************************/


/******************************************************************************/

#include <sysint.h>

#include <stdlib.h>
#include <string.h>

#include <X11/PEX5/PEXlib.h>            	/* PEX library definitions */
#include <X11/PEX5/PEXHPlib.h>          	/* PEX library definitions */
#include "PEXUtCmap.h"				/* colormap utilities header */

/****************************************************************************/
#define  GetEnv(x,s,d)  if ((chPtr = getenv(s)) != NULL)                \
                            sscanf(chPtr, "%d", &x);                    \
                        else                                            \
                            x = d

void MakePEXWindow(display, double_buf, window_return, capx_return)
    Display 			*display;
    int 			double_buf;
    Window  			*window_return;
    PEXColorApproxEntry 	*capx_return;
{
    int                 	screen;
    Window              	window;

    XVisualInfo                 VisualInfo;
    XStandardColormap           ColormapInfo;
    PEXColorApproxEntry         ColorAprxInfo;
    XSizeHints                  SizeHints;
    PEXUtVisualCriteria         VisCriteria;
    PEXUtWindowSpecification    WindowInfo;
    unsigned int                Unmet;
    Atom                        PropertyAtom;
    int                         Result;
    XColor                      Background;
    int				selected_criteria;
    Colormap			Colormap_ID;

    int                 	PosX, PosY;
    int                 	Width, Height;
    char                	*chPtr;

    
    screen = DefaultScreen(display);

    /*--- get window size/position from environment variables --------------*/
    GetEnv(PosX,   "PEXwinX",  iwindowxpos);      /* assign PEX window's X position */
    GetEnv(PosY,   "PEXwinY",  iwindowypos);      /* assign PEX window's Y position */
    GetEnv(Width,  "PEXwinWd", iwindowwidth);    /* assign PEX window's width */
    GetEnv(Height, "PEXwinHt", iwindowheight);    /* assign PEX window's height */

    /*--- put pertinent info into structures -------------------------------*/
    SizeHints.x = PosX;
    SizeHints.y = PosY;
    SizeHints.width = Width;
    SizeHints.height = Height;
    SizeHints.flags = (USSize|USPosition);
    VisCriteria.hard_criteria_mask = 0;
    VisCriteria.soft_criteria_mask = PEXUtStandardColormapProperty;
    VisCriteria.standard_colormap_property = True;
    if (double_buf) {
        VisCriteria.soft_criteria_mask |= PEXUtDBCapability;
	VisCriteria.double_buffering_capability = PEXUtDBPEX;
    }
    WindowInfo.attr_mask = 0;
    WindowInfo.title = windowtitle;
    WindowInfo.size_hints = SizeHints;
    WindowInfo.parent = RootWindow (display, screen);
    WindowInfo.border_width = 0;
    WindowInfo.background_color_name = "black";
    WindowInfo.border_color_name = "white";

    /*--- do it ------------------------------------------------------------*/
    Result = PEXUtMakeWindowAndColormap(display, screen, 
                                        1, &VisCriteria,
                                        &WindowInfo, &window,
                                        &VisualInfo, 
                                        &ColormapInfo, 
                                        &ColorAprxInfo,
					&selected_criteria,
                                        &Unmet, &PropertyAtom,
                                        &Background, 
					&Colormap_ID);

    if ((Result != PEXUtSuccess) && (Result != PEXUtQualifiedSuccess)) {
        fprintf (stderr, "ERROR:  Failed to create window\n");
        exit (1);
    }
    if ((Result == PEXUtQualifiedSuccess) 
	&& (Unmet & PEXUtDBCapability)) {
        fprintf (stderr, 
		"WARNING:  Couldn't get Visual for PEX double-buffering\n");
    }

    *window_return = window;
    *capx_return = ColorAprxInfo;

} /* MakePEXWindow */

/****************************************************************************/
int CheckAlphaSupport (display, window)
    Display 	*display; 
    Window 	window;
{
    int status, j, found;
    int enum_types[1];
    unsigned long *enum_counts;
    PEXEnumTypeDesc *enum_values, *p_enum;
	
    /*
	Determine whether the Renderer can support alpha blending.
    */

    enum_types[0] = PEXHPETTransparencyMethod;

    status = PEXGetEnumTypeInfo (display, window,
			1, enum_types, 
			PEXETCounts|PEXETIndex,
			&enum_counts, &enum_values);
    if (!status) {
	fprintf(stderr, "inquiry of enumerated types failed - exiting\n");
	exit(1);
    }

    p_enum = enum_values;
    found = False;

    for (j=0; j<enum_counts[0]; j++) {
	if (((unsigned short) (p_enum++)->index) == 
	    ((unsigned short) PEXHPTransparencyMethodAlphaBlend)) {
	    found = True;
	}
    }

    PEXFreeEnumInfo (1, enum_counts, enum_values);

    return found;

} /* CheckAlphaSupport */

/****************************************************************************/
void CreatePEXResources(display, window, capx, 
			renderer_return, rnd_attrs_return)
    Display			*display;
    Window			window;
    PEXColorApproxEntry		*capx;
    PEXRenderer			*renderer_return;
    PEXRendererAttributes	*rnd_attrs_return;
{
    unsigned int                RndrrMask = 0;

    /*--- create bundle tables ---------------------------------------------*/
    RndrrMask |= PEXRAMarkerBundle;
    rnd_attrs_return->marker_bundle =
      PEXCreateLookupTable(display, window, PEXLUTMarkerBundle);
    RndrrMask |= PEXRATextBundle;
    rnd_attrs_return->text_bundle =
      PEXCreateLookupTable(display, window, PEXLUTTextBundle);
    RndrrMask |= PEXRALineBundle;
    rnd_attrs_return->line_bundle =
      PEXCreateLookupTable(display, window, PEXLUTLineBundle);
    RndrrMask |= PEXRAInteriorBundle;
    rnd_attrs_return->interior_bundle =
      PEXCreateLookupTable(display, window, PEXLUTInteriorBundle);
    RndrrMask |= PEXRAEdgeBundle;
    rnd_attrs_return->edge_bundle =
      PEXCreateLookupTable(display, window, PEXLUTEdgeBundle);

    /*--- create viewing table ---------------------------------------------*/
    RndrrMask |= PEXRAViewTable;
    rnd_attrs_return->view_table = 
	PEXCreateLookupTable(display, window, PEXLUTView);

    /*--- create color table -----------------------------------------------*/
    RndrrMask |= PEXRAColorTable;
    rnd_attrs_return->color_table =
      PEXCreateLookupTable(display, window, PEXLUTColor);

    /*--- create depth-cue table -------------------------------------------*/
    RndrrMask |= PEXRADepthCueTable;
    rnd_attrs_return->depth_cue_table =
      PEXCreateLookupTable(display, window, PEXLUTDepthCue);

    /*--- create light table -----------------------------------------------*/
    RndrrMask |= PEXRALightTable;
    rnd_attrs_return->light_table =
      PEXCreateLookupTable(display, window, PEXLUTLight);

    /*--- create color approximation table and load default entry ----------*/
    RndrrMask |= PEXRAColorApproxTable;
    rnd_attrs_return->color_approx_table =
      PEXCreateLookupTable(display, window, PEXLUTColorApprox);
    PEXSetTableEntries(display, rnd_attrs_return->color_approx_table, 0, 1,
      PEXLUTColorApprox, capx);

    /*--- create text font table -------------------------------------------*/
    RndrrMask |= PEXRATextFontTable;
    rnd_attrs_return->text_font_table = PEXCreateLookupTable(display, window,
      PEXLUTTextFont);
    /* Could call LoadAllFonts here but leave that for caller. */

    /*--- create the renderer ----------------------------------------------*/
    *renderer_return = PEXCreateRenderer(display, window, 
					RndrrMask, rnd_attrs_return);

} /* CreatePEXResources */

/****************************************************************************/
SetUpRenderer(display, renderer, rnd_attrs)
    Display 			*display;
    PEXRenderer			renderer;
    PEXRendererAttributes 	*rnd_attrs;
{
    unsigned long mask = 0;

    mask |= PEXRAClearZ;
    rnd_attrs->clear_z = True;

    mask |= PEXRAClearImage;
    rnd_attrs->clear_image = True;

    mask |= PEXRABackgroundColor;
    rnd_attrs->background_color.type = PEXColorTypeRGB;
    rnd_attrs->background_color.value.rgb.red = 0.0;
    rnd_attrs->background_color.value.rgb.green = 0.0;
    rnd_attrs->background_color.value.rgb.blue = 0.0;

    PEXChangeRenderer(display, renderer, mask, rnd_attrs);

} /* SetUpRenderer */


/****************************************************************************/
LoadAllFonts(display, window, FontTable, Verbose)
    Display         	*display;               /* X display to be used */
    Window          	window;                 /* X window to be used */
    int			Verbose;		/* print out font names */
{
    int                 MaxFonts;       /* maximum possible number of fonts */
    unsigned long       NumFonts;       /* current number of fonts */
    char                **FontNames;    /* array of pointers to strings */
    PEXFont             *FontIDs;       /* pointer to array of font IDs */
    PEXTextFontEntry    *Entries;       /* pointer to array of font entries */
    PEXTableInfo        TableInfo;      /* for defining MaxFonts */
    int                 Error;          /* error-return variable */
    int                 I;              /* loop control variable */

    if (!(Error=PEXGetTableInfo(display,window,PEXLUTTextFont,&TableInfo))) {
        fprintf(stderr, "Error %d returned from %s; terminating.\n", Error,
          "PEXGetTableInfo");
        exit(1);
    }
    MaxFonts = TableInfo.definable_entries;
    FontIDs = (PEXFont *) malloc(MaxFonts * sizeof(PEXFont));
    Entries = (PEXTextFontEntry *) malloc(MaxFonts * sizeof(PEXTextFontEntry));
    if (FontNames = PEXListFonts(display, "*", MaxFonts, &NumFonts)) {
        for (I = 0; I < NumFonts; I++) {
            if (Verbose) printf("%2d:%s\n", I + 1, FontNames[I]);
            FontIDs[I] = PEXLoadFont(display, FontNames[I]);
            Entries[I].count = 1;
            Entries[I].fonts = &FontIDs[I];
        }
        PEXSetTableEntries(display, FontTable, 1, NumFonts, PEXLUTTextFont,
          (PEXPointer) Entries);
        PEXFreeFontNames(NumFonts, FontNames);
    }
    free(FontIDs);
    free(Entries);

} /* LoadAllFonts */

