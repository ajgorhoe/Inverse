/*
    KONSTRUKCIJA 2D GRAFOV
*/



gogroup gomakeframe2d(double minx,double miny,double maxx,double maxy,double z,
        golinesettings ls,golinesettings lsbas,int numx,int numy)
    /* Sestavi graficni objekt - dvodimenzionalni okvir iz crt. minx, miny,
    maxx in maxy so meje okvirja, z pa koordinata z (visina) okvirja. numx in
    numy povesta, na koliko delov naj bodo razdeljene crte, vzporedne z osema.
    ls doloca lastnosti crt, ki sestavljajo okvir, lsbas pa lastnosti crt, ki
    tvorijo osnovni kot. Ce je lsbas enak NULL, se vzame za lastnosti crt, ki
    tvorijo osnovni kot, kar ls.
    $A Igor feb97; */
{
_coord3d p1,p2;
gogroup ret=NULL,ret1=NULL;
/* Skupina, na kateri sta desna in zgornja stranica: */
ret=newgogroupst(1,5,0);
ret->name=stringcopy("2D-frame");
if (ls!=NULL)
{
  ret->ls1=malloc(sizeof(*ret->ls1));
  *(ret->ls1)=*ls;
}
/* Skupina, na kateri sta leva in spodnja stranica: */
ret1=newgogroupst(0,1,0);
pushstack(ret->groups,ret1);
ret1->name=stringcopy("axes");
/* Nastavitve za risanje crt: */
if (lsbas!=NULL)
{
  ret1->ls1=malloc(sizeof(*ret1->ls1));
  *(ret1->ls1)=*lsbas;
} else if(ls!=NULL)
{
  ret1->ls1=malloc(sizeof(*ret1->ls1));
  *(ret1->ls1)=*ls;
}
/* Desna stranica: */
p1.x=maxx; p1.y=miny; p1.z=z;
p2=p1; p2.y=maxy;
goaddlinediv(&p1,&p2,ret->primitives,ret,numy);
/* Zgornja stranica: */
p1.x=minx; p1.y=maxy;
goaddlinediv(&p2,&p1,ret->primitives,ret,numx);
/* Leva stranica: */
p2.x=minx; p2.y=miny;
goaddlinediv(&p1,&p2,ret1->primitives,ret1,numx);
/* Spodnja stranica: */
p1.x=maxx; p1.y=miny;
goaddlinediv(&p2,&p1,ret1->primitives,ret1,numx);
return ret;
}



gogroup gomakeendaxeslabels2d0(double xmin,double ymin,double xmax,double ymax,
          char *strx,char *stry,gotextsettings tsx,gotextsettings tsy,
          double factx,double facty)
{
return NULL;
}




gogroup gomakerulers2d0(double minx,double miny,double maxx,double maxy,
          double z,golinesettings ls,golinesettings ls1,golinesettings ls2,
          int numx,double relx,double relx1,double relx2,double posx,
          int numy,double rely,double rely1,double rely2,double posy)
    /* POZOR! To je zastarela funkcija, ki naj se ne bi vec uporabljala.
    Namesto nje naj bi se v prihodnje uporabljala go3dgridbas().
      Postavi ravnila na robove (okvir) dvodimenzionalnega grafa. minx,miny,
    maxx in maxy so meje okvirja, z je koordinata z ravnil (visina), ls, ls1
    in ls2 so lastnosti crt pri finih, srednje finih in grobih razdelkih,
    naprej pa so argumenti, ki dolocajo geometrijske lastnosti in sicer:
    numx je  najmanjse stevilo vseh razdelkov osi x skupaj, relx je relativna
    dolzina finih razdelkov na osi x v primerjavi s sirino grafa (maxy-miny),
    relx1 in relx2 sta isti stvari za srednjo in grbo delitev, posx pa je
    relativna pozicija zacetkov razdelkov na osi x glede na sirino grafa. Ce je
    npr. posx=1 in relx=0.1, so fini razdelki na osi x locirani na zgornjem
    robu grafa in strlijo za 0.1 sirine grafa navzven (ker je relx pozitiven;
    ce bi bil negativen, bi strleli navznoter). Ekvivalentni so pomeni
    spremenljivk, ki dolocajo geometrijske lastnosti razdelkov za os y.
    $A Igor feb97; */
{
int i;
_coord3d p1,p2;
stack st=NULL,st1=NULL,st2=NULL;
gogroup ret=NULL,retx=NULL,rety=NULL,ret0=NULL,ret1=NULL,ret2=NULL;
/* Alokacija korenske skupine: */
ret=newgogroupst(2,0,0);
ret->name=stringcopy("rulers2d");
/* Alokacija skupin za osi x in y: */
retx=newgogroupst(3,0,0);
retx->name=stringcopy("X");
pushstack(ret->groups,retx);
rety=newgogroupst(3,0,0);
rety->name=stringcopy("Y");
pushstack(ret->groups,rety);
st=newstack(10); st1=newstack(8); st2=newstack(5);
/* Skladi, na katere se nalozijo pozicije razdelkov: */
/* Os x: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
/* Skupine za fino,srednjo in grobo delitev: */
ret0=newgogroupst(0,10,0);
ret0->name=stringcopy("fine");
ret0->ls1=malloc(sizeof(*(ret0->ls1)));
*(ret0->ls1)=*ls;
ret1=newgogroupst(0,10,0);
ret1->name=stringcopy("medium");
ret1->ls1=malloc(sizeof(*(ret1->ls1)));
*(ret1->ls1)=*ls1;
ret2=newgogroupst(0,10,0);
ret2->name=stringcopy("rough");
ret2->ls1=malloc(sizeof(*(ret2->ls1)));
*(ret2->ls1)=*ls2;
pushstack(retx->groups,ret0);
pushstack(retx->groups,ret1);
pushstack(retx->groups,ret2);
gridcalc(minx,maxx,numx,st,st1,st2);
p1.z=p2.z=z;
p1.y=miny+posx*(maxy-miny);
if (st!=NULL)
  if (st->n>0)
  {
    p2.y=p1.y+relx*(maxy-miny);
    for (i=1;i<=st->n;++i)
    {
      p1.x=p2.x=*((double *)st->s[i]);
      goaddline(&p1,&p2,ret0->primitives,ret0);
    }
  }
if (st1!=NULL)
  if (st1->n>0)
  {
    p2.y=p1.y+relx1*(maxy-miny);
    for (i=1;i<=st1->n;++i)
    {
      p1.x=p2.x=*((double *)st1->s[i]);
      goaddline(&p1,&p2,ret1->primitives,ret1);
    }
  }
if (st2!=NULL)
  if (st2->n>0)
  {
    p2.y=p1.y+relx2*(maxy-miny);
    for (i=1;i<=st2->n;++i)
    {
      p1.x=p2.x=*((double *)st2->s[i]);
      goaddline(&p1,&p2,ret2->primitives,ret2);
    }
  }
/* Os y: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
/* Skupine za fino,srednjo in grobo delitev: */
ret0=newgogroupst(0,10,0);
ret0->name=stringcopy("fine");
ret0->ls1=malloc(sizeof(*(ret0->ls1)));
*(ret0->ls1)=*ls;
ret1=newgogroupst(0,10,0);
ret1->name=stringcopy("medium");
ret1->ls1=malloc(sizeof(*(ret1->ls1)));
*(ret1->ls1)=*ls1;
ret2=newgogroupst(0,10,0);
ret2->name=stringcopy("rough");
ret2->ls1=malloc(sizeof(*(ret2->ls1)));
*(ret2->ls1)=*ls2;
pushstack(rety->groups,ret0);
pushstack(rety->groups,ret1);
pushstack(rety->groups,ret2);
gridcalc(miny,maxy,numy,st,st1,st2);
p1.z=p2.z=z;
p1.x=minx+posy*(maxx-minx);
if (st!=NULL)
  if (st->n>0)
  {
    p2.x=p1.x+rely*(maxx-minx);
    for (i=1;i<=st->n;++i)
    {
      p1.y=p2.y=*((double *)st->s[i]);
      goaddline(&p1,&p2,ret0->primitives,ret0);
    }
  }
if (st1!=NULL)
  if (st1->n>0)
  {
    p2.x=p1.x+rely1*(maxx-minx);
    for (i=1;i<=st1->n;++i)
    {
      p1.y=p2.y=*((double *)st1->s[i]);
      goaddline(&p1,&p2,ret1->primitives,ret1);
    }
  }
if (st2!=NULL)
  if (st2->n>0)
  {
    p2.x=p1.x+rely2*(maxx-minx);
    for (i=1;i<=st2->n;++i)
    {
      p1.y=p2.y=*((double *)st2->s[i]);
      goaddline(&p1,&p2,ret2->primitives,ret2);
    }
  }
/* Brisanje skladov: */
if (st!=NULL)
{
  dispstackval(st); dispstack(&st);
}
if (st1!=NULL)
{
  dispstackval(st1); dispstack(&st1);
}
if (st2!=NULL)
{
  dispstackval(st2); dispstack(&st2);
}
return ret;
}


static gogroup gomakerulers2dold(double minx,double miny,double maxx,double maxy,
          double z,golinesettings ls,golinesettings ls1,golinesettings ls2,
          int num,double rel,double rel1,double rel2)
    /* Podobno kot gomakerulers2d0(), le da so nekatere stvari skupne za obe
    osi (najmanjse stevilo razdelkov num in relativne dolzine rel...), lege so
    vnaprej dolocene (niso parametri).
    POZOR: To je stara verzija gomakerulers2d in ni vec v uporabi. Cez cas se
    lahko brise.
    $A Igor feb97; */
{
return gomakerulers2d0(minx,miny,maxx,maxy,z,ls,ls1,ls2,
                       num,rel,rel1,rel2,0,
                       num,rel,rel1,rel2,0);
}

gogroup gomakerulers2d(double minx,double miny,double maxx,double maxy,
          double z,golinesettings ls,golinesettings ls1,golinesettings ls2,
          int num,double rel,double rel1,double rel2)
    /* Postavi ravnila na robove dvodimenzionalnega grafa. minx, miny, maxx in
    maxy dolocajo okvir grafa z pa koordinato z (visino) grafa. V ls, ls1 in
    ls2 so nastavitve za risanje crt pri fini, srednji in grobi razdelitvi.
    num je najmanjse stevilo vseh razdelkov za katerokoli os,rel, rel1 in rel2
    pa so ustrezne relativne dolzine razdelkov glede na dimenzije okvirja.
    $A Igor feb97; */
{
_frame3d frame;
frame.min.x=minx; frame.min.y=miny;frame.min.z=z;
frame.max.x=maxx; frame.max.y=maxy;frame.max.z=z;
return go3dgridbas(&frame,
           ls,ls1,ls2,num, 0,0, rel,rel1,rel2, 0,0,0,
           ls,ls1,ls2,num, 0,0, rel,rel1,rel2, 0,0,0,
           ls,ls1,ls2,num, 0,0, 0,0,0, 0,0,0,
           1,1,0);
}




gogroup gomakerulertext2d0(double minx,double miny,double maxx,double maxy,
            double z,gotextsettings tsx,gotextsettings tsy,
            int digx,int numx,double numxtext,double posx,
            int digy,int numy,double numytext,double posy)
    /* POZOR! To je zastarela funkcija, ki naj se ne bi vec uporabljala.
    Namesto nje naj bi se v prihodnje uporabljala go3dgridtextbas().
      Sestavi stevilcne oznake za ravnila dvodimenzionalnega grafa. minx,
    miny,maxx in maxy so meje okvirja grafa, z pa je koordinata z (visina)
    grafa. V tsx in tsy so nastavitve za tekst za os x in za os y.
    digx je stevilo decimalnih mest, ki se izpisuje za os x. numx je najmanjse
    stevilo razdelkov za os x, kot je bilo uporabljeno v funkciji, ki naredi
    ravnilo, numxtext pa je najmanjse stevilo stevilcnih oznak, ki se izpisejo
    tekstovno. Glede na numx in numxtext se funkcija odloci, ali bodo stevilcne
    oznake le na najbolj grobi delitvi, ali pa morda tudi na finejsih. posx je
    relativna oddaljenost stevilcnih oznak za os x od spodnjega roba grafa
    glede na visino grafa (maxy-miny). Ce je na primer posx=0.1, bodo stevilcne
    oznake za os x ob spodnjem robu grafa, pomaknjene za 0.1 visine grafa v
    notranjost, ce pa je posx=1.05, bodo nad zgornjim robom grafa pomaknjene
    za 0.05 visine grafa navzven.
    Pomen argumentov digy, numy, numytext, posy in posy je ekvivalenten, le da
    se nanasajo na os y.
    $A Igor feb97 */
{
int i;
char *str=NULL;
_coord3d p1;
stack st=NULL,st1=NULL,st2=NULL;
gogroup ret=NULL,retx=NULL,rety=NULL;
str=malloc(30);

ret=newgogroupst(3,0,0);
ret->name=stringcopy("rulertext2d");
retx=newgogroupst(0,10,0);
retx->name=stringcopy("x");
retx->ts1=malloc(sizeof(*(retx->ts1)));
*(retx->ts1)=*tsx;
rety=newgogroupst(0,10,0);
rety->name=stringcopy("y");
rety->ts1=malloc(sizeof(*(rety->ts1)));
*(rety->ts1)=*tsy;
pushstack(ret->groups,retx);
pushstack(ret->groups,rety);
st=newstack(10); st1=newstack(8); st2=newstack(5);

/* Os x: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
gridcalc(minx,maxx,numx,st,st1,st2);
/* Na sklad st2 se prepisejo tudi razdelbe s st1 in po moznosti se s st, ce je
razdelb na st2 manj kot numxtext: */
if (st2->n<numxtext)
  while(st1->n>0)
      pushstack(st2,popstack(st1));
if (st2->n<numxtext)
  while(st->n>0)
      pushstack(st2,popstack(st));
p1.z=z; p1.y=miny+posx*(maxy-miny);
if (st2->n>0)
  for (i=1;i<=st2->n;++i)
  {
    p1.x=*((double *)st2->s[i]);
    sprintf(str,"%.*g",digx,p1.x);
    goaddtext(str,&p1,retx->primitives,retx);
  }

/* Os y: */
dispstackval(st); dispstackval(st1); dispstackval(st2);
popstackall(st); popstackall(st1); popstackall(st2);
gridcalc(miny,maxy,numy,st,st1,st2);
/* Na sklad st2 se prepisejo tudi razdelbe s st1 in po moznosti se s st, ce je
razdelb na st2 manj kot numytext: */
if (st2->n<numytext)
  while(st1->n>0)
      pushstack(st2,popstack(st1));
if (st2->n<numytext)
  while(st->n>0)
      pushstack(st2,popstack(st));
p1.z=z; p1.x=minx+posy*(maxx-minx);
if (st2->n>0)
  for (i=1;i<=st2->n;++i)
  {
    p1.y=*((double *)st2->s[i]);
    sprintf(str,"%.*g",digy,p1.y);
    goaddtext(str,&p1,retx->primitives,retx);
  }

if (str!=NULL)
  free(str);
if (st!=NULL)
{
  dispstackval(st); dispstack(&st);
}
if (st1!=NULL)
{
  dispstackval(st1); dispstack(&st1);
}
if (st2!=NULL)
{
  dispstackval(st2); dispstack(&st2);
}
return ret;
}



gogroup gomakerulertext2dold(double minx,double miny,double maxx,double maxy,
            double z,gotextsettings ts, int dig,int num,double numtext,
            double pos)
    /* Podobno kot gomakerulertext2d0(), le da so nekatere stvari skupne za
    vse osi (nastavitve za tekst ts, stevilo decimalk dig, najmanjse stevilo
    razdelkov num, najmanjse stevilo stevilcnih oznak numtext, relativna
    pozicija glede na okvir grafa pos).
    POZOR: To je stara verzija in ni vec v uporabi. Cez cas se lahko brise.
    $A Igor feb97; */
{
return gomakerulertext2d0(minx,miny,maxx,maxy,z,ts,ts,
            dig,num,numtext,pos,dig,num,numtext,pos);
}


gogroup gomakerulertext2d(double minx,double miny,double maxx,double maxy,
            double z,gotextsettings ts, int dig,int num,double numtext,
            double pos)
    /* Postavi stevilcne oznake v obliki teksta za ravnila dvodimenzionalnega
    grafa. minx, miny, maxx in maxy dolocajo meje okvirja gtrafa, z pa njegovo
    koordinato z (visino). V ts so nastavitve za tekst. digits je stevilo
    decimalk, ki se izpisejo v oznakah. num je najmanjse stevilo vseh razdelkov
    ravnil, numtext pa je najmanjse stevilo oznak. pos je relstivna pozicija
    oznak glede na dimenzije okvirja. Funkcija je misljena za uporabo skupaj s
    funkcijo gomakerulers2d(). V tem primeru mora biti argument num enak kot
    pri klicu te funkicje.
    $A Igor feb97; */
{
_frame3d frame;
frame.min.x=minx; frame.min.y=miny;frame.min.z=z;
frame.max.x=maxx; frame.max.y=maxy;frame.max.z=z;
return go3dgridtextbas(&frame,
             ts,dig,num,(int) numtext,-pos,0.0,
             ts,dig,num,(int) numtext,-pos,0.0,
             ts,dig,num,(int) numtext,0.0,0.0,
             (char) 1,(char) 1,(char) 0);
}





static gogroup gocurveplot2dpar0(double fx(double),double fy(double),
        int num,int div,double from, double to,double z,golinesettings ls)
    /* Sestavi graficni objekt - graf parametricno podane krivulje v dveh
    dimenzijah. fx, in fy sta funkcijski odvisnosti koordinat od parametra, ki
    tece od from do to. Krivulja je razdeljena na num ravnih delov, od katerih
    je vsak razdeljen na div krajsih crt. V ls so lastnosti crt, ki sestavljajo
    krivuljo. z je koordinata z (visina) grafa.
    $A Igor feb97; */
{
double step;
_coord3d p1,p2;
gogroup ret=NULL;
int i;
step=(to-from)/((double) num);
ret=newgogroupst(0,100,0);
/*
ret->name=stringcopy("curveplot2d");
*/
/* Nastavitve za risanje crt: */
if (ls!=NULL)
{
  ret->ls1=malloc(sizeof(*ret->ls1));
  *(ret->ls1)=*ls;
}
/* Sestava grafa: */
p2.x=fx(from);  p2.y=fy(from);  p2.z=z;
for (i=1;i<=num;++i)
{
  p1=p2;
  p2.x=fx(from+((double)i)*step);
  p2.y=fy(from+((double)i)*step);
  goaddlinediv(&p1,&p2,ret->primitives,ret,div);
}
return ret;
}

gogroup gocurveplot2dpar(double fx(double),double fy(double),
        int num,int div,double from, double to,double z,golinesettings ls)
    /* Sestavi graficni objekt - graf parametricno podane krivulje v dveh
    dimenzijah. Funkcija je identicna gocurveplot2dpar0(), le da postavi se ime
    skupine, ki jo vrne.
    $A Igor feb97; */
{
gogroup ret;
ret=gocurveplot2dpar0(fx,fy,num,div,from,to,z,ls);
if (ret!=NULL)
  ret->name=stringcopy("curveplot2dpar");
return ret;
}



static double retarg(double x)
    /* Vrne svoj argument. Uporablja se za to, da lahko funkcijo za risanje
    parametricno podanih krivulj v 2 dimenzijah uporabimo za grafe funkcij.
    $A Igor feb97 */
{
return x;
}

gogroup gocurveplot2d(double ff(double),int num,int div,
        double from, double to,double z,golinesettings ls)
    /* Sestavi graficni objekt - graf funkcije ff, pri cemer x tece od from do
    to. Krivulja je razdeljena na num ravnih delov, od katerih je vsak
    razdeljen na div krajsih crt. V ls so lastnosti crt, ki sestavljajo
    krivuljo. z je koordinata z (visina) grafa.
    $A Igor feb97; */
{
gogroup ret;
ret=gocurveplot2dpar0(retarg,ff,num,div,from,to,z,ls);
if (ret!=NULL)
  ret->name=stringcopy("curveplot2d");
return ret;
}



/* Kazalec na funkcijo za polarni graf */
static double (*rpolar) (double fi)=retarg;

static double xpolar(double fi)
    /* Vrne koordinato x v odvisnosti od polarnega kota fi.
    $A Igor feb97; */
{
return rpolar(fi)*cos(fi);
}

static double ypolar(double fi)
    /* Vrne koordinato y v odvisnosti od polarnega kota fi.
    $A Igor feb97; */
{
return rpolar(fi)*sin(fi);
}

gogroup gocurveplotpolar(double fr(double),int num,int div,
        double from, double to,double z,golinesettings ls)
    /* Sestavi graficni objekt - polarni graf funkcije fr, pri cemer polarni
    kot tece od from do to. Krivulja je razdeljena na num ravnih delov, od
    katerih je vsak razdeljen na div krajsih crt. V ls so lastnosti crt, ki
    sestavljajo krivuljo. z je koordinata z (visina) grafa.
    $A Igor feb97; */
{
gogroup ret;
/* Nastavitev funkcije, ki jo kliceta xpolar() in ypolar(): */
rpolar=fr;
ret=gocurveplot2dpar0(xpolar,ypolar,num,div,from,to,z,ls);
if (ret!=NULL)
  ret->name=stringcopy("polarcurveplot");
return ret;
}




