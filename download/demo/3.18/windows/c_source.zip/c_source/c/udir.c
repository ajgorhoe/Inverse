#include <string.h>
#include <stdlib.h>

#include <sysint.h>


#include <mtypes.h>
#include <st.h>
#include <strop.h>
#include <fop.h>
#include <er.h>
#include <udir.h>



dirtype newdirtype(void)
        /* Vrne objekt tipa dirtype, za katerega rezervira prostor v spominu. */
{
  dirtype d=NULL;
  d=(dirtype) malloc(sizeof(*d));
  memset(d,0,sizeof(*d));
  d->str=NULL;
  d->name=NULL;
  d->relpath=NULL;
  d->link=NULL;
  d->own=NULL;
  d->grp=NULL;
  d->permit=NULL;
  d->length=NULL;
  d->nlinks=NULL;
  d->dlength=NULL;
  d->tdlength=NULL;
  d->nf=NULL;
  d->tnf=NULL;
  d->date=NULL;
  d->cont=NULL;
  return d;
}





void dispdirtype(dirtype *d)
     /* Sprosti spomin, ki ga zaseda d. Pred tem sprosti tudi spomin, ki ga
     zasedajo komponente *d. */
{
if (*d!=NULL)
{
  if ((*d)->str!=NULL)
    free((*d)->str);
  if ((*d)->name!=NULL)
    free((*d)->name);
  if ((*d)->relpath!=NULL)
    free((*d)->relpath);
  if ((*d)->link!=NULL)
    free((*d)->link);
  if ((*d)->own!=NULL)
    free((*d)->own);
  if ((*d)->grp!=NULL)
    free((*d)->grp);
  if ((*d)->permit!=NULL)
    free((*d)->permit);
  if ((*d)->length!=NULL)
    free((*d)->length);
  if ((*d)->nlinks!=NULL)
    free((*d)->nlinks);
  if ((*d)->dlength!=NULL)
    free((*d)->dlength);
  if ((*d)->tdlength!=NULL)
    free((*d)->tdlength);
  if ((*d)->nf!=NULL)
    free((*d)->nf);
  if ((*d)->tnf!=NULL)
    free((*d)->tnf);
  if ((*d)->date!=NULL)
    free((*d)->date);
  if ((*d)->cont!=NULL)
    dispstack(&((*d)->cont));
  free(*d);
  *d=NULL;
}
}



void dispdirtree(dirtype *d)
     /* Zbrise celotno drevo *d, ki predstavlja direktorijsko strukturo
     (rekurzivno se brisejo vsi poddirektoriji). Po brisanju postavi *d na
     NULL. */
{
int i;
if ((*d)->cont!=NULL)
  if ((*d)->cont->n>0)
    for (i=1;i<=(*d)->cont->n;++i)
      dispdirtree((dirtype *) &( (*d)->cont->s[i] ) );
dispdirtype(d);
}






static char kinddirentry(dirtype dd)
       /* Vrne vrsto datoteke, ki jo predstavlja podatkovna struktura tipa
       dirtype. Ce je to prava datoteka, v Unixu vrne '-', ce je direktorij,
       'd', ce pa je link, vrne 'l'. Ce se ne da ugotoviti vrsta datoteke iz
       dd, funkcija vrne znak '\0'. */
{
if (dd==NULL)
  return('\0');
if (dd->str!=NULL)
  return dd->str[0];
else if (dd->permit!=NULL)
  return dd->permit[0];
else
  return '\0';
}





dircom newdircom(void)
       /* Vrne objekt tipa dircom, za katerega rezervira prostor. Rezervira
       tudi prostor za (...)->dm in (...)->dkm. */
{
dircom dc;
dc=(dircom) malloc(sizeof(*dc));
memset(dc,0,sizeof(*dc));
dc->fp=stdout;
dc->spaces=0;
dc->plusspaces=3;
dc->dlevel=10000;
dc->llevel=0;
dc->pdlevel=3;
dc->pllevel=0;
dc->spacechar=' ';
dc->inslines=0;
dc->printdirdata=1;
dc->printhead=1;
dc->dm= (dirmask) malloc( sizeof(*(dc->dm)) );
memset(dc->dm,0, sizeof(*(dc->dm)) );
dc->pdm= (dirmask) malloc( sizeof(*(dc->pdm)) );
memset(dc->pdm,0, sizeof(*(dc->pdm)) );
dc->dkm= (dirkindmask) malloc( sizeof(*(dc->dkm)) );
memset(dc->dkm,0, sizeof(*(dc->dkm)) );
dc->dm->str=1;
dc->dm->name=1;
dc->dm->link=1;
dc->dm->own=dc->dm->grp=dc->dm->permit=1;
dc->dm->length=1;
dc->dm->nlinks=1;
dc->dm->date=1;
dc->pdm->str=1;
dc->pdm->name=1;
dc->pdm->link=1;
dc->pdm->own=dc->pdm->grp=dc->pdm->permit=0;
dc->pdm->length=1;
dc->pdm->nlinks=0;
dc->pdm->date=0;
dc->dkm->file=1;
dc->dkm->dir=1;
dc->dkm->link=1;
dc->dkm->unknown=0;
dc->dkm->rest=1;
return dc;
}




void dispdircom(dircom *dc)
     /* Zbrise objekt tipa dircom, na katerega kaze *dc. Ta kazalec potem
     postavi na NULL. Zbrise tudi (*dc)->dm in (*dc)->dkm. */
{
dircom dcr=*dc;
if (*dc!=NULL)
{
  if (dcr->dm!=NULL)
    free(dcr->dm);
  if (dcr->pdm!=NULL)
    free(dcr->pdm);
  if (dcr->dkm!=NULL)
    free(dcr->dkm);
  free(*dc);
  *dc=NULL;
}
}




dircom copydircom(dircom dc)
       /* Vrne kopijo objekta tipa dirkom. Skopira tudi dc->dm in dc->dkm. */
{
dircom ret=NULL;
if (dc!=NULL)
{
  ret=newdircom();
  ret->fp=dc->fp;
  ret->spaces=dc->spaces;
  ret->plusspaces=dc->plusspaces;
  ret->dlevel=dc->dlevel;
  ret->llevel=dc->llevel;
  ret->pdlevel=dc->pdlevel;
  ret->pllevel=dc->pllevel;
  ret->spacechar=dc->spacechar;
  ret->inslines=dc->inslines;
  ret->printdirdata=dc->printdirdata;
  ret->printhead=dc->printhead;
  memcpy(ret->dm,dc->dm,sizeof(*(ret->dm)));
  memcpy(ret->pdm,dc->pdm,sizeof(*(ret->pdm)));
  memcpy(ret->dkm,dc->dkm,sizeof(*(ret->dkm)));
}
return ret;
}



void consistentdircom(dircom dc)
     /* Zagotovi notranjo konsistenco ukazne strukture za delo z direktoriji
     dc (Zagotovi na primer, da zahteve v dc->pdm niso vecje kot zahteve v
     dc->dm; to bi namrez privedlo do neuresnicljivih zahtev, saj se ne da
     uresniciti zahteva za izpis necesa, kar ni bilo shranjeno.). */
{
if (dc!=NULL)
{
  if (dc->printhead || dc->printdirdata)
    dc->dm->length=1;
  if (dc->dlevel<dc->pdlevel)
    dc->dlevel=dc->pdlevel;
  if (dc->llevel<dc->pllevel)
    dc->llevel=dc->pllevel;
  if (dc->dm!=NULL && dc->pdm!=NULL)
  {
    if (dc->pdm->str)
      dc->dm->str=1;
    if (dc->pdm->name)
      dc->dm->name=1;
    if (dc->pdm->link)
      dc->dm->link=1;
    if (dc->pdm->own)
      dc->dm->own=1;
    if (dc->pdm->grp)
      dc->dm->grp=1;
    if (dc->pdm->permit)
      dc->dm->permit=1;
    if (dc->pdm->length)
      dc->dm->length=1;
    if (dc->pdm->nlinks)
      dc->dm->nlinks=1;
    if (dc->pdm->date)
      dc->dm->date=1;
    if (dc->pdm->cont)
      dc->dm->cont=1;
  }
}
}



static long longmonth(char *month)
     /* Vrne zap. st. meseca, ki je predstavljen s trimestnim nizom mounth z
     veliko zacetnico */
{
if (cmpstrings(month,"Jan")==0)
  return 1;
else if (cmpstrings(month,"Feb")==0)
  return 2;
else if (cmpstrings(month,"Mar")==0)
  return 3;
else if (cmpstrings(month,"Apr")==0)
  return 4;
else if (cmpstrings(month,"May")==0)
  return 5;
else if (cmpstrings(month,"Jun")==0)
  return 6;
else if (cmpstrings(month,"Jul")==0)
  return 7;
else if (cmpstrings(month,"Aug")==0)
  return 8;
else if (cmpstrings(month,"Sep")==0)
  return 9;
else if (cmpstrings(month,"Oct")==0)
  return 10;
else if (cmpstrings(month,"Nov")==0)
  return 11;
else if (cmpstrings(month,"Dec")==0)
  return 12;
else
return 0;
}




static stack dirdata(char *path)
        /* Vrne sklad, na katerega da podatke v obliki struktur tipa dirtype o
        datotekah, ki so vsebovane v direktoriju path. Funkcija zapise le nize,
        s katerimi Unix opise datoteko pri ukazu 'll -a'. te nize shrani v nize
        (...)->str v strukturah tipa dirtype.
        tempfile je ime pomozne datoteke, ki jo funkcija uporablja za prenos
        informacij z Unixa. */
{
char *com=NULL,*com1=NULL,*line=NULL,*tempfile=NULL,*str;
FILE *fp;
stack st=NULL;
dirtype d=NULL;
int linelength,strlength,buflength=500; /* maksimalna dolzina vrstice */
st=newstack(5);
tempfile= (char *) makestring(256);
tempfile=tmpnam(tempfile);
if (strlen(tempfile)<=0)
  printf("ERROR IN directory0(): Can't create unique file name\n");
/* printf("tempfile: %s\n",tempfile); */
/* Podatki se s pomocjo Unixovega ukaza 'll -a' najprej zapisejo v datoteko z
imenom tempfile: */
com=stringcat("ls -a -l ",path);
com1=stringcat(com," > ");
free(com);
com=stringcat(com1,tempfile);
free(com1); com1=NULL;
system(com);
free(com); com=NULL;
/* Branje podatkov iz datoteke z imenom tempfile: */
fp=fopen(tempfile,"rb");
if (fp==NULL)
  printf("ERROR IN directory0(): Can't create unique file name\n");
line= (char *) makestring(buflength);
while (!feof(fp))
{
  fgets(line,buflength+1,fp);
  if ( strlen(line)>0 && (!feof(fp)) )
  {
    /* Vrstice v izpisu sistemskega ukaza (v tem primeru "ls -a -l"), ki
    predstalvjajo datoteke, se potisnejo na sklad st. Pri tem moramo eliminirati
    nize s posebnim pomenom (npr. niz, ki pove skupno st. bytov v direktoriju
    in niz, ki pove, da datoteka ne obstaja) */
    str=line;
    linelength=strlen(line);
    strlength=strlen("not found");
    if (linelength>=strlength)
      str=line+linelength-strlength;
    if (strncmp("total",line,sizeof("total")-1) != 0 &&
     cmpstrings(str,"not found")!=0 )
    {
      d=newdirtype();
      line[strlen(line)-1]='\0';
      d->str=stringcopy(line);
      pushstack(st,d);
    }
  }
}
if (line!=NULL)
  free(line);
line=NULL;
fclose(fp);
remove(tempfile);
if (tempfile!=NULL) free(tempfile);
return st;
}




static void developdirentry(dirtype dd,dirmask dm)
     /* Razvije niz, kakrsnega tvori funkcija dirdata in predstavlja podatke o
     direktoriju ali datoteki. Iz tega niza izlusci podatke glede na vrednosti
     polj strukture *dm in jih razvrsti v strukturo *dd (Podatki so v nizu
     dd->str). */
{
char *pnlinks=NULL,*pown=NULL,*pgrp=NULL,*ppermit=NULL,*plength=NULL,
     *pmonth=NULL,*pdate=NULL,*pyear=NULL,*pname=NULL,*plink=NULL,
     *parrow=NULL,*p=NULL,*p1=NULL,*p2=NULL;
char *str=NULL;
long *lp=NULL;
datetype date=NULL;
str=stringcopy(dd->str); /* Naredi se kopija niza, ki predstavlja datoteko */
if (str!=NULL)
{
/* Kopija se razbije na pomenske odseke: */
ppermit=memnotnchr(str,strlen(str)," \n\r\0",4);
p=memnchr(ppermit,strlen(ppermit)+1," \n\r\0",4);
pnlinks=memnotnchr(p,strlen(p)," \n\r\0",4);
p[0]='\0';
p=memnchr(pnlinks,strlen(pnlinks)+1," \n\r\0",4);
pown=memnotnchr(p,strlen(p)," \n\r\0",4);
p[0]='\0';
p=memnchr(pown,strlen(pown)+1," \n\r\0",4);
pgrp=memnotnchr(p,strlen(p)," \n\r\0",4);
p[0]='\0';
p=memnchr(pgrp,strlen(pgrp)+1," \n\r\0",4);
plength=memnotnchr(p,strlen(p)," \n\r\0",4);
p[0]='\0';
p=memnchr(plength,strlen(plength)+1," \n\r\0",4);
pmonth=memnotnchr(p,strlen(p)," \n\r\0",4);
p[0]='\0';
p=memnchr(pmonth,strlen(pmonth)+1," \n\r\0",4);
pdate=memnotnchr(p,strlen(p)," \n\r\0",4);
p[0]='\0';
p=memnchr(pdate,strlen(pdate)+1," \n\r\0",4);
pyear=memnotnchr(p,strlen(p)," \n\r\0",4);
p[0]='\0';
p=memnchr(pyear,strlen(pyear)+1," \n\r\0",4);
pname=memnotnchr(p,strlen(p)," \n\r\0",4);
p[0]='\0';
p=memnchr(pname,strlen(pname)+1," \n\r\0",4);
parrow=memnotnchr(p,strlen(p)," \n\r\0",4);
p[0]='\0';
if (parrow!=NULL)
{
  p=memnchr(parrow,strlen(parrow)+1," \n\r\0",4);
  plink=memnotnchr(p,strlen(p)," \n\r\0",4);
  p[0]='\0';
  p=memnchr(plink,strlen(plink)+1," \n\r\0",4);
  /* plink=memnotnchr(p,strlen(p)," \n\r\0",4); */
  p[0]='\0';
}
if (dm->permit)
  dd->permit=stringcopy(ppermit);
if (dm->nlinks)
{
  lp=(long *) malloc(sizeof(*lp));
  *lp=atol(pnlinks);
  dd->nlinks=lp; lp=NULL;
}
if (dm->own)
  dd->own=stringcopy(pown);
if (dm->grp)
  dd->grp=stringcopy(pgrp);
if (dm->length)
{
  lp=(long *) malloc(sizeof(*lp));
  *lp=atol(plength);
  dd->length=lp; lp=NULL;
}
if (dm->name)
  dd->name=stringcopy(pname);
if (dm->link)
  if (plink!=NULL)
    dd->link=stringcopy(plink);
if (dm->date)
{
  date=(datetype) malloc(sizeof(*date));
  memset(date,0,sizeof(*date));
  date->month=longmonth(pmonth);
  date->day=atol(pdate);
  p=memnchr(pyear,strlen(pyear),":",1);
  if (p==NULL)
    date->year=atol(pyear);
  else
  {
    p[0]='\0';
    ++p;
    date->hour=atol(pyear);
    date->min=atol(p);
  }
  dd->date=date;
}
free(str); str=NULL;
}
}




static void developdirdata(stack st,dirmask dm)
     /* Na vseh elementih sklada st izvede funkcijo developdirentry(). */
{
int i;
if (st!=NULL)
  if (st->n>0)
    for (i=1;i<=st->n;++i)
    {
      developdirentry((dirtype)st->s[i],dm);
    }
}







static void arrangedirdata(stack st)
     /* Uredi podatke o direktoriju na skladu st tako, da so na skladu najprej
     podatki o direktorijih, nato o linkih in nazadnje o datotekah. */
{
stack st1=NULL;
dirtype dd;
int i;
if (st!=NULL)
  if (st->n>0)
  {
    st1=newstack(6);
    /* Na sklad st1 se najprej nalozijo podatki s sklada st, ki predstavljajo
    direktorije. Pri tem se izpustita direktorija z imenoma "." in ".." : */
    for (i=1;i<=st->n;++i)
    {
      dd=(dirtype) st->s[i];
      if ( kinddirentry(dd) == 'd')
      {
        if (dd->name!=NULL)
        {
          /* Ce smo naleteli na direktorij z imenom "." ali "..", ga brisemo s
          sklada st, drugace ga potisnemo na sklad st1: */
          if (cmpstrings(dd->name,".")!=0 && cmpstrings(dd->name,"..")!=0)
            pushstack(st1,st->s[i]);
          else
          {
            dispdirtype( (dirtype *) &(st->s[i]) );
            delstack(st,i);
          }
        }
        else
          pushstack(st1,st->s[i]);
      }
    }
    /* Nato se na sklad st1 nalozijo podatki s sklada st, ki predstavljajo
    linke: */
    for (i=1;i<=st->n;++i)
    {
      if ( kinddirentry( (dirtype) st->s[i] ) == 'l')
        pushstack(st1,st->s[i]);
    }
    /* Nato se na sklad st1 nalozijo podatki s sklada st, ki predstavljajo
    datoteke: */
    for (i=1;i<=st->n;++i)
    {
      if ( kinddirentry( (dirtype) st->s[i] ) == '-')
        pushstack(st1,st->s[i]);
    }
    /* Nato se na sklad st1 nalozijo podatki s sklada st, za katere se ne da
    ugotoviti, kaj predstavljajo: */
    for (i=1;i<=st->n;++i)
    {
      if ( kinddirentry( (dirtype) st->s[i] ) == '\0')
        pushstack(st1,st->s[i]);
    }
    popstackall(st);
    for (i=1;i<=st1->n;++i)
      pushstack(st,st1->s[i]);
    if (st1!=NULL)
      dispstack(&st1);
  }
}




static void fprintdirectory(FILE *fp,stack st,int spaces,char spacechar)
     /* V datoteko fp izpise podatke o direktoriju, ki so na skladu st. Izpise
     le en nivo (ignorira poddirektorije) ter izpisuje le nize (...)->str
     podatkov, ki so na tem skladu. To so nizi, ki jih generira UNIXov ukaz
     ll. */
{
dirtype d=NULL;
char *spstr=NULL;
int i;
if (fp!=NULL)
{
  spstr=makestring(spaces);
  if (spaces>0)
    memset(spstr,spacechar,spaces);
  if (st!=NULL)
    if (st->n>0)
      for (i=1; i<=st->n; ++i)
      {
        d=(dirtype) st->s[i];
        fprintf(fp,"%i: %s%s\n",i,spstr,d->str);
      }
  if (spstr!=NULL)
    free(spstr);
  }
}




static void fprintdirentry(FILE *fp,dirtype dd,dirmask dm)
     /* V datoteko fp izpise podatke o datoteki (direktoriju, linku, ...), na
     katere kaze dd. dm doloca, kaj od teh podatkov se bo izpisalo. */
{
if (fp!=NULL)
{
  if (dm->permit)
    if (dd->permit!=NULL)
    {
      fprintf(fp,"%-s",dd->permit);
      fprintf(fp," ");
    }
  if (dm->nlinks)
    if (dd->nlinks!=NULL)
    {
      fprintf(fp,"%-3i",*(dd->nlinks));
      fprintf(fp," ");
    }
  if (dm->own)
    if (dd->own!=NULL)
    {
      /* fprintf(fp,"%-8s",dd->own); */
      fprintf(fp,"%-8s",dd->own);
      fprintf(fp," ");
    }
  if (dm->grp)
    if (dd->grp!=NULL)
    {
      /* fprintf(fp,"%-8s",dd->grp); */
      fprintf(fp,"%-8s",dd->grp);
      fprintf(fp," ");
    }
  if (dm->length)
    if (dd->length!=NULL)
    {
      fprintf(fp,"%-9li",*(dd->length));
      fprintf(fp," ");
    }
  if (dm->date)
    if (dd->date!=NULL)
    {
      fprintf(fp,"%02i.%02i. ",dd->date->day,dd->date->month);
      if (dd->date->year!=0)
        fprintf(fp,"%5i",dd->date->year);
      else
      {
        fprintf(fp,"%02i:%02i",dd->date->hour,dd->date->min);
      }
      fprintf(fp," ");
    }
  if (dm->name)
    if (dd->name!=NULL)
      fprintf(fp,"%-s",dd->name);
  if (dm->link)
    if (dd->link!=NULL)
    {
      fprintf(fp," ");
      fprintf(fp,"=> %-s",dd->link);
    }
  }
}







static void fprintdir(FILE *fp,stack st,int spaces,char spacechar,dirmask dm,
     dirkindmask dkm)
     /* V datoteko fp izpise podatke o direktoriju, ki so na skladu st v obliki
     kazalcev tipa dirtype. Space dolzina niza, ki se izpise pred izpisom
     podatkov o posamezni datoteki, spacechar je znak, ki se ponavlja v tem
     nizu, dm pove, kateri podatki naj se izpisejo o posamezni stvari, dkm
     pa pove, ali naj se izpisejo datoteke, direktoriji, linki in stvari neznane
     vrste. Izpise se le 1. nivo, tudi ce podatki o direktorijih na skladu st
     vsebujejo se podatke o svojih poddirektorijih. */
{
int i;
char *spacestr=NULL;
if (fp!=NULL)
{
  /* Tvori se niz presledkov: */
  spacestr=makestring(spaces);
  memset(spacestr,spacechar,spaces);
  spacestr[spaces]='\0';
  if (st!=NULL)
    if (st->n>0)
    {
      for (i=1;i<=st->n;++i)
      {
        fprintf(fp,"%s",spacestr);
        fprintdirentry(fp,(dirtype) st->s[i],dm);
        fprintf(fp,"\n");
      }
    }
  if (spacestr!=NULL)
    free(spacestr);
}
}



stack dirdatatree(char *path,dirmask dm,int dlevel,int llevel)
      /* Vrne sklad, na katerem so nalozeni podatki o direktoiju oziroma
      datoteki z imenom path. Ce gre za datoteko, nalozi na sklad le en podatek
      tipa dirtype, ce pa gre za direktorij, nalozi na sklad po en podatek te
      vrste za vsak direktorij, link, datoteko itd. v tem direktoriju.
        Pri direktorijih in linkih lahko funkcija (odvisno od vrednosti dlevel
      oz. llevel) rekurzivno doda podatke o njihovih poddirektorijih in linkih.
        Kateri podatki se shranejo, je odvisno od vrednosti polj strukture *dm.
      dlevel pove, za koliko poddirektorijev v globino se shranjujejo podatki,
      llevel pa pove, do kaksne globine se gre pri linkih (globina se steje
      neodvisno za podlinke in poddirektorije. */
{
int i,j;
dirtype dd=NULL,dd1=NULL;
char *str1=NULL,*path1=NULL,*path2=NULL;
stack ret=NULL,st=NULL;
ret=dirdata(path);
developdirdata(ret,dm);
arrangedirdata(ret);
--dlevel; --llevel;
if (llevel<0)
  llevel=0;
if (ret!=NULL)
  if (ret->n>0)
  {
    if (path[strlen(path)-1]=='/')
      path1=stringcopy(path);
    else
      path1=stringcat(path,"/");
    if (dlevel>0)
    {
      /* Naprej se gradijo strukture za vse poddirektorije, ki so v direktoriju
      path: */
      for (i=1;i<=ret->n;++i)
        if(kinddirentry( ( dd = (dirtype)ret->s[i]) ) =='d' )
        {
          /* Ce je i. element direktorij, se zanj tvori podstruktura */
          if (dd->name!=NULL)
          {
            path2=stringcat(path1,dd->name);
            printf("  Listing  %s\n",path2);
            dd->cont=dirdatatree(path2,dm,dlevel,llevel);
            dd->relpath=stringcopy(path2);
            free(path2); path2=NULL;
          }
        }
    }
    if (llevel>0)
    {
      /* Nato se gradijo strukture za vse linke, ki so v direktoriju
      path: */
      for (i=1;i<=ret->n;++i)
        if(kinddirentry( ( dd = (dirtype)ret->s[i]) ) =='l')
        {
          /* Ce je i. element link, se zanj tvori podstruktura */
          if (dd->name!=NULL)
          {
            path2=stringcat(path1,dd->name);
            dd->cont=dirdatatree(path2,dm,dlevel,llevel);
            free(path2); path2=NULL;
          }
        }
    }
    /* Izracuna se dolzina direktorija, celotna dolzina direktorija s
    poddirektoriji vred (do globine, ki je dolocena v argumentih dlevel in
    llevel), st. datotek v direktoriju in celotno st. datotek v direktoriju
    z vsemi poddirektoriji vred (do omenjene globine) za vsako stvar */
    for (i=1; i<=ret->n; ++i)
    {
      /* Izracun skupne dolzine in stevila datotek v direktorijih, ki so
      vsebovani v direktorijih na skladu ret: */
      dd=(dirtype) ret->s[i];
      /* Najprej se alocira prostor za posamezne kazalce: */
      if (dd->dlength==NULL) dd->dlength=(long *) malloc(sizeof(*(dd->dlength)));
      if (dd->tdlength==NULL) dd->tdlength=(long *) malloc(sizeof(*(dd->tdlength)));
      if (dd->nf==NULL) dd->nf=(long *) malloc(sizeof(*(dd->nf)));
      if (dd->tnf==NULL) dd->tnf=(long *) malloc(sizeof(*(dd->tnf)));
      *(dd->dlength)=0; *(dd->tdlength)=0;
      *(dd->nf)=0;      *(dd->tnf)=0;
      if (dd->cont!=NULL)
        if (dd->cont->n>0)
          for (j=1;j<=dd->cont->n;++j)
          {
            dd1=(dirtype) dd->cont->s[j];
            if (dd1!=NULL)
            {
              ++ *(dd->nf);
              ++ *(dd->tnf);
              if (dd1->length!=NULL)
              {
                *(dd->dlength) += *(dd1->length);
                *(dd->tdlength) += *(dd1->length);
              }
              if (dd1->tdlength!=NULL)
                *(dd->tdlength) += *(dd1->tdlength);
              if (dd1->tnf!=NULL)
                *(dd->tnf) += *(dd1->tnf);
            }
          }
    }
  }
if (path1!=NULL)
  free(path1); path1=NULL;
return ret;
}



static void fprintdirtree0(FILE *fp,stack st,int spaces,int plusspaces,
     char spacechar, dirmask dm, dirkindmask dkm,int dlevel,int llevel,
     char inslines, char printdirdata)
     /* V datoteko fp zapise podatke o direktoriju, linku ali datoteki, ki so
     spravljeni na skladu st. Rekurzivno se izpisejo tudi podatki o
     poddirektorijih in podlinkih - glede na dostopne podatke in vrednosti
     dlevel in llevel.
       Spaces je stevilo presledkov, ki se izpisejo pred podatki o vsaki
     datoteki (direktoriju, linku...) na osnovnem nivoju, plusspaces je stevilo
     presledkov, ki se doda pri poddirektorijih in podlinkih, spacechar je znak,
     ki se pri tem uporablja namesto presledka, dm pove, katere lastnosti
     datotek, direktorijev itd. naj se izpisejo, dkm pove, o kaksnih vrstah
     datotek (direktoriji, linki, datoteke, ostalo, nedolocljivo) naj se
     izpisejo podatki, dlevel pove, do kaksne globine naj se izpisejo
     poddirektoriji in llevel, do kaksne globine naj se izpisejo podlinki
     (globina se steje za oboje neodvisno). inslines pove, ali naj se izpisejo
     prazne vrstice med poddirektoriji, printdirdata pa, ali naj se o vsakem
     direktoriju, poddirektoriju ali linku izpisejo pregledno podatki o dolzini
     in stevilu datotek. */
{
dirtype dd;
int i,k;
char *spacestr=NULL,fkind;
if (fp!=NULL)
{
  /* Tvori se niz presledkov: */
  spacestr=makestring(spaces);
  memset(spacestr,spacechar,spaces);
  spacestr[spaces]='\0';
  --dlevel;
  --llevel;
  /* Najprej se izpisejo vsi podatki o navadnih datotekah: */
  if (st!=NULL)
    if (st->n>0)
    {
      for (i=1;i<=st->n;++i)
      {
        dd=(dirtype) st->s[i];
        if (dd!=NULL)
        {
          /* Izpis posamezne stvari na skladu st: */
          fkind=kinddirentry(dd);
          if (fkind=='-')
          {
            if (dkm->file)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          }
        }
      }
    }
  /* Po navadnih datotekah se izpisejo direktoriji, linki itd.: */
  if (st!=NULL)
    if (st->n>0)
    {
      for (i=1;i<=st->n;++i)
      {
        dd=(dirtype) st->s[i];
        if (dd!=NULL)
        {
          /* Izpis posamezne stvari na skladu st: */
          fkind=kinddirentry(dd);
          if (fkind=='-')
          {
  
          } else if (0)
          {
            if (dkm->file)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          } else if (fkind=='d')
          {
            if (dkm->dir)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          } else if (fkind=='l')
          {
            if (dkm->link)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          } else if (fkind=='\0')
          {
            if (dkm->unknown)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          } else
          {
            if (dkm->rest)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          }
          /* Zapis podatkov o direktoriju: */
          if (kinddirentry(dd)=='d' && dlevel>0)
          {
            if ( (dd->dlength!=NULL || dd->tdlength!=NULL || dd->nf!=NULL ||
             dd->tnf!=NULL) && printdirdata && dkm->dir )
            {
  
              if (spaces>0)
                for (k=1;k<=spaces;++k)
                  fprintf(fp," ");
              if (plusspaces>0)
                for (k=1;k<=plusspaces;++k)
                  fprintf(fp," ");
              if (dd->relpath!=NULL)
                fprintf(fp,"%s\n",dd->relpath);
  
  
              if (spaces>0)
                for (k=1;k<=spaces;++k)
                  fprintf(fp," ");
              if (plusspaces>0)
                for (k=1;k<=plusspaces;++k)
                  fprintf(fp," ");
              if (dd->tdlength!=NULL)
                fprintf(fp,"Tdl=%li ",*(dd->tdlength));
              if (dd->dlength!=NULL)
                fprintf(fp,"Dl=%li ",*(dd->dlength));
              if (dd->tnf!=NULL)
                fprintf(fp,"Tnf=%li ",*(dd->tnf));
              if (dd->nf!=NULL)
                fprintf(fp,"Nf=%li ",*(dd->nf));
              fprintf(fp,"\n");
              /* $$$$ */
            }
            if (inslines) fprintf(fp,"\n");
            fprintdirtree0(fp,dd->cont,spaces+plusspaces,plusspaces,spacechar,dm,
             dkm,dlevel,llevel,inslines,printdirdata);
            if (inslines) fprintf(fp,"\n");
          }
          if (kinddirentry(dd)=='l' && llevel>0)
          {
            if ( (dd->dlength!=NULL || dd->tdlength!=NULL || dd->nf!=NULL ||
             dd->tnf!=NULL) && printdirdata && dkm->link )
            {
              if (spaces>0)
                for (k=1;k<=spaces;++k)
                  fprintf(fp," ");
              if (dd->tdlength!=NULL)
                fprintf(fp,"Tdl=%li ",*(dd->tdlength));
              if (dd->dlength!=NULL)
                fprintf(fp,"Dl=%li ",*(dd->dlength));
              if (dd->tnf!=NULL)
                fprintf(fp,"Tnf=%li ",*(dd->tnf));
              if (dd->nf!=NULL)
                fprintf(fp,"Nf=%li ",*(dd->nf));
              fprintf(fp,"\n");
            }
            if (inslines) fprintf(fp,"\n");
            fprintdirtree0(fp,dd->cont,spaces+plusspaces,plusspaces,spacechar,dm,
             dkm,dlevel,llevel,inslines,printdirdata);
            if (inslines) fprintf(fp,"\n");
          }
        }
      }
    }
  if (spacestr!=NULL)
    free(spacestr);
  }
}





/* Prejsnja verzija funkcije fprintdirtree0: */

static void fprintdirtree01(FILE *fp,stack st,int spaces,int plusspaces,
     char spacechar, dirmask dm, dirkindmask dkm,int dlevel,int llevel,
     char inslines, char printdirdata)
     /* V datoteko fp zapise podatke o direktoriju, linku ali datoteki, ki so
     spravljeni na skladu st. Rekurzivno se izpisejo tudi podatki o
     poddirektorijih in podlinkih - glede na dostopne podatke in vrednosti
     dlevel in llevel.
       Spaces je stevilo presledkov, ki se izpisejo pred podatki o vsaki
     datoteki (direktoriju, linku...) na osnovnem nivoju, plusspaces je stevilo
     presledkov, ki se doda pri poddirektorijih in podlinkih, spacechar je znak,
     ki se pri tem uporablja namesto presledka, dm pove, katere lastnosti
     datotek, direktorijev itd. naj se izpisejo, dkm pove, o kaksnih vrstah
     datotek (direktoriji, linki, datoteke, ostalo, nedolocljivo) naj se
     izpisejo podatki, dlevel pove, do kaksne globine naj se izpisejo
     poddirektoriji in llevel, do kaksne globine naj se izpisejo podlinki
     (globina se steje za oboje neodvisno). inslines pove, ali naj se izpisejo
     prazne vrstice med poddirektoriji, printdirdata pa, ali naj se o vsakem
     direktoriju, poddirektoriju ali linku izpisejo pregledno podatki o dolzini
     in stevilu datotek. */
{
dirtype dd;
int i,k;
char *spacestr=NULL,fkind;
if (fp!=NULL)
{
  /* Tvori se niz presledkov: */
  spacestr=makestring(spaces);
  memset(spacestr,spacechar,spaces);
  spacestr[spaces]='\0';
  --dlevel;
  --llevel;
  if (st!=NULL)
    if (st->n>0)
    {
      for (i=1;i<=st->n;++i)
      {
        dd=(dirtype) st->s[i];
        if (dd!=NULL)
        {
          /* Izpis posamezne stvari na skladu st: */
          fkind=kinddirentry(dd);
          if (fkind=='-')
          {
            if (dkm->file)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          } else if (fkind=='d')
          {
            if (dkm->dir)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          } else if (fkind=='l')
          {
            if (dkm->link)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          } else if (fkind=='\0')
          {
            if (dkm->unknown)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          } else
          {
            if (dkm->rest)
            {
              fprintf(fp,"%s",spacestr);
              fprintdirentry(fp,dd,dm);
              fprintf(fp,"\n");
            }
          }
          if (kinddirentry(dd)=='d' && dlevel>0)
          {
            if ( (dd->dlength!=NULL || dd->tdlength!=NULL || dd->nf!=NULL ||
             dd->tnf!=NULL) && printdirdata && dkm->dir )
            {
  
              if (spaces>0)
                for (k=1;k<=spaces;++k)
                  fprintf(fp," ");
              if (plusspaces>0)
                for (k=1;k<=plusspaces;++k)
                  fprintf(fp," ");
              if (dd->relpath!=NULL)
                fprintf(fp,"%s\n",dd->relpath);
  
  
              if (spaces>0)
                for (k=1;k<=spaces;++k)
                  fprintf(fp," ");
              if (plusspaces>0)
                for (k=1;k<=plusspaces;++k)
                  fprintf(fp," ");
              if (dd->tdlength!=NULL)
                fprintf(fp,"Tdl=%li ",*(dd->tdlength));
              if (dd->dlength!=NULL)
                fprintf(fp,"Dl=%li ",*(dd->dlength));
              if (dd->tnf!=NULL)
                fprintf(fp,"Tnf=%li ",*(dd->tnf));
              if (dd->nf!=NULL)
                fprintf(fp,"Nf=%li ",*(dd->nf));
              fprintf(fp,"\n");
              /* $$$$ */
            }
            if (inslines) fprintf(fp,"\n");
            fprintdirtree0(fp,dd->cont,spaces+plusspaces,plusspaces,spacechar,dm,
             dkm,dlevel,llevel,inslines,printdirdata);
            if (inslines) fprintf(fp,"\n");
          }
          if (kinddirentry(dd)=='l' && llevel>0)
          {
            if ( (dd->dlength!=NULL || dd->tdlength!=NULL || dd->nf!=NULL ||
             dd->tnf!=NULL) && printdirdata && dkm->link )
            {
              if (spaces>0)
                for (k=1;k<=spaces;++k)
                  fprintf(fp," ");
              if (dd->tdlength!=NULL)
                fprintf(fp,"Tdl=%li ",*(dd->tdlength));
              if (dd->dlength!=NULL)
                fprintf(fp,"Dl=%li ",*(dd->dlength));
              if (dd->tnf!=NULL)
                fprintf(fp,"Tnf=%li ",*(dd->tnf));
              if (dd->nf!=NULL)
                fprintf(fp,"Nf=%li ",*(dd->nf));
              fprintf(fp,"\n");
            }
            if (inslines) fprintf(fp,"\n");
            fprintdirtree0(fp,dd->cont,spaces+plusspaces,plusspaces,spacechar,dm,
             dkm,dlevel,llevel,inslines,printdirdata);
            if (inslines) fprintf(fp,"\n");
          }
        }
      }
    }
  if (spacestr!=NULL)
    free(spacestr);
  }
}






void fprintdirtree(FILE *fp,stack st,int spaces,int plusspaces,char spacechar,
     dirmask dm, dirkindmask dkm,int dlevel,int llevel,char inslines,
     char printdirdata,char printhead)
     /* Naredi podobno kot fprintdirtree0, le da v primeru, ko so na skladu st
     podatki o direktoriju ali linku, na koncu pregledno izpise podatke o skupni
     dolzini in stevilu datotek, ce je printhead razlicen od 0 (Funkcija
     fprintdirtree0 maredi to le za podnivoje). */
{
dirtype dd;
int i;
char doit=0;
long dlength=0,tdlength=0,nf=0,tnf=0;
if (fp!=NULL)
{
  fprintdirtree0(fp,st,spaces,plusspaces,spacechar,dm,dkm,dlevel,llevel,inslines,
                 printdirdata);
  if (printhead)
  {
    if (st!=NULL)
      if (st->n>0)
      {
        /* Ce je na skladu vsaj en element, je se vedno treba ugotoviti, ali je
        smiselno zapisati glavo za direktorij: */
        dd=st->s[1];
        doit=0;
        if (st->n>1)
          doit=1;
        else if (dd!=NULL)
          if (kinddirentry(dd)=='d' || kinddirentry(dd)=='l')
            doit=1;
        if (doit)
        {
          for (i=1;i<=st->n; ++i)
          {
            dd=st->s[i];
            ++nf;
            ++tnf;
            if (dd->tnf!=NULL)
              tnf+=*(dd->tnf);
            if (dd->tdlength!=NULL)
            {
              tdlength+=*(dd->tdlength);
            }
            if (dd->length!=NULL)
            {
              dlength+=*(dd->length);
              tdlength+=*(dd->length);
            }
          }
          fprintf(fp,"================================\n");
          fprintf(fp,"Total number of files: %9li\n",tnf);
          fprintf(fp,"Number of files:       %9li\n",nf);
          fprintf(fp,"Total length:          %9li\n",tdlength);
          fprintf(fp,"Directory length:      %9li\n",dlength);
        }
      }
  }
  }
}






/* VISJE FUNKCIJE, NAMENJENE ZA UPORABO V PROGRAMIH */





int flistdirectory(FILE *fp,char *path,dircom dc)
    /* Zapise vsebino direktorija path (ali podatke o datoteki, ce je path ime
    datoteke) glede na vrednosti polj *dc. Ce je fp razlicna od NULL, se podatki
    zapisejo v datoteko fp (dc->fp se pri tem ne spremeni), ce pa je fp enaka
    NULL, se podatki zapisejo v datoteko dc->fp. */
{
stack dir;
int i;
FILE *fpref=NULL;
if (dc==NULL || path==NULL)
  return -1;
if (fp!=NULL)
{
  fpref=dc->fp;
  dc->fp=fp;
} else if (dc->fp==NULL)
  return -1;
dir=dirdatatree(path,dc->dm,dc->dlevel,dc->llevel);
fprintdirtree(dc->fp,dir,dc->spaces,dc->plusspaces,dc->spacechar,dc->dm,
       dc->dkm,dc->pdlevel,dc->pllevel,dc->inslines,
       dc->printdirdata,dc->printhead);
if (dir!=NULL)
{
  if (dir->n>0)
    for (i=1; i<=dir->n; ++i)
      dispdirtree( (dirtype *) &(dir->s[i]));
  dispstack(&dir);
}
if (fpref!=NULL)
  dc->fp=fpref;
return 0;
}




stack stringparamlistsimp(char *paramstr)
      /* Vrne sklad, na katerega nalozi parametre (v obliki nizov), ki jih
      izlusci iz niza paramstr. Kot locila med posameznimi parametri uposteva
      znake ' ', '\n' in '\r'. */
{
stack ret=NULL;
char *parameter=NULL,*p1=NULL,*p2=NULL,end=0;
if (paramstr!=NULL)
  if (strlen(paramstr)>0)
  {
    ret=newstack(4);
    p1=paramstr;
    while (!end)
    {
      p2=memnotnchr(p1,strlen(p1)," \n\r",3);
      if (p2==NULL)
        end=1;
      else
      {
        p1=memnchr(p2,strlen(p2)," \n\r",3);
        if (p1==NULL)
        {
          end=1;
          p1=p2+strlen(p2);
        }
        pushstack(ret, (void *) stringncopy(p2,p1-p2));
      }
    }
  }
return ret;
}












/* Pri tej funkciji dodaj se stvari za dc->dm in za dc->dkm! */




int setdiroption(dircom dc,char *opt)
    /* V ukazni strukturi za zajemanje in izpis podatkov o direktorijih in
    datotekah dc nastavi nastavitev, ki jo veleva niz opt. Dogovori so
    naslednji:
      Opcije, ki imajo dve moznosti, se nastavijo z nizom, ki se zacne s '+' za
    nastavitev oziroma z '-' za umaknitev opcije. Preostali del niza je
    dogovorjeno ime doticne opcije in sicer:
        "inslines" - vrivanje praznih vrstic med poddirektoriji
        "printdirdata" - izpis skup. dolzine in st. datotek pri direktorijih
        "printhead" - izpis splosnih podatkov o direktoriju (osnov. nivo)
        "ms" - sharanitev niza, ki ga generiria ukaz ll
        "mn" - shranitev imena
        "mlk" - shranitev linka
        "mo" - shranitev lastnika
        "mg" - shranitev skupine
        "mp" - shranitev dovoljenj
        "ml" - shranitev dolzine dat.
        "mnlk" - shranitev stevila linkov
        "md" - shranitev datuma
        "mc" - shranitev vsebine poddirektorijev
        "ps" - sharanitev niza, ki ga generiria ukaz ll
        "pn" - izpis imena
        "plk" - izpis linka
        "po" - izpis lastnika
        "pg" - izpis skupine
        "pp" - izpis dovoljenj
        "pl" - izpis dolzine dat.
        "pnlk" - izpis stevila linkov
        "pd" - izpis datuma
        "pc" - izpis vsebine poddirektorijev
        "kmf" - izpis datotek
        "kmd" - izpis direktorijev
        "kml" - izpis linkov
        "kmu" - izpis datotek neznane vrste
        "kmr" - izpis ostalih vrst datotek
      Opcije, ki imajo stevilcno ali znakovno vrednost, so sestavljeni iz niza
    za identifikacijo opcije in iz znaka oziroma stevilcne vrednosti.
    Identifikacijski nizi so:
        "sc" - znak, ki se uporablja kot presledek pri zamikanju
        "s+" - stevilo dodatnih presledkov pri zamikih
        "s" - zacetno stevilo presledkov
        "dl" - nivo, do katerega se shranejo podatki o poddirektorijih
        "ll" - nivo, do katerega se shranejo podatki o podlinkih
        "pdl" - nivo, do katerega se izpisejo podatki o poddirektorijih
        "pll" - nivo, do katerega se izpisejo podatki o podlinkih
    */
{
int ret=0;
if (dc!=NULL)
{
  if (opt!=NULL)
  {
    if (opt[0]=='+' || opt[0]=='-')
    {
    /* Opcije, ki so lahko ali vkljucene ali izkljucene */
      if (cmpstrings(opt+1,"inslines")==0)
      {
        /* Vrivanje vrstic med izpisi poddirektorijev */
        if (opt[0]=='+')
          dc->inslines=1;
        else
          dc->inslines=0;
      } else if (cmpstrings(opt+1,"printdirdata")==0)
      {
        /* Izpisovanje sestetih podatkov o direktorijih */
        if (opt[0]=='+')
          dc->printdirdata=1;
        else dc->printdirdata=0;
      } else if (cmpstrings(opt+1,"printhead")==0)
      {
        /* Izpisovanje glave za osnovni direktorij */
        if (opt[0]=='+')
          dc->printhead=1;
        else dc->printhead=0;
      } else if (cmpstrings(opt+1,"ms")==0)
      /* MASKE ZA TO, KAJ NAJ SE SHRANI */
      {
        /* Maska za shranitev niza, dobljenega pri unixovem ukazu ll -a */
        if (dc->dm!=NULL)
        {
          if (opt[0]=='+')
            dc->dm->str=1;
          else dc->dm->str=0;
        }
      } else if (cmpstrings(opt+1,"mn")==0)
      {
        /* Maska za shranitev imena */
        if (dc->dm!=NULL)
        {
          if (opt[0]=='+')
            dc->dm->name=1;
          else dc->dm->name=0;
        }
      }  else if (cmpstrings(opt+1,"mlk")==0)
      {
        /* Maska za shranitev linka */
        if (dc->dm!=NULL)
        {
          if (opt[0]=='+')
            dc->dm->link=1;
          else dc->dm->link=0;
        }
      } else if (cmpstrings(opt+1,"mo")==0)
      {
        /* Maska za shranitev lastnika */
        if (dc->dm!=NULL)
        {
          if (opt[0]=='+')
            dc->dm->own=1;
          else dc->dm->own=0;
        }
      } else if (cmpstrings(opt+1,"mg")==0)
      {
        /* Maska za shranitev skupine */
        if (dc->dm!=NULL)
        {
          if (opt[0]=='+')
            dc->dm->grp=1;
          else dc->dm->grp=0;
        }
      } else if (cmpstrings(opt+1,"mp")==0)
      {
        /* Maska za shranitev dovoljenj */
        if (dc->dm!=NULL)
        {
          if (opt[0]=='+')
            dc->dm->permit=1;
          else dc->dm->permit=0;
        }
      } else if (cmpstrings(opt+1,"ml")==0)
      {
        /* Maska za shranitev dolzine datoteke */
        if (dc->dm!=NULL)
        {
          if (opt[0]=='+')
            dc->dm->length=1;
          else dc->dm->length=0;
        }
      } else if (cmpstrings(opt+1,"mnlk")==0)
      {
        /* Maska za shranitev stevila linkov */
        if (dc->dm!=NULL)
        {
          if (opt[0]=='+')
            dc->dm->nlinks=1;
          else dc->dm->nlinks=0;
        }
      }  else if (cmpstrings(opt+1,"md")==0)
      {
        /* Maska za shranitev datuma */
        if (dc->dm!=NULL)
        {
          if (opt[0]=='+')
            dc->dm->date=1;
          else dc->dm->date=0;
        }
      } else if (cmpstrings(opt+1,"mc")==0)
      {
        /* Maska za poddirektorije */
        if (dc->dm!=NULL)
        {
          if (opt[0]=='+')
            dc->dm->cont=1;
          else dc->dm->cont=0;
        }
      } else if (cmpstrings(opt+1,"ps")==0)
      /* MASKE ZA TO, KAJ NAJ SE IZPISE */
      {
        /* Maska za izpis niza, dobljenega pri unixovem ukazu ll -a */
        if (dc->pdm!=NULL)
        {
          if (opt[0]=='+')
            dc->pdm->str=1;
          else dc->pdm->str=0;
        }
      } else if (cmpstrings(opt+1,"pn")==0)
      {
        /* Maska za izpis imena */
        if (dc->pdm!=NULL)
        {
          if (opt[0]=='+')
            dc->pdm->name=1;
          else dc->pdm->name=0;
        }
      }  else if (cmpstrings(opt+1,"plk")==0)
      {
        /* Maska za izpis linka */
        if (dc->pdm!=NULL)
        {
          if (opt[0]=='+')
            dc->pdm->link=1;
          else dc->pdm->link=0;
        }
      } else if (cmpstrings(opt+1,"po")==0)
      {
        /* Maska za izpis lastnika */
        if (dc->pdm!=NULL)
        {
          if (opt[0]=='+')
            dc->pdm->own=1;
          else dc->pdm->own=0;
        }
      } else if (cmpstrings(opt+1,"pg")==0)
      {
        /* Maska za izpis skupine */
        if (dc->pdm!=NULL)
        {
          if (opt[0]=='+')
            dc->pdm->grp=1;
          else dc->pdm->grp=0;
        }
      } else if (cmpstrings(opt+1,"pp")==0)
      {
        /* Maska za izpis dovoljenj */
        if (dc->pdm!=NULL)
        {
          if (opt[0]=='+')
            dc->pdm->permit=1;
          else dc->pdm->permit=0;
        }
      } else if (cmpstrings(opt+1,"pl")==0)
      {
        /* Maska za izpis dolzine datoteke */
        if (dc->pdm!=NULL)
        {
          if (opt[0]=='+')
            dc->pdm->length=1;
          else dc->pdm->length=0;
        }
      } else if (cmpstrings(opt+1,"pnlk")==0)
      {
        /* Maska za izpis stevila linkov */
        if (dc->pdm!=NULL)
        {
          if (opt[0]=='+')
            dc->pdm->nlinks=1;
          else dc->pdm->nlinks=0;
        }
      }  else if (cmpstrings(opt+1,"pd")==0)
      {
        /* Maska za izpis datuma */
        if (dc->pdm!=NULL)
        {
          if (opt[0]=='+')
            dc->pdm->date=1;
          else dc->pdm->date=0;
        }
      } else if (cmpstrings(opt+1,"pc")==0)
      {
        /* Maska za poddirektorije */
        if (dc->pdm!=NULL)
        {
          if (opt[0]=='+')
            dc->pdm->cont=1;
          else dc->pdm->cont=0;
        }
      } else if (cmpstrings(opt+1,"kmf")==0)
      {
        /* Maska za izpis dattek */
        if (dc->dkm!=NULL)
        {
          if (opt[0]=='+')
            dc->dkm->file=1;
          else dc->dkm->file=0;
        }
      } else if (cmpstrings(opt+1,"kmd")==0)
      {
        /* Maska za izpis direktorijev */
        if (dc->dkm!=NULL)
        {
          if (opt[0]=='+')
            dc->dkm->dir=1;
          else dc->dkm->dir=0;
        }
      } else if (cmpstrings(opt+1,"kml")==0)
      {
        /* Maska za izpis linkov */
        if (dc->dkm!=NULL)
        {
          if (opt[0]=='+')
            dc->dkm->link=1;
          else dc->dkm->link=0;
        }
      } else if (cmpstrings(opt+1,"kmu")==0)
      {
        /* Maska za izpis datotek neznane vrste */
        if (dc->dkm!=NULL)
        {
          if (opt[0]=='+')
            dc->dkm->unknown=1;
          else dc->dkm->unknown=0;
        }
      } else if (cmpstrings(opt+1,"kmr")==0)
      {
        /* Maska izpis ostalih vrst datotek */
        if (dc->dkm!=NULL)
        {
          if (opt[0]=='+')
            dc->dkm->rest=1;
          else dc->dkm->rest=0;
        }
      } else
        ret=-2;
    } else
    {
      if (opt[0]=='s' && opt[1]=='c')
      {
        /* Znak, ki se uporablja kot presledek pri zamikanju */
        if (opt[2]=='\0')
          dc->spacechar=' ';
        else dc->spacechar=opt[2];
      } else if (opt[0]=='s' && opt[1]=='+')
      {
         /* Stevilo  presledkov pri zamikanju poddirektorijev */
         dc->plusspaces=atol(opt+2);
      } else if (opt[0]=='s')
      {
        /* Zacetno stevilo presledkov pri zamikanju poddirektorijev */
        dc->spaces=atol(opt+1);
      } else if (opt[0]=='d' && opt[2]=='l')
      {
        /* Nivo, do katerega se naredijo poddrevesa za direktorije */
        dc->dlevel=atol(opt+2);
      } else if (opt[0]=='l' && opt[2]=='l')
      {
        /* Nivo, do katerega se naredijo poddrevesa za linke */
        dc->llevel=atol(opt+2);
      } else if (opt[0]=='p' && opt[1]=='d' && strlen(opt)>2)
      {
        if (opt[2]=='l')
        {
          /* Nivo, do katereg se izpisujejo poddirektoriji */
          dc->pdlevel=atol(opt+3);
        } else
          ret=-2;
      } else if (opt[0]=='p' && opt[1]=='l' && strlen(opt)>2)
      {
        if (opt[2]=='l')
        {
          /* Nivo, do katereg se izpisujejo podlinki */
          dc->pllevel=atol(opt+3);
        } else
          ret=-2;
      } else
        ret=-2;
    }
  } else
    ret=-1;
} else
  ret=-1;
return ret;
}



void fcomlistdir(FILE *fp,char *command,dircom dc,stack *dir)
     /* V datoteko fp izpise podatke o datoteki oz. direktoriju - glede na
     vrednosti spremenljivk command, dc in dir.
       1. del niza command je ime direktorija oz. datoteke, drugi del pa so
     lahko opcije, prepoznavne za funkcijo setdiroption(). Deli tega niza so
     lahko med seboj loceni z locili ' ', '\n' ali '\r'. Poleg tega obstaja
     se nekaj posebnih primerov za ta niz. Ce je 1. del niza ">", potem se ne
     iscejo novi podatki za datoteko oz. direktorij s tem imenom, temvec se
     vzamejo podatki, ki so ze spravljeni na skladu *dir, s tem da se upostevajo
     morebitne dodatne opcije v nadaljevanju niza commmand.
       podatki na skladu *dir se vsakic zbrisejo na zacetku funkcije, razen, ce
     je 1. del niza command enak ">". Po izpisu podatkov pa se podatki na *dir
     ne brisejo, tako da so dostopni za morebitno naslednjo izvrsitev te
     funkcije s 1. delom niza command enakim "<".
       Spremenljivka dc pove, na kaksen nacin naj se zajamejo in izpisejo
     podatki. Ce so v nizu command kaksne todatne opcije, se njihov efekt cuti
     le med izvajanjem te funkcije, po izvedbi pa ostane *dc nespremenjen. */
{
stack param=NULL;
dircom dc1=NULL;
char *path=0,*p;
int i;
char lookoptions=0,maketree=0,printtree=0;
if (fp!=NULL)
{
  param=stringparamlistsimp(command);
  /* dc se skopira v dc1, ker v tej funkciji opcije ne smejo imeti efekta na
  originalen dc: */
  dc1=copydircom(dc);
  if (dc1==NULL)
    dc1=newdircom();
  if (fp!=NULL)
    dc1->fp=fp;
  if (param!=NULL)
  {
    if (param->n>0)
    {
      path=stringcopy(param->s[1]);
      if (path!=NULL)
      {
        if (cmpstrings(path,"?")==0)
        {
          /* Zahteva za izpis pomoci */
          lookoptions=0;
          maketree=0;
          printtree=0;
        } else if (cmpstrings(path,">")==0)
        {
          /* Izpise se drektorij, ki je se v prejsnjem dir */
          lookoptions=1;
          maketree=0;
          printtree=1;
        } else
        {
          lookoptions=1;
          maketree=1;
          printtree=1;
        }
        if (lookoptions)
        {
          if (param->n>1)
            for (i=2; i<=param->n; ++i)
            {
              p=(char*) param->s[i];
              setdiroption(dc1,p);
            }
          consistentdircom(dc);
        }
        if (maketree)
        {
          if (*dir!=NULL)
          {
            if ((*dir)->n>0)
              for (i=1; i<=(*dir)->n;++i)
                if ((*dir)->s[i]!=NULL)
                  dispdirtree( (dirtype *) &((*dir)->s[i]) );
            dispstack(dir);
          }
          *dir=dirdatatree(path,dc1->dm,dc1->dlevel,dc1->llevel);
        }
        if (printtree)
        {
          fprintdirtree(dc1->fp,*dir,dc1->spaces,dc1->plusspaces,dc1->spacechar,
               dc1->pdm,dc1->dkm,dc1->dlevel,dc1->llevel,dc1->inslines,
               dc1->printdirdata,dc1->printhead);
        }
      }
    }
    dispstackval(param);
    dispstack(&param);
  }
  if (dc1!=NULL)
    dispdircom(&dc1);
  if (path!=NULL)
    free(path);
}
}




void dirsettings(dircom dc)
     /* Nastavitveukazne spremenljivke za zajem in izpis podatkov o direktorijih
     oz. datotekah prek terminala. */
{
long l;
char c;
if (dc!=NULL)
{
  printf("Znak za presledke: ");
  scanf("%c",&(dc->spacechar));
  scanf("%c",&c);
  printf("Stevilo nivojev za poddirektorije: ");
  l=dc->dlevel;
  readlong(&l); dc->dlevel=l;
  printf("Stevilo nivojev za podlinke: ");
  l=dc->llevel;
  readlong(&l); dc->llevel=l;
  printf("Stevilo nivojev za izpis poddirektorijev: ");
  l=dc->dlevel;
  readlong(&l); dc->dlevel=l;
  printf("Stevilo nivojev za izpis podlinkov: ");
  l=dc->llevel;
  readlong(&l); dc->llevel=l;
  printf("Zacetno stevilo presledkov: ");
  l=dc->spaces=l;
  readlong(&l); dc->spaces=l;
  printf("St. presledkov pri zamiku: ");
  l=dc->plusspaces;
  readlong(&l); dc->plusspaces=l;
  printf("Izpis glave (0/1)? ");
  l=dc->printhead;
  readlong(&l); dc->printhead=(char) l;
  printf("Izpis podatkov o direktorijih (0/1)? ");
  l=dc->printdirdata;
  readlong(&l); dc->printdirdata=(char) l;
  printf("Prazne vrstice med direktoriji (0/1)? ");
  l=dc->printdirdata;
  readlong(&l); dc->printdirdata=(char) l;
  printf("KATERI PODATKI NAJ SE SHRANIJO:\n");
  printf("Vrstice, ki jih izpise ukaz ll (0/1)? ");
  l=dc->dm->str;
  readlong(&l); dc->dm->str=(char) l;
  printf("Imena datotek (0/1)? ");
  l=dc->dm->name;
  readlong(&l); dc->dm->name=(char) l;
  printf("Linki (0/1)? ");
  l=dc->dm->nlinks;
  readlong(&l); dc->dm->nlinks=(char) l;
  printf("Lastniki (0/1)? ");
  l=dc->dm->own;
  readlong(&l); dc->dm->own=(char) l;
  printf("Skupine (0/1)? ");
  l=dc->dm->grp;
  readlong(&l); dc->dm->grp=(char) l;
  printf("Dovoljenja (0/1)? ");
  l=dc->dm->permit;
  readlong(&l); dc->dm->permit=(char) l;
  printf("Dolzine dat. (0/1)? ");
  l=dc->dm->length;
  readlong(&l); dc->dm->length=(char) l;
  printf("St. linkov (0/1)? ");
  l=dc->dm->nlinks;
  readlong(&l); dc->dm->nlinks=(char) l;
  printf("Datumi (0/1)? ");
  l=dc->dm->date;
  readlong(&l); dc->dm->date=(char) l;
  printf("Vsebina poddirektorijev (0/1)? ");
  l=dc->dm->cont;
  readlong(&l); dc->dm->cont=(char) l;
  printf("KATERI PODATKI NAJ SE IZPISEJO:\n");
  printf("Vrstice, ki jih izpise ukaz ll (0/1)? ");
  l=dc->pdm->str;
  readlong(&l); dc->pdm->str=(char) l;
  printf("Imena datotek (0/1)? ");
  l=dc->pdm->name;
  readlong(&l); dc->pdm->name=(char) l;
  printf("Linki (0/1)? ");
  l=dc->pdm->nlinks;
  readlong(&l); dc->pdm->nlinks=(char) l;
  printf("Lastniki (0/1)? ");
  l=dc->pdm->own;
  readlong(&l); dc->pdm->own=(char) l;
  printf("Skupine (0/1)? ");
  l=dc->pdm->grp;
  readlong(&l); dc->pdm->grp=(char) l;
  printf("Dovoljenja (0/1)? ");
  l=dc->pdm->permit;
  readlong(&l); dc->pdm->permit=(char) l;
  printf("Dolzine dat. (0/1)? ");
  l= dc->pdm->length;
  readlong(&l); dc->pdm->length=(char) l;
  printf("St. linkov (0/1)? ");
  l=dc->pdm->nlinks;
  readlong(&l); dc->pdm->nlinks=(char) l;
  printf("Datumi (0/1)? ");
  l=dc->pdm->date;
  readlong(&l); dc->pdm->date=(char) l;
  printf("Vsebina poddirektorijev (0/1)? ");
  l=dc->pdm->cont;
  readlong(&l); dc->pdm->cont=(char) l;
  printf("KATERE VRSTE DATOTEK NAJ SE IZPISEJO:\n");
  printf("Datoteke (0/1)? ");
  l=dc->dkm->file;
  readlong(&l); dc->dkm->file=(char) l;
  printf("Direktoriji (0/1)? ");
  l=dc->dkm->dir;
  readlong(&l); dc->dkm->dir=(char) l;
  printf("Linki (0/1)? ");
  l=dc->dkm->link;
  readlong(&l); dc->dkm->link=(char) l;
  printf("Ostalo (0/1)? ");
  l=dc->dkm->rest;
  readlong(&l); dc->dkm->rest=(char) l;
  printf("Nedefinirano (0/1)? ");
  l=dc->dkm->unknown;
  readlong(&l); dc->dkm->unknown=(char) l;
}
consistentdircom(dc);
}








void fprintdirsettings(FILE *fp,dircom dc)
     /* V datoteko fp zapise vse nastavitve za prikazovanje direktorijev iz dc
     in sicer v obliki, v kakrsni so posamezne nastavitve berljive za funkcijo
     setdiroption(). */
{
if (fp!=NULL)
{
  if (dc!=NULL)
  {
    if (dc->inslines)
      fprintf(fp," +inslines ");
    else
      fprintf(fp," -inslines ");
    if (dc->printdirdata)
      fprintf(fp," +printdirdata ");
    else
      fprintf(fp," -printdirdata ");
    if (dc->printhead)
      fprintf(fp," +printhead ");
    else
      fprintf(fp," -printhead ");
    if (dc->dm!=NULL)
    {
      if (dc->dm->str)
        fprintf(fp," +ms ");
      else
        fprintf(fp," -ms ");
      if (dc->dm->name)
        fprintf(fp," +mn ");
      else
        fprintf(fp," -mn ");
      if (dc->dm->link)
        fprintf(fp," +mlk ");
      else
        fprintf(fp," -mlk ");
      if (dc->dm->own)
        fprintf(fp," +mo ");
      else
        fprintf(fp," -mo ");
      if (dc->dm->grp)
        fprintf(fp," +mg ");
      else
        fprintf(fp," -mg ");
      if (dc->dm->permit)
        fprintf(fp," +mp ");
      else
        fprintf(fp," -mp ");
      if (dc->dm->length)
        fprintf(fp," +ml ");
      else
        fprintf(fp," -ml ");
      if (dc->dm->nlinks)
        fprintf(fp," +mnlk ");
      else
        fprintf(fp," -mnlk ");
      if (dc->dm->date)
        fprintf(fp," +md ");
      else
        fprintf(fp," -md ");
      if (dc->dm->cont)
        fprintf(fp," +mc ");
      else
        fprintf(fp," -mc ");
    }
    if (dc->pdm!=NULL)
    {
      if (dc->pdm->str)
        fprintf(fp," +ps ");
      else
        fprintf(fp," -ps ");
      if (dc->pdm->name)
        fprintf(fp," +pn ");
      else
        fprintf(fp," -pn ");
      if (dc->pdm->link)
        fprintf(fp," +plk ");
      else
        fprintf(fp," -plk ");
      if (dc->pdm->own)
        fprintf(fp," +po ");
      else
        fprintf(fp," -po ");
      if (dc->pdm->grp)
        fprintf(fp," +pg ");
      else
        fprintf(fp," -pg ");
      if (dc->pdm->permit)
        fprintf(fp," +pp ");
      else
        fprintf(fp," -pp ");
      if (dc->pdm->length)
        fprintf(fp," +pl ");
      else
        fprintf(fp," -pl ");
      if (dc->pdm->nlinks)
        fprintf(fp," +pnlk ");
      else
        fprintf(fp," -pnlk ");
      if (dc->pdm->date)
        fprintf(fp," +pd ");
      else
        fprintf(fp," -pd ");
      if (dc->pdm->cont)
        fprintf(fp," +pc ");
      else
        fprintf(fp," -pc ");
    }
    if (dc->dkm!=NULL)
    {
      if (dc->dkm->file)
        fprintf(fp," +kmf ");
      else
        fprintf(fp," -kmf ");
      if (dc->dkm->dir)
        fprintf(fp," +kmd ");
      else
        fprintf(fp," -kmd ");
      if (dc->dkm->link)
        fprintf(fp," +kml ");
      else
        fprintf(fp," -kml ");
      if (dc->dkm->unknown)
        fprintf(fp," +kmu ");
      else
        fprintf(fp," -kmu ");
      if (dc->dkm->rest)
        fprintf(fp," +kmr ");
      else
        fprintf(fp," -kmr ");
    }
    fprintf(fp," sc%c ",dc->spacechar);
    fprintf(fp," s+%i ",dc->plusspaces);
    fprintf(fp," s%i ",dc->spaces);
    fprintf(fp," dl%i ",dc->dlevel);
    fprintf(fp," ll%i ",dc->llevel);
    fprintf(fp," pdl%i ",dc->pdlevel);
    fprintf(fp," pll%i ",dc->pllevel);
  }
}
}





/* FUNKCIJE ZA UPORABO V INVAN-U: */


static char *dircommand(char *path,char *filename)
    /* Vrne sistemski ukaz, ki na danem sistemu izpise vsebino direktorija
    z imenom path v datoteko z imenom filename. Niz, ki ga funkcija vrne, je
    treba po uporabi brisati.
    $A Igor okt99; */
{
char *com=NULL,*com1=NULL;
#ifdef UNIX
  com="ls -a -l ";
#endif
#ifdef DOSWN
  com="dir ";
#endif
com=stringcat(com,path);
com1=stringcat(com," > "); free(com);
com=stringcat(com1,filename); free(com1);
return com;
}

static char testdirentry(char *entry)
    /* Vrne 0, ce niz entry ne more predstavljati opisa direktorija ali
    datoteke, drugace vrne 1.
    $A Igor okt99; */
{
char ret=1;
#ifdef DOSWN
  if (entry==NULL)
    ret=0;
  else if (strlen(entry)<30)
    ret=0;
  else if (entry[0]==' ' || entry[0]=='\n' || entry[0]=='\r')
    ret=0;
  else if (entry[0]=='V' && (entry[1]=='O' || entry[1]=='o') )
    ret=0;
#endif
#ifdef UNIX
  if (entry==NULL)
    ret=0;
  else if (strlen(entry)<30)
    ret=0;
  else if (entry[0]==' ' || entry[0]=='\n' || entry[0]=='\r')
    ret=0;
#endif
return ret;
}

static stack getlinedirdata(char *path)
    /* Vrne sklad, na katerega da podatke v obliki nizov datotekah, ki so
    vsebovane v direktoriju path. Funkcija zapise le nize, s katerimi sistem
    opise datoteko pri klicu ustreznega ukaza ('ls -a -l ' za Unix oz. 'dir '
    za DOS). Sklad, ki ga funkcija vrne, je vedno razlicen od NULL (lahko pa
    je prazen).
    $A Igor okt99; */
{
char *com=NULL,*line=NULL,*tempfile=NULL;
FILE *fp;
stack st=NULL;
int buflength=500; /* maksimalna dolzina vrstice */
st=newstack(5);
tempfile= (char *) makestring(256);
tempfile=tmpnam(tempfile);
if (strlen(tempfile)<=0)
  printf("ERROR IN directory0(): Can't create unique file name\n");
/* printf("tempfile: %s\n",tempfile); */
/* Podatki se s pomocjo Unixovega ukaza 'll -a' najprej zapisejo v datoteko z
imenom tempfile: */
com=dircommand(path,tempfile);
system(com);
disppointer((void **) &com);
/* Branje podatkov iz datoteke z imenom tempfile: */
fp=fopen(tempfile,"rb");
if (fp==NULL)
{
  errfunc0("getlinedirdata");
  fprintf(erf(),"Can not create unique file name\n.\n");
  errfunc2();
}
line= (char *) makestring(buflength);
while (!feof(fp))
{
  fgets(line,buflength,fp);
  if ( testdirentry(line) && (!feof(fp)) )
    pushstack(st,stringcopy(line));
  line[0]='\0';
}
if (line!=NULL)
  free(line);
line=NULL;
fclose(fp);
if (tempfile!=NULL)
{
  remove(tempfile);
  free(tempfile);
}
return st;
}


static stack decomposedirentry(char *entry)
    /* Vrstico s podatki o datoteki oz. direktoriju, ki jo generira sistemski
    ukaz, razstavi na posamezne dele in vrne sklad, na katerem so nalozeni ti
    deli kot nizi.
    Funkcija vedno vrne sklad, ki je razlicen od NULL (lahko pa je prazen).
    $A Igor okt99; */
{
stack ret;
char *current=NULL,*end=NULL;
ret=newstack(10);
current=entry;
if (current!=NULL)
  current=memnotnchr(current,strlen(current)," \n\r\0",4);
while(current!=NULL)
{
  end=memnchr(current,strlen(current)+1," \n\r\0",4);
  if (end==NULL)
    current=NULL;
  else if (end==current)
    current=NULL;
  else
  {
    /* Kopijo naslednjega dela potisnemo na sklad: */
    pushstack(ret,stringncopy(current,end-current));
    current=memnotnchr(end,strlen(end)," \n\r\0",4);
  }
}
return ret;
}

static char *extractdirentryname(char *entry)
    /* Iz niza, ki predstavlja podatke o datoteki in je rezultat sistemskega
    ukaza za izpis podatkov o datotekah, izvlece ime datoteke (tipicno je to
    zadnji del niza) in ga vrne.
    $A Igor okt99; */
{
char *ret=NULL;
stack decst;
decst=decomposedirentry(entry);
ret=popstack(decst);
dispstackval(decst);
dispstack(&decst);
return ret;
}


static stack decomposedirdata(stack linedirdata)
    /* Vrne sklad, na katerem so skladi z dekompozicijami nizov na skladu
    linedirdata. Na tem skladu naj bi bili v obliki nizov nalozeni podatki o
    datotekah, kot jih generira ustrezen sistemski ukaz. Za dekompozicijo se
    uporabi funkcija decomposedirentry.
    Funkcija vedno vrne sklad, ki je razlicen od NULL in tudi skladi, ki so
    nanj nalozeni, so vsi razlicni od NULL (lahko pa so prazni).
    $A Igor okt99; */
{
int i;
stack ret=NULL;
if (linedirdata!=NULL)
{
  ret=newstack(linedirdata->n+1);
  for (i=1;i<=linedirdata->n;++i)
  {
    pushstack(ret,decomposedirentry(linedirdata->s[i]));
  }
} else ret=newstack(1);
return ret;
}


static stack extractdirdatanames(stack linedirdata)
    /* Vrne sklad, na katerem so imena datotek iz nizov na skladu
    linedirdata. Na tem skladu naj bi bili v obliki nizov nalozeni podatki o
    datotekah, kot jih generira ustrezen sistemski ukaz. Za ekstrakcijo se
    uporabi funkcija extractdirentryname.
    Funkcija vedno vrne sklad, ki je razlicen od NULL.
    $A Igor okt99; */
{
int i;
stack ret=NULL;
if (linedirdata!=NULL)
{
  ret=newstack(linedirdata->n+1);
  for (i=1;i<=linedirdata->n;++i)
  {
    pushstack(ret,extractdirentryname(linedirdata->s[i]));
  }
} else ret=newstack(1);
return ret;
}



stack getdecomposeddirdata(char *path)
    /*  Vrne sklad, na katerem so skladi z dekompozicijami nizov s podatki
    o datotekah v direktoriju path, kot jih generira ustrezen sistemski ukaz.
    Za zajem sistemskih podatkov se uporabi funkcija getlinedirdata, za njihovo
    dekompozicijo pa funkcija decomposedirdata.
    Funkcija vedno vrne sklad, ki je razlicen od NULL in tudi skladi, ki so
    nanj nalozeni, so vsi razlicni od NULL (lahko pa so prazni).
    $A Igor okt99; */
{
stack linest,retst;
linest=getlinedirdata(path);
retst=decomposedirdata(linest);
dispstackval(linest);
dispstack(&linest);
return retst;
}

stack getdirdatanames(char *path)
    /* Vrne sklad, na katerem so imena datotek iz nizov s podatki o datotekah
    v direktoriju path, kot jih generira ustrezen sistemski ukaz. Za zajem
    sistemskih podatkov se uporabi funkcija getlinedirdata, za njihovo
    dekompozicijo pa funkcija decomposedirdata.
    Funkcija vedno vrne sklad, ki je razlicen od NULL.
    $A Igor okt99; */
{
stack linest,retst;
linest=getlinedirdata(path);
retst=extractdirdatanames(linest);
dispstackval(linest);
dispstack(&linest);
return retst;
}



static char *getpwdstringunix(void)
     /* Vrne niz, ki predstavlja tekoci direktorij, za UNIX. Vrnjeni niz je
     potrebno po uporabi brisati.
     $A Igor okt99; */
{
int buflength=200;
char *ret=NULL,*buf=NULL,*tmp=NULL,*filename=NULL;
FILE *fp;
filename=tmpnam(filename);
buf=makestring(buflength);
tmp=stringcat("pwd > ",filename);
system(tmp);   disppointer((void **) &tmp);
fp=fopen(filename,"rb");
tmp=fgets(buf,buflength,fp);
tmp=NULL;
fclose(fp);
if (buf[strlen(buf)-1]=='\n' || buf[strlen(buf)-1]=='\r')
  buf[strlen(buf)-1]='\0';
ret=stringcopy(buf);
if (filename!=NULL)
{
  remove(filename);
  disppointer((void **) &filename);
}
disppointer((void  **) &buf);
disppointer((void  **) &tmp);
if (ret!=NULL)
  if (ret[strlen(ret)-1]!='/')
  {
    tmp=ret;
    ret=stringcat(tmp,"/");
    disppointer((void **) &tmp);
  }
return ret;
}



static char *getpwdstringdos(void)
     /* Vrne niz, ki predstavlja tekoci direktorij. Vrnjeni niz je potrebno
     po uporabi brisati.
     $A Igor okt99; */
{
int buflength=200,length;
char *ret=NULL,*tmp=NULL,*buf=NULL,*filename=NULL;
FILE *fp;
long pos1,pos2;
filename=makestring(300);
filename=tmpnam(filename);
tmp=stringcat("dir > ",filename);
system(tmp);   disppointer((void **) &tmp);
fp=fopen(filename,"rb");
/* Preberemo del datoteke, ki sledi "Directory of..." do 1. znaka za novo
vrstico: */
pos1=filestringto(fp,"irectory",1,0,100);
if (pos1>0)
{
  pos2=filecharto(fp,"\n\r",2,pos1,flength(fp),100);
  if (pos2>0)
  {
    length=pos2-pos1;
    buf=makestring(length+1); /* en znak vec, ce bo treba dodati '\' */
    fileread(buf,length,1,fp,pos1);
    buf[length]='\0';
    /* Zagotovimo, da je zadnji znak imena \: */
	if (buf[length-1]==':')
      buf[length-1]='\\';
    if (buf[length-1]!='\\')
    {
      buf[length]='\\';
      buf[length+1]='\0';
    }
    /* Iz niza izlocimo zadnji del, ki je res ime direktorija: */
    ret=&(buf[length-1]);
    while (*ret!=' ' && *ret!=':' && ret>=buf)
      --ret;
    ++ret;
	ret=stringcopy(ret);
  }
}
fclose(fp);
if (filename!=NULL)
{
  remove(filename);
  disppointer((void **) &filename);
}
disppointer((void  **) &buf);
disppointer((void  **) &tmp);
if (ret!=NULL)
  if (ret[strlen(ret)-1]!='\\')
  {
    tmp=ret;
    ret=stringcat(tmp,"\\");
    disppointer((void **) &tmp);
  }
return ret;
}


char *getpwdstring(void)
     /* Vrne niz, ki predstavlja tekoci direktorij, za UNIX. Vrnjeni niz je
     potrebno po uporabi brisati.
     $A Igor okt99; */
{
#ifdef UNIX
  return getpwdstringunix();
#else
  #ifdef DOSWN
    return getpwdstringdos();
  #else
    return NULL;
  #endif
#endif
}



/* KONEC FUNKCIJ ZA UPORABO V INVAN-U. */


















/*

    PRIMER UPORABE FUNKCIJ IZ TE DATOTEKE:


main()
{
stack dir;
dirmask dm;
dirkindmask dkm;
dircom dc;
char *path;
int contin=1,dirset=1;
dm=(dirmask) malloc(sizeof(*dm));
dkm=(dirkindmask) malloc(sizeof(*dkm));
memset(dm,1,sizeof(*dm));
memset(dkm,1,sizeof(*dkm));
path="/nfs/jupiter/users/igor";
dc=newdircom();
path=makestring(100);
while (contin)
{
  printf("Pot in opcije: ");
  gets(path); printf("\n");
  fcomlistdir(NULL,path,dc,&dir);
  printf("Nadaljevanje (0/1) ? ");
  scanf("%i",&contin);  gets(path);
  printf("Nastavitve (0/1) ? ");
  scanf("%i",&dirset);  gets(path);
  if (dirset)
    dirsettings(dc);
  printf("Nastavitve z nizom parametrov (0/1) ? ");
  scanf("%i",&dirset);  gets(path);
  if (dirset)
  {
    int i;
    char *p;
    stack param;
    printf("Parametri: ");
    gets(path); printf("\n");
    param=stringparamlistsimp(path);
    if (param!=NULL)
    {
      if (param->n>=1)
        for (i=1; i<=param->n; ++i)
        {
          p=(char*) param->s[i];
          setdiroption(dc,p);
        }
    }
  }
  consistentdircom(dc);
  printf("\n\n");
  fprintdirsettings(stdout,dc);
  printf("\n\n");
}
exit(0);
}

*/
