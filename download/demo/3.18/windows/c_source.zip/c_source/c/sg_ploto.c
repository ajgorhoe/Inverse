

        /***********************************/
        /*                                 */
        /*   PLOTTING OF GRAPHIC OBJECTS   */
        /*                                 */
        /***********************************/


#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <math.h>

#include <sysint.h>

#include <strop.h>
#include <rf.h>
#include <st.h>
#include <er.h>
#include <grint.h>
#include <gro.h>

#include <sg_obj.h>
#include <sg_draw.h>
#include <sg_ploto.h>





static int gpcomparedp(void *p1,void *p2)
    /* Compares graphic primitives p1 and p2 by the field ...->dp. Returns
    -1 if p1->dp<p2->dp, 1 if if p1->dp>p2->dp, or 0.
    $A Igor <== sep03; */
{
goprimitive gp1,gp2;
if (p1!=NULL && p2!=NULL)
{
  gp1=p1; gp2=p2;
  if (gp1->dp!=NULL && gp2->dp!=NULL)
  {
    if (*(gp1->dp) < *(gp2->dp))
      return -1;
    else if  (*(gp1->dp) > *(gp2->dp))
      return 1;
    else
      return 0;
  } else return 0;
} else return 0;
}


/* Function that is usef for comparison of graphic primitives at sorting stacks
on which the primitives are loaded: */
static int (*gpcompare) (void *,void *) = gpcomparedp;





               /*****************************************/
               /*   CONVERSION TO WINDOW CO-ORDINATES   */
               /*****************************************/


/* LOCAL VARIABLES USED FOR CONVERSION OF CO-ORDINATES: */

static _frame3d graphlimits;  /* graph limits (untransfomred) */
static _frame3d graphtransflimits;  /* transformed graph. limits (nust fit
                                       into the frame) */
static _frame3d graphframe;   /* frame in which graph must fit */
static _coord3d graphcenter;  /* center of the graph in 3D */
static _coord3d graphtransfcenter; /* transformed center */
static double graphdiagonal; /* diagonal length of graphlimits */
/* Scaling factors for conversion of natural co-ords to window c.: */
static double framexscale=1,frameyscale=1,framezscale=1;
/* Center of the wrame which we draw into: */
static double framexcenter=0.5, frameycenter=0.5, framezcenter=0.0;

char sg_drawtransf=1;    /* If 0 then untransformed objects are plotted. */


static void baswindowcoord1old(coord3d point,double *x,double *y)
    /* Calculates window co-ordinates of a graphic point. Plain or
    transformed co-ordinates are scaled proportionally.
    $A Igor <== sep03; */
{
*x=framexcenter+(point->x-graphtransfcenter.x)*framexscale;
*y=frameycenter+(point->y-graphtransfcenter.y)*frameyscale;
}



static double distancefactor1old=1;
/* tells for how many diagonals of the plotted area the observer is away of the
center of this area; used in eyewindowcoord(), set in gosettransfeyesimp() and
gosettransfeyesimpscale(). */


static void eyewindowcoord1old(coord3d point,double *x,double *y)
    /* Calculates window co-ordinates of a graphicla point. Plain or
    transformed co-ordinates are transformed in perspective.
    $A Igor <== sep03; */
{
double l,l0;
l0=graphdiagonal*distancefactor1old;
l=l0-point->z;
if (l/graphdiagonal<0.01)
{
  *x=framexcenter;
  *y=frameycenter;
} else
{
  *x=framexcenter+(point->x-graphtransfcenter.x)*framexscale*l0/l;
  *y=frameycenter+(point->y-graphtransfcenter.y)*frameyscale*l0/l;
}
}


static void (*gpwindowcoord1old) (coord3d, double *, double *) = baswindowcoord1old;
/* Function that calculates window co-ordinates of a point from its space
co-ordinates. */




static void baswindowcoord(coord3d point,coord3d wp)
       /* Calculates window co-ordinates of a graphic point. Plain or
       transformed co-ordinates are scaled proportionally.
         It writes window co-ords. to wp->x in wp->y.
       $A Igor <== apr97 sep03; */
{
wp->x=framexcenter+(point->x-graphtransfcenter.x)*framexscale;
wp->y=frameycenter+(point->y-graphtransfcenter.y)*frameyscale;
}



static double distancefactor=1;
/* Tells how many diagonals of the plotted area the observer is away from
the center of this area; used in eyewindowcoord(), set in gosettransfeyesimp()
and gosettransfeyesimpscale(). */

static void eyewindowcoord(coord3d point,coord3d wp)
     /* Calculates window co-ordinates of a graphic point. Plain or transformed
     co-ordinates are scaled in perspective. Window co-ordinates are written
     to wp->x and wp->y.
       $A Igor <== apr97, sep03; */
{
double l,l0;
l0=graphdiagonal*distancefactor;
l=l0-point->z;
if (l/graphdiagonal<0.01)
{
  wp->x=framexcenter;
  wp->y=frameycenter;
} else
{
  wp->x=framexcenter+(point->x-graphtransfcenter.x)*framexscale*l0/l;
  wp->y=frameycenter+(point->y-graphtransfcenter.y)*frameyscale*l0/l;
}
}


/* Function that calculates window coordinates from the space coordinates of a
point: */
void (*gpwindowcoord) (coord3d,coord3d) = baswindowcoord;








               /*********************************/
               /* TRANSFORMS OF GRAPHIC OPJECTS */
               /*********************************/


static _transfsimptype trsimp; /* parameters that define the transform */

static void transfcoordsimp(coord3d original, coord3d transformed)
    /* Transforms co-ordinates original to transformed. Space for *transformed
    must be allocated. It uses local var. trsimp as a source of parameters of
    the transform.
    $A Igor <== sep03; */
{
if (original!=NULL && transformed!=NULL)
{
  transformed->x=-(trsimp.sf)*original->x
                 +(trsimp.cf)*original->y;
  transformed->y=(trsimp.ct)*original->z-(trsimp.st)*
                 ((trsimp.cf)*original->x+(trsimp.sf)*original->y);
  transformed->z=(trsimp.st)*original->z+(trsimp.ct)*
                 ((trsimp.cf)*original->x+(trsimp.sf)*original->y);
}
}


static double xscale=1,yscale=1,zscale=1;

static void transfcoordsimpscale(coord3d original, coord3d transformed)
    /* Transforms co-ordinates original to transformed. Space for *transformed
    must be allocated. It uses local var. trsimp as a source of parameters of
    the transform. It is different from transfcoordsimp() in that beside the
    rotation it also performs scaling of the co-ordinates.
    $A Igor <== sep03; */
{
if (original!=NULL && transformed!=NULL)
{
  transformed->x=-(trsimp.sf)*original->x*xscale
                 +(trsimp.cf)*original->y*yscale;
  transformed->y=(trsimp.ct)*original->z*zscale-(trsimp.st)*
                 ((trsimp.cf)*original->x*xscale+(trsimp.sf)*original->y*yscale);
  transformed->z=(trsimp.st)*original->z*zscale+(trsimp.ct)*
                 ((trsimp.cf)*original->x*xscale+(trsimp.sf)*original->y*yscale);
}
}




/* Function that is used for transformatio of co-ordinates: */
static void (*gotransfcoord) (coord3d,coord3d) = transfcoordsimp;


static void transformgoprimitive(goprimitive gp)
    /* Transforms co-ordinates of the graphic primitive gp. All co-ordinates
    on gp->coord are transformed to the appropriate co-ordinates on
    gp->transfcoord. If necessary it allocates the space for the transformed
    co-ordinates.
    $A Igor <== sep03; */
{
int i,n;
coord3d coord=NULL;
if (gp!=NULL)
  if (gp->coord!=NULL)
    if (gp->coord->n>0)
    {
      if (gp->transfcoord==NULL)
        gp->transfcoord=newstack(1);
      n=gp->coord->n-gp->transfcoord->n;
      if (gp->transfcoord->n<gp->coord->n)
        for (i=1;i<=n;++i)
        {
          coord=malloc(sizeof(*coord));
          pushstack(gp->transfcoord,coord);
        }
      if (gp->dp==NULL)
        gp->dp=malloc(sizeof(*(gp->dp)));
      *gp->dp=0;
      for (i=1;i<=gp->coord->n;++i)
      {
        gotransfcoord( (coord3d) gp->coord->s[i], (coord3d) gp->transfcoord->s[i] );
        *(gp->dp)+= ( (coord3d) gp->transfcoord->s[i] ) ->z;
      }
      *(gp->dp)/=(double) gp->coord->n;
    }
}



/* Function that is used for transformation of graphic primitives: */
static void (*gotransfprimitive) (goprimitive) = transformgoprimitive;



void gotransfgroup(gogroup gg)
    /* Transforms the whole graphic object gg (transforms all primitives loaded
    on gg->primitives, gg->extraprimitives and on the corresponding stacks of
    sub-trees of gg. gotransfprimitive() is used for the transformation of
    primitives.
    $A Igor <== sep03; */
{
int i;
if (gg!=NULL)
{
  if (gg->groups!=NULL)
    if (gg->groups->n>0)
      for (i=1;i<=gg->groups->n;++i)
        gotransfgroup( (gogroup) gg->groups->s[i] );
  if (gg->primitives!=NULL)
    if (gg->primitives->n>0)
      for (i=1;i<=gg->primitives->n;++i)
        gotransfprimitive((goprimitive) gg->primitives->s[i]);
  if (gg->extraprimitives!=NULL)
    if (gg->extraprimitives->n>0)
      for (i=1;i<=gg->extraprimitives->n;++i)
        gotransfprimitive((goprimitive) gg->extraprimitives->s[i]);
}
}


void gotransfstack(stack st)
    /* Transforms all graphic primitives that are loaded to st by the function
    gotransfprimitive(). It also transforms primitives from the stacks
    (...)->before and (...)->after of these primitives.
    $A Igor <== sep03; */
{
goprimitive gp;
int i,j;
if (st!=NULL)
  if (st->n>0)
    for (i=1;i<=st->n;++i)
    for (i=1;i<=st->n;++i)
    {
      gp=st->s[i];
      gotransfprimitive(gp);
      if (gp->before!=NULL)
        if (gp->before->n>0)
          for (j=1;j<=gp->before->n;++j)
            gotransfprimitive(gp->before->s[j]);
      if (gp->after!=NULL)
        if (gp->after->n>0)
          for (j=1;j<=gp->after->n;++j)
            gotransfprimitive(gp->after->s[j]);
    }
}


void gosettransfsimp(double fi, double theta)
    /* Sets parameters for the rotation of graphic primitives to fi and
    theta. transfcoordsimp() becomes the function for transformation of
    co-ordinates , while baswindowcoord() becomes the function for conversion
    to window co-ordinates.
    $A Igor <== sep03; */
{
/* Parameters for transform of co-ordinates: */
trsimp.fi=fi;          trsimp.theta=theta;
trsimp.sf=sin(fi);     trsimp.cf=cos(fi);
trsimp.st=sin(theta);  trsimp.ct=cos(theta);
/* Function that is used for transform of co-ordinates:  */
gotransfcoord=transfcoordsimp;
/* Function for calculation of window co-ordinates: */
gpwindowcoord=baswindowcoord;
/* Function for transformation of graphic primitive: */
gotransfprimitive=transformgoprimitive;
/* Transform of the center of the graph: */
gotransfcoord(&graphcenter,&graphtransfcenter);
}


/* Scaling factors for the transformation: */
static double xscalingfactor=1,yscalingfactor=1,zscalingfactor=0.6;

void gosettransfsimpscale(double fi, double theta)
    /* Sets the parameters for the rotation of graphic objects to fi and
    theta. Sets function for transformation of co-ordinates to
    transfcoordsimpscale() and function for conversion to window co-ordinates
    to baswindowcoord().
    $A Igor <== sep03; */
{
double sqrt3=1.732050808;
/* Data for co-ordinate transform: */
trsimp.fi=fi;          trsimp.theta=theta;
trsimp.sf=sin(fi);     trsimp.cf=cos(fi);
trsimp.st=sin(theta);  trsimp.ct=cos(theta);
/* Function that will be used for co-ordinate transform: */
gotransfcoord=transfcoordsimpscale;
/* Function for calculation of window co-ordinates: */
gpwindowcoord=baswindowcoord;
/* Scaling factors for the latter function: */
xscale=xscalingfactor*graphdiagonal/
 (sqrt3*(graphlimits.max.x-graphlimits.min.x));
yscale=yscalingfactor*graphdiagonal/
 (sqrt3*(graphlimits.max.y-graphlimits.min.y));
zscale=zscalingfactor*graphdiagonal/
 (sqrt3*(graphlimits.max.z-graphlimits.min.z));
/* Function for transform of the graphic primitive: */
gotransfprimitive=transformgoprimitive;
/* Transform of the graph center: */
gotransfcoord(&graphcenter,&graphtransfcenter);
}

void gosettransfeyesimp(double fi, double theta)
    /* Sets the parameters for rotation of graphic objects to fi and theta.
    transfcoordsimp() becomes the function for transformation of co-ordinates
    and eyewindowcoord() for the conversion to window co-ordinates.
    $A Igor <== sep03; */
{
/* Data for transform of co-ordinates: */
trsimp.fi=fi;          trsimp.theta=theta;
trsimp.sf=sin(fi);     trsimp.cf=cos(fi);
trsimp.st=sin(theta);  trsimp.ct=cos(theta);
/* Function that will vbe used for transformatio of co-ordinates: */
gotransfcoord=transfcoordsimp;
/* Function for calculation of window co-ordinates: */
gpwindowcoord=eyewindowcoord;
/* Function for transformation of graphic primitive: */
gotransfprimitive=transformgoprimitive;
/* Transform of the graph center: */
gotransfcoord(&graphcenter,&graphtransfcenter);
}

void gosettransfeyesimpscale(double fi, double theta)
    /* Sets parameters for rotation of graphic objects to fi and theta.
    Function for transformation of co-ordinates is set to 
    transfcoordsimpscale() whilw function for conversion to window co-ordinates
    is set to eyewindowcoord()
    $A Igor <== sep03; */
{
double sqrt3=1.732050808;
/* Data for transformation of co-ordinates: */
trsimp.fi=fi;          trsimp.theta=theta;
trsimp.sf=sin(fi);     trsimp.cf=cos(fi);
trsimp.st=sin(theta);  trsimp.ct=cos(theta);
/* Function that will be used for transformation of co-ordinates: */
gotransfcoord=transfcoordsimpscale;
/* Function for calculation of window co-ordinates: */
gpwindowcoord=eyewindowcoord;
/* Scaling factors for this function: */
xscale=xscalingfactor*graphdiagonal/
 (sqrt3*(graphlimits.max.x-graphlimits.min.x));
yscale=yscalingfactor*graphdiagonal/
 (sqrt3*(graphlimits.max.y-graphlimits.min.y));
zscale=zscalingfactor*graphdiagonal/
 (sqrt3*(graphlimits.max.z-graphlimits.min.z));
/* Function for transformation of graphic primitive: */
gotransfprimitive=transformgoprimitive;
/* Transformation of graph center: */
gotransfcoord(&graphcenter,&graphtransfcenter);
}

void gosettransfscalingfactors(double xfac,double yfac,double zfac)
    /* Sets the factors for scaling of co-ordinates after the transform
    by the function gosettransfsimpscale().
    $A Igor <== sep03; */
{
xscalingfactor=xfac;
yscalingfactor=yfac;
zscalingfactor=zfac;
}

void gosetdistancefactor(double factor)
    /* SEts the ratio between the distance of the observer from the center of
    the plotted 3D area and the diagonal of this area.
    $A Igor <== sep03; */
{
distancefactor=factor;
}




void preparegraph3dbas(frame3d limits,frame3d frame)
    /* Prepares parameters for plotting the graph. Parameters that affect
    mapping from spatial to window co-ordinates on the screen are set according
    to the variables limits (geometric borders of a 3D object) and frame
    (window co-ordinates or limits within which everything within limits
    should be plotted). It also sets functions that are used for mapping of
    co-ordinates.
      Remark:
      frame can be NULL, in this case the default frame is taken ([0,1]x[0,1]).
    $A Igor <== sep03; */
{
static _frame3d defaultframe={{0,0,0},{1,1,1}};
graphlimits=*limits;
if (frame==NULL)
{
  graphframe=defaultframe;
  frame=&defaultframe;
} else
  graphframe=*frame;
graphcenter.x=0.5*(graphlimits.min.x+graphlimits.max.x);
graphcenter.y=0.5*(graphlimits.min.y+graphlimits.max.y);
graphcenter.z=0.5*(graphlimits.min.z+graphlimits.max.z);
graphtransfcenter=graphcenter;
/* Diagonal of the graph limits: */
graphdiagonal=sqrt(pow(limits->max.x-limits->min.x,2)+
                   pow(limits->max.y-limits->min.y,2)+
                   pow(limits->max.z-limits->min.z,2));
/* Scaling factors in x and y directions: */
framexscale=(frame->max.x-frame->min.x)/graphdiagonal;
frameyscale=(frame->max.y-frame->min.y)/graphdiagonal;
framezscale=(frame->max.z-frame->min.z)/graphdiagonal;

/* Center fo the frame into which we draw: */
framexcenter=0.5*(frame->max.x+frame->min.x);
frameycenter=0.5*(frame->max.y+frame->min.y);
/* Function that converts transformed co-ordinates to the co-ordinates in a
window: */
gpwindowcoord=baswindowcoord;
}
















               /*************************/
               /* LIGHTING OF 3D GRAPHS */
               /*************************/



    /* LIGHTS : */

/* Remark: The color components of light intensity can be more than 1. */

/* DIFFUSE LIGHT: */
static _truecolor intdifuselight= {1.0,1.0,1.0}; /* intenziteta */

/* INFINITLY DISTANT LIGHTS: */
static stack intfarlights=NULL;  /* intensities */
static stack dirfarlights=NULL;  /* directions (torwards lights) */
static double powfarlighting=0.5; /* power to which the cosines of indcident
         angles of rays are raised (contrast intensification effect) */


static double lightfactor=1.0; /* factor by which the calculated surface
          brightness is multiplied */

char sg_dolighting=0; /* if 0 then lighting does not take effect */



void godolighting(char dl)
    /* If dl is 0 then lighting will not be accounted for when drawing graphic
    objects, otherwise lighting will take effect.
    $A Igor <== sep09; */
{
sg_dolighting=dl;
}


double gogetlightfactor(void)
    /* Returns the factor by which intensities of colors are multiplied after
    calculation of lighting effects.
    $A Igor <== sep09; */
{
return lightfactor;
}

void gosetlightfactor(double factor)
    /* Sets the factor by which the intensities of object colors are multiplied
    after all lighting effects are calculated. The factor is stored to a local
    variable lightfactor.
    $A Igor <== sep09; */
{
lightfactor=factor;
}

double goupdatelightfactor(double factor)
    /* Sets the factor by which the intensities of object colors are multiplied
    after all lighting effects are calculated. First this factor is calculated
    in such a way that the largest component of the sum of intensities of all
    lights is 1, then this factor is multiplied by 'factor' that is the
    argument of this function. The factor obtained in this way is stored to a
    local variable lightfactor.
    $A Igor <== sep09; */
{
_truecolor color={0,0,0};
truecolor pcol;
double maxcomponent;
int i;
color.red+=intdifuselight.red;
color.green+=intdifuselight.green;
color.blue+=intdifuselight.blue;
if (intfarlights!=NULL)
  if (intfarlights->n>0)
    for (i=1;i<=intfarlights->n;++i)
    {
      pcol=intfarlights->s[i];
      color.red+=pcol->red;
      color.green+=pcol->green;
      color.blue+=pcol->blue;
    }
maxcomponent=color.red;
if (color.green>maxcomponent)
  maxcomponent=color.green;
if (color.blue>maxcomponent)
  maxcomponent=color.blue;
if (maxcomponent!=0)
  lightfactor=factor/maxcomponent;
else lightfactor=1;
return lightfactor;
}



void gosetdifuselight(double red,double green,double blue)
    /* Sets the intensities of components of the diffuse light. Values are
    stored in a local variable intdifuselight(). The components can be more
    than 1.
    $A Igor <== sep09; */
{
intdifuselight.red=(float) red;
intdifuselight.green=(float) green;
intdifuselight.blue=(float) blue;
goupdatelightfactor(1);
}



void gosetfarlight(double red,double green,double blue,
                   double xdir,double ydir,double zdir)
    /* Adds an infinitely distant illuminant that lights with the intensity
    (red,green,blue) and whose direction (towards the light source) is
    (xdir,ydir,zdir). Intensity is pushed as an object of type truecolor
    on the stack intfarlights, directions are pusher as an object of type
    coord3d on the stack dirfarlights.
    $A Igor <== sep09; */
{
truecolor intensity;
coord3d direction;
double norm;
if (intfarlights==NULL)
  intfarlights=newstack(1);
if (dirfarlights==NULL)
  dirfarlights=newstack(1);
intensity=malloc(sizeof(*intensity));
direction=malloc(sizeof(*direction));
intensity->red=(float) red; intensity->green=(float) green; intensity->blue=(float) blue;
norm=sqrt(xdir*xdir+ydir*ydir+zdir*zdir);
direction->x=xdir/norm; direction->y=ydir/norm; direction->z=zdir/norm;
pushstack(intfarlights,intensity);
pushstack(dirfarlights,direction);
goupdatelightfactor(1);
}


double gogetpowfarlighting(void)
    /* Returns the power to which the cosine of the incident angle of light is
    raised when calculating the brightness of the lit object. (for surfaces
    this is the cosine of the angle between the normal and the reverse
    direction of the ray while for lines this is the absolute of the sine
    between the direction angle of the line and the incident direction of the
    ray.
    $A Igor <== sep09; */
{
return powfarlighting;
}

void gosetpowfarlighting(double pw)
    /* Sets the power to which the cosine of the incident angle of light
    is raised when calculating brightnes of the lit object.
    $A Igor <== sep09; */
{
powfarlighting=pw;
}



void calclightintensity(stack coord,truecolor original,truecolor calc)
    /* Calculates the intensity of the light reflected from an object with
    respect to the arrangement of all defined light sources. coord must be a
    stack on which there are co-ordinates of the graphic object (primitive)
    and original must contain the natural color of the object. The calculated
    reflected color is put into *calc.
    $A Igor <== sep09; */
{
truecolor it;
_coord3d n,v1,v2;
coord3d dir,p1,p2,p3;
double norm,cosfi,sinfi;
int i;
calc->red=calc->green=calc->blue=0;
if (coord!=NULL && original!=NULL)
{
  if (coord->n==1)  /* point object  */
  {
    /* Diffuse light contribution: */
    calc->red=original->red*intdifuselight.red;
    calc->green=original->green*intdifuselight.green;
    calc->blue=original->blue*intdifuselight.blue;
  } else if (coord->n==2) /* line object */
  {
    /* Diffuse light contribution: */
    calc->red=original->red*intdifuselight.red;
    calc->green=original->green*intdifuselight.green;
    calc->blue=original->blue*intdifuselight.blue;
    /* Distant (infinity) lights: */
    if (coord->s[1]!=NULL && coord->s[2]!=NULL
     && dirfarlights!=NULL && intfarlights!=NULL)
    {
      if (dirfarlights->n>0 && intfarlights->n>0)
      {
        /* Direction angle of a line: */
        p1=coord->s[1];
        p2=coord->s[2];
        n.x=p2->x-p1->x;
        n.y=p2->y-p1->y;
        n.z=p2->z-p1->z;
        norm=sqrt(n.x*n.x+n.y*n.y+n.z*n.z); /* norm of the dir. vect. */
        if (norm==0)
          norm=1;
        for (i=1;i<=dirfarlights->n;++i)
        {
          it=intfarlights->s[i];
          dir=dirfarlights->s[i]; /* reverse direction of the ray */
          if (it!=NULL && dir!=NULL)
          {
            sinfi=(dir->x*n.x+dir->y*n.y+dir->z*n.z)/norm;
            cosfi=sqrt(1-sinfi*sinfi);
            cosfi=pow(cosfi,powfarlighting);
            calc->red+=(float) ( it->red*original->red*cosfi );
            calc->green+=(float) ( it->green*original->green*cosfi );
            calc->blue+=(float) ( it->blue*original->blue*cosfi );
          }
        }
      }
    }
  } else if (coord->n>2)  /* surface */
  {
    /* Diffuse light contribution */
    calc->red=original->red*intdifuselight.red;
    calc->green=original->green*intdifuselight.green;
    calc->blue=original->blue*intdifuselight.blue;
    /* Distant (infinity) lights contributions: */
    if (coord->s[1]!=NULL && coord->s[coord->n]!=NULL && coord->s[2]!=NULL
     && dirfarlights!=NULL && intfarlights!=NULL)
    {
      if (dirfarlights->n>0 && intfarlights->n>0)
      {
        /* Normal of the surface: */
        p1=coord->s[1];
        p2=coord->s[2];
        p3=coord->s[coord->n];
        v1.x=p2->x-p1->x; v1.y=p2->y-p1->y; v1.z=p2->z-p1->z;
        v2.x=p3->x-p1->x; v2.y=p3->y-p1->y; v2.z=p3->z-p1->z;
        n.x=v1.y*v2.z-v1.z*v2.y;
        n.y=v1.z*v2.x-v1.x*v2.z;
        n.z=v1.x*v2.y-v1.y*v2.x;
        norm=sqrt(n.x*n.x+n.y*n.y+n.z*n.z); /* normal norm */
        for (i=1;i<=dirfarlights->n;++i)
        {
          it=intfarlights->s[i];
          dir=dirfarlights->s[i]; /* reverse ray direction */
          if (it!=NULL && dir!=NULL)
          {
            cosfi=(dir->x*n.x+dir->y*n.y+dir->z*n.z)/norm;
            if (cosfi<0) cosfi=0;
            cosfi=pow(cosfi,powfarlighting);
            calc->red+=(float) ( it->red*original->red*cosfi );
            calc->green+=(float) ( it->green*original->green*cosfi );
            calc->blue+=(float) ( it->blue*original->blue*cosfi );
          }
        }
      }
    }
  } else
  {
    calc->red=original->red*intdifuselight.red;
  }
} else
{
  calc->red=calc->green=calc->blue=0;
}
calc->red*=(float) lightfactor; calc->green*=(float) lightfactor; calc->blue*=(float) lightfactor;
}













           /******************************************/
           /*   FUNCTIONS FOR PLOTTING 3D OBJECTS:   */
           /******************************************/



static void setlinesettings(golinesettings ls)
    /* Sets the attributes for drawing lines as specified by ls.
    $A Igor <== sep09; */
{
sg_setlinecolor(ls->color.red,ls->color.green,ls->color.blue);
sg_setlinewidth(ls->linewidth);
sg_setlinetype(ls->linetype);
}


static void setfillsettings(gofillsettings fs)
    /* Sets the attributes for drawing filled shapes as it is specified by fs.
    $A Igor <== sep09; */
{
sg_setfillcolor(fs->color.red,fs->color.green,fs->color.blue);
}


static void settextsettings(gotextsettings ts)
    /* Sets the attributes for drawing text as it is specified by ls.
    $A Igor <== sep09; */
{
sg_settextcolor(ts->color.red,ts->color.green,ts->color.blue);
sg_settextfont(ts->font);
sg_settextheight((float) ts->height);
/*
sg_settextspacing((float) ts->spacing);
sg_settextexpansion((float) ts->expansion);
*/
sg_settextxalignment(ts->xalignment);
sg_settextyalignment(ts->yalignment);
}





    /* PLOTTING OF DIFFERENT TYPES OF GRAPHIC PRIMITIVES: */



/* Variables used for storing of window co-ordinates: */
static _coord3d wp1,wp2,wp3,wp4;




static void gpdrawline(goprimitive gp)
    /* Draws a graphic primitive that represents a line.
    $A Igor <== sep09; */
{
char nottransf=0;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>1)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>1)
    {
      p1=gp->coord->s[1];
      p2=gp->coord->s[2];
    }
if (p1!=NULL && p2!=NULL)
{
  gg=gp->grp;
  ls=(golinesettings) gp->props1;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      sg_setlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  sg_line((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y);
}
}



static void gpdrawtriangle(goprimitive gp)
    /* Drawa a graphic primitive that represents a triangle made of lines.
    $A Igor <== sep09; */
{
char nottransf=0;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>2)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>2)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL)
{
  gg=gp->grp;
  ls=(golinesettings) gp->props1;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      sg_setlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  sg_triangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
}
}



static void gpdrawfilltriangle(goprimitive gp)
    /* Draws a graphic primitive that represents a filled triangle.
    $A Igor <== sep09; */
{
char nottransf=0;
gofillsettings fs=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>2)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>2)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      sg_setfillcolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  sg_filltriangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
}
}



static void gpdrawbordtriangle(goprimitive gp)
    /* Draws a primitive that represents filled and bordered triangle.
    $A Igor <== sep09; */
{
char nottransf=0;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>2)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>2)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      sg_setfillcolor(color.red,color.green,color.blue);
    }
  }
  ls=(golinesettings) gp->props2;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      sg_setlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  sg_filltriangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
  sg_triangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
}
}




static void gpdrawpartbordtriangle(goprimitive gp)
    /* Draws a primitive that represents filled and partially bordered triangle.
    $A Igor <== sep09; */
{
char nottransf=0;
char *flags=NULL;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>2)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>2)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      sg_setfillcolor(color.red,color.green,color.blue);
    }
  }
  if (gp->props3!=NULL)
  {
    /* Preparation for drawing lines: */
    ls=(golinesettings) gp->props2;
    if (ls==NULL)
      if (gg!=NULL)
        ls=gg->ls1;
    if (ls!=NULL)
    {
      setlinesettings(ls);
      if (sg_dolighting)
      {
        _truecolor color={0,0,0};
        if (gp->transfcoord!=NULL && sg_drawtransf)
          calclightintensity(gp->transfcoord,&(ls->color),&color);
        else if (gp->coord!=NULL)
          calclightintensity(gp->transfcoord,&(ls->color),&color);
        sg_setlinecolor(color.red,color.green,color.blue);
      }
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  sg_filltriangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
  if (gp->props3!=NULL)
  {
    flags=gp->props3;
    if (flags[0])
      sg_line((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y);
    if (flags[1])
      sg_line((float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
    if (flags[2])
      sg_line((float) wp3.x,(float) wp3.y,(float) wp1.x,(float) wp1.y);
  }
}
}





static void gpdrawfourangle(goprimitive gp)
    /* Draws a primitive that represents a fourangle composed of lines.
    $A Igor <== sep09; */
{
char nottransf=0;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL,p4=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>3)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
    p4=gp->transfcoord->s[4];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>3)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
        p4=gp->coord->s[4];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL&& p4!=NULL)
{
  gg=gp->grp;
  ls=(golinesettings) gp->props1;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      sg_setlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  gpwindowcoord(p4,&wp4);
  sg_fourangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
}
}


static void gpdrawfillfourangle(goprimitive gp)
    /* Draws a primitive that represents a filled fourangle.
    $A Igor <== sep09; */
{
char nottransf=0;
gofillsettings fs=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL,p4=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>3)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
    p4=gp->transfcoord->s[4];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>3)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
        p4=gp->coord->s[4];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL&& p4!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      sg_setfillcolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  gpwindowcoord(p4,&wp4);
  sg_fillfourangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
}
}


static void gpdrawbordfourangle(goprimitive gp)
    /* Draws a primitive that represents filled and bordered fourangle.
    $A Igor <== sep09; */
       /* Izrise graficni primitiv, ki predstavlja obrobljen zapolnjen
       stirikotnik ('4','b','0')
       $A Igor <== apr97; */
{
char nottransf=0;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL,p4=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>3)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
    p4=gp->transfcoord->s[4];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>3)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
        p4=gp->coord->s[4];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL&& p4!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      sg_setfillcolor(color.red,color.green,color.blue);
    }
  }
  ls=(golinesettings) gp->props2;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      sg_setlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  gpwindowcoord(p4,&wp4);
  sg_fillfourangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
  sg_fourangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
}
}



static void gpdrawpartbordfourangle(goprimitive gp)
    /* Draws a primitive that represents filled and partially bordered
    fourangle. If at least one edge is bordered, then gp->props3 is a pointer
    to a table of 4 characters, of which those different from 0 represent
    bordered edges. gp->props3[0] corresponds to the line between the first
    and second apex, gp->props3[1] to the edge between the second and third
    apec (coordinate on the stack gp->coord or gp->transfcoord), etc.
    $A Igor <== sep09; */
{
char nottransf=0;
char *flags=NULL;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL,p4=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>3)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
    p4=gp->transfcoord->s[4];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>3)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
        p4=gp->coord->s[4];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL&& p4!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      sg_setfillcolor(color.red,color.green,color.blue);
    }
  }
  if (gp->props3!=NULL)
  {
    /* Preparation for drawing lines (edges) */
    ls=(golinesettings) gp->props2;
    if (ls==NULL)
      if (gg!=NULL)
        ls=gg->ls1;
    if (ls!=NULL)
    {
      setlinesettings(ls);
      if (sg_dolighting)
      {
        _truecolor color={0,0,0};
        if (gp->transfcoord!=NULL && sg_drawtransf)
          calclightintensity(gp->transfcoord,&(ls->color),&color);
        else if (gp->coord!=NULL)
          calclightintensity(gp->transfcoord,&(ls->color),&color);
        sg_setlinecolor(color.red,color.green,color.blue);
      }
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  gpwindowcoord(p4,&wp4);
  sg_fillfourangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
  if (gp->props3!=NULL)
  {
    flags=gp->props3;
    if (flags[0])
      sg_line((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y);
    if (flags[1])
      sg_line((float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
    if (flags[2])
      sg_line((float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
    if (flags[3])
      sg_line((float) wp4.x,(float) wp4.y,(float) wp1.x,(float) wp1.y);
  }
}
}



static void gpdrawtext(goprimitive gp)
    /* Draws a text primitive (one line).
    $A Igor <== sep09; */
{
char nottransf=0;
gotextsettings ts=NULL;
gogroup gg;
coord3d p1;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>0)
  {
    p1=gp->transfcoord->s[1];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>0)
    {
      p1=gp->coord->s[1];
    }
if (p1!=NULL)
{
  gg=gp->grp;
  ts=(gotextsettings) gp->props2;
  if (ts==NULL)
    if (gg!=NULL)
      ts=gg->ts1;
  if (ts!=NULL)
    settextsettings((gotextsettings) ts);
  gpwindowcoord(p1,&wp1);
  if (gp->props1!=NULL)
    sg_text((char *) gp->props1,(float) wp1.x,(float) wp1.y);
}
}



static void gpdrawmarker(goprimitive gp)
    /* Draws a primitive that represents a marker (used for representing
    points in graphs).
    $A Igor <== sep09; */
{
char nottransf=0;
double *psize=NULL,size;
int *pkind=NULL,kind;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>0)
  {
    p1=gp->transfcoord->s[1];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>0)
      {
        p1=gp->coord->s[1];
      }
if (p1!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      sg_setfillcolor(color.red,color.green,color.blue);
    }
  }
  /* Preparation for trawing lines */
  ls=(golinesettings) gp->props2;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      sg_setlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  psize=gp->props3;
  pkind=gp->props4;
  if (psize!=NULL)
    size=*psize;
  else
    size=0.025;
  if (pkind!=NULL)
    kind=*pkind;
  else
    kind=1;
  sg_marker((float) wp1.x,(float) wp1.y,(float) size,kind);
}
}



static void gpdrawarrow(goprimitive gp)
    /* Draws a primitive that represents an arrow. These primitives are used
    for presentation of vectors in graphs.
    $A Igor <== sep09; */
{
char nottransf=0;
double *psize=NULL,size,*pangle=NULL,angle;
int *pattr=NULL,attr;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>0)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>0)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
      }
if (p1!=NULL && p2!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      sg_setfillcolor(color.red,color.green,color.blue);
    }
  }
  /* Preparation for drawing lines: */
  ls=(golinesettings) gp->props2;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      sg_setlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  psize=pangle=(double *)gp->props3;
  if (psize!=NULL)
    size=*psize;
  else
    size=0.05;
  if (pangle!=NULL)
  {
    ++pangle;
    angle=*pangle;
  }
  else
    angle=0.2;
  pattr=(int *) gp->props4;
  if (pattr!=NULL)
    attr=*pattr;
  else
    attr=0;
  sg_arrow((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) size,(float) angle,attr);
}
}



void sg_godrawprimitive(goprimitive gp)
    /* Plots the primitive gp with the currently active plotting interface.
    $A Igor sep03; */
{
int i;
static int repundef=0,repinval=0;
if (gp!=NULL)
{
  if (gp->before!=NULL)
    if (gp->before->n!=0)
      for (i=1;i<=gp->before->n;++i)
        sg_godrawprimitive(gp->before->s[i]);
  switch (gp->type)
  {
    case SG_PR_UNDEF:
      if (!repundef)
      {
        warnfunc1(1,"sg_godrawprimitive");
        sprintf(ers(),"A graphic primitive of undefined type encountered");
        sprintf(ers(),"Further messages of this type will be surpressed.\n");
        warnfunc2();
        ++repundef;
      }
      break;
    case SG_PR_LINE:
      gpdrawline(gp);
      break;
    case SG_PR_TRI:
      gpdrawtriangle(gp);
      break;
    case SG_PR_F_TRI:
      gpdrawfilltriangle(gp);
      break;
    case SG_PR_FB_TRI:
      gpdrawbordtriangle(gp);
      break;
    case SG_PR_FP_TRI:
      gpdrawpartbordfourangle(gp);
      break;
    case SG_PR_FOUR:
      gpdrawfourangle(gp);
      break;
    case SG_PR_F_FOUR:
      gpdrawfillfourangle(gp);
      break;
    case SG_PR_FB_FOUR:
      gpdrawbordfourangle(gp);
      break;
    case SG_PR_FP_FOUR:
      gpdrawpartbordfourangle(gp);
      break;
    case SG_PR_TEXT:
      gpdrawtext(gp);
      break;
    case SG_PR_MARK:
      gpdrawmarker(gp);
      break;
    case SG_PR_ARROW:
      gpdrawarrow(gp);
      break;
    default:
      if (!repinval)
      {
        warnfunc1(1,"sg_godrawprimitive");
        sprintf(ers(),"A graphic primitive of invalid type (%i) encountered",
          gp->type);
        sprintf(ers(),"Further messages of this type will be surpressed.\n");
        warnfunc2();
        ++repinval;
      }
  }
  if (gp->after!=NULL)
    if (gp->after->n!=0)
      for (i=1;i<=gp->after->n;++i)
        sg_godrawprimitive(gp->after->s[i]);
}
}





void gosortstack(stack st)
    /* Sorts stack with the graphic primitives where the relation "is greater"
    is defined by a local function gpcompare().
    $A Igor <== sep03; */
{
qsortstack(st,gpcompare);
}


