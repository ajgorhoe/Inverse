#include <sysint.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stddef.h>


#include <rf.h>
#include <er.h>


#include <mtypes.h>
#include <vec.h>





  /* COUNTERS: */

counter getcounter(void)
    /* Creates a new counter and returns its pointer.
    $A Igor feb05; */
{
counter ret;
ret=calloc(sizeof(*ret),1);
return ret;
}

void dispcounter(counter *addr)
    /* If applicable, deallocates the counter whose address is addr and sets
    *addr to NULL.
    $A Igor feb05; */
{
if (addr!=NULL)
{
  if (*addr!=NULL)
  {
    free(*addr);
    *addr=NULL;
  }
}
}


void fprintcounter(FILE *fp,counter s)
    /* Prints the counter s to the file fp, with a newline printed after the
    value.
    $A Igor mar05; */
{
if (fp!=NULL)
{
  if (s==NULL)
    fprintf(fp,"NULL\n");
  else
    fprintf(fp,"%li\n",*s);
}
}

void printcounter(counter s)
    /* The same as fprintcounter, but prints to the standard output rather than
    to a specified file.
    $A Igor mar05; */
{
fprintcounter(stdout,s);
}


void fprintcounterlist(FILE *fp,counter s)
    /* Prints a counter s to the file fp. Only pure value is printed: neither a
    newline nor a space is printed after the value.
    $A Igor mar05; */
{
if (fp!=NULL)
{
  if (s==NULL)
    fprintf(fp,"NULL");
  else
    fprintf(fp,"%li",*s);
}
}

void printcounterlist(counter s)
    /* The same as fprintstalarlist, but prints to the standard output rather
    than to a specified file.
    $A Igor mar05; */
{
fprintcounterlist(stdout,s);
}



void resizecounter(counter *addr)
    /* If counter pointed to by addr is NULL then the counter is allocated.
      Remark: this is actually not resizing, but the name is taken in
    analogy to containter structures.
    $A Igor mar04; */
{
if (addr!=NULL)
  if (*addr==NULL)
    *addr=calloc(1,sizeof(**addr));
}


counter copycounter0(counter v1,counter *v2)
    /* Returns a coopy of counter v1. If v2!=NULL then v1 is copied to v2
    and v2 returned.
    $A Igor nov98; */
{
counter v;
if (v2!=NULL)
{
  /* If *v2!=NULL, v1 is copied to *v2: */
  if (v1==NULL)
  {
    disppointer((void **) v2);
  } else
  {
    /* If *v2==NULL, we must allocate *v2: */
    if (*v2==NULL)
      *v2=malloc(sizeof(**v2));
    v=*v2;
    /* Value copying: */
    *v=*v1;
  }
  return *v2; /* Since v2 was not NULL, *v2 is returned. */
} else
{
  /* v2==NULL, we make a new counter that is a copy of v1, its pointer is
  returned: */
  if (v1==NULL)
    return NULL;
  else
  {
    v=malloc(sizeof(*v));
    *v=*v1;
    return v;
  }
}
}



  /* SCALARS: */

scalar getscalar(void)
    /* Creates a new scalar and returns its pointer.
    $A Igor feb05; */
{
scalar ret;
ret=calloc(sizeof(*ret),1);
return ret;
}

void dispscalar(scalar *addr)
    /* If applicable, deallocates a scalar whose address is addr and sets *addr
    to NULL.
    $A Igor feb05; */
{
if (addr!=NULL)
{
  if (*addr!=NULL)
  {
    free(*addr);
    *addr=NULL;
  }
}
}


void fprintscalar(FILE *fp,scalar s)
    /* Prints a scalar s to the file fp, with a newline printed after the
    value.
    $A Igor mar05; */
{
if (fp!=NULL)
{
  if (s==NULL)
    fprintf(fp,"NULL\n");
  else
    fprintf(fp,"%.*g\n",m_outdig,*s);
}
}

void printscalar(scalar s)
    /* The same as fprintscalar, but prints to the standard output rather than
    to a specified file.
    $A Igor mar05; */
{
fprintscalar(stdout,s);
}


void fprintscalarlist(FILE *fp,scalar s)
  /* Prints a scalar s to the file fp. Only pure value is printed: neither a
  newline nor a space is printed after the value.
    $A Igor mar05; */
{
if (fp!=NULL)
{
  if (s==NULL)
    fprintf(fp,"NULL");
  else
    fprintf(fp,"%.*g",m_outdig,*s);
}
}

void printscalarlist(scalar s)
    /* The same as fprintstalarlist, but prints to the standard output rather
    than to a specified file.
    $A Igor mar05; */
{
fprintscalarlist(stdout,s);
}


void resizescalar(scalar *addr)
    /* If scalar pointed to by addr is NULL then the scalar is allocated.
      Remark: this is actually not resizing, but the name is taken in
    analogy to containter structures.
    $A Igor mar05; */
{
if (addr!=NULL)
  if (*addr==NULL)
    *addr=calloc(1,sizeof(**addr));
}

scalar copyscalar0(scalar v1,scalar *v2)
    /* Returns a copy of scalar v1. If v2!=NULL then v1 is copied to *v2
    and *v2 returned.
    $A Igor maj98; */
{
scalar v;
if (v2!=NULL)
{
  /* If v2!=NULL then v1 is copied to *v2: */
  if (v1==NULL)
  {
    disppointer((void **) v2);
  } else
  {
    /* If *v2==NULL, we allocate *v2: */
    if (*v2==NULL)
      *v2=malloc(sizeof(**v2));
    v=*v2;
    /* Value copying: */
    *v=*v1;
  }
  return *v2; /* Since v2 was not NULL, *v2 is returned. */
} else
{
  /* v2==NULL, we make a new scalar that is a copy of v1, its pointer is
  returned after copying contents: */
  if (v1==NULL)
    return NULL;
  else
  {
    v=malloc(sizeof(*v));
    *v=*v1;
    return v;
  }
}
}


static int /* outdig=8, */   /* St. dec. mest pri izpisovanju stevil */
           outchar=1;  /* Min. st. mest pri izpisovanju stevil */

int vecgetoutdig(void)
    /* Vrne stevilo decimalnih mest pri izpisovanju stevil v modulu vec.c.
    $A Igor mar99; */
{
return m_outdig;
}

int vecgetoutchar(void)
    /* Vrne najmanjse stevilo mest pri izpisovanju stevil v modulu vec.c.
    $A Igor mar99; */
{
return outchar;
}

void vecsetoutdig(int num)
    /* Postavi stevilo decimalnih mest pri izpisovanju stevil v modulu vec.c.
    $A Igor mar99; */
{
if (m_outdig>0)
  m_outdig=num;
}

void vecsetoutchar(int num)
    /* Postavi najmanjse stevilo mest pri izpisovanju stevil v modulu vec.c.
    $A Igor mar99; */
{
if (outchar>0)
  outchar=num;
}



/*
typedef struct{
          int d;
          double * v;
        } struct _vector;
*/


void getvec(vector vec, int n)
     /* Naredi vektor dimenzije n. */
{
vec->d=n;
vec->v=calloc(n,sizeof(double));
-- (vec->v);
}


void dispvec(vector vec)
     /* Sprosti spomin, na katerega kaze vec.v, postavi
        vec.v in vec.d na 0 */
{
double *p;
if (vec->d>0 && vec->v!=NULL)
{
  p=vec->v;
  ++p;
  free(p);
}
/*  free(++(vec->v)); */
vec->d=0;
vec->v=NULL;
}



void initvec(vector  vec)
{
  vec->d=0;
  vec->v=NULL;
}



vector getvector(int dim)
       /* Rezervira spomin za vektor z dim elementi in vrne kazalec na ta
       prostor. */
{
vector v;
v=malloc(sizeof(*v));
getvec(v,dim);
return v;
}


vector resizevector(vector *addrv,int dim)
    /* Resizes a vector pointed to by addrv so that its new dimension is dim.
    All components of an old vector that fit in the new one are preserved. If
    addrv=NULL then vector is created and returned. If dim=0 then vector is
    set to NULL.
    $A Igor nov03; */
{
vector old,ret;
int i;
if (addrv!=NULL)
  old=*addrv;
else
  old=NULL;
if (old==NULL)
{
  if (dim>0)
    ret=getvector(dim);
  else
    ret=NULL;
} else
{
  if (dim<=0)
  {
    dispvector(&old);
    ret=NULL;
  } else if (dim==old->d)
  {
    ret=old;
  } else
  {
    ret=getvector(dim);
    for (i=1;i<=old->d && i<=ret->d;++i)
      ret->v[i]=old->v[i];
    dispvector(&old);
  }
}
if (addrv!=NULL)
  *addrv=ret;
return ret;
}




vector vectorcopy(vector v)
    /* Vrne kopijo vektorja v.
    $A Igor okt97; */
{
vector ret=NULL;
if (v!=NULL)
{
  ret=getvector(v->d);
  if (v->d>0)
  {
    int i;
    for (i=1;i<=v->d;++i)
      ret->v[i]=v->v[i];
  }
}
return ret;
}


void dispvector(vector *vec)
     /* Zbrise vektor *vec z vsebino vred in njegovo vrednost postavi na
     NULL. */
{
vector v;
if (vec!=NULL)
{
  if ((v=*vec)!=NULL)
  {
    dispvec(v);
    free(v);
    *vec=NULL;
  }
}
}


int cmpvecfirstcomp(const vector vec1,const vector vec2)
    /* Compares vectors vec1 and vec2 by the first component that is not equal
    if they are of the same dimension, or by dimension if they are not of the 
    same dimension, or vector which is NULL is consider smaller.
      Returns 0 if vectors are equal, -1 if the first vector is smaller than
    the second one and 1 if the first vector is larger than the second one
    according to this criterium.
      This function can be used for checking whether two vectors are equal or
    for sorting & searcing of vectors or vector parts of structures.
    $A Igor apr05; */
{
if (vec1==NULL)
{
  if (vec2==NULL)
    return 0;
  else
    return -1;
} else if (vec2==NULL)
  return 1;
else if (vec1->d<vec2->d)
  return -1;
else if (vec1->d>vec2->d)
  return 1;
else
{
  int i;
  for (i=1;i<=vec1->d;++i)
  {
    if (vec1->v[i]<vec2->v[i])
      return -1;
    else if (vec1->v[i]>vec2->v[i])
      return 1;
  }
  return 0;
}
}


vector copytabletovector(double *x,int dim,vector *vec)
    /* Tabela dim stevil dipa double *x se prepise v vektor *vec. Ce je
    dim enak 0 ali ce je x enak NULL, postane *vec enak NULL. Funkcija
    vektor, ki je nastal s prepisom, tudi vrne.
      Ce je argument vec, ki je naslov ciljnega vektorja, enak NULL, se vektor,
    v katerega se prepise tabela in ki ga funkcija vrne, tvori na novo.
    Dimenzija vektorja, v katerega se prepise tabela, je po operaciji enaka
    dim.
      POZOR:
    x mora kazati na 1. element tabele. To pomeni, da se na 1. element
    sklicujemo z x[0] in ne z x[1].
    $A Igor jul98; */
{
vector ret=NULL;
int i;
if (dim>0 && x!=NULL)
{
  /* Ce sta x in dim, ki podajata tabelo, ustrezna, se tabela prepise v *vec,
  ki ga funkcija tudi vrne; Ce je vec enak NULL, se na novo tvori vektor, ki
  ga funkcija vrne, tabela se prepise v ta vektor: */
  if (vec==NULL)
  {
    /* Ce je vec (naslov ciljnega vektorja) enak NULL, se tvori nov vektor
    ustrezne dimenzije in se priredi vektorju, ki ga funkcija vrne: */
    ret=getvector(dim);
    vec=&ret;  /* zato, da nadalje ni treba operirati nad vektorjem ret */
  } else
  {
    resizevector(vec,dim);
    ret=*vec;
  }
  /*
  if (*vec==NULL)
    *vec=getvector(dim);
  else if ((*vec)->d!=dim)
  {
    /* Ce vektor *vec obstaja, a ni ustrezne dimenzije, se zbrise in tvori na
    novo, po tem moramo vektor, ki se vrne, znova postaviti na *vec: *
    dispvector(vec);
    *vec=getvector(dim);
    ret=*vec;
  }
  */
  /* Prepisovanje komponent: */
  for (i=1;i<=dim;++i)
    ret->v[i]=x[i-1];
} else 
{
  /* Ce x in dim, ki podajata tabelo, nista ustrezna, se *vec zbrise in vrne NULL: */
  if (vec!=NULL)
    dispvector(vec);
}
return ret;
}

int copyvectortotable(vector v,double **x,int *dim)
    /* Vektor v se prepise v tabelo stevil tipa double, katere nasov je x.
    Ce je v enak NULL ali je njegova dimenzija (v->d) enaka 0 ali je x enak
    NULL, se ne zgodi nic. Ce je dim razlicen od NULL, je z *dim podana
    resnicna dimenzija tabele oz. alociranega prostora. V tem primeru se
    preveri, ce je alociranega prostora dovolj in ce ga ni, se *x zbrise in
    alocira na novo, v *dim pa se zapise dimenzija vektorja. *x se alocira na
    novo tudi, ce je enak NULL. Funkcija vrne stevilo prepisanih komponent
    (ki je lahko samo 0 ali v->d).
      POZOR:
    *x mora kazati na 1. element tabele, na katerega se torej sklicujemo z
    (*x)[0] in ne z (*x)[1].
    $A Igor jul98; */
{
int ret=0,i;
if (dim!=NULL)
  *dim=0;
if (x!=NULL && v!=NULL)
  if (v->d>0)
  {
    if (dim!=NULL)
    {
      if (*dim<v->d && *x!=NULL)
      {
        free(*x);
        *x=NULL;
      }
      *dim=v->d;
    } else  /* dim==NULL */
    {
      if (*x!=NULL)
      {
        free(*x);
        *x=NULL;
      }
    }
    if (*x==NULL)
      *x=malloc(v->d*sizeof(**x));
    /* Prepisovanje komponent: */
    for (i=1;i<=v->d;++i)
    {
      (*x)[i-1]=v->v[i];
      ++ret;
    }
  }
return ret;
}


void copyvec(vector v1, vector v2)
     /* Vektor v2 prepise na vektor v1. v1 mora biti
        inicializiran na 0. */
{
int i;
if (v1->d!=0 && v1->v!=0)
  dispvec(v1);
getvec(v1,v2->d);
for (i=1; i<=v2->d; ++i)
  v1->v[i]=v2->v[i];
v1->d=v2->d;
}



vector copyvector(vector v1,vector *v2)
    /* Returns a copy of the vector v1. If v2 is different than NULL then v1
    is copied to *v2 and *v2 returned. v2 can be address of v1.
    $A Igor mar98; */
{
vector v;
int i;
if (v2!=NULL)
{
  /* Ce je v2!=NULL, se v1 skopira v *v2: */
  if (v1==NULL)
  {
    dispvector(v2);
  } else
  {
    /* Preverimo dimenzijo *v2, ce ni ustrezna, zbrisemo *v2: */
    if (*v2!=NULL)
      if ((*v2)->d!=v1->d)
        dispvector(v2);
    /* Ce je *v2==NULL, tvorimo *v2 z dimenzijo v1: */
    if (*v2==NULL)
      *v2=getvector(v1->d);
    v=*v2;
    /* Kopiranje vrednosti: */
    if (v1->d>0)
      for (i=1;i<=v1->d;++i)
        v->v[i]=v1->v[i];
  }
  return *v2; /* Ker je bil v2!=NULL, se vrne *v2. */
} else
{
  /* v2==NULL, naredi se nov vektor, ki je kopija v1, vrne se njegov kazalec: */
  if (v1==NULL)
    return NULL;
  else
  {
    v=getvector(v1->d);
    if (v1->d>0)
      for (i=1;i<=v1->d;++i)
        v->v[i]=v1->v[i];
    return v;
  }
}
}




vector vectorsum0(vector v1,vector v2,vector *v3)
    /* Vrne vsoto vektorjev v1 in v2. Ce je v3 razlicen od NULL, zapise rezultat
    v *v3 in vrne *v3.
    $A Igor mar98; */
{
vector v;
int i;
if (v3!=NULL)
{
  /* Ce je *v3!=NULL, se rezultat shrane v *v3: */
  if (v1==NULL || v2==NULL)
    dispvector(v3);
  else if (v1->d!=v2->d || v1->d<1)
    dispvector(v3);
  else
  {
    /* Preverimo dimenzijo *v3, ce ni ustrezna, zbrisemo *v3: */
    if (*v3!=NULL)
      if ((*v3)->d!=v1->d)
        dispvector(v3);
    /* Ce je *v3==NULL, tvorimo *v3 z dimenzijo v1: */
    if (*v3==NULL)
      *v3=getvector(v1->d);
    v=*v3;
    /* Izvedba operacije: */
    for (i=1;i<=v1->d;++i)
      v->v[i]=v1->v[i]+v2->v[i];
  }
  return *v3; /* Ker je bil v3!=NULL, se vrne *v3. */
} else
{
  /* v3==NULL, naredi se nov vektor, ki je vsota v1 in v2, vrne se njegov
  kazalec: */
  
  if (v1==NULL || v2==NULL)
    return NULL;
  else if (v1->d!=v2->d || v1->d<1)
    return NULL;
  else
  {
    v=getvector(v1->d);
    /* Izvedba operacije: */
    for (i=1;i<=v1->d;++i)
      v->v[i]=v1->v[i]+v2->v[i];
    return v;
  }
}
}


vector vectordif0(vector v1,vector v2,vector *v3)
    /* Vrne razliko vektorjev v1 in v2. Ce je v3 razlicen od NULL, zapise rezultat
    v *v3 in vrne *v3.
    $A Igor mar99; */
{
vector v;
int i;
if (v3!=NULL)
{
  /* Ce je *v3!=NULL, se rezultat shrane v *v3: */
  if (v1==NULL || v2==NULL)
    dispvector(v3);
  else if (v1->d!=v2->d || v1->d<1)
    dispvector(v3);
  else
  {
    /* Preverimo dimenzijo *v3, ce ni ustrezna, zbrisemo *v3: */
    if (*v3!=NULL)
      if ((*v3)->d!=v1->d)
        dispvector(v3);
    /* Ce je *v3==NULL, tvorimo *v3 z dimenzijo v1: */
    if (*v3==NULL)
      *v3=getvector(v1->d);
    v=*v3;
    /* Izvedba operacije: */
    for (i=1;i<=v1->d;++i)
      v->v[i]=v1->v[i]-v2->v[i];
  }
  return *v3; /* Ker je bil v3!=NULL, se vrne *v3. */
} else
{
  /* v3==NULL, naredi se nov vektor, ki je vsota v1 in v2, vrne se njegov
  kazalec: */
  
  if (v1==NULL || v2==NULL)
    return NULL;
  else if (v1->d!=v2->d || v1->d<1)
    return NULL;
  else
  {
    v=getvector(v1->d);
    /* Izvedba operacije: */
    for (i=1;i<=v1->d;++i)
      v->v[i]=v1->v[i]-v2->v[i];
    return v;
  }
}
}

vector movevector0(vector *v1,vector *v2)
    /* Premakne *v1 v *v2 in vrne *v2. Po izvedbi je vedno *v1==NULL. Ce je
    v2==NULL, samo vrne *v1 (ce je v1==NULL, vrne NULL).
    $A Igor mar98; */
{
vector v;
if (v1!=NULL)
{
  if (v2!=NULL)
  {
    /* Ce je v2!=NULL, se *v1 premakne v *v2: */
    dispvector(v2);
    *v2=*v1;
    *v1=NULL;
    return *v2;
  } else
  {
    v=*v1;
    *v1=NULL;
    return v;
  }
} else
{
  /* Ce je v1 NULL, se zbrise v2 in vrne NULL. */
  if (v2!=NULL)
    dispvector(v2);
  return NULL;
}
}



void fprintvec(FILE *fp,struct _vector v)
     /* Izpise vsebino vektorja v datoteko fp. */
{
int i;
if (fp!=NULL)
{
  if (v.d!=0 && v.v!=0)
  {
    fprintf(fp,"Dimension: %i\n",v.d);
    fprintf(fp,"Components:\n");
    for (i=1; i<=v.d; ++i)
      fprintf(fp,"v[%i]=%-*.*g\n",i,outchar,m_outdig,v.v[i]);
  }
}
}




void printvec(struct _vector v)
     /* Izpise vsebino vektorja na zaslon */
{
int i;
if (v.d!=0 && v.v!=0)
{
  printf("Dimension: %i\n",v.d);
  printf("Components:\n");
  for (i=1; i<=v.d; ++i)
    printf("v[%i]=%-*.*g\n",i,outchar,m_outdig,v.v[i]);
}
}



void fprintvector(FILE *fp,vector vec)
     /* Izpise vsebino vektorja vec v datoteko fp. */
{
if (fp!=NULL)
{
  if (vec==NULL)
    fprintf(fp,"NULL\n");
  else
    fprintvec(fp,*vec);
}
}



void printvector(vector vec)
     /* Izpise vsebino vektorja vec na zaslon. */
{
fprintvector(stdout,vec);
}




void fprintvecname(FILE *fp,struct _vector v, char *name)
     /* Izpise vsebino vektorja na datoteko fp. Ime vektorja je name. */
{
int i;
if (fp!=NULL)
{
  if (v.d!=0 && v.v!=0)
  {
    fprintf(fp,"Dimension: %i\n",v.d);
    fprintf(fp,"Components:\n");
    for (i=1; i<=v.d; ++i)
      fprintf(fp,"%s[%i]=%-*.*g\n",name,i,outchar,m_outdig,v.v[i]);
  }
}
}


void printvecname(struct _vector v,char *name)
     /* Izpise vsebino vektorja na zaslon. Ime vektorja je name. */
{
fprintvecname(stdout,v,name);
}


void fprintvectorname(FILE *fp,vector v,char *name)
     /* Izpise vsebino vektorja na datoteko fp. Ime vektorja je name. */
{
if (fp!=NULL)
{
  if (v==NULL)
    fprintf(fp,"%s = NULL\n",name);
  else
    fprintvecname(fp,*v,name);
}
}


void printvectorname(vector v,char *name)
     /* Izpise vsebino vektorja na zaslon. Ime vektorja je name. */
{
fprintvectorname(stdout,v,name);
}


void fprintvectorline(FILE *fp,vector vec)
    /* Izpise vektor vec v datoteko fp. Vse komponente izpise v eni vrstici.
    $A Igor sep97; */
{
int i;
if (fp!=NULL)
{
  if (vec==NULL)
    fprintf(fp,"NULL VECTOR.\n");
  else if (vec->d>0)
  {
    for (i=1;i<=vec->d;++i)
    {
      fprintf(fp,"v[%i]=%-*.*g",i,outchar,m_outdig,vec->v[i]);
      if (i<vec->d)
        fprintf(fp,", ");
      else
        fprintf(fp,"\n");
    }
  } else fprintf(fp,"EMPTY VECTOR.\n");
}
}

void printvectorline(vector vec)
    /* Izpise vektor vec na stand. izhod. Vse komponente izpise v eni vrstici.
    $A Igor sep97; */
{
fprintvectorline(stdout,vec);
}


void fprintvectorlist(FILE *fp,vector vec)
    /* Prints vector vec to fp in a list form as used by Mathematica.
    $A Igor nov03; */
{
int i;
if (fp!=NULL)
{
  fprintf(fp,"{");
  if (vec!=NULL) if (vec->d>0)
  {
    for (i=1;i<vec->d;++i)
      /*
      fprintf(fp,"%5g, ",vec->v[i]);
      */
      fprintf(fp,"%.*g, ",m_outdig,vec->v[i]);
    /*
    fprintf(fp,"%5g",vec->v[i]);
    */
    fprintf(fp,"%.*g",m_outdig,vec->v[i]);
  }
  fprintf(fp,"}");
}
}

void printvectorlist(vector vec)
    /* Prints vector vec to stand. output in a list form as used by Mathematica.
    $A Igor nov03; */
{
fprintvectorlist(stdout,vec);
}

void readvec(vector v)
     /* Prebere vektor */
{
int i;
if (v->d!=0 && v->v!=0)
  dispvec(v);
printf("Dimension: "); scanf("%i",&(v->d));
getvec(v,v->d);
for (i=1; i<=v->d; ++i)
{
  printf("v[%i]: ",i); scanf("%lg",&(v->v[i]));
}
}




void fwritevec(char *filename, struct _vector v)
     /* Zapise komponente vektorja v datoteko z imenom filename.
        Prvotna datoteka se prepise (ce je obstajala). */
{
FILE *f;
int i;
f=fopen(filename,"wb");
if (f!=NULL)
{
  if (v.d!=0 && v.v!=0)
  {
    for (i=1; i<=v.d; ++i)
      fprintf(f,"%-*.*g\n",outchar,m_outdig,v.v[i]);
  }
  fclose(f);
}
}



int freadvec(char *filename, vector v)
     /* Prebere vektor v iz datoteke z imenom filename.
        V datoteki morajo biti po vrsti zapisane samo komponente
        vektorja. Vrne dimenzijo vektorja. */
{
int i,num;
double x;
FILE *tempfile;
if (v->d!=0 && v->v!=0)
  dispvec(v);
tempfile=fopen(filename,"rb");
rewind(tempfile);
num=0;
while (fscanf(tempfile,"%lg",&x)>0)
  ++ num;
getvec(v,num);
rewind(tempfile);
for (i=1; i<=num; ++i)
  fscanf(tempfile,"%lg",&(v->v[i]));
fclose(tempfile);
return(num);
}





void normvec1(vector vec)
             /* Normira vektor vec */
{
int i;
double norm, norm2=0;
if (vec->d>0 && vec->v!=NULL)
{
  for (i=1; i<=vec->d; ++i)
    norm2+=vec->v[i]*vec->v[i];
  norm=sqrt(norm2);
  if (norm>0) for (i=1; i<=vec->d; ++i)
    vec->v[i]/=norm;
}
}




struct _vector timesvec(struct _vector v, double t)
       /* Vrne produkt vektorja v s stevilom t */
{
int i;
struct _vector vret;
if (v.d!=0 && v.v!=NULL)
{
  getvec(&vret, v.d);
  for (i=1; i<=v.d; ++i)
    vret.v[i]=v.v[i]*t;
} else initvec(&vret);
return vret;
}



struct _vector sumvec(struct _vector v1, struct _vector v2)
       /* Vrne vsoto vektorjev v1 in v2. */
{
int i;
struct _vector vret;
if (v1.d!=0 && v1.d==v2.d && v1.v!=NULL && v2.v!=NULL)
{
  getvec(&vret, v1.d);
  for (i=1; i<=v1.d; ++i)
    vret.v[i]=v1.v[i]+v2.v[i];
} else initvec(&vret);
return vret;
}



struct _vector difvec(struct _vector v1, struct _vector v2)
       /* Vrne razliko vektorjev v1 in v2. (v1-v2) */
{
int i;
struct _vector vret;
if (v1.d!=0 && v1.d==v2.d && v1.v!=NULL && v2.v!=NULL)
{
  getvec(&vret, v1.d);
  for (i=1; i<=v1.d; ++i)
    vret.v[i]=v1.v[i]-v2.v[i];
} else initvec(&vret);
return vret;
}
























































