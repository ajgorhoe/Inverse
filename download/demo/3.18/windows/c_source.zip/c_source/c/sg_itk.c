
          /**************************************/
          /*   SGS PLOTTING INTERFACE FOR ITK   */
          /**************************************/



# include <stddef.h>
# include <stdio.h>
# include <stdlib.h>

#include <sysint.h>
# include <strop.h>
# include <rf.h>
# include <er.h>
# include <itk.h>
#include <gro.h>

#include <sg_obj.h>
#include <sg_draw.h>
#include <sg_ploto.h>
#include <sg_obj.h>

#include <sg_intfc.h>



typedef struct {
  int id;         /* SGS ID */
  sg_window base; /* pointer to base structure containing general data */
  char *tkid;     /* Tk's window name */
  char *forcewin; /* potential existing window that will be used */
  /* Fields used by the file interface: */
  char *file;     /* name of the output file */
  FILE *fp;
  
} _itk_windata;

typedef _itk_windata *itk_windata;



typedef struct {
  int id;            /* SGS ID */
  sg_font base;      /* pointer to base structure containing general data */
  char *tkid;        /* Tk font name */
  char *inststr;     /* installation string for the font in Tk */
  char installeditk; /* indicates whether the font has been installed in the
        ITK interp. */
  /* The following indicates the windows in which the font has already been
  installed: */
  indtab filewins;
} _itk_fontdata;

typedef _itk_fontdata *itk_fontdata;

itk_windata newitk_windata(void)
    /* Creates a new object of the type itk_windata.
    $A Igor sep03; */
{
itk_windata ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
return ret;
}


void dispitk_windata(itk_windata *addr)
    /* Deallocates an object pointet to by addr and sets *addr to NULL.
    $A Igor sep03; */
{
itk_windata data;
if (addr!=NULL)
{
  data=*addr;
  if (data!=NULL)
  {
    if (data->tkid!=NULL)
      free(data->tkid);
    if (data->forcewin!=NULL)
      free(data->forcewin);
    if (data->file!=NULL)
      free(data->file);
    if (data->fp!=NULL)
    {
      fclose(data->fp);
      data->fp=NULL;
    }
  }
  free(data);
  *addr=NULL;
}
}

itk_fontdata newitk_fontdata(void)
    /* Creates a new object of the type itk_fontdata.
    $A Igor sep03; */
{
itk_fontdata ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
return ret;
}


void dispitk_fontdata(itk_fontdata *addr)
    /* Deallocates an object pointet to by addr and sets *addr to NULL.
    $A Igor sep03; */
{
itk_fontdata data;
if (addr!=NULL)
{
  data=*addr;
  if (data!=NULL)
  {
    if (data->tkid!=NULL)
      free(data->tkid);
    if (data->inststr!=NULL)
      free(data->inststr);
    if (data->filewins!=NULL)
      dispindtab(&(data->filewins));
  }
  free(data);
  *addr=NULL;
}
}




/* General options and data: */

/* Execution flag - determines how the Tcl Commands are executed.
  0: direct execution via itk_sendcomcp
  1: prints commands into a file.
  */
static char exflag=0;
static char *combuf=NULL;     /* Command buffer */
static int combuflength=1000;  /* Size of the command buffer, should be enough to store
                       any command */
static int drawtofile=0;  /* specifies whether to draw to a file (to create Tcl
    interpretable files) */
static FILE *outfile=NULL;



/* FOR DEVELOPERS:
There is an ambiguitiy related to functions like sg_itk_setwindowidth() and
sg_itk_getwindowwidth(). Functions with the prefic sg_itk_set set the size for windows
that will be open, while functions with the prefix get return the size of the
current window. This ambiguity must be resolved in such a way that the complete
functionality is preserved. 
*/


static int locitkwin=0;  /* Current window ID for the Tcl and ITK interface */

/* static int loctclwin=0;   Current window ID for the Tcl interface */

static char *locwindowstr=NULL; /* Tk string ID for the current window */
static char *locforcewin=NULL;  /* Forces particular window to be used by the
            sg_itk_openwindow() - string is not deleted in the module! */
static char *locitkwinprefix=".itk_sgs_win_";

static char *loccursor=NULL;  /* Stores initial shape of the cursor for the canvas */

static _coord3d p1,p2,p3,p4,p5;  /* Auxiliary variables for coord. transf. */




/* Common parameters that are shared for all graphics: */

/* screen graphics: */


/* Color handling for screen graphics - enables to handle problems where images
contain too many different colors to fit in the color table. It has not yet
been decided whether color restrictions should (such as gray scale and coarse
divisions of shades) should be taken into account while printing to files.
*/
static char loclinecolor[8], locfillcolor[8], loctextcolor[8];


static char *loctextanchor="center";
static char *loctextfontstr="times";

/*
static float shartextprecision=(float) 0.01f;
static float shartextspacing=0.0f;
static float shartextexpansion=1.0f;
*/



static stack plotst=NULL;
static /* Tcl_Interp */ void *itkinterp;
static int directitk=0;

static void sg_itk_godrawstack(stack st);


#ifdef ITK

static int itkplotcmd(ClientData clientData, Tcl_Interp *interp,
       int argc,const char *argv[])
    /* Function for the Tcl command installed in the ITK interpreter, which
    plots the SGS graphics stacks by passing commands directly to the
    interprter. This can be done because the function is executed by the
    same thread in which the interpreter was created. Such plotting is much
    quicker because there are no delays due to synchronization of threads.
    $A Igor jul03; */
{
itkinterp=interp;
directitk=1;
sg_itk_godrawstack(plotst);
tcl_processallevents(); /* Block until window is actually redrawn */
directitk=0;
return TCL_OK;
}

#endif


static void initgritk(void)
    /* Initialisation of the ITK plotting interface */
{
static int itkinitialized=0;
if (combuf==NULL)
{
  combuf=malloc(1+combuflength);
  *combuf='\0';
}
if (!itkinitialized && !drawtofile)
{
  #ifndef ITK
    errfunc0("initgritk");
    sprintf(ers(),"ITK is not present.\n");
    sprintf(ers(),"Only the Tcl file plotting interface is available.\n");
    errfunc2();
  #else
    itkinitialized=1;
    /* Install the plotting procedure: */
    itk_initialize();
    itk_lockinterp();
    Tcl_CreateCommand(itk_interp(), "itk_sgs_plot",itkplotcmd,(ClientData) NULL,
                      (Tcl_CmdDeleteProc *) NULL);
    itk_unlockinterp();
  #endif
}
}



static int itkerrorreported=0;


static void runbufblock(void)
    /* Executes the command buffer and sets the writing position to the
    beginning of the buffer. $A Igor jul03; */
{
char *res=NULL;
int code=0;
static int reported=0;
/* Check for possible buffer overflow: */
if ((int) strlen(combuf)>=combuflength)
{
  int i;
  errfunc0("runbufblock");
  sprintf(ers(),"Command length (%i) is greater than buffer length %i.\n",
    strlen(combuf),combuflength);
  sprintf(ers(),"Beginning of the command:\n");
  for (i=0;i<80;++i)
    *ers()=combuf[i];
  sprintf(ers(),"\n");
  errfunc2();
}
if (drawtofile)
{
  if (outfile==NULL)
  {
    errfunc0("runbufblock");
    sprintf(ers(),"Tcl output file is not open.\n");
    errfunc2();
  } else
  {
    fprintf(outfile,"%s",combuf);
    /* fflush(outfile); */
  }
} else if (directitk)
{
  #ifndef ITK
    if (!reported)
    {
      errfunc0("runbufblock");
      sprintf(ers(),"ITK is not present.\n");
      sprintf(ers(),"Only the Tcl file plotting interface is available.\n");
      sprintf(ers(),"Further messages of this type will be suppressed.\n");
      errfunc2();
      ++ reported;
    }
  #else
    /* When this command is called in the thread of the ITK's Tcl interpreter,
    the commands can be passed directly to the interpreter: */
    Tcl_Eval(itkinterp,combuf);
  #endif
  *combuf='\0';
} else
{
  #ifndef ITK
    if (!reported)
    {
      errfunc0("runbufblock");
      sprintf(ers(),"ITK is not present.\n");
      sprintf(ers(),"Only the Tcl file plotting interface is available.\n");
      sprintf(ers(),"Further messages of this type will be suppressed.\n");
      errfunc2();
      ++ reported;
    }
  #else  /* not defined ITK */
    res=itk_interpretcp(combuf,&code);
    if (!tcl_okcode(code) && !itkerrorreported)
    {
      itkerrorreported=1;
      errfunc0("runbufblock");
      sprintf(ers(),"SGS - ITK error. Tcl error report:\n");
      checkminerbuf(stringlength(res));
      sprintf(ers(),"%s",res);
      errfunc2();
    }
    disppointer((void **) &res);
  #endif  /* defined(ITK) */
  *combuf='\0';
}
}




static void runbuf(void)
    /* Executes the command buffer and sets the writing position to the
    beginning of the buffer. $A Igor jul03; */
{
static int num=0;
static int reported=0;
/* Check for possible buffer overflow: */
if ((int) strlen(combuf)>=combuflength)
{
  int i;
  errfunc0("runbuf");
  sprintf(ers(),"Command length (%i) is greater than buffer length %i.\n",
    strlen(combuf),combuflength);
  sprintf(ers(),"Beginning of the command:\n");
  for (i=0;i<80;++i)
    *ers()=combuf[i];
  sprintf(ers(),"\n");
  errfunc2();
}
if (drawtofile)
{
  if (outfile==NULL)
  {
    errfunc0("runbuf");
    sprintf(ers(),"Tcl output file is not open.\n");
    errfunc2();
  } else
  {
    fprintf(outfile,"%s",combuf);
    /* fflush(outfile); */
  }
} else if (directitk)
{
  #ifndef ITK
    if (!reported)
    {
      errfunc0("runbuf");
      sprintf(ers(),"ITK is not present.\n");
      sprintf(ers(),"Only the Tcl file plotting interface is available.\n");
      sprintf(ers(),"Further messages of this type will be suppressed.\n");
      errfunc2();
      ++ reported;
    }
  #else
    /* When this command is called in the thread of the ITK's Tcl interpreter,
    the commands can be passed directly to the interpreter: */
    Tcl_Eval(itkinterp,combuf);
  #endif
  *combuf='\0';
} else
{
  #ifndef ITK
    if (!reported)
    {
      errfunc0("runbuf");
      sprintf(ers(),"ITK is not present.\n");
      sprintf(ers(),"Only the Tcl file plotting interface is available.\n");
      sprintf(ers(),"Further messages of this type will be suppressed.\n");
      errfunc2();
      ++ reported;
    }
  #else
    if (exflag==0)
      itk_sendcomcp(combuf);
  #endif
  *combuf='\0';
}
if (!drawtofile)
{
  ++num;
  if (num>=100)
  {
    /* Process events between draving to enable window handling */
    #ifdef ITK
      tcl_processquickevents();
    #endif
    num=0;
  }
}
}



static int godrawstackitk(stack st)
    /* Arranges that the stack of graphic objects is drawn in the same thread
    as the ITK's Tcl interpreter was created, in order to eliminate delays due
    to sinchronization of threads and speed up interpretation.
    $A Igor jul03; */
{
char *com=NULL,*res=NULL,*ptr=NULL;
int code=0;
static int reported=0,reccount=0;
++reccount;
if (reccount>1 || drawtofile)
{
  --reccount;
  return 0;
} else
{  
  #ifndef ITK
    if (!reported)
    {
      errfunc0("godrawstackitk");
      sprintf(ers(),"ITK is not present.\n");
      sprintf(ers(),"Only the Tcl file plotting interface is available.\n");
      sprintf(ers(),"Further messages of this type will be suppressed.\n");
      errfunc2();
      ++ reported;
    }
  #else
    /* The following line will check if the Tk window that corresponds to the
    current window still exists, and if not, it will be re-created: */
    /*
    int savedirectitk=directitk;
    directitk=0;
    sg_itk_setwindow(locitkwin);
    directitk=savedirectitk;
    */
    plotst=st;
    com=malloc(1000);
    ptr=com;
    if (loccursor!=NULL)
      /* to set cursor to indicate that the window is busy */
      ptr+=sprintf(ptr,"catch {%s configure -cursor %s } ;\n",locwindowstr,"watch");
    ptr+=sprintf(ptr,"itk_sgs_plot ;\n "); /* to invoke plotting command */
    res=itk_interpretcp(com,&code);
    disppointer((void **) &res);
    ptr=com;
    if (loccursor!=NULL)
      /* to restore window's cursor to the initial state */
      ptr+=sprintf(ptr,"%s configure -cursor {%s} ;",locwindowstr,loccursor);
    itk_sendcomcp(com);
    disppointer((void **) &com);
  #endif
}
--reccount;
return 1;
}



static void xxx_tclinaturalwindowcoord(float x,float y,coord3d p)
    /* Pri transformaciji koordinat objektov v njihove okenske koordinate
    se pusti kar naravne koordinate.
    $A Igor apr97; */
{
p->x=x; p->y; p->z=0;
}


static void xxx_tcligpwindowcoord(float x,float y,coord3d p)
    /* Normalni okenski koordinati (ki gresta v obeh smereh od 0 do 1 s
    koordinatnim izhodiscem v spodnjem levem kotu) se pretvorita v okenski
    koordinati za format Tcl.
    $A Igor apr97; */
{
/* $$$ TO BE IMPLEMENTED! */
/*
p->x=tclistartx+x*tclisizex;
p->y=tclistarty+y*tclisizey;
p->z=0;
*/
}



/*
*/


/* FOR DEVELOPERS: 
TAKE CARE OF THESE FUNCTIONS! */

static void xxx_tclisetscaling(char scaling)
    /* Doloci skaliranje koordinat pri zapisu graficnih objektov v formatu Tcl.
    ce je scaling==0, postane funkcija tcliwindowcoord() za skaliranje koordinat
    kar funkcija tclinaturalwindowcoord(), ki ohranja naravne koordinate objektov,
    drugace pa to postane funkcija tcligpwindowcoord(), ki skalira koordinati x
    in y tako, kot se to naredi pri risanju na zaslon, koordinato z pa poskusa
    skalirati na podoben nacin.
    $A Igor <== apr97; */
{
/*
tcliscalecoordinates=scaling;
if (tcliscalecoordinates==0)
  tcliwindowcoord=tclinaturalwindowcoord;
else tcliwindowcoord=tcligpwindowcoord;
*/
}




static void xxx_tclsetwindowsize(int width,int height)
    /* Postavi sirino tcl-ovega okna, v katerem se izrise graf iz tcl-ove
    datoteke, na width, in visino na height. Ce je eden ali drugi 0, se
    ohranita dimenziji, ki sta trenutno nastavljeni.
    $A Igor maj01; */
{
  /*
if (width>0)
{
  tclwindowwidth=width;
  tclisizex=tclwindowwidth;
}
if (height>0)
{
  tclwindowheight=height;
  tclistarty=tclwindowheight;
  tclisizey=-tclwindowheight;
}
*/
}


static void xxx_tclisetwindowsize(double width,double height)
    /* Postavi sirino tcl-ovega okna, v katerem se izrise graf iz tcl-ove
    datoteke,xxx_ na width, in visino na height. Ce je eden ali drugi 0, se
    ohranita dimenziji, ki sta trenutno nastavljeni.
    $A Igor maj01; */
{
/*
if (width>0)
{
  tclwindowwidth=(int) width;
  tclisizex=tclwindowwidth;
}
if (height>0)
{
  tclwindowheight=(int) height;
  tclistarty=tclwindowheight;
  tclisizey=-tclwindowheight;
}
*/
}


static double xxx_tcligetwindowwidth(void)
    /* Vrne sirino trenutnega Tcl-ovega okna oz. skalirni faktor v smeri x.
    $A Igor maj01; */
{
/*
return fabs(tclisizex);
*/
}

static double xxx_tcligetwindowheight(void)
    /* Vrne visino trenutnega Tcl-ovega okna oz. skalirni faktor v smeri y.
    $A Igor maj01; */
{
/*
return fabs(tclisizey);
*/
}




#if 0

static itkwin newitkwin(void)
    /* Allocates an empty itkwin structure and returns its pointer.
    $A Igor jul03; */
{
itkwin itkw;
itkw=malloc(sizeof(*itkw));
memset(itkw,0,sizeof(*itkw));
return itkw;
}

static void dispitkwin(itkwin *wp)
    /* Deletes a dynamically allocated structure *wp and sets *wp to NULL.
    $A Igor jul03; */
{
itkwin itkw;
if ((itkw=*wp)!=NULL)
{
  disppointer((void *) &itkw->tkid);
  disppointer((void *) &itkw->forcewin);
  disppointer((void *) &itkw->windowtitle);
}
*wp=NULL;
}

#endif




int sg_itk_initdisplay(void)
{
return 1;
}

int sg_itk_initgraph(void)
{
return 1;
}


/* WARNING for programmers:
  When a window is closed, its ID can be used by another window that is opened
after that. This can make some errors more difficult to find, for example
operations on a window that has been closed already may become well defined
for a program just because some other window newly opened after this window
has been closed reused its ID. */



static void itkgiwindowcoord (float x,float y,coord3d p)
{
p->x=x*sg_iwindowwidth;
p->y=sg_iwindowheight*(1-y);
p->z=0;
}





static int sg_itk_setwindow(int id);

static int sg_itk_openwindow(void)
    /* Opens a new window, which also becomes the current plotting window of
    SGS. Returns the identification number of the opened whindow, through
    which the window can be accessed e.g. for closing, clearing, activating,
    etc.
      sg_windowwidth, sg_windowheight, sg_windowxpos and sg_windowxpos are
    used to determine the size and position of the window.
    $A Igor sep03; */
{
int id=0,i=1,code=0,serial=0;
char *tkname=NULL,*toplevel=NULL,ext[30],*ptr=NULL,*res=NULL;
/*
itkwin itkw;
*/
sg_window itkw;
itk_windata windata;
static int reported=0;
/*
if (combuf==NULL)
*/
initgritk();
id=sg_openwindow_default();
itkw=stackel(sg_windows,id);
windata=itkw->intfcdata=newitk_windata();
serial=itkw->serial;
/* Save opening settings: */
itkw->title=stringcopy(sg_windowtitle);
windata->forcewin=stringcopy(locforcewin);
ptr=combuf;
if (drawtofile)
{
  windata->file=sg_obtainplotfile(".tcl");
  outfile=windata->fp=fopen(windata->file,"wb");
  drawtofile=1;
  /* Create a new toplevel window containing a canvas: */
  sprintf(ext,"__%04i",id);
  stringappend(&toplevel,ext);   /* Toplevel window */
  toplevel=stringcat(locitkwinprefix,ext);
  tkname=stringcat(toplevel,".c");
  ptr+=sprintf(ptr,"#!wish -f\n");
  ptr+=sprintf(ptr,"catch {toplevel %s} ;\n",toplevel);
  ptr+=sprintf(ptr,"catch {canvas %s -bg #FFFFFF -width %i -height %i} ;\n",
    tkname,sg_iwindowwidth,sg_iwindowheight);
  ptr+=sprintf(ptr,"catch {pack %s -side top -expand 1 -fill both} ;\n",tkname);
  if (sg_windowxpos<1 && sg_windowypos<1)
  {
    ptr+=sprintf(ptr,"catch {wm geometry %s +%i+%i}; \n",
      toplevel,sg_iwindowxpos,sg_iwindowypos);
  }
  ptr+=sprintf(ptr,"catch {wm geometry %s {}}; \n",toplevel);
  if (sg_windowtitle!=NULL)
    ptr+=sprintf(ptr,"catch {wm title %s {%s}}\n",toplevel,sg_windowtitle);
  else
    /* This is not really necessary - change in the future? */
    ptr+=sprintf(ptr,"catch {wm title %s {SGS - ITK win. %i}}\n",toplevel,id);
  ptr+=sprintf(ptr,"after 100 {catch {raise %s }}\n",toplevel);
  runbuf(); *combuf='\0'; ptr=combuf;
  /* Add some controls to the window: */
  /* Button 3 for destroying the window: */
  ptr+=sprintf(ptr,"bind %s <Button-3> {destroy %s}\n",toplevel,toplevel); 
  ptr+=sprintf(ptr,"set epsfilename %s\n","0.eps");
  /* Lover window for buttons, message and entry: */
  ptr+=sprintf(ptr,"frame %s.fmes -bd 3 -relief sunken\n",toplevel);
  ptr+=sprintf(ptr,"pack %s.fmes -side top -fill both\n",toplevel);
  /* Message: */
  ptr+=sprintf(ptr,"message %s.fmes.m -text {Press <Quit> to exit program or <Print> to write\\\n",
    toplevel);
  ptr+=sprintf(ptr,"the canvas to a file in eps format. Pressing the third mouse button in\\\n");
  ptr+=sprintf(ptr,"the window or <Close> destroys it.} -width 550 -anchor center -bd 6\n");
  ptr+=sprintf(ptr,"pack %s.fmes.m -side top -fill both\n",toplevel);
  /* Frame for buttons: */
  runbuf(); *combuf='\0'; ptr=combuf;
  ptr+=sprintf(ptr,"frame %s.fmes.bot -bd 5\n",toplevel);
  ptr+=sprintf(ptr,"pack %s.fmes.bot -side top -fill both\n",toplevel);
  ptr+=sprintf(ptr,"button %s.fmes.bot.print -text Print -command {printeps $epsfilename}\n",
      toplevel);
  ptr+=sprintf(ptr,"button %s.fmes.bot.quit -text Quit -command {quit 0}\n",toplevel);
  ptr+=sprintf(ptr,"button %s.fmes.bot.destroy -text Close -command {destroy %s}\n",toplevel,toplevel);
  ptr+=sprintf(ptr,"label %s.fmes.bot.lab -text {Name of the eps file:}\n",toplevel);
  runbuf(); *combuf='\0'; ptr=combuf;
  ptr+=sprintf(ptr,"entry %s.fmes.bot.eps -textvariable epsfilename\n",toplevel);
  runbuf(); *combuf='\0'; ptr=combuf;
  ptr+=sprintf(ptr,"pack %s.fmes.bot.quit  -side left -expand 1\n",toplevel);
  ptr+=sprintf(ptr,"pack %s.fmes.bot.destroy -side left -expand 1\n",toplevel);
  ptr+=sprintf(ptr,"pack %s.fmes.bot.print -side right -expand 0\n",toplevel);
  ptr+=sprintf(ptr,"pack  %s.fmes.bot.eps %s.fmes.bot.lab -side right -expand 0\n",
               toplevel,toplevel);
  runbuf(); *combuf='\0'; ptr=combuf;
  ptr+=sprintf(ptr,"bind %s.fmes.bot.eps <FocusIn> {%cW select from 0 ; %cW select to end}\n",toplevel,'%','%');
  ptr+=sprintf(ptr,"proc printeps x {\n");
  ptr+=sprintf(ptr,"global %s\n",tkname);
  runbuf(); *combuf='\0'; ptr=combuf;
  ptr+=sprintf(ptr,"%s postscript -file $x\n",tkname);
  ptr+=sprintf(ptr,"}\n");
  ptr+=sprintf(ptr,"proc quit x {\n");
  ptr+=sprintf(ptr,"global .\n");
  ptr+=sprintf(ptr,"destroy .\n");
  ptr+=sprintf(ptr,"}\n");
  ptr+=sprintf(ptr,"\n");
  ptr+=sprintf(ptr,"\n\n# BEGINNING OF THE PLOT: \n\n");
  runbuf(); *combuf='\0'; ptr=combuf;

  disppointer((void **) &toplevel);
  windata->tkid=tkname;
  tkname=NULL;
  itkw->width=sg_iwindowwidth;
  itkw->height=sg_iwindowheight;

} else if (0 /* stringlength(locforcewin)>0 */)
{
  locforcewin=NULL;
  /* TO BE IMPLEMENTED!!!! (uncomment also the condition!) */
} else
{
  #ifndef ITK
    if (!reported)
    {
      errfunc0("sg_itk_openwindow");
      sprintf(ers(),"ITK is not present.\n");
      sprintf(ers(),"Only the Tcl file plotting interface is available.\n");
      sprintf(ers(),"Further messages of this type will be suppressed.\n");
      errfunc2();
      ++ reported;
    }
  #else
    /* Create a new toplevel window containing a canvas: */
    sprintf(ext,"__%04i",id);
    stringappend(&toplevel,ext);   /* Toplevel window */
    toplevel=stringcat(locitkwinprefix,ext);
    tkname=stringcat(toplevel,".c");
    ptr+=sprintf(ptr,"catch {toplevel %s} ;\n",toplevel);
    ptr+=sprintf(ptr,"catch {canvas %s -bg #FFFFFF -width %i -height %i} ;\n",
      tkname,sg_iwindowwidth,sg_iwindowheight);
    ptr+=sprintf(ptr,"catch {pack %s -expand 1 -fill both} ;\n",tkname);
    if (sg_windowxpos<1 && sg_windowypos<1)
    {
      ptr+=sprintf(ptr,"catch {wm geometry %s +%i+%i}; \n",
        toplevel,sg_iwindowxpos,sg_iwindowypos);
    }
    ptr+=sprintf(ptr,"catch {wm geometry %s {}}; \n",toplevel);
    if (sg_windowtitle!=NULL)
      ptr+=sprintf(ptr,"catch {wm title %s {%s}}",toplevel,sg_windowtitle);
    else
      /* This is not really necessary - change in the future? */
      ptr+=sprintf(ptr,"catch {wm title %s {SGS - ITK win. %i}}",toplevel,id);
    /*
    printf("\nITK command for opening the SGS window (length: %i):\n%s\n\n",
      strlen(combuf),combuf);
    */
    res=itk_interpretcp(combuf,NULL);
    *combuf='\0';
    disppointer((void **) &res);
    disppointer((void **) &toplevel);
    windata->tkid=tkname;
    tkname=NULL;
    itkw->width=sg_iwindowwidth;
    itkw->height=sg_iwindowheight;
  #endif
}
runbufblock(); *combuf='\0'; ptr=combuf;
/* The following takes care of variables related to the current window */
sg_itk_setwindow(id);
#ifdef ITK
  if (loccursor==NULL && !drawtofile)
  {
    /* Obtain common cursor shape if we don't have it yet: */
    ptr=combuf;
    ptr+=sprintf(ptr,"%s cget -cursor \n",locwindowstr);
    res=itk_interpretcp(combuf,&code);
    *combuf=0;
    if (tcl_okcode(code) /* stringlength(res)>0 */)
    {
      loccursor=res;
      res=NULL;
      if (loccursor==NULL)
        loccursor=stringcopy("");
    } else
      disppointer((void **) &res);
  }
#endif
return id;
}



static int sg_itk_setwindow(int id)
    /* Sets the window identified by id as the current plotting window.
    Returns 0 if for any reason the window identified by ID can not set to
    the current window (e.g. it does not exist or actual window has been
    closed outside the SGS).
      If the actual window does not exist (e.g. it was closed by user
    interaction), this function tries to reopen it.
    $A Igor sep03; */
{
int ret=0,code=0;
static int reported=0,reclev=0; /* recursion counter */
char *ptr=NULL,*res=NULL;
sg_window itkw;
itk_windata windata=NULL;
++reclev;
if (drawtofile && outfile!=NULL)
  fflush(outfile);
if (reclev==5)  /* prevent infinite recursion */
{
  errfunc0("sg_itk_setwindow");
  sprintf(ers(),"Infinite recursion when trying to activate window %i.\n",id);
  sprintf(ers(),"The attempt is given up, current window (%i) will be used.\n",locitkwin);
  errfunc2();
  return 0;
}
/*
if (sg_windows==NULL)
  sg_windows=newstack(5);
*/
if (id<0)
{
  errfunc0("sg_itk_setwindow");
  sprintf(ers(),"Non-positive window ID (%i) passed. Must be a positive integer.\n",id);
  errfunc2();
} else if (sg_windows->n<id)
{
  errfunc0("sg_itk_setwindow");
  sprintf(ers(),"There is no window identified by %i.\n",id);
  errfunc2();
} else
{
  if ((itkw=stackel(sg_windows,id))==NULL)
  {
    errfunc0("sg_itk_setwindow");
    sprintf(ers(),"There is no window identified by %i.\n",id);
    sprintf(ers(),"The corresponding data structure is NULL.\n");
    errfunc2();
  } else
  {
    /* Window structure with a specific id exists: */
    if (drawtofile)
    {
      if (itkw->intfc!=SG_PLOT_TCL)
      {
        errfunc0("sg_itk_setwindow");
        sprintf(ers(),"The window with ID %i does not belong to the Tcl file plotting\n",id);
        sprintf(ers(),"graphic interface.\n");
        errfunc2();
        return 0;
      }
    } else if (itkw->intfc!=SG_PLOT_ITK)
    {
      errfunc0("sg_itk_setwindow");
      sprintf(ers(),"The window with ID %i does not belong to the ITK graphic interface.\n");
      errfunc2();
      return 0;
    }
    windata=itkw->intfcdata;
    if (!drawtofile)
    {
      #ifdef ITK
        ptr=combuf;
        ptr+=sprintf(ptr,"winfo exists %s ;\n",windata->tkid);
        res=itk_interpretcp(combuf,&code);
        *combuf='\0';
        if (!tcl_okcode(code))
        {
          errfunc0("sg_itk_setwindow");
          sprintf(ers(),"Existence of the tk window %s (ID %i)\n",windata->tkid,id);
          sprintf(ers(),"could not be checked - Tcl error code %i, error:\n",code);
          checkminerbuf(stringlength(res)); /* Ensure that error buffer can hold the
                                            message */
          sprintf(ers(),"%s",res);
          errfunc2();
          disppointer((void **) &res);
        } else
        {
          if (!cmpstrings(res,"0"))
          {
            /* Actual window identified by id does not exist, we try to reopen the
            window in the same way as it has been opened initially: */
            char *saveforcewin=NULL,*savewindowtitle=NULL;
            int idnew,saveiwidth,saveiheight;
            float savewidth,saveheight;
            /* Save affected SGS settings and change them to the original settings
            for the window to be opened: */
            saveforcewin=locforcewin; locforcewin=windata->forcewin;
            savewindowtitle=sg_windowtitle; sg_windowtitle=itkw->title;
            savewidth=sg_windowwidth;
            saveiwidth=sg_iwindowwidth; sg_iwindowwidth=itkw->width;
            saveheight=sg_windowheight;
            saveiheight=sg_iwindowheight; sg_iwindowheight=itkw->height;
            /* Try to re-open window: */
            idnew=sg_itk_openwindow();
            /* Restore affected SGS settings: */
            locforcewin=saveforcewin;
            sg_windowtitle=savewindowtitle;
            sg_windowwidth=savewidth; sg_windowheight=saveheight;
            sg_iwindowwidth=saveiwidth; sg_iwindowheight=saveiheight;
            dispsg_window(&itkw);  /* deallocate the old window structure */
            sg_windows->s[id]=NULL;
            if (idnew>0)
            {
              /* Change the ID of the newly created window to id and set itkw,
              retreive interface specific data and change ID there: */
              itkw=sg_windows->s[idnew];
              itkw->id=id;
              windata=itkw->intfcdata;
              windata->id=id;
              /*
              sg_windows->s[id]=NULL;
              */
              sg_windows->s[id]=itkw;
              sg_windows->s[idnew]=NULL;
            } else
            {
              /* If creation was not successful, we return, recursion level must be
              decremented back: */
              --reclev;
              return ret;
            }
            /* 
            errfunc0("sg_itk_setwindow");
            sprintf(ers(),"Re - creation of SGS ITK windows is not yet implemented.\n");
            sprintf(ers(),"You must take care that the SGS ITK windows are not closed\n");
            sprintf(ers(),"outside the SGS!\n");
            errfunc2();
            */
          }
          disppointer((void **) &res);
          if (itkw!=NULL)
          {
            ptr=combuf;
            ptr+=sprintf(ptr,"winfo exists %s ;\n",windata->tkid);
            res=itk_interpretcp(combuf,&code);
            *combuf='\0';
          }
          if (!cmpstrings(res,"0") || res==NULL || !tcl_okcode(code))
          {
            disppointer ((void **) &res);
            errfunc0("sg_itk_setwindow");
            sprintf(ers(),"Can not set the current window to %i - actual window does not exist.\n",
              id);
            errfunc2();
          } else
          {
            ret=locitkwin=sg_currentwindow=id;
            disppointer((void **) &res);
            /* The window exists, we update the data on the window structure: */
            sprintf(combuf,"winfo width %s ;\n",windata->tkid);
            res=itk_interpretcp(combuf,&code);
            *combuf='\0';
            if (!tcl_okcode(code))
            {
              errfunc0("sg_itk_setwindow");
              sprintf(ers(),"SGS can not determine the actual width and height of the window %i.\n",
                id);
              errfunc2();
            } else
            {
              itkw->width=atol(res);
              disppointer((void **) &res);
              sprintf(combuf,"winfo height %s ;\n",windata->tkid);
              res=itk_interpretcp(combuf,&code);
              *combuf='\0';
              if (!tcl_okcode(code))
              {
                errfunc0("sg_itk_setwindow");
                sprintf(ers(),"SGS can not determine the actual height of the window %i.\n",
                  id);
                errfunc2();
              } else
              {
                itkw->height=atol(res);
                disppointer((void **) &res);
              }
            }
          }
          disppointer((void **) &res);
        }
      #endif  /* defined(ITK) */
    }  /* ! drawtofile */
    /* Update local variable for accessing the window: */
    locwindowstr=windata->tkid;
    if (drawtofile)
    {
      outfile=windata->fp;
      sg_currentwindow=locitkwin=itkw->id;
    } else
      sg_currentwindow=locitkwin=itkw->id;
  }
}
runbufblock();
--reclev;
return ret;
}



void sg_itk_clearwindow(void)
     /* Deletes the contents of the active window.
    $A Igor sep03; */
{
if (!drawtofile)
{
  sprintf(combuf,"catch {%s delete all}; \n",locwindowstr);
  runbufblock();
}
}


static void sg_itk_resetwindow(void)
    /* Resets the currrent window. Window contents is deleted and its size is
    checked.
    $A Igor sep03; */
{
int code=0;
char *res=NULL;
static int reported=0;
sprintf(combuf,"catch {%s delete all}; \n",locwindowstr);
runbufblock();
if (locitkwin>0 && sg_windows!=NULL && !drawtofile)
{
  #ifndef ITK
    if (!reported)
    {
      errfunc0("sg_itk_resetwindow");
      sprintf(ers(),"ITK is not present.\n");
      sprintf(ers(),"Only the Tcl file plotting interface is available.\n");
      sprintf(ers(),"Further messages of this type will be suppressed.\n");
      errfunc2();
      ++ reported;
    }
  #else
    if (sg_windows->n>=locitkwin)
    {
      sg_window w;
      w=sg_windows->s[locitkwin];
      if (w!=NULL)
      {
        /* Check the dimensions of the window: */
        sprintf(combuf,"winfo width %s; \n",locwindowstr);
        res=itk_interpretcp(combuf,&code);
        *combuf='\0';
        if (tcl_okcode(code))
          w->width=atol(res);
        disppointer((void **) &res);
        sprintf(combuf,"winfo height %s; \n",locwindowstr);
        res=itk_interpretcp(combuf,&code);
        *combuf='\0';
        if (tcl_okcode(code))
          w->height=atol(res);
        disppointer((void **) &res);
        sg_iwindowwidth=w->width;
        sg_iwindowheight=w->height;
      }
    }
  #endif
}
}



static void sg_itk_closewindow(void)
     /* Closes the current (active) windeow.
     $A Igor jul03; */
{
char *res=NULL;
int code=0;
sg_window itkwin;
itk_windata windata;
static int reported=0;
if (locitkwin>0 && sg_windows!=NULL)
  if (sg_windows->n>=locitkwin)
  {
    if (drawtofile)
    {
      if (locitkwin>0 && locitkwin<=sg_windows->n)
        itkwin=sg_windows->s[locitkwin];
      if (itkwin!=NULL)
      {
        windata=itkwin->intfcdata;
        if (windata!=NULL)
        {
          fprintf(windata->fp,"\n# END OF THE PLOT.\n\n");
          fprintf(windata->fp,"update\n");
          fclose(windata->fp);
          windata->fp=NULL;
        }
        dispsg_window(&itkwin);
      }
      outfile=NULL;
      sg_currentwindow=locitkwin=0;
      locwindowstr=NULL;
    } else
    {
      #ifndef ITK
        if (!reported)
        {
          errfunc0("sg_itk_closewindow");
          sprintf(ers(),"ITK is not present.\n");
          sprintf(ers(),"Only the Tcl file plotting interface is available.\n");
          sprintf(ers(),"Further messages of this type will be suppressed.\n");
          errfunc2();
          ++ reported;
        }
      #else
        if (ncmpstrings(locitkwinprefix,locwindowstr,
          stringlength(locitkwinprefix))==0)
        {
          /* SGS opened a new toplevel window to hold the canvas; the toplevel
          window is destroyed: */
          sprintf(combuf,"destroy [winfo toplevel %s] ;\n",locwindowstr);
          res=itk_interpretcp(combuf,&code);
          *combuf='\0';
          disppointer((void **) &res);
        } else
        {
          /* The canvas window was created in an existent window or the existent
          canvas is used; only the canvas is unmaped, parent windows are not
          affected: */
          sprintf(combuf,"pack forget %s ;\n",locwindowstr);
          res=itk_interpretcp(combuf,&code);
          *combuf='\0';
          disppointer((void **) &res);
        }
        /* Window structure is deallocated so that window ID can be reused by
        another window: */
        if (locitkwin>0 && locitkwin<=sg_windows->n)
          if (sg_windows->s[locitkwin]!=NULL)
            dispsg_window((sg_window *) &(sg_windows->s[locitkwin]));
        outfile=NULL;
        sg_currentwindow=locitkwin=0;
        locwindowstr=NULL;
      #endif
    }
  }
sg_currentwindow=locitkwin=0;
locwindowstr=NULL;
}



static void sg_itk_raisewindow(void)
    /* Raises the current graphics window to the top of the window stack so
    that it is not obscured by other windows. */
{
sprintf(combuf,"catch \"raise [winfo toplevel %s]\"; \n",locwindowstr);
runbufblock();
}

static int sg_itk_getwindow(void)
{
return locitkwin;
}


static void sg_itk_flushdisplay(void)
     /* Enforces drawing of everything from SGS what has not been drawn yet.
    $A Igor jul03; */
{
}



  /* BASIC FUNCTIONS FOR PLOTTING BY Tk: */



static char *itkinstallfont(itk_fontdata fd)
    /* Executes installation of the Tk font in the Tcl interpreter, chooses a
    unique name of this font and returns it. The Tk name of the font is returned
    is everything is OK, but the returned pointer should not be deallocated.
    If an error occurs then NULL is returned.
    $A Igor sep03; */
{
static int num=0;
char *ptr,str[30],*family;
char bold,italic,underline,overstrike;
if (fd->tkid==NULL)
{
  ++num; /* increse serial number */
  /* Get a new Tk font name (hopefully not yet occupied): */
  sprintf(str,"%04i",num);
  fd->tkid=stringcat("ITK_SGS_FONT_",str);
}
if (fd->base==NULL)
{
  errfunc0("");
  sprintf(ers(),"Pointer to base font structure is NULL.\n");
  sprintf(ers(),"Font ID: %i\n",fd->id);
  errfunc2();
  return NULL;
}
family=fd->base->family;
bold=fd->base->bold;
italic=fd->base->italic;
underline=fd->base->underline;
overstrike=fd->base->overstrike;
/*
if (combuf==NULL)
*/
initgritk();
ptr=combuf;
ptr+=sprintf(ptr,"catch {font delete %s}; ",fd->tkid);
ptr+=sprintf(ptr,"font create %s ",fd->tkid);
ptr+=sprintf(ptr,"-family {%s} ",family);
if (bold)
  ptr+=sprintf(ptr,"-weight bold ");
if (italic)
  ptr+=sprintf(ptr,"-slant italic ");
if (underline)
  ptr+=sprintf(ptr,"-underline 1 ");
if (overstrike)
  ptr+=sprintf(ptr,"-overstrike 1 ");
ptr+=sprintf(ptr,";\n");
/*
printf("\nITK font installation command:\n%s\n",combuf);
*/
runbufblock();
return fd->tkid;
}



static itk_fontdata itkregisterfont(int font)
    /* Takes care that the font with ID font is registered in the current
    context. The context means the ITK interpreter if drawing on screen is
    activated, or the current window (meaning also the file) if graphic output
    is written to a Tcl file.
      The function returns the pointer to the data structure of type
    itk_fontdata, which conatins relevant font data for plotting interfaces
    SG_PLOT_ITK (plotting on the screen by ITK) and SG_PLOT_TCL (plotting to
    Tcl output file), or NULL if the task can not be performed (e.g. no window
    is open so there is no current window).
      The function can also be called if the font is already registered in the
    current drawing context, in this case it doesn't do anything but just
    returns the pointer to the data.
    $A Igor sep03; */
{
sg_font fs=NULL;
itk_fontdata ret,*addr;
if (font<=0)
{
  errfunc0("itkregisterfont");
  sprintf(ers(),"The font ID less than 1 (%i).\n",font);
  errfunc2();
  return NULL;
}
if (sg_fonts->n>=font)
  fs=sg_fonts->s[font];
if (fs==NULL)
{
  errfunc0("itkregisterfont");
  sprintf(ers(),"There is no font with ID %i.\n",font);
  errfunc2();
  return NULL;
}
/* Obtain the address of the pointer to the local font data, so we can
initialize it or access the data: */
addr=(itk_fontdata *) sg_fontdataaddr(fs);
if (addr==NULL)
{
  errfunc0("itkregisterfont");
  sprintf(ers(),"Unable to obtain the address for local font data pointer.\n",font);
  errfunc2();
  return NULL;
}
if (*addr==NULL)
{
  *addr=newitk_fontdata();
  (*addr)->base=fs;
  (*addr)->id=fs->id;
}
ret=*addr;
ret->id=fs->id;
if (drawtofile)
{
  sg_window win=NULL;
  itk_windata tkwin=NULL;
  int installed=0;
  /* Drawing to a file, the font must be installed for every window: */
  /* First check if the font is installed for the current window; the font is
  installed if the window unique serial number can be found on ret->filewins : */
  win=stackel(sg_windows,sg_currentwindow);
  if (win==NULL)
  {
    errfunc0("itkregisterfont");
    sprintf(ers(),"Unable to register the font %id for the Tcl file.\n",font);
    sprintf(ers(),"Reason:\nUnable to get data for the current window.\n");
    sprintf(ers(),"Font data: \nfamily = \"%s\"\n",fs->family);
    sprintf(ers(),"bold: %i, italic: %i, underline: %i, overstrike: %i\n",
            fs->bold,fs->italic,fs->underline,fs->overstrike);
    errfunc2();
    return NULL;
  } else if (win->intfc!=SG_PLOT_TCL)
  {
    errfunc0("itkregisterfont");
    sprintf(ers(),"Unable to register the font %id for the Tcl file.\n",font);
    sprintf(ers(),"Reason:\nThe Tcl file graphic interface is not active.\n");
    sprintf(ers(),"Font data: \nfamily = \"%s\"\n",fs->family);
    sprintf(ers(),"bold: %i, italic: %i, underline: %i, overstrike: %i\n",
            fs->bold,fs->italic,fs->underline,fs->overstrike);
    errfunc2();
    return NULL;
  }
  if (ret->filewins==NULL)
    ret->filewins=newindtab(2,1);
  else
    installed=findindtab(ret->filewins,win->serial,0,0);
  if (!installed)
  {
    /* The font has not yet been installed for the currend window (=file),
    install it: */
    addindtabun(ret->filewins,win->serial,0,0);
    if (itkinstallfont(ret)==NULL)
    {
      errfunc0("itkregisterfont");
      sprintf(ers(),"Unable to register the font %id for the Tcl file.\n",font);
      tkwin=win->intfcdata;
      if (tkwin!=NULL)
        printf("Graphic output file: %s\n",tkwin->file);
      else
        printf("Graphic output file not defined.\n");
      sprintf(ers(),"Font data: \nfamily = \"%s\"\n",fs->family);
      sprintf(ers(),"bold: %i, italic: %i, underline: %i, overstrike: %i\n",
              fs->bold,fs->italic,fs->underline,fs->overstrike);
      errfunc2();
      return NULL;
    }
  }
} else
{
  /* Drawing on the screen, we need to install the font only once: */
  /* Install the tk font that corresponds to the attributes stored in fs, if
  it has not not yet been installed: */
  if (!ret->installeditk)
  {
    ret->installeditk=1;
    if (itkinstallfont(ret)==NULL)
    {
      errfunc0("itkregisterfont");
      sprintf(ers(),"Unable to register the font %id in the ITK.\n",font);
      sprintf(ers(),"Font data: \nfamily = \"%s\"\n",fs->family);
      sprintf(ers(),"bold: %i, italic: %i, underline: %i, overstrike: %i\n",
              fs->bold,fs->italic,fs->underline,fs->overstrike);
      errfunc2();
      return NULL;
    }
  }
}
return ret;
}


static void itkinstallfontstr(int id,char *spec)
{
char *ptr;
/*
if (combuf==NULL)
*/
initgritk();
ptr=combuf;
if (sg_fonts->n>=id)
{
  if (sg_fonts->s[id]!=NULL)
  {
    ptr+=sprintf(ptr,"font delete %s; ",sg_fonts->s[id]);
  }
} else
  insstack(sg_fonts,NULL,id);
if (sg_fonts->s[id]==NULL)
{
  char *str;
  str=malloc(30);
  sprintf(str,"%i",id);
  sg_fonts->s[id]=stringcat("ITK_SGS_font_",str);
  free(str); str=NULL;
}
ptr+=sprintf(ptr,"font create %s;\n",spec);
runbuf();
}





static void printcolorhandlingstatus(void)
    /* Izpise nastavitve, ki se ticejo ravnanja z barvami. */
{
printf("IG coloring status:\n");
if (sg_coloring)
  printf("Using RGB colors.\n");
else
  printf("Using gray scale.\n");
if (sg_numshades==0)
  printf("Using continuous colors.\n");
else
{
  printf("Number of shades: %i\n",sg_numshades);
  printf("Number of colors: %i\n",sg_numdiscretecolors);
}
if (sg_indexsize>0)
{
  printf("Size of index table: %i\n",sg_indexsize);
  printf("Number of indeces used: %i\n",sg_numindices);
  if (sg_numindices==sg_numdiscretecolors)
    printf("Cells for all possible colors are allocated.\n");;
} else printf ("No indexing.\n");
}




void sg_itk_setcoloring(int yes)
    /* If yes is 0, then graphics will be plotted in grey, otherwise in colors.
    $A Igor jul03; */
{
if (yes)
  sg_coloring=1;
else
  sg_coloring=0;
}

void sg_itk_setnumshades(int num)
    /* Sets the number of shades for each color component to num (or the number
    of gray scales if coloring is switched off). If num is 0, the colors are
    contiguous, in this case also indexing can not be used on the systems where
    it can otherwise be enabled.
    $A Igor jul03; */
{
if (num<0)
  num=0;
if (num==1) /* Must be at least 2!!! */
  num=2;
if (num>1024)
  num=1024;
sg_numshades=num;
}

void sg_itk_colortabsize(int size)
    /* Sets the size of the table that stores indices of already allocated
    collor cells, to size. If size is 0, indexing is not used, which means that
    for use of any color the graphic underlying library is instructed to
    allocate the appropriate color cell, regardless of whether the color has
    been used before.
    With ITK, this does not have any effect (but does e.g. with Xlib)
    $A Igor jul03; */
{
if (size<0)
  size=0;
sg_indexsize=size;
}

void sg_itk_preindexcolors(int yes)
    /* If yes is 0, then the requests for allocation of colors are sent to the
    library each time. If it is 1, then colors are allocated in advance at the
    initialization of the screen, if the table of indices is large enough.
      This function has no effect with ITK, but does w.g. with Xlib.
    $A Igor jul03; */
{
if (yes)
  sg_preindexall=1;
else
  sg_preindexall=0;
}





void sg_itk_setwindowtitle(char *title)
    /* Sets the window title for windows that will be open anew. If title is
    NULL, then the SGS chooses its own title when opening new toplevel
    windows, which distinguishes the SGS graphics windows from the others and
    also indicates the number of the window (recommended unless this would
    affect the look of the application in an undesired way, useful for
    debugging).
      The SGS makes a dynamic copy of the string title. Therefore, if a
    dynamically allocated string is passed as an argument, it can be
    deallocated after the function call.
    $A Igor jul03; */
{
if (sg_windowtitle!=NULL)
  free(sg_windowtitle);
sg_windowtitle=stringcopy(title);
}

char *sg_itk_getwindowtitle(void)
    /* Returns the current window title as has been set by the user. A pointer
    to the title is returned, therefore it may not be allocated or modified by
    the user.
      Warning:
    This function must be used with care when graphics is used by multiple
    threads.
    $A Igor jul03; */
{
return sg_windowtitle;
}

float sg_itk_setwindowxpos(float z)
    /* Sets the initial position of windows (upper left corner) at opening in
    the x direction to z where z is relative to screen width with the
    range from 0 to 1. If z is out of range (e.g. negative), the underlying
    graphic library will chose the window position position.
      The previous position is returned.
    $A Igor jul03; */
{
float ret;
ret=sg_windowxpos;
if (z>=0 && z<=1)
{
  sg_windowxpos=z;
  sg_iwindowxpos=1+(int) (z*(sg_MAXX-1));
} else
{
  sg_iwindowxpos=(int) z;
  sg_windowxpos=(float) sg_iwindowxpos/(float) sg_MAXX;
}
return ret;
}

float sg_itk_getwindowxpos(void)
    /* return the current position for opening new windows in the x direction
    relative to the screen width. Negative value means that the system chooses
    the position.
    $A Igor jul03; */
{
return sg_windowxpos;
}


float sg_itk_setwindowypos(float z)
    /* Sets the initial position of windows (upper left corner) at opening in
    the y direction to z where z is relative to screen height with the
    range from 0 to 1. If z is out of range (e.g. negative), the underlying
    graphic library will chose the window position position.
    $A Igor jul03; */
{
float ret;
ret=sg_windowypos;
if (z>=0 && z<=1)
{
  sg_windowypos=z;
  sg_iwindowypos=1+(int) (z*(sg_MAXY-1));
} else
{
  sg_iwindowypos=(int) z;
  sg_windowypos=(float) sg_iwindowxpos/(float) sg_MAXY;

}
return ret;
}

float sg_itk_getwindowypos(void)
    /* return the current position for opening new windows in the x direction
    relative to the screen width. Negative value means that the system chooses
    the position.
    $A Igor jul03; */
{
return sg_windowypos;
}




float sg_itk_setwindowwidth(float z)
    /* Sets the initial width of windows when they are open to z. Returns
    previous value. Possible range is from 0 to 1.
    $A Igor jul03; */
{
float ret;
ret=sg_windowwidth;
if (z>=0 && z<=1)
{
  sg_windowwidth=z;
  sg_iwindowwidth=(int) ( 1.0f+(z*(sg_MAXX-1)) );
}
return ret;
}

float sg_itk_getwindowwidth(void)
    /* Returns the currently set value of the window width for newly open
    windows.
    $A Igor jul03; */
{
return sg_windowwidth;
}



float sg_itk_setwindowheight(float z)
    /* Sets the initial height of windows when they are open to z. Returns
    previous value. Possible range is from 0 to 1.
    $A Igor jul03; */
{
float ret;
ret=sg_windowheight;
if (z>=0 && z<=1)
{
  sg_windowheight=z;
  sg_iwindowheight=(int) ( 1+(z*(sg_MAXY-1)) );
}
return ret;
}

float sg_itk_getwindowheight(void)
    /* Returns the currently set value of the window height for newly open
    windows.
    $A Igor jul03; */
{
return sg_windowheight;
}




int sg_itk_nsetwindowxpos(int z)
    /* Sets the initial position for newly open windows in the x direction in
    pixels from the upper left corner of the screen. Negative vlaues imposes
    that the system can choose the position. The previous value is returned.
    If the value is greater than the screen widt, it is adjusted to the screen
    width. Negative values mean that the system is let to choose the position.
    $A Igor jul03; */
{
int ret;
ret=sg_iwindowxpos;
if (z<0)
{
  sg_windowxpos=-1;
  sg_iwindowxpos=-1;
} else
{
  if (z>sg_MAXX)
    z=sg_MAXX;
  sg_windowxpos=(float) z/sg_MAXX;
  sg_iwindowxpos=z;
}
return ret;
}


int sg_itk_ngetwindowxpos(void)
    /* Returns the current position in the x direction in pixels from the
    upper-left corner of the screen for newly open windows (negative value
    means that the system positions newly open windows).
    $A Igor jul03; */
{
return sg_iwindowxpos;
}



int sg_itk_nsetwindowypos(int z)
    /* Sets the initial position for newly open windows in the y direction in
    pixels from the upper left corner of the screen. Negative vlaues imposes
    that the system can choose the position. The previous value is returned.
    If the value is greater than the screen height, it is adjusted to the screen
    height. Negative values mean that the system is let to choose the position.
    $A Igor jul03; */
{
int ret;
ret=sg_iwindowypos;
if (z<0)
{
  sg_windowypos=-1;
  sg_iwindowypos=-1;
} else
{
  if (z>sg_MAXY)
    z=sg_MAXY;
  sg_windowypos=(float) z/sg_MAXY;
  sg_iwindowypos=z;
}
return ret;
}


int sg_itk_ngetwindowypos(void)
    /* Returns the current position in the y direction in pixels from the
    upper-left corner of the screen for newly open windows (negative value
    means that the system positions newly open windows).
    $A Igor jul03; */
{
return sg_iwindowypos;
}





int sg_itk_nsetwindowwidth(int z)
    /* Sets the initial width of newly open graphical windows in pixels and
    returns the previous value. If z is greater than the screen width, it is
    corrected do the screen width; if it is less than 1 then it is corrected
    to some reasonable value.
    $A Igor jul03; */
{
int ret;
if (z<1)
  z=100;
if (z>sg_MAXX)
  z=sg_MAXX;
ret=sg_iwindowwidth;
sg_windowwidth=(float) z/sg_MAXX;
sg_iwindowwidth=z;
return ret;
}

int sg_itk_ngetwindowwidth(void)
    /* Returns the currently set width for newly open windows in pixels.
    $A Igor jul03; */
{
return sg_iwindowwidth;
}



int sg_itk_nsetwindowheight(int z)
    /* Sets the initial height of newly open graphical windows in pixels and
    returns the previous value. If z is greater than the screen height, it is
    corrected do the screen heigth; if it is less than 1 then it is corrected
    to some reasonable value.
    $A Igor jul03; */
{
int ret;
if (z<1)
  z=100;
if (z>sg_MAXY)
  z=sg_MAXY;
ret=sg_iwindowheight;
sg_windowheight=(float) z/sg_MAXY;
sg_iwindowheight=z;
return ret;
}

int sg_itk_ngetwindowheight(void)
    /* Returns the currently set height for newly open windows in pixels.
    $A Igor jul03; */
{
return sg_iwindowheight;
}



/* Settings for plotting points: */


float sg_itk_setpointsize(float size)
      /* Sets the size of points relative to screen width and height and
      returns the current size. The size must be within the range from 0 to 1.0
      inclusively. If it is out of range, some reasonable size is set.
      $A Igor jul03; */
{
float ret=sg_pointsize;
if (size>0 && size<=1)
  sg_pointsize=size;
else
  sg_pointsize=0.01f;
return ret;
}

float sg_itk_getpointsize(void)
    /* Returns the current relative size for plotting points. 
    $A Igor jul03; */
{
return sg_pointsize;
}


int sg_itk_setcurvepoints(int num)
    /* Sets the number of divisions for drawing curved objects such as circles,
    and returns the current number. If num is less than 4, then 4 points are
    used. If it is more than 4000, then 4000 points are used.
    $A Igor jul03; */
{
int ret=sg_curvepoints;
if (num<4)
  num=4;
else if (num>4000)
  num=4000;
sg_curvepoints=num;
return ret;
}

int sg_itk_getcurvepoints(void)
    /* Returns number of divisions used for drawing curved objects
    $A Igor jul03; */
{
return sg_curvepoints;
}




/* SETTING COLORS: */


/* Auxiliary functions for specifying colors in Tk: */

static void sprinthexcolor(char *str,float red,float green,float blue)
    /* Prints a 6 digit hexadecimal color specification starting by a leading
    '#' to the string str. Color components red, green and blue must be within
    the range [0.0,1.0]!
    $A Igor jul03; */
{
div_t res;
int digit;
sprintf(str,"#");  /* print leading '#' */
++str;
/* Red component: */
res=div((int) (red*255),16);
digit=res.quot;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
digit=res.rem;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
/* Green component: */
res=div((int) (green*255),16);
digit=res.quot;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
digit=res.rem;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
/* Blue component: */
res=div((int) (blue*255),16);
digit=res.quot;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
digit=res.rem;
if (digit<10)
  sprintf(str,"%c",digit+'0');
else
  sprintf(str,"%c",digit-10+'A');
++str;
}



static void itksetcolor(float red,float green, float blue,truecolor col,
                      char *tkcol)
{
float c1;
if (!sg_coloring)
{
  /* Plotting in grey scale */
  c1=(red+green+blue)/3.0f;
  /* Force colors within the limits: */
  if (c1<0)
    c1=0.0;
  else if (c1>1.0)
    c1=1;
  if (sg_numshades>0 && sg_numshades<256)
  {
    /* Discretize colors: */
    c1=(float) round((double) c1 * ((double) sg_numshades-0.8))/
      ((float) sg_numshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (c1>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Grey level was set to %g>1 after discretization.\n",
        c1);
      errfunc2();
      c1=(float) 1;
    }
  }
  red=green=blue=c1;
} else
{
  /* Coloring; Force limits: */
  if (red<0.0) red=0.0; else if (red>1.0) red=1.0;
  if (green<0.0) green=0.0; else if (green>1.0) green=1.0;
  if (blue<0.0) blue=0.0; else if (blue>1.0) blue=1.0;
  if (sg_numshades>0 && sg_numshades<256)
  {
    /* Discretize colors: */
    red=(float) round((double) red * ((double) sg_numshades-0.8))/
      ((float) sg_numshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (red>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Red color component set to %g>1 after discretization.\n",
        red);
      errfunc2();
      red=(float) 1;
    }
    green=(float) round((double) green * ((double) sg_numshades-0.8))/
      ((float) sg_numshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (green>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Green color component set to %g>1 after discretization.\n",
        green);
      errfunc2();
      green=(float) 1;
    }
    green=(float) round((double) green * ((double) sg_numshades-0.8))/
      ((float) sg_numshades - (float) 1);
    /* $$ After some time, the check below should be removed: */
    if (green>1)
    {
      errfunc0("calccolor in module gritk.h");
      sprintf(ers(),"Red color component set to %g>1 after discretization.\n",
        green);
      errfunc2();
      green=(float) 1;
    }
  }
}
col->red=red;
col->green=green;
col->blue=blue;
sprinthexcolor(tkcol,red,green,blue);
}



void sg_itk_setlinecolor(float red,float green,float blue)
     /* Sets the color for drawing lines. Color components red, green and blue
     should be in the range between 0 and 1. Color discretization and grayscale
     conversion is performed if specified by the settings.
     $A Igor jul03; */
{
itksetcolor(red,green,blue,&sg_linecolor,loclinecolor);
}

void sg_itk_getlinecolor(float *red,float *green,float *blue)
    /* Sets *red, *green and *blue to the current values of RGB color
    components for drawing lines. These components are as have been set by the
    last call to the sg_itk_setlinecolor() and possibly updated according to the
    discrete shading or grayscale settings.
     $A Igor jul03; */
{
*red=sg_linecolor.red; *green=sg_linecolor.green; *blue=sg_linecolor.blue;
}


void sg_itk_setfillcolor(float red,float green,float blue)
     /* Sets the color for filling. Color components red, green and blue
     should be in the range between 0 and 1. Color discretization and grayscale
     conversion is performed if specified by the settings.
     $A Igor jul03; */
{
itksetcolor(red,green,blue,&sg_fillcolor,locfillcolor);
}

void sg_itk_getfillcolor(float *red,float *green,float *blue)
    /* Sets *red, *green and *blue to the current values of RGB color
    components for filling. These components are as have been set by the
    last call to the sg_itk_setfillcolor() and possibly updated according to the
    discrete shading or grayscale settings.
     $A Igor jul03; */
{
*red=sg_fillcolor.red; *green=sg_fillcolor.green; *blue=sg_fillcolor.blue;
}


void sg_itk_settextcolor(float red,float green,float blue)
     /* Sets the color for drawing text. Color components red, green and blue
     should be in the range between 0 and 1. Color discretization and grayscale
     conversion is performed if specified by the settings.
     $A Igor jul03; */
{
itksetcolor(red,green,blue,&sg_fillcolor,loctextcolor);
}

void sg_itk_gettextcolor(float *red,float *green,float *blue)
    /* Sets *red, *green and *blue to the current values of RGB color
    components for drawing text. These components are as have been set by the
    last call to the sg_itk_settextcolor() and possibly updated according to the
    discrete shading or grayscale settings.
     $A Igor jul03; */
{
*red=sg_textcolor.red; *green=sg_textcolor.green; *blue=sg_textcolor.blue;
}




    /* LINE SETTINGS */


void sg_itk_setlinewidth(double width)
     /* Sets width of the lines to width. width should normally be an integer
     starting from 1. 
       WARNING - For programmers:
       This function should be replaced in the future in order to take integer
     arguments, possibly supplemented by one that takes floating point
     arguments. Handling for floating point values should be such that if they
     are less than 1, they are considered as relative width with respect to the
     window size, otherwise they are considered as width in window pixels.
     $A Igor jul03; */
{
if (width<0)
  width=0;
sg_linewidth=width;
if (width>=1)
  sg_ilinewidth=(int) width;
else
  sg_ilinewidth=1+(int) (width*(float) m_minval(sg_iwindowwidth,sg_iwindowheight));
}

double sg_itk_getlinewidth(void)
    /* Returns the current line width.
     $A Igor jul03; */
{
return sg_linewidth;
}



void sg_itk_setlinetype(int type)
     /* Sets the type of lines to type. If type is 1 then lines are continuous.
     $A Igor jul03; */
{
if( type<1)
  type=1;
else if (type>3)
  type=3;
sg_linetype=type;
}

int sg_itk_getlinetype(void)
    /* Returns the current line type.
     $A Igor jul03; */
{
return sg_linetype;
}



    /* TEXT SETTINGS: */


#if 0

void sg_itk_settextprecision(float precision)
     /* This function is not yet elaborated and does currently not have any
     effect.
     $A Igor jul03; */
{
shartextprecision=0;
}

float sg_itk_gettextprecision()
     /* This function is not yet elaborated and does currently not have any
     effect.
     $A Igor jul03; */
{
return shartextprecision;
}

#endif



void sg_itk_settextfont(int font)
     /* Sets the font that is used for plotting text.
     $A Igor jul03; */
{
if (font<1)
  font=1;
sg_currentfont=font;
}

int sg_itk_gettextfont(void)
    /* Returns the current font that is used for plotting text strings.
    $A Igor jul03; */
{
return sg_currentfont;
}



void sg_itk_settextheight(float height)
     /* Sets the height of the plotted text. height can either specify the
     height relative to the window size, in which case it must be less than
     1 (0 means the smallest admissible height that is system dependent) or
     an integer meaning the height in pixels. Floating point values greater
     than 1 are rounded to the nearest integer. Values smaller than 0 are
     treated as 0.
     $A Igor jul03; */
{
if (height<00.0)
  height=(float) 0.05 /* 6.0 */;
if (height>=1)
{
  sg_textheight=height/m_minval(sg_iwindowwidth,sg_iwindowheight);
} else
  sg_textheight=height;
  sg_itextheight=1+(int) (height*(float) m_minval(sg_iwindowwidth,sg_iwindowheight));
}

float sg_itk_gettextheight(void)
{
return sg_textheight;
}


#if 0

void sg_itk_settextspacing(float spacing)
    /* Sets the size of spaces between the letters of plotted text strings.
      WARNING:
      This function is currently not standardised and it is better not to
     use it.
     $A Igor apr03; */
{
if (spacing<(float) 0.0)
  spacing=(float) 0.0;
shartextspacing=spacing;
}

float sg_itk_gettextspacing(void)
    /* Returns the text spacing as it is currently set.
    $A Igor jul03; */
{
return shartextspacing;
}


void sg_itk_settextexpansion(float expansion)
     /* Sets the text expansion in the horizontal direction.
       WARNING:
       This function is currently not standardized and its use should be
     avoided.
    $A Igor jul03; */
{
if (expansion<=0.0f)
  expansion=1.0;
shartextexpansion=expansion;
}

float sg_itk_gettextexpansion(void)
    /* Returns the text expansion as it is currently set.
    $A Igor jul03; */
{
return shartextexpansion;
}

#endif



void sg_itk_settextxalignment(int alignment)
    /* Sets the alignment of text in the horizontal direction. If alignment
    is -1 then text is aligned to the left of the anchor position, if it is
    0, the text is centered around the anchor position and if it is 1, the
    text is aligned to the right of the anchor position.
    $A Igor jul03; */
{
if (alignment<-1)
  alignment=-1;
else if (alignment>1)
  alignment=1;
sg_textxalignment=alignment;
}

int sg_itk_gettextxalignment(void)
    /* Returns the current allignment of plotted text strings in the horizontal
    direction.
    $A Igor jul03; */
{
return sg_textxalignment;
}



void sg_itk_settextyalignment(int alignment)
    /* Sets the alignment of text in the vertical direction. If alignment
    is -1 then text is aligned below the anchor position, if it is 0, the text
    is centered around the anchor position and if it is 1, the text is aligned
    above the anchor position.
    $A Igor jul03; */
{
if (alignment<-1)
  alignment=-1;
else if (alignment>1)
  alignment=1;
sg_textyalignment=alignment;
}

int sg_itk_gettextyalignment(void)
    /* Returns the current allignment of plotted text strings in the vertical
    direction.
    $A Igor jul03; */
{
return sg_textxalignment;
}



void sg_itk_settextalignment(int xalignment,int yalignment)
    /* Sets the alignment of text in both horizontal and vertical directions
    by using the functions sg_itk_settextxalignment() and settextyalignment().
    $A Igor jul03; */
{
sg_itk_settextxalignment(xalignment);
sg_itk_settextyalignment(yalignment);
}

void sg_itk_gettextalignment(int *xalignment,int *yalignment)
    /* Returns the current allignment of the plotted text strings in the
    horizontal direction in *xalignment and in vertical direction in
    *yalignment. The pointer arguments may not be NULL.
    $A Igor jul03; */
{
*xalignment=sg_textxalignment;  *yalignment=sg_textyalignment;
}




/* WARNING - For programmers:
Implemented should be also plotting with integer coordinates!
Implement calculation of fp coordinates from window coordinates and vice versa!
*/



void sg_itk_line(float x1,float y1,float x2,float y2)
    /* Draws a line with given relative window coordinates of endpoints.
    Current line drawing settings are used.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
itkgiwindowcoord(x2,y2,&p2);
sprintf(combuf,"%s create line %g %g %g %g -fill %s -width %i\n",
        locwindowstr,p1.x,p1.y,p2.x,p2.y,loclinecolor,sg_ilinewidth);
runbuf();
}


void sg_itk_triangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* Draws a frame triangle with given relative window coordinates of
    apices. Current line drawing settings are used.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
itkgiwindowcoord(x2,y2,&p2);
itkgiwindowcoord(x3,y3,&p3);
sprintf(combuf,"%s create line %g %g %g %g %g %g %g %g -fill %s -width %i\n",
        locwindowstr,p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,p1.x,p1.y,
        loclinecolor,sg_ilinewidth);
runbuf();
}


void sg_itk_fourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* Draws a frame fourangle with sg_itk_ven relative window coordinates of
    apices. Current line drawing settings are used.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
itkgiwindowcoord(x2,y2,&p2);
itkgiwindowcoord(x3,y3,&p3);
itkgiwindowcoord(x4,y4,&p4);
sprintf(combuf,"%s create line %g %g %g %g %g %g %g %g %g %g -fill %s -width %i\n",
        locwindowstr,p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,p4.x,p4.y,p1.x,p1.y,
        loclinecolor,sg_ilinewidth);
runbuf();
}


void sg_itk_filltriangle(float x1,float y1,float x2,float y2,
                        float x3,float y3)
    /* Draws a filled triangle with given relative window coordinates of
    apices. Current fill settings are used.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
itkgiwindowcoord(x2,y2,&p2);
itkgiwindowcoord(x3,y3,&p3);
sprintf(combuf,"%s create polygon %g %g %g %g %g %g -fill %s\n",
        locwindowstr,p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,
        locfillcolor);
runbuf();
}


void sg_itk_fillfourangle(float x1,float y1,float x2,float y2,
                        float x3,float y3,float x4,float y4)
    /* Draws a filled fourangle with given relative window coordinates of
    apices. Current fill settings are used.
    $A Igor jul03; */
{
itkgiwindowcoord(x1,y1,&p1);
itkgiwindowcoord(x2,y2,&p2);
itkgiwindowcoord(x3,y3,&p3);
itkgiwindowcoord(x4,y4,&p4);
sprintf(combuf,"%s create polygon %g %g %g %g %g %g %g %g -fill %s\n",
        locwindowstr,p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,p4.x,p4.y,
        locfillcolor);
runbuf();
}


static void xxx_tclimarktextpos(char *str,float x,float y,char mark,char box)
    /* Currently not implemented. Supposed to mark the predicted position of
    the plotted text by a frame.
    $A Igor apr97; */
{
errfunc0("tclimarktextpos");
sprintf(ers(),"The function is currently not implemented.\n");
errfunc2();
}


void sg_itk_text(char *str,float x1,float y1)
    /* Plots the text strings at the relative window coordinates (x1,y1) with
    the current font settings.
    $A Igor jul03; */
{
itk_fontdata fd=NULL;
int error=0;
itkgiwindowcoord(x1,y1,&p1);
fd=itkregisterfont(sg_currentfont);
if (fd==NULL)
  error=1;
else if (fd->tkid==NULL)
  error=1;
if (error)
{
  errfunc0("sg_itk_text");
  sprintf(ers(),"The font %i is not registered properly.\n",sg_currentfont);
  errfunc2();
} else
{
  if (sg_textxalignment==1)
  {
    if (sg_textyalignment==1)
      loctextanchor="sw";
    else if (sg_textyalignment==0)
      loctextanchor="w";
    else if (sg_textyalignment==-1)
      loctextanchor="nw";
  } else if (sg_textxalignment==0)
  {
    if (sg_textyalignment==1)
      loctextanchor="s";
    else if (sg_textyalignment==0)
      loctextanchor="center";
    else if (sg_textyalignment==-1)
      loctextanchor="n";
  } else
  {
    if (sg_textyalignment==1)
      loctextanchor="se";
    else if (sg_textyalignment==0)
      loctextanchor="e";
    else if (sg_textyalignment==-1)
      loctextanchor="ne";
  }
  sprintf(combuf,"%s create text %g %g -text {%s} -fill %s -anchor %s -font \"%s %i\"\n",
          locwindowstr,p1.x,p1.y,str,loctextcolor,loctextanchor,
          fd->tkid,sg_itextheight);
  /*
  printf("Text height: %g (int.: %i), Tcl command:\n%s\n",sg_textheight,
         sg_itextheight,combuf);
  */
  runbuf();
}
}






    /* DRAWING STACKS (actually lists) OF GRAPHIC PRIMITIVES: */



static void godrawstack0(stack st)
    /* Draws the stack of graphic primitives in the usual manner.
    $A Igor sep03; */
{
int i;
if (st!=NULL)
  if (st->n>0)
    for (i=1;i<=st->n;++i)
      sg_godrawprimitive( (goprimitive) st->s[i]);
}

static void sg_itk_godrawstack(stack st)
     /* Plots the stack st containing graphic primitives. Primitives are
    plotted in order of appearance. It is arranged that all primitives are
    drawin at once in the thread of the ITK's Tcl interpreter, which enables
    direct interpretation (this is much faster that sending Tcl commands
    across the threads).
    $A Igor sep03; */
{
int godrawstackitk(stack st);
static int runplain=0;
/* Call godrawstackitk(), which launches an ITK plotting procedure 
itk_sgs_plot, which calls this function again, and this function then draws
the complete stack st at once in the  ITK int. thread; If this function
was called from godrawstackitk(), then that function returns 0 indicating
that the stack needs to be drawn now (the function counts its level of
recursion). Otherwise, godrawstackitk() runs this function and returns 0. */
if (!godrawstackitk(st))
  godrawstack0(st);
}





    /* INSTALLING THE ITK DRAWING INTERFACE FOR SGS */


void sg_itk_interface0(int fileint)
    /* Activates the ITK plotting interface for plotting on the screen.
    $A Igor sep03; */
{
sg_initintbas();  /* must be called at the beginning of every interface 
                     activation function */
/* First switch to default (empty) interface to override any active interface,
just to prevent mixing of functions in the case that any function is not
implemented and installed in this interface: */
sg_interface(SG_PLOT_DEFAULT);
/* Mark the active interface: */
if (fileint)
  sg_interfaceid=SG_PLOT_TCL;
else
  sg_interfaceid=SG_PLOT_ITK;
if (sg_windows==NULL)
  sg_windows=newstack(10);
if (sg_fonts==NULL)
  sg_fonts=newstack(5);
drawtofile=fileint;  /* specifies whether to draw to a file */
/* We need to register the interface houskeeping functions: */
sg_register_dispwin((void (*)(void **)) dispitk_windata); /* for deletion of intfc. specific win. data */
sg_register_dispfont((void (*)(void **)) dispitk_fontdata); /* deletion of intfc. specific font data */
/* INSTALL INTERFACE SPECIFIC PLOTTING FUNCTIONS: */
/* WINDOW (and graphic context) HNADLING: */
sg_openwindow = sg_itk_openwindow;
sg_setwindow = sg_itk_setwindow;
sg_clearwindow = sg_itk_clearwindow;
sg_resetwindow = sg_itk_resetwindow;
sg_closewindow = sg_itk_closewindow;
sg_raisewindow = sg_itk_raisewindow;
sg_installfont=sg_installfont_default;
sg_installfontstr = itkinstallfontstr;
sg_setcoloring = sg_itk_setcoloring;
sg_setnumshades = sg_itk_setnumshades;
sg_colortabsize = sg_itk_colortabsize;
sg_preindexcolors = sg_itk_preindexcolors;
sg_setwindowtitle = sg_itk_setwindowtitle;
sg_getwindowtitle = sg_itk_getwindowtitle;
sg_setwindowxpos = sg_itk_setwindowxpos;
sg_getwindowxpos = sg_itk_getwindowxpos;
sg_setwindowypos = sg_itk_setwindowypos;
sg_getwindowypos = sg_itk_getwindowypos;
sg_setwindowwidth = sg_itk_setwindowwidth;
sg_getwindowwidth = sg_itk_getwindowwidth;
sg_setwindowheight = sg_itk_setwindowheight;
sg_getwindowheight = sg_itk_getwindowheight;
sg_nsetwindowxpos = sg_itk_nsetwindowxpos;
sg_ngetwindowxpos = sg_itk_ngetwindowxpos;
sg_nsetwindowypos = sg_itk_nsetwindowypos;
sg_ngetwindowypos = sg_itk_ngetwindowypos;
sg_nsetwindowwidth = sg_itk_nsetwindowwidth;
sg_ngetwindowwidth = sg_itk_ngetwindowwidth;
sg_nsetwindowheight = sg_itk_nsetwindowheight;
sg_ngetwindowheight = sg_itk_ngetwindowheight;
sg_setpointsize = sg_itk_setpointsize;
sg_getpointsize = sg_itk_getpointsize;
sg_setcurvepoints = sg_itk_setcurvepoints;
sg_getcurvepoints = sg_itk_getcurvepoints;
/* SETTING COLORS: */
sg_setlinecolor= sg_itk_setlinecolor;
sg_getlinecolor = sg_itk_getlinecolor;
sg_setfillcolor = sg_itk_setfillcolor;
sg_getfillcolor = sg_itk_getfillcolor;
sg_settextcolor = sg_itk_settextcolor;
sg_gettextcolor = sg_itk_gettextcolor;
/* LINE SETTINGS */
sg_setlinewidth = sg_itk_setlinewidth;
sg_getlinewidth = sg_itk_getlinewidth;
sg_setlinetype = sg_itk_setlinetype;
sg_getlinetype = sg_itk_getlinetype;
/* TEXT SETTINGS: */
sg_settextfont = sg_itk_settextfont;
sg_gettextfont = sg_itk_gettextfont;
sg_settextheight = sg_itk_settextheight;
sg_gettextheight = sg_itk_gettextheight;
sg_settextxalignment = sg_itk_settextxalignment;
sg_gettextxalignment = sg_itk_gettextxalignment;
sg_settextyalignment = sg_itk_settextyalignment;
sg_gettextyalignment = sg_itk_gettextyalignment;
sg_settextalignment = sg_itk_settextalignment;
sg_gettextalignment = sg_itk_gettextalignment;
/* BASIC DRAWING FUNCTIONS: */
sg_line = sg_itk_line;
sg_triangle = sg_itk_triangle;
sg_fourangle = sg_itk_fourangle;
sg_filltriangle = sg_itk_filltriangle;
sg_fillfourangle = sg_itk_fillfourangle;
sg_text = sg_itk_text;
/* BASIC GRAPHIC ELEMENTS THAT ARE DRAWN BY OTHER DRAWING FUNCTIONS: */
sg_rectangle = sg_rectangle_default;
sg_circle = sg_circle_default;
sg_circlearc = sg_circlearc_default;
sg_ellipse = sg_ellipse_default;
sg_ellipsearc = sg_ellipsearc_default;
sg_fillrectangle = sg_fillrectangle_default;
sg_point = sg_point_default;
sg_fillcircle = sg_fillcircle_default;
sg_fillcirclearc = sg_fillcirclearc_default;
sg_fillellipse = sg_fillellipse_default;
sg_fillellipsearc = sg_fillellipsearc_default;
/* FUNCTIONS FOR DRAWING MARKERS (=points) AND ARROWS (vectors) : */
sg_marker = sg_marker_default;
sg_registermarker = sg_registermarker_default;
sg_arrow = sg_arrow_default;
/* DRAWING STACKS (or better lists) OF GRAPHIC PRIMITIVES: */
sg_godrawstack = sg_itk_godrawstack;

/* RESET LOCAL VARIABLES (especially those that concern windows, since windows
are treated independently by different graphic interfaces: */
locitkwin=0;
locwindowstr=NULL;
}



void sg_itk_interface(void)
    /* Installs the ITK drawing interface for SGS, which draws on screen by
    using the Tk canvas widgets.
    $A Igor sep03; */
{
sg_itk_interface0(0);
}


void sg_tcl_interface(void)
    /* Installs the Tcl drawing interface for SGS, which draws in kfiles in Tcl
    format that can be directly interpreted by any Tcl/Tk interpreter, for
    example by the wish shell.
    $A Igor sep03; */
{
sg_itk_interface0(1);
}


int sg_itk_setdirectitk(int direct,void *interp)
    /* Sets either direct access to the ITK interpreter (if direct==1 and
    interp!=NULL) by the ITK plotting interface or indirect access. Returns
    the current value of the flag that determines what kind of execution is
    in use. The function should normally be called twice - for the first time
    to set the kind of access and for the second time to restore the previous
    state (with the same argument interp). If direct is 1 then interp must be
    the pointer to the ITK interpreter.
    $A Igor sep03; */
{
int ret=direct;
static int reported=0;
#ifndef ITK
  if (!reported)
  {
    errfunc0("sg_itk_setdirectitk");
    sprintf(ers(),"ITK is not present.\n");
    sprintf(ers(),"Only the Tcl file plotting interface is available.\n");
    sprintf(ers(),"Further messages of this type will be suppressed.\n");
    errfunc2();
    ++ reported;
  }
#else
directitk=direct;
if (interp!=NULL)
{
  /* The pointer to the ITK interpreter is left unchanged if direct is 0: */
  itkinterp=interp;
}
if (interp==NULL)
  directitk=0;
#endif
return ret;
}













