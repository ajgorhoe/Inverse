
                 /***********************/
                 /*                     */
                 /*    APPROXIMATION    */
                 /*                     */
                 /***********************/

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>

#include <er.h>
#include <rf.h>
#include <st.h>
#include <vec.h>
#include <mat.h>
#include <matrixop.h>
#include <rand.h>
#include <mtime.h>
#include <itk.h>

#include <approx.h>



static char prn=0;  /* flag for auxiliary print-outs */


  /* GENERAL REMARKS: 
  Functions for calculating approximatinos with linear and quadratic
  polynomials are optimized for calculating approximation in many point, i.e.
with possibly different data sets of the same dimensions. Therefore, auxiliary
matrices are static variables and it is possible not to deallocate them
between successive computations, which saves the computational time. */




         /****************************************/
         /*                                      */
         /*  LINEAR LEAST SQUARES APPROXIMATION  */
         /*                                      */
         /****************************************/


static int ap_lock=0;  /* thread lock */
static matrix ap_basfunc=NULL, ap_C=NULL,  ap_decomp=NULL;
static vector ap_d=NULL;
static vector ap_raw=NULL;

static int ap_forceclean=0;

int approx_forceclean(int doclean)
    /* Sets the parameter that determines whether the auxiliary storage used by
    approximation routines is released each time after use. If doclean is
    non-zero then the storage is released, otherwise (if doclean is 0) some
    auxiliary variables are not deallocated after use, so that the next
    computation can use utilize the same storage and it need not to allocate
    the space again. This can speed up computation especially when a lot of
    approximations of small dimensions are calculated successively. By default
    cleaning is not enforced. If the necessary storage is large then the
    auxiliary storage is deallocated after use in any case (since repeated
    allocation is inexpensive with respect to computation).
      The current value of the parameter before the call is returned.
    $A Igor nov03; */
{
int ret=ap_forceclean;
ap_forceclean=doclean;
return ret;
}

void approx_cleanauxdata(void)
   /* Releases the space that is eventually occupied by auxiliary variables
   used by the functions of the approximation module.
   $A Igor nov03; */
{
dispvector(&ap_d);
dispmatrix(&ap_basfunc);
dispmatrix(&ap_C);
dispmatrix(&ap_decomp);
}


    /* GENERAL LIN. APPROXIMATION (any type of basis functions): */

int coeflincombapprox(matrix basval,vector val,vector w,vector *coefaddr)
    /* Calculates coefficients of a linear combination of a set of basis
    functions that approximates the best the given data, and stores them
    to *coefaddr. basval must contain values of the basis functions in the
    sampling points (each line corresponds to one sampling point and each
    element of this line corresponds to a value of the corresponding basis
    function in that point). Val must contain values of the approximated
    function in the sampling points and w their QUADRATIC weights. basval,
    val and w must be of consistent dimensions because this is not checked
    by the function. *coefaddr can be NULL or of inconsistend dimensions
    since it is allocated or reallocated if necessary.
    $A Igor nov03; */
{
int i,j,k,N,m,ret=0,decomp;
static int reclevel;
vector coef;
m_threadlocksleep(ap_lock,1);
++reclevel;
m=basval->d1;  N=basval->d2;
if (*coefaddr!=NULL)
{
  if ((*coefaddr)->d!=N)
  {
    dispvector(coefaddr);
    *coefaddr=getvector(N);
  }
} else
  *coefaddr=getvector(N);
coef=*coefaddr;
if (ap_C!=NULL)
{
  if (ap_C->d1!=N || ap_C->d2!=N)
  {
    dispmatrix(&ap_C);
    ap_C=getmatrix(N,N);
  }
} else
  ap_C=getmatrix(N,N);
if (ap_decomp!=NULL)
{
  if (ap_decomp->d1!=N || ap_decomp->d2!=N)
  {
    dispmatrix(&ap_decomp);
    ap_decomp=getmatrix(N,N);
  }
} else
  ap_decomp=getmatrix(N,N);
/* Assembling of the system matrix and the right-hand side vector: */
for (i=1;i<=N;++i)
{
  coef->v[i]=0;
  for (k=1;k<=m;++k)
    coef->v[i]+=w->v[k]*basval->m[k][i]*val->v[k];
  for (j=1;j<=N;++j)
  {
    ap_C->m[i][j]=0;
    for (k=1;k<=m;++k)
      ap_C->m[i][j]+=w->v[k]*basval->m[k][i]*basval->m[k][j];
  }
}
decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,1e-14);
if (decomp)
{
  if (1)
  {
    double R=1.0e-9,incfact=100.0,sumdiag,term,termmin,aux,small,small2;
    vector reg=NULL,sqrsumlines;
    /* Regularization by addition of coefficient size minimization terms,
    which leads to addition of small positive values to diagonal terms of the
    system matrix: */
    /*
    printf("Singular system matrix:\n");
    printmatrixlist(ap_C);
    */
    reg=getvector(N);
    sqrsumlines=getvector(N);
    /* Calculate root mean square of diagonal elements: */
    sumdiag=0;
    for (i=1;i<=N;++i)
      sumdiag+=ap_C->m[i][i]*ap_C->m[i][i];
    sumdiag=sqrt(sumdiag)/((double) (10*N));
    small=sumdiag*R*1e-5;
    small2=sumdiag*sumdiag*R*R*1e-5;  /* Square measure for a small value */
    /* Calculate the square sums for all lines: */
    for (i=1;i<=N;++i)
    {
      sqrsumlines->v[i]=0;
      for (j=1;j<=N;++j)
        sqrsumlines->v[i]+=ap_C->m[i][j]*ap_C->m[i][j];
      if (sqrsumlines->v[i]<small2)
        sqrsumlines->v[i]=small2;
    }
    /* Calculate the coefficients: */
    if (N==1)
    {
      reg->v[1]=R*fabs(ap_C->m[1][1]);
      if (reg->v[1]<1e-40)
        reg->v[1]=1e-40;
    } else
    {
      for (i=1;i<=N;++i)
      {
        /* Minimum of sums over lines, we omit square root and coef. R/N: */
        termmin=0;
        for (j=1;j<=N;++j)
        {
          if (j!=i)
          {
            aux=ap_C->m[j][i]*ap_C->m[j][i];
            term=(sqrsumlines->v[j]-aux)/(aux+small);  /* addition of small
                  prevents division by zero */
            termmin=m_minval(termmin,term);
          }
        }
        if (termmin==0)
          termmin=1e-30;
        reg->v[i]=R*m_minval(1,sqrt(termmin)/(double) N)*
             m_maxval(fabs(ap_C->m[i][i]),sumdiag);
      }
    }
    while (decomp && R<1.0)
    {
      ++ret;
      for (i=1;i<=N;++i)
        ap_C->m[i][i]+=reg->v[i];
      decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,0.0);
      if (decomp)
      {
        /* Matrix is still singular, we increase the regularization
        coefficients: */
        R*=incfact;
        for (i=1;i<=N;++i)
          reg->v[i]*=incfact;
      }
    }
    if (decomp)
    {
      ret=-ret;
    }
    /* 
    else
    {
      printf("Repaired system matrix:\n");
      printmatrixlist(ap_C);
    }
    */
    dispvector(&sqrsumlines);
    dispvector(&reg);
  } else
  {
    ++ret;
    errfunc0("coeflincombapprox");
    sprintf(ers(),"Singular system matrix.\n");
    errfunc2();
    return ret;
  }
}
if (ret>=0)
  solvLDLTplain(ap_decomp,ap_decomp,coef,coef);
if (ap_forceclean)
{
  dispmatrix(&ap_C);
  dispmatrix(&ap_decomp);
  dispvector(&ap_d);
} else
{
  if (N>100)
  {
    dispmatrix(&ap_C);
    dispmatrix(&ap_decomp);
    dispvector(&ap_d);
  }
}
m_threadunlock(ap_lock);
return ret;
}


int coeflincombapproxgrad(matrix basval,matrix val,matrix w,vector *coefaddr)
    /* Calculates coefficients of a linear combination of a set of basis
    functions that approximates the best the given data, and stores them
    to *coefaddr. basval must contain values and gradients of the basis
    functions in the sampling points where function values and gradients
    were captured (each line must corresponds to one sampling point and 
    must contain by turns the value and the derivatives for each basis
    bunction in that point). Val must contain values and gradients of the
    approximated function in the sampling points and w their QUADRATIC weights
    (one line per a sampling point).
      basval, val and w must be of consistent dimensions because this is not
    checked by the function. Values in each line of basval must be listed by
    basis functions, for each function the value in the corresponding sampling
    points must be stated first followed by the derivatives. 
      *coefaddr can be NULL or of inconsistend dimensions because it is
    allocated or reallocated if necessary.
    $A Igor nov03; */
{
int i,j,k,l,ind1,ind2,N,m,dim,ret=0,decomp;
static int reclevel;
vector coef;
m_threadlocksleep(ap_lock,1);
++reclevel;
/* Num. points, dimension of space (=number of grad. components), number of 
basis functions: */
m=basval->d1;  dim=val->d2-1;  N=basval->d2/(dim+1);
if (*coefaddr!=NULL)
{
  if ((*coefaddr)->d!=N)
  {
    dispvector(coefaddr);
    *coefaddr=getvector(N);
  }
} else
  *coefaddr=getvector(N);
coef=*coefaddr;
if (ap_C!=NULL)
{
  if (ap_C->d1!=N || ap_C->d2!=N)
  {
    dispmatrix(&ap_C);
    ap_C=getmatrix(N,N);
  }
} else
  ap_C=getmatrix(N,N);
if (ap_decomp!=NULL)
{
  if (ap_decomp->d1!=N || ap_decomp->d2!=N)
  {
    dispmatrix(&ap_decomp);
    ap_decomp=getmatrix(N,N);
  }
} else
  ap_decomp=getmatrix(N,N);
/* Assembling of the system matrix and the right-hand side vector: */
for (i=1;i<=N;++i)
{
  ind1=1+(i-1)*(dim+1); /* index for value entry in basval for function i */
  coef->v[i]=0;
  for (k=1;k<=m;++k)
  {
    coef->v[i]+=w->m[k][1]*basval->m[k][ind1]*val->m[k][1];
    for (l=1;l<=dim;++l)
      coef->v[i]+=w->m[k][1+l]*basval->m[k][ind1+l]*val->m[k][1+l];
  }
  for (j=1;j<=N;++j)
  {
    ind2=1+(j-1)*(dim+1); /* index for value entry in basval for function i */
    ap_C->m[i][j]=0;
    for (k=1;k<=m;++k)
    {
      ap_C->m[i][j]+=w->m[k][1]*basval->m[k][ind1]*basval->m[k][ind2];
      for (l=1;l<=dim;++l)
        ap_C->m[i][j]+=w->m[k][1+l]*basval->m[k][ind1+l]*basval->m[k][ind2+l];
    }
  }
}
decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,1e-14);
if (decomp)
{
  if (1)
  {
    double R=1.0e-9,incfact=100.0,sumdiag,term,termmin,aux,small,small2;
    vector reg=NULL,sqrsumlines;
    /* Regularization by addition of coefficient size minimization terms,
    which leads to addition of small positive values to diagonal terms of the
    system matrix: */
    /*
    printf("Singular system matrix:\n");
    printmatrixlist(ap_C);
    */
    reg=getvector(N);
    sqrsumlines=getvector(N);
    /* Calculate root mean square of diagonal elements: */
    sumdiag=0;
    for (i=1;i<=N;++i)
      sumdiag+=ap_C->m[i][i]*ap_C->m[i][i];
    sumdiag=sqrt(sumdiag)/((double) (10*N));
    small=sumdiag*R*1e-5;
    small2=sumdiag*sumdiag*R*R*1e-5;  /* Square measure for a small value */
    /* Calculate the square sums for all lines: */
    for (i=1;i<=N;++i)
    {
      sqrsumlines->v[i]=0;
      for (j=1;j<=N;++j)
        sqrsumlines->v[i]+=ap_C->m[i][j]*ap_C->m[i][j];
      if (sqrsumlines->v[i]<small2)
        sqrsumlines->v[i]=small2;
    }
    /* Calculate the coefficients: */
    if (N==1)
    {
      reg->v[1]=R*fabs(ap_C->m[1][1]);
      if (reg->v[1]<1e-40)
        reg->v[1]=1e-40;
    } else
    {
      for (i=1;i<=N;++i)
      {
        /* Minimum of sums over lines, we omit square root and coef. R/N: */
        termmin=0;
        for (j=1;j<=N;++j)
        {
          if (j!=i)
          {
            aux=ap_C->m[j][i]*ap_C->m[j][i];
            term=(sqrsumlines->v[j]-aux)/(aux+small);  /* addition of small
                  prevents division by zero */
            termmin=m_minval(termmin,term);
          }
        }
        if (termmin==0)
          termmin=1e-30;
        reg->v[i]=R*m_minval(1,sqrt(termmin)/(double) N)*
             m_maxval(fabs(ap_C->m[i][i]),sumdiag);
      }
    }
    while (decomp && R<1.0)
    {
      ++ret;
      for (i=1;i<=N;++i)
        ap_C->m[i][i]+=reg->v[i];
      decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,0.0);
      if (decomp)
      {
        /* Matrix is still singular, we increase the regularization
        coefficients: */
        R*=incfact;
        for (i=1;i<=N;++i)
          reg->v[i]*=incfact;
      }
    }
    if (decomp)
    {
      ret=-ret;
    }
    dispvector(&sqrsumlines);
    dispvector(&reg);
  } else
  {
    ++ret;
    errfunc0("coeflincombapproxgrad");
    sprintf(ers(),"Singular system matrix.\n");
    errfunc2();
    return ret;
  }
}
if (ret>=0)
  solvLDLTplain(ap_decomp,ap_decomp,coef,coef);
if (ap_forceclean)
{
  dispmatrix(&ap_C);
  dispmatrix(&ap_decomp);
  dispvector(&ap_d);
} else
{
  if (N>100)
  {
    dispmatrix(&ap_C);
    dispmatrix(&ap_decomp);
    dispvector(&ap_d);
  }
}
m_threadunlock(ap_lock);
return ret;
}



         /*************************************************/
         /*                                               */
         /*     APPROXIMATION WITH LINEAR POLYNOMIALS     */
         /*                                               */
         /*************************************************/


  /* CONVERSION BETWEEN RAW AND NORMAL FORM OF COEFFICIENTS: */

void coeflinpolraw(vector b,double c,vector *addrraw)
    /* Conversion from regular form of coefficients of a linear polynomial to
    raw form. The lin. pol. is b_T x + c. In raw form, coefficients are
    arranged in a single vector and sorted in the following order: c, b[1],
    b[2], ..., b[dim] where dim is the number of independent variables
    (dimension of the space).
      b must be allocated and of correct dimension since this is not checked. 
      addrraw may not be NULL, but it can point to a NULL vector. The function
    allocates or reallocates the space for *addrraw if necessary.
    $A Igor nov03; */
{
vector raw;
int dim,N,i;
dim=b->d;
N=dim+1;
if (*addrraw!=NULL)
{
  if ((*addrraw)->d!=N)
  {
    dispvector(addrraw);
    *addrraw=getvector(N);
  }
} else
  *addrraw=getvector(N);
raw=*addrraw;
raw->v[1]=c;
for (i=1;i<=dim;++i)
  raw->v[i+1]=b->v[i];
}


void coeflinpolreg(vector raw,vector *addrb,double *addrc)
    /* Rearrangement of raw coefficients of a linear polynomial to a regular
    form. Coefficient are arranged in vector *addrb and scalar *addrc. If
    necessary, the vector is allocated or re-allocated.
    See also coeflinpolraw()!
      If necessary, vector *addrb is reallocated or allocated anew.
    $A Igror nov03; */
{
vector b;
int i,dim;
/* Calc. dimension, number of coefficients must be (dim+1)(dim+2)/2: */
dim=raw->d-1;
if (*addrb!=NULL)
{
  if ((*addrb)->d!=dim)
  {
    dispvector(addrb);
    *addrb=getvector(dim);
  }
} else
  *addrb=getvector(dim);
b=*addrb;
*addrc=raw->v[1];
for (i=1;i<=dim;++i)
  b->v[i]=raw->v[i+1];
}


  /* CALCULATION OF LINEAR POLYNOMIAL AND ITS GRADIENT: */

double linpol(vector x,vector b,double c)
    /* Returns the value of a linear polynomial with coefficients b and
    c at x.
    $A Igor nov03; */
{
double ret;
int i,dim;
dim=x->d;
ret=c;
for (i=1;i<=dim;++i)
  ret+=b->v[i]*x->v[i];
return ret;
}


vector gradlinpol(vector x,vector b,vector *addrgrad)
    /* Calculates gradient of a linear polynomial with linear coefficients b,
    and stores it to *addrgrad. x, and b must be allocated and of consistent
    dimensions since this is not checked by the function. If necessary the
    function allocates or reallocates the storage for the gradient.
    $A Igor nov03; */
{
vector grad;
int dim;
dim=x->d;
copyvector(b,addrgrad);
grad=*addrgrad;
return grad;
}


double derlinpol(vector x,int which,vector b)
    /* Returns the derivative of a linear polynomial whose  linear coefficients
    are in b, with respect to the variable which at the point x.
    $A igor nov03; */
{
return b->v[which];
}


double linpolraw(vector x,vector raw)
    /* Calculates a linear polynomial in x whose raw coefficients are in
    raw. x and raw must be allocated and of consistent dimensions since this
    is not checked by the function.
    $A Igor nov03; */
{
double ret;
int i,dim;
dim=x->d;
ret=raw->v[1];
for (i=1;i<=dim;++i)
  ret+=raw->v[i+1]*x->v[i];
return ret;
}


vector gradlinpolraw(vector x,vector raw,vector *addrgrad)
    /* Calculates gradient of a linear polynomial with coefficients raw
    arranged in raw form, and stores it to *addrgrad. x and raw must be
    allocated and of consistent dimensions since this is not checked in the
    function. If necessary the function allocates or reallocates the storage
    for the gradient.
    $A Igor nov03; */
{
int i,dim;
vector grad;
dim=x->d;
if (*addrgrad!=NULL)
{
  if ((*addrgrad)->d!=dim)
  {
    dispvector(addrgrad);
    *addrgrad=getvector(dim);
  }
} else
  *addrgrad=getvector(dim);
grad=*addrgrad;
for (i=1;i<=dim;++i)
  grad->v[i]=raw->v[i+1];
return grad;
}


double derlinpolraw(vector x,int which,vector raw)
    /* Returns the derivative of the linear polynomial with raw coefficients
    in raw at x with respect to the variable which. x and raw must be allocated
    with consistent dimensions and it must be 0<which<=which->d, since this is
    not checked.
      If which==0 then the value of the linear polynomiel is returned.
    $A Igor nov03; */
{
if (which==0)
  return linpolraw(x,raw);
else
  return raw->v[which+1];
}



  /* CALCULATING THE APPROXIMATION: */


int coeflinpolapproxraw_old(matrix points,vector val,vector w,vector *rawaddr)
    /* Calculates coefficients of a linear pol. approximation and stores them
    to *rawaddr. points must be a matrix whose LINES contain co-ordinates
    of sampling points, val must contain values of the sampled function in
    these points, and w must contain the corresponding SQUARE weigth that weigh
    the importance of individual points. points, val and w must be allocated
    and of consistent dimensions since this is not checked by the function.
    If necessary, space for coefficients is allocated anew or re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) with values close to the value
    in the most important point (or just one of them if they are equally
    weighted). The returned value is then a counter of how many times the
    system algorithm has been applied in order to obtain a solution. If all
    attempts to get a solution fail then a negative value is returned (equal
    to minus the number of attempts). In each attempt dim points are added
    where dim is dimension of the space.
      WARNINING:
      w must contain the SQUARED weights!
      REMARK:
      This is an old version of a function. It is a bit quicker than the
    newer one, but uses additional auxiliary storage for values of basic
    functions in all points (which can be considerable for large number of
    dimensions).
    $A Igor nov03; */
{
int i,j,k,ind,N,m,dim,ret=0;
static int reclevel;
vector raw;
m_threadlocksleep(ap_lock,1);
++reclevel;
m=points->d1;  dim=points->d2;  N=dim+1;
if (*rawaddr!=NULL)
{
  if ((*rawaddr)->d!=N)
  {
    dispvector(rawaddr);
    *rawaddr=getvector(N);
  }
} else
  *rawaddr=getvector(N);
raw=*rawaddr;
if (ap_C!=NULL)
{
  if (ap_C->d1!=N || ap_C->d2!=N)
  {
    dispmatrix(&ap_C);
    ap_C=getmatrix(N,N);
  }
} else
  ap_C=getmatrix(N,N);
if (ap_basfunc!=NULL)
{
  if (ap_basfunc->d1<N || ap_basfunc->d2<m)
  {
    dispmatrix(&ap_basfunc);
    ap_basfunc=getmatrix(N,m);
  }
} else
  ap_basfunc=getmatrix(N,m);
/* Evlauating basis functions in all points: */
for (k=1;k<=m;++k)
  ap_basfunc->m[1][k]=1;  /* constant term */
for (i=1;i<=dim;++i)
  for (k=1;k<=m;++k)
    ap_basfunc->m[i+1][k]=points->m[k][i];  /* lin. terms */
ind=dim+2;
/* Assembling of the system matrix and the right-hand side vector: */
for (i=1;i<=N;++i)
{
  raw->v[i]=0;
  for (k=1;k<=m;++k)
    raw->v[i]+=w->v[k]*ap_basfunc->m[i][k]*val->v[k];
  ap_C->m[i][i]=0;
  for (k=1;k<=m;++k)
    ap_C->m[i][i]+=w->v[k]*ap_basfunc->m[i][k]*ap_basfunc->m[i][k];
  for (j=i+1;j<=N;++j)
  {
    ap_C->m[i][j]=0;
    for (k=1;k<=m;++k)
      ap_C->m[i][j]+=w->v[k]*ap_basfunc->m[i][k]*ap_basfunc->m[j][k];
    ap_C->m[j][i]=ap_C->m[i][j];  /* symmetric */
  }
}
if (LDLTdecomptolplain(ap_C,ap_C,ap_C,0.0))
{
  if (reclevel<2*dim)
  {
    double wmax,wmax1,wsum;
    int iwmax;
    vector xwdist,xwmax,newval,neww;
    matrix newpoints;
    ++ret;
    /* Calculate the greatest weight, its index and the second greatest weight: */
    wmax=wmax1=w->v[1]; iwmax=1;
    xwdist=getvector(dim);
    xwmax=getvector(dim);
    for (i=2;i<=m;++i)
      if (w->v[i]>wmax)
      {
        wmax=w->v[i];   iwmax=i;
      } else if (w->v[i]>wmax1)
        wmax1=w->v[1];
    /* Point with maximum weight: */
    for (j=1;j<=dim;++j)
    {
      xwmax->v[j]=points->m[iwmax][j];
      xwdist->v[j]=0;
    }
    /* Calculate the weighted average component distance with respect to the
    point with the max. weight: */
    wsum=0;  /* wavdist=0; */
    for (i=1;i<=m;++i)
      if (i!=iwmax)
      {
        wsum+=w->v[i];
        for (j=1;j<=dim;++j)
          xwdist->v[j]+=fabs(points->m[i][j]-xwmax->v[j])*w->v[i];
        /*
        dist=vecnorm(vectordif0(xwmax,x,&x));
        wavdist+=dist*w->v[i];
        */
      }
    /* Divide components by sum of weights to get weighted average, then reduce
    the w. distance additionally */
    for (j=1;j<=dim;++j)
      xwdist->v[j]/=(wsum*(double) (100*N));
    /* Derive a small weight for additional points by reducing the second
    largest weight; fact. 10000 makes a point 100 times less important: */
    wmax1/=((double) (10000*N*dim)); 
    /* Add randomly a set of dim new points around the point with the largest
    weight in order to stabilize the least square equation; weights are small
    so that approximation of the original dataset should not be spoiled: */
    newpoints=getmatrix(m+dim,dim);
    newval=getvector(m+dim);
    neww=getvector(m+dim);
    for (i=1;i<=m;++i)  /* Transcription of original data: */
    {
      for (j=1;j<=dim;++j)
        newpoints->m[i][j]=points->m[i][j];
      neww->v[i]=w->v[i];
      newval->v[i]=val->v[i];
    }
    for (i=m+1;i<=m+dim;++i)  /* Transcription of original data: */
    {
      for (j=1;j<=dim;++j)
        newpoints->m[i][j]=xwmax->v[j]+xwdist->v[j]*random1();
      newval->v[i]=val->v[iwmax];
      neww->v[i]=wmax1;
    }
    m_threadunlock(ap_lock);
    ret+=coeflinpolapproxraw_old(newpoints,newval,neww,rawaddr);
    m_threadlocksleep(ap_lock,1);
    dispmatrix(&newpoints);
    dispvector(&newval);
    dispvector(&neww);
    dispvector(&xwdist);
    dispvector(&xwmax);
    --reclevel;
    m_threadunlock(ap_lock);
    return ret;
  } else
  {
    errfunc0("coeflinpolapproxraw_old");
    sprintf(ers(),"The system matrix is not invertable.\n");
    sprintf(ers(),"Attempt to condition the system matrix failed.\n");
    errfunc2();
    ret=-ret;
    --reclevel;
    m_threadunlock(ap_lock);
    return ret;
  }
}
solvLDLTplain(ap_C,ap_C,raw,raw);
--reclevel;
m_threadunlock(ap_lock);
if (ap_forceclean)
{
  dispmatrix(&ap_C);
  dispmatrix(&ap_basfunc);
  dispvector(&ap_d);
} else
{
  if (N>100)
  {
    dispmatrix(&ap_C);
    dispvector(&ap_d);
  }
  if (N>100 || m*N>100000)
    dispmatrix(&ap_basfunc);
}
return ret;
}


int coeflinpolapproxraw1(matrix points,vector val,vector w,vector *rawaddr)
    /* Does the same as coeflinpolapproxraw(), except that it first creates a
    matrix of values of basis functions in sampling points and then calculates
    the approximation by coeflincombapprox(). On contrary, coeflinpolapproxraw()
    assembles the system of equations without this intermediate storage.
      This function is slower than coeflinpolapproxraw() and was primarily
    created  for testing coeflincombapprox().
    $A, Igor nov03; */
{
int i,k,ind,dim,m,N,ret;
matrix basval=NULL;
m=points->d1;  dim=points->d2;  N=dim+1;
basval=getmatrix(m,N);
/* Fill basval with values of basis functions in points: */
for (k=1;k<=m;++k)
  basval->m[k][1]=1;
for (i=1;i<=dim;++i)
{
  for (k=1;k<=m;++k)
    basval->m[k][i+1]=points->m[k][i];
  ++ind;
}
ret=coeflincombapprox(basval,val,w,rawaddr);
dispmatrix(&basval);
return ret;
}


int coeflinpolapproxraw(matrix points,vector val,vector w,vector *rawaddr)
    /* Calculates coefficients of a linear pol. approximation and stores them
    to *rawaddr. points must be a matrix whose LINES contain co-ordinates
    of sampling points, val must contain values of the sampled function in
    these points, and w must contain the corresponding SQUARE weigth that
    weigh the importance of individual points. points, val and w must be
    allocated and of consistent dimensions since this is not checked by the
    function. If necessary, space for coefficients is allocated anew or
    re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) by values close to the value
    in the most important point (or just one of them if they are equally
    weighted). The returned value is then a counter of how many times the
    system algorithm has been applied in order to obtain a solution. If all
    attempts to get a solution fail then a negative value is returned (equal
    to minus the number of attempts). In each attempt dim points are added
    where dim is dimension of the space.
      WARNINING:
      w must contain the SQUARED weights!
    $A Igor nov03; */
{
int i,j,i1,i2,k,ind1,ind2,N,m,dim,ret=0,decomp;
static int reclevel;
vector raw;
m_threadlocksleep(ap_lock,1);
++reclevel;
m=points->d1;  dim=points->d2;  N=dim+1;
if (*rawaddr!=NULL)
{
  if ((*rawaddr)->d!=N)
  {
    dispvector(rawaddr);
    *rawaddr=getvector(N);
  }
} else
  *rawaddr=getvector(N);
raw=*rawaddr;
if (ap_C!=NULL)
{
  if (ap_C->d1!=N || ap_C->d2!=N)
  {
    dispmatrix(&ap_C);
    ap_C=getmatrix(N,N);
  }
} else
  ap_C=getmatrix(N,N);
if (ap_decomp!=NULL)
{
  if (ap_decomp->d1!=N || ap_decomp->d2!=N)
  {
    dispmatrix(&ap_decomp);
    ap_decomp=getmatrix(N,N);
  }
} else
  ap_decomp=getmatrix(N,N);
/* Assembling of the system matrix and the right-hand side vector: we arrange
inner and outer iteration over all basis functions in such a way that the form
of basis functions is always known : */
/* First bas. func. constant, second bas. function constant (ind2=1): */
raw->v[1]=0;
ap_C->m[1][1]=0;
for (k=1;k<=m;++k)
{
  raw->v[1]+=w->v[k]* /* 1 * */ val->v[k];
  ap_C->m[1][1]+=w->v[k] /* 1*1 */;
}
/* First bas. func. constant, second bas. function linear (ind2=2...dim+1): */
for (i2=1;i2<=dim;++i2)   /* ind2 = i2+1  */
{
  ind2=i2+1;
  ap_C->m[1][ind2]=0;
  for (k=1;k<=m;++k)
    ap_C->m[1][ind2]+=w->v[k]* /* 1 * */ points->m[k][i2];
  ap_C->m[ind2][1]=ap_C->m[1][ind2];  /* symmetrize */
}
ind2=dim+2;
/* First bas. function linear (x_i1), ind1=i1+1: */
for (i1=1;i1<=dim;++i1)
{
  ind1=i1+1;
  /* First bas. func. linear, second bas. function constant (ind2=1): */
  raw->v[ind1]=0;
  /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  for (k=1;k<=m;++k)
  {
    raw->v[ind1]+=w->v[k]*points->m[k][i1]*val->v[k];
    /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  }
  /* First bas. func. linear, second bas. function linear (ind2=2...dim+1): */
  for (i2=i1;i2<=dim;++i2)   /* ind2 = i2+1; from i1 because of symmetry  */
  {
    ind2=i2+1;
    ap_C->m[ind1][ind2]=0;
    for (k=1;k<=m;++k)
      ap_C->m[ind1][ind2]+=w->v[k]*points->m[k][i1]*points->m[k][i2];
    ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
  }
  ind2=dim+2;
}
decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,1e-14);
if (decomp)
{
  if (1)
  {
    double R=1.0e-9,incfact=100.0,sumdiag,term,termmin,aux,small,small2;
    vector reg=NULL,sqrsumlines;
    /* Regularization by addition of coefficient size minimization terms,
    which leads to addition of small positive values to diagonal terms of the
    system matrix: */
    /*
    printf("Singular system matrix:\n");
    printmatrixlist(ap_C);
    */
    reg=getvector(N);
    sqrsumlines=getvector(N);
    /* Calculate root mean square of diagonal elements: */
    sumdiag=0;
    for (i=1;i<=N;++i)
      sumdiag+=ap_C->m[i][i]*ap_C->m[i][i];
    sumdiag=sqrt(sumdiag)/((double) (10*N));
    small=sumdiag*R*1e-5;
    small2=sumdiag*sumdiag*R*R*1e-5;  /* Square measure for a small value */
    /* Calculate the square sums for all lines: */
    for (i=1;i<=N;++i)
    {
      sqrsumlines->v[i]=0;
      for (j=1;j<=N;++j)
        sqrsumlines->v[i]+=ap_C->m[i][j]*ap_C->m[i][j];
      if (sqrsumlines->v[i]<small2)
        sqrsumlines->v[i]=small2;
    }
    /* Calculate the coefficients: */
    if (N==1)
    {
      reg->v[1]=R*fabs(ap_C->m[1][1]);
      if (reg->v[1]<1e-40)
        reg->v[1]=1e-40;
    } else
    {
      for (i=1;i<=N;++i)
      {
        /* Minimum of sums over lines, we omit square root and coef. R/N: */
        termmin=0;
        for (j=1;j<=N;++j)
        {
          if (j!=i)
          {
            aux=ap_C->m[j][i]*ap_C->m[j][i];
            term=(sqrsumlines->v[j]-aux)/(aux+small);  /* addition of small
                  prevents division by zero */
            termmin=m_minval(termmin,term);
          }
        }
        if (termmin==0)
          termmin=1e-30;
        reg->v[i]=R*m_minval(1,sqrt(termmin)/(double) N)*
             m_maxval(fabs(ap_C->m[i][i]),sumdiag);
      }
    }
    while (decomp && R<1.0)
    {
      ++ret;
      for (i=1;i<=N;++i)
        ap_C->m[i][i]+=reg->v[i];
      decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,0.0);
      if (decomp)
      {
        /* Matrix is still singular, we increase the regularization
        coefficients: */
        R*=incfact;
        for (i=1;i<=N;++i)
          reg->v[i]*=incfact;
      }
    }
    if (decomp)
    {
      ret=-ret;
    }
    /* 
    else
    {
      printf("Repaired system matrix:\n");
      printmatrixlist(ap_C);
    }
    */
    dispvector(&sqrsumlines);
    dispvector(&reg);
  } else
  {
    /* Regularization by addition of fictitious points: */
    if (reclevel<2*dim)
    {
      double wmax,wmax1,wsum;
      int iwmax;
      vector xwdist,xwmax,newval,neww;
      matrix newpoints;
      ++ret;
      /* Calculate the greatest weight, its index and the second greatest weight: */
      wmax=wmax1=w->v[1]; iwmax=1;
      xwdist=getvector(dim);
      xwmax=getvector(dim);
      for (i=2;i<=m;++i)
        if (w->v[i]>wmax)
        {
          wmax=w->v[i];   iwmax=i;
        } else if (w->v[i]>wmax1)
          wmax1=w->v[1];
      /* Point with maximum weight: */
      for (j=1;j<=dim;++j)
      {
        xwmax->v[j]=points->m[iwmax][j];
        xwdist->v[j]=0;
      }
      /* Calculate the weighted average component distance with respect to the
      point with the max. weight: */
      wsum=0;  /* wavdist=0; */
      for (i=1;i<=m;++i)
        if (i!=iwmax)
        {
          wsum+=w->v[i];
          for (j=1;j<=dim;++j)
            xwdist->v[j]+=fabs(points->m[i][j]-xwmax->v[j])*w->v[i];
          /*
          dist=vecnorm(vectordif0(xwmax,x,&x));
          wavdist+=dist*w->v[i];
          */
        }
      /* Divide components by sum of weights to get weighted average, then reduce
      the w. distance additionally */
      for (j=1;j<=dim;++j)
        xwdist->v[j]/=(wsum*(double) (100*N));
      /* Derive a small weight for additional points by reducing the second
      largest weight; fact. 10000 makes a point 100 times less important: */
      wmax1/=((double) (10000*N*dim)); 
      /* Add randomly a set of dim new points around the point with the largest
      weight in order to stabilize the least square equation; weights are small
      so that approximation of the original dataset should not be spoiled: */
      newpoints=getmatrix(m+dim,dim);
      newval=getvector(m+dim);
      neww=getvector(m+dim);
      for (i=1;i<=m;++i)  /* Transcription of original data: */
      {
        for (j=1;j<=dim;++j)
          newpoints->m[i][j]=points->m[i][j];
        neww->v[i]=w->v[i];
        newval->v[i]=val->v[i];
      }
      for (i=m+1;i<=m+dim;++i)  /* Transcription of original data: */
      {
        for (j=1;j<=dim;++j)
          newpoints->m[i][j]=xwmax->v[j]+xwdist->v[j]*random1();
        newval->v[i]=val->v[iwmax];
        neww->v[i]=wmax1;
      }
      m_threadunlock(ap_lock);
      ret+=coeflinpolapproxraw(newpoints,newval,neww,rawaddr);
      m_threadlocksleep(ap_lock,1);
      dispmatrix(&newpoints);
      dispvector(&newval);
      dispvector(&neww);
      dispvector(&xwdist);
      dispvector(&xwmax);
      --reclevel;
      m_threadunlock(ap_lock);
      return ret;
    } else
    {
      errfunc0("coeflinpolapproxraw");
      sprintf(ers(),"The system matrix is not invertable.\n");
      sprintf(ers(),"Attempt to condition the system matrix failed.\n");
      errfunc2();
      ret=-ret;
      --reclevel;
      m_threadunlock(ap_lock);
      return ret;
    }
  }
}
if (ret>=0)
  solvLDLTplain(ap_decomp,ap_decomp,raw,raw);
else for (i=1;i<=N;++i)
  raw->v[i]=0;
if (ap_forceclean)
{
  dispmatrix(&ap_C);
  dispmatrix(&ap_decomp);
  dispvector(&ap_d);
} else
{
  if (N>100)
  {
    dispmatrix(&ap_C);
  dispmatrix(&ap_decomp);
    dispvector(&ap_d);
  }
}
--reclevel;
m_threadunlock(ap_lock);
return ret;
}




double linpolapprox(vector x,matrix points,vector val,vector w)
    /* Calculates the value of a linear pol. approximation of data in point x.
    points must contain co-ordinates of data points, val must contain values
    in these points to be fitted, and w must contain the corresponding SQUARED
    weights. A warning is launched if the initial problem is not well posed so
    that it had to be conditioned by adding imaginary points, and an error is
    launched if the repair failed to produce results.
      Remark:
      For many applications it is better to separately perform calculation of
    approximation coefficients by coeflinpolapproxraw() and then call
    linpolraw() to evaluate the approximation, since in this way it can be
    controlled if the approximation problem is well defined and separate
    actions can be performed if it is not.
    $A Igor nov03; */
{
int ret;
double retval;
ret=coeflinpolapproxraw(points,val,w,&ap_raw);
if (ret)
{
  if (ret>0)
  {
    warnfunc1(1,"linpolapprox");
    sprintf(ers(),"Initial approximation problem was not well defined,\n");
    sprintf(ers(),"conditioned by adding imaginary points (%i passes).\n",ret);
    warnfunc2();
  } else
  {
    errfunc0("linpolapprox");
    sprintf(ers(),"The approximation problem is not well posed, reparation failed.\n");
    warnfunc2();
  }
}
if (ap_forceclean || ap_raw->d>100)
  dispvector(&ap_raw);
retval=linpolraw(x,ap_raw);
return retval;
}


static int coeflinpolapproxgradraw1(matrix points,matrix val,matrix w,vector *rawaddr)
    /* Does the same as coeflinpolapproxgradraw(), except that it first
    creates a matrix of values of basis functions in sampling points and then
    calculates the approximation by coeflincombapproxgrad(). On contrary,
    coeflinpolapproxgradraw() assembles the system of equations without this
    intermediate storage.
      This function is much slower than coeflinpolapproxraw() and was primarily
    created  for testing coeflincombapproxgrad().
    $A, Igor nov03; */
{
int i,k,l,ind,m,N,dim,ret;
matrix basval=NULL;
m=points->d1;  dim=points->d2;  N=dim+1;
basval=getmatrix(m,N*(dim+1));
/* Fill basval with values of basis functions in points: */
for (k=1;k<=m;++k)
{
  /* Const. term, derivatives are zero: */
  basval->m[k][1]=1;
  for (l=1;l<=dim;++l)
    basval->m[k][l+1]=0;
}
ind=dim+2;
for (i=1;i<=dim;++i)
{
  /* Lin. term i, i-th derivative is 1, others are 0: */
  for (k=1;k<=m;++k)
  {
    basval->m[k][ind]=points->m[k][i];  /* value of the i-th lin. term */
    for (l=1;l<=dim;++l)  /* derivatives */
      basval->m[k][ind+l]=0;
    basval->m[k][ind+i]=1;
  }
  ind+=(dim+1);
}
ret=coeflincombapproxgrad(basval,val,w,rawaddr);
dispmatrix(&basval);
return ret;
}



int coeflinpolapproxgradraw(matrix points,matrix val,matrix w,vector *rawaddr)
    /* Calculates coefficients of a linear pol. approximation on the basis of
    function values and gradients and stores them to *rawaddr. points must be
    a matrix whose LINES contain co-ordinates of sampling points, val must
    contain values and derivatives with respect to all independent variables
    (co-ordinates) of the sampled function in these points (each row contains
    the value and all derivatives in turns for one point), and w must contain
    the corresponding SQUARE weigth that weigh the importance of values and
    derivatives with respect to each variable (the dimension must therefore be
    the same as that of val). points, val and w must be allocated and of
    consistent dimensions since this is not checked by the function. If
    necessary, space for coefficients is allocated anew or re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) by values close to the value
    in the most important point (i.e. that with the highest weight for the
    value, or just one of them if they are equally weighted). The returned
    value is then a counter of how many times the repair algorithm has been
    applied in order to obtain a solution. If all attempts to get a solution
    fail, then a negative value is returned (equal to minus the number of
    attempts). In each attempt dim points are added where dim is dimension of
    the space.
      WARNINING:
      w must contain the SQUARED weights!
    $A Igor nov03; */
{
int i,j,i1,i2,k,ind1,ind2,N,m,dim,ret=0,decomp;
static int reclevel;
vector raw;
m_threadlocksleep(ap_lock,1);
++reclevel;
m=points->d1;  dim=points->d2;  N=dim+1;
if (*rawaddr!=NULL)
{
  if ((*rawaddr)->d!=N)
  {
    dispvector(rawaddr);
    *rawaddr=getvector(N);
  }
} else
  *rawaddr=getvector(N);
raw=*rawaddr;
if (ap_C!=NULL)
{
  if (ap_C->d1!=N || ap_C->d2!=N)
  {
    dispmatrix(&ap_C);
    ap_C=getmatrix(N,N);
  }
} else
  ap_C=getmatrix(N,N);
if (ap_decomp!=NULL)
{
  if (ap_decomp->d1!=N || ap_decomp->d2!=N)
  {
    dispmatrix(&ap_decomp);
    ap_decomp=getmatrix(N,N);
  }
} else
  ap_decomp=getmatrix(N,N);
/* Assembling of the system matrix and the right-hand side vector: we arrange
inner and outer iteration over all basis functions in such a way that the form
of basis functions is always known: */
/* First bas. func. constant, second bas. function constant (ind2=1): */
raw->v[1]=0;
ap_C->m[1][1]=0;
for (k=1;k<=m;++k)
{
  raw->v[1]+=w->m[k][1]* /* 1 * */ val->m[k][1];
  ap_C->m[1][1]+=w->m[k][1] /* 1*1 */;
  /* All derivatives are 0 for const. bas. func. */
}
/* First bas. func. constant, second bas. function linear (ind2=2...dim+1): */
for (i2=1;i2<=dim;++i2)   /* ind2 = i2+1  */
{
  ind2=i2+1;
  ap_C->m[1][ind2]=0;
  for (k=1;k<=m;++k)
    ap_C->m[1][ind2]+=w->m[k][1]* /* 1 * */ points->m[k][i2];
  ap_C->m[ind2][1]=ap_C->m[1][ind2];  /* symmetrize */
}
/* First bas. function linear (x_i1), ind1=i1+1: */
for (i1=1;i1<=dim;++i1)
{
  ind1=i1+1;
  /* First bas. func. linear, second bas. function constant (ind2=1): */
  raw->v[ind1]=0;
  /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  for (k=1;k<=m;++k)
  {
    raw->v[ind1]+=w->m[k][1]*points->m[k][i1]*val->m[k][1]+
    /* Contribution of gradient elements; in w and val, the column is i1+1=ind1 */
       w->m[k][ind1]* /* *1 */ val->m[k][ind1];
    /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  }
  /* First bas. func. linear, second bas. function linear (ind2=2...dim+1): */
  for (i2=i1;i2<=dim;++i2)   /* ind2 = i2+1; from i1 because of symmetry  */
  {
    ind2=i2+1;
    ap_C->m[ind1][ind2]=0;
    for (k=1;k<=m;++k)
      ap_C->m[ind1][ind2]+=w->m[k][1]*points->m[k][i1]*points->m[k][i2];
    /* Contribution of gradient data: */
    if (i1==i2)
      for (k=1;k<=m;++k)
        ap_C->m[ind1][ind2]+=w->m[k][ind1] /* *1*1* */ ;
    ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
  }
  ind2=dim+2;
}
decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,1e-14);
if (decomp)
{
  if (1)
  {
    double R=1.0e-9,incfact=100.0,sumdiag,term,termmin,aux,small,small2;
    vector reg=NULL,sqrsumlines;
    /* Regularization by addition of coefficient size minimization terms,
    which leads to addition of small positive values to diagonal terms of the
    system matrix: */
    /*
    printf("Singular system matrix:\n");
    printmatrixlist(ap_C);
    */
    reg=getvector(N);
    sqrsumlines=getvector(N);
    /* Calculate root mean square of diagonal elements: */
    sumdiag=0;
    for (i=1;i<=N;++i)
      sumdiag+=ap_C->m[i][i]*ap_C->m[i][i];
    sumdiag=sqrt(sumdiag)/((double) (10*N));
    small=sumdiag*R*1e-5;
    small2=sumdiag*sumdiag*R*R*1e-5;  /* Square measure for a small value */
    /* Calculate the square sums for all lines: */
    for (i=1;i<=N;++i)
    {
      sqrsumlines->v[i]=0;
      for (j=1;j<=N;++j)
        sqrsumlines->v[i]+=ap_C->m[i][j]*ap_C->m[i][j];
      if (sqrsumlines->v[i]<small2)
        sqrsumlines->v[i]=small2;
    }
    /* Calculate the coefficients: */
    if (N==1)
    {
      reg->v[1]=R*fabs(ap_C->m[1][1]);
      if (reg->v[1]<1e-40)
        reg->v[1]=1e-40;
    } else
    {
      for (i=1;i<=N;++i)
      {
        /* Minimum of sums over lines, we omit square root and coef. R/N: */
        termmin=0;
        for (j=1;j<=N;++j)
        {
          if (j!=i)
          {
            aux=ap_C->m[j][i]*ap_C->m[j][i];
            term=(sqrsumlines->v[j]-aux)/(aux+small);  /* addition of small
                  prevents division by zero */
            termmin=m_minval(termmin,term);
          }
        }
        if (termmin==0)
          termmin=1e-30;
        reg->v[i]=R*m_minval(1,sqrt(termmin)/(double) N)*
             m_maxval(fabs(ap_C->m[i][i]),sumdiag);
      }
    }
    while (decomp && R<1.0)
    {
      ++ret;
      for (i=1;i<=N;++i)
        ap_C->m[i][i]+=reg->v[i];
      decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,0.0);
      if (decomp)
      {
        /* Matrix is still singular, we increase the regularization
        coefficients: */
        R*=incfact;
        for (i=1;i<=N;++i)
          reg->v[i]*=incfact;
      }
    }
    if (decomp)
    {
      ret=-ret;
    }
    /* 
    else
    {
      printf("Repaired system matrix:\n");
      printmatrixlist(ap_C);
    }
    */
    dispvector(&sqrsumlines);
    dispvector(&reg);
  } else
  {
    /* If the LDLT decomposition can not be done (i.e. ap_C is not invertible),
    we try to add randomly a number of fictious points in order to condition the
    system, but in such a way that approximation of original data is not spoiled
    too much. A limited number of attempts is done: */
    if (reclevel<2*dim)
    {
      /* If the LDLT decomposition can not be done (i.e. ap_C is not invertible),
      we try to add randomly a number of fictious points in order to condition the
      system, but in such a way that approximation of original data is not spoiled
      too much. A limited number of attempts is done: */
      double wmax,wmax1,wsum;
      int iwmax;
      vector xwdist,xwmax;
      matrix newval,neww;
      matrix newpoints;
      ++ret;
      /* Calculate the greatest weight, its index and the second greatest weight: */
      wmax=wmax1=w->m[k][1]; iwmax=1;
      xwdist=getvector(dim);
      xwmax=getvector(dim);
      for (i=2;i<=m;++i)
        if (w->m[i][1]>wmax)
        {
          wmax=w->m[i][1];   iwmax=i;
        } else if (w->m[i][1]>wmax1)
          wmax1=w->m[1][1];
      /* Point with maximum weight: */
      for (j=1;j<=dim;++j)
      {
        xwmax->v[j]=points->m[iwmax][j];
        xwdist->v[j]=0;
      }
      /* Calculate the weighted average component distance with respect to the
      point with the max. weight: */
      wsum=0;  /* wavdist=0; */
      for (i=1;i<=m;++i)
        if (i!=iwmax)
        {
          wsum+=w->m[i][1];
          for (j=1;j<=dim;++j)
            xwdist->v[j]+=fabs(points->m[i][j]-xwmax->v[j])*w->m[i][1];
          /*
          dist=vecnorm(vectordif0(xwmax,x,&x));
          wavdist+=dist*w->v[i];
          */
        }
      /* Divide components by sum of weights to get weighted average, then reduce
      the w. distance additionally */
      for (j=1;j<=dim;++j)
        xwdist->v[j]/=(wsum*(double) (100*N));
      /* Derive a small weight for additional points by reducing the second
      largest weight; fact. 10000 makes a point 100 times less important: */
      wmax1/=((double) (10000*N*dim)); 
      /* Add randomly a set of dim new points around the point with the largest
      weight in order to stabilize the least square equation; weights are small
      so that approximation of the original dataset should not be spoiled: */
      newpoints=getmatrix(m+dim,dim);
      newval=getmatrix(m+dim,val->d2);
      neww=getmatrix(m+dim,w->d2);
      for (i=1;i<=m;++i)  /* Transcription of original data: */
      {
        for (j=1;j<=dim;++j)
          newpoints->m[i][j]=points->m[i][j];
        for (j=1;j>=dim+1;++i)
        {
          neww->m[i][j]=w->m[i][j];
          newval->m[i][j]=val->m[i][j];
        }
      }
      for (i=m+1;i<=m+dim;++i)  /* Transcription of original data: */
      {
        for (j=1;j<=dim;++j)
          newpoints->m[i][j]=xwmax->v[j]+xwdist->v[j]*random1();
        for (j=1;j>=dim+1;++i)
        {
          newval->m[i][j]=val->m[iwmax][j];
          neww->m[i][j]=(wmax1/wmax)*w->m[iwmax][j];
        }
      }
      m_threadunlock(ap_lock);
      ret+=coeflinpolapproxgradraw(newpoints,newval,neww,rawaddr);
      m_threadlocksleep(ap_lock,1);
      dispmatrix(&newpoints);
      dispmatrix(&newval);
      dispmatrix(&neww);
      dispvector(&xwdist);
      dispvector(&xwmax);
      --reclevel;
      m_threadunlock(ap_lock);
      return ret;
    } else
    {
      errfunc0("coeflinpolapproxraw");
      sprintf(ers(),"The system matrix is not invertable.\n");
      sprintf(ers(),"Attempt to condition the system matrix failed.\n");
      errfunc2();
      ret=-ret;
      --reclevel;
      m_threadunlock(ap_lock);
      return ret;
    }
  }
}
if (ret>=0)
  solvLDLTplain(ap_decomp,ap_decomp,raw,raw);
else for (i=1;i<=N;++i)
  raw->v[i]=0;
if (ap_forceclean)
{
  dispmatrix(&ap_C);
  dispmatrix(&ap_decomp);
  dispvector(&ap_d);
} else
{
  if (N>100)
  {
    dispmatrix(&ap_C);
  dispmatrix(&ap_decomp);
    dispvector(&ap_d);
  }
}
--reclevel;
m_threadunlock(ap_lock);
return ret;
}




double linpolapproxgrad(vector x,matrix points,matrix val,matrix w)
    /* Calculates the value of a linear pol. approximation of data in point x.
    points must contain co-ordinates of data points, val must contain values
    and gradients in these points to be fitted (each line corresponds to one
    point and contains the value followed by all derivatives), and w must
    contain the corresponding SQUARED weights. A warning is launched if the
    initial problem is not well posed so that it had to be conditioned by
    adding imaginary points, and an error report is launched if the repair
    failed to produce results.
      Remark:
      For many applications it is better to separately perform calculation of
    approximation coefficients by coeflinpolapproxgradraw() and then call
    linpolraw() to evaluate the approximation, since in this way it can be
    controlled if the approximation problem is well defined and separate
    actions can be performed if it is not.
    $A Igor nov03; */
{
int ret;
double retval;
ret=coeflinpolapproxgradraw(points,val,w,&ap_raw);
if (ret)
{
  if (ret>0)
  {
    warnfunc1(1,"linpolapprox");
    sprintf(ers(),"Initial approximation problem was not well defined,\n");
    sprintf(ers(),"conditioned by adding imaginary points (%i passes).\n",ret);
    warnfunc2();
  } else
  {
    errfunc0("linpolapprox");
    sprintf(ers(),"The approximation problem is not well posed, reparation failed.\n");
    warnfunc2();
  }
}
if (ap_forceclean || ap_raw->d>100)
  dispvector(&ap_raw);
retval=linpolraw(x,ap_raw);
return retval;
}




         /*****************************************************/
         /*                                                   */
         /*      APPROXIMATION WITH QUADRATIC POLYNOMIALS     */
         /*                                                   */
         /*****************************************************/


  /* CONVERSION BETWEEN RAW AND NORMAL FORM OF COEFFICIENTS: */

void coefquadpolraw(matrix G,vector b,double c,vector *addrraw)
    /* Conversion from regular form of coefficients of a quadratic function to
    raw form. The quatratic function is 1/2 x_T G x + b_T x + c. In the raw
    form, coefficients are arranged in a single vector and sorted in the
    following order: c, b[1], b[2], ..., b[dim], G[1,1], G[1,2], ..., G[1,dim],
    G[2,2], ..., G[2,dim], G[3,3], ..., G[3,dim] where dim is the number of
    the variables (dimension of the space).
      G, b and c must be allocated and of correct dimensions since this is not
    checked. G must be a symmetric matrix. Only upper triangle is taken into
    account at conversion.
      addrraw may not be NULL, but it can point to a NULL vector. The function
    allocates or reallocates the space for *addrraw if necessary.
    $A Igor nov03; */
{
vector raw;
int dim,ind,N,i,j;
dim=G->d1;
N=(dim+1)*(dim+2)/2;
if (*addrraw!=NULL)
{
  if ((*addrraw)->d!=N)
  {
    dispvector(addrraw);
    *addrraw=getvector(N);
  }
} else
  *addrraw=getvector(N);
raw=*addrraw;
raw->v[1]=c;
for (i=1;i<=dim;++i)
  raw->v[i+1]=b->v[i];
ind=dim+2;  /*current index */
for (i=1;i<=dim;++i)
{
  raw->v[ind]=G->m[i][i];
  ++ind;
  for (j=i+1;j<=dim;++j)
  {
    raw->v[ind]=G->m[i][j];
    ++ind;
  }
}
}


void coefquadpolreg(vector raw,matrix *addrG,vector *addrb,double *addrc)
    /* Rearrangement of raw coefficients of a quadratic function to a regular
    form. Coefficient are arranged in matrix *addrG, vector *addrb and scalar
    *addrc. If necessary, the matrix and the vector are allocated or
    re-allocated. Although the matrix is symmetric, all elements are filled.
    See also coefquadpolraw()!
      addrG, addrb and addrc may not be NULL. Wector raw must be allocated and
    of correct dimension (at least 3).
    $A Igror nov03; */
{
matrix G;
vector b;
int i,j,ind,dim;
/* Calc. dimension, number of coefficients must be (dim+1)(dim+2)/2: */
dim=(int) round((sqrt((double) (1+8*raw->d))-3)/2);
if ((dim+1)*(dim+2)/2!=raw->d)
{
  errfunc0("coefquadpolreg");
  sprintf(ers(),"Wrong number of coefficients of quadratic function.");
  errfunc2();
  dispmatrix(addrG);
  dispvector(addrb);
  return;
}
if (*addrG!=NULL)
{
  if ((*addrG)->d1!=dim || (*addrG)->d2!=dim)
  {
    dispmatrix(addrG);
    *addrG=getmatrix(dim,dim);
  }
} else
  *addrG=getmatrix(dim,dim);
G=*addrG;
if (*addrb!=NULL)
{
  if ((*addrb)->d!=dim)
  {
    dispvector(addrb);
    *addrb=getvector(dim);
  }
} else
  *addrb=getvector(dim);
b=*addrb;
*addrc=raw->v[1];
for (i=1;i<=dim;++i)
  b->v[i]=raw->v[i+1];
ind=dim+2;
for (i=1;i<=dim;++i)
{
  G->m[i][i]=raw->v[ind];
  ++ind;
  for (j=i+1;j<=dim;++j)
  {
    G->m[i][j]=G->m[j][i]=raw->v[ind];
    ++ind;
  }
}
}

  /* CALCULATION OF QUADRATIC POLYNOMIAL AND ITS GRADIENT: */

double quadpol(vector x,matrix G,vector b,double c)
    /* Returns the value of the quadratic function with coefficients G, b and
    c at x. Only upper triangle of G is used in calculation.
    $A Igor nov03; */
{
double ret;
int i,j,dim;
dim=x->d;
ret=c;
for (i=1;i<=dim;++i)
  ret+=b->v[i]*x->v[i];
for (i=1;i<=dim;++i)
{
  ret+=G->m[i][i]*x->v[i]*x->v[i]/2;
  for (j=i+1;j<=dim;++j)
    ret+=G->m[i][j]*x->v[i]*x->v[j];
}
return ret;
}

vector gradquadpol(vector x,matrix G,vector b,vector *addrgrad)
    /* Calculates gradient of a quadratic function with quadratic and linear
    coefficients G and b, and stores it to *addrgrad. x, G and b must be
    allocated and of consistent dimensions since this is not checked in the
    function. If necessary the function allocates or reallocates the storage
    for gradient.
      Only the upper triangle of G (which is symmetric) is used in calculation.
    $A Igor nov03; */
{
int i,j,dim;
vector grad;
dim=x->d;
copyvector(b,addrgrad);
grad=*addrgrad;
for(i=1;i<=dim;++i)
{
  grad->v[i]+=G->m[i][i]*x->v[i];
  for (j=i+1;j<=dim;++j)
  {
    grad->v[i]+=G->m[i][j]*x->v[j];
    grad->v[j]+=G->m[i][j]*x->v[i];
  }
}
return grad;
}


double derquadpol(vector x,int which,matrix G,vector b)
    /* Returns the derivative of a quadratic function whose quadratic and
    linear coefficients are G and b, with respect to the variable which at
    the point x.
    $A igor nov03; */
{
double ret=0;
int i,dim=x->d;
ret+=b->v[which];
for (i=which;i<=dim;++i)
  ret+=G->m[which][i]*x->v[i];
for (i=1;i<which;++i)
  ret+=G->m[i][which]*x->v[i];
return ret;
}


double quadpolraw(vector x,vector raw)
    /* Calculates a quadratic function in x whose raw coefficients are in
    raw. x and raw must be allocated and of consistent dimensions since this
    is not checked in the function.
    $A Igor nov03; */
{
double ret;
int i,j,ind,dim;
dim=x->d;
ret=raw->v[1];
for (i=1;i<=dim;++i)
  ret+=raw->v[i+1]*x->v[i];
ind=dim+2;
for (i=1;i<=dim;++i)
{
  ret+=raw->v[ind]*x->v[i]*x->v[i]/2;
  ++ind;
  for (j=i+1;j<=dim;++j)
  {
    ret+=raw->v[ind]*x->v[i]*x->v[j];
    ++ind;
  }
}
return ret;
}



vector gradquadpolraw(vector x,vector raw,vector *addrgrad)
    /* Calculates gradient of a quadratic function with coefficients raw
    arranged in raw form, and stores it to *addrgrad. x and raw must be
    allocated and of consistent dimensions since this is not checked in the
    function. If necessary the function allocates or reallocates the storage
    for gradient.
    $A Igor nov03; */
{
int i,j,dim,ind;
vector grad;
dim=x->d;
if (*addrgrad!=NULL)
{
  if ((*addrgrad)->d!=dim)
  {
    dispvector(addrgrad);
    *addrgrad=getvector(dim);
  }
} else
  *addrgrad=getvector(dim);
grad=*addrgrad;
for (i=1;i<=dim;++i)
  grad->v[i]=raw->v[i+1];
ind=dim+2;
for (i=1;i<=dim;++i)
{
  grad->v[i]+=raw->v[ind]*x->v[i];
  ++ind;
  for (j=i+1;j<=dim;++j)
  {
    grad->v[i]+=raw->v[ind]*x->v[j];
    grad->v[j]+=raw->v[ind]*x->v[i];
    ++ind;
  }
}
return grad;
}


double derquadpolraw(vector x,int which,vector raw)
    /* Returns the derivative of the quadratic function with raw coefficients
    in raw at x with respect to the variable which. x and raw must be allocated
    with consistent dimensions and it must be 0<=which<=which->d, since this is
    not checked.
      If which==0 then the value of the quadratic function is returned.
    $A Igor nov03; */
{
int i,dim,ind;
double ret;
if (which==0)
  return quadpolraw(x,raw);
dim=x->d;
ret=raw->v[which+1];
ind=dim+2;
for (i=1;i<which;++i)
{
  ret+=raw->v[ind+which-i]*x->v[i];
  ind+=dim-i+1;
}
for (i=which;i<=dim;++i)
{
  ret+=raw->v[ind]*x->v[i];
  ++ind;
}
return ret;
}




  /* CALCULATING THE APPROXIMATION: */

  /* Remark: Functions for calculating quadratic approximatinos are optimized
for calculating approximation in many point, i.e. with possibly different
data sets of the same dimensions. Therefore, auxiliary matrices are static
variables and it is possible not to deallocate them between successive
computations, which saves the computational time. */


int coefquadpolapproxraw_old(matrix points,vector val,vector w,vector *rawaddr)
    /* Calculates coefficients of a quadratic approximation and stores them
    to *rawaddr. points must be a matrix whose LINES contain co-ordinates
    of sampling points, val must contain values of the sampled function in
    these points, and w must contain the corresponding SQUARE weigth that weigh
    the importance of individual points. points, val and w must be allocated
    and of consistent dimensions since this is not checked by the function.
    If necessary, space for coefficients is allocated anew or re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) by values close to the value
    in the most important point (or just one of them if they are equally
    weighted). The returned value is then a counter of how many times the
    system algorithm has been applied in order to obtain a solution. If all
    attempts to get a solution fail then a negative value is returned (equal
    to minus the number of attempts). In each attempt dim points are added
    where dim is dimension of the space.
      WARNINING:
      w must contain the SQUARED weights!
      REMARK:
      This is an old version of a function. It is approx. 1/3 quicker than the
    newer one, but uses additional auxiliary storage for values of basic
    functions in all points (which can be considerable for large number of
    dimensions since the dimension grows
    $A Igor nov03; */
{
int i,j,k,ind,N,m,dim,ret=0;
static int reclevel;
vector raw;
m_threadlocksleep(ap_lock,1);
++reclevel;
m=points->d1;  dim=points->d2;  N=(dim+1)*(dim+2)/2;
if (*rawaddr!=NULL)
{
  if ((*rawaddr)->d!=N)
  {
    dispvector(rawaddr);
    *rawaddr=getvector(N);
  }
} else
  *rawaddr=getvector(N);
raw=*rawaddr;
if (ap_C!=NULL)
{
  if (ap_C->d1!=N || ap_C->d2!=N)
  {
    dispmatrix(&ap_C);
    ap_C=getmatrix(N,N);
  }
} else
  ap_C=getmatrix(N,N);
if (ap_basfunc!=NULL)
{
  if (ap_basfunc->d1<N || ap_basfunc->d2<m)
  {
    dispmatrix(&ap_basfunc);
    ap_basfunc=getmatrix(N,m);
  }
} else
  ap_basfunc=getmatrix(N,m);
/* Evlauating basis functions in all points: */
for (k=1;k<=m;++k)
  ap_basfunc->m[1][k]=1;  /* constant term */
for (i=1;i<=dim;++i)
  for (k=1;k<=m;++k)
    ap_basfunc->m[i+1][k]=points->m[k][i];  /* lin. terms */
ind=dim+2;
for (i=1;i<=dim;++i)
{
  for (k=1;k<=m;++k)
    ap_basfunc->m[ind][k]=points->m[k][i]*points->m[k][i]/2; /* quadrat. term */
  ++ind;  
  for (j=i+1;j<=dim;++j)
  {
    for (k=1;k<=m;++k)
      ap_basfunc->m[ind][k]=points->m[k][i]*points->m[k][j]; /* quadrat. term */
    ++ind;
  }
}
/* Assembling of the system matrix and the right-hand side vector: */
for (i=1;i<=N;++i)
{
  raw->v[i]=0;
  for (k=1;k<=m;++k)
    raw->v[i]+=w->v[k]*ap_basfunc->m[i][k]*val->v[k];
  ap_C->m[i][i]=0;
  for (k=1;k<=m;++k)
    ap_C->m[i][i]+=w->v[k]*ap_basfunc->m[i][k]*ap_basfunc->m[i][k];
  for (j=i+1;j<=N;++j)
  {
    ap_C->m[i][j]=0;
    for (k=1;k<=m;++k)
      ap_C->m[i][j]+=w->v[k]*ap_basfunc->m[i][k]*ap_basfunc->m[j][k];
    ap_C->m[j][i]=ap_C->m[i][j];  /* symmetric */
  }
}
if (LDLTdecomptolplain(ap_C,ap_C,ap_C,0.0))
{
  if (reclevel<2*dim)
  {
    double wmax,wmax1,wsum;
    int iwmax;
    vector xwdist,xwmax,newval,neww;
    matrix newpoints;
    ++ret;
    /* Calculate the greatest weight, its index and the second greatest weight: */
    wmax=wmax1=w->v[1]; iwmax=1;
    xwdist=getvector(dim);
    xwmax=getvector(dim);
    for (i=2;i<=m;++i)
      if (w->v[i]>wmax)
      {
        wmax=w->v[i];   iwmax=i;
      } else if (w->v[i]>wmax1)
        wmax1=w->v[1];
    /* Point with maximum weight: */
    for (j=1;j<=dim;++j)
    {
      xwmax->v[j]=points->m[iwmax][j];
      xwdist->v[j]=0;
    }
    /* Calculate the weighted average component distance with respect to the
    point with the max. weight: */
    wsum=0;  /* wavdist=0; */
    for (i=1;i<=m;++i)
      if (i!=iwmax)
      {
        wsum+=w->v[i];
        for (j=1;j<=dim;++j)
          xwdist->v[j]+=fabs(points->m[i][j]-xwmax->v[j])*w->v[i];
        /*
        dist=vecnorm(vectordif0(xwmax,x,&x));
        wavdist+=dist*w->v[i];
        */
      }
    /* Divide components by sum of weights to get weighted average, then reduce
    the w. distance additionally */
    for (j=1;j<=dim;++j)
      xwdist->v[j]/=(wsum*(double) (100*N));
    /* Derive a small weight for additional points by reducing the second
    largest weight; fact. 10000 makes a point 100 times less important: */
    wmax1/=((double) (10000*N*dim)); 
    /* Add randomly a set of dim new points around the point with the largest
    weight in order to stabilize the least square equation; weights are small
    so that approximation of the original dataset should not be spoiled: */
    newpoints=getmatrix(m+dim,dim);
    newval=getvector(m+dim);
    neww=getvector(m+dim);
    for (i=1;i<=m;++i)  /* Transcription of original data: */
    {
      for (j=1;j<=dim;++j)
        newpoints->m[i][j]=points->m[i][j];
      neww->v[i]=w->v[i];
      newval->v[i]=val->v[i];
    }
    for (i=m+1;i<=m+dim;++i)  /* Transcription of original data: */
    {
      for (j=1;j<=dim;++j)
        newpoints->m[i][j]=xwmax->v[j]+xwdist->v[j]*random1();
      newval->v[i]=val->v[iwmax];
      neww->v[i]=wmax1;
    }
    m_threadunlock(ap_lock);
    ret+=coefquadpolapproxraw_old(newpoints,newval,neww,rawaddr);
    m_threadlocksleep(ap_lock,1);
    dispmatrix(&newpoints);
    dispvector(&newval);
    dispvector(&neww);
    dispvector(&xwdist);
    dispvector(&xwmax);
    --reclevel;
    m_threadunlock(ap_lock);
    return ret;
  } else
  {
    errfunc0("coefquadpolapproxraw");
    sprintf(ers(),"The system matrix is not invertable.\n");
    sprintf(ers(),"Attempt to condition the system matrix failed.\n");
    errfunc2();
    ret=-ret;
    --reclevel;
    m_threadunlock(ap_lock);
    return ret;
  }
}
solvLDLTplain(ap_C,ap_C,raw,raw);
--reclevel;
m_threadunlock(ap_lock);
if (ap_forceclean)
{
  dispmatrix(&ap_C);
  dispmatrix(&ap_basfunc);
  dispvector(&ap_d);
} else
{
  if (N>100)
  {
    dispmatrix(&ap_C);
    dispvector(&ap_d);
  }
  if (N>100 || m*N>100000)
    dispmatrix(&ap_basfunc);
}
return ret;
}


int coefquadpolapproxraw1(matrix points,vector val,vector w,vector *rawaddr)
    /* Does the same as coefquadpolapproxraw(), except that it first creates a
    matrix of values of basis functions in sampling points and then calculates
    the approximation by coeflincombapprox(). On contrary, coefquadpolapproxraw()
    assembles the system of equations without this intermediate storage.
      This function is slower than coefquadpolapproxraw() and was primarily created 
    for testing coeflincombapprox().
    $A, Igor nov03; */
{
int i,j,k,ind,m,N,dim,ret;
matrix basval=NULL;
m=points->d1;  dim=points->d2;  N=(dim+1)*(dim+2)/2;
basval=getmatrix(m,N);
/* Fill basval with values of quadratic basis functions in points: */
for (k=1;k<=m;++k)
  basval->m[k][1]=1;
ind=2;
for (i=1;i<=dim;++i)
{
  for (k=1;k<=m;++k)
    basval->m[k][ind]=points->m[k][i];
  ++ind;
}
ind=dim+2;
for (i=1;i<=dim;++i)
{
  for (k=1;k<=m;++k)
    basval->m[k][ind]=points->m[k][i]*points->m[k][i]/2;
  ++ind;
  for (j=i+1;j<=dim;++j)
  {
    for (k=1;k<=m;++k)
      basval->m[k][ind]=points->m[k][i]*points->m[k][j];
    ++ind;
  }
}
ret=coeflincombapprox(basval,val,w,rawaddr);
dispmatrix(&basval);
return ret;
}


int coefquadpolapproxraw(matrix points,vector val,vector w,vector *rawaddr)
    /* Calculates coefficients of a quadratic approximation and stores them
    to *rawaddr. points must be a matrix whose LINES contain co-ordinates
    of sampling points, val must contain values of the sampled function in
    these points, and w must contain the corresponding SQUARE weigth that weigh
    the importance of individual points. points, val and w must be allocated
    and of consistent dimensions since this is not checked by the function.
    If necessary, space for coefficients is allocated anew or re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) by values close to the value
    in the most important point (or just one of them if they are equally
    weighted). The returned value is then a counter of how many times the
    system algorithm has been applied in order to obtain a solution. If all
    attempts to get a solution fail then a negative value is returned (equal
    to minus the number of attempts). In each attempt dim points are added
    where dim is dimension of the space.
      WARNINING:
      w must contain the SQUARED weights!
    $A Igor nov03; */
{
int i,j,i1,j1,i2,j2,k,ind1,ind2,N,m,dim,ret=0,decomp;
static int reclevel;
vector raw;
m_threadlocksleep(ap_lock,1);
++reclevel;
m=points->d1;  dim=points->d2;  N=(dim+1)*(dim+2)/2;
if (*rawaddr!=NULL)
{
  if ((*rawaddr)->d!=N)
  {
    dispvector(rawaddr);
    *rawaddr=getvector(N);
  }
} else
  *rawaddr=getvector(N);
raw=*rawaddr;
if (ap_C!=NULL)
{
  if (ap_C->d1!=N || ap_C->d2!=N)
  {
    dispmatrix(&ap_C);
    ap_C=getmatrix(N,N);
  }
} else
  ap_C=getmatrix(N,N);
if (ap_decomp!=NULL)
{
  if (ap_decomp->d1!=N || ap_decomp->d2!=N)
  {
    dispmatrix(&ap_decomp);
    ap_decomp=getmatrix(N,N);
  }
} else
  ap_decomp=getmatrix(N,N);
/* Assembling of the system matrix and the right-hand side vector: we arrange
inner and outer iteration over all basis functions in such a way that the form
of basis functions is always known (i.e. we always have index i for linear
terms x_i and indices (i,j) for square terms x_i*x_j for both function indices
ind_1 and ind_2: */
/* First bas. func. constant, second bas. function constant (ind2=1): */
raw->v[1]=0;
ap_C->m[1][1]=0;
for (k=1;k<=m;++k)
{
  raw->v[1]+=w->v[k]* /* 1 * */ val->v[k];
  ap_C->m[1][1]+=w->v[k] /* 1*1 */;
}
/* First bas. func. constant, second bas. function linear (ind2=2...dim+1): */
for (i2=1;i2<=dim;++i2)   /* ind2 = i2+1  */
{
  ind2=i2+1;
  ap_C->m[1][ind2]=0;
  for (k=1;k<=m;++k)
    ap_C->m[1][ind2]+=w->v[k]* /* 1 * */ points->m[k][i2];
  ap_C->m[ind2][1]=ap_C->m[1][ind2];  /* symmetrize */
}
ind2=dim+2;
/* First bas. func. constant, second bas. function quadratic: */
for (i2=1;i2<=dim;++i2)
{
  ap_C->m[1][ind2]=0;
  for (k=1;k<=m;++k)
    ap_C->m[1][ind2]+=w->v[k]* /* 1* */ points->m[k][i2]*points->m[k][i2]/2;
  ap_C->m[ind2][1]=ap_C->m[1][ind2];  /* symmetrize */
  ++ind2;
  for (j2=i2+1;j2<=dim;++j2)
  {
    ap_C->m[1][ind2]=0;
    for (k=1;k<=m;++k)
    ap_C->m[1][ind2]+=w->v[k]* /* 1* */ points->m[k][i2]*points->m[k][j2];
    ap_C->m[ind2][1]=ap_C->m[1][ind2];  /* symmetrize */
    ++ind2;
  }
}
/* First bas. function linear (x_i1), ind1=i1+1: */
for (i1=1;i1<=dim;++i1)
{
  ind1=i1+1;
  /* First bas. func. linear, second bas. function constant (ind2=1): */
  raw->v[ind1]=0;
  /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  for (k=1;k<=m;++k)
  {
    raw->v[ind1]+=w->v[k]*points->m[k][i1]*val->v[k];
    /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  }
  /* First bas. func. linear, second bas. function linear (ind2=2...dim+1): */
  for (i2=i1;i2<=dim;++i2)   /* ind2 = i2+1; from i1 because of symmetry  */
  {
    ind2=i2+1;
    ap_C->m[ind1][ind2]=0;
    for (k=1;k<=m;++k)
      ap_C->m[ind1][ind2]+=w->v[k]*points->m[k][i1]*points->m[k][i2];
    ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
  }
  ind2=dim+2;
  /* First bas. func. linear, second bas. function quadratic: */
  for (i2=1;i2<=dim;++i2)
  {
    ap_C->m[ind1][ind2]=0;
    for (k=1;k<=m;++k)
      ap_C->m[ind1][ind2]+=w->v[k]*points->m[k][i1]*
        points->m[k][i2]*points->m[k][i2]/2;
    ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
    ++ind2;
    for (j2=i2+1;j2<=dim;++j2)
    {
      ap_C->m[ind1][ind2]=0;
      for (k=1;k<=m;++k)
      ap_C->m[ind1][ind2]+=w->v[k]*points->m[k][i1]*
        points->m[k][i2]*points->m[k][j2];
      ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
      ++ind2;
    }
  }
}
ind1=dim+2;
for (i1=1;i1<=dim;++i1)
{  
  /* First bas. function pure quadratic (x_i1*x_i1): */
  /* First bas. func. pure quadrat., second bas. function constant (ind2=1): */
  raw->v[ind1]=0;
  /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  for (k=1;k<=m;++k)
  {
    raw->v[ind1]+=w->v[k]*(points->m[k][i1]*points->m[k][i1]/2)*val->v[k];
    /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  }
  /* First bas. func. pure quadrat., second bas. function linear -
  ap_C->m[ind1][ind2] already calculated (as symmetric element) */
  ind2=dim+2;
  /* First bas. func. pure quadrat., second bas. function quadratic: */
  for (i2=1;i2<=dim;++i2)
  {
    ap_C->m[ind1][ind2]=0;
    for (k=1;k<=m;++k)
      ap_C->m[ind1][ind2]+=w->v[k]*(points->m[k][i1]*points->m[k][i1]/2)*
        points->m[k][i2]*points->m[k][i2]/2;
    ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
    ++ind2;
    for (j2=i2+1;j2<=dim;++j2)
    {
      ap_C->m[ind1][ind2]=0;
      for (k=1;k<=m;++k)
      ap_C->m[ind1][ind2]+=w->v[k]*(points->m[k][i1]*points->m[k][i1]/2)*
        points->m[k][i2]*points->m[k][j2];
      ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
      ++ind2;
    }
  }
  ++ind1;
  for (j1=i1+1;j1<=dim;++j1)
  {
    /* First bas. function mixed (x_i1*x_j1): */
    /* First bas. func. mixed, second bas. function constant (ind2=1): */
    raw->v[ind1]=0;
    /* ap_C->m[ind1][1] already calculated (as symmetric element) */
    for (k=1;k<=m;++k)
    {
      raw->v[ind1]+=w->v[k]*points->m[k][i1]*points->m[k][j1]*val->v[k];
      /* ap_C->m[ind1][1] already calculated (as symmetric element) */
    }
    /* First bas. func. mixed, second bas. function linear -
    ap_C->m[ind1][ind2] already calculated (as symmetric element) */
    ind2=dim+2;
    /* First bas. func. mixed, second bas. function quadratic: */
    for (i2=1;i2<=dim;++i2)
    {
      /* ap_C->m[ind2][ind2] already calculated (as symmetric element) */
      ++ind2;
      for (j2=i2+1;j2<=dim;++j2)
      {
        if (ind2>=ind1)
        {
          ap_C->m[ind1][ind2]=0;
          for (k=1;k<=m;++k)
          ap_C->m[ind1][ind2]+=w->v[k]*points->m[k][i1]*points->m[k][j1]*
            points->m[k][i2]*points->m[k][j2];
          ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
        }
        ++ind2;
      }
    }
    ++ind1;
  }
}
decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,1e-14);
if (decomp)
{
  if (1)
  {
    double R=1.0e-9,incfact=100.0,sumdiag,term,termmin,aux,small,small2;
    vector reg=NULL,sqrsumlines;
    /* Regularization by addition of coefficient size minimization terms,
    which leads to addition of small positive values to diagonal terms of the
    system matrix: */
    /*
    printf("Singular system matrix:\n");
    printmatrixlist(ap_C);
    */
    reg=getvector(N);
    sqrsumlines=getvector(N);
    /* Calculate root mean square of diagonal elements: */
    sumdiag=0;
    for (i=1;i<=N;++i)
      sumdiag+=ap_C->m[i][i]*ap_C->m[i][i];
    sumdiag=sqrt(sumdiag)/((double) (10*N));
    small=sumdiag*R*1e-5;
    small2=sumdiag*sumdiag*R*R*1e-5;  /* Square measure for a small value */
    /* Calculate the square sums for all lines: */
    for (i=1;i<=N;++i)
    {
      sqrsumlines->v[i]=0;
      for (j=1;j<=N;++j)
        sqrsumlines->v[i]+=ap_C->m[i][j]*ap_C->m[i][j];
      if (sqrsumlines->v[i]<small2)
        sqrsumlines->v[i]=small2;
    }
    /* Calculate the coefficients: */
    if (N==1)
    {
      reg->v[1]=R*fabs(ap_C->m[1][1]);
      if (reg->v[1]<1e-40)
        reg->v[1]=1e-40;
    } else
    {
      for (i=1;i<=N;++i)
      {
        /* Minimum of sums over lines, we omit square root and coef. R/N: */
        termmin=0;
        for (j=1;j<=N;++j)
        {
          if (j!=i)
          {
            aux=ap_C->m[j][i]*ap_C->m[j][i];
            term=(sqrsumlines->v[j]-aux)/(aux+small);  /* addition of small
                  prevents division by zero */
            termmin=m_minval(termmin,term);
          }
        }
        if (termmin==0)
          termmin=1e-30;
        reg->v[i]=R*m_minval(1,sqrt(termmin)/(double) N)*
             m_maxval(fabs(ap_C->m[i][i]),sumdiag);
      }
    }
    while (decomp && R<1.0)
    {
      ++ret;
      for (i=1;i<=N;++i)
        ap_C->m[i][i]+=reg->v[i];
      decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,0.0);
      if (decomp)
      {
        /* Matrix is still singular, we increase the regularization
        coefficients: */
        R*=incfact;
        for (i=1;i<=N;++i)
          reg->v[i]*=incfact;
      }
    }
    if (decomp)
    {
      ret=-ret;
    }
    /* 
    else
    {
      printf("Repaired system matrix:\n");
      printmatrixlist(ap_C);
    }
    */
    dispvector(&sqrsumlines);
    dispvector(&reg);
  } else
  {
    if (reclevel<2*dim)
    {
      double wmax,wmax1,wsum;
      int iwmax;
      vector xwdist,xwmax,newval,neww;
      matrix newpoints;
      ++ret;
      /* Calculate the greatest weight, its index and the second greatest weight: */
      wmax=wmax1=w->v[1]; iwmax=1;
      xwdist=getvector(dim);
      xwmax=getvector(dim);
      for (i=2;i<=m;++i)
        if (w->v[i]>wmax)
        {
          wmax=w->v[i];   iwmax=i;
        } else if (w->v[i]>wmax1)
          wmax1=w->v[1];
      /* Point with maximum weight: */
      for (j=1;j<=dim;++j)
      {
        xwmax->v[j]=points->m[iwmax][j];
        xwdist->v[j]=0;
      }
      /* Calculate the weighted average component distance with respect to the
      point with the max. weight: */
      wsum=0;  /* wavdist=0; */
      for (i=1;i<=m;++i)
        if (i!=iwmax)
        {
          wsum+=w->v[i];
          for (j=1;j<=dim;++j)
            xwdist->v[j]+=fabs(points->m[i][j]-xwmax->v[j])*w->v[i];
          /*
          dist=vecnorm(vectordif0(xwmax,x,&x));
          wavdist+=dist*w->v[i];
          */
        }
      /* Divide components by sum of weights to get weighted average, then reduce
      the w. distance additionally */
      for (j=1;j<=dim;++j)
        xwdist->v[j]/=(wsum*(double) (100*N));
      /* Derive a small weight for additional points by reducing the second
      largest weight; fact. 10000 makes a point 100 times less important: */
      wmax1/=((double) (10000*N*dim)); 
      /* Add randomly a set of dim new points around the point with the largest
      weight in order to stabilize the least square equation; weights are small
      so that approximation of the original dataset should not be spoiled: */
      newpoints=getmatrix(m+dim,dim);
      newval=getvector(m+dim);
      neww=getvector(m+dim);
      for (i=1;i<=m;++i)  /* Transcription of original data: */
      {
        for (j=1;j<=dim;++j)
          newpoints->m[i][j]=points->m[i][j];
        neww->v[i]=w->v[i];
        newval->v[i]=val->v[i];
      }
      for (i=m+1;i<=m+dim;++i)  /* Transcription of original data: */
      {
        for (j=1;j<=dim;++j)
          newpoints->m[i][j]=xwmax->v[j]+xwdist->v[j]*random1();
        newval->v[i]=val->v[iwmax];
        neww->v[i]=wmax1;
      }
      m_threadunlock(ap_lock);
      ret+=coefquadpolapproxraw(newpoints,newval,neww,rawaddr);
      m_threadlocksleep(ap_lock,1);
      dispmatrix(&newpoints);
      dispvector(&newval);
      dispvector(&neww);
      dispvector(&xwdist);
      dispvector(&xwmax);
      --reclevel;
      m_threadunlock(ap_lock);
      return ret;
    } else
    {
      errfunc0("coefquadpolapproxraw");
      sprintf(ers(),"The system matrix is not invertable.\n");
      sprintf(ers(),"Attempt to condition the system matrix failed.\n");
      errfunc2();
      ret=-ret;
      --reclevel;
      m_threadunlock(ap_lock);
      return ret;
    }
  }
}
if (ret>=0)
  solvLDLTplain(ap_decomp,ap_decomp,raw,raw);
else for (i=1;i<=N;++i)
  raw->v[i]=0;
if (ap_forceclean)
{
  dispmatrix(&ap_C);
  dispmatrix(&ap_decomp);
  dispvector(&ap_d);
} else
{
  if (N>100)
  {
    dispmatrix(&ap_C);
  dispmatrix(&ap_decomp);
    dispvector(&ap_d);
  }
}
--reclevel;
m_threadunlock(ap_lock);
return ret;
}




double quadpolapprox(vector x,matrix points,vector val,vector w)
    /* Calculates the value of a quadratic approximation of data in point x.
    points must contain co-ordinates of data points, val must contain values
    in these points to be fitted, and w must contain the corresponding SQUARED
    weights. A warning is launched if the initial problem is not well posed so
    that it had to be conditioned by adding imaginary points, and an error is
    launched if the repair failed to produce results.
      Remark:
      For many applications it is better to separately perform calculation of
    approximation coefficients by coefquadpolapproxraw() and then call
    quadpolraw() to evaluate the approximation, since in this way it can be
    controlled if the approximation problem is well defined and separate
    actions can be performed if it is not.
    $A Igor nov03; */
{
int ret;
double retval;
ret=coefquadpolapproxraw(points,val,w,&ap_raw);
if (ret)
{
  if (ret>0)
  {
    warnfunc1(1,"quadpolapprox");
    sprintf(ers(),"Initial approximation problem was not well defined,\n");
    sprintf(ers(),"conditioned by adding imaginary points (%i passes).\n",ret);
    warnfunc2();
  } else
  {
    errfunc0("quadpolapprox");
    sprintf(ers(),"The approximation problem is not well posed, reparation failed.\n");
    warnfunc2();
  }
}
if (ap_forceclean || ap_raw->d>100)
  dispvector(&ap_raw);
retval=quadpolraw(x,ap_raw);
return retval;
}


static int coefquadpolapproxgradraw1(matrix points,matrix val,matrix w,vector *rawaddr)
    /* Does the same as coefquadpolapproxgradraw(), except that it first creates
    a matrix of values of basis functions in sampling points and then
    calculates the approximation by coeflincombapproxgrad(). On contrary,
    coefquadpolapproxgradraw() assembles the system of equations without this
    intermediate storage.
      This function is much slower than coefquadpolapproxraw() and was primarily
    created  for testing coeflincombapproxgrad().
    $A, Igor nov03; */
{
int i,j,k,l,ind,m,N,dim,ret;
matrix basval=NULL;
m=points->d1;  dim=points->d2;  N=(dim+1)*(dim+2)/2;
basval=getmatrix(m,N*(dim+1));
/* Fill basval with values of quadratic basis functions in points: */
for (k=1;k<=m;++k)
{
  /* Const. term, derivatives are zero: */
  basval->m[k][1]=1;
  for (l=1;l<=dim;++l)
    basval->m[k][l+1]=0;
}
ind=dim+2;
for (i=1;i<=dim;++i)
{
  /* Lin. term, i-th derivative is 1, others are 0: */
  for (k=1;k<=m;++k)
  {
    basval->m[k][ind]=points->m[k][i];
    for (l=1;l<=dim;++l)
      basval->m[k][ind+l]=0;
    basval->m[k][ind+i]=1;
  }
  ind+=dim+1;
}
/*
ind=dim+2;
*/
for (i=1;i<=dim;++i)
{
  /* pure quadratic term x_i^2/2, i-th derivative is x_1, others are 0: */
  for (k=1;k<=m;++k)
  {
    /* pure quadratic term x_i^2/2, i-th derivative is x_i, others are 0: */
    basval->m[k][ind]=points->m[k][i]*points->m[k][i]/2;
    for (l=1;l<=dim;++l)
      basval->m[k][ind+l]=0;
    basval->m[k][ind+i]=points->m[k][i];
  }
  ind+=dim+1;
  for (j=i+1;j<=dim;++j)
  {
    /* mixed term x_i*x_j, i-th derivative is x_j, j-th is x_i, others are 0: */
    for (k=1;k<=m;++k)
    {
      basval->m[k][ind]=points->m[k][i]*points->m[k][j];
      for (l=1;l<=dim;++l)
        basval->m[k][ind+l]=0;
      basval->m[k][ind+i]=points->m[k][j];
      basval->m[k][ind+j]=points->m[k][i];
    }
    ind+=dim+1;
  }
}
ret=coeflincombapproxgrad(basval,val,w,rawaddr);
dispmatrix(&basval);
return ret;
}



int coefquadpolapproxgradraw(matrix points,matrix val,matrix w,vector *rawaddr)
    /* Calculates coefficients of a quadratic approximation on the basis of
    function values and gradients and stores them to *rawaddr. points must be
    a matrix whose LINES contain co-ordinates of sampling points, val must
    contain values and derivatives with respect to all independent variables
    (co-ordinates) of the sampled function in these points (each row contains
    the value and all derivatives in turns for one point), and w must contain
    the corresponding SQUARE weigth that weigh the importance of values and
    each derivative of different (the dimension must therefore be the same
    as that of val). points, val and w must be allocated and of consistent
    dimensions since this is not checked by the function. If necessary, space
    for coefficients is allocated anew or re-allocated.
      Function returns 0 if everything is OK and a positive number if the
    approximation problem is not well posed (i.e. the system matrix is
    singular). In this case an attempt is made to get a solution by adding
    extra imaginary points (currently randomly) by values close to the value
    in the most important point (i.e. that with the highest weight for the
    value, or just one of them if they are equally weighted). The returned
    value is then a counter of how many times the system algorithm has been
    applied in order to obtain a solution. If all attempts to get a solution
    fail, then a negative value is returned (equal to minus the number of
    attempts). In each attempt dim points are added where dim is dimension of
    the space.
      WARNINING:
      w must contain the SQUARED weights!
    $A Igor nov03; */
{
int i,j,i1,j1,i2,j2,k,ind1,ind2,N,m,dim,ret=0,decomp;
static int reclevel;
vector raw;
m_threadlocksleep(ap_lock,1);
++reclevel;
m=points->d1;  dim=points->d2;  N=(dim+1)*(dim+2)/2;
if (*rawaddr!=NULL)
{
  if ((*rawaddr)->d!=N)
  {
    dispvector(rawaddr);
    *rawaddr=getvector(N);
  }
} else
  *rawaddr=getvector(N);
raw=*rawaddr;
if (ap_C!=NULL)
{
  if (ap_C->d1!=N || ap_C->d2!=N)
  {
    dispmatrix(&ap_C);
    ap_C=getmatrix(N,N);
  }
} else
  ap_C=getmatrix(N,N);
if (ap_decomp!=NULL)
{
  if (ap_decomp->d1!=N || ap_decomp->d2!=N)
  {
    dispmatrix(&ap_decomp);
    ap_decomp=getmatrix(N,N);
  }
} else
  ap_decomp=getmatrix(N,N);
/* Assembling of the system matrix and the right-hand side vector: we arrange
inner and outer iteration over all basis functions in such a way that the form
of basis functions is always known (i.e. we always have index i for linear
terms x_i and indices (i,j) for square terms x_i*x_j for both function indices
ind_1 and ind_2: */
/* First bas. func. constant, second bas. function constant (ind2=1): */
raw->v[1]=0;
ap_C->m[1][1]=0;
for (k=1;k<=m;++k)
{
  raw->v[1]+=w->m[k][1]* /* 1 * */ val->m[k][1];
  ap_C->m[1][1]+=w->m[k][1] /* 1*1 */;
  /* All derivatives are 0 for const. bas. func. */
}
/* First bas. func. constant, second bas. function linear (ind2=2...dim+1): */
for (i2=1;i2<=dim;++i2)   /* ind2 = i2+1  */
{
  ind2=i2+1;
  ap_C->m[1][ind2]=0;
  for (k=1;k<=m;++k)
    ap_C->m[1][ind2]+=w->m[k][1]* /* 1 * */ points->m[k][i2];
  ap_C->m[ind2][1]=ap_C->m[1][ind2];  /* symmetrize */
}
ind2=dim+2;
/* First bas. func. constant, second bas. function quadratic: */
for (i2=1;i2<=dim;++i2)
{
  ap_C->m[1][ind2]=0;
  for (k=1;k<=m;++k)
    ap_C->m[1][ind2]+=w->m[k][1]* /* 1* */ points->m[k][i2]*points->m[k][i2]/2;
  ap_C->m[ind2][1]=ap_C->m[1][ind2];  /* symmetrize */
  ++ind2;
  for (j2=i2+1;j2<=dim;++j2)
  {
    ap_C->m[1][ind2]=0;
    for (k=1;k<=m;++k)
    ap_C->m[1][ind2]+=w->m[k][1]* /* 1* */ points->m[k][i2]*points->m[k][j2];
    ap_C->m[ind2][1]=ap_C->m[1][ind2];  /* symmetrize */
    ++ind2;
  }
}
/* First bas. function linear (x_i1), ind1=i1+1: */
for (i1=1;i1<=dim;++i1)
{
  ind1=i1+1;
  /* First bas. func. linear, second bas. function constant (ind2=1): */
  raw->v[ind1]=0;
  /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  for (k=1;k<=m;++k)
  {
    raw->v[ind1]+=w->m[k][1]*points->m[k][i1]*val->m[k][1]+
    /* Contribution of gradient elements; in w and val, the column is i1+1=ind1 */
       w->m[k][ind1]* /* *1 */ val->m[k][ind1];
    /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  }
  /* First bas. func. linear, second bas. function linear (ind2=2...dim+1): */
  for (i2=i1;i2<=dim;++i2)   /* ind2 = i2+1; from i1 because of symmetry  */
  {
    ind2=i2+1;
    ap_C->m[ind1][ind2]=0;
    for (k=1;k<=m;++k)
      ap_C->m[ind1][ind2]+=w->m[k][1]*points->m[k][i1]*points->m[k][i2];
    /* Contribution of gradient data: */
    if (i1==i2)
      for (k=1;k<=m;++k)
        ap_C->m[ind1][ind2]+=w->m[k][ind1] /* *1*1* */ ;
    ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
  }
  ind2=dim+2;
  /* First bas. func. linear, second bas. function quadratic: */
  for (i2=1;i2<=dim;++i2)
  {
    ap_C->m[ind1][ind2]=0;
    for (k=1;k<=m;++k)
    {
      ap_C->m[ind1][ind2]+=w->m[k][1]*points->m[k][i1]*
        points->m[k][i2]*points->m[k][i2]/2;
      /* Gradient contribution: only if i1==i2, then derivative with respect
      to x_i1 is non-zero for both functions (column in w: i+1=ind1): */
      if (i2==i1)
        ap_C->m[ind1][ind2]+=w->m[k][ind1]* /* 1* */ points->m[k][i1];
    }
    ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
    ++ind2;
    for (j2=i2+1;j2<=dim;++j2)
    {
      ap_C->m[ind1][ind2]=0;
      for (k=1;k<=m;++k)
        ap_C->m[ind1][ind2]+=w->m[k][1]*points->m[k][i1]*
          points->m[k][i2]*points->m[k][j2];
      /* Gradient contribution: */
      if (i2==i1)
      {
        /* first function x_i1, second x_i1*x_j2: */
        for (k=1;k<=m;++k)
          ap_C->m[ind1][ind2]+=w->m[k][ind1] /* *1 */ *points->m[k][j2];
      } else if (j2==i1)
      {
        /* first function x_i1, second x_i2*x_i1: */
        for (k=1;k<=m;++k)
          ap_C->m[ind1][ind2]+=w->m[k][ind1] /* *1 */ *points->m[k][i2];
      }
      ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
      ++ind2;
    }
  }
}
ind1=dim+2;
for (i1=1;i1<=dim;++i1)
{  
  /* First bas. function pure quadratic (x_i1*x_i1): */
  /* First bas. func. pure quadrat., second bas. function constant (ind2=1): */
  raw->v[ind1]=0;
  /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  for (k=1;k<=m;++k)
  {
    raw->v[ind1]+=w->m[k][1]*(points->m[k][i1]*points->m[k][i1]/2)*val->m[k][1]
      /* Gradient contribution: */
      +w->m[k][i1+1]*points->m[k][i1]*val->m[k][i1+1];
    /* ap_C->m[ind1][1] already calculated (as symmetric element) */
  }
  /* First bas. func. pure quadrat., second bas. function linear -
  ap_C->m[ind1][ind2] already calculated (as symmetric element) */
  ind2=dim+2;
  /* First bas. func. pure quadrat., second bas. function quadratic: */
  for (i2=1;i2<=dim;++i2)
  {
    ap_C->m[ind1][ind2]=0;
    for (k=1;k<=m;++k)
      ap_C->m[ind1][ind2]+=w->m[k][1]*(points->m[k][i1]*points->m[k][i1]/2)*
        points->m[k][i2]*points->m[k][i2]/2;
      /* Gradient contribution: */
    if (i2==i1)
    {
      /* first function x_i1^2/2, second x_i1^2/2: */
      for (k=1;k<=m;++k)
        ap_C->m[ind1][ind2]+=w->m[k][i1+1]*points->m[k][i1]*points->m[k][i1];
    }
    ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
    ++ind2;
    for (j2=i2+1;j2<=dim;++j2)
    {
      ap_C->m[ind1][ind2]=0;
      for (k=1;k<=m;++k)
        ap_C->m[ind1][ind2]+=w->m[k][1]*(points->m[k][i1]*points->m[k][i1]/2)*
          points->m[k][i2]*points->m[k][j2];
        /* Gradient contribution: */
      if (i2==i1)
      {
        /* first function x_i1^2/2, second x_i1*x_j2: */
        for (k=1;k<=m;++k)
          ap_C->m[ind1][ind2]+=w->m[k][i1+1]*points->m[k][i1]*points->m[k][j2];
      } else if (j2==i1)
      {
        /* first function x_i1^2/2, second x_i2*x_i1: */
        for (k=1;k<=m;++k)
          ap_C->m[ind1][ind2]+=w->m[k][i1+1]*points->m[k][i1]*points->m[k][i2];
      }
      ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
      ++ind2;
    }
  }
  ++ind1;
  for (j1=i1+1;j1<=dim;++j1)
  {
    /* First bas. function mixed (x_i1*x_j1): */
    /* First bas. func. mixed, second bas. function constant (ind2=1): */
    raw->v[ind1]=0;
    /* ap_C->m[ind1][1] already calculated (as symmetric element) */
    for (k=1;k<=m;++k)
    {
      raw->v[ind1]+=w->m[k][1]*points->m[k][i1]*points->m[k][j1]*val->m[k][1]
      /* Gradient contribution: */
      +w->m[k][i1+1]*points->m[k][j1]*val->m[k][i1+1]  /* d(...)/d x_i1 */
      +w->m[k][j1+1]*points->m[k][i1]*val->m[k][j1+1]; /* d(...)/d x_j1 */
      /* ap_C->m[ind1][1] already calculated (as symmetric element) */
    }
    /* First bas. func. mixed, second bas. function linear -
    ap_C->m[ind1][ind2] already calculated (as symmetric element) */
    ind2=dim+2;
    /* First bas. func. mixed, second bas. function quadratic: */
    for (i2=1;i2<=dim;++i2)
    {
      /* ap_C->m[ind2][ind2] already calculated (as symmetric element) */
      ++ind2;
      for (j2=i2+1;j2<=dim;++j2)
      {
        if (ind2>=ind1)
        {
          ap_C->m[ind1][ind2]=0;
          for (k=1;k<=m;++k)
          ap_C->m[ind1][ind2]+=w->m[k][1]*points->m[k][i1]*points->m[k][j1]*
            points->m[k][i2]*points->m[k][j2];


          if (i2==i1)
          {
            /* first function x_i1*x_j1, second x_i1*x_j2; d.../d x_i1: */
            for (k=1;k<=m;++k)
              ap_C->m[ind1][ind2]+=w->m[k][i1+1]*points->m[k][j1]*points->m[k][j2];
          } else if (j2==i1)
          {
            /* first function x_i1*x_j1, second x_i2*x_i1; d.../d x_i1: */
            for (k=1;k<=m;++k)
              ap_C->m[ind1][ind2]+=w->m[k][i1+1]*points->m[k][j1]*points->m[k][i2];
          }
          if (i2==j1)
          {
            /* first function x_i1*x_j1, second x_j1*x_j2; d.../d x_j1: */
            for (k=1;k<=m;++k)
              ap_C->m[ind1][ind2]+=w->m[k][j1+1]*points->m[k][i1]*points->m[k][j2];
          } else if (j2==j1)
          {
            /* first function x_i1*x_j1, second x_i2*x_j1; d.../d x_j1: */
            for (k=1;k<=m;++k)
              ap_C->m[ind1][ind2]+=w->m[k][j1+1]*points->m[k][i1]*points->m[k][i2];
          }
          ap_C->m[ind2][ind1]=ap_C->m[ind1][ind2];  /* symmetrize */
        }
        ++ind2;
      }
    }
    ++ind1;
  }
}
decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,1e-14);
if (decomp)
{
  if (1)
  {
    double R=1.0e-9,incfact=100.0,sumdiag,term,termmin,aux,small,small2;
    vector reg=NULL,sqrsumlines;
    /* Regularization by addition of coefficient size minimization terms,
    which leads to addition of small positive values to diagonal terms of the
    system matrix: */
    reg=getvector(N);
    sqrsumlines=getvector(N);
    /* Calculate root mean square of diagonal elements: */
    sumdiag=0;
    for (i=1;i<=N;++i)
      sumdiag+=ap_C->m[i][i]*ap_C->m[i][i];
    sumdiag=sqrt(sumdiag)/((double) (10*N));
    small=sumdiag*R*1e-5;
    small2=sumdiag*sumdiag*R*R*1e-5;  /* Square measure for a small value */
    /* Calculate the square sums for all lines: */
    for (i=1;i<=N;++i)
    {
      sqrsumlines->v[i]=0;
      for (j=1;j<=N;++j)
        sqrsumlines->v[i]+=ap_C->m[i][j]*ap_C->m[i][j];
      if (sqrsumlines->v[i]<small2)
        sqrsumlines->v[i]=small2;
    }
    /* Calculate the coefficients: */
    if (N==1)
    {
      reg->v[1]=R*fabs(ap_C->m[1][1]);
      if (reg->v[1]<1e-40)
        reg->v[1]=1e-40;
    } else
    {
      for (i=1;i<=N;++i)
      {
        /* Minimum of sums over lines, we omit square root and coef. R/N: */
        termmin=0;
        for (j=1;j<=N;++j)
        {
          if (j!=i)
          {
            aux=ap_C->m[j][i]*ap_C->m[j][i];
            term=(sqrsumlines->v[j]-aux)/(aux+small);  /* addition of small
                  prevents division by zero */
            termmin=m_minval(termmin,term);
          }
        }
        if (termmin==0)
          termmin=1e-30;
        reg->v[i]=R*m_minval(1,sqrt(termmin)/(double) N)*
             m_maxval(fabs(ap_C->m[i][i]),sumdiag);
      }
    }
    while (decomp && R<1.0)
    {
      ++ret;
      for (i=1;i<=N;++i)
        ap_C->m[i][i]+=reg->v[i];
      decomp=LDLTdecomptolplain(ap_C,ap_decomp,ap_decomp,0.0);
      if (decomp)
      {
        /* Matrix is still singular, we increase the regularization
        coefficients: */
        R*=incfact;
        for (i=1;i<=N;++i)
          reg->v[i]*=incfact;
      }
    }
    if (decomp)
    {
      ret=-ret;
    }
    dispvector(&sqrsumlines);
    dispvector(&reg);
  } else
  {
    /* If the LDLT decomposition can not be done (i.e. ap_C is not invertible),
    we try to add randomly a number of fictious points in order to condition the
    system, but in such a way that approximation of original data is not spoiled
    too much. A limited number of attempts is done: */
    if (reclevel<2*dim)
    {
      /* If the LDLT decomposition can not be done (i.e. ap_C is not invertible),
      we try to add randomly a number of fictious points in order to condition the
      system, but in such a way that approximation of original data is not spoiled
      too much. A limited number of attempts is done: */
      double wmax,wmax1,wsum;
      int iwmax;
      vector xwdist,xwmax;
      matrix newval,neww;
      matrix newpoints;
      ++ret;
      /* Calculate the greatest weight, its index and the second greatest weight: */
      wmax=wmax1=w->m[k][1]; iwmax=1;
      xwdist=getvector(dim);
      xwmax=getvector(dim);
      for (i=2;i<=m;++i)
        if (w->m[i][1]>wmax)
        {
          wmax=w->m[i][1];   iwmax=i;
        } else if (w->m[i][1]>wmax1)
          wmax1=w->m[1][1];
      /* Point with maximum weight: */
      for (j=1;j<=dim;++j)
      {
        xwmax->v[j]=points->m[iwmax][j];
        xwdist->v[j]=0;
      }
      /* Calculate the weighted average component distance with respect to the
      point with the max. weight: */
      wsum=0;  /* wavdist=0; */
      for (i=1;i<=m;++i)
        if (i!=iwmax)
        {
          wsum+=w->m[i][1];
          for (j=1;j<=dim;++j)
            xwdist->v[j]+=fabs(points->m[i][j]-xwmax->v[j])*w->m[i][1];
          /*
          dist=vecnorm(vectordif0(xwmax,x,&x));
          wavdist+=dist*w->v[i];
          */
        }
      /* Divide components by sum of weights to get weighted average, then reduce
      the w. distance additionally */
      for (j=1;j<=dim;++j)
        xwdist->v[j]/=(wsum*(double) (100*N));
      /* Derive a small weight for additional points by reducing the second
      largest weight; fact. 10000 makes a point 100 times less important: */
      wmax1/=((double) (10000*N*dim)); 
      /* Add randomly a set of dim new points around the point with the largest
      weight in order to stabilize the least square equation; weights are small
      so that approximation of the original dataset should not be spoiled: */
      newpoints=getmatrix(m+dim,dim);
      newval=getmatrix(m+dim,val->d2);
      neww=getmatrix(m+dim,w->d2);
      for (i=1;i<=m;++i)  /* Transcription of original data: */
      {
        for (j=1;j<=dim;++j)
          newpoints->m[i][j]=points->m[i][j];
        for (j=1;j>=dim+1;++i)
        {
          neww->m[i][j]=w->m[i][j];
          newval->m[i][j]=val->m[i][j];
        }
      }
      for (i=m+1;i<=m+dim;++i)  /* Transcription of original data: */
      {
        for (j=1;j<=dim;++j)
          newpoints->m[i][j]=xwmax->v[j]+xwdist->v[j]*random1();
        for (j=1;j>=dim+1;++i)
        {
          newval->m[i][j]=val->m[iwmax][j];
          neww->m[i][j]=(wmax1/wmax)*w->m[iwmax][j];
        }
      }
      m_threadunlock(ap_lock);
      ret+=coefquadpolapproxgradraw(newpoints,newval,neww,rawaddr);
      m_threadlocksleep(ap_lock,1);
      dispmatrix(&newpoints);
      dispmatrix(&newval);
      dispmatrix(&neww);
      dispvector(&xwdist);
      dispvector(&xwmax);
      --reclevel;
      m_threadunlock(ap_lock);
      return ret;
    } else
    {
      errfunc0("coefquadpolapproxraw");
      sprintf(ers(),"The system matrix is not invertable.\n");
      sprintf(ers(),"Attempt to condition the system matrix failed.\n");
      errfunc2();
      ret=-ret;
      --reclevel;
      m_threadunlock(ap_lock);
      return ret;
    }
  }
}
if (ret>=0)
  solvLDLTplain(ap_decomp,ap_decomp,raw,raw);
else for (i=1;i<=N;++i)
  raw->v[i]=0;
if (ap_forceclean)
{
  dispmatrix(&ap_C);
  dispmatrix(&ap_decomp);
  dispvector(&ap_d);
} else
{
  if (N>100)
  {
    dispmatrix(&ap_C);
  dispmatrix(&ap_decomp);
    dispvector(&ap_d);
  }
}
--reclevel;
m_threadunlock(ap_lock);
return ret;
}




double quadpolapproxgrad(vector x,matrix points,matrix val,matrix w)
    /* Calculates the value of a quadratic approximation of data in point x.
    points must contain co-ordinates of data points, val must contain values
    and gradients in these points to be fitted (each line corresponds to one
    point and contains the value followed by all derivatives), and w must
    contain the corresponding SQUARED weights. A warning is launched if the
    initial problem is not well posed so that it had to be conditioned by
    adding imaginary points, and an error report is launched if the repair
    failed to produce results.
      Remark:
      For many applications it is better to separately perform calculation of
    approximation coefficients by coefquadpolapproxgradraw() and then call
    quadpolraw() to evaluate the approximation, since in this way it can be
    controlled if the approximation problem is well defined and separate
    actions can be performed if it is not.
    $A Igor nov03; */
{
int ret;
double retval;
ret=coefquadpolapproxgradraw(points,val,w,&ap_raw);
if (ret)
{
  if (ret>0)
  {
    warnfunc1(1,"quadpolapprox");
    sprintf(ers(),"Initial approximation problem was not well defined,\n");
    sprintf(ers(),"conditioned by adding imaginary points (%i passes).\n",ret);
    warnfunc2();
  } else
  {
    errfunc0("quadpolapprox");
    sprintf(ers(),"The approximation problem is not well posed, reparation failed.\n");
    warnfunc2();
  }
}
if (ap_forceclean || ap_raw->d>100)
  dispvector(&ap_raw);
retval=quadpolraw(x,ap_raw);
return retval;
}


static double weightfunc1(vector r,vector rw)
    /* Returns the value of the weighting function at the difference vector
    dif, with effective radii specified in rw. Weights are proportional to
    exp(-r^2), the actual expression is exp(-sqrt(r1^2/rw1^2+r2^2/rw2^2+...).
    If r is 0 then the returned value is 1, and in each direction, it falls to
    1/exp(1) ~ 0.37 at r_i=rw_i.
    $A Igor aug04; */
{
int i;
double exponent,ret=0;
if (r==NULL || rw==NULL)
{
  errfunc0("weightfunc1");
  sprintf(ers(),"The difference vector or the radius vector is not specified.\n");
  errfunc2();
} else if (r->d!=rw->d)
{
  errfunc0("weightfunc1");
  sprintf(ers(),"Inconsistent dimensions of the difference (%i) and radius vector (%i).\n",
    r->d,rw->d);
  errfunc2();
} else
{
  exponent=0;
  for (i=1;i<=r->d;++i)
    exponent+=m_sqr(r->v[i]/rw->v[i]);
  ret=exp(-exponent);
}
return ret;
}




    /* SMOOTHING APPROXIMATIONS: */


static void numgrad0(vector x,double h,double fn(vector xpt),int fd,int quadratic,
                     double *valaddr,vector *gradaddr)
    /* An auxiliary function, calculates approximate gradient of function fn
    at point x numerically and stores it to *gradaddr, using step size h. The
    function also stores function value to *valaddr. Either valaddr or gradaddr
    may be NULL (in this case either gradient or value is not stored), but not both.
    If gradaddr is NULL then gradient is not calculated, i.e. function is only called
    once in order to obtin its value in the point x.
      fd and quadratic specify according to which scheme the gradient is calculated.
    If quadratic is 0 then linear interpolation is used, either backward difference
    (if fd is 0) or forward difference (otherwise). If quadratic is not 0 then the
    central difference scheme is used (effectively quadratic approximation).
      Keyword: numerical gradient
    $A Igor aug04; */
{
int j,dim=0;
double val,val1,val2;
vector x1=NULL;
if (x!=NULL)
  dim=x->d;
if (gradaddr==NULL && valaddr==NULL)
{
  errfunc0("numgrad0");
  sprintf(ers(),"The storage address for both value and gradient is not specified.\n");
  errfunc2();
} else if (dim<1)
{
  errfunc0("numgrad0");
  sprintf(ers(),"Evlauation point not specified properly.\n");
  errfunc2();
} else if (h==0 && gradaddr!=NULL)
{
  errfunc0("numgrad0");
  sprintf(ers(),"Gradient calculation step is not positive.\n");
  errfunc2();
} else
{
  if (h<0)  /* h must be positive */
    h=-h;
  val=fn(x);
  if (valaddr!=NULL)
    *valaddr=val;
  if (gradaddr!=NULL)
  {
    resizevector(gradaddr,x->d);
    if (!quadratic)
    {
      /* Linear interpolation used: */
      if (!fd)  /* backward difference, reverse h */
        h=-h;
      for (j=1;j<=dim;++j)
      {
        copyvector(x,&x1);
        x1->v[j]+=h;
        val1=fn(x1);
        (*gradaddr)->v[j]=(val1-val)/h;
      }
    } else
    {
      /* Quadratic interpolation (central difference): */
      for (j=1;j<=dim;++j)
      {
        copyvector(x,&x1);
        x1->v[j]+=h;
        val2=fn(x1);
        x1->v[j]-=2.0*h;
        val1=fn(x1);
        (*gradaddr)->v[j]=0.5*(val2-val1)/h;
      }
    }
  }
}
dispvector(&x1);
}

static void numgrad(vector x,double h,double fn(vector xpt),vector *gradaddr)
    /* An auxiliary function, calculates approximate gradient of function fn
    at point x and stores it to *gradaddr, using step size h (forward
    difference scheme). The function is simplified with respect to numgrad0
    in a way that it only allows the forward difference scheme and it does not
    store the function value in x.
    $A Igor aug04; */
{
double val;
numgrad0(x,h,fn,1,0,&val,gradaddr) ;
}

static matrix aux_points;
static vector aux_val,aux_w,*aux_rawaddr;
static int aux_ret;


static double aux_funcapprox(vector x)
    /* Auxiliary function for smoothapproxsimp0, returns the approximation in x on
    the basis of the data that is provided by smoothapproxsimp0 and stored in static
    variables defined above. Use of static data is thread safe because the use of
    thread locks.
    $A Igor aug04; */
{
aux_ret=coefquadpolapproxraw(aux_points,aux_val,aux_w,aux_rawaddr);
return quadpolraw(x,*aux_rawaddr);
}

int smoothapproxsimp0(matrix samp,vector rw,vector x,int whichval,
                      double *valaddr,vector *gradaddr,double hgrad,int dispauxvar)
    /* Calculates the value and gradient of a smooth approximation of function
    whose samples are specified in samp. The approximation is quadratic moving
    least squares approximatio where all the points are taken into account,
    and the dependency of weights on the difference r between pooint of
    evaluation and the sample is exp(-sqrt(r1^2/rw1^2+r2^2/rw2^2+...).
      Lines of samp represent samples, the first rw->dim columns being
    parameter values and the next being values.
      rw is a vector whose dimension equals the number of independent
    variables, and its components rw1, re2, etc. represent the length in each
    co-ordinate direction on which the value of weighting function falls to
    1/exp(1) ~ 0.37 (the value is 1 in the sampling point).
      x is the point in which approximation is evaluated.
      whichval determines which value is approximated (starts with 1).
    valaddr is the address where the value of the approximation calculated in
    x is stored. It must not be NULL.
      gradaddr is address of the vector where gradient of the approximation is
    stored. It can be NULL, in this case gradient is not calculated. If hgrad>0
    then the gradient is calculated numerically, with the step size hgrad and
    according to a forward difference formula. If it is 0 (or also less than 0,
    currently) then gradient is calculated approximately analitically. The approximate
    gradient calculation just derives the approximate function in x as if its
    coefficients were constant, which is not actually the casse (this can in many
    cases generate large errors).
      If dispauxvar is nonzero then auxiliay variables are deleted at the end
    of the function, otherwise they are left allocated so that successive calls
    are quicker.
      Return value:
      The function returns the value returned from coefquadpolapproxraw(), i.e.
    0 if everything is OK.
      Remarks:
      The approximation is a quadratic function whose coefficients vary in the
    space of parameters, however this is not taken into account in calculation 
    of the gradient, which is calculated just by deriving a quadratic function
    with constant coefficients.
    $A Igor aug04; */
{
int dim=0,npt=0,i,k,ret=-1;
static int lock;
static matrix points=NULL;
static vector val=NULL,w=NULL,pt=NULL,dif=NULL,raw=NULL;
char prn=0;
double valapprox;
m_threadlock(lock);  /* thread safety - because of static variables */
if (x!=NULL)
  dim=x->d;
if (samp!=NULL)
  npt=samp->d1;
if (samp==NULL)
{
  errfunc0("smoothapproxsimp0");
  sprintf(ers(),"The matrix of samples is NULL");
  errfunc2();
} else if (dim==0)
{
  errfunc0("smoothapproxsimp0");
  sprintf(ers(),"The point in which calculation should be calculated is not specified\n");
  sprintf(ers(),"properly.\n");
  errfunc2();
} else if (rw==NULL)
{
  errfunc0("smoothapproxsimp0");
  sprintf(ers(),"The vector of radii of weighting functions is not specified.\n");
  errfunc2();
} else if (rw->d!=x->d)
{
  errfunc0("smoothapproxsimp0");
  sprintf(ers(),"The vector of radii of weighting functions has inconsistent dimensions.\n");
  sprintf(ers(),"Dimension: %i, number of independent variables: %i.\n",rw->d,x->d);
  errfunc2();
} else if (valaddr==NULL)
{
  errfunc0("smoothapproxsimp0");
  sprintf(ers(),"Address to store approximation value is not specified.\n");
  errfunc2();
} else if (whichval<0 || whichval>samp->d2-x->d)
{
  errfunc0("smoothapproxsimp0");
  sprintf(ers(),"The vector of radii of weighting functions is not specified.\n");
  errfunc2();
} else if (whichval<1 || whichval>samp->d2-x->d)
{
  errfunc0("smoothapproxsimp0");
  sprintf(ers(),"The value index %i is not in the alloved range (from %i to %i).\n",
    whichval,1,samp->d2-x->d);
  sprintf(ers(),"Number of independent variables: %i.\n",x->d);
  sprintf(ers(),"Number of matrix columns: %i (includes co-ordinates and values).\n",samp->d2);
  errfunc2();
} else if (npt<(dim+1)*(dim+2)/2)
{
  errfunc0("smoothapproxsimp0");
  sprintf(ers(),"Insufficient number of samples for quadratic approximation.\n");
  sprintf(ers(),"(%i, should be at least %i).\n",npt,(dim+1)*(dim+2)/2);
  errfunc2();
} else
{
  /* Prepare data storage: */
  resizematrix(&points,npt,dim);
  resizevector(&val,npt);
  resizevector(&w,npt);
  resizevector(&pt,dim);
  resizevector(&dif,dim);
  /* Preparation of data for calculation of approximation coefficients: */
  if (0 && prn)
    printf("\nPreparing data for approximation:\n");
  for (i=1;i<=npt;++i)
  {
    for (k=1;k<=dim;++k)
      points->m[i][k]=pt->v[k]=samp->m[i][k];
    val->v[i]=samp->m[i][dim+whichval];
    vecdifplain(x,pt,dif);
    w->v[i]=weightfunc1(dif,rw);
    if (0 && prn)
      printf("%g ",w->v[i]);
  }
  /* Calculate the approximation and possibly its gradients, prepare data for
  the afunction aux_funcauxapprox, which will be used for convenience: */
  aux_points=points;
  aux_val=val;
  aux_w=w;
  aux_rawaddr=&raw;  /* this enables re-use */

  ret=aux_ret;   /* get the return value from the approximation function */
  if (hgrad!=0 && gradaddr==NULL)
  {
    errfunc0("smoothapproxsimp0");
    sprintf(ers(),"Address of gradient storage is not specified.\n");
    sprintf(ers(),"Gradient will not be calculated although the step size\n");
    sprintf(ers(),"is different than 0 (%g).\n",hgrad);
    errfunc2();
    hgrad=0;
  }
  if (hgrad!=0)
  {
    /* Numerical calculation of approximation gradient (also calculates the value),
    function aux_funxapprox uses the data that was stored to static variables: */
    numgrad0(x,hgrad,aux_funcapprox,1,0,valaddr,gradaddr);
  } else
  {
    /* Calculate and store the function value: */
    valapprox=aux_funcapprox(x);
    if (valaddr!=NULL)
      *valaddr=valapprox;
    if (gradaddr!=NULL)
    {
      /* Approximate analytical evaluation of the approximation gradient 
      (coefficients raw were calculated by aux_funxapprox ): */
      gradquadpolraw(x,raw,gradaddr);
    }
  }
  if (prn)
  {
    /* Performing some consistency checking, use this if the function does not
    seem to behave properly (although this should not be the case any more) */
    vector min=NULL,max=NULL;
    double minval,maxval;
    int i=0,j=0,k=0;
    /* Calculating extension of sampling points: */
    if (samp->d1<1)
      printf("\n\nThere are no sampling points!\n");
    else
    {
      min=getvector(x->d);
      max=getvector(x->d);
      minval=maxval=val->v[1];
      if (samp->m[1][x->d+whichval]!=val->v[1])
        printf("\n\nValues are not transcribed properly: %i (0)\n",1);
      for (k=1;k<=points->d2;++k)
      {
        min->v[k]=max->v[k]=points->m[1][k];
        if (samp->m[1][k]!=points->m[1][k])
          printf("\n\nPoints are not transcribed properly: %i (1)\n",1);
      }
      for (i=2;i<=samp->d1;++i)
      {
        if (val->v[i]<minval)
          minval=val->v[i];
        else if (val->v[i]>maxval)
          maxval=val->v[i];
        for (k=1;k<=points->d2;++k)
        {
          if (points->m[i][k]<min->v[k])
            min->v[k]=points->m[i][k];
          else if (points->m[i][k]>max->v[k])
            max->v[k]=points->m[i][k];
          if (samp->m[i][k]!=points->m[i][k])
            printf("\n\nPoints are not transcribed properly: %i (2)\n",i);
        }
        if (samp->m[i][x->d+whichval]!=val->v[i])
          printf("\n\nValues are not transcribed properly: %i (3)\n",i);
      }
    }
    printf("\n\nCalculated quadratic approximation in point:\n  {");
    for (i=1;i<=x->d;++i)
    {
      printf("%-10g",x->v[i]);
      if (i<x->d) printf(", "); else printf("}\n");
    }
    printf("Effective radii:\n  {");
    for (i=1;i<=rw->d;++i)
    {
      printf("%-10g",rw->v[i]);
      if (i<rw->d) printf(", "); else printf("}\n");
    }
    printf("Sampled points are in the following range:\n  {");
    for (i=1;i<=min->d;++i)
    {
      printf("%-10g",min->v[i]);
      if (i<min->d) printf(", "); else printf("}\n");
    }
    printf("  {");
    for (i=1;i<=max->d;++i)
    {
      printf("%-10g",max->v[i]);
      if (i<max->d) printf(", "); else printf("}\n");
    }
    printf("Sampled values are in the following range:\n");
    printf("%-10g  to  %-10g.\n\n",minval,maxval);

    printf("\n\n");
    dispvector(&min); dispvector(&max);
  }
  /* Cleaning of local storage if specified: */
  if (dispauxvar)
  {
    dispmatrix(&points);
    dispvector(&val);
    dispvector(&w);
    dispvector(&pt);
    dispvector(&dif);
    dispvector(&raw);
  }
}
m_threadunlock(lock);  /* thread safety - because of static variables */
return ret;
}


int smoothapproxsimp(matrix samp,vector rw,vector x,int whichval,
                      double *valaddr,vector *gradaddr,int dispauxvar)
    /* The same as smoothapproxsimp0(), except that numerical evaluation of 
    the gradient is not possible. Therefore, an approximate analytical gradient
    is evaluated if gradaddr is different than NULL, which does not take into
    account the dependency of the approximatino coefficients on the intependent
    variables.
    $A Igor aug04; */
{
return smoothapproxsimp0(samp,rw,x,whichval,valaddr,gradaddr,
           0  /* evaluation of gradient is approximate analytical */ ,dispauxvar );
}



    /* AUXILIARY FUNCTIONS FOR testapprox(): */

static double func(vector x)
    /* An auxiliary function to be approximated; currently not used.
    $A Igor nov03; */
{
return cos(sqrt( m_sqr(x->v[1]/2) +m_sqr(x->v[2]/2) ));
}

static double func1(vector x)
    /* An auxiliary function to be approximated; currently used for testing
    smooth approximations. sin(x) or (1/x->d)*(sin(x_1)+sin(x_2)+...)
    $A Igor aug04; */
{
double ret=0;
int i;
if (x==NULL)
{
  errfunc0("func1");
  sprintf(ers(),"The difference vector or the radius vector is not specified.\n");
  errfunc2();
} else
{
  for (i=1;i<=x->d;++i)
    ret+=sin(x->v[i]);
  ret/=(double) x->d;
}
return ret;
}


/* Aux. data for funcap: */
static matrix  fa_samp=NULL; 
static vector  fa_rw=NULL;
static int     fa_whichval=0;

static double funcap(vector x)
    /* An auxiliary function to be approximated; currently used for testing
    smooth approximations. Returns value of approximation, but approximation
    data must be pointed by the static variables defined above prior to call
    to the function.
    $A Igor aug04; */
{
double ret;

smoothapproxsimp(fa_samp,fa_rw,  x,  fa_whichval, &ret,NULL,1);
return ret;
}


#include <fop.h>

static void readmatrixfromfile(char *filename,matrix *mataddr)
    /* Reads a matrix from the physical file addressed by filename and
    stores it in the matrix pointed to by mataddr. Matrix must be written in
    the file row by row. Components in the row may be separated by strings
    that can not be interpreted as numbers. There can also be several lines
    containing only non-numerical strings between the lines that contain
    matrix components.
      Comment:
      This function should be moved to Stanislav's code - remove from here!
    $A Igor aug04; */
{
indtab rows=NULL;  /* for lengths of matrix lines */
stack numst=NULL;   /* for matrix components */
FILE *fp=NULL;
long start,last,newlinepos;
int length,rowlength,maxrowlength,reported=0,i,j,which;
double val,*dptr;
char prn=1;
if (filename!=NULL)
  fp=fopen(filename,"rb");
if (fp==NULL)
{
  errfunc0("readmatrixfromfile");
  sprintf(ers(),"File could not be open for reading.\n");
  if (filename!=NULL) 
    sprintf(ers(),"File name: %s.\n",filename);
  errfunc2();
} else if (mataddr==NULL)
{
  errfunc0("readmatrixfromfile");
  sprintf(ers(),"Address to store matrix is not specified.\n");
  if (filename!=NULL) 
    sprintf(ers(),"File name: %s.\n",filename);
  errfunc2();
}
{
  rows=newindtab(5,5);  /* Length of lines */
  numst=newstack(100);
  start=1; length=1;
  last=1; newlinepos=1;
  rowlength=maxrowlength=0;
  while(start>0)
  {
    /* Read the next number from file: */
    val=filenum(fp,last,100,&start,&length);
    if (start>0)
    {
      /* The next number has been read, push it to the stack: */
      dptr=malloc(sizeof(*dptr));
      *dptr=val;
      pushstack(numst,dptr);
      ++rowlength;
      if (prn)
        printf(" %g ",val);
    }
    if (numst->n>1)
    {
      /* If this is not the first number then check if there has been a newline
      between the last and this number, which means that a new row must be started: */
      newlinepos=filecharto(fp,"\n",1,last,start,40);
      if (newlinepos>0)
      {
        --rowlength; /* the last number does not belong to the completed row */
        pushindtab(rows,rowlength);
        if (rowlength>maxrowlength)
          maxrowlength=rowlength;
        if (prn)
          printf("\nNew row finished, length = %i.\n",rowlength);
        rowlength=1;  /* the last number is already from a new row */
      }
    }
    last=start+length;  /* Starting position for the next reading */
  }
  /* Also record the length of the last row: */
  if (rowlength>0)
    pushindtab(rows,rowlength);
  if (prn)
  {
    printf("\nThe matrix is of dimensions %ix%i.\n",rows->n,maxrowlength);
    for (i=1;i<=rows->n;++i)
      if (rows->t[i]!=maxrowlength)
        printf("\nRow % i is shorter than maximum length (%i/%i).\n\n",
          i,rows->t[i],maxrowlength);
  }
  for (i=1;i<=rows->n;++i)
    if (rows->t[i]!=maxrowlength)
    {
      warnfunc1(1,"readmatrixfromfile");
      printf("\nRow % i is shorter than maximum length (%i/%i).\n\n",
        i,rows->t[i],maxrowlength);
      warnfunc2();
    }
  if ( rows->n<1 || maxrowlength<1)
  {
    dispmatrix(mataddr);
    if (prn)
      printf("The matrix is deleted.\n");
  } else
    resizematrix(mataddr,rows->n,maxrowlength);
  which=0;
  if (*mataddr!=NULL)
    for (i=1;i<=rows->n;++i)
      for (j=1;j<=rows->t[i];++j)
      {
        ++which;
        dptr=numst->s[which];
        (*mataddr)->m[i][j]=*dptr;
      }
  if (prn)
  {
    printf("Matrix read from file:\n");
    printmatrixline(*mataddr);
  }
}
dispindtab(&rows);
dispstackall(&numst);
}









    /* TEST FUNCTION OF THIS MODULE: */


void testapprox(void)
    /* A test function of the linear approximation module. Several types of
    functionality are tested, some of which are included in "if (0)" - change
    0 to 1 if you want to run tests for this functionality.
    $A Igor nov03; */
{
indtab it=NULL;
matrix G=NULL,G1=NULL,tabx=NULL,maux=NULL,A=NULL,ml=NULL,mu=NULL;
vector b=NULL,b1=NULL,
       taby=NULL,tabw=NULL,raw=NULL,
       tabfunc=NULL,x=NULL,vaux=NULL;
double c=0,c1=0;
int numx=5,numy=5,numz=5,i,j,k,ind,
    numcalc=1,  /* Number of calculations of 3D approximation */
    dim=400;
double t0=0,t1=0,t2=0,t3=0,t4=0,t5=0,t6=0,ct0=0,ct1=0,ct2=0,ct3=0,ct4=0,ct5=0,ct6=0;

t0=absolutetime();  ct0=cputime();

/* SMOOTHING APPROXIMATION: */

if (0)  /* Test of the function for reading a matrix from a file */
{
  matrix mat=NULL;
  readmatrixfromfile("matdata.txt",&mat);
}

if (1)
{
  matrix samp=NULL,samprnd=NULL,pointmat=NULL;
  vector rw=NULL,x=NULL,grad=NULL;
  int whichval=1,dispauxvar=1,dim=2,nx=5,ny=5,nx1=5,ny1=5,np=0,i,j,k,l=0,ipt,
    num=10,whichpt=10;
  double val=0,h=1e-5,fromx=0,fromy=0,tox=1.6,toy=1.6,noiselevel;
  double valfunc,valapprox,valsamp,relnoiselevel=0.1;
  double minval1,maxval1,minval2,maxval2,val1,val2;
  vector gradfunc=NULL,gradapprox=NULL,numgradapprox=NULL;
  indtab pointind=NULL;


  /* VAZNA OPOMBA -upostevaj, ko bos kaj preizkusal:
    Opaziti je, da pri sumu ni moc doseci, da bi bile razlike med aproksimacijo in
    pravo funkcijo manjse kot med aproksimacijo in vzorceno vrednostjo v vzorcnih
    tockah, tudi, ce je stevilo vzorcev veliko, efektivni radij dovolj velik in
    funkcija skoraj linearna (dovolj majhno obmocje). Preveri, zakaj ne dela kot bi
    mislil izpovprecenje suma (morda bi bilo morda bolje uporabiti linearno 
    aproksimacijo namesto kvadraticne)! */



  dim=2;
  nx=10;
  ny=10;
  nx1=0;
  ny1=1;     /* for calculation and print-out */
  /* Sampling intervals; remark: reduce to increase linearity! */
  fromx=0;
  fromy=0;
  tox=1.6;
  toy=1.6;
  if (nx1>nx)
    nx1=nx;
  if (ny1>ny)
    ny1=ny;
  if (whichpt>nx*ny)
    whichpt=nx*ny/2;
  
  /* Step for numerical calculation of the function gradient: */
  h=1e-5;

  np=nx*ny;
  relnoiselevel=0.1;  /* noise level relative to the value range */
  rw=getvector(dim);
  rw->v[1]=(tox-fromx)* 0.3 ;   /* Effective radii of weighting dunctions */
  rw->v[2]=(toy-fromy)* 0.3 ;
  x=getvector(dim);
  samp=getmatrix(np,dim+2);

  whichpt=110;   /* for calculation in only one point */
  
  /* Indices of sampling points in which approximation will be evaluated: */
  pointind=newindtab(5,5);
  pushindtab(pointind,1);
  pushindtab(pointind,nx*ny);
  pushindtab(pointind,nx*ny/2);
  pushindtab(pointind,nx*ny/2+nx/4);
  pushindtab(pointind,nx*ny/2+nx/2);
  pushindtab(pointind,nx*ny/4);
  pushindtab(pointind,3*nx*ny/4);

  /* Points in which approximation will be evaluated (not necessarily concide with
  sampling points: */
  pointmat=getmatrix(6,dim);
  pointmat->m[1][1]=fromx+(tox-fromx)*-0.133; pointmat->m[1][2]=fromy+(toy-fromy)*-0.233;
  pointmat->m[2][1]=fromx+(tox-fromx)*0.233; pointmat->m[2][2]=fromy+(toy-fromy)*0.233;
  pointmat->m[3][1]=fromx+(tox-fromx)*0.333; pointmat->m[3][2]=fromy+(toy-fromy)*0.133;
  pointmat->m[4][1]=fromx+(tox-fromx)*0.533; pointmat->m[4][2]=fromy+(toy-fromy)*0.533;
  pointmat->m[5][1]=fromx+(tox-fromx)*0.633; pointmat->m[5][2]=fromy+(toy-fromy)*0.533;
  pointmat->m[6][1]=fromx+(tox-fromx)*0.933; pointmat->m[6][2]=fromy+(toy-fromy)*0.133;

  /* Creation of samples: */
  printf("\nCreating samples; valuse:\n");
  ipt=0;
  for (i=0;i<nx;++i)
    for (j=0;j<ny;++j)
    {
      ++ipt;
      x->v[1]=samp->m[ipt][1]=fromx+(double) i*(tox-fromx)/(double)(nx-1);
      x->v[2]=samp->m[ipt][2]=fromy+(double) j*(toy-fromy)/(double)(ny-1);
      val1=samp->m[ipt][dim+1]=func1(x);  /* First function sampled value */
      val2=samp->m[ipt][dim+2]=0;  /* Second function sampled value */
      /* Value range calculation: */
      if (ipt==1)
      {
        minval1=maxval1=val1;
        minval2=maxval2=val2;
      } else
      {
        if (val1<minval1)
          minval1=val1;
        else if (val1>maxval1)
          maxval1=val1;
        if (val2<minval2)
          minval2=val2;
        else if (val2>maxval2)
          maxval2=val2;
      }
                              /*
      printf("%g ",samp->m[ipt][dim+1]);
      */
    }
  noiselevel=relnoiselevel*(maxval1-minval1);
  printf("\nValue range: %g, rel. noise level: %g, abs. noise level:%g\n",
    maxval1-minval1,relnoiselevel,noiselevel);
  copymatrix(samp,&samprnd);
  /* Adding noise: */
  ipt=0;
  for (i=0;i<nx;++i)
    for (j=0;j<ny;++j)
    {
      ++ipt;
      samprnd->m[ipt][dim+1]+=random1()*noiselevel;
      samprnd->m[ipt][dim+2]+=random1()*noiselevel;
    }

  /* Calculating the approximation and its gradients in sampling points: */
  /* Setting auxiliary data for the approximation function that can be used
  for numerical calculation of the true gradient of approximation: */
  fa_samp=samprnd;
  fa_rw=rw;
  fa_whichval=1;
  printf("\n\nCalculating smoothing approximation in %i sampling points:\n",nx1*ny1);
  ipt=0;
  for (i=0;i<nx1;++i)
    for (j=0;j<ny1;++j)
    {
      ++ipt;
      for (k=1;k<=dim;++k)
        x->v[k]=samprnd->m[ipt][k];
      valsamp=samprnd->m[ipt][dim+1];
      valfunc=func1(x);
      /* Numerical gradient of actual function: */
      numgrad(x,h,func1,&gradfunc);
      /* Analytical approximation of gradient: */
      smoothapproxsimp(samprnd,rw,x,1, /* which sampled function */
                         &valapprox,&gradapprox,1 /* delete aux. var. */ );
      /* Numerical approximation of gradient: */
      smoothapproxsimp0(samprnd,rw,x,1, /* which sampled function */
             &valapprox,&numgradapprox, h /* step for num. grad. */
             , 1 /* delete aux. var. */ );

      /*
      (matrix samp,vector rw,vector x,int whichval,
                      double *valaddr,vector *gradaddr,double hgrad,int dispauxvar)
      */
      printf("\n\n%i -th sampling point (%i,%i):\nPoint:\n",ipt,i+1,j+1);
      printvectorline(x);
      printf("Value:\n");
      printf("Function:     %g\n",valfunc);
      printf("Sample:       %g\n",valsamp);
      printf("Approximated: %g\n",valapprox);
      printf("ap. - samp.:  %-12g (rel. %g)\n",valapprox-valsamp,
        (valapprox-valsamp)/(valsamp+1e-20));
      printf("ap. - func.:  %-12g (rel. %g)\n",valapprox-valfunc,
        (valapprox-valfunc)/(valfunc+1e-20));
      if (1)
      {
        printf("Gradient (num. func. /calc. approx. /num. approx., h=%g):\n",h);
        printf("num. func.:    "); printvectorline(gradfunc);
        printf("calc. approx.: "); printvectorline(gradapprox);
        printf("num. approx.:  "); printvectorline(numgradapprox);
      }
    }

  /* Calculate the approximation in a number of sampling points whose indices
  are specified by the index table pointind: */
  printf("\n\n\n\n\n\n\nCalculating smoothing approximation in particular sampling points:\n",nx1*ny1);
  for (i=1;i<=pointind->n;++i)
  {
    ipt=pointind->t[i];
    if (ipt>nx*ny)
      ipt=nx*ny/2;
    for (k=1;k<=dim;++k)
      x->v[k]=samprnd->m[ipt][k];
    valsamp=samprnd->m[ipt][dim+1];
    valfunc=func1(x);
    /* Numerical gradient of actual function: */
    numgrad(x,h,func1,&gradfunc);
    /* Analytical approximation of gradient: */
    smoothapproxsimp(samprnd,rw,x,1, /* which sampled function */
                       &valapprox,&gradapprox,1 /* delete aux. var. */ );
    /* Numerical approximation of gradient: */
    smoothapproxsimp0(samprnd,rw,x,1, /* which sampled function */
           &valapprox,&numgradapprox, h /* step for num. grad. */
           , 1 /* delete aux. var. */ );

    /*
    (matrix samp,vector rw,vector x,int whichval,
                    double *valaddr,vector *gradaddr,double hgrad,int dispauxvar)
    */
    printf("\n\n%i -th sampling point (%i,%i):\nPoint:\n",ipt,i+1,j+1);
    printvectorline(x);
    printf("Value:\n");
    printf("Function:     %g\n",valfunc);
    printf("Sample:       %g\n",valsamp);
    printf("Approximated: %g\n",valapprox);
    printf("ap. - samp.:  %-12g (rel. %g)\n",valapprox-valsamp,
      (valapprox-valsamp)/(valsamp+1e-20));
    printf("ap. - func.:  %-12g (rel. %g)\n",valapprox-valfunc,
      (valapprox-valfunc)/(valfunc+1e-20));
    if (1)
    {
      printf("Gradient (num. func. /calc. approx. /num. approx., h=%g):\n",h);
      printf("num. func.:    "); printvectorline(gradfunc);
      printf("calc. approx.: "); printvectorline(gradapprox);
      printf("num. approx.:  "); printvectorline(numgradapprox);
    }
  }
    
  /* Calculate the approximation in a number of points thet don't necessarily
  coincide with sampling points; point co-ordinates are specified by pointmat: */
  printf("\n\n\n\n\n\n\nCalculating smoothing approximation in different points:\n",nx1*ny1);
  for (i=1;i<=pointmat->d1;++i)
  {
    ipt=1;
    for (k=1;k<=dim;++k)
      x->v[k]=pointmat->m[i][k];
    valsamp=samprnd->m[ipt][dim+1];
    valfunc=func1(x);
    /* Numerical gradient of actual function: */
    numgrad(x,h,func1,&gradfunc);
    /* Analytical approximation of gradient: */
    smoothapproxsimp(samprnd,rw,x,1, /* which sampled function */
                       &valapprox,&gradapprox,1 /* delete aux. var. */ );
    /* Numerical approximation of gradient: */
    smoothapproxsimp0(samprnd,rw,x,1, /* which sampled function */
           &valapprox,&numgradapprox, h /* step for num. grad. */
           , 1 /* delete aux. var. */ );

    /*
    (matrix samp,vector rw,vector x,int whichval,
                    double *valaddr,vector *gradaddr,double hgrad,int dispauxvar)
    */
    printf("\n\n%i -th sampling point (%i,%i):\nPoint:\n",ipt,i+1,j+1);
    printvectorline(x);
    printf("Value:\n");
    printf("Function:     %g\n",valfunc);
    /*
    printf("Sample:       %g\n",valsamp);
    */
    printf("Approximated: %g\n",valapprox);
    /*
    printf("ap. - samp.:  %-12g (rel. %g)\n",valapprox-valsamp,
      (valapprox-valsamp)/(valsamp+1e-20));
    */
    printf("ap. - func.:  %-12g (rel. %g)\n",valapprox-valfunc,
      (valapprox-valfunc)/(valfunc+1e-20));
    if (1)
    {
      printf("Gradient (num. func. /calc. approx. /num. approx., h=%g):\n",h);
      printf("num. func.:    "); printvectorline(gradfunc);
      printf("calc. approx.: "); printvectorline(gradapprox);
      printf("num. approx.:  "); printvectorline(numgradapprox);
    }
  }
    

  /* Checking speed of approximation: */
  num=0;
  printf("\n\nSpeed of smoothing approximation,\n");
  printf("%i evaluations, dim = %i, %i samp. points...\n\n",
    num,x->d,samp->d1);
  
  t0=absolutetime(); ct0=cputime();

  for (i=1;i<=num;++i)
  {
    smoothapproxsimp(samprnd,rw,x,1, /* which sampled function */
                     &valapprox,&gradapprox,1 /* delete aux. var. */ );
  }

  t1=absolutetime(); ct1=cputime();
  printf("\n\nTime spent: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);

  /*
  printf("Matrix of samples:\n");
  printmatrixline(samp);
  printf("Matrix of samples with noise:\n");
  printmatrixline(samprnd);
  */

  if (1)
  {
    errfunc0("");
    sprintf(ers(),"Exit is called.\n");
    errfunc2();
    exit(1);
  }
}


/* APPROXIMATION WITH QUADRATIC POLYNOMIALS: */
if (0)
{
  /* Test of quadratic approximations in 2D, similar as in flim.nb: */
  printf("Quadratic approximation in 2D\n");
  initmat0(&G,2,2, 1.,2.,  2.,4.);
  initvec0(&b,2, 4.,6.);
  c=10;
  printf("Matrix G:\n");   printmatrixlist(G);
  printf("Vector b:\n");   printvectorlist(b);
  printf("Scalar c: %g\n",c);
  resizematrix(&tabx,5*5,2);
  k=0;
  for (i=1;i<=numx;++i)
    for (j=1;j<=numy;++j)
    {
      ++k;
      tabx->m[k][1]=(double) i/(double) 10;
      tabx->m[k][2]=(double) j/(double) 10;
    }
  m_tablevector(taby,quadpol(matrowtovec0(tabx,i,&x),G,b,c),
                i=1,i<=tabx->d1,++i);
  m_tablevector(tabw,1,i=1,i<=tabx->d1,++i)
  printf("Matrix tabx:\n");   printmatrixlist(tabx);
  printf("Vector taby:\n");   printvectorlist(taby);
  printf("Vector tabw:\n");   printvectorlist(tabw);

  printf("\nCalculating coefficients of approximation...\n");
  i=coefquadpolapproxraw(tabx,taby,tabw,&raw);
  printf("Vector of raw coefficients:\n");   printvectorlist(raw);

  printf("\n\nConversion to regular form coefficients:\n");
  coefquadpolreg(raw,&G1,&b1,&c1);
  printf("Quadratic coefficients:\n");   printmatrixlist(G1);
  printf("Lin. coefficients:\n");   printvectorlist(b1);
  printf("Const. coefficient: %g\n",c1);

  printf("\n\nConversion back to raw form of coefficients:\n");
  coefquadpolraw(G1,b1,c1,&vaux);
  printf("Raw coefficients:\n");   printvectorlist(vaux);

  printf("\n\nTest of quadratic function and gradients:\n");
  initmat0(&tabx,9,2,  
     0.,0.,  0.,1.,  1.,0.,  1.,1.,  0.,10.,  10.,0.,  1.,10.,  10.,1., 10.,10.);
  printf("Table of points:\n");   printmatrixlist(tabx);
  printf("Values of the quadratic function in these points:\n");
  printf("By quadpol:\n");
  m_tablevector(tabfunc,quadpol(matrowtovec0(tabx,i,&x),G,b,c),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("By quadpolraw:\n");
  dispvector(&tabfunc);
  m_tablevector(tabfunc,quadpolraw(matrowtovec0(tabx,i,&x),raw),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("Gradients of the quadratic function in these points:\n");
  printf("By gradquadpol:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradquadpol(matrowtovec0(tabx,i,&x),G,b,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  printf("By gradquadpolraw:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradquadpolraw(matrowtovec0(tabx,i,&x),raw,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  dispmatrix(&maux);
  printf("By derquadpol:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derquadpol(matrowtovec0(tabx,i,&x),j,G,b);
  printmatrixlist(maux);
  printf("By derquadpolraw:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derquadpolraw(matrowtovec0(tabx,i,&x),j,raw);
  printmatrixlist(maux);
}

if (1)
{
  printf("\nPress <Enter>!");
  if (0)
    getchar();
  /* Test of quadratic approximations in 3D, similar as in flim.nb: */
  printf("\n\n\n\n\nQUADRATIC approximation in 3D\n");
  initmat0(&G,3,3, 1.,2.,3., 
                   2.,4.,6.,
                   3.,6.,7.   );
  initvec0(&b,3,   4.,6.,25. );
  c=10;
  printf("Matrix G:\n");   printmatrixlist(G);
  printf("Vector b:\n");   printvectorlist(b);
  printf("Scalar c: %g\n",c);
  numx=numy=numz=3;
  resizematrix(&tabx,numx*numy*numz,3);
  ind=0;
  for (i=1;i<=numx;++i)
    for (j=1;j<=numy;++j)
    {
      for (k=1;k<=numz;++k)
      {
        ++ind;
        tabx->m[ind][1]=(double) i/(double) 10;
        tabx->m[ind][2]=(double) j/(double) 10;
        tabx->m[ind][3]=(double) k/(double) 10;
      }
    }
  m_tablevector(taby,quadpol(matrowtovec0(tabx,i,&x),G,b,c),
                i=1,i<=tabx->d1,++i);
  m_tablevector(tabw,1,i=1,i<=tabx->d1,++i)
  printf("Matrix tabx:\n");   printmatrixlist(tabx);
  printf("Vector taby:\n");   printvectorlist(taby);
  printf("Vector tabw:\n");   printvectorlist(tabw);

  printf("\nCalculating coefficients of approximation...\n");
  t1=absolutetime(); ct1=cputime();
  printf("\n\nTime spent up to now: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);
  for (j=1;j<=numcalc;++j)
    i=coefquadpolapproxraw(tabx,taby,tabw,&raw);
  t2=absolutetime(); ct2=cputime();
  printf("\n\nCalculating %i approximations: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    numcalc,t2-t0,ct2-ct0,t2-t1,ct2-ct1);
  printf("Vector of raw coefficients:\n");   printvectorlist(raw);
  printf("\n\n");

  printf("\n\nConversion to regular form coefficients:\n");
  coefquadpolreg(raw,&G1,&b1,&c1);
  printf("Quadratic coefficients:\n");   printmatrixlist(G1);
  printf("Lin. coefficients:\n");   printvectorlist(b1);
  printf("Const. coefficient: %g\n",c1);

  printf("\n\nConversion back to raw form of coefficients:\n");
  coefquadpolraw(G1,b1,c1,&vaux);
  printf("Raw coefficients:\n");   printvectorlist(vaux);

  printf("\n\nTest of quadratic function and gradients:\n");
  initmat0(&tabx,12,3,  0.,0.,0.,  1.,0.,0.,  0.,1.,0.,  0.,0.,1.,
                        1.,1.,1.,  10.,0.,0., 0.,10.,0., 0.,0.,10.,
                        10.,1.,0., 1.,10.,0., 0.,10.,1., 0.,1.,10.  );
  printf("Table of points:\n");   printmatrixlist(tabx);
  printf("Values of the quadratic function in these points:\n");
  printf("By quadpol:\n");
  m_tablevector(tabfunc,quadpol(matrowtovec0(tabx,i,&x),G,b,c),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("By quadpolraw:\n");
  dispvector(&tabfunc);
  m_tablevector(tabfunc,quadpolraw(matrowtovec0(tabx,i,&x),raw),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("Gradients of the quadratic function in these points:\n");
  printf("By gradquadpol:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradquadpol(matrowtovec0(tabx,i,&x),G,b,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  printf("By gradquadpolraw:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradquadpolraw(matrowtovec0(tabx,i,&x),raw,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  dispmatrix(&maux);
  printf("By derquadpol:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derquadpol(matrowtovec0(tabx,i,&x),j,G,b);
  printmatrixlist(maux);
  printf("By derquadpolraw:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derquadpolraw(matrowtovec0(tabx,i,&x),j,raw);
  printmatrixlist(maux);
}

if (0)
{
  matrix taby=NULL,tabw=NULL;
  printf("\nPress <Enter>!");
  if (1)
    getchar();
  /* Test of quadratic approximations in 3D with gradient data: */
  printf("\n\n\n\n\n\nQUADRATIC approximation in 3D with GRADIENT data\n\n");
  initmat0(&G,3,3, 1.,2.,3., 
                   2.,4.,6.,
                   3.,6.,7.   );
  initvec0(&b,3,   4.,6.,25. );
  c=10;
  printf("Matrix G:\n");   printmatrixlist(G);
  printf("Vector b:\n");   printvectorlist(b);
  printf("Scalar c: %g\n",c);
  numx=numy=numz=3;
  resizematrix(&tabx,numx*numy*numz,3);
  ind=0;
  for (i=1;i<=numx;++i)
    for (j=1;j<=numy;++j)
    {
      for (k=1;k<=numz;++k)
      {
        ++ind;
        tabx->m[ind][1]=(double) i/(double) 10;
        tabx->m[ind][2]=(double) j/(double) 10;
        tabx->m[ind][3]=(double) k/(double) 10;
      }
    }
  coefquadpolraw(G,b,c,&vaux);
  m_tablematrix(taby, derquadpolraw(matrowtovec0(tabx,i,&x),j,vaux),
                i=1,i<=tabx->d1,++i,j=0,j<=tabx->d2,++j);
  m_tablematrix(tabw,1,i=1,
    i<=tabx->d1,++i,j=0,
    j<=tabx->d2,++j)
  printf("Matrix tabx (points):\n");   printmatrixlist(tabx);
  printf("Matrix taby (values and derivatives in points):\n");   printmatrixlist(taby);
  printf("matrix tabw (weights for values and derivatives):\n");   printmatrixlist(tabw);

  printf("\nCalculating coefficients of approximation...\n");
  t1=absolutetime(); ct1=cputime();
  printf("\n\nTime spent up to now: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);
  for (j=1;j<=numcalc;++j)
    i=coefquadpolapproxgradraw(tabx,taby,tabw,&raw);
  t2=absolutetime(); ct2=cputime();
  printf("\n\nCalculating %i approximations: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    numcalc,t2-t0,ct2-ct0,t2-t1,ct2-ct1);
  printf("Vector of raw coefficients:\n");   printvectorlist(raw);
  printf("\n\n");

  printf("\n\nConversion to regular form coefficients:\n");
  coefquadpolreg(raw,&G1,&b1,&c1);
  printf("Quadratic coefficients:\n");   printmatrixlist(G1);
  printf("Lin. coefficients:\n");   printvectorlist(b1);
  printf("Const. coefficient: %g\n",c1);

  printf("\n\nConversion back to raw form of coefficients:\n");
  coefquadpolraw(G1,b1,c1,&vaux);
  printf("Raw coefficients:\n");   printvectorlist(vaux);

  printf("\n\nTest of quadratic function and gradients:\n");
  initmat0(&tabx,12,3,  0.,0.,0.,  1.,0.,0.,  0.,1.,0.,  0.,0.,1.,
                        1.,1.,1.,  10.,0.,0., 0.,10.,0., 0.,0.,10.,
                        10.,1.,0., 1.,10.,0., 0.,10.,1., 0.,1.,10.  );
  printf("Table of points:\n");   printmatrixlist(tabx);
  printf("Values of the quadratic function in these points:\n");
  printf("By quadpol:\n");
  m_tablevector(tabfunc,quadpol(matrowtovec0(tabx,i,&x),G,b,c),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("By quadpolraw:\n");
  dispvector(&tabfunc);
  m_tablevector(tabfunc,quadpolraw(matrowtovec0(tabx,i,&x),raw),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("Gradients of the quadratic function in these points:\n");
  printf("By gradquadpol:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradquadpol(matrowtovec0(tabx,i,&x),G,b,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  printf("By gradquadpolraw:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradquadpolraw(matrowtovec0(tabx,i,&x),raw,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  dispmatrix(&maux);
  printf("By derquadpol:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derquadpol(matrowtovec0(tabx,i,&x),j,G,b);
  printmatrixlist(maux);
  printf("By derquadpolraw:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derquadpolraw(matrowtovec0(tabx,i,&x),j,raw);
  printmatrixlist(maux);
}

/* APPROXIMATION WITH LINEAR POLYNOMIALS: */
if (0)
{
  printf("\nPress <Enter>!");
  if (1)
    getchar();
  /* Test of linear polynomial approximations in 3D: */
  printf("\n\n\n\n\nLINEAR POL. approximation in 3D\n");
  initvec0(&b,3,   4.,6.,25. );
  c=10;
  printf("Vector b:\n");   printvectorlist(b);
  printf("Scalar c: %g\n",c);
  numx=numy=numz=3;
  resizematrix(&tabx,numx*numy*numz,3);
  ind=0;
  for (i=1;i<=numx;++i)
    for (j=1;j<=numy;++j)
    {
      for (k=1;k<=numz;++k)
      {
        ++ind;
        tabx->m[ind][1]=(double) i/(double) 10;
        tabx->m[ind][2]=(double) j/(double) 10;
        tabx->m[ind][3]=(double) k/(double) 10;
      }
    }
  m_tablevector(taby,linpol(matrowtovec0(tabx,i,&x),b,c),
                i=1,i<=tabx->d1,++i);
  m_tablevector(tabw,1,i=1,i<=tabx->d1,++i)
  printf("Matrix tabx:\n");   printmatrixlist(tabx);
  printf("Vector taby:\n");   printvectorlist(taby);
  printf("Vector tabw:\n");   printvectorlist(tabw);

  printf("\nCalculating coefficients of approximation...\n");
  t1=absolutetime(); ct1=cputime();
  printf("\n\nTime spent up to now: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);
  for (j=1;j<=numcalc;++j)
    i=coeflinpolapproxraw(tabx,taby,tabw,&raw);
  t2=absolutetime(); ct2=cputime();
  printf("\n\nCalculating %i approximations: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    numcalc,t2-t0,ct2-ct0,t2-t1,ct2-ct1);
  printf("Vector of raw coefficients:\n");   printvectorlist(raw);
  printf("\n\n");

  printf("\n\nConversion to regular form coefficients:\n");
  coeflinpolreg(raw,&b1,&c1);
  printf("Lin. coefficients:\n");   printvectorlist(b1);
  printf("Const. coefficient: %g\n",c1);

  printf("\n\nConversion back to raw form of coefficients:\n");
  coeflinpolraw(b1,c1,&vaux);
  printf("Raw coefficients:\n");   printvectorlist(vaux);

  printf("\n\nTest of lin. polynomial and gradients:\n");
  initmat0(&tabx,12,3,  0.,0.,0.,  1.,0.,0.,  0.,1.,0.,  0.,0.,1.,
                        1.,1.,1.,  10.,0.,0., 0.,10.,0., 0.,0.,10.,
                        10.,1.,0., 1.,10.,0., 0.,10.,1., 0.,1.,10.  );
  printf("Table of points:\n");   printmatrixlist(tabx);
  printf("Values of the linear polynomial in these points:\n");
  printf("By linpol:\n");
  m_tablevector(tabfunc,linpol(matrowtovec0(tabx,i,&x),b,c),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("By linpolraw:\n");
  dispvector(&tabfunc);
  m_tablevector(tabfunc,linpolraw(matrowtovec0(tabx,i,&x),raw),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("Gradients of the linear polynomiial in these points:\n");
  printf("By gradlinpol:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradlinpol(matrowtovec0(tabx,i,&x),b,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  printf("By gradlinpolraw:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradlinpolraw(matrowtovec0(tabx,i,&x),raw,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  dispmatrix(&maux);
  printf("By derlinpol:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derlinpol(matrowtovec0(tabx,i,&x),j,b);
  printmatrixlist(maux);
  printf("By derlinpolraw:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derlinpolraw(matrowtovec0(tabx,i,&x),j,raw);
  printmatrixlist(maux);
}

if (0)
{
  matrix taby=NULL,tabw=NULL;
  printf("\nPress <Enter>!");
  if (1)
    getchar();
  /* Test of linear polynom. approximations in 3D with gradient data: */
  printf("\n\n\n\n\n\nLINEAR POL. approximation in 3D with GRADIENT data\n\n");
  initvec0(&b,3,   4.,6.,25. );
  c=10;
  printf("Vector b:\n");   printvectorlist(b);
  printf("Scalar c: %g\n",c);
  numx=numy=numz=3;
  resizematrix(&tabx,numx*numy*numz,3);
  ind=0;
  for (i=1;i<=numx;++i)
    for (j=1;j<=numy;++j)
    {
      for (k=1;k<=numz;++k)
      {
        ++ind;
        tabx->m[ind][1]=(double) i/(double) 10;
        tabx->m[ind][2]=(double) j/(double) 10;
        tabx->m[ind][3]=(double) k/(double) 10;
      }
    }
  coeflinpolraw(b,c,&vaux);
  m_tablematrix(taby, derlinpolraw(matrowtovec0(tabx,i,&x),j,vaux),
                i=1,i<=tabx->d1,++i,j=0,j<=tabx->d2,++j);
  m_tablematrix(tabw,1,i=1,
    i<=tabx->d1,++i,j=0,
    j<=tabx->d2,++j)
  printf("Matrix tabx (points):\n");   printmatrixlist(tabx);
  printf("Matrix taby (values and derivatives in points):\n");   printmatrixlist(taby);
  printf("matrix tabw (weights for values and derivatives):\n");   printmatrixlist(tabw);

  printf("\nCalculating coefficients of approximation...\n");
  t1=absolutetime(); ct1=cputime();
  printf("\n\nTime spent up to now: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);
  for (j=1;j<=numcalc;++j)
    i=coeflinpolapproxgradraw(tabx,taby,tabw,&raw);
  t2=absolutetime(); ct2=cputime();
  printf("\n\nCalculating %i approximations: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    numcalc,t2-t0,ct2-ct0,t2-t1,ct2-ct1);
  printf("Vector of raw coefficients:\n");   printvectorlist(raw);
  printf("\n\n");

  printf("\n\nConversion to regular form coefficients:\n");
  coeflinpolreg(raw,&b1,&c1);
  printf("Lin. coefficients:\n");   printvectorlist(b1);
  printf("Const. coefficient: %g\n",c1);

  printf("\n\nConversion back to raw form of coefficients:\n");
  coeflinpolraw(b1,c1,&vaux);
  printf("Raw coefficients:\n");   printvectorlist(vaux);

  printf("\n\nTest of linear polynomial and gradients:\n");
  initmat0(&tabx,12,3,  0.,0.,0.,  1.,0.,0.,  0.,1.,0.,  0.,0.,1.,
                        1.,1.,1.,  10.,0.,0., 0.,10.,0., 0.,0.,10.,
                        10.,1.,0., 1.,10.,0., 0.,10.,1., 0.,1.,10.  );
  printf("Table of points:\n");   printmatrixlist(tabx);
  printf("Values of the linear polynomial in these points:\n");
  printf("By linpol:\n");
  m_tablevector(tabfunc,linpol(matrowtovec0(tabx,i,&x),b,c),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("By linpolraw:\n");
  dispvector(&tabfunc);
  m_tablevector(tabfunc,linpolraw(matrowtovec0(tabx,i,&x),raw),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("Gradients of the linear polynomial in these points:\n");
  printf("By gradlinpol:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradlinpol(matrowtovec0(tabx,i,&x),b,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  printf("By gradlinpolraw:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradlinpolraw(matrowtovec0(tabx,i,&x),raw,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  dispmatrix(&maux);
  printf("By derlinpol:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derlinpol(matrowtovec0(tabx,i,&x),j,b);
  printmatrixlist(maux);
  printf("By derlinpolraw:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derlinpolraw(matrowtovec0(tabx,i,&x),j,raw);
  printmatrixlist(maux);
}

/* REGULARIZATION OF LINEAR POLYNOMIALS APPROXIMATION: */
if (1)
{
  printf("\nPress <Enter>!");
  if (1)
    getchar();
  /* Test of REGULARIZATION of linear polynomial approximations in 3D,
  point grid does not have z component: */
  printf("\n\n\n\n\nREGULARIZATION of LINEAR POL. approximation in 3D\n");
  initvec0(&b,3,   4.,6.,25. );
  c=10;
  printf("Vector b:\n");   printvectorlist(b);
  printf("Scalar c: %g\n",c);
  numx=numy=numz=3;
  resizematrix(&tabx,numx*numy*1,3);
  ind=0;
  for (i=1;i<=numx;++i)
    for (j=1;j<=numy;++j)
    {
      for (k=0;k<=0;++k) /* no component in z direction, sys. mat. will be singular */
      {
        ++ind;
        tabx->m[ind][1]=(double) i/(double) 10;
        tabx->m[ind][2]=(double) j/(double) 10;
        tabx->m[ind][3]=(double) k/(double) 10;
      }
    }
  /* Insert additional poiint with small value of z co-ordinate. If the value
  is too small, the system will be pre-conditioned, which will in general
  spoil the original solution, but prevent some of coefficient of becoming
  too large: */
  resizematrix(&tabx,tabx->d1+1,3);
  tabx->m[tabx->d1][1]=tabx->m[tabx->d1][2]=0;
  tabx->m[tabx->d1][3]=1e-10;
  m_tablevector(taby,linpol(matrowtovec0(tabx,i,&x),b,c),
                i=1,i<=tabx->d1,++i);
  m_tablevector(tabw,1,i=1,i<=tabx->d1,++i)
  printf("Matrix tabx:\n");   printmatrixlist(tabx);
  printf("Vector taby:\n");   printvectorlist(taby);
  printf("Vector tabw:\n");   printvectorlist(tabw);

  printf("\nCalculating coefficients of approximation...\n");
  t1=absolutetime(); ct1=cputime();
  printf("\n\nTime spent up to now: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    t1-t0,ct1-ct0,t1-t0,ct1-ct0);
  for (j=1;j<=numcalc;++j)
    i=coeflinpolapproxraw(tabx,taby,tabw,&raw);
  if (i)
  {
    printf("\nThe system matrix was singular.\n");
    if (i>0)
      printf("Repaired after %i iterations.\n\n",i);
    else
      printf("Could not be repaired, gave up after %i attempts.\n\n",-i);
  }
  t2=absolutetime(); ct2=cputime();
  printf("\n\nCalculating %i approximations: %g s (CPU %g s), pure: %g s (CPU %g s)\n",
    numcalc,t2-t0,ct2-ct0,t2-t1,ct2-ct1);
  printf("Vector of raw coefficients:\n");   printvectorlist(raw);
  printf("\n\n");

  printf("\n\nConversion to regular form coefficients:\n");
  coeflinpolreg(raw,&b1,&c1);
  printf("Lin. coefficients:\n");   printvectorlist(b1);
  printf("Const. coefficient: %g\n",c1);

  printf("\n\nConversion back to raw form of coefficients:\n");
  coeflinpolraw(b1,c1,&vaux);
  printf("Raw coefficients:\n");   printvectorlist(vaux);

  printf("\n\nTest of lin. polynomial and gradients:\n");
  initmat0(&tabx,12,3,  0.,0.,0.,  1.,0.,0.,  0.,1.,0.,  0.,0.,1.,
                        1.,1.,1.,  10.,0.,0., 0.,10.,0., 0.,0.,10.,
                        10.,1.,0., 1.,10.,0., 0.,10.,1., 0.,1.,10.  );
  printf("Table of points:\n");   printmatrixlist(tabx);
  printf("Values of the linear polynomial in these points:\n");
  printf("By linpol:\n");
  m_tablevector(tabfunc,linpol(matrowtovec0(tabx,i,&x),b,c),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("By linpolraw:\n");
  dispvector(&tabfunc);
  m_tablevector(tabfunc,linpolraw(matrowtovec0(tabx,i,&x),raw),
                i=1,i<=tabx->d1,++i);
  printvectorlist(tabfunc);
  printf("Gradients of the linear polynomiial in these points:\n");
  printf("By gradlinpol:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradlinpol(matrowtovec0(tabx,i,&x),b,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  printf("By gradlinpolraw:\n");
  dispmatrix(&maux);
  m_tablematrix(maux,
                gradlinpolraw(matrowtovec0(tabx,i,&x),raw,&vaux)->v[j],
                i=1,i<=tabx->d1,++i,j=1,j<=tabx->d2,++j);
  printmatrixlist(maux);
  dispmatrix(&maux);
  printf("By derlinpol:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derlinpol(matrowtovec0(tabx,i,&x),j,b);
  printmatrixlist(maux);
  printf("By derlinpolraw:\n");
  dispmatrix(&maux);  maux=getmatrix(tabx->d1,tabx->d2);
  for (i=1;i<=maux->d1;++i)
    for (j=1;j<=maux->d2;++j)
      maux->m[i][j]=derlinpolraw(matrowtovec0(tabx,i,&x),j,raw);
  printmatrixlist(maux);
}


dispmatrix(&G);
dispvector(&b);
}

