
#include <sysint.h>
#include <t_sysint.h>

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <stdarg.h>

# include <mtypes.h>
# include <st.h>
# include <strop.h>
# include <fop.h>
# include <mtime.h>
# include <rf.h>
# include <er.h>

#include <t_strop.h>

#include <z.h>

#ifdef IGTEST
 #include "../ct/h/h_z.h"
#endif

/* Structure that determines the coding functions and data: */
typedef struct{
  char *name;
  void (*code) (char *str,int length,char *key);
  void (*decode) (char *str,int length,char *key);
} _codingstruct;

typedef _codingstruct *codingstruct;


static void codedouble(char *str,int length,char *key); /* for use with defaultcodingdata */

static _codingstruct defaultcodingdata={
   "default",              /* name */
    codeblocksimppub,  /* code */
    decodeblocksimppub             /* decode */
};

/* Current coding functions and data: */
static codingstruct codingdata=&defaultcodingdata;
/* Available groups of coding functions and data accessible by identification
string: */
static stack codingstack=NULL;

static void codeidentity(char *str,int length,char *key)
    /* Identity coding.
    $A Igor jan02; */
{
}

static void codedouble(char *str,int length,char *key)
    /* Auxiliary function for initcodingdata().
    $A Igor jan02; */
{
codingdata->code(str,length,key);
codingdata->code(str,length,key);
}

static void codetriple(char *str,int length,char *key)
    /* Auxiliary function for initcodingdata().
    $A Igor jan02; */
{
codingdata->code(str,length,key);
codingdata->code(str,length,key);
codingdata->code(str,length,key);
}


void codestring(char *str,int length,char *key)
    /* Codes string str of length length with the current coding algorithm
    using the key string key. str can contain zero characters ('\0').
    Function setcodingdata() or setcodingdatanum() should be called prior to use
    of this function.
    $A Igor dec02; */
{
if (codingdata==NULL)
{
  errfunc0("codestring");
  sprintf(ers(),"Can not perform coding: coding data is not defined.\n");
  errfunc2();
} else if (codingdata->code==NULL)
{
  errfunc0("codestring");
  sprintf(ers(),"Can not perform coding: coding procedure is not known.\n");
  errfunc2();
} else
{
  codingdata->code(str,length,key);
}
}

void codestring0(char *str,char *key)
    /* Codes string str of length length with the current coding algorithm
    using the key string key. str must be a zero terminated string.
    Function setcodingdata() or setcodingdatanum() should be called prior to use
    of this function.
    $A Igor dec02; */
{
codestring(str,stringlength(str),key);
}


void decodestring(char *str,int length,char *key)
    /* Decodes string str of length length with the current coding algorithm
    using the key string key. str can contain zero characters ('\0').
    Function setcodingdata() or setcodingdatanum() should be called prior to use
    of this function.
    $A Igor dec02; */
{
if (codingdata==NULL)
{
  errfunc0("decodestring");
  sprintf(ers(),"Can not perform coding: coding data is not defined.\n");
  errfunc2();
} else if (codingdata->decode==NULL)
{
  errfunc0("decodestring");
  sprintf(ers(),"Can not perform coding: coding procedure is not known.\n");
  errfunc2();
} else
{
  codingdata->decode(str,length,key);
}
}

void decodestring0(char *str,char *key)
    /* Decodes string str of length length with the current coding algorithm
    using the key string key. str must be a zero terminated string.
    Function setcodingdata() or setcodingdatanum() should be called prior to use
    of this function.
    $A Igor dec02; */
{
decodestring(str,stringlength(str),key);
}


static int cmpcodingstruct(void *p1,void *p2)
    /* Compares pointers p1 and p2 of the type codingstruct by (...)->name.
    If p1 and p2 are different than NULL, then cmpstrings(pe->name,p2->name)
    is returned. If both are NULL, 0 is returned, if only p1 is NULL, 2 is
    returned (in this case it is condidered that p1>p2), and if only p2 is
    NULL, -2 is returned.
    $A Igor dec02; */
{
codingstruct u1,u2;
u1=p1; u2=p2;
if (u1!=NULL && u2!=NULL)
  return cmpstrings(u1->name,u2->name);
else if (u1==NULL)
{
  if (u2==NULL)
    return 0;
  else
    return 2;
} else if (u2==NULL)
  return -2;
else return -2; /* for the sake of some compilers */
}


int setcodingdata(char *name)
    /* Sets the coding and encoding functions and data according to the
    string name. Returns a positive successive number of the data if
    successfull, 0 if not.
    $A Igor dec02; */
{
int place=0;
_codingstruct csref={0};
csref.name=name;
if (codingstack==NULL)
  initcodingdata();
if ((place=findsortstack(codingstack,&csref,0,0,cmpcodingstruct))>0)
  codingdata=codingstack->s[place];
else
{
  errfunc0("setcodingdata");
  sprintf(ers(),"String \"%s\" is not a valid coding identification.\n",name);
  errfunc2();
}
return place;
}


char *setcodingdatanum(int n)
    /* Sets the coding and encoding functions and data according to the
    successive number n on the stack codingstack. Returns the coding
    identification string if successfull, NULL if not.
    $A Igor dec02; */
{
char *ret=NULL;
codingstruct csref=NULL;
if (codingstack==NULL)
  initcodingdata();
if ((csref=nstack(codingstack,n))!=NULL)
{
  codingdata=csref;
  ret=codingdata->name;
} else
{
  errfunc0("setcodingdatanum");
  sprintf(ers(),"Number %i is not a valid coding identification.\n",n);
  errfunc2();
}
return ret;
}


void initcodingdata(void)
    /* Initialises data about the available ways of coding identifiable by the
    identification strings. 
    $A Igor dec02; */
{
codingstruct cs;
if (codingstack==NULL)
{
  codingstack=newstack(8);
  /* default coding - "default" */
  cs=calloc(1,sizeof(*cs));
   *cs=defaultcodingdata;
   inssortstack(codingstack,cs,cmpcodingstruct);
  /* identity coding (does not change the contents) - "i" */
  cs=calloc(1,sizeof(*cs));
   cs->name="i";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codeidentity;
   cs->decode=codeidentity;
  /* Coding by using characte maps: */
  cs=calloc(1,sizeof(*cs));
   cs->name="simpmap";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codetwostepsimp100;
   cs->decode=codetwostepsimp100;
  cs=calloc(1,sizeof(*cs));
   cs->name="simpmap1";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codetwostepsimp100;
   cs->decode=codetwostepsimp100;
  cs=calloc(1,sizeof(*cs));
   cs->name="simpmap2";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codetwostepsimp100;
   cs->decode=codetwostepsimp100;
  cs=calloc(1,sizeof(*cs));
   cs->name="simpmap3";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codethreestepsimp100;
   cs->decode=codedouble;
  cs=calloc(1,sizeof(*cs));
   cs->name="simpmap4";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codefourstepsimp100;
   cs->decode=codetriple;
  /* Coding without character maps: */
  cs=calloc(1,sizeof(*cs));
   cs->name="pub";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codeblocksimppub;
   cs->decode=decodeblocksimppub;
  cs=calloc(1,sizeof(*cs));
   cs->name="inv";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codeblocksimpinv;
   cs->decode=decodeblocksimpinv;
  /* Test algorithms: */
  #ifdef IGTEST
  cs=calloc(1,sizeof(*cs));
   cs->name="ig0";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codeblocksimp0;
   cs->decode=decodeblocksimp0;
   cs=calloc(1,sizeof(*cs));
   cs->name="ig1";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codeblocksimp1001;
   cs->decode=decodeblocksimp1001;
  cs=calloc(1,sizeof(*cs));
   cs->name="ig2";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codeblocksimp1002;
   cs->decode=decodeblocksimp1002;
  cs=calloc(1,sizeof(*cs));
   cs->name="ig";
   inssortstack(codingstack,cs,cmpcodingstruct);
   cs->code=codeblocksimp100;
   cs->decode=decodeblocksimp100;
  #endif   /* defined IGTEST */

}
}


#ifdef KEYPROT
  #include <../z/z1.h>
#else
  
  static char *getkeytwostepsimp100(char *str)
  {
  errfunc0("getkeytwostepsimp100");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  return NULL;
  }
  
  void codetwostepsimp100(char *string,int length,char *key)
  {
  errfunc0("codetwostepsimp100");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  }
  
  static char *getkeythreestepsimp100(char *str)
  {
  errfunc0("getkeythreestepsimp100");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  return NULL;
  }
  
  void codethreestepsimp100(char *string,int length,char *key)
  {
  errfunc0("codethreestepsimp100");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  }
  
  static char *getkeyfourstepsimp100(char *str)
  {
  errfunc0("getkeyfourstepsimp100");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  return NULL;
  }
  
  void codefourstepsimp100(char *string,int length,char *key)
  {
  errfunc0("codefourstepsimp100");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  }

  
  char *getuserdatainv(char *key)
  {
  errfunc0("getuserdatainv");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  return NULL;
  }
  
  char *createkeyinv(void)
  {
  errfunc0("createkeyinv");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  return NULL;
  }

  void codeblocksimppub(char *str,int length,char *key)
  {
  errfunc0("codeblocksimppub");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  }

  void decodeblocksimppub(char *str,int length,char *key)
  {
  errfunc0("decodeblocksimppub");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  }

  void codeblocksimpinv(char *str,int length,char *key)
  {
  errfunc0("codeblocksimpinv");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  }

  void decodeblocksimpinv(char *str,int length,char *key)
  {
  errfunc0("codeblocksimpinv");
  sprintf(ers(),"Macro KEYPROT was not defined during compilation!\nThe code should be recompiled.");
  errfunc2();
  }


#endif /* not defied KEYPROT */


static char *getmachineiddos(char *helpstr)
    /* Vrne identifikacijski niz racunalnika, na katerem tece program, ce je
    sistem na tem racunalniku sistem DOS ali Windows.
    $A Igor avg98; */
{
char *ret=NULL,*str=NULL,*str1=NULL,*command;
char filename[200];
FILE *fp;
int i;
tmpnam(filename);
/* V zacasno datoteko s sistemskim ukazom izpisemo oznako volumna in serijsko
stevilko, iz cesar potem razberemo identifikacijski niz: */
str=stringcat("vol ",helpstr);
str1=stringcat(str," > ");
command=stringcat(str1,filename);
if (str!=NULL)
  free(str);
if (str1==NULL)
  free(str1);
str=str1=NULL;
system(command);
free(command);
/* Odpremo zacasno datoteko in preberemo zapisan niz: */
fp=fopen(filename,"rb");
if (fp!=NULL)
{
  long pos1,pos2;
  int length;
  /* V datoteki najprej poiscemo niz "Serial "Number ali nekaj podobnega: */
  pos1=filestring(fp,"erial",1,50);
  if (pos1<1)
    pos1=filestring(fp,"SERIAL",1,50);
  if (pos1>0)
  {
    pos2=filestring(fp,"umber",pos1,25);
    if (pos2<1)
      pos2=filestring(fp,"NUMBER",pos1,25);
    if (pos2>0)
    {
      length=flength(fp)+1-pos2;
      if (length>0)
      {
        str=makestring(length);
        fileread(str,1,length,fp,pos2);
        pos2=strlen(str);
        /* pos2 postane od zadaj naprej pozicija prvega znaka prebranega
        niza, ki je neprazen (stevsi od 0 naprej): */
        while(pos2>=0 && (str[pos2]==' ' ||str[pos2]=='\n' || str[pos2]=='\r'
              || str[pos2]=='\t' || str[pos2]=='\0') )
          --pos2;
        if (pos2>=0)
        {
          /* pos1 postane od pos2-1 proti zacetku niza pozicija zadnjega znaka
          niza, ki je neprazen: */
          pos1=pos2;
          while (pos1>0 && (str[pos1-1]!=' ' && str[pos1-1]!='\n' && str[pos1-1]!='\r'
                 && str[pos1-1]!='\t' && str[pos1-1]!='\0'))
            --pos1;
          length=pos2+1-pos1;
          /* ustrezni del prebranega niza str prepisemo v ret: */
          ret=makestring(length);
          i=pos1;
          while(i<=pos2)
          {
            ret[i-pos1]=str[i];
            ++i;
          }
        }
        free(str);
        str=NULL;
      }
    }
  }
  /* Po branju zapremo datoteko in zbrisemo zacasno datoteko: */
  fclose(fp);
  remove(filename);
}
return ret;
}


static char *getmachineidlinux(void)
    /* Vrne identifikacijski niz racunalnika, na katerem tece program, ce je
    sistem na tem racunalniku sistem Linux. Niz dobimo z ukazi "uname -s",
    "uname -n" in "uname -m" (je zlepljenka nizov, ki jih izpisejo ti ukazi).
    $A Igor avg98; */
{
long pos1,pos2;
int length;
char *ret=NULL,*str=NULL,*str1=NULL;
char filename[200];
FILE *fp;
char *command;
tmpnam(filename);
/* V zacasno datoteko s sistemskim ukazom izpisemo 1. del identifikacijskega
niza: */
command=stringcat("uname -s > ",filename);
system(command);
free(command);
/* Odpremo zacasno datoteko in preberemo zapisan niz: */
fp=fopen(filename,"rb");
if (fp!=NULL)
{
  /* V datoteki izpustimo vse prazne znake pred in po nizu: */
  pos1=filenotchar(fp," \n\r\t\0",5,1,5);
  if (pos1>0)
  {
    pos2=filechar(fp," \n\r\t\0",5,pos1,15);
    if (pos2<1)
      pos2=flength(fp)+1;
    length=pos2-pos1;
    /* 1. del identifikacijskega niza preberemo v ret: */
    if (length>0)
    {
      ret=makestring(length);
      fileread(ret,1,length,fp,pos1);
    }
  }
  /* Po branju zapremo datoteko in zbrisemo zacasno datoteko: */
  fclose(fp);
  remove(filename);
}
/* V zacasno datoteko s sistemskim ukazom izpisemo 2. del identifikacijskega
niza: */
command=stringcat("uname -n > ",filename);
system(command);
free(command);
/* Odpremo zacasno datoteko in preberemo zapisan niz: */
fp=fopen(filename,"rb");
if (fp!=NULL)
{
  /* V datoteki izpustimo vse prazne znake pred in po nizu: */
  pos1=filenotchar(fp," \n\r\t\0",5,1,5);
  if (pos1>0)
  {
    pos2=filechar(fp," \n\r\t\0",5,pos1,15);
    if (pos2<1)
      pos2=flength(fp)+1;
    length=pos2-pos1;
    /* 2. del identifikacijskega niza preberemo v str in ga nato dodamo ret: */
    if (length>0)
    {
      str=makestring(length);
      fileread(str,1,length,fp,pos1);
      str1=ret;
      ret=stringcat(str1,str);
      if (str!=NULL)
        free(str);
      if (str1!=NULL)
        free(str1);
      str=str1=NULL;
    }
  }
  /* Po branju zapremo datoteko in zbrisemo zacasno datoteko: */
  fclose(fp);
  remove(filename);
}
/* V zacasno datoteko s sistemskim ukazom izpisemo 3. del identifikacijskega
niza: */
command=stringcat("uname -m > ",filename);
system(command);
free(command);
/* Odpremo zacasno datoteko in preberemo zapisan niz: */
fp=fopen(filename,"rb");
if (fp!=NULL)
{
  /* V datoteki izpustimo vse prazne znake pred in po nizu: */
  pos1=filenotchar(fp," \n\r\t\0",5,1,5);
  if (pos1>0)
  {
    pos2=filechar(fp," \n\r\t\0",5,pos1,15);
    if (pos2<1)
      pos2=flength(fp)+1;
    length=pos2-pos1;
    /* 3. del identifikacijskega niza preberemo v str in ga nato dodamo ret: */
    if (length>0)
    {
      str=makestring(length);
      fileread(str,1,length,fp,pos1);
      str1=ret;
      ret=stringcat(str1,str);
      if (str!=NULL)
        free(str);
      if (str1!=NULL)
        free(str1);
      str=str1=NULL;
    }
  }
  /* Po branju zapremo datoteko in zbrisemo zacasno datoteko: */
  fclose(fp);
  remove(filename);
}
return ret;
}


static char *getmachineidnormalunix(void)
    /* Vrne identifikacijski niz racunalnika, na katerem tece program, ce je
    sistem na tem racunalniku sistem Unix, pri katerem ukaz "uname -i" vrne
    stevilko racunalnika.
    $A Igor avg98; */
{
char *ret=NULL;
char filename[200];
FILE *fp;
char *command;
tmpnam(filename);
/* V zacasno datoteko s sistemskim ukazom izpisemo identifikacijski niz: */
command=stringcat("uname -i > ",filename);

/*
Test, ki naj pove, zakaj so stvari tako pocasne Izgleda, da je zelo pocasen
ukaz remove.
if(1)
{
  int i;
  for (i=1;i<=10;++i)
  {
    tmpnam(filename);
    fp=fopen(filename,"wb");
    fclose(fp);
    remove(filename);
  }
}
*/

system(command);
free(command);
/* Odpremo zacasno datoteko in preberemo zapisan niz: */
fp=fopen(filename,"rb");
if (fp!=NULL)
{
  long pos1,pos2;
  int length;
  /* V datoteki izpustimo vse prazne znake pred in po nizu: */
  pos1=filenotchar(fp," \n\r\t\0",5,1,5);
  if (pos1>0)
  {
    pos2=filechar(fp," \n\r\t\0",5,pos1,15);
    if (pos2<1)
      pos2=flength(fp)+1;
    length=pos2-pos1;
    if (length>0)
    {
      ret=makestring(length);
      fileread(ret,1,length,fp,pos1);
    }
  }
  /* Po branju zapremo datoteko in zbrisemo zacasno datoteko: */
  fclose(fp);
  remove(filename);
}
return ret;
}


char *getmachineid(char *helpstr)
    /* Funkcija vrne identifikacijski niz racunalnika, na katerem tece program.
    Ta niz se lahko uporabi npr. za preverjanje veljavnosti licenc. helpstr
    je pomozni niz, s katerim si funkcija lahko pomaga, da pride do pravega
    identifikacijskega niza. Na DOSu in Windowsih se npr. za identifikacijski
    niz tipicno vzame serijska stevilka diska, na katerem je instaliran
    program, zato pa je treba vedeti, kateri je ta disk in to sporocimo
    funkciji prek argumenta helpstr (na UNIX-u tega argumenta ne uporabljamo).
      Ce se identifikacijskega niza ne more dobiti, funkcija vrne NULL.
    $A Igor avg98; */
{
char *ret=NULL;
#if 1
  return ig_getmachinestr();
#else
  #ifdef UNIX
   #ifdef LINUX
    ret=getmachineidlinux();
   #else
   /* Ce smo na UNIXU, kjer uname -i vrne identifikacijsko stevilko masine: */
    ret=getmachineidnormalunix();
   #endif
  #else
   #ifdef DOS
    ret=getmachineiddos(helpstr);
   #endif
  #endif
  return ret;
#endif
}




char *getuserdatafield(char *data,int length,char *fieldname)
    /* Vrne vrednost polja z imenom fieldname iz niza data dolzine length, ki
    vsebuje podatke o licenci oz. uporabniku programa v primerni obliki. Ce
    taksnega polja niz data ne vsebuje, vrne NULL. Niz, ki ga funkcija vrne,
    lahko brisemo s free.
    $A Igor sep98; */
{
char *fieldval=NULL;
int pos1,pos2;
/* Najprej poiscemo ime polja: */
pos1=imemfind(data,length,fieldname,strlen(fieldname));
if (pos1>-1)
{
  pos1+=strlen(fieldname);
  while(data[pos1]==' '&& pos1<length)
    ++pos1;
  if (pos1<length && data[pos1]=='{')
  {
    ++pos1;
    pos2=pos1;
    while(data[pos2]!='}'&& pos2<length)
      ++pos2;
    if (pos2<length)
    {
      fieldval=stringncopy(data+pos1,pos2-pos1);
    }
  }
}
return fieldval;
}

char *getuserdatafield0(char *data,char *fieldname)
    /* Vrne vrednost polja z imenom fieldname iz niza data, ki vsebuje podatke
    o licenci oz. uporabniku programa v primerni obliki. Ce taksnega polja niz
    data ne vsebuje, vrne NULL. Niz, ki ga funkcija vrne, lahko brisemo s free.
    data mora biti niz zakljucen z znakom '\0'.
    $A Igor sep98; */
{
return getuserdatafield(data,strlen(data),fieldname);
}



static void addfieldtouserdata(char **data,char *fieldname,char *fieldvalue)
    /* V niz *data, ki predstavlja podatke o programu in licenci, doda polje
    z imenom fieldname in vrednostjo fieldvalue.
     OPOMBA:
     Format niza, ki predstavlja podatke o licenci, je nasleden:
       polje1{vrednost1} polje2{vrednost1} polje3{vrednost3} ...
    Ime 1. polja mora biti obvezno "program"!!! Poleg tega mora biti to ime
    takoj na zacetku niza!
    $A Igor avg98; */
{
char *str1,*str2;
if (*data==NULL)
  str1=stringcopy(*data);
else if (**data=='\0')
  str1=stringcopy(*data);
else
  str1=stringcat(*data," ");
free(*data);
str2=stringcat(str1,fieldname);
free(str1);
str1=stringcat(str2,"{");
free(str2);
str2=stringcat(str1,fieldvalue);
free(str1);
*data=stringcat(str2,"}");
free(str2);
}


char *getuserdatastr(char *first,...)
    /* Returns an allocated string that contains field and values as specified
    by arguments. Arguments must appear in pairs where the first one represents
    the field and the second one the coresponding value (may be NULL). The end
    of the pairs must be indicated by a NULL pointer for the field. There is
    no need to state any corresponding value pointer to this terminating field
    pointer.
    $A Igor dec02; */
{
char *arg,*ret=NULL,*fld,*val;
va_list ap;
va_start(ap,first);
arg=first;
while (arg!=NULL)
{
  fld=arg;
  val=arg=va_arg(ap,char*);
  addfieldtouserdata(&ret,fld,val);
  arg=va_arg(ap,char *);
}
return ret;
}


char *getuserdata(stack fieldnames,stack fieldvalues)
    /* Returns an allocated string that contains fields and values as specified
    by stack fieldnames and fieldvalues. Fieldnames must contain strings thet
    represent the fields while corresponding strings on fieldvalues must ve
    the values of these fields.
    $A Igor dec02; */
{
char *ret=NULL,*fld,*val;
int i;
if (fieldnames!=NULL)
{
  if (fieldvalues!=NULL)
    if (fieldvalues->n>fieldnames->n)
    {
      errfunc0("getuserdata");
      sprintf(ers(),"Number of values (%i) is greater than number of fields (%i).\n",
        fieldvalues->n,fieldnames->n);
      errfunc2();
    }
  for (i=1;i<=fieldnames->n;++i)
  {
    fld=fieldnames->s[i];
    val=NULL;
    if (fieldvalues!=NULL)
      if (fieldvalues->n>=i)
        val=fieldvalues->s[i];
    if (fld==NULL)
    {
      if (val!=NULL)
      {
        errfunc0("getuserdata");
        sprintf(ers(),"Field is NULL ( corresponding value: %s).\n",val);
        errfunc2();
      }
    } else if (*fld=='\0')
    {
      if (val!=NULL)
      {
        errfunc0("getuserdata");
        sprintf(ers(),"Field is an empty string (corresponding value: %s).\n",val);
        errfunc2();
      }
    } else
    {
      addfieldtouserdata(&ret,fld,val);
    }
  }
}
return ret;
}

char *getuserdataint(stack fieldnames,stack fieldvalues)
    /* Makes a string that contains data about the program and licence. Stack
    fieldnames must contain names of the fields included in the string while
    the stack fieldvalues must contain the values of these fields at the
    corresponding positions.
      If any values on fieldvalues are NULL then the user is asked to insert
    these values. When all fields on fieldnames are added to the created
    string, the user is asked to add any additional fields. Entering of the
    additional fields stops when the user inserts an empty string for the
    first time.
    $A Igor avg98; dec02; */
{
char buf[1000],buf1[1000],*data=NULL,end=0,dispfieldnames=0,dispfieldvalues=0;
int i,ask;
if (fieldnames!=NULL)
{
  if (fieldnames->n>0)
  {
    printf("\n\nInput required user's data! Press <Return> when data not applicable!\n\n");
    for (i=1;i<=fieldnames->n;++i)
    {
      if (fieldnames->s[i]!=NULL)
      {
        ask=1;
        if (fieldvalues!=NULL)
          if (fieldvalues->n>=i)
            if (fieldvalues->s[i]!=NULL)
            {
              addfieldtouserdata(&data,fieldnames->s[i],fieldvalues->s[i]);
              printf("\n    %s = {%s}\n\n",fieldnames->s[i],fieldvalues->s[i]);
              ask=0;
            }
        if (ask)
        {
          printf("%s = ",fieldnames->s[i]);
          gets(buf);
          addfieldtouserdata(&data,fieldnames->s[i],buf);
        }
      }
    }
  } else if (fieldvalues!=NULL)
    if (fieldvalues->n>0)
    {
      errfunc0("getuserdataint");
      sprintf(ers(),"There are no field names, but %i field values are defined.\n",
        fieldvalues->n);
    }
}  else if (fieldvalues!=NULL)
  if (fieldvalues->n>0)
  {
    errfunc0("getuserdataint");
    sprintf(ers(),"There are no field names, but %i field values are defined.\n",
      fieldvalues->n);
  }
if (fieldnames==NULL)
{
  fieldnames=newstack(10);
  dispfieldnames=1;
}
if (fieldvalues==NULL)
{
  fieldvalues=newstack(10);
  dispfieldvalues=1;
}
printf("\nInput additional user data fields!\n");
printf("Press <Return> when you want to finish!\n\n");
while (!end)
{
  printf("Field name: ");
  gets(buf1);
  if (*buf1!='\0')
  {
    printf("Value of %s: ",buf1);
    gets(buf);
    printf("\n");
    addfieldtouserdata(&data,buf1,buf);
  } else
  {
    end=1;
    printf(">>>> No more fields.\n");
  }
}
printf("\nUser data string created. String is: \n\"%s\"\n",data);
printf("String length is %i.\n\n",stringlength(data));
if (dispfieldnames)
  dispstack(&fieldnames);
if (dispfieldvalues)
  dispstack(&fieldvalues);
return data;
}


char *getuserdataintstr(char *first,...)
    /* Returns an allocated string that contains field and values as specified
    by arguments. Arguments must appear in pairs where the first one represents
    the field and the second one the coresponding value (may be NULL). The end
    of the pairs must be indicated by a NULL pointer for the field. There is
    no need to state any corresponding value pointer to this terminating field
    pointer.
    $A Igor dec02; */
{
char *arg,*ret=NULL,*fld,*val;
stack fields=NULL,values=NULL;
va_list ap;
va_start(ap,first);
arg=first;
while ((fld=arg)!=NULL)
{
  val=arg=va_arg(ap,char*);
  arg=va_arg(ap,char *);
  if (*fld!='\0')
  {
    if (fields==NULL)
      fields=newstack(10);
    pushstack(fields,val);
    if (val!=NULL)
    {
      if (values==NULL)
        values=newstack(10);
      insstack(values,val,fields->n);
    }
  }
  /* addfieldtouserdata(&ret,fld,val); */
}
ret=getuserdataint(fields,values);
dispstack(&fields);
dispstack(&values);
return ret;
}



char *getuserdatastandard(void)
    /* Naredi niz, v katerem so osnovni podatki o programu in licenci in ki je
    osnova z kljuc, ki ga cekira program pri zagonu. Nekaj standardnih polj
    funkcija ze sama pripravi za vgraditev v niz.
    $A Igor avg98; */
{
stack fieldnames;
char *data;
fieldnames=newstack(5);
pushstack(fieldnames,"program");
pushstack(fieldnames,"version");
pushstack(fieldnames,"level");
pushstack(fieldnames,"expire");
pushstack(fieldnames,"owner");
pushstack(fieldnames,"mail");
pushstack(fieldnames,"address");
pushstack(fieldnames,"id");
pushstack(fieldnames,"key");
data=getuserdataint(fieldnames,NULL);
dispstack(&fieldnames);
return data;
}









/* IG_Z */

char *ig_getmachinestr(void)
    /* Returns machine-dependent string that can be used for check the machine
    identity.
    $A Igor dec02; */
{
char *compname=NULL,*procid=NULL,*procrev=NULL,*windir=NULL,
     *sysdrive=NULL,*idstr=NULL,*idstr1=NULL,*idstr2=NULL,
     *aux1=NULL,*aux2=NULL,*aux3=NULL,
     *os=NULL,*machine=NULL,
     *ret=NULL,*com=NULL,*com1=NULL,*com2=NULL,*sep=";";
#define PRINTINTERMEDIATERESULTS 0
#if defined (UNIX)
  compname=getenv("HOSTNAME");
  if (compname==NULL)
    compname=getenv("HOST");
  if (stringlength(compname)<1)
    compname=aux1=systemresstr("hostname");
  machine=getenv("HOSTTYPE");
  if (stringlength(machine)<1)
    machine=getenv("PROCESSOR_IDENTIFIER");
  if (stringlength(machine)<1)
    machine=aux2=systemresstr("echo -n $HOSTTYPE");
  os=getenv("MACHTYPE");
  if (stringlength(os)<1)
    os=getenv("PROCESSOR_REVISION");
  if (stringlength(os)<1)
    os=aux3=systemresstr("echo -n $MACHTYPE");
  com=multstringcatn(2,"una","me -m");
  com1=multstringcatn(2,"una","me -n");
  com2=multstringcatn(2,"una","me -i");
  idstr=systemresstr(com);
  idstr1=systemresstr(com1);
  idstr2=systemresstr(com2);
  if (stringlength(idstr2)<2)
  {
    disppointer((void **) &com2); disppointer((void **) &idstr2);
    com2=multstringcatn(2,"una","me -s");
    idstr2=systemresstr(com2);
  }
  ret=multstringcatn(12,compname,sep,machine,sep,os,sep,
      idstr,sep,idstr1,sep,idstr2,sep,sep);
  
  #if PRINTINTERMEDIATERESULTS
    printf("Computer name:        %s\n",compname);
    printf("Machine:              %s\n",machine);
    printf("Op. system:           %s\n",os);
    printf("Command:              %s\n",com);
    printf("Command result:       %s\n",idstr);
    printf("Command 1:            %s\n",com1);
    printf("Command result 1:     %s\n",idstr1);
    printf("Command 2:            %s\n",com2);
    printf("Command result 2:     %s\n",idstr2);
    printf("Beg. com. res.:       %i, %i, %i, ..., %i, %i\n",
      idstr[0],idstr[1],idstr[2],idstr[strlen(idstr)-2],idstr[strlen(idstr)-1]);
    printf("Beg. com. res. 1:     %i, %i, %i\n",idstr1[0],idstr1[1],idstr1[2]);
    printf("Beg. com. res. 2:     %i, %i, %i\n\n",idstr2[0],idstr2[1],idstr2[2]);
  #endif
  disppointer((void **) &com); disppointer((void **) &idstr);
  disppointer((void **) &com1); disppointer((void **) &idstr1);
  disppointer((void **) &com2); disppointer((void **) &idstr2);
  disppointer((void **) &aux1); disppointer((void **) &aux2);
  disppointer((void **) &aux3);
#elif defined (WNDOWS)
  compname=getenv("COMPUTERNAME");
  procid=getenv("PROCESSOR_IDENTIFIER");
  procrev=getenv("PROCESSOR_REVISION");
  windir=getenv("WINDIR");
  if (sysdrive==NULL && windir!=NULL)
    if (strlen(windir)>=2)
      sysdrive=stringncopy(windir,2);
  if (stringlength(sysdrive)<1)
    sysdrive=stringcopy(getenv("SYSTEMDRIVE"));
  if (stringlength(sysdrive)<1)
    sysdrive=stringcopy("C:");
  com=multstringcatn(2,"vol ",sysdrive);
  idstr=systemresstr(com);
  ret=multstringcatn(10,compname,sep,procid,sep,procrev,sep,
      idstr,sep,sysdrive,sep,sep);
  #if PRINTINTERMEDIATERESULTS
    printf("System drive:         %s\n",sysdrive);
    printf("Windows directory:    %s\n",windir);
    printf("Computer name:        %s\n",compname);
    printf("Processor:            %s\n",procid);
    printf("Proc. revision:       %s\n",procrev);
    printf("Command:              %s\n",com);
    printf("Command result:       %s\n",idstr);
    printf("Beg. com. res.:       %i, %i, %i, ..., %i, %i\n",
      idstr[0],idstr[1],idstr[2],idstr[strlen(idstr)-2],idstr[strlen(idstr)-1]);
  #endif
  disppointer((void **) &sysdrive);
  disppointer((void **) &com);
  disppointer((void **) &idstr);
#else /* not UNIX or WNDOWS */
  compname=getenv("HOSTNAME");
  if (compname==NULL)
    compname=getenv("HOST");
  if (stringlength(compname)<1)
    compname=aux1=systemresstr("hostname");
  machine=getenv("HOSTTYPE");
  if (stringlength(machine)<1)
    machine=getenv("PROCESSOR_IDENTIFIER");
  if (stringlength(machine)<1)
    machine=aux2=systemresstr("echo -n $HOSTTYPE");
  os=getenv("MACHTYPE");
  if (stringlength(os)<1)
    os=getenv("PROCESSOR_REVISION");
  if (stringlength(os)<1)
    os=aux3=systemresstr("echo -n $MACHTYPE");
  com=multstringcatn(2,"una","me -m");
  com1=multstringcatn(2,"una","me -n");
  com2=multstringcatn(2,"una","me -i");
  idstr=systemresstr(com);
  idstr1=systemresstr(com1);
  idstr2=systemresstr(com2);
  if (stringlength(idstr2)<2)
  {
    disppointer((void **) &com2); disppointer((void **) &idstr2);
    com2=multstringcatn(2,"una","me -s");
    idstr2=systemresstr(com2);
  }
  ret=multstringcatn(12,compname,sep,machine,sep,os,sep,
      idstr,sep,idstr1,sep,idstr2,sep,sep);
  
  #if PRINTINTERMEDIATERESULTS
    printf("Computer name:        %s\n",compname);
    printf("Machine:              %s\n",machine);
    printf("Op. system:           %s\n",os);
    printf("Command:              %s\n",com);
    printf("Command result:       %s\n",idstr);
    printf("Command 1:            %s\n",com1);
    printf("Command result 1:     %s\n",idstr1);
    printf("Command 2:            %s\n",com2);
    printf("Command result 2:     %s\n",idstr2);
    printf("Beg. com. res.:       %i, %i, %i, ..., %i, %i\n",
      idstr[0],idstr[1],idstr[2],idstr[strlen(idstr)-2],idstr[strlen(idstr)-1]);
    printf("Beg. com. res. 1:     %i, %i, %i\n",idstr1[0],idstr1[1],idstr1[2]);
    printf("Beg. com. res. 2:     %i, %i, %i\n\n",idstr2[0],idstr2[1],idstr2[2]);
  #endif
  disppointer((void **) &com); disppointer((void **) &idstr);
  disppointer((void **) &com1); disppointer((void **) &idstr1);
  disppointer((void **) &com2); disppointer((void **) &idstr2);
  disppointer((void **) &aux1); disppointer((void **) &aux2);
  disppointer((void **) &aux3);  
#endif  /* not UNIX or WNDOWS */
return ret;
}





















#ifdef IGTEST
 #include "../ct/c_z.c"
#else
 void codeblocksimp0(char *str,int length,char *key) {}
 void decodeblocksimp0(char *str,int length,char *key) {}
 void codeblocksimp1001(char *str,int length,char *key) {}
 void decodeblocksimp1001(char *str,int length,char *key) {}
 void codeblocksimp1002(char *str,int length,char *key) {}
 void decodeblocksimp1002(char *str,int length,char *key) {}
 void codeblocksimp100(char *str,int length,char *key) {}
 void decodeblocksimp100(char *str,int length,char *key) {}
#endif





