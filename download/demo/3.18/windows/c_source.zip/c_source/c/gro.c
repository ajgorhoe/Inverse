
#ifdef IGS    /* This belongs to the IGS! */


/*

STVARI, KI JIH BO TREBA NAREDITI!
	
	Napisati funkcijo za brisanje sestavljenih graficnih objektov.
	Napisati funkcijo za transformacijo luci.
	Narediti primer izrisa geometrije, ki je prebrana iz Elfenove vhodne
datoteke.
	Napisati osnovne funkcije za risanje grafov v 2D.
	Napisati modul za zapis in branje graficnih objektov iz datotek.
	Napisati modul za izpis v obliki, ki se lahko sprinda npr. iz Worda.

*/


#include <sysint.h>

#include <float.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <math.h>
#include <mtypes.h>
#include <er.h>
#include <mtime.h>
#include <strop.h>
#include <rf.h>
#include <st.h>
#include <fop.h>
#include <vec.h>
#include <sg_obj.h>
#include <grint.h>
#include <gro.h>


/* To insure that there are no conflicts between  IGS and SGS: */
#include <sg_draw.h>
#include <sg_ploto.h>
#include <sg_obj.h>




/*

           VRSTE GRAFICNIH PRIMITIVOV

identifikac. znak:  |     vrsta:
  i1  |  i2  |  i3  |     opis
------+------+------+----------------------
  t   |  0   |  0   |  navaden tekst
  l   |  0   |  0   |  navadna crta
  3   |  0   |  0   |  trikotnik iz crt
  3   |  f   |  0   |  zapolnjem trikotnik
  3   |  b   |  0   |  zapolnjem obrobljen trikotnik
  3   |  p   |  0   |  zapolnjem delno obrobljen trikotnik
  4   |  0   |  0   |  stirikotnik iz crt
  4   |  f   |  0   |  zapolnjem stirikotnik
  4   |  b   |  0   |  zapolnjem obrobljen stirikotnik
  4   |  p   |  0   |  zapolnjem delno obrobljen stirikotnik
  m   |  0   |  0   |  marker (za oznacevanje tock)


Kaj predstavljajo kazalci props1, props2, props3 in props4, ce so definirani:

identifikac. znak:  |    pomen kazalcev props1, props2, props3 in props4
  i1  |  i2  |  i3  |          / (tip kazalcev)
------+------+------+-----------------------------------------------------
  t   |  0   |  0   |  1: Tekstovni niz (char *)
                       2: Nastavitve za tekst (gotextsettings)
  l   |  0   |  0   |  1: Nastavitve za linije (golinesettings)
  3   |  0   |  0   |  1: Nastavitve za linije (golinesettings)
  3   |  f   |  0   |  1: Nastavitve za ploskve (gofillsettings)
  3   |  b   |  0   |  1: Nastavitve za ploskve (gofillsettings)
                       2: Nastavitve za linije (golinesettings)
  3   |  p   |  0   |  1: Nastavitve za ploskve (gofillsettings)
                       2: Nastavitve za linije (golinesettings)
                       3: Zastavice za aktivne robove (char[3])
  4   |  0   |  0   |  1: Nastavitve za linije (golinesettings)
  4   |  f   |  0   |  1: Nastavitve za ploskve (gofillsettings)
  4   |  b   |  0   |  1: Nastavitve za ploskve (gofillsettings)
                       2: Nastavitve za linije (golinesettings)
  4   |  p   |  0   |  1: Nastavitve za ploskve (gofillsettings)
                       2: Nastavitve za linije (golinesettings)
                       3: Zastavice za aktivne robove (char[3])
  m   |  0   |  0   |  1: Nastavitve za ploskve
                       2: Nastavitve za linije
                       3: Velikost (double[1])
                       4: Vrsta (int[1])
  a   |  *   |  *   |  1: Nastavitve za ploskve
                       2: Nastavitve za linije
                       3: Velikost (double[1])
                       4: Tangens kota (double[1])
                          Opomba: i2 in i3 povesta, ali risemo linije in
                          zapolnjen trikotnik, i4 pa pove, ce je velikost glave
                          relativna glede na solzino puscice ali velikost okna.
  a   | i2='0', 0      Pri glavi se NE izrise trikonik ali puscica iz crt
  a   | i2='t', 'T'    Pri glavi se izrise trikonik iz crt
  a   | i2='1',1       Pri glavi se izrise puscica iz crt
  a   | i3='0', 0      Pri glavi se NE izrise zapolnjen trikotnik
  a   | i3='1', 1      Pri glavi se izrise zapolnjen trikotnik
  a   | i3='r', 'R'    Velikost glave je relativna glede na dolzino puscice
  a   | i3=ostalo      Velikost glave je relativna glede na visino okna



OPOMBA - dodatno pravilo pri povezovanju graficnih objektov:
	Primitivi, ki so na skladu (...)->before ali (...)->after nekega
	graficnega primitiva xxx (to avtomatsko pomeni, da morajo biti nalozeni
	se nekam drugam, ker se pri brisanju primitiva ti primitivi ne brisejo),
	so lahko nalozeni le na sklad (...)->extraprimitives skupine, ki vsebuje
	doticni graficni primitiv xxx, ali na isti sklad katere od njenih
	podskupin (skupin, ki so na skladu (...)->groups te skupine).


*/




/*

typedef struct {
        double minx,
               maxx,
               miny,
               maxy,
               minz,
               maxz;
        } _fr3d;

typedef _fr3d *fr3d;

typedef struct {
        double minx,
               maxx,
               miny,
               maxy;
        } _fr2d;

typedef _fr2d *fr2d;


typedef struct  {
        double x1,y1,z1,x2,y2,z2,x3,y3,z3,x4,y4,z4,
               avdist;
        int id;
        } _surfacepiece;

typedef _surfacepiece *surfacepiece;

*/






           /****************************************************/
           /*   FUNKCIJE ZA IZRIS TRIDIMENZIONALNIH OBJEKTOV   */
           /****************************************************/



/* RISANJE RAZLICNIH VRST GRAFICNIH PRIMITIVOV */




/* Spremenljivke, kii se uporabijo pri shranjevanju okenskih koordinat: */
static _coord3d wp1,wp2,wp3,wp4;


static void setlinesettings(golinesettings ls)
       /* Nastavi parametre pri risanju crt, kot je doloceno z ls. */
{
gisetlinecolor(ls->color.red,ls->color.green,ls->color.blue);
gisetlinewidth(ls->linewidth);
gisetlinetype(ls->linetype);
}


static void setfillsettings(gofillsettings fs)
       /* Nastavi parametre pri risanju zapolnjenih likov, kot je doloceno z ls. */
{
gisetfillcolor(fs->color.red,fs->color.green,fs->color.blue);
}


static void settextsettings(gotextsettings ts)
       /* Nastavi parametre pri risanju te, kot je doloceno z ls. */
{
gisettextcolor(ts->color.red,ts->color.green,ts->color.blue);
gisettextfont(ts->font);
gisettextheight((float) ts->height);
gisettextspacing((float) ts->spacing);
gisettextexpansion((float) ts->expansion);
gisettextxalignment(ts->xalignment);
gisettextyalignment(ts->yalignment);
}



static void gpdrawline(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja crto ('l','0','0')
       $A Igor <== apr97; */
{
char nottransf=0;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>1)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>1)
    {
      p1=gp->coord->s[1];
      p2=gp->coord->s[2];
    }
if (p1!=NULL && p2!=NULL)
{
  gg=gp->grp;
  ls=(golinesettings) gp->props1;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      gisetlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  griline((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y);
}
}



static void gpdrawtriangle(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja trikotnik iz crt
       ('3','0','0')
       $A Igor <== apr97; */
{
char nottransf=0;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>2)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>2)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL)
{
  gg=gp->grp;
  ls=(golinesettings) gp->props1;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      gisetlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  gritriangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
}
}



static void gpdrawfilltriangle(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja pobarvan trikotnik
       ('3','f','0')
       $A Igor <== apr97; */
{
char nottransf=0;
gofillsettings fs=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>2)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>2)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      gisetfillcolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  grifilltriangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
}
}



static void gpdrawbordtriangle(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja pobarvan obrobljen trikotnik
       ('3','b','0')
       $A Igor <== apr97; */
{
char nottransf=0;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>2)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>2)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      gisetfillcolor(color.red,color.green,color.blue);
    }
  }
  ls=(golinesettings) gp->props2;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      gisetlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  grifilltriangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
  gritriangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
}
}




static void gpdrawpartbordtriangle(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja pobarvan delno obrobljen
       trikotnik ('3','p','0'). Ce je vsaj ena stranica trikotnika obrobljena s
       crto, je gp->props3 kazalec na niz 3 znakov. Obrobljene so stranice, za
       katere so ustrezni znako razlicni od '\0'. gp->props3[0] ustreza stranici
       med 1. in 2. koordinato itd.
       $A Igor <== apr97; */
{
char nottransf=0;
char *flags=NULL;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>2)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>2)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      gisetfillcolor(color.red,color.green,color.blue);
    }
  }
  if (gp->props3!=NULL)
  {
    /* Priprava z risanje crt */
    ls=(golinesettings) gp->props2;
    if (ls==NULL)
      if (gg!=NULL)
        ls=gg->ls1;
    if (ls!=NULL)
    {
      setlinesettings(ls);
      if (sg_dolighting)
      {
        _truecolor color={0,0,0};
        if (gp->transfcoord!=NULL && sg_drawtransf)
          calclightintensity(gp->transfcoord,&(ls->color),&color);
        else if (gp->coord!=NULL)
          calclightintensity(gp->transfcoord,&(ls->color),&color);
        gisetlinecolor(color.red,color.green,color.blue);
      }
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  grifilltriangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
  if (gp->props3!=NULL)
  {
    flags=gp->props3;
    if (flags[0])
      griline((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y);
    if (flags[1])
      griline((float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
    if (flags[2])
      griline((float) wp3.x,(float) wp3.y,(float) wp1.x,(float) wp1.y);
  }
}
}





static void gpdrawfourangle(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja stirikotnik iz crt
       ('4','0','0')
       $A Igor <== apr97; */
{
char nottransf=0;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL,p4=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>3)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
    p4=gp->transfcoord->s[4];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>3)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
        p4=gp->coord->s[4];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL&& p4!=NULL)
{
  gg=gp->grp;
  ls=(golinesettings) gp->props1;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      gisetlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  gpwindowcoord(p4,&wp4);
  grifourangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
}
}


static void gpdrawfillfourangle(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja zapolnjen stirikotnik
       ('4','f','0')
       $A Igor <== apr97; */
{
char nottransf=0;
gofillsettings fs=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL,p4=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>3)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
    p4=gp->transfcoord->s[4];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>3)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
        p4=gp->coord->s[4];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL&& p4!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      gisetfillcolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  gpwindowcoord(p4,&wp4);
  grifillfourangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
}
}


static void gpdrawbordfourangle(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja obrobljen zapolnjen
       stirikotnik ('4','b','0')
       $A Igor <== apr97; */
{
char nottransf=0;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL,p4=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>3)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
    p4=gp->transfcoord->s[4];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>3)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
        p4=gp->coord->s[4];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL&& p4!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      gisetfillcolor(color.red,color.green,color.blue);
    }
  }
  ls=(golinesettings) gp->props2;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      gisetlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  gpwindowcoord(p4,&wp4);
  grifillfourangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
  grifourangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
}
}





static void gpdrawpartbordfourangle(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja delno obrobljen zapolnjen
       stirikotnik ('4','p','0'). Ce je vsaj ena stranica stirikotnika obroblje-
       na, je gp->props3 kazalec na niz 4 znakov. Obrobljene so stranice, za
       katere so ustrezni znako razlicni od '\0'. gp->props3[0] ustreza stranici
       med 1. in 2. koordinato itd.
       $A Igor <== apr97; */
{
char nottransf=0;
char *flags=NULL;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL,p3=NULL,p4=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>3)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
    p3=gp->transfcoord->s[3];
    p4=gp->transfcoord->s[4];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>3)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
        p3=gp->coord->s[3];
        p4=gp->coord->s[4];
      }
if (p1!=NULL && p2!=NULL && p3!=NULL&& p4!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      gisetfillcolor(color.red,color.green,color.blue);
    }
  }
  if (gp->props3!=NULL)
  {
    /* Priprava z risanje crt */
    ls=(golinesettings) gp->props2;
    if (ls==NULL)
      if (gg!=NULL)
        ls=gg->ls1;
    if (ls!=NULL)
    {
      setlinesettings(ls);
      if (sg_dolighting)
      {
        _truecolor color={0,0,0};
        if (gp->transfcoord!=NULL && sg_drawtransf)
          calclightintensity(gp->transfcoord,&(ls->color),&color);
        else if (gp->coord!=NULL)
          calclightintensity(gp->transfcoord,&(ls->color),&color);
        gisetlinecolor(color.red,color.green,color.blue);
      }
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  gpwindowcoord(p3,&wp3);
  gpwindowcoord(p4,&wp4);
  grifillfourangle((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
  if (gp->props3!=NULL)
  {
    flags=gp->props3;
    if (flags[0])
      griline((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y);
    if (flags[1])
      griline((float) wp2.x,(float) wp2.y,(float) wp3.x,(float) wp3.y);
    if (flags[2])
      griline((float) wp3.x,(float) wp3.y,(float) wp4.x,(float) wp4.y);
    if (flags[3])
      griline((float) wp4.x,(float) wp4.y,(float) wp1.x,(float) wp1.y);
  }
}
}




static void gpdrawmarker(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja marker ('m','0','0')
       $A Igor <== apr97; */
{
char nottransf=0;
double *psize=NULL,size;
int *pkind=NULL,kind;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>0)
  {
    p1=gp->transfcoord->s[1];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>0)
      {
        p1=gp->coord->s[1];
      }
if (p1!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      gisetfillcolor(color.red,color.green,color.blue);
    }
  }
  /* Priprava z risanje crt */
  ls=(golinesettings) gp->props2;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      gisetlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  psize=gp->props3;
  pkind=gp->props4;
  if (psize!=NULL)
    size=*psize;
  else
    size=0.025;
  if (pkind!=NULL)
    kind=*pkind;
  else
    kind=1;
  grimarker((float) wp1.x,(float) wp1.y,(float) size,kind);
}
}



static void gpdrawarrow(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja puscico ('a','...','...')
       $A Igor  maj01; */
{
char nottransf=0;
double *psize=NULL,size,*pangle=NULL,angle;
gofillsettings fs=NULL;
golinesettings ls=NULL;
gogroup gg;
coord3d p1=NULL,p2=NULL;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>0)
  {
    p1=gp->transfcoord->s[1];
    p2=gp->transfcoord->s[2];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>0)
      {
        p1=gp->coord->s[1];
        p2=gp->coord->s[2];
      }
if (p1!=NULL && p2!=NULL)
{
  gg=gp->grp;
  fs=(gofillsettings) gp->props1;
  if (fs==NULL)
    if (gg!=NULL)
      fs=gg->fs1;
  if (fs!=NULL)
  {
    setfillsettings(fs);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(fs->color),&color);
      gisetfillcolor(color.red,color.green,color.blue);
    }
  }
  /* Priprava z risanje crt */
  ls=(golinesettings) gp->props2;
  if (ls==NULL)
    if (gg!=NULL)
      ls=gg->ls1;
  if (ls!=NULL)
  {
    setlinesettings(ls);
    if (sg_dolighting)
    {
      _truecolor color={0,0,0};
      if (gp->transfcoord!=NULL && sg_drawtransf)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      else if (gp->coord!=NULL)
        calclightintensity(gp->transfcoord,&(ls->color),&color);
      gisetlinecolor(color.red,color.green,color.blue);
    }
  }
  gpwindowcoord(p1,&wp1);
  gpwindowcoord(p2,&wp2);
  psize=(double *)gp->props3;
  if (psize!=NULL)
    size=*psize;
  else
    size=0.05;
  pangle=(double *) gp->props4;
  if (pangle!=NULL)
    angle=*pangle;
  else
    angle=0.2;
  griarrow((float) wp1.x,(float) wp1.y,(float) wp2.x,(float) wp2.y,(float) size,(float) angle,gp->i2,gp->i3,gp->i4);
}
}





static void gpdrawtext(goprimitive gp)
       /* Izrise graficni primitiv, ki predstavlja mavaden tekst
       ('t','0','0')
       $A Igor <== apr97; */
{
char nottransf=0;
gotextsettings ts=NULL;
gogroup gg;
coord3d p1;
if (gp->transfcoord!=NULL && sg_drawtransf)
{
  if (gp->transfcoord->n>0)
  {
    p1=gp->transfcoord->s[1];
  } else nottransf=1;
} else nottransf=1;
if (nottransf)
  if (gp->coord!=NULL)
    if (gp->coord->n>0)
    {
      p1=gp->coord->s[1];
    }
if (p1!=NULL)
{
  gg=gp->grp;
  ts=(gotextsettings) gp->props2;
  if (ts==NULL)
    if (gg!=NULL)
      ts=gg->ts1;
  if (ts!=NULL)
    settextsettings((gotextsettings) ts);
  gpwindowcoord(p1,&wp1);
  if (gp->props1!=NULL)
    gritext((char *) gp->props1,(float) wp1.x,(float) wp1.y);
}
}



/* Funkcije, ki se v funkciji za izris graficnega primitiva uporabijo za izrise
razlicnih vrst graficnih primitivov: */
/*
static void (* gpdrawline) (goprimitive gp)=basgpline;
static void (* gpdrawtriangle) (goprimitive gp)=basgptriangle;
static void (* gpdrawfilltriangle) (goprimitive gp)=basgpfilltriangle;
static void (* gpdrawbordtriangle) (goprimitive gp)=basgpbordtriangle;
static void (* gpdrawpartbordtriangle) (goprimitive gp)=basgppartbordtriangle;
static void (* gpdrawfourangle) (goprimitive gp)=basgpfourangle;
static void (* gpdrawfillfourangle) (goprimitive gp)=basgpfillfourangle;
static void (* gpdrawbordfourangle) (goprimitive gp)=basgpbordfourangle;
static void (* gpdrawpartbordfourangle) (goprimitive gp)=basgppartbordfourangle;
static void (* gpdrawmarker) (goprimitive gp)=basgpmarker;
static void (* gpdrawarrow) (goprimitive gp)=basgparrow;
static void (* gpdrawtext) (goprimitive gp)=basgptext;
*/




void godrawprimitive(goprimitive gp)
     /* Izrise graficni primitiv gp. */
{
int i;
if (gp!=NULL)
{
  if (gp->before!=NULL)
    if (gp->before->n!=0)
      for (i=1;i<=gp->before->n;++i)
        godrawprimitive(gp->before->s[i]);
  if (gp->i1=='l')
  {
    if (gp->i2=='0')
    {
      if (gp->i3=='0')
        gpdrawline(gp); /* Navadna crta */
    }
  } else if (gp->i1=='3')
  {
    if (gp->i2=='p')
    {
      if (gp->i3=='0')
        gpdrawpartbordtriangle(gp); /* Delno obrobljen zapolnjen trikotnik */
    } else if (gp->i2=='0')
    {
      if (gp->i3=='0')
        gpdrawtriangle(gp); /* Trikotnik iz crt */
    } else if (gp->i2=='f')
    {
      if (gp->i3=='0')
        gpdrawfilltriangle(gp); /* Zapolnjen trikotnik iz crt */
    } else if (gp->i2=='b')
    {
      if (gp->i3=='0')
        gpdrawbordtriangle(gp); /* Obrobljen trikotnik iz crt */
    }
  } else if (gp->i1=='4')
  {
    if (gp->i2=='p')
    {
      if (gp->i3=='0')
        gpdrawpartbordfourangle(gp); /* Delno obrobljen zapolnjen stirikotnik */
    } else if (gp->i2=='0')
    {
      if (gp->i3=='0')
        gpdrawfourangle(gp); /* Stirikotnik iz crt */
    } else if (gp->i2=='f')
    {
      if (gp->i3=='0')
        gpdrawfillfourangle(gp); /* Zapolnjen stirikotnik iz crt */
    } else if (gp->i2=='b')
    {
      if (gp->i3=='0')
        gpdrawbordfourangle(gp); /* Obrobljen stirikotnik iz crt */
    }
  } else if (gp->i1=='m')
  {
    if (gp->i2=='0')
    {
      if (gp->i3=='0')
        gpdrawmarker(gp); /* Marker (za risanje tock) */
    }
  } else if (gp->i1=='a')
  {
    gpdrawarrow(gp); /* Puscica */
  } else if (gp->i1=='t')
  {
    if (gp->i2=='0')
    {
      if (gp->i3=='0')
        gpdrawtext(gp); /* Tekst */
    }
  }
  if (gp->after!=NULL)
    if (gp->after->n!=0)
      for (i=1;i<=gp->after->n;++i)
        godrawprimitive(gp->after->s[i]);
}
}


static void godrawstack0(stack st)
{
    int i;
    if (st!=NULL)
      if (st->n>0)
        for (i=1;i<=st->n;++i)
          godrawprimitive( (goprimitive) st->s[i]);
}

void godrawstack(stack st)
     /* Izrise sklad, na katerega so nalozeni graficni primetivi. */
{
#ifdef GRITK
  int godrawstackitk(stack st);
  static int runplain=0;
  /* Call godrawstackitk(), which launches an ITK plotting procedure 
  itk_igs_plot, which calls this function again, and this function then draws
  the complete stack st at once in the  ITK int. thread; If this function
  was called from godrawstackitk(), then that function returns 0 indicating
  that the stack needs to be drawn now (the function counts its level of
  recursion). Otherwise, godrawstackitk() runs this function and returns 0. */
  if (!godrawstackitk(st))
    godrawstack0(st);
  /*
  if (!runplain)
  {
    godrawstackitk(st);
    ++runplain;
  } else
  {
    godrawstack0(st);
    --runplain;
  }
  */
# else
  godrawstack0(st);
#endif
}


void gotclscreendrawstackautosize(stack st);
static int ntcl=0;
static double t=0,t1;

void godrawstackscreen(stack st)
    /* Izrise sklad, na katerega so nalozeni graficni primetivi. Deluje
    podobno kot godrawstack(), le da je funkcija namenjena le za risanje
    na zaslon in ne tudi v datoteke, poleg tega pa vedno poskusa najti nacin
    za izris - ce v sistem niso povezane graficne knjiznice, izris izvede
    z izrisom v Tcl-ovo datoteko in interpretacijo z lupino wish.
    $A Igor maj01; */
{
#ifdef GRTCL
  /* Prepreciti moramo, da bi se tcl-ova okna odpirala prehirto: */
  if (t==0)
    t=absolutetime();
  else
  {
    ++ntcl;
    t1=absolutetime();
    t1-=t;  /* t1 postane cas v sekundah od zadnjega reseta */
    if (ntcl>=10 && t1/ntcl<2.0)  /* v povprecju manj kot 2s med dvema oknoma */
      sleep(2);
    else if (ntcl>=8 && t1/ntcl<1)
      sleep(1);
    else if (ntcl>=4 && t1/ntcl<0.8)
      sleep(1);
    else if (ntcl>=2 && t1/ntcl<0.3)
      sleep(1);
    if (ntcl>8 && (t1-4)/ntcl>2)
    {
      /* Okna se ne odpirajo prehitro, resetiramo spremenljivke. */
      t=absolutetime();
      ntcl=0;
    }
  }
  gotclscreendrawstackautosize(st);
#else
  godrawstack(st);
#endif
}

void gosetdrawtransf(char dt)
    /* Funkcija nastavi vrednost lokalne spremenljivke sg_drawtransf, ki
    kontrolira, ali se izrisejo graficni objekti v originalnih koordinatah (ce
    je vrednost spremenljivke 0) ali transformiranih (ce je razlicna od 0). */
{
sg_drawtransf=dt;
}







     /***************************************************/
     /*     FUNKCIJE ZA IZRIS V RAZLICNIH FORMATIH:     */
     /***************************************************/



void gopsfdrawstack(FILE *fp,stack st)
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko fp v formatu PostScript. 
     $A Igor apr97; */
{
if (fp!=NULL)
{
  grisavefunc();
  setgrintps(fp);
  griprinthead();
  godrawstack(st);
  griprinttail();
  grirestorefunc();
}
}


void gopsfiledrawstack(char *name,stack st)
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko z imenom name v formatu PostScript. Ce datoteka ze obstaja,
     se prepise. 
     $A Igor apr97; */
{
FILE *fp;
fp=fopen(name,"wb");
if (fp!=NULL)
{
  gopsfdrawstack(fp,st);
  fclose(fp);
  fp=NULL;
} else
{
  errfunc0("gopsfiledrawstack");
  fprintf(erf(),"Can not open file \"%s\".\n",name);
  errfunc2();
}
}




void gotclfdrawstack(FILE *fp,stack st)
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko fp v formatu Tcl. 
     $A Igor apr97; */
{
if (fp!=NULL)
{
  grisavefunc();
  setgrinttcl(fp);
  griprinthead();
  godrawstack(st);
  griprinttail();
  grirestorefunc();
}
}


void gotclfiledrawstack(char *name,stack st)
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko z imenom name v formatu Tcl. Ce datoteka ze obstaja,
     se prepise. 
     $A Igor apr97; */
{
FILE *fp;
fp=fopen(name,"wb");
if (fp!=NULL)
{
  gotclfdrawstack(fp,st);
  fclose(fp);
  fp=NULL;
} else
{
  errfunc0("gotclfiledrawstack");
  fprintf(erf(),"Can not open file \"%s\".\n",name);
  errfunc2();
}
}


static char *wishshell=NULL;
static char *tempname=NULL;

void gotclscreendrawstack(stack st,int width,int height)
    /* Izrise objekte na skladu st s pomocjo Tcl-a in interpreterja wish.
    width in height sta sirina in visina okna, v katerem se grafika izrise;
    ce sta 0, se vzameta ze nastavljeni meri.
    $A Igor maj01; */
{
int retry=1;
char *str=NULL,*str1=NULL;
if (wishshell==NULL)
{
  /* Ce ni nastavljena lokacija interpreterja wish, se nastavijo default lok.: */
  #ifdef UNIX
    wishshell=stringcopy("/usr/bin/wish");
  #else
    #ifdef WNDOWS
      /*
      wishshell=stringcopy("\"C:\\Program Files\\Tcl\\bin\\wish80.exe\"");
      */
      wishshell=stringcopy("C:\\wish.bat");
    #else
      wishshell=stringcopy("wish80");
    #endif
  #endif
}
/* Preverimo, ce obstaja datoteka na domnevni lokaciji wishove lupine; Ce ne
obstaja, zahtevamo od uporabnika specifikacijo lokacije: */
while(retry && !fileexists(wishshell))
{
  printf("Could not locate the wish interpreter (file \"%s\").\n",wishshell);
  printf("Try to look under other file name (0/1) "); readint(&retry);
  if (retry)
  {
    printf("\nInput the location (file name) of wish interpreter is located!\n");
    readstring(&wishshell);
  }
}
if (tempname==NULL)
  tempname=tmpnam(NULL);
tclsetwindowsize(width,height);
gotclfiledrawstack(tempname,st);
printf("\nGraph drawn to tcl file \"%s\".\n",tempname);
str1=stringcat(wishshell," ");
str=stringcat(str1,tempname);
disppointer((void *) &str1);
str1=stringcat(str," &");
system(str1);
disppointer((void *) &str1);
disppointer((void *) &str);
/*
remove(tempname);
*/
}

void gotclscreendrawstackautosize(stack st)
    /* Izrise objekte na skladu st s pomocjo Tcl-a in interpreterja wish.
    Velikost okna nastavi avtomatsko glede na trenutno sirino in visino okna
    v graficnem sistemu.
    $A Igor maj01; */
{
gotclscreendrawstack(st,gingetwindowwidth(),gingetwindowheight());
}


void godxffdrawstack(FILE *fp,stack st)
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko fp v formatu DXF. 
     $A Igor apr97; */
{
if (fp!=NULL)
{
  grisavefunc();
  setgrintdxf(fp);
  griprinthead();
  godrawstack(st);
  griprinttail();
  grirestorefunc();
}
}


void godxffiledrawstack(char *name,stack st)
     /* Sklad st, na katerega so nalozeni graficni primitivi, se izrise v
     datoteko z imenom name v formatu DXF. Ce datoteka ze obstaja,
     se prepise. 
     $A Igor apr97; */
{
FILE *fp;
fp=fopen(name,"wb");
if (fp!=NULL)
{
  godxffdrawstack(fp,st);
  fclose(fp);
  fp=NULL;
} else
{
  errfunc0("godxffiledrawstack");
  fprintf(erf(),"Can not open file \"%s\".\n",name);
  errfunc2();
}
}






   /***************************************************/
   /*   FUNKCIJE ZA PRIPRAVO ZA IZRIS V FORMATU PS   */
   /***************************************************/


/*
#include "grps.h"
*/



   /***************************************************/
   /*   FUNKCIJE ZA PRIPRAVO ZA IZRIS V FORMATU DXF   */
   /***************************************************/


/*
#include "grdxf.h"
*/


   /***************************************************/
   /*   FUNKCIJE ZA PRIPRAVO ZA IZRIS V FORMATU Tcl   */
   /***************************************************/


/*
#include "grtcl.h"
*/





   /***********************************************************************/
   /*   FUNKCIJE ZA PRIPRAVO ZA IZRIS SKUPIN TRIDIMENZIONALNIH OBJEKTOV   */
   /***********************************************************************/




static int gpcomparedp(void *p1,void *p2)
       /* Primerja graficna primitiva p1 in p2 po parametru ...->dp. Vrne -1,
       ce je p1->dp<=p2->dp, drugace pa 1. */
{
goprimitive gp1,gp2;
if (p1!=NULL && p2!=NULL)
{
  gp1=p1; gp2=p2;
  if (gp1->dp!=NULL && gp2->dp!=NULL)
  {
    if (*(gp1->dp)<=*(gp2->dp))
      return -1;
    else return 1;
  } else return 0;
} else return 0;
}


/* Funkcija z primerjavo graficnih primitivov pri sortiranju skladov, na katerih
so nalozeni graficni primitivi. Funkcija vrne -1, ce je 1. argument po danih
kriterijih manjsi od drugega, ter 1, ce je drugi argument po teh kriterijih
manjsi od prvega. */

static int (*gpcompare) (void *,void *) = gpcomparedp;











#endif /* defined (IGS) */
