/*-------------------------------------------------------------*/
/*  File: xhello.c
 *
 *  Display "Hello, World" in an X window. User can exit by
 *  pressing a mouse button in the "Exit" button.
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>



#define DEFAULTBANDWIDTH         1

static XSetWindowAttributes winat;

unsigned long tabpixels[300];



/* Default parameter values (as strings) */
char *mfont        = "fixed",
     *display_name = NULL,
     *mgeom        = NULL;


char *appname = "xhello";

/* Non-string parameters of xhello */
XFontStruct    *mfontstruct;
unsigned long  mbgpix, mfgpix, ebgpix, efgpix;

/* Size and location of the Exit button */
unsigned int ewidth, eheight;
int          ex, ey, extxt, eytxt;

/* Other global variables */

XWMHints      *pxwmh;     /* Hints for the window manager  */
XSizeHints    *pxsh;      /* Size hints for window manager */
XClassHint    *pch;       /* Class hint for window manager */
XTextProperty wname;       /* Window name for title bar     */
XTextProperty iname;       /* Icon name for icon label      */
Display       *display;     /* Connection to X display       */
Window        window=0,w1=0,w2=0;  /* Window ID of the two windows  */
GC            gc;       /* The graphics context for main */
XEvent        theEvent;    /* Structure for current event   */
int           Done = 0;    /* Flag to indicate when done    */
char          default_geometry[80];

char *window_title = "Hello";
void usage();


static void printvisualinfo(XVisualInfo *visual)
{
printf("\n");
printf("ID: %i\n",visual->visualid);
printf("Screen: %i\n",visual->screen);
printf("Depth: %i\n",visual->depth);
printf("Class: %i\n",visual->class);
printf("Redmask: %i\n",visual->red_mask);
printf("Greenmask: %i\n",visual->green_mask);
printf("Bluemask: %i\n",visual->blue_mask);
printf("Colormap size: %i\n",visual->colormap_size);
printf("Bits per RGB: %i\n",visual->bits_per_rgb);
}


static int numcol,factcol,maxcol;
static int maxcolor=65535;

unsigned short calccolor(float color)
{
int discretecolor;
discretecolor=(int)(color*numcol);
discretecolor*=factcol;
if (discretecolor<0)
  discretecolor=0;
else if (discretecolor>maxcolor)
  discretecolor=maxcolor;
return (unsigned short) discretecolor;
}





/*********** FUNKCIJE ZA RAVNANJE Z BARVAMI: ************/

/* Ta del zajema funkcije za inicializacijo (vzpostavitev zelenega nacina
ravnanja z barvami) in funkcije za pretvorbo barv v celice X serverja */

/* SPLOSNE SPREMENLJIVKE: */

static Colormap colormap;

/* OSNOVNE KONSTANTE: */

static unsigned int MAXSHADES=65536; /* Strojna meja stevila odtenkov */



/* UPORABNIKOVA NAVODILA ZA DELO Z BARVAMI: */

static char ucoloring=1;
/* uporaba barv (v nasprotnem primeru sivi odtenki */

static char upreindexall=0;
/* Ce je 1, se pri inicializaciji alocirajo vsi mozni pixli. */

static unsigned short unumshades=256;
/* Stevilo odtenkov barvnih komponent; 256 je dovolj za obcutek zveznega
prelivanja. Ce je 0, so barve zvezne (v tem primeru se tudi ne more uporabiti
indeksiranje). */

static int  uindexsize=1025;
/* Dolzina tabele indeksov Ce je to 0, naj se ne uporablja indeksiranje. */

static unsigned long unumprivatecells=0;
/* Stevilo celic v privatni tabeli. Ce je to 0, se ne alocira privat. tabela. */






/* SPREMENLJIVKE, KI SE UPORABLJAJO PRI PRETVORBI BARVA->PIXEL: */

static char coloring=1;

static char preindexall=0;

static int numshades=256; /* Stevilo odtenkov barvnih komponent */

static int shadefactor=256; /* MAXSHADES/numshades */

static unsigned long numdiscretecolors;
/* Stevilo vseh moznih diskretnih barv; pri sivih odtenkih je to numshades, pri
barvnih pa numshades^3. */

static int indexsize=0; /* Velikost indeksnih tabel */

static int numindeces=0;  /* Stevilo indeksov v tabeli */

static unsigned long *pixeltab=NULL;
/* Tabela pikslov, ki pripadajo ustreznim   indeksom tabele indextab */

static unsigned long *indextab=NULL;
/* Tabela indeksov, ki pripadajo ustreznim pikslom */
static unsigned long numprivatecells;

static int freecells=0;


/* STOPNJE PRI PRETVORBI BARVE V PIXEL: */

static struct {
           float red,green,blue;     /*komponente barve */
       } true;

static unsigned short ired,igreen,iblue; /* diskretni indeksi komponent */

static XColor color;  /* komponente diskretne barve in pixel; S komponentami
                      server alocira barvno celico in vrne pixel */

static unsigned long index; /* Indeks, ki enolicno doloca diskretno barvo */

static char allocated; /* Ce je 1, je bil pixel uspesno alociran. */


/* OSNOVNE FUNKCIJE PRETVORBE: */

static void indextodiscretecolor(void)
{
color.red=ired*shadefactor+ired;
color.green=igreen*shadefactor+igreen;
color.blue=iblue*shadefactor+iblue;
}

static void indextodiscretegray(void)
{
color.red=color.green=color.blue=ired*shadefactor+ired;
}

static void truetodiscretecolor(void)
    /* Komponente realne barve pretvori v diskretne komponente, ce se
    uporabljajo barve. */
{
ired=true.red*(numshades-1);
igreen=true.green*(numshades-1);
iblue=true.blue*(numshades-1);
color.red=ired*shadefactor+ired;
color.green=igreen*shadefactor+igreen;
color.blue=iblue*shadefactor+iblue;
}

static float grayintensity;
static void truetodiscretegray(void)
    /* Komponente realne barve pretvori v diskretne komponente, ce se
    uporabljajo sivi odtenki. */
{
grayintensity=(true.red+true.green+true.blue)/3;
ired=igreen=iblue=grayintensity*(numshades-1);
color.red=color.green=color.blue=ired*shadefactor+ired;
}

static void (*truetodiscrete) (void) = truetodiscretecolor;
    /* Funkcija, ki se dejansko klice pri pretvorbi realne barve v diskretne
    komponente; Po inicializaciji mora biti to naslov ene od funkcij
    truetodiscretecolor() ali truetodiscretegray(). */

static void discretetoindexcolor(void)
    /* Diskretne komponente barve enolicno pretvori v indeks (identifikacijsko
    stevilko) barve v primeru, ko se uporabljajo barvni odtenki. Mapiranje treh
    komponent barve v indeks je odvisno od stevila odtenkov numshades. */
{
index=ired+igreen*(numshades)*numshades*(numshades)*(numshades);
}

static void discretetoindexgray(void)
    /* Diskretne komponente barve enolicno pretvori v indeks (identifikacijsko
    stevilko) barve v primeru, ko se uporabljajo sivi odtenki. Mapiranje je
    odvisno od stevila odtenkov numshades. */
{
index=ired;
}

static void (*discretetoindex) (void) = discretetoindexcolor;
   /* Funkcija, ki se dejansko uporabi pri pretvorbi diskretnih komponent v
   indeks. Po inicializaciji je to naslov ene od funkcij discretetoindexcolor()
   in discretetoindexgray(). */

static void directtopixel(void)
    /* Komponente diskretne barve pretvori v pixel */
{
/*
printf("RGB=(%i,%i,%i)\n",color.red,color.green,color.blue);
*/
allocated=1;
if (XAllocColor(display,colormap,&color)==0)
{
  printf("X: Can not allocate a cell for color (%i,%i,%i).\n",color.red,color.green,color.blue);
  color.pixel=BlackPixel(display,DefaultScreen(display));
  allocated=0;
}
}

static char indexfound;
static unsigned long indexplace;
static unsigned long *pointindex;

static int compareindeces(const void *p1,const void*p2)
{
if (*(long*)p1<*(long*)p2)
  return -1;
else if (*(long*)p1==*(long*)p2)
  return 0;
else
  return 1;
}

static void findindex(void)
{
if (indextab!=NULL)
{
  if (numindeces==numdiscretecolors) /* Tabela indeksov pokriva vse barve */
  {
    indexplace=index;
    indexfound=1;
  } else
  {
    /*
    pointindex=bsearch(indextab,&index,
                        numindeces,sizeof(*indextab),compareindeces);
    if (pointindex==NULL)
      indexfound=0;
    else
    {
      indexfound=1;
      indexplace=pointindex-indextab;
    }
    */
    indexplace=0;
    while(indextab[indexplace]!=index && indexplace<numindeces)
      ++indexplace;
    if (indexplace<numindeces)
      indexfound=1;
    else
      indexfound=0;
  }
}
}


/*
static void freepixels(void)
{
if (numindeces>0 && pixeltab!=NULL)
{
  if (freecells>numindeces)
    freecells=numindeces/2;
  if (freecells>0)
  {
    XFreeColors(display,colormap,
     &(pixeltab[numindeces-freecells-10]) ,freecells,0);
    printf("FREEEEEEEEEING COLORS.\n");
  }
}
}
*/



static void freepixels(void)
{
int numcleared=0;
unsigned long clearedindex=indexsize+1;
int place,i;

unsigned long blackpixel,whitepixel;
blackpixel=BlackPixel(display,DefaultScreen(display));
whitepixel=WhitePixel(display,DefaultScreen(display));

if (numindeces>0 && pixeltab!=NULL)
{
  if (freecells>numindeces)
    freecells=numindeces/2;
  if (freecells>0)
  {
    place=0;
    numcleared=0;
    while (place<numindeces && numcleared<freecells)
    {
      if (pixeltab[place]!=blackpixel && pixeltab[place]!=whitepixel)
      {
        printf("FREING COLOR PIXEL no. %i (index %i):\n",pixeltab[place],indextab[place]);
        XFreeColors(display,colormap,&(pixeltab[place]),1,0);
        ++numcleared;
        indextab[place]=clearedindex;
      }
      ++place;
    }
    /* Treba je se zapolniti luknje v tabeli indeksov in pixlov: */
    place=0;
    for (i=0;i<numindeces;++i)
    {
      if (indextab[i]!=clearedindex)
      {
        indextab[place]=indextab[i];
        pixeltab[place]=pixeltab[i];
        ++place;
      } else
        --numindeces;
    }

  }
}
}




static void markindex(void)
{
long i,j;

if (freecells>0 && numindeces>=indexsize)
  freepixels();
if (indexsize>numindeces && indextab!=NULL && pixeltab!=NULL)
/* Ce je v indeksni tabeli se prostor, postavimo indeks na svoje mesto */
{
  i=-1;
  /* Najde se 1. element tabele, ki ni manjsi od index: */
  do
  {
    ++i;
  } while (indextab[i]<index && i<numindeces);
  /* index bo zavzel mesto tega elementa, zato je treba vse elemente od tega
  naprej premakniti za eno mesto v desno. */
  if (i<numindeces)
  {
    for (j=numindeces;j>i;--j)
    {
      indextab[j]=indextab[j-1];
      pixeltab[j]=pixeltab[j-1];
    }
  }
  indextab[i]=index;
  pixeltab[i]=color.pixel;
  ++numindeces;
}
}

/*
static int ind=0;
*/

static void indextopixel(void)
    /* Barvo pretvori v pixel, pri cemer najprej poskusi z iskanjem indeksov po
    tabeli indextab. Ce indeks barve v tej tabeli ne obstaja, najde pixel z
    direktno pretvorbo iz diskretne barve prek alokacije celice s serverjem */
{
/*
if (ind>130)
{
  ind=ind+1;
  --ind;
}
printf(".");
*/
findindex();
/*
if (!indexfound)
{
  ++ind;
  printf(" %i ",ind);
}
*/
if (indexfound)
{
  color.pixel=pixeltab[indexplace];
} else
{
  directtopixel();
  /*
  if (allocated)
  */
  markindex();
}
}



static void calculatepixel(void)
{
if (indexsize>0)
{
  truetodiscrete();
  discretetoindex();
  indextopixel();
} else
  directtopixel();
}



static void indexallcolors(void)
{
int i;
if (coloring)
{
  for (ired=0;ired<numshades;++ired)
    for (igreen=0;igreen<numshades;++igreen)
      for (iblue=0;iblue<numshades;++iblue)
      {
        indextodiscretecolor();
        discretetoindexcolor();
        directtopixel();
        if (indexsize>index)
        {
          pixeltab[index]=color.pixel;
          indextab[index]=index;
          ++numindeces;
        }
      }
} else
{
  if (indexsize>=numshades)
    for (i=0;i<numshades;++i)
    {
      ired=igreen=iblue=i;
      indextodiscretegray();
      discretetoindexgray();
      directtopixel();
      pixeltab[index]=color.pixel;
      indextab[index]=index;
      ++numindeces;
    }
}
}


static void initcolorhandling(void)
{
coloring=ucoloring;
numshades=unumshades;
if (numshades<0)
  numshades=0;
if (numshades==1)
  numshades=2;
indexsize=uindexsize;
if (indexsize<0)
  indexsize=0;
numprivatecells=unumprivatecells;
if (numprivatecells<0)
  numprivatecells=0;
/* Ce ni mapiranja v diskretne barve, tudi indeksiranja ne more biti: */
if (numshades==0)
  indexsize=0;
shadefactor=MAXSHADES/numshades;
if (coloring && numshades>0)
  numdiscretecolors=numshades*numshades*numshades;
else
  numdiscretecolors=numshades;  /* sivi odtenki */
if (numshades==0)
  numdiscretecolors=0;
numindeces=0;
if (indexsize!=0)
{
  indextab=realloc(indextab,(indexsize+1)*sizeof(*indextab));
  pixeltab=realloc(pixeltab,(indexsize+1)*sizeof(indextab));
}
if (coloring)
{
  truetodiscrete=truetodiscretecolor;
  discretetoindex=discretetoindexcolor;
} else
{
  truetodiscrete=truetodiscretegray;
  discretetoindex=discretetoindexgray;
}
if (upreindexall)
  preindexall=1;
else
  preindexall=0;
/* Vnaprejsnje indeksiranje ni mozno, ce je na razpolago manj indeksov kot je
vseh barv: */
if (indexsize<numdiscretecolors)
  preindexall=0;
if (preindexall)
  indexallcolors();
/*    Alokacija privatnih tabel:
.........


*/

}


static void printcolorhandlingstatus(void)
{
printf("IG coloring status:\n");
if (coloring)
  printf("Using RGB colors.\n");
else
  printf("Using gray scale.\n");
if (numshades==0)
  printf("Using continuous colors.\n");
else
{
  printf("Number of shades: %i\n",numshades);
  printf("Number of colors: %i\n",numdiscretecolors);
}
if (indexsize>0)
{
  printf("Size of index table: %i\n",indexsize);
  printf("Number of indeces used: %i\n",numindeces);
  if (numindeces==numdiscretecolors)
    printf("Cells for all possible colors are allocated.\n");;
} else printf ("No indexing.\n");
}




/*-------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
static char                 *tmpstr;
static int                  bitmask;
static XGCValues            gcv;
static XSetWindowAttributes xswa;

static XFontStruct *fontstruct;
static XPoint points[4];
static unsigned long bgpixel,fgpixel;


/*$$$$$$$$$$$$$$$$$$$$*/
if (1)
{



/*-------------------------------------------------------------*/
/* STEP 2:  Open connection to display */

    if ((display = XOpenDisplay(display_name)) == NULL)
    {
        fprintf(stderr, "%s: can't open display named %s\n",
                argv[0], XDisplayName(display_name));
        exit(1);
    }

/*-------------------------------------------------------------*/
/* STEP 4: Set up colors and fonts */
/*         First the fonts...      */

    if ((mfontstruct = XLoadQueryFont(display, mfont)) == NULL)
    {
        fprintf(stderr, "%s: display %s cannot load font %s\n",
                "X11", DisplayString(display), mfont);
        exit(1);
    }





/* Now select the colors using the default colormap */
    colormap = DefaultColormap(display,
                                   DefaultScreen(display));

/* Main window's background color */
color.red=30000; color.green=60000; color.blue=60000;
/* Use white background in case of failure */
    if ( /* XParseColor(display, colormap, mbgcolor,
                    &color) == 0 || */
        XAllocColor(display, colormap, &color) == 0)
        mbgpix = WhitePixel(display, DefaultScreen(display));
    else
        mbgpix = color.pixel;

color.red=0; color.green=30000; color.blue=50000;
/* Main window's foreground color */
/* Use black foreground in case of failure */
    if ( /* XParseColor(display, colormap, mfgcolor,
                    &color) == 0 || */
        XAllocColor(display, colormap, &color) == 0)
        mfgpix = BlackPixel(display, DefaultScreen(display));
    else
        mfgpix = color.pixel;










/* Exit window's background color */
/* Use white background in case of failure */
/* Exit window's foreground color */
/* Use black foreground in case of failure */
/*-------------------------------------------------------------*/
/* STEP 5: Select initial position and size of top window */
/* Allocate and fill out a XsizeHints structure to inform the
 * window manager. Here we pick a default size large enough to
 * fit the text and the Exit button.
 */





    if((pxsh = XAllocSizeHints()) == NULL)
    {
        fprintf(stderr, "Error allocating size hints!\n");
        exit(1);
    }

/*

    if(extext_cline != NULL) extext = extext_cline;
    else
        if(extext_rsrc != NULL) extext = extext_rsrc;

    if(msgtext_cline != NULL) msgtext = msgtext_cline;
    else
        if(msgtext_rsrc != NULL) msgtext = msgtext_rsrc;

    extxt = efontstruct->max_bounds.width / 2;
    eytxt = efontstruct->max_bounds.ascent +
            efontstruct->max_bounds.descent;
    ewidth = extxt + XTextWidth(efontstruct, extext,
                                strlen(extext)) + 4;
    eheight = eytxt + 4;



*/

    pxsh->flags=(PPosition | PSize | PMinSize);
    pxsh->min_width=20;
    pxsh->min_height=10;
    pxsh->width=600;
    pxsh->height=450;
    pxsh->x = 600;
    pxsh->y = 10;

if (0)
{

/* Construct a default geometry string */

    sprintf(default_geometry, "%dx%d+%d+%d", pxsh->width,
            pxsh->height, pxsh->x, pxsh->y);
    mgeom = default_geometry;


/* Process the geometry specification */

    bitmask =  XGeometry(display, DefaultScreen(display), mgeom,
                         default_geometry, DEFAULTBANDWIDTH,
                         mfontstruct->max_bounds.width,
                         mfontstruct->max_bounds.ascent +
                         mfontstruct->max_bounds.descent,
                         1, 1, &(pxsh->x), &(pxsh->y),
                         &(pxsh->width), &(pxsh->height));

/* Check bitmask and set flags in XSizeHints structure */

    if (bitmask & (XValue | YValue)) pxsh->flags |= USPosition;
    if (bitmask & (WidthValue | HeightValue))
                                     pxsh->flags |= USSize;


}

printf("BREZ GEOMETRIJSKEGA NIZA !!!!!!!!\n\n");
pxsh->flags |= USPosition;
pxsh->flags |= USSize;
/*-------------------------------------------------------------*/
/* STEP 6: Create top-level window                     */
/* Use position and size information derived above.
 * For border color, use the foreground color.
 */

    window = XCreateSimpleWindow(display, DefaultRootWindow(display),
                  pxsh->x, pxsh->y, pxsh->width, pxsh->height,
                  DEFAULTBANDWIDTH, mfgpix, mbgpix);

/*-------------------------------------------------------------*/
/* STEP 7: Set Window Manager properties (window name, icon
 * name, command-line, and size hints)
 */
    if((pch = XAllocClassHint()) == NULL)
    {
        fprintf(stderr, "Error allocating class hint!\n");
        exit(1);
    }
    pch->res_name = appname;
    pch->res_class = "XHello";

/* Set up XTextProperty for window name and icon name */
    if(XStringListToTextProperty(&window_title, 1, &wname) == 0)
    {
        fprintf(stderr, "Error creating XTextProperty!\n");
        exit(1);
    }
    if(XStringListToTextProperty(&window_title, 1, &iname) == 0)
    {
        fprintf(stderr, "Error creating XTextProperty!\n");
        exit(1);
    }

    if((pxwmh = XAllocWMHints()) == NULL)
    {
        fprintf(stderr, "Error allocating Window Manager hints!\n");
        exit(1);
    }
    pxwmh->flags = (InputHint|StateHint);
    pxwmh->input = False;
    pxwmh->initial_state = NormalState;

    /*
    XSetWMProperties(display, window, &wname, &iname, argv, argc,
                     pxsh, pxwmh, pch);
    */
    XSetWMProperties(display, window, &wname, &iname, NULL, 0,
                     pxsh, pxwmh, pch);


/*-------------------------------------------------------------*/
/* STEP 8: Create a graphics context for the Main window */

    gcv.font = mfontstruct->fid;
    gcv.foreground = mfgpix;
    gcv.background = mbgpix;
    gc = XCreateGC(display, window,
                (GCFont | GCForeground | GCBackground), &gcv);
/*-------------------------------------------------------------*/
/* STEP 9: Set window attributes (colormap, bit_gravity) */

    xswa.colormap = DefaultColormap(display,
                                    DefaultScreen(display));
    xswa.bit_gravity = CenterGravity;
    XChangeWindowAttributes(display, window, (CWColormap |
                            CWBitGravity), &xswa);
/*-------------------------------------------------------------*/
/* STEP 10: Select input events for the window window */

    XSelectInput(display, window, ExposureMask | ButtonPressMask);
/*-------------------------------------------------------------*/
/* STEP 11: Map the Main window--to make it visible */

    XMapWindow(display, window);




/*$$$$$$$$$$$$$$$$$*/
}



/*-------------------------------------------------------------*/
/* STEP 13: Retrieve and process events until done */




/**************************************************************/
/*							      */
/*	BOLJ PREPROST NACIN KREIRANJA OKNA:		      */
/*							      */
/*************************************************************/

/* Kreiranje okna na drugacen nacin: */


/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/






/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
if (0)
{
  int screen,i,mapsize;
  Colormap newmap;
  XColor *colors;

  if ((display = XOpenDisplay(display_name)) == NULL)
  {
      fprintf(stderr, "%s: can't open display named %s\n",
              argv[0], XDisplayName(display_name));
      exit(1);
  }

  /* IZDELAVA PRIVATNE BARVNE MAPE: */
  screen=DefaultScreen(display);
  mapsize=DisplayCells(display,screen);
  colors=(XColor *) calloc(mapsize,sizeof(XColor));
  for (i=0;i<mapsize;++i)
  {
    colors[i].pixel=i;
    colors[i].flags=DoRed|DoGreen|DoBlue;
  }
  XQueryColors(display,DefaultColormap(display,screen),colors,mapsize);
  newmap=XCreateColormap(display,RootWindow(display,screen),
                                 DefaultVisual(display,screen),AllocAll);
  XStoreColors(display,newmap,colors,mapsize);
  free(colors);

  /*
  colormap=newmap;
  */

  colormap=DefaultColormap(display,DefaultScreen(display));


  winat.colormap=colormap;
  winat.background_pixel=WhitePixel(display,DefaultScreen(display));
  winat.border_pixel=BlackPixel(display,DefaultScreen(display));
  window=XCreateWindow(display,
                   DefaultRootWindow(display/*,DefaultScreen(display)*/),
                   300,10,600,600,1,8,InputOutput,
                   DefaultVisual(display,DefaultScreen(display)),
                   CWColormap|CWBackPixel|CWBorderPixel,
                   &winat);
  XMapWindow(display,window);


    /* gcv.font = mfontstruct->fid; */
    gcv.foreground = mfgpix;
    gcv.background = mbgpix;
    gc = XCreateGC(display, window,
                (/* GCFont |  GCForeground | GCBackground */ 0), &gcv);
/*-------------------------------------------------------------*/
/* STEP 9: Set window attributes (colormap, bit_gravity) */

    /*
    xswa.colormap = DefaultColormap(display,
                                    DefaultScreen(display));
    */
    xswa.colormap=colormap;
    xswa.bit_gravity = CenterGravity;
    XChangeWindowAttributes(display, window, (CWColormap |
                            CWBitGravity), &xswa);
/*-------------------------------------------------------------*/
/* STEP 10: Select input events for the window window */

    XSelectInput(display, window, ExposureMask | ButtonPressMask);
}






if (0)
{
  if ((display = XOpenDisplay(display_name)) == NULL)
  {
      fprintf(stderr, "%s: can't open display named %s\n",
              argv[0], XDisplayName(display_name));
      exit(1);
  }
  colormap=DefaultColormap(display,DefaultScreen(display));
  winat.colormap=colormap;
  winat.background_pixel=WhitePixel(display,DefaultScreen(display));
  winat.border_pixel=BlackPixel(display,DefaultScreen(display));
  window=XCreateWindow(display,
                   DefaultRootWindow(display/*,DefaultScreen(display)*/),
                   300,10,600,600,1,8,InputOutput,
                   DefaultVisual(display,DefaultScreen(display)),
                   CWColormap|CWBackPixel|CWBorderPixel,
                   &winat);
  XMapWindow(display,window);


    /* gcv.font = mfontstruct->fid; */
    gcv.foreground = mfgpix;
    gcv.background = mbgpix;
    gc = XCreateGC(display, window,
                (/* GCFont |  GCForeground | GCBackground */ 0), &gcv);
/*-------------------------------------------------------------*/
/* STEP 9: Set window attributes (colormap, bit_gravity) */

    /*
    xswa.colormap = DefaultColormap(display,
                                    DefaultScreen(display));
    */
    xswa.colormap=colormap;
    xswa.bit_gravity = CenterGravity;
    XChangeWindowAttributes(display, window, (CWColormap |
                            CWBitGravity), &xswa);
/*-------------------------------------------------------------*/
/* STEP 10: Select input events for the window window */

    XSelectInput(display, window, ExposureMask | ButtonPressMask);
}















    while  (!Done)
    {

                int x, y, itemp;
                unsigned int width, height, utemp;
                Window wtemp;


        XNextEvent(display, &theEvent);

        if(theEvent.xany.window == window)
        {
            if(theEvent.type == ButtonPress)
            {
              Done=1;
            } else if(theEvent.type == Expose &&  theEvent.xexpose.count == 0)
            {






/*$$$$$$$$$$$$$$$$$*/
if (1)
{


/* Determine the current size of the main window */
                if(XGetGeometry(display, window, &wtemp,
                       &itemp, &itemp, &width, &height,
                       &utemp, &utemp) == 0) break;
/* Compute new position for string */
                x = (width - XTextWidth(mfontstruct, "Hello,World",
                     strlen("Hello,World"))) / 2;
                y = eheight + (height - eheight +
                     mfontstruct->max_bounds.ascent -
                     mfontstruct->max_bounds.descent) / 2;
                XClearWindow(display, window);
                XDrawString(display, window, gc, x, y,
                            "Hello,World_1", strlen("Hello,World_1"));




color.red=color.green=color.blue=maxcolor;
color.green=0;
if (XAllocColor(display,colormap,&color)==0)
  fgpixel=BlackPixel(display,DefaultScreen(display));
else
  fgpixel=color.pixel;
gcv.font=mfontstruct->fid;
gcv.foreground=fgpixel;
gcv.background=bgpixel;

XChangeGC(display,gc,(/*GCFont|*/ GCForeground|GCBackground),&gcv);

XDrawLine(display,window,gc,10,10,100,100);
XDrawLine(display,window,gc,10,10,12,20);

XDrawString(display,window,gc,50,60,"Tekst",strlen("Tekst"));


color.red=color.green=color.blue=maxcolor;
color.green=0;
if (XAllocColor(display,colormap,&color)==0)
  fgpixel=BlackPixel(display,DefaultScreen(display));
else
  fgpixel=color.pixel;
gcv.font=mfontstruct->fid;
gcv.foreground=fgpixel;
gcv.background=bgpixel;
XChangeGC(display,gc,(/*GCFont|*/GCForeground|GCBackground),&gcv);
XDrawLine(display,window,gc,10,10,100,100);
points[0].x=20; points[0].y=25;
points[1].x=80; points[1].y=120;
points[2].x=116; points[2].y=70 ;
XFillPolygon(display,window,gc,points,3,Convex,CoordModeOrigin);


/*
    XFreeColors(display,colormap,
     &fgpixel,1,0);
fgpixel=BlackPixel(display,DefaultScreen(display));
printf("BlackPixel je %li\n",fgpixel);
XFreeColors(display,colormap,&fgpixel,1,0);
*/


/*
getch();
exit(0);
*/


/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
}



color.red=color.green=color.blue=0;
color.blue=maxcolor;
if (XAllocColor(display,colormap,&color)==0)
  fgpixel=BlackPixel(display,DefaultScreen(display));
else
  fgpixel=color.pixel;
gcv.foreground=fgpixel;
XChangeGC(display,gc,(GCForeground),&gcv);

XDrawLine(display,window,gc,10,10,12,20);
XFlush(display);

if (1)
{
  int i,j,ci;
  int x,y,x1,y1,h,d,red;
  Font font1,font2,font3,font4,font5,font6;
  XFontStruct *fs1=NULL,*fs2=NULL,*fs3=NULL,*fs4=NULL,*fs5=NULL,*fs6=NULL;
  char *fn1=NULL,*fn2=NULL,*fn3=NULL,*fn4=NULL,*fn5=NULL,*fn6=NULL;
  char *str1=NULL,*str2=NULL,*str3=NULL,*str4=NULL,*str5=NULL,*str6=NULL;
  float cr,cg,cb,cred,cgreen,cblue,hc,dc;





  /* Test barv: */

  /* Privatne barvne celice: */





  unsigned long colorcells[1000000];
  unsigned long planemasks[1];
  unsigned long numcells=50;
  unsigned long tabpixels[1000];


  /*
  colormap=DefaultColormap(display,DefaultScreen(display));
  if (! XAllocColorCells(display,colormap,True,planemasks,1,colorcells,
  numcells))
    printf("\n\n\n\nNeuspeh pri alociranju privatnih barvnih celic(%i celic).\n\n\n",numcells);
  else printf("\n\n\n\nUSPEH pri alociranju bloka barvnih celic. \n\n\n\n\n");
  */
  /*******************************************************************/
  /************************              *****************************/
  /************************   TEST BARV  *****************************/
  /************************              *****************************/
  /*******************************************************************/

if (1)
{
  int i;
  XVisualInfo *vislist,vistemplate;
  int numvisuals;
  vistemplate.screen=DefaultScreen(display);
  vislist=XGetVisualInfo(display,VisualScreenMask,&vistemplate,&numvisuals);

  for (i=0;i<numvisuals;++i)
    printvisualinfo(vislist+i);

  printf("\n\nVelikost default colormap: %li\n\n",
                        DisplayCells(display,DefaultScreen(display)));

}



  ucoloring=1;
  unumshades=64;
  uindexsize=200;
  unumprivatecells=0;
  upreindexall=0;
  freecells=10;



  initcolorhandling();
  printcolorhandlingstatus();



  numcol=256/2; factcol=256*2;


  h=1;
  d=1;
  hc=(float)1/(float)800;
  dc=(float)1/(float)800;



  x=y=0;
  cred=0; cgreen=0; cblue=1;
  cr=0;

  for (i=1;i<=800;++i)
  {
    x=0;
    y+=h;


    cr+=hc/2;
    cred=cr;
    cgreen=0;
    cblue-=hc;
    for (j=1;j<=800;++j)
    {
      cred+=dc/2;
      cgreen+=dc;
      x+=d;
      /* Za sivo skalo: */
      /*
      cred=cgreen=cblue=(cred+cgreen+cblue)/3;
      */
      /*
      color.red=calccolor(cred);
      color.green=calccolor(cgreen);
      color.blue=calccolor(cblue);
      */


      /*
      printf("(%i,%i,%i)\n",color.red,color.green,color.blue);
      */
      /*
      if (XAllocColor(display,colormap,&color)==0)
      {
        fgpixel=BlackPixel(display,DefaultScreen(display));
        printf("Ni uspel alocirati barve (%i,%i,%i)\n",color.red,color.green,color.blue);
      } else
      fgpixel=color.pixel;
      */
      /*

      ci=(int)(cred*numcol);
      fgpixel=tabpixels[ci];

      */
      true.red=cred;
      true.green=cgreen;
      true.blue=cblue;
      if (true.red<0)
        true.red=0;
      else if (true.red>1)
        true.red=1;
      if (true.green<0)
        true.green=0;
      else if (true.green>1)
        true.green=1;
      if (true.blue<0)
        true.blue=0;
      else if (true.blue>1)
        true.blue=1;
      calculatepixel();
      gcv.foreground=color.pixel;
      XChangeGC(display,gc,(GCForeground),&gcv);
      XDrawLine(display,window,gc,x,y,x+d,y);
    }
  }



  printcolorhandlingstatus();



  if (1)
  {
    printf("Rezerviranje pixlov v tabpixels:\n");
    /* Nastavitev pixlov za barve; Vsaka stevilka v tabpixels pove stevilko
    pixla, ki predstavlja barvo, kateri pripada stevilka v tej tabeli. */
    for (i=0;i<=numcol;++i)
    {
      /* Crnobela barvna lestvica: */
      /* Zaradi konverzije int->float: */
      cgreen=i; cblue=numcol;
      cred=cgreen/cblue;
      cgreen=cred; cblue=cred;
      color.red=cred*maxcolor;
      color.green=cgreen*maxcolor;
      color.blue=cblue*maxcolor;
      if (XAllocColor(display,colormap,&color)==0)
      {
        fgpixel=BlackPixel(display,DefaultScreen(display));
        printf("Ni uspel alocirati barve (%i,%i,%i)\n",color.red,color.green,color.blue);
        /* Tu dodaj se dodatne rutine, ki povedo, kaj naj se naredi v tem primeru! */
      } else
      fgpixel=color.pixel;
      tabpixels[i]=fgpixel;
      /*
      printf("Pixel %i (%i,%i,%i): %i\n",i,color.red,color.green,color.blue,fgpixel);
      */
    }
    printf("Rezerviranje pixlov v tabpixels koncano.\n");
  }




  x=y=0;
  cred=0; cgreen=0; cblue=1;
  cr=0;

  for (i=1;i<=800;++i)
  {
    x=0;
    y+=h;


    cr+=hc/2;
    cred=cr;
    cgreen=0;
    cblue-=hc;


    for (j=1;j<=800;++j)
    {

      cred+=dc/2;
      cgreen+=dc;


      /*
      printf("red=%g\n",cred);
      */

      x+=d;


      /* Za sivo skalo: */
      cred=cgreen=cblue=(cred+cgreen+cblue)/3;

      color.red=calccolor(cred);
      color.green=calccolor(cgreen);
      color.blue=calccolor(cblue);



      /*
      printf("(%i,%i,%i)\n",color.red,color.green,color.blue);
      */
      /*
      if (XAllocColor(display,colormap,&color)==0)
      {
        fgpixel=BlackPixel(display,DefaultScreen(display));
        printf("Ni uspel alocirati barve (%i,%i,%i)\n",color.red,color.green,color.blue);
      } else
      fgpixel=color.pixel;
      */


      ci=(int)(cred*numcol);
      fgpixel=tabpixels[ci];


      gcv.foreground=fgpixel;
      XChangeGC(display,gc,(GCForeground),&gcv);
      XDrawLine(display,window,gc,x,y,x+d,y);
    }
  }



  printcolorhandlingstatus();




  /* Test fontov: */
  fn1="-adobe-courier-bold-r-normal--11-80-100-100-m-60-iso8859-1";


  fn1="*times-bold*normal--1-*";
  fn2="*times-bold*normal--2-*";
  fn3="*times-bold*normal--3-*";
  fn4="*times-bold*normal--4-*";
  fn5="*times-bold*normal--5-*";
  fn6="*times-bold*normal--6-*";

  fn1="*times-bold*normal--7-*";
  fn2="*times-bold*normal--8-*";
  fn3="*times-bold*normal--9-*";
  fn4="*times-bold*normal--10-*";
  fn5="*times-bold*normal--11-*";
  fn6="*times-bold*normal--12-*";

  fn1="*times-bold*normal--13-*";
  fn2="*times-bold*normal--14-*";
  fn3="*times-bold*normal--15-*";
  fn4="*times-bold*normal--16-*";
  fn5="*times-bold*normal--17-*";
  fn6="*times-bold*normal--18-*";

  fn1="*times-bold*normal--19-*";
  fn2="*times-bold*normal--20-*";
  fn3="*times-bold*normal--21-*";
  fn4="*times-bold*normal--22-*";
  fn5="*times-bold*normal--23-*";
  fn6="*times-bold*normal--24-*";

  fn1="*times-bold*normal--25-*";
  fn2="*times-bold*normal--26-*";
  fn3="*times-bold*normal--27-*";
  fn4="*times-bold*normal--28-*";
  fn5="*times-bold*normal--29-*";
  fn6="*times-bold*normal--30-*";

  fn1="*times-bold*normal--31-*";
  fn2="*times-bold*normal--32-*";
  fn3="*times-bold*normal--33-*";
  fn4="*times-bold*normal--34-*";
  fn5="*times-bold*normal--35-*";
  fn6="*times-bold*normal--36-*";

  fn1="*times-bold*normal--20-*";
  fn2="*times-bold*normal--20-*";
  fn3="*times-bold*normal--20-*";
  fn4="*times-bold*normal--21-*";
  fn5="*times-bold*normal--22-*";
  fn6="*times-bold*normal--23-*";

  fn1="-adobe-courier-bold-o-normal--90-0-75-75-m-0-hp-roman8";
  fn2="";
  fn3="-adobe-symbol-medium-r-normal*--34-240-100-100-p-191-adobe-fontspecific";
  fn4="";
  fn5="";
  fn6="";

  /* Scalable fonts: Te fonte je treba imenovati s celim imenom (brez *). */
  /* Dokaj dobra ideja za skaliranje. Slabost je v tem, da je treba natancno
  poznati imena fontov nasistemu. */

  fn1="-adobe-courier-bold-o-normal--1-0-75-75-m-0-hp-roman8";
  fn2="-adobe-courier-bold-o-normal--2-0-75-75-m-0-hp-roman8";
  fn3="-adobe-courier-bold-o-normal--3-0-75-75-m-0-hp-roman8";
  fn4="-adobe-courier-bold-o-normal--4-0-75-75-m-0-hp-roman8";
  fn5="-adobe-courier-bold-o-normal--5-0-75-75-m-0-hp-roman8";
  fn6="-adobe-courier-bold-o-normal--6-0-75-75-m-0-hp-roman8";


  fn1="-adobe-courier-bold-o-normal--7-0-75-75-m-0-hp-roman8";
  fn2="-adobe-courier-bold-o-normal--8-0-75-75-m-0-hp-roman8";
  fn3="-adobe-courier-bold-o-normal--9-0-75-75-m-0-hp-roman8";
  fn4="-adobe-courier-bold-o-normal--10-0-75-75-m-0-hp-roman8";
  fn5="-adobe-courier-bold-o-normal--11-0-75-75-m-0-hp-roman8";
  fn6="-adobe-courier-bold-o-normal--12-0-75-75-m-0-hp-roman8";

  fn1="-adobe-courier-bold-o-normal--1-0-75-75-m-0-hp-roman8";
  fn2="-adobe-courier-bold-o-normal--2-0-75-75-m-0-hp-roman8";
  fn3="-adobe-courier-bold-o-normal--3-0-75-75-m-0-hp-roman8";
  fn4="-adobe-courier-bold-o-normal--4-0-75-75-m-0-hp-roman8";
  fn5="-adobe-courier-bold-o-normal--5-0-75-75-m-0-hp-roman8";
  fn6="-adobe-courier-bold-o-normal--6-0-75-75-m-0-hp-roman8";

  fn1="";
  fn2="";
  fn3="";
  fn4="";
  fn5="";
  fn6="";



  /* Malo slabsa ideja za skaliranje (zaradi manjkajocih velikosti) */

  fn1="*--10-*";
  fn2="*--11-*";
  fn3="*--12-*";
  fn4="*--13-*";
  fn5="*--14-*";
  fn6="*--15-*";


  fn1="*--20*";
  fn2="*--19*";
  fn3="*--18*";
  fn4="*--17*";
  fn5="*--16*";
  fn6="*--15*";



  str1="QWERjjjjjfajklaklg 1";
  str2="QWERjjjjjfajklaklg 2";
  str3="QWERjjjjjfajklaklg 3";
  str4="QWERjjjjjfajklaklg 4";
  str5="QWERjjjjjfajklaklg 5";
  str6="QWERjjjjjfajklaklg 6";




  x=300; y=60; h=40;
  if ( (fs1=XLoadQueryFont(display,fn1)) == NULL )
  {
    fprintf(stderr,"Can not load font %s\n",fn1);
  } else
  {
    font1=fs1->fid;
    printf("Font ID: %i\n",font1);
  gcv.font=font1;
  XChangeGC(display,gc,(GCFont),&gcv);
  XDrawString(display,window,gc,x,y,str1,strlen(str1));
  }


  y+=h;
  if ( (fs2=XLoadQueryFont(display,fn2)) == NULL )
  {
    fprintf(stderr,"Can not load font %s\n",fn2);
  } else
  {
    font2=fs2->fid;
    printf("Font ID: %i\n",font2);
  gcv.font=font2;
  XChangeGC(display,gc,(GCFont),&gcv);
  XDrawString(display,window,gc,x,y,str2,strlen(str2));
  }


  y+=h;
  if ( (fs3=XLoadQueryFont(display,fn3)) == NULL )
  {
    fprintf(stderr,"Can not load font %s\n",fn3);
  } else
  {
    font3=fs3->fid;
    printf("Font ID: %i\n",font3);
  gcv.font=font3;
  XChangeGC(display,gc,(GCFont),&gcv);
  XDrawString(display,window,gc,x,y,str3,strlen(str3));
  }


  y+=h;
  if ( (fs4=XLoadQueryFont(display,fn4)) == NULL )
  {
    fprintf(stderr,"Can not load font %s\n",fn4);
  } else
  {
    font4=fs4->fid;
    printf("Font ID: %i\n",font4);
  gcv.font=font4;
  XChangeGC(display,gc,(GCFont),&gcv);
  XDrawString(display,window,gc,x,y,str4,strlen(str4));
  }


  y+=h;
  if ( (fs5=XLoadQueryFont(display,fn5)) == NULL )
  {
    fprintf(stderr,"Can not load font %s\n",fn5);
  } else
  {
    font5=fs5->fid;
    printf("Font ID: %i\n",font5);
  gcv.font=font5;
  XChangeGC(display,gc,(GCFont),&gcv);
  XDrawString(display,window,gc,x,y,str5,strlen(str5));
  }


  y+=h;
  if ( (fs6=XLoadQueryFont(display,fn6)) == NULL )
  {
    fprintf(stderr,"Can not load font %s\n",fn6);
  } else
  {
    font6=fs6->fid;
    printf("Font ID: %i\n",font6);
  gcv.font=font6;
  XChangeGC(display,gc,(GCFont),&gcv);
  XDrawString(display,window,gc,x,y,str6,strlen(str6));
  }



  if ( (fs6=XLoadQueryFont(display,fn6)) == NULL )
  {
    fprintf(stderr,"Can not load font %s\n",fn6);
  } else
  {
    font6=fs6->fid;
    printf("Font ID: %i\n",font6);
  gcv.font=font6;
  XChangeGC(display,gc,(GCFont),&gcv);
  XDrawString(display,window,gc,x,y,str6,strlen(str6));
  }


}





            }
        }

    }
/*-------------------------------------------------------------*/
/* STEP 14:  Close connection to display and exit. */

    XFreeGC(display, gc);
    XUnloadFont(display, mfontstruct->fid);
    XDestroyWindow(display, window);
    XCloseDisplay(display);
    exit(0);
}
/*-------------------------------------------------------------*/
