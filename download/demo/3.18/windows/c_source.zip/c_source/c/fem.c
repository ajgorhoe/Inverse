
             /*************************************************/
             /*                                               */
             /*    VISUALIZATION TOOLS FOR FINITE ELEMENTS    */
             /*                                               */
             /*************************************************/

#include <math.h>
#include <float.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>

#include <mtypes.h>
#include <er.h>
#include <rf.h>
#include <st.h>
#include <vec.h>
#include <mat.h>
#include <strop.h>
#include <numut.h>
#include <simb.h>
#include <fop.h>
#include <mtime.h>
#include <geom.h>
#include <sg_draw.h>
#include <sg_obj.h>
#include <sg_graph.h>


#include <fem.h>



static char prn=0;  /* Auxiliary print-outs */



         /***********************************/
         /*                                 */
         /*      FINITE ELEMENT MESHES      */
         /*                                 */
         /***********************************/

/*
SHORT EXPLANATION (more detailed in fem.h):
  After reading, the mesh must have the matrix (...)->nodcoord set to the node
co-ordinates such that lines of this matrix correspond to nodes. There may not
be any empty lines in this matrix. If node numbers don't follow in turn then
(...)->nodnum must contain the node numbers corresponding to lines of
(...)->nodcoord. In this case nodnuminv must also be allocated and must be
an inverse index table to (...)->nodcoord.
  Stack (...)->elgrp on the mesh (type femesh) must contain for each group of
elements the correspondinf element data structure (type elgrp) so that the
number of each group corresponds to its place on (...)->elgrp. All elements of
a group must be of the same type. On each element group, (...)->elspec must be
set which defines the type of an element (necessary for searching the element
topology data), (...)->elnum must contain global element numbers that
correspond to positions in element data tables such as (...)->eltop and
(...)->outsurf, (...)->eltop must contain the for each element the nodes
that constitute that element, listed in proper order. Elements of a group are
listed without empty places on the stack while for each entry the actual
(global) element number is obtained from the stack (...)->elnum. Other
necessary data define the element topology: (...)->numelnod must contain the
number of nodes per element, (...)->surftop must contain for each element
surface the element-local node numbers (corresponding to the entries of index
tables that are on (...)->eltop) that constitute the surface (the nodes that
span the outline of the surface must be stated first!) listed in an index table
on (...)->surftop, and (...)->surfedg must contain number of edges for each
element surface listed in (...)->surftop.
  The following auxiliary data can be set on the mesh data structure:
(...)->elgrpinv and (...)->elnuminv contain for each element (global element
number being the location index) the group that this element belongs to and its
sequential number in this group's data structures. If (...)->eltopinv is
allocated, then it holds for each node (entry indices correspond to those in
(...)->nodcoords) an index table (type indtab) that contains global numbers
of all elements that contain a given node. (...)->origcoord may contain the
original nodal co-ordinates of the mesh for the case that the mesh is
transformed. In this case (...)->nodcoord will contain the current
(transformed) co-ordinates.
  On a group structure, the following auxiliary data can be allocated:
If (...)->outsurf is allocated, it contains the list of group outer surfaces
for each element listed on (...)->eltop represented by an index table (type
indtab). If the corresponding element is NULL then the element does not contain
any external surfaces of the group (it is also allowed that the table is
allocated but the number of elements is 0, however this should not be
practised). Otherwise, the element surfices are indexed in the same order that
is adopted in (...)->surftop.

*/


    /* ALLOCATION AND DEALLOCATION */

elgrp newelgrp(void)
    /* Makes a new object of type elgrp and returns its pointer. All fields
    of the created objece are initialized to 0.
    $A Igor jul01; */
{
elgrp ret;
ret=malloc(sizeof(*ret));
memset(ret,0,sizeof(*ret));
return ret;
}

void dispelgrp(elgrp *e)
    /* Releases the complete object *e of the type elgrp and sets *e to NULL.
    $A Igor jul01; */
{
elgrp ref;
if (e!=NULL)
{
  ref=*e;
  if (ref!=NULL)
  {
    disppointer((void **) &(ref->name));
    disppointer((void **) &(ref->elspec));
    dispindtab(&(ref->elnum));
    dispstackallspec(&(ref->eltop),(void (*)(void **)) dispindtab);
    dispstackallspec(&(ref->surftop),(void (*)(void **)) dispindtab);
    dispindtab(&(ref->surfedg));
    dispstackallspec(&(ref->outsurf),(void (*)(void **)) dispindtab);
    disppointer((void **) e);
  }
}
}


static void copyelgrpbas(elgrp gr1,elgrp gr2)
    /* Copies contents of gr1 to gr2; both must be different than NULL.
      Warning:
    Stack of outer surfaces is also copied, but sometimes these should actually
    be re-calculated. In such a case care fo this must be taken separately.
    $A Igor feb04; */
{
if (gr1!=NULL && gr2!=NULL)
{
  copystring(gr1->name,&(gr2->name));
  copystring(gr1->elspec,&(gr2->elspec));
  copyindtab(gr1->elnum,&(gr2->elnum));
  copystackspec(gr1->eltop,&(gr2->eltop),(void (*) (void **)) dispindtab,
      (void *(*)(void *,void **)) copyindtab);
  gr2->numelnod=gr1->numelnod;
  copystackspec(gr1->surftop,&(gr2->surftop),(void (*) (void **)) dispindtab,
      (void *(*)(void *,void **)) copyindtab);
  copyindtab(gr1->surfedg,&(gr2->surfedg));
  copystackspec(gr1->outsurf,&(gr2->outsurf),(void (*) (void **)) dispindtab,
      (void *(*)(void *,void **)) copyindtab);
}
return;
}

elgrp copyelgrp(elgrp gr1,elgrp * gr2)
    /* Returns a copy of element group gr1. If gr2 is different than NULL
    then gr1 is coppied to *gr2 and *gr2 returned.
    $A Igor feb04; */
{
elgrp gr;
if (gr2!=NULL)
{
  /* If gr2!=NULL, gr1 is copied to *gr2: */
  if (gr1==NULL)
  {
    dispelgrp(gr2);
  } else
  {
    /* Perform copying: */
    if (*gr2==NULL)
      *gr2=newelgrp();
    copyelgrpbas(gr1,*gr2);
  }
  return *gr2;  /* since gr2!=NULL, *gr2 is returned */
} else
{
  /* gr2==NULL, wa make a new object, which is copy of gr1, and return its
  pointer: */
  if (gr1==NULL)
    return NULL;
  else
  {
    gr=newelgrp();
    copyelgrpbas(gr1,gr);
    return gr;
  }
}
}


femesh newfemesh(void)
    /* Creates a new object of type femesh and returns its pointer. All its 
    fields are initialized to 0 except the stack (...)->elgrp, which is
    allocated but empty (field ex seto to 1).
    $A Igor jul01; */
{
femesh ret;
ret=calloc(1,sizeof(*ret));
/*
memset(ret,0,sizeof(*ret));
*/
ret->elgrp=newstack(2);
return ret;
}

void dispfemesh(femesh *m)
    /* Releases the complete object *m and sets *m to NULL.
    $A Igor jul01; */
{
femesh ref;
if (m!=NULL)
{
  ref=*m;
  if (ref!=NULL)
  {
    dispstackallspec(&(ref->elgrp),(void (*)(void **)) dispelgrp);
    dispindtab(&(ref->nodnum));
    dispindtab(&(ref->nodnuminv));
    dispindtab(&(ref->elgrpinv));
    dispindtab(&(ref->elnuminv));
    dispmatrix(&(ref->nodcoord));
    dispmatrix(&(ref->origcoord));
    dispstackallspec(&(ref->eltopinv),(void (*) (void **)) dispindtab);
    disppointer((void **) m);
  }
}
}

static void copyfemeshbas(femesh m1,femesh m2)
    /* Copies contents of m1 to m2; both must be different than NULL.
    $A Igor feb04; */
{
if (m1!=NULL && m2!=NULL)
{
  copystackspec(m1->elgrp,&(m2->elgrp),(void (*) (void **)) dispelgrp,
      (void *(*)(void *,void **)) copyelgrp);
  copyindtab(m1->nodnum,&(m2->nodnum));
  copyindtab(m1->nodnuminv,&(m2->nodnuminv));
  copyindtab(m1->elgrpinv,&(m2->elgrpinv));
  copyindtab(m1->elnuminv,&(m2->elnuminv));
  copymatrix(m1->nodcoord,&(m2->nodcoord));
  copymatrix(m1->origcoord,&(m2->origcoord));
  copystackspec(m1->eltopinv,&(m2->eltopinv),(void (*) (void **)) dispindtab,
      (void *(*)(void *,void **)) copyindtab);

}
}

femesh copyfemesh(femesh m1,femesh * m2)
    /* Returns a copy of finite element mesh m1. If m2 is different than NULL
    then m1 is coppied to *m2 and *m2 returned.
    $A Igor feb04; */
{
femesh m;
if (m2!=NULL)
{
  /* If m2!=NULL, m1 is copied to *m2: */
  if (m1==NULL)
  {
    dispfemesh(m2);
  } else
  {
    /* Perform copying: */
    if (*m2==NULL)
      *m2=newfemesh();
    copyfemeshbas(m1,*m2);
  }
  return *m2;  /* since m2!=NULL, *m2 is returned */
} else
{
  /* m2==NULL, wa make a new object, which is copy of m1, and return its
  pointer: */
  if (m1==NULL)
    return NULL;
  else
  {
    m=newfemesh();
    copyfemeshbas(m1,m);
    return m;
  }
}
}



/* COMFORTABLE FUNCTIONS FOR OBTAINING MESH INFORMATION: */


int femnodeind(femesh mesh,int nodenum)
    /* Returns the index (position) of the node numbered by nodenum in the node
    data tables like mesh->coord, or 0 if there is no node numbered nodenum
    in the mesh or the data can not be bounkd.
    $A Igor sep03; */
{
int nodind=0;
if (nodenum>0)
{
  if (mesh->nodnuminv!=NULL)
  {
    if (nodenum<=mesh->nodnuminv->n)
      nodind=mesh->nodnuminv->t[nodenum];
  } else if (mesh->nodnum!=NULL)
  {
    if (nodenum<=mesh->nodnum->n)
      nodind=mesh->nodnum->t[nodenum];
  } else
  {
    if (mesh->nodcoord!=NULL)
      if (nodenum<=mesh->nodcoord->d1)
        nodind=nodenum;
  }
}
return nodind;
}

int femnodenum(femesh mesh,int nodeind)
    /* Returns the number of the mesh node whose position in the node data
    tables like mesh->coord and other nodal data is nodeind.
    $A Igor sep03; */
{
int nodenum=0;
if (nodeind>0)
{
  if (mesh->nodnum!=NULL)
  {
    if (nodeind<=mesh->nodnum->n)
      nodenum=mesh->nodnum->t[nodeind];
  } else
  {
    if (mesh->nodcoord!=NULL)
      if (nodenum<=mesh->nodcoord->d1)
        nodenum=nodeind;
  }
}
return nodenum;
}

double femnodcoord(femesh mesh,int nodenum,int whichcoord)
    /* Returns a specific coordinate (whichcoord) of the node nodnum of the
    finite element mesh mesh. Does not check if mesh is different than 0 etc.
    If indices nodnum and whichcoord are out of range then 0 is returned.
    $A Igor sep03; */
{
double ret=0;
int nodind=0;
if (nodenum>0)
{
  if (mesh->nodnuminv!=NULL)
  {
    if (nodenum<=mesh->nodnuminv->n)
      nodind=mesh->nodnuminv->t[nodenum];
  } else if (mesh->nodnum!=NULL)
  {
    if (nodenum<=mesh->nodnum->n)
      nodind=mesh->nodnum->t[nodenum];
  } else
  {
    if (mesh->nodcoord!=NULL)
      if (nodenum<=mesh->nodcoord->d1)
        nodind=nodenum;
  }
}
if (nodind>0 && nodind<=mesh->nodcoord->d1 && 
    whichcoord>0 && whichcoord<=mesh->nodcoord->d2)
  ret=mesh->nodcoord->m[nodind][whichcoord];
return ret;
}

int femnodcoords(femesh mesh,int nodenum,coord3d coord)
    /* Writes three co-ordinates of the node numbered nodnum of the FE mesh to
    If there are more than 3 coordinates per node, the first three are written
    to coord, if there are less, zeros are written for the remaining
    co-ordinates. Function does not chech whether mesh or coord are differet
    than NULL. If index nodnum is out of range then zeros are written to coord.
      Returns the position of node data in the matrix mesh->nodcoord or 0 if
    the co-ordinates can not be found.
    $A Igor sep03; */
{
int nodind=0;
if (nodenum>0)
{
  if (mesh->nodnuminv!=NULL)
  {
    if (nodenum<=mesh->nodnuminv->n)
      nodind=mesh->nodnuminv->t[nodenum];
  } else if (mesh->nodnum!=NULL)
  {
    if (nodenum<=mesh->nodnum->n)
      nodind=mesh->nodnum->t[nodenum];
  } else
  {
    if (mesh->nodcoord!=NULL)
      if (nodenum<=mesh->nodcoord->d1)
        nodind=nodenum;
  }
}
if (nodind>0 && nodind<=mesh->nodcoord->d1)
{
  if (mesh->nodcoord->d2>=1)
    coord->x=mesh->nodcoord->m[nodind][1];
  else
    coord->x=0;
  if (mesh->nodcoord->d2>=2)
    coord->y=mesh->nodcoord->m[nodind][2];
  else
    coord->y=0;
  if (mesh->nodcoord->d2>=3)
    coord->z=mesh->nodcoord->m[nodind][3];
  else
    coord->z=0;
} else
{ /* index out of range */
  coord->x=coord->y=coord->z=0;
  nodind=0;
}
return nodind;
}


int femnodcoordsind(femesh mesh,int nodind,coord3d coord)
    /* Writes three co-ordinates of the node numbered nodnum of the FE mesh to
    If there are more than 3 coordinates per node, the first three are written
    to coord, if there are less, zeros are written for the remaining
    co-ordinates. Function does not chech whether mesh or coord are differet
    than NULL. If index nodnum is out of range then zeros are written to coord.
      Returns the position of node data in the matrix mesh->nodcoord or 0 if
    the co-ordinates can not be found.
    $A Igor sep03; */
{
int ret=0;
if (nodind>0 && nodind<=mesh->nodcoord->d1)
{
  ret=nodind;
  if (mesh->nodcoord->d2>=1)
    coord->x=mesh->nodcoord->m[nodind][1];
  else
    coord->x=0;
  if (mesh->nodcoord->d2>=2)
    coord->y=mesh->nodcoord->m[nodind][2];
  else
    coord->y=0;
  if (mesh->nodcoord->d2>=3)
    coord->z=mesh->nodcoord->m[nodind][3];
  else
    coord->z=0;
} else
{ /* index out of range */
  coord->x=coord->y=coord->z=0;
}
return ret;
}


int femnumgroups(femesh mesh)
    /* Returns the number of element groups in the finite element mesh "mesh".
    $A Igor sep03; */
{
int ret=0;
if (mesh!=NULL)
  if (mesh->elgrp!=NULL)
    ret=mesh->elgrp->n;
return ret;
}


elgrp femgroup(femesh mesh,int ngroup)
    /* Returns the a pointer to the ngroup-th element group containet in mesh,
    or NULL if ngroup is out of range or the data pointer for this group is
    NULL.
    $A Igor sep03; */
{
elgrp ret=NULL;
if (mesh!=NULL)
  if (mesh->elgrp!=NULL)
    if (ngroup>=0 && ngroup<=mesh->elgrp->n)
      ret=mesh->elgrp->s[ngroup];
return ret;
}



int femnumelements(elgrp grp)
    /* Returns the number of elements of the element group grp.
      grp may be NULL , in this case 0 is returned.
    $A Igor sep03; */
{
int ret=0;
if (grp!=NULL)
  if (grp->eltop!=NULL)
    ret=grp->eltop->n;
return ret;
}


int femnumelnodes(elgrp grp,int el)
    /* Returns the number of nodes of the element el of the element group grp,
    or 0 if thre is no data about that.
    $A Igor spe03.*/
{
int ret=0;
if (grp->eltop!=NULL)
  if (el>0 && el<=grp->eltop->n)
  {
    indtab elnodes=grp->eltop->s[el];
    if (elnodes!=NULL)
      ret=elnodes->n;
  }
return ret;
}

int femelnode(elgrp grp,int el,int which)
    /* Returns the number of the node which of element el on the group grp.
    does not check if grp is NULL. el must be a serial number of the element on
    the stack grp->eltop (which is necessarily the same as element ID), and
    which must be the local serial number of the node within an element. If a
    node that satisfies the parameters can not be identified, 0 is returned.
    $A Igor sep03; */
{
int ret=0;
if (grp->eltop!=NULL)
  if (el>0 && el<=grp->eltop->n)
  {
    indtab elnodes=grp->eltop->s[el];
    if (elnodes!=NULL)
      if (which>0 && which<=elnodes->n)
        ret=elnodes->t[which];
  }
return ret;
}


void femelnodes(elgrp grp,int el,indtab it)
    /* Loads indices of all nodes of element el of element group grp to the
    index tab it (in the appropriate order). Space for it must be allocated.
    The function does not check if grp is different than NULL. If indices are
    out of range or the data can not be obtained, then it will contain 0
    elements after the function call.
    $A Igor sep03; */
{
it->n=0;
if (grp->eltop!=NULL)
  if (el>0 && el<=grp->eltop->n)
  {
    indtab elnodes=grp->eltop->s[el];
    if (elnodes!=NULL)
    {
      int i;
      for (i=1;i<=elnodes->n;++i)
        pushindtab(it,elnodes->t[i]);
    }
  }
}


int femnumelsurf(elgrp grp,int el)
    /* Returns the number of surfaces of the element el of the element group
    grp, or 0 if thre is no data about that or el is out of range. It does not
    check if grp is NULL.
    $A Igor sep03.*/
{
int ret=0;
if (grp->eltop!=NULL)
  if (el>0 && el<=grp->eltop->n)
  {
    if (grp->surfedg!=NULL)
      ret=grp->surfedg->n;
    else if (grp->surftop!=NULL)
      ret=grp->surftop->n;
  }
return ret;
}

int femnumelsurfedges(elgrp grp,int el,int surf)
    /* Returns the number of surface edges of the surface surf of the element
    el of the element group grp, or 0 if the data is not available or if the
    indices are out of range. grp may not be NULL because the function itself
    does not check it.
    $A Igor sep03 */
{
int ret=0;
if (grp->eltop!=NULL)
  if (el>0 && el<=grp->eltop->n)
  {
    if (grp->surfedg!=NULL)
      if (surf>=0 && surf<=grp->surfedg->n)
        ret=grp->surfedg->t[surf];
  }
return ret;
}

int femnumelsurfnodes(elgrp grp,int el,int surf)
    /* Returns the number of nodes on the surface surf of the element el of the
    element group grp, or 0 if the data is not available or if the indices are
    out of range. grp may not be NULL because the function itself does not
    check this.
    $A Igor sep03; */
{
int ret=0;
indtab it;
if (grp->eltop!=NULL)
  if (grp->surftop!=NULL)
    if (surf>0 && surf<=grp->surftop->n)
    {
      it=grp->surftop->s[surf];
      if (it!=NULL)
        ret=it->n;
    }
return ret;
}

int femelsurfnode(elgrp grp,int el,int surf,int which)
    /* Returns the node number of node which of the surface surf of element
    el on grp, or 0 if the indormation can not be obtained or if indices are
    out of range. It does not check if grp is NULL.
    $A Igor spe03.*/
{
int ret=0;
if (grp->eltop!=NULL)
  if (el>0 && el<=grp->eltop->n)
  {
    if (grp->surftop!=NULL)
      if (surf>=0 && surf<=grp->surftop->n)
      {
        indtab surftop=grp->surftop->s[surf];
        indtab element=grp->eltop->s[el];
        if (element!=NULL && surftop!=NULL)
          if (which>0 && which<=surftop->n)
          {
            int ind=surftop->t[which];
            if (ind>0 && ind<=element->n)
              ret=element->t[ind];
          }
      }
  }
return ret;
}


void femelsurfnodes(elgrp grp,int el,int surf,indtab it)
    /* Loads indices of the surface surf of element el of the group grp on the
    index table it, which must be allocated. If indices are out of range or
    the information could not be obtained, then it will contain 0 indices
    after the call. grp must be different than NULL because the function does
    not check it.
    $A Igor spe03.*/
{
it->n=0;
if (grp->eltop!=NULL)
  if (el>0 && el<=grp->eltop->n)
  {
    if (grp->surftop!=NULL)
      if (surf>=0 && surf<=grp->surftop->n)
      {
        indtab surftop=grp->surftop->s[surf];
        indtab element=grp->eltop->s[el];
        if (element!=NULL && surftop!=NULL)
        {
          int ind,which;
          for (which=1;which<=surftop->n;++which)
          {
            ind=surftop->t[which];
            if (ind>0 && ind<=element->n)
              pushindtab(it,element->t[ind]);
          }
        }
      }
  }
}


int femelsurfext(femesh mesh,elgrp grp,int el,int surf)
    /* Returns 1 if teh surface surf of element el of the element group grp is
    a part of the external surface of the element group grp, or 0 if it is not
    or if the information can not be obtained.
      mesh and grp may not be NULL because the function itself does not check
    this. It is necessary to pass mesh as argument because a pointer to the
    whole finite element mesh is necessary for identification of outer surfaces.
    The function automatically identifies the outer element surfaces for the
    all groups of the mesh if this data is not yet available (this refers to
    the element surfaces that are external to groups, which includes those that
    lie on the border of two groups).
    /* $A Igor sep03; */
{
int ret=0,i;
indtab it;
if (grp->outsurf==NULL)
  /*
  identifyfemeshsurfgrp(mesh);
  */
  femcalcoutsurf(mesh,0);
if (grp->outsurf!=NULL)
  if (el>0 && el<=grp->outsurf->n)
  {
    it=grp->outsurf->s[el];
    /*
    if (it!=NULL)
      if (surf>0 && surf<=it->n)
        ret=it->t[surf];
    */
    if (it!=NULL)
    {
      for (i=1;i<=it->n;++i)
        if (it->t[i]==surf)
        {
          ret=1;
          break;
        }
    }
  }
return ret;
}


int femel2d(elgrp grp,int el)
    /* Returns 1 if it can be confirmed that the element el of the group grp is
    two dimensional, otherwise it returns 0. Currently this function relies
    only on the information in gr->surfedg, but which should also be enough.
    $A Igor sep03; */
{
int ret=0;
if (grp!=NULL)
  if (grp->eltop!=NULL)
    if (el>0 && el<=grp->eltop->n)
    {
      if (grp->surfedg!=NULL)
        if (grp->surfedg->t[1]==1)
          ret=1;
    }
return ret;
}

int femel3d(elgrp grp,int el)
    /* Returns 1 if it can be confirmed that the element el of the group grp is
    three dimensional, otherwise it returns 0. Currently this function relies
    only on the information in gr->surfedg, but which should also be enough.
    $A Igor sep03; */
{
int ret=0;
if (grp!=NULL)
  if (grp->eltop!=NULL)
    if (el>0 && el<=grp->eltop->n)
    {
      if (grp->surfedg!=NULL)
        if (grp->surfedg->t[1]>=3)
          ret=1;
    }
return ret;
}




    /* ROUTINES FOR CALCULATING DERIVED DATA: */

void femcalcelnuminv(femesh mesh)
    /* Calculates the position of element data for all elements and stores this
    information in mesh->elgrpinv and mesh->elnuminv. If these structures
    already exist, they are re-calculated.
    $A igor sep03; */
{
static char *funcname="femcalcelnuminv";
int i,j,nonempty,elnum;
elgrp grp;
if (mesh==NULL)
{
  errfunc0(funcname);
  sprintf(ers(),"The pointer to the mesh data is NULL.");
  errfunc2();
  return;
}
if (mesh->elgrp==NULL)
{
  errfunc0(funcname);
  sprintf(ers(),"The stack of element groups is NULL.");
  errfunc2();
  return;
} else if (mesh->elgrp->n<1)
{
  errfunc0(funcname);
  sprintf(ers(),"There are no element groups.");
  errfunc2();
  return;
}
/* Reset the space for the data: */
if (mesh->elgrpinv==NULL)
  mesh->elgrpinv=newindtab(1000,0);
else
  mesh->elgrpinv->ex=1000;
if (mesh->elnuminv==NULL)
  mesh->elnuminv=newindtab(1000,0);
else
  mesh->elnuminv->ex=1000;
mesh->elgrpinv->n=mesh->elnuminv->n=0; /* reset the tables if they existed */
nonempty=0;
for (i=1;i<=mesh->elgrp->n;++i)
{
  grp=mesh->elgrp->s[i];
  if (grp!=NULL)
  {
    if (grp->elnum!=NULL) if (grp->elnum->n>0)
    {
      ++nonempty;
      for (j=1;j<=grp->elnum->n;++j)
      {
        if ((elnum=grp->elnum->t[j])>0)
        {
          /* For element elnum, write its group to elgrpinv and its local index
          within the group to elnuminv: */
          setindtab(mesh->elgrpinv,i,elnum);
          setindtab(mesh->elnuminv,j,elnum);
        }
      }
    }
  }
}
/* Re-allocate the index tables in such a way tahat the allocated space is
not larger than necessary: */
resizeindtab(&(mesh->elgrpinv),100,mesh->elgrpinv->n,mesh->elgrpinv->n);
resizeindtab(&(mesh->elnuminv),100,mesh->elnuminv->n,mesh->elnuminv->n);
if (!nonempty)
{
  errfunc0(funcname);
  sprintf(ers(),"There is no data about element groups or all data structures are NULL.");
  errfunc2();
  return;
}
}


void femcalceltopinv(femesh mesh)
    /* Calculates and creates mesh->eltopinv, which contains for each node 
    a list of elements that contain this node. Index of an entry that
    represents a given node is the same as the indices of the the node data
    on mesh->coord, and elements are listed by their global numbers.
      If the structure already exists, it is re-calculated.
    $A igor sep03; */
{
static char *funcname="femcalceltopinv";
elgrp grp;
stack st;
indtab it,elnodes;
int i,j,k,nonempty,elnum,nodeind;
if (mesh==NULL)
{
  errfunc0(funcname);
  sprintf(ers(),"The pointer to the mesh data is NULL.");
  errfunc2();
  return;
}
if (mesh->elgrp==NULL)
{
  errfunc0(funcname);
  sprintf(ers(),"The stack of element groups is NULL.");
  errfunc2();
  return;
} else if (mesh->elgrp->n<1)
{
}
/* Reset the space for the data: */
if (mesh->eltopinv!=NULL)
{
  dispstackvalspec(mesh->eltopinv,(void (*)(void **)) dispindtab);
  mesh->eltopinv->ex=1000;
  mesh->eltopinv->n=0;
} else
  mesh->eltopinv=newstack(1000);
st=mesh->eltopinv;
for (i=1;i<=mesh->elgrp->n;++i)
{
  grp=mesh->elgrp->s[i];
  if (grp!=NULL)
  {
    if (grp->eltop!=NULL) if (grp->eltop->n>0)
    {
      ++nonempty;
      for (j=1;j<=grp->eltop->n;++j)
      {
        /* Get a table of nodes contained on the j-th  of group i: */
        elnodes=grp->eltop->s[j];
        elnum=0;
        if (grp->elnum!=NULL)
          if (grp->elnum->n>=j)
            elnum=grp->elnum->t[j];
        if (elnum<=0)
        {
          errfunc0(funcname);
          sprintf(ers(),"Can not determine the global element number for element %i\n",j);
          sprintf(ers(),"of the group %i.\n",i);
          errfunc2();
          continue;
        }

        if (elnodes!=NULL)
          for (k=1;k<=elnodes->n;++k)
          {
            /* Get the index of the k-th node of the element and store the
            data: */
            nodeind=femnodeind(mesh,elnodes->t[k]);
            if (nodeind<=0)
            {
              errfunc0(funcname);
              sprintf(ers(),"Can not determine the index of the node %i\n",elnodes->t[k]);
              errfunc2();
              continue;
            }
            it=stackel(st,nodeind);
            if (it==NULL)
            {
              it=newindtab(10,6);
              setstack(st,it,nodeind);
            }
            pushindtab(it,elnum);
          }
      }
    }
  }
}
/* Sort the data and reallocate memory in such a way that no unnecessary space
is consumed: */
for (i=1;i<=st->n;++i)
{
  it=st->s[i];
  if (it!=NULL)
  {
    sortindtab(it);
    resizeindtab(&(it),4,it->n,it->n);
  }
}
/* Re-allocate the stack in such a way tahat the allocated space is
not larger than necessary: */
st->ex=100;
if (st->r > st->n)
{
  st->r=st->n;
  if (st->s!=NULL)
  {
    ++ st->s;
    st->s=realloc(st->s,st->r*sizeof(*(st->s)));
    -- st->s;  
  }
}
}



void femcalcoutsurf(femesh mesh,int grpnum)
    /* For the element group grpnum of the mesh, checks which element surfaces
    are the outer surfaces for the group of elements and writes the information
    in the stack (...)->outsurf of a given group. If the stack alreay exists,
    the data is recalculated and rewritten.
      For every element thet has one or more output surfaces, an index table 
    is put on (...)->outsurf at the index of this element within the element
    group. Element of this index table (type indtab) are the element-local
    numbers of surfaces of the element that are outer surfaces of the group.
    $A Igor sep03; */
{
static char *funcname="femcalcoutsurf";
int i,j,k,num,elnum,testind,nodeind,testelnum,foundsamesurf=0,surfnum,testsurfnum;
elgrp grp=NULL;
stack st,comsurfel=NULL,comsurfsurf=NULL;
indtab surfnodes=NULL,surfnodes1=NULL,checked=NULL,neigh,it;
#define m_sameel(element,surface)  \
  ( ((indtab) comsurfel->s[element]) -> t[surface] )

#define m_samesurf(element,surface)  \
  ( ((indtab) comsurfsurf->s[element]) -> t[surface] )

if (mesh==NULL)
{
  errfunc0(funcname);
  sprintf(ers(),"The mesh data is NULL.\n",grpnum);
  errfunc2();
  return;
}
if (mesh->elgrp==NULL)
  return;
if (grpnum<0)
{
  errfunc0(funcname);
  sprintf(ers(),"Group number is %i, but should be greater or equal to zero.\n",grpnum);
  errfunc2();
} else if (grpnum==0)
{
  if (mesh->elgrp!=NULL)
    for (i=1;i<=mesh->elgrp->n;++i)
      femcalcoutsurf(mesh,i);
} else
{
  if (grpnum>0 && grpnum <= mesh->elgrp->n)
    grp=mesh->elgrp->s[grpnum];
  if (grp==NULL)
    return;
  if (grp->eltop==NULL || grp->surftop==NULL)
  {
    errfunc0(funcname);
    sprintf(ers(),"Element or surface topology is not available for group %i.\n",grpnum);
    errfunc2();
  }
  /* Reset the data: */
  if (grp->outsurf==NULL)
    grp->outsurf=newstack(1000);
  else
  {
    dispstackvalspec(grp->outsurf,(void (*) (void **)) dispindtab);
    grp->outsurf->ex=1000;
    grp->outsurf->n=0;
  }
  st=grp->outsurf;
  while (st->n<grp->eltop->n)
    pushstack(st,NULL);
  /* Prepare the auxiliary information and data structures: */
  if (mesh->eltopinv==NULL)
    femcalceltopinv(mesh);
  if (mesh->elgrpinv==NULL)
    femcalcelnuminv(mesh);
  /* Local auxiliary vars: */
  surfnodes=newindtab(10,10);  /* for nodes of the current surface */
  surfnodes1=newindtab(10,10);  /* for nodes of the compared surface */
  num=grp->eltop->n;
  checked=newindtab(100,num);  checked->n=num;  /* indicate inspected elements */
  /* The following data structures will contain information for the identified
  same surfaces between elements. For each element, there is an index table on
  each stack with a many elements as there are surfaces of the element,
  initialized to 0 on comsurfel. Elements of index table on comsurfel are 0
  if the surface has not been inspected yet, -1 if no other element contains
  the surface or num. or the element that also contains the surface - in the
  latter case the corresponding member of comsurfsurf contains the index of
  the surface in this element which is the same. */
  /*
  comsurfel=newstackrn(100,num);  
  comsurfsurf=newstackrn(100,num);
  */
  comsurfel=newstackrn(100,num);
  comsurfsurf=newstackrn(100,num);
  /*
  for (i=1;i<=num;++i)
  {
    pushstack(comsurfel,NULL);
    pushstack(comsurfsurf,NULL);
  }
  */
  for (i=1;i<=num;++i)
  {
    checked->t[i]=0;
    comsurfel->s[i]=it=newindtab(10,grp->surftop->n);
    it->n=it->r;
    for (j=1;j<=it->n;++j)
      it->t[j]=0;
    comsurfsurf->s[i]=it=newindtab(10,grp->surftop->n);
    it->n=it->r;
  }
  for (elnum=1;elnum<=grp->eltop->n;++elnum)
  {    /* Iterate over all elements: */
    for (surfnum=1;surfnum<=femnumelsurf(grp,elnum);++surfnum)
      if (!m_sameel(elnum,surfnum))
    {   /* Check all surfaces of the element that has not been ch. yet: */
      /*
      printf("Checking element %i, surface %i:\n",elnum,surfnum);  
      */  
      foundsamesurf=0;
      surfnodes->n=0;
      femelsurfnodes(grp,elnum,surfnum,surfnodes);
      sortindtab(surfnodes);
      /* Obtain a list of elements that contain the first node of the surface: */
      nodeind=0;
      if (surfnodes->n>0)
        nodeind=femnodeind(mesh,surfnodes->t[1]);
      neigh=NULL;
      if (nodeind>0 && nodeind<=mesh->eltopinv->n)
        neigh=mesh->eltopinv->s[nodeind];
      if (neigh==NULL)
      {
        errfunc0(funcname);
        sprintf(ers(),"Can not determine containing elements for node %i.\n",
          femnodenum(mesh,nodeind));
        errfunc2();
        continue;
      }
      /*
      printf("Take node %i, neigh. el.: ",nodeind);
      for (testind=1;testind<=neigh->n;++testind)
        printf("%i ",neigh->t[testind]);
      printf("\n");
      */
      for (testind=1;testind<=neigh->n && !foundsamesurf;++testind)
      {
        /* Check all elements that contain the first node of the surface: */
        testelnum=mesh->elnuminv->t[neigh->t[testind]];
        if (mesh->elgrpinv->t[neigh->t[testind]]==grpnum && !checked->t[testelnum]
               && testelnum!=elnum    )
        {
          /*
          printf("  Compare with element %i:\n",testelnum);
          */
          /*
          foundsamesurf=0;
          */
          /* found=0; */
          for (testsurfnum=1;testsurfnum<=femnumelsurf(grp,testelnum) /*&& !checked*/
              && !foundsamesurf; ++testsurfnum)
            if (!m_sameel(testelnum,testsurfnum))
            {
              surfnodes1->n=0;
              femelsurfnodes(grp,testelnum,testsurfnum,surfnodes1);
              sortindtab(surfnodes1);
              /* Compare the nodes in the surface that is being checked and
              the reference surface: */
              if (surfnodes->n==surfnodes1->n)
              {
                foundsamesurf=1;
                for (i=1;i<=surfnodes->n && foundsamesurf;++i)
                  if (surfnodes->t[i]!=surfnodes1->t[i])
                    foundsamesurf=0;
              }


              if (foundsamesurf)
              {
                /*
                printf("elnum: %i, surfnum: %i, testelnum: %i,testsurfnum: %i\n",
                  elnum,surfnum,testelnum,testsurfnum); 
                */
                m_sameel(elnum,surfnum)=testelnum;
                m_samesurf(elnum,surfnum)=testsurfnum;
                m_sameel(testelnum,testsurfnum)=elnum;
                m_samesurf(testelnum,testsurfnum)=surfnum;
              }


            }
        }
      }
      if (!foundsamesurf)
      {
        /* The same surface could not be found in any other element of the
        element group, which means that the surface must be its outer surf.: */
        m_sameel(elnum,surfnum)=-1;
        /*
        if (grp->outsurf->s[elnum]==NULL)
          grp->outsurf->s[elnum]=newindtab(10,10);
        it=grp->outsurf->s[elnum];
        pushindtab(it,surfnum);
        */
      }
    }
    checked->t[elnum]=1;
  }
  /*
  grp=mesh->elgrp->s[i];
  */
  /* Collect and store the obtained data about outer surfaces: */

  /*
  dispstackallspec(&comsurfel,(void (*)(void **)) dispindtab);
  dispstackallspec(&comsurfsurf,(void (*)(void **)) dispindtab);
*/
  
  elnum=grp->eltop->n;
  num=grp->surftop->n;
  for (j=1;j<=elnum;++j)
  {
    for (k=1;k<=num;++k)
    {
      /*
      printf("(%i,%i): %i   ",j,k,m_sameel(j,k));
      */
      if (m_sameel(j,k)==-1)
      {
        /* The surface is an outer one, store this information: */
        if ((it=grp->outsurf->s[j])==NULL)
          it=grp->outsurf->s[j]=newindtab(4,4);
        pushindtab(it,k);
      } else  if (m_sameel(j,k)==0)
      {  /* Leave this check in the future and perform only the first if(...)!  */
        errfunc0(funcname);
        sprintf(ers(),"Surface %i of element %i, group %i has not been checked.\n",
          k,j,grpnum);
        errfunc2();
      }
    }
  }
  dispindtab(&surfnodes);
  dispindtab(&surfnodes1);
  dispindtab(&checked);
  dispstackallspec(&comsurfel,(void (*)(void **)) dispindtab);
  dispstackallspec(&comsurfsurf,(void (*)(void **)) dispindtab);
  /* Re-allocate the stack in such a way tahat the allocated space is
  not larger than necessary: */
  st->ex=10;
  if (st->r > st->n)
  {
    st->r=st->n;
    if (st->s!=NULL)
    {
      ++ st->s;
      st->s=realloc(st->s,st->r*sizeof(*(st->s)));
      -- st->s;  
    }
  }
  /* Arrange data on the stack: */
  for (i=1;i<=st->n;++i)
  {
    it=st->s[i];
    if (it!=NULL)
    {
      /*
      sortindtab(it);
      */
      resizeindtab(&it,2,it->n,it->n);
    }
  }
  
}
#undef m_sameel
#undef m_samesurf
}




int femcalcnodnuminv(femesh fm)
    /* Na mrezi koncnih elementov kreira inverzno indeksno tabelo za stevilke
    vozlisc fm->nodnuminv, tako da je i. element zap. st. vozlisca st. i na
    fm->nodnum. Ce so stevilke vozlisc ze po vrsti ali je fm->nodnum enak
    NULL, postane tudi fm->nodnuminv NULL. Ce je inverzna tabela ze narejena,
    funkcija ne naredi nic. Funkcija vrne stevilo vozlisc, ki jih spravi na
    inverzno indeksno tabelo, ali -1, ce pride do napake.
    $A Igor jul01; */
{
int ret=0;
int i,max,sorted,n;
indtab it,itinv;
if (prn)
  printf("Creating inverse node number table...\n");
if (fm==NULL)
{
  errfunc0("femcalcnodnuminv");
  sprintf(ers(),"Address of mesh data storage is NULL.\n");
  errfunc2();
  ret=-1;
} else if (fm->nodnum==NULL && fm->nodcoord==NULL)
{
  errfunc0("femcalcnodnuminv");
  sprintf(ers(),"There are no nodes on the mesh data structure.\n");
  errfunc2();
  ret=-1;
} else if (fm->nodnum!=NULL)
{
  if (fm->nodnum->n<1)
  {
    errfunc0("femcalcnodnuminv");
    sprintf(ers(),"There are no nodes on the node numbers table.\n");
    errfunc2();
    ret=-1;
  } else if (fm->nodcoord!=NULL)
    if (fm->nodcoord->d1!=fm->nodnum->n)
    {
      errfunc0("femcalcnodnuminv");
      sprintf(ers(),"Number of nodes on node number table (%i) differs from number of nodes in the coordinate matrix (%i).\n",
       fm->nodnum->n,fm->nodcoord->d1);
      errfunc2();
      ret=-1;
    }
  if (fm->nodnuminv!=NULL)
    if (fm->nodnuminv->n < fm->nodnum->n)
      dispindtab(&(fm->nodnuminv));
  if (ret==0 && fm->nodnuminv==NULL)
  {
    /* Najprej se preveri, ce ni morda inverzna tabela ista kot direktna,
    hkrati pa se izlusci najvecja stevilka vozlisca: */
    sorted=1;
    max=0;
    it=fm->nodnum;
    if (prn)
      printf("Checking if inverse table is necessary...\n");
    for (i=1;i<=it->n;++i)
    {
      if ((n=fm->nodnum->t[i])!=i)
        sorted=0;
      if (n>max)
        max=n;
    }
    if (!sorted)
    {
      /* Tabela fm->nodnum ni enaka svojemu inverzu, zato je potrebno narediti
      inverzno tabelo: */
      if (prn)
        printf("Creating inverse table...\n");
      fm->nodnuminv=itinv=newindtab(0,max);
      itinv->n=max;
      for (i=1;i<=itinv->n;++i)
        itinv->t[i]=0;
      for (i=1;i<=it->n;++i)
      {
        itinv->t[ it->t[i] ]=i;
        ++ret;
        if (prn)
          if (i%100==0)
            printf(".");
      }
      if (prn && i>100)
        printf("\n");
    }
  }
}
if (prn)
  printf("Inverse node number table finished.\n");
return ret;
}



void femcalclimits(femesh mesh,vector *addrmin,vector *addrmax)
    /* Calculates the minimum and maximum values for nodal co-ordinnates of
    the finite element mesh "mesh" and writes them to *addrmin and *addrmax,
    respectively. addrmin and addrmax must be addresses of vectors that are
    either NULL or allocated with any dimension.
      If mesh==NULL or mesh->coord==NULL then vectors *addrmin and *addrmax
    are deleted, but no error is reported.
    $A Igor oct03; */
{
vector min=NULL,max=NULL;
int i,j;
if (addrmin==NULL || addrmax==NULL)
{
  errfunc0("calcmeshlimits");
  sprintf(ers(),"The address of one or both result vectors is NULL.\n");
  errfunc2();
}
if (mesh==NULL)
{
  dispvector(addrmin); dispvector(addrmax); return;
} else if (mesh->nodcoord==NULL)
{
  dispvector(addrmin); dispvector(addrmax); return;
}
if (*addrmin!=NULL)
  if ((*addrmin)->d!=mesh->nodcoord->d2)
    dispvector(addrmin);
if (*addrmax!=NULL)
  if ((*addrmax)->d!=mesh->nodcoord->d2)
    dispvector(addrmax);
if (*addrmin==NULL)
  *addrmin=getvector(mesh->nodcoord->d2);
if (*addrmax==NULL)
  *addrmax=getvector(mesh->nodcoord->d2);
min=*addrmin;
max=*addrmax;
for (j=1;j<=min->d;++j)
  min->v[j]=max->v[j]=mesh->nodcoord->m[1][j];
for (i=2;i<=mesh->nodcoord->d1;++i)
  for (j=1;j<=min->d;++j)
    if (mesh->nodcoord->m[i][j]<min->v[j])
      min->v[j]=mesh->nodcoord->m[i][j];
    else if (mesh->nodcoord->m[i][j]>max->v[j])
      max->v[j]=mesh->nodcoord->m[i][j];
}


void femcalcgrplimits(femesh mesh,int grp,vector *addrmin,vector *addrmax)
    /* Calculates the minimum and maximum values for nodal co-ordinnates of
    the group grp of the finite element mesh "mesh" and writes them to *addrmin
    and *addrmax, respectively. addrmin and addrmax must be addresses of 
    vectors that are either NULL or allocated with any dimension.
      If grp==0 then limits are calculated for the whole mesh, but in this
    case femcalclimits() is much more efficient.
      If there are no nodes belonging to the group grp then *addrmin and 
    *addrmax are deleted, but no error is reported.
    $A Igor oct03 feb04; */
{
vector min=NULL,max=NULL;
int i,j,obtainedfirst,rightgroup,elnum;
indtab ellist;
if (addrmin==NULL || addrmax==NULL)
{
  errfunc0("femcalcgrplimits");
  sprintf(ers(),"The address of one or both result vectors is NULL.\n");
  errfunc2();
}
if (mesh==NULL)
{
  dispvector(addrmin); dispvector(addrmax); return;
} else if (mesh->nodcoord==NULL)
{
  dispvector(addrmin); dispvector(addrmax); return;
}
if (*addrmin!=NULL)
  if ((*addrmin)->d!=mesh->nodcoord->d2)
    dispvector(addrmin);
if (*addrmax!=NULL)
  if ((*addrmax)->d!=mesh->nodcoord->d2)
    dispvector(addrmax);
if (*addrmin==NULL)
  *addrmin=getvector(mesh->nodcoord->d2);
if (*addrmax==NULL)
  *addrmax=getvector(mesh->nodcoord->d2);
min=*addrmin;
max=*addrmax;
if (grp>0)
{  /* Construct the necessary mesh information: */
  if (mesh->eltopinv==NULL)
    femcalceltopinv(mesh);
  if (mesh->elgrpinv==NULL || mesh->elnuminv==NULL)
    femcalcelnuminv(mesh);
}
for (j=1;j<=min->d;++j)
  min->v[j]=max->v[j]=0;
obtainedfirst=0;
for (i=1;i<=mesh->nodcoord->d1;++i)
{
  if (grp>0)
  {
    /* Check whether the node belongs to any element contained in the group
    grp: */
    rightgroup=0;
    ellist=NULL;
    if (mesh->eltopinv!=NULL)
      if (mesh->eltopinv->n>=i)
        ellist=mesh->eltopinv->s[i];
    if (ellist==NULL)
    {
      static int reported=0;
      if (!reported)
      {
        ++reported;
        errfunc0("femcalcgrplimits");
        sprintf(ers(),"List of containing elements can not be obtained for the node whose index is %i.\n",
          i);
        errfunc2();
      }
    } else for (j=1;j<=ellist->n && !rightgroup;++j)
    {
      elnum=ellist->t[j];
      if (elnum>0 && mesh->elgrpinv!=NULL)
        if (mesh->elgrpinv->n>=elnum)
          if (mesh->elgrpinv->t[elnum]==grp)
            rightgroup=1;
    }
  } else
    if (grp==0)
      rightgroup=1;
  if (rightgroup)
  {
    if (!obtainedfirst)
    {  /* Initialize to co-ordinates of the first node */
      obtainedfirst=1;
      for (j=1;j<=min->d;++j)
        min->v[j]=max->v[j]=mesh->nodcoord->m[i][j];
    } else for (j=1;j<=min->d;++j)
    {
      if (mesh->nodcoord->m[i][j]<min->v[j])
        min->v[j]=mesh->nodcoord->m[i][j];
      else if (mesh->nodcoord->m[i][j]>max->v[j])
        max->v[j]=mesh->nodcoord->m[i][j];
    }
  }
}
if (!obtainedfirst)
{
  dispvector(addrmin); dispvector(addrmax); return;
}
}






    /* PRINTING MESH DATA: */


void printelsurftop(elgrp grp)
    /* Izpise topologijo povrsin elementov, ki so na skupini elementov grp.
    $A Igor jul01; */
{
int i,j;
indtab it;
if (grp->surftop==NULL)
  printf("Surface topology is not specified.\n");
else
{
  printf("Surface topology:\n");
  if (grp->surftop->n<1)
    printf("No surfaces specified.\n");
  for (i=1;i<=grp->surftop->n;++i)
  {
    printf("Surface %i:\n",i);
    if (grp->surfedg==NULL)
      printf(" Number of borders not specified.\n");
    else if (grp->surfedg->n<i)
      printf(" Number of borders not specified.\n");
    else
      printf(" %i borders.\n",grp->surfedg->t[i]);
    printf(" Nodes:");
    it=grp->surftop->s[i];
    if (it!=NULL) for (j=1;j<=it->n;++j)
      printf(" %2i",it->t[j]);
    printf("\n");
  }
}
}

void printelsurftopgrp(femesh fm)
    /* Izpise topologijo povrsin elementov, ki so na skupini elementov grp.
    $A Igor avg01; */
{
int i;
elgrp grp;
if (fm==NULL)
{
  printf("Mesh pointer is NULL.\n");
} else if (fm->elgrp==NULL)
  printf("Stack of element groups is NULL.\n");
else if (fm->elgrp->n<1)
  printf("No element groups on the stack.\n");
else for (i=1;i<=fm->elgrp->n;++i)
{
  if ((grp=fm->elgrp->s[i])==NULL)
    printf("\nElement group %i is NULL.\n",i);
  else
  {
    printf("\nElement group %i (named \"%s\"), element %s:\n",i,grp->name,grp->elspec);
    printelsurftop(grp);
  }
}
}


void printelgrp(femesh mesh,elgrp grp)
    /* Izpise vsebino objekta grp na mrezi mesh.
    $A Igor jul01; */
{
int i,j,num;
indtab it;
if (grp==NULL)
  printf("Element group pointer is NULL.\n\n");
else
{
  printf("Group name: \"%s\"\nElement type: \"%s\"\n",
  grp->name,grp->elspec);
  printelsurftop(grp);
  printf("\n");
  if (grp->eltop==NULL)
  {
    printf("Element topology is not specified.\n");
    if (grp->elnum!=NULL)
    {
      printf("\nElement numbers:\n");
      printindtabline(grp->elnum);
      printf("\n");
    }
  } else if (grp->eltop->n==0)
  {
    printf("There are no elements on topology stack.\n");
    if (grp->elnum!=NULL)
    {
      printf("\nElement numbers:\n");
      printindtabline(grp->elnum);
      printf("\n");
    }
  } else
  {
    if (prn)
    {
      printf("Element numbers for subsequent elements in the topology table:\n");
      printindtabline(grp->elnum);
    }
    if (grp->elnum==NULL)
      printf("Element numbers not specified, sequential numbers are used.\n");
    else  if (grp->elnum->n!=grp->eltop->n)
    {
      printf("WARNING: Dimension of element number table (%i) does not match number of elements",
       grp->elnum->n);
      printf("  in topology table  (%i).\n",grp->eltop->n);
    }
    printf("\nNumber of elements: %i.\nNodes constituting elements (%i/el.):\n",grp->eltop->n,grp->numelnod);
    printf("El. num.      Nodes\n");
    for (i=1;i<=grp->eltop->n;++i)
    {
      if (grp->elnum==NULL)
        printf("%-6i ",i);
      else if (grp->elnum->n<i)
        printf("%-6i ",i);
      else
        printf("%-6i ",grp->elnum->t[i]);
      if ((it=grp->eltop->s[i])!=NULL)
        for (j=1;j<=it->n;++j)
          printf(" %5i",it->t[j]);
      printf("\n");
    }
    printf("\n");
  }
  if (grp->outsurf==NULL)
    printf("Stack of outer element surfaces is NULL.\n");
  else if (grp->outsurf->n<1)
    printf("No data on the stack of outer element surfaces.\n");
  else
  {
    printf("Outer element surfaces - new way:\n");
    num=0;
    for (i=1;i<=femnumelements(grp);++i)
    {
      printf("Element %i: ",i);
      if (stackel(grp->outsurf,i)==NULL)
        printf(" table is NULL.");
      for (j=1;j<=femnumelsurf(grp,i);++j)
        if (femelsurfext(mesh,grp,i,j))
        {
          printf(" %i",j);
          ++num;
        }
      printf("\n");
    }
    printf("%i outer surfaces found.\n",num);


    /*
    printf("Outer element surfaces:\n");
    num=0;
    for (i=1;i<=grp->outsurf->n;++i)
    {
      if ((it=stackel(grp->outsurf,i))==NULL)
      {
        printf("Element %i: table of outer surfaces is NULL.",i);
      } else
      {
        n=0;
        for (j=1;j<=it->n;++j)
          if (it->t[j])
          {
            ++n;
            ++num;
          }
        if (n)
        {
          printf("Element %i: ",i);
          for (j=1;j<=it->n;++j)
            if (it->t[j])
              printf("%i ",j);
        } else
          printf("Element %i: -",i);
      }
      printf("\n");
    }
    printf("%i outer surfaces found.\n",num);
    */
  }
}
}



void printfemesh(femesh mesh)
    /* Izpise vsebino objekta mesh, izpise tudi topologije elementov vseh
    skupin elementov, ki so na mesh.
    $A Igor jul01; */
{
int i,j;
if (mesh==NULL)
  printf("FEM mesh pointer is NULL.\n");
else
{
  /* Izpis vozlisc: */
  if (mesh->nodnum==NULL)
    printf("Table of node numbers is NULL.\n\n");
  else if (mesh->nodnum->n==0)
    printf("There are no nodes on node table.\n\n");
  else
  {
    printf("Table of nodes (%i nodes):\n",mesh->nodnum->n);
    for (i=1;i<=mesh->nodnum->n;++i)
    {
      printf("%6i ",mesh->nodnum->t[i]);
      if (i%10==0)
        printf("\n");
    }
    printf("\n\n");
  }
  if (mesh->nodcoord!=NULL)
  {
    if (mesh->nodnum!=NULL)
      if (mesh->nodnum->n!=mesh->nodcoord->d1)
      {
        printf("Warning: Number of coordinates in node number table (%i) differs from number in\n",
         mesh->nodnum->n);
        printf("coordinate matrix (%i).\n",mesh->nodcoord->d1);
      }
    printf("Node coordinates:\n");
    printf("Nod. num.     Coordinates\n");
    for (i=1;i<=mesh->nodcoord->d1;++i)
    {
      if (mesh->nodnum==NULL)
        printf("%-6i ",i);
      else if (mesh->nodnum->n<i)
        printf("%-6i ",i);
      else
        printf("%-6i ",mesh->nodnum->t[i]);
      for (j=1;j<=mesh->nodcoord->d2;++j)
        printf(" %10.8g",mesh->nodcoord->m[i][j]);
      printf("\n");
    }
    printf("\n");
  }
  if (mesh->nodnuminv==NULL)
    printf("Inverse table of node numbers is NULL.\n");
  else if (mesh->nodnuminv->n<1)
    printf("Inverse table of node numbers has no elements.\n");
  else
    printf("Inverse table of node numbers is allocated.\n");
  if (mesh->elgrpinv==NULL)
    printf("Tables of element locations are NULL.\n\n");
  else if (mesh->elgrpinv->n==0)
    printf("There are no elements on tables of element locations.\n\n");
  else
  {
    if (mesh->elnuminv==NULL)
      printf("Element locations: indices are NULL!\n");
    else if (mesh->elnuminv->n != mesh->elgrpinv->n)
      printf("Element locations: Table of indices has different dimension \nthan table of groups!\n");
    else
    {
      printf("Table of element locations (size: %i):\n%10s %10s %10s\n",
        mesh->elgrpinv->n,"el. num.","el. group","index in the group");
      for (i=1;i<=mesh->elgrpinv->n;++i)
      {
        printf("%10i %10i %10i\n",i,mesh->elgrpinv->t[i],mesh->elnuminv->t[i]);
        /* if (i%10==0)
          printf("\n");
        */
      }
      printf("\n\n");
    }
  }
  if (mesh->eltopinv==NULL)
    printf("Lists of elements that contain given nodes are not allocated.\n");
  else if (mesh->eltopinv->n<1)
    printf("There are no lists of element that contain given nodes.\n");
  else
  {
    indtab it;
    int nodenum;
    printf("Lists of elements that contain given nodes:\n");
    for (i=1;i<=mesh->eltopinv->n;++i)
    {
      nodenum=femnodenum(mesh,i);
      it=mesh->eltopinv->s[i];
      printf("%3i.: node %i, el.:",i,nodenum);
      if (it==NULL)
        printf(" List is NULL.");
      else for (j=1;j<=it->n;++j)
      {
        printf(" %i",it->t[j]);
        if (j<it->n)
          printf(",");
      }
      printf("\n");
    }
    printf("\n\n");
  }
  if (mesh->elgrp==NULL)
    printf("Stack of element groups is NULL.\n\n");
  else if (mesh->elgrp->n==0)
    printf("There are no element groups on the stack.\n\n");
  else
  {
    for (i=1;i<=mesh->elgrp->n;++i)
    {
      printf("\nELEMENT GROUP %i:\n",i);
      printelgrp(mesh,mesh->elgrp->s[i]);
    }
    printf("\n");
  }
}
}




typedef struct {
    indtab it;  /* sortirana indeksna tabela vozlisc */
    int *fp;    /* kazalec na flag, ki pove, ali je povrsina zunanja ali ne */
} _elsurftype;

typedef _elsurftype *elsurftype;

static elsurftype newelsurftype(int excess,int r,int n)
    /* Naredi nov objekt tipa elsurftype z alocirano indeksno tabelo, excess in
    r sta ustrezna parametra pri alokaciji indeksne tabele, na n pa se postavi.
    stevilo elementov indeksne tabele.
    $A Igor avg01; */
{
elsurftype ret;
ret=malloc(sizeof(*ret));
ret->it=newindtab(excess,r);
ret->it->n=n;
ret->fp=NULL;
return ret;
}

static void dispelsurftype(elsurftype *el)
    /* Zbrise objekt, na katerega kaze *el, in postavi *el na NULL. Ne brise se
    tisto, na kar kaze (*el)->fp, ker je to samo kazalec na flag, ki se ne
    alocira v povezavi z objektom.
    $A Igor avg01; */
{
if (el!=NULL)
{
  if (*el!=NULL)
  {
    dispindtab(&((*el)->it));
    free(*el);
  }
  *el=NULL;
}
}



static int cmpelsurftype(void *p1,void *p2)
    /* Primerja kazalca p1 in p2 tipa elsurftype po soleznih stevilkah vozlisc
    na (...)->name. Ce sta p1 in p2 NULL, vrne funkcija 0, ce je le p1 NULL,
    vrne 2 (v tem primeru se smatra, da je p1 vecji od p2), ce pa je le p2 NULL,
    vrne -2. Podobno velja, ce je pri katerem od p1 ali p2 (...)->it enak NULL,
    le da se v tem primeru vrne -3 ali 3 ali 0. Funkcija vrne 1, ce je p1 vecji
    od p2, -1, ce je p2 vecji od p1, in 0, ce sta enaka po primerjavi elementov
    indeksne tabele (...)->it. Primerjavo odloci prvi element it, ki ni enak pri
    obeh objektih.
    $A Igor avg01; */
{
elsurftype o1,o2;
indtab it1,it2;
int i;
o1=p1; o2=p2;
if (o1!=NULL && o2!=NULL)
{
  it1=o1->it;
  it2=o2->it;
  if (it1!=NULL && it2!=NULL)
  {
    for (i=1;i<=it1->n && i<=it2->n;++i)
      if (it1->t[i]>it2->t[i])
        return 1;
      else if (it1->t[i]<it2->t[i])
        return -1;
    if (it1->n=it2->n)
      return 0;
    else if (it1->n>it2->n)
      return 1;
    else
      return -1;
  } else if (it1==NULL)
  {
    if (it2==NULL)
      return 0;
    else
      return 3;
  } else if (it2==NULL)
    return -3;
} else if (o1==NULL)
{
  if (o2==NULL)
    return 0;
  else
    return 2;
} else if (o2==NULL)
  return -2;
return -2; /* samo zaradi prevajalnika */
}


int identifyfemeshsurfold(femesh fm)
    /* V mrezi koncnih elementov identificira vse tiste povrsine elementov, ki
    so zunanje povrsine za objekte iz koncnih elementov na fm. Funkcija deluje
    podobno kot identifyfemeshsurfgrpold, le da poisce zunanje povrsine celotne
    mreze koncnih elementov na fm in ne za vsako skupino elementov na fm
    posebej.
    Funkcija vrne stevilo vseh odkritih zunanjih povrsin oz. -1, ce pride
    pri izvedbi do napake.
    $A Igor avg01; */
{
int ret=0,i,j,k,l,num,numnodes,maxsurf,place;
indtab itaux,it,itsurf,itflag;
stack surf=NULL;
elsurftype elsurf=NULL,elsurfref;
elgrp grp;
if (prn)
  printf("Identifying outer element surfaces of the whole finite elsment mesh...\n");
if (fm==NULL)
{
  errfunc0("identifyfemeshsurfold");
  sprintf(ers(),"Address of mesh data storage is NULL.\n");
  errfunc2();
  ret=-1;
} else if (fm->elgrp==NULL)
{
  errfunc0("identifyfemeshsurfold");
  sprintf(ers(),"There are no element groups on the mesh data structure.\n");
  errfunc2();
  ret=-1;
} else if (fm->elgrp->n<1)
{
  errfunc0("identifyfemeshsurfold");
  sprintf(ers(),"There are no element groups on the mesh data structure.\n");
  errfunc2();
  ret=-1;
} else
{
  numnodes=0;
  if (fm->nodnum!=NULL)
    numnodes=fm->nodnum->n;
  else if (fm->nodcoord!=NULL)
    numnodes=fm->nodcoord->d1;
  if (numnodes==0)
  {
    errfunc0("identifyfemeshsurfold");
    sprintf(ers(),"There are no nodes on the mesh data structure.\n");
    errfunc2();
    ret=-1;
  } else if (!ret)
  {
    /* Ugotovi se najvecje mozno stevilo elementov na skladu surf: */
    num=0;
    for (i=1;i<=fm->elgrp->n;++i)
      if ((grp=fm->elgrp->s[i])!=NULL)
      {
        if (grp->surftop==NULL)
          ;
        else if (grp->surftop->n<1)
          ;
        else
        {
          num+=grp->eltop->n*grp->surftop->n;
        }
    /* Alocira se sklad, na katerega se bodo nalagali sortirani podatki
    o povrsinah elementov za alokacijo skupnih povrsin; alocira se
    dovolj prostora za vse elemente sklada: */
    surf=newstackr(100,num);
    for (i=1;i<=fm->elgrp->n;++i)
      if ((grp=fm->elgrp->s[i])!=NULL)
      {
        if (grp->surftop==NULL)
        {
          errfunc0("identifyfemeshsurfold");
          sprintf(ers(),"Element surface topology for element group %i is not defined.\n",i);
          errfunc2();
          ret=-1;
        } else if (grp->surftop->n<1)
        {
          errfunc0("identifyfemeshsurfold");
          sprintf(ers(),"Element surface topology for element group %i is not defined correctly.\n",i);
          errfunc2();
          ret=-1;
        } else
        {
          /* Identifikacija zun. povrsin za skupino elementov grp: */
          if (prn)
          {
            printf("Identifying outer element surfaces for element group %i...\n",i);
            printf("Creating max. frequency table...\n");
          }
          /* Iteracija po elementih in skupine in dolocanje zunanjih povrsin: */
          if (prn)
            printf("Identifying outer surfaces...\n");
          if (grp->outsurf==NULL)
            grp->outsurf=newstackr(50,grp->eltop->n);
          else
            dispstackvalspec(grp->outsurf,(void (*) (void **)) dispindtab);
          /* Ugotovi se najvecje stevilo vozlisc na katerikoli povrsini
          elementa in stevilo povrsin elementa (zaradi velikosti sklada): */
          maxsurf=0;
          num=grp->surftop->n;
          for (l=1;l<num;++l)
          {
            itaux=stackel(grp->surftop,l);
            if (itaux!=NULL)
              if (itaux->n>maxsurf)
                maxsurf=itaux->n;
          }
          num=0; /* stevec vseh zun. povrsin na skupini elementov: */
          for (j=1;j<=grp->eltop->n;++j) /* iteracija po elementih: */
          {
            if ((it=grp->eltop->s[j])!=NULL)
            {
              /* Kreira se indeksna tabela, katere elementi dolocajo zunanje
              (ce so 1) oz. notranje (ce so 0) povrsine elementa in se porine
              na sklad grp->outsurf: */
              pushstack(grp->outsurf,itflag=newindtab(0,grp->surftop->n));
              itflag->n=grp->surftop->n;
              for (k=1;k<=grp->surftop->n;++k)
              {
                if ((itsurf=stackel(grp->surftop,k))!=NULL)
                {
                  /* Preveri se k-ta povrsina; vozlisca povrsine se dajo na
                  indeksno tabelo in se sortirajo, indeksna tabela pa se
                  postavi na sklad surf. */
                  itflag->t[k]=0;
                  if (elsurf==NULL)
                  {
                    /* Rezervira se prostor, kamor se bo nalozilo stevilke
                    vozlisc povrsine elementa za iskanje, ce je ista povrsina
                    vsebovana se v kaksnem drugem elementu; Rezervira se
                    prostor za maksimalno stevilo vozlisc na katerikoli
                    povrsini, da se bo lahko prostor uporabil se za kaksno drugo
                    povrsino, ce te ne bo potrebno sgraniti na sklad: */
                    elsurf=newelsurftype(1,maxsurf,itsurf->n);
                  } else
                    elsurf->it->n=itsurf->n;
                  for (l=1;l<=itsurf->n;++l)
                    if (it->n<itsurf->t[l] || itsurf->t[l]<1)
                    {
                      errfunc0("identifyfemeshsurfold");
                      sprintf(ers(),"Local node index %i, surface %i, is out of range (%i) for element %i.\n",
                       itsurf->t[l],k,it->n,j);
                      errfunc2();
                      ret=-1;
                    } else
                      elsurf->it->t[l]=it->t[itsurf->t[l]];
                  sortindtab(elsurf->it);
                  /* Po potrebi se ali da podatke o povrsini na sklad ali
                  ugotovi, da dana povrsina ni zunanja: */
                  place=placesortstack(surf,elsurf,(int (*)(void *,void *)) cmpelsurftype);
                  if (!(cmpelsurftype(elsurf,(elsurfref=stackel(surf,place-1)))))
                  {
                    /* povrsina, ki je na skladu surf predstavljena z
                    elsurfref, ni zunanja, ker je vsebovana tudi v elementu,
                    ki ga trenutno preverjamo; objekt elsurf bomo lahko
                    uporabili se za druge povrsine. */
                    if (*(elsurfref->fp)>0)
                    {
                      *(elsurfref->fp)=0;
                      --num;
                    }
                    itflag->t[k]=0; /* tudi trenut. povrsina ni zunanja */
                  }
                  else if (!(cmpelsurftype(elsurf,(elsurfref=stackel(surf,place)))))
                  {
                    /* povrsina, ki je na skladu surf predstavljena z
                    elsurfref, ni zunanja, ker je vsebovana tudi v elementu,
                    ki ga trenutno preverjamo; objekt elsurf bomo lahko
                    uporabili se za druge povrsine. */
                    if (*(elsurfref->fp)>0)
                    {
                      *(elsurfref->fp)=0;
                      --num;
                    }
                    itflag->t[k]=0; /* tudi trenut. povrsina ni zunanja */
                  }
                  else
                  {
                    /* Na skladu se ni povrsine z istimi vozlisci: */
                    itflag->t[k]=1; /* zaenkrat bi lahko bila zun. povrsina */
                    ++num;
                    elsurf->fp=&(itflag->t[k]);
                    insstack(surf,elsurf,place);
                    elsurf=NULL; /* prostor je ze uporabljen */
                  }
                } else
                {
                  errfunc0("identifyfemeshsurfold");
                  sprintf(ers(),"Error in surface topology of element group %i: surface %i not defined.\n",
                   i,k);
                  errfunc2();
                  ret=-1;
                  itflag->t[k]=0;
                  dispstackvalspec(grp->outsurf,(void (*) (void **)) dispindtab);
                  return ret;
                }
              }
            } else
              pushstack(grp->outsurf,NULL);
          }
          dispelsurftype(&elsurf);
          if (ret>=0 && num>0)
            ret+=num;
          if (prn)
            printf("%i outer surfaces identified.\n",num);
          if (prn)
            printf("\nElenment group %i finished.\n",i);
        }
      }
    dispstackallspec(&surf,(void (*)(void **)) dispelsurftype);
  }
}
if (prn)
  printf("Identification of outer surfaces finished.\n");
}
/* Compatibility insurance: */
for (i=1;i<=fm->elgrp->n;++i)
{
  grp=fm->elgrp->s[i];
  for (j=1;j<=grp->outsurf->n;++j)
  {
    it=grp->outsurf->s[j];
    itaux=newindtab(4,4);
    for (k=1;k<=it->n;++k)
      if (it->t[k])
        pushindtab(itaux,k);
    if (itaux->n==0)
      dispindtab(&itaux);
    grp->outsurf->s[j]=itaux;
    dispindtab(&it);
  }
}
return (ret);
}



int identifyfemeshsurfgrpold(femesh fm)
    /* V mrezi koncnih elementov identificira vse tiste povrsine elementov, ki
    so zunanje povrsine za skupine koncnih elementov na fm. Funkcija tvori za
    posamezne povrsine podatkovne strukture, na katerih sortirane stevilke
    vozlisc na povrsini (stevilke se vzamejo kar iste kot so na skladu
    (...)->eltop skupine, saj tu ni potrebno vedeti dejanskih stevilk vozlisc,
    ki se v splosnem dobijo preko fm->nodnuminv). Tako lahko funkcija primerja
    povrsine razlicnih elementov in ugotovi, ali gre pri dveh povrsinah
    razlicnega elementa fizicno za isto povrsino. Povrsine, ki so prvic
    identificirane, se nalozijo na sklad, da se lahko pri povrsinah, ki so
    identificirane kasneje, ugotovi, ali dana povrsina obstaja ze pri kaksnem
    drugem elementu. Zunanje povrsine skupine elementov so namrec le tiste, ki
    nastopajo v enem samem elementu.
    Funkcija vrne stevilo vseh odkritih zunanjih povrsin oz. -1, ce pride
    pri izvedbi do napake.
    $A Igor avg01; */
{
int ret=0,i,j,k,l,num,numnodes,maxsurf,place;
indtab itaux,it,itsurf,itflag;
stack surf=NULL;
elsurftype elsurf=NULL,elsurfref;
elgrp grp;
if (prn)
  printf("Identifying outer element surfaces for element groups of the finite elsment mesh...\n");
if (fm==NULL)
{
  errfunc0("identifyfemeshsurfgrpold");
  sprintf(ers(),"Address of mesh data storage is NULL.\n");
  errfunc2();
  ret=-1;
} else if (fm->elgrp==NULL)
{
  errfunc0("identifyfemeshsurfgrpold");
  sprintf(ers(),"There are no element groups on the mesh data structure.\n");
  errfunc2();
  ret=-1;
} else if (fm->elgrp->n<1)
{
  errfunc0("identifyfemeshsurfgrpold");
  sprintf(ers(),"There are no element groups on the mesh data structure.\n");
  errfunc2();
  ret=-1;
} else
{
  numnodes=0;
  if (fm->nodnum!=NULL)
    numnodes=fm->nodnum->n;
  else if (fm->nodcoord!=NULL)
    numnodes=fm->nodcoord->d1;
  if (numnodes==0)
  {
    errfunc0("identifyfemeshsurfgrpold");
    sprintf(ers(),"There are no nodes on the mesh data structure.\n");
    errfunc2();
    ret=-1;
  } else if (!ret)
  {
    for (i=1;i<=fm->elgrp->n;++i)
      if ((grp=fm->elgrp->s[i])!=NULL)
      {
        if (grp->surftop==NULL)
        {
          errfunc0("identifyfemeshsurfgrpold");
          sprintf(ers(),"Element surface topology for element group %i is not defined.\n",i);
          errfunc2();
          ret=-1;
        } else if (grp->surftop->n<1)
        {
          errfunc0("identifyfemeshsurfgrpold");
          sprintf(ers(),"Element surface topology for element group %i is not defined correctly.\n",i);
          errfunc2();
          ret=-1;
        } else
        {
          /* Identifikacija zun. povrsin za skupino elementov grp: */
          if (prn)
          {
            printf("Identifying outer element surfaces for element group %i...\n",i);
            printf("Creating max. frequency table...\n");
          }
          /* Iteracija po elementih in skupine in dolocanje zunanjih povrsin: */
          if (prn)
            printf("Identifying outer surfaces...\n");
          if (grp->outsurf==NULL)
            grp->outsurf=newstackr(50,grp->eltop->n);
          else
            dispstackvalspec(grp->outsurf,(void (*) (void **)) dispindtab);
          /* Ugotovi se najvecje stevilo vozlisc na katerikoli povrsini
          elementa in stevilo povrsin elementa (zaradi velikosti sklada): */
          maxsurf=0;
          num=grp->surftop->n;
          for (l=1;l<num;++l)
          {
            itaux=stackel(grp->surftop,l);
            if (itaux!=NULL)
              if (itaux->n>maxsurf)
                maxsurf=itaux->n;
          }
          /* Alocira se sklad, na katerega se bodo nalagali sortirani podatki
          o povrsinah elementov za alokacijo skupnih povrsin; alocira se
          dovolj prostora za vse elemente sklada: */
          surf=newstackr(100,1+num*grp->eltop->n);
          num=0; /* stevec vseh zun. povrsin na skupini elementov: */
          for (j=1;j<=grp->eltop->n;++j) /* iteracija po elementih: */
          {
            if ((it=grp->eltop->s[j])!=NULL)
            {
              /* Kreira se indeksna tabela, katere elementi dolocajo zunanje
              (ce so 1) oz. notranje (ce so 0) povrsine elementa in se porine
              na sklad grp->outsurf: */
              pushstack(grp->outsurf,itflag=newindtab(0,grp->surftop->n));
              itflag->n=grp->surftop->n;
              for (k=1;k<=grp->surftop->n;++k)
              {
                if ((itsurf=stackel(grp->surftop,k))!=NULL)
                {
                  /* Preveri se k-ta povrsina; vozlisca povrsine se dajo na
                  indeksno tabelo in se sortirajo, indeksna tabela pa se
                  postavi na sklad surf. */
                  itflag->t[k]=0;
                  if (elsurf==NULL)
                  {
                    /* Rezervira se prostor, kamor se bo nalozilo stevilke
                    vozlisc povrsine elementa za iskanje, ce je ista povrsina
                    vsebovana se v kaksnem drugem elementu; Rezervira se
                    prostor za maksimalno stevilo vozlisc na katerikoli
                    povrsini, da se bo lahko prostor uporabil se za kaksno drugo
                    povrsino, ce te ne bo potrebno sgraniti na sklad: */
                    elsurf=newelsurftype(1,maxsurf,itsurf->n);
                  } else
                    elsurf->it->n=itsurf->n;
                  for (l=1;l<=itsurf->n;++l)
                    if (it->n<itsurf->t[l] || itsurf->t[l]<1)
                    {
                      errfunc0("identifyfemeshsurfgrpold");
                      sprintf(ers(),"Local node index %i, surface %i, is out of range (%i) for element %i.\n",
                       itsurf->t[l],k,it->n,j);
                      errfunc2();
                      ret=-1;
                    } else
                      elsurf->it->t[l]=it->t[itsurf->t[l]];
                  sortindtab(elsurf->it);
                  /* Po potrebi se ali da podatke o povrsini na sklad ali
                  ugotovi, da dana povrsina ni zunanja: */
                  place=placesortstack(surf,elsurf,(int (*)(void *,void *)) cmpelsurftype);
                  if (!(cmpelsurftype(elsurf,(elsurfref=stackel(surf,place-1)))))
                  {
                    /* povrsina, ki je na skladu surf predstavljena z
                    elsurfref, ni zunanja, ker je vsebovana tudi v elementu,
                    ki ga trenutno preverjamo; objekt elsurf bomo lahko
                    uporabili se za druge povrsine. */
                    if (*(elsurfref->fp)>0)
                    {
                      *(elsurfref->fp)=0;
                      --num;
                    }
                    itflag->t[k]=0; /* tudi trenut. povrsina ni zunanja */
                  }
                  else if (!(cmpelsurftype(elsurf,(elsurfref=stackel(surf,place)))))
                  {
                    /* povrsina, ki je na skladu surf predstavljena z
                    elsurfref, ni zunanja, ker je vsebovana tudi v elementu,
                    ki ga trenutno preverjamo; objekt elsurf bomo lahko
                    uporabili se za druge povrsine. */
                    if (*(elsurfref->fp)>0)
                    {
                      *(elsurfref->fp)=0;
                      --num;
                    }
                    itflag->t[k]=0; /* tudi trenut. povrsina ni zunanja */
                  }
                  else
                  {
                    /* Na skladu se ni povrsine z istimi vozlisci: */
                    itflag->t[k]=1; /* zaenkrat bi lahko bila zun. povrsina */
                    ++num;
                    elsurf->fp=&(itflag->t[k]);
                    insstack(surf,elsurf,place);
                    elsurf=NULL; /* prostor je ze uporabljen */
                  }
                } else
                {
                  errfunc0("identifyfemeshsurfgrpold");
                  sprintf(ers(),"Error in surface topology of element group %i: surface %i not defined.\n",
                   i,k);
                  errfunc2();
                  ret=-1;
                  itflag->t[k]=0;
                  dispstackvalspec(grp->outsurf,(void (*) (void **)) dispindtab);
                  return ret;
                }
              }
            } else
              pushstack(grp->outsurf,NULL);
          }
          dispstackallspec(&surf,(void (*)(void **)) dispelsurftype);
          dispelsurftype(&elsurf);
          if (ret>=0 && num>0)
            ret+=num;
          if (prn)
            printf("%i outer surfaces identified.\n",num);
          if (prn)
            printf("\nElenment group %i finished.\n",i);
        }
      }
  }
}
if (prn)
  printf("Identification of outer surfaces finished.\n");
/* Compatibility insurance: */
for (i=1;i<=fm->elgrp->n;++i)
{
  grp=fm->elgrp->s[i];
  for (j=1;j<=grp->outsurf->n;++j)
  {
    it=grp->outsurf->s[j];
    itaux=newindtab(4,4);
    for (k=1;k<=it->n;++k)
      if (it->t[k])
        pushindtab(itaux,k);
    if (itaux->n==0)
      dispindtab(&itaux);
    grp->outsurf->s[j]=itaux;
    dispindtab(&it);
  }
}
return (ret);
}




int identifyfemeshsurfgrp(femesh fm)
{
return identifyfemeshsurfgrpold(fm);
}

int identifyfemeshsurf(femesh fm)
{
return identifyfemeshsurfold(fm);
/*
femcalcoutsurf(fm,0);
return 1;
*/
}



int identifyfemeshsurfstruct(femesh fm)
    /* V strukturirani (!) mrezi koncnih elementov identificira vse tiste
    povrsine elementov, ki so zunanje povrsine za celotno mrezo koncnih
    elementov fm. Zunanje povrsine se identificirajo glede na to, koliko
    elementom pripadajo vozlisca na posamezni povrsini elementa. Ce vsa
    vozlisca na povrsini pripadajo manj elementom kot je najvecje ugotovljeno
    stevilo v dani skupini elementov za doloceno vozlisce elementa, potem se
    povrsina steje za zunanjo. Zaradi morebitnega napacnega delovanja pri
    primerih, kjer so objekti npr. sestavljeni le iz dveh plasti elementov in
    se lahko zgodi, da za kaksno vozlisce stevilo pojavov v nobenem elementu
    ni vecje kot ce to vozlisce pripada zunanji povrsini (ker je stevilcenje
    taksno, da je se dolocena povrsina elementa nikoli ne pojavi kot notranja,
    kar je pri taksnih degeneriranih primerih mozno), se preveri, ali je
    funkcija nasla vsaj pricakovano povrsino zunanjih povrsin; Ce ni, se
    kriterij sprosti tako, da se povrsina spozna za zunanjo, ce ima ima vsaj
    polovica vozlisc manj kot maks. st. pojavov. Vseeno v taksnih primerih
    uporaba funkcije ni zanesljiva in je bolje uporabiti funkcije za
    nestrukturirano mrezo, ki so cisto splosne, a zato pocasnejse.
    Ta funkcija obravnava vse skupine elementov skupaj, ne loceno, zato se
    mejne povrsine med posameznimi skupinami elementov ne stejejo za zunanje
    povrsine. Funkcija vrne stevilo vseh odkritih zunanjih povrsin oz. -1, ce
    pride pri izvedbi do napake.
    $A Igor jul01; */
{
int ret=0,i,j,k,l,n,num,numnodes,nmin,nmax;
indtab freq=NULL,it,itsurf,itflag,itmin,itmax;
elgrp grp;
if (prn)
  printf("Identifying outer element surfaces for whole mesh...\n");
if (fm==NULL)
{
  errfunc0("identifyfemeshsurfstruct");
  sprintf(ers(),"Address of mesh data storage is NULL.\n");
  errfunc2();
  ret=-1;
} else if (fm->elgrp==NULL)
{
  errfunc0("identifyfemeshsurfstruct");
  sprintf(ers(),"There are no element groups on the mesh data structure.\n");
  errfunc2();
  ret=-1;
} else if (fm->elgrp->n<1)
{
  errfunc0("identifyfemeshsurfstruct");
  sprintf(ers(),"There are no element groups on the mesh data structure.\n");
  errfunc2();
  ret=-1;
} else
{
  numnodes=0;
  if (fm->nodnum!=NULL)
    numnodes=fm->nodnum->n;
  else if (fm->nodcoord!=NULL)
    numnodes=fm->nodcoord->d1;
  if (numnodes==0)
  {
    errfunc0("identifyfemeshsurfstruct");
    sprintf(ers(),"There are no nodes on the mesh data structure.\n");
    errfunc2();
    ret=-1;
  } else
  {
    /* Najprej se naredi indeksna tabela, ki za vsako vozlisce meri stevilo
    njegovih pojavov v elementih vseh skupin: */
    femcalcnodnuminv(fm);  /* inverz. ind. tab. za st. vozlisc */
    if (prn)
      printf("Creating frequency table...\n");
    freq=newindtab(0,numnodes);
    freq->n=numnodes;
    for (i=1;i<=numnodes;++i)
      freq->t[i]=0;
    for (i=1;i<=fm->elgrp->n;++i)
      if ((grp=fm->elgrp->s[i])!=NULL)
      {
        if (grp->eltop==NULL)
        {
          errfunc0("identifyfemeshsurfstruct");
          sprintf(ers(),"Element topology for element group %i is not defined.\n",i);
          errfunc2();
          ret=-1;
        } else if (grp->eltop->n<1)
        {
          errfunc0("identifyfemeshsurfstruct");
          sprintf(ers(),"Element topology for element group %i is not defined.\n",i);
          errfunc2();
          ret=-1;
        } else
        {
          /* Iterira se po vseh elementih skupine in se pristeva pojave vozlisc
          na indeksni tabeli freq: */
          for (j=1;j<=grp->eltop->n;++j)
          {
            if ((it=grp->eltop->s[j])!=NULL)
              for (k=1;k<=it->n;++k)
              {
                if (fm->nodnuminv!=NULL)
                  n=fm->nodnuminv->t[it->t[k]];
                else
                  n=it->t[k];
                ++freq->t[n];
              }
          }
        }
      }
    if (!ret)
    {
      for (i=1;i<=fm->elgrp->n;++i)
        if ((grp=fm->elgrp->s[i])!=NULL)
        {
          if (grp->surftop==NULL)
          {
            errfunc0("identifyfemeshsurfstruct");
            sprintf(ers(),"Element surface topology for element group %i is not defined.\n",i);
            errfunc2();
            ret=-1;
          } else if (grp->surftop->n<1)
          {
            errfunc0("identifyfemeshsurfstruct");
            sprintf(ers(),"Element surface topology for element group %i is not defined correctly.\n",i);
            errfunc2();
            ret=-1;
          } else
          {
            /* Identifikacija zun. povrsin za skupino elementov grp: */
            if (prn)
            {
              printf("Identifying outer element surfaces for element group %i...\n",i);
              printf("Creating max. frequency table...\n");
            }
            /* Izdelava tabele maksimalnih pogostnosti za lokal. st. vozlisc: */
            itmax=newindtab(0,grp->numelnod);
            itmax->n=grp->numelnod;
            for (k=1;k<=itmax->n;++k)
              itmax->t[k]=0;
            /* Izdelava tabele minmalnih pogostnosti za lokal. st. vozlisc: */
            itmin=newindtab(0,grp->numelnod);
            itmin->n=grp->numelnod;
            for (k=1;k<=itmax->n;++k)
              itmin->t[k]=30000;
            /* Iteracija po elementih skupine in zapisovanje maks. st. pojavov
            dolocenega lokalnega vozlisca v kateremkoli elementu v itmax: */
            for (j=1;j<=grp->eltop->n;++j)
            {
              if ((it=grp->eltop->s[j])!=NULL)
                for (k=1;k<=it->n;++k)
                {
                  if (fm->nodnuminv!=NULL)
                    n=fm->nodnuminv->t[it->t[k]];
                  else
                    n=it->t[k];
                  if (freq->t[n]>itmax->t[k])
                    itmax->t[k]=freq->t[n];
                  /* Najmanjsega pojava ne stejemo, ce se dano vozlisce na
                  povrsini pojavi samo enkrat: */
                  if ( /* freq->t[n]>1 && */ freq->t[n]<itmin->t[k])
                    itmin->t[k]=freq->t[n];
                }
            }
            /* Izracun polovic. maks. st. pojavov posameznega niza - povprecja med
            maks. in min. pojavom, po potrebi zaokrozeno navzdol:*/
            if (prn)
            {
              printf("Number of appearances of nodes:\n");
              printindtabline(freq);
              printf("Max. number of appearances of element nodes in different elements:\n");
              for (l=1;l<=itmax->n;++l)
                printf("Element node %i: %i times.\n",l,itmax->t[l]);
              printf("Min. number of appearances of element nodes in different elements:\n");
              for (l=1;l<=itmax->n;++l)
                printf("Element node %i: %i times.\n",l,itmin->t[l]);
            }
            /* Iteracija po elementih in skupine in dolocanje zunanjih povrsin: */
            if (prn)
              printf("Identifying outer surfaces...\n");
            if (grp->outsurf==NULL)
              grp->outsurf=newstackr(50,grp->eltop->n);
            else
              dispstackvalspec(grp->outsurf,(void (*) (void **)) dispindtab);
            num=0; /* stevec vseh zun. povrsin na skupini elementov: */
            for (j=1;j<=grp->eltop->n;++j)
            {
              if ((it=grp->eltop->s[j])!=NULL)
              {
                /* Kreira se indeksna tabela, katere elementi dolocajo zunanje
                (ce so 1) oz. notranje (ce so 0) povrsine elementa in se porine
                na sklad grp->outsurf: */
                pushstack(grp->outsurf,itflag=newindtab(0,grp->surftop->n));
                itflag->n=grp->surftop->n;
                for (k=1;k<=grp->surftop->n;++k)
                {
                  if ((itsurf=stackel(grp->surftop,k))!=NULL)
                  {
                    /* Preveri se k-ta povrsina, za vsa vozlisca povrsine se
                    preveri, ce so res vsebovana v manj elementih kot je maks.
                    st; najprej se privzame, da je povrsina zunanja: */
                    nmin=nmax=0;
                    itflag->t[k]=0;
                    for (l=1;l<=itsurf->n;++l)
                    {
                      /* indeks l-tega vozlisca na k-ti povrsini j-tega
                      elementa: */
                      if (fm->nodnuminv!=NULL)
                        n=fm->nodnuminv->t[it->t[itsurf->t[l]]];
                      else
                        n=it->t[itsurf->t[l]];
                      /* Preveri se, ce je st. pojavov tega vozlisca enako maks.
                      ali min. st. pojavov tega vozlisca v kateremkoli elementu
                      oz. ce je vecje od min. st. pojavov tega vozlisca. */
                      if (freq->t[n]==itmax->t[itsurf->t[l]])
                        ++nmax;
                    }
                    /* Preverjanje kriterija za to, ce je dana povrsina elementa
                    zunanja: */
                    if (nmax==0)
                    {
                      itflag->t[k]=1;
                      ++num;
                    }
                  } else
                  {
                    errfunc0("identifyfemeshsurfstruct");
                    sprintf(ers(),"Error in surface topology of element group %i: surface %i not defined.\n",
                     i,k);
                    errfunc2();
                    ret=-1;
                    itflag->t[k]=0;
                    dispstackvalspec(grp->outsurf,(void (*) (void **)) dispindtab);
                    return ret;
                  }
                }
              } else
                pushstack(grp->outsurf,NULL);
            }
            if (num<=m_sqr(grp->surftop->n) && num<grp->eltop->n)
            {
              /* Ce st. identificiranih zunanjih povrsin ni vecje od stevila
              povrsin elementa, verjetno nekaj ni v redu. Mozno je, da skupina
              predstavlja tnko plast (najvec dva elementa po debelini), tako
              da obstajajo vozlisca elementa, ki nikoli niso notranja, tako da
              je njihovo maks. st. pojavov enako st. pojavov, ko je taksno
              vozlisce del zunanje povrsine. Tako je skoraj vedno izkljucujoc
              pogoj, da mora biti stevilo pojavov vseh vozlisc na zunanji
              povrsini manjse kot pri notranjih povrsinah. Zato se v tem
              primeru se enkrat ziterira cez elemente in se postavi pogoj za
              zunanjo povrsino, da ima vsaj eno vozliscepovrsine  manj pojavov
              kot je maks. stevilo pojavov za to vozlisce elementa: */
              if (prn)
                printf("Only %i outer surfaces identified, taking milder criterium...\n",
                 num);
              num=0;
              for (j=1;j<=grp->eltop->n;++j)
              {
                if ((itflag=stackel(grp->outsurf,j))!=NULL)
                {
                  for (k=1;k<=grp->surftop->n;++k)
                  {
                    if ((itsurf=stackel(grp->surftop,k))!=NULL)
                    {
                      /* Ponovno se preveri k-ta povrsina z novim kriterijem: */
                      nmin=nmax=0;
                      itflag->t[k]=0;
                      for (l=1;l<=itsurf->n;++l)
                      {
                        /* indeks l-tega vozlisca na k-ti povrsini j-tega
                        elementa: */
                        if (fm->nodnuminv!=NULL)
                          n=fm->nodnuminv->t[it->t[itsurf->t[l]]];
                        else
                          n=it->t[itsurf->t[l]];
                        /* Preveri se, ce je st. pojavov tega vozlisca manjse od
                        maks. ali povprec. st. pojavov tega vozlisca v kateremkoli
                        elementu oz. ce je vecje od min. st. pojavov tega
                        vozlisca. */
                        if (freq->t[n]==itmax->t[itsurf->t[l]])
                        {
                          /* if (itmax->t[itsurf->t[l]]>itmin->t[itsurf->t[l]]) */
                            ++nmax;
                        }
                        if (freq->t[n]==itmin->t[itsurf->t[l]])
                          ++nmin;
                        /*
                        if (freq->t[n]<=itmin->t[itsurf->t[l]])
                          ++nmin;
                        if (freq->t[n]<=ithalf->t[itsurf->t[l]])
                          ++nav;
                        */
                      }
                      /* Preverjanje kriterija za to, ce je dana povrsina elementa
                      zunanja: */
                      if (nmax<=itsurf->n/2)
                      {
                        itflag->t[k]=1;
                        ++num;
                      } else if (nmin)
                        itflag->t[k]=0;
                    } else
                    {
                      errfunc0("identifyfemeshsurfstruct");
                      sprintf(ers(),"Error in surface topology of element group %i: surface %i not defined.\n",
                       i,k);
                      errfunc2();
                      ret=-1;
                      itflag->t[k]=0;
                      dispstackvalspec(grp->outsurf,(void (*) (void **)) dispindtab);
                      return ret;
                    }
                  }
                }
            }
              if (prn)
                printf("%i outer surfaces identified by milder criterium...\n",
                 num);
            }
            if (ret>=0)
              ret+=num;
            if (prn)
              printf("%i outer surfaces identified.\n",num);
            dispindtab(&itmax);
            dispindtab(&itmin);
            if (prn)
              printf("\nElenment group %i finished.\n",i);
          }
        }
    }
  }
}
dispindtab(&freq);
if (prn)
  printf("Identification of outer surfaces finished.\n");
return (ret);
}


    /*   BRANJE MREZ IZ ELFENOVIH DATOTEK (neutral format):   */


/* Nizi, ki oznacujejo dolocene stvari v datoteki: */

static char fileformat=0;  /* Oznaka formata; 1 za Elfenov neutral form. */
static stack 
             groupdatastr=NULL,
             groupnamestr=NULL,
             groupelspecstr=NULL,
             eldatastr=NULL,
             eltopstr=NULL,
             elnumstr=NULL,
             noddatastr=NULL,
             nodnumstr=NULL,
             nodcoordstr=NULL,
             elnodcomstr=NULL,
             groupcomstr=NULL,
             elcomstr=NULL,
             nodcomstr=NULL;

static char *numelstr=NULL,
            *numnodelstr=NULL,
            *numnodstr=NULL,
            *dimstr=NULL,
            *elgrpnumstr=NULL;


static void initelfstr(void)
    /* Ta funkcija postavi nize, ki oznacujejo polja v Elfenovih datotekah.
    Te stvari so devfinirane kot lokalne spremenljivke, ker se lahko imena z
    verzijami Elfena spreminjajo, poleg tega pa je lahko za isto polje vec imen.
    $A Igor jul01; */
{
int i;
if (fileformat!=1)
{
  fileformat=1; /* Elfenov neutral format */
  /* Na sklade se porinejo vse razlicice nizov, ki lahko oznacujejo doloceno
  polje (stare vrednosti se pred tem odstranijo): */
  popstackall(groupdatastr);
  if (groupdatastr==NULL)
    groupdatastr=newstack(2);
  pushstack(groupdatastr,"Element_group_data");
  popstackall(groupnamestr);
  if (groupnamestr==NULL)
    groupnamestr=newstack(2);
  pushstack(groupnamestr,"Group_name");
  popstackall(groupelspecstr);
  if (groupelspecstr==NULL)
    groupelspecstr=newstack(2);
  pushstack(groupelspecstr,"Element_type");
  popstackall(eldatastr);
  if (eldatastr==NULL)
    eldatastr=newstack(2);
  pushstack(eldatastr,"Element_data");
  popstackall(eltopstr);
  if (eltopstr==NULL)
    eltopstr=newstack(2);
  pushstack(eltopstr,"Element_topology");
  popstackall(elnumstr);
  if (elnumstr==NULL)
    elnumstr=newstack(2);
  pushstack(elnumstr,"Element_numbers");
  popstackall(noddatastr);
  if (noddatastr==NULL)
    noddatastr=newstack(2);
  pushstack(noddatastr,"Node_data");
  popstackall(nodnumstr);
  if (nodnumstr==NULL)
    nodnumstr=newstack(2);
  pushstack(nodnumstr,"Node_numbers");
  popstackall(nodcoordstr);
  if (nodcoordstr==NULL)
    nodcoordstr=newstack(2);
  pushstack(nodcoordstr,"Coordinates");
  /* Sklad, na katerem so vsa mozna imena, ki se ticejo ali podatkov o elementih
  ali podatkov o vozliscih: */
  popstackall(elnodcomstr);
  if (elnodcomstr==NULL)
    elnodcomstr=newstack(2);
  for (i=1;i<=groupdatastr->n;++i)
    pushstack(elnodcomstr,groupdatastr->s[i]);
  for (i=1;i<=eldatastr->n;++i)
    pushstack(elnodcomstr,eldatastr->s[i]);
  for (i=1;i<=noddatastr->n;++i)
    pushstack(elnodcomstr,noddatastr->s[i]);
  /* Sklad, na katerem so vsa mozna imena, ki dolocajo polja znotraj splosnih
  podatkov o skupini elementov: */
  popstackall(groupcomstr);
  if (groupcomstr==NULL)
    groupcomstr=newstack(2);
  for (i=1;i<=groupnamestr->n;++i)
    pushstack(groupcomstr,groupnamestr->s[i]);
  for (i=1;i<=groupelspecstr->n;++i)
    pushstack(groupcomstr,groupelspecstr->s[i]);
  /* Sklad, na katerem so vsa mozna imena, ki dolocajo polja znotraj podatkov
  o elementih: */
  popstackall(elcomstr);
  if (elcomstr==NULL)
    elcomstr=newstack(2);
  for (i=1;i<=eltopstr->n;++i)
    pushstack(elcomstr,eltopstr->s[i]);
  for (i=1;i<=eltopstr->n;++i)
    pushstack(elcomstr,eltopstr->s[i]);
  for (i=1;i<=elnumstr->n;++i)
    pushstack(elcomstr,elnumstr->s[i]);
  /* Sklad, na katerem so vsa mozna imena, ki dolocajo polja znotraj podatkov
  o vozliscih: */
  popstackall(nodcomstr);
  if (nodcomstr==NULL)
    nodcomstr=newstack(2);
  for (i=1;i<=nodnumstr->n;++i)
    pushstack(nodcomstr,nodnumstr->s[i]);
  for (i=1;i<=nodcoordstr->n;++i)
    pushstack(nodcomstr,nodcoordstr->s[i]);
  numelstr="NELGP";
  numnodelstr="NNODE";
  numnodstr="NPOIN";
  dimstr="NDIMN";
  elgrpnumstr="IGROUP";
}
}



int freadelfmesh(FILE *fp, femesh *pfm)
    /* Iz datoteke fp, ki mora biti odprta za branje in mora biti v Elfenovem
    neutral formatu, prebere podatke o mrezi koncnih elementov in jih zapise
    v *pfm. Funkcija ne izvaja nobene dodatne obdelave podatkov. Vrne 0, ce med
    branjem ni prislo do napak, in -1, ce je.
     Opomba:
    Funkcija najprej sama zbrise podatke, ki po moznosti ze obstajajo na pfm.
    Morda bo kdaj treba narediti funkcijo, ki dodaja k obstojecim podatkom.
    $A Igor jul01; */
{
long posbas,possub,pos,pos1,pos2,possub1,possub2;
int which,i,j,n,num,dim,cont,ret=0;
femesh fm=NULL;
elgrp elgr;
indtab it;
if (prn)
  printf("\nReading mesh data from Elfen neutral file...\n");
/* Funkcija najprej zbrise obstojece podatke: */
dispfemesh(pfm);
if (pfm==NULL)
{
  errfunc0("freadelfmesh");
  sprintf(ers(),"Address of mesh data storage is NULL.\n");
  errfunc2();
  ret=-1;
} else if (fp==NULL)
{
  errfunc0("freadelfmesh");
  sprintf(ers(),"File is not open.\n");
  errfunc2();
  ret=-1;
} else
{
  initelfstr();  /* Inicializacija podatkov o kljucnih nizih v Elf. datotekah */
  pos2=posbas=1;
  while (pos2>0 && (posbas=nfilestring(fp,elnodcomstr,posbas,1000,&which))>0)
  {
    /* Nasli smo niz, ki doloca ali polje podatkov o elementih ali polje
    podatkov o vozliscih. Glede na eno ali drugo moznost ise izvede branje
    podatkov, se prej pa se ugotovi pozicija polja in postavi posbas za
    naslednjo iteracijo: */
    filebrac(fp,'{','}',posbas,10000,&pos1,&pos2);
    posbas=pos2+1; /* pozicija za naslednje iskanje */
    if (pos1<1 || pos2<1)
    {
      posbas=-1;
      errfunc0("freadelfmesh");
      sprintf(ers(),"Enclosing brackets for field %s can not be located.\n",
       elnodcomstr->s[which]);
      errfunc2();
      ret=-1;
    } else if ( findstack(groupdatastr,elnodcomstr->s[which],0,0,
     (int(*)(void *,void *)) cmpstrings) >0)
    {
      /* BRANJE SPLOSNIH PODATKOV O SKUPINAH ELEMENTOV (ime skupine, tip el.): */
      /* Kljucni niz, ki smo ga nasli, oznacuje splosne podatke o skupini: */
      if (prn)
        printf("Reading general element group data...\n");
      if (fm==NULL)  /* prostor za podatke se ni bil alociran */
      {
        if (*pfm==NULL)
          *pfm=newfemesh();
        fm=*pfm;
      }
      /* Branje stevilke skupine: */
      if ((possub=filestringto(fp,elgrpnumstr,pos1+1,pos2-1,30))<1)
      {
        errfunc0("freadelfmesh");
        sprintf(ers(),"Element group number (named %s) is missing.\n",elgrpnumstr);
        errfunc2();
        ret=-1;
      } else if ((pos=filecharto(fp,"}",1,possub,pos2-1,30))<1)
      {
        errfunc0("freadelfmesh");
        sprintf(ers(),"Wrong format of element group number (named %s).\n",elgrpnumstr);
        errfunc2();
        ret=-1;
      } else
      {
        n=(int) filenumto(fp,possub+strlen(elgrpnumstr)+1,pos,30,&possub,&i);
        if (possub>0)
        {
          /* Uspesno smo prebrali stevilko skupine; najprej naredimo ustrezen
          objekt za podatke o skupini elementov in nato preberemo podatke: */
          if (prn)
            printf("Reading general data for element group No. %i...\n",n);
          possub=pos+1;
          if (fm->elgrp==NULL)
            fm->elgrp=newstack(3);
          if (fm->elgrp->n<n)
            insstack(fm->elgrp,NULL,n);
          /* Po potrebi kreiramo ustrezne strukture: */
          /*
          dispelgrp((elgrp *) & (fm->elgrp->s[n]));
          elgr=(fm->elgrp->s[n]=newelgrp());
          */
          if (fm->elgrp->s[n]==NULL)
            fm->elgrp->s[n]=newelgrp();
          elgr=fm->elgrp->s[n];
          possub2=1;
          while (possub2>0 && (possub=nfilestringto(fp,groupcomstr,possub,pos2,100,&which))>0)
          {
            ++possub;
            /* Nasli smo niz, ki doloca specificne splos. podatke o skupini el.
            Najprej se ugotovijo meje podpolja, nato pa se glede na to, za
            katero vrsto podatkov gre, polje prebere in shrane v ustrezno
            polje na elgr: */
            filebracto(fp,'{','}',possub,pos2,10000,&possub1,&possub2);
            possub=possub2+1; /* pozicija za naslednje iskanje */
            if (possub1<1 || possub2<1)
            {
              possub=-1;
              errfunc0("freadelfmesh");
              sprintf(ers(),"Enclosing brackets for subfield %s can not be located.\n",
               groupcomstr->s[which]);
              errfunc2();
              ret=-1;
            } else if ( findstack(groupnamestr,groupcomstr->s[which],0,0,
             (int(*)(void *,void *)) cmpstrings) >0 )
            {
              /* BRANJE IMENA SKUPINE ELEMENTOV: */
              /* Kljucni niz, ki smo ga nasli, oznacuje podatke o imenu skupine
              elementov: */
              if (prn)
                printf("Reading name of element group %i...\n",n);
              disppointer((void **) &(elgr->name));
              if ((possub1=filecharto(fp,"\"",1,possub1,possub2-1,30))<1)
              {
                errfunc0("freadelfmesh");
                sprintf(ers(),"Wrong format el. group name (designated %s): the first quotation mark \" is missing.\n",
                 groupcomstr->s[which]);
                errfunc2();
                ret=-1;
              } else if ((possub2=filecharto(fp,"\"",1,possub1+1,possub2-1,30))<1)       
              {
                errfunc0("freadelfmesh");
                sprintf(ers(),"Wrong format el. group name (designated %s): the second quotation mark \" is missing.\n",
                 groupcomstr->s[which]);
                errfunc2();
                ret=-1;
              } else
              {
                elgr->name=makestring(possub2-possub1-1);
                if (possub2-possub1>1)
                  fileread(elgr->name,1,possub2-possub1-1,fp,possub1+1);
              }             
            } else if ( findstack(groupelspecstr,groupcomstr->s[which],0,0,
             (int(*)(void *,void *)) cmpstrings) >0 )
            {
              /* BRANJE SPECIFIKACIJE (imena) ELEMENTA SKUPINE: */
              /* Kljucni niz, ki smo ga nasli, oznacuje podatke tip elementov: */
              if (prn)
                printf("Reading element type specification for element group %i...\n",n);
              disppointer((void **) &(elgr->elspec));
              if ((possub1=filecharto(fp,"\"",1,possub1,possub2-1,30))<1)
              {
                errfunc0("freadelfmesh");
                sprintf(ers(),"Wrong format element specification (designated %s): the first quotation mark \" is missing.\n",
                 groupcomstr->s[which]);
                errfunc2();
                ret=-1;
              } else if ((possub2=filecharto(fp,"\"",1,possub1+1,possub2-1,30))<1)       
              {
                errfunc0("freadelfmesh");
                sprintf(ers(),"Wrong format element specification (designated %s): the second quotation mark \" is missing.\n",
                 groupcomstr->s[which]);
                errfunc2();
                ret=-1;
              } else
              {
                elgr->elspec=makestring(possub2-possub1-1);
                if (possub2-possub1>1)
                  fileread(elgr->elspec,1,possub2-possub1-1,fp,possub1+1);
              }             
            }
          }
        }
      }
    } else if ( findstack(eldatastr,elnodcomstr->s[which],0,0,
     (int(*)(void *,void *)) cmpstrings) >0)
    {
      /* BRANJE PODATKOV O ELEMENTIH: */
      /* Kljucni niz, ki smo ga nasli, oznacuje podatke o elementih: */
      if (prn)
        printf("Reading element data...\n");
      if (fm==NULL)  /* prostor za podatke se ni bil alociran */
      {
        if (*pfm==NULL)
          *pfm=newfemesh();
        fm=*pfm;
      }
      /* Branje stevilke skupine: */
      if ((possub=filestringto(fp,elgrpnumstr,pos1+1,pos2-1,30))<1)
      {
        errfunc0("freadelfmesh");
        sprintf(ers(),"Element group number (named %s) is missing.\n",elgrpnumstr);
        errfunc2();
        ret=-1;
      } else if ((pos=filecharto(fp,"}",1,possub,pos2-1,30))<1)
      {
        errfunc0("freadelfmesh");
        sprintf(ers(),"Wrong format of element group number (named %s).\n",elgrpnumstr);
        errfunc2();
        ret=-1;
      } else
      {
        n=(int) filenumto(fp,possub+strlen(elgrpnumstr)+1,pos,30,&possub,&i);
        if (possub>0)
        {
          /* Uspesno smo prebrali stevilko skupine; najprej naredimo ustrezen
          objekt za podatke o skupini elementov in nato preberemo podatke: */
          if (prn)
            printf("Reading data for element group No. %i...\n",n);
          possub=pos+1;
          if (fm->elgrp==NULL)
            fm->elgrp=newstack(3);
          if (fm->elgrp->n<n)
            insstack(fm->elgrp,NULL,n);
          /* Po potrebi kreiramo ustrezne strukture: */
          /*
          dispelgrp((elgrp *) & (fm->elgrp->s[n]));
          elgr=(fm->elgrp->s[n]=newelgrp());
          */
          if (fm->elgrp->s[n]==NULL)
            fm->elgrp->s[n]=newelgrp();
          elgr=fm->elgrp->s[n];
          possub2=1;
          while (possub2>0 && (possub=nfilestringto(fp,elcomstr,possub,pos2,100,&which))>0)
          {
            ++possub;
            /* Nasli smo niz, ki doloca specificne podatke o elementih.
            Najprej se ugotovijo meje podpolja, nato pa se glede na to, za
            katero vrsto podatkov gre, polje prebere in shrane v ustrezno
            polje na elgr: */
            filebracto(fp,'{','}',possub,pos2,10000,&possub1,&possub2);
            possub=possub2+1; /* pozicija za naslednje iskanje */
            if (possub1<1 || possub2<1)
            {
              possub=-1;
              errfunc0("freadelfmesh");
              sprintf(ers(),"Enclosing brackets for subfield %s can not be located.\n",
               elcomstr->s[which]);
              errfunc2();
              ret=-1;
            } else if ( findstack(eltopstr,elcomstr->s[which],0,0,
             (int(*)(void *,void *)) cmpstrings) >0)
            {
              /* BRANJE TOPOLOGIJE ELEMENTOV: */
              /* Kljucni niz, ki smo ga nasli, oznacuje podatke o topologiji
              elementov: */
              if (prn)
                printf("Reading element topology for el. group %i...\n",n);
              if (elgr->eltop==NULL)  /* prostor za podatke se ni bil alociran */
                elgr->eltop=newstack(20);
              /* Brisanje morebitnih podatkov na skladu za topologijo: */
              while ((it=popstack(elgr->eltop))!=NULL)
                dispindtab(&it);
              /* STEVILO VOZLISC NA ELEMENT: */
              if ((pos=filestringto(fp,numnodelstr,possub1+1,possub2-1,30))<1)
              {
                errfunc0("freadelfmesh");
                sprintf(ers(),"Number of nodes per element (named %s) is missing.\n",numnodelstr);
                errfunc2();
                ret=-1;
              } else if ((possub1=filecharto(fp,"}",1,pos,possub2-1,30))<1)
              {
                errfunc0("freadelfmesh");
                sprintf(ers(),"Wrong format of number of nodes per element (named %s).\n",numnodelstr);
                errfunc2();
                ret=-1;
              } else
              {
                elgr->numelnod=(int) filenumto(fp,pos+strlen(numnodelstr)+1,possub1,30,&pos,&i);
                if (pos<1)
                {
                  errfunc0("freadelfmesh");
                  sprintf(ers(),"Nmber of nodes per element (named %s) not specified.\n",numnodelstr);
                  errfunc2();
                  ret=-1;
                } else
                {
                  /* STEVILO ELEMENTOV V SKUPINI: */
                  if ((pos=filestringto(fp,numelstr,possub1,possub2-1,30))<1)
                  {
                    errfunc0("freadelfmesh");
                    sprintf(ers(),"Number of elements in the group (named %s) is missing.\n",numelstr);
                    errfunc2();
                    ret=-1;
                  } else if ((possub1=filecharto(fp,"}",1,pos,possub2-1,30))<1)
                  {
                    errfunc0("freadelfmesh");
                    sprintf(ers(),"Wrong format of number of elements in the group (named %s).\n",numelstr);
                    errfunc2();
                    ret=-1;
                  } else
                  {
                    num=(int) filenumto(fp,pos+strlen(numelstr)+1,possub1,30,&pos,&i);
                    if (pos<1)
                    {
                      errfunc0("freadelfmesh");
                      sprintf(ers(),"Nmber of nodes per element (named %s) not specified.\n",numelstr);
                      errfunc2();
                      ret=-1;
                    } else
                    {
                      /* Branje topologije elementov */
                      if (prn)
                        printf("Reading topology for element group No. %i...\n",n);
                      cont=1;
                      fseek(fp,possub1,SEEK_SET);
                      for (i=1;i<=num && cont;++i)
                      {
                        /* Branje elementa (obicajno ena vrstica v datoteki) */
                        if (prn)
                          if (i%100==0)
                            printf(".");
                        pushstack(elgr->eltop,it=newindtab(1,elgr->numelnod));
                        for (j=1;j<=elgr->numelnod && cont;++j)
                        {
                          /* Prebiranje naslednjega stevilskega podatka; Ce se podatek ne
                          da prebrati ali je pozicija po branju vecja od pozicije zaklepaja
                          polja topologije, se prekine branje topologije in se javi napaka: */
                          cont=fscanf(fp,"%i",&(it->t[j]));
                          if (cont!=1)
                            cont=0;
                          else if (ftell(fp)>possub2+1)
                            cont=0;
                          if (!cont)
                          {
                            errfunc0("freadelfmesh");
                            sprintf(ers(),"Insufficient data for topology of element group %i\n",n);
                            sprintf(ers(),"(error occured at reading node %i of element seq. num. %i).\n",j,i);
                            errfunc2();
                            ret=-1;
                          } else
                            ++it->n;
                        }
                      }  /* Branje elementa */
                      if (prn)
                        printf("\n");
                    }  /* Topologije posameznih elementov */
                  }
                }
              }
            } else if ( findstack(elnumstr,elcomstr->s[which],0,0,
             (int(*)(void *,void *)) cmpstrings) >0)
            {
              /* BRANJE STEVILK ELEMENTOV v skupini */
              /* Kljucni niz, ki smo ga nasli, oznacuje podatke stevilkah
              elementov: */
              if (prn)
                printf("Reading element numbers for el. group %i...\n",n);
              /* STEVILO ELEMENTOV: */
              if ((pos=filestringto(fp,numelstr,possub1+1,possub2-1,30))<1)
              {
                errfunc0("freadelfmesh");
                sprintf(ers(),"Number of elements (named %s) is missing.\n",numelstr);
                errfunc2();
                ret=-1;
              } else if ((possub1=filecharto(fp,"}",1,pos,possub2-1,30))<1)
              {
                errfunc0("freadelfmesh");
                sprintf(ers(),"Wrong format of number of elements (named %s).\n",numelstr);
                errfunc2();
                ret=-1;
              } else
              {
                num=(int) filenumto(fp,pos+strlen(numelstr)+1,possub1,30,&pos,&i);
                if (pos<1)
                {
                  errfunc0("freadelfmesh");
                  sprintf(ers(),"Nmber of elements (named %s) not specified.\n",numelstr);
                  errfunc2();
                  ret=-1;
                } else
                {
                  /* Poskrbi se, da je tabela stevilk elementov primerno alocirana: */
                  if (elgr->elnum!=NULL)
                  {
                    elgr->elnum->n=0; /* zaradi pravilnega delovanja operacije resize */
                    if (elgr->elnum->r<num)
                      resizeindtab(&elgr->elnum,0,num,0);
                  }
                  if (elgr->elnum==NULL)  /* prostor za podatke se ni alociran */
                    elgr->elnum=newindtab(2,num);
                  /* Branje stevilk elementov v skupini */
                  if (prn)
                    printf("Reading numbers...\n");
                  cont=1;
                  fseek(fp,possub1,SEEK_SET);
                  it=elgr->elnum;
                  it->n=0;
                  for (i=1;i<=num && cont;++i)
                  {
                    /* Prebiranje naslednjega stevilskega podatka; Ce se podatek ne
                    da prebrati ali je pozicija po branju vecja od pozicije zaklepaja
                    polja stevilk el., se prekine branje stevilk el. in se javi napaka: */
                    cont=fscanf(fp,"%i",&(it->t[i]));
                    if (prn)
                      if (i%100==0)
                        printf(".");
                    if (cont!=1)
                      cont=0;
                    else if (ftell(fp)>possub2+1)
                      cont=0;
                    if (!cont)
                    {
                      errfunc0("freadelfmesh");
                      sprintf(ers(),"Insufficient data for element numbers of group %i\n",n);
                      sprintf(ers(),"(error occured at reading data for element seq. num. %i).\n",i);
                      errfunc2();
                      ret=-1;
                    } else
                      ++it->n;
                  }  /* Branje stevilke elementa */
                  if (prn)
                    printf("\n");
                }
              }
            } /* branje stevilk elementov v skupini */
          }
          /* Na koncu branja podatkov o skupini elementov preverimo, ce smo prebrali
          topologijo: */
          if (elgr->eltop==NULL)
          {
            errfunc0("freadelfmesh");
            sprintf(ers(),"Element topology for group no. %i not specified.\n",n);
            errfunc2();
            ret=-1;
          } else if (elgr->elnum!=NULL)
            if(elgr->elnum->n!=elgr->eltop->n)
            {
              errfunc0("freadelfmesh");
              sprintf(ers(),"Number of elements in topology table (%i) is different than dimension of el. num. table (%i)\n",
               elgr->eltop->n,elgr->elnum->n);
              errfunc2();
              ret=-1;
            }
        }
      }
    } else if ( findstack(noddatastr,elnodcomstr->s[which],0,0,
     (int(*)(void *,void *)) cmpstrings) >0)
    {
      /* BRANJE PODATKOV O VOZLISCIH: */
      /* Kljucni niz, ki smo ga nasli, oznacuje podatke o vozliscih: */
      if (prn)
        printf("Reading nodal data...\n");
      if (fm==NULL)  /* prostor za podatke se ni bil alociran */
      {
        if (*pfm==NULL)
          *pfm=newfemesh();
        fm=*pfm;
      }
      possub=pos1+1;
      possub2=1;
      while (possub2>0 && (possub=nfilestringto(fp,nodcomstr,possub,pos2,100,&which))>0)
      {
        ++possub;
        /* Nasli smo niz, ki doloca specificne podatke o vozliscih.
        Najprej se ugotovijo meje podpolja, nato pa se glede na to, za
        katero vrsto podatkov gre, polje prebere in shrane v ustrezno
        polje na fm: */
        filebracto(fp,'{','}',possub,pos2,10000,&possub1,&possub2);
        possub=possub2+1; /* pozicija za naslednje iskanje */
        if (possub1<1 || possub2<1)
        {
          possub=-1;
          errfunc0("freadelfmesh");
          sprintf(ers(),"Enclosing brackets for subfield %s can not be located.\n",
           elcomstr->s[which]);
          errfunc2();
          ret=-1;
        } else if ( findstack(nodnumstr,nodcomstr->s[which],0,0,
         (int(*)(void *,void *)) cmpstrings) >0)
        {
          /* BRANJE STEVILK VOZLISC */
          if (prn)
            printf("Reading node numbers...\n");
          /* STEVILO VOZLISC: */
          if ((pos=filestringto(fp,numnodstr,possub1+1,possub2-1,30))<1)
          {
            errfunc0("freadelfmesh");
            sprintf(ers(),"Number of nodes (named %s) is missing.\n",numnodstr);
            errfunc2();
            ret=-1;
          } else if ((possub1=filecharto(fp,"}",1,pos,possub2-1,30))<1)
          {
            errfunc0("freadelfmesh");
            sprintf(ers(),"Wrong format of number of nodes (named %s).\n",numnodstr);
            errfunc2();
            ret=-1;
          } else
          {
            num=(int) filenumto(fp,pos+strlen(numnodstr)+1,possub1,30,&pos,&i);
            if (pos<1)
            {
              errfunc0("freadelfmesh");
              sprintf(ers(),"Nmber of nodes (named %s) not specified.\n",numnodstr);
              errfunc2();
              ret=-1;
            } else
            {
              /* Poskrbi se, da je tabela stevilk vozlisc primerno alocirana: */
              if (fm->nodnum!=NULL)
              {
                fm->nodnum->n=0; /* zaradi pravilnega delovanja operacije resize */
                if (fm->nodnum->r<num)
                  resizeindtab(&fm->nodnum,0,num,0);
              }
              if (fm->nodnum==NULL)  /* prostor za podatke se ni alociran */
                fm->nodnum=newindtab(2,num);
              /* Branje stevilk elementov v skupini */
              if (prn)
                printf("Reading numbers...\n");
              cont=1;
              fseek(fp,possub1,SEEK_SET);
              it=fm->nodnum;
              it->n=0;
              for (i=1;i<=num && cont;++i)
              {
                /* Prebiranje naslednjega stevilskega podatka; Ce se podatek ne
                da prebrati ali je pozicija po branju vecja od pozicije zaklepaja
                polja voz. stevilk, se prekine branje stevilk voz. in se javi napaka: */
                cont=fscanf(fp,"%i",&(it->t[i]));
                if (prn)
                  if (i%100==0)
                    printf(".");
                if (cont!=1)
                  cont=0;
                else if (ftell(fp)>possub2+1)
                  cont=0;
                if (!cont)
                {
                  errfunc0("freadelfmesh");
                  sprintf(ers(),"Insufficient data for node numbers\n");
                  sprintf(ers(),"(error occured at reading data for node seq. num. %i).\n",i);
                  errfunc2();
                  ret=-1;
                } else
                  ++it->n;
              }  /* Branje stevilke vozlisca */
              if (prn)
                printf("\n");
            }
          }
        } else if ( findstack(nodcoordstr,nodcomstr->s[which],0,0,
         (int(*)(void *,void *)) cmpstrings) >0)
        {
          /* BRANJE KOORDINAT VOZLISC */
          if (prn)
            printf("Reading node coordinates...\n");
          /* DIMENZIJA: */
          if ((pos=filestringto(fp,dimstr,possub1+1,possub2-1,30))<1)
          {
            errfunc0("freadelfmesh");
            sprintf(ers(),"dimension (named %s) is missing.\n",dimstr);
            errfunc2();
            ret=-1;
          } else if ((possub1=filecharto(fp,"}",1,pos,possub2-1,30))<1)
          {
            errfunc0("freadelfmesh");
            sprintf(ers(),"Wrong format of dimension (named %s).\n",dimstr);
            errfunc2();
            ret=-1;
          } else
          {
            dim=(int) filenumto(fp,pos+strlen(dimstr)+1,possub1,30,&pos,&i);
            if (pos<1)
            {
              errfunc0("freadelfmesh");
              sprintf(ers(),"Dimension (named %s) not specified.\n",dimstr);
              errfunc2();
              ret=-1;
            } else
            {
              /* STEVILO VOZLISC: */
              if ((pos=filestringto(fp,numnodstr,possub1,possub2-1,30))<1)
              {
                errfunc0("freadelfmesh");
                sprintf(ers(),"Number of nodes (named %s) is missing.\n",numnodstr);
                errfunc2();
                ret=-1;
              } else if ((possub1=filecharto(fp,"}",1,pos,possub2-1,30))<1)
              {
                errfunc0("freadelfmesh");
                sprintf(ers(),"Wrong format of number of nodes (named %s).\n",numnodstr);
                errfunc2();
                ret=-1;
              } else
              {
                num=(int) filenumto(fp,pos+strlen(numnodstr)+1,possub1,30,&pos,&i);
                if (pos<1)
                {
                  errfunc0("freadelfmesh");
                  sprintf(ers(),"Number of nodes (named %s) not specified.\n",numnodstr);
                  errfunc2();
                  ret=-1;
                } else
                {
                  /* Branje koordinat, najprej se alocira matrika: */
                  if (fm->nodcoord!=NULL)
                    if (fm->nodcoord->d1!=num || fm->nodcoord->d2!=dim)
                      dispmatrix(&(fm->nodcoord));
                  if (fm->nodcoord==NULL)
                    fm->nodcoord=getmatrix(num, dim);
                  if (prn)
                    printf("Reading coordinates...\n");
                  cont=1;
                  fseek(fp,possub1,SEEK_SET);
                  for (i=1;i<=num && cont;++i)
                  {
                    if (prn)
                      if (i%100==0)
                        printf(".");
                    /* Branje podatkov za vozlisce (obicajno ena vrstica v datoteki) */
                    for (j=1;j<=dim && cont;++j)
                    {
                      /* Prebiranje naslednjega stevilskega podatka; Ce se podatek ne
                      da prebrati ali je pozicija po branju vecja od pozicije zaklepaja
                      polja koordinat, se prekine branje koordinat in se javi napaka: */
                      cont=fscanf(fp,"%lg",&(fm->nodcoord->m[i][j]));
                      if (cont!=1)
                        cont=0;
                      else if (ftell(fp)>possub2+1)
                        cont=0;
                      if (!cont)
                      {
                        errfunc0("freadelfmesh");
                        sprintf(ers(),"Insufficient data for node coordinates\n");
                        sprintf(ers(),"(error occured at reading coordinate %i of node seq. num. %i).\n",j,i);
                        errfunc2();
                        ret=-1;
                      }
                    }
                  }  /* branje koordinat posameznih vozlisc */
                  if (prn)
                    printf("\n");
                }
              }
            }
          }
        }  /* branje polja vozliscnih koordinat */
      }
      /* Na koncu branja podatkov o skupini elementov preverimo, ce smo prebrali
      koordinate in ce se stevilo elementov ujema pri koordinatah in ind. tab.: */
      if (fm->nodcoord==NULL)
      {
        errfunc0("freadelfmesh");
        sprintf(ers(),"Node coordinates not specified.\n");
        errfunc2();
        ret=-1;
      } else if (fm->nodnum!=NULL)
        if(fm->nodnum->n!=fm->nodcoord->d1)
        {
          errfunc0("freadelfmesh");
          sprintf(ers(),"Number of nodes in coordinate mat. (%i) is different than dimension of nod. num. table (%i)\n",
           fm->nodcoord->d1,fm->nodnum->n);
          errfunc2();
          ret=-1;
        }
    } else   /* branje podatkov o vozliscih */
    {
      errfunc0("freadelfmesh");
      sprintf(ers(),"String %s was not be found neither among elenent nore among node data strings.\n",
       elnodcomstr->s[which]);
      errfunc2();
      ret=-1;
    }
  }
}
if (prn)
  printf("Mesh data read.\n\n");
return ret;
}




    /* BRANJE TOPOLOGIJE POVRSIN ELEMENTOV (standardiziran format) */


long freadelsurftop(FILE *fp,long pos,elgrp grp)
    /* Iz datoteke fp prebere od trenutne pozicije naprej podatke o topologiji
    povrsin elementa in jih zapise na strukturo podatkov o elementu *grp.
    Ce se pri branju ne pojavijo napake, vrne pozicijo 1. znaka za zadnjim
    prebranim podatkom, ce se, pa -1. Podatki v datoteki morajo biti v
    dogovorjeni obliki. Vsi nestevilski podatki se ignorirajo,, stevilski pa
    so organizirani na naslednji nacin: 1. stevilka je stevilo povrsin, sledijo
    stevila robov za vsako povrsino (vedno 1 v dveh dimenzijah, v treh pa
    navadno 3 ali 4), stevilo vozlisc na povrsini za vsako povrsino, nazadnje
    pa so za vsako povrsino nastete stevilke vozlisc, ki so na povrsini.
    Ce je pos manj od 1, se na zacetku postavi na 1.
     Primer datoteke:
      Number of Surfaces:
      4
      Number of borders for individual surfaces (surfedg):
      1 1 1 1
      Number of nodes per each surface:
      2 2 2 2
      Local numbers of nodes that constitute individual surfaces:
      1 2
      2 3
      3 4
      4 1
      End of file.
     Opozorilo:
    Funkcija zbrise polje grp->outsurf, kjer so podatki o zunanjih povrsinah
    posameznih elementov.
    $A Igor jul01; */
{
int i,j,l,n,numsurf;
indtab it;
if (fp==NULL)
{
  errfunc0("freadelsurftop");
  sprintf(ers(),"File is not open.\n");
  errfunc2();
  return -1;
} else if (grp==NULL)
{
  errfunc0("freadelsurftop");
  sprintf(ers(),"Element group pointer is NULL.\n");
  errfunc2();
  return -1;
} else
{
  /* Najprej se zbrisejo morebitni ze obstojeci podatki vezani na topologijo
   povrsin elementov: */
  dispstackallspec(&(grp->surftop),(void (*)(void **)) dispindtab);
  dispstackallspec(&(grp->outsurf),(void (*)(void **)) dispindtab);
  dispindtab(&(grp->surfedg));
  if ( pos <1)
    pos=1;
  /* Stevilo povrsin v elementu: */
  numsurf=(int) filenum(fp,pos,50,&pos,&l);
  if (pos<1)
  {
    errfunc0("freadelsurftop");
    sprintf(ers(),"Number of surfaces could not be read.\n");
    errfunc2();
    return -1;
  }
  pos+=l;
  /* Branje stevila robov pri posam. povrsinah: */
  it=(grp->surfedg=newindtab(0,numsurf));
  for (i=1;i<=numsurf;++i)
  {
    it->t[i]=(int) filenum(fp,pos,50,&pos,&l);
    if (pos<1)
    {
      errfunc0("freadelsurftop");
      sprintf(ers(),"Can not read number of borders for surface %i.\n",i);
      errfunc2();
      dispindtab(&(grp->surfedg));
      return -1;
    }
    pos+=l;
    ++it->n;
  }
  /* Branje stevila vozlisc za vsako povrsino: */
  grp->surftop=newstack(numsurf);
  for (i=1;i<=numsurf;++i)
  {
    n=(int) filenum(fp,pos,50,&pos,&l);
    if (pos<1)
    {
      errfunc0("freadelsurftop");
      sprintf(ers(),"Can not read number of nodes for surface %i.\n",i);
      errfunc2();
      dispstackallspec(&(grp->surftop),(void (*)(void **)) dispindtab);
      return -1;
    }
    pos+=l;
    pushstack(grp->surftop,newindtab(0,n));
  }
  /* Branje lokalnih stevilk vozlisc, ki tvorijo posamezne povrsine el.: */
  for (i=1;i<=numsurf;++i)
  {
    it=grp->surftop->s[i];
    it->n=0;
    n=it->r;
    for (j=1;j<=n;++j)
    {
      it->t[j]=(int) filenum(fp,pos,50,&pos,&l);
      if (pos<1)
      {
        errfunc0("freadelsurftop");
        sprintf(ers(),"Can not read number of node %i on surface %i.\n",j,i);
        errfunc2();
        dispstackallspec(&(grp->surftop),(void (*)(void **)) dispindtab);
        return -1;
      } else if ((grp->numelnod>0 && n>grp->numelnod) || n<1)
      {
        errfunc0("freadelsurftop");
        sprintf(ers(),"Local node number %i for node %i on surface %i is out of range (range %i).\n",
         n,j,i,grp->numelnod);
        errfunc2();
        dispstackallspec(&(grp->surftop),(void (*)(void **)) dispindtab);
        return -1;
      }
      pos+=l;
      ++it->n;
    }
  }
}
if (prn)
  printelsurftop(grp);
return pos;
}


long filereadelsurftop(char *filename,long pos,elgrp grp)
    /* Iz datoteke z imenom filename prebere s funkcijo freadelsurftop
    podatke o topologiji povrsin elementa. Bere od pozicije pos naprej,
    vrne pozicijo po zadnjem prebranem podatku oz. -1, ce je prislo do
    napake, in zapise podatke v *grp.
    $A Igor jul01; */
{
FILE *fp=NULL;
if ((fp=fopen(filename,"rb"))==NULL)
{
  printf("\nReading surface topology, invalid file name was specified...\n");
  fp=fopensafe(filename,"rb");
}
if (fp==NULL)
{
  errfunc0("filereadelsurftop");
  sprintf(ers(),"File with surface topology data (initial name %s) could not be open.\n",filename);
  errfunc2();
  return -1;
}
pos=freadelsurftop(fp,pos,grp);
fclose(fp);
return pos;
}



long freadelsurftopgrp(FILE *fp,long pos,femesh fm)
    /* Iz datoteke fp prebere podatke o topologiji povrsin elementov za
    skupine elementov, ki so na fm. Podatke bere od pozicije pos naprej in
    morajo biti v taksni obliki, kot so podatki za funkcijo freadelsurftop,
    poleg tega pa mora biti prvi podatek stevilo skupin, za katere se prebere
    podatke, pri vsaki skupini pa mora biti na zacetku se stevilka skupine.
    Ce je branje uspesno, vrne funkcija pozicijo takoj za zadnjim prebranim
    podatkom, drugace pa -1. Ce je pos manj kot 1, se na zacetku postavi na 1.
     POZOR!
     Podatke of topologiji povrsin elementa se lahko bere sele potem, ko je
    ze alociran prostor za podatke o elementih (objekti tipa elgrp), ni pa
    potrebno, da je alociran prostor za podatke o topologiji povrsin (polji
    surftop in surfedg na objektu tipa elgrp).
    $A Igor jul01; */
{
int i,l,numgroups,num;
elgrp grp;
if (fp==NULL)
{
  errfunc0("freadelsurftopgrp");
  sprintf(ers(),"File is not open.\n");
  errfunc2();
  return -1;
} else if (fm==NULL)
{
  errfunc0("freadelsurftopgrp");
  sprintf(ers(),"Mesh data pointer is NULL.\n");
  errfunc2();
  return -1;
} else
{
  if ( pos <1)
    pos=1;
  /* Branje stevila skupin elementov: */
  numgroups=(int) filenum(fp,pos,50,&pos,&l);
  if (pos<1)
  {
    errfunc0("freadelsurftopgrp");
    sprintf(ers(),"Number of element groups could not be read.\n");
    errfunc2();
    return -1;
  }
  pos+=l;
  for (i=1;i<=numgroups;++i)
  {
    /* Branje stevilke skupine elementov: */
    num=(int) filenum(fp,pos,50,&pos,&l);
    if (pos<1)
    {
      errfunc0("freadelsurftopgrp");
      sprintf(ers(),"Group number could not be read (reading seq. num. %i).\n",i);
      errfunc2();
      return -1;
    }
    pos+=l;
    grp=stackel(fm->elgrp,num); /* podatki za skupino st. num */
    if (grp==NULL)
    {
      errfunc0("freadelsurftopgrp");
      sprintf(ers(),"Data structure for group %i (reading seq. num. %i) not allocated.\n",num,i);
      errfunc2();
      return -1;
    }
    /* Branje topologije povrsin elementov za skupino st. i: */
    if (prn)
      printf("Reading local surface topology for element group %i...\n",num);
    pos=freadelsurftop(fp,pos,grp);
  }
}
return pos;
}



long filereadelsurftopgrp(char *filename,long pos,femesh fm)
    /* Iz datoteke z imenom filename prebere s funkcijo freadelsurftopgrp
    podatke o topologiji povrsin elementa. Bere od pozicije pos naprej,
    vrne pozicijo po zadnjem prebranem podatku oz. -1, ce je prislo do
    napake, in zapise podatke v *grp.
    $A Igor jul01; */
{
FILE *fp=NULL;
if ((fp=fopen(filename,"rb"))==NULL)
{
  printf("\nReading surface topology, invalid file name was specified...\n");
  fp=fopensafe(filename,"rb");
}
if (fp==NULL)
{
  errfunc0("filereadelsurftopgrp");
  sprintf(ers(),"File with surface topology data for el. groups (initial name %s) could not be open.\n",filename);
  errfunc2();
  return -1;
}
pos=freadelsurftopgrp(fp,pos,fm);
fclose(fp);
return pos;
}



/* UPORABA DATOTEK S PODATKI O TOPOLOGIJI POVRSIN ZA POSAMEZNE ELEMENTE: */


int dirreadelsurftopgrp(char *dirname,femesh fm)
    /* Podatke o topologiji povrsin elementov na skupinah elementov mreze fm
    poisce v direktoriju dirname. Podatke isce v datotekah z istim imenom kot
    je ime tipa elementov, ki tvorijo skupino, torej (...)->elspec, plus
    koncnica ".est" (element surface topology). Podatki v datotekah za
    posamezne elemente morajo biti v istem formatu kot za funkcijo
    freadelsurftop(), pred zacetkom podatkov pa mora biti obvezno niz "begin"
    (lahko se zacne z veliko ali je cel zapisan z velikimi crkami). Ce se
    ustrezne datoteke za kak tip elementov ne najde, funkcija vrne -1.
    $A Igor avg01; */
{
char *dn=NULL,*fn=NULL,*mode=NULL,*str=NULL;
int ret=0,i;
long pos;
FILE *fp;
elgrp gr;
if (fm==NULL)
{
  errfunc0("dirreadelsurftopgrp");
  sprintf(ers(),"Mesh data pointer is NULL.\n");
  errfunc2();
  return -1;
} else if (fm->elgrp==NULL)
{
  errfunc0("dirreadelsurftopgrp");
  sprintf(ers(),"Stack of element groups is NULL.\n");
  errfunc2();
  return -1;
} else if (fm->elgrp->n<1)
{
  errfunc0("dirreadelsurftopgrp");
  sprintf(ers(),"Stack of element groups contains no groups.\n");
  errfunc2();
  return -1;
} else
{
  dn=stringcopy(dirname);
  convertfilesyst(dn);
  mode=stringcopy("rb");
  for (i=1;i<=fm->elgrp->n;++i)
    if ((gr=fm->elgrp->s[i])!=NULL)
    {
      if (gr->elspec==NULL)
      {
        errfunc0("dirreadelsurftopgrp");
        sprintf(ers(),"Element type is not specified for element group %s (seq. num. %i).\n",
         gr->name,i);
        errfunc2();
        ret= -1;
      } else if (strlen(gr->elspec)==0)
      {
        errfunc0("dirreadelsurftopgrp");
        sprintf(ers(),"Element type is not specified for element group %s (seq. num. %i).\n",
         gr->name,i);
        errfunc2();
        ret= -1;
      } else
      {
        disppointer((void **) &fn);
        str=stringcat(gr->elspec,".est");
        fn=dirplusfile(dn,str);
        disppointer((void **) &str);
        if ( (fp=fopen(fn,mode)) ==NULL )
        {
          errfunc0("dirreadelsurftopgrp");
          sprintf(ers(),"Could not open the element surface topology file \"%s\" for element type %s.\n",
           fn,gr->elspec);
          errfunc2();
          ret= -1;
        } else
        {
          /* V datoteki se poisce niz, ki oznacuje zacetek podatkov: */
          pos=filestring(fp,"begin",1,100);
          if (pos<1)
            pos=filestring(fp,"Begin",1,100);
          if (pos<1)
            pos=filestring(fp,"BEGIN",1,100);
          if (pos<1)
          {
            errfunc0("dirreadelsurftopgrp");
            sprintf(ers(),"Could not find the string for beginning of data in surface topology file for element type %s (group %s, seq. num. %i).\n",
             gr->elspec,gr->name,i);
            printf("File name: %s.\n",fn);
            errfunc2();
            ret=-1;
          } else
          if (ret>=0)
            ret=(int) freadelsurftop(fp,pos,gr);
          else
            freadelsurftop(fp,pos,gr);
          fclose(fp);
        }
      }
    }
}
disppointer((void **) &fn);
disppointer((void **) &dn);
disppointer((void **) &mode);
return ret;
}


int dirreadelsurftopgrpsafe(char *dirname,femesh fm)
    /* Podatke o topologiji povrsin elementov na skupinah elementov mreze fm
    poisce v direktoriju dirname. Podatke isce v datotekah z istim imenom kot
    je ime tipa elementov, ki tvorijo skupino, torej (...)->elspec, plus
    koncnica ".est" (element surface topology). Podatki v datotekah za
    posamezne elemente morajo biti v istem formatu kot za funkcijo
    freadelsurftop(), pred zacetkom podatkov pa mora biti obvezno niz "begin"
    (lahko se zacne z veliko ali je cel zapisan z velikimi crkami). Ce se
    ustrezne datoteke ne najde, funkcija vprasa za novo ime direktorija.
    $A Igor avg01; */
{
char *dn=NULL,*fn=NULL,*mode=NULL,*str=NULL;
int ret=0,i;
long pos;
FILE *fp;
elgrp gr;
if (fm==NULL)
{
  errfunc0("dirreadelsurftopgrpsafe");
  sprintf(ers(),"Mesh data pointer is NULL.\n");
  errfunc2();
  return -1;
} else if (fm->elgrp==NULL)
{
  errfunc0("dirreadelsurftopgrpsafe");
  sprintf(ers(),"Stack of element groups is NULL.\n");
  errfunc2();
  return -1;
} else if (fm->elgrp->n<1)
{
  errfunc0("dirreadelsurftopgrpsafe");
  sprintf(ers(),"Stack of element groups contains no groups.\n");
  errfunc2();
  return -1;
} else
{
  dn=stringcopy(dirname);
  mode=stringcopy("rb");
  convertfilesyst(dn);
  for (i=1;i<=fm->elgrp->n;++i)
    if ((gr=fm->elgrp->s[i])!=NULL)
    {
      if (gr->elspec==NULL)
      {
        errfunc0("dirreadelsurftopgrpsafe");
        sprintf(ers(),"Element type is not specified for element group %s (seq. num. %i).\n",
         gr->name,i);
        errfunc2();
        ret= -1;
      } else if (strlen(gr->elspec)==0)
      {
        errfunc0("dirreadelsurftopgrpsafe");
        sprintf(ers(),"Element type is not specified for element group %s (seq. num. %i).\n",
         gr->name,i);
        errfunc2();
        ret= -1;
      } else
      {
        disppointer((void **) &fn);
        str=stringcat(gr->elspec,".est");
        fn=dirplusfile(dn,str);
        disppointer((void **) &str);
        if ( (fp=fopen(fn,mode)) ==NULL)
        {
          printf("\nWarning:\nCould not open the element surface topology file \"%s\". Try to specify a valid file name for element type %s!\n",
           fn,gr->elspec);
          fopensafeaddr(&fn,&mode);
          if (fp==NULL)
          {
            errfunc0("dirreadelsurftopgrpsafe");
            sprintf(ers(),"Could not open surface topology file for element type %s (group %s, seq. num. %i).\n",
             gr->elspec,gr->name,i);
            errfunc2();
            ret= -1;
          } else
          {
            /* Uporabnik je vstavil novo ime datoteke, ki je veljavno, iz imena
            se izlusci ime direktorija za branje podatkov pri naslednjih
            skupinah: */
            disppointer((void **) &dn);
            dn=fileminusfile(fn);
          }
        }
        if (fp!=NULL)
        {
          /* V datoteki se poisce niz, ki oznacuje zacetek podatkov: */
          pos=filestring(fp,"begin",1,100);
          if (pos<1)
            pos=filestring(fp,"Begin",1,100);
          if (pos<1)
            pos=filestring(fp,"BEGIN",1,100);
          if (pos<1)
          {
            errfunc0("dirreadelsurftopgrpsafe");
            sprintf(ers(),"Could not find the string for beginning of data in surface topology file for element type %s (group %s, seq. num. %i).\n",
             gr->elspec,gr->name,i);
            printf("File name: %s.\n",fn);
            errfunc2();
            ret=-1;
          } else
          if (ret>=0)
            ret=(int) freadelsurftop(fp,pos,gr);
          else
            freadelsurftop(fp,pos,gr);
          fclose(fp);
        }
      }
    }
}
disppointer((void **) &fn);
disppointer((void **) &dn);
disppointer((void **) &mode);
return ret;
}




   /* BRANJE TOPOLOGIJE POVRSIN ELEMENTOV S STAND. VHODA IN VARNO BRANJE: */


int readelsurftop(elgrp grp)
    /* S stand. vhoda prebere podatke o topologiji povrsin elementa in jih
    zapise na strukturo podatkov o elementu *grp. Ce se pri branju ne pojavijo
    napake, vrne 0, ce se, pa -1. Funkcija zahteva od uporabnika, da po vrsti
    vstavlja podatke v stevilski obliki, ki se berejo s funkcijo readint.
    Prostor za podatke na grp se ob branju sproti alocira.
     Opozorilo:
    Funkcija zbrise polje grp->outsurf, kjer so podatki o zunanjih povrsinah
    posameznih elementov.
    $A Igor jul01; */
{
int i,j,n,numsurf;
indtab it;
if (grp==NULL)
{
  errfunc0("readelsurftop");
  sprintf(ers(),"Element group pointer is NULL.\n");
  errfunc2();
  return -1;
} else
{
  /* Najprej se zbrisejo morebitni ze obstojeci podatki vezani na topologijo
   povrsin elementov: */
  dispstackallspec(&(grp->surftop),(void (*)(void **)) dispindtab);
  dispstackallspec(&(grp->outsurf),(void (*)(void **)) dispindtab);
  dispindtab(&(grp->surfedg));
  /* Stevilo povrsin v elementu: */
  printf("Number or element surfaces: ");
  readint(&numsurf);
  if (numsurf<3)
  {
    errfunc0("readelsurftop");
    sprintf(ers(),"Invalid number of surfaces (%i).\n",numsurf);
    errfunc2();
    return -1;
  }
  /* Branje stevila robov pri posam. povrsinah: */
  printf("Number of borders on element surfaces:\n");
  it=(grp->surfedg=newindtab(0,numsurf));
  for (i=1;i<=numsurf;++i)
  {
    printf("Surface %i: ",i);
    readint(&(it->t[i]));
    if (it->t[i]<1)
    {
      errfunc0("readelsurftop");
      sprintf(ers(),"Invalid number of edges (%i) for surface %i.\n",it->t[i],i);
      errfunc2();
      dispindtab(&(grp->surfedg));
      return -1;
    }
    ++it->n;
  }
  /* Branje stevila vozlisc za vsako povrsino: */
  printf("Number of nodes on element surfaces:\n");
  grp->surftop=newstack(numsurf);
  for (i=1;i<=numsurf;++i)
  {
    printf("Surface %i: ",i);
    readint(&n);
    if (n<2)
    {
      errfunc0("readelsurftop");
      sprintf(ers(),"Invalid number of nodes (%i) for surface %i.\n",n,i);
      errfunc2();
      dispstackallspec(&(grp->surftop),(void (*)(void **)) dispindtab);
      return -1;
    }
    pushstack(grp->surftop,newindtab(0,n));
  }
  /* Branje lokalnih stevilk vozlisc, ki tvorijo posamezne povrsine el.: */
  printf("  Local numbers of nodes on element surfaces:\n");
  for (i=1;i<=numsurf;++i)
  {
    printf("Local numbers of nodes on surface %i:\n",i);
    it=grp->surftop->s[i];
    it->n=0;
    n=it->r;
    for (j=1;j<=n;++j)
    {
      printf("Surf. %i, node %i: ",i,j);
      readint(&(it->t[j]));
      if ((grp->numelnod>0 && n>grp->numelnod) || n<1)
      {
        errfunc0("readelsurftop");
        sprintf(ers(),"Local node number %i for node %i on surface %i is out of range (range %i).\n",
         n,j,i,grp->numelnod);
        errfunc2();
        dispstackallspec(&(grp->surftop),(void (*)(void **)) dispindtab);
        return -1;
      }
      ++it->n;
    }
  }
}
if (prn)
  printelsurftop(grp);
return 0;
}



int readelsurftopgrp(femesh fm)
    /* S stand. vhoda prebere podatke o topologiji povrsin elementov za
    posamezne skupine elementov in jih zapise na strukturo podatkov o emrezi
    koncnih elementov *fm. Ce se pri branju ne pojavijo napake, vrne 0, ce se,
    pa -1. Funkcija zahteva od uporabnika, da po vrsti vstavlja podatke v
    stevilski obliki, ki se berejo s funkcijo readint. Prostor za podatke na
    *fm se ob branju sproti alocira.
     POZOR!
     Podatke of topologiji povrsin elementa se lahko bere sele potem, ko je
    ze alociran prostor za podatke o elementih (objekti tipa elgrp), ni pa
    potrebno, da je alociran prostor za podatke o topologiji povrsin (polji
    surftop in surfedg na objektu tipa elgrp).
    $A Igor jul01; */
{
int i,numgroups,num;
elgrp grp;
if (fm==NULL)
{
  errfunc0("readelsurftopgrp");
  sprintf(ers(),"Mesh data pointer is NULL.\n");
  errfunc2();
  return -1;
} else
{
  /* Branje stevila skupin elementov: */
  printf("Number of element groups for which you will specify\n");
  printf("                           element surface topology: ");
  readint(&numgroups);
  if (numgroups<0 || numgroups>fm->elgrp->n)
  {
    errfunc0("freadelsurftopgrp");
    sprintf(ers(),"Invalid number of element groups (%i), max. number is %i.\n",
     numgroups,fm->elgrp->n);
    errfunc2();
    return -1;
  }
  printf("Data for element groups:\n");
  for (i=1;i<=numgroups;++i)
  {
    /* Branje stevilke skupine elementov: */
    printf("Group number: ");
    readint(&num);
    if (num<1 || num>fm->elgrp->n)
    {
      errfunc0("readelsurftopgrp");
      sprintf(ers(),"Invalid group number (%i), max. number is %i.\n",num,fm->elgrp->n);
      errfunc2();
      return -1;
    }
    grp=stackel(fm->elgrp,num); /* podatki za skupino st. num */
    if (grp==NULL)
    {
      errfunc0("readelsurftopgrp");
      sprintf(ers(),"Data structure for group %i (reading seq. num. %i) not allocated.\n",num,i);
      errfunc2();
      return -1;
    }
    /* Branje topologije povrsin elementov za skupino st. i: */
    if (prn)
      printf("Reading local surface topology for element group %i...\n",num);
    return (int) readelsurftop(grp);
  }
}
return 0;
}


long filereadelsurftopgrpsafe(char *filename,femesh fm)
    /* Iz datoteke z imenom filename poskusa prebrati podatke o topologiji
    povrsin elementov za skupine elementov, ki so na *fm. Ce je filename
    razlicen od NULL ali "", najprej poskusi z branjem iz datoteke z imenom
    filename, drugace pa z branjem preko standardnega vhoda (rocno vstavljanje
    podatkov) oz. iz datoteke, ki jo specifira uporabnik.
    Po branju preveri, ce so prebrani podatki za vse skupine elementov in javi
    napako, ce niso. Funkcija vrne negativno stevilo, ce branje ni bilo uspesno
    oz. pozitivno ali 0, ce je bilo branje uspesno. Funkcija javi napako tudi,
    ce je fm NULL ali ce ne kaze na strukturo, na kateri so podatki o vsaj eni
    skupini elementov. Funkcija poskusa poskrbeti, da se preberejo topologije
    povrsin za vse skupine elementov na fm, v nasprotnem primeru javi napako.
    $A Igor jul01; */
{
int readfromfile=1,readfromstdin,cont=1,i;
char *fn=NULL;
FILE *fp=NULL;
elgrp grp;
long ret=0;
if (fm==NULL)
{
  errfunc0("filereadelsurftopgrpsafe");
  sprintf(ers(),"Pointer to finite element data structure is NULL.\n");
  errfunc2();
  return -1;
} else if (fm->elgrp==NULL)
{
  errfunc0("filereadelsurftopgrpsafe");
  sprintf(ers(),"Stack of element groups is NULL.\n");
  errfunc2();
  return -1;
} else if (fm->elgrp->n<1)
{
  errfunc0("filereadelsurftopgrpsafe");
  sprintf(ers(),"There are no element groups on the stack.\n");
  errfunc2();
  return -1;
}
fn=stringcopy(filename);
convertfilesyst(fn);
if (fn==NULL)
  readfromfile=0;
else if (cmpstrings(fn,"")==0)
  readfromfile=0;
if (readfromfile)
  ret=filereadelsurftopgrp(fn,1,fm);
else
  ret=-1;
/* Ce pri branju ni prislo do napak, se preveri, ce so prebrane topologije
povrsin za vse skupine elementov na fm->elgrp: */
for (i=1;i<=fm->elgrp->n;++i)
{
  grp=stackel(fm->elgrp,i);
  if (grp!=NULL)
    if (grp->eltop!=NULL && grp->surftop==NULL)
    {
      ret=-1;
      printf("Element surface topology for element group %i (named %s, element type %s) is not specified.\n",
       i,grp->name,grp->elspec);
    }
}
readfromfile=readfromstdin=1;
while (ret<0 && (readfromfile || readfromstdin) )
{
  printf("\nElement surface topology has not been successfully specified for all element groups.\n");
  printf("\nRead element surface topology data from a file (0/1)? ");
  readint(&readfromfile);
  if (readfromfile)
  {
    printf("File name: ");
    readstring(&fn);
    ret=filereadelsurftopgrp(fn,1,fm);
  } else
  {
    printf("\nRead element surface topology data from the terminal input (0/1)? ");
    readint(&readfromstdin);
    if (readfromstdin)
      ret=readelsurftopgrp(fm);
  }
  ret=0;
  for
  (i=1;i<=fm->elgrp->n;++i)
  {
    grp=stackel(fm->elgrp,i);
    if (grp!=NULL)
      if (grp->eltop!=NULL && grp->surftop==NULL)
      {
        ret=-1;
        printf("Element surface topology for element group %i (named %s, element type %s) is not specified.\n",
         i,grp->name,grp->elspec);
      }
  }
}
if (ret<0)
{
  errfunc0("filereadelsurftopgrpsafe");
  sprintf(ers(),"Element surface topology has not been successfully specified for all element groups.\n");
  errfunc2();
  ret= -1;
}
disppointer((void **) &fn);
return ret;
}


long readelsurftopgrpsafe(char *dirname,char *filename,femesh fm)
    /* Branje podatkov o topologiji povrsin elementov za skupine elementov, ki
    so na *fm, z varnostnimi mehanizmi in na razlicne nacine.
      Ce je dirname razlicen od NULL ali "", najprej poskusi se z branjem iz
    direktorija z imenom dirname in ce je filename razlicen od NULL ali "",
    poskusi (se) z branjem iz datoteke z imenom filename. Ce ne poskusi niti
    z branjem iz direktorija niti iz datoteke oziroma dokler niso dolocene
    topologije povrsin za vse skupine, poskusa z branjem na tri nacine, ki
    vkljucujejo poleg branja iz direktorija in datoteke se branja s standardnega
    vhoda. Iz direktorija bere s funkcijo dirreadelsurftopgrpsafe, iz datoteke s
    funkcijo filereadelsurftopgrp, s standardnega vhoda pa s funkcijo
    readelsurftopgrp.
    Po branju preveri, ce so prebrani podatki za vse skupine elementov in javi
    napako, ce niso. Funkcija vrne negativno stevilo, ce branje ni bilo uspesno
    oz. pozitivno ali 0, ce je bilo branje uspesno. Funkcija javi napako tudi,
    ce je fm NULL ali ce ne kaze na strukturo, na kateri so podatki o vsaj eni
    skupini elementov. Funkcija poskusa poskrbeti, da se preberejo topologije
    povrsin za vse skupine elementov na fm, v nasprotnem primeru javi napako.
    $A Igor avg01; */
{
int readfromfile=1,readfromdir=1,readfromstdin,cont=1,i;
char *fn=NULL,*dn=NULL;
FILE *fp=NULL;
elgrp grp;
long ret=0;
if (fm==NULL)
{
  errfunc0("filereadelsurftopgrpsafe");
  sprintf(ers(),"Pointer to finite element data structure is NULL.\n");
  errfunc2();
  return -1;
} else if (fm->elgrp==NULL)
{
  errfunc0("filereadelsurftopgrpsafe");
  sprintf(ers(),"Stack of element groups is NULL.\n");
  errfunc2();
  return -1;
} else if (fm->elgrp->n<1)
{
  errfunc0("filereadelsurftopgrpsafe");
  sprintf(ers(),"There are no element groups on the stack.\n");
  errfunc2();
  return -1;
}
dn=stringcopy(dirname);
convertfilesyst(dn);
if (dn==NULL)
  readfromdir=0;
else if (cmpstrings(dn,"")==0)
  readfromdir=0;
if (readfromdir)
{
  if (ret>=0)
    ret=dirreadelsurftopgrpsafe(dn,fm);
  else
    dirreadelsurftopgrpsafe(dn,fm);
}
fn=stringcopy(filename);
convertfilesyst(fn);
if (fn==NULL)
  readfromfile=0;
else if (cmpstrings(fn,"")==0)
  readfromfile=0;
if (readfromfile)
{
  if (ret>=0)
    ret=filereadelsurftopgrp(fn,1,fm);
  else
    filereadelsurftopgrp(fn,1,fm);
}
if (! (readfromfile || readfromdir) )
  ret=-1;
/* Ce pri branju ni prislo do napak, se preveri, ce so prebrane topologije
povrsin za vse skupine elementov na fm->elgrp: */
for (i=1;i<=fm->elgrp->n;++i)
{
  grp=stackel(fm->elgrp,i);
  if (grp!=NULL)
    if (grp->eltop!=NULL && grp->surftop==NULL)
    {
      ret=-1;
      printf("Element surface topology for element group %i (named %s, element type %s) is not specified.\n",
       i,grp->name,grp->elspec);
    }
}
readfromfile=readfromdir=readfromstdin=1;
while (ret<0 && (readfromfile || readfromdir || readfromstdin) )
{
  printf("\nElement surface topology has not been successfully specified for all element groups.\n");
  printf("\nRead element surface topology data from a directory with element specifications (0/1)? ");
  readint(&readfromdir);
  if (readfromdir)
  {
    printf("Directory name: ");
    readstring(&dn);
    ret=dirreadelsurftopgrpsafe(dn,fm);
  } else
  {
    printf("\nRead element surface topology data from a file (0/1)? ");
    readint(&readfromfile);
    if (readfromfile)
    {
      printf("File name: ");
      readstring(&fn);
      ret=filereadelsurftopgrp(fn,1,fm);
    } else
    {
      printf("\nRead element surface topology data from the terminal input (0/1)? ");
      readint(&readfromstdin);
      if (readfromstdin)
        ret=readelsurftopgrp(fm);
    }
  }
  ret=0;
  for
  (i=1;i<=fm->elgrp->n;++i)
  {
    grp=stackel(fm->elgrp,i);
    if (grp!=NULL)
      if (grp->eltop!=NULL && grp->surftop==NULL)
      {
        ret=-1;
        printf("Element surface topology for element group %i (named %s, element type %s) is not specified.\n",
         i,grp->name,grp->elspec);
      }
  }
}
if (ret<0)
{
  errfunc0("filereadelsurftopgrpsafe");
  sprintf(ers(),"Element surface topology has not been successfully specified for all element groups.\n");
  errfunc2();
  ret= -1;
}
disppointer((void **) &fn);
disppointer((void **) &dn);
return ret;
}



    /* VARIOUS MESH MANIPULATION UTILITIES: */



void transffemeshbas(femesh mesh,int grp,vector param,
                  void (*transform)(vector orig,vector transf,vector param))
    /* Transforms co-ordinates of the nodes of the element group grp of the
    mesh mesh by the function transf. If grp is 0 then nodes of all the groups
    are transformed.
      The transform is performed from mesh->origcoord to mesh->nodcoord. If
    both are NULL (or if mesh is NULL) an error is reported, if mesh->nodcoord
    is NULL then a level 2 warning is launched and mesh->origcoord is copied
    to mesh->nodcoord before performing operation, and if mesh->origcoord is
    NULL then mesh->nodcoord is copied to mesh->origcoord before the operation
    and no warning is launched. Such a regime is adopted because it is not
    normally assumed that the field (...)->origcoord of a finite element mesh
    is allocated.
    $A Igor oct03 fev04; */
{
static char *funcname="transffemeshbas";
int i,j,dim,dotransf;
vector orig=NULL,transf=NULL;
void *vorig,*vtransf;
indtab elements;
if (mesh==NULL)
{
  errfunc0(funcname);
  sprintf(ers(),"The mesh is NULL.\n");
  errfunc2();
  return;
} else
if (mesh->origcoord==NULL)
{
  if (mesh->nodcoord==NULL)
  {
    errfunc0(funcname);
    sprintf(ers(),"The original and the currend co-ordinates are NULL, no transform is done.\n");
    errfunc2();
    return;
  }
  copymatrix(mesh->nodcoord,&(mesh->origcoord));
  warnfunc1(2,funcname);
  sprintf(ers(),"The original node co-ordinates did not exist, copied from current.");
  warnfunc2();
} else if (mesh->nodcoord==NULL)
{
  warnfunc1(2,funcname);
  sprintf(ers(),"The current node co-ordinates did not exist, copied from original.");
  warnfunc2();
  copymatrix(mesh->origcoord,&(mesh->nodcoord));
}
dim=mesh->origcoord->d2;
if (dim!=mesh->nodcoord->d2)
{
  errfunc0(funcname);
  sprintf(ers(),"The dimensions of original (%i) and current (%i) nodal co-ordinates\n",
      mesh->origcoord->d2,mesh->nodcoord->d2);
  sprintf(ers(),"Do not match.\n");
  errfunc2();
  return;
}
if (dim<1)
{
  errfunc0(funcname);
  sprintf(ers(),"The dimension can not be determined.\n");
  errfunc2();
  return;
}
if (grp>0)
{
  /* The group is specified, we will neet the tables that enable us to
  determine whether a given node is contained in a certain group: */
  if (mesh->eltopinv==NULL)
    femcalceltopinv(mesh);
  if (mesh->elgrpinv==NULL || mesh->elnuminv==NULL)
    femcalcelnuminv(mesh);
}
orig=getvector(dim);
transf=getvector(dim);
vorig=orig->v;
vtransf=transf->v;
for (i=1;i<=mesh->nodcoord->d1;++i)
{
  /* Determine whether to transform a particular node or just transcribe it: */
  dotransf=0;
  if (grp<=0)
    dotransf=1;
  else
  {
    elements=mesh->eltopinv->s[i];
    if (elements!=NULL)
      for (j=1;j<=elements->n && !dotransf;++j)
        if (mesh->elgrpinv->t[elements->t[j]]==grp)
          dotransf=1;
  }
  if (dotransf)
  {
    /* set element tavbles of vectors to point to the row i of the matrices of
    nodal co-ordinates and perform the transform: */
    /*
    for (j=1;j<=dim;++j)
      coord->v[j]=mesh->nodcoord->m[i][j];
    */
    orig->v=  mesh->origcoord->m[i];
    transf->v=mesh->nodcoord->m[i];
    transform(orig,transf,param);
    /*
    for (j=1;j<=dim;++j)
      mesh->nodcoord->m[i][j]=coord->v[j];
    */
  }
}
/* Set element tables to point to original location and delete vectors: */
orig->v=vorig;
transf->v=vtransf;
dispvector(&orig);
dispvector(&transf);
}




void transffemesh(femesh mesh,int grp,int which,vector param,
                  void (*transform)(vector orig,vector transf,vector param))
    /* The same as transffemesh0, except that the caller can specify by which
    how the co-ordinates are transformed.
      which<0 :
      transform is performed on original co-ordinates mesh->origcoord
    without affecting the current co-ordinates. If mesh->origcoord is NULL
    then the current co-ordinates are first copied to the original without
    a warning.
      which==0 (default):
      transform maps from original co-ordinates (mesh->origcoord) to current
    (mesh->nodcoord). If mesh->origcoord==NULL then current co-ordinates
    are first copied to original, and if mesh->nodcoord==NULL then original
    coordinates are first copied to current, without any warning.
      which>0 :
      transform will be performed on current co-ordinates (mesh->nodcoord).
    If mesh->nodcoord==NULL then original co-ordinates are first copied
    to current and a level warning is launched.
    $A Igor oct03; */
{
static char *funcname="transffemesh";
matrix stored;
if (mesh==NULL)
{
  errfunc0(funcname);
  sprintf(ers(),"The mesh is NULL.\n");
  errfunc2();
  return;
}
if (which<0)
{
  /* Copy original co-ordinates from current if not yet defined: */
  if (mesh->origcoord==NULL)
    copymatrix(mesh->nodcoord,&(mesh->origcoord));
  /* Perform transform only on original co-ordinates: */
  stored=mesh->nodcoord;
  mesh->nodcoord=mesh->origcoord;
  transffemeshbas(mesh,grp,param,transform);
  mesh->nodcoord=stored;
} else if (which==0)
{
  /* If either original or current co-ordinate are not defined yet, copy one
  to another: */
  if (mesh->origcoord==NULL)
    copymatrix(mesh->nodcoord,&(mesh->origcoord));
  else if (mesh->nodcoord==NULL)
    copymatrix(mesh->origcoord,&(mesh->nodcoord));
  /* Perform transform from original to current co-ordinates: */
  transffemeshbas(mesh,grp,param,transform);
} else /* which>0 */
{
  if (mesh->nodcoord==NULL)
  {
    errfunc0(funcname);
    sprintf(ers(),"Matrix of nodal co-ordinates is NULL.\n");
    if (mesh->origcoord!=NULL)
      sprintf(ers(),"Original co-ordinates will be copied to nodal co-ordinates.\n");
    errfunc2();
    copymatrix(mesh->origcoord,&(mesh->nodcoord));
  }
  /* Perform transform only on current co-ordinates: */
  stored=mesh->origcoord;
  mesh->origcoord=mesh->nodcoord;
  transffemeshbas(mesh,grp,param,transform);
  mesh->origcoord=stored;
}
}







int addfemesh(femesh mesh,femesh *maddr,int newgroups,double tolcoord)
    /* Adds elements and nodes of mesh to the finite element mesh whose address
    is maddr. *maddr may be NULL (in this case it is created and the function
    only copies the mesh on it) or may contain no elements.
      If newgroups is not 0 then element groups wirth the same numbers are not
    merged, but a new group is created on *maddr for each group on mesh.
      If tolcoord>=0 then nodes of the two meshes with the same co-ordinates
    are considered identical and only one node number is assigned to such a
    pair (this is always the number used on the original mesh). If tolcoord==0
    then only exact matching is considered. When tolcoord>0, two nodes are
    considered identical when absolute difference is below tolcoord for all
    of their co-ordinates.
      Returns 0 if operation succeeded or a negative number if there is an
    error. A warning is launched if mesh does no contain any nodes or elements
    (-1 is also returned in this case).
      Properties:
      Node and element numbers (if any) on *maddr are preserved. If there are
    holes in node or element numbering these are not filled.
      If there are identical nodes on mesh itself, they are olso joined into
    one node. Therefore you can use this function only for removal of multiple
    nodes (e.g. by adding a mesh to an empty mesh and then deletinf the added
    mesh). Function can even be used to number nodes in such a way that thre
    are no gaps and the fields (...)->nodnum and (...)->nodnuminv are not
    needed any more on the mesh structure.
      Warnings:
      Because of finite precision you should not set tolcoord to 0 except in
    some very exceptional cases where there is strong correlation between 
    generation of the original and added mesh.
      Only the current co-ordinates mesh->nodcoord of the added mesh are copied
    to *maddr while mesh->origcoord are not copied. (*maddr)->origcoord are
    deleted if they are not NULL. If original co-ordinates should be copied
    instead, they can simply be swaped before the operation.
    $A Igor feb04; */
{
indtab mapnodnum=NULL;
femesh orig=NULL;
elgrp group=NULL,meshgroup=NULL;
indtab it;
int i,j,k,identical,no,ex,origdim,ret=0;
int nodnum,nodind,elnum;
if (maddr==NULL)
{
  errfunc0("addfemesh");
  sprintf(ers(),"Address of the original mesh is NULL.\n");
  errfunc2();
  return -1;
} else if (mesh==NULL)
{
  warnfunc1(1,"addfemesh");
  sprintf(ers(),"Mesh to be added is NULL.\n");
  errfunc2();
  return -1; 
} else if (mesh->nodcoord==NULL || mesh->elgrp==NULL)
{
    warnfunc1(1,"addfemesh");
    sprintf(ers(),"Mesh to be added contains no nodes or elements.\n");
    errfunc2();
    return -1; 
}
if (*maddr==NULL)
  *maddr=newfemesh();
orig=*maddr;
/* Add nodes first; first calculate starting indices and node numbers
for added nodes in mesh: */
nodind=nodnum=0;
if (orig->nodcoord!=NULL)
  if (orig->nodcoord->d1>0)
  {
    nodind=orig->nodcoord->d1;
    if (orig->nodnum!=NULL)
    {
      /* Re-calculate the inverse index table for nodes if necessary: */
      if (orig->nodnuminv==NULL)
        femcalcnodnuminv(orig);
      /* See whether there are more indices than nodes: */
      if (orig->nodnuminv==NULL)
        nodnum=orig->nodcoord->d1;
      else
        nodnum=orig->nodnuminv->n;
    } else
      nodnum=orig->nodcoord->d1;
  }
/* Calculate inverse node number table for the added mesh if necessary: */
if (mesh->nodnum!=NULL && mesh->nodnuminv!=NULL)
  femcalcnodnuminv(mesh);
/* Get dimension of the original mesh co-ord. space: */
origdim=0;
if (orig->nodcoord!=NULL)
{
  origdim=orig->nodcoord->d2;
  if (orig->nodcoord->d2!=mesh->nodcoord->d2)
  {
    warnfunc1(1,"addfemesh");
    sprintf(ers(),"Co-ordinate dimensions are not equal for the original and added mesh.\n");
    sprintf(ers(),"Original mesh: %iD, added: %iD.\n",
     orig->nodcoord->d2,mesh->nodcoord->d2);
    warnfunc2();
    ret=-1;
  }
}
resizematrix(&(orig->nodcoord),nodind+mesh->nodcoord->d1,
             m_maxval(origdim,mesh->nodcoord->d2));
dispmatrix(&(orig->origcoord));
/* Prepare node number mapping table; we will need this for updating element
information on the targed mesh: */
if (mesh->nodnuminv!=NULL)
  mapnodnum=newindtabrn(1,mesh->nodnuminv->n);
else
  mapnodnum=newindtabrn(1,mesh->nodcoord->d1);
/* Increase excess on the (...)->nodnum of the target mesh for speed-up: */
if (orig->nodnum!=NULL)
{
  ex=orig->nodnum->ex;
  orig->nodnum->ex=1+mesh->nodcoord->d1;
}
/* Perform transcription: */
for (i=1;i<=mesh->nodcoord->d1;++i)
{
  identical=0; /* index of identical co-ordinates on the original mesh */
  if (tolcoord>=0)
    for (j=1;j<=nodind;++j)
    {  /* search for identical nodes among original and currently added */
      no=0;
      for (k=1;k<=mesh->nodcoord->d2;++k)
        if (fabs(mesh->nodcoord->m[i][k]-orig->nodcoord->m[j][k])>tolcoord)
        {
          no=1;
          break;
        }
      if (no==0)
      {
        identical=j;
        break;
      }
    }
  if (identical<1)
  {
    /* No identical found, increment map, num. and index & copy co-ordinates: */
    ++nodind;  ++nodnum;
    for (k=1;k<=mesh->nodcoord->d2;++k)
      orig->nodcoord->m[nodind][k]=mesh->nodcoord->m[i][k];
    if (orig->nodnum!=NULL)  /* update table of node numbers */
      pushindtab(orig->nodnum,nodnum);
    /* Update map of node numbers: */
    if (mesh->nodnuminv!=NULL)
      mapnodnum->t[mesh->nodnum->t[i]]=nodnum;
    else  /* node numbers on mesh correspond to node numbers */
      mapnodnum->t[i]=nodnum;
  } else
  {
    /* Identical node was found on orig, use this node, only update the map: */
    if (mesh->nodnuminv!=NULL)
      mapnodnum->t[mesh->nodnum->t[i]]=identical;
    else  /* node numbers on mesh correspond to node numbers */
      mapnodnum->t[i]=identical;
  }
}
if (orig->nodnum!=NULL)
{
  /* Restore excess on the (...)->nodnum of the target mesh to previous value
  and clean unused space: */
  orig->nodnum->ex=ex;
  if (orig->nodnum->r-orig->nodnum->n>ex+2)
    resizeindtab(&orig->nodnum,ex,orig->nodnum->n,orig->nodnum->n);
}
if (tolcoord>=0)
{
  /* It is possible that not all co-ordinates were occupied because of
  identical nodes, re-allocate the co-ordinates: */
  if (orig->nodcoord->d1>nodind)
    resizematrix(&(orig->nodcoord),nodind,orig->nodcoord->d2);
}
if (orig->nodnuminv!=NULL)
{
  dispindtab(&(orig->nodnuminv));
  femcalcnodnuminv(orig);
}
/* Copy elements, first mark the current highest element number and remove the
data that will need recalculation: */
if (orig->elgrpinv==NULL || orig->elnuminv==NULL)
  if (orig->elgrp!=NULL)
    if (orig->elgrp->n>0)
      femcalcelnuminv(orig);
if (orig->elnuminv==NULL)
  elnum=0;
else
  elnum=orig->elnuminv->n;
dispstackallspec(&(orig->eltopinv),(void (*) (void **)) dispindtab);
dispindtab(&(orig->elgrpinv));
dispindtab(&(orig->elnuminv));
for (i=1;i<=mesh->elgrp->n;++i)
{
  if (newgroups || i>orig->elgrp->n)
  {
    /* Element group from mesh is copied to a new element group on orig: */
    pushstack( orig->elgrp,(group=copyelgrp(mesh->elgrp->s[i],NULL)) );
    /* Clean the data that needs to be re-calculated: */
    dispstackallspec(&(group->outsurf),(void (*) (void **)) dispindtab);
    /* Update element and node numbers on element topology of the group by
    using the node number mapping table and current element number: */
    for (j=1;j<=group->elnum->n;++j)
    {
      ++elnum;  /* element number for the new element */
      group->elnum->t[j]=elnum;
      it=group->eltop->s[j];
      /* Map node numbers on mesh to node numbers on orig: */
      for (k=1;k<=it->n;++k)
        it->t[k]=mapnodnum->t[it->t[k]];
    }
  } else
  {
    /* Elements form the element group on mesh are added to the element group
    with the same serial number on orig: */
    if (orig->elgrp->s[i]!=NULL)
      if (((elgrp) orig->elgrp->s[i])->eltop==NULL)
        dispelgrp((elgrp *)&(orig->elgrp->s[i]));
    if (orig->elgrp->s[i]==NULL)
    {
      copyelgrp((elgrp) mesh->elgrp->s[i],(elgrp *) &(orig->elgrp->s[i]));
    } else
    {
      group=orig->elgrp->s[i];
      /* Clean the data that needs to be re-calculated: */
      dispstackallspec(&(group->outsurf),(void (*) (void **)) dispindtab);
      /* Add elements from mesh: */
      meshgroup=mesh->elgrp->s[i];
      for (j=1;j<=meshgroup->eltop->n;++j)
      {
        ++elnum;
        it=NULL;
        copyindtab(meshgroup->eltop->s[j],&it);
        /* Map node numbers on mesh to node numbers on orig: */
        for (k=1;k<=it->n;++k)
          it->t[k]=mapnodnum->t[it->t[k]];
        pushstack(group->eltop,it);
        pushindtab(group->elnum,elnum);
      }
    }
  }
}
if (!newgroups)
{
  /* Since elements were added to existing groups, we will re-number them
  so that the numbers will follow successively: */
  elnum=0;
  for (i=1;i<=orig->elgrp->n;++i)
  {
    group=orig->elgrp->s[i];
    if (group!=NULL)
    {
      if (group->elnum!=NULL)
      {
        for (j=1;j<=group->elnum->n;++j)
        {
          ++elnum;
          group->elnum->t[j]=elnum;
        }
      } else
      {
        /* Just for any case: If group->elnum==NULL then we add the number of
        elements of group->eltop to the current element counter elnum: */
        if (group->eltop!=NULL)
        {
          elnum+=group->eltop->n;
          warnfunc1(1,"addfemesh");
          sprintf(ers(),"Element group %i of the mesh where we add elements:\n",
              i);
          sprintf(ers(),"Table of element numbers is NULL, but topology contains %i elements.\n",
              group->eltop->n);
          warnfunc2();
          ret=-1;
        }
      }
    }
  }
}
dispindtab(&mapnodnum);
return ret;
}


void stretchtransform(vector orig,vector transf,vector param)
    /* Maps orig to transf by stretchig co-ordinates by the corresponding
    components of param. If param has less components than orig then the
    remaining components are not affected, except if param has only
    one component, in which case all components of orig are multiplied by 
    that component.
      Vectors orig and transf must be allocated and of compatible dimensions,
    otherwise error is reported. They can point to the same vector. param must
    also be allocated and of dimension at least 1.
    $A Igor feb04; */
{
int i;
static int reported=0;
if (orig==NULL || transf==NULL || param==NULL)
{
  errfunc0("stretchtransform");
  if (orig==NULL)
    sprintf(ers(),"Vector of original co-ordinates is NULL.\n");
  if (transf==NULL)
    sprintf(ers(),"Vector of transformed co-ordinates is NULL.\n");
  if (transf==NULL)
    sprintf(ers(),"Vector of parameters is NULL.\n");
  errfunc2();
} else if (orig->d==0 || transf->d!=orig->d || param->d<1)
{
  errfunc0("stretchtransform");
  sprintf(ers(),"Incompatible dimensions of vector arguments..\n");
  sprintf(ers(),"orig: %i, transf: %i, param: %i\n",orig->d,transf->d,param->d);
  errfunc2();
} else
{
  if(param->d==1)
  {
    for (i=1;i<=orig->d;++i)
      transf->v[i]=orig->v[i]*param->v[1];
  } else
  {
    for (i=1;i<=orig->d && i<=param->d;++i)
      transf->v[i]=orig->v[i]*param->v[i];
  }
}
}


void translationtransform(vector orig,vector transf,vector param)
    /* Maps orig to transf by translation by the corresponding components of
    param. If param has less components than orig then the remaining
    components are not affected (even if there is only one component - this is
    different for example from stretchtransform().
      Vectors orig and transf must be allocated and of compatible dimensions,
    otherwise error is reported. They can point to the same vector. param must
    also be allocated and of dimension at least 1.
    $A Igor feb04; */
{
int i;
static int reported=0;
if (orig==NULL || transf==NULL || param==NULL)
{
  errfunc0("translationtransform");
  if (orig==NULL)
    sprintf(ers(),"Vector of original co-ordinates is NULL.\n");
  if (transf==NULL)
    sprintf(ers(),"Vector of transformed co-ordinates is NULL.\n");
  if (transf==NULL)
    sprintf(ers(),"Vector of parameters is NULL.\n");
  errfunc2();
} else if (orig->d==0 || transf->d!=orig->d || param->d<1)
{
  errfunc0("translationtransform");
  sprintf(ers(),"Incompatible dimensions of vector arguments..\n");
  sprintf(ers(),"orig: %i, transf: %i, param: %i\n",orig->d,transf->d,param->d);
  errfunc2();
} else
{
 for (i=1;i<=orig->d && i<=param->d;++i)
    transf->v[i]=orig->v[i]+param->v[i];
}
}

int femgrid(femesh cell,femesh *maddr,int newgroups,double tolcoord,
            int numx,int numy,int numz,
            mat3d transmat,vec3d shift)
    /* Takes the finite element mesh cell and creates a grid of equal meshes by
    translating and copying it. The created grid is added to *maddr, which is
    created anew if necessary. If any element groups already exist on *maddr
    they are kept, therefore cara of cleaning the original contents must be 
    taken specially if this is necessary.
      If newgroups==0 then groups numbers of the original cells are preserved,
    (i.e. element groups in all copied cells and eventually the original mesh
    with the same group number are merged into one group). If tolcoord>=0 it
    is used to identify which nodes in the created grid (eventually together
    with the original mesh) have the same (witgin tolerance) co-ordinates.
    Such groups of multiple nodes are then replaced by a single node. tolcoord
    0 should be rarely used (because of numerical errors obteined at
    translation). Two nodes are consitered identical if all co-ordinates differ
    absolutely by something less or equal tol.
      numx, numy and numz specify the number of cells in a grid in three
    directions, transmat specifies the three translation vectors for
    creating the lattice of cells and shift specifies the shift by which the
    entire grid is shifted, both can be NULL. Basis cell is located at the same
    co-ordinates as the original, translated by shift.
      If shift is NULL then the grid is not shifted. If transmat is NULL
    then the translation vectors are set in the co-ordinate directions x, y
    and z such that their sizes equal to sizes of sides of the smallest 3D
    frame (sides parallel to co-ordinate axes) that contains the mesh.
    $A Igor feb04; */
{
int ret=0,dim=0,ix,iy,iz,i;
_mat3d tr={0};
vector shiftvec=NULL,transvec=NULL,min=NULL,max=NULL;
matrix coord=NULL,shiftcord=NULL;
if (cell==NULL)
{
  errfunc0("femgrid");
  sprintf(ers(),"The cell mesh is not initialized.\n");
  errfunc2();
  return -1;
} else if (maddr==NULL)
{
  errfunc0("femgrid");
  sprintf(ers(),"The address of the grid mesh data is not specified.\n");
  errfunc2();
  return -1;
} else
{
  if (numx<1) numx=1;   if (numy<1) numy=1;   if (numy<1) numz=1;
  if (transmat==NULL)
  {
    /* Translation vectors not specified, calculate them from the co-ordinate
    limits of the mesh: */
    transmat=&(tr);
    femcalclimits(cell,&min,&max);
    if (min!=NULL)
    {
      if (min->d>=1)
        tr.x.x=max->v[1]-min->v[1];
      if (min->d>=2)
        tr.y.y=max->v[2]-min->v[2];
      if (min->d>=3)
        tr.z.z=max->v[3]-min->v[3];
    }
    dispvector(&min);  dispvector(&max);
  }
}
if (cell->nodcoord!=NULL)
  dim=cell->nodcoord->d2;
else if (cell->origcoord!=NULL)
  dim=cell->origcoord->d2;
/* Store co-ordinates for later restore: */
copymatrix(cell->nodcoord,&coord);
if (shift!=NULL)
{
  /* Perform shift of the basic cell: */
  shiftvec=getvector(dim);
  if (dim>=1)
    shiftvec->v[1]=shift->x;
  if (dim>=2)
    shiftvec->v[2]=shift->y;
  if (dim>=3)
    shiftvec->v[3]=shift->z;
  /*
  transffemesh(cell,0,1,shiftvec,translationtransform);
  */
}
transvec=getvector(dim);
for (i=1;i<=transvec->d;++i)
  transvec->v[i]=0;
for (ix=1;ix<=numx;++ix)
  for (iy=1;iy<=numy;++iy)
    for (iz=1;iz<=numz;++iz)
    {
      if (dim>=1)  /* Set up first component of the translation vector: */
      {
        /* Add x-component of translation vectors multiplied by the appropriate
        grid index to the x component of translation vector: */
        transvec->v[1]=(ix-1)*transmat->x.x+
          (iy-1)*transmat->y.x+(iz-1)*transmat->z.x;
        if (shiftvec!=NULL)
          transvec->v[1]+=shiftvec->v[1];
      }
      if (dim>=2)  /* Set up first component of the translation vector: */
      {
        transvec->v[2]=(ix-1)*transmat->x.y+
          (iy-1)*transmat->y.y+(iz-1)*transmat->z.y;
        if (shiftvec!=NULL)
          transvec->v[2]+=shiftvec->v[2];
      }
      if (dim>=3)  /* Set up first component of the translation vector: */
      {
        transvec->v[3]=(ix-1)*transmat->x.z+
          (iy-1)*transmat->y.z+(iz-1)*transmat->z.z;
        if (shiftvec!=NULL)
          transvec->v[1]+=shiftvec->v[1];
      }
      /* Restore original co-ordinates of the mesh cell, translate the cell and
      add the translated cell to the grid: */
      copymatrix(coord,&(cell->nodcoord));
      transffemesh(cell,0,1,transvec,translationtransform);
      addfemesh(cell,maddr,newgroups,tolcoord);
    }

/* Restore original co-ordinates of cell: */
dispmatrix(&(cell->nodcoord));
cell->nodcoord=coord;
coord=NULL;
dispvector(&transvec);  dispvector(&shiftvec);
return ret;
}






    /* FOR the FEAP INTERFACE: */


int fwritefemeshfeap(FILE *fp,femesh mesh)
    /* Writes the finite element mesh in the FEAP format to the file fp 
    starting from the current position in the file. Returns 0 if OK, negative
    value in the case of error.
    $A Igor feb04; */
{
int i,j,k,tot,err=0,ret=0;
matrix coord;
elgrp group;
indtab nodnum,elnum,elnod;
if (mesh==NULL)
{
  sprintf(ers(),"Mesh data is NULL!.\n");
  errfunc2();
  return -1;
} else if (fp==NULL)
{
  errfunc0("fwritefemeshfeap");
  sprintf(ers(),"The file is not open.\n");
  errfunc2();
  return -1;
}
/* Print the head: */
fprintf(fp,"\n! FEAP mesh file, generated from Igor's mesh structure\n");
fprintf(fp,"! Time of generation: ");
fprinttime(fp);
fprintf(fp,"\n\n");

/* Print nodal co-ordinates: */
if (mesh->nodcoord==NULL)
{
  errfunc0("fwritefemeshfeap");
  sprintf(ers(),"Matrix of nodal co-ordinates does not exist.\n");
  errfunc2();
  fprintf(fp,"\n! Error: Co-ordinate field is empty.\n");
  ret=-1;
} else
{
  coord=mesh->nodcoord;
  if (coord->d1==0 || coord->d2==0)
  {
    errfunc0("fwritefemeshfeap");
    sprintf(ers(),"Dimensions of nodal co-ordinates field are 0.\n");
    errfunc2();
    fprintf(fp,"\n! Error: Co-ordinate field is empty (dimensions are 0).\n");
    ret=-1;
  } else
  {
    fprintf(fp,"! Nodal co-ordinates (%i*%i):\n",coord->d1,coord->d2);
    fprintf(fp,"COOR\n");
    nodnum=mesh->nodnum;
    if (nodnum==NULL)
    {
      for (i=1;i<=coord->d1;++i)
      {
        fprintf(fp,"  %-5i 0",i);
        for (j=1;j<=coord->d2;++j)
          fprintf(fp,"  %20.16f",coord->m[i][j]);
        fprintf(fp,"\n");
      }
    } else
    {
      if (nodnum->n>=coord->d1)
      {
        for (i=1;i<=coord->d1;++i)
        {
          fprintf(fp,"  %-5i 0",nodnum->t[i]);
          for (j=1;j<=coord->d2;++j)
            fprintf(fp,"  %20.16f",coord->m[i][j]);
          fprintf(fp,"\n");
        }
      } else
      {
        for (i=1;i<=coord->d1;++i)
        {
          fprintf(fp,"  %-5i 0",i);
          for (j=1;j<=coord->d2;++j)
            fprintf(fp,"  %20.16f",coord->m[i][j]);
          fprintf(fp,"\n");
        }
      }
    }
  }
}
if (err)
  fprintf(fp,"! %i inconsistencies encountered in co-ordinate data.\n");
err=0;
fprintf(fp,"\n\n");
/* Print connectivity data ("mesh topology"): */
if (mesh->elgrp==NULL)
{
  errfunc0("fwritefemeshfeap");
  sprintf(ers(),"Stack of element groups is NULL.\n");
  errfunc2();
  fprintf(fp,"\n! Error: No element groups.\n");
  ret=-1;
} else if (mesh->elgrp->n==0)
{
  errfunc0("fwritefemeshfeap");
  sprintf(ers(),"No element groups on the stack.\n");
  errfunc2();
  fprintf(fp,"\n! Error: No element groups.\n");
  ret=-1;
} else
{
  fprintf(fp,"! Mesh connectivity; number of element groups: %i.\n",
    mesh->elgrp->n);
  fprintf(fp,"! Remark: Material numbers will correspond to element groups.\n");
  tot=0;
  for (i=1;i<=mesh->elgrp->n;++i)
  {
    group=mesh->elgrp->s[i];
    if (mesh->elgrp->n>1)
    {
      fprintf(fp,"! Group %i",i);
      if (stringlength(group->name)>0)
        fprintf(fp," (named \"%s\"):",group->name);
      else
        fprintf(fp,":");
      if (group->eltop!=NULL)
      {
        tot+=group->eltop->n;
        fprintf(fp," %i elements\n",group->eltop->n);
      }
      else
        fprintf(fp," no elements on this group.\n");
    }
  }
  fprintf(fp,"! Total: %i elements.\n",tot);
  fprintf(fp,"\nELEM\n");
  for (i=1;i<=mesh->elgrp->n;++i)
  {
    group=mesh->elgrp->s[i];
    if (group==NULL)
    {
      warnfunc1(1,"fwritefemeshfeap");
      sprintf(ers(),"Element group %i is NULL.\n",i);
      warnfunc2();
      /* no comments in the middle of the field!
      fprintf(fp,"! Warning: Eement group %i contains no elements.\n",i);
      */
    } else
    {
      if (group->eltop==NULL)
      {
        warnfunc1(1,"fwritefemeshfeap");
        sprintf(ers(),"Element group %i does not contain any elements.\n",i);
        warnfunc2();
        ++err;
        /* no comments in the middle of the field!
        fprintf(fp,"! Warning: Eement group %i contains no elements.\n",i);
        */
      } else if (group->eltop->n<1)
      {
        warnfunc1(1,"fwritefemeshfeap");
        sprintf(ers(),"Element group %i does not contain any elements.\n",i);
        warnfunc2();
        ++err;
        /* no comments in the middle of the field!
        fprintf(fp,"! Warning: Eement group %i contains no elements.\n",i);
        */
      } else
      {
        elnum=NULL;
        if (group->elnum!=NULL)
        {
          if (group->elnum->n>=group->eltop->n)
            elnum=group->elnum;
          else
          {
            warnfunc1(1,"fwritefemeshfeap");
            sprintf(ers(),"Number of elements on the topology stack %i does not match.\n",
                group->eltop->n);
            sprintf(ers(),"The number of indices in element number table (%i) for group %i.\n",
                group->elnum->n,i);
            warnfunc2();
            ++err;
            ret=-1;
            /* no comments in the middle of the field!
            fprintf(fp,"! Warning: Unequal number of elements %i and their indices %i for group %i.\n",
              group->eltop->n,group->elnum->n,i);
            */
          }
        }
        if (elnum==NULL)
        {
          for (j=1;j<=group->eltop->n;++j)
          {
            elnod=group->eltop->s[j];
            if (elnod!=NULL)
              if (elnod->n<1)
                elnod=NULL;
            if (elnod==NULL)
            {
              warnfunc1(3,"fwritefemeshfeap");
              sprintf(ers(),"Element %i of group %i contains no nodes.\n",j,i);
              warnfunc2();
              ++err;
              ret=-1;
              /* no comments in the middle of the field!
              fprintf(fp,"! Warning: Element %i of group %i contains no nodes.\n",j,i);
              */
            } else
            {
              fprintf(fp,"  %-5i 0 %-3i",j,i);
              for (k=1;k<=elnod->n;++k)
                fprintf(fp,"  %5i",elnod->t[k]);
              fprintf(fp,"\n");
            }
          }
        } else
        {
          for (j=1;j<=group->eltop->n;++j)
          {
            elnod=group->eltop->s[j];
            if (elnod!=NULL)
              if (elnod->n<1)
                elnod=NULL;
            if (elnod==NULL)
            {
              warnfunc1(3,"fwritefemeshfeap");
              sprintf(ers(),"Element %i of group %i contains no nodes.\n",j,i);
              warnfunc2();
              ++err;
              ret=-1;
              /*  no comments in the middle of the field!
              fprintf(fp,"! Warning: Element %i of group %i contains no nodes.\n",j,i);
              */
            } else
            {
              fprintf(fp,"  %-5i 0 %-3i",elnum->t[j],i);
              for (k=1;k<=elnod->n;++k)
              {
                fprintf(fp,"  %5i",elnod->t[k]);
              }
              fprintf(fp,"\n");
            }
          }
        }
      }
    }
  }
  if (err)
    fprintf(fp,"! %i inconsistencies encountered in connectivity data.\n");
  fprintf(fp,"\n! End of generated data.\n\n");
  fflush(fp);
}
return ret;
}


int filewritemeshfeap(char *filename,femesh mesh)
    /* Writes the finite element mesh in the FEAP format to the file named
    filename. Returns 0 if OK, negative value in the case of error. If the
    file with that name exists its contents are overwritten.
    $A Igor feb04; */
{
FILE *fp=NULL;
int ret=0;
if (filename!=NULL)
  fp=fopen(filename,"w");
if (fp==NULL)
{
  errfunc0("filewritemeshfeap");
  sprintf(ers(),"File %s could not be open for writing.\n");
  errfunc2();
  return -1;
} else
{
  ret=fwritefemeshfeap(fp,mesh);
  fclose(fp);
  return ret;
}
return ret;
}









    /* PLOTTING FE MESHES: */






gogroup gofemeshplotbas(femesh mesh,int ngroup,
          char frout,char fillout,char frin,char fillin,
          char pelnum,char pnodnum,char pnodes,
          gofillsettings fs,golinesettings ls,
          gotextsettings tselements,gotextsettings tsnodes,
          golinesettings lsnodes,int markertype,double markersize)
    /* Creates and returns a plot of a finite element mesh mesh or one of its
    element groups. If ngroup is 0 then all element groups are plotted,
    otherwise just the element group whose number is ngroup is plotted.
      If frout is different than 0 then the frame is plotted for outer element
    surfaces of the group, if fillout is different than 0 then a filled frame
    is plotted for outer surfaces, if frin is different than 0 then a frame is
    plotted for internal element surfaces, and if fillin is different than 0
    then the filled frame is also plotted for the inner surfaces.
      pelnum is an orr-ed combination of flags that determine if and how the
    element numbers are plotted with the mesh. If 1 is set then element numbers
    are plotted, if 2 is set then the surface numbers are also plotted where
    appropriate and if 4 is set (3rd bit) then the group number is plotted with
    each element.
      If pnodnum is different than 0 then node numbers are plotted. If pnodes
    is different than 0 then markers are plotted for nodes.
      fs are fill settings for coloring element surfaces, ls are line settings
    for plotting element outlines, and tselements are text settings for
    plotting element numbers and tsnodes are text settings for plotting node
    numbers. lsnodes are line settings for plotting node markers, markertype
    is the type of markers plotted for nodes and markersize is their size.
    $A Igor sep03; */
{
int firstgroup,lastgroup,groupnum;
char buf[100],*ptr;
gogroup ret=NULL,retframe=NULL,retnodnums=NULL,retelnums=NULL,retnodes=NULL;
    elgrp grp=NULL;
    int el,m2d,m3d,i,j,surfnum,numsurf,outersurf,nodeind;
    _coord3d *pt,centel,centsurf,coord;
    indtab nodes=NULL,topology=NULL,surf=NULL;
    stack coords=NULL,nodesafter=NULL,st=NULL;
    goprimitive structprim,labelprim1,labelprim2;
    
#define m_registernodeafter(nodnum,primitive)  \
    if (primitive!=NULL)  \
    {  \
      int index=femnodeind(mesh,nodnum);  \
      if (index>0)  \
      {  \
        if (nodesafter->n<index)  \
          setstack(nodesafter,newstack(6),index);  \
        if (nodesafter->s[index]==NULL)  \
          nodesafter->s[index]=newstack(6);  \
        pushstack(nodesafter->s[index],primitive);  \
      }  \
    }

nodesafter=newstack(100);
ret=newgogroupst(5,1,1);
ptr=buf;
if (ngroup>0)
  ptr+=sprintf(buf,"FE mesh for element group %i",ngroup);
else
  ptr+=sprintf(buf,"FE mesh for all element groups");
ret->name=stringcopy(buf);
retframe=newgogroupst(1,100,100);
pushstack(ret->groups,retframe);
retframe->name=stringcopy("Sceleton");
retframe->ls1=calloc(1,sizeof(*(ret->ls1)));
if (ls!=NULL)
  *(retframe->ls1)=*ls;
else
{
  /* Default line settings: */
  retframe->ls1->color.red=0;  retframe->ls1->color.green=0;
  retframe->ls1->color.blue=0.7f;
  retframe->ls1->linewidth=1.0f;
  retframe->ls1->linetype=1;
  retframe->ls1->extra=NULL;
}
retframe->fs1=calloc(1,sizeof(*(ret->fs1)));
if (fs!=NULL)
  *(retframe->fs1)=*fs;
else
{
  /* Default fill settings: */
  retframe->fs1->color.red=1; retframe->fs1->color.green=1;
  retframe->fs1->color.blue=0.5;
  retframe->fs1->extra=NULL;
}
if (pelnum)
{
  retelnums=newgogroupst(1,100,100);
  pushstack(ret->groups,retelnums);
  retelnums->name=stringcopy("Element numbers");
  retelnums->ts1=calloc(1,sizeof(*(retelnums->ts1)));
  if (tselements!=NULL)
    *(retelnums->ts1)=*tselements;
  else
  {
    retelnums->ts1->color.red=0;  retelnums->ts1->color.green=0.6f;
    retelnums->ts1->color.blue=0;
    retelnums->ts1->font=9;
    retelnums->ts1->height=0.01;
    retelnums->ts1->xalignment=0;
    retelnums->ts1->yalignment=0;
    retelnums->ts1->extra=NULL;
  }
}
if (pnodnum)
{
  retnodnums=newgogroupst(1,100,100);
  pushstack(ret->groups,retnodnums);
  retnodnums->name=stringcopy("Node numbers");
  retnodnums->ts1=calloc(1,sizeof(*(retnodnums->ts1)));
  if (tsnodes!=NULL)
    *(retnodnums->ts1)=*tsnodes;
  else
  {
    retnodnums->ts1->color.red=1;  retnodnums->ts1->color.green=0;
    retnodnums->ts1->color.blue=0;
    retnodnums->ts1->font=1;
    retnodnums->ts1->height=0.008;
    retnodnums->ts1->xalignment=1;
    retnodnums->ts1->yalignment=0;
    retnodnums->ts1->extra=NULL;
  }
}
if (pnodes)
{
  retnodes=newgogroupst(1,100,100);
  pushstack(ret->groups,retnodes);
  retnodes->name=stringcopy("Nodes");
  retnodes->ls1=calloc(1,sizeof(*(retnodes->ls1)));
  if (lsnodes!=NULL)
    *(retnodes->ls1)=*lsnodes;
  else
  {
    /* Default line settings for nodes: */
    retnodes->ls1->color.red=0;  retnodes->ls1->color.green=0.2f;
    retnodes->ls1->color.blue=0.7f;
    retnodes->ls1->linewidth=1.0f;
    retnodes->ls1->linetype=1;
    retnodes->ls1->extra=NULL;
  }
}
if (markersize==0)
  markersize=0.008;
if (mesh==NULL)
{
  errfunc0("gofemeshplotbas");
  sprintf(ers(),"Mesh pointer is NULL.\n");
  errfunc2();
} else if (mesh->elgrp==NULL)
{
  errfunc0("gofemeshplotbas");
  sprintf(ers(),"Element group data is missing.\n");
  errfunc2();
} else if (mesh->elgrp->n<1)
{
  errfunc0("gofemeshplotbas");
  sprintf(ers(),"No element groups defined.\n");
  errfunc2();
} else if (mesh->nodcoord==NULL)
{
  errfunc0("gofemeshplotbas");
  sprintf(ers(),"Nodal co-ordinates are not specified.\n");
  errfunc2();
} else
{
  /* Define which element groups to plot: */
  if (ngroup>0)
    firstgroup=lastgroup=ngroup;
  else
  {
    firstgroup=1;
    lastgroup=mesh->elgrp->n;
  }
  for (groupnum=firstgroup; groupnum<=lastgroup;++groupnum)
  {
    /* Iterate over element groups: */
    if (groupnum>0 || groupnum<=mesh->elgrp->n)
      grp=mesh->elgrp->s[groupnum];
    if (grp==NULL)
    {
      errfunc0("gofemeshplotbas");
      sprintf(ers(),"There is no group of elements No. %i.\n",groupnum);
      errfunc2();
      continue;
    }
    if (grp->eltop==NULL)
    {
      errfunc0("gofemeshplotbas");
      sprintf(ers(),"No element topology for group No. %i.\n",groupnum);
      errfunc2();
      continue;
    }
    /* Determine whether there is a 3D or a 2D mesh: */
    if (grp->surfedg==NULL)
    {
      errfunc0("gofemeshplotbas");
      sprintf(ers(),"Number of edges per el. surface not specidied for group No. %i.\n",groupnum);
      errfunc2();
      continue;
    }
    if (grp->surftop==NULL)
    {
      errfunc0("gofemeshplotbas");
      sprintf(ers(),"Element surface topology not specidied for group No. %i.\n",groupnum);
      errfunc2();
      continue;
    }
    /* Determine if the mesh is 2D or 3D: */
    m2d=femel2d(grp,1);
    if (m2d)
      m3d=0;
    else
      m3d=femel3d(grp,1);
    if (!m2d && !m3d)
    {
      errfunc0("gofemeshplotbas");
      sprintf(ers(),"Can not determine whether the mesh is 2D or 3D.\n",groupnum);
      errfunc2();
      continue;
    }
    if (m2d)
    {
      /* Iterate over elements: */
      for (el=1;el<=grp->eltop->n;++el)
      {
        /* Two dimensional mesh, each element has only one surface and this is
        external: */
        numsurf=femnumelsurf(grp,el);
        if (numsurf<3)
        {
          static int reported=0;
          if (! reported)
          {
            ++reported;
            errfunc0("gofemeshplotbas");
            sprintf(ers(),"Number of surfaces can not be determined for %ith element of group No. %i.\n",el,groupnum);
            if (grp->elnum!=NULL)
              if (grp->elnum->n>=el)
                sprintf(ers(),"Global number of this element is %i.\n",grp->elnum->t[el]);
            errfunc2();
            continue;
          }
        }
        /* Pick nodes that are apeces of the surface: */
        if (nodes==NULL)
          nodes=newindtab(5,0);
        nodes->n=0;
        for (surfnum=1;surfnum<=numsurf;++surfnum)
        {
          /* In 2D, the 1st and the 2nd node of each surface are the apex nodes
          of the element: */
          addindtabun(nodes,femelsurfnode(grp,el,surfnum,1),0,0);
          addindtabun(nodes,femelsurfnode(grp,el,surfnum,2),0,0);
          /* Check if any of the node numbers is 0: */
          i=0;
          for (j=1;j<=nodes->n;++j)
            if (nodes->t[j]==0)
              ++i;
          if (i>0)
          {
            static int reported=0;
            if (! reported)
            {
              ++reported;
              errfunc0("gofemeshplotbas");
              sprintf(ers(),"Element surface topology is invalid for the surface %i of element %i \nof group No. %i.\n",
                surfnum,el,groupnum);
              if (grp->elnum!=NULL)
              errfunc2();
              continue;
            }
          }
        }
        if (coords==NULL)
          coords=newstack(5);
        while (coords->n<nodes->n)
          pushstack(coords,malloc(sizeof(*pt)));
        centsurf.x=centsurf.y=centsurf.z=0;
        for (i=1;i<=nodes->n;++i)
        {
          /* Extract co-ordinates: */
          pt=coords->s[i];
          femnodcoords(mesh,nodes->t[i],pt);
          centsurf.x+=pt->x;  centsurf.y+=pt->y;  centsurf.z+=pt->z;
        }
        centsurf.x/=(double) nodes->n;  centsurf.y/=(double) nodes->n;
        centsurf.z/=(double) nodes->n;
        structprim=NULL;
        if (nodes->n==3)
        {
          if (fillout)
            structprim=goaddbordtriangle(coords->s[1],coords->s[2],coords->s[3],
              retframe->primitives,retframe);
          else if (frout)
            structprim=goaddtriangle(coords->s[1],coords->s[2],coords->s[3],
              retframe->primitives,retframe);
        } else if (nodes->n>=4)
        {
          if (fillout)
            structprim=goaddbordfourangle(coords->s[1],coords->s[2],coords->s[3],coords->s[4],
            retframe->primitives,retframe);
          else if (frout)
            structprim=goaddfourangle(coords->s[1],coords->s[2],coords->s[3],coords->s[4],
            retframe->primitives,retframe);
          if (nodes->n>4)
          {
            static int reported=0;
            if (!reported)
            {
              ++ reported;
              warnfunc1(1,"gofemeshplotbas");
              sprintf(ers(),"Element surface has more than 4 apices (%i).\n",nodes->n);
              warnfunc2();
            }
          }
        } else
        {
          static int reported=0;
          if (!reported)
          {
            ++ reported;
            errfunc0("gofemeshplotbas");
            sprintf(ers(),"Element surface has less than 3 apices (%i).\n",nodes->n);
            warnfunc2();
          }
        }
        /* Plot element numbers if required: */
        if ((pelnum&(1|4)) && structprim!=NULL)
        {
          /*
          if (printelsurf)
            sprintf(buf,"%i.%i",grp->elnum->t[el],surfnum);
          else
          */
          *buf=0;
          if (pelnum&4)
          {
            sprintf(buf,"%i",groupnum);
            if (pelnum&1)
              sprintf(buf+strlen(buf),".");
          }
          if (pelnum&1)
            sprintf(buf+strlen(buf),"%i",grp->elnum->t[el]);
          labelprim1=goaddtext(buf,&centsurf,retelnums->extraprimitives,
            retelnums);
          if (structprim->after==NULL)
            structprim->after=newstack(1);
          pushstack(structprim->after,labelprim1);
        } else
        {
          /* The frame is not drawn, the element labels should be put on the
          stack retelnums->primitives for independent drawing:
          - not implemented (for now labels can only be drawin with the
          frame! */
        }
        if ((pnodnum || pnodes) && structprim!=NULL)
        {
          /* Ensure that the surfaces will not be plotted over node labels or
          markers: */
          for (i=1;i<=femnumelnodes(grp,el);++i)
          {
            m_registernodeafter(femelnode(grp,el,i),structprim);
            /*
            int nodnum;
            goprimitive primitive;
            if (nodesafter==NULL)  \
              nodesafter=newstack(100);  \
            if (femnodeind(mesh,nodnum)>0)  \
            {  \
              int index=femnodeind(mesh,nodnum);  \
              if (nodesafter->n<index)  \
                setstack(nodesafter,newstack(6),index);  \
              if (nodesafter->s[index]==NULL)  \
                nodesafter->s[index]=newstack(6);  \
              pushstack(nodesafter->s[index],primitive);  \
            }
            */
          }
        }
      }
    } else if (m3d)
    {
      /* Three dimensional mesh: */


      /* We make sure that the outer surfaces are identified: */
      if (grp->outsurf==NULL)
        femcalcoutsurf(mesh,0);
      /*
        identifyfemeshsurfgrp(mesh);
      */
      /* Iterate over elements: */
      for (el=1;el<=grp->eltop->n;++el)
      {
        if (frin && pelnum)
          centel.x=centel.y=centel.z=0;
        /* Check the individual surfaces of the element: */
        numsurf=femnumelsurf(grp,el);
        if (numsurf<4)
        {
          static int reported=0;
          if (! reported)
          {
            ++reported;
            errfunc0("gofemeshplotbas");
            sprintf(ers(),"Number of surfaces can not be determined for %ith element of group No. %i.\n",el,groupnum);
            sprintf(ers(),"Less than 3 surfaces (%i) identified for a 3D element.\n",numsurf);
            if (grp->elnum!=NULL)
              if (grp->elnum->n>=el)
                sprintf(ers(),"Global number of this element is %i.\n",grp->elnum->t[el]);
            errfunc2();
            continue;
          }
        }
        if (nodes==NULL)
          nodes=newindtab(5,0);
        for (surfnum=1;surfnum<=numsurf;++surfnum)
        {
          /* Check if the surface is outer one: */
          outersurf=femelsurfext(mesh,grp,el,surfnum);
          /* Zero the average coord.: */
          centsurf.x=centsurf.y=centsurf.z=0;
          /* Get the nodes that define the outline (apices of the surface); the
          following only work if in element surface topology data (grp->surftop)
          the nodes in apices of the element surface are listed first: */
          nodes->n=0;
          for (i=1;i<=femnumelsurfedges(grp,el,surfnum);++i)
            pushindtab(nodes,femelsurfnode(grp,el,surfnum,i));
          if (nodes->n<3)
          {
            static int reported=0;
            if (!reported)
            {
              ++ reported;
              errfunc0("gofemeshplotbas");
              sprintf(ers(),"Element surface has less than 3 apices (%i).\n",nodes->n);
              warnfunc2();
            }
          }
          /* Check if any of the node numbers is 0: */
          i=0;
          for (j=1;j<=nodes->n;++j)
            if (nodes->t[j]==0)
              ++i;
          if (i>0)
          {
            static int reported=0;
            if (! reported)
            {
              ++reported;
              errfunc0("gofemeshplotbas");
              sprintf(ers(),"Element surface topology is invalid for the surface %i of element %i \nof group No. %i.\n",
                surfnum,el,groupnum);
              if (grp->elnum!=NULL)
              errfunc2();
              continue;
            }
          }
          if (coords==NULL)
            coords=newstack(5);
          while (coords->n<nodes->n)
            pushstack(coords,malloc(sizeof(*pt)));
          for (i=1;i<=nodes->n;++i)
          {
            /* Extract co-ordinates of apices: */
            pt=coords->s[i];
            femnodcoords(mesh,nodes->t[i],pt);
            /* Accummulate data for the center: */
            centsurf.x+=pt->x; centsurf.y+=pt->y; centsurf.z+=pt->z;
          }
          centsurf.x/=(double) nodes->n; centsurf.y/=(double) nodes->n;
          centsurf.z/=(double) nodes->n;
          structprim=NULL;
          if (outersurf && fillout || !outersurf && fillin)
          {
            if (nodes->n==3)
              structprim=goaddbordtriangle(coords->s[1],coords->s[2],coords->s[3],
                  retframe->primitives,retframe);
            else
              structprim=goaddbordfourangle(coords->s[1],coords->s[2],coords->s[3],
                  coords->s[4],retframe->primitives,retframe);
          } else if (outersurf && frout || !outersurf && frin)
          {
            if (nodes->n==3)
              structprim=goaddtriangle(coords->s[1],coords->s[2],coords->s[3],
                  retframe->primitives,retframe);
            else
              structprim=goaddfourangle(coords->s[1],coords->s[2],coords->s[3],
                  coords->s[4],retframe->primitives,retframe);
          }
          /* Plot element numbers if required: */
          if (pelnum && structprim!=NULL && 
              (fillout && outersurf || fillin && !outersurf || 
              frout && ! frin && !fillout && !fillin) )
          {
            /*
            if (printelsurf)
              sprintf(buf,"%i.%i",grp->elnum->t[el],surfnum);
            else
              sprintf(buf,"%i",grp->elnum->t[el]);
            */
            *buf=0;
            if (pelnum & 4)
            {
              sprintf(buf,"%i",groupnum);
              if (pelnum & 1)
                sprintf(buf+strlen(buf),".");
            }
            if (pelnum&1)
            {
              sprintf(buf+strlen(buf),"%i",grp->elnum->t[el]);
            }
            if (pelnum & 2)
              sprintf(buf+strlen(buf),".%i",surfnum);
            labelprim1=goaddtext(buf,&centsurf,retelnums->extraprimitives,
              retelnums);
            if (structprim->after==NULL)
              structprim->after=newstack(1);
            pushstack(structprim->after,labelprim1);
          } else
          {
            /* The frame is not drawn, the element labels should be put on the
            stack retelnums->primitives for independent drawing:
            - not implemented (for now labels can only be drawin with the
            frame! */
          }
				  if ((pnodnum || pnodes) && structprim!=NULL)
          {
            /* Store information to ensure later that the surfaces will not be
            plotted over node labels or markers: */
            for (i=1;i<=femnumelsurfnodes(grp,el,surfnum);++i)
              m_registernodeafter(femelsurfnode(grp,el,surfnum,i),structprim);
          }

          if (frin && pelnum)
          {
            centel.x+=centsurf.x; centel.y+=centsurf.y; centel.z+=centel.z;
          }
        } /* it. over surfaces of one element */
        if (frin && pelnum)
        {
          /* Element label at the center of the element */
          centel.x/=(double) numsurf;  centel.y/=(double) numsurf;
          centel.z/=(double) numsurf;
          sprintf(buf,"%i",grp->elnum->t[el]);
          labelprim1=goaddtext(buf,&centsurf,retelnums->primitives,
              retelnums);
        }
      }  /* it. over elements */
    }
  }
}
if (pnodnum || pnodes)
  if (mesh->nodcoord!=NULL)
  {
    for (nodeind=1;nodeind<=mesh->nodcoord->d1;++nodeind)
    {
      /* Get the co-ordinates of the node: */
      i=femnodcoordsind(mesh,nodeind,&coord);
      if (i>0)
      {
        labelprim1=labelprim2=NULL;
        /* We check if there are primitives on top of which given node or its
        label should be plotted: */
        st=NULL;
        if (nodesafter!=NULL)
          if (nodesafter->n>=nodeind)
            st=nodesafter->s[nodeind];
        if (st!=NULL) if (st->n==0) st=NULL;
        if (st!=NULL)
        {
          /* The primitivs will be attached to another ones: */
          if (pnodes)
            labelprim1=goaddmarker(&coord,markersize,markertype,
                 retnodes->extraprimitives,retnodes);
          if (pnodnum)
          {
            sprintf(buf,"%i",femnodenum(mesh,nodeind));
            labelprim2=goaddtext(buf,&coord,
                retnodnums->extraprimitives,retnodnums);
          }
          for (i=1;i<=st->n;++i)
          {
            structprim=st->s[i];
            if (structprim->after==NULL)
              structprim->after=newstack(5);
            if (labelprim1!=NULL)
              pushstack(structprim->after,labelprim1);
            if (labelprim2!=NULL)
              pushstack(structprim->after,labelprim2);
          }
        } else
        {
          /* The primitive is stand-alone: */
          if (pnodes)
            labelprim1=goaddmarker(&coord,markersize,markertype,
                 retnodes->primitives,retnodes);
          if (pnodnum)
          {
            sprintf(buf," %i",femnodenum(mesh,nodeind));
            labelprim2=goaddtext(buf,&coord,
                retnodnums->primitives,retnodnums);
          }
        }
      }
    }
  }
      
dispindtab(&nodes); 
dispstackall(&coords);
dispstackallspec(&nodesafter,(void (*)(void **)) dispstack);
return ret;
#undef registernodeafter
}

/* A list of windows used for mesh plots */
static indtab meshwin=NULL;

void plotmeshtofile(femesh fm,char *filename,double fi, double theta,
                 char *str,vector param,int intfc,int winid)
    /* Plots a finite element mesh fm to a file named filename so that it can be
    visualized later. If filename is NULL or "" then the name of the file is
    chosen isn such a way that it is unique for one run of the program, which
    enables that several plots can be produced and kept in the current directory.
    The name begins with  "SGS_meshplot".
      fi and theta define the viewpoint and are set automatically in the case
    that mesh is 2D. 
      If str is different than NULL then this string is plotted on the top of the
    plot, and if vector of parameters param is different than NULL then its
    components are plotted. They are plotted beside the string (if it is not NULL),
    therefore the string must contain a newline in order to plot the components
    in a different line than a string (with some graphic interfaces this might not
    work, however).
      intfc defines the plotting interface to be used, such as SG_PLOT_TCL or 
    SG_PLOT_PS.
      If intfc specifies a screen interface (as opposed to file plotting) then
    winid can be used for a minimal window control. If winid is 0 then a new
    window is open every time this function is called. If it is greater than 0
    (a limit is 1000) then it represents an internal window ID and functions
    calls with the same winid will cause plotting to the same window.
    $A Igor feb04 mar04; */
{
int i=0,intfcid,textwritten=0,grp=0,numgrp=0,win;
double fc;
frame3d winlimits=NULL,frame=NULL;
golinesettings ls=NULL;
gofillsettings fs=NULL;
gotextsettings ts=NULL;
gogroup g2=NULL;
stack st=NULL,groups=NULL;
_truecolor fc1={0,0,0}, fc2={0,0,0};
if (fm!=NULL)
  if (fm->elgrp!=NULL)
    numgrp=fm->elgrp->n;
if (numgrp==0)
{
  warnfunc1(1,"plotmeshtofile");
  sprintf(ers(),"The mesh is NULL or it does not contain element groups.\n");
  warnfunc2();
} else
{
  groups=newstack(10);
  /* Frame in the window into which the graph should fir: */
  winlimits=malloc(sizeof(*winlimits));
  winlimits->min.x=0.1; winlimits->min.y=0.0; winlimits->max.x=0.7; winlimits->max.y=0.8;
  /* Geometrical limits of the graph: */
  frame=calloc(1,sizeof(*frame));
  /*
  frame->min.x=-1.3;    frame->min.y=-1.3;    frame->min.z=-1.3;
  frame->max.x=1.3;     frame->max.y=1.3;     frame->max.z=1.3;
  */

  /* Nastavitve za risanje crt: */
  ls=malloc(sizeof(*ls));
  ls->color.red=(float) 0; ls->color.green=(float) 0.7; ls->color.blue=(float) 0.4;
  ls->linewidth=1;
  ls->linetype=1;

  /* Nastavitve za risanje ploskev: */
  fs=malloc(sizeof(*fs));
  fs->color.red=0; fs->color.green=0; fs->color.blue=1;

  /* Nastavitve za risanje teksta: */
  ts=malloc(sizeof(*ts));
  ts->color.red=(float) 0.5; ts->color.green=(float) 0.1; ts->color.blue=(float) 0.7;
  ts->font=1;
  ts->height=0.01;
  ts->expansion=1;
  ts->xalignment=0;
  ts->yalignment=0;
  ts->height=0.008;
  
  /* Set fill collors, fc1 for the first and fc2 for the last group: */
  fc1.red=1.f; fc1.green=1.f; fc1.blue=0;
  fc2.red=0; fc2.green=1.f; fc2.blue=1.f;
  st=newstack(100);
  goloadtostack(g2,st);
  for (grp=1;grp<=numgrp;++grp)
  {
    /* fill settings: */

    fc=1 - (double) (grp-1)/(double) m_minval(1,(numgrp-1));
    dispgofillsettings(&fs);
    fs=malloc(sizeof(*fs));
    fs->color.red=(float) fc*(fc1.red)+(1.0f-(float) fc)*fc2.red; 
    fs->color.green=(float) fc*(fc1.green)+(1.0f-(float) fc)*fc2.green; 
    fs->color.blue=(float) fc*(fc1.blue)+(1.0f-(float) fc)*fc2.blue;
    
    
    /* Create plot of group grp of the mesh: */
    g2=gofemeshplotbas(fm,grp,
          0,1,0,0,
          0,0,0,
          /*
          fs,ls,
          ts,ts,
          ls,
          */
          fs,NULL,ts,NULL,NULL,
          2,0);
    fs=NULL;
    if (!textwritten && g2!=NULL && (str!=NULL || param!=NULL))
    {
      /* Add a text describing parameter values to the graph: */
      int i;
      char buf[100],*pos=buf;
      _coord3d pp1={0};
      vector mincoord=NULL,maxcoord=NULL;
      gotextsettings ts;
      textwritten=1;

      if (str!=NULL)
        pos+=sprintf(pos,"%s ",str);
      if (param!=NULL)
      {
        pos+=sprintf(pos,"p = { ");
        for (i=1;i<=param->d;++i)
        {
          pos+=sprintf(pos,"%g",param->v[i]);
          if (i<param->d)
            pos+=sprintf(pos,", ");
          else
            pos+=sprintf(pos," }");
        }
      }
      if (g2!=NULL)
        /*
        if (g2->groups!=NULL)
          if (g2->groups->n>0)
          */
          {
            if (g2->ts1==NULL)
            {
              /* Text settings: */
              ts=malloc(sizeof(*ts));
              ts->color.red=(float) 0.5; ts->color.green=(float) 0.1; ts->color.blue=(float) 0.7;
              ts->font=1;
              ts->height=0.01;
              ts->expansion=1;
              ts->xalignment=0;
              ts->yalignment=0;
              g2->ts1=ts;
              ts=NULL;
            }
            /* Calc. mesh co-ordinate limits: */
            femcalcgrplimits(fm,0,&mincoord,&maxcoord);
            pp1.x=(mincoord->v[1]+maxcoord->v[1])/2;
            if (mincoord->d==2)
              pp1.y=maxcoord->v[2]+0.08*(maxcoord->v[2]-mincoord->v[2]);
            else
              pp1.y=(mincoord->v[2]+maxcoord->v[2])/2;
            if (mincoord->d>2)
              pp1.z=maxcoord->v[3]+0.08*(maxcoord->v[3]-mincoord->v[3]);
            else
              pp1.z=0;
            if (g2->primitives==NULL)
              g2->primitives=newstack(100);
            goaddtext(buf,&pp1,g2->primitives,g2);
            /* Also plot a marker at the lower left corner: */
            pp1.x=pp1.y=pp1.z=0;
            pp1.x=mincoord->v[1]-0.06*(maxcoord->v[1]-mincoord->v[1]);
            if (mincoord->d>1)
              pp1.y=mincoord->v[2]-0.06*(maxcoord->v[2]-mincoord->v[2]);
            if (mincoord->d>2)
              pp1.z=mincoord->v[3]-0.06*(maxcoord->v[3]-mincoord->v[3]);
            goaddmarker(&pp1,0.01,1,g2->primitives,g2);
          }
      dispvector(&mincoord);
      dispvector(&maxcoord);   
    }

    calcgogroupframe(g2,frame);
    goloadtostack(g2,st);
    pushstack(groups,g2);
    g2=NULL;

  }

  /* Transform of primitives on st according to viewpoint: */
  preparegraph3dbas(frame,NULL /* winlimits */);
  if (femel2d( femgroup(fm,1), 1) )  /* viewpoint */
    gosettransfsimp(rad(-90),rad(90));
  else
    gosettransfsimp(rad(fi),rad(theta));
  gotransfstack(st);
  gosortstack(st);

  /* Plot: */
  intfcid=sg_interfaceid; /* save cur. plot. interface*/
  sg_interface(intfc);
  if (stringlength(filename)>0)
    sg_setplotfile(filename);
  else
    sg_setplotfileroot("SGS_meshplot");
  /* Window settings: */
  sg_setwindowtitle("Mesh_plot");
  sg_setwindowxpos(0.35f); sg_setwindowypos(0.f);
  sg_setwindowwidth((float) 0.75f); sg_setwindowheight((float) 1.0f);
  /* Open "window" (actualy a file) and draw: */
  if (sg_screeninterface(intfc) && winid>0)
  {
    if (meshwin==NULL)
      meshwin=newindtab(5,5);
    if (meshwin->n>=winid)
    {
      win=meshwin->t[winid];
      if (win>0)
        win=meshwin->t[winid]=sg_setwindow(win);
      else
        meshwin->t[winid]=win=sg_openwindow();
    } else
    {
      if (winid>1000)
      {
        warnfunc1(1,"");
        sprintf(ers(),"The internal window ID %i  is too high, should be less than 1000.\n",
          winid);
        warnfunc2();
        pushindtab(meshwin,(win=sg_openwindow()));
      } else
      {
        while(meshwin->n<winid)
          pushindtab(meshwin,0);
        win=meshwin->t[winid]=sg_openwindow();
      }
    }
  } else
    sg_openwindow();
  sg_clearwindow();
  sg_godrawstack(st);
  if (! sg_screeninterface(intfc) )
    sg_closewindow();
  if (intfcid>0)
    sg_interface(intfcid);  /* Restore the interface */
  /* Cleanup: */
  dispgogroup(&g2);
  dispstack(&st);
  dispstackallspec(&groups,(void (*)(void **)) dispgogroup);
  disppointer((void **) &winlimits);
  disppointer((void **) &frame);
  disppointer((void **) &ls);
  disppointer((void **) &fs);
  disppointer((void **) &ts);
  dispgogroup(&g2);
}
}


void plotmeshtcl(femesh fm,char *filename,double fi, double theta,
                 char *str,vector param)
    /* Plots a finite element mesh fm to a Tcl file named filename, which can
    be later interpreted by the wish shell in order to visualize the mesh.
    If filename is NULL or "" then the name of the file is chosen in such a
    way that it is unique for the current run of the program, which enables that
    several plots can be produced and kept in the current directory (the name in
    this case begins with "SGS_meshplot".
      fi and theta define the viewpoint and are set automatically in the case
    that mesh is 2D. 
      If str is different than NULL then this string is plotted on the top of the
    plot, and if vector of parameters param is different than NULL then its
    components are plotted. They are plotted beside the string (if it is not NULL),
    therefore the string must contain a newline in order to plot the components
    in a different line than a string (with some graphic interfaces this might not
    work, however).
    $A Igor mar04; */
{
plotmeshtofile(fm,filename,fi,theta,str,param,SG_PLOT_TCL,0);
}

void plotmeshps(femesh fm,char *filename,double fi, double theta,
                 char *str,vector param)
    /* Plots a finite element mesh fm to a Tcl file named filename, which can
    be later interpreted by the wish shell in order to visualize the mesh.
    If filename is NULL or "" then the name of the file is chosen in such a
    way that it is unique for the current run of the program, which enables that
    several plots can be produced and kept in the current directory (the name in
    this case begins with "SGS_meshplot".
      fi and theta define the viewpoint and are set automatically in the case
    that mesh is 2D. 
      If str is different than NULL then this string is plotted on the top of the
    plot, and if vector of parameters param is different than NULL then its
    components are plotted. They are plotted beside the string (if it is not NULL),
    therefore the string must contain a newline in order to plot the components
    in a different line than a string (with some graphic interfaces this might not
    work, however).
    $A Igor mar04; */
{
plotmeshtofile(fm,filename,fi,theta,str,param,SG_PLOT_PS,0);
}

void plotmesh(femesh fm,double fi, double theta,char *str,vector param,int winid)
    /* Plots a finite element mesh fm in a new window on the screen.
      fi and theta define the viewpoint and are set automatically in the case
    that mesh is 2D. 
      If str is different than NULL then this string is plotted on the top of the
    plot, and if vector of parameters param is different than NULL then its
    components are plotted. They are plotted beside the string (if it is not NULL),
    therefore the string must contain a newline in order to plot the components
    in a different line than a string (with some graphic interfaces this might not
    work, however).
      If winid is 0 then a new window is open every time this function is called.
    If it is greater than 0 (a limit is 1000) then it represents an internal 
    window ID and function calls with the same winid will cause plotting to the
    same window on the screen (with clearing executed before plotting).
    $A Igor mar04; */
{
plotmeshtofile(fm,NULL,fi,theta,str,param,SG_PLOT_BASIC,winid);
}







