
This is a program home directory for programs whose home does otherwise not
exist.


$A Igor jan02;
